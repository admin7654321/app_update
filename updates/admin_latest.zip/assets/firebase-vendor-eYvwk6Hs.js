const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3c62fe,_0x43ede3){if(!_0x3c62fe)throw ht(_0x43ede3);},ht=function(_0x4eb749){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4eb749);},Hr=function(_0x5a3cb8){const _0x3cabc5=[];let _0x5c14c8=0x0;for(let _0x371bef=0x0;_0x371bef<_0x5a3cb8['length'];_0x371bef++){let _0xc1956e=_0x5a3cb8['charCodeAt'](_0x371bef);_0xc1956e<0x80?_0x3cabc5[_0x5c14c8++]=_0xc1956e:_0xc1956e<0x800?(_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0x6|0xc0,_0x3cabc5[_0x5c14c8++]=_0xc1956e&0x3f|0x80):(_0xc1956e&0xfc00)===0xd800&&_0x371bef+0x1<_0x5a3cb8['length']&&(_0x5a3cb8['charCodeAt'](_0x371bef+0x1)&0xfc00)===0xdc00?(_0xc1956e=0x10000+((_0xc1956e&0x3ff)<<0xa)+(_0x5a3cb8['charCodeAt'](++_0x371bef)&0x3ff),_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0x12|0xf0,_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0xc&0x3f|0x80,_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0x6&0x3f|0x80,_0x3cabc5[_0x5c14c8++]=_0xc1956e&0x3f|0x80):(_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0xc|0xe0,_0x3cabc5[_0x5c14c8++]=_0xc1956e>>0x6&0x3f|0x80,_0x3cabc5[_0x5c14c8++]=_0xc1956e&0x3f|0x80);}return _0x3cabc5;},nc=function(_0x19ff97){const _0x2dc0de=[];let _0xa6c6fc=0x0,_0x47cac4=0x0;for(;_0xa6c6fc<_0x19ff97['length'];){const _0xb9fa3b=_0x19ff97[_0xa6c6fc++];if(_0xb9fa3b<0x80)_0x2dc0de[_0x47cac4++]=String['fromCharCode'](_0xb9fa3b);else{if(_0xb9fa3b>0xbf&&_0xb9fa3b<0xe0){const _0x2d4f10=_0x19ff97[_0xa6c6fc++];_0x2dc0de[_0x47cac4++]=String['fromCharCode']((_0xb9fa3b&0x1f)<<0x6|_0x2d4f10&0x3f);}else{if(_0xb9fa3b>0xef&&_0xb9fa3b<0x16d){const _0x201bbf=_0x19ff97[_0xa6c6fc++],_0x3297fa=_0x19ff97[_0xa6c6fc++],_0x46f75b=_0x19ff97[_0xa6c6fc++],_0x31c3bf=((_0xb9fa3b&0x7)<<0x12|(_0x201bbf&0x3f)<<0xc|(_0x3297fa&0x3f)<<0x6|_0x46f75b&0x3f)-0x10000;_0x2dc0de[_0x47cac4++]=String['fromCharCode'](0xd800+(_0x31c3bf>>0xa)),_0x2dc0de[_0x47cac4++]=String['fromCharCode'](0xdc00+(_0x31c3bf&0x3ff));}else{const _0x147536=_0x19ff97[_0xa6c6fc++],_0x2a7000=_0x19ff97[_0xa6c6fc++];_0x2dc0de[_0x47cac4++]=String['fromCharCode']((_0xb9fa3b&0xf)<<0xc|(_0x147536&0x3f)<<0x6|_0x2a7000&0x3f);}}}}return _0x2dc0de['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x41e9a7,_0x1a0ba7){if(!Array['isArray'](_0x41e9a7))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x18e046=_0x1a0ba7?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2fdf73=[];for(let _0x578579=0x0;_0x578579<_0x41e9a7['length'];_0x578579+=0x3){const _0x54dd97=_0x41e9a7[_0x578579],_0x39824e=_0x578579+0x1<_0x41e9a7['length'],_0x762510=_0x39824e?_0x41e9a7[_0x578579+0x1]:0x0,_0x3d922c=_0x578579+0x2<_0x41e9a7['length'],_0x587d6b=_0x3d922c?_0x41e9a7[_0x578579+0x2]:0x0,_0x491482=_0x54dd97>>0x2,_0x2c2fea=(_0x54dd97&0x3)<<0x4|_0x762510>>0x4;let _0x193829=(_0x762510&0xf)<<0x2|_0x587d6b>>0x6,_0xc5e383=_0x587d6b&0x3f;_0x3d922c||(_0xc5e383=0x40,_0x39824e||(_0x193829=0x40)),_0x2fdf73['push'](_0x18e046[_0x491482],_0x18e046[_0x2c2fea],_0x18e046[_0x193829],_0x18e046[_0xc5e383]);}return _0x2fdf73['join']('');},'encodeString'(_0x3810bc,_0x46ed72){return this['HAS_NATIVE_SUPPORT']&&!_0x46ed72?btoa(_0x3810bc):this['encodeByteArray'](Hr(_0x3810bc),_0x46ed72);},'decodeString'(_0x3e4f8f,_0x197a62){return this['HAS_NATIVE_SUPPORT']&&!_0x197a62?atob(_0x3e4f8f):nc(this['decodeStringToByteArray'](_0x3e4f8f,_0x197a62));},'decodeStringToByteArray'(_0x346c3f,_0x4bb020){this['init_']();const _0x4c032e=_0x4bb020?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5317d1=[];for(let _0x3a7b63=0x0;_0x3a7b63<_0x346c3f['length'];){const _0x1f5f1d=_0x4c032e[_0x346c3f['charAt'](_0x3a7b63++)],_0x29f893=_0x3a7b63<_0x346c3f['length']?_0x4c032e[_0x346c3f['charAt'](_0x3a7b63)]:0x0;++_0x3a7b63;const _0x2aab09=_0x3a7b63<_0x346c3f['length']?_0x4c032e[_0x346c3f['charAt'](_0x3a7b63)]:0x40;++_0x3a7b63;const _0x158de4=_0x3a7b63<_0x346c3f['length']?_0x4c032e[_0x346c3f['charAt'](_0x3a7b63)]:0x40;if(++_0x3a7b63,_0x1f5f1d==null||_0x29f893==null||_0x2aab09==null||_0x158de4==null)throw new ic();const _0x48ff42=_0x1f5f1d<<0x2|_0x29f893>>0x4;if(_0x5317d1['push'](_0x48ff42),_0x2aab09!==0x40){const _0x2eb828=_0x29f893<<0x4&0xf0|_0x2aab09>>0x2;if(_0x5317d1['push'](_0x2eb828),_0x158de4!==0x40){const _0x50d7d4=_0x2aab09<<0x6&0xc0|_0x158de4;_0x5317d1['push'](_0x50d7d4);}}}return _0x5317d1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5cb8a5=0x0;_0x5cb8a5<this['ENCODED_VALS']['length'];_0x5cb8a5++)this['byteToCharMap_'][_0x5cb8a5]=this['ENCODED_VALS']['charAt'](_0x5cb8a5),this['charToByteMap_'][this['byteToCharMap_'][_0x5cb8a5]]=_0x5cb8a5,this['byteToCharMapWebSafe_'][_0x5cb8a5]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5cb8a5),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5cb8a5]]=_0x5cb8a5,_0x5cb8a5>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5cb8a5)]=_0x5cb8a5,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5cb8a5)]=_0x5cb8a5);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x33c6c9){const _0x1594cc=Hr(_0x33c6c9);return Fi['encodeByteArray'](_0x1594cc,!0x0);},dn=function(_0x50cd56){return $r(_0x50cd56)['replace'](/\./g,'');},fn=function(_0x25103c){try{return Fi['decodeString'](_0x25103c,!0x0);}catch(_0x41482a){console['error']('base64Decode\x20failed:\x20',_0x41482a);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x635a39){return Gr(void 0x0,_0x635a39);}function Gr(_0x5d667f,_0xdcd50e){if(!(_0xdcd50e instanceof Object))return _0xdcd50e;switch(_0xdcd50e['constructor']){case Date:const _0x28c4e9=_0xdcd50e;return new Date(_0x28c4e9['getTime']());case Object:_0x5d667f===void 0x0&&(_0x5d667f={});break;case Array:_0x5d667f=[];break;default:return _0xdcd50e;}for(const _0x3989be in _0xdcd50e)!_0xdcd50e['hasOwnProperty'](_0x3989be)||!rc(_0x3989be)||(_0x5d667f[_0x3989be]=Gr(_0x5d667f[_0x3989be],_0xdcd50e[_0x3989be]));return _0x5d667f;}function rc(_0x33962c){return _0x33962c!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x36f616=Ps['__FIREBASE_DEFAULTS__'];if(_0x36f616)return JSON['parse'](_0x36f616);},lc=()=>{if(typeof document>'u')return;let _0x4cf523;try{_0x4cf523=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4ac8fc=_0x4cf523&&fn(_0x4cf523[0x1]);return _0x4ac8fc&&JSON['parse'](_0x4ac8fc);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x319066){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x319066);return;}},qr=_0x1faf33=>{var _0x13f438,_0x46e07a;return(_0x46e07a=(_0x13f438=Ui())==null?void 0x0:_0x13f438['emulatorHosts'])==null?void 0x0:_0x46e07a[_0x1faf33];},hc=_0x157891=>{const _0x40b138=qr(_0x157891);if(!_0x40b138)return;const _0x20576a=_0x40b138['lastIndexOf'](':');if(_0x20576a<=0x0||_0x20576a+0x1===_0x40b138['length'])throw new Error('Invalid\x20host\x20'+_0x40b138+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x269158=parseInt(_0x40b138['substring'](_0x20576a+0x1),0xa);return _0x40b138[0x0]==='['?[_0x40b138['substring'](0x1,_0x20576a-0x1),_0x269158]:[_0x40b138['substring'](0x0,_0x20576a),_0x269158];},zr=()=>{var _0xc2b2d1;return(_0xc2b2d1=Ui())==null?void 0x0:_0xc2b2d1['config'];},jr=_0x5c3be3=>{var _0x5de877;return(_0x5de877=Ui())==null?void 0x0:_0x5de877['_'+_0x5c3be3];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x19654e,_0x2b23fe)=>{this['resolve']=_0x19654e,this['reject']=_0x2b23fe;});}['wrapCallback'](_0x3d78df){return(_0x2a4abc,_0x5c8307)=>{_0x2a4abc?this['reject'](_0x2a4abc):this['resolve'](_0x5c8307),typeof _0x3d78df=='function'&&(this['promise']['catch'](()=>{}),_0x3d78df['length']===0x1?_0x3d78df(_0x2a4abc):_0x3d78df(_0x2a4abc,_0x5c8307));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x237418,_0x460460){if(_0x237418['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x57c6c3={'alg':'none','type':'JWT'},_0x3b2387=_0x460460||'demo-project',_0x3a1a95=_0x237418['iat']||0x0,_0x24da44=_0x237418['sub']||_0x237418['user_id'];if(!_0x24da44)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5081ba={'iss':'https://securetoken.google.com/'+_0x3b2387,'aud':_0x3b2387,'iat':_0x3a1a95,'exp':_0x3a1a95+0xe10,'auth_time':_0x3a1a95,'sub':_0x24da44,'user_id':_0x24da44,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x237418};return[dn(JSON['stringify'](_0x57c6c3)),dn(JSON['stringify'](_0x5081ba)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x231dd1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x231dd1=='object'&&_0x231dd1['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2180a1=W();return _0x2180a1['indexOf']('MSIE\x20')>=0x0||_0x2180a1['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x8a6883,_0xb006cf)=>{try{let _0x2cf5e1=!0x0;const _0x31e67e='validate-browser-context-for-indexeddb-analytics-module',_0x99f253=self['indexedDB']['open'](_0x31e67e);_0x99f253['onsuccess']=()=>{_0x99f253['result']['close'](),_0x2cf5e1||self['indexedDB']['deleteDatabase'](_0x31e67e),_0x8a6883(!0x0);},_0x99f253['onupgradeneeded']=()=>{_0x2cf5e1=!0x1;},_0x99f253['onerror']=()=>{var _0x55ea8f;_0xb006cf(((_0x55ea8f=_0x99f253['error'])==null?void 0x0:_0x55ea8f['message'])||'');};}catch(_0x17b8aa){_0xb006cf(_0x17b8aa);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x253933,_0x41cf05,_0x5cd2a8){super(_0x41cf05),this['code']=_0x253933,this['customData']=_0x5cd2a8,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x3c9f34,_0x462bf8,_0x59859e){this['service']=_0x3c9f34,this['serviceName']=_0x462bf8,this['errors']=_0x59859e;}['create'](_0x21e22f,..._0x494a17){const _0x2523fe=_0x494a17[0x0]||{},_0x1ef30e=this['service']+'/'+_0x21e22f,_0x398b1c=this['errors'][_0x21e22f],_0x17a876=_0x398b1c?vc(_0x398b1c,_0x2523fe):'Error',_0x4ee77b=this['serviceName']+':\x20'+_0x17a876+'\x20('+_0x1ef30e+').';return new Re(_0x1ef30e,_0x4ee77b,_0x2523fe);}}function vc(_0x259561,_0x556363){return _0x259561['replace'](Ec,(_0x5a3208,_0x1efc83)=>{const _0x22924c=_0x556363[_0x1efc83];return _0x22924c!=null?String(_0x22924c):'<'+_0x1efc83+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x3e8c10){return JSON['parse'](_0x3e8c10);}function O(_0x2b282b){return JSON['stringify'](_0x2b282b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x979f17){let _0x491786={},_0x3d6b5b={},_0xc825d0={},_0x339bc7='';try{const _0x5cdcbb=_0x979f17['split']('.');_0x491786=Nt(fn(_0x5cdcbb[0x0])||''),_0x3d6b5b=Nt(fn(_0x5cdcbb[0x1])||''),_0x339bc7=_0x5cdcbb[0x2],_0xc825d0=_0x3d6b5b['d']||{},delete _0x3d6b5b['d'];}catch{}return{'header':_0x491786,'claims':_0x3d6b5b,'data':_0xc825d0,'signature':_0x339bc7};},Ic=function(_0x309bf7){const _0x4da2b3=Yr(_0x309bf7),_0x5e814f=_0x4da2b3['claims'];return!!_0x5e814f&&typeof _0x5e814f=='object'&&_0x5e814f['hasOwnProperty']('iat');},wc=function(_0x274096){const _0x1d1742=Yr(_0x274096)['claims'];return typeof _0x1d1742=='object'&&_0x1d1742['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x3b22ee,_0x91bbf9){return Object['prototype']['hasOwnProperty']['call'](_0x3b22ee,_0x91bbf9);}function Le(_0x24d096,_0x232496){if(Object['prototype']['hasOwnProperty']['call'](_0x24d096,_0x232496))return _0x24d096[_0x232496];}function pn(_0x1c5478){for(const _0x73db85 in _0x1c5478)if(Object['prototype']['hasOwnProperty']['call'](_0x1c5478,_0x73db85))return!0x1;return!0x0;}function _n(_0x56a37c,_0x48232f,_0xad2ee){const _0x440911={};for(const _0x35c106 in _0x56a37c)Object['prototype']['hasOwnProperty']['call'](_0x56a37c,_0x35c106)&&(_0x440911[_0x35c106]=_0x48232f['call'](_0xad2ee,_0x56a37c[_0x35c106],_0x35c106,_0x56a37c));return _0x440911;}function xe(_0xa8a293,_0xe9352b){if(_0xa8a293===_0xe9352b)return!0x0;const _0x2f57c1=Object['keys'](_0xa8a293),_0x4ea94a=Object['keys'](_0xe9352b);for(const _0x15ded5 of _0x2f57c1){if(!_0x4ea94a['includes'](_0x15ded5))return!0x1;const _0x511ace=_0xa8a293[_0x15ded5],_0x506ed6=_0xe9352b[_0x15ded5];if(Ns(_0x511ace)&&Ns(_0x506ed6)){if(!xe(_0x511ace,_0x506ed6))return!0x1;}else{if(_0x511ace!==_0x506ed6)return!0x1;}}for(const _0x3ad650 of _0x4ea94a)if(!_0x2f57c1['includes'](_0x3ad650))return!0x1;return!0x0;}function Ns(_0x3719ee){return _0x3719ee!==null&&typeof _0x3719ee=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x542dc3){const _0x2dbaba=[];for(const [_0x731f29,_0x53c617]of Object['entries'](_0x542dc3))Array['isArray'](_0x53c617)?_0x53c617['forEach'](_0x4ffb37=>{_0x2dbaba['push'](encodeURIComponent(_0x731f29)+'='+encodeURIComponent(_0x4ffb37));}):_0x2dbaba['push'](encodeURIComponent(_0x731f29)+'='+encodeURIComponent(_0x53c617));return _0x2dbaba['length']?'&'+_0x2dbaba['join']('&'):'';}function Ct(_0x452300){const _0x1de493={};return _0x452300['replace'](/^\?/,'')['split']('&')['forEach'](_0x16a4fe=>{if(_0x16a4fe){const [_0x3a6165,_0x10523d]=_0x16a4fe['split']('=');_0x1de493[decodeURIComponent(_0x3a6165)]=decodeURIComponent(_0x10523d);}}),_0x1de493;}function Tt(_0x24c64d){const _0xd2563e=_0x24c64d['indexOf']('?');if(!_0xd2563e)return'';const _0x3c1936=_0x24c64d['indexOf']('#',_0xd2563e);return _0x24c64d['substring'](_0xd2563e,_0x3c1936>0x0?_0x3c1936:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x455018=0x1;_0x455018<this['blockSize'];++_0x455018)this['pad_'][_0x455018]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x129ac8,_0x16ee4f){_0x16ee4f||(_0x16ee4f=0x0);const _0x54c915=this['W_'];if(typeof _0x129ac8=='string'){for(let _0x3fa1d0=0x0;_0x3fa1d0<0x10;_0x3fa1d0++)_0x54c915[_0x3fa1d0]=_0x129ac8['charCodeAt'](_0x16ee4f)<<0x18|_0x129ac8['charCodeAt'](_0x16ee4f+0x1)<<0x10|_0x129ac8['charCodeAt'](_0x16ee4f+0x2)<<0x8|_0x129ac8['charCodeAt'](_0x16ee4f+0x3),_0x16ee4f+=0x4;}else{for(let _0x2f9f86=0x0;_0x2f9f86<0x10;_0x2f9f86++)_0x54c915[_0x2f9f86]=_0x129ac8[_0x16ee4f]<<0x18|_0x129ac8[_0x16ee4f+0x1]<<0x10|_0x129ac8[_0x16ee4f+0x2]<<0x8|_0x129ac8[_0x16ee4f+0x3],_0x16ee4f+=0x4;}for(let _0x4f7857=0x10;_0x4f7857<0x50;_0x4f7857++){const _0x228dbf=_0x54c915[_0x4f7857-0x3]^_0x54c915[_0x4f7857-0x8]^_0x54c915[_0x4f7857-0xe]^_0x54c915[_0x4f7857-0x10];_0x54c915[_0x4f7857]=(_0x228dbf<<0x1|_0x228dbf>>>0x1f)&0xffffffff;}let _0x4d8432=this['chain_'][0x0],_0x5ea5d9=this['chain_'][0x1],_0x5a1350=this['chain_'][0x2],_0x51eb2b=this['chain_'][0x3],_0x294f81=this['chain_'][0x4],_0x298d4f,_0x5a6029;for(let _0x109db4=0x0;_0x109db4<0x50;_0x109db4++){_0x109db4<0x28?_0x109db4<0x14?(_0x298d4f=_0x51eb2b^_0x5ea5d9&(_0x5a1350^_0x51eb2b),_0x5a6029=0x5a827999):(_0x298d4f=_0x5ea5d9^_0x5a1350^_0x51eb2b,_0x5a6029=0x6ed9eba1):_0x109db4<0x3c?(_0x298d4f=_0x5ea5d9&_0x5a1350|_0x51eb2b&(_0x5ea5d9|_0x5a1350),_0x5a6029=0x8f1bbcdc):(_0x298d4f=_0x5ea5d9^_0x5a1350^_0x51eb2b,_0x5a6029=0xca62c1d6);const _0x7e4cd=(_0x4d8432<<0x5|_0x4d8432>>>0x1b)+_0x298d4f+_0x294f81+_0x5a6029+_0x54c915[_0x109db4]&0xffffffff;_0x294f81=_0x51eb2b,_0x51eb2b=_0x5a1350,_0x5a1350=(_0x5ea5d9<<0x1e|_0x5ea5d9>>>0x2)&0xffffffff,_0x5ea5d9=_0x4d8432,_0x4d8432=_0x7e4cd;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4d8432&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5ea5d9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5a1350&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x51eb2b&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x294f81&0xffffffff;}['update'](_0x737ca7,_0x21ee4b){if(_0x737ca7==null)return;_0x21ee4b===void 0x0&&(_0x21ee4b=_0x737ca7['length']);const _0x522237=_0x21ee4b-this['blockSize'];let _0x54deb5=0x0;const _0x5e76ef=this['buf_'];let _0x780b0f=this['inbuf_'];for(;_0x54deb5<_0x21ee4b;){if(_0x780b0f===0x0){for(;_0x54deb5<=_0x522237;)this['compress_'](_0x737ca7,_0x54deb5),_0x54deb5+=this['blockSize'];}if(typeof _0x737ca7=='string'){for(;_0x54deb5<_0x21ee4b;)if(_0x5e76ef[_0x780b0f]=_0x737ca7['charCodeAt'](_0x54deb5),++_0x780b0f,++_0x54deb5,_0x780b0f===this['blockSize']){this['compress_'](_0x5e76ef),_0x780b0f=0x0;break;}}else{for(;_0x54deb5<_0x21ee4b;)if(_0x5e76ef[_0x780b0f]=_0x737ca7[_0x54deb5],++_0x780b0f,++_0x54deb5,_0x780b0f===this['blockSize']){this['compress_'](_0x5e76ef),_0x780b0f=0x0;break;}}}this['inbuf_']=_0x780b0f,this['total_']+=_0x21ee4b;}['digest'](){const _0x138ed5=[];let _0x5e999d=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x174eb7=this['blockSize']-0x1;_0x174eb7>=0x38;_0x174eb7--)this['buf_'][_0x174eb7]=_0x5e999d&0xff,_0x5e999d/=0x100;this['compress_'](this['buf_']);let _0x2502b9=0x0;for(let _0x2ef2dd=0x0;_0x2ef2dd<0x5;_0x2ef2dd++)for(let _0xc003cf=0x18;_0xc003cf>=0x0;_0xc003cf-=0x8)_0x138ed5[_0x2502b9]=this['chain_'][_0x2ef2dd]>>_0xc003cf&0xff,++_0x2502b9;return _0x138ed5;}}function Tc(_0x1fbfe7,_0x1c803e){const _0x5a098c=new Sc(_0x1fbfe7,_0x1c803e);return _0x5a098c['subscribe']['bind'](_0x5a098c);}class Sc{constructor(_0x4fa74a,_0x4e31cf){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4e31cf,this['task']['then'](()=>{_0x4fa74a(this);})['catch'](_0x12409a=>{this['error'](_0x12409a);});}['next'](_0x3f568b){this['forEachObserver'](_0x40d39a=>{_0x40d39a['next'](_0x3f568b);});}['error'](_0x56646e){this['forEachObserver'](_0x5bb020=>{_0x5bb020['error'](_0x56646e);}),this['close'](_0x56646e);}['complete'](){this['forEachObserver'](_0x381990=>{_0x381990['complete']();}),this['close']();}['subscribe'](_0x5f56d7,_0x311393,_0x500c45){let _0x1dc659;if(_0x5f56d7===void 0x0&&_0x311393===void 0x0&&_0x500c45===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x5f56d7,['next','error','complete'])?_0x1dc659=_0x5f56d7:_0x1dc659={'next':_0x5f56d7,'error':_0x311393,'complete':_0x500c45},_0x1dc659['next']===void 0x0&&(_0x1dc659['next']=ti),_0x1dc659['error']===void 0x0&&(_0x1dc659['error']=ti),_0x1dc659['complete']===void 0x0&&(_0x1dc659['complete']=ti);const _0x10274d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1dc659['error'](this['finalError']):_0x1dc659['complete']();}catch{}}),this['observers']['push'](_0x1dc659),_0x10274d;}['unsubscribeOne'](_0x3e2375){this['observers']===void 0x0||this['observers'][_0x3e2375]===void 0x0||(delete this['observers'][_0x3e2375],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x19e50f){if(!this['finalized']){for(let _0x308b6e=0x0;_0x308b6e<this['observers']['length'];_0x308b6e++)this['sendOne'](_0x308b6e,_0x19e50f);}}['sendOne'](_0x17b873,_0x9d2482){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x17b873]!==void 0x0)try{_0x9d2482(this['observers'][_0x17b873]);}catch(_0x1955fb){typeof console<'u'&&console['error']&&console['error'](_0x1955fb);}});}['close'](_0x534634){this['finalized']||(this['finalized']=!0x0,_0x534634!==void 0x0&&(this['finalError']=_0x534634),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x300168,_0x4efa3c){if(typeof _0x300168!='object'||_0x300168===null)return!0x1;for(const _0x460b18 of _0x4efa3c)if(_0x460b18 in _0x300168&&typeof _0x300168[_0x460b18]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x22fa5c,_0x3565c8){return _0x22fa5c+'\x20failed:\x20'+_0x3565c8+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4be5b4){const _0x46d997=[];let _0x5fc6af=0x0;for(let _0x5ed970=0x0;_0x5ed970<_0x4be5b4['length'];_0x5ed970++){let _0x343ed5=_0x4be5b4['charCodeAt'](_0x5ed970);if(_0x343ed5>=0xd800&&_0x343ed5<=0xdbff){const _0x5c94f7=_0x343ed5-0xd800;_0x5ed970++,f(_0x5ed970<_0x4be5b4['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x151af=_0x4be5b4['charCodeAt'](_0x5ed970)-0xdc00;_0x343ed5=0x10000+(_0x5c94f7<<0xa)+_0x151af;}_0x343ed5<0x80?_0x46d997[_0x5fc6af++]=_0x343ed5:_0x343ed5<0x800?(_0x46d997[_0x5fc6af++]=_0x343ed5>>0x6|0xc0,_0x46d997[_0x5fc6af++]=_0x343ed5&0x3f|0x80):_0x343ed5<0x10000?(_0x46d997[_0x5fc6af++]=_0x343ed5>>0xc|0xe0,_0x46d997[_0x5fc6af++]=_0x343ed5>>0x6&0x3f|0x80,_0x46d997[_0x5fc6af++]=_0x343ed5&0x3f|0x80):(_0x46d997[_0x5fc6af++]=_0x343ed5>>0x12|0xf0,_0x46d997[_0x5fc6af++]=_0x343ed5>>0xc&0x3f|0x80,_0x46d997[_0x5fc6af++]=_0x343ed5>>0x6&0x3f|0x80,_0x46d997[_0x5fc6af++]=_0x343ed5&0x3f|0x80);}return _0x46d997;},Ln=function(_0x176c75){let _0x4c143b=0x0;for(let _0x192707=0x0;_0x192707<_0x176c75['length'];_0x192707++){const _0x2bffe9=_0x176c75['charCodeAt'](_0x192707);_0x2bffe9<0x80?_0x4c143b++:_0x2bffe9<0x800?_0x4c143b+=0x2:_0x2bffe9>=0xd800&&_0x2bffe9<=0xdbff?(_0x4c143b+=0x4,_0x192707++):_0x4c143b+=0x3;}return _0x4c143b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3a08fb){return _0x3a08fb&&_0x3a08fb['_delegate']?_0x3a08fb['_delegate']:_0x3a08fb;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x55a721){try{return(_0x55a721['startsWith']('http://')||_0x55a721['startsWith']('https://')?new URL(_0x55a721)['hostname']:_0x55a721)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3300ce){return(await fetch(_0x3300ce,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x489e39,_0x5fd9db,_0x2cd450){this['name']=_0x489e39,this['instanceFactory']=_0x5fd9db,this['type']=_0x2cd450,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3a1549){return this['instantiationMode']=_0x3a1549,this;}['setMultipleInstances'](_0x28cdb5){return this['multipleInstances']=_0x28cdb5,this;}['setServiceProps'](_0x35624f){return this['serviceProps']=_0x35624f,this;}['setInstanceCreatedCallback'](_0x5bb198){return this['onInstanceCreated']=_0x5bb198,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x27aa6f,_0x3d082b){this['name']=_0x27aa6f,this['container']=_0x3d082b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3acd31){const _0x6c6022=this['normalizeInstanceIdentifier'](_0x3acd31);if(!this['instancesDeferred']['has'](_0x6c6022)){const _0x3520fb=new H();if(this['instancesDeferred']['set'](_0x6c6022,_0x3520fb),this['isInitialized'](_0x6c6022)||this['shouldAutoInitialize']())try{const _0x560d4f=this['getOrInitializeService']({'instanceIdentifier':_0x6c6022});_0x560d4f&&_0x3520fb['resolve'](_0x560d4f);}catch{}}return this['instancesDeferred']['get'](_0x6c6022)['promise'];}['getImmediate'](_0x8619d3){const _0x4abbf5=this['normalizeInstanceIdentifier'](_0x8619d3==null?void 0x0:_0x8619d3['identifier']),_0x237a74=(_0x8619d3==null?void 0x0:_0x8619d3['optional'])??!0x1;if(this['isInitialized'](_0x4abbf5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4abbf5});}catch(_0x5e92ac){if(_0x237a74)return null;throw _0x5e92ac;}else{if(_0x237a74)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x7f1646){if(_0x7f1646['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x7f1646['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x7f1646,!!this['shouldAutoInitialize']()){if(Pc(_0x7f1646))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x11a2c9,_0xbdaf4e]of this['instancesDeferred']['entries']()){const _0x165dde=this['normalizeInstanceIdentifier'](_0x11a2c9);try{const _0x40d6ec=this['getOrInitializeService']({'instanceIdentifier':_0x165dde});_0xbdaf4e['resolve'](_0x40d6ec);}catch{}}}}['clearInstance'](_0x128d91=Ne){this['instancesDeferred']['delete'](_0x128d91),this['instancesOptions']['delete'](_0x128d91),this['instances']['delete'](_0x128d91);}async['delete'](){const _0x213a59=Array['from'](this['instances']['values']());await Promise['all']([..._0x213a59['filter'](_0x3d2ad8=>'INTERNAL'in _0x3d2ad8)['map'](_0x2f371e=>_0x2f371e['INTERNAL']['delete']()),..._0x213a59['filter'](_0x1c1ba4=>'_delete'in _0x1c1ba4)['map'](_0x538937=>_0x538937['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x16b273=Ne){return this['instances']['has'](_0x16b273);}['getOptions'](_0x13b9e7=Ne){return this['instancesOptions']['get'](_0x13b9e7)||{};}['initialize'](_0x4e2c4f={}){const {options:_0x56e9da={}}=_0x4e2c4f,_0x4b27b4=this['normalizeInstanceIdentifier'](_0x4e2c4f['instanceIdentifier']);if(this['isInitialized'](_0x4b27b4))throw Error(this['name']+'('+_0x4b27b4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x59aaf0=this['getOrInitializeService']({'instanceIdentifier':_0x4b27b4,'options':_0x56e9da});for(const [_0x3190a1,_0x3289b9]of this['instancesDeferred']['entries']()){const _0x1510fe=this['normalizeInstanceIdentifier'](_0x3190a1);_0x4b27b4===_0x1510fe&&_0x3289b9['resolve'](_0x59aaf0);}return _0x59aaf0;}['onInit'](_0x1f9174,_0x2abeed){const _0x2a62a0=this['normalizeInstanceIdentifier'](_0x2abeed),_0x326a2a=this['onInitCallbacks']['get'](_0x2a62a0)??new Set();_0x326a2a['add'](_0x1f9174),this['onInitCallbacks']['set'](_0x2a62a0,_0x326a2a);const _0x2175a4=this['instances']['get'](_0x2a62a0);return _0x2175a4&&_0x1f9174(_0x2175a4,_0x2a62a0),()=>{_0x326a2a['delete'](_0x1f9174);};}['invokeOnInitCallbacks'](_0x206bbf,_0x5d9717){const _0x5ab307=this['onInitCallbacks']['get'](_0x5d9717);if(_0x5ab307){for(const _0x333f34 of _0x5ab307)try{_0x333f34(_0x206bbf,_0x5d9717);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2434e0,options:_0x591017={}}){let _0x5dd3ff=this['instances']['get'](_0x2434e0);if(!_0x5dd3ff&&this['component']&&(_0x5dd3ff=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2434e0),'options':_0x591017}),this['instances']['set'](_0x2434e0,_0x5dd3ff),this['instancesOptions']['set'](_0x2434e0,_0x591017),this['invokeOnInitCallbacks'](_0x5dd3ff,_0x2434e0),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2434e0,_0x5dd3ff);}catch{}return _0x5dd3ff||null;}['normalizeInstanceIdentifier'](_0x1b5d9f=Ne){return this['component']?this['component']['multipleInstances']?_0x1b5d9f:Ne:_0x1b5d9f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x388bee){return _0x388bee===Ne?void 0x0:_0x388bee;}function Pc(_0x17b4d3){return _0x17b4d3['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x53bbc5){this['name']=_0x53bbc5,this['providers']=new Map();}['addComponent'](_0x5ef394){const _0x2f142f=this['getProvider'](_0x5ef394['name']);if(_0x2f142f['isComponentSet']())throw new Error('Component\x20'+_0x5ef394['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2f142f['setComponent'](_0x5ef394);}['addOrOverwriteComponent'](_0x2aa0ca){this['getProvider'](_0x2aa0ca['name'])['isComponentSet']()&&this['providers']['delete'](_0x2aa0ca['name']),this['addComponent'](_0x2aa0ca);}['getProvider'](_0x528722){if(this['providers']['has'](_0x528722))return this['providers']['get'](_0x528722);const _0x485d55=new Ac(_0x528722,this);return this['providers']['set'](_0x528722,_0x485d55),_0x485d55;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5c9e75){_0x5c9e75[_0x5c9e75['DEBUG']=0x0]='DEBUG',_0x5c9e75[_0x5c9e75['VERBOSE']=0x1]='VERBOSE',_0x5c9e75[_0x5c9e75['INFO']=0x2]='INFO',_0x5c9e75[_0x5c9e75['WARN']=0x3]='WARN',_0x5c9e75[_0x5c9e75['ERROR']=0x4]='ERROR',_0x5c9e75[_0x5c9e75['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x8d01b3,_0x1765bb,..._0x2ebd6a)=>{if(_0x1765bb<_0x8d01b3['logLevel'])return;const _0x3fc418=new Date()['toISOString'](),_0x241af3=Mc[_0x1765bb];if(_0x241af3)console[_0x241af3]('['+_0x3fc418+']\x20\x20'+_0x8d01b3['name']+':',..._0x2ebd6a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1765bb+')');};class Bi{constructor(_0x311bb7){this['name']=_0x311bb7,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4a3d14){if(!(_0x4a3d14 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4a3d14+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4a3d14;}['setLogLevel'](_0x555ba7){this['_logLevel']=typeof _0x555ba7=='string'?Oc[_0x555ba7]:_0x555ba7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x44ee37){if(typeof _0x44ee37!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x44ee37;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2832d8){this['_userLogHandler']=_0x2832d8;}['debug'](..._0x4a45dd){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4a45dd),this['_logHandler'](this,T['DEBUG'],..._0x4a45dd);}['log'](..._0x201448){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x201448),this['_logHandler'](this,T['VERBOSE'],..._0x201448);}['info'](..._0x8999e7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x8999e7),this['_logHandler'](this,T['INFO'],..._0x8999e7);}['warn'](..._0x581d89){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x581d89),this['_logHandler'](this,T['WARN'],..._0x581d89);}['error'](..._0x269013){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x269013),this['_logHandler'](this,T['ERROR'],..._0x269013);}}const xc=(_0x53ad7f,_0x405aa9)=>_0x405aa9['some'](_0x4452e0=>_0x53ad7f instanceof _0x4452e0);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x55f712){const _0x348a9b=new Promise((_0x3697ee,_0x206731)=>{const _0x4ccd98=()=>{_0x55f712['removeEventListener']('success',_0x3f2f15),_0x55f712['removeEventListener']('error',_0x1415d8);},_0x3f2f15=()=>{_0x3697ee(ge(_0x55f712['result'])),_0x4ccd98();},_0x1415d8=()=>{_0x206731(_0x55f712['error']),_0x4ccd98();};_0x55f712['addEventListener']('success',_0x3f2f15),_0x55f712['addEventListener']('error',_0x1415d8);});return _0x348a9b['then'](_0x434725=>{_0x434725 instanceof IDBCursor&&Jr['set'](_0x434725,_0x55f712);})['catch'](()=>{}),Vi['set'](_0x348a9b,_0x55f712),_0x348a9b;}function Bc(_0x1ebd47){if(_i['has'](_0x1ebd47))return;const _0x346e1c=new Promise((_0x5667f5,_0x187bf0)=>{const _0x3ff086=()=>{_0x1ebd47['removeEventListener']('complete',_0x1ed6cc),_0x1ebd47['removeEventListener']('error',_0x4d6d9b),_0x1ebd47['removeEventListener']('abort',_0x4d6d9b);},_0x1ed6cc=()=>{_0x5667f5(),_0x3ff086();},_0x4d6d9b=()=>{_0x187bf0(_0x1ebd47['error']||new DOMException('AbortError','AbortError')),_0x3ff086();};_0x1ebd47['addEventListener']('complete',_0x1ed6cc),_0x1ebd47['addEventListener']('error',_0x4d6d9b),_0x1ebd47['addEventListener']('abort',_0x4d6d9b);});_i['set'](_0x1ebd47,_0x346e1c);}let gi={'get'(_0x325c34,_0x14ff42,_0x3916e1){if(_0x325c34 instanceof IDBTransaction){if(_0x14ff42==='done')return _i['get'](_0x325c34);if(_0x14ff42==='objectStoreNames')return _0x325c34['objectStoreNames']||Xr['get'](_0x325c34);if(_0x14ff42==='store')return _0x3916e1['objectStoreNames'][0x1]?void 0x0:_0x3916e1['objectStore'](_0x3916e1['objectStoreNames'][0x0]);}return ge(_0x325c34[_0x14ff42]);},'set'(_0x2bd40e,_0x2aa4bd,_0x6500a5){return _0x2bd40e[_0x2aa4bd]=_0x6500a5,!0x0;},'has'(_0x4599c6,_0x3144cd){return _0x4599c6 instanceof IDBTransaction&&(_0x3144cd==='done'||_0x3144cd==='store')?!0x0:_0x3144cd in _0x4599c6;}};function Vc(_0x3f9a96){gi=_0x3f9a96(gi);}function Hc(_0x203a08){return _0x203a08===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x44a871,..._0x2ef3e2){const _0x1ee269=_0x203a08['call'](ii(this),_0x44a871,..._0x2ef3e2);return Xr['set'](_0x1ee269,_0x44a871['sort']?_0x44a871['sort']():[_0x44a871]),ge(_0x1ee269);}:Uc()['includes'](_0x203a08)?function(..._0x272efa){return _0x203a08['apply'](ii(this),_0x272efa),ge(Jr['get'](this));}:function(..._0x511b72){return ge(_0x203a08['apply'](ii(this),_0x511b72));};}function $c(_0x2a44cb){return typeof _0x2a44cb=='function'?Hc(_0x2a44cb):(_0x2a44cb instanceof IDBTransaction&&Bc(_0x2a44cb),xc(_0x2a44cb,Fc())?new Proxy(_0x2a44cb,gi):_0x2a44cb);}function ge(_0xed527c){if(_0xed527c instanceof IDBRequest)return Wc(_0xed527c);if(ni['has'](_0xed527c))return ni['get'](_0xed527c);const _0x18cb14=$c(_0xed527c);return _0x18cb14!==_0xed527c&&(ni['set'](_0xed527c,_0x18cb14),Vi['set'](_0x18cb14,_0xed527c)),_0x18cb14;}const ii=_0x4b1c18=>Vi['get'](_0x4b1c18);function Gc(_0x51fa8c,_0x54fe32,{blocked:_0x5c8f98,upgrade:_0x5c9f89,blocking:_0x39045d,terminated:_0x47a778}={}){const _0xd09ac=indexedDB['open'](_0x51fa8c,_0x54fe32),_0xdfd060=ge(_0xd09ac);return _0x5c9f89&&_0xd09ac['addEventListener']('upgradeneeded',_0x5da2b2=>{_0x5c9f89(ge(_0xd09ac['result']),_0x5da2b2['oldVersion'],_0x5da2b2['newVersion'],ge(_0xd09ac['transaction']),_0x5da2b2);}),_0x5c8f98&&_0xd09ac['addEventListener']('blocked',_0x13f318=>_0x5c8f98(_0x13f318['oldVersion'],_0x13f318['newVersion'],_0x13f318)),_0xdfd060['then'](_0x3869b9=>{_0x47a778&&_0x3869b9['addEventListener']('close',()=>_0x47a778()),_0x39045d&&_0x3869b9['addEventListener']('versionchange',_0x2b9ee6=>_0x39045d(_0x2b9ee6['oldVersion'],_0x2b9ee6['newVersion'],_0x2b9ee6));})['catch'](()=>{}),_0xdfd060;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x2229a5,_0x4714e3){if(!(_0x2229a5 instanceof IDBDatabase&&!(_0x4714e3 in _0x2229a5)&&typeof _0x4714e3=='string'))return;if(si['get'](_0x4714e3))return si['get'](_0x4714e3);const _0x42d48a=_0x4714e3['replace'](/FromIndex$/,''),_0x2f11c7=_0x4714e3!==_0x42d48a,_0xd7ddbe=zc['includes'](_0x42d48a);if(!(_0x42d48a in(_0x2f11c7?IDBIndex:IDBObjectStore)['prototype'])||!(_0xd7ddbe||qc['includes'](_0x42d48a)))return;const _0x340a32=async function(_0x5b832e,..._0x421203){const _0x5ce33f=this['transaction'](_0x5b832e,_0xd7ddbe?'readwrite':'readonly');let _0x3e2e8e=_0x5ce33f['store'];return _0x2f11c7&&(_0x3e2e8e=_0x3e2e8e['index'](_0x421203['shift']())),(await Promise['all']([_0x3e2e8e[_0x42d48a](..._0x421203),_0xd7ddbe&&_0x5ce33f['done']]))[0x0];};return si['set'](_0x4714e3,_0x340a32),_0x340a32;}Vc(_0x3c1389=>({..._0x3c1389,'get':(_0x5b23e8,_0x5749f6,_0x4b4437)=>Ms(_0x5b23e8,_0x5749f6)||_0x3c1389['get'](_0x5b23e8,_0x5749f6,_0x4b4437),'has':(_0x23aa2f,_0x472dba)=>!!Ms(_0x23aa2f,_0x472dba)||_0x3c1389['has'](_0x23aa2f,_0x472dba)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x22f954){this['container']=_0x22f954;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x51e2ab=>{if(Kc(_0x51e2ab)){const _0x27d209=_0x51e2ab['getImmediate']();return _0x27d209['library']+'/'+_0x27d209['version'];}else return null;})['filter'](_0x1c7a78=>_0x1c7a78)['join']('\x20');}}function Kc(_0x3a4075){const _0x753e58=_0x3a4075['getComponent']();return(_0x753e58==null?void 0x0:_0x753e58['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x310436,_0x316dce){try{_0x310436['container']['addComponent'](_0x316dce);}catch(_0x16c25d){oe['debug']('Component\x20'+_0x316dce['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x310436['name'],_0x16c25d);}}function st(_0x28eeb4){const _0x3eebee=_0x28eeb4['name'];if(Ei['has'](_0x3eebee))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3eebee+'.'),!0x1;Ei['set'](_0x3eebee,_0x28eeb4);for(const _0x26fd77 of Ue['values']())xs(_0x26fd77,_0x28eeb4);for(const _0xb57e7d of vi['values']())xs(_0xb57e7d,_0x28eeb4);return!0x0;}function Hi(_0x5d130a,_0x298f5d){const _0xa3ac22=_0x5d130a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xa3ac22&&_0xa3ac22['triggerHeartbeat'](),_0x5d130a['container']['getProvider'](_0x298f5d);}function $(_0x5fd415){return _0x5fd415==null?!0x1:_0x5fd415['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1fe42d,_0x18cb12,_0x25e7a5){this['_isDeleted']=!0x1,this['_options']={..._0x1fe42d},this['_config']={..._0x18cb12},this['_name']=_0x18cb12['name'],this['_automaticDataCollectionEnabled']=_0x18cb12['automaticDataCollectionEnabled'],this['_container']=_0x25e7a5,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4157c6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4157c6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x34e627){this['_isDeleted']=_0x34e627;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x239d18,_0x22d90f={}){let _0x358292=_0x239d18;typeof _0x22d90f!='object'&&(_0x22d90f={'name':_0x22d90f});const _0x2423ad={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x22d90f},_0x348afe=_0x2423ad['name'];if(typeof _0x348afe!='string'||!_0x348afe)throw me['create']('bad-app-name',{'appName':String(_0x348afe)});if(_0x358292||(_0x358292=zr()),!_0x358292)throw me['create']('no-options');const _0x2efb93=Ue['get'](_0x348afe);if(_0x2efb93){if(xe(_0x358292,_0x2efb93['options'])&&xe(_0x2423ad,_0x2efb93['config']))return _0x2efb93;throw me['create']('duplicate-app',{'appName':_0x348afe});}const _0x16ce6c=new Nc(_0x348afe);for(const _0x13a123 of Ei['values']())_0x16ce6c['addComponent'](_0x13a123);const _0x56ccba=new Tl(_0x358292,_0x2423ad,_0x16ce6c);return Ue['set'](_0x348afe,_0x56ccba),_0x56ccba;}function Zr(_0x25b417=yi){const _0x1680cc=Ue['get'](_0x25b417);if(!_0x1680cc&&_0x25b417===yi&&zr())return Sl();if(!_0x1680cc)throw me['create']('no-app',{'appName':_0x25b417});return _0x1680cc;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x348c4a){let _0x57adb4=!0x1;const _0x15d56c=_0x348c4a['name'];Ue['has'](_0x15d56c)?(_0x57adb4=!0x0,Ue['delete'](_0x15d56c)):vi['has'](_0x15d56c)&&_0x348c4a['decRefCount']()<=0x0&&(vi['delete'](_0x15d56c),_0x57adb4=!0x0),_0x57adb4&&(await Promise['all'](_0x348c4a['container']['getProviders']()['map'](_0x2639a3=>_0x2639a3['delete']())),_0x348c4a['isDeleted']=!0x0);}function ye(_0x3f3d8a,_0x42b561,_0x8b5c9f){let _0x3bfeb6=wl[_0x3f3d8a]??_0x3f3d8a;_0x8b5c9f&&(_0x3bfeb6+='-'+_0x8b5c9f);const _0x5168e3=_0x3bfeb6['match'](/\s|\//),_0x34b925=_0x42b561['match'](/\s|\//);if(_0x5168e3||_0x34b925){const _0x2f7517=['Unable\x20to\x20register\x20library\x20\x22'+_0x3bfeb6+'\x22\x20with\x20version\x20\x22'+_0x42b561+'\x22:'];_0x5168e3&&_0x2f7517['push']('library\x20name\x20\x22'+_0x3bfeb6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5168e3&&_0x34b925&&_0x2f7517['push']('and'),_0x34b925&&_0x2f7517['push']('version\x20name\x20\x22'+_0x42b561+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2f7517['join']('\x20'));return;}st(new Fe(_0x3bfeb6+'-version',()=>({'library':_0x3bfeb6,'version':_0x42b561}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x14868e,_0x339bd6)=>{switch(_0x339bd6){case 0x0:try{_0x14868e['createObjectStore'](Ot);}catch(_0x23adea){console['warn'](_0x23adea);}}}})['catch'](_0x5061df=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5061df['message']});})),ri;}async function Al(_0x169ed7){try{const _0xdad3f5=(await eo())['transaction'](Ot),_0x58b478=await _0xdad3f5['objectStore'](Ot)['get'](to(_0x169ed7));return await _0xdad3f5['done'],_0x58b478;}catch(_0x35900b){if(_0x35900b instanceof Re)oe['warn'](_0x35900b['message']);else{const _0x3033ef=me['create']('idb-get',{'originalErrorMessage':_0x35900b==null?void 0x0:_0x35900b['message']});oe['warn'](_0x3033ef['message']);}}}async function Fs(_0x164268,_0x3f1f54){try{const _0x2ec4a4=(await eo())['transaction'](Ot,'readwrite');await _0x2ec4a4['objectStore'](Ot)['put'](_0x3f1f54,to(_0x164268)),await _0x2ec4a4['done'];}catch(_0x6f18b1){if(_0x6f18b1 instanceof Re)oe['warn'](_0x6f18b1['message']);else{const _0x2bc5a4=me['create']('idb-set',{'originalErrorMessage':_0x6f18b1==null?void 0x0:_0x6f18b1['message']});oe['warn'](_0x2bc5a4['message']);}}}function to(_0x1fbab8){return _0x1fbab8['name']+'!'+_0x1fbab8['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x136d51){this['container']=_0x136d51,this['_heartbeatsCache']=null;const _0x30ce74=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x30ce74),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3d42cb=>(this['_heartbeatsCache']=_0x3d42cb,_0x3d42cb));}async['triggerHeartbeat'](){var _0x2b3111,_0x37921b;try{const _0x37422c=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2888f7=Us();if(((_0x2b3111=this['_heartbeatsCache'])==null?void 0x0:_0x2b3111['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x37921b=this['_heartbeatsCache'])==null?void 0x0:_0x37921b['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2888f7||this['_heartbeatsCache']['heartbeats']['some'](_0x5341c4=>_0x5341c4['date']===_0x2888f7))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2888f7,'agent':_0x37422c}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x205ebf=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x205ebf,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x30556f){oe['warn'](_0x30556f);}}async['getHeartbeatsHeader'](){var _0x14a51b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x14a51b=this['_heartbeatsCache'])==null?void 0x0:_0x14a51b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x23c591=Us(),{heartbeatsToSend:_0x1d4765,unsentEntries:_0x19b73e}=Ol(this['_heartbeatsCache']['heartbeats']),_0x5778cd=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1d4765}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x23c591,_0x19b73e['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x19b73e,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5778cd;}catch(_0x1a625e){return oe['warn'](_0x1a625e),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x3f210b,_0x1c70d0=kl){const _0x2a6827=[];let _0x1a7fa7=_0x3f210b['slice']();for(const _0x533038 of _0x3f210b){const _0x4bcb38=_0x2a6827['find'](_0x450970=>_0x450970['agent']===_0x533038['agent']);if(_0x4bcb38){if(_0x4bcb38['dates']['push'](_0x533038['date']),Ws(_0x2a6827)>_0x1c70d0){_0x4bcb38['dates']['pop']();break;}}else{if(_0x2a6827['push']({'agent':_0x533038['agent'],'dates':[_0x533038['date']]}),Ws(_0x2a6827)>_0x1c70d0){_0x2a6827['pop']();break;}}_0x1a7fa7=_0x1a7fa7['slice'](0x1);}return{'heartbeatsToSend':_0x2a6827,'unsentEntries':_0x1a7fa7};}class Dl{constructor(_0x36f620){this['app']=_0x36f620,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3bba48=await Al(this['app']);return _0x3bba48!=null&&_0x3bba48['heartbeats']?_0x3bba48:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x300186){if(await this['_canUseIndexedDBPromise']){const _0xbdfd0e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x300186['lastSentHeartbeatDate']??_0xbdfd0e['lastSentHeartbeatDate'],'heartbeats':_0x300186['heartbeats']});}else return;}async['add'](_0x38566a){if(await this['_canUseIndexedDBPromise']){const _0x147756=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x38566a['lastSentHeartbeatDate']??_0x147756['lastSentHeartbeatDate'],'heartbeats':[..._0x147756['heartbeats'],..._0x38566a['heartbeats']]});}else return;}}function Ws(_0x4e1e8d){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4e1e8d}))['length'];}function Ml(_0x5a09cc){if(_0x5a09cc['length']===0x0)return-0x1;let _0x1ec218=0x0,_0x13f49c=_0x5a09cc[0x0]['date'];for(let _0x53774d=0x1;_0x53774d<_0x5a09cc['length'];_0x53774d++)_0x5a09cc[_0x53774d]['date']<_0x13f49c&&(_0x13f49c=_0x5a09cc[_0x53774d]['date'],_0x1ec218=_0x53774d);return _0x1ec218;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x55761f){st(new Fe('platform-logger',_0x1aa743=>new jc(_0x1aa743),'PRIVATE')),st(new Fe('heartbeat',_0x454d25=>new Nl(_0x454d25),'PRIVATE')),ye(mi,Ls,_0x55761f),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xa2d33a){no=_0xa2d33a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x22e97f){this['domStorage_']=_0x22e97f,this['prefix_']='firebase:';}['set'](_0x1a9621,_0x22124b){_0x22124b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1a9621)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1a9621),O(_0x22124b));}['get'](_0x55365e){const _0x159b82=this['domStorage_']['getItem'](this['prefixedName_'](_0x55365e));return _0x159b82==null?null:Nt(_0x159b82);}['remove'](_0xd89f0e){this['domStorage_']['removeItem'](this['prefixedName_'](_0xd89f0e));}['prefixedName_'](_0x4734b4){return this['prefix_']+_0x4734b4;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x13062e,_0x3b6437){_0x3b6437==null?delete this['cache_'][_0x13062e]:this['cache_'][_0x13062e]=_0x3b6437;}['get'](_0x1488cb){return Q(this['cache_'],_0x1488cb)?this['cache_'][_0x1488cb]:null;}['remove'](_0x3a5ccf){delete this['cache_'][_0x3a5ccf];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x265179){try{if(typeof window<'u'&&typeof window[_0x265179]<'u'){const _0x3f8f79=window[_0x265179];return _0x3f8f79['setItem']('firebase:sentinel','cache'),_0x3f8f79['removeItem']('firebase:sentinel'),new Wl(_0x3f8f79);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x104a33=0x1;return function(){return _0x104a33++;};}()),ro=function(_0x24b6b7){const _0x1f8b7e=Rc(_0x24b6b7),_0x54c5ff=new Cc();_0x54c5ff['update'](_0x1f8b7e);const _0xbc8984=_0x54c5ff['digest']();return Fi['encodeByteArray'](_0xbc8984);},zt=function(..._0x5abf2d){let _0x3eb7e6='';for(let _0x135169=0x0;_0x135169<_0x5abf2d['length'];_0x135169++){const _0x486807=_0x5abf2d[_0x135169];Array['isArray'](_0x486807)||_0x486807&&typeof _0x486807=='object'&&typeof _0x486807['length']=='number'?_0x3eb7e6+=zt['apply'](null,_0x486807):typeof _0x486807=='object'?_0x3eb7e6+=O(_0x486807):_0x3eb7e6+=_0x486807,_0x3eb7e6+='\x20';}return _0x3eb7e6;};let St=null,$s=!0x0;const Hl=function(_0x327603,_0x303196){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x31e2cb){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x2e4d6b=zt['apply'](null,_0x31e2cb);St(_0x2e4d6b);}},jt=function(_0x4fb444){return function(..._0x169c80){L(_0x4fb444,..._0x169c80);};},Ii=function(..._0x34f138){const _0x16afa2='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x34f138);Ze['error'](_0x16afa2);},ae=function(..._0x1c423e){const _0x398f33='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1c423e);throw Ze['error'](_0x398f33),new Error(_0x398f33);},U=function(..._0x4d7f2d){const _0x2f1127='FIREBASE\x20WARNING:\x20'+zt(..._0x4d7f2d);Ze['warn'](_0x2f1127);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5aff53){return typeof _0x5aff53=='number'&&(_0x5aff53!==_0x5aff53||_0x5aff53===Number['POSITIVE_INFINITY']||_0x5aff53===Number['NEGATIVE_INFINITY']);},Gl=function(_0x459e77){if(document['readyState']==='complete')_0x459e77();else{let _0x4e9ced=!0x1;const _0x24524c=function(){if(!document['body']){setTimeout(_0x24524c,Math['floor'](0xa));return;}_0x4e9ced||(_0x4e9ced=!0x0,_0x459e77());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x24524c,!0x1),window['addEventListener']('load',_0x24524c,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x24524c();}),window['attachEvent']('onload',_0x24524c));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x1ed31b,_0x4f1fbb){if(_0x1ed31b===_0x4f1fbb)return 0x0;if(_0x1ed31b===We||_0x4f1fbb===we)return-0x1;if(_0x4f1fbb===We||_0x1ed31b===we)return 0x1;{const _0x34980c=Gs(_0x1ed31b),_0x98b42a=Gs(_0x4f1fbb);return _0x34980c!==null?_0x98b42a!==null?_0x34980c-_0x98b42a===0x0?_0x1ed31b['length']-_0x4f1fbb['length']:_0x34980c-_0x98b42a:-0x1:_0x98b42a!==null?0x1:_0x1ed31b<_0x4f1fbb?-0x1:0x1;}},ql=function(_0x5ebf6f,_0x37e6e7){return _0x5ebf6f===_0x37e6e7?0x0:_0x5ebf6f<_0x37e6e7?-0x1:0x1;},vt=function(_0x5d5dc0,_0x40bf76){if(_0x40bf76&&_0x5d5dc0 in _0x40bf76)return _0x40bf76[_0x5d5dc0];throw new Error('Missing\x20required\x20key\x20('+_0x5d5dc0+')\x20in\x20object:\x20'+O(_0x40bf76));},$i=function(_0x5f36ca){if(typeof _0x5f36ca!='object'||_0x5f36ca===null)return O(_0x5f36ca);const _0x48b76=[];for(const _0x4f7007 in _0x5f36ca)_0x48b76['push'](_0x4f7007);_0x48b76['sort']();let _0x4c8350='{';for(let _0x4a50cc=0x0;_0x4a50cc<_0x48b76['length'];_0x4a50cc++)_0x4a50cc!==0x0&&(_0x4c8350+=','),_0x4c8350+=O(_0x48b76[_0x4a50cc]),_0x4c8350+=':',_0x4c8350+=$i(_0x5f36ca[_0x48b76[_0x4a50cc]]);return _0x4c8350+='}',_0x4c8350;},oo=function(_0x216f67,_0x203eb1){const _0x12504f=_0x216f67['length'];if(_0x12504f<=_0x203eb1)return[_0x216f67];const _0x373924=[];for(let _0x3566b1=0x0;_0x3566b1<_0x12504f;_0x3566b1+=_0x203eb1)_0x3566b1+_0x203eb1>_0x12504f?_0x373924['push'](_0x216f67['substring'](_0x3566b1,_0x12504f)):_0x373924['push'](_0x216f67['substring'](_0x3566b1,_0x3566b1+_0x203eb1));return _0x373924;};function x(_0x431680,_0x22e070){for(const _0x1d8464 in _0x431680)_0x431680['hasOwnProperty'](_0x1d8464)&&_0x22e070(_0x1d8464,_0x431680[_0x1d8464]);}const ao=function(_0x28eed2){f(!xn(_0x28eed2),'Invalid\x20JSON\x20number');const _0x2224d8=0xb,_0x3fec04=0x34,_0x551a86=(0x1<<_0x2224d8-0x1)-0x1;let _0x136e8f,_0x4b4cd0,_0x100a6d,_0x5f51b5,_0x105343;_0x28eed2===0x0?(_0x4b4cd0=0x0,_0x100a6d=0x0,_0x136e8f=0x1/_0x28eed2===-0x1/0x0?0x1:0x0):(_0x136e8f=_0x28eed2<0x0,_0x28eed2=Math['abs'](_0x28eed2),_0x28eed2>=Math['pow'](0x2,0x1-_0x551a86)?(_0x5f51b5=Math['min'](Math['floor'](Math['log'](_0x28eed2)/Math['LN2']),_0x551a86),_0x4b4cd0=_0x5f51b5+_0x551a86,_0x100a6d=Math['round'](_0x28eed2*Math['pow'](0x2,_0x3fec04-_0x5f51b5)-Math['pow'](0x2,_0x3fec04))):(_0x4b4cd0=0x0,_0x100a6d=Math['round'](_0x28eed2/Math['pow'](0x2,0x1-_0x551a86-_0x3fec04))));const _0x322c0f=[];for(_0x105343=_0x3fec04;_0x105343;_0x105343-=0x1)_0x322c0f['push'](_0x100a6d%0x2?0x1:0x0),_0x100a6d=Math['floor'](_0x100a6d/0x2);for(_0x105343=_0x2224d8;_0x105343;_0x105343-=0x1)_0x322c0f['push'](_0x4b4cd0%0x2?0x1:0x0),_0x4b4cd0=Math['floor'](_0x4b4cd0/0x2);_0x322c0f['push'](_0x136e8f?0x1:0x0),_0x322c0f['reverse']();const _0x4d2b37=_0x322c0f['join']('');let _0x41b6f9='';for(_0x105343=0x0;_0x105343<0x40;_0x105343+=0x8){let _0x425339=parseInt(_0x4d2b37['substr'](_0x105343,0x8),0x2)['toString'](0x10);_0x425339['length']===0x1&&(_0x425339='0'+_0x425339),_0x41b6f9=_0x41b6f9+_0x425339;}return _0x41b6f9['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x366d19,_0x2aaee0){let _0x2111b1='Unknown\x20Error';_0x366d19==='too_big'?_0x2111b1='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x366d19==='permission_denied'?_0x2111b1='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x366d19==='unavailable'&&(_0x2111b1='The\x20service\x20is\x20unavailable');const _0x1dda21=new Error(_0x366d19+'\x20at\x20'+_0x2aaee0['_path']['toString']()+':\x20'+_0x2111b1);return _0x1dda21['code']=_0x366d19['toUpperCase'](),_0x1dda21;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x36c835){if(Yl['test'](_0x36c835)){const _0x155430=Number(_0x36c835);if(_0x155430>=Ql&&_0x155430<=Jl)return _0x155430;}return null;},ft=function(_0x39697c){try{_0x39697c();}catch(_0x4939fc){setTimeout(()=>{const _0x22e005=_0x4939fc['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x22e005),_0x4939fc;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x1f7737,_0x1a3fad){const _0xfc7762=setTimeout(_0x1f7737,_0x1a3fad);return typeof _0xfc7762=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0xfc7762):typeof _0xfc7762=='object'&&_0xfc7762['unref']&&_0xfc7762['unref'](),_0xfc7762;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x283db7,_0x5ab358){this['appCheckProvider']=_0x5ab358,this['appName']=_0x283db7['name'],$(_0x283db7)&&_0x283db7['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x283db7['settings']['appCheckToken']),this['appCheck']=_0x5ab358==null?void 0x0:_0x5ab358['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5ab358==null||_0x5ab358['get']()['then'](_0x5f4307=>this['appCheck']=_0x5f4307);}['getToken'](_0x258f8f){if(this['serverAppAppCheckToken']){if(_0x258f8f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x258f8f):new Promise((_0x2ad474,_0x450071)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x258f8f)['then'](_0x2ad474,_0x450071):_0x2ad474(null);},0x0);});}['addTokenChangeListener'](_0x36d95c){var _0x110485;(_0x110485=this['appCheckProvider'])==null||_0x110485['get']()['then'](_0x343d0b=>_0x343d0b['addTokenListener'](_0x36d95c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x8a0c16,_0xd14dfe,_0x4372b9){this['appName_']=_0x8a0c16,this['firebaseOptions_']=_0xd14dfe,this['authProvider_']=_0x4372b9,this['auth_']=null,this['auth_']=_0x4372b9['getImmediate']({'optional':!0x0}),this['auth_']||_0x4372b9['onInit'](_0x54361d=>this['auth_']=_0x54361d);}['getToken'](_0x1b1715){return this['auth_']?this['auth_']['getToken'](_0x1b1715)['catch'](_0x1884dd=>_0x1884dd&&_0x1884dd['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1884dd)):new Promise((_0x78376f,_0x42c47d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1b1715)['then'](_0x78376f,_0x42c47d):_0x78376f(null);},0x0);});}['addTokenChangeListener'](_0x1a41cd){this['auth_']?this['auth_']['addAuthTokenListener'](_0x1a41cd):this['authProvider_']['get']()['then'](_0x2260b5=>_0x2260b5['addAuthTokenListener'](_0x1a41cd));}['removeTokenChangeListener'](_0x5f2ead){this['authProvider_']['get']()['then'](_0x55b52c=>_0x55b52c['removeAuthTokenListener'](_0x5f2ead));}['notifyForInvalidToken'](){let _0x310401='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x310401+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x310401+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x310401+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x310401);}}class an{constructor(_0xdeaef9){this['accessToken']=_0xdeaef9;}['getToken'](_0x42f5d7){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x520a74){_0x520a74(this['accessToken']);}['removeTokenChangeListener'](_0x2f29a9){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x52ed3b,_0x7367ec,_0x1b776a,_0x36952a,_0x12e4c1=!0x1,_0x3c2657='',_0x56e9a8=!0x1,_0x113260=!0x1,_0x3805f7=null){this['secure']=_0x7367ec,this['namespace']=_0x1b776a,this['webSocketOnly']=_0x36952a,this['nodeAdmin']=_0x12e4c1,this['persistenceKey']=_0x3c2657,this['includeNamespaceInQueryParams']=_0x56e9a8,this['isUsingEmulator']=_0x113260,this['emulatorOptions']=_0x3805f7,this['_host']=_0x52ed3b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x52ed3b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xe570b1){_0xe570b1!==this['internalHost']&&(this['internalHost']=_0xe570b1,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2ea8ed=this['toURLString']();return this['persistenceKey']&&(_0x2ea8ed+='<'+this['persistenceKey']+'>'),_0x2ea8ed;}['toURLString'](){const _0x53b154=this['secure']?'https://':'http://',_0x3c57a5=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x53b154+this['host']+'/'+_0x3c57a5;}}function th(_0x100b75){return _0x100b75['host']!==_0x100b75['internalHost']||_0x100b75['isCustomHost']()||_0x100b75['includeNamespaceInQueryParams'];}function vo(_0x278dc5,_0x3cd34f,_0x5ae12b){f(typeof _0x3cd34f=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5ae12b=='object','typeof\x20params\x20must\x20==\x20object');let _0x10c5be;if(_0x3cd34f===go)_0x10c5be=(_0x278dc5['secure']?'wss://':'ws://')+_0x278dc5['internalHost']+'/.ws?';else{if(_0x3cd34f===mo)_0x10c5be=(_0x278dc5['secure']?'https://':'http://')+_0x278dc5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3cd34f);}th(_0x278dc5)&&(_0x5ae12b['ns']=_0x278dc5['namespace']);const _0xa3bb9b=[];return x(_0x5ae12b,(_0x30817a,_0x2b5363)=>{_0xa3bb9b['push'](_0x30817a+'='+_0x2b5363);}),_0x10c5be+_0xa3bb9b['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4af49a,_0x320abb=0x1){Q(this['counters_'],_0x4af49a)||(this['counters_'][_0x4af49a]=0x0),this['counters_'][_0x4af49a]+=_0x320abb;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x22f8db){const _0x1e6cd3=_0x22f8db['toString']();return oi[_0x1e6cd3]||(oi[_0x1e6cd3]=new nh()),oi[_0x1e6cd3];}function ih(_0x1caac0,_0x90096d){const _0x4a4d6b=_0x1caac0['toString']();return ai[_0x4a4d6b]||(ai[_0x4a4d6b]=_0x90096d()),ai[_0x4a4d6b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5446c8){this['onMessage_']=_0x5446c8,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x435e59,_0x3e9aad){this['closeAfterResponse']=_0x435e59,this['onClose']=_0x3e9aad,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2a3ad9,_0x5b274e){for(this['pendingResponses'][_0x2a3ad9]=_0x5b274e;this['pendingResponses'][this['currentResponseNum']];){const _0x30389f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x108faf=0x0;_0x108faf<_0x30389f['length'];++_0x108faf)_0x30389f[_0x108faf]&&ft(()=>{this['onMessage_'](_0x30389f[_0x108faf]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x338ed5,_0x1fc690,_0x8d00b,_0x10c327,_0x2845c3,_0x17afea,_0x26ab95){this['connId']=_0x338ed5,this['repoInfo']=_0x1fc690,this['applicationId']=_0x8d00b,this['appCheckToken']=_0x10c327,this['authToken']=_0x2845c3,this['transportSessionId']=_0x17afea,this['lastSessionId']=_0x26ab95,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x338ed5),this['stats_']=qi(_0x1fc690),this['urlFn']=_0x3cf27a=>(this['appCheckToken']&&(_0x3cf27a[wi]=this['appCheckToken']),vo(_0x1fc690,mo,_0x3cf27a));}['open'](_0xd53cff,_0x5dbe9a){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5dbe9a,this['myPacketOrderer']=new sh(_0xd53cff),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0xc324db)=>{const [_0x2e63af,_0x35962f,_0x10213f,_0x39c614,_0x16737e]=_0xc324db;if(this['incrementIncomingBytes_'](_0xc324db),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2e63af===qs)this['id']=_0x35962f,this['password']=_0x10213f;else{if(_0x2e63af===rh)_0x35962f?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x35962f,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2e63af);}}},(..._0xd5c8f6)=>{const [_0x1629ca,_0x1dd981]=_0xd5c8f6;this['incrementIncomingBytes_'](_0xd5c8f6),this['myPacketOrderer']['handleResponse'](_0x1629ca,_0x1dd981);},()=>{this['onClosed_']();},this['urlFn']);const _0x51a59e={};_0x51a59e[qs]='t',_0x51a59e[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x51a59e[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x51a59e[co]=Gi,this['transportSessionId']&&(_0x51a59e[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x51a59e[po]=this['lastSessionId']),this['applicationId']&&(_0x51a59e[_o]=this['applicationId']),this['appCheckToken']&&(_0x51a59e[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x51a59e[ho]=uo);const _0x31a0fc=this['urlFn'](_0x51a59e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x31a0fc),this['scriptTagHolder']['addTag'](_0x31a0fc,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x144507){const _0x1de32d=O(_0x144507);this['bytesSent']+=_0x1de32d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1de32d['length']);const _0x59600a=$r(_0x1de32d),_0x5a129c=oo(_0x59600a,fh);for(let _0x5c16c6=0x0;_0x5c16c6<_0x5a129c['length'];_0x5c16c6++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5a129c['length'],_0x5a129c[_0x5c16c6]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x32d1e3,_0x47b81e){this['myDisconnFrame']=document['createElement']('iframe');const _0x25a3a4={};_0x25a3a4[dh]='t',_0x25a3a4[Eo]=_0x32d1e3,_0x25a3a4[Io]=_0x47b81e,this['myDisconnFrame']['src']=this['urlFn'](_0x25a3a4),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2c0b03){const _0x169335=O(_0x2c0b03)['length'];this['bytesReceived']+=_0x169335,this['stats_']['incrementCounter']('bytes_received',_0x169335);}}class zi{constructor(_0x5d91cd,_0x354519,_0x5154e8,_0x1b0e19){this['onDisconnect']=_0x5154e8,this['urlFn']=_0x1b0e19,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5d91cd,window[ah+this['uniqueCallbackIdentifier']]=_0x354519,this['myIFrame']=zi['createIFrame_']();let _0x1bb4d3='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1bb4d3='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x31ee41='<html><body>'+_0x1bb4d3+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x31ee41),this['myIFrame']['doc']['close']();}catch(_0x314b32){L('frame\x20writing\x20exception'),_0x314b32['stack']&&L(_0x314b32['stack']),L(_0x314b32);}}}static['createIFrame_'](){const _0x1d357f=document['createElement']('iframe');if(_0x1d357f['style']['display']='none',document['body']){document['body']['appendChild'](_0x1d357f);try{_0x1d357f['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5d0bec=document['domain'];_0x1d357f['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5d0bec+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1d357f['contentDocument']?_0x1d357f['doc']=_0x1d357f['contentDocument']:_0x1d357f['contentWindow']?_0x1d357f['doc']=_0x1d357f['contentWindow']['document']:_0x1d357f['document']&&(_0x1d357f['doc']=_0x1d357f['document']),_0x1d357f;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3db703=this['onDisconnect'];_0x3db703&&(this['onDisconnect']=null,_0x3db703());}['startLongPoll'](_0x534b0a,_0x4faf3d){for(this['myID']=_0x534b0a,this['myPW']=_0x4faf3d,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x20d259={};_0x20d259[Eo]=this['myID'],_0x20d259[Io]=this['myPW'],_0x20d259[wo]=this['currentSerial'];let _0x2c066c=this['urlFn'](_0x20d259),_0x9716cd='',_0x335701=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x9716cd['length']<=Co;){const _0x5861c0=this['pendingSegs']['shift']();_0x9716cd=_0x9716cd+'&'+lh+_0x335701+'='+_0x5861c0['seg']+'&'+hh+_0x335701+'='+_0x5861c0['ts']+'&'+uh+_0x335701+'='+_0x5861c0['d'],_0x335701++;}return _0x2c066c=_0x2c066c+_0x9716cd,this['addLongPollTag_'](_0x2c066c,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x560f72,_0x5a0d8e,_0x4dae7d){this['pendingSegs']['push']({'seg':_0x560f72,'ts':_0x5a0d8e,'d':_0x4dae7d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2d2423,_0x59166b){this['outstandingRequests']['add'](_0x59166b);const _0x181db6=()=>{this['outstandingRequests']['delete'](_0x59166b),this['newRequest_']();},_0x210917=setTimeout(_0x181db6,Math['floor'](ph)),_0x408cf0=()=>{clearTimeout(_0x210917),_0x181db6();};this['addTag'](_0x2d2423,_0x408cf0);}['addTag'](_0x43bb46,_0x480027){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5d84a9=this['myIFrame']['doc']['createElement']('script');_0x5d84a9['type']='text/javascript',_0x5d84a9['async']=!0x0,_0x5d84a9['src']=_0x43bb46,_0x5d84a9['onload']=_0x5d84a9['onreadystatechange']=function(){const _0x30f1ab=_0x5d84a9['readyState'];(!_0x30f1ab||_0x30f1ab==='loaded'||_0x30f1ab==='complete')&&(_0x5d84a9['onload']=_0x5d84a9['onreadystatechange']=null,_0x5d84a9['parentNode']&&_0x5d84a9['parentNode']['removeChild'](_0x5d84a9),_0x480027());},_0x5d84a9['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x43bb46),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5d84a9);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x4f048c,_0x153dab,_0x335820,_0x1b9233,_0x2dad64,_0x3e479c,_0x1ed055){this['connId']=_0x4f048c,this['applicationId']=_0x335820,this['appCheckToken']=_0x1b9233,this['authToken']=_0x2dad64,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x153dab),this['connURL']=q['connectionURL_'](_0x153dab,_0x3e479c,_0x1ed055,_0x1b9233,_0x335820),this['nodeAdmin']=_0x153dab['nodeAdmin'];}static['connectionURL_'](_0xb72fbf,_0x5e5a51,_0x554c66,_0xb703da,_0x50d9bd){const _0xdb1696={};return _0xdb1696[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xdb1696[ho]=uo),_0x5e5a51&&(_0xdb1696[lo]=_0x5e5a51),_0x554c66&&(_0xdb1696[po]=_0x554c66),_0xb703da&&(_0xdb1696[wi]=_0xb703da),_0x50d9bd&&(_0xdb1696[_o]=_0x50d9bd),vo(_0xb72fbf,go,_0xdb1696);}['open'](_0x51fd95,_0x46c95d){this['onDisconnect']=_0x46c95d,this['onMessage']=_0x51fd95,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x411f83;_c(),this['mySock']=new gn(this['connURL'],[],_0x411f83);}catch(_0x4ab919){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xf1810c=_0x4ab919['message']||_0x4ab919['data'];_0xf1810c&&this['log_'](_0xf1810c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x452da3=>{this['handleIncomingFrame'](_0x452da3);},this['mySock']['onerror']=_0x2eb93c=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x199815=_0x2eb93c['message']||_0x2eb93c['data'];_0x199815&&this['log_'](_0x199815),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x19aefe=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5621e2=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1bd6e7=navigator['userAgent']['match'](_0x5621e2);_0x1bd6e7&&_0x1bd6e7['length']>0x1&&parseFloat(_0x1bd6e7[0x1])<4.4&&(_0x19aefe=!0x0);}return!_0x19aefe&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x49e34b){if(this['frames']['push'](_0x49e34b),this['frames']['length']===this['totalFrames']){const _0x389ab5=this['frames']['join']('');this['frames']=null;const _0x19ce5f=Nt(_0x389ab5);this['onMessage'](_0x19ce5f);}}['handleNewFrameCount_'](_0x544957){this['totalFrames']=_0x544957,this['frames']=[];}['extractFrameCount_'](_0x265a69){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x265a69['length']<=0x6){const _0x3a620b=Number(_0x265a69);if(!isNaN(_0x3a620b))return this['handleNewFrameCount_'](_0x3a620b),null;}return this['handleNewFrameCount_'](0x1),_0x265a69;}['handleIncomingFrame'](_0x289869){if(this['mySock']===null)return;const _0x37f6c4=_0x289869['data'];if(this['bytesReceived']+=_0x37f6c4['length'],this['stats_']['incrementCounter']('bytes_received',_0x37f6c4['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x37f6c4);else{const _0x2aed98=this['extractFrameCount_'](_0x37f6c4);_0x2aed98!==null&&this['appendFrame_'](_0x2aed98);}}['send'](_0x535d27){this['resetKeepAlive']();const _0x24c24d=O(_0x535d27);this['bytesSent']+=_0x24c24d['length'],this['stats_']['incrementCounter']('bytes_sent',_0x24c24d['length']);const _0x750410=oo(_0x24c24d,gh);_0x750410['length']>0x1&&this['sendString_'](String(_0x750410['length']));for(let _0xbd735a=0x0;_0xbd735a<_0x750410['length'];_0xbd735a++)this['sendString_'](_0x750410[_0xbd735a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xea27e3){try{this['mySock']['send'](_0xea27e3);}catch(_0x108af8){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x108af8['message']||_0x108af8['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x257835){this['initTransports_'](_0x257835);}['initTransports_'](_0x3c2dc4){const _0x472282=q&&q['isAvailable']();let _0x175f20=_0x472282&&!q['previouslyFailed']();if(_0x3c2dc4['webSocketOnly']&&(_0x472282||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x175f20=!0x0),_0x175f20)this['transports_']=[q];else{const _0x5b2b5f=this['transports_']=[];for(const _0x212ab7 of Dt['ALL_TRANSPORTS'])_0x212ab7&&_0x212ab7['isAvailable']()&&_0x5b2b5f['push'](_0x212ab7);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x261e78,_0x22edbf,_0x4ae438,_0x483304,_0x324aec,_0x2bc328,_0x2f311a,_0x185ff9,_0x3afc5a,_0x519407){this['id']=_0x261e78,this['repoInfo_']=_0x22edbf,this['applicationId_']=_0x4ae438,this['appCheckToken_']=_0x483304,this['authToken_']=_0x324aec,this['onMessage_']=_0x2bc328,this['onReady_']=_0x2f311a,this['onDisconnect_']=_0x185ff9,this['onKill_']=_0x3afc5a,this['lastSessionId']=_0x519407,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x22edbf),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3a2edf=this['transportManager_']['initialTransport']();this['conn_']=new _0x3a2edf(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3a2edf['responsesRequiredToBeHealthy']||0x0;const _0x24d070=this['connReceiver_'](this['conn_']),_0x264b95=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x24d070,_0x264b95);},Math['floor'](0x0));const _0x37dabb=_0x3a2edf['healthyTimeout']||0x0;_0x37dabb>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x37dabb)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4e38c4){return _0x17d2ab=>{_0x4e38c4===this['conn_']?this['onConnectionLost_'](_0x17d2ab):_0x4e38c4===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1952f){return _0x4b1ca5=>{this['state_']!==0x2&&(_0x1952f===this['rx_']?this['onPrimaryMessageReceived_'](_0x4b1ca5):_0x1952f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x4b1ca5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x50e982){const _0x1ebf43={'t':'d','d':_0x50e982};this['sendData_'](_0x1ebf43);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x38f24a){if(ci in _0x38f24a){const _0x57f380=_0x38f24a[ci];_0x57f380===Ys?this['upgradeIfSecondaryHealthy_']():_0x57f380===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x57f380===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x15da65){const _0x5c6f00=vt('t',_0x15da65),_0x287e1d=vt('d',_0x15da65);if(_0x5c6f00==='c')this['onSecondaryControl_'](_0x287e1d);else{if(_0x5c6f00==='d')this['pendingDataMessages']['push'](_0x287e1d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5c6f00);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xab2613){const _0x3dfe87=vt('t',_0xab2613),_0x2a9517=vt('d',_0xab2613);_0x3dfe87==='c'?this['onControl_'](_0x2a9517):_0x3dfe87==='d'&&this['onDataMessage_'](_0x2a9517);}['onDataMessage_'](_0x2f5a1a){this['onPrimaryResponse_'](),this['onMessage_'](_0x2f5a1a);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x898fa1){const _0x2982b7=vt(ci,_0x898fa1);if(zs in _0x898fa1){const _0x137b40=_0x898fa1[zs];if(_0x2982b7===Th){const _0x506fd4={..._0x137b40};this['repoInfo_']['isUsingEmulator']&&(_0x506fd4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x506fd4);}else{if(_0x2982b7===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x40dd12=0x0;_0x40dd12<this['pendingDataMessages']['length'];++_0x40dd12)this['onDataMessage_'](this['pendingDataMessages'][_0x40dd12]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2982b7===wh?this['onConnectionShutdown_'](_0x137b40):_0x2982b7===js?this['onReset_'](_0x137b40):_0x2982b7===Ch?Ii('Server\x20Error:\x20'+_0x137b40):_0x2982b7===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x2982b7);}}}['onHandshake_'](_0x3a9f15){const _0xed8aa5=_0x3a9f15['ts'],_0xa74d40=_0x3a9f15['v'],_0x5a6a29=_0x3a9f15['h'];this['sessionId']=_0x3a9f15['s'],this['repoInfo_']['host']=_0x5a6a29,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xed8aa5),Gi!==_0xa74d40&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2bc4ef=this['transportManager_']['upgradeTransport']();_0x2bc4ef&&this['startUpgrade_'](_0x2bc4ef);}['startUpgrade_'](_0x367c6e){this['secondaryConn_']=new _0x367c6e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x367c6e['responsesRequiredToBeHealthy']||0x0;const _0x48449a=this['connReceiver_'](this['secondaryConn_']),_0x51bb36=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x48449a,_0x51bb36),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x1e8cc2){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x1e8cc2),this['repoInfo_']['host']=_0x1e8cc2,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3f7fd6,_0x458cb7){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3f7fd6,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x458cb7,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x11cb07=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x11cb07||this['rx_']===_0x11cb07)&&this['close']();}['onConnectionLost_'](_0x3425be){this['conn_']=null,!_0x3425be&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x38891f){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x38891f),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x546d95){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x546d95);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x207ef4,_0x1ac100,_0xa218ea,_0x14b40c){}['merge'](_0x992c67,_0x1cc94a,_0x12cd78,_0x1a5241){}['refreshAuthToken'](_0x7112d1){}['refreshAppCheckToken'](_0x10db8d){}['onDisconnectPut'](_0x538159,_0x518ce4,_0x1049e2){}['onDisconnectMerge'](_0xedf647,_0x5e3e69,_0x82405f){}['onDisconnectCancel'](_0x5bf9ca,_0x589b67){}['reportStats'](_0x1ea8d5){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x50d263){this['allowedEvents_']=_0x50d263,this['listeners_']={},f(Array['isArray'](_0x50d263)&&_0x50d263['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2129fd,..._0x32ffee){if(Array['isArray'](this['listeners_'][_0x2129fd])){const _0x5df764=[...this['listeners_'][_0x2129fd]];for(let _0xee1c9a=0x0;_0xee1c9a<_0x5df764['length'];_0xee1c9a++)_0x5df764[_0xee1c9a]['callback']['apply'](_0x5df764[_0xee1c9a]['context'],_0x32ffee);}}['on'](_0x4b7157,_0x50042a,_0x1c9d07){this['validateEventType_'](_0x4b7157),this['listeners_'][_0x4b7157]=this['listeners_'][_0x4b7157]||[],this['listeners_'][_0x4b7157]['push']({'callback':_0x50042a,'context':_0x1c9d07});const _0x2f5e2b=this['getInitialEvent'](_0x4b7157);_0x2f5e2b&&_0x50042a['apply'](_0x1c9d07,_0x2f5e2b);}['off'](_0x1909f8,_0x19725b,_0x2405d8){this['validateEventType_'](_0x1909f8);const _0x1dc896=this['listeners_'][_0x1909f8]||[];for(let _0x39bc71=0x0;_0x39bc71<_0x1dc896['length'];_0x39bc71++)if(_0x1dc896[_0x39bc71]['callback']===_0x19725b&&(!_0x2405d8||_0x2405d8===_0x1dc896[_0x39bc71]['context'])){_0x1dc896['splice'](_0x39bc71,0x1);return;}}['validateEventType_'](_0xb3172f){f(this['allowedEvents_']['find'](_0x1b50f6=>_0x1b50f6===_0xb3172f),'Unknown\x20event:\x20'+_0xb3172f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x707594){return f(_0x707594==='online','Unknown\x20event\x20type:\x20'+_0x707594),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1cb996,_0x56a670){if(_0x56a670===void 0x0){this['pieces_']=_0x1cb996['split']('/');let _0x44d90c=0x0;for(let _0x135616=0x0;_0x135616<this['pieces_']['length'];_0x135616++)this['pieces_'][_0x135616]['length']>0x0&&(this['pieces_'][_0x44d90c]=this['pieces_'][_0x135616],_0x44d90c++);this['pieces_']['length']=_0x44d90c,this['pieceNum_']=0x0;}else this['pieces_']=_0x1cb996,this['pieceNum_']=_0x56a670;}['toString'](){let _0x4b948b='';for(let _0x3822d4=this['pieceNum_'];_0x3822d4<this['pieces_']['length'];_0x3822d4++)this['pieces_'][_0x3822d4]!==''&&(_0x4b948b+='/'+this['pieces_'][_0x3822d4]);return _0x4b948b||'/';}}function w(){return new C('');}function y(_0x59118b){return _0x59118b['pieceNum_']>=_0x59118b['pieces_']['length']?null:_0x59118b['pieces_'][_0x59118b['pieceNum_']];}function Ce(_0x292729){return _0x292729['pieces_']['length']-_0x292729['pieceNum_'];}function S(_0x32d6bf){let _0x528010=_0x32d6bf['pieceNum_'];return _0x528010<_0x32d6bf['pieces_']['length']&&_0x528010++,new C(_0x32d6bf['pieces_'],_0x528010);}function ji(_0x8f8354){return _0x8f8354['pieceNum_']<_0x8f8354['pieces_']['length']?_0x8f8354['pieces_'][_0x8f8354['pieces_']['length']-0x1]:null;}function bh(_0x2cf4fa){let _0x57269d='';for(let _0x3b6b68=_0x2cf4fa['pieceNum_'];_0x3b6b68<_0x2cf4fa['pieces_']['length'];_0x3b6b68++)_0x2cf4fa['pieces_'][_0x3b6b68]!==''&&(_0x57269d+='/'+encodeURIComponent(String(_0x2cf4fa['pieces_'][_0x3b6b68])));return _0x57269d||'/';}function Mt(_0x50b22d,_0x3f60b0=0x0){return _0x50b22d['pieces_']['slice'](_0x50b22d['pieceNum_']+_0x3f60b0);}function Ro(_0xf48471){if(_0xf48471['pieceNum_']>=_0xf48471['pieces_']['length'])return null;const _0x3a749f=[];for(let _0x175f49=_0xf48471['pieceNum_'];_0x175f49<_0xf48471['pieces_']['length']-0x1;_0x175f49++)_0x3a749f['push'](_0xf48471['pieces_'][_0x175f49]);return new C(_0x3a749f,0x0);}function k(_0x5350c6,_0x18ee60){const _0x43a7e1=[];for(let _0x284656=_0x5350c6['pieceNum_'];_0x284656<_0x5350c6['pieces_']['length'];_0x284656++)_0x43a7e1['push'](_0x5350c6['pieces_'][_0x284656]);if(_0x18ee60 instanceof C){for(let _0x565b9e=_0x18ee60['pieceNum_'];_0x565b9e<_0x18ee60['pieces_']['length'];_0x565b9e++)_0x43a7e1['push'](_0x18ee60['pieces_'][_0x565b9e]);}else{const _0x12f33c=_0x18ee60['split']('/');for(let _0x3c6b38=0x0;_0x3c6b38<_0x12f33c['length'];_0x3c6b38++)_0x12f33c[_0x3c6b38]['length']>0x0&&_0x43a7e1['push'](_0x12f33c[_0x3c6b38]);}return new C(_0x43a7e1,0x0);}function v(_0x274eca){return _0x274eca['pieceNum_']>=_0x274eca['pieces_']['length'];}function F(_0x5ed4dd,_0x57429c){const _0x2dca0f=y(_0x5ed4dd),_0x31b3b6=y(_0x57429c);if(_0x2dca0f===null)return _0x57429c;if(_0x2dca0f===_0x31b3b6)return F(S(_0x5ed4dd),S(_0x57429c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x57429c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x5ed4dd+')');}function Rh(_0x14ffa2,_0x41af1a){const _0x4f99fb=Mt(_0x14ffa2,0x0),_0x4e5884=Mt(_0x41af1a,0x0);for(let _0xcc4d7f=0x0;_0xcc4d7f<_0x4f99fb['length']&&_0xcc4d7f<_0x4e5884['length'];_0xcc4d7f++){const _0x3cc767=qe(_0x4f99fb[_0xcc4d7f],_0x4e5884[_0xcc4d7f]);if(_0x3cc767!==0x0)return _0x3cc767;}return _0x4f99fb['length']===_0x4e5884['length']?0x0:_0x4f99fb['length']<_0x4e5884['length']?-0x1:0x1;}function Ki(_0x1bc977,_0x13c5ee){if(Ce(_0x1bc977)!==Ce(_0x13c5ee))return!0x1;for(let _0x45ae2b=_0x1bc977['pieceNum_'],_0xeaaf64=_0x13c5ee['pieceNum_'];_0x45ae2b<=_0x1bc977['pieces_']['length'];_0x45ae2b++,_0xeaaf64++)if(_0x1bc977['pieces_'][_0x45ae2b]!==_0x13c5ee['pieces_'][_0xeaaf64])return!0x1;return!0x0;}function G(_0x585470,_0x4d48dd){let _0x395579=_0x585470['pieceNum_'],_0x48fef6=_0x4d48dd['pieceNum_'];if(Ce(_0x585470)>Ce(_0x4d48dd))return!0x1;for(;_0x395579<_0x585470['pieces_']['length'];){if(_0x585470['pieces_'][_0x395579]!==_0x4d48dd['pieces_'][_0x48fef6])return!0x1;++_0x395579,++_0x48fef6;}return!0x0;}class Ah{constructor(_0x502d63,_0x2de5b9){this['errorPrefix_']=_0x2de5b9,this['parts_']=Mt(_0x502d63,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x248e2d=0x0;_0x248e2d<this['parts_']['length'];_0x248e2d++)this['byteLength_']+=Ln(this['parts_'][_0x248e2d]);Ao(this);}}function kh(_0x229190,_0x2a585b){_0x229190['parts_']['length']>0x0&&(_0x229190['byteLength_']+=0x1),_0x229190['parts_']['push'](_0x2a585b),_0x229190['byteLength_']+=Ln(_0x2a585b),Ao(_0x229190);}function Ph(_0x5b700a){const _0x2796ee=_0x5b700a['parts_']['pop']();_0x5b700a['byteLength_']-=Ln(_0x2796ee),_0x5b700a['parts_']['length']>0x0&&(_0x5b700a['byteLength_']-=0x1);}function Ao(_0x4e0024){if(_0x4e0024['byteLength_']>Zs)throw new Error(_0x4e0024['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4e0024['byteLength_']+').');if(_0x4e0024['parts_']['length']>Xs)throw new Error(_0x4e0024['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4e0024));}function Oe(_0x87ad65){return _0x87ad65['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x87ad65['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x44a1ed,_0x277e8a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x277e8a='visibilitychange',_0x44a1ed='hidden'):typeof document['mozHidden']<'u'?(_0x277e8a='mozvisibilitychange',_0x44a1ed='mozHidden'):typeof document['msHidden']<'u'?(_0x277e8a='msvisibilitychange',_0x44a1ed='msHidden'):typeof document['webkitHidden']<'u'&&(_0x277e8a='webkitvisibilitychange',_0x44a1ed='webkitHidden')),this['visible_']=!0x0,_0x277e8a&&document['addEventListener'](_0x277e8a,()=>{const _0x1ea17a=!document[_0x44a1ed];_0x1ea17a!==this['visible_']&&(this['visible_']=_0x1ea17a,this['trigger']('visible',_0x1ea17a));},!0x1);}['getInitialEvent'](_0x1cb9f8){return f(_0x1cb9f8==='visible','Unknown\x20event\x20type:\x20'+_0x1cb9f8),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x50b3e0,_0x4cae06,_0x4349f1,_0x33835c,_0x130cb8,_0x2845e9,_0x1d9f1c,_0x25433f){if(super(),this['repoInfo_']=_0x50b3e0,this['applicationId_']=_0x4cae06,this['onDataUpdate_']=_0x4349f1,this['onConnectStatus_']=_0x33835c,this['onServerInfoUpdate_']=_0x130cb8,this['authTokenProvider_']=_0x2845e9,this['appCheckTokenProvider_']=_0x1d9f1c,this['authOverride_']=_0x25433f,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x25433f)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x50b3e0['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3b6f22,_0x51439f,_0x495c59){const _0xc6cbe3=++this['requestNumber_'],_0x2c3e3d={'r':_0xc6cbe3,'a':_0x3b6f22,'b':_0x51439f};this['log_'](O(_0x2c3e3d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2c3e3d),_0x495c59&&(this['requestCBHash_'][_0xc6cbe3]=_0x495c59);}['get'](_0x599b4e){this['initConnection_']();const _0x31add5=new H(),_0x26e695={'action':'g','request':{'p':_0x599b4e['_path']['toString'](),'q':_0x599b4e['_queryObject']},'onComplete':_0x4f0cd6=>{const _0x5d66af=_0x4f0cd6['d'];_0x4f0cd6['s']==='ok'?_0x31add5['resolve'](_0x5d66af):_0x31add5['reject'](_0x5d66af);}};this['outstandingGets_']['push'](_0x26e695),this['outstandingGetCount_']++;const _0x201d54=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x201d54),_0x31add5['promise'];}['listen'](_0x2337b0,_0x3c5cff,_0x2087ac,_0x9b72cd){this['initConnection_']();const _0x380213=_0x2337b0['_queryIdentifier'],_0x20d1e5=_0x2337b0['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x20d1e5+'\x20'+_0x380213),this['listens']['has'](_0x20d1e5)||this['listens']['set'](_0x20d1e5,new Map()),f(_0x2337b0['_queryParams']['isDefault']()||!_0x2337b0['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x20d1e5)['has'](_0x380213),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x3896e5={'onComplete':_0x9b72cd,'hashFn':_0x3c5cff,'query':_0x2337b0,'tag':_0x2087ac};this['listens']['get'](_0x20d1e5)['set'](_0x380213,_0x3896e5),this['connected_']&&this['sendListen_'](_0x3896e5);}['sendGet_'](_0x515def){const _0x1fb96d=this['outstandingGets_'][_0x515def];this['sendRequest']('g',_0x1fb96d['request'],_0x465078=>{delete this['outstandingGets_'][_0x515def],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1fb96d['onComplete']&&_0x1fb96d['onComplete'](_0x465078);});}['sendListen_'](_0x4e4759){const _0x30f40e=_0x4e4759['query'],_0x245403=_0x30f40e['_path']['toString'](),_0x51c512=_0x30f40e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x245403+'\x20for\x20'+_0x51c512);const _0x8f71a9={'p':_0x245403},_0x52c8a4='q';_0x4e4759['tag']&&(_0x8f71a9['q']=_0x30f40e['_queryObject'],_0x8f71a9['t']=_0x4e4759['tag']),_0x8f71a9['h']=_0x4e4759['hashFn'](),this['sendRequest'](_0x52c8a4,_0x8f71a9,_0x3062ab=>{const _0x5c4fca=_0x3062ab['d'],_0x3dc1b4=_0x3062ab['s'];se['warnOnListenWarnings_'](_0x5c4fca,_0x30f40e),(this['listens']['get'](_0x245403)&&this['listens']['get'](_0x245403)['get'](_0x51c512))===_0x4e4759&&(this['log_']('listen\x20response',_0x3062ab),_0x3dc1b4!=='ok'&&this['removeListen_'](_0x245403,_0x51c512),_0x4e4759['onComplete']&&_0x4e4759['onComplete'](_0x3dc1b4,_0x5c4fca));});}static['warnOnListenWarnings_'](_0xc75e0e,_0x3901c3){if(_0xc75e0e&&typeof _0xc75e0e=='object'&&Q(_0xc75e0e,'w')){const _0x3ecfef=Le(_0xc75e0e,'w');if(Array['isArray'](_0x3ecfef)&&~_0x3ecfef['indexOf']('no_index')){const _0x486000='\x22.indexOn\x22:\x20\x22'+_0x3901c3['_queryParams']['getIndex']()['toString']()+'\x22',_0x44d022=_0x3901c3['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x486000+'\x20at\x20'+_0x44d022+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x4c254e){this['authToken_']=_0x4c254e,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x4c254e);}['reduceReconnectDelayIfAdminCredential_'](_0x45cd57){(_0x45cd57&&_0x45cd57['length']===0x28||wc(_0x45cd57))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x14e5a6){this['appCheckToken_']=_0x14e5a6,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x58bfd2=this['authToken_'],_0x2a8379=Ic(_0x58bfd2)?'auth':'gauth',_0x41f020={'cred':_0x58bfd2};this['authOverride_']===null?_0x41f020['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x41f020['authvar']=this['authOverride_']),this['sendRequest'](_0x2a8379,_0x41f020,_0x517228=>{const _0x5c6175=_0x517228['s'],_0x1c82b7=_0x517228['d']||'error';this['authToken_']===_0x58bfd2&&(_0x5c6175==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5c6175,_0x1c82b7));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xf394b4=>{const _0x5ae640=_0xf394b4['s'],_0x3922ea=_0xf394b4['d']||'error';_0x5ae640==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5ae640,_0x3922ea);});}['unlisten'](_0x34d100,_0x5e56bb){const _0x5808b3=_0x34d100['_path']['toString'](),_0x21e2a1=_0x34d100['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5808b3+'\x20'+_0x21e2a1),f(_0x34d100['_queryParams']['isDefault']()||!_0x34d100['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5808b3,_0x21e2a1)&&this['connected_']&&this['sendUnlisten_'](_0x5808b3,_0x21e2a1,_0x34d100['_queryObject'],_0x5e56bb);}['sendUnlisten_'](_0x18f6d9,_0xc47bbd,_0x484f97,_0x31da40){this['log_']('Unlisten\x20on\x20'+_0x18f6d9+'\x20for\x20'+_0xc47bbd);const _0x2320e4={'p':_0x18f6d9},_0x4c3edd='n';_0x31da40&&(_0x2320e4['q']=_0x484f97,_0x2320e4['t']=_0x31da40),this['sendRequest'](_0x4c3edd,_0x2320e4);}['onDisconnectPut'](_0x183477,_0x49c1a8,_0x4d5126){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x183477,_0x49c1a8,_0x4d5126):this['onDisconnectRequestQueue_']['push']({'pathString':_0x183477,'action':'o','data':_0x49c1a8,'onComplete':_0x4d5126});}['onDisconnectMerge'](_0x2d8fa4,_0x3f4fad,_0x20196c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2d8fa4,_0x3f4fad,_0x20196c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2d8fa4,'action':'om','data':_0x3f4fad,'onComplete':_0x20196c});}['onDisconnectCancel'](_0x2ab128,_0x4c4eb3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2ab128,null,_0x4c4eb3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2ab128,'action':'oc','data':null,'onComplete':_0x4c4eb3});}['sendOnDisconnect_'](_0x5d4308,_0x23d81b,_0x228dae,_0x2cce82){const _0x31369a={'p':_0x23d81b,'d':_0x228dae};this['log_']('onDisconnect\x20'+_0x5d4308,_0x31369a),this['sendRequest'](_0x5d4308,_0x31369a,_0x288e34=>{_0x2cce82&&setTimeout(()=>{_0x2cce82(_0x288e34['s'],_0x288e34['d']);},Math['floor'](0x0));});}['put'](_0x1cfc48,_0x52ec28,_0x57bf96,_0x2633a3){this['putInternal']('p',_0x1cfc48,_0x52ec28,_0x57bf96,_0x2633a3);}['merge'](_0x220704,_0x2f06d4,_0x46220e,_0x34abbd){this['putInternal']('m',_0x220704,_0x2f06d4,_0x46220e,_0x34abbd);}['putInternal'](_0x2820da,_0x425a90,_0x458eb8,_0x563191,_0x4ba6d9){this['initConnection_']();const _0x347e47={'p':_0x425a90,'d':_0x458eb8};_0x4ba6d9!==void 0x0&&(_0x347e47['h']=_0x4ba6d9),this['outstandingPuts_']['push']({'action':_0x2820da,'request':_0x347e47,'onComplete':_0x563191}),this['outstandingPutCount_']++;const _0x23e136=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x23e136):this['log_']('Buffering\x20put:\x20'+_0x425a90);}['sendPut_'](_0x5d9884){const _0x5ab3b1=this['outstandingPuts_'][_0x5d9884]['action'],_0xa971e2=this['outstandingPuts_'][_0x5d9884]['request'],_0x5a00ec=this['outstandingPuts_'][_0x5d9884]['onComplete'];this['outstandingPuts_'][_0x5d9884]['queued']=this['connected_'],this['sendRequest'](_0x5ab3b1,_0xa971e2,_0x386996=>{this['log_'](_0x5ab3b1+'\x20response',_0x386996),delete this['outstandingPuts_'][_0x5d9884],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5a00ec&&_0x5a00ec(_0x386996['s'],_0x386996['d']);});}['reportStats'](_0x3d3315){if(this['connected_']){const _0x57ed13={'c':_0x3d3315};this['log_']('reportStats',_0x57ed13),this['sendRequest']('s',_0x57ed13,_0x48bdff=>{if(_0x48bdff['s']!=='ok'){const _0x2c7b29=_0x48bdff['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2c7b29);}});}}['onDataMessage_'](_0x566b15){if('r'in _0x566b15){this['log_']('from\x20server:\x20'+O(_0x566b15));const _0x2c6865=_0x566b15['r'],_0x179104=this['requestCBHash_'][_0x2c6865];_0x179104&&(delete this['requestCBHash_'][_0x2c6865],_0x179104(_0x566b15['b']));}else{if('error'in _0x566b15)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x566b15['error'];'a'in _0x566b15&&this['onDataPush_'](_0x566b15['a'],_0x566b15['b']);}}['onDataPush_'](_0x16526d,_0x2ad952){this['log_']('handleServerMessage',_0x16526d,_0x2ad952),_0x16526d==='d'?this['onDataUpdate_'](_0x2ad952['p'],_0x2ad952['d'],!0x1,_0x2ad952['t']):_0x16526d==='m'?this['onDataUpdate_'](_0x2ad952['p'],_0x2ad952['d'],!0x0,_0x2ad952['t']):_0x16526d==='c'?this['onListenRevoked_'](_0x2ad952['p'],_0x2ad952['q']):_0x16526d==='ac'?this['onAuthRevoked_'](_0x2ad952['s'],_0x2ad952['d']):_0x16526d==='apc'?this['onAppCheckRevoked_'](_0x2ad952['s'],_0x2ad952['d']):_0x16526d==='sd'?this['onSecurityDebugPacket_'](_0x2ad952):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x16526d)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x43660f,_0x180e5a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x43660f),this['lastSessionId']=_0x180e5a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x84f88d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x84f88d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x3656c0){_0x3656c0&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x3656c0;}['onOnline_'](_0x281c38){_0x281c38?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1b1b2c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x9f8409=Math['max'](0x0,this['reconnectDelay_']-_0x1b1b2c);_0x9f8409=Math['random']()*_0x9f8409,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x9f8409+'ms'),this['scheduleConnect_'](_0x9f8409),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x570d04=this['onDataMessage_']['bind'](this),_0x2eca75=this['onReady_']['bind'](this),_0x42680b=this['onRealtimeDisconnect_']['bind'](this),_0x59d7c4=this['id']+':'+se['nextConnectionId_']++,_0x108e63=this['lastSessionId'];let _0xf058af=!0x1,_0x478a28=null;const _0x2c1311=function(){_0x478a28?_0x478a28['close']():(_0xf058af=!0x0,_0x42680b());},_0x38f340=function(_0x57b876){f(_0x478a28,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x478a28['sendRequest'](_0x57b876);};this['realtime_']={'close':_0x2c1311,'sendRequest':_0x38f340};const _0x16d108=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x29a250,_0x290605]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x16d108),this['appCheckTokenProvider_']['getToken'](_0x16d108)]);_0xf058af?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x29a250&&_0x29a250['accessToken'],this['appCheckToken_']=_0x290605&&_0x290605['token'],_0x478a28=new Sh(_0x59d7c4,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x570d04,_0x2eca75,_0x42680b,_0x896a8a=>{U(_0x896a8a+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x108e63));}catch(_0x1034a7){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1034a7),_0xf058af||(this['repoInfo_']['nodeAdmin']&&U(_0x1034a7),_0x2c1311());}}}['interrupt'](_0x14625b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x14625b),this['interruptReasons_'][_0x14625b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x49538a){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x49538a),delete this['interruptReasons_'][_0x49538a],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x190ca1){const _0x4a7409=_0x190ca1-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4a7409});}['cancelSentTransactions_'](){for(let _0x4f300a=0x0;_0x4f300a<this['outstandingPuts_']['length'];_0x4f300a++){const _0x227870=this['outstandingPuts_'][_0x4f300a];_0x227870&&'h'in _0x227870['request']&&_0x227870['queued']&&(_0x227870['onComplete']&&_0x227870['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4f300a],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x33ba3f,_0x2f96fe){let _0x2b0f3d;_0x2f96fe?_0x2b0f3d=_0x2f96fe['map'](_0x2956cd=>$i(_0x2956cd))['join']('$'):_0x2b0f3d='default';const _0x25f6cb=this['removeListen_'](_0x33ba3f,_0x2b0f3d);_0x25f6cb&&_0x25f6cb['onComplete']&&_0x25f6cb['onComplete']('permission_denied');}['removeListen_'](_0x2ca4dd,_0x38bd84){const _0x2170c5=new C(_0x2ca4dd)['toString']();let _0x3a0be9;if(this['listens']['has'](_0x2170c5)){const _0xb2929c=this['listens']['get'](_0x2170c5);_0x3a0be9=_0xb2929c['get'](_0x38bd84),_0xb2929c['delete'](_0x38bd84),_0xb2929c['size']===0x0&&this['listens']['delete'](_0x2170c5);}else _0x3a0be9=void 0x0;return _0x3a0be9;}['onAuthRevoked_'](_0x1ff926,_0xf0ddae){L('Auth\x20token\x20revoked:\x20'+_0x1ff926+'/'+_0xf0ddae),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1ff926==='invalid_token'||_0x1ff926==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3f93d1,_0x5e8f4d){L('App\x20check\x20token\x20revoked:\x20'+_0x3f93d1+'/'+_0x5e8f4d),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3f93d1==='invalid_token'||_0x3f93d1==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x15cf98){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x15cf98):'msg'in _0x15cf98&&console['log']('FIREBASE:\x20'+_0x15cf98['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x23f23c of this['listens']['values']())for(const _0x1d5f9a of _0x23f23c['values']())this['sendListen_'](_0x1d5f9a);for(let _0x236ce1=0x0;_0x236ce1<this['outstandingPuts_']['length'];_0x236ce1++)this['outstandingPuts_'][_0x236ce1]&&this['sendPut_'](_0x236ce1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2629b6=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2629b6['action'],_0x2629b6['pathString'],_0x2629b6['data'],_0x2629b6['onComplete']);}for(let _0x485f23=0x0;_0x485f23<this['outstandingGets_']['length'];_0x485f23++)this['outstandingGets_'][_0x485f23]&&this['sendGet_'](_0x485f23);}['sendConnectStats_'](){const _0x10465c={};let _0x50e42e='js';_0x10465c['sdk.'+_0x50e42e+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x10465c['framework.cordova']=0x1:Kr()&&(_0x10465c['framework.reactnative']=0x1),this['reportStats'](_0x10465c);}['shouldReconnect_'](){const _0x311e0f=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x311e0f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4dbe0c,_0x4a6367){this['name']=_0x4dbe0c,this['node']=_0x4a6367;}static['Wrap'](_0x533306,_0x34ccf7){return new E(_0x533306,_0x34ccf7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x54a53f,_0x310507){const _0x20486c=new E(We,_0x54a53f),_0x4f6230=new E(We,_0x310507);return this['compare'](_0x20486c,_0x4f6230)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0xa59b00){sn=_0xa59b00;}['compare'](_0x490c8d,_0x376374){return qe(_0x490c8d['name'],_0x376374['name']);}['isDefinedOn'](_0x58a0d6){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x55c9de,_0x178e07){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x12b7d5,_0x3f7a9f){return f(typeof _0x12b7d5=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x12b7d5,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x56f8ec,_0x5ee2ac,_0x1638af,_0x5db3d5,_0x40b5b3=null){this['isReverse_']=_0x5db3d5,this['resultGenerator_']=_0x40b5b3,this['nodeStack_']=[];let _0x2410ba=0x1;for(;!_0x56f8ec['isEmpty']();)if(_0x56f8ec=_0x56f8ec,_0x2410ba=_0x5ee2ac?_0x1638af(_0x56f8ec['key'],_0x5ee2ac):0x1,_0x5db3d5&&(_0x2410ba*=-0x1),_0x2410ba<0x0)this['isReverse_']?_0x56f8ec=_0x56f8ec['left']:_0x56f8ec=_0x56f8ec['right'];else{if(_0x2410ba===0x0){this['nodeStack_']['push'](_0x56f8ec);break;}else this['nodeStack_']['push'](_0x56f8ec),this['isReverse_']?_0x56f8ec=_0x56f8ec['right']:_0x56f8ec=_0x56f8ec['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x31bdec=this['nodeStack_']['pop'](),_0x46088c;if(this['resultGenerator_']?_0x46088c=this['resultGenerator_'](_0x31bdec['key'],_0x31bdec['value']):_0x46088c={'key':_0x31bdec['key'],'value':_0x31bdec['value']},this['isReverse_']){for(_0x31bdec=_0x31bdec['left'];!_0x31bdec['isEmpty']();)this['nodeStack_']['push'](_0x31bdec),_0x31bdec=_0x31bdec['right'];}else{for(_0x31bdec=_0x31bdec['right'];!_0x31bdec['isEmpty']();)this['nodeStack_']['push'](_0x31bdec),_0x31bdec=_0x31bdec['left'];}return _0x46088c;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x57195e=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x57195e['key'],_0x57195e['value']):{'key':_0x57195e['key'],'value':_0x57195e['value']};}}class M{constructor(_0x5b9f4b,_0x20b5be,_0x2648f2,_0x4922d6,_0x8f3030){this['key']=_0x5b9f4b,this['value']=_0x20b5be,this['color']=_0x2648f2??M['RED'],this['left']=_0x4922d6??B['EMPTY_NODE'],this['right']=_0x8f3030??B['EMPTY_NODE'];}['copy'](_0x377c18,_0x16b4f4,_0x150af9,_0x228067,_0x2a4c70){return new M(_0x377c18??this['key'],_0x16b4f4??this['value'],_0x150af9??this['color'],_0x228067??this['left'],_0x2a4c70??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x49f925){return this['left']['inorderTraversal'](_0x49f925)||!!_0x49f925(this['key'],this['value'])||this['right']['inorderTraversal'](_0x49f925);}['reverseTraversal'](_0x346e5f){return this['right']['reverseTraversal'](_0x346e5f)||_0x346e5f(this['key'],this['value'])||this['left']['reverseTraversal'](_0x346e5f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4ff613,_0x1d94cc,_0x1729a8){let _0x381870=this;const _0x55bd19=_0x1729a8(_0x4ff613,_0x381870['key']);return _0x55bd19<0x0?_0x381870=_0x381870['copy'](null,null,null,_0x381870['left']['insert'](_0x4ff613,_0x1d94cc,_0x1729a8),null):_0x55bd19===0x0?_0x381870=_0x381870['copy'](null,_0x1d94cc,null,null,null):_0x381870=_0x381870['copy'](null,null,null,null,_0x381870['right']['insert'](_0x4ff613,_0x1d94cc,_0x1729a8)),_0x381870['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1ca78e=this;return!_0x1ca78e['left']['isRed_']()&&!_0x1ca78e['left']['left']['isRed_']()&&(_0x1ca78e=_0x1ca78e['moveRedLeft_']()),_0x1ca78e=_0x1ca78e['copy'](null,null,null,_0x1ca78e['left']['removeMin_'](),null),_0x1ca78e['fixUp_']();}['remove'](_0x3905ed,_0x4027cb){let _0x5de940,_0x114e7f;if(_0x5de940=this,_0x4027cb(_0x3905ed,_0x5de940['key'])<0x0)!_0x5de940['left']['isEmpty']()&&!_0x5de940['left']['isRed_']()&&!_0x5de940['left']['left']['isRed_']()&&(_0x5de940=_0x5de940['moveRedLeft_']()),_0x5de940=_0x5de940['copy'](null,null,null,_0x5de940['left']['remove'](_0x3905ed,_0x4027cb),null);else{if(_0x5de940['left']['isRed_']()&&(_0x5de940=_0x5de940['rotateRight_']()),!_0x5de940['right']['isEmpty']()&&!_0x5de940['right']['isRed_']()&&!_0x5de940['right']['left']['isRed_']()&&(_0x5de940=_0x5de940['moveRedRight_']()),_0x4027cb(_0x3905ed,_0x5de940['key'])===0x0){if(_0x5de940['right']['isEmpty']())return B['EMPTY_NODE'];_0x114e7f=_0x5de940['right']['min_'](),_0x5de940=_0x5de940['copy'](_0x114e7f['key'],_0x114e7f['value'],null,null,_0x5de940['right']['removeMin_']());}_0x5de940=_0x5de940['copy'](null,null,null,null,_0x5de940['right']['remove'](_0x3905ed,_0x4027cb));}return _0x5de940['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x193e14=this;return _0x193e14['right']['isRed_']()&&!_0x193e14['left']['isRed_']()&&(_0x193e14=_0x193e14['rotateLeft_']()),_0x193e14['left']['isRed_']()&&_0x193e14['left']['left']['isRed_']()&&(_0x193e14=_0x193e14['rotateRight_']()),_0x193e14['left']['isRed_']()&&_0x193e14['right']['isRed_']()&&(_0x193e14=_0x193e14['colorFlip_']()),_0x193e14;}['moveRedLeft_'](){let _0x28ce37=this['colorFlip_']();return _0x28ce37['right']['left']['isRed_']()&&(_0x28ce37=_0x28ce37['copy'](null,null,null,null,_0x28ce37['right']['rotateRight_']()),_0x28ce37=_0x28ce37['rotateLeft_'](),_0x28ce37=_0x28ce37['colorFlip_']()),_0x28ce37;}['moveRedRight_'](){let _0x3fd144=this['colorFlip_']();return _0x3fd144['left']['left']['isRed_']()&&(_0x3fd144=_0x3fd144['rotateRight_'](),_0x3fd144=_0x3fd144['colorFlip_']()),_0x3fd144;}['rotateLeft_'](){const _0x4915d4=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4915d4,null);}['rotateRight_'](){const _0x80ae69=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x80ae69);}['colorFlip_'](){const _0x102937=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4630fc=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x102937,_0x4630fc);}['checkMaxDepth_'](){const _0x2b7433=this['check_']();return Math['pow'](0x2,_0x2b7433)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x103fa0=this['left']['check_']();if(_0x103fa0!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x103fa0+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x3baf84,_0xc9495a,_0x56a31c,_0x5cf798,_0x14179b){return this;}['insert'](_0x3328e1,_0x1c9789,_0x47ea81){return new M(_0x3328e1,_0x1c9789,null);}['remove'](_0x4b0dbc,_0xf94e6c){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x580a0f){return!0x1;}['reverseTraversal'](_0x3f30f0){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4a670b,_0x288d35=B['EMPTY_NODE']){this['comparator_']=_0x4a670b,this['root_']=_0x288d35;}['insert'](_0x4efeba,_0x598519){return new B(this['comparator_'],this['root_']['insert'](_0x4efeba,_0x598519,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x373ee1){return new B(this['comparator_'],this['root_']['remove'](_0x373ee1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1d5449){let _0x389dc5,_0x1fce60=this['root_'];for(;!_0x1fce60['isEmpty']();){if(_0x389dc5=this['comparator_'](_0x1d5449,_0x1fce60['key']),_0x389dc5===0x0)return _0x1fce60['value'];_0x389dc5<0x0?_0x1fce60=_0x1fce60['left']:_0x389dc5>0x0&&(_0x1fce60=_0x1fce60['right']);}return null;}['getPredecessorKey'](_0x4135d5){let _0x1f5d4f,_0x9c1409=this['root_'],_0x275de0=null;for(;!_0x9c1409['isEmpty']();)if(_0x1f5d4f=this['comparator_'](_0x4135d5,_0x9c1409['key']),_0x1f5d4f===0x0){if(_0x9c1409['left']['isEmpty']())return _0x275de0?_0x275de0['key']:null;for(_0x9c1409=_0x9c1409['left'];!_0x9c1409['right']['isEmpty']();)_0x9c1409=_0x9c1409['right'];return _0x9c1409['key'];}else _0x1f5d4f<0x0?_0x9c1409=_0x9c1409['left']:_0x1f5d4f>0x0&&(_0x275de0=_0x9c1409,_0x9c1409=_0x9c1409['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1d345d){return this['root_']['inorderTraversal'](_0x1d345d);}['reverseTraversal'](_0x8ec4e9){return this['root_']['reverseTraversal'](_0x8ec4e9);}['getIterator'](_0x316587){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x316587);}['getIteratorFrom'](_0x5626cb,_0x475672){return new rn(this['root_'],_0x5626cb,this['comparator_'],!0x1,_0x475672);}['getReverseIteratorFrom'](_0x565342,_0x4cd515){return new rn(this['root_'],_0x565342,this['comparator_'],!0x0,_0x4cd515);}['getReverseIterator'](_0x1241b2){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1241b2);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1c2efc,_0x10247e){return qe(_0x1c2efc['name'],_0x10247e['name']);}function Qi(_0x24cbc3,_0x586a24){return qe(_0x24cbc3,_0x586a24);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x992cc4){Ci=_0x992cc4;}const Po=function(_0x545f82){return typeof _0x545f82=='number'?'number:'+ao(_0x545f82):'string:'+_0x545f82;},No=function(_0x417797){if(_0x417797['isLeafNode']()){const _0x56e9fa=_0x417797['val']();f(typeof _0x56e9fa=='string'||typeof _0x56e9fa=='number'||typeof _0x56e9fa=='object'&&Q(_0x56e9fa,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x417797===Ci||_0x417797['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x417797===Ci||_0x417797['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x488abb){nr=_0x488abb;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x22be6b,_0x3ae4ba=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x22be6b,this['priorityNode_']=_0x3ae4ba,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x469944){return new D(this['value_'],_0x469944);}['getImmediateChild'](_0x14d3b8){return _0x14d3b8==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x518e88){return v(_0x518e88)?this:y(_0x518e88)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x899984,_0x517380){return null;}['updateImmediateChild'](_0x19310c,_0x50deb0){return _0x19310c==='.priority'?this['updatePriority'](_0x50deb0):_0x50deb0['isEmpty']()&&_0x19310c!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x19310c,_0x50deb0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x30ac07,_0x6ad216){const _0x72247a=y(_0x30ac07);return _0x72247a===null?_0x6ad216:_0x6ad216['isEmpty']()&&_0x72247a!=='.priority'?this:(f(_0x72247a!=='.priority'||Ce(_0x30ac07)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x72247a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x30ac07),_0x6ad216)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x135c9e,_0xf247a0){return!0x1;}['val'](_0xc4dc6e){return _0xc4dc6e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x165bf2='';this['priorityNode_']['isEmpty']()||(_0x165bf2+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x2c17bf=typeof this['value_'];_0x165bf2+=_0x2c17bf+':',_0x2c17bf==='number'?_0x165bf2+=ao(this['value_']):_0x165bf2+=this['value_'],this['lazyHash_']=ro(_0x165bf2);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x52b423){return _0x52b423===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x52b423 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x52b423['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x52b423));}['compareToLeafNode_'](_0x141f62){const _0x1b1377=typeof _0x141f62['value_'],_0x57b7ba=typeof this['value_'],_0x5735b1=D['VALUE_TYPE_ORDER']['indexOf'](_0x1b1377),_0x157de5=D['VALUE_TYPE_ORDER']['indexOf'](_0x57b7ba);return f(_0x5735b1>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1b1377),f(_0x157de5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x57b7ba),_0x5735b1===_0x157de5?_0x57b7ba==='object'?0x0:this['value_']<_0x141f62['value_']?-0x1:this['value_']===_0x141f62['value_']?0x0:0x1:_0x157de5-_0x5735b1;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xe82459){if(_0xe82459===this)return!0x0;if(_0xe82459['isLeafNode']()){const _0x3519ec=_0xe82459;return this['value_']===_0x3519ec['value_']&&this['priorityNode_']['equals'](_0x3519ec['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x544cb8){Oo=_0x544cb8;}function Wh(_0xa36d6e){Do=_0xa36d6e;}class Bh extends Fn{['compare'](_0xce503e,_0x582c5f){const _0x28b6ef=_0xce503e['node']['getPriority'](),_0x27b55a=_0x582c5f['node']['getPriority'](),_0x38898b=_0x28b6ef['compareTo'](_0x27b55a);return _0x38898b===0x0?qe(_0xce503e['name'],_0x582c5f['name']):_0x38898b;}['isDefinedOn'](_0x36a607){return!_0x36a607['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x52f16c,_0xd0eacc){return!_0x52f16c['getPriority']()['equals'](_0xd0eacc['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x1342c5,_0x294309){const _0x166b48=Oo(_0x1342c5);return new E(_0x294309,new D('[PRIORITY-POST]',_0x166b48));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x4c0e1d){const _0x3dfdf1=_0x1d5e06=>parseInt(Math['log'](_0x1d5e06)/Vh,0xa),_0x5cdeae=_0x878646=>parseInt(Array(_0x878646+0x1)['join']('1'),0x2);this['count']=_0x3dfdf1(_0x4c0e1d+0x1),this['current_']=this['count']-0x1;const _0x1e63f1=_0x5cdeae(this['count']);this['bits_']=_0x4c0e1d+0x1&_0x1e63f1;}['nextBitIsOne'](){const _0x43b91d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x43b91d;}}const yn=function(_0x131fce,_0x2749cb,_0x247373,_0x39d7ce){_0x131fce['sort'](_0x2749cb);const _0x47ce59=function(_0x32731c,_0x336a3b){const _0x188e8a=_0x336a3b-_0x32731c;let _0x19f8ef,_0x4f0fdc;if(_0x188e8a===0x0)return null;if(_0x188e8a===0x1)return _0x19f8ef=_0x131fce[_0x32731c],_0x4f0fdc=_0x247373?_0x247373(_0x19f8ef):_0x19f8ef,new M(_0x4f0fdc,_0x19f8ef['node'],M['BLACK'],null,null);{const _0x33d482=parseInt(_0x188e8a/0x2,0xa)+_0x32731c,_0x14a545=_0x47ce59(_0x32731c,_0x33d482),_0x3e2620=_0x47ce59(_0x33d482+0x1,_0x336a3b);return _0x19f8ef=_0x131fce[_0x33d482],_0x4f0fdc=_0x247373?_0x247373(_0x19f8ef):_0x19f8ef,new M(_0x4f0fdc,_0x19f8ef['node'],M['BLACK'],_0x14a545,_0x3e2620);}},_0x1b2665=function(_0x2087bf){let _0x557b76=null,_0x471368=null,_0x5d14dc=_0x131fce['length'];const _0x48611a=function(_0x3d704a,_0x4688d4){const _0x476350=_0x5d14dc-_0x3d704a,_0x53ff9f=_0x5d14dc;_0x5d14dc-=_0x3d704a;const _0x2d0665=_0x47ce59(_0x476350+0x1,_0x53ff9f),_0x370efd=_0x131fce[_0x476350],_0x2ba3fd=_0x247373?_0x247373(_0x370efd):_0x370efd;_0x185ea2(new M(_0x2ba3fd,_0x370efd['node'],_0x4688d4,null,_0x2d0665));},_0x185ea2=function(_0x1edd7b){_0x557b76?(_0x557b76['left']=_0x1edd7b,_0x557b76=_0x1edd7b):(_0x471368=_0x1edd7b,_0x557b76=_0x1edd7b);};for(let _0x331695=0x0;_0x331695<_0x2087bf['count'];++_0x331695){const _0x1eba8=_0x2087bf['nextBitIsOne'](),_0x34b607=Math['pow'](0x2,_0x2087bf['count']-(_0x331695+0x1));_0x1eba8?_0x48611a(_0x34b607,M['BLACK']):(_0x48611a(_0x34b607,M['BLACK']),_0x48611a(_0x34b607,M['RED']));}return _0x471368;},_0x18a75d=new Hh(_0x131fce['length']),_0x4f5c2d=_0x1b2665(_0x18a75d);return new B(_0x39d7ce||_0x2749cb,_0x4f5c2d);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x100b5f,_0x19b299){this['indexes_']=_0x100b5f,this['indexSet_']=_0x19b299;}['get'](_0x1fa113){const _0x875f8d=Le(this['indexes_'],_0x1fa113);if(!_0x875f8d)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1fa113);return _0x875f8d instanceof B?_0x875f8d:null;}['hasIndex'](_0x57f4c8){return Q(this['indexSet_'],_0x57f4c8['toString']());}['addIndex'](_0x10d1ba,_0x4a68bf){f(_0x10d1ba!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2f52d0=[];let _0x121a0f=!0x1;const _0x2a9b2d=_0x4a68bf['getIterator'](E['Wrap']);let _0x283cc0=_0x2a9b2d['getNext']();for(;_0x283cc0;)_0x121a0f=_0x121a0f||_0x10d1ba['isDefinedOn'](_0x283cc0['node']),_0x2f52d0['push'](_0x283cc0),_0x283cc0=_0x2a9b2d['getNext']();let _0x537922;_0x121a0f?_0x537922=yn(_0x2f52d0,_0x10d1ba['getCompare']()):_0x537922=Qe;const _0x37d308=_0x10d1ba['toString'](),_0x4628ca={...this['indexSet_']};_0x4628ca[_0x37d308]=_0x10d1ba;const _0x258911={...this['indexes_']};return _0x258911[_0x37d308]=_0x537922,new te(_0x258911,_0x4628ca);}['addToIndexes'](_0x37abcb,_0x4cdf42){const _0x8c46a6=_n(this['indexes_'],(_0x485fae,_0xb11509)=>{const _0x55b3d1=Le(this['indexSet_'],_0xb11509);if(f(_0x55b3d1,'Missing\x20index\x20implementation\x20for\x20'+_0xb11509),_0x485fae===Qe){if(_0x55b3d1['isDefinedOn'](_0x37abcb['node'])){const _0x25e753=[],_0x446992=_0x4cdf42['getIterator'](E['Wrap']);let _0x20e150=_0x446992['getNext']();for(;_0x20e150;)_0x20e150['name']!==_0x37abcb['name']&&_0x25e753['push'](_0x20e150),_0x20e150=_0x446992['getNext']();return _0x25e753['push'](_0x37abcb),yn(_0x25e753,_0x55b3d1['getCompare']());}else return Qe;}else{const _0x3a4942=_0x4cdf42['get'](_0x37abcb['name']);let _0x5f30f1=_0x485fae;return _0x3a4942&&(_0x5f30f1=_0x5f30f1['remove'](new E(_0x37abcb['name'],_0x3a4942))),_0x5f30f1['insert'](_0x37abcb,_0x37abcb['node']);}});return new te(_0x8c46a6,this['indexSet_']);}['removeFromIndexes'](_0x5c0cf2,_0x424b96){const _0x103cf0=_n(this['indexes_'],_0x224b57=>{if(_0x224b57===Qe)return _0x224b57;{const _0xbfba62=_0x424b96['get'](_0x5c0cf2['name']);return _0xbfba62?_0x224b57['remove'](new E(_0x5c0cf2['name'],_0xbfba62)):_0x224b57;}});return new te(_0x103cf0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x150681,_0x133fbd,_0x16e72b){this['children_']=_0x150681,this['priorityNode_']=_0x133fbd,this['indexMap_']=_0x16e72b,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x22cf47){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x22cf47,this['indexMap_']);}['getImmediateChild'](_0x2b96c4){if(_0x2b96c4==='.priority')return this['getPriority']();{const _0x2c5226=this['children_']['get'](_0x2b96c4);return _0x2c5226===null?It:_0x2c5226;}}['getChild'](_0x14230d){const _0x1604c0=y(_0x14230d);return _0x1604c0===null?this:this['getImmediateChild'](_0x1604c0)['getChild'](S(_0x14230d));}['hasChild'](_0x25e8ce){return this['children_']['get'](_0x25e8ce)!==null;}['updateImmediateChild'](_0x1451ba,_0x2a8bf9){if(f(_0x2a8bf9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1451ba==='.priority')return this['updatePriority'](_0x2a8bf9);{const _0x2b91d7=new E(_0x1451ba,_0x2a8bf9);let _0x3503,_0x24546c;_0x2a8bf9['isEmpty']()?(_0x3503=this['children_']['remove'](_0x1451ba),_0x24546c=this['indexMap_']['removeFromIndexes'](_0x2b91d7,this['children_'])):(_0x3503=this['children_']['insert'](_0x1451ba,_0x2a8bf9),_0x24546c=this['indexMap_']['addToIndexes'](_0x2b91d7,this['children_']));const _0x46f524=_0x3503['isEmpty']()?It:this['priorityNode_'];return new g(_0x3503,_0x46f524,_0x24546c);}}['updateChild'](_0x3ce640,_0xc26ee){const _0x213bc9=y(_0x3ce640);if(_0x213bc9===null)return _0xc26ee;{f(y(_0x3ce640)!=='.priority'||Ce(_0x3ce640)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1f3ebb=this['getImmediateChild'](_0x213bc9)['updateChild'](S(_0x3ce640),_0xc26ee);return this['updateImmediateChild'](_0x213bc9,_0x1f3ebb);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x491531){if(this['isEmpty']())return null;const _0x1b4fd2={};let _0x30a1e1=0x0,_0x50f993=0x0,_0x9bb71d=!0x0;if(this['forEachChild'](R,(_0x1dca4e,_0x5fd01)=>{_0x1b4fd2[_0x1dca4e]=_0x5fd01['val'](_0x491531),_0x30a1e1++,_0x9bb71d&&g['INTEGER_REGEXP_']['test'](_0x1dca4e)?_0x50f993=Math['max'](_0x50f993,Number(_0x1dca4e)):_0x9bb71d=!0x1;}),!_0x491531&&_0x9bb71d&&_0x50f993<0x2*_0x30a1e1){const _0x2d74d1=[];for(const _0x40c740 in _0x1b4fd2)_0x2d74d1[_0x40c740]=_0x1b4fd2[_0x40c740];return _0x2d74d1;}else return _0x491531&&!this['getPriority']()['isEmpty']()&&(_0x1b4fd2['.priority']=this['getPriority']()['val']()),_0x1b4fd2;}['hash'](){if(this['lazyHash_']===null){let _0xdd107f='';this['getPriority']()['isEmpty']()||(_0xdd107f+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x35c14a,_0x2022b8)=>{const _0x3d59cb=_0x2022b8['hash']();_0x3d59cb!==''&&(_0xdd107f+=':'+_0x35c14a+':'+_0x3d59cb);}),this['lazyHash_']=_0xdd107f===''?'':ro(_0xdd107f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x296506,_0x371c68,_0x4454aa){const _0x40e2f5=this['resolveIndex_'](_0x4454aa);if(_0x40e2f5){const _0x474304=_0x40e2f5['getPredecessorKey'](new E(_0x296506,_0x371c68));return _0x474304?_0x474304['name']:null;}else return this['children_']['getPredecessorKey'](_0x296506);}['getFirstChildName'](_0x19c58f){const _0x232d5d=this['resolveIndex_'](_0x19c58f);if(_0x232d5d){const _0x1896cb=_0x232d5d['minKey']();return _0x1896cb&&_0x1896cb['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4c5870){const _0x2c1612=this['getFirstChildName'](_0x4c5870);return _0x2c1612?new E(_0x2c1612,this['children_']['get'](_0x2c1612)):null;}['getLastChildName'](_0x215cff){const _0x13ad56=this['resolveIndex_'](_0x215cff);if(_0x13ad56){const _0x4f3e79=_0x13ad56['maxKey']();return _0x4f3e79&&_0x4f3e79['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x138b68){const _0x2da13c=this['getLastChildName'](_0x138b68);return _0x2da13c?new E(_0x2da13c,this['children_']['get'](_0x2da13c)):null;}['forEachChild'](_0x4601ba,_0x2d33e5){const _0x26c3b5=this['resolveIndex_'](_0x4601ba);return _0x26c3b5?_0x26c3b5['inorderTraversal'](_0x2398eb=>_0x2d33e5(_0x2398eb['name'],_0x2398eb['node'])):this['children_']['inorderTraversal'](_0x2d33e5);}['getIterator'](_0x3d3aa2){return this['getIteratorFrom'](_0x3d3aa2['minPost'](),_0x3d3aa2);}['getIteratorFrom'](_0x286de7,_0x31cea1){const _0x20af7f=this['resolveIndex_'](_0x31cea1);if(_0x20af7f)return _0x20af7f['getIteratorFrom'](_0x286de7,_0x14bb8f=>_0x14bb8f);{const _0x1f54c4=this['children_']['getIteratorFrom'](_0x286de7['name'],E['Wrap']);let _0x2adeb1=_0x1f54c4['peek']();for(;_0x2adeb1!=null&&_0x31cea1['compare'](_0x2adeb1,_0x286de7)<0x0;)_0x1f54c4['getNext'](),_0x2adeb1=_0x1f54c4['peek']();return _0x1f54c4;}}['getReverseIterator'](_0x37c5f2){return this['getReverseIteratorFrom'](_0x37c5f2['maxPost'](),_0x37c5f2);}['getReverseIteratorFrom'](_0x5d8826,_0x1ad215){const _0xcd6235=this['resolveIndex_'](_0x1ad215);if(_0xcd6235)return _0xcd6235['getReverseIteratorFrom'](_0x5d8826,_0x5a20ad=>_0x5a20ad);{const _0x2ca0e4=this['children_']['getReverseIteratorFrom'](_0x5d8826['name'],E['Wrap']);let _0x2da856=_0x2ca0e4['peek']();for(;_0x2da856!=null&&_0x1ad215['compare'](_0x2da856,_0x5d8826)>0x0;)_0x2ca0e4['getNext'](),_0x2da856=_0x2ca0e4['peek']();return _0x2ca0e4;}}['compareTo'](_0x34df16){return this['isEmpty']()?_0x34df16['isEmpty']()?0x0:-0x1:_0x34df16['isLeafNode']()||_0x34df16['isEmpty']()?0x1:_0x34df16===Kt?-0x1:0x0;}['withIndex'](_0x1f3d1c){if(_0x1f3d1c===ve||this['indexMap_']['hasIndex'](_0x1f3d1c))return this;{const _0x55cc3f=this['indexMap_']['addIndex'](_0x1f3d1c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x55cc3f);}}['isIndexed'](_0x4e656e){return _0x4e656e===ve||this['indexMap_']['hasIndex'](_0x4e656e);}['equals'](_0x1fc6c0){if(_0x1fc6c0===this)return!0x0;if(_0x1fc6c0['isLeafNode']())return!0x1;{const _0x18f933=_0x1fc6c0;if(this['getPriority']()['equals'](_0x18f933['getPriority']())){if(this['children_']['count']()===_0x18f933['children_']['count']()){const _0x13e661=this['getIterator'](R),_0x37593e=_0x18f933['getIterator'](R);let _0x5493b7=_0x13e661['getNext'](),_0x2d3462=_0x37593e['getNext']();for(;_0x5493b7&&_0x2d3462;){if(_0x5493b7['name']!==_0x2d3462['name']||!_0x5493b7['node']['equals'](_0x2d3462['node']))return!0x1;_0x5493b7=_0x13e661['getNext'](),_0x2d3462=_0x37593e['getNext']();}return _0x5493b7===null&&_0x2d3462===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x51617b){return _0x51617b===ve?null:this['indexMap_']['get'](_0x51617b['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3f9f5f){return _0x3f9f5f===this?0x0:0x1;}['equals'](_0x29cedd){return _0x29cedd===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5789f3){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x329688,_0x3a2591=null){if(_0x329688===null)return g['EMPTY_NODE'];if(typeof _0x329688=='object'&&'.priority'in _0x329688&&(_0x3a2591=_0x329688['.priority']),f(_0x3a2591===null||typeof _0x3a2591=='string'||typeof _0x3a2591=='number'||typeof _0x3a2591=='object'&&'.sv'in _0x3a2591,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3a2591),typeof _0x329688=='object'&&'.value'in _0x329688&&_0x329688['.value']!==null&&(_0x329688=_0x329688['.value']),typeof _0x329688!='object'||'.sv'in _0x329688){const _0x3320cc=_0x329688;return new D(_0x3320cc,A(_0x3a2591));}if(!(_0x329688 instanceof Array)&&Gh){const _0x8f238=[];let _0x3fd496=!0x1;if(x(_0x329688,(_0x24ab54,_0x162edd)=>{if(_0x24ab54['substring'](0x0,0x1)!=='.'){const _0x18d903=A(_0x162edd);_0x18d903['isEmpty']()||(_0x3fd496=_0x3fd496||!_0x18d903['getPriority']()['isEmpty'](),_0x8f238['push'](new E(_0x24ab54,_0x18d903)));}}),_0x8f238['length']===0x0)return g['EMPTY_NODE'];const _0x4ef6cb=yn(_0x8f238,xh,_0x124e1f=>_0x124e1f['name'],Qi);if(_0x3fd496){const _0x195c9a=yn(_0x8f238,R['getCompare']());return new g(_0x4ef6cb,A(_0x3a2591),new te({'.priority':_0x195c9a},{'.priority':R}));}else return new g(_0x4ef6cb,A(_0x3a2591),te['Default']);}else{let _0x316721=g['EMPTY_NODE'];return x(_0x329688,(_0xe1ac73,_0x779b80)=>{if(Q(_0x329688,_0xe1ac73)&&_0xe1ac73['substring'](0x0,0x1)!=='.'){const _0x568141=A(_0x779b80);(_0x568141['isLeafNode']()||!_0x568141['isEmpty']())&&(_0x316721=_0x316721['updateImmediateChild'](_0xe1ac73,_0x568141));}}),_0x316721['updatePriority'](A(_0x3a2591));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x47a8c7){super(),this['indexPath_']=_0x47a8c7,f(!v(_0x47a8c7)&&y(_0x47a8c7)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1ed558){return _0x1ed558['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2d78fe){return!_0x2d78fe['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3df3e5,_0x5c1d33){const _0x5a12c9=this['extractChild'](_0x3df3e5['node']),_0x4aafbb=this['extractChild'](_0x5c1d33['node']),_0x5e476a=_0x5a12c9['compareTo'](_0x4aafbb);return _0x5e476a===0x0?qe(_0x3df3e5['name'],_0x5c1d33['name']):_0x5e476a;}['makePost'](_0x51a25c,_0x1c39a8){const _0x1e5ad2=A(_0x51a25c),_0xbcefb7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1e5ad2);return new E(_0x1c39a8,_0xbcefb7);}['maxPost'](){const _0x17b4e7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x17b4e7);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x51dd37,_0x5a1913){const _0xbd41c8=_0x51dd37['node']['compareTo'](_0x5a1913['node']);return _0xbd41c8===0x0?qe(_0x51dd37['name'],_0x5a1913['name']):_0xbd41c8;}['isDefinedOn'](_0x1c5a60){return!0x0;}['indexedValueChanged'](_0x363500,_0xc88ff4){return!_0x363500['equals'](_0xc88ff4);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x42b495,_0x143a63){const _0x11fdde=A(_0x42b495);return new E(_0x143a63,_0x11fdde);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x220534){return{'type':'value','snapshotNode':_0x220534};}function rt(_0x3840d7,_0x3fd334){return{'type':'child_added','snapshotNode':_0x3fd334,'childName':_0x3840d7};}function Lt(_0x460ded,_0xa5e208){return{'type':'child_removed','snapshotNode':_0xa5e208,'childName':_0x460ded};}function xt(_0x2c8cf0,_0x12df8d,_0x2ab808){return{'type':'child_changed','snapshotNode':_0x12df8d,'childName':_0x2c8cf0,'oldSnap':_0x2ab808};}function zh(_0x51f8d8,_0x4cfa15){return{'type':'child_moved','snapshotNode':_0x4cfa15,'childName':_0x51f8d8};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x305cab){this['index_']=_0x305cab;}['updateChild'](_0x1e5542,_0xa4c1f1,_0x58549a,_0x4c6332,_0x47faa9,_0x3b0a6d){f(_0x1e5542['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1ca372=_0x1e5542['getImmediateChild'](_0xa4c1f1);return _0x1ca372['getChild'](_0x4c6332)['equals'](_0x58549a['getChild'](_0x4c6332))&&_0x1ca372['isEmpty']()===_0x58549a['isEmpty']()||(_0x3b0a6d!=null&&(_0x58549a['isEmpty']()?_0x1e5542['hasChild'](_0xa4c1f1)?_0x3b0a6d['trackChildChange'](Lt(_0xa4c1f1,_0x1ca372)):f(_0x1e5542['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1ca372['isEmpty']()?_0x3b0a6d['trackChildChange'](rt(_0xa4c1f1,_0x58549a)):_0x3b0a6d['trackChildChange'](xt(_0xa4c1f1,_0x58549a,_0x1ca372))),_0x1e5542['isLeafNode']()&&_0x58549a['isEmpty']())?_0x1e5542:_0x1e5542['updateImmediateChild'](_0xa4c1f1,_0x58549a)['withIndex'](this['index_']);}['updateFullNode'](_0x5a9fae,_0x4721b9,_0x2ac97f){return _0x2ac97f!=null&&(_0x5a9fae['isLeafNode']()||_0x5a9fae['forEachChild'](R,(_0x1608e1,_0x22335e)=>{_0x4721b9['hasChild'](_0x1608e1)||_0x2ac97f['trackChildChange'](Lt(_0x1608e1,_0x22335e));}),_0x4721b9['isLeafNode']()||_0x4721b9['forEachChild'](R,(_0x25c8bc,_0x3cdd90)=>{if(_0x5a9fae['hasChild'](_0x25c8bc)){const _0x1956f0=_0x5a9fae['getImmediateChild'](_0x25c8bc);_0x1956f0['equals'](_0x3cdd90)||_0x2ac97f['trackChildChange'](xt(_0x25c8bc,_0x3cdd90,_0x1956f0));}else _0x2ac97f['trackChildChange'](rt(_0x25c8bc,_0x3cdd90));})),_0x4721b9['withIndex'](this['index_']);}['updatePriority'](_0x546bbf,_0x1e8237){return _0x546bbf['isEmpty']()?g['EMPTY_NODE']:_0x546bbf['updatePriority'](_0x1e8237);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x17f8d0){this['indexedFilter_']=new Xi(_0x17f8d0['getIndex']()),this['index_']=_0x17f8d0['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x17f8d0),this['endPost_']=Ft['getEndPost_'](_0x17f8d0),this['startIsInclusive_']=!_0x17f8d0['startAfterSet_'],this['endIsInclusive_']=!_0x17f8d0['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x46fee8){const _0x449533=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x46fee8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x46fee8)<0x0,_0x1761ae=this['endIsInclusive_']?this['index_']['compare'](_0x46fee8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x46fee8,this['getEndPost']())<0x0;return _0x449533&&_0x1761ae;}['updateChild'](_0x19f82a,_0x1ce358,_0x57afd6,_0x3f51fb,_0x23db8a,_0x4a1637){return this['matches'](new E(_0x1ce358,_0x57afd6))||(_0x57afd6=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x19f82a,_0x1ce358,_0x57afd6,_0x3f51fb,_0x23db8a,_0x4a1637);}['updateFullNode'](_0x1de247,_0x4ed39f,_0x5dec81){_0x4ed39f['isLeafNode']()&&(_0x4ed39f=g['EMPTY_NODE']);let _0x349101=_0x4ed39f['withIndex'](this['index_']);_0x349101=_0x349101['updatePriority'](g['EMPTY_NODE']);const _0x43072a=this;return _0x4ed39f['forEachChild'](R,(_0x174832,_0x1c0571)=>{_0x43072a['matches'](new E(_0x174832,_0x1c0571))||(_0x349101=_0x349101['updateImmediateChild'](_0x174832,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1de247,_0x349101,_0x5dec81);}['updatePriority'](_0x491848,_0x586f0b){return _0x491848;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2fcc46){if(_0x2fcc46['hasStart']()){const _0x5bf1ba=_0x2fcc46['getIndexStartName']();return _0x2fcc46['getIndex']()['makePost'](_0x2fcc46['getIndexStartValue'](),_0x5bf1ba);}else return _0x2fcc46['getIndex']()['minPost']();}static['getEndPost_'](_0x1c773c){if(_0x1c773c['hasEnd']()){const _0x283285=_0x1c773c['getIndexEndName']();return _0x1c773c['getIndex']()['makePost'](_0x1c773c['getIndexEndValue'](),_0x283285);}else return _0x1c773c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x53bf75){this['withinDirectionalStart']=_0x435bad=>this['reverse_']?this['withinEndPost'](_0x435bad):this['withinStartPost'](_0x435bad),this['withinDirectionalEnd']=_0x3faf45=>this['reverse_']?this['withinStartPost'](_0x3faf45):this['withinEndPost'](_0x3faf45),this['withinStartPost']=_0x429701=>{const _0x407400=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x429701);return this['startIsInclusive_']?_0x407400<=0x0:_0x407400<0x0;},this['withinEndPost']=_0x16722b=>{const _0xb6e6b6=this['index_']['compare'](_0x16722b,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xb6e6b6<=0x0:_0xb6e6b6<0x0;},this['rangedFilter_']=new Ft(_0x53bf75),this['index_']=_0x53bf75['getIndex'](),this['limit_']=_0x53bf75['getLimit'](),this['reverse_']=!_0x53bf75['isViewFromLeft'](),this['startIsInclusive_']=!_0x53bf75['startAfterSet_'],this['endIsInclusive_']=!_0x53bf75['endBeforeSet_'];}['updateChild'](_0x283d18,_0x25e046,_0x3acc54,_0xd22be7,_0x9bce53,_0x1e86d8){return this['rangedFilter_']['matches'](new E(_0x25e046,_0x3acc54))||(_0x3acc54=g['EMPTY_NODE']),_0x283d18['getImmediateChild'](_0x25e046)['equals'](_0x3acc54)?_0x283d18:_0x283d18['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x283d18,_0x25e046,_0x3acc54,_0xd22be7,_0x9bce53,_0x1e86d8):this['fullLimitUpdateChild_'](_0x283d18,_0x25e046,_0x3acc54,_0x9bce53,_0x1e86d8);}['updateFullNode'](_0x58500b,_0x295a37,_0x5bc3e7){let _0x22d44b;if(_0x295a37['isLeafNode']()||_0x295a37['isEmpty']())_0x22d44b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x295a37['numChildren']()&&_0x295a37['isIndexed'](this['index_'])){_0x22d44b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x23c863;this['reverse_']?_0x23c863=_0x295a37['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x23c863=_0x295a37['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x521a10=0x0;for(;_0x23c863['hasNext']()&&_0x521a10<this['limit_'];){const _0xfb1309=_0x23c863['getNext']();if(this['withinDirectionalStart'](_0xfb1309)){if(this['withinDirectionalEnd'](_0xfb1309))_0x22d44b=_0x22d44b['updateImmediateChild'](_0xfb1309['name'],_0xfb1309['node']),_0x521a10++;else break;}else continue;}}else{_0x22d44b=_0x295a37['withIndex'](this['index_']),_0x22d44b=_0x22d44b['updatePriority'](g['EMPTY_NODE']);let _0xf36270;this['reverse_']?_0xf36270=_0x22d44b['getReverseIterator'](this['index_']):_0xf36270=_0x22d44b['getIterator'](this['index_']);let _0x15468b=0x0;for(;_0xf36270['hasNext']();){const _0x2515d9=_0xf36270['getNext']();_0x15468b<this['limit_']&&this['withinDirectionalStart'](_0x2515d9)&&this['withinDirectionalEnd'](_0x2515d9)?_0x15468b++:_0x22d44b=_0x22d44b['updateImmediateChild'](_0x2515d9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x58500b,_0x22d44b,_0x5bc3e7);}['updatePriority'](_0x475a4d,_0x22cb2f){return _0x475a4d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x14887c,_0x54a895,_0x4367c5,_0x41e187,_0xaae12f){let _0x4db8ef;if(this['reverse_']){const _0x5deee2=this['index_']['getCompare']();_0x4db8ef=(_0x1efcc2,_0x57e1dd)=>_0x5deee2(_0x57e1dd,_0x1efcc2);}else _0x4db8ef=this['index_']['getCompare']();const _0x587456=_0x14887c;f(_0x587456['numChildren']()===this['limit_'],'');const _0x31029c=new E(_0x54a895,_0x4367c5),_0xb582db=this['reverse_']?_0x587456['getFirstChild'](this['index_']):_0x587456['getLastChild'](this['index_']),_0x3b2cd6=this['rangedFilter_']['matches'](_0x31029c);if(_0x587456['hasChild'](_0x54a895)){const _0x475a33=_0x587456['getImmediateChild'](_0x54a895);let _0x587cf5=_0x41e187['getChildAfterChild'](this['index_'],_0xb582db,this['reverse_']);for(;_0x587cf5!=null&&(_0x587cf5['name']===_0x54a895||_0x587456['hasChild'](_0x587cf5['name']));)_0x587cf5=_0x41e187['getChildAfterChild'](this['index_'],_0x587cf5,this['reverse_']);const _0x4a6971=_0x587cf5==null?0x1:_0x4db8ef(_0x587cf5,_0x31029c);if(_0x3b2cd6&&!_0x4367c5['isEmpty']()&&_0x4a6971>=0x0)return _0xaae12f!=null&&_0xaae12f['trackChildChange'](xt(_0x54a895,_0x4367c5,_0x475a33)),_0x587456['updateImmediateChild'](_0x54a895,_0x4367c5);{_0xaae12f!=null&&_0xaae12f['trackChildChange'](Lt(_0x54a895,_0x475a33));const _0x332b09=_0x587456['updateImmediateChild'](_0x54a895,g['EMPTY_NODE']);return _0x587cf5!=null&&this['rangedFilter_']['matches'](_0x587cf5)?(_0xaae12f!=null&&_0xaae12f['trackChildChange'](rt(_0x587cf5['name'],_0x587cf5['node'])),_0x332b09['updateImmediateChild'](_0x587cf5['name'],_0x587cf5['node'])):_0x332b09;}}else return _0x4367c5['isEmpty']()?_0x14887c:_0x3b2cd6&&_0x4db8ef(_0xb582db,_0x31029c)>=0x0?(_0xaae12f!=null&&(_0xaae12f['trackChildChange'](Lt(_0xb582db['name'],_0xb582db['node'])),_0xaae12f['trackChildChange'](rt(_0x54a895,_0x4367c5))),_0x587456['updateImmediateChild'](_0x54a895,_0x4367c5)['updateImmediateChild'](_0xb582db['name'],g['EMPTY_NODE'])):_0x14887c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3449f7=new Zi();return _0x3449f7['limitSet_']=this['limitSet_'],_0x3449f7['limit_']=this['limit_'],_0x3449f7['startSet_']=this['startSet_'],_0x3449f7['startAfterSet_']=this['startAfterSet_'],_0x3449f7['indexStartValue_']=this['indexStartValue_'],_0x3449f7['startNameSet_']=this['startNameSet_'],_0x3449f7['indexStartName_']=this['indexStartName_'],_0x3449f7['endSet_']=this['endSet_'],_0x3449f7['endBeforeSet_']=this['endBeforeSet_'],_0x3449f7['indexEndValue_']=this['indexEndValue_'],_0x3449f7['endNameSet_']=this['endNameSet_'],_0x3449f7['indexEndName_']=this['indexEndName_'],_0x3449f7['index_']=this['index_'],_0x3449f7['viewFrom_']=this['viewFrom_'],_0x3449f7;}}function Kh(_0x423a83){return _0x423a83['loadsAllData']()?new Xi(_0x423a83['getIndex']()):_0x423a83['hasLimit']()?new jh(_0x423a83):new Ft(_0x423a83);}function Yh(_0x10d9c0,_0x301afe){const _0x179d72=_0x10d9c0['copy']();return _0x179d72['limitSet_']=!0x0,_0x179d72['limit_']=_0x301afe,_0x179d72['viewFrom_']='l',_0x179d72;}function Qh(_0x293f28,_0x3ed782,_0x24b2e5){const _0x5ef594=_0x293f28['copy']();return _0x5ef594['startSet_']=!0x0,_0x3ed782===void 0x0&&(_0x3ed782=null),_0x5ef594['indexStartValue_']=_0x3ed782,_0x24b2e5!=null?(_0x5ef594['startNameSet_']=!0x0,_0x5ef594['indexStartName_']=_0x24b2e5):(_0x5ef594['startNameSet_']=!0x1,_0x5ef594['indexStartName_']=''),_0x5ef594;}function Jh(_0xb14f70,_0x2387ed,_0x46d5df){const _0x22b14a=_0xb14f70['copy']();return _0x22b14a['endSet_']=!0x0,_0x2387ed===void 0x0&&(_0x2387ed=null),_0x22b14a['indexEndValue_']=_0x2387ed,_0x46d5df!==void 0x0?(_0x22b14a['endNameSet_']=!0x0,_0x22b14a['indexEndName_']=_0x46d5df):(_0x22b14a['endNameSet_']=!0x1,_0x22b14a['indexEndName_']=''),_0x22b14a;}function xo(_0x336714,_0x30031b){const _0x44b5ce=_0x336714['copy']();return _0x44b5ce['index_']=_0x30031b,_0x44b5ce;}function ir(_0x1233ff){const _0x5b260f={};if(_0x1233ff['isDefault']())return _0x5b260f;let _0x4a90a2;if(_0x1233ff['index_']===R?_0x4a90a2='$priority':_0x1233ff['index_']===Mo?_0x4a90a2='$value':_0x1233ff['index_']===ve?_0x4a90a2='$key':(f(_0x1233ff['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4a90a2=_0x1233ff['index_']['toString']()),_0x5b260f['orderBy']=O(_0x4a90a2),_0x1233ff['startSet_']){const _0x123117=_0x1233ff['startAfterSet_']?'startAfter':'startAt';_0x5b260f[_0x123117]=O(_0x1233ff['indexStartValue_']),_0x1233ff['startNameSet_']&&(_0x5b260f[_0x123117]+=','+O(_0x1233ff['indexStartName_']));}if(_0x1233ff['endSet_']){const _0x428913=_0x1233ff['endBeforeSet_']?'endBefore':'endAt';_0x5b260f[_0x428913]=O(_0x1233ff['indexEndValue_']),_0x1233ff['endNameSet_']&&(_0x5b260f[_0x428913]+=','+O(_0x1233ff['indexEndName_']));}return _0x1233ff['limitSet_']&&(_0x1233ff['isViewFromLeft']()?_0x5b260f['limitToFirst']=_0x1233ff['limit_']:_0x5b260f['limitToLast']=_0x1233ff['limit_']),_0x5b260f;}function sr(_0x885079){const _0x43fc3d={};if(_0x885079['startSet_']&&(_0x43fc3d['sp']=_0x885079['indexStartValue_'],_0x885079['startNameSet_']&&(_0x43fc3d['sn']=_0x885079['indexStartName_']),_0x43fc3d['sin']=!_0x885079['startAfterSet_']),_0x885079['endSet_']&&(_0x43fc3d['ep']=_0x885079['indexEndValue_'],_0x885079['endNameSet_']&&(_0x43fc3d['en']=_0x885079['indexEndName_']),_0x43fc3d['ein']=!_0x885079['endBeforeSet_']),_0x885079['limitSet_']){_0x43fc3d['l']=_0x885079['limit_'];let _0x548875=_0x885079['viewFrom_'];_0x548875===''&&(_0x885079['isViewFromLeft']()?_0x548875='l':_0x548875='r'),_0x43fc3d['vf']=_0x548875;}return _0x885079['index_']!==R&&(_0x43fc3d['i']=_0x885079['index_']['toString']()),_0x43fc3d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2c7b6c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5d32df,_0x298da7){return _0x298da7!==void 0x0?'tag$'+_0x298da7:(f(_0x5d32df['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5d32df['_path']['toString']());}constructor(_0x5e970f,_0x22bea2,_0x17455f,_0x2d1315){super(),this['repoInfo_']=_0x5e970f,this['onDataUpdate_']=_0x22bea2,this['authTokenProvider_']=_0x17455f,this['appCheckTokenProvider_']=_0x2d1315,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x36fa5b,_0x3dd38f,_0xb374f9,_0x22fe4b){const _0xe38ae8=_0x36fa5b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xe38ae8+'\x20'+_0x36fa5b['_queryIdentifier']);const _0x3312cb=vn['getListenId_'](_0x36fa5b,_0xb374f9),_0x2e2aaa={};this['listens_'][_0x3312cb]=_0x2e2aaa;const _0x237686=ir(_0x36fa5b['_queryParams']);this['restRequest_'](_0xe38ae8+'.json',_0x237686,(_0xc4ee,_0x42cc18)=>{let _0x16ca63=_0x42cc18;if(_0xc4ee===0x194&&(_0x16ca63=null,_0xc4ee=null),_0xc4ee===null&&this['onDataUpdate_'](_0xe38ae8,_0x16ca63,!0x1,_0xb374f9),Le(this['listens_'],_0x3312cb)===_0x2e2aaa){let _0x291249;_0xc4ee?_0xc4ee===0x191?_0x291249='permission_denied':_0x291249='rest_error:'+_0xc4ee:_0x291249='ok',_0x22fe4b(_0x291249,null);}});}['unlisten'](_0x4be059,_0x1a5332){const _0x341ed2=vn['getListenId_'](_0x4be059,_0x1a5332);delete this['listens_'][_0x341ed2];}['get'](_0x1c2ea2){const _0xa6bf16=ir(_0x1c2ea2['_queryParams']),_0x329d7e=_0x1c2ea2['_path']['toString'](),_0x45b408=new H();return this['restRequest_'](_0x329d7e+'.json',_0xa6bf16,(_0x10cd4b,_0x4bf72a)=>{let _0x1aa49f=_0x4bf72a;_0x10cd4b===0x194&&(_0x1aa49f=null,_0x10cd4b=null),_0x10cd4b===null?(this['onDataUpdate_'](_0x329d7e,_0x1aa49f,!0x1,null),_0x45b408['resolve'](_0x1aa49f)):_0x45b408['reject'](new Error(_0x1aa49f));}),_0x45b408['promise'];}['refreshAuthToken'](_0x44b181){}['restRequest_'](_0x57c991,_0x2eac90={},_0x45480a){return _0x2eac90['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x59db05,_0x5e1405])=>{_0x59db05&&_0x59db05['accessToken']&&(_0x2eac90['auth']=_0x59db05['accessToken']),_0x5e1405&&_0x5e1405['token']&&(_0x2eac90['ac']=_0x5e1405['token']);const _0x50b635=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x57c991+'?ns='+this['repoInfo_']['namespace']+ut(_0x2eac90);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x50b635);const _0x171a05=new XMLHttpRequest();_0x171a05['onreadystatechange']=()=>{if(_0x45480a&&_0x171a05['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x50b635+'\x20received.\x20status:',_0x171a05['status'],'response:',_0x171a05['responseText']);let _0xf6d711=null;if(_0x171a05['status']>=0xc8&&_0x171a05['status']<0x12c){try{_0xf6d711=Nt(_0x171a05['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x50b635+':\x20'+_0x171a05['responseText']);}_0x45480a(null,_0xf6d711);}else _0x171a05['status']!==0x191&&_0x171a05['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x50b635+'\x20Status:\x20'+_0x171a05['status']),_0x45480a(_0x171a05['status']);_0x45480a=null;}},_0x171a05['open']('GET',_0x50b635,!0x0),_0x171a05['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x34a80c){return this['rootNode_']['getChild'](_0x34a80c);}['updateSnapshot'](_0x315c0e,_0x1f127a){this['rootNode_']=this['rootNode_']['updateChild'](_0x315c0e,_0x1f127a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x34dd92,_0x5ab843,_0x533efc){if(v(_0x5ab843))_0x34dd92['value']=_0x533efc,_0x34dd92['children']['clear']();else{if(_0x34dd92['value']!==null)_0x34dd92['value']=_0x34dd92['value']['updateChild'](_0x5ab843,_0x533efc);else{const _0x5364cd=y(_0x5ab843);_0x34dd92['children']['has'](_0x5364cd)||_0x34dd92['children']['set'](_0x5364cd,En());const _0x762331=_0x34dd92['children']['get'](_0x5364cd);_0x5ab843=S(_0x5ab843),pt(_0x762331,_0x5ab843,_0x533efc);}}}function Ti(_0x71afb6,_0x18b729){if(v(_0x18b729))return _0x71afb6['value']=null,_0x71afb6['children']['clear'](),!0x0;if(_0x71afb6['value']!==null){if(_0x71afb6['value']['isLeafNode']())return!0x1;{const _0x677d39=_0x71afb6['value'];return _0x71afb6['value']=null,_0x677d39['forEachChild'](R,(_0x492158,_0x28ecd6)=>{pt(_0x71afb6,new C(_0x492158),_0x28ecd6);}),Ti(_0x71afb6,_0x18b729);}}else{if(_0x71afb6['children']['size']>0x0){const _0x15bf10=y(_0x18b729);return _0x18b729=S(_0x18b729),_0x71afb6['children']['has'](_0x15bf10)&&Ti(_0x71afb6['children']['get'](_0x15bf10),_0x18b729)&&_0x71afb6['children']['delete'](_0x15bf10),_0x71afb6['children']['size']===0x0;}else return!0x0;}}function Si(_0x2142ad,_0xcacdc,_0x23b00b){_0x2142ad['value']!==null?_0x23b00b(_0xcacdc,_0x2142ad['value']):Zh(_0x2142ad,(_0x1feb5f,_0x4e17ff)=>{const _0x3bd372=new C(_0xcacdc['toString']()+'/'+_0x1feb5f);Si(_0x4e17ff,_0x3bd372,_0x23b00b);});}function Zh(_0x2c91f1,_0x39d57b){_0x2c91f1['children']['forEach']((_0xea4ac5,_0x35c889)=>{_0x39d57b(_0x35c889,_0xea4ac5);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1aa8a0){this['collection_']=_0x1aa8a0,this['last_']=null;}['get'](){const _0x46ab4c=this['collection_']['get'](),_0x341529={..._0x46ab4c};return this['last_']&&x(this['last_'],(_0x3ff47a,_0x1d0460)=>{_0x341529[_0x3ff47a]=_0x341529[_0x3ff47a]-_0x1d0460;}),this['last_']=_0x46ab4c,_0x341529;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x38afbd,_0x1ab828){this['server_']=_0x1ab828,this['statsToReport_']={},this['statsListener_']=new eu(_0x38afbd);const _0x1a2d5f=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1a2d5f));}['reportStats_'](){const _0x40832a=this['statsListener_']['get'](),_0x2e82be={};let _0x5b9dc5=!0x1;x(_0x40832a,(_0x240c72,_0x149671)=>{_0x149671>0x0&&Q(this['statsToReport_'],_0x240c72)&&(_0x2e82be[_0x240c72]=_0x149671,_0x5b9dc5=!0x0);}),_0x5b9dc5&&this['server_']['reportStats'](_0x2e82be),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4ed7c4){_0x4ed7c4[_0x4ed7c4['OVERWRITE']=0x0]='OVERWRITE',_0x4ed7c4[_0x4ed7c4['MERGE']=0x1]='MERGE',_0x4ed7c4[_0x4ed7c4['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4ed7c4[_0x4ed7c4['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x53d47d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x53d47d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xc013ff,_0x1221d5,_0x59ff5b){this['path']=_0xc013ff,this['affectedTree']=_0x1221d5,this['revert']=_0x59ff5b,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x129b28){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x54258f=this['affectedTree']['subtree'](new C(_0x129b28));return new In(w(),_0x54258f,this['revert']);}}else return f(y(this['path'])===_0x129b28,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x1a2915,_0x1bdd5c){this['source']=_0x1a2915,this['path']=_0x1bdd5c,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4e33b2){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xd714c5,_0x23f647,_0x494a4e){this['source']=_0xd714c5,this['path']=_0x23f647,this['snap']=_0x494a4e,this['type']=z['OVERWRITE'];}['operationForChild'](_0x137dcc){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x137dcc)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x23800b,_0x11d9c3,_0x35bf2c){this['source']=_0x23800b,this['path']=_0x11d9c3,this['children']=_0x35bf2c,this['type']=z['MERGE'];}['operationForChild'](_0x4b2dcc){if(v(this['path'])){const _0x321c35=this['children']['subtree'](new C(_0x4b2dcc));return _0x321c35['isEmpty']()?null:_0x321c35['value']?new Be(this['source'],w(),_0x321c35['value']):new ot(this['source'],w(),_0x321c35);}else return f(y(this['path'])===_0x4b2dcc,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0xf15191,_0x4e28f8,_0x3aa17c){this['node_']=_0xf15191,this['fullyInitialized_']=_0x4e28f8,this['filtered_']=_0x3aa17c;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x31297a){if(v(_0x31297a))return this['isFullyInitialized']()&&!this['filtered_'];const _0x34cdf9=y(_0x31297a);return this['isCompleteForChild'](_0x34cdf9);}['isCompleteForChild'](_0x56bfe9){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x56bfe9);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1eb89a){this['query_']=_0x1eb89a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x39270b,_0x4e2b9,_0x554856,_0x427cf6){const _0x16bab7=[],_0x361c11=[];return _0x4e2b9['forEach'](_0x5ab488=>{_0x5ab488['type']==='child_changed'&&_0x39270b['index_']['indexedValueChanged'](_0x5ab488['oldSnap'],_0x5ab488['snapshotNode'])&&_0x361c11['push'](zh(_0x5ab488['childName'],_0x5ab488['snapshotNode']));}),wt(_0x39270b,_0x16bab7,'child_removed',_0x4e2b9,_0x427cf6,_0x554856),wt(_0x39270b,_0x16bab7,'child_added',_0x4e2b9,_0x427cf6,_0x554856),wt(_0x39270b,_0x16bab7,'child_moved',_0x361c11,_0x427cf6,_0x554856),wt(_0x39270b,_0x16bab7,'child_changed',_0x4e2b9,_0x427cf6,_0x554856),wt(_0x39270b,_0x16bab7,'value',_0x4e2b9,_0x427cf6,_0x554856),_0x16bab7;}function wt(_0x35ab1a,_0x3407b8,_0x5c6275,_0x3c41aa,_0x1256b6,_0x19803f){const _0x25410b=_0x3c41aa['filter'](_0x4fbe57=>_0x4fbe57['type']===_0x5c6275);_0x25410b['sort']((_0x296cf4,_0x8e38ae)=>au(_0x35ab1a,_0x296cf4,_0x8e38ae)),_0x25410b['forEach'](_0x3801ad=>{const _0x52eb95=ou(_0x35ab1a,_0x3801ad,_0x19803f);_0x1256b6['forEach'](_0xc36e79=>{_0xc36e79['respondsTo'](_0x3801ad['type'])&&_0x3407b8['push'](_0xc36e79['createEvent'](_0x52eb95,_0x35ab1a['query_']));});});}function ou(_0x2ad81a,_0x36a5ec,_0x3294c1){return _0x36a5ec['type']==='value'||_0x36a5ec['type']==='child_removed'||(_0x36a5ec['prevName']=_0x3294c1['getPredecessorChildName'](_0x36a5ec['childName'],_0x36a5ec['snapshotNode'],_0x2ad81a['index_'])),_0x36a5ec;}function au(_0x211cdf,_0x47e221,_0x218e1b){if(_0x47e221['childName']==null||_0x218e1b['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1fa353=new E(_0x47e221['childName'],_0x47e221['snapshotNode']),_0xcf14c0=new E(_0x218e1b['childName'],_0x218e1b['snapshotNode']);return _0x211cdf['index_']['compare'](_0x1fa353,_0xcf14c0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x59b807,_0x2bb8a1){return{'eventCache':_0x59b807,'serverCache':_0x2bb8a1};}function Rt(_0x1d7a2b,_0x4c55a0,_0x5c492c,_0x1b7fa5){return Un(new Te(_0x4c55a0,_0x5c492c,_0x1b7fa5),_0x1d7a2b['serverCache']);}function Fo(_0x1c4f8f,_0x590d1f,_0x24d350,_0x24c348){return Un(_0x1c4f8f['eventCache'],new Te(_0x590d1f,_0x24d350,_0x24c348));}function wn(_0x1da5b4){return _0x1da5b4['eventCache']['isFullyInitialized']()?_0x1da5b4['eventCache']['getNode']():null;}function Ve(_0x259dbd){return _0x259dbd['serverCache']['isFullyInitialized']()?_0x259dbd['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x33e978){let _0xcff83=new b(null);return x(_0x33e978,(_0x473f0e,_0x1aaace)=>{_0xcff83=_0xcff83['set'](new C(_0x473f0e),_0x1aaace);}),_0xcff83;}constructor(_0x29f959,_0x2e9497=cu()){this['value']=_0x29f959,this['children']=_0x2e9497;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5a13ef,_0x5c2ff4){if(this['value']!=null&&_0x5c2ff4(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5a13ef))return null;{const _0x150abd=y(_0x5a13ef),_0x134afe=this['children']['get'](_0x150abd);if(_0x134afe!==null){const _0x42af51=_0x134afe['findRootMostMatchingPathAndValue'](S(_0x5a13ef),_0x5c2ff4);return _0x42af51!=null?{'path':k(new C(_0x150abd),_0x42af51['path']),'value':_0x42af51['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x29b97a){return this['findRootMostMatchingPathAndValue'](_0x29b97a,()=>!0x0);}['subtree'](_0x5a6cde){if(v(_0x5a6cde))return this;{const _0x11b5c4=y(_0x5a6cde),_0x39c3d2=this['children']['get'](_0x11b5c4);return _0x39c3d2!==null?_0x39c3d2['subtree'](S(_0x5a6cde)):new b(null);}}['set'](_0x4cc466,_0x25ea5f){if(v(_0x4cc466))return new b(_0x25ea5f,this['children']);{const _0x2a66b5=y(_0x4cc466),_0x89f132=(this['children']['get'](_0x2a66b5)||new b(null))['set'](S(_0x4cc466),_0x25ea5f),_0x3b16b9=this['children']['insert'](_0x2a66b5,_0x89f132);return new b(this['value'],_0x3b16b9);}}['remove'](_0x29185e){if(v(_0x29185e))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x52cb40=y(_0x29185e),_0x313127=this['children']['get'](_0x52cb40);if(_0x313127){const _0x172e0d=_0x313127['remove'](S(_0x29185e));let _0x55eba8;return _0x172e0d['isEmpty']()?_0x55eba8=this['children']['remove'](_0x52cb40):_0x55eba8=this['children']['insert'](_0x52cb40,_0x172e0d),this['value']===null&&_0x55eba8['isEmpty']()?new b(null):new b(this['value'],_0x55eba8);}else return this;}}['get'](_0x2f891a){if(v(_0x2f891a))return this['value'];{const _0x2c15b9=y(_0x2f891a),_0x31e222=this['children']['get'](_0x2c15b9);return _0x31e222?_0x31e222['get'](S(_0x2f891a)):null;}}['setTree'](_0x5d8778,_0x2ee28e){if(v(_0x5d8778))return _0x2ee28e;{const _0x44d4ac=y(_0x5d8778),_0x2281e2=(this['children']['get'](_0x44d4ac)||new b(null))['setTree'](S(_0x5d8778),_0x2ee28e);let _0x58f84f;return _0x2281e2['isEmpty']()?_0x58f84f=this['children']['remove'](_0x44d4ac):_0x58f84f=this['children']['insert'](_0x44d4ac,_0x2281e2),new b(this['value'],_0x58f84f);}}['fold'](_0x2780a5){return this['fold_'](w(),_0x2780a5);}['fold_'](_0x46486b,_0x5a37c4){const _0xb11e2={};return this['children']['inorderTraversal']((_0xb5f8c2,_0x57ca24)=>{_0xb11e2[_0xb5f8c2]=_0x57ca24['fold_'](k(_0x46486b,_0xb5f8c2),_0x5a37c4);}),_0x5a37c4(_0x46486b,this['value'],_0xb11e2);}['findOnPath'](_0x4c628f,_0x36f0ff){return this['findOnPath_'](_0x4c628f,w(),_0x36f0ff);}['findOnPath_'](_0xcfc5ad,_0x410323,_0x8367e8){const _0x122a16=this['value']?_0x8367e8(_0x410323,this['value']):!0x1;if(_0x122a16)return _0x122a16;if(v(_0xcfc5ad))return null;{const _0x107b31=y(_0xcfc5ad),_0x51badf=this['children']['get'](_0x107b31);return _0x51badf?_0x51badf['findOnPath_'](S(_0xcfc5ad),k(_0x410323,_0x107b31),_0x8367e8):null;}}['foreachOnPath'](_0xf2a156,_0x53ff4d){return this['foreachOnPath_'](_0xf2a156,w(),_0x53ff4d);}['foreachOnPath_'](_0x476585,_0x3ae2c8,_0x3376cd){if(v(_0x476585))return this;{this['value']&&_0x3376cd(_0x3ae2c8,this['value']);const _0x586ca7=y(_0x476585),_0x13ca2b=this['children']['get'](_0x586ca7);return _0x13ca2b?_0x13ca2b['foreachOnPath_'](S(_0x476585),k(_0x3ae2c8,_0x586ca7),_0x3376cd):new b(null);}}['foreach'](_0x12608c){this['foreach_'](w(),_0x12608c);}['foreach_'](_0x3843aa,_0x4e844e){this['children']['inorderTraversal']((_0x17e461,_0x4cf149)=>{_0x4cf149['foreach_'](k(_0x3843aa,_0x17e461),_0x4e844e);}),this['value']&&_0x4e844e(_0x3843aa,this['value']);}['foreachChild'](_0x3ae806){this['children']['inorderTraversal']((_0x4e25a5,_0x7ddff2)=>{_0x7ddff2['value']&&_0x3ae806(_0x4e25a5,_0x7ddff2['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x26c9db){this['writeTree_']=_0x26c9db;}static['empty'](){return new K(new b(null));}}function At(_0xfa591,_0x1a5e23,_0x527b5a){if(v(_0x1a5e23))return new K(new b(_0x527b5a));{const _0x4f00db=_0xfa591['writeTree_']['findRootMostValueAndPath'](_0x1a5e23);if(_0x4f00db!=null){const _0x653667=_0x4f00db['path'];let _0x30fc81=_0x4f00db['value'];const _0x4f2a54=F(_0x653667,_0x1a5e23);return _0x30fc81=_0x30fc81['updateChild'](_0x4f2a54,_0x527b5a),new K(_0xfa591['writeTree_']['set'](_0x653667,_0x30fc81));}else{const _0xed3bc4=new b(_0x527b5a),_0x337b42=_0xfa591['writeTree_']['setTree'](_0x1a5e23,_0xed3bc4);return new K(_0x337b42);}}}function bi(_0x5cdb92,_0x6945aa,_0x3ead01){let _0x251c94=_0x5cdb92;return x(_0x3ead01,(_0x596db4,_0x17f340)=>{_0x251c94=At(_0x251c94,k(_0x6945aa,_0x596db4),_0x17f340);}),_0x251c94;}function or(_0x2803d7,_0x3f03c8){if(v(_0x3f03c8))return K['empty']();{const _0x417216=_0x2803d7['writeTree_']['setTree'](_0x3f03c8,new b(null));return new K(_0x417216);}}function Ri(_0x34d9de,_0x52ffb3){return ze(_0x34d9de,_0x52ffb3)!=null;}function ze(_0x86b3aa,_0x36be28){const _0x20d73d=_0x86b3aa['writeTree_']['findRootMostValueAndPath'](_0x36be28);return _0x20d73d!=null?_0x86b3aa['writeTree_']['get'](_0x20d73d['path'])['getChild'](F(_0x20d73d['path'],_0x36be28)):null;}function ar(_0x2dcd00){const _0x5f039b=[],_0x4a588a=_0x2dcd00['writeTree_']['value'];return _0x4a588a!=null?_0x4a588a['isLeafNode']()||_0x4a588a['forEachChild'](R,(_0x4dec0f,_0x571efe)=>{_0x5f039b['push'](new E(_0x4dec0f,_0x571efe));}):_0x2dcd00['writeTree_']['children']['inorderTraversal']((_0x16db0,_0x141f2a)=>{_0x141f2a['value']!=null&&_0x5f039b['push'](new E(_0x16db0,_0x141f2a['value']));}),_0x5f039b;}function Ee(_0x1c0b0c,_0x22946d){if(v(_0x22946d))return _0x1c0b0c;{const _0x42ea9a=ze(_0x1c0b0c,_0x22946d);return _0x42ea9a!=null?new K(new b(_0x42ea9a)):new K(_0x1c0b0c['writeTree_']['subtree'](_0x22946d));}}function Ai(_0x5c063d){return _0x5c063d['writeTree_']['isEmpty']();}function at(_0x3258c0,_0x4fb9ba){return Uo(w(),_0x3258c0['writeTree_'],_0x4fb9ba);}function Uo(_0x140a6e,_0x2a4f73,_0x68c5ac){if(_0x2a4f73['value']!=null)return _0x68c5ac['updateChild'](_0x140a6e,_0x2a4f73['value']);{let _0x3a794=null;return _0x2a4f73['children']['inorderTraversal']((_0x3c8aeb,_0x34d312)=>{_0x3c8aeb==='.priority'?(f(_0x34d312['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3a794=_0x34d312['value']):_0x68c5ac=Uo(k(_0x140a6e,_0x3c8aeb),_0x34d312,_0x68c5ac);}),!_0x68c5ac['getChild'](_0x140a6e)['isEmpty']()&&_0x3a794!==null&&(_0x68c5ac=_0x68c5ac['updateChild'](k(_0x140a6e,'.priority'),_0x3a794)),_0x68c5ac;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x29be57,_0x446ab8){return Ho(_0x446ab8,_0x29be57);}function lu(_0x289ea0,_0x309f71,_0x55b647,_0x55f7ce,_0x59b088){f(_0x55f7ce>_0x289ea0['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x59b088===void 0x0&&(_0x59b088=!0x0),_0x289ea0['allWrites']['push']({'path':_0x309f71,'snap':_0x55b647,'writeId':_0x55f7ce,'visible':_0x59b088}),_0x59b088&&(_0x289ea0['visibleWrites']=At(_0x289ea0['visibleWrites'],_0x309f71,_0x55b647)),_0x289ea0['lastWriteId']=_0x55f7ce;}function hu(_0x5c54b9,_0x2a70e1,_0x144747,_0x11128c){f(_0x11128c>_0x5c54b9['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5c54b9['allWrites']['push']({'path':_0x2a70e1,'children':_0x144747,'writeId':_0x11128c,'visible':!0x0}),_0x5c54b9['visibleWrites']=bi(_0x5c54b9['visibleWrites'],_0x2a70e1,_0x144747),_0x5c54b9['lastWriteId']=_0x11128c;}function uu(_0x1896fc,_0x24956f){for(let _0x121fd5=0x0;_0x121fd5<_0x1896fc['allWrites']['length'];_0x121fd5++){const _0x5ec2b9=_0x1896fc['allWrites'][_0x121fd5];if(_0x5ec2b9['writeId']===_0x24956f)return _0x5ec2b9;}return null;}function du(_0xda6fc3,_0x51ccb8){const _0xa955fd=_0xda6fc3['allWrites']['findIndex'](_0xdbefb6=>_0xdbefb6['writeId']===_0x51ccb8);f(_0xa955fd>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x74138b=_0xda6fc3['allWrites'][_0xa955fd];_0xda6fc3['allWrites']['splice'](_0xa955fd,0x1);let _0xf32813=_0x74138b['visible'],_0xbd560e=!0x1,_0x5a1565=_0xda6fc3['allWrites']['length']-0x1;for(;_0xf32813&&_0x5a1565>=0x0;){const _0x3bd2cc=_0xda6fc3['allWrites'][_0x5a1565];_0x3bd2cc['visible']&&(_0x5a1565>=_0xa955fd&&fu(_0x3bd2cc,_0x74138b['path'])?_0xf32813=!0x1:G(_0x74138b['path'],_0x3bd2cc['path'])&&(_0xbd560e=!0x0)),_0x5a1565--;}if(_0xf32813){if(_0xbd560e)return pu(_0xda6fc3),!0x0;if(_0x74138b['snap'])_0xda6fc3['visibleWrites']=or(_0xda6fc3['visibleWrites'],_0x74138b['path']);else{const _0x2d3009=_0x74138b['children'];x(_0x2d3009,_0x21c06b=>{_0xda6fc3['visibleWrites']=or(_0xda6fc3['visibleWrites'],k(_0x74138b['path'],_0x21c06b));});}return!0x0;}else return!0x1;}function fu(_0x2f6037,_0x20ac0f){if(_0x2f6037['snap'])return G(_0x2f6037['path'],_0x20ac0f);for(const _0x506fb0 in _0x2f6037['children'])if(_0x2f6037['children']['hasOwnProperty'](_0x506fb0)&&G(k(_0x2f6037['path'],_0x506fb0),_0x20ac0f))return!0x0;return!0x1;}function pu(_0x29a0fd){_0x29a0fd['visibleWrites']=Wo(_0x29a0fd['allWrites'],_u,w()),_0x29a0fd['allWrites']['length']>0x0?_0x29a0fd['lastWriteId']=_0x29a0fd['allWrites'][_0x29a0fd['allWrites']['length']-0x1]['writeId']:_0x29a0fd['lastWriteId']=-0x1;}function _u(_0xa0b9d6){return _0xa0b9d6['visible'];}function Wo(_0x56dc9f,_0x5af06f,_0xe858b8){let _0x4d729b=K['empty']();for(let _0x39bfcd=0x0;_0x39bfcd<_0x56dc9f['length'];++_0x39bfcd){const _0x37683d=_0x56dc9f[_0x39bfcd];if(_0x5af06f(_0x37683d)){const _0x39612a=_0x37683d['path'];let _0x15ad0f;if(_0x37683d['snap'])G(_0xe858b8,_0x39612a)?(_0x15ad0f=F(_0xe858b8,_0x39612a),_0x4d729b=At(_0x4d729b,_0x15ad0f,_0x37683d['snap'])):G(_0x39612a,_0xe858b8)&&(_0x15ad0f=F(_0x39612a,_0xe858b8),_0x4d729b=At(_0x4d729b,w(),_0x37683d['snap']['getChild'](_0x15ad0f)));else{if(_0x37683d['children']){if(G(_0xe858b8,_0x39612a))_0x15ad0f=F(_0xe858b8,_0x39612a),_0x4d729b=bi(_0x4d729b,_0x15ad0f,_0x37683d['children']);else{if(G(_0x39612a,_0xe858b8)){if(_0x15ad0f=F(_0x39612a,_0xe858b8),v(_0x15ad0f))_0x4d729b=bi(_0x4d729b,w(),_0x37683d['children']);else{const _0xd745a7=Le(_0x37683d['children'],y(_0x15ad0f));if(_0xd745a7){const _0x32c5b5=_0xd745a7['getChild'](S(_0x15ad0f));_0x4d729b=At(_0x4d729b,w(),_0x32c5b5);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4d729b;}function Bo(_0x10306c,_0x549859,_0x191dea,_0x3f72b6,_0x29649d){if(!_0x3f72b6&&!_0x29649d){const _0x55ef92=ze(_0x10306c['visibleWrites'],_0x549859);if(_0x55ef92!=null)return _0x55ef92;{const _0x545b44=Ee(_0x10306c['visibleWrites'],_0x549859);if(Ai(_0x545b44))return _0x191dea;if(_0x191dea==null&&!Ri(_0x545b44,w()))return null;{const _0x44ffa7=_0x191dea||g['EMPTY_NODE'];return at(_0x545b44,_0x44ffa7);}}}else{const _0x55e2d7=Ee(_0x10306c['visibleWrites'],_0x549859);if(!_0x29649d&&Ai(_0x55e2d7))return _0x191dea;if(!_0x29649d&&_0x191dea==null&&!Ri(_0x55e2d7,w()))return null;{const _0x2e5188=function(_0x379644){return(_0x379644['visible']||_0x29649d)&&(!_0x3f72b6||!~_0x3f72b6['indexOf'](_0x379644['writeId']))&&(G(_0x379644['path'],_0x549859)||G(_0x549859,_0x379644['path']));},_0x42c0d2=Wo(_0x10306c['allWrites'],_0x2e5188,_0x549859),_0x1f9d7e=_0x191dea||g['EMPTY_NODE'];return at(_0x42c0d2,_0x1f9d7e);}}}function gu(_0x462458,_0x324b8e,_0x3d8e21){let _0x1953f4=g['EMPTY_NODE'];const _0x41a208=ze(_0x462458['visibleWrites'],_0x324b8e);if(_0x41a208)return _0x41a208['isLeafNode']()||_0x41a208['forEachChild'](R,(_0x1b7bf0,_0x3814fc)=>{_0x1953f4=_0x1953f4['updateImmediateChild'](_0x1b7bf0,_0x3814fc);}),_0x1953f4;if(_0x3d8e21){const _0x214497=Ee(_0x462458['visibleWrites'],_0x324b8e);return _0x3d8e21['forEachChild'](R,(_0x61758e,_0x5f0492)=>{const _0x343c27=at(Ee(_0x214497,new C(_0x61758e)),_0x5f0492);_0x1953f4=_0x1953f4['updateImmediateChild'](_0x61758e,_0x343c27);}),ar(_0x214497)['forEach'](_0x285c1a=>{_0x1953f4=_0x1953f4['updateImmediateChild'](_0x285c1a['name'],_0x285c1a['node']);}),_0x1953f4;}else{const _0x43825e=Ee(_0x462458['visibleWrites'],_0x324b8e);return ar(_0x43825e)['forEach'](_0x137a2f=>{_0x1953f4=_0x1953f4['updateImmediateChild'](_0x137a2f['name'],_0x137a2f['node']);}),_0x1953f4;}}function mu(_0x4cc023,_0x2e37e8,_0x50b7f4,_0x41541f,_0x3662ae){f(_0x41541f||_0x3662ae,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x175d66=k(_0x2e37e8,_0x50b7f4);if(Ri(_0x4cc023['visibleWrites'],_0x175d66))return null;{const _0xec8ff7=Ee(_0x4cc023['visibleWrites'],_0x175d66);return Ai(_0xec8ff7)?_0x3662ae['getChild'](_0x50b7f4):at(_0xec8ff7,_0x3662ae['getChild'](_0x50b7f4));}}function yu(_0x4f53c1,_0x419b63,_0x4e818a,_0x4d5648){const _0x297263=k(_0x419b63,_0x4e818a),_0x39ba70=ze(_0x4f53c1['visibleWrites'],_0x297263);if(_0x39ba70!=null)return _0x39ba70;if(_0x4d5648['isCompleteForChild'](_0x4e818a)){const _0x27954b=Ee(_0x4f53c1['visibleWrites'],_0x297263);return at(_0x27954b,_0x4d5648['getNode']()['getImmediateChild'](_0x4e818a));}else return null;}function vu(_0x3a0aa0,_0x9b6d75){return ze(_0x3a0aa0['visibleWrites'],_0x9b6d75);}function Eu(_0xadb3a6,_0x889810,_0x41921e,_0x503346,_0x23b6bf,_0x1f8aa4,_0x172205){let _0x599405;const _0x50af6c=Ee(_0xadb3a6['visibleWrites'],_0x889810),_0x4b6580=ze(_0x50af6c,w());if(_0x4b6580!=null)_0x599405=_0x4b6580;else{if(_0x41921e!=null)_0x599405=at(_0x50af6c,_0x41921e);else return[];}if(_0x599405=_0x599405['withIndex'](_0x172205),!_0x599405['isEmpty']()&&!_0x599405['isLeafNode']()){const _0x1ae98f=[],_0x4487ae=_0x172205['getCompare'](),_0x56ebe3=_0x1f8aa4?_0x599405['getReverseIteratorFrom'](_0x503346,_0x172205):_0x599405['getIteratorFrom'](_0x503346,_0x172205);let _0x36cbb9=_0x56ebe3['getNext']();for(;_0x36cbb9&&_0x1ae98f['length']<_0x23b6bf;)_0x4487ae(_0x36cbb9,_0x503346)!==0x0&&_0x1ae98f['push'](_0x36cbb9),_0x36cbb9=_0x56ebe3['getNext']();return _0x1ae98f;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x4fede1,_0xbe53b7,_0x46a27d,_0x567647){return Bo(_0x4fede1['writeTree'],_0x4fede1['treePath'],_0xbe53b7,_0x46a27d,_0x567647);}function is(_0x326773,_0x3a3b1c){return gu(_0x326773['writeTree'],_0x326773['treePath'],_0x3a3b1c);}function cr(_0x227034,_0x4218ce,_0x381cf5,_0x37aa82){return mu(_0x227034['writeTree'],_0x227034['treePath'],_0x4218ce,_0x381cf5,_0x37aa82);}function Tn(_0x4ea734,_0x22e059){return vu(_0x4ea734['writeTree'],k(_0x4ea734['treePath'],_0x22e059));}function wu(_0x226847,_0x526bc6,_0x8c4a36,_0x4d2764,_0x521497,_0x1955ca){return Eu(_0x226847['writeTree'],_0x226847['treePath'],_0x526bc6,_0x8c4a36,_0x4d2764,_0x521497,_0x1955ca);}function ss(_0x1e754d,_0x4858cc,_0x5b5a88){return yu(_0x1e754d['writeTree'],_0x1e754d['treePath'],_0x4858cc,_0x5b5a88);}function Vo(_0x12fea1,_0x186975){return Ho(k(_0x12fea1['treePath'],_0x186975),_0x12fea1['writeTree']);}function Ho(_0x31a8f2,_0x5b7a6d){return{'treePath':_0x31a8f2,'writeTree':_0x5b7a6d};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4c2105){const _0x53666f=_0x4c2105['type'],_0x24e72d=_0x4c2105['childName'];f(_0x53666f==='child_added'||_0x53666f==='child_changed'||_0x53666f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x24e72d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1882ae=this['changeMap']['get'](_0x24e72d);if(_0x1882ae){const _0x1e2d19=_0x1882ae['type'];if(_0x53666f==='child_added'&&_0x1e2d19==='child_removed')this['changeMap']['set'](_0x24e72d,xt(_0x24e72d,_0x4c2105['snapshotNode'],_0x1882ae['snapshotNode']));else{if(_0x53666f==='child_removed'&&_0x1e2d19==='child_added')this['changeMap']['delete'](_0x24e72d);else{if(_0x53666f==='child_removed'&&_0x1e2d19==='child_changed')this['changeMap']['set'](_0x24e72d,Lt(_0x24e72d,_0x1882ae['oldSnap']));else{if(_0x53666f==='child_changed'&&_0x1e2d19==='child_added')this['changeMap']['set'](_0x24e72d,rt(_0x24e72d,_0x4c2105['snapshotNode']));else{if(_0x53666f==='child_changed'&&_0x1e2d19==='child_changed')this['changeMap']['set'](_0x24e72d,xt(_0x24e72d,_0x4c2105['snapshotNode'],_0x1882ae['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x4c2105+'\x20occurred\x20after\x20'+_0x1882ae);}}}}}else this['changeMap']['set'](_0x24e72d,_0x4c2105);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x4fe1cc){return null;}['getChildAfterChild'](_0xae749f,_0x166dfc,_0x1442bd){return null;}}const $o=new Tu();class rs{constructor(_0x49ef70,_0x5e68fe,_0x1ee06f=null){this['writes_']=_0x49ef70,this['viewCache_']=_0x5e68fe,this['optCompleteServerCache_']=_0x1ee06f;}['getCompleteChild'](_0x430908){const _0x308b87=this['viewCache_']['eventCache'];if(_0x308b87['isCompleteForChild'](_0x430908))return _0x308b87['getNode']()['getImmediateChild'](_0x430908);{const _0x3814d6=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x430908,_0x3814d6);}}['getChildAfterChild'](_0x2ca350,_0x2e101d,_0x500a97){const _0x3217c0=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x1d9109=wu(this['writes_'],_0x3217c0,_0x2e101d,0x1,_0x500a97,_0x2ca350);return _0x1d9109['length']===0x0?null:_0x1d9109[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2cd4f1){return{'filter':_0x2cd4f1};}function bu(_0x53a648,_0x1f6167){f(_0x1f6167['eventCache']['getNode']()['isIndexed'](_0x53a648['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1f6167['serverCache']['getNode']()['isIndexed'](_0x53a648['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4619f2,_0x3e2a4c,_0x1cb96a,_0x5111ed,_0xee35aa){const _0x3b3f60=new Cu();let _0x1732e9,_0x22cae9;if(_0x1cb96a['type']===z['OVERWRITE']){const _0x549c9a=_0x1cb96a;_0x549c9a['source']['fromUser']?_0x1732e9=ki(_0x4619f2,_0x3e2a4c,_0x549c9a['path'],_0x549c9a['snap'],_0x5111ed,_0xee35aa,_0x3b3f60):(f(_0x549c9a['source']['fromServer'],'Unknown\x20source.'),_0x22cae9=_0x549c9a['source']['tagged']||_0x3e2a4c['serverCache']['isFiltered']()&&!v(_0x549c9a['path']),_0x1732e9=Sn(_0x4619f2,_0x3e2a4c,_0x549c9a['path'],_0x549c9a['snap'],_0x5111ed,_0xee35aa,_0x22cae9,_0x3b3f60));}else{if(_0x1cb96a['type']===z['MERGE']){const _0x4d492b=_0x1cb96a;_0x4d492b['source']['fromUser']?_0x1732e9=ku(_0x4619f2,_0x3e2a4c,_0x4d492b['path'],_0x4d492b['children'],_0x5111ed,_0xee35aa,_0x3b3f60):(f(_0x4d492b['source']['fromServer'],'Unknown\x20source.'),_0x22cae9=_0x4d492b['source']['tagged']||_0x3e2a4c['serverCache']['isFiltered'](),_0x1732e9=Pi(_0x4619f2,_0x3e2a4c,_0x4d492b['path'],_0x4d492b['children'],_0x5111ed,_0xee35aa,_0x22cae9,_0x3b3f60));}else{if(_0x1cb96a['type']===z['ACK_USER_WRITE']){const _0x3fa3ab=_0x1cb96a;_0x3fa3ab['revert']?_0x1732e9=Ou(_0x4619f2,_0x3e2a4c,_0x3fa3ab['path'],_0x5111ed,_0xee35aa,_0x3b3f60):_0x1732e9=Pu(_0x4619f2,_0x3e2a4c,_0x3fa3ab['path'],_0x3fa3ab['affectedTree'],_0x5111ed,_0xee35aa,_0x3b3f60);}else{if(_0x1cb96a['type']===z['LISTEN_COMPLETE'])_0x1732e9=Nu(_0x4619f2,_0x3e2a4c,_0x1cb96a['path'],_0x5111ed,_0x3b3f60);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1cb96a['type']);}}}const _0x4a8943=_0x3b3f60['getChanges']();return Au(_0x3e2a4c,_0x1732e9,_0x4a8943),{'viewCache':_0x1732e9,'changes':_0x4a8943};}function Au(_0xf5fff8,_0x28593a,_0x1a794f){const _0x878f97=_0x28593a['eventCache'];if(_0x878f97['isFullyInitialized']()){const _0x3be5ee=_0x878f97['getNode']()['isLeafNode']()||_0x878f97['getNode']()['isEmpty'](),_0x336ae0=wn(_0xf5fff8);(_0x1a794f['length']>0x0||!_0xf5fff8['eventCache']['isFullyInitialized']()||_0x3be5ee&&!_0x878f97['getNode']()['equals'](_0x336ae0)||!_0x878f97['getNode']()['getPriority']()['equals'](_0x336ae0['getPriority']()))&&_0x1a794f['push'](Lo(wn(_0x28593a)));}}function Go(_0x355d9d,_0x17bd22,_0x215365,_0x407408,_0x254829,_0xea7a6e){const _0x26c437=_0x17bd22['eventCache'];if(Tn(_0x407408,_0x215365)!=null)return _0x17bd22;{let _0x11e30c,_0x4ccdb6;if(v(_0x215365)){if(f(_0x17bd22['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x17bd22['serverCache']['isFiltered']()){const _0x3b2535=Ve(_0x17bd22),_0x343e48=_0x3b2535 instanceof g?_0x3b2535:g['EMPTY_NODE'],_0x5dff8a=is(_0x407408,_0x343e48);_0x11e30c=_0x355d9d['filter']['updateFullNode'](_0x17bd22['eventCache']['getNode'](),_0x5dff8a,_0xea7a6e);}else{const _0x547e52=Cn(_0x407408,Ve(_0x17bd22));_0x11e30c=_0x355d9d['filter']['updateFullNode'](_0x17bd22['eventCache']['getNode'](),_0x547e52,_0xea7a6e);}}else{const _0x54ce1a=y(_0x215365);if(_0x54ce1a==='.priority'){f(Ce(_0x215365)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x25ad5e=_0x26c437['getNode']();_0x4ccdb6=_0x17bd22['serverCache']['getNode']();const _0x2d323e=cr(_0x407408,_0x215365,_0x25ad5e,_0x4ccdb6);_0x2d323e!=null?_0x11e30c=_0x355d9d['filter']['updatePriority'](_0x25ad5e,_0x2d323e):_0x11e30c=_0x26c437['getNode']();}else{const _0x417e8e=S(_0x215365);let _0x3a39c3;if(_0x26c437['isCompleteForChild'](_0x54ce1a)){_0x4ccdb6=_0x17bd22['serverCache']['getNode']();const _0x5f047e=cr(_0x407408,_0x215365,_0x26c437['getNode'](),_0x4ccdb6);_0x5f047e!=null?_0x3a39c3=_0x26c437['getNode']()['getImmediateChild'](_0x54ce1a)['updateChild'](_0x417e8e,_0x5f047e):_0x3a39c3=_0x26c437['getNode']()['getImmediateChild'](_0x54ce1a);}else _0x3a39c3=ss(_0x407408,_0x54ce1a,_0x17bd22['serverCache']);_0x3a39c3!=null?_0x11e30c=_0x355d9d['filter']['updateChild'](_0x26c437['getNode'](),_0x54ce1a,_0x3a39c3,_0x417e8e,_0x254829,_0xea7a6e):_0x11e30c=_0x26c437['getNode']();}}return Rt(_0x17bd22,_0x11e30c,_0x26c437['isFullyInitialized']()||v(_0x215365),_0x355d9d['filter']['filtersNodes']());}}function Sn(_0xf77e37,_0x75db49,_0x7b3123,_0x3ebca5,_0x43f715,_0xd044b,_0x743bf7,_0x3f95ab){const _0x2d8ed2=_0x75db49['serverCache'];let _0x481d9c;const _0x3f4290=_0x743bf7?_0xf77e37['filter']:_0xf77e37['filter']['getIndexedFilter']();if(v(_0x7b3123))_0x481d9c=_0x3f4290['updateFullNode'](_0x2d8ed2['getNode'](),_0x3ebca5,null);else{if(_0x3f4290['filtersNodes']()&&!_0x2d8ed2['isFiltered']()){const _0x2fedcd=_0x2d8ed2['getNode']()['updateChild'](_0x7b3123,_0x3ebca5);_0x481d9c=_0x3f4290['updateFullNode'](_0x2d8ed2['getNode'](),_0x2fedcd,null);}else{const _0x31b260=y(_0x7b3123);if(!_0x2d8ed2['isCompleteForPath'](_0x7b3123)&&Ce(_0x7b3123)>0x1)return _0x75db49;const _0x4f7b19=S(_0x7b3123),_0x3c6105=_0x2d8ed2['getNode']()['getImmediateChild'](_0x31b260)['updateChild'](_0x4f7b19,_0x3ebca5);_0x31b260==='.priority'?_0x481d9c=_0x3f4290['updatePriority'](_0x2d8ed2['getNode'](),_0x3c6105):_0x481d9c=_0x3f4290['updateChild'](_0x2d8ed2['getNode'](),_0x31b260,_0x3c6105,_0x4f7b19,$o,null);}}const _0x58e6ab=Fo(_0x75db49,_0x481d9c,_0x2d8ed2['isFullyInitialized']()||v(_0x7b3123),_0x3f4290['filtersNodes']()),_0x274a02=new rs(_0x43f715,_0x58e6ab,_0xd044b);return Go(_0xf77e37,_0x58e6ab,_0x7b3123,_0x43f715,_0x274a02,_0x3f95ab);}function ki(_0x12196f,_0x20e02b,_0x13dfe2,_0x5c6751,_0x4913cd,_0x4521c6,_0x188d8a){const _0x527af9=_0x20e02b['eventCache'];let _0x38aab5,_0x118b86;const _0x54996a=new rs(_0x4913cd,_0x20e02b,_0x4521c6);if(v(_0x13dfe2))_0x118b86=_0x12196f['filter']['updateFullNode'](_0x20e02b['eventCache']['getNode'](),_0x5c6751,_0x188d8a),_0x38aab5=Rt(_0x20e02b,_0x118b86,!0x0,_0x12196f['filter']['filtersNodes']());else{const _0x4096c4=y(_0x13dfe2);if(_0x4096c4==='.priority')_0x118b86=_0x12196f['filter']['updatePriority'](_0x20e02b['eventCache']['getNode'](),_0x5c6751),_0x38aab5=Rt(_0x20e02b,_0x118b86,_0x527af9['isFullyInitialized'](),_0x527af9['isFiltered']());else{const _0x459aae=S(_0x13dfe2),_0x4598d6=_0x527af9['getNode']()['getImmediateChild'](_0x4096c4);let _0x155aa6;if(v(_0x459aae))_0x155aa6=_0x5c6751;else{const _0x4167b4=_0x54996a['getCompleteChild'](_0x4096c4);_0x4167b4!=null?ji(_0x459aae)==='.priority'&&_0x4167b4['getChild'](Ro(_0x459aae))['isEmpty']()?_0x155aa6=_0x4167b4:_0x155aa6=_0x4167b4['updateChild'](_0x459aae,_0x5c6751):_0x155aa6=g['EMPTY_NODE'];}if(_0x4598d6['equals'](_0x155aa6))_0x38aab5=_0x20e02b;else{const _0x1e1a58=_0x12196f['filter']['updateChild'](_0x527af9['getNode'](),_0x4096c4,_0x155aa6,_0x459aae,_0x54996a,_0x188d8a);_0x38aab5=Rt(_0x20e02b,_0x1e1a58,_0x527af9['isFullyInitialized'](),_0x12196f['filter']['filtersNodes']());}}}return _0x38aab5;}function lr(_0x65d5ea,_0x58149d){return _0x65d5ea['eventCache']['isCompleteForChild'](_0x58149d);}function ku(_0xf20319,_0x1b9b7f,_0x4eb56b,_0x544bbe,_0x170169,_0x260bda,_0x3e0e39){let _0x281e5b=_0x1b9b7f;return _0x544bbe['foreach']((_0x53b47b,_0x5975e3)=>{const _0x4f732b=k(_0x4eb56b,_0x53b47b);lr(_0x1b9b7f,y(_0x4f732b))&&(_0x281e5b=ki(_0xf20319,_0x281e5b,_0x4f732b,_0x5975e3,_0x170169,_0x260bda,_0x3e0e39));}),_0x544bbe['foreach']((_0x11c1d7,_0x2df2af)=>{const _0x51bab7=k(_0x4eb56b,_0x11c1d7);lr(_0x1b9b7f,y(_0x51bab7))||(_0x281e5b=ki(_0xf20319,_0x281e5b,_0x51bab7,_0x2df2af,_0x170169,_0x260bda,_0x3e0e39));}),_0x281e5b;}function hr(_0x10d76f,_0x211490,_0x5ae1e3){return _0x5ae1e3['foreach']((_0x770892,_0x2aef5c)=>{_0x211490=_0x211490['updateChild'](_0x770892,_0x2aef5c);}),_0x211490;}function Pi(_0x3299d2,_0x3611e6,_0x394edb,_0x55a569,_0x22ab30,_0x554e16,_0x308304,_0x393bff){if(_0x3611e6['serverCache']['getNode']()['isEmpty']()&&!_0x3611e6['serverCache']['isFullyInitialized']())return _0x3611e6;let _0x559564=_0x3611e6,_0x41fadc;v(_0x394edb)?_0x41fadc=_0x55a569:_0x41fadc=new b(null)['setTree'](_0x394edb,_0x55a569);const _0x3222b4=_0x3611e6['serverCache']['getNode']();return _0x41fadc['children']['inorderTraversal']((_0x2728df,_0x278097)=>{if(_0x3222b4['hasChild'](_0x2728df)){const _0x8273f0=_0x3611e6['serverCache']['getNode']()['getImmediateChild'](_0x2728df),_0x2a0a2b=hr(_0x3299d2,_0x8273f0,_0x278097);_0x559564=Sn(_0x3299d2,_0x559564,new C(_0x2728df),_0x2a0a2b,_0x22ab30,_0x554e16,_0x308304,_0x393bff);}}),_0x41fadc['children']['inorderTraversal']((_0x1f6db6,_0x3511cb)=>{const _0x19280d=!_0x3611e6['serverCache']['isCompleteForChild'](_0x1f6db6)&&_0x3511cb['value']===null;if(!_0x3222b4['hasChild'](_0x1f6db6)&&!_0x19280d){const _0x3aeb00=_0x3611e6['serverCache']['getNode']()['getImmediateChild'](_0x1f6db6),_0x516eeb=hr(_0x3299d2,_0x3aeb00,_0x3511cb);_0x559564=Sn(_0x3299d2,_0x559564,new C(_0x1f6db6),_0x516eeb,_0x22ab30,_0x554e16,_0x308304,_0x393bff);}}),_0x559564;}function Pu(_0x498539,_0x47fb70,_0x1a97f7,_0x2bacf7,_0x1d3270,_0x124d3c,_0xb59b2a){if(Tn(_0x1d3270,_0x1a97f7)!=null)return _0x47fb70;const _0x10893a=_0x47fb70['serverCache']['isFiltered'](),_0xe8af27=_0x47fb70['serverCache'];if(_0x2bacf7['value']!=null){if(v(_0x1a97f7)&&_0xe8af27['isFullyInitialized']()||_0xe8af27['isCompleteForPath'](_0x1a97f7))return Sn(_0x498539,_0x47fb70,_0x1a97f7,_0xe8af27['getNode']()['getChild'](_0x1a97f7),_0x1d3270,_0x124d3c,_0x10893a,_0xb59b2a);if(v(_0x1a97f7)){let _0x17bf2d=new b(null);return _0xe8af27['getNode']()['forEachChild'](ve,(_0x22907d,_0x300edb)=>{_0x17bf2d=_0x17bf2d['set'](new C(_0x22907d),_0x300edb);}),Pi(_0x498539,_0x47fb70,_0x1a97f7,_0x17bf2d,_0x1d3270,_0x124d3c,_0x10893a,_0xb59b2a);}else return _0x47fb70;}else{let _0x6b5724=new b(null);return _0x2bacf7['foreach']((_0x22fdb9,_0x4cf1fd)=>{const _0x30028b=k(_0x1a97f7,_0x22fdb9);_0xe8af27['isCompleteForPath'](_0x30028b)&&(_0x6b5724=_0x6b5724['set'](_0x22fdb9,_0xe8af27['getNode']()['getChild'](_0x30028b)));}),Pi(_0x498539,_0x47fb70,_0x1a97f7,_0x6b5724,_0x1d3270,_0x124d3c,_0x10893a,_0xb59b2a);}}function Nu(_0x2195e4,_0x563240,_0x286c84,_0x17d0f1,_0x10fb5e){const _0x2c0209=_0x563240['serverCache'],_0x232211=Fo(_0x563240,_0x2c0209['getNode'](),_0x2c0209['isFullyInitialized']()||v(_0x286c84),_0x2c0209['isFiltered']());return Go(_0x2195e4,_0x232211,_0x286c84,_0x17d0f1,$o,_0x10fb5e);}function Ou(_0x91e62,_0x56de81,_0xcd08fe,_0x381e2b,_0x2d8046,_0x5e499d){let _0x5103d2;if(Tn(_0x381e2b,_0xcd08fe)!=null)return _0x56de81;{const _0x598949=new rs(_0x381e2b,_0x56de81,_0x2d8046),_0x16feb5=_0x56de81['eventCache']['getNode']();let _0xb4aeb8;if(v(_0xcd08fe)||y(_0xcd08fe)==='.priority'){let _0x6a6585;if(_0x56de81['serverCache']['isFullyInitialized']())_0x6a6585=Cn(_0x381e2b,Ve(_0x56de81));else{const _0x2775fe=_0x56de81['serverCache']['getNode']();f(_0x2775fe instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x6a6585=is(_0x381e2b,_0x2775fe);}_0x6a6585=_0x6a6585,_0xb4aeb8=_0x91e62['filter']['updateFullNode'](_0x16feb5,_0x6a6585,_0x5e499d);}else{const _0x3833a5=y(_0xcd08fe);let _0x11aa84=ss(_0x381e2b,_0x3833a5,_0x56de81['serverCache']);_0x11aa84==null&&_0x56de81['serverCache']['isCompleteForChild'](_0x3833a5)&&(_0x11aa84=_0x16feb5['getImmediateChild'](_0x3833a5)),_0x11aa84!=null?_0xb4aeb8=_0x91e62['filter']['updateChild'](_0x16feb5,_0x3833a5,_0x11aa84,S(_0xcd08fe),_0x598949,_0x5e499d):_0x56de81['eventCache']['getNode']()['hasChild'](_0x3833a5)?_0xb4aeb8=_0x91e62['filter']['updateChild'](_0x16feb5,_0x3833a5,g['EMPTY_NODE'],S(_0xcd08fe),_0x598949,_0x5e499d):_0xb4aeb8=_0x16feb5,_0xb4aeb8['isEmpty']()&&_0x56de81['serverCache']['isFullyInitialized']()&&(_0x5103d2=Cn(_0x381e2b,Ve(_0x56de81)),_0x5103d2['isLeafNode']()&&(_0xb4aeb8=_0x91e62['filter']['updateFullNode'](_0xb4aeb8,_0x5103d2,_0x5e499d)));}return _0x5103d2=_0x56de81['serverCache']['isFullyInitialized']()||Tn(_0x381e2b,w())!=null,Rt(_0x56de81,_0xb4aeb8,_0x5103d2,_0x91e62['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x49e53b,_0x1ce9b0){this['query_']=_0x49e53b,this['eventRegistrations_']=[];const _0x238c9b=this['query_']['_queryParams'],_0x156beb=new Xi(_0x238c9b['getIndex']()),_0x5645af=Kh(_0x238c9b);this['processor_']=Su(_0x5645af);const _0xe42854=_0x1ce9b0['serverCache'],_0x42ab08=_0x1ce9b0['eventCache'],_0x313604=_0x156beb['updateFullNode'](g['EMPTY_NODE'],_0xe42854['getNode'](),null),_0x13e539=_0x5645af['updateFullNode'](g['EMPTY_NODE'],_0x42ab08['getNode'](),null),_0x1c8467=new Te(_0x313604,_0xe42854['isFullyInitialized'](),_0x156beb['filtersNodes']()),_0x4f17c2=new Te(_0x13e539,_0x42ab08['isFullyInitialized'](),_0x5645af['filtersNodes']());this['viewCache_']=Un(_0x4f17c2,_0x1c8467),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xe347bf){return _0xe347bf['viewCache_']['serverCache']['getNode']();}function Lu(_0x41e32f){return wn(_0x41e32f['viewCache_']);}function xu(_0x118660,_0xdf06f9){const _0x52db21=Ve(_0x118660['viewCache_']);return _0x52db21&&(_0x118660['query']['_queryParams']['loadsAllData']()||!v(_0xdf06f9)&&!_0x52db21['getImmediateChild'](y(_0xdf06f9))['isEmpty']())?_0x52db21['getChild'](_0xdf06f9):null;}function ur(_0x54a3ad){return _0x54a3ad['eventRegistrations_']['length']===0x0;}function Fu(_0x1da727,_0x17be4a){_0x1da727['eventRegistrations_']['push'](_0x17be4a);}function dr(_0x7cf0ce,_0x1d4bd8,_0x31c36b){const _0x477d49=[];if(_0x31c36b){f(_0x1d4bd8==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2a9731=_0x7cf0ce['query']['_path'];_0x7cf0ce['eventRegistrations_']['forEach'](_0x5a5889=>{const _0x3dc632=_0x5a5889['createCancelEvent'](_0x31c36b,_0x2a9731);_0x3dc632&&_0x477d49['push'](_0x3dc632);});}if(_0x1d4bd8){let _0x388270=[];for(let _0x3a3c4f=0x0;_0x3a3c4f<_0x7cf0ce['eventRegistrations_']['length'];++_0x3a3c4f){const _0x53bd06=_0x7cf0ce['eventRegistrations_'][_0x3a3c4f];if(!_0x53bd06['matches'](_0x1d4bd8))_0x388270['push'](_0x53bd06);else{if(_0x1d4bd8['hasAnyCallback']()){_0x388270=_0x388270['concat'](_0x7cf0ce['eventRegistrations_']['slice'](_0x3a3c4f+0x1));break;}}}_0x7cf0ce['eventRegistrations_']=_0x388270;}else _0x7cf0ce['eventRegistrations_']=[];return _0x477d49;}function fr(_0x5af2c3,_0x5f57f1,_0x1ee264,_0x2ae914){_0x5f57f1['type']===z['MERGE']&&_0x5f57f1['source']['queryId']!==null&&(f(Ve(_0x5af2c3['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x5af2c3['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x458c2c=_0x5af2c3['viewCache_'],_0x515500=Ru(_0x5af2c3['processor_'],_0x458c2c,_0x5f57f1,_0x1ee264,_0x2ae914);return bu(_0x5af2c3['processor_'],_0x515500['viewCache']),f(_0x515500['viewCache']['serverCache']['isFullyInitialized']()||!_0x458c2c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5af2c3['viewCache_']=_0x515500['viewCache'],qo(_0x5af2c3,_0x515500['changes'],_0x515500['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x37ba68,_0x3310fe){const _0x567228=_0x37ba68['viewCache_']['eventCache'],_0x72bfe7=[];return _0x567228['getNode']()['isLeafNode']()||_0x567228['getNode']()['forEachChild'](R,(_0x2afa62,_0x6b2754)=>{_0x72bfe7['push'](rt(_0x2afa62,_0x6b2754));}),_0x567228['isFullyInitialized']()&&_0x72bfe7['push'](Lo(_0x567228['getNode']())),qo(_0x37ba68,_0x72bfe7,_0x567228['getNode'](),_0x3310fe);}function qo(_0x5108d8,_0x757152,_0x58456c,_0x4de285){const _0x16513d=_0x4de285?[_0x4de285]:_0x5108d8['eventRegistrations_'];return ru(_0x5108d8['eventGenerator_'],_0x757152,_0x58456c,_0x16513d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x2ac6ef){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x2ac6ef;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x595889){return _0x595889['views']['size']===0x0;}function os(_0x209890,_0x79c328,_0x40aef8,_0x5596cf){const _0x1c99a2=_0x79c328['source']['queryId'];if(_0x1c99a2!==null){const _0x568f09=_0x209890['views']['get'](_0x1c99a2);return f(_0x568f09!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x568f09,_0x79c328,_0x40aef8,_0x5596cf);}else{let _0x23cfdf=[];for(const _0x361421 of _0x209890['views']['values']())_0x23cfdf=_0x23cfdf['concat'](fr(_0x361421,_0x79c328,_0x40aef8,_0x5596cf));return _0x23cfdf;}}function jo(_0x370657,_0x5ade80,_0x378158,_0x457bd7,_0x5d2aef){const _0x16da97=_0x5ade80['_queryIdentifier'],_0x330785=_0x370657['views']['get'](_0x16da97);if(!_0x330785){let _0x22de60=Cn(_0x378158,_0x5d2aef?_0x457bd7:null),_0x193a5a=!0x1;_0x22de60?_0x193a5a=!0x0:_0x457bd7 instanceof g?(_0x22de60=is(_0x378158,_0x457bd7),_0x193a5a=!0x1):(_0x22de60=g['EMPTY_NODE'],_0x193a5a=!0x1);const _0x4025a4=Un(new Te(_0x22de60,_0x193a5a,!0x1),new Te(_0x457bd7,_0x5d2aef,!0x1));return new Du(_0x5ade80,_0x4025a4);}return _0x330785;}function Hu(_0x5b22fa,_0x79f57f,_0x450b99,_0x22da14,_0x5aa472,_0x3db483){const _0x2456dc=jo(_0x5b22fa,_0x79f57f,_0x22da14,_0x5aa472,_0x3db483);return _0x5b22fa['views']['has'](_0x79f57f['_queryIdentifier'])||_0x5b22fa['views']['set'](_0x79f57f['_queryIdentifier'],_0x2456dc),Fu(_0x2456dc,_0x450b99),Uu(_0x2456dc,_0x450b99);}function $u(_0x44c7d8,_0x21de0f,_0x22db15,_0x25bfce){const _0xf6f96b=_0x21de0f['_queryIdentifier'],_0x31e3fa=[];let _0x4e5b6b=[];const _0x39dacc=Se(_0x44c7d8);if(_0xf6f96b==='default'){for(const [_0xa6cfa3,_0x6ba18d]of _0x44c7d8['views']['entries']())_0x4e5b6b=_0x4e5b6b['concat'](dr(_0x6ba18d,_0x22db15,_0x25bfce)),ur(_0x6ba18d)&&(_0x44c7d8['views']['delete'](_0xa6cfa3),_0x6ba18d['query']['_queryParams']['loadsAllData']()||_0x31e3fa['push'](_0x6ba18d['query']));}else{const _0x262731=_0x44c7d8['views']['get'](_0xf6f96b);_0x262731&&(_0x4e5b6b=_0x4e5b6b['concat'](dr(_0x262731,_0x22db15,_0x25bfce)),ur(_0x262731)&&(_0x44c7d8['views']['delete'](_0xf6f96b),_0x262731['query']['_queryParams']['loadsAllData']()||_0x31e3fa['push'](_0x262731['query'])));}return _0x39dacc&&!Se(_0x44c7d8)&&_0x31e3fa['push'](new(Bu())(_0x21de0f['_repo'],_0x21de0f['_path'])),{'removed':_0x31e3fa,'events':_0x4e5b6b};}function Ko(_0x59097c){const _0x76ad9a=[];for(const _0x27b862 of _0x59097c['views']['values']())_0x27b862['query']['_queryParams']['loadsAllData']()||_0x76ad9a['push'](_0x27b862);return _0x76ad9a;}function Ie(_0x475dbc,_0x5a76c9){let _0xa78451=null;for(const _0x20ba7e of _0x475dbc['views']['values']())_0xa78451=_0xa78451||xu(_0x20ba7e,_0x5a76c9);return _0xa78451;}function Yo(_0x37899d,_0x3e7ab6){if(_0x3e7ab6['_queryParams']['loadsAllData']())return Bn(_0x37899d);{const _0x5b16b2=_0x3e7ab6['_queryIdentifier'];return _0x37899d['views']['get'](_0x5b16b2);}}function Qo(_0x184a70,_0x373049){return Yo(_0x184a70,_0x373049)!=null;}function Se(_0x2de639){return Bn(_0x2de639)!=null;}function Bn(_0x4d89e2){for(const _0x5f19ed of _0x4d89e2['views']['values']())if(_0x5f19ed['query']['_queryParams']['loadsAllData']())return _0x5f19ed;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x343109){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x343109;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2d5fcb){this['listenProvider_']=_0x2d5fcb,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2592b5,_0x155770,_0x24ad6d,_0x1ad4c7,_0xc2c283){return lu(_0x2592b5['pendingWriteTree_'],_0x155770,_0x24ad6d,_0x1ad4c7,_0xc2c283),_0xc2c283?_t(_0x2592b5,new Be(es(),_0x155770,_0x24ad6d)):[];}function ju(_0x25557f,_0x28d2f0,_0x52d3a3,_0xc176cf){hu(_0x25557f['pendingWriteTree_'],_0x28d2f0,_0x52d3a3,_0xc176cf);const _0x23f6a5=b['fromObject'](_0x52d3a3);return _t(_0x25557f,new ot(es(),_0x28d2f0,_0x23f6a5));}function _e(_0x202471,_0x4c5a11,_0x2ed786=!0x1){const _0x204540=uu(_0x202471['pendingWriteTree_'],_0x4c5a11);if(du(_0x202471['pendingWriteTree_'],_0x4c5a11)){let _0x31249d=new b(null);return _0x204540['snap']!=null?_0x31249d=_0x31249d['set'](w(),!0x0):x(_0x204540['children'],_0x1c9eb5=>{_0x31249d=_0x31249d['set'](new C(_0x1c9eb5),!0x0);}),_t(_0x202471,new In(_0x204540['path'],_0x31249d,_0x2ed786));}else return[];}function Yt(_0x3ccc55,_0x5bae06,_0x4c9511){return _t(_0x3ccc55,new Be(ts(),_0x5bae06,_0x4c9511));}function Ku(_0x4c7b59,_0x561f21,_0x258f3d){const _0x2c4de9=b['fromObject'](_0x258f3d);return _t(_0x4c7b59,new ot(ts(),_0x561f21,_0x2c4de9));}function Yu(_0x170a6e,_0x2a19d6){return _t(_0x170a6e,new Ut(ts(),_0x2a19d6));}function Qu(_0x363cf8,_0x42eee7,_0x1e1ca5){const _0x5e6eed=cs(_0x363cf8,_0x1e1ca5);if(_0x5e6eed){const _0x2b15ea=ls(_0x5e6eed),_0x12040d=_0x2b15ea['path'],_0x43e2d1=_0x2b15ea['queryId'],_0x5091ee=F(_0x12040d,_0x42eee7),_0x5d0118=new Ut(ns(_0x43e2d1),_0x5091ee);return hs(_0x363cf8,_0x12040d,_0x5d0118);}else return[];}function An(_0xd5c8e9,_0x3e3dc3,_0x2c9dc2,_0x3be168,_0x24dd69=!0x1){const _0x5cc877=_0x3e3dc3['_path'],_0x407558=_0xd5c8e9['syncPointTree_']['get'](_0x5cc877);let _0x541657=[];if(_0x407558&&(_0x3e3dc3['_queryIdentifier']==='default'||Qo(_0x407558,_0x3e3dc3))){const _0x48e85f=$u(_0x407558,_0x3e3dc3,_0x2c9dc2,_0x3be168);Vu(_0x407558)&&(_0xd5c8e9['syncPointTree_']=_0xd5c8e9['syncPointTree_']['remove'](_0x5cc877));const _0x1e3fb3=_0x48e85f['removed'];if(_0x541657=_0x48e85f['events'],!_0x24dd69){const _0x4e695d=_0x1e3fb3['findIndex'](_0x47b868=>_0x47b868['_queryParams']['loadsAllData']())!==-0x1,_0x2451e8=_0xd5c8e9['syncPointTree_']['findOnPath'](_0x5cc877,(_0x38c198,_0x2f34f3)=>Se(_0x2f34f3));if(_0x4e695d&&!_0x2451e8){const _0x41061e=_0xd5c8e9['syncPointTree_']['subtree'](_0x5cc877);if(!_0x41061e['isEmpty']()){const _0x585b22=Zu(_0x41061e);for(let _0x329102=0x0;_0x329102<_0x585b22['length'];++_0x329102){const _0x43786e=_0x585b22[_0x329102],_0x1b9757=_0x43786e['query'],_0x11a9c8=ea(_0xd5c8e9,_0x43786e);_0xd5c8e9['listenProvider_']['startListening'](kt(_0x1b9757),Wt(_0xd5c8e9,_0x1b9757),_0x11a9c8['hashFn'],_0x11a9c8['onComplete']);}}}!_0x2451e8&&_0x1e3fb3['length']>0x0&&!_0x3be168&&(_0x4e695d?_0xd5c8e9['listenProvider_']['stopListening'](kt(_0x3e3dc3),null):_0x1e3fb3['forEach'](_0x424df9=>{const _0x127dc8=_0xd5c8e9['queryToTagMap']['get'](Hn(_0x424df9));_0xd5c8e9['listenProvider_']['stopListening'](kt(_0x424df9),_0x127dc8);}));}ed(_0xd5c8e9,_0x1e3fb3);}return _0x541657;}function Jo(_0xf078e6,_0x648872,_0x534f90,_0x387eba){const _0x33f493=cs(_0xf078e6,_0x387eba);if(_0x33f493!=null){const _0x5086ea=ls(_0x33f493),_0x260f3c=_0x5086ea['path'],_0x508fbe=_0x5086ea['queryId'],_0x5d6273=F(_0x260f3c,_0x648872),_0x213de0=new Be(ns(_0x508fbe),_0x5d6273,_0x534f90);return hs(_0xf078e6,_0x260f3c,_0x213de0);}else return[];}function Ju(_0x363ee3,_0xa17089,_0x341e48,_0x24e2fb){const _0x3d1d0e=cs(_0x363ee3,_0x24e2fb);if(_0x3d1d0e){const _0xd33dda=ls(_0x3d1d0e),_0x38c6c3=_0xd33dda['path'],_0x5283aa=_0xd33dda['queryId'],_0x3926e2=F(_0x38c6c3,_0xa17089),_0x8fac18=b['fromObject'](_0x341e48),_0x56c990=new ot(ns(_0x5283aa),_0x3926e2,_0x8fac18);return hs(_0x363ee3,_0x38c6c3,_0x56c990);}else return[];}function Ni(_0xe5cd0,_0x2d8e84,_0xbcc75e,_0x5bd5a4=!0x1){const _0xc67b4e=_0x2d8e84['_path'];let _0x4b6ad1=null,_0x166795=!0x1;_0xe5cd0['syncPointTree_']['foreachOnPath'](_0xc67b4e,(_0x247d11,_0x1b1bf1)=>{const _0x2dc1b1=F(_0x247d11,_0xc67b4e);_0x4b6ad1=_0x4b6ad1||Ie(_0x1b1bf1,_0x2dc1b1),_0x166795=_0x166795||Se(_0x1b1bf1);});let _0x19987c=_0xe5cd0['syncPointTree_']['get'](_0xc67b4e);_0x19987c?(_0x166795=_0x166795||Se(_0x19987c),_0x4b6ad1=_0x4b6ad1||Ie(_0x19987c,w())):(_0x19987c=new zo(),_0xe5cd0['syncPointTree_']=_0xe5cd0['syncPointTree_']['set'](_0xc67b4e,_0x19987c));let _0x8a70be;_0x4b6ad1!=null?_0x8a70be=!0x0:(_0x8a70be=!0x1,_0x4b6ad1=g['EMPTY_NODE'],_0xe5cd0['syncPointTree_']['subtree'](_0xc67b4e)['foreachChild']((_0x35b494,_0x436246)=>{const _0x37b2f6=Ie(_0x436246,w());_0x37b2f6&&(_0x4b6ad1=_0x4b6ad1['updateImmediateChild'](_0x35b494,_0x37b2f6));}));const _0x1d973b=Qo(_0x19987c,_0x2d8e84);if(!_0x1d973b&&!_0x2d8e84['_queryParams']['loadsAllData']()){const _0x2939b3=Hn(_0x2d8e84);f(!_0xe5cd0['queryToTagMap']['has'](_0x2939b3),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5bc2b3=td();_0xe5cd0['queryToTagMap']['set'](_0x2939b3,_0x5bc2b3),_0xe5cd0['tagToQueryMap']['set'](_0x5bc2b3,_0x2939b3);}const _0x217443=Wn(_0xe5cd0['pendingWriteTree_'],_0xc67b4e);let _0x2b7600=Hu(_0x19987c,_0x2d8e84,_0xbcc75e,_0x217443,_0x4b6ad1,_0x8a70be);if(!_0x1d973b&&!_0x166795&&!_0x5bd5a4){const _0x29fe39=Yo(_0x19987c,_0x2d8e84);_0x2b7600=_0x2b7600['concat'](nd(_0xe5cd0,_0x2d8e84,_0x29fe39));}return _0x2b7600;}function Vn(_0x3e4800,_0x171e59,_0x19e750){const _0x53d1a2=_0x3e4800['pendingWriteTree_'],_0x2dce1c=_0x3e4800['syncPointTree_']['findOnPath'](_0x171e59,(_0x449754,_0x3173d2)=>{const _0x43aa62=F(_0x449754,_0x171e59),_0x19f0be=Ie(_0x3173d2,_0x43aa62);if(_0x19f0be)return _0x19f0be;});return Bo(_0x53d1a2,_0x171e59,_0x2dce1c,_0x19e750,!0x0);}function Xu(_0xd42df2,_0x24f192){const _0x2034c7=_0x24f192['_path'];let _0x2b8627=null;_0xd42df2['syncPointTree_']['foreachOnPath'](_0x2034c7,(_0x5895c7,_0x207e20)=>{const _0x1c4a3e=F(_0x5895c7,_0x2034c7);_0x2b8627=_0x2b8627||Ie(_0x207e20,_0x1c4a3e);});let _0x6b0b2c=_0xd42df2['syncPointTree_']['get'](_0x2034c7);_0x6b0b2c?_0x2b8627=_0x2b8627||Ie(_0x6b0b2c,w()):(_0x6b0b2c=new zo(),_0xd42df2['syncPointTree_']=_0xd42df2['syncPointTree_']['set'](_0x2034c7,_0x6b0b2c));const _0x562959=_0x2b8627!=null,_0x47ee8f=_0x562959?new Te(_0x2b8627,!0x0,!0x1):null,_0x5a5a78=Wn(_0xd42df2['pendingWriteTree_'],_0x24f192['_path']),_0x33331c=jo(_0x6b0b2c,_0x24f192,_0x5a5a78,_0x562959?_0x47ee8f['getNode']():g['EMPTY_NODE'],_0x562959);return Lu(_0x33331c);}function _t(_0x1b2328,_0xaf9400){return Xo(_0xaf9400,_0x1b2328['syncPointTree_'],null,Wn(_0x1b2328['pendingWriteTree_'],w()));}function Xo(_0x37a3ad,_0x339672,_0x1b95e5,_0xaef14c){if(v(_0x37a3ad['path']))return Zo(_0x37a3ad,_0x339672,_0x1b95e5,_0xaef14c);{const _0x29b2f7=_0x339672['get'](w());_0x1b95e5==null&&_0x29b2f7!=null&&(_0x1b95e5=Ie(_0x29b2f7,w()));let _0x13f1e9=[];const _0x2823fd=y(_0x37a3ad['path']),_0x4cc607=_0x37a3ad['operationForChild'](_0x2823fd),_0x2a2232=_0x339672['children']['get'](_0x2823fd);if(_0x2a2232&&_0x4cc607){const _0x4ffbd8=_0x1b95e5?_0x1b95e5['getImmediateChild'](_0x2823fd):null,_0x1f4449=Vo(_0xaef14c,_0x2823fd);_0x13f1e9=_0x13f1e9['concat'](Xo(_0x4cc607,_0x2a2232,_0x4ffbd8,_0x1f4449));}return _0x29b2f7&&(_0x13f1e9=_0x13f1e9['concat'](os(_0x29b2f7,_0x37a3ad,_0xaef14c,_0x1b95e5))),_0x13f1e9;}}function Zo(_0x35adde,_0x2066af,_0x2b66c2,_0x5ed7e7){const _0x7e6b35=_0x2066af['get'](w());_0x2b66c2==null&&_0x7e6b35!=null&&(_0x2b66c2=Ie(_0x7e6b35,w()));let _0x3d032e=[];return _0x2066af['children']['inorderTraversal']((_0x2414b2,_0x5d0fb8)=>{const _0x354ef5=_0x2b66c2?_0x2b66c2['getImmediateChild'](_0x2414b2):null,_0x31c054=Vo(_0x5ed7e7,_0x2414b2),_0x3984c3=_0x35adde['operationForChild'](_0x2414b2);_0x3984c3&&(_0x3d032e=_0x3d032e['concat'](Zo(_0x3984c3,_0x5d0fb8,_0x354ef5,_0x31c054)));}),_0x7e6b35&&(_0x3d032e=_0x3d032e['concat'](os(_0x7e6b35,_0x35adde,_0x5ed7e7,_0x2b66c2))),_0x3d032e;}function ea(_0x440714,_0x20895){const _0x2782a1=_0x20895['query'],_0x588fd8=Wt(_0x440714,_0x2782a1);return{'hashFn':()=>(Mu(_0x20895)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x43525b=>{if(_0x43525b==='ok')return _0x588fd8?Qu(_0x440714,_0x2782a1['_path'],_0x588fd8):Yu(_0x440714,_0x2782a1['_path']);{const _0x2bbfe8=Kl(_0x43525b,_0x2782a1);return An(_0x440714,_0x2782a1,null,_0x2bbfe8);}}};}function Wt(_0x5939e7,_0x5f399e){const _0x172b4d=Hn(_0x5f399e);return _0x5939e7['queryToTagMap']['get'](_0x172b4d);}function Hn(_0x16b3ca){return _0x16b3ca['_path']['toString']()+'$'+_0x16b3ca['_queryIdentifier'];}function cs(_0x5deaf5,_0x13e841){return _0x5deaf5['tagToQueryMap']['get'](_0x13e841);}function ls(_0x554838){const _0x2c8a01=_0x554838['indexOf']('$');return f(_0x2c8a01!==-0x1&&_0x2c8a01<_0x554838['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x554838['substr'](_0x2c8a01+0x1),'path':new C(_0x554838['substr'](0x0,_0x2c8a01))};}function hs(_0x37aadb,_0x2a5e7e,_0x1af879){const _0x3401bf=_0x37aadb['syncPointTree_']['get'](_0x2a5e7e);f(_0x3401bf,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2156c3=Wn(_0x37aadb['pendingWriteTree_'],_0x2a5e7e);return os(_0x3401bf,_0x1af879,_0x2156c3,null);}function Zu(_0x1922b8){return _0x1922b8['fold']((_0x32ca39,_0x41ba0f,_0x2492c3)=>{if(_0x41ba0f&&Se(_0x41ba0f))return[Bn(_0x41ba0f)];{let _0x15410f=[];return _0x41ba0f&&(_0x15410f=Ko(_0x41ba0f)),x(_0x2492c3,(_0x4eb2a9,_0x17ea76)=>{_0x15410f=_0x15410f['concat'](_0x17ea76);}),_0x15410f;}});}function kt(_0x39afa4){return _0x39afa4['_queryParams']['loadsAllData']()&&!_0x39afa4['_queryParams']['isDefault']()?new(qu())(_0x39afa4['_repo'],_0x39afa4['_path']):_0x39afa4;}function ed(_0x52f77c,_0x56204c){for(let _0x4018cd=0x0;_0x4018cd<_0x56204c['length'];++_0x4018cd){const _0x2e9298=_0x56204c[_0x4018cd];if(!_0x2e9298['_queryParams']['loadsAllData']()){const _0x2220d5=Hn(_0x2e9298),_0x572702=_0x52f77c['queryToTagMap']['get'](_0x2220d5);_0x52f77c['queryToTagMap']['delete'](_0x2220d5),_0x52f77c['tagToQueryMap']['delete'](_0x572702);}}}function td(){return zu++;}function nd(_0x2e8990,_0xf25176,_0x2938b3){const _0x3c48e7=_0xf25176['_path'],_0x5bae6f=Wt(_0x2e8990,_0xf25176),_0x32dc16=ea(_0x2e8990,_0x2938b3),_0x31e6fb=_0x2e8990['listenProvider_']['startListening'](kt(_0xf25176),_0x5bae6f,_0x32dc16['hashFn'],_0x32dc16['onComplete']),_0xceab10=_0x2e8990['syncPointTree_']['subtree'](_0x3c48e7);if(_0x5bae6f)f(!Se(_0xceab10['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x1a6788=_0xceab10['fold']((_0x3b688f,_0x3a466d,_0x56d3c4)=>{if(!v(_0x3b688f)&&_0x3a466d&&Se(_0x3a466d))return[Bn(_0x3a466d)['query']];{let _0x2d03e5=[];return _0x3a466d&&(_0x2d03e5=_0x2d03e5['concat'](Ko(_0x3a466d)['map'](_0x2891ef=>_0x2891ef['query']))),x(_0x56d3c4,(_0x19211d,_0x2157a5)=>{_0x2d03e5=_0x2d03e5['concat'](_0x2157a5);}),_0x2d03e5;}});for(let _0x46c5e1=0x0;_0x46c5e1<_0x1a6788['length'];++_0x46c5e1){const _0x5c4c17=_0x1a6788[_0x46c5e1];_0x2e8990['listenProvider_']['stopListening'](kt(_0x5c4c17),Wt(_0x2e8990,_0x5c4c17));}}return _0x31e6fb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x4810b8){this['node_']=_0x4810b8;}['getImmediateChild'](_0x246200){const _0xe79b08=this['node_']['getImmediateChild'](_0x246200);return new us(_0xe79b08);}['node'](){return this['node_'];}}class ds{constructor(_0x517b23,_0x1a19b6){this['syncTree_']=_0x517b23,this['path_']=_0x1a19b6;}['getImmediateChild'](_0x36667c){const _0xcdcb85=k(this['path_'],_0x36667c);return new ds(this['syncTree_'],_0xcdcb85);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x245bb6){return _0x245bb6=_0x245bb6||{},_0x245bb6['timestamp']=_0x245bb6['timestamp']||new Date()['getTime'](),_0x245bb6;},_r=function(_0x3a3edf,_0x584fc1,_0x332729){if(!_0x3a3edf||typeof _0x3a3edf!='object')return _0x3a3edf;if(f('.sv'in _0x3a3edf,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3a3edf['.sv']=='string')return sd(_0x3a3edf['.sv'],_0x584fc1,_0x332729);if(typeof _0x3a3edf['.sv']=='object')return rd(_0x3a3edf['.sv'],_0x584fc1);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3a3edf,null,0x2));},sd=function(_0x38e33e,_0x517979,_0xd7a73a){switch(_0x38e33e){case'timestamp':return _0xd7a73a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x38e33e);}},rd=function(_0x4e79ba,_0x3c0768,_0xe398d1){_0x4e79ba['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4e79ba,null,0x2));const _0x185485=_0x4e79ba['increment'];typeof _0x185485!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x185485);const _0x36f1e2=_0x3c0768['node']();if(f(_0x36f1e2!==null&&typeof _0x36f1e2<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x36f1e2['isLeafNode']())return _0x185485;const _0x42ed98=_0x36f1e2['getValue']();return typeof _0x42ed98!='number'?_0x185485:_0x42ed98+_0x185485;},ta=function(_0x57600f,_0x11dde4,_0x2f3b28,_0x181b57){return ps(_0x11dde4,new ds(_0x2f3b28,_0x57600f),_0x181b57);},fs=function(_0x4c531c,_0x28ae96,_0x3d67a6){return ps(_0x4c531c,new us(_0x28ae96),_0x3d67a6);};function ps(_0x31c000,_0x1ddca4,_0x4c8936){const _0x4817bb=_0x31c000['getPriority']()['val'](),_0x9db1c8=_r(_0x4817bb,_0x1ddca4['getImmediateChild']('.priority'),_0x4c8936);let _0x22e929;if(_0x31c000['isLeafNode']()){const _0x150b9d=_0x31c000,_0x1708f3=_r(_0x150b9d['getValue'](),_0x1ddca4,_0x4c8936);return _0x1708f3!==_0x150b9d['getValue']()||_0x9db1c8!==_0x150b9d['getPriority']()['val']()?new D(_0x1708f3,A(_0x9db1c8)):_0x31c000;}else{const _0x32bdad=_0x31c000;return _0x22e929=_0x32bdad,_0x9db1c8!==_0x32bdad['getPriority']()['val']()&&(_0x22e929=_0x22e929['updatePriority'](new D(_0x9db1c8))),_0x32bdad['forEachChild'](R,(_0x25588e,_0x54d212)=>{const _0x3bae36=ps(_0x54d212,_0x1ddca4['getImmediateChild'](_0x25588e),_0x4c8936);_0x3bae36!==_0x54d212&&(_0x22e929=_0x22e929['updateImmediateChild'](_0x25588e,_0x3bae36));}),_0x22e929;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x51cd86='',_0x517983=null,_0x5ca0ea={'children':{},'childCount':0x0}){this['name']=_0x51cd86,this['parent']=_0x517983,this['node']=_0x5ca0ea;}}function $n(_0x258918,_0x5d271b){let _0x36f570=_0x5d271b instanceof C?_0x5d271b:new C(_0x5d271b),_0x227e49=_0x258918,_0x1a0790=y(_0x36f570);for(;_0x1a0790!==null;){const _0x3c0335=Le(_0x227e49['node']['children'],_0x1a0790)||{'children':{},'childCount':0x0};_0x227e49=new _s(_0x1a0790,_0x227e49,_0x3c0335),_0x36f570=S(_0x36f570),_0x1a0790=y(_0x36f570);}return _0x227e49;}function je(_0xaa4520){return _0xaa4520['node']['value'];}function gs(_0x14ed70,_0x291bb6){_0x14ed70['node']['value']=_0x291bb6,Oi(_0x14ed70);}function na(_0x564f6d){return _0x564f6d['node']['childCount']>0x0;}function od(_0x11093b){return je(_0x11093b)===void 0x0&&!na(_0x11093b);}function Gn(_0x5e864e,_0xf5b0fd){x(_0x5e864e['node']['children'],(_0x5915bd,_0x104cf3)=>{_0xf5b0fd(new _s(_0x5915bd,_0x5e864e,_0x104cf3));});}function ia(_0x1471dd,_0x18e9f2,_0x26542c,_0x10e238){_0x26542c&&_0x18e9f2(_0x1471dd),Gn(_0x1471dd,_0x5c1889=>{ia(_0x5c1889,_0x18e9f2,!0x0);});}function ad(_0x3239b9,_0x421978,_0x4979c6){let _0x50d825=_0x3239b9['parent'];for(;_0x50d825!==null;){if(_0x421978(_0x50d825))return!0x0;_0x50d825=_0x50d825['parent'];}return!0x1;}function Qt(_0x4cdbd9){return new C(_0x4cdbd9['parent']===null?_0x4cdbd9['name']:Qt(_0x4cdbd9['parent'])+'/'+_0x4cdbd9['name']);}function Oi(_0x1ab0dc){_0x1ab0dc['parent']!==null&&cd(_0x1ab0dc['parent'],_0x1ab0dc['name'],_0x1ab0dc);}function cd(_0x2bc72f,_0x3fe2ee,_0x1eebb1){const _0x2ab55d=od(_0x1eebb1),_0x31e50e=Q(_0x2bc72f['node']['children'],_0x3fe2ee);_0x2ab55d&&_0x31e50e?(delete _0x2bc72f['node']['children'][_0x3fe2ee],_0x2bc72f['node']['childCount']--,Oi(_0x2bc72f)):!_0x2ab55d&&!_0x31e50e&&(_0x2bc72f['node']['children'][_0x3fe2ee]=_0x1eebb1['node'],_0x2bc72f['node']['childCount']++,Oi(_0x2bc72f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x38f93a){return typeof _0x38f93a=='string'&&_0x38f93a['length']!==0x0&&!ld['test'](_0x38f93a);},sa=function(_0x2db8e3){return typeof _0x2db8e3=='string'&&_0x2db8e3['length']!==0x0&&!hd['test'](_0x2db8e3);},ud=function(_0x556bbb){return _0x556bbb&&(_0x556bbb=_0x556bbb['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x556bbb);},Bt=function(_0x31fcfd){return _0x31fcfd===null||typeof _0x31fcfd=='string'||typeof _0x31fcfd=='number'&&!xn(_0x31fcfd)||_0x31fcfd&&typeof _0x31fcfd=='object'&&Q(_0x31fcfd,'.sv');},He=function(_0x5a5e28,_0x2a7d4a,_0x3d3746,_0x5af16c){_0x5af16c&&_0x2a7d4a===void 0x0||Jt(it(_0x5a5e28,'value'),_0x2a7d4a,_0x3d3746);},Jt=function(_0x1b52dc,_0xbcc3eb,_0x39a0c1){const _0x1dbcdd=_0x39a0c1 instanceof C?new Ah(_0x39a0c1,_0x1b52dc):_0x39a0c1;if(_0xbcc3eb===void 0x0)throw new Error(_0x1b52dc+'contains\x20undefined\x20'+Oe(_0x1dbcdd));if(typeof _0xbcc3eb=='function')throw new Error(_0x1b52dc+'contains\x20a\x20function\x20'+Oe(_0x1dbcdd)+'\x20with\x20contents\x20=\x20'+_0xbcc3eb['toString']());if(xn(_0xbcc3eb))throw new Error(_0x1b52dc+'contains\x20'+_0xbcc3eb['toString']()+'\x20'+Oe(_0x1dbcdd));if(typeof _0xbcc3eb=='string'&&_0xbcc3eb['length']>ui/0x3&&Ln(_0xbcc3eb)>ui)throw new Error(_0x1b52dc+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x1dbcdd)+'\x20(\x27'+_0xbcc3eb['substring'](0x0,0x32)+'...\x27)');if(_0xbcc3eb&&typeof _0xbcc3eb=='object'){let _0x2e758b=!0x1,_0x2b1df8=!0x1;if(x(_0xbcc3eb,(_0x3b7b7c,_0x44cf6f)=>{if(_0x3b7b7c==='.value')_0x2e758b=!0x0;else{if(_0x3b7b7c!=='.priority'&&_0x3b7b7c!=='.sv'&&(_0x2b1df8=!0x0,!ms(_0x3b7b7c)))throw new Error(_0x1b52dc+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3b7b7c+')\x20'+Oe(_0x1dbcdd)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x1dbcdd,_0x3b7b7c),Jt(_0x1b52dc,_0x44cf6f,_0x1dbcdd),Ph(_0x1dbcdd);}),_0x2e758b&&_0x2b1df8)throw new Error(_0x1b52dc+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x1dbcdd)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x338a1f,_0x415695){let _0x7c5944,_0x5a4644;for(_0x7c5944=0x0;_0x7c5944<_0x415695['length'];_0x7c5944++){_0x5a4644=_0x415695[_0x7c5944];const _0x4bd3b4=Mt(_0x5a4644);for(let _0x16a33b=0x0;_0x16a33b<_0x4bd3b4['length'];_0x16a33b++)if(!(_0x4bd3b4[_0x16a33b]==='.priority'&&_0x16a33b===_0x4bd3b4['length']-0x1)){if(!ms(_0x4bd3b4[_0x16a33b]))throw new Error(_0x338a1f+'contains\x20an\x20invalid\x20key\x20('+_0x4bd3b4[_0x16a33b]+')\x20in\x20path\x20'+_0x5a4644['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x415695['sort'](Rh);let _0x4445b2=null;for(_0x7c5944=0x0;_0x7c5944<_0x415695['length'];_0x7c5944++){if(_0x5a4644=_0x415695[_0x7c5944],_0x4445b2!==null&&G(_0x4445b2,_0x5a4644))throw new Error(_0x338a1f+'contains\x20a\x20path\x20'+_0x4445b2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5a4644['toString']());_0x4445b2=_0x5a4644;}},ra=function(_0x1c04ed,_0x1f87db,_0x24f4cd,_0x3d6c38){const _0x31d8fe=it(_0x1c04ed,'values');if(!(_0x1f87db&&typeof _0x1f87db=='object')||Array['isArray'](_0x1f87db))throw new Error(_0x31d8fe+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2c1ea9=[];x(_0x1f87db,(_0x46c8e0,_0x69e553)=>{const _0x11d433=new C(_0x46c8e0);if(Jt(_0x31d8fe,_0x69e553,k(_0x24f4cd,_0x11d433)),ji(_0x11d433)==='.priority'&&!Bt(_0x69e553))throw new Error(_0x31d8fe+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x11d433['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2c1ea9['push'](_0x11d433);}),dd(_0x31d8fe,_0x2c1ea9);},fd=function(_0xa85936,_0x41db42,_0x1135c5){if(xn(_0x41db42))throw new Error(it(_0xa85936,'priority')+'is\x20'+_0x41db42['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x41db42))throw new Error(it(_0xa85936,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x318a81,_0x56d0af,_0x5ab722,_0x1ac9e0){if(!sa(_0x5ab722))throw new Error(it(_0x318a81,_0x56d0af)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5ab722+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x2870c9,_0x3bccaa,_0x53ad3c,_0x3c03f7){_0x53ad3c&&(_0x53ad3c=_0x53ad3c['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x2870c9,_0x3bccaa,_0x53ad3c);},Me=function(_0x29c646,_0x1c6568){if(y(_0x1c6568)==='.info')throw new Error(_0x29c646+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x4efaa6,_0x52c3b2){const _0x3d3f8b=_0x52c3b2['path']['toString']();if(typeof _0x52c3b2['repoInfo']['host']!='string'||_0x52c3b2['repoInfo']['host']['length']===0x0||!ms(_0x52c3b2['repoInfo']['namespace'])&&_0x52c3b2['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3d3f8b['length']!==0x0&&!ud(_0x3d3f8b))throw new Error(it(_0x4efaa6,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x5e399b,_0x44c03b){let _0x5f2662=null;for(let _0x55704d=0x0;_0x55704d<_0x44c03b['length'];_0x55704d++){const _0x38a3bc=_0x44c03b[_0x55704d],_0x9f8001=_0x38a3bc['getPath']();_0x5f2662!==null&&!Ki(_0x9f8001,_0x5f2662['path'])&&(_0x5e399b['eventLists_']['push'](_0x5f2662),_0x5f2662=null),_0x5f2662===null&&(_0x5f2662={'events':[],'path':_0x9f8001}),_0x5f2662['events']['push'](_0x38a3bc);}_0x5f2662&&_0x5e399b['eventLists_']['push'](_0x5f2662);}function oa(_0x11e33e,_0x31ad85,_0x22c120){qn(_0x11e33e,_0x22c120),aa(_0x11e33e,_0x132e99=>Ki(_0x132e99,_0x31ad85));}function V(_0xf2552a,_0x29f0a9,_0x1796d2){qn(_0xf2552a,_0x1796d2),aa(_0xf2552a,_0x44e0b9=>G(_0x44e0b9,_0x29f0a9)||G(_0x29f0a9,_0x44e0b9));}function aa(_0x3f18c6,_0x495203){_0x3f18c6['recursionDepth_']++;let _0x365253=!0x0;for(let _0x2e4303=0x0;_0x2e4303<_0x3f18c6['eventLists_']['length'];_0x2e4303++){const _0x1fff35=_0x3f18c6['eventLists_'][_0x2e4303];if(_0x1fff35){const _0x8bd9c9=_0x1fff35['path'];_0x495203(_0x8bd9c9)?(md(_0x3f18c6['eventLists_'][_0x2e4303]),_0x3f18c6['eventLists_'][_0x2e4303]=null):_0x365253=!0x1;}}_0x365253&&(_0x3f18c6['eventLists_']=[]),_0x3f18c6['recursionDepth_']--;}function md(_0x19d30a){for(let _0x22628c=0x0;_0x22628c<_0x19d30a['events']['length'];_0x22628c++){const _0x507515=_0x19d30a['events'][_0x22628c];if(_0x507515!==null){_0x19d30a['events'][_0x22628c]=null;const _0x5288b4=_0x507515['getEventRunner']();St&&L('event:\x20'+_0x507515['toString']()),ft(_0x5288b4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x21e8d6,_0x127695,_0x257388,_0x5c8da2){this['repoInfo_']=_0x21e8d6,this['forceRestClient_']=_0x127695,this['authTokenProvider_']=_0x257388,this['appCheckProvider_']=_0x5c8da2,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4a2d2d,_0x51491c,_0x2ff536){if(_0x4a2d2d['stats_']=qi(_0x4a2d2d['repoInfo_']),_0x4a2d2d['forceRestClient_']||Xl())_0x4a2d2d['server_']=new vn(_0x4a2d2d['repoInfo_'],(_0x5ef4a0,_0x53e16e,_0x483e7d,_0xfa58c9)=>{gr(_0x4a2d2d,_0x5ef4a0,_0x53e16e,_0x483e7d,_0xfa58c9);},_0x4a2d2d['authTokenProvider_'],_0x4a2d2d['appCheckProvider_']),setTimeout(()=>mr(_0x4a2d2d,!0x0),0x0);else{if(typeof _0x2ff536<'u'&&_0x2ff536!==null){if(typeof _0x2ff536!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2ff536);}catch(_0x54008a){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x54008a);}}_0x4a2d2d['persistentConnection_']=new se(_0x4a2d2d['repoInfo_'],_0x51491c,(_0x303917,_0x47ac72,_0x53578b,_0xf84ddb)=>{gr(_0x4a2d2d,_0x303917,_0x47ac72,_0x53578b,_0xf84ddb);},_0x1bfc72=>{mr(_0x4a2d2d,_0x1bfc72);},_0x529c9b=>{Id(_0x4a2d2d,_0x529c9b);},_0x4a2d2d['authTokenProvider_'],_0x4a2d2d['appCheckProvider_'],_0x2ff536),_0x4a2d2d['server_']=_0x4a2d2d['persistentConnection_'];}_0x4a2d2d['authTokenProvider_']['addTokenChangeListener'](_0x1b0325=>{_0x4a2d2d['server_']['refreshAuthToken'](_0x1b0325);}),_0x4a2d2d['appCheckProvider_']['addTokenChangeListener'](_0x4c45ac=>{_0x4a2d2d['server_']['refreshAppCheckToken'](_0x4c45ac['token']);}),_0x4a2d2d['statsReporter_']=ih(_0x4a2d2d['repoInfo_'],()=>new iu(_0x4a2d2d['stats_'],_0x4a2d2d['server_'])),_0x4a2d2d['infoData_']=new Xh(),_0x4a2d2d['infoSyncTree_']=new pr({'startListening':(_0x450aeb,_0x31374f,_0x499256,_0x283b2f)=>{let _0xc092c8=[];const _0x213ff7=_0x4a2d2d['infoData_']['getNode'](_0x450aeb['_path']);return _0x213ff7['isEmpty']()||(_0xc092c8=Yt(_0x4a2d2d['infoSyncTree_'],_0x450aeb['_path'],_0x213ff7),setTimeout(()=>{_0x283b2f('ok');},0x0)),_0xc092c8;},'stopListening':()=>{}}),vs(_0x4a2d2d,'connected',!0x1),_0x4a2d2d['serverSyncTree_']=new pr({'startListening':(_0x2117ff,_0x4dc315,_0x226983,_0x4f5c52)=>(_0x4a2d2d['server_']['listen'](_0x2117ff,_0x226983,_0x4dc315,(_0x57798f,_0x5b13d1)=>{const _0xc800c9=_0x4f5c52(_0x57798f,_0x5b13d1);V(_0x4a2d2d['eventQueue_'],_0x2117ff['_path'],_0xc800c9);}),[]),'stopListening':(_0x5eb24d,_0x262c4d)=>{_0x4a2d2d['server_']['unlisten'](_0x5eb24d,_0x262c4d);}});}function la(_0x1b998d){const _0x1721a5=_0x1b998d['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1721a5;}function Xt(_0x2de340){return id({'timestamp':la(_0x2de340)});}function gr(_0x1e846e,_0x30f127,_0x8d773c,_0x1788f0,_0xe12955){_0x1e846e['dataUpdateCount']++;const _0x3360d3=new C(_0x30f127);_0x8d773c=_0x1e846e['interceptServerDataCallback_']?_0x1e846e['interceptServerDataCallback_'](_0x30f127,_0x8d773c):_0x8d773c;let _0x202997=[];if(_0xe12955){if(_0x1788f0){const _0x229b18=_n(_0x8d773c,_0x184dec=>A(_0x184dec));_0x202997=Ju(_0x1e846e['serverSyncTree_'],_0x3360d3,_0x229b18,_0xe12955);}else{const _0x29a728=A(_0x8d773c);_0x202997=Jo(_0x1e846e['serverSyncTree_'],_0x3360d3,_0x29a728,_0xe12955);}}else{if(_0x1788f0){const _0x410a48=_n(_0x8d773c,_0x539d83=>A(_0x539d83));_0x202997=Ku(_0x1e846e['serverSyncTree_'],_0x3360d3,_0x410a48);}else{const _0x8f4b8e=A(_0x8d773c);_0x202997=Yt(_0x1e846e['serverSyncTree_'],_0x3360d3,_0x8f4b8e);}}let _0x54be0b=_0x3360d3;_0x202997['length']>0x0&&(_0x54be0b=ct(_0x1e846e,_0x3360d3)),V(_0x1e846e['eventQueue_'],_0x54be0b,_0x202997);}function mr(_0x151be0,_0x3ea615){vs(_0x151be0,'connected',_0x3ea615),_0x3ea615===!0x1&&Sd(_0x151be0);}function Id(_0x4210ab,_0x27e648){x(_0x27e648,(_0x570a13,_0x27dd9c)=>{vs(_0x4210ab,_0x570a13,_0x27dd9c);});}function vs(_0x28a56d,_0x364afd,_0x21b2d2){const _0x4484e4=new C('/.info/'+_0x364afd),_0x43ec14=A(_0x21b2d2);_0x28a56d['infoData_']['updateSnapshot'](_0x4484e4,_0x43ec14);const _0x4c77e4=Yt(_0x28a56d['infoSyncTree_'],_0x4484e4,_0x43ec14);V(_0x28a56d['eventQueue_'],_0x4484e4,_0x4c77e4);}function zn(_0x35351e){return _0x35351e['nextWriteId_']++;}function wd(_0xed0fd6,_0x48dfb8,_0x1dbb79){const _0x3041bc=Xu(_0xed0fd6['serverSyncTree_'],_0x48dfb8);return _0x3041bc!=null?Promise['resolve'](_0x3041bc):_0xed0fd6['server_']['get'](_0x48dfb8)['then'](_0xad0b93=>{const _0x529a7a=A(_0xad0b93)['withIndex'](_0x48dfb8['_queryParams']['getIndex']());Ni(_0xed0fd6['serverSyncTree_'],_0x48dfb8,_0x1dbb79,!0x0);let _0x4c225d;if(_0x48dfb8['_queryParams']['loadsAllData']())_0x4c225d=Yt(_0xed0fd6['serverSyncTree_'],_0x48dfb8['_path'],_0x529a7a);else{const _0x462391=Wt(_0xed0fd6['serverSyncTree_'],_0x48dfb8);_0x4c225d=Jo(_0xed0fd6['serverSyncTree_'],_0x48dfb8['_path'],_0x529a7a,_0x462391);}return V(_0xed0fd6['eventQueue_'],_0x48dfb8['_path'],_0x4c225d),An(_0xed0fd6['serverSyncTree_'],_0x48dfb8,_0x1dbb79,null,!0x0),_0x529a7a;},_0x4229b5=>(gt(_0xed0fd6,'get\x20for\x20query\x20'+O(_0x48dfb8)+'\x20failed:\x20'+_0x4229b5),Promise['reject'](new Error(_0x4229b5))));}function Cd(_0x165ae2,_0x58f62a,_0x40ed41,_0x3273c2,_0x1ebbf2){gt(_0x165ae2,'set',{'path':_0x58f62a['toString'](),'value':_0x40ed41,'priority':_0x3273c2});const _0x7c7a7a=Xt(_0x165ae2),_0x56d977=A(_0x40ed41,_0x3273c2),_0x303192=Vn(_0x165ae2['serverSyncTree_'],_0x58f62a),_0x389917=fs(_0x56d977,_0x303192,_0x7c7a7a),_0x4afae2=zn(_0x165ae2),_0x35cb7f=as(_0x165ae2['serverSyncTree_'],_0x58f62a,_0x389917,_0x4afae2,!0x0);qn(_0x165ae2['eventQueue_'],_0x35cb7f),_0x165ae2['server_']['put'](_0x58f62a['toString'](),_0x56d977['val'](!0x0),(_0x489cb1,_0x50f89f)=>{const _0xc3da5a=_0x489cb1==='ok';_0xc3da5a||U('set\x20at\x20'+_0x58f62a+'\x20failed:\x20'+_0x489cb1);const _0x4ae933=_e(_0x165ae2['serverSyncTree_'],_0x4afae2,!_0xc3da5a);V(_0x165ae2['eventQueue_'],_0x58f62a,_0x4ae933),be(_0x165ae2,_0x1ebbf2,_0x489cb1,_0x50f89f);});const _0x519002=Is(_0x165ae2,_0x58f62a);ct(_0x165ae2,_0x519002),V(_0x165ae2['eventQueue_'],_0x519002,[]);}function Td(_0xc86aa6,_0x5169ab,_0x29fde4,_0x55538f){gt(_0xc86aa6,'update',{'path':_0x5169ab['toString'](),'value':_0x29fde4});let _0x174b4d=!0x0;const _0x360a49=Xt(_0xc86aa6),_0x406248={};if(x(_0x29fde4,(_0x436620,_0x4f7f0a)=>{_0x174b4d=!0x1,_0x406248[_0x436620]=ta(k(_0x5169ab,_0x436620),A(_0x4f7f0a),_0xc86aa6['serverSyncTree_'],_0x360a49);}),_0x174b4d)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xc86aa6,_0x55538f,'ok',void 0x0);else{const _0x3334e2=zn(_0xc86aa6),_0x17feb4=ju(_0xc86aa6['serverSyncTree_'],_0x5169ab,_0x406248,_0x3334e2);qn(_0xc86aa6['eventQueue_'],_0x17feb4),_0xc86aa6['server_']['merge'](_0x5169ab['toString'](),_0x29fde4,(_0x1b2bb7,_0x10a856)=>{const _0xc7f4d3=_0x1b2bb7==='ok';_0xc7f4d3||U('update\x20at\x20'+_0x5169ab+'\x20failed:\x20'+_0x1b2bb7);const _0x54d96d=_e(_0xc86aa6['serverSyncTree_'],_0x3334e2,!_0xc7f4d3),_0x21135b=_0x54d96d['length']>0x0?ct(_0xc86aa6,_0x5169ab):_0x5169ab;V(_0xc86aa6['eventQueue_'],_0x21135b,_0x54d96d),be(_0xc86aa6,_0x55538f,_0x1b2bb7,_0x10a856);}),x(_0x29fde4,_0xaed58a=>{const _0x44299f=Is(_0xc86aa6,k(_0x5169ab,_0xaed58a));ct(_0xc86aa6,_0x44299f);}),V(_0xc86aa6['eventQueue_'],_0x5169ab,[]);}}function Sd(_0x184b3f){gt(_0x184b3f,'onDisconnectEvents');const _0x30db47=Xt(_0x184b3f),_0x53df9b=En();Si(_0x184b3f['onDisconnect_'],w(),(_0x3f1661,_0x84d64f)=>{const _0x141161=ta(_0x3f1661,_0x84d64f,_0x184b3f['serverSyncTree_'],_0x30db47);pt(_0x53df9b,_0x3f1661,_0x141161);});let _0x177b38=[];Si(_0x53df9b,w(),(_0x3d34f2,_0x2c64f3)=>{_0x177b38=_0x177b38['concat'](Yt(_0x184b3f['serverSyncTree_'],_0x3d34f2,_0x2c64f3));const _0x33e3a1=Is(_0x184b3f,_0x3d34f2);ct(_0x184b3f,_0x33e3a1);}),_0x184b3f['onDisconnect_']=En(),V(_0x184b3f['eventQueue_'],w(),_0x177b38);}function bd(_0x106828,_0x537b29,_0x240d87){_0x106828['server_']['onDisconnectCancel'](_0x537b29['toString'](),(_0x5d19fb,_0x25a4e9)=>{_0x5d19fb==='ok'&&Ti(_0x106828['onDisconnect_'],_0x537b29),be(_0x106828,_0x240d87,_0x5d19fb,_0x25a4e9);});}function yr(_0x528f01,_0x18512b,_0x29335c,_0x1426e6){const _0x4d3c9c=A(_0x29335c);_0x528f01['server_']['onDisconnectPut'](_0x18512b['toString'](),_0x4d3c9c['val'](!0x0),(_0x162e0b,_0x39ff04)=>{_0x162e0b==='ok'&&pt(_0x528f01['onDisconnect_'],_0x18512b,_0x4d3c9c),be(_0x528f01,_0x1426e6,_0x162e0b,_0x39ff04);});}function Rd(_0x37b20a,_0x249f5f,_0x9c6a77,_0x2a3d63,_0x20fa8c){const _0x2364da=A(_0x9c6a77,_0x2a3d63);_0x37b20a['server_']['onDisconnectPut'](_0x249f5f['toString'](),_0x2364da['val'](!0x0),(_0x3d68d9,_0x1fba4b)=>{_0x3d68d9==='ok'&&pt(_0x37b20a['onDisconnect_'],_0x249f5f,_0x2364da),be(_0x37b20a,_0x20fa8c,_0x3d68d9,_0x1fba4b);});}function Ad(_0x2a71a3,_0x1ae172,_0x3d84c8,_0x5f0db4){if(pn(_0x3d84c8)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2a71a3,_0x5f0db4,'ok',void 0x0);return;}_0x2a71a3['server_']['onDisconnectMerge'](_0x1ae172['toString'](),_0x3d84c8,(_0x135fb3,_0xd5d242)=>{_0x135fb3==='ok'&&x(_0x3d84c8,(_0x47b836,_0x302cb4)=>{const _0xc0f77e=A(_0x302cb4);pt(_0x2a71a3['onDisconnect_'],k(_0x1ae172,_0x47b836),_0xc0f77e);}),be(_0x2a71a3,_0x5f0db4,_0x135fb3,_0xd5d242);});}function kd(_0x2d45a7,_0x14beda,_0x45d689){let _0x1a3037;y(_0x14beda['_path'])==='.info'?_0x1a3037=Ni(_0x2d45a7['infoSyncTree_'],_0x14beda,_0x45d689):_0x1a3037=Ni(_0x2d45a7['serverSyncTree_'],_0x14beda,_0x45d689),oa(_0x2d45a7['eventQueue_'],_0x14beda['_path'],_0x1a3037);}function Pd(_0x1dca9c,_0x2f71c7,_0x109062){let _0xe6209a;y(_0x2f71c7['_path'])==='.info'?_0xe6209a=An(_0x1dca9c['infoSyncTree_'],_0x2f71c7,_0x109062):_0xe6209a=An(_0x1dca9c['serverSyncTree_'],_0x2f71c7,_0x109062),oa(_0x1dca9c['eventQueue_'],_0x2f71c7['_path'],_0xe6209a);}function ha(_0x4f3067){_0x4f3067['persistentConnection_']&&_0x4f3067['persistentConnection_']['interrupt'](ca);}function Nd(_0x5088b3){_0x5088b3['persistentConnection_']&&_0x5088b3['persistentConnection_']['resume'](ca);}function gt(_0x42910a,..._0x1407ba){let _0x32e28e='';_0x42910a['persistentConnection_']&&(_0x32e28e=_0x42910a['persistentConnection_']['id']+':'),L(_0x32e28e,..._0x1407ba);}function be(_0x3336bd,_0x27e580,_0x57d116,_0x25cc18){_0x27e580&&ft(()=>{if(_0x57d116==='ok')_0x27e580(null);else{const _0x37f054=(_0x57d116||'error')['toUpperCase']();let _0x223a97=_0x37f054;_0x25cc18&&(_0x223a97+=':\x20'+_0x25cc18);const _0x441fde=new Error(_0x223a97);_0x441fde['code']=_0x37f054,_0x27e580(_0x441fde);}});}function Od(_0x164c62,_0x1fc34e,_0x1445dc,_0x4a3361,_0x4febe0,_0x2e3009){gt(_0x164c62,'transaction\x20on\x20'+_0x1fc34e);const _0x16ebb2={'path':_0x1fc34e,'update':_0x1445dc,'onComplete':_0x4a3361,'status':null,'order':so(),'applyLocally':_0x2e3009,'retryCount':0x0,'unwatcher':_0x4febe0,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3e5039=Es(_0x164c62,_0x1fc34e,void 0x0);_0x16ebb2['currentInputSnapshot']=_0x3e5039;const _0x4ffbaf=_0x16ebb2['update'](_0x3e5039['val']());if(_0x4ffbaf===void 0x0)_0x16ebb2['unwatcher'](),_0x16ebb2['currentOutputSnapshotRaw']=null,_0x16ebb2['currentOutputSnapshotResolved']=null,_0x16ebb2['onComplete']&&_0x16ebb2['onComplete'](null,!0x1,_0x16ebb2['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4ffbaf,_0x16ebb2['path']),_0x16ebb2['status']=0x0;const _0x5ea74b=$n(_0x164c62['transactionQueueTree_'],_0x1fc34e),_0x5e62a1=je(_0x5ea74b)||[];_0x5e62a1['push'](_0x16ebb2),gs(_0x5ea74b,_0x5e62a1);let _0x3d832f;typeof _0x4ffbaf=='object'&&_0x4ffbaf!==null&&Q(_0x4ffbaf,'.priority')?(_0x3d832f=Le(_0x4ffbaf,'.priority'),f(Bt(_0x3d832f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x3d832f=(Vn(_0x164c62['serverSyncTree_'],_0x1fc34e)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x166172=Xt(_0x164c62),_0x39328f=A(_0x4ffbaf,_0x3d832f),_0x5cba78=fs(_0x39328f,_0x3e5039,_0x166172);_0x16ebb2['currentOutputSnapshotRaw']=_0x39328f,_0x16ebb2['currentOutputSnapshotResolved']=_0x5cba78,_0x16ebb2['currentWriteId']=zn(_0x164c62);const _0x23799d=as(_0x164c62['serverSyncTree_'],_0x1fc34e,_0x5cba78,_0x16ebb2['currentWriteId'],_0x16ebb2['applyLocally']);V(_0x164c62['eventQueue_'],_0x1fc34e,_0x23799d),jn(_0x164c62,_0x164c62['transactionQueueTree_']);}}function Es(_0x1bb8e1,_0x4f2d2f,_0x325a64){return Vn(_0x1bb8e1['serverSyncTree_'],_0x4f2d2f,_0x325a64)||g['EMPTY_NODE'];}function jn(_0x2a1800,_0x7a4b82=_0x2a1800['transactionQueueTree_']){if(_0x7a4b82||Kn(_0x2a1800,_0x7a4b82),je(_0x7a4b82)){const _0x3772c4=da(_0x2a1800,_0x7a4b82);f(_0x3772c4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3772c4['every'](_0x4b91f7=>_0x4b91f7['status']===0x0)&&Dd(_0x2a1800,Qt(_0x7a4b82),_0x3772c4);}else na(_0x7a4b82)&&Gn(_0x7a4b82,_0x44ceff=>{jn(_0x2a1800,_0x44ceff);});}function Dd(_0x589854,_0x57ce17,_0x2e34f4){const _0x4dae3d=_0x2e34f4['map'](_0x2809b5=>_0x2809b5['currentWriteId']),_0x381782=Es(_0x589854,_0x57ce17,_0x4dae3d);let _0x5344d5=_0x381782;const _0x40df6e=_0x381782['hash']();for(let _0x54f3c5=0x0;_0x54f3c5<_0x2e34f4['length'];_0x54f3c5++){const _0x2a5a2f=_0x2e34f4[_0x54f3c5];f(_0x2a5a2f['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2a5a2f['status']=0x1,_0x2a5a2f['retryCount']++;const _0x17d97c=F(_0x57ce17,_0x2a5a2f['path']);_0x5344d5=_0x5344d5['updateChild'](_0x17d97c,_0x2a5a2f['currentOutputSnapshotRaw']);}const _0x5b4b23=_0x5344d5['val'](!0x0),_0x3b4cfa=_0x57ce17;_0x589854['server_']['put'](_0x3b4cfa['toString'](),_0x5b4b23,_0x47d69e=>{gt(_0x589854,'transaction\x20put\x20response',{'path':_0x3b4cfa['toString'](),'status':_0x47d69e});let _0x55a2fe=[];if(_0x47d69e==='ok'){const _0x18a51c=[];for(let _0x311147=0x0;_0x311147<_0x2e34f4['length'];_0x311147++)_0x2e34f4[_0x311147]['status']=0x2,_0x55a2fe=_0x55a2fe['concat'](_e(_0x589854['serverSyncTree_'],_0x2e34f4[_0x311147]['currentWriteId'])),_0x2e34f4[_0x311147]['onComplete']&&_0x18a51c['push'](()=>_0x2e34f4[_0x311147]['onComplete'](null,!0x0,_0x2e34f4[_0x311147]['currentOutputSnapshotResolved'])),_0x2e34f4[_0x311147]['unwatcher']();Kn(_0x589854,$n(_0x589854['transactionQueueTree_'],_0x57ce17)),jn(_0x589854,_0x589854['transactionQueueTree_']),V(_0x589854['eventQueue_'],_0x57ce17,_0x55a2fe);for(let _0x1c9060=0x0;_0x1c9060<_0x18a51c['length'];_0x1c9060++)ft(_0x18a51c[_0x1c9060]);}else{if(_0x47d69e==='datastale'){for(let _0x216291=0x0;_0x216291<_0x2e34f4['length'];_0x216291++)_0x2e34f4[_0x216291]['status']===0x3?_0x2e34f4[_0x216291]['status']=0x4:_0x2e34f4[_0x216291]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3b4cfa['toString']()+'\x20failed:\x20'+_0x47d69e);for(let _0x1a175f=0x0;_0x1a175f<_0x2e34f4['length'];_0x1a175f++)_0x2e34f4[_0x1a175f]['status']=0x4,_0x2e34f4[_0x1a175f]['abortReason']=_0x47d69e;}ct(_0x589854,_0x57ce17);}},_0x40df6e);}function ct(_0x15460b,_0x158acf){const _0x319b9c=ua(_0x15460b,_0x158acf),_0x24ffed=Qt(_0x319b9c),_0x47b4f3=da(_0x15460b,_0x319b9c);return Md(_0x15460b,_0x47b4f3,_0x24ffed),_0x24ffed;}function Md(_0x50d618,_0x1c49ec,_0x4060b5){if(_0x1c49ec['length']===0x0)return;const _0x33d3af=[];let _0x4aa6f2=[];const _0x5bcefe=_0x1c49ec['filter'](_0x280265=>_0x280265['status']===0x0)['map'](_0x408b7f=>_0x408b7f['currentWriteId']);for(let _0x38044e=0x0;_0x38044e<_0x1c49ec['length'];_0x38044e++){const _0x280440=_0x1c49ec[_0x38044e],_0x49eb2c=F(_0x4060b5,_0x280440['path']);let _0x3966db=!0x1,_0x62d01d;if(f(_0x49eb2c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x280440['status']===0x4)_0x3966db=!0x0,_0x62d01d=_0x280440['abortReason'],_0x4aa6f2=_0x4aa6f2['concat'](_e(_0x50d618['serverSyncTree_'],_0x280440['currentWriteId'],!0x0));else{if(_0x280440['status']===0x0){if(_0x280440['retryCount']>=yd)_0x3966db=!0x0,_0x62d01d='maxretry',_0x4aa6f2=_0x4aa6f2['concat'](_e(_0x50d618['serverSyncTree_'],_0x280440['currentWriteId'],!0x0));else{const _0x37b391=Es(_0x50d618,_0x280440['path'],_0x5bcefe);_0x280440['currentInputSnapshot']=_0x37b391;const _0x39fe84=_0x1c49ec[_0x38044e]['update'](_0x37b391['val']());if(_0x39fe84!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x39fe84,_0x280440['path']);let _0x99a90b=A(_0x39fe84);typeof _0x39fe84=='object'&&_0x39fe84!=null&&Q(_0x39fe84,'.priority')||(_0x99a90b=_0x99a90b['updatePriority'](_0x37b391['getPriority']()));const _0x8dc64c=_0x280440['currentWriteId'],_0x85312=Xt(_0x50d618),_0x425d67=fs(_0x99a90b,_0x37b391,_0x85312);_0x280440['currentOutputSnapshotRaw']=_0x99a90b,_0x280440['currentOutputSnapshotResolved']=_0x425d67,_0x280440['currentWriteId']=zn(_0x50d618),_0x5bcefe['splice'](_0x5bcefe['indexOf'](_0x8dc64c),0x1),_0x4aa6f2=_0x4aa6f2['concat'](as(_0x50d618['serverSyncTree_'],_0x280440['path'],_0x425d67,_0x280440['currentWriteId'],_0x280440['applyLocally'])),_0x4aa6f2=_0x4aa6f2['concat'](_e(_0x50d618['serverSyncTree_'],_0x8dc64c,!0x0));}else _0x3966db=!0x0,_0x62d01d='nodata',_0x4aa6f2=_0x4aa6f2['concat'](_e(_0x50d618['serverSyncTree_'],_0x280440['currentWriteId'],!0x0));}}}V(_0x50d618['eventQueue_'],_0x4060b5,_0x4aa6f2),_0x4aa6f2=[],_0x3966db&&(_0x1c49ec[_0x38044e]['status']=0x2,function(_0x587538){setTimeout(_0x587538,Math['floor'](0x0));}(_0x1c49ec[_0x38044e]['unwatcher']),_0x1c49ec[_0x38044e]['onComplete']&&(_0x62d01d==='nodata'?_0x33d3af['push'](()=>_0x1c49ec[_0x38044e]['onComplete'](null,!0x1,_0x1c49ec[_0x38044e]['currentInputSnapshot'])):_0x33d3af['push'](()=>_0x1c49ec[_0x38044e]['onComplete'](new Error(_0x62d01d),!0x1,null))));}Kn(_0x50d618,_0x50d618['transactionQueueTree_']);for(let _0x4da227=0x0;_0x4da227<_0x33d3af['length'];_0x4da227++)ft(_0x33d3af[_0x4da227]);jn(_0x50d618,_0x50d618['transactionQueueTree_']);}function ua(_0x4795f7,_0x382fd6){let _0x274138,_0x476a71=_0x4795f7['transactionQueueTree_'];for(_0x274138=y(_0x382fd6);_0x274138!==null&&je(_0x476a71)===void 0x0;)_0x476a71=$n(_0x476a71,_0x274138),_0x382fd6=S(_0x382fd6),_0x274138=y(_0x382fd6);return _0x476a71;}function da(_0x75796a,_0x442ebb){const _0x421c3a=[];return fa(_0x75796a,_0x442ebb,_0x421c3a),_0x421c3a['sort']((_0x5664ed,_0x25e95b)=>_0x5664ed['order']-_0x25e95b['order']),_0x421c3a;}function fa(_0x2adf4b,_0x27295f,_0x1d746b){const _0x4de74e=je(_0x27295f);if(_0x4de74e){for(let _0x4126b8=0x0;_0x4126b8<_0x4de74e['length'];_0x4126b8++)_0x1d746b['push'](_0x4de74e[_0x4126b8]);}Gn(_0x27295f,_0x4f4ed0=>{fa(_0x2adf4b,_0x4f4ed0,_0x1d746b);});}function Kn(_0xab4925,_0x19bd46){const _0x3fe3a9=je(_0x19bd46);if(_0x3fe3a9){let _0x225847=0x0;for(let _0x1d049a=0x0;_0x1d049a<_0x3fe3a9['length'];_0x1d049a++)_0x3fe3a9[_0x1d049a]['status']!==0x2&&(_0x3fe3a9[_0x225847]=_0x3fe3a9[_0x1d049a],_0x225847++);_0x3fe3a9['length']=_0x225847,gs(_0x19bd46,_0x3fe3a9['length']>0x0?_0x3fe3a9:void 0x0);}Gn(_0x19bd46,_0xd59730=>{Kn(_0xab4925,_0xd59730);});}function Is(_0xa3bc7c,_0x395dcb){const _0x5cf67a=Qt(ua(_0xa3bc7c,_0x395dcb)),_0x50f163=$n(_0xa3bc7c['transactionQueueTree_'],_0x395dcb);return ad(_0x50f163,_0x1972f3=>{di(_0xa3bc7c,_0x1972f3);}),di(_0xa3bc7c,_0x50f163),ia(_0x50f163,_0xf6982f=>{di(_0xa3bc7c,_0xf6982f);}),_0x5cf67a;}function di(_0x1a4578,_0x1c3344){const _0x501aac=je(_0x1c3344);if(_0x501aac){const _0x2adf90=[];let _0x1c838b=[],_0x236e76=-0x1;for(let _0x73629=0x0;_0x73629<_0x501aac['length'];_0x73629++)_0x501aac[_0x73629]['status']===0x3||(_0x501aac[_0x73629]['status']===0x1?(f(_0x236e76===_0x73629-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x236e76=_0x73629,_0x501aac[_0x73629]['status']=0x3,_0x501aac[_0x73629]['abortReason']='set'):(f(_0x501aac[_0x73629]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x501aac[_0x73629]['unwatcher'](),_0x1c838b=_0x1c838b['concat'](_e(_0x1a4578['serverSyncTree_'],_0x501aac[_0x73629]['currentWriteId'],!0x0)),_0x501aac[_0x73629]['onComplete']&&_0x2adf90['push'](_0x501aac[_0x73629]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x236e76===-0x1?gs(_0x1c3344,void 0x0):_0x501aac['length']=_0x236e76+0x1,V(_0x1a4578['eventQueue_'],Qt(_0x1c3344),_0x1c838b);for(let _0x33276c=0x0;_0x33276c<_0x2adf90['length'];_0x33276c++)ft(_0x2adf90[_0x33276c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x51debb){let _0xd5c7a9='';const _0x5eb4a3=_0x51debb['split']('/');for(let _0x277ca6=0x0;_0x277ca6<_0x5eb4a3['length'];_0x277ca6++)if(_0x5eb4a3[_0x277ca6]['length']>0x0){let _0x1e595d=_0x5eb4a3[_0x277ca6];try{_0x1e595d=decodeURIComponent(_0x1e595d['replace'](/\+/g,'\x20'));}catch{}_0xd5c7a9+='/'+_0x1e595d;}return _0xd5c7a9;}function xd(_0x4baf30){const _0x49154c={};_0x4baf30['charAt'](0x0)==='?'&&(_0x4baf30=_0x4baf30['substring'](0x1));for(const _0x4189c0 of _0x4baf30['split']('&')){if(_0x4189c0['length']===0x0)continue;const _0x530c9b=_0x4189c0['split']('=');_0x530c9b['length']===0x2?_0x49154c[decodeURIComponent(_0x530c9b[0x0])]=decodeURIComponent(_0x530c9b[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4189c0+'\x27\x20in\x20query\x20\x27'+_0x4baf30+'\x27');}return _0x49154c;}const vr=function(_0x223a3a,_0x539e19){const _0x5de7f5=Fd(_0x223a3a),_0xf1ab9=_0x5de7f5['namespace'];_0x5de7f5['domain']==='firebase.com'&&ae(_0x5de7f5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xf1ab9||_0xf1ab9==='undefined')&&_0x5de7f5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5de7f5['secure']||$l();const _0x484a1d=_0x5de7f5['scheme']==='ws'||_0x5de7f5['scheme']==='wss';return{'repoInfo':new yo(_0x5de7f5['host'],_0x5de7f5['secure'],_0xf1ab9,_0x484a1d,_0x539e19,'',_0xf1ab9!==_0x5de7f5['subdomain']),'path':new C(_0x5de7f5['pathString'])};},Fd=function(_0x51bda7){let _0x559328='',_0x3f9a98='',_0x179219='',_0x3d6d16='',_0x358540='',_0x3d1a57=!0x0,_0x149a9e='https',_0x4b56e9=0x1bb;if(typeof _0x51bda7=='string'){let _0x190899=_0x51bda7['indexOf']('//');_0x190899>=0x0&&(_0x149a9e=_0x51bda7['substring'](0x0,_0x190899-0x1),_0x51bda7=_0x51bda7['substring'](_0x190899+0x2));let _0x247c54=_0x51bda7['indexOf']('/');_0x247c54===-0x1&&(_0x247c54=_0x51bda7['length']);let _0x1338f0=_0x51bda7['indexOf']('?');_0x1338f0===-0x1&&(_0x1338f0=_0x51bda7['length']),_0x559328=_0x51bda7['substring'](0x0,Math['min'](_0x247c54,_0x1338f0)),_0x247c54<_0x1338f0&&(_0x3d6d16=Ld(_0x51bda7['substring'](_0x247c54,_0x1338f0)));const _0x40f4a5=xd(_0x51bda7['substring'](Math['min'](_0x51bda7['length'],_0x1338f0)));_0x190899=_0x559328['indexOf'](':'),_0x190899>=0x0?(_0x3d1a57=_0x149a9e==='https'||_0x149a9e==='wss',_0x4b56e9=parseInt(_0x559328['substring'](_0x190899+0x1),0xa)):_0x190899=_0x559328['length'];const _0x47323f=_0x559328['slice'](0x0,_0x190899);if(_0x47323f['toLowerCase']()==='localhost')_0x3f9a98='localhost';else{if(_0x47323f['split']('.')['length']<=0x2)_0x3f9a98=_0x47323f;else{const _0x1eb871=_0x559328['indexOf']('.');_0x179219=_0x559328['substring'](0x0,_0x1eb871)['toLowerCase'](),_0x3f9a98=_0x559328['substring'](_0x1eb871+0x1),_0x358540=_0x179219;}}'ns'in _0x40f4a5&&(_0x358540=_0x40f4a5['ns']);}return{'host':_0x559328,'port':_0x4b56e9,'domain':_0x3f9a98,'subdomain':_0x179219,'secure':_0x3d1a57,'scheme':_0x149a9e,'pathString':_0x3d6d16,'namespace':_0x358540};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x3f867b=0x0;const _0xe5b339=[];return function(_0x1560f3){const _0x19f83c=_0x1560f3===_0x3f867b;_0x3f867b=_0x1560f3;let _0x4cd84d;const _0x111479=new Array(0x8);for(_0x4cd84d=0x7;_0x4cd84d>=0x0;_0x4cd84d--)_0x111479[_0x4cd84d]=Er['charAt'](_0x1560f3%0x40),_0x1560f3=Math['floor'](_0x1560f3/0x40);f(_0x1560f3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5e82d7=_0x111479['join']('');if(_0x19f83c){for(_0x4cd84d=0xb;_0x4cd84d>=0x0&&_0xe5b339[_0x4cd84d]===0x3f;_0x4cd84d--)_0xe5b339[_0x4cd84d]=0x0;_0xe5b339[_0x4cd84d]++;}else{for(_0x4cd84d=0x0;_0x4cd84d<0xc;_0x4cd84d++)_0xe5b339[_0x4cd84d]=Math['floor'](Math['random']()*0x40);}for(_0x4cd84d=0x0;_0x4cd84d<0xc;_0x4cd84d++)_0x5e82d7+=Er['charAt'](_0xe5b339[_0x4cd84d]);return f(_0x5e82d7['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5e82d7;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x15515e,_0x44b2a8,_0x539866,_0x4412e2){this['eventType']=_0x15515e,this['eventRegistration']=_0x44b2a8,this['snapshot']=_0x539866,this['prevName']=_0x4412e2;}['getPath'](){const _0x370f3c=this['snapshot']['ref'];return this['eventType']==='value'?_0x370f3c['_path']:_0x370f3c['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x521aa3,_0x43bbf2,_0x3e445b){this['eventRegistration']=_0x521aa3,this['error']=_0x43bbf2,this['path']=_0x3e445b;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0xac7a50,_0x1146e4){this['snapshotCallback']=_0xac7a50,this['cancelCallback']=_0x1146e4;}['onValue'](_0x990a5e,_0x3fac96){this['snapshotCallback']['call'](null,_0x990a5e,_0x3fac96);}['onCancel'](_0x3f57f5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3f57f5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1a9229){return this['snapshotCallback']===_0x1a9229['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1a9229['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1a9229['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5e16ad,_0x5b95f5){this['_repo']=_0x5e16ad,this['_path']=_0x5b95f5;}['cancel'](){const _0x44d183=new H();return bd(this['_repo'],this['_path'],_0x44d183['wrapCallback'](()=>{})),_0x44d183['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x54fe83=new H();return yr(this['_repo'],this['_path'],null,_0x54fe83['wrapCallback'](()=>{})),_0x54fe83['promise'];}['set'](_0x5e0a27){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x5e0a27,this['_path'],!0x1);const _0x58ae56=new H();return yr(this['_repo'],this['_path'],_0x5e0a27,_0x58ae56['wrapCallback'](()=>{})),_0x58ae56['promise'];}['setWithPriority'](_0x2e10be,_0x12dd7a){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x2e10be,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x12dd7a);const _0x40dd00=new H();return Rd(this['_repo'],this['_path'],_0x2e10be,_0x12dd7a,_0x40dd00['wrapCallback'](()=>{})),_0x40dd00['promise'];}['update'](_0x3f4ce5){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x3f4ce5,this['_path']);const _0x261fa4=new H();return Ad(this['_repo'],this['_path'],_0x3f4ce5,_0x261fa4['wrapCallback'](()=>{})),_0x261fa4['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0xdbf802,_0x41b87b,_0x3043b9,_0xf3c465){this['_repo']=_0xdbf802,this['_path']=_0x41b87b,this['_queryParams']=_0x3043b9,this['_orderByCalled']=_0xf3c465;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x3eee77=sr(this['_queryParams']),_0x17f37e=$i(_0x3eee77);return _0x17f37e==='{}'?'default':_0x17f37e;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1d6706){if(_0x1d6706=P(_0x1d6706),!(_0x1d6706 instanceof Ae))return!0x1;const _0x45e13c=this['_repo']===_0x1d6706['_repo'],_0x580b6c=Ki(this['_path'],_0x1d6706['_path']),_0xeecd78=this['_queryIdentifier']===_0x1d6706['_queryIdentifier'];return _0x45e13c&&_0x580b6c&&_0xeecd78;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x78d099,_0x174e4d){if(_0x78d099['_orderByCalled']===!0x0)throw new Error(_0x174e4d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x217cee){let _0x32d8bd=null,_0x3cb5af=null;if(_0x217cee['hasStart']()&&(_0x32d8bd=_0x217cee['getIndexStartValue']()),_0x217cee['hasEnd']()&&(_0x3cb5af=_0x217cee['getIndexEndValue']()),_0x217cee['getIndex']()===ve){const _0x7456bf='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2189e0='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x217cee['hasStart']()){if(_0x217cee['getIndexStartName']()!==We)throw new Error(_0x7456bf);if(typeof _0x32d8bd!='string')throw new Error(_0x2189e0);}if(_0x217cee['hasEnd']()){if(_0x217cee['getIndexEndName']()!==we)throw new Error(_0x7456bf);if(typeof _0x3cb5af!='string')throw new Error(_0x2189e0);}}else{if(_0x217cee['getIndex']()===R){if(_0x32d8bd!=null&&!Bt(_0x32d8bd)||_0x3cb5af!=null&&!Bt(_0x3cb5af))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x217cee['getIndex']()instanceof Ji||_0x217cee['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x32d8bd!=null&&typeof _0x32d8bd=='object'||_0x3cb5af!=null&&typeof _0x3cb5af=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2a253d){if(_0x2a253d['hasStart']()&&_0x2a253d['hasEnd']()&&_0x2a253d['hasLimit']()&&!_0x2a253d['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x4f0958,_0x58de60){super(_0x4f0958,_0x58de60,new Zi(),!0x1);}get['parent'](){const _0xa0acf0=Ro(this['_path']);return _0xa0acf0===null?null:new ee(this['_repo'],_0xa0acf0);}get['root'](){let _0x5b0328=this;for(;_0x5b0328['parent']!==null;)_0x5b0328=_0x5b0328['parent'];return _0x5b0328;}}class lt{constructor(_0x4b0af9,_0x25247d,_0x2d7c30){this['_node']=_0x4b0af9,this['ref']=_0x25247d,this['_index']=_0x2d7c30;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x223329){const _0x34b13=new C(_0x223329),_0x5dff3e=Vt(this['ref'],_0x223329);return new lt(this['_node']['getChild'](_0x34b13),_0x5dff3e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x507031){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x303cd0,_0x58bd94)=>_0x507031(new lt(_0x58bd94,Vt(this['ref'],_0x303cd0),R)));}['hasChild'](_0x42dce4){const _0x3770ab=new C(_0x42dce4);return!this['_node']['getChild'](_0x3770ab)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x3a845a,_0x489e3c){return _0x3a845a=P(_0x3a845a),_0x3a845a['_checkNotDeleted']('ref'),_0x489e3c!==void 0x0?Vt(_0x3a845a['_root'],_0x489e3c):_0x3a845a['_root'];}function Vt(_0x234d20,_0x3a8f26){return _0x234d20=P(_0x234d20),y(_0x234d20['_path'])===null?pd('child','path',_0x3a8f26):ys('child','path',_0x3a8f26),new ee(_0x234d20['_repo'],k(_0x234d20['_path'],_0x3a8f26));}function v_(_0x51dab3){return _0x51dab3=P(_0x51dab3),new Vd(_0x51dab3['_repo'],_0x51dab3['_path']);}function E_(_0x1802cc,_0x87229b){_0x1802cc=P(_0x1802cc),Me('push',_0x1802cc['_path']),He('push',_0x87229b,_0x1802cc['_path'],!0x0);const _0x4920a8=la(_0x1802cc['_repo']),_0x45ca65=Ud(_0x4920a8),_0x4efa88=Vt(_0x1802cc,_0x45ca65),_0x3bad7d=Vt(_0x1802cc,_0x45ca65);let _0x47c45a;return _0x87229b!=null?_0x47c45a=Hd(_0x3bad7d,_0x87229b)['then'](()=>_0x3bad7d):_0x47c45a=Promise['resolve'](_0x3bad7d),_0x4efa88['then']=_0x47c45a['then']['bind'](_0x47c45a),_0x4efa88['catch']=_0x47c45a['then']['bind'](_0x47c45a,void 0x0),_0x4efa88;}function Hd(_0x324bf8,_0x228914){_0x324bf8=P(_0x324bf8),Me('set',_0x324bf8['_path']),He('set',_0x228914,_0x324bf8['_path'],!0x1);const _0x3999cd=new H();return Cd(_0x324bf8['_repo'],_0x324bf8['_path'],_0x228914,null,_0x3999cd['wrapCallback'](()=>{})),_0x3999cd['promise'];}function I_(_0x4c8038,_0x2525ad){ra('update',_0x2525ad,_0x4c8038['_path']);const _0x1463d4=new H();return Td(_0x4c8038['_repo'],_0x4c8038['_path'],_0x2525ad,_0x1463d4['wrapCallback'](()=>{})),_0x1463d4['promise'];}function w_(_0x5920e8){_0x5920e8=P(_0x5920e8);const _0x468722=new pa(()=>{}),_0x218101=new Qn(_0x468722);return wd(_0x5920e8['_repo'],_0x5920e8,_0x218101)['then'](_0x5b9c34=>new lt(_0x5b9c34,new ee(_0x5920e8['_repo'],_0x5920e8['_path']),_0x5920e8['_queryParams']['getIndex']()));}class Qn{constructor(_0x154119){this['callbackContext']=_0x154119;}['respondsTo'](_0x5526c8){return _0x5526c8==='value';}['createEvent'](_0x4f7553,_0x6e9399){const _0x399252=_0x6e9399['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4f7553['snapshotNode'],new ee(_0x6e9399['_repo'],_0x6e9399['_path']),_0x399252));}['getEventRunner'](_0x572696){return _0x572696['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x572696['error']):()=>this['callbackContext']['onValue'](_0x572696['snapshot'],null);}['createCancelEvent'](_0x14b2fd,_0x44f084){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x14b2fd,_0x44f084):null;}['matches'](_0xdade0b){return _0xdade0b instanceof Qn?!_0xdade0b['callbackContext']||!this['callbackContext']?!0x0:_0xdade0b['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x4a2591,_0xd62061,_0x1e17b1,_0x5734d9,_0x52e2ac){const _0x15536e=new pa(_0x1e17b1,void 0x0),_0x100da5=new Qn(_0x15536e);return kd(_0x4a2591['_repo'],_0x4a2591,_0x100da5),()=>Pd(_0x4a2591['_repo'],_0x4a2591,_0x100da5);}function Gd(_0x58614f,_0x371174,_0x120fd2,_0x2cd943){return $d(_0x58614f,'value',_0x371174);}class mt{}class ma extends mt{constructor(_0x9383e5,_0x20fd59){super(),this['_value']=_0x9383e5,this['_key']=_0x20fd59,this['type']='endAt';}['_apply'](_0x26f012){He('endAt',this['_value'],_0x26f012['_path'],!0x0);const _0x4b766f=Jh(_0x26f012['_queryParams'],this['_value'],this['_key']);if(ga(_0x4b766f),Yn(_0x4b766f),_0x26f012['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x26f012['_repo'],_0x26f012['_path'],_0x4b766f,_0x26f012['_orderByCalled']);}}function C_(_0x56a7ae,_0x5a2681){return new ma(_0x56a7ae,_0x5a2681);}class ya extends mt{constructor(_0x162e73,_0x4e4589){super(),this['_value']=_0x162e73,this['_key']=_0x4e4589,this['type']='startAt';}['_apply'](_0x2df694){He('startAt',this['_value'],_0x2df694['_path'],!0x0);const _0x50e7ac=Qh(_0x2df694['_queryParams'],this['_value'],this['_key']);if(ga(_0x50e7ac),Yn(_0x50e7ac),_0x2df694['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x2df694['_repo'],_0x2df694['_path'],_0x50e7ac,_0x2df694['_orderByCalled']);}}function T_(_0x1b665f=null,_0x4ac444){return new ya(_0x1b665f,_0x4ac444);}class qd extends mt{constructor(_0x560bdd){super(),this['_limit']=_0x560bdd,this['type']='limitToFirst';}['_apply'](_0x338b67){if(_0x338b67['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x338b67['_repo'],_0x338b67['_path'],Yh(_0x338b67['_queryParams'],this['_limit']),_0x338b67['_orderByCalled']);}}function S_(_0x11e42d){if(Math['floor'](_0x11e42d)!==_0x11e42d||_0x11e42d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x11e42d);}class zd extends mt{constructor(_0x52f1a6){super(),this['_path']=_0x52f1a6,this['type']='orderByChild';}['_apply'](_0x5ecaf4){_a(_0x5ecaf4,'orderByChild');const _0x4859fc=new C(this['_path']);if(v(_0x4859fc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x595801=new Ji(_0x4859fc),_0xfa1336=xo(_0x5ecaf4['_queryParams'],_0x595801);return Yn(_0xfa1336),new Ae(_0x5ecaf4['_repo'],_0x5ecaf4['_path'],_0xfa1336,!0x0);}}function b_(_0x1d7792){if(_0x1d7792==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1d7792==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1d7792==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x1d7792),new zd(_0x1d7792);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xd71cb0){_a(_0xd71cb0,'orderByKey');const _0xc7e507=xo(_0xd71cb0['_queryParams'],ve);return Yn(_0xc7e507),new Ae(_0xd71cb0['_repo'],_0xd71cb0['_path'],_0xc7e507,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x312b11,_0x1adc68){super(),this['_value']=_0x312b11,this['_key']=_0x1adc68,this['type']='equalTo';}['_apply'](_0x1655f4){if(He('equalTo',this['_value'],_0x1655f4['_path'],!0x1),_0x1655f4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1655f4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1655f4));}}function A_(_0x585ec5,_0x106e83){return new Kd(_0x585ec5,_0x106e83);}function k_(_0x1b71aa,..._0x4365fe){let _0x23879c=P(_0x1b71aa);for(const _0x2485cc of _0x4365fe)_0x23879c=_0x2485cc['_apply'](_0x23879c);return _0x23879c;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1149c7,_0x378269,_0x5940cd,_0x5a7a7c){const _0x411986=_0x378269['lastIndexOf'](':'),_0x3a5a29=_0x378269['substring'](0x0,_0x411986),_0x2a2cd9=qt(_0x3a5a29);_0x1149c7['repoInfo_']=new yo(_0x378269,_0x2a2cd9,_0x1149c7['repoInfo_']['namespace'],_0x1149c7['repoInfo_']['webSocketOnly'],_0x1149c7['repoInfo_']['nodeAdmin'],_0x1149c7['repoInfo_']['persistenceKey'],_0x1149c7['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x5940cd),_0x5a7a7c&&(_0x1149c7['authTokenProvider_']=_0x5a7a7c);}function Xd(_0x5c2631,_0x2cf401,_0x492217,_0x44e9b0,_0x1a77fb){let _0x1fac16=_0x44e9b0||_0x5c2631['options']['databaseURL'];_0x1fac16===void 0x0&&(_0x5c2631['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5c2631['options']['projectId']),_0x1fac16=_0x5c2631['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x8603ac=vr(_0x1fac16,_0x1a77fb),_0x23cb23=_0x8603ac['repoInfo'],_0x46a213;typeof process<'u'&&Bs&&(_0x46a213=Bs[Yd]),_0x46a213?(_0x1fac16='http://'+_0x46a213+'?ns='+_0x23cb23['namespace'],_0x8603ac=vr(_0x1fac16,_0x1a77fb),_0x23cb23=_0x8603ac['repoInfo']):_0x8603ac['repoInfo']['secure'];const _0x309ebe=new eh(_0x5c2631['name'],_0x5c2631['options'],_0x2cf401);_d('Invalid\x20Firebase\x20Database\x20URL',_0x8603ac),v(_0x8603ac['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1bc32e=ef(_0x23cb23,_0x5c2631,_0x309ebe,new Zl(_0x5c2631,_0x492217));return new tf(_0x1bc32e,_0x5c2631);}function Zd(_0x27656e,_0x1a9954){const _0x161897=Di[_0x1a9954];(!_0x161897||_0x161897[_0x27656e['key']]!==_0x27656e)&&ae('Database\x20'+_0x1a9954+'('+_0x27656e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x27656e),delete _0x161897[_0x27656e['key']];}function ef(_0x40a3b3,_0x10298a,_0x38136c,_0x13864d){let _0x45b846=Di[_0x10298a['name']];_0x45b846||(_0x45b846={},Di[_0x10298a['name']]=_0x45b846);let _0x4fa8c5=_0x45b846[_0x40a3b3['toURLString']()];return _0x4fa8c5&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4fa8c5=new vd(_0x40a3b3,Qd,_0x38136c,_0x13864d),_0x45b846[_0x40a3b3['toURLString']()]=_0x4fa8c5,_0x4fa8c5;}class tf{constructor(_0xde2be7,_0x5a1c01){this['_repoInternal']=_0xde2be7,this['app']=_0x5a1c01,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x462e81){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x462e81+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x4c88b8=Zr(),_0x2f9d56){const _0x153b52=Hi(_0x4c88b8,'database')['getImmediate']({'identifier':_0x2f9d56});if(!_0x153b52['_instanceStarted']){const _0x5d3b16=hc('database');_0x5d3b16&&nf(_0x153b52,..._0x5d3b16);}return _0x153b52;}function nf(_0x3ed514,_0x3406fa,_0x46d627,_0xfeca72={}){_0x3ed514=P(_0x3ed514),_0x3ed514['_checkNotDeleted']('useEmulator');const _0x40020e=_0x3406fa+':'+_0x46d627,_0x3128ac=_0x3ed514['_repoInternal'];if(_0x3ed514['_instanceStarted']){if(_0x40020e===_0x3ed514['_repoInternal']['repoInfo_']['host']&&xe(_0xfeca72,_0x3128ac['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x32d4cc;if(_0x3128ac['repoInfo_']['nodeAdmin'])_0xfeca72['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x32d4cc=new an(an['OWNER']);else{if(_0xfeca72['mockUserToken']){const _0x1bcf89=typeof _0xfeca72['mockUserToken']=='string'?_0xfeca72['mockUserToken']:uc(_0xfeca72['mockUserToken'],_0x3ed514['app']['options']['projectId']);_0x32d4cc=new an(_0x1bcf89);}}qt(_0x3406fa)&&Qr(_0x3406fa),Jd(_0x3128ac,_0x40020e,_0xfeca72,_0x32d4cc);}function N_(_0x1befe0){_0x1befe0=P(_0x1befe0),_0x1befe0['_checkNotDeleted']('goOffline'),ha(_0x1befe0['_repo']);}function O_(_0x40b090){_0x40b090=P(_0x40b090),_0x40b090['_checkNotDeleted']('goOnline'),Nd(_0x40b090['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0xafad37){Ul(dt),st(new Fe('database',(_0x3b715f,{instanceIdentifier:_0x3c8e4e})=>{const _0x1e19fa=_0x3b715f['getProvider']('app')['getImmediate'](),_0x58cd4d=_0x3b715f['getProvider']('auth-internal'),_0x31f13f=_0x3b715f['getProvider']('app-check-internal');return Xd(_0x1e19fa,_0x58cd4d,_0x31f13f,_0x3c8e4e);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xafad37),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x739ffe,_0x155e08){this['committed']=_0x739ffe,this['snapshot']=_0x155e08;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x410d77,_0x40dfe6,_0x5aebe5){if(_0x410d77=P(_0x410d77),Me('Reference.transaction',_0x410d77['_path']),_0x410d77['key']==='.length'||_0x410d77['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x410d77['key']+'\x20is\x20a\x20read-only\x20object.';const _0x43354d=!0x0,_0xf94980=new H(),_0x550142=(_0x158119,_0x40e6e3,_0x271c82)=>{let _0x113542=null;_0x158119?_0xf94980['reject'](_0x158119):(_0x113542=new lt(_0x271c82,new ee(_0x410d77['_repo'],_0x410d77['_path']),R),_0xf94980['resolve'](new of(_0x40e6e3,_0x113542)));},_0xf9243d=Gd(_0x410d77,()=>{});return Od(_0x410d77['_repo'],_0x410d77['_path'],_0x40dfe6,_0x550142,_0xf9243d,_0x43354d),_0xf94980['promise'];}se['prototype']['simpleListen']=function(_0x2fe606,_0x7528d6){this['sendRequest']('q',{'p':_0x2fe606},_0x7528d6);},se['prototype']['echo']=function(_0x1b8af9,_0x245c0f){this['sendRequest']('echo',{'d':_0x1b8af9},_0x245c0f);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5209e9,..._0x3db311){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5209e9,..._0x3db311);}function cn(_0x195c53,..._0x209d69){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x195c53,..._0x209d69);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4c4828,..._0x430d5b){throw ws(_0x4c4828,..._0x430d5b);}function X(_0x36997d,..._0x350fc8){return ws(_0x36997d,..._0x350fc8);}function Ia(_0x465353,_0x31559a,_0x56b46c){const _0x4e50c3={...af(),[_0x31559a]:_0x56b46c};return new Gt('auth','Firebase',_0x4e50c3)['create'](_0x31559a,{'appName':_0x465353['name']});}function re(_0x5c17dc){return Ia(_0x5c17dc,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x207232,..._0x4298b7){if(typeof _0x207232!='string'){const _0x429200=_0x4298b7[0x0],_0x3cf919=[..._0x4298b7['slice'](0x1)];return _0x3cf919[0x0]&&(_0x3cf919[0x0]['appName']=_0x207232['name']),_0x207232['_errorFactory']['create'](_0x429200,..._0x3cf919);}return Ea['create'](_0x207232,..._0x4298b7);}function m(_0x13244c,_0x4a0f3f,..._0x394933){if(!_0x13244c)throw ws(_0x4a0f3f,..._0x394933);}function ne(_0x1f15d9){const _0xa8c84f='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1f15d9;throw cn(_0xa8c84f),new Error(_0xa8c84f);}function ce(_0x2a9c15,_0x1adf20){_0x2a9c15||ne(_0x1adf20);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x34ff34;return typeof self<'u'&&((_0x34ff34=self['location'])==null?void 0x0:_0x34ff34['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1e25cf;return typeof self<'u'&&((_0x1e25cf=self['location'])==null?void 0x0:_0x1e25cf['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x12a617=navigator;return _0x12a617['languages']&&_0x12a617['languages'][0x0]||_0x12a617['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x535afe,_0x7fa974){this['shortDelay']=_0x535afe,this['longDelay']=_0x7fa974,ce(_0x7fa974>_0x535afe,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x32730f,_0x4fe6a4){ce(_0x32730f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1b9ce5}=_0x32730f['emulator'];return _0x4fe6a4?''+_0x1b9ce5+(_0x4fe6a4['startsWith']('/')?_0x4fe6a4['slice'](0x1):_0x4fe6a4):_0x1b9ce5;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x46dd90,_0x2aee10,_0x5b1219){this['fetchImpl']=_0x46dd90,_0x2aee10&&(this['headersImpl']=_0x2aee10),_0x5b1219&&(this['responseImpl']=_0x5b1219);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x59b5bf,_0x13066b){return _0x59b5bf['tenantId']&&!_0x13066b['tenantId']?{..._0x13066b,'tenantId':_0x59b5bf['tenantId']}:_0x13066b;}async function Pe(_0x1a5cfd,_0x1690db,_0xc9ebdd,_0x28e4cd,_0x475456={}){return Ca(_0x1a5cfd,_0x475456,async()=>{let _0x15b2f8={},_0x2b2b8b={};_0x28e4cd&&(_0x1690db==='GET'?_0x2b2b8b=_0x28e4cd:_0x15b2f8={'body':JSON['stringify'](_0x28e4cd)});const _0x14eaaf=ut({..._0x2b2b8b,'key':_0x1a5cfd['config']['apiKey']})['slice'](0x1),_0x230d6c=await _0x1a5cfd['_getAdditionalHeaders']();_0x230d6c['Content-Type']='application/json',_0x1a5cfd['languageCode']&&(_0x230d6c['X-Firebase-Locale']=_0x1a5cfd['languageCode']);const _0x11847f={'method':_0x1690db,'headers':_0x230d6c,..._0x15b2f8};return dc()||(_0x11847f['referrerPolicy']='strict-origin-when-cross-origin'),_0x1a5cfd['emulatorConfig']&&qt(_0x1a5cfd['emulatorConfig']['host'])&&(_0x11847f['credentials']='include'),wa['fetch']()(await Ta(_0x1a5cfd,_0x1a5cfd['config']['apiHost'],_0xc9ebdd,_0x14eaaf),_0x11847f);});}async function Ca(_0xb10aa3,_0x4f000b,_0x2f5fc6){_0xb10aa3['_canInitEmulator']=!0x1;const _0x35aec0={...df,..._0x4f000b};try{const _0x81a001=new gf(_0xb10aa3),_0x182274=await Promise['race']([_0x2f5fc6(),_0x81a001['promise']]);_0x81a001['clearNetworkTimeout']();const _0x604913=await _0x182274['json']();if('needConfirmation'in _0x604913)throw on(_0xb10aa3,'account-exists-with-different-credential',_0x604913);if(_0x182274['ok']&&!('errorMessage'in _0x604913))return _0x604913;{const _0xbac3c1=_0x182274['ok']?_0x604913['errorMessage']:_0x604913['error']['message'],[_0x111267,_0x1bd076]=_0xbac3c1['split']('\x20:\x20');if(_0x111267==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0xb10aa3,'credential-already-in-use',_0x604913);if(_0x111267==='EMAIL_EXISTS')throw on(_0xb10aa3,'email-already-in-use',_0x604913);if(_0x111267==='USER_DISABLED')throw on(_0xb10aa3,'user-disabled',_0x604913);const _0x343d81=_0x35aec0[_0x111267]||_0x111267['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1bd076)throw Ia(_0xb10aa3,_0x343d81,_0x1bd076);Y(_0xb10aa3,_0x343d81);}}catch(_0x233539){if(_0x233539 instanceof Re)throw _0x233539;Y(_0xb10aa3,'network-request-failed',{'message':String(_0x233539)});}}async function en(_0x1553ec,_0x56c4d9,_0x58d331,_0x5b783f,_0x36643c={}){const _0x44d69d=await Pe(_0x1553ec,_0x56c4d9,_0x58d331,_0x5b783f,_0x36643c);return'mfaPendingCredential'in _0x44d69d&&Y(_0x1553ec,'multi-factor-auth-required',{'_serverResponse':_0x44d69d}),_0x44d69d;}async function Ta(_0x3a718e,_0x47704e,_0x3656f9,_0x599b6d){const _0x40be5b=''+_0x47704e+_0x3656f9+'?'+_0x599b6d,_0x129891=_0x3a718e,_0x3a687b=_0x129891['config']['emulator']?Cs(_0x3a718e['config'],_0x40be5b):_0x3a718e['config']['apiScheme']+'://'+_0x40be5b;return ff['includes'](_0x3656f9)&&(await _0x129891['_persistenceManagerAvailable'],_0x129891['_getPersistenceType']()==='COOKIE')?_0x129891['_getPersistence']()['_getFinalTarget'](_0x3a687b)['toString']():_0x3a687b;}function _f(_0x3f603e){switch(_0x3f603e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x256837){this['auth']=_0x256837,this['timer']=null,this['promise']=new Promise((_0x28d657,_0x11d460)=>{this['timer']=setTimeout(()=>_0x11d460(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x12ab9e,_0x598754,_0x4d7230){const _0x18e371={'appName':_0x12ab9e['name']};_0x4d7230['email']&&(_0x18e371['email']=_0x4d7230['email']),_0x4d7230['phoneNumber']&&(_0x18e371['phoneNumber']=_0x4d7230['phoneNumber']);const _0xf356ca=X(_0x12ab9e,_0x598754,_0x18e371);return _0xf356ca['customData']['_tokenResponse']=_0x4d7230,_0xf356ca;}function wr(_0x4ef8b6){return _0x4ef8b6!==void 0x0&&_0x4ef8b6['enterprise']!==void 0x0;}class mf{constructor(_0x78f86a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x78f86a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x78f86a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x78f86a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x40423e){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x153a45 of this['recaptchaEnforcementState'])if(_0x153a45['provider']&&_0x153a45['provider']===_0x40423e)return _f(_0x153a45['enforcementState']);return null;}['isProviderEnabled'](_0x19b1c8){return this['getProviderEnforcementState'](_0x19b1c8)==='ENFORCE'||this['getProviderEnforcementState'](_0x19b1c8)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5f487b,_0x2e1aac){return Pe(_0x5f487b,'GET','/v2/recaptchaConfig',ke(_0x5f487b,_0x2e1aac));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0xb1e726,_0x1a6648){return Pe(_0xb1e726,'POST','/v1/accounts:delete',_0x1a6648);}async function Pn(_0x10f6df,_0x4f3aab){return Pe(_0x10f6df,'POST','/v1/accounts:lookup',_0x4f3aab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0xd98290){if(_0xd98290)try{const _0x2d1f43=new Date(Number(_0xd98290));if(!isNaN(_0x2d1f43['getTime']()))return _0x2d1f43['toUTCString']();}catch{}}async function Ef(_0x45acef,_0x4aeacc=!0x1){const _0x5847c0=P(_0x45acef),_0x59e393=await _0x5847c0['getIdToken'](_0x4aeacc),_0x1d0d3c=Ts(_0x59e393);m(_0x1d0d3c&&_0x1d0d3c['exp']&&_0x1d0d3c['auth_time']&&_0x1d0d3c['iat'],_0x5847c0['auth'],'internal-error');const _0x48cdf3=typeof _0x1d0d3c['firebase']=='object'?_0x1d0d3c['firebase']:void 0x0,_0x11c81d=_0x48cdf3==null?void 0x0:_0x48cdf3['sign_in_provider'];return{'claims':_0x1d0d3c,'token':_0x59e393,'authTime':Pt(fi(_0x1d0d3c['auth_time'])),'issuedAtTime':Pt(fi(_0x1d0d3c['iat'])),'expirationTime':Pt(fi(_0x1d0d3c['exp'])),'signInProvider':_0x11c81d||null,'signInSecondFactor':(_0x48cdf3==null?void 0x0:_0x48cdf3['sign_in_second_factor'])||null};}function fi(_0x499e5f){return Number(_0x499e5f)*0x3e8;}function Ts(_0x3e46e9){const [_0x343bcf,_0x4a566e,_0x5a7830]=_0x3e46e9['split']('.');if(_0x343bcf===void 0x0||_0x4a566e===void 0x0||_0x5a7830===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x424821=fn(_0x4a566e);return _0x424821?JSON['parse'](_0x424821):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x53b711){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x53b711==null?void 0x0:_0x53b711['toString']()),null;}}function Cr(_0x3f0155){const _0x392b23=Ts(_0x3f0155);return m(_0x392b23,'internal-error'),m(typeof _0x392b23['exp']<'u','internal-error'),m(typeof _0x392b23['iat']<'u','internal-error'),Number(_0x392b23['exp'])-Number(_0x392b23['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x10f79a,_0x369807,_0x125282=!0x1){if(_0x125282)return _0x369807;try{return await _0x369807;}catch(_0x2df8d3){throw _0x2df8d3 instanceof Re&&If(_0x2df8d3)&&_0x10f79a['auth']['currentUser']===_0x10f79a&&await _0x10f79a['auth']['signOut'](),_0x2df8d3;}}function If({code:_0x42b10e}){return _0x42b10e==='auth/user-disabled'||_0x42b10e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0xe91ee8){this['user']=_0xe91ee8,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x269daf){if(_0x269daf){const _0x316ad2=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x316ad2;}else{this['errorBackoff']=0x7530;const _0x4717e9=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4717e9);}}['schedule'](_0x15f765=!0x1){if(!this['isRunning'])return;const _0x1a3b77=this['getInterval'](_0x15f765);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1a3b77);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4d0957){(_0x4d0957==null?void 0x0:_0x4d0957['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x2f61cd,_0x3b7e8d){this['createdAt']=_0x2f61cd,this['lastLoginAt']=_0x3b7e8d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x5c9cab){this['createdAt']=_0x5c9cab['createdAt'],this['lastLoginAt']=_0x5c9cab['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2abfc2){var _0x36cd3b;const _0x220623=_0x2abfc2['auth'],_0x3247cc=await _0x2abfc2['getIdToken'](),_0x273e8a=await Ht(_0x2abfc2,Pn(_0x220623,{'idToken':_0x3247cc}));m(_0x273e8a==null?void 0x0:_0x273e8a['users']['length'],_0x220623,'internal-error');const _0x5a5e37=_0x273e8a['users'][0x0];_0x2abfc2['_notifyReloadListener'](_0x5a5e37);const _0x594d70=(_0x36cd3b=_0x5a5e37['providerUserInfo'])!=null&&_0x36cd3b['length']?Sa(_0x5a5e37['providerUserInfo']):[],_0x72b374=Tf(_0x2abfc2['providerData'],_0x594d70),_0x3cc8d3=_0x2abfc2['isAnonymous'],_0x581d92=!(_0x2abfc2['email']&&_0x5a5e37['passwordHash'])&&!(_0x72b374!=null&&_0x72b374['length']),_0x3c5437=_0x3cc8d3?_0x581d92:!0x1,_0x4dc849={'uid':_0x5a5e37['localId'],'displayName':_0x5a5e37['displayName']||null,'photoURL':_0x5a5e37['photoUrl']||null,'email':_0x5a5e37['email']||null,'emailVerified':_0x5a5e37['emailVerified']||!0x1,'phoneNumber':_0x5a5e37['phoneNumber']||null,'tenantId':_0x5a5e37['tenantId']||null,'providerData':_0x72b374,'metadata':new Li(_0x5a5e37['createdAt'],_0x5a5e37['lastLoginAt']),'isAnonymous':_0x3c5437};Object['assign'](_0x2abfc2,_0x4dc849);}async function Cf(_0x1eb5d7){const _0x2db817=P(_0x1eb5d7);await Nn(_0x2db817),await _0x2db817['auth']['_persistUserIfCurrent'](_0x2db817),_0x2db817['auth']['_notifyListenersIfCurrent'](_0x2db817);}function Tf(_0x1b231e,_0x3d0163){return[..._0x1b231e['filter'](_0x47096b=>!_0x3d0163['some'](_0x469504=>_0x469504['providerId']===_0x47096b['providerId'])),..._0x3d0163];}function Sa(_0x174007){return _0x174007['map'](({providerId:_0x3a59eb,..._0x1f88a8})=>({'providerId':_0x3a59eb,'uid':_0x1f88a8['rawId']||'','displayName':_0x1f88a8['displayName']||null,'email':_0x1f88a8['email']||null,'phoneNumber':_0x1f88a8['phoneNumber']||null,'photoURL':_0x1f88a8['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0xb06bec,_0x7dad6e){const _0x224ccb=await Ca(_0xb06bec,{},async()=>{const _0x2151c2=ut({'grant_type':'refresh_token','refresh_token':_0x7dad6e})['slice'](0x1),{tokenApiHost:_0x563ef8,apiKey:_0x41cb3f}=_0xb06bec['config'],_0x25294b=await Ta(_0xb06bec,_0x563ef8,'/v1/token','key='+_0x41cb3f),_0x38235d=await _0xb06bec['_getAdditionalHeaders']();_0x38235d['Content-Type']='application/x-www-form-urlencoded';const _0x35e42a={'method':'POST','headers':_0x38235d,'body':_0x2151c2};return _0xb06bec['emulatorConfig']&&qt(_0xb06bec['emulatorConfig']['host'])&&(_0x35e42a['credentials']='include'),wa['fetch']()(_0x25294b,_0x35e42a);});return{'accessToken':_0x224ccb['access_token'],'expiresIn':_0x224ccb['expires_in'],'refreshToken':_0x224ccb['refresh_token']};}async function bf(_0x5d56b7,_0x3de6cd){return Pe(_0x5d56b7,'POST','/v2/accounts:revokeToken',ke(_0x5d56b7,_0x3de6cd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x212da9){m(_0x212da9['idToken'],'internal-error'),m(typeof _0x212da9['idToken']<'u','internal-error'),m(typeof _0x212da9['refreshToken']<'u','internal-error');const _0x4a9846='expiresIn'in _0x212da9&&typeof _0x212da9['expiresIn']<'u'?Number(_0x212da9['expiresIn']):Cr(_0x212da9['idToken']);this['updateTokensAndExpiration'](_0x212da9['idToken'],_0x212da9['refreshToken'],_0x4a9846);}['updateFromIdToken'](_0x5bbfaf){m(_0x5bbfaf['length']!==0x0,'internal-error');const _0x454e94=Cr(_0x5bbfaf);this['updateTokensAndExpiration'](_0x5bbfaf,null,_0x454e94);}async['getToken'](_0x4e39c3,_0x32d40f=!0x1){return!_0x32d40f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4e39c3,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4e39c3,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x450a21,_0x3b17be){const {accessToken:_0x11c109,refreshToken:_0x1ccf87,expiresIn:_0x4d725a}=await Sf(_0x450a21,_0x3b17be);this['updateTokensAndExpiration'](_0x11c109,_0x1ccf87,Number(_0x4d725a));}['updateTokensAndExpiration'](_0x4fe3b5,_0x34494e,_0x484cc6){this['refreshToken']=_0x34494e||null,this['accessToken']=_0x4fe3b5||null,this['expirationTime']=Date['now']()+_0x484cc6*0x3e8;}static['fromJSON'](_0x7eed3e,_0x53b286){const {refreshToken:_0x262f69,accessToken:_0x4455e8,expirationTime:_0xe08ac2}=_0x53b286,_0x486a03=new et();return _0x262f69&&(m(typeof _0x262f69=='string','internal-error',{'appName':_0x7eed3e}),_0x486a03['refreshToken']=_0x262f69),_0x4455e8&&(m(typeof _0x4455e8=='string','internal-error',{'appName':_0x7eed3e}),_0x486a03['accessToken']=_0x4455e8),_0xe08ac2&&(m(typeof _0xe08ac2=='number','internal-error',{'appName':_0x7eed3e}),_0x486a03['expirationTime']=_0xe08ac2),_0x486a03;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2eb229){this['accessToken']=_0x2eb229['accessToken'],this['refreshToken']=_0x2eb229['refreshToken'],this['expirationTime']=_0x2eb229['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x381eaf,_0x1dc898){m(typeof _0x381eaf=='string'||typeof _0x381eaf>'u','internal-error',{'appName':_0x1dc898});}class j{constructor({uid:_0x593897,auth:_0x1191a4,stsTokenManager:_0x1b863d,..._0x2fc1d6}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x593897,this['auth']=_0x1191a4,this['stsTokenManager']=_0x1b863d,this['accessToken']=_0x1b863d['accessToken'],this['displayName']=_0x2fc1d6['displayName']||null,this['email']=_0x2fc1d6['email']||null,this['emailVerified']=_0x2fc1d6['emailVerified']||!0x1,this['phoneNumber']=_0x2fc1d6['phoneNumber']||null,this['photoURL']=_0x2fc1d6['photoURL']||null,this['isAnonymous']=_0x2fc1d6['isAnonymous']||!0x1,this['tenantId']=_0x2fc1d6['tenantId']||null,this['providerData']=_0x2fc1d6['providerData']?[..._0x2fc1d6['providerData']]:[],this['metadata']=new Li(_0x2fc1d6['createdAt']||void 0x0,_0x2fc1d6['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3d14b0){const _0x4f1348=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x3d14b0));return m(_0x4f1348,this['auth'],'internal-error'),this['accessToken']!==_0x4f1348&&(this['accessToken']=_0x4f1348,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4f1348;}['getIdTokenResult'](_0x3c5698){return Ef(this,_0x3c5698);}['reload'](){return Cf(this);}['_assign'](_0x32207f){this!==_0x32207f&&(m(this['uid']===_0x32207f['uid'],this['auth'],'internal-error'),this['displayName']=_0x32207f['displayName'],this['photoURL']=_0x32207f['photoURL'],this['email']=_0x32207f['email'],this['emailVerified']=_0x32207f['emailVerified'],this['phoneNumber']=_0x32207f['phoneNumber'],this['isAnonymous']=_0x32207f['isAnonymous'],this['tenantId']=_0x32207f['tenantId'],this['providerData']=_0x32207f['providerData']['map'](_0x5217d8=>({..._0x5217d8})),this['metadata']['_copy'](_0x32207f['metadata']),this['stsTokenManager']['_assign'](_0x32207f['stsTokenManager']));}['_clone'](_0x47cb26){const _0x10933a=new j({...this,'auth':_0x47cb26,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x10933a['metadata']['_copy'](this['metadata']),_0x10933a;}['_onReload'](_0x2a27c3){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2a27c3,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2b20f3){this['reloadListener']?this['reloadListener'](_0x2b20f3):this['reloadUserInfo']=_0x2b20f3;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x35d822,_0x115728=!0x1){let _0x268ca8=!0x1;_0x35d822['idToken']&&_0x35d822['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x35d822),_0x268ca8=!0x0),_0x115728&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x268ca8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x288cfa=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x288cfa})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xafcd84=>({..._0xafcd84})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x567e8b,_0x23c623){const _0x3e1981=_0x23c623['displayName']??void 0x0,_0x51db66=_0x23c623['email']??void 0x0,_0x57f356=_0x23c623['phoneNumber']??void 0x0,_0x4b4e83=_0x23c623['photoURL']??void 0x0,_0x1bf6b8=_0x23c623['tenantId']??void 0x0,_0x507c67=_0x23c623['_redirectEventId']??void 0x0,_0x1902df=_0x23c623['createdAt']??void 0x0,_0x514e70=_0x23c623['lastLoginAt']??void 0x0,{uid:_0x2eefdb,emailVerified:_0x2ffa84,isAnonymous:_0x28fa4b,providerData:_0x3f7f2f,stsTokenManager:_0x25c59c}=_0x23c623;m(_0x2eefdb&&_0x25c59c,_0x567e8b,'internal-error');const _0x4074d5=et['fromJSON'](this['name'],_0x25c59c);m(typeof _0x2eefdb=='string',_0x567e8b,'internal-error'),le(_0x3e1981,_0x567e8b['name']),le(_0x51db66,_0x567e8b['name']),m(typeof _0x2ffa84=='boolean',_0x567e8b,'internal-error'),m(typeof _0x28fa4b=='boolean',_0x567e8b,'internal-error'),le(_0x57f356,_0x567e8b['name']),le(_0x4b4e83,_0x567e8b['name']),le(_0x1bf6b8,_0x567e8b['name']),le(_0x507c67,_0x567e8b['name']),le(_0x1902df,_0x567e8b['name']),le(_0x514e70,_0x567e8b['name']);const _0x778edf=new j({'uid':_0x2eefdb,'auth':_0x567e8b,'email':_0x51db66,'emailVerified':_0x2ffa84,'displayName':_0x3e1981,'isAnonymous':_0x28fa4b,'photoURL':_0x4b4e83,'phoneNumber':_0x57f356,'tenantId':_0x1bf6b8,'stsTokenManager':_0x4074d5,'createdAt':_0x1902df,'lastLoginAt':_0x514e70});return _0x3f7f2f&&Array['isArray'](_0x3f7f2f)&&(_0x778edf['providerData']=_0x3f7f2f['map'](_0x31ef15=>({..._0x31ef15}))),_0x507c67&&(_0x778edf['_redirectEventId']=_0x507c67),_0x778edf;}static async['_fromIdTokenResponse'](_0x5ec417,_0x359f07,_0x1aa64b=!0x1){const _0xc5b0a9=new et();_0xc5b0a9['updateFromServerResponse'](_0x359f07);const _0xc61b00=new j({'uid':_0x359f07['localId'],'auth':_0x5ec417,'stsTokenManager':_0xc5b0a9,'isAnonymous':_0x1aa64b});return await Nn(_0xc61b00),_0xc61b00;}static async['_fromGetAccountInfoResponse'](_0x2ba9fd,_0x3369df,_0x49dac0){const _0x2ec5d3=_0x3369df['users'][0x0];m(_0x2ec5d3['localId']!==void 0x0,'internal-error');const _0x44bd5b=_0x2ec5d3['providerUserInfo']!==void 0x0?Sa(_0x2ec5d3['providerUserInfo']):[],_0x130f7e=!(_0x2ec5d3['email']&&_0x2ec5d3['passwordHash'])&&!(_0x44bd5b!=null&&_0x44bd5b['length']),_0x500248=new et();_0x500248['updateFromIdToken'](_0x49dac0);const _0x55f3eb=new j({'uid':_0x2ec5d3['localId'],'auth':_0x2ba9fd,'stsTokenManager':_0x500248,'isAnonymous':_0x130f7e}),_0x3070ca={'uid':_0x2ec5d3['localId'],'displayName':_0x2ec5d3['displayName']||null,'photoURL':_0x2ec5d3['photoUrl']||null,'email':_0x2ec5d3['email']||null,'emailVerified':_0x2ec5d3['emailVerified']||!0x1,'phoneNumber':_0x2ec5d3['phoneNumber']||null,'tenantId':_0x2ec5d3['tenantId']||null,'providerData':_0x44bd5b,'metadata':new Li(_0x2ec5d3['createdAt'],_0x2ec5d3['lastLoginAt']),'isAnonymous':!(_0x2ec5d3['email']&&_0x2ec5d3['passwordHash'])&&!(_0x44bd5b!=null&&_0x44bd5b['length'])};return Object['assign'](_0x55f3eb,_0x3070ca),_0x55f3eb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4e1f65){ce(_0x4e1f65 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x20c986=Tr['get'](_0x4e1f65);return _0x20c986?(ce(_0x20c986 instanceof _0x4e1f65,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x20c986):(_0x20c986=new _0x4e1f65(),Tr['set'](_0x4e1f65,_0x20c986),_0x20c986);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x55f6e6,_0x5e6de1){this['storage'][_0x55f6e6]=_0x5e6de1;}async['_get'](_0x168a73){const _0x1ddd38=this['storage'][_0x168a73];return _0x1ddd38===void 0x0?null:_0x1ddd38;}async['_remove'](_0x375161){delete this['storage'][_0x375161];}['_addListener'](_0x29ed4d,_0x138718){}['_removeListener'](_0x11e6a1,_0x1862ea){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3a1c8e,_0x8d1063,_0xc5a31c){return'firebase:'+_0x3a1c8e+':'+_0x8d1063+':'+_0xc5a31c;}class tt{constructor(_0x268421,_0x268356,_0x44d950){this['persistence']=_0x268421,this['auth']=_0x268356,this['userKey']=_0x44d950;const {config:_0xc3c139,name:_0x384b5a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0xc3c139['apiKey'],_0x384b5a),this['fullPersistenceKey']=ln('persistence',_0xc3c139['apiKey'],_0x384b5a),this['boundEventHandler']=_0x268356['_onStorageEvent']['bind'](_0x268356),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2d0b58){return this['persistence']['_set'](this['fullUserKey'],_0x2d0b58['toJSON']());}async['getCurrentUser'](){const _0x17c8d1=await this['persistence']['_get'](this['fullUserKey']);if(!_0x17c8d1)return null;if(typeof _0x17c8d1=='string'){const _0x2da440=await Pn(this['auth'],{'idToken':_0x17c8d1})['catch'](()=>{});return _0x2da440?j['_fromGetAccountInfoResponse'](this['auth'],_0x2da440,_0x17c8d1):null;}return j['_fromJSON'](this['auth'],_0x17c8d1);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3d2729){if(this['persistence']===_0x3d2729)return;const _0x1d670f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3d2729,_0x1d670f)return this['setCurrentUser'](_0x1d670f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x241112,_0x40b24b,_0x26f2e5='authUser'){if(!_0x40b24b['length'])return new tt(ie(Sr),_0x241112,_0x26f2e5);const _0x12de0e=(await Promise['all'](_0x40b24b['map'](async _0x1443dd=>{if(await _0x1443dd['_isAvailable']())return _0x1443dd;})))['filter'](_0x198333=>_0x198333);let _0x3e3466=_0x12de0e[0x0]||ie(Sr);const _0x479451=ln(_0x26f2e5,_0x241112['config']['apiKey'],_0x241112['name']);let _0x3c1cdc=null;for(const _0x89db58 of _0x40b24b)try{const _0x500aa4=await _0x89db58['_get'](_0x479451);if(_0x500aa4){let _0x22a3fc;if(typeof _0x500aa4=='string'){const _0x2f5e6c=await Pn(_0x241112,{'idToken':_0x500aa4})['catch'](()=>{});if(!_0x2f5e6c)break;_0x22a3fc=await j['_fromGetAccountInfoResponse'](_0x241112,_0x2f5e6c,_0x500aa4);}else _0x22a3fc=j['_fromJSON'](_0x241112,_0x500aa4);_0x89db58!==_0x3e3466&&(_0x3c1cdc=_0x22a3fc),_0x3e3466=_0x89db58;break;}}catch{}const _0x18955d=_0x12de0e['filter'](_0x3ebfa4=>_0x3ebfa4['_shouldAllowMigration']);return!_0x3e3466['_shouldAllowMigration']||!_0x18955d['length']?new tt(_0x3e3466,_0x241112,_0x26f2e5):(_0x3e3466=_0x18955d[0x0],_0x3c1cdc&&await _0x3e3466['_set'](_0x479451,_0x3c1cdc['toJSON']()),await Promise['all'](_0x40b24b['map'](async _0x35614b=>{if(_0x35614b!==_0x3e3466)try{await _0x35614b['_remove'](_0x479451);}catch{}})),new tt(_0x3e3466,_0x241112,_0x26f2e5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2ed3c4){const _0x4882e9=_0x2ed3c4['toLowerCase']();if(_0x4882e9['includes']('opera/')||_0x4882e9['includes']('opr/')||_0x4882e9['includes']('opios/'))return'Opera';if(Pa(_0x4882e9))return'IEMobile';if(_0x4882e9['includes']('msie')||_0x4882e9['includes']('trident/'))return'IE';if(_0x4882e9['includes']('edge/'))return'Edge';if(Ra(_0x4882e9))return'Firefox';if(_0x4882e9['includes']('silk/'))return'Silk';if(Oa(_0x4882e9))return'Blackberry';if(Da(_0x4882e9))return'Webos';if(Aa(_0x4882e9))return'Safari';if((_0x4882e9['includes']('chrome/')||ka(_0x4882e9))&&!_0x4882e9['includes']('edge/'))return'Chrome';if(Na(_0x4882e9))return'Android';{const _0x554614=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x12990d=_0x2ed3c4['match'](_0x554614);if((_0x12990d==null?void 0x0:_0x12990d['length'])===0x2)return _0x12990d[0x1];}return'Other';}function Ra(_0x35ac56=W()){return/firefox\//i['test'](_0x35ac56);}function Aa(_0x2065ee=W()){const _0x490b37=_0x2065ee['toLowerCase']();return _0x490b37['includes']('safari/')&&!_0x490b37['includes']('chrome/')&&!_0x490b37['includes']('crios/')&&!_0x490b37['includes']('android');}function ka(_0x304106=W()){return/crios\//i['test'](_0x304106);}function Pa(_0x19904d=W()){return/iemobile/i['test'](_0x19904d);}function Na(_0x26b73d=W()){return/android/i['test'](_0x26b73d);}function Oa(_0x493018=W()){return/blackberry/i['test'](_0x493018);}function Da(_0x378cad=W()){return/webos/i['test'](_0x378cad);}function Ss(_0x5864ef=W()){return/iphone|ipad|ipod/i['test'](_0x5864ef)||/macintosh/i['test'](_0x5864ef)&&/mobile/i['test'](_0x5864ef);}function Rf(_0x28dbed=W()){var _0x89bf98;return Ss(_0x28dbed)&&!!((_0x89bf98=window['navigator'])!=null&&_0x89bf98['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x81c604=W()){return Ss(_0x81c604)||Na(_0x81c604)||Da(_0x81c604)||Oa(_0x81c604)||/windows phone/i['test'](_0x81c604)||Pa(_0x81c604);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x456d40,_0x31bf3f=[]){let _0x440662;switch(_0x456d40){case'Browser':_0x440662=br(W());break;case'Worker':_0x440662=br(W())+'-'+_0x456d40;break;default:_0x440662=_0x456d40;}const _0x48e3b4=_0x31bf3f['length']?_0x31bf3f['join'](','):'FirebaseCore-web';return _0x440662+'/JsCore/'+dt+'/'+_0x48e3b4;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x47447e){this['auth']=_0x47447e,this['queue']=[];}['pushCallback'](_0x30fff9,_0x3564c2){const _0x30bc29=_0x522122=>new Promise((_0x3352ed,_0x354d4a)=>{try{const _0x1a0eed=_0x30fff9(_0x522122);_0x3352ed(_0x1a0eed);}catch(_0x2dfb42){_0x354d4a(_0x2dfb42);}});_0x30bc29['onAbort']=_0x3564c2,this['queue']['push'](_0x30bc29);const _0x3579a4=this['queue']['length']-0x1;return()=>{this['queue'][_0x3579a4]=()=>Promise['resolve']();};}async['runMiddleware'](_0x406119){if(this['auth']['currentUser']===_0x406119)return;const _0x2833bc=[];try{for(const _0x5cf7aa of this['queue'])await _0x5cf7aa(_0x406119),_0x5cf7aa['onAbort']&&_0x2833bc['push'](_0x5cf7aa['onAbort']);}catch(_0x28d564){_0x2833bc['reverse']();for(const _0x546081 of _0x2833bc)try{_0x546081();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x28d564==null?void 0x0:_0x28d564['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x556294,_0x224128={}){return Pe(_0x556294,'GET','/v2/passwordPolicy',ke(_0x556294,_0x224128));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x23c5a9){var _0x22c6c3;const _0x2515e4=_0x23c5a9['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2515e4['minPasswordLength']??Nf,_0x2515e4['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2515e4['maxPasswordLength']),_0x2515e4['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2515e4['containsLowercaseCharacter']),_0x2515e4['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2515e4['containsUppercaseCharacter']),_0x2515e4['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2515e4['containsNumericCharacter']),_0x2515e4['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2515e4['containsNonAlphanumericCharacter']),this['enforcementState']=_0x23c5a9['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x22c6c3=_0x23c5a9['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x22c6c3['join'](''))??'',this['forceUpgradeOnSignin']=_0x23c5a9['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x23c5a9['schemaVersion'];}['validatePassword'](_0x1399ec){const _0x47f312={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1399ec,_0x47f312),this['validatePasswordCharacterOptions'](_0x1399ec,_0x47f312),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['meetsMinPasswordLength']??!0x0),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['meetsMaxPasswordLength']??!0x0),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['containsLowercaseLetter']??!0x0),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['containsUppercaseLetter']??!0x0),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['containsNumericCharacter']??!0x0),_0x47f312['isValid']&&(_0x47f312['isValid']=_0x47f312['containsNonAlphanumericCharacter']??!0x0),_0x47f312;}['validatePasswordLengthOptions'](_0x3e701b,_0x700ff5){const _0x44e244=this['customStrengthOptions']['minPasswordLength'],_0x4a1ca0=this['customStrengthOptions']['maxPasswordLength'];_0x44e244&&(_0x700ff5['meetsMinPasswordLength']=_0x3e701b['length']>=_0x44e244),_0x4a1ca0&&(_0x700ff5['meetsMaxPasswordLength']=_0x3e701b['length']<=_0x4a1ca0);}['validatePasswordCharacterOptions'](_0x579679,_0x40e743){this['updatePasswordCharacterOptionsStatuses'](_0x40e743,!0x1,!0x1,!0x1,!0x1);let _0x2aacbb;for(let _0x19960e=0x0;_0x19960e<_0x579679['length'];_0x19960e++)_0x2aacbb=_0x579679['charAt'](_0x19960e),this['updatePasswordCharacterOptionsStatuses'](_0x40e743,_0x2aacbb>='a'&&_0x2aacbb<='z',_0x2aacbb>='A'&&_0x2aacbb<='Z',_0x2aacbb>='0'&&_0x2aacbb<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x2aacbb));}['updatePasswordCharacterOptionsStatuses'](_0x4a06c9,_0x1a13eb,_0x26e73e,_0x4d9e29,_0x1b92a6){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4a06c9['containsLowercaseLetter']||(_0x4a06c9['containsLowercaseLetter']=_0x1a13eb)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4a06c9['containsUppercaseLetter']||(_0x4a06c9['containsUppercaseLetter']=_0x26e73e)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4a06c9['containsNumericCharacter']||(_0x4a06c9['containsNumericCharacter']=_0x4d9e29)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4a06c9['containsNonAlphanumericCharacter']||(_0x4a06c9['containsNonAlphanumericCharacter']=_0x1b92a6));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x8c4364,_0x37ea31,_0x4bd582,_0x36ab4f){this['app']=_0x8c4364,this['heartbeatServiceProvider']=_0x37ea31,this['appCheckServiceProvider']=_0x4bd582,this['config']=_0x36ab4f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x8c4364['name'],this['clientVersion']=_0x36ab4f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x94817e=>this['_resolvePersistenceManagerAvailable']=_0x94817e);}['_initializeWithPersistence'](_0x52ec9f,_0x534bfa){return _0x534bfa&&(this['_popupRedirectResolver']=ie(_0x534bfa)),this['_initializationPromise']=this['queue'](async()=>{var _0x574383,_0x2c61a0,_0x3882d9;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x52ec9f),(_0x574383=this['_resolvePersistenceManagerAvailable'])==null||_0x574383['call'](this),!this['_deleted'])){if((_0x2c61a0=this['_popupRedirectResolver'])!=null&&_0x2c61a0['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x534bfa),this['lastNotifiedUid']=((_0x3882d9=this['currentUser'])==null?void 0x0:_0x3882d9['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3139b6=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3139b6)){if(this['currentUser']&&_0x3139b6&&this['currentUser']['uid']===_0x3139b6['uid']){this['_currentUser']['_assign'](_0x3139b6),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3139b6,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x372050){try{const _0x11d0e2=await Pn(this,{'idToken':_0x372050}),_0x471811=await j['_fromGetAccountInfoResponse'](this,_0x11d0e2,_0x372050);await this['directlySetCurrentUser'](_0x471811);}catch(_0x27de9b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x27de9b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3235c7){var _0x220078;if($(this['app'])){const _0x56694b=this['app']['settings']['authIdToken'];return _0x56694b?new Promise(_0x327493=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x56694b)['then'](_0x327493,_0x327493));}):this['directlySetCurrentUser'](null);}const _0x573d8f=await this['assertedPersistence']['getCurrentUser']();let _0x2d8b42=_0x573d8f,_0x1d6599=!0x1;if(_0x3235c7&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x2a9e66=(_0x220078=this['redirectUser'])==null?void 0x0:_0x220078['_redirectEventId'],_0xf906d6=_0x2d8b42==null?void 0x0:_0x2d8b42['_redirectEventId'],_0x3c79ad=await this['tryRedirectSignIn'](_0x3235c7);(!_0x2a9e66||_0x2a9e66===_0xf906d6)&&(_0x3c79ad!=null&&_0x3c79ad['user'])&&(_0x2d8b42=_0x3c79ad['user'],_0x1d6599=!0x0);}if(!_0x2d8b42)return this['directlySetCurrentUser'](null);if(!_0x2d8b42['_redirectEventId']){if(_0x1d6599)try{await this['beforeStateQueue']['runMiddleware'](_0x2d8b42);}catch(_0x1123f9){_0x2d8b42=_0x573d8f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1123f9));}return _0x2d8b42?this['reloadAndSetCurrentUserOrClear'](_0x2d8b42):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2d8b42['_redirectEventId']?this['directlySetCurrentUser'](_0x2d8b42):this['reloadAndSetCurrentUserOrClear'](_0x2d8b42);}async['tryRedirectSignIn'](_0x375964){let _0x35306d=null;try{_0x35306d=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x375964,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x35306d;}async['reloadAndSetCurrentUserOrClear'](_0x209661){try{await Nn(_0x209661);}catch(_0x37a276){if((_0x37a276==null?void 0x0:_0x37a276['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x209661);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5a45a7){if($(this['app']))return Promise['reject'](re(this));const _0x5b4ec3=_0x5a45a7?P(_0x5a45a7):null;return _0x5b4ec3&&m(_0x5b4ec3['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5b4ec3&&_0x5b4ec3['_clone'](this));}async['_updateCurrentUser'](_0x3e0b17,_0x3d7776=!0x1){if(!this['_deleted'])return _0x3e0b17&&m(this['tenantId']===_0x3e0b17['tenantId'],this,'tenant-id-mismatch'),_0x3d7776||await this['beforeStateQueue']['runMiddleware'](_0x3e0b17),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3e0b17),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1463bd){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1463bd));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x44e2ed){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1351a8=this['_getPasswordPolicyInternal']();return _0x1351a8['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1351a8['validatePassword'](_0x44e2ed);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x43a454=await Pf(this),_0xc7a5b2=new Of(_0x43a454);this['tenantId']===null?this['_projectPasswordPolicy']=_0xc7a5b2:this['_tenantPasswordPolicies'][this['tenantId']]=_0xc7a5b2;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x49bafa){this['_errorFactory']=new Gt('auth','Firebase',_0x49bafa());}['onAuthStateChanged'](_0xe78891,_0xf1a659,_0x41131d){return this['registerStateListener'](this['authStateSubscription'],_0xe78891,_0xf1a659,_0x41131d);}['beforeAuthStateChanged'](_0x5477ec,_0xf6541b){return this['beforeStateQueue']['pushCallback'](_0x5477ec,_0xf6541b);}['onIdTokenChanged'](_0x4c8f15,_0x5f2287,_0x2af9eb){return this['registerStateListener'](this['idTokenSubscription'],_0x4c8f15,_0x5f2287,_0x2af9eb);}['authStateReady'](){return new Promise((_0x338b1d,_0xcc76cc)=>{if(this['currentUser'])_0x338b1d();else{const _0x1f8269=this['onAuthStateChanged'](()=>{_0x1f8269(),_0x338b1d();},_0xcc76cc);}});}async['revokeAccessToken'](_0x38d256){if(this['currentUser']){const _0x3672c2=await this['currentUser']['getIdToken'](),_0x449e00={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x38d256,'idToken':_0x3672c2};this['tenantId']!=null&&(_0x449e00['tenantId']=this['tenantId']),await bf(this,_0x449e00);}}['toJSON'](){var _0x3bac66;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3bac66=this['_currentUser'])==null?void 0x0:_0x3bac66['toJSON']()};}async['_setRedirectUser'](_0x4f1321,_0x47d596){const _0x4ae5a5=await this['getOrInitRedirectPersistenceManager'](_0x47d596);return _0x4f1321===null?_0x4ae5a5['removeCurrentUser']():_0x4ae5a5['setCurrentUser'](_0x4f1321);}async['getOrInitRedirectPersistenceManager'](_0x5aec7c){if(!this['redirectPersistenceManager']){const _0x1074dd=_0x5aec7c&&ie(_0x5aec7c)||this['_popupRedirectResolver'];m(_0x1074dd,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1074dd['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1141fe){var _0x42110c,_0x331946;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x42110c=this['_currentUser'])==null?void 0x0:_0x42110c['_redirectEventId'])===_0x1141fe?this['_currentUser']:((_0x331946=this['redirectUser'])==null?void 0x0:_0x331946['_redirectEventId'])===_0x1141fe?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x21a4c7){if(_0x21a4c7===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x21a4c7));}['_notifyListenersIfCurrent'](_0x615750){_0x615750===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x47c5b5;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3d5547=((_0x47c5b5=this['currentUser'])==null?void 0x0:_0x47c5b5['uid'])??null;this['lastNotifiedUid']!==_0x3d5547&&(this['lastNotifiedUid']=_0x3d5547,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x143f87,_0x580392,_0x4b2869,_0x27dd54){if(this['_deleted'])return()=>{};const _0x2e27f3=typeof _0x580392=='function'?_0x580392:_0x580392['next']['bind'](_0x580392);let _0x10107e=!0x1;const _0x45a202=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x45a202,this,'internal-error'),_0x45a202['then'](()=>{_0x10107e||_0x2e27f3(this['currentUser']);}),typeof _0x580392=='function'){const _0x3473c0=_0x143f87['addObserver'](_0x580392,_0x4b2869,_0x27dd54);return()=>{_0x10107e=!0x0,_0x3473c0();};}else{const _0x5065da=_0x143f87['addObserver'](_0x580392);return()=>{_0x10107e=!0x0,_0x5065da();};}}async['directlySetCurrentUser'](_0x44db43){this['currentUser']&&this['currentUser']!==_0x44db43&&this['_currentUser']['_stopProactiveRefresh'](),_0x44db43&&this['isProactiveRefreshEnabled']&&_0x44db43['_startProactiveRefresh'](),this['currentUser']=_0x44db43,_0x44db43?await this['assertedPersistence']['setCurrentUser'](_0x44db43):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4aec72){return this['operations']=this['operations']['then'](_0x4aec72,_0x4aec72),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x186952){!_0x186952||this['frameworks']['includes'](_0x186952)||(this['frameworks']['push'](_0x186952),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5824f4;const _0x4f0ecb={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4f0ecb['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4356e3=await((_0x5824f4=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5824f4['getHeartbeatsHeader']());_0x4356e3&&(_0x4f0ecb['X-Firebase-Client']=_0x4356e3);const _0x2b4872=await this['_getAppCheckToken']();return _0x2b4872&&(_0x4f0ecb['X-Firebase-AppCheck']=_0x2b4872),_0x4f0ecb;}async['_getAppCheckToken'](){var _0x1a9bcb;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x395a56=await((_0x1a9bcb=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1a9bcb['getToken']());return _0x395a56!=null&&_0x395a56['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x395a56['error']),_0x395a56==null?void 0x0:_0x395a56['token'];}}function Ke(_0x5b83fe){return P(_0x5b83fe);}class Rr{constructor(_0x224249){this['auth']=_0x224249,this['observer']=null,this['addObserver']=Tc(_0x2a8bc7=>this['observer']=_0x2a8bc7);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5d79e0){Jn=_0x5d79e0;}function xa(_0x4f72a1){return Jn['loadJS'](_0x4f72a1);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x8b682a){return'__'+_0x8b682a+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x3a6ec1){_0x3a6ec1();}['execute'](_0x3df366,_0x1373b5){return Promise['resolve']('token');}['render'](_0x24e280,_0x295bf8){return'';}}class Wf{['ready'](_0x445620){_0x445620();}['execute'](_0x1fbc85,_0x147d78){return Promise['resolve']('token');}['render'](_0x11be3e,_0x4cb0ac){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0xf4ddec){this['type']=Bf,this['auth']=Ke(_0xf4ddec);}async['verify'](_0x9e5ee='verify',_0x10a80b=!0x1){async function _0x5408c8(_0x12d6b8){if(!_0x10a80b){if(_0x12d6b8['tenantId']==null&&_0x12d6b8['_agentRecaptchaConfig']!=null)return _0x12d6b8['_agentRecaptchaConfig']['siteKey'];if(_0x12d6b8['tenantId']!=null&&_0x12d6b8['_tenantRecaptchaConfigs'][_0x12d6b8['tenantId']]!==void 0x0)return _0x12d6b8['_tenantRecaptchaConfigs'][_0x12d6b8['tenantId']]['siteKey'];}return new Promise(async(_0x172e7b,_0x4675b1)=>{yf(_0x12d6b8,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x18bed=>{if(_0x18bed['recaptchaKey']===void 0x0)_0x4675b1(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x17e0d0=new mf(_0x18bed);return _0x12d6b8['tenantId']==null?_0x12d6b8['_agentRecaptchaConfig']=_0x17e0d0:_0x12d6b8['_tenantRecaptchaConfigs'][_0x12d6b8['tenantId']]=_0x17e0d0,_0x172e7b(_0x17e0d0['siteKey']);}})['catch'](_0x4ab5e8=>{_0x4675b1(_0x4ab5e8);});});}function _0x5666fb(_0x4c5255,_0x42064a,_0x4badc3){const _0x346113=window['grecaptcha'];wr(_0x346113)?_0x346113['enterprise']['ready'](()=>{_0x346113['enterprise']['execute'](_0x4c5255,{'action':_0x9e5ee})['then'](_0x153757=>{_0x42064a(_0x153757);})['catch'](()=>{_0x42064a(Fa);});}):_0x4badc3(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xd5a06a,_0x53011c)=>{_0x5408c8(this['auth'])['then'](async _0x524e22=>{if(!_0x10a80b&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x5666fb(_0x524e22,_0xd5a06a,_0x53011c);else{if(typeof window>'u'){_0x53011c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x351956=Lf();_0x351956['length']!==0x0&&(_0x351956+=_0x524e22+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x255b5c;(_0x255b5c=he['scriptInjectionDeferred'])==null||_0x255b5c['resolve']();},xa(_0x351956)['then'](()=>{var _0x2d2581;return(_0x2d2581=he['scriptInjectionDeferred'])==null?void 0x0:_0x2d2581['promise'];})['then'](()=>{_0x5666fb(_0x524e22,_0xd5a06a,_0x53011c);})['catch'](_0x32625d=>{_0x53011c(_0x32625d);});}})['catch'](_0x4509a9=>{_0x53011c(_0x4509a9);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x43a93f,_0x51df35,_0x3e270e,_0x27293b=!0x1,_0x36aae6=!0x1){const _0xdda0bd=new he(_0x43a93f);let _0x53b9ff;if(_0x36aae6)_0x53b9ff=Fa;else try{_0x53b9ff=await _0xdda0bd['verify'](_0x3e270e);}catch{_0x53b9ff=await _0xdda0bd['verify'](_0x3e270e,!0x0);}const _0x5b26a4={..._0x51df35};if(_0x3e270e==='mfaSmsEnrollment'||_0x3e270e==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5b26a4){const _0x597013=_0x5b26a4['phoneEnrollmentInfo']['phoneNumber'],_0x221665=_0x5b26a4['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5b26a4,{'phoneEnrollmentInfo':{'phoneNumber':_0x597013,'recaptchaToken':_0x221665,'captchaResponse':_0x53b9ff,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5b26a4){const _0x159c94=_0x5b26a4['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5b26a4,{'phoneSignInInfo':{'recaptchaToken':_0x159c94,'captchaResponse':_0x53b9ff,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5b26a4;}return _0x27293b?Object['assign'](_0x5b26a4,{'captchaResp':_0x53b9ff}):Object['assign'](_0x5b26a4,{'captchaResponse':_0x53b9ff}),Object['assign'](_0x5b26a4,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5b26a4,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5b26a4;}async function xi(_0x5eafe0,_0x3205d4,_0x361e44,_0x204e61,_0x168eea){var _0xcd79b5;if((_0xcd79b5=_0x5eafe0['_getRecaptchaConfig']())!=null&&_0xcd79b5['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x46da17=await kr(_0x5eafe0,_0x3205d4,_0x361e44,_0x361e44==='getOobCode');return _0x204e61(_0x5eafe0,_0x46da17);}else return _0x204e61(_0x5eafe0,_0x3205d4)['catch'](async _0x35e59d=>{if(_0x35e59d['code']==='auth/missing-recaptcha-token'){console['log'](_0x361e44+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1ab762=await kr(_0x5eafe0,_0x3205d4,_0x361e44,_0x361e44==='getOobCode');return _0x204e61(_0x5eafe0,_0x1ab762);}else return Promise['reject'](_0x35e59d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x426e55,_0x569057){const _0x5c20e6=Hi(_0x426e55,'auth');if(_0x5c20e6['isInitialized']()){const _0x3e5a27=_0x5c20e6['getImmediate'](),_0xc93382=_0x5c20e6['getOptions']();if(xe(_0xc93382,_0x569057??{}))return _0x3e5a27;Y(_0x3e5a27,'already-initialized');}return _0x5c20e6['initialize']({'options':_0x569057});}function Hf(_0x2d5c73,_0x5f452d){const _0x1f68c1=(_0x5f452d==null?void 0x0:_0x5f452d['persistence'])||[],_0x269f62=(Array['isArray'](_0x1f68c1)?_0x1f68c1:[_0x1f68c1])['map'](ie);_0x5f452d!=null&&_0x5f452d['errorMap']&&_0x2d5c73['_updateErrorMap'](_0x5f452d['errorMap']),_0x2d5c73['_initializeWithPersistence'](_0x269f62,_0x5f452d==null?void 0x0:_0x5f452d['popupRedirectResolver']);}function $f(_0x49acf3,_0x7055e9,_0x3c713c){const _0x5187e5=Ke(_0x49acf3);m(/^https?:\/\//['test'](_0x7055e9),_0x5187e5,'invalid-emulator-scheme');const _0x3143d9=!0x1,_0x5b1fe5=Ua(_0x7055e9),{host:_0x8a947d,port:_0x54feb5}=Gf(_0x7055e9),_0x37154a=_0x54feb5===null?'':':'+_0x54feb5,_0x2d71df={'url':_0x5b1fe5+'//'+_0x8a947d+_0x37154a+'/'},_0x31e932=Object['freeze']({'host':_0x8a947d,'port':_0x54feb5,'protocol':_0x5b1fe5['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3143d9})});if(!_0x5187e5['_canInitEmulator']){m(_0x5187e5['config']['emulator']&&_0x5187e5['emulatorConfig'],_0x5187e5,'emulator-config-failed'),m(xe(_0x2d71df,_0x5187e5['config']['emulator'])&&xe(_0x31e932,_0x5187e5['emulatorConfig']),_0x5187e5,'emulator-config-failed');return;}_0x5187e5['config']['emulator']=_0x2d71df,_0x5187e5['emulatorConfig']=_0x31e932,_0x5187e5['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x8a947d)?Qr(_0x5b1fe5+'//'+_0x8a947d+_0x37154a):qf();}function Ua(_0x38e606){const _0x3eb730=_0x38e606['indexOf'](':');return _0x3eb730<0x0?'':_0x38e606['substr'](0x0,_0x3eb730+0x1);}function Gf(_0x344f96){const _0x5b76e3=Ua(_0x344f96),_0x59bc05=/(\/\/)?([^?#/]+)/['exec'](_0x344f96['substr'](_0x5b76e3['length']));if(!_0x59bc05)return{'host':'','port':null};const _0x2621d1=_0x59bc05[0x2]['split']('@')['pop']()||'',_0x521273=/^(\[[^\]]+\])(:|$)/['exec'](_0x2621d1);if(_0x521273){const _0x4682fa=_0x521273[0x1];return{'host':_0x4682fa,'port':Pr(_0x2621d1['substr'](_0x4682fa['length']+0x1))};}else{const [_0x5488a9,_0x43f01f]=_0x2621d1['split'](':');return{'host':_0x5488a9,'port':Pr(_0x43f01f)};}}function Pr(_0x17ae4e){if(!_0x17ae4e)return null;const _0x37cad0=Number(_0x17ae4e);return isNaN(_0x37cad0)?null:_0x37cad0;}function qf(){function _0x19527d(){const _0x47722d=document['createElement']('p'),_0x16f6ee=_0x47722d['style'];_0x47722d['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x16f6ee['position']='fixed',_0x16f6ee['width']='100%',_0x16f6ee['backgroundColor']='#ffffff',_0x16f6ee['border']='.1em\x20solid\x20#000000',_0x16f6ee['color']='#b50000',_0x16f6ee['bottom']='0px',_0x16f6ee['left']='0px',_0x16f6ee['margin']='0px',_0x16f6ee['zIndex']='10000',_0x16f6ee['textAlign']='center',_0x47722d['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x47722d);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x19527d):_0x19527d());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x4a67a5,_0x478a80){this['providerId']=_0x4a67a5,this['signInMethod']=_0x478a80;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x367a44){return ne('not\x20implemented');}['_linkToIdToken'](_0x4aa47a,_0xf03451){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x10758f){return ne('not\x20implemented');}}async function zf(_0x39c799,_0x34c81e){return Pe(_0x39c799,'POST','/v1/accounts:signUp',_0x34c81e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x450db4,_0x2e6b1d){return en(_0x450db4,'POST','/v1/accounts:signInWithPassword',ke(_0x450db4,_0x2e6b1d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xde030e,_0x5c687a){return en(_0xde030e,'POST','/v1/accounts:signInWithEmailLink',ke(_0xde030e,_0x5c687a));}async function Yf(_0x4a4013,_0x25cde2){return en(_0x4a4013,'POST','/v1/accounts:signInWithEmailLink',ke(_0x4a4013,_0x25cde2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x2463de,_0x4de50d,_0x2ca7d7,_0xfba589=null){super('password',_0x2ca7d7),this['_email']=_0x2463de,this['_password']=_0x4de50d,this['_tenantId']=_0xfba589;}static['_fromEmailAndPassword'](_0x3c927f,_0x293c28){return new $t(_0x3c927f,_0x293c28,'password');}static['_fromEmailAndCode'](_0x131b72,_0x32f511,_0x1488d4=null){return new $t(_0x131b72,_0x32f511,'emailLink',_0x1488d4);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5545f0){const _0x491a5e=typeof _0x5545f0=='string'?JSON['parse'](_0x5545f0):_0x5545f0;if(_0x491a5e!=null&&_0x491a5e['email']&&(_0x491a5e!=null&&_0x491a5e['password'])){if(_0x491a5e['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x491a5e['email'],_0x491a5e['password']);if(_0x491a5e['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x491a5e['email'],_0x491a5e['password'],_0x491a5e['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3e85fe){switch(this['signInMethod']){case'password':const _0x949ccb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3e85fe,_0x949ccb,'signInWithPassword',jf);case'emailLink':return Kf(_0x3e85fe,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3e85fe,'internal-error');}}async['_linkToIdToken'](_0x1af941,_0x4abb33){switch(this['signInMethod']){case'password':const _0x57f47f={'idToken':_0x4abb33,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1af941,_0x57f47f,'signUpPassword',zf);case'emailLink':return Yf(_0x1af941,{'idToken':_0x4abb33,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1af941,'internal-error');}}['_getReauthenticationResolver'](_0x6f6410){return this['_getIdTokenResponse'](_0x6f6410);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1e3c1d,_0x33d6f3){return en(_0x1e3c1d,'POST','/v1/accounts:signInWithIdp',ke(_0x1e3c1d,_0x33d6f3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x149d17){const _0x1cc158=new $e(_0x149d17['providerId'],_0x149d17['signInMethod']);return _0x149d17['idToken']||_0x149d17['accessToken']?(_0x149d17['idToken']&&(_0x1cc158['idToken']=_0x149d17['idToken']),_0x149d17['accessToken']&&(_0x1cc158['accessToken']=_0x149d17['accessToken']),_0x149d17['nonce']&&!_0x149d17['pendingToken']&&(_0x1cc158['nonce']=_0x149d17['nonce']),_0x149d17['pendingToken']&&(_0x1cc158['pendingToken']=_0x149d17['pendingToken'])):_0x149d17['oauthToken']&&_0x149d17['oauthTokenSecret']?(_0x1cc158['accessToken']=_0x149d17['oauthToken'],_0x1cc158['secret']=_0x149d17['oauthTokenSecret']):Y('argument-error'),_0x1cc158;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x188702){const _0x5d750f=typeof _0x188702=='string'?JSON['parse'](_0x188702):_0x188702,{providerId:_0x5f4e8d,signInMethod:_0x464ebb,..._0x38c624}=_0x5d750f;if(!_0x5f4e8d||!_0x464ebb)return null;const _0x427cd9=new $e(_0x5f4e8d,_0x464ebb);return _0x427cd9['idToken']=_0x38c624['idToken']||void 0x0,_0x427cd9['accessToken']=_0x38c624['accessToken']||void 0x0,_0x427cd9['secret']=_0x38c624['secret'],_0x427cd9['nonce']=_0x38c624['nonce'],_0x427cd9['pendingToken']=_0x38c624['pendingToken']||null,_0x427cd9;}['_getIdTokenResponse'](_0x176a1f){const _0x439147=this['buildRequest']();return nt(_0x176a1f,_0x439147);}['_linkToIdToken'](_0x4c50af,_0x83fc44){const _0x4ba284=this['buildRequest']();return _0x4ba284['idToken']=_0x83fc44,nt(_0x4c50af,_0x4ba284);}['_getReauthenticationResolver'](_0xd3cf63){const _0x5f071a=this['buildRequest']();return _0x5f071a['autoCreate']=!0x1,nt(_0xd3cf63,_0x5f071a);}['buildRequest'](){const _0x3d5d12={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3d5d12['pendingToken']=this['pendingToken'];else{const _0x4f2a57={};this['idToken']&&(_0x4f2a57['id_token']=this['idToken']),this['accessToken']&&(_0x4f2a57['access_token']=this['accessToken']),this['secret']&&(_0x4f2a57['oauth_token_secret']=this['secret']),_0x4f2a57['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4f2a57['nonce']=this['nonce']),_0x3d5d12['postBody']=ut(_0x4f2a57);}return _0x3d5d12;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x3608ac){switch(_0x3608ac){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x146269){const _0x3c698c=Ct(Tt(_0x146269))['link'],_0x4737b7=_0x3c698c?Ct(Tt(_0x3c698c))['deep_link_id']:null,_0x88dde8=Ct(Tt(_0x146269))['deep_link_id'];return(_0x88dde8?Ct(Tt(_0x88dde8))['link']:null)||_0x88dde8||_0x4737b7||_0x3c698c||_0x146269;}class Rs{constructor(_0x3d3fc2){const _0x5ca17f=Ct(Tt(_0x3d3fc2)),_0x133264=_0x5ca17f['apiKey']??null,_0x6f3534=_0x5ca17f['oobCode']??null,_0x894645=Jf(_0x5ca17f['mode']??null);m(_0x133264&&_0x6f3534&&_0x894645,'argument-error'),this['apiKey']=_0x133264,this['operation']=_0x894645,this['code']=_0x6f3534,this['continueUrl']=_0x5ca17f['continueUrl']??null,this['languageCode']=_0x5ca17f['lang']??null,this['tenantId']=_0x5ca17f['tenantId']??null;}static['parseLink'](_0x9cdcc9){const _0x33926a=Xf(_0x9cdcc9);try{return new Rs(_0x33926a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x3d4627,_0x3f2317){return $t['_fromEmailAndPassword'](_0x3d4627,_0x3f2317);}static['credentialWithLink'](_0x491863,_0xe381d6){const _0x6e6568=Rs['parseLink'](_0xe381d6);return m(_0x6e6568,'argument-error'),$t['_fromEmailAndCode'](_0x491863,_0x6e6568['code'],_0x6e6568['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x114167){this['providerId']=_0x114167,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xf9ee61){this['defaultLanguageCode']=_0xf9ee61;}['setCustomParameters'](_0x3ddb78){return this['customParameters']=_0x3ddb78,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4db243){return this['scopes']['includes'](_0x4db243)||this['scopes']['push'](_0x4db243),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1ec2e2){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1ec2e2});}static['credentialFromResult'](_0x5323af){return ue['credentialFromTaggedObject'](_0x5323af);}static['credentialFromError'](_0x396f52){return ue['credentialFromTaggedObject'](_0x396f52['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3a6e7f}){if(!_0x3a6e7f||!('oauthAccessToken'in _0x3a6e7f)||!_0x3a6e7f['oauthAccessToken'])return null;try{return ue['credential'](_0x3a6e7f['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x25ee77,_0x5b2d99){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x25ee77,'accessToken':_0x5b2d99});}static['credentialFromResult'](_0x2d7463){return de['credentialFromTaggedObject'](_0x2d7463);}static['credentialFromError'](_0xca7fe1){return de['credentialFromTaggedObject'](_0xca7fe1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x83077a}){if(!_0x83077a)return null;const {oauthIdToken:_0x5de099,oauthAccessToken:_0x4ffc47}=_0x83077a;if(!_0x5de099&&!_0x4ffc47)return null;try{return de['credential'](_0x5de099,_0x4ffc47);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x21a20d){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x21a20d});}static['credentialFromResult'](_0x58fcc7){return fe['credentialFromTaggedObject'](_0x58fcc7);}static['credentialFromError'](_0x4443ff){return fe['credentialFromTaggedObject'](_0x4443ff['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1f4db0}){if(!_0x1f4db0||!('oauthAccessToken'in _0x1f4db0)||!_0x1f4db0['oauthAccessToken'])return null;try{return fe['credential'](_0x1f4db0['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3c474e,_0x52064c){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3c474e,'oauthTokenSecret':_0x52064c});}static['credentialFromResult'](_0x134ccd){return pe['credentialFromTaggedObject'](_0x134ccd);}static['credentialFromError'](_0x3281df){return pe['credentialFromTaggedObject'](_0x3281df['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x54b7f0}){if(!_0x54b7f0)return null;const {oauthAccessToken:_0x1b5765,oauthTokenSecret:_0x117167}=_0x54b7f0;if(!_0x1b5765||!_0x117167)return null;try{return pe['credential'](_0x1b5765,_0x117167);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2b3d5d,_0xd0d61f){return en(_0x2b3d5d,'POST','/v1/accounts:signUp',ke(_0x2b3d5d,_0xd0d61f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x56f2af){this['user']=_0x56f2af['user'],this['providerId']=_0x56f2af['providerId'],this['_tokenResponse']=_0x56f2af['_tokenResponse'],this['operationType']=_0x56f2af['operationType'];}static async['_fromIdTokenResponse'](_0x44e166,_0x4c93e6,_0x178d4d,_0x3b9c51=!0x1){const _0x340ab3=await j['_fromIdTokenResponse'](_0x44e166,_0x178d4d,_0x3b9c51),_0x7f7566=Nr(_0x178d4d);return new Ge({'user':_0x340ab3,'providerId':_0x7f7566,'_tokenResponse':_0x178d4d,'operationType':_0x4c93e6});}static async['_forOperation'](_0x466c5a,_0x43578a,_0x3d04bb){await _0x466c5a['_updateTokensIfNecessary'](_0x3d04bb,!0x0);const _0x20143d=Nr(_0x3d04bb);return new Ge({'user':_0x466c5a,'providerId':_0x20143d,'_tokenResponse':_0x3d04bb,'operationType':_0x43578a});}}function Nr(_0x1406ef){return _0x1406ef['providerId']?_0x1406ef['providerId']:'phoneNumber'in _0x1406ef?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x58bee8,_0x44a803,_0x13f368,_0x4d8956){super(_0x44a803['code'],_0x44a803['message']),this['operationType']=_0x13f368,this['user']=_0x4d8956,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x58bee8['name'],'tenantId':_0x58bee8['tenantId']??void 0x0,'_serverResponse':_0x44a803['customData']['_serverResponse'],'operationType':_0x13f368};}static['_fromErrorAndOperation'](_0x4ff8ff,_0x31e263,_0x496903,_0x5674b3){return new On(_0x4ff8ff,_0x31e263,_0x496903,_0x5674b3);}}function Ba(_0x4f3da3,_0xa73201,_0xb91b2b,_0x2a35fd){return(_0xa73201==='reauthenticate'?_0xb91b2b['_getReauthenticationResolver'](_0x4f3da3):_0xb91b2b['_getIdTokenResponse'](_0x4f3da3))['catch'](_0x225c6d=>{throw _0x225c6d['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4f3da3,_0x225c6d,_0xa73201,_0x2a35fd):_0x225c6d;});}async function ep(_0x23541c,_0x154488,_0xcda373=!0x1){const _0x62f61c=await Ht(_0x23541c,_0x154488['_linkToIdToken'](_0x23541c['auth'],await _0x23541c['getIdToken']()),_0xcda373);return Ge['_forOperation'](_0x23541c,'link',_0x62f61c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3177c5,_0x354840,_0x2007ab=!0x1){const {auth:_0x2e8b1f}=_0x3177c5;if($(_0x2e8b1f['app']))return Promise['reject'](re(_0x2e8b1f));const _0x4aceb2='reauthenticate';try{const _0x5b6dd9=await Ht(_0x3177c5,Ba(_0x2e8b1f,_0x4aceb2,_0x354840,_0x3177c5),_0x2007ab);m(_0x5b6dd9['idToken'],_0x2e8b1f,'internal-error');const _0x15d416=Ts(_0x5b6dd9['idToken']);m(_0x15d416,_0x2e8b1f,'internal-error');const {sub:_0xdf463c}=_0x15d416;return m(_0x3177c5['uid']===_0xdf463c,_0x2e8b1f,'user-mismatch'),Ge['_forOperation'](_0x3177c5,_0x4aceb2,_0x5b6dd9);}catch(_0x559ce8){throw(_0x559ce8==null?void 0x0:_0x559ce8['code'])==='auth/user-not-found'&&Y(_0x2e8b1f,'user-mismatch'),_0x559ce8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x18cf56,_0x57ffe4,_0x3024e2=!0x1){if($(_0x18cf56['app']))return Promise['reject'](re(_0x18cf56));const _0x162246='signIn',_0x1ed913=await Ba(_0x18cf56,_0x162246,_0x57ffe4),_0x57d0a8=await Ge['_fromIdTokenResponse'](_0x18cf56,_0x162246,_0x1ed913);return _0x3024e2||await _0x18cf56['_updateCurrentUser'](_0x57d0a8['user']),_0x57d0a8;}async function np(_0x50abf1,_0x38e9a7){return Va(Ke(_0x50abf1),_0x38e9a7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x108cab){const _0x3a1f85=Ke(_0x108cab);_0x3a1f85['_getPasswordPolicyInternal']()&&await _0x3a1f85['_updatePasswordPolicy']();}async function L_(_0x3e5422,_0x524529,_0x2ee322){if($(_0x3e5422['app']))return Promise['reject'](re(_0x3e5422));const _0x28d842=Ke(_0x3e5422),_0x309c75=await xi(_0x28d842,{'returnSecureToken':!0x0,'email':_0x524529,'password':_0x2ee322,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x4849c0=>{throw _0x4849c0['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3e5422),_0x4849c0;}),_0x31afab=await Ge['_fromIdTokenResponse'](_0x28d842,'signIn',_0x309c75);return await _0x28d842['_updateCurrentUser'](_0x31afab['user']),_0x31afab;}function x_(_0x254b93,_0xa3faa1,_0x2a8efe){return $(_0x254b93['app'])?Promise['reject'](re(_0x254b93)):np(P(_0x254b93),yt['credential'](_0xa3faa1,_0x2a8efe))['catch'](async _0x427b6d=>{throw _0x427b6d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x254b93),_0x427b6d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x26e3d6,_0x5d5fe4){return P(_0x26e3d6)['setPersistence'](_0x5d5fe4);}function ip(_0x2eae91,_0x5d5dc6,_0x2c4504,_0x3c8c60){return P(_0x2eae91)['onIdTokenChanged'](_0x5d5dc6,_0x2c4504,_0x3c8c60);}function sp(_0x27b379,_0x15bc19,_0x3383fe){return P(_0x27b379)['beforeAuthStateChanged'](_0x15bc19,_0x3383fe);}function U_(_0x326c8a,_0x110146,_0x1e1e32,_0x27efb7){return P(_0x326c8a)['onAuthStateChanged'](_0x110146,_0x1e1e32,_0x27efb7);}function W_(_0x259e72){return P(_0x259e72)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x12885d,_0x100ef7){this['storageRetriever']=_0x12885d,this['type']=_0x100ef7;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xc4bd58,_0x29b1cf){return this['storage']['setItem'](_0xc4bd58,JSON['stringify'](_0x29b1cf)),Promise['resolve']();}['_get'](_0x489473){const _0x313611=this['storage']['getItem'](_0x489473);return Promise['resolve'](_0x313611?JSON['parse'](_0x313611):null);}['_remove'](_0x47d27c){return this['storage']['removeItem'](_0x47d27c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1e9485,_0x23d23d)=>this['onStorageEvent'](_0x1e9485,_0x23d23d),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xd9243e){for(const _0x323825 of Object['keys'](this['listeners'])){const _0x5509ee=this['storage']['getItem'](_0x323825),_0x38c712=this['localCache'][_0x323825];_0x5509ee!==_0x38c712&&_0xd9243e(_0x323825,_0x38c712,_0x5509ee);}}['onStorageEvent'](_0x56ff80,_0x2bc374=!0x1){if(!_0x56ff80['key']){this['forAllChangedKeys']((_0xfb6872,_0x4a14d6,_0x292016)=>{this['notifyListeners'](_0xfb6872,_0x292016);});return;}const _0x516356=_0x56ff80['key'];_0x2bc374?this['detachListener']():this['stopPolling']();const _0x4e67e5=()=>{const _0x5ae457=this['storage']['getItem'](_0x516356);!_0x2bc374&&this['localCache'][_0x516356]===_0x5ae457||this['notifyListeners'](_0x516356,_0x5ae457);},_0x17cc9d=this['storage']['getItem'](_0x516356);Af()&&_0x17cc9d!==_0x56ff80['newValue']&&_0x56ff80['newValue']!==_0x56ff80['oldValue']?setTimeout(_0x4e67e5,op):_0x4e67e5();}['notifyListeners'](_0x480518,_0x151002){this['localCache'][_0x480518]=_0x151002;const _0x1f93f1=this['listeners'][_0x480518];if(_0x1f93f1){for(const _0x3a4bcc of Array['from'](_0x1f93f1))_0x3a4bcc(_0x151002&&JSON['parse'](_0x151002));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5f4956,_0x44e78e,_0xd738d7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5f4956,'oldValue':_0x44e78e,'newValue':_0xd738d7}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3206ef,_0xd6c842){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3206ef]||(this['listeners'][_0x3206ef]=new Set(),this['localCache'][_0x3206ef]=this['storage']['getItem'](_0x3206ef)),this['listeners'][_0x3206ef]['add'](_0xd6c842);}['_removeListener'](_0x34753e,_0x427e5b){this['listeners'][_0x34753e]&&(this['listeners'][_0x34753e]['delete'](_0x427e5b),this['listeners'][_0x34753e]['size']===0x0&&delete this['listeners'][_0x34753e]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2b1574,_0x4b930b){await super['_set'](_0x2b1574,_0x4b930b),this['localCache'][_0x2b1574]=JSON['stringify'](_0x4b930b);}async['_get'](_0x2dcedd){const _0x5088a4=await super['_get'](_0x2dcedd);return this['localCache'][_0x2dcedd]=JSON['stringify'](_0x5088a4),_0x5088a4;}async['_remove'](_0xc2b8ad){await super['_remove'](_0xc2b8ad),delete this['localCache'][_0xc2b8ad];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1f3cbf,_0x516311){}['_removeListener'](_0x32efbd,_0x4e53c3){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x381918){return Promise['all'](_0x381918['map'](async _0x108527=>{try{return{'fulfilled':!0x0,'value':await _0x108527};}catch(_0x2763b8){return{'fulfilled':!0x1,'reason':_0x2763b8};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xf6e9e1){this['eventTarget']=_0xf6e9e1,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3dfc6d){const _0x1243cb=this['receivers']['find'](_0x4408fc=>_0x4408fc['isListeningto'](_0x3dfc6d));if(_0x1243cb)return _0x1243cb;const _0x3b2578=new Xn(_0x3dfc6d);return this['receivers']['push'](_0x3b2578),_0x3b2578;}['isListeningto'](_0x3ff544){return this['eventTarget']===_0x3ff544;}async['handleEvent'](_0x3001e3){const _0x39fc71=_0x3001e3,{eventId:_0x30e7e4,eventType:_0x32bf59,data:_0x43b1fe}=_0x39fc71['data'],_0x21381f=this['handlersMap'][_0x32bf59];if(!(_0x21381f!=null&&_0x21381f['size']))return;_0x39fc71['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x30e7e4,'eventType':_0x32bf59});const _0x8eb4c0=Array['from'](_0x21381f)['map'](async _0x8455e3=>_0x8455e3(_0x39fc71['origin'],_0x43b1fe)),_0x85a43f=await cp(_0x8eb4c0);_0x39fc71['ports'][0x0]['postMessage']({'status':'done','eventId':_0x30e7e4,'eventType':_0x32bf59,'response':_0x85a43f});}['_subscribe'](_0x116309,_0x42338a){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x116309]||(this['handlersMap'][_0x116309]=new Set()),this['handlersMap'][_0x116309]['add'](_0x42338a);}['_unsubscribe'](_0x1a402b,_0x464937){this['handlersMap'][_0x1a402b]&&_0x464937&&this['handlersMap'][_0x1a402b]['delete'](_0x464937),(!_0x464937||this['handlersMap'][_0x1a402b]['size']===0x0)&&delete this['handlersMap'][_0x1a402b],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3fb4ca='',_0x49375e=0xa){let _0x9a9cd4='';for(let _0x1e0868=0x0;_0x1e0868<_0x49375e;_0x1e0868++)_0x9a9cd4+=Math['floor'](Math['random']()*0xa);return _0x3fb4ca+_0x9a9cd4;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x49128d){this['target']=_0x49128d,this['handlers']=new Set();}['removeMessageHandler'](_0x56f72c){_0x56f72c['messageChannel']&&(_0x56f72c['messageChannel']['port1']['removeEventListener']('message',_0x56f72c['onMessage']),_0x56f72c['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x56f72c);}async['_send'](_0x5a53cb,_0x68cf41,_0x3aec79=0x32){const _0x4597f8=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4597f8)throw new Error('connection_unavailable');let _0x26e48d,_0x162f7;return new Promise((_0x14c0a3,_0x2003cd)=>{const _0x241aa5=As('',0x14);_0x4597f8['port1']['start']();const _0x1d8d3d=setTimeout(()=>{_0x2003cd(new Error('unsupported_event'));},_0x3aec79);_0x162f7={'messageChannel':_0x4597f8,'onMessage'(_0x29b731){const _0x48abda=_0x29b731;if(_0x48abda['data']['eventId']===_0x241aa5)switch(_0x48abda['data']['status']){case'ack':clearTimeout(_0x1d8d3d),_0x26e48d=setTimeout(()=>{_0x2003cd(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x26e48d),_0x14c0a3(_0x48abda['data']['response']);break;default:clearTimeout(_0x1d8d3d),clearTimeout(_0x26e48d),_0x2003cd(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x162f7),_0x4597f8['port1']['addEventListener']('message',_0x162f7['onMessage']),this['target']['postMessage']({'eventType':_0x5a53cb,'eventId':_0x241aa5,'data':_0x68cf41},[_0x4597f8['port2']]);})['finally'](()=>{_0x162f7&&this['removeMessageHandler'](_0x162f7);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0xd62c68){Z()['location']['href']=_0xd62c68;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x25387c;return((_0x25387c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x25387c['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x193272){this['request']=_0x193272;}['toPromise'](){return new Promise((_0x4b6e62,_0x53aac4)=>{this['request']['addEventListener']('success',()=>{_0x4b6e62(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x53aac4(this['request']['error']);});});}}function Zn(_0x3f46f2,_0x375a2f){return _0x3f46f2['transaction']([Mn],_0x375a2f?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0xe57434=indexedDB['deleteDatabase'](Ka);return new nn(_0xe57434)['toPromise']();}function Qa(){const _0x41e0ad=indexedDB['open'](Ka,pp);return new Promise((_0x9b8ff8,_0x55fbdd)=>{_0x41e0ad['addEventListener']('error',()=>{_0x55fbdd(_0x41e0ad['error']);}),_0x41e0ad['addEventListener']('upgradeneeded',()=>{const _0x48c93c=_0x41e0ad['result'];try{_0x48c93c['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x403bfd){_0x55fbdd(_0x403bfd);}}),_0x41e0ad['addEventListener']('success',async()=>{const _0x17574a=_0x41e0ad['result'];_0x17574a['objectStoreNames']['contains'](Mn)?_0x9b8ff8(_0x17574a):(_0x17574a['close'](),await _p(),_0x9b8ff8(await Qa()));});});}async function Or(_0xde0ae5,_0x984582,_0x7c86c7){const _0x25c744=Zn(_0xde0ae5,!0x0)['put']({[Ya]:_0x984582,'value':_0x7c86c7});return new nn(_0x25c744)['toPromise']();}async function gp(_0x3e2821,_0x4fbdc8){const _0x42767b=Zn(_0x3e2821,!0x1)['get'](_0x4fbdc8),_0x44e1d6=await new nn(_0x42767b)['toPromise']();return _0x44e1d6===void 0x0?null:_0x44e1d6['value'];}function Dr(_0x4b2568,_0x538e11){const _0x2dd1fe=Zn(_0x4b2568,!0x0)['delete'](_0x538e11);return new nn(_0x2dd1fe)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x7c06b4){let _0x25cd19=0x0;for(;;)try{const _0x58ce5a=await this['_openDb']();return await _0x7c06b4(_0x58ce5a);}catch(_0x509006){if(_0x25cd19++>yp)throw _0x509006;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x460925,_0x94e72)=>({'keyProcessed':(await this['_poll']())['includes'](_0x94e72['key'])})),this['receiver']['_subscribe']('ping',async(_0x473a8e,_0x550e01)=>['keyChanged']);}async['initializeSender'](){var _0x38bc81,_0xbf91fb;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2b906f=await this['sender']['_send']('ping',{},0x320);_0x2b906f&&(_0x38bc81=_0x2b906f[0x0])!=null&&_0x38bc81['fulfilled']&&(_0xbf91fb=_0x2b906f[0x0])!=null&&_0xbf91fb['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x277323){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x277323},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3bfd7f=>{await Or(_0x3bfd7f,Dn,'1'),await Dr(_0x3bfd7f,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5ae10e){this['pendingWrites']++;try{await _0x5ae10e();}finally{this['pendingWrites']--;}}async['_set'](_0x451874,_0x11b05d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x59e60f=>Or(_0x59e60f,_0x451874,_0x11b05d)),this['localCache'][_0x451874]=_0x11b05d,this['notifyServiceWorker'](_0x451874)));}async['_get'](_0x70750c){const _0x97aabd=await this['_withRetries'](_0x5d916d=>gp(_0x5d916d,_0x70750c));return this['localCache'][_0x70750c]=_0x97aabd,_0x97aabd;}async['_remove'](_0x37366c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3c4951=>Dr(_0x3c4951,_0x37366c)),delete this['localCache'][_0x37366c],this['notifyServiceWorker'](_0x37366c)));}async['_poll'](){const _0x51518e=await this['_withRetries'](_0x176f37=>{const _0x587308=Zn(_0x176f37,!0x1)['getAll']();return new nn(_0x587308)['toPromise']();});if(!_0x51518e)return[];if(this['pendingWrites']!==0x0)return[];const _0x448f85=[],_0x42ff8f=new Set();if(_0x51518e['length']!==0x0){for(const {fbase_key:_0x1e72f0,value:_0x5e2dbd}of _0x51518e)_0x42ff8f['add'](_0x1e72f0),JSON['stringify'](this['localCache'][_0x1e72f0])!==JSON['stringify'](_0x5e2dbd)&&(this['notifyListeners'](_0x1e72f0,_0x5e2dbd),_0x448f85['push'](_0x1e72f0));}for(const _0x5ae3d4 of Object['keys'](this['localCache']))this['localCache'][_0x5ae3d4]&&!_0x42ff8f['has'](_0x5ae3d4)&&(this['notifyListeners'](_0x5ae3d4,null),_0x448f85['push'](_0x5ae3d4));return _0x448f85;}['notifyListeners'](_0x21a0d7,_0x48f1fa){this['localCache'][_0x21a0d7]=_0x48f1fa;const _0x4e2705=this['listeners'][_0x21a0d7];if(_0x4e2705){for(const _0x5eee85 of Array['from'](_0x4e2705))_0x5eee85(_0x48f1fa);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3bdb82,_0x59f346){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3bdb82]||(this['listeners'][_0x3bdb82]=new Set(),this['_get'](_0x3bdb82)),this['listeners'][_0x3bdb82]['add'](_0x59f346);}['_removeListener'](_0x48592a,_0x4b3b3c){this['listeners'][_0x48592a]&&(this['listeners'][_0x48592a]['delete'](_0x4b3b3c),this['listeners'][_0x48592a]['size']===0x0&&delete this['listeners'][_0x48592a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1137ff,_0x1e6890){return _0x1e6890?ie(_0x1e6890):(m(_0x1137ff['_popupRedirectResolver'],_0x1137ff,'argument-error'),_0x1137ff['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0xa7ec45){super('custom','custom'),this['params']=_0xa7ec45;}['_getIdTokenResponse'](_0x2e3faa){return nt(_0x2e3faa,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2b7bae,_0x192f60){return nt(_0x2b7bae,this['_buildIdpRequest'](_0x192f60));}['_getReauthenticationResolver'](_0x5e4f52){return nt(_0x5e4f52,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xcf022f){const _0x5810f1={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xcf022f&&(_0x5810f1['idToken']=_0xcf022f),_0x5810f1;}}function Ip(_0x248850){return Va(_0x248850['auth'],new ks(_0x248850),_0x248850['bypassAuthState']);}function wp(_0x337152){const {auth:_0xa69dcf,user:_0x8a5983}=_0x337152;return m(_0x8a5983,_0xa69dcf,'internal-error'),tp(_0x8a5983,new ks(_0x337152),_0x337152['bypassAuthState']);}async function Cp(_0x259824){const {auth:_0x2efe08,user:_0x57fd16}=_0x259824;return m(_0x57fd16,_0x2efe08,'internal-error'),ep(_0x57fd16,new ks(_0x259824),_0x259824['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x38ffc9,_0x2761d4,_0x4d6795,_0x3d9bdf,_0xf84d51=!0x1){this['auth']=_0x38ffc9,this['resolver']=_0x4d6795,this['user']=_0x3d9bdf,this['bypassAuthState']=_0xf84d51,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2761d4)?_0x2761d4:[_0x2761d4];}['execute'](){return new Promise(async(_0x3f6335,_0x5cb4e0)=>{this['pendingPromise']={'resolve':_0x3f6335,'reject':_0x5cb4e0};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x368dd9){this['reject'](_0x368dd9);}});}async['onAuthEvent'](_0x4abf67){const {urlResponse:_0xe72b26,sessionId:_0x41e260,postBody:_0x2d97c9,tenantId:_0x23f263,error:_0x56d685,type:_0x38001c}=_0x4abf67;if(_0x56d685){this['reject'](_0x56d685);return;}const _0x1ed75d={'auth':this['auth'],'requestUri':_0xe72b26,'sessionId':_0x41e260,'tenantId':_0x23f263||void 0x0,'postBody':_0x2d97c9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x38001c)(_0x1ed75d));}catch(_0x295052){this['reject'](_0x295052);}}['onError'](_0x119fca){this['reject'](_0x119fca);}['getIdpTask'](_0x4370ea){switch(_0x4370ea){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x5a897e){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5a897e),this['unregisterAndCleanUp']();}['reject'](_0x26c093){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x26c093),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5d4fac,_0x4de604,_0x5de232,_0xf2726,_0x2307f4){super(_0x5d4fac,_0x4de604,_0xf2726,_0x2307f4),this['provider']=_0x5de232,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x189584=await this['execute']();return m(_0x189584,this['auth'],'internal-error'),_0x189584;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x500c78=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x500c78),this['authWindow']['associatedEvent']=_0x500c78,this['resolver']['_originValidation'](this['auth'])['catch'](_0x38ff8f=>{this['reject'](_0x38ff8f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3fa94b=>{_0x3fa94b||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1e6f15;return((_0x1e6f15=this['authWindow'])==null?void 0x0:_0x1e6f15['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x154dc7=()=>{var _0x531c22,_0x293f16;if((_0x293f16=(_0x531c22=this['authWindow'])==null?void 0x0:_0x531c22['window'])!=null&&_0x293f16['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x154dc7,Tp['get']());};_0x154dc7();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x32182c,_0x33fd0b,_0x56408f=!0x1){super(_0x32182c,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x33fd0b,void 0x0,_0x56408f),this['eventId']=null;}async['execute'](){let _0x251f0b=hn['get'](this['auth']['_key']());if(!_0x251f0b){try{const _0x5679a5=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x251f0b=()=>Promise['resolve'](_0x5679a5);}catch(_0x4bc470){_0x251f0b=()=>Promise['reject'](_0x4bc470);}hn['set'](this['auth']['_key'](),_0x251f0b);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x251f0b();}async['onAuthEvent'](_0x50e601){if(_0x50e601['type']==='signInViaRedirect')return super['onAuthEvent'](_0x50e601);if(_0x50e601['type']==='unknown'){this['resolve'](null);return;}if(_0x50e601['eventId']){const _0x259713=await this['auth']['_redirectUserForId'](_0x50e601['eventId']);if(_0x259713)return this['user']=_0x259713,super['onAuthEvent'](_0x50e601);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x38a9ca,_0x3ef311){const _0x2fc794=Pp(_0x3ef311),_0x42f709=kp(_0x38a9ca);if(!await _0x42f709['_isAvailable']())return!0x1;const _0x4baba0=await _0x42f709['_get'](_0x2fc794)==='true';return await _0x42f709['_remove'](_0x2fc794),_0x4baba0;}function Ap(_0x3bed48,_0x1dc451){hn['set'](_0x3bed48['_key'](),_0x1dc451);}function kp(_0x1abd2e){return ie(_0x1abd2e['_redirectPersistence']);}function Pp(_0x120251){return ln(Sp,_0x120251['config']['apiKey'],_0x120251['name']);}async function Np(_0x481ea0,_0x5caa00,_0xdcf414=!0x1){if($(_0x481ea0['app']))return Promise['reject'](re(_0x481ea0));const _0x3ff1f1=Ke(_0x481ea0),_0x5778c4=Ep(_0x3ff1f1,_0x5caa00),_0x1d6723=await new bp(_0x3ff1f1,_0x5778c4,_0xdcf414)['execute']();return _0x1d6723&&!_0xdcf414&&(delete _0x1d6723['user']['_redirectEventId'],await _0x3ff1f1['_persistUserIfCurrent'](_0x1d6723['user']),await _0x3ff1f1['_setRedirectUser'](null,_0x5caa00)),_0x1d6723;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3dd14d){this['auth']=_0x3dd14d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2754e0){this['consumers']['add'](_0x2754e0),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2754e0)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2754e0),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3b5f67){this['consumers']['delete'](_0x3b5f67);}['onEvent'](_0x4d885e){if(this['hasEventBeenHandled'](_0x4d885e))return!0x1;let _0xd85807=!0x1;return this['consumers']['forEach'](_0x2d674d=>{this['isEventForConsumer'](_0x4d885e,_0x2d674d)&&(_0xd85807=!0x0,this['sendToConsumer'](_0x4d885e,_0x2d674d),this['saveEventToCache'](_0x4d885e));}),this['hasHandledPotentialRedirect']||!Mp(_0x4d885e)||(this['hasHandledPotentialRedirect']=!0x0,_0xd85807||(this['queuedRedirectEvent']=_0x4d885e,_0xd85807=!0x0)),_0xd85807;}['sendToConsumer'](_0x5aa51b,_0x363193){var _0x4b95bf;if(_0x5aa51b['error']&&!Za(_0x5aa51b)){const _0x4d012e=((_0x4b95bf=_0x5aa51b['error']['code'])==null?void 0x0:_0x4b95bf['split']('auth/')[0x1])||'internal-error';_0x363193['onError'](X(this['auth'],_0x4d012e));}else _0x363193['onAuthEvent'](_0x5aa51b);}['isEventForConsumer'](_0x3fc79d,_0x36f8e2){const _0x399fef=_0x36f8e2['eventId']===null||!!_0x3fc79d['eventId']&&_0x3fc79d['eventId']===_0x36f8e2['eventId'];return _0x36f8e2['filter']['includes'](_0x3fc79d['type'])&&_0x399fef;}['hasEventBeenHandled'](_0x385071){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x385071));}['saveEventToCache'](_0x1e4b6e){this['cachedEventUids']['add'](Mr(_0x1e4b6e)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x21b329){return[_0x21b329['type'],_0x21b329['eventId'],_0x21b329['sessionId'],_0x21b329['tenantId']]['filter'](_0xb664e=>_0xb664e)['join']('-');}function Za({type:_0x3dc1ab,error:_0x280e57}){return _0x3dc1ab==='unknown'&&(_0x280e57==null?void 0x0:_0x280e57['code'])==='auth/no-auth-event';}function Mp(_0x1a5721){switch(_0x1a5721['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1a5721);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x49365d,_0xb10ba5={}){return Pe(_0x49365d,'GET','/v1/projects',_0xb10ba5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x568b80){if(_0x568b80['config']['emulator'])return;const {authorizedDomains:_0x545748}=await Lp(_0x568b80);for(const _0x54b96d of _0x545748)try{if(Wp(_0x54b96d))return;}catch{}Y(_0x568b80,'unauthorized-domain');}function Wp(_0x4f22b1){const _0x22ca1a=Mi(),{protocol:_0x317524,hostname:_0x2f4317}=new URL(_0x22ca1a);if(_0x4f22b1['startsWith']('chrome-extension://')){const _0x392c26=new URL(_0x4f22b1);return _0x392c26['hostname']===''&&_0x2f4317===''?_0x317524==='chrome-extension:'&&_0x4f22b1['replace']('chrome-extension://','')===_0x22ca1a['replace']('chrome-extension://',''):_0x317524==='chrome-extension:'&&_0x392c26['hostname']===_0x2f4317;}if(!Fp['test'](_0x317524))return!0x1;if(xp['test'](_0x4f22b1))return _0x2f4317===_0x4f22b1;const _0x20a0e6=_0x4f22b1['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x20a0e6+'|'+_0x20a0e6+')$','i')['test'](_0x2f4317);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x35dd38=Z()['___jsl'];if(_0x35dd38!=null&&_0x35dd38['H']){for(const _0x39838a of Object['keys'](_0x35dd38['H']))if(_0x35dd38['H'][_0x39838a]['r']=_0x35dd38['H'][_0x39838a]['r']||[],_0x35dd38['H'][_0x39838a]['L']=_0x35dd38['H'][_0x39838a]['L']||[],_0x35dd38['H'][_0x39838a]['r']=[..._0x35dd38['H'][_0x39838a]['L']],_0x35dd38['CP']){for(let _0x3375cc=0x0;_0x3375cc<_0x35dd38['CP']['length'];_0x3375cc++)_0x35dd38['CP'][_0x3375cc]=null;}}}function Vp(_0x3650f5){return new Promise((_0x310802,_0x3d539d)=>{var _0x49f898,_0x5314ac,_0x1f3d1e;function _0x2a384a(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x310802(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x3d539d(X(_0x3650f5,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5314ac=(_0x49f898=Z()['gapi'])==null?void 0x0:_0x49f898['iframes'])!=null&&_0x5314ac['Iframe'])_0x310802(gapi['iframes']['getContext']());else{if((_0x1f3d1e=Z()['gapi'])!=null&&_0x1f3d1e['load'])_0x2a384a();else{const _0x291e9f=Ff('iframefcb');return Z()[_0x291e9f]=()=>{gapi['load']?_0x2a384a():_0x3d539d(X(_0x3650f5,'network-request-failed'));},xa(xf()+'?onload='+_0x291e9f)['catch'](_0x14c54b=>_0x3d539d(_0x14c54b));}}})['catch'](_0x384585=>{throw un=null,_0x384585;});}let un=null;function Hp(_0x4e0804){return un=un||Vp(_0x4e0804),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x3b7323){const _0x276a76=_0x3b7323['config'];m(_0x276a76['authDomain'],_0x3b7323,'auth-domain-config-required');const _0x15e313=_0x276a76['emulator']?Cs(_0x276a76,qp):'https://'+_0x3b7323['config']['authDomain']+'/'+Gp,_0x15e9ac={'apiKey':_0x276a76['apiKey'],'appName':_0x3b7323['name'],'v':dt},_0xa24f57=jp['get'](_0x3b7323['config']['apiHost']);_0xa24f57&&(_0x15e9ac['eid']=_0xa24f57);const _0x233074=_0x3b7323['_getFrameworks']();return _0x233074['length']&&(_0x15e9ac['fw']=_0x233074['join'](',')),_0x15e313+'?'+ut(_0x15e9ac)['slice'](0x1);}async function Yp(_0x3dbae2){const _0x463e4c=await Hp(_0x3dbae2),_0x470f12=Z()['gapi'];return m(_0x470f12,_0x3dbae2,'internal-error'),_0x463e4c['open']({'where':document['body'],'url':Kp(_0x3dbae2),'messageHandlersFilter':_0x470f12['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x4348ac=>new Promise(async(_0x4d185a,_0x4ac32e)=>{await _0x4348ac['restyle']({'setHideOnLeave':!0x1});const _0x2bb5bb=X(_0x3dbae2,'network-request-failed'),_0x5bfcf7=Z()['setTimeout'](()=>{_0x4ac32e(_0x2bb5bb);},$p['get']());function _0xf14a8c(){Z()['clearTimeout'](_0x5bfcf7),_0x4d185a(_0x4348ac);}_0x4348ac['ping'](_0xf14a8c)['then'](_0xf14a8c,()=>{_0x4ac32e(_0x2bb5bb);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x449edf){this['window']=_0x449edf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x174cf0,_0x41124a,_0x1ab32b,_0x45fe8d=Jp,_0x565bcc=Xp){const _0x140e6d=Math['max']((window['screen']['availHeight']-_0x565bcc)/0x2,0x0)['toString'](),_0x43c374=Math['max']((window['screen']['availWidth']-_0x45fe8d)/0x2,0x0)['toString']();let _0x16519b='';const _0x4b0fe5={...Qp,'width':_0x45fe8d['toString'](),'height':_0x565bcc['toString'](),'top':_0x140e6d,'left':_0x43c374},_0x329ca8=W()['toLowerCase']();_0x1ab32b&&(_0x16519b=ka(_0x329ca8)?Zp:_0x1ab32b),Ra(_0x329ca8)&&(_0x41124a=_0x41124a||e_,_0x4b0fe5['scrollbars']='yes');const _0x58f48c=Object['entries'](_0x4b0fe5)['reduce']((_0x2d0b1c,[_0x2a512e,_0x137c6c])=>''+_0x2d0b1c+_0x2a512e+'='+_0x137c6c+',','');if(Rf(_0x329ca8)&&_0x16519b!=='_self')return n_(_0x41124a||'',_0x16519b),new xr(null);const _0x4e9b33=window['open'](_0x41124a||'',_0x16519b,_0x58f48c);m(_0x4e9b33,_0x174cf0,'popup-blocked');try{_0x4e9b33['focus']();}catch{}return new xr(_0x4e9b33);}function n_(_0x22206d,_0x117b45){const _0x371eb3=document['createElement']('a');_0x371eb3['href']=_0x22206d,_0x371eb3['target']=_0x117b45;const _0x16b5e5=document['createEvent']('MouseEvent');_0x16b5e5['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x371eb3['dispatchEvent'](_0x16b5e5);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x590be0,_0x59aa4e,_0x5bc926,_0xa6a3b,_0x365c04,_0x36339b){m(_0x590be0['config']['authDomain'],_0x590be0,'auth-domain-config-required'),m(_0x590be0['config']['apiKey'],_0x590be0,'invalid-api-key');const _0x19a848={'apiKey':_0x590be0['config']['apiKey'],'appName':_0x590be0['name'],'authType':_0x5bc926,'redirectUrl':_0xa6a3b,'v':dt,'eventId':_0x365c04};if(_0x59aa4e instanceof Wa){_0x59aa4e['setDefaultLanguage'](_0x590be0['languageCode']),_0x19a848['providerId']=_0x59aa4e['providerId']||'',pn(_0x59aa4e['getCustomParameters']())||(_0x19a848['customParameters']=JSON['stringify'](_0x59aa4e['getCustomParameters']()));for(const [_0x31056d,_0x5cb316]of Object['entries']({}))_0x19a848[_0x31056d]=_0x5cb316;}if(_0x59aa4e instanceof tn){const _0x28a26f=_0x59aa4e['getScopes']()['filter'](_0xf8c4c2=>_0xf8c4c2!=='');_0x28a26f['length']>0x0&&(_0x19a848['scopes']=_0x28a26f['join'](','));}_0x590be0['tenantId']&&(_0x19a848['tid']=_0x590be0['tenantId']);const _0x528984=_0x19a848;for(const _0x5b62e8 of Object['keys'](_0x528984))_0x528984[_0x5b62e8]===void 0x0&&delete _0x528984[_0x5b62e8];const _0xe4b2a8=await _0x590be0['_getAppCheckToken'](),_0x1b267b=_0xe4b2a8?'#'+r_+'='+encodeURIComponent(_0xe4b2a8):'';return o_(_0x590be0)+'?'+ut(_0x528984)['slice'](0x1)+_0x1b267b;}function o_({config:_0x2867ad}){return _0x2867ad['emulator']?Cs(_0x2867ad,s_):'https://'+_0x2867ad['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x203289,_0x47908f,_0x2a4efd,_0x285531){var _0x3a6b51;ce((_0x3a6b51=this['eventManagers'][_0x203289['_key']()])==null?void 0x0:_0x3a6b51['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x511620=await Fr(_0x203289,_0x47908f,_0x2a4efd,Mi(),_0x285531);return t_(_0x203289,_0x511620,As());}async['_openRedirect'](_0x512b36,_0x29a1cc,_0x49a704,_0x4d0be6){await this['_originValidation'](_0x512b36);const _0x55c4b3=await Fr(_0x512b36,_0x29a1cc,_0x49a704,Mi(),_0x4d0be6);return hp(_0x55c4b3),new Promise(()=>{});}['_initialize'](_0x59f782){const _0x384572=_0x59f782['_key']();if(this['eventManagers'][_0x384572]){const {manager:_0x4a7fd8,promise:_0x93f95b}=this['eventManagers'][_0x384572];return _0x4a7fd8?Promise['resolve'](_0x4a7fd8):(ce(_0x93f95b,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x93f95b);}const _0x9fc139=this['initAndGetManager'](_0x59f782);return this['eventManagers'][_0x384572]={'promise':_0x9fc139},_0x9fc139['catch'](()=>{delete this['eventManagers'][_0x384572];}),_0x9fc139;}async['initAndGetManager'](_0x3b0d53){const _0x19677a=await Yp(_0x3b0d53),_0xc0458=new Dp(_0x3b0d53);return _0x19677a['register']('authEvent',_0x3a66ab=>(m(_0x3a66ab==null?void 0x0:_0x3a66ab['authEvent'],_0x3b0d53,'invalid-auth-event'),{'status':_0xc0458['onEvent'](_0x3a66ab['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3b0d53['_key']()]={'manager':_0xc0458},this['iframes'][_0x3b0d53['_key']()]=_0x19677a,_0xc0458;}['_isIframeWebStorageSupported'](_0x46a044,_0x361587){this['iframes'][_0x46a044['_key']()]['send'](pi,{'type':pi},_0x5d4871=>{var _0x1dc1ef;const _0x559847=(_0x1dc1ef=_0x5d4871==null?void 0x0:_0x5d4871[0x0])==null?void 0x0:_0x1dc1ef[pi];_0x559847!==void 0x0&&_0x361587(!!_0x559847),Y(_0x46a044,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x28bd99){const _0x37e899=_0x28bd99['_key']();return this['originValidationPromises'][_0x37e899]||(this['originValidationPromises'][_0x37e899]=Up(_0x28bd99)),this['originValidationPromises'][_0x37e899];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x5e6411){this['auth']=_0x5e6411,this['internalListeners']=new Map();}['getUid'](){var _0x3358ec;return this['assertAuthConfigured'](),((_0x3358ec=this['auth']['currentUser'])==null?void 0x0:_0x3358ec['uid'])||null;}async['getToken'](_0x4f7382){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4f7382)}:null;}['addAuthTokenListener'](_0x2ad5ad){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2ad5ad))return;const _0x591981=this['auth']['onIdTokenChanged'](_0x22daed=>{_0x2ad5ad((_0x22daed==null?void 0x0:_0x22daed['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2ad5ad,_0x591981),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x51f4cb){this['assertAuthConfigured']();const _0x1e1d64=this['internalListeners']['get'](_0x51f4cb);_0x1e1d64&&(this['internalListeners']['delete'](_0x51f4cb),_0x1e1d64(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x42aeeb){switch(_0x42aeeb){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x1dca54){st(new Fe('auth',(_0x49bed3,{options:_0x88ffb})=>{const _0x37cc00=_0x49bed3['getProvider']('app')['getImmediate'](),_0x4b8ddf=_0x49bed3['getProvider']('heartbeat'),_0x3601e9=_0x49bed3['getProvider']('app-check-internal'),{apiKey:_0x290de3,authDomain:_0x3453da}=_0x37cc00['options'];m(_0x290de3&&!_0x290de3['includes'](':'),'invalid-api-key',{'appName':_0x37cc00['name']});const _0x34d7f4={'apiKey':_0x290de3,'authDomain':_0x3453da,'clientPlatform':_0x1dca54,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1dca54)},_0x573e26=new Df(_0x37cc00,_0x4b8ddf,_0x3601e9,_0x34d7f4);return Hf(_0x573e26,_0x88ffb),_0x573e26;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x27fdf1,_0x5cd44d,_0x40e969)=>{_0x27fdf1['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x4c26d7=>{const _0x349b81=Ke(_0x4c26d7['getProvider']('auth')['getImmediate']());return(_0x55fad9=>new l_(_0x55fad9))(_0x349b81);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x1dca54)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x456c14=>async _0x540d07=>{const _0x6461ed=_0x540d07&&await _0x540d07['getIdTokenResult'](),_0x592f82=_0x6461ed&&(new Date()['getTime']()-Date['parse'](_0x6461ed['issuedAtTime']))/0x3e8;if(_0x592f82&&_0x592f82>f_)return;const _0x6eb57=_0x6461ed==null?void 0x0:_0x6461ed['token'];Br!==_0x6eb57&&(Br=_0x6eb57,await fetch(_0x456c14,{'method':_0x6eb57?'POST':'DELETE','headers':_0x6eb57?{'Authorization':'Bearer\x20'+_0x6eb57}:{}}));};function B_(_0x4f270c=Zr()){const _0x3e9e79=Hi(_0x4f270c,'auth');if(_0x3e9e79['isInitialized']())return _0x3e9e79['getImmediate']();const _0x4e5d24=Vf(_0x4f270c,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x5d0e9d=jr('authTokenSyncURL');if(_0x5d0e9d&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x11246b=new URL(_0x5d0e9d,location['origin']);if(location['origin']===_0x11246b['origin']){const _0x54d310=p_(_0x11246b['toString']());sp(_0x4e5d24,_0x54d310,()=>_0x54d310(_0x4e5d24['currentUser'])),ip(_0x4e5d24,_0x2c79c7=>_0x54d310(_0x2c79c7));}}const _0x27d1ee=qr('auth');return _0x27d1ee&&$f(_0x4e5d24,'http://'+_0x27d1ee),_0x4e5d24;}function __(){var _0x4a9e2a;return((_0x4a9e2a=document['getElementsByTagName']('head'))==null?void 0x0:_0x4a9e2a[0x0])??document;}Mf({'loadJS'(_0xbe8921){return new Promise((_0x22558a,_0x1c705a)=>{const _0x3c3734=document['createElement']('script');_0x3c3734['setAttribute']('src',_0xbe8921),_0x3c3734['onload']=_0x22558a,_0x3c3734['onerror']=_0x4656b2=>{const _0x121932=X('internal-error');_0x121932['customData']=_0x4656b2,_0x1c705a(_0x121932);},_0x3c3734['type']='text/javascript',_0x3c3734['charset']='UTF-8',__()['appendChild'](_0x3c3734);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};