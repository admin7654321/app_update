const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x139225,_0x3c3e83){if(!_0x139225)throw ht(_0x3c3e83);},ht=function(_0x5d5d96){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5d5d96);},Hr=function(_0x2e8042){const _0x4c2d6e=[];let _0x3e37b0=0x0;for(let _0x5c1149=0x0;_0x5c1149<_0x2e8042['length'];_0x5c1149++){let _0x2d7dde=_0x2e8042['charCodeAt'](_0x5c1149);_0x2d7dde<0x80?_0x4c2d6e[_0x3e37b0++]=_0x2d7dde:_0x2d7dde<0x800?(_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0x6|0xc0,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde&0x3f|0x80):(_0x2d7dde&0xfc00)===0xd800&&_0x5c1149+0x1<_0x2e8042['length']&&(_0x2e8042['charCodeAt'](_0x5c1149+0x1)&0xfc00)===0xdc00?(_0x2d7dde=0x10000+((_0x2d7dde&0x3ff)<<0xa)+(_0x2e8042['charCodeAt'](++_0x5c1149)&0x3ff),_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0x12|0xf0,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0xc&0x3f|0x80,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0x6&0x3f|0x80,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde&0x3f|0x80):(_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0xc|0xe0,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde>>0x6&0x3f|0x80,_0x4c2d6e[_0x3e37b0++]=_0x2d7dde&0x3f|0x80);}return _0x4c2d6e;},nc=function(_0xb89270){const _0xc0dfbb=[];let _0x123c86=0x0,_0x39c374=0x0;for(;_0x123c86<_0xb89270['length'];){const _0x1dd5d3=_0xb89270[_0x123c86++];if(_0x1dd5d3<0x80)_0xc0dfbb[_0x39c374++]=String['fromCharCode'](_0x1dd5d3);else{if(_0x1dd5d3>0xbf&&_0x1dd5d3<0xe0){const _0x292324=_0xb89270[_0x123c86++];_0xc0dfbb[_0x39c374++]=String['fromCharCode']((_0x1dd5d3&0x1f)<<0x6|_0x292324&0x3f);}else{if(_0x1dd5d3>0xef&&_0x1dd5d3<0x16d){const _0xc69eb2=_0xb89270[_0x123c86++],_0x32225c=_0xb89270[_0x123c86++],_0x2715ed=_0xb89270[_0x123c86++],_0x5f37d6=((_0x1dd5d3&0x7)<<0x12|(_0xc69eb2&0x3f)<<0xc|(_0x32225c&0x3f)<<0x6|_0x2715ed&0x3f)-0x10000;_0xc0dfbb[_0x39c374++]=String['fromCharCode'](0xd800+(_0x5f37d6>>0xa)),_0xc0dfbb[_0x39c374++]=String['fromCharCode'](0xdc00+(_0x5f37d6&0x3ff));}else{const _0x8177bd=_0xb89270[_0x123c86++],_0x2187c8=_0xb89270[_0x123c86++];_0xc0dfbb[_0x39c374++]=String['fromCharCode']((_0x1dd5d3&0xf)<<0xc|(_0x8177bd&0x3f)<<0x6|_0x2187c8&0x3f);}}}}return _0xc0dfbb['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x39eab5,_0x57ff06){if(!Array['isArray'](_0x39eab5))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x422d2e=_0x57ff06?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xa38a4b=[];for(let _0x1c49d7=0x0;_0x1c49d7<_0x39eab5['length'];_0x1c49d7+=0x3){const _0xdd409d=_0x39eab5[_0x1c49d7],_0x2335d3=_0x1c49d7+0x1<_0x39eab5['length'],_0x56b563=_0x2335d3?_0x39eab5[_0x1c49d7+0x1]:0x0,_0x4cefa2=_0x1c49d7+0x2<_0x39eab5['length'],_0x383a52=_0x4cefa2?_0x39eab5[_0x1c49d7+0x2]:0x0,_0x3e3959=_0xdd409d>>0x2,_0x307f7f=(_0xdd409d&0x3)<<0x4|_0x56b563>>0x4;let _0x44f30c=(_0x56b563&0xf)<<0x2|_0x383a52>>0x6,_0x46b67d=_0x383a52&0x3f;_0x4cefa2||(_0x46b67d=0x40,_0x2335d3||(_0x44f30c=0x40)),_0xa38a4b['push'](_0x422d2e[_0x3e3959],_0x422d2e[_0x307f7f],_0x422d2e[_0x44f30c],_0x422d2e[_0x46b67d]);}return _0xa38a4b['join']('');},'encodeString'(_0x305fee,_0x2aedeb){return this['HAS_NATIVE_SUPPORT']&&!_0x2aedeb?btoa(_0x305fee):this['encodeByteArray'](Hr(_0x305fee),_0x2aedeb);},'decodeString'(_0x582a99,_0x288e3a){return this['HAS_NATIVE_SUPPORT']&&!_0x288e3a?atob(_0x582a99):nc(this['decodeStringToByteArray'](_0x582a99,_0x288e3a));},'decodeStringToByteArray'(_0x16da52,_0x500144){this['init_']();const _0x3f6bdd=_0x500144?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4e1075=[];for(let _0x5b1eb7=0x0;_0x5b1eb7<_0x16da52['length'];){const _0x1a4cc6=_0x3f6bdd[_0x16da52['charAt'](_0x5b1eb7++)],_0x3b676d=_0x5b1eb7<_0x16da52['length']?_0x3f6bdd[_0x16da52['charAt'](_0x5b1eb7)]:0x0;++_0x5b1eb7;const _0x439194=_0x5b1eb7<_0x16da52['length']?_0x3f6bdd[_0x16da52['charAt'](_0x5b1eb7)]:0x40;++_0x5b1eb7;const _0x2a8cc=_0x5b1eb7<_0x16da52['length']?_0x3f6bdd[_0x16da52['charAt'](_0x5b1eb7)]:0x40;if(++_0x5b1eb7,_0x1a4cc6==null||_0x3b676d==null||_0x439194==null||_0x2a8cc==null)throw new ic();const _0xbb0446=_0x1a4cc6<<0x2|_0x3b676d>>0x4;if(_0x4e1075['push'](_0xbb0446),_0x439194!==0x40){const _0x3da390=_0x3b676d<<0x4&0xf0|_0x439194>>0x2;if(_0x4e1075['push'](_0x3da390),_0x2a8cc!==0x40){const _0x4d0c28=_0x439194<<0x6&0xc0|_0x2a8cc;_0x4e1075['push'](_0x4d0c28);}}}return _0x4e1075;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x39f7fd=0x0;_0x39f7fd<this['ENCODED_VALS']['length'];_0x39f7fd++)this['byteToCharMap_'][_0x39f7fd]=this['ENCODED_VALS']['charAt'](_0x39f7fd),this['charToByteMap_'][this['byteToCharMap_'][_0x39f7fd]]=_0x39f7fd,this['byteToCharMapWebSafe_'][_0x39f7fd]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x39f7fd),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x39f7fd]]=_0x39f7fd,_0x39f7fd>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x39f7fd)]=_0x39f7fd,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x39f7fd)]=_0x39f7fd);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x1a6035){const _0x27f5d6=Hr(_0x1a6035);return Fi['encodeByteArray'](_0x27f5d6,!0x0);},dn=function(_0x5186a0){return $r(_0x5186a0)['replace'](/\./g,'');},fn=function(_0x1ed0db){try{return Fi['decodeString'](_0x1ed0db,!0x0);}catch(_0x260df4){console['error']('base64Decode\x20failed:\x20',_0x260df4);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x133a8e){return Gr(void 0x0,_0x133a8e);}function Gr(_0x2ee76c,_0x1ac81b){if(!(_0x1ac81b instanceof Object))return _0x1ac81b;switch(_0x1ac81b['constructor']){case Date:const _0x5e197a=_0x1ac81b;return new Date(_0x5e197a['getTime']());case Object:_0x2ee76c===void 0x0&&(_0x2ee76c={});break;case Array:_0x2ee76c=[];break;default:return _0x1ac81b;}for(const _0x20d995 in _0x1ac81b)!_0x1ac81b['hasOwnProperty'](_0x20d995)||!rc(_0x20d995)||(_0x2ee76c[_0x20d995]=Gr(_0x2ee76c[_0x20d995],_0x1ac81b[_0x20d995]));return _0x2ee76c;}function rc(_0xbb22aa){return _0xbb22aa!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x454799=Ps['__FIREBASE_DEFAULTS__'];if(_0x454799)return JSON['parse'](_0x454799);},lc=()=>{if(typeof document>'u')return;let _0x7c9814;try{_0x7c9814=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x22ce4f=_0x7c9814&&fn(_0x7c9814[0x1]);return _0x22ce4f&&JSON['parse'](_0x22ce4f);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x67cac8){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x67cac8);return;}},qr=_0x382c2e=>{var _0x2967fd,_0x230ae2;return(_0x230ae2=(_0x2967fd=Ui())==null?void 0x0:_0x2967fd['emulatorHosts'])==null?void 0x0:_0x230ae2[_0x382c2e];},hc=_0x1e1865=>{const _0x5dd0ab=qr(_0x1e1865);if(!_0x5dd0ab)return;const _0x1c9ea2=_0x5dd0ab['lastIndexOf'](':');if(_0x1c9ea2<=0x0||_0x1c9ea2+0x1===_0x5dd0ab['length'])throw new Error('Invalid\x20host\x20'+_0x5dd0ab+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x22f2a2=parseInt(_0x5dd0ab['substring'](_0x1c9ea2+0x1),0xa);return _0x5dd0ab[0x0]==='['?[_0x5dd0ab['substring'](0x1,_0x1c9ea2-0x1),_0x22f2a2]:[_0x5dd0ab['substring'](0x0,_0x1c9ea2),_0x22f2a2];},zr=()=>{var _0x5e7b04;return(_0x5e7b04=Ui())==null?void 0x0:_0x5e7b04['config'];},jr=_0x59c79a=>{var _0xad8120;return(_0xad8120=Ui())==null?void 0x0:_0xad8120['_'+_0x59c79a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5f32ea,_0x25da57)=>{this['resolve']=_0x5f32ea,this['reject']=_0x25da57;});}['wrapCallback'](_0x9d4fd6){return(_0x1e6c29,_0x4828df)=>{_0x1e6c29?this['reject'](_0x1e6c29):this['resolve'](_0x4828df),typeof _0x9d4fd6=='function'&&(this['promise']['catch'](()=>{}),_0x9d4fd6['length']===0x1?_0x9d4fd6(_0x1e6c29):_0x9d4fd6(_0x1e6c29,_0x4828df));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x247768,_0x940554){if(_0x247768['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1d357a={'alg':'none','type':'JWT'},_0x37b8bd=_0x940554||'demo-project',_0x544fdc=_0x247768['iat']||0x0,_0x5719af=_0x247768['sub']||_0x247768['user_id'];if(!_0x5719af)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x57d676={'iss':'https://securetoken.google.com/'+_0x37b8bd,'aud':_0x37b8bd,'iat':_0x544fdc,'exp':_0x544fdc+0xe10,'auth_time':_0x544fdc,'sub':_0x5719af,'user_id':_0x5719af,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x247768};return[dn(JSON['stringify'](_0x1d357a)),dn(JSON['stringify'](_0x57d676)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x428d5d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x428d5d=='object'&&_0x428d5d['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xe4e5a6=W();return _0xe4e5a6['indexOf']('MSIE\x20')>=0x0||_0xe4e5a6['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x389909,_0x1fa274)=>{try{let _0x163056=!0x0;const _0x5eaef9='validate-browser-context-for-indexeddb-analytics-module',_0x2c5451=self['indexedDB']['open'](_0x5eaef9);_0x2c5451['onsuccess']=()=>{_0x2c5451['result']['close'](),_0x163056||self['indexedDB']['deleteDatabase'](_0x5eaef9),_0x389909(!0x0);},_0x2c5451['onupgradeneeded']=()=>{_0x163056=!0x1;},_0x2c5451['onerror']=()=>{var _0x2621ad;_0x1fa274(((_0x2621ad=_0x2c5451['error'])==null?void 0x0:_0x2621ad['message'])||'');};}catch(_0x528e0c){_0x1fa274(_0x528e0c);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x5e1b08,_0xc4593d,_0x323cb6){super(_0xc4593d),this['code']=_0x5e1b08,this['customData']=_0x323cb6,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x70eb42,_0x1b5064,_0x343f64){this['service']=_0x70eb42,this['serviceName']=_0x1b5064,this['errors']=_0x343f64;}['create'](_0x21e19f,..._0x4f9e6d){const _0x14deae=_0x4f9e6d[0x0]||{},_0x29df06=this['service']+'/'+_0x21e19f,_0x41277c=this['errors'][_0x21e19f],_0x481f4a=_0x41277c?vc(_0x41277c,_0x14deae):'Error',_0x1c3157=this['serviceName']+':\x20'+_0x481f4a+'\x20('+_0x29df06+').';return new Re(_0x29df06,_0x1c3157,_0x14deae);}}function vc(_0x8e7214,_0x4748df){return _0x8e7214['replace'](Ec,(_0x1878c3,_0x349fb)=>{const _0x51b756=_0x4748df[_0x349fb];return _0x51b756!=null?String(_0x51b756):'<'+_0x349fb+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x4be2d3){return JSON['parse'](_0x4be2d3);}function O(_0x577fbc){return JSON['stringify'](_0x577fbc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5d23b3){let _0xe85fcd={},_0x5621db={},_0x3aa52a={},_0xcc7a7e='';try{const _0x5f361c=_0x5d23b3['split']('.');_0xe85fcd=Nt(fn(_0x5f361c[0x0])||''),_0x5621db=Nt(fn(_0x5f361c[0x1])||''),_0xcc7a7e=_0x5f361c[0x2],_0x3aa52a=_0x5621db['d']||{},delete _0x5621db['d'];}catch{}return{'header':_0xe85fcd,'claims':_0x5621db,'data':_0x3aa52a,'signature':_0xcc7a7e};},Ic=function(_0xd36872){const _0x2b7478=Yr(_0xd36872),_0x47eddc=_0x2b7478['claims'];return!!_0x47eddc&&typeof _0x47eddc=='object'&&_0x47eddc['hasOwnProperty']('iat');},wc=function(_0x585922){const _0x19e387=Yr(_0x585922)['claims'];return typeof _0x19e387=='object'&&_0x19e387['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x490e98,_0x32bb77){return Object['prototype']['hasOwnProperty']['call'](_0x490e98,_0x32bb77);}function Le(_0x154a5d,_0x566f13){if(Object['prototype']['hasOwnProperty']['call'](_0x154a5d,_0x566f13))return _0x154a5d[_0x566f13];}function pn(_0x976a27){for(const _0x2f57ac in _0x976a27)if(Object['prototype']['hasOwnProperty']['call'](_0x976a27,_0x2f57ac))return!0x1;return!0x0;}function _n(_0x1f2b8a,_0x5c4886,_0x13a48f){const _0x1ab482={};for(const _0x5d7482 in _0x1f2b8a)Object['prototype']['hasOwnProperty']['call'](_0x1f2b8a,_0x5d7482)&&(_0x1ab482[_0x5d7482]=_0x5c4886['call'](_0x13a48f,_0x1f2b8a[_0x5d7482],_0x5d7482,_0x1f2b8a));return _0x1ab482;}function xe(_0x23a184,_0x218daa){if(_0x23a184===_0x218daa)return!0x0;const _0x191188=Object['keys'](_0x23a184),_0x3932cf=Object['keys'](_0x218daa);for(const _0x2e4b62 of _0x191188){if(!_0x3932cf['includes'](_0x2e4b62))return!0x1;const _0x4dee28=_0x23a184[_0x2e4b62],_0x12921f=_0x218daa[_0x2e4b62];if(Ns(_0x4dee28)&&Ns(_0x12921f)){if(!xe(_0x4dee28,_0x12921f))return!0x1;}else{if(_0x4dee28!==_0x12921f)return!0x1;}}for(const _0x37f0e2 of _0x3932cf)if(!_0x191188['includes'](_0x37f0e2))return!0x1;return!0x0;}function Ns(_0x871428){return _0x871428!==null&&typeof _0x871428=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4626cb){const _0x1481b9=[];for(const [_0x338138,_0x1bd957]of Object['entries'](_0x4626cb))Array['isArray'](_0x1bd957)?_0x1bd957['forEach'](_0x1f00b3=>{_0x1481b9['push'](encodeURIComponent(_0x338138)+'='+encodeURIComponent(_0x1f00b3));}):_0x1481b9['push'](encodeURIComponent(_0x338138)+'='+encodeURIComponent(_0x1bd957));return _0x1481b9['length']?'&'+_0x1481b9['join']('&'):'';}function Ct(_0x529ad8){const _0x136af9={};return _0x529ad8['replace'](/^\?/,'')['split']('&')['forEach'](_0xab0904=>{if(_0xab0904){const [_0x3fa474,_0x55725a]=_0xab0904['split']('=');_0x136af9[decodeURIComponent(_0x3fa474)]=decodeURIComponent(_0x55725a);}}),_0x136af9;}function Tt(_0x4b421d){const _0x14b456=_0x4b421d['indexOf']('?');if(!_0x14b456)return'';const _0x147bf6=_0x4b421d['indexOf']('#',_0x14b456);return _0x4b421d['substring'](_0x14b456,_0x147bf6>0x0?_0x147bf6:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xbfd038=0x1;_0xbfd038<this['blockSize'];++_0xbfd038)this['pad_'][_0xbfd038]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1d154c,_0x326b65){_0x326b65||(_0x326b65=0x0);const _0x119958=this['W_'];if(typeof _0x1d154c=='string'){for(let _0x21d5ee=0x0;_0x21d5ee<0x10;_0x21d5ee++)_0x119958[_0x21d5ee]=_0x1d154c['charCodeAt'](_0x326b65)<<0x18|_0x1d154c['charCodeAt'](_0x326b65+0x1)<<0x10|_0x1d154c['charCodeAt'](_0x326b65+0x2)<<0x8|_0x1d154c['charCodeAt'](_0x326b65+0x3),_0x326b65+=0x4;}else{for(let _0x4653d6=0x0;_0x4653d6<0x10;_0x4653d6++)_0x119958[_0x4653d6]=_0x1d154c[_0x326b65]<<0x18|_0x1d154c[_0x326b65+0x1]<<0x10|_0x1d154c[_0x326b65+0x2]<<0x8|_0x1d154c[_0x326b65+0x3],_0x326b65+=0x4;}for(let _0x3162d3=0x10;_0x3162d3<0x50;_0x3162d3++){const _0x1a6934=_0x119958[_0x3162d3-0x3]^_0x119958[_0x3162d3-0x8]^_0x119958[_0x3162d3-0xe]^_0x119958[_0x3162d3-0x10];_0x119958[_0x3162d3]=(_0x1a6934<<0x1|_0x1a6934>>>0x1f)&0xffffffff;}let _0x436f2e=this['chain_'][0x0],_0x833e86=this['chain_'][0x1],_0x51decf=this['chain_'][0x2],_0x55d26d=this['chain_'][0x3],_0x559e30=this['chain_'][0x4],_0x5d14d7,_0x1ff917;for(let _0x27321d=0x0;_0x27321d<0x50;_0x27321d++){_0x27321d<0x28?_0x27321d<0x14?(_0x5d14d7=_0x55d26d^_0x833e86&(_0x51decf^_0x55d26d),_0x1ff917=0x5a827999):(_0x5d14d7=_0x833e86^_0x51decf^_0x55d26d,_0x1ff917=0x6ed9eba1):_0x27321d<0x3c?(_0x5d14d7=_0x833e86&_0x51decf|_0x55d26d&(_0x833e86|_0x51decf),_0x1ff917=0x8f1bbcdc):(_0x5d14d7=_0x833e86^_0x51decf^_0x55d26d,_0x1ff917=0xca62c1d6);const _0x12ce6b=(_0x436f2e<<0x5|_0x436f2e>>>0x1b)+_0x5d14d7+_0x559e30+_0x1ff917+_0x119958[_0x27321d]&0xffffffff;_0x559e30=_0x55d26d,_0x55d26d=_0x51decf,_0x51decf=(_0x833e86<<0x1e|_0x833e86>>>0x2)&0xffffffff,_0x833e86=_0x436f2e,_0x436f2e=_0x12ce6b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x436f2e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x833e86&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x51decf&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x55d26d&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x559e30&0xffffffff;}['update'](_0x10f864,_0x30c071){if(_0x10f864==null)return;_0x30c071===void 0x0&&(_0x30c071=_0x10f864['length']);const _0x3aa144=_0x30c071-this['blockSize'];let _0x4949ac=0x0;const _0x1d62dd=this['buf_'];let _0x2b9bca=this['inbuf_'];for(;_0x4949ac<_0x30c071;){if(_0x2b9bca===0x0){for(;_0x4949ac<=_0x3aa144;)this['compress_'](_0x10f864,_0x4949ac),_0x4949ac+=this['blockSize'];}if(typeof _0x10f864=='string'){for(;_0x4949ac<_0x30c071;)if(_0x1d62dd[_0x2b9bca]=_0x10f864['charCodeAt'](_0x4949ac),++_0x2b9bca,++_0x4949ac,_0x2b9bca===this['blockSize']){this['compress_'](_0x1d62dd),_0x2b9bca=0x0;break;}}else{for(;_0x4949ac<_0x30c071;)if(_0x1d62dd[_0x2b9bca]=_0x10f864[_0x4949ac],++_0x2b9bca,++_0x4949ac,_0x2b9bca===this['blockSize']){this['compress_'](_0x1d62dd),_0x2b9bca=0x0;break;}}}this['inbuf_']=_0x2b9bca,this['total_']+=_0x30c071;}['digest'](){const _0x30ff6b=[];let _0x3a5ba1=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x536b51=this['blockSize']-0x1;_0x536b51>=0x38;_0x536b51--)this['buf_'][_0x536b51]=_0x3a5ba1&0xff,_0x3a5ba1/=0x100;this['compress_'](this['buf_']);let _0x3d447d=0x0;for(let _0x404425=0x0;_0x404425<0x5;_0x404425++)for(let _0x4ed7c4=0x18;_0x4ed7c4>=0x0;_0x4ed7c4-=0x8)_0x30ff6b[_0x3d447d]=this['chain_'][_0x404425]>>_0x4ed7c4&0xff,++_0x3d447d;return _0x30ff6b;}}function Tc(_0x5797c4,_0x573743){const _0x421f12=new Sc(_0x5797c4,_0x573743);return _0x421f12['subscribe']['bind'](_0x421f12);}class Sc{constructor(_0xb661a7,_0xe7891f){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xe7891f,this['task']['then'](()=>{_0xb661a7(this);})['catch'](_0x231928=>{this['error'](_0x231928);});}['next'](_0x34184c){this['forEachObserver'](_0x17d2c2=>{_0x17d2c2['next'](_0x34184c);});}['error'](_0x28bdc9){this['forEachObserver'](_0x3b3c9d=>{_0x3b3c9d['error'](_0x28bdc9);}),this['close'](_0x28bdc9);}['complete'](){this['forEachObserver'](_0x502d21=>{_0x502d21['complete']();}),this['close']();}['subscribe'](_0x1bab68,_0x250c8b,_0x561db0){let _0x1b83b9;if(_0x1bab68===void 0x0&&_0x250c8b===void 0x0&&_0x561db0===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1bab68,['next','error','complete'])?_0x1b83b9=_0x1bab68:_0x1b83b9={'next':_0x1bab68,'error':_0x250c8b,'complete':_0x561db0},_0x1b83b9['next']===void 0x0&&(_0x1b83b9['next']=ti),_0x1b83b9['error']===void 0x0&&(_0x1b83b9['error']=ti),_0x1b83b9['complete']===void 0x0&&(_0x1b83b9['complete']=ti);const _0x1cf4b6=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x1b83b9['error'](this['finalError']):_0x1b83b9['complete']();}catch{}}),this['observers']['push'](_0x1b83b9),_0x1cf4b6;}['unsubscribeOne'](_0x36dabf){this['observers']===void 0x0||this['observers'][_0x36dabf]===void 0x0||(delete this['observers'][_0x36dabf],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1bbdb4){if(!this['finalized']){for(let _0x2f866e=0x0;_0x2f866e<this['observers']['length'];_0x2f866e++)this['sendOne'](_0x2f866e,_0x1bbdb4);}}['sendOne'](_0x25b34c,_0x4e1a53){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x25b34c]!==void 0x0)try{_0x4e1a53(this['observers'][_0x25b34c]);}catch(_0x4089e8){typeof console<'u'&&console['error']&&console['error'](_0x4089e8);}});}['close'](_0x2f49af){this['finalized']||(this['finalized']=!0x0,_0x2f49af!==void 0x0&&(this['finalError']=_0x2f49af),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x16ab5c,_0x5addd6){if(typeof _0x16ab5c!='object'||_0x16ab5c===null)return!0x1;for(const _0x64d54f of _0x5addd6)if(_0x64d54f in _0x16ab5c&&typeof _0x16ab5c[_0x64d54f]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x40d746,_0x30385b){return _0x40d746+'\x20failed:\x20'+_0x30385b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x517da1){const _0x5548ab=[];let _0x50d3a2=0x0;for(let _0x141f8e=0x0;_0x141f8e<_0x517da1['length'];_0x141f8e++){let _0x2d0fd5=_0x517da1['charCodeAt'](_0x141f8e);if(_0x2d0fd5>=0xd800&&_0x2d0fd5<=0xdbff){const _0x1e3ddb=_0x2d0fd5-0xd800;_0x141f8e++,f(_0x141f8e<_0x517da1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x54e626=_0x517da1['charCodeAt'](_0x141f8e)-0xdc00;_0x2d0fd5=0x10000+(_0x1e3ddb<<0xa)+_0x54e626;}_0x2d0fd5<0x80?_0x5548ab[_0x50d3a2++]=_0x2d0fd5:_0x2d0fd5<0x800?(_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0x6|0xc0,_0x5548ab[_0x50d3a2++]=_0x2d0fd5&0x3f|0x80):_0x2d0fd5<0x10000?(_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0xc|0xe0,_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0x6&0x3f|0x80,_0x5548ab[_0x50d3a2++]=_0x2d0fd5&0x3f|0x80):(_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0x12|0xf0,_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0xc&0x3f|0x80,_0x5548ab[_0x50d3a2++]=_0x2d0fd5>>0x6&0x3f|0x80,_0x5548ab[_0x50d3a2++]=_0x2d0fd5&0x3f|0x80);}return _0x5548ab;},Ln=function(_0x3fc68b){let _0x2e6e9b=0x0;for(let _0x411eee=0x0;_0x411eee<_0x3fc68b['length'];_0x411eee++){const _0x1f7dcd=_0x3fc68b['charCodeAt'](_0x411eee);_0x1f7dcd<0x80?_0x2e6e9b++:_0x1f7dcd<0x800?_0x2e6e9b+=0x2:_0x1f7dcd>=0xd800&&_0x1f7dcd<=0xdbff?(_0x2e6e9b+=0x4,_0x411eee++):_0x2e6e9b+=0x3;}return _0x2e6e9b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x4c1e65){return _0x4c1e65&&_0x4c1e65['_delegate']?_0x4c1e65['_delegate']:_0x4c1e65;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x279533){try{return(_0x279533['startsWith']('http://')||_0x279533['startsWith']('https://')?new URL(_0x279533)['hostname']:_0x279533)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x378dfe){return(await fetch(_0x378dfe,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x121c8a,_0x1f968a,_0x23b5bf){this['name']=_0x121c8a,this['instanceFactory']=_0x1f968a,this['type']=_0x23b5bf,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2e0048){return this['instantiationMode']=_0x2e0048,this;}['setMultipleInstances'](_0x27eda9){return this['multipleInstances']=_0x27eda9,this;}['setServiceProps'](_0x21369b){return this['serviceProps']=_0x21369b,this;}['setInstanceCreatedCallback'](_0x138b49){return this['onInstanceCreated']=_0x138b49,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4cf808,_0xc62423){this['name']=_0x4cf808,this['container']=_0xc62423,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x248f52){const _0x57ea38=this['normalizeInstanceIdentifier'](_0x248f52);if(!this['instancesDeferred']['has'](_0x57ea38)){const _0x23378f=new H();if(this['instancesDeferred']['set'](_0x57ea38,_0x23378f),this['isInitialized'](_0x57ea38)||this['shouldAutoInitialize']())try{const _0x5e7e51=this['getOrInitializeService']({'instanceIdentifier':_0x57ea38});_0x5e7e51&&_0x23378f['resolve'](_0x5e7e51);}catch{}}return this['instancesDeferred']['get'](_0x57ea38)['promise'];}['getImmediate'](_0x1db9da){const _0x5a7640=this['normalizeInstanceIdentifier'](_0x1db9da==null?void 0x0:_0x1db9da['identifier']),_0xba8b28=(_0x1db9da==null?void 0x0:_0x1db9da['optional'])??!0x1;if(this['isInitialized'](_0x5a7640)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5a7640});}catch(_0x2087d6){if(_0xba8b28)return null;throw _0x2087d6;}else{if(_0xba8b28)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x594bc8){if(_0x594bc8['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x594bc8['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x594bc8,!!this['shouldAutoInitialize']()){if(Pc(_0x594bc8))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x20ad4a,_0x46ab5a]of this['instancesDeferred']['entries']()){const _0xb165ad=this['normalizeInstanceIdentifier'](_0x20ad4a);try{const _0x135141=this['getOrInitializeService']({'instanceIdentifier':_0xb165ad});_0x46ab5a['resolve'](_0x135141);}catch{}}}}['clearInstance'](_0xed1221=Ne){this['instancesDeferred']['delete'](_0xed1221),this['instancesOptions']['delete'](_0xed1221),this['instances']['delete'](_0xed1221);}async['delete'](){const _0x1b95dd=Array['from'](this['instances']['values']());await Promise['all']([..._0x1b95dd['filter'](_0x135a3f=>'INTERNAL'in _0x135a3f)['map'](_0x164f10=>_0x164f10['INTERNAL']['delete']()),..._0x1b95dd['filter'](_0x8deafa=>'_delete'in _0x8deafa)['map'](_0x1ee869=>_0x1ee869['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4e12f3=Ne){return this['instances']['has'](_0x4e12f3);}['getOptions'](_0x4e7f6a=Ne){return this['instancesOptions']['get'](_0x4e7f6a)||{};}['initialize'](_0x2f7077={}){const {options:_0x404175={}}=_0x2f7077,_0x5da42c=this['normalizeInstanceIdentifier'](_0x2f7077['instanceIdentifier']);if(this['isInitialized'](_0x5da42c))throw Error(this['name']+'('+_0x5da42c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2e18cf=this['getOrInitializeService']({'instanceIdentifier':_0x5da42c,'options':_0x404175});for(const [_0xd86454,_0x365b61]of this['instancesDeferred']['entries']()){const _0x5589fb=this['normalizeInstanceIdentifier'](_0xd86454);_0x5da42c===_0x5589fb&&_0x365b61['resolve'](_0x2e18cf);}return _0x2e18cf;}['onInit'](_0x236777,_0x59a60e){const _0x550154=this['normalizeInstanceIdentifier'](_0x59a60e),_0x182385=this['onInitCallbacks']['get'](_0x550154)??new Set();_0x182385['add'](_0x236777),this['onInitCallbacks']['set'](_0x550154,_0x182385);const _0x532738=this['instances']['get'](_0x550154);return _0x532738&&_0x236777(_0x532738,_0x550154),()=>{_0x182385['delete'](_0x236777);};}['invokeOnInitCallbacks'](_0x3cd4c3,_0x23c9f1){const _0x6755d6=this['onInitCallbacks']['get'](_0x23c9f1);if(_0x6755d6){for(const _0x294948 of _0x6755d6)try{_0x294948(_0x3cd4c3,_0x23c9f1);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x46df6c,options:_0x4e6bfb={}}){let _0x5f01cd=this['instances']['get'](_0x46df6c);if(!_0x5f01cd&&this['component']&&(_0x5f01cd=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x46df6c),'options':_0x4e6bfb}),this['instances']['set'](_0x46df6c,_0x5f01cd),this['instancesOptions']['set'](_0x46df6c,_0x4e6bfb),this['invokeOnInitCallbacks'](_0x5f01cd,_0x46df6c),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x46df6c,_0x5f01cd);}catch{}return _0x5f01cd||null;}['normalizeInstanceIdentifier'](_0x2e080f=Ne){return this['component']?this['component']['multipleInstances']?_0x2e080f:Ne:_0x2e080f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4fb91f){return _0x4fb91f===Ne?void 0x0:_0x4fb91f;}function Pc(_0x58b80f){return _0x58b80f['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x34b570){this['name']=_0x34b570,this['providers']=new Map();}['addComponent'](_0x507889){const _0x3f48fb=this['getProvider'](_0x507889['name']);if(_0x3f48fb['isComponentSet']())throw new Error('Component\x20'+_0x507889['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x3f48fb['setComponent'](_0x507889);}['addOrOverwriteComponent'](_0x148592){this['getProvider'](_0x148592['name'])['isComponentSet']()&&this['providers']['delete'](_0x148592['name']),this['addComponent'](_0x148592);}['getProvider'](_0x4ec3c3){if(this['providers']['has'](_0x4ec3c3))return this['providers']['get'](_0x4ec3c3);const _0x1b83db=new Ac(_0x4ec3c3,this);return this['providers']['set'](_0x4ec3c3,_0x1b83db),_0x1b83db;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x9cb0d2){_0x9cb0d2[_0x9cb0d2['DEBUG']=0x0]='DEBUG',_0x9cb0d2[_0x9cb0d2['VERBOSE']=0x1]='VERBOSE',_0x9cb0d2[_0x9cb0d2['INFO']=0x2]='INFO',_0x9cb0d2[_0x9cb0d2['WARN']=0x3]='WARN',_0x9cb0d2[_0x9cb0d2['ERROR']=0x4]='ERROR',_0x9cb0d2[_0x9cb0d2['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x129237,_0x55c198,..._0x1c1fd2)=>{if(_0x55c198<_0x129237['logLevel'])return;const _0x21410e=new Date()['toISOString'](),_0x2303bf=Mc[_0x55c198];if(_0x2303bf)console[_0x2303bf]('['+_0x21410e+']\x20\x20'+_0x129237['name']+':',..._0x1c1fd2);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x55c198+')');};class Bi{constructor(_0x54bcf1){this['name']=_0x54bcf1,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x335558){if(!(_0x335558 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x335558+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x335558;}['setLogLevel'](_0x26a8d1){this['_logLevel']=typeof _0x26a8d1=='string'?Oc[_0x26a8d1]:_0x26a8d1;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x408b8c){if(typeof _0x408b8c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x408b8c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x18a099){this['_userLogHandler']=_0x18a099;}['debug'](..._0x50796e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x50796e),this['_logHandler'](this,T['DEBUG'],..._0x50796e);}['log'](..._0x4575dd){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4575dd),this['_logHandler'](this,T['VERBOSE'],..._0x4575dd);}['info'](..._0x43019d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x43019d),this['_logHandler'](this,T['INFO'],..._0x43019d);}['warn'](..._0x1d5075){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1d5075),this['_logHandler'](this,T['WARN'],..._0x1d5075);}['error'](..._0x4f49e0){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4f49e0),this['_logHandler'](this,T['ERROR'],..._0x4f49e0);}}const xc=(_0x56de40,_0x2f57e3)=>_0x2f57e3['some'](_0x432ed7=>_0x56de40 instanceof _0x432ed7);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x25e3d7){const _0x256fc8=new Promise((_0x1660f7,_0x3749c5)=>{const _0x288692=()=>{_0x25e3d7['removeEventListener']('success',_0x448215),_0x25e3d7['removeEventListener']('error',_0x4c8b83);},_0x448215=()=>{_0x1660f7(ge(_0x25e3d7['result'])),_0x288692();},_0x4c8b83=()=>{_0x3749c5(_0x25e3d7['error']),_0x288692();};_0x25e3d7['addEventListener']('success',_0x448215),_0x25e3d7['addEventListener']('error',_0x4c8b83);});return _0x256fc8['then'](_0x25404e=>{_0x25404e instanceof IDBCursor&&Jr['set'](_0x25404e,_0x25e3d7);})['catch'](()=>{}),Vi['set'](_0x256fc8,_0x25e3d7),_0x256fc8;}function Bc(_0x25cef9){if(_i['has'](_0x25cef9))return;const _0x34c6b1=new Promise((_0x2939f2,_0x364028)=>{const _0x4990d3=()=>{_0x25cef9['removeEventListener']('complete',_0x39edf2),_0x25cef9['removeEventListener']('error',_0x1f1e35),_0x25cef9['removeEventListener']('abort',_0x1f1e35);},_0x39edf2=()=>{_0x2939f2(),_0x4990d3();},_0x1f1e35=()=>{_0x364028(_0x25cef9['error']||new DOMException('AbortError','AbortError')),_0x4990d3();};_0x25cef9['addEventListener']('complete',_0x39edf2),_0x25cef9['addEventListener']('error',_0x1f1e35),_0x25cef9['addEventListener']('abort',_0x1f1e35);});_i['set'](_0x25cef9,_0x34c6b1);}let gi={'get'(_0x1ebe02,_0x12a4d0,_0x51c0d5){if(_0x1ebe02 instanceof IDBTransaction){if(_0x12a4d0==='done')return _i['get'](_0x1ebe02);if(_0x12a4d0==='objectStoreNames')return _0x1ebe02['objectStoreNames']||Xr['get'](_0x1ebe02);if(_0x12a4d0==='store')return _0x51c0d5['objectStoreNames'][0x1]?void 0x0:_0x51c0d5['objectStore'](_0x51c0d5['objectStoreNames'][0x0]);}return ge(_0x1ebe02[_0x12a4d0]);},'set'(_0x151013,_0x4234b8,_0x4f6a2b){return _0x151013[_0x4234b8]=_0x4f6a2b,!0x0;},'has'(_0x3c1f87,_0x36ba90){return _0x3c1f87 instanceof IDBTransaction&&(_0x36ba90==='done'||_0x36ba90==='store')?!0x0:_0x36ba90 in _0x3c1f87;}};function Vc(_0x56240b){gi=_0x56240b(gi);}function Hc(_0x520348){return _0x520348===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x30ed24,..._0x27fd3d){const _0x5ba3a1=_0x520348['call'](ii(this),_0x30ed24,..._0x27fd3d);return Xr['set'](_0x5ba3a1,_0x30ed24['sort']?_0x30ed24['sort']():[_0x30ed24]),ge(_0x5ba3a1);}:Uc()['includes'](_0x520348)?function(..._0x222361){return _0x520348['apply'](ii(this),_0x222361),ge(Jr['get'](this));}:function(..._0x27fdd5){return ge(_0x520348['apply'](ii(this),_0x27fdd5));};}function $c(_0x4a0838){return typeof _0x4a0838=='function'?Hc(_0x4a0838):(_0x4a0838 instanceof IDBTransaction&&Bc(_0x4a0838),xc(_0x4a0838,Fc())?new Proxy(_0x4a0838,gi):_0x4a0838);}function ge(_0x1734da){if(_0x1734da instanceof IDBRequest)return Wc(_0x1734da);if(ni['has'](_0x1734da))return ni['get'](_0x1734da);const _0x5c3833=$c(_0x1734da);return _0x5c3833!==_0x1734da&&(ni['set'](_0x1734da,_0x5c3833),Vi['set'](_0x5c3833,_0x1734da)),_0x5c3833;}const ii=_0x586745=>Vi['get'](_0x586745);function Gc(_0x3ac448,_0x4b807d,{blocked:_0x255adf,upgrade:_0x4bca7a,blocking:_0x1331a0,terminated:_0xb30448}={}){const _0x5d2658=indexedDB['open'](_0x3ac448,_0x4b807d),_0x43103e=ge(_0x5d2658);return _0x4bca7a&&_0x5d2658['addEventListener']('upgradeneeded',_0x4709ab=>{_0x4bca7a(ge(_0x5d2658['result']),_0x4709ab['oldVersion'],_0x4709ab['newVersion'],ge(_0x5d2658['transaction']),_0x4709ab);}),_0x255adf&&_0x5d2658['addEventListener']('blocked',_0x23ca5f=>_0x255adf(_0x23ca5f['oldVersion'],_0x23ca5f['newVersion'],_0x23ca5f)),_0x43103e['then'](_0x5931b7=>{_0xb30448&&_0x5931b7['addEventListener']('close',()=>_0xb30448()),_0x1331a0&&_0x5931b7['addEventListener']('versionchange',_0xc5b5ad=>_0x1331a0(_0xc5b5ad['oldVersion'],_0xc5b5ad['newVersion'],_0xc5b5ad));})['catch'](()=>{}),_0x43103e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x1dfefd,_0x3ae179){if(!(_0x1dfefd instanceof IDBDatabase&&!(_0x3ae179 in _0x1dfefd)&&typeof _0x3ae179=='string'))return;if(si['get'](_0x3ae179))return si['get'](_0x3ae179);const _0x1adfcd=_0x3ae179['replace'](/FromIndex$/,''),_0xa4c1fe=_0x3ae179!==_0x1adfcd,_0x3e3076=zc['includes'](_0x1adfcd);if(!(_0x1adfcd in(_0xa4c1fe?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3e3076||qc['includes'](_0x1adfcd)))return;const _0x4f839c=async function(_0xe34e8b,..._0x24ad28){const _0x2f44a7=this['transaction'](_0xe34e8b,_0x3e3076?'readwrite':'readonly');let _0x4034bd=_0x2f44a7['store'];return _0xa4c1fe&&(_0x4034bd=_0x4034bd['index'](_0x24ad28['shift']())),(await Promise['all']([_0x4034bd[_0x1adfcd](..._0x24ad28),_0x3e3076&&_0x2f44a7['done']]))[0x0];};return si['set'](_0x3ae179,_0x4f839c),_0x4f839c;}Vc(_0x35be1b=>({..._0x35be1b,'get':(_0x331742,_0x3344df,_0x2fddc0)=>Ms(_0x331742,_0x3344df)||_0x35be1b['get'](_0x331742,_0x3344df,_0x2fddc0),'has':(_0x4760c7,_0x591a49)=>!!Ms(_0x4760c7,_0x591a49)||_0x35be1b['has'](_0x4760c7,_0x591a49)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x3cb0a1){this['container']=_0x3cb0a1;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x246d0f=>{if(Kc(_0x246d0f)){const _0x1bbfd1=_0x246d0f['getImmediate']();return _0x1bbfd1['library']+'/'+_0x1bbfd1['version'];}else return null;})['filter'](_0x199318=>_0x199318)['join']('\x20');}}function Kc(_0x5b0ac8){const _0x2e3a77=_0x5b0ac8['getComponent']();return(_0x2e3a77==null?void 0x0:_0x2e3a77['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xc39b3e,_0xaabc52){try{_0xc39b3e['container']['addComponent'](_0xaabc52);}catch(_0x67fe30){oe['debug']('Component\x20'+_0xaabc52['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xc39b3e['name'],_0x67fe30);}}function st(_0x5c7e8d){const _0x7cb91e=_0x5c7e8d['name'];if(Ei['has'](_0x7cb91e))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x7cb91e+'.'),!0x1;Ei['set'](_0x7cb91e,_0x5c7e8d);for(const _0x14cb2f of Ue['values']())xs(_0x14cb2f,_0x5c7e8d);for(const _0x99496e of vi['values']())xs(_0x99496e,_0x5c7e8d);return!0x0;}function Hi(_0x384403,_0x5b90b0){const _0x197cf8=_0x384403['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x197cf8&&_0x197cf8['triggerHeartbeat'](),_0x384403['container']['getProvider'](_0x5b90b0);}function $(_0x1aeb80){return _0x1aeb80==null?!0x1:_0x1aeb80['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4c093d,_0x5a6f53,_0x4c12bd){this['_isDeleted']=!0x1,this['_options']={..._0x4c093d},this['_config']={..._0x5a6f53},this['_name']=_0x5a6f53['name'],this['_automaticDataCollectionEnabled']=_0x5a6f53['automaticDataCollectionEnabled'],this['_container']=_0x4c12bd,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x315000){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x315000;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x362e58){this['_isDeleted']=_0x362e58;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x4a63d8,_0x47f132={}){let _0x5eedea=_0x4a63d8;typeof _0x47f132!='object'&&(_0x47f132={'name':_0x47f132});const _0x2389a4={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x47f132},_0x83afe4=_0x2389a4['name'];if(typeof _0x83afe4!='string'||!_0x83afe4)throw me['create']('bad-app-name',{'appName':String(_0x83afe4)});if(_0x5eedea||(_0x5eedea=zr()),!_0x5eedea)throw me['create']('no-options');const _0x252908=Ue['get'](_0x83afe4);if(_0x252908){if(xe(_0x5eedea,_0x252908['options'])&&xe(_0x2389a4,_0x252908['config']))return _0x252908;throw me['create']('duplicate-app',{'appName':_0x83afe4});}const _0x43a0ea=new Nc(_0x83afe4);for(const _0x50e715 of Ei['values']())_0x43a0ea['addComponent'](_0x50e715);const _0x4c1036=new Tl(_0x5eedea,_0x2389a4,_0x43a0ea);return Ue['set'](_0x83afe4,_0x4c1036),_0x4c1036;}function Zr(_0x561044=yi){const _0x45d35c=Ue['get'](_0x561044);if(!_0x45d35c&&_0x561044===yi&&zr())return Sl();if(!_0x45d35c)throw me['create']('no-app',{'appName':_0x561044});return _0x45d35c;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x11e9a4){let _0x5cacd5=!0x1;const _0x2bd153=_0x11e9a4['name'];Ue['has'](_0x2bd153)?(_0x5cacd5=!0x0,Ue['delete'](_0x2bd153)):vi['has'](_0x2bd153)&&_0x11e9a4['decRefCount']()<=0x0&&(vi['delete'](_0x2bd153),_0x5cacd5=!0x0),_0x5cacd5&&(await Promise['all'](_0x11e9a4['container']['getProviders']()['map'](_0x2f6a0d=>_0x2f6a0d['delete']())),_0x11e9a4['isDeleted']=!0x0);}function ye(_0x1dc0bf,_0x1916f7,_0x5eb9c3){let _0xc74c58=wl[_0x1dc0bf]??_0x1dc0bf;_0x5eb9c3&&(_0xc74c58+='-'+_0x5eb9c3);const _0x5f33c2=_0xc74c58['match'](/\s|\//),_0x10f152=_0x1916f7['match'](/\s|\//);if(_0x5f33c2||_0x10f152){const _0x1ce83d=['Unable\x20to\x20register\x20library\x20\x22'+_0xc74c58+'\x22\x20with\x20version\x20\x22'+_0x1916f7+'\x22:'];_0x5f33c2&&_0x1ce83d['push']('library\x20name\x20\x22'+_0xc74c58+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5f33c2&&_0x10f152&&_0x1ce83d['push']('and'),_0x10f152&&_0x1ce83d['push']('version\x20name\x20\x22'+_0x1916f7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1ce83d['join']('\x20'));return;}st(new Fe(_0xc74c58+'-version',()=>({'library':_0xc74c58,'version':_0x1916f7}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1b09c3,_0x301070)=>{switch(_0x301070){case 0x0:try{_0x1b09c3['createObjectStore'](Ot);}catch(_0x9448e1){console['warn'](_0x9448e1);}}}})['catch'](_0x5eb61b=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5eb61b['message']});})),ri;}async function Al(_0x286b8c){try{const _0x611795=(await eo())['transaction'](Ot),_0x22fdb6=await _0x611795['objectStore'](Ot)['get'](to(_0x286b8c));return await _0x611795['done'],_0x22fdb6;}catch(_0x108cbb){if(_0x108cbb instanceof Re)oe['warn'](_0x108cbb['message']);else{const _0x18519b=me['create']('idb-get',{'originalErrorMessage':_0x108cbb==null?void 0x0:_0x108cbb['message']});oe['warn'](_0x18519b['message']);}}}async function Fs(_0x56bbee,_0x47f8df){try{const _0x15580b=(await eo())['transaction'](Ot,'readwrite');await _0x15580b['objectStore'](Ot)['put'](_0x47f8df,to(_0x56bbee)),await _0x15580b['done'];}catch(_0x46ad1d){if(_0x46ad1d instanceof Re)oe['warn'](_0x46ad1d['message']);else{const _0x451cd0=me['create']('idb-set',{'originalErrorMessage':_0x46ad1d==null?void 0x0:_0x46ad1d['message']});oe['warn'](_0x451cd0['message']);}}}function to(_0x650da7){return _0x650da7['name']+'!'+_0x650da7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x469bcf){this['container']=_0x469bcf,this['_heartbeatsCache']=null;const _0x4a95eb=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4a95eb),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x237655=>(this['_heartbeatsCache']=_0x237655,_0x237655));}async['triggerHeartbeat'](){var _0x528ba5,_0x24b167;try{const _0x4618a5=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4f32e2=Us();if(((_0x528ba5=this['_heartbeatsCache'])==null?void 0x0:_0x528ba5['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x24b167=this['_heartbeatsCache'])==null?void 0x0:_0x24b167['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4f32e2||this['_heartbeatsCache']['heartbeats']['some'](_0x8f5d1c=>_0x8f5d1c['date']===_0x4f32e2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4f32e2,'agent':_0x4618a5}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x4ca932=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x4ca932,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x381ed9){oe['warn'](_0x381ed9);}}async['getHeartbeatsHeader'](){var _0x36b19b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x36b19b=this['_heartbeatsCache'])==null?void 0x0:_0x36b19b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x67ab6b=Us(),{heartbeatsToSend:_0x1be8fd,unsentEntries:_0x424b22}=Ol(this['_heartbeatsCache']['heartbeats']),_0xbf2996=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1be8fd}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x67ab6b,_0x424b22['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x424b22,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xbf2996;}catch(_0xf1c6dd){return oe['warn'](_0xf1c6dd),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2132b0,_0x39b81e=kl){const _0x1a7a4f=[];let _0x49882d=_0x2132b0['slice']();for(const _0x54490e of _0x2132b0){const _0x32f1ad=_0x1a7a4f['find'](_0x30a98a=>_0x30a98a['agent']===_0x54490e['agent']);if(_0x32f1ad){if(_0x32f1ad['dates']['push'](_0x54490e['date']),Ws(_0x1a7a4f)>_0x39b81e){_0x32f1ad['dates']['pop']();break;}}else{if(_0x1a7a4f['push']({'agent':_0x54490e['agent'],'dates':[_0x54490e['date']]}),Ws(_0x1a7a4f)>_0x39b81e){_0x1a7a4f['pop']();break;}}_0x49882d=_0x49882d['slice'](0x1);}return{'heartbeatsToSend':_0x1a7a4f,'unsentEntries':_0x49882d};}class Dl{constructor(_0x2944de){this['app']=_0x2944de,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x18e3ef=await Al(this['app']);return _0x18e3ef!=null&&_0x18e3ef['heartbeats']?_0x18e3ef:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x533abc){if(await this['_canUseIndexedDBPromise']){const _0x3e151c=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x533abc['lastSentHeartbeatDate']??_0x3e151c['lastSentHeartbeatDate'],'heartbeats':_0x533abc['heartbeats']});}else return;}async['add'](_0x596130){if(await this['_canUseIndexedDBPromise']){const _0x1e56a1=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x596130['lastSentHeartbeatDate']??_0x1e56a1['lastSentHeartbeatDate'],'heartbeats':[..._0x1e56a1['heartbeats'],..._0x596130['heartbeats']]});}else return;}}function Ws(_0x5f3895){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x5f3895}))['length'];}function Ml(_0x568452){if(_0x568452['length']===0x0)return-0x1;let _0x38dbfa=0x0,_0x39824a=_0x568452[0x0]['date'];for(let _0x426551=0x1;_0x426551<_0x568452['length'];_0x426551++)_0x568452[_0x426551]['date']<_0x39824a&&(_0x39824a=_0x568452[_0x426551]['date'],_0x38dbfa=_0x426551);return _0x38dbfa;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x410b5a){st(new Fe('platform-logger',_0x3270fd=>new jc(_0x3270fd),'PRIVATE')),st(new Fe('heartbeat',_0x3c9f58=>new Nl(_0x3c9f58),'PRIVATE')),ye(mi,Ls,_0x410b5a),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x4ec13e){no=_0x4ec13e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x162d23){this['domStorage_']=_0x162d23,this['prefix_']='firebase:';}['set'](_0x3e16af,_0x3ad2c3){_0x3ad2c3==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3e16af)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3e16af),O(_0x3ad2c3));}['get'](_0x976779){const _0xdbee99=this['domStorage_']['getItem'](this['prefixedName_'](_0x976779));return _0xdbee99==null?null:Nt(_0xdbee99);}['remove'](_0x20891a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x20891a));}['prefixedName_'](_0x22781e){return this['prefix_']+_0x22781e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x401a43,_0x64e4e8){_0x64e4e8==null?delete this['cache_'][_0x401a43]:this['cache_'][_0x401a43]=_0x64e4e8;}['get'](_0x5bcf14){return Q(this['cache_'],_0x5bcf14)?this['cache_'][_0x5bcf14]:null;}['remove'](_0x468b8c){delete this['cache_'][_0x468b8c];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4cda92){try{if(typeof window<'u'&&typeof window[_0x4cda92]<'u'){const _0x381025=window[_0x4cda92];return _0x381025['setItem']('firebase:sentinel','cache'),_0x381025['removeItem']('firebase:sentinel'),new Wl(_0x381025);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x25ef90=0x1;return function(){return _0x25ef90++;};}()),ro=function(_0x50b4c2){const _0x148408=Rc(_0x50b4c2),_0x4f610a=new Cc();_0x4f610a['update'](_0x148408);const _0x353b47=_0x4f610a['digest']();return Fi['encodeByteArray'](_0x353b47);},zt=function(..._0x103088){let _0x4ed6b2='';for(let _0x4ba6de=0x0;_0x4ba6de<_0x103088['length'];_0x4ba6de++){const _0x2c22fa=_0x103088[_0x4ba6de];Array['isArray'](_0x2c22fa)||_0x2c22fa&&typeof _0x2c22fa=='object'&&typeof _0x2c22fa['length']=='number'?_0x4ed6b2+=zt['apply'](null,_0x2c22fa):typeof _0x2c22fa=='object'?_0x4ed6b2+=O(_0x2c22fa):_0x4ed6b2+=_0x2c22fa,_0x4ed6b2+='\x20';}return _0x4ed6b2;};let St=null,$s=!0x0;const Hl=function(_0x1ba3e0,_0x2fdbcf){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x288eef){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x21e3a6=zt['apply'](null,_0x288eef);St(_0x21e3a6);}},jt=function(_0x1f9db0){return function(..._0x44dbca){L(_0x1f9db0,..._0x44dbca);};},Ii=function(..._0x258322){const _0x1d3ca0='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x258322);Ze['error'](_0x1d3ca0);},ae=function(..._0x2697c1){const _0x5ed71f='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x2697c1);throw Ze['error'](_0x5ed71f),new Error(_0x5ed71f);},U=function(..._0x4d662b){const _0x1098ca='FIREBASE\x20WARNING:\x20'+zt(..._0x4d662b);Ze['warn'](_0x1098ca);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x89c6ce){return typeof _0x89c6ce=='number'&&(_0x89c6ce!==_0x89c6ce||_0x89c6ce===Number['POSITIVE_INFINITY']||_0x89c6ce===Number['NEGATIVE_INFINITY']);},Gl=function(_0x22e813){if(document['readyState']==='complete')_0x22e813();else{let _0x1c2f81=!0x1;const _0x2805a7=function(){if(!document['body']){setTimeout(_0x2805a7,Math['floor'](0xa));return;}_0x1c2f81||(_0x1c2f81=!0x0,_0x22e813());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2805a7,!0x1),window['addEventListener']('load',_0x2805a7,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2805a7();}),window['attachEvent']('onload',_0x2805a7));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4ed410,_0x32f12a){if(_0x4ed410===_0x32f12a)return 0x0;if(_0x4ed410===We||_0x32f12a===we)return-0x1;if(_0x32f12a===We||_0x4ed410===we)return 0x1;{const _0x10d214=Gs(_0x4ed410),_0x105fc4=Gs(_0x32f12a);return _0x10d214!==null?_0x105fc4!==null?_0x10d214-_0x105fc4===0x0?_0x4ed410['length']-_0x32f12a['length']:_0x10d214-_0x105fc4:-0x1:_0x105fc4!==null?0x1:_0x4ed410<_0x32f12a?-0x1:0x1;}},ql=function(_0x5039f0,_0x3aac7c){return _0x5039f0===_0x3aac7c?0x0:_0x5039f0<_0x3aac7c?-0x1:0x1;},vt=function(_0xaae49e,_0x198202){if(_0x198202&&_0xaae49e in _0x198202)return _0x198202[_0xaae49e];throw new Error('Missing\x20required\x20key\x20('+_0xaae49e+')\x20in\x20object:\x20'+O(_0x198202));},$i=function(_0x23a6c5){if(typeof _0x23a6c5!='object'||_0x23a6c5===null)return O(_0x23a6c5);const _0x29155a=[];for(const _0x526102 in _0x23a6c5)_0x29155a['push'](_0x526102);_0x29155a['sort']();let _0x162461='{';for(let _0x4bd9c4=0x0;_0x4bd9c4<_0x29155a['length'];_0x4bd9c4++)_0x4bd9c4!==0x0&&(_0x162461+=','),_0x162461+=O(_0x29155a[_0x4bd9c4]),_0x162461+=':',_0x162461+=$i(_0x23a6c5[_0x29155a[_0x4bd9c4]]);return _0x162461+='}',_0x162461;},oo=function(_0xe180c7,_0x4adb89){const _0x1663bc=_0xe180c7['length'];if(_0x1663bc<=_0x4adb89)return[_0xe180c7];const _0x4529db=[];for(let _0x419b4d=0x0;_0x419b4d<_0x1663bc;_0x419b4d+=_0x4adb89)_0x419b4d+_0x4adb89>_0x1663bc?_0x4529db['push'](_0xe180c7['substring'](_0x419b4d,_0x1663bc)):_0x4529db['push'](_0xe180c7['substring'](_0x419b4d,_0x419b4d+_0x4adb89));return _0x4529db;};function x(_0x32a021,_0x46dcd1){for(const _0x78a172 in _0x32a021)_0x32a021['hasOwnProperty'](_0x78a172)&&_0x46dcd1(_0x78a172,_0x32a021[_0x78a172]);}const ao=function(_0x12c335){f(!xn(_0x12c335),'Invalid\x20JSON\x20number');const _0x227b97=0xb,_0x368fad=0x34,_0x2a448c=(0x1<<_0x227b97-0x1)-0x1;let _0x51a459,_0x2ad272,_0x1dbeb6,_0x45c472,_0x2ed99e;_0x12c335===0x0?(_0x2ad272=0x0,_0x1dbeb6=0x0,_0x51a459=0x1/_0x12c335===-0x1/0x0?0x1:0x0):(_0x51a459=_0x12c335<0x0,_0x12c335=Math['abs'](_0x12c335),_0x12c335>=Math['pow'](0x2,0x1-_0x2a448c)?(_0x45c472=Math['min'](Math['floor'](Math['log'](_0x12c335)/Math['LN2']),_0x2a448c),_0x2ad272=_0x45c472+_0x2a448c,_0x1dbeb6=Math['round'](_0x12c335*Math['pow'](0x2,_0x368fad-_0x45c472)-Math['pow'](0x2,_0x368fad))):(_0x2ad272=0x0,_0x1dbeb6=Math['round'](_0x12c335/Math['pow'](0x2,0x1-_0x2a448c-_0x368fad))));const _0x2bfca3=[];for(_0x2ed99e=_0x368fad;_0x2ed99e;_0x2ed99e-=0x1)_0x2bfca3['push'](_0x1dbeb6%0x2?0x1:0x0),_0x1dbeb6=Math['floor'](_0x1dbeb6/0x2);for(_0x2ed99e=_0x227b97;_0x2ed99e;_0x2ed99e-=0x1)_0x2bfca3['push'](_0x2ad272%0x2?0x1:0x0),_0x2ad272=Math['floor'](_0x2ad272/0x2);_0x2bfca3['push'](_0x51a459?0x1:0x0),_0x2bfca3['reverse']();const _0x4da449=_0x2bfca3['join']('');let _0x3007d4='';for(_0x2ed99e=0x0;_0x2ed99e<0x40;_0x2ed99e+=0x8){let _0x168635=parseInt(_0x4da449['substr'](_0x2ed99e,0x8),0x2)['toString'](0x10);_0x168635['length']===0x1&&(_0x168635='0'+_0x168635),_0x3007d4=_0x3007d4+_0x168635;}return _0x3007d4['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x543be8,_0x214432){let _0x11c53e='Unknown\x20Error';_0x543be8==='too_big'?_0x11c53e='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x543be8==='permission_denied'?_0x11c53e='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x543be8==='unavailable'&&(_0x11c53e='The\x20service\x20is\x20unavailable');const _0x123f57=new Error(_0x543be8+'\x20at\x20'+_0x214432['_path']['toString']()+':\x20'+_0x11c53e);return _0x123f57['code']=_0x543be8['toUpperCase'](),_0x123f57;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x4585f1){if(Yl['test'](_0x4585f1)){const _0x294071=Number(_0x4585f1);if(_0x294071>=Ql&&_0x294071<=Jl)return _0x294071;}return null;},ft=function(_0x1fb1a2){try{_0x1fb1a2();}catch(_0x49b75b){setTimeout(()=>{const _0x57e1c4=_0x49b75b['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x57e1c4),_0x49b75b;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xd3bb11,_0x3373cf){const _0x1b1bcc=setTimeout(_0xd3bb11,_0x3373cf);return typeof _0x1b1bcc=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1b1bcc):typeof _0x1b1bcc=='object'&&_0x1b1bcc['unref']&&_0x1b1bcc['unref'](),_0x1b1bcc;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3c5700,_0xb080a){this['appCheckProvider']=_0xb080a,this['appName']=_0x3c5700['name'],$(_0x3c5700)&&_0x3c5700['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3c5700['settings']['appCheckToken']),this['appCheck']=_0xb080a==null?void 0x0:_0xb080a['getImmediate']({'optional':!0x0}),this['appCheck']||_0xb080a==null||_0xb080a['get']()['then'](_0xc54a0c=>this['appCheck']=_0xc54a0c);}['getToken'](_0x12d2db){if(this['serverAppAppCheckToken']){if(_0x12d2db)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x12d2db):new Promise((_0x5d2063,_0x4914db)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x12d2db)['then'](_0x5d2063,_0x4914db):_0x5d2063(null);},0x0);});}['addTokenChangeListener'](_0x18fbd8){var _0x43971e;(_0x43971e=this['appCheckProvider'])==null||_0x43971e['get']()['then'](_0x22143f=>_0x22143f['addTokenListener'](_0x18fbd8));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2cd452,_0x18c8cf,_0x34766c){this['appName_']=_0x2cd452,this['firebaseOptions_']=_0x18c8cf,this['authProvider_']=_0x34766c,this['auth_']=null,this['auth_']=_0x34766c['getImmediate']({'optional':!0x0}),this['auth_']||_0x34766c['onInit'](_0x2767bc=>this['auth_']=_0x2767bc);}['getToken'](_0x98dd42){return this['auth_']?this['auth_']['getToken'](_0x98dd42)['catch'](_0x2e8ac7=>_0x2e8ac7&&_0x2e8ac7['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2e8ac7)):new Promise((_0x3a6cda,_0xe3fd8c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x98dd42)['then'](_0x3a6cda,_0xe3fd8c):_0x3a6cda(null);},0x0);});}['addTokenChangeListener'](_0x36de10){this['auth_']?this['auth_']['addAuthTokenListener'](_0x36de10):this['authProvider_']['get']()['then'](_0x4921db=>_0x4921db['addAuthTokenListener'](_0x36de10));}['removeTokenChangeListener'](_0x47e895){this['authProvider_']['get']()['then'](_0x597fca=>_0x597fca['removeAuthTokenListener'](_0x47e895));}['notifyForInvalidToken'](){let _0x1e56bb='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1e56bb+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1e56bb+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1e56bb+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1e56bb);}}class an{constructor(_0x3de85a){this['accessToken']=_0x3de85a;}['getToken'](_0x5ba5d5){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3bda02){_0x3bda02(this['accessToken']);}['removeTokenChangeListener'](_0x50455d){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x43bf06,_0x19a0e3,_0x32ee78,_0x949eea,_0x495f59=!0x1,_0x436304='',_0x306251=!0x1,_0x3a03e1=!0x1,_0x32b53c=null){this['secure']=_0x19a0e3,this['namespace']=_0x32ee78,this['webSocketOnly']=_0x949eea,this['nodeAdmin']=_0x495f59,this['persistenceKey']=_0x436304,this['includeNamespaceInQueryParams']=_0x306251,this['isUsingEmulator']=_0x3a03e1,this['emulatorOptions']=_0x32b53c,this['_host']=_0x43bf06['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x43bf06)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xe65d37){_0xe65d37!==this['internalHost']&&(this['internalHost']=_0xe65d37,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x288797=this['toURLString']();return this['persistenceKey']&&(_0x288797+='<'+this['persistenceKey']+'>'),_0x288797;}['toURLString'](){const _0x116dfe=this['secure']?'https://':'http://',_0x59f641=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x116dfe+this['host']+'/'+_0x59f641;}}function th(_0x10143a){return _0x10143a['host']!==_0x10143a['internalHost']||_0x10143a['isCustomHost']()||_0x10143a['includeNamespaceInQueryParams'];}function vo(_0x6a5c3f,_0x4f61ff,_0x2f5bf9){f(typeof _0x4f61ff=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2f5bf9=='object','typeof\x20params\x20must\x20==\x20object');let _0x283efe;if(_0x4f61ff===go)_0x283efe=(_0x6a5c3f['secure']?'wss://':'ws://')+_0x6a5c3f['internalHost']+'/.ws?';else{if(_0x4f61ff===mo)_0x283efe=(_0x6a5c3f['secure']?'https://':'http://')+_0x6a5c3f['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4f61ff);}th(_0x6a5c3f)&&(_0x2f5bf9['ns']=_0x6a5c3f['namespace']);const _0x132022=[];return x(_0x2f5bf9,(_0x10e5c4,_0x119b71)=>{_0x132022['push'](_0x10e5c4+'='+_0x119b71);}),_0x283efe+_0x132022['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x10c5f5,_0x4d34ae=0x1){Q(this['counters_'],_0x10c5f5)||(this['counters_'][_0x10c5f5]=0x0),this['counters_'][_0x10c5f5]+=_0x4d34ae;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x33c880){const _0x4184db=_0x33c880['toString']();return oi[_0x4184db]||(oi[_0x4184db]=new nh()),oi[_0x4184db];}function ih(_0x4d8164,_0x3d7838){const _0x4e6c06=_0x4d8164['toString']();return ai[_0x4e6c06]||(ai[_0x4e6c06]=_0x3d7838()),ai[_0x4e6c06];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4113a0){this['onMessage_']=_0x4113a0,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4b7d0d,_0x57a139){this['closeAfterResponse']=_0x4b7d0d,this['onClose']=_0x57a139,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xaa21f,_0x5d667c){for(this['pendingResponses'][_0xaa21f]=_0x5d667c;this['pendingResponses'][this['currentResponseNum']];){const _0x1107f7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x373d85=0x0;_0x373d85<_0x1107f7['length'];++_0x373d85)_0x1107f7[_0x373d85]&&ft(()=>{this['onMessage_'](_0x1107f7[_0x373d85]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x29741c,_0x22da7e,_0x20d60b,_0x30db93,_0x7f3426,_0x5ad4c9,_0x583467){this['connId']=_0x29741c,this['repoInfo']=_0x22da7e,this['applicationId']=_0x20d60b,this['appCheckToken']=_0x30db93,this['authToken']=_0x7f3426,this['transportSessionId']=_0x5ad4c9,this['lastSessionId']=_0x583467,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x29741c),this['stats_']=qi(_0x22da7e),this['urlFn']=_0x2ebdc2=>(this['appCheckToken']&&(_0x2ebdc2[wi]=this['appCheckToken']),vo(_0x22da7e,mo,_0x2ebdc2));}['open'](_0x32c535,_0x2583c2){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2583c2,this['myPacketOrderer']=new sh(_0x32c535),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5e0388)=>{const [_0x398c9b,_0x3e29f6,_0x25dc87,_0x48ecb2,_0x3930a8]=_0x5e0388;if(this['incrementIncomingBytes_'](_0x5e0388),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x398c9b===qs)this['id']=_0x3e29f6,this['password']=_0x25dc87;else{if(_0x398c9b===rh)_0x3e29f6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3e29f6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x398c9b);}}},(..._0x962a8a)=>{const [_0x32c4cc,_0xbafe3d]=_0x962a8a;this['incrementIncomingBytes_'](_0x962a8a),this['myPacketOrderer']['handleResponse'](_0x32c4cc,_0xbafe3d);},()=>{this['onClosed_']();},this['urlFn']);const _0x5a74c8={};_0x5a74c8[qs]='t',_0x5a74c8[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5a74c8[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5a74c8[co]=Gi,this['transportSessionId']&&(_0x5a74c8[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5a74c8[po]=this['lastSessionId']),this['applicationId']&&(_0x5a74c8[_o]=this['applicationId']),this['appCheckToken']&&(_0x5a74c8[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5a74c8[ho]=uo);const _0x1d2353=this['urlFn'](_0x5a74c8);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1d2353),this['scriptTagHolder']['addTag'](_0x1d2353,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x277788){const _0x4f312a=O(_0x277788);this['bytesSent']+=_0x4f312a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4f312a['length']);const _0x5a5bee=$r(_0x4f312a),_0x3a01e8=oo(_0x5a5bee,fh);for(let _0x425529=0x0;_0x425529<_0x3a01e8['length'];_0x425529++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3a01e8['length'],_0x3a01e8[_0x425529]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1b8594,_0x19b450){this['myDisconnFrame']=document['createElement']('iframe');const _0x473e7b={};_0x473e7b[dh]='t',_0x473e7b[Eo]=_0x1b8594,_0x473e7b[Io]=_0x19b450,this['myDisconnFrame']['src']=this['urlFn'](_0x473e7b),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x29940f){const _0x408c03=O(_0x29940f)['length'];this['bytesReceived']+=_0x408c03,this['stats_']['incrementCounter']('bytes_received',_0x408c03);}}class zi{constructor(_0x2a5301,_0x5c0f1b,_0x4eb91e,_0x26cdf1){this['onDisconnect']=_0x4eb91e,this['urlFn']=_0x26cdf1,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2a5301,window[ah+this['uniqueCallbackIdentifier']]=_0x5c0f1b,this['myIFrame']=zi['createIFrame_']();let _0x5b25c4='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5b25c4='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x335a7c='<html><body>'+_0x5b25c4+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x335a7c),this['myIFrame']['doc']['close']();}catch(_0x5a1e0f){L('frame\x20writing\x20exception'),_0x5a1e0f['stack']&&L(_0x5a1e0f['stack']),L(_0x5a1e0f);}}}static['createIFrame_'](){const _0x952577=document['createElement']('iframe');if(_0x952577['style']['display']='none',document['body']){document['body']['appendChild'](_0x952577);try{_0x952577['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2ab0c7=document['domain'];_0x952577['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2ab0c7+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x952577['contentDocument']?_0x952577['doc']=_0x952577['contentDocument']:_0x952577['contentWindow']?_0x952577['doc']=_0x952577['contentWindow']['document']:_0x952577['document']&&(_0x952577['doc']=_0x952577['document']),_0x952577;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x33238d=this['onDisconnect'];_0x33238d&&(this['onDisconnect']=null,_0x33238d());}['startLongPoll'](_0x53f3ed,_0x3bee6d){for(this['myID']=_0x53f3ed,this['myPW']=_0x3bee6d,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x19af02={};_0x19af02[Eo]=this['myID'],_0x19af02[Io]=this['myPW'],_0x19af02[wo]=this['currentSerial'];let _0x13a418=this['urlFn'](_0x19af02),_0x5edccd='',_0x4ece90=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5edccd['length']<=Co;){const _0x28c5a6=this['pendingSegs']['shift']();_0x5edccd=_0x5edccd+'&'+lh+_0x4ece90+'='+_0x28c5a6['seg']+'&'+hh+_0x4ece90+'='+_0x28c5a6['ts']+'&'+uh+_0x4ece90+'='+_0x28c5a6['d'],_0x4ece90++;}return _0x13a418=_0x13a418+_0x5edccd,this['addLongPollTag_'](_0x13a418,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3da50c,_0x3ab3c6,_0x1eb256){this['pendingSegs']['push']({'seg':_0x3da50c,'ts':_0x3ab3c6,'d':_0x1eb256}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x45c104,_0x4ae862){this['outstandingRequests']['add'](_0x4ae862);const _0x55aabd=()=>{this['outstandingRequests']['delete'](_0x4ae862),this['newRequest_']();},_0x31024e=setTimeout(_0x55aabd,Math['floor'](ph)),_0x22f99e=()=>{clearTimeout(_0x31024e),_0x55aabd();};this['addTag'](_0x45c104,_0x22f99e);}['addTag'](_0x5dfc46,_0x4e2bc4){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x24a537=this['myIFrame']['doc']['createElement']('script');_0x24a537['type']='text/javascript',_0x24a537['async']=!0x0,_0x24a537['src']=_0x5dfc46,_0x24a537['onload']=_0x24a537['onreadystatechange']=function(){const _0x139679=_0x24a537['readyState'];(!_0x139679||_0x139679==='loaded'||_0x139679==='complete')&&(_0x24a537['onload']=_0x24a537['onreadystatechange']=null,_0x24a537['parentNode']&&_0x24a537['parentNode']['removeChild'](_0x24a537),_0x4e2bc4());},_0x24a537['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5dfc46),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x24a537);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x543175,_0x988529,_0xcf7774,_0x5df418,_0x3144fd,_0x3d36f6,_0x44b252){this['connId']=_0x543175,this['applicationId']=_0xcf7774,this['appCheckToken']=_0x5df418,this['authToken']=_0x3144fd,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x988529),this['connURL']=q['connectionURL_'](_0x988529,_0x3d36f6,_0x44b252,_0x5df418,_0xcf7774),this['nodeAdmin']=_0x988529['nodeAdmin'];}static['connectionURL_'](_0x5d1c3b,_0x168a9f,_0x198029,_0x43d575,_0x446fab){const _0x4ab1b8={};return _0x4ab1b8[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4ab1b8[ho]=uo),_0x168a9f&&(_0x4ab1b8[lo]=_0x168a9f),_0x198029&&(_0x4ab1b8[po]=_0x198029),_0x43d575&&(_0x4ab1b8[wi]=_0x43d575),_0x446fab&&(_0x4ab1b8[_o]=_0x446fab),vo(_0x5d1c3b,go,_0x4ab1b8);}['open'](_0x43ade4,_0x5d4a87){this['onDisconnect']=_0x5d4a87,this['onMessage']=_0x43ade4,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4f4fa6;_c(),this['mySock']=new gn(this['connURL'],[],_0x4f4fa6);}catch(_0x4a429b){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1e8dcd=_0x4a429b['message']||_0x4a429b['data'];_0x1e8dcd&&this['log_'](_0x1e8dcd),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3f19e9=>{this['handleIncomingFrame'](_0x3f19e9);},this['mySock']['onerror']=_0x5d0725=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3303c6=_0x5d0725['message']||_0x5d0725['data'];_0x3303c6&&this['log_'](_0x3303c6),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x203634=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x210022=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xabb85a=navigator['userAgent']['match'](_0x210022);_0xabb85a&&_0xabb85a['length']>0x1&&parseFloat(_0xabb85a[0x1])<4.4&&(_0x203634=!0x0);}return!_0x203634&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x1885b5){if(this['frames']['push'](_0x1885b5),this['frames']['length']===this['totalFrames']){const _0x2a4c9a=this['frames']['join']('');this['frames']=null;const _0x4afa74=Nt(_0x2a4c9a);this['onMessage'](_0x4afa74);}}['handleNewFrameCount_'](_0x392ec3){this['totalFrames']=_0x392ec3,this['frames']=[];}['extractFrameCount_'](_0x2d9c50){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2d9c50['length']<=0x6){const _0x379a74=Number(_0x2d9c50);if(!isNaN(_0x379a74))return this['handleNewFrameCount_'](_0x379a74),null;}return this['handleNewFrameCount_'](0x1),_0x2d9c50;}['handleIncomingFrame'](_0x3ff009){if(this['mySock']===null)return;const _0xf0b4ce=_0x3ff009['data'];if(this['bytesReceived']+=_0xf0b4ce['length'],this['stats_']['incrementCounter']('bytes_received',_0xf0b4ce['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0xf0b4ce);else{const _0x5df8c5=this['extractFrameCount_'](_0xf0b4ce);_0x5df8c5!==null&&this['appendFrame_'](_0x5df8c5);}}['send'](_0x34cde1){this['resetKeepAlive']();const _0x47282f=O(_0x34cde1);this['bytesSent']+=_0x47282f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x47282f['length']);const _0x5847fd=oo(_0x47282f,gh);_0x5847fd['length']>0x1&&this['sendString_'](String(_0x5847fd['length']));for(let _0x1e3655=0x0;_0x1e3655<_0x5847fd['length'];_0x1e3655++)this['sendString_'](_0x5847fd[_0x1e3655]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2d5b6d){try{this['mySock']['send'](_0x2d5b6d);}catch(_0x4456a3){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4456a3['message']||_0x4456a3['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1f3f88){this['initTransports_'](_0x1f3f88);}['initTransports_'](_0x376779){const _0x7ba1a6=q&&q['isAvailable']();let _0x4b8fb0=_0x7ba1a6&&!q['previouslyFailed']();if(_0x376779['webSocketOnly']&&(_0x7ba1a6||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4b8fb0=!0x0),_0x4b8fb0)this['transports_']=[q];else{const _0x5e1f2f=this['transports_']=[];for(const _0x503cd8 of Dt['ALL_TRANSPORTS'])_0x503cd8&&_0x503cd8['isAvailable']()&&_0x5e1f2f['push'](_0x503cd8);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3daef8,_0x3f10de,_0x47e6d7,_0x2d9723,_0x556dd3,_0x343bc0,_0x5b42ab,_0x3b4d6a,_0x340496,_0x2e8f85){this['id']=_0x3daef8,this['repoInfo_']=_0x3f10de,this['applicationId_']=_0x47e6d7,this['appCheckToken_']=_0x2d9723,this['authToken_']=_0x556dd3,this['onMessage_']=_0x343bc0,this['onReady_']=_0x5b42ab,this['onDisconnect_']=_0x3b4d6a,this['onKill_']=_0x340496,this['lastSessionId']=_0x2e8f85,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3f10de),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4f6fd5=this['transportManager_']['initialTransport']();this['conn_']=new _0x4f6fd5(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4f6fd5['responsesRequiredToBeHealthy']||0x0;const _0x5410a0=this['connReceiver_'](this['conn_']),_0x41b67d=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5410a0,_0x41b67d);},Math['floor'](0x0));const _0x35458a=_0x4f6fd5['healthyTimeout']||0x0;_0x35458a>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x35458a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2c16d3){return _0x414040=>{_0x2c16d3===this['conn_']?this['onConnectionLost_'](_0x414040):_0x2c16d3===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x7e8d95){return _0x294cdf=>{this['state_']!==0x2&&(_0x7e8d95===this['rx_']?this['onPrimaryMessageReceived_'](_0x294cdf):_0x7e8d95===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x294cdf):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ff2cd){const _0x570aa7={'t':'d','d':_0x3ff2cd};this['sendData_'](_0x570aa7);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x342be6){if(ci in _0x342be6){const _0x4da05a=_0x342be6[ci];_0x4da05a===Ys?this['upgradeIfSecondaryHealthy_']():_0x4da05a===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4da05a===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x36f5d3){const _0x671fba=vt('t',_0x36f5d3),_0x269f65=vt('d',_0x36f5d3);if(_0x671fba==='c')this['onSecondaryControl_'](_0x269f65);else{if(_0x671fba==='d')this['pendingDataMessages']['push'](_0x269f65);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x671fba);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3792a6){const _0x5d4d3f=vt('t',_0x3792a6),_0x368619=vt('d',_0x3792a6);_0x5d4d3f==='c'?this['onControl_'](_0x368619):_0x5d4d3f==='d'&&this['onDataMessage_'](_0x368619);}['onDataMessage_'](_0x4e591f){this['onPrimaryResponse_'](),this['onMessage_'](_0x4e591f);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4ab4ef){const _0x50052b=vt(ci,_0x4ab4ef);if(zs in _0x4ab4ef){const _0x19b768=_0x4ab4ef[zs];if(_0x50052b===Th){const _0x340b4d={..._0x19b768};this['repoInfo_']['isUsingEmulator']&&(_0x340b4d['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x340b4d);}else{if(_0x50052b===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3ca62d=0x0;_0x3ca62d<this['pendingDataMessages']['length'];++_0x3ca62d)this['onDataMessage_'](this['pendingDataMessages'][_0x3ca62d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x50052b===wh?this['onConnectionShutdown_'](_0x19b768):_0x50052b===js?this['onReset_'](_0x19b768):_0x50052b===Ch?Ii('Server\x20Error:\x20'+_0x19b768):_0x50052b===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x50052b);}}}['onHandshake_'](_0x173a3b){const _0x583668=_0x173a3b['ts'],_0x23222c=_0x173a3b['v'],_0x57e3ec=_0x173a3b['h'];this['sessionId']=_0x173a3b['s'],this['repoInfo_']['host']=_0x57e3ec,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x583668),Gi!==_0x23222c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x40f9ed=this['transportManager_']['upgradeTransport']();_0x40f9ed&&this['startUpgrade_'](_0x40f9ed);}['startUpgrade_'](_0x50d920){this['secondaryConn_']=new _0x50d920(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x50d920['responsesRequiredToBeHealthy']||0x0;const _0x131942=this['connReceiver_'](this['secondaryConn_']),_0x1f7a57=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x131942,_0x1f7a57),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x473232){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x473232),this['repoInfo_']['host']=_0x473232,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2213d9,_0x2804e0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2213d9,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2804e0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x382caf=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x382caf||this['rx_']===_0x382caf)&&this['close']();}['onConnectionLost_'](_0x44c18a){this['conn_']=null,!_0x44c18a&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3c6599){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3c6599),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x377c05){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x377c05);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1938b7,_0x2d3aaa,_0x45b66b,_0x389ba5){}['merge'](_0x255766,_0x33f222,_0x3a6f81,_0x5f5d73){}['refreshAuthToken'](_0x4f25fb){}['refreshAppCheckToken'](_0x6ff123){}['onDisconnectPut'](_0x5002a9,_0x288b7e,_0x4c7c5e){}['onDisconnectMerge'](_0x40809d,_0x52de30,_0x345535){}['onDisconnectCancel'](_0x40c8d8,_0x11e73c){}['reportStats'](_0x2614cb){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x27b42d){this['allowedEvents_']=_0x27b42d,this['listeners_']={},f(Array['isArray'](_0x27b42d)&&_0x27b42d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2c9785,..._0x3608cf){if(Array['isArray'](this['listeners_'][_0x2c9785])){const _0x1de8c8=[...this['listeners_'][_0x2c9785]];for(let _0x5ccccb=0x0;_0x5ccccb<_0x1de8c8['length'];_0x5ccccb++)_0x1de8c8[_0x5ccccb]['callback']['apply'](_0x1de8c8[_0x5ccccb]['context'],_0x3608cf);}}['on'](_0x457208,_0x240af2,_0x43c1ed){this['validateEventType_'](_0x457208),this['listeners_'][_0x457208]=this['listeners_'][_0x457208]||[],this['listeners_'][_0x457208]['push']({'callback':_0x240af2,'context':_0x43c1ed});const _0x3746a4=this['getInitialEvent'](_0x457208);_0x3746a4&&_0x240af2['apply'](_0x43c1ed,_0x3746a4);}['off'](_0x557d22,_0x25cdba,_0x56ccb2){this['validateEventType_'](_0x557d22);const _0x3ee431=this['listeners_'][_0x557d22]||[];for(let _0x53d389=0x0;_0x53d389<_0x3ee431['length'];_0x53d389++)if(_0x3ee431[_0x53d389]['callback']===_0x25cdba&&(!_0x56ccb2||_0x56ccb2===_0x3ee431[_0x53d389]['context'])){_0x3ee431['splice'](_0x53d389,0x1);return;}}['validateEventType_'](_0x454cb0){f(this['allowedEvents_']['find'](_0x21450e=>_0x21450e===_0x454cb0),'Unknown\x20event:\x20'+_0x454cb0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x38bc7e){return f(_0x38bc7e==='online','Unknown\x20event\x20type:\x20'+_0x38bc7e),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x420a34,_0x11f74f){if(_0x11f74f===void 0x0){this['pieces_']=_0x420a34['split']('/');let _0x22867a=0x0;for(let _0x3e10f5=0x0;_0x3e10f5<this['pieces_']['length'];_0x3e10f5++)this['pieces_'][_0x3e10f5]['length']>0x0&&(this['pieces_'][_0x22867a]=this['pieces_'][_0x3e10f5],_0x22867a++);this['pieces_']['length']=_0x22867a,this['pieceNum_']=0x0;}else this['pieces_']=_0x420a34,this['pieceNum_']=_0x11f74f;}['toString'](){let _0x10c25f='';for(let _0x350d29=this['pieceNum_'];_0x350d29<this['pieces_']['length'];_0x350d29++)this['pieces_'][_0x350d29]!==''&&(_0x10c25f+='/'+this['pieces_'][_0x350d29]);return _0x10c25f||'/';}}function w(){return new C('');}function y(_0x4e5083){return _0x4e5083['pieceNum_']>=_0x4e5083['pieces_']['length']?null:_0x4e5083['pieces_'][_0x4e5083['pieceNum_']];}function Ce(_0x20831f){return _0x20831f['pieces_']['length']-_0x20831f['pieceNum_'];}function S(_0x3c4bcd){let _0x5e9103=_0x3c4bcd['pieceNum_'];return _0x5e9103<_0x3c4bcd['pieces_']['length']&&_0x5e9103++,new C(_0x3c4bcd['pieces_'],_0x5e9103);}function ji(_0x1509fe){return _0x1509fe['pieceNum_']<_0x1509fe['pieces_']['length']?_0x1509fe['pieces_'][_0x1509fe['pieces_']['length']-0x1]:null;}function bh(_0x158b49){let _0x29ed5b='';for(let _0x5e8ab7=_0x158b49['pieceNum_'];_0x5e8ab7<_0x158b49['pieces_']['length'];_0x5e8ab7++)_0x158b49['pieces_'][_0x5e8ab7]!==''&&(_0x29ed5b+='/'+encodeURIComponent(String(_0x158b49['pieces_'][_0x5e8ab7])));return _0x29ed5b||'/';}function Mt(_0x273b6a,_0x18f6d4=0x0){return _0x273b6a['pieces_']['slice'](_0x273b6a['pieceNum_']+_0x18f6d4);}function Ro(_0x4116d0){if(_0x4116d0['pieceNum_']>=_0x4116d0['pieces_']['length'])return null;const _0x30a7e4=[];for(let _0x46989b=_0x4116d0['pieceNum_'];_0x46989b<_0x4116d0['pieces_']['length']-0x1;_0x46989b++)_0x30a7e4['push'](_0x4116d0['pieces_'][_0x46989b]);return new C(_0x30a7e4,0x0);}function k(_0x3d77da,_0x21fb7a){const _0x1d60cc=[];for(let _0x214d62=_0x3d77da['pieceNum_'];_0x214d62<_0x3d77da['pieces_']['length'];_0x214d62++)_0x1d60cc['push'](_0x3d77da['pieces_'][_0x214d62]);if(_0x21fb7a instanceof C){for(let _0x464539=_0x21fb7a['pieceNum_'];_0x464539<_0x21fb7a['pieces_']['length'];_0x464539++)_0x1d60cc['push'](_0x21fb7a['pieces_'][_0x464539]);}else{const _0x165a7f=_0x21fb7a['split']('/');for(let _0x1c3bc0=0x0;_0x1c3bc0<_0x165a7f['length'];_0x1c3bc0++)_0x165a7f[_0x1c3bc0]['length']>0x0&&_0x1d60cc['push'](_0x165a7f[_0x1c3bc0]);}return new C(_0x1d60cc,0x0);}function v(_0x59ee33){return _0x59ee33['pieceNum_']>=_0x59ee33['pieces_']['length'];}function F(_0x30c692,_0x3752c9){const _0x4a068c=y(_0x30c692),_0x2004eb=y(_0x3752c9);if(_0x4a068c===null)return _0x3752c9;if(_0x4a068c===_0x2004eb)return F(S(_0x30c692),S(_0x3752c9));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x3752c9+')\x20is\x20not\x20within\x20outerPath\x20('+_0x30c692+')');}function Rh(_0x59438f,_0x46623b){const _0xb1084f=Mt(_0x59438f,0x0),_0x20e50b=Mt(_0x46623b,0x0);for(let _0x3200d7=0x0;_0x3200d7<_0xb1084f['length']&&_0x3200d7<_0x20e50b['length'];_0x3200d7++){const _0x330bf7=qe(_0xb1084f[_0x3200d7],_0x20e50b[_0x3200d7]);if(_0x330bf7!==0x0)return _0x330bf7;}return _0xb1084f['length']===_0x20e50b['length']?0x0:_0xb1084f['length']<_0x20e50b['length']?-0x1:0x1;}function Ki(_0x2c0cf1,_0x2d1dd5){if(Ce(_0x2c0cf1)!==Ce(_0x2d1dd5))return!0x1;for(let _0x481110=_0x2c0cf1['pieceNum_'],_0x54e295=_0x2d1dd5['pieceNum_'];_0x481110<=_0x2c0cf1['pieces_']['length'];_0x481110++,_0x54e295++)if(_0x2c0cf1['pieces_'][_0x481110]!==_0x2d1dd5['pieces_'][_0x54e295])return!0x1;return!0x0;}function G(_0x18e497,_0xc9453b){let _0x2ef06e=_0x18e497['pieceNum_'],_0x236fdb=_0xc9453b['pieceNum_'];if(Ce(_0x18e497)>Ce(_0xc9453b))return!0x1;for(;_0x2ef06e<_0x18e497['pieces_']['length'];){if(_0x18e497['pieces_'][_0x2ef06e]!==_0xc9453b['pieces_'][_0x236fdb])return!0x1;++_0x2ef06e,++_0x236fdb;}return!0x0;}class Ah{constructor(_0x2b1100,_0x32ebd5){this['errorPrefix_']=_0x32ebd5,this['parts_']=Mt(_0x2b1100,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1fb9aa=0x0;_0x1fb9aa<this['parts_']['length'];_0x1fb9aa++)this['byteLength_']+=Ln(this['parts_'][_0x1fb9aa]);Ao(this);}}function kh(_0x5675fe,_0x32a292){_0x5675fe['parts_']['length']>0x0&&(_0x5675fe['byteLength_']+=0x1),_0x5675fe['parts_']['push'](_0x32a292),_0x5675fe['byteLength_']+=Ln(_0x32a292),Ao(_0x5675fe);}function Ph(_0x2c1de9){const _0x5f5dd7=_0x2c1de9['parts_']['pop']();_0x2c1de9['byteLength_']-=Ln(_0x5f5dd7),_0x2c1de9['parts_']['length']>0x0&&(_0x2c1de9['byteLength_']-=0x1);}function Ao(_0x27d5ad){if(_0x27d5ad['byteLength_']>Zs)throw new Error(_0x27d5ad['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x27d5ad['byteLength_']+').');if(_0x27d5ad['parts_']['length']>Xs)throw new Error(_0x27d5ad['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x27d5ad));}function Oe(_0x4f3fbd){return _0x4f3fbd['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4f3fbd['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x4530e6,_0x4e7c07;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4e7c07='visibilitychange',_0x4530e6='hidden'):typeof document['mozHidden']<'u'?(_0x4e7c07='mozvisibilitychange',_0x4530e6='mozHidden'):typeof document['msHidden']<'u'?(_0x4e7c07='msvisibilitychange',_0x4530e6='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4e7c07='webkitvisibilitychange',_0x4530e6='webkitHidden')),this['visible_']=!0x0,_0x4e7c07&&document['addEventListener'](_0x4e7c07,()=>{const _0x48f62e=!document[_0x4530e6];_0x48f62e!==this['visible_']&&(this['visible_']=_0x48f62e,this['trigger']('visible',_0x48f62e));},!0x1);}['getInitialEvent'](_0x5e1817){return f(_0x5e1817==='visible','Unknown\x20event\x20type:\x20'+_0x5e1817),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x17861e,_0x4be574,_0x366ba2,_0xc2a1df,_0x1234e7,_0x288875,_0x19b9a3,_0x66120){if(super(),this['repoInfo_']=_0x17861e,this['applicationId_']=_0x4be574,this['onDataUpdate_']=_0x366ba2,this['onConnectStatus_']=_0xc2a1df,this['onServerInfoUpdate_']=_0x1234e7,this['authTokenProvider_']=_0x288875,this['appCheckTokenProvider_']=_0x19b9a3,this['authOverride_']=_0x66120,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x66120)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x17861e['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3295da,_0x1dc3e4,_0x59ceae){const _0x36c5c9=++this['requestNumber_'],_0x12e792={'r':_0x36c5c9,'a':_0x3295da,'b':_0x1dc3e4};this['log_'](O(_0x12e792)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x12e792),_0x59ceae&&(this['requestCBHash_'][_0x36c5c9]=_0x59ceae);}['get'](_0x21c8ae){this['initConnection_']();const _0x5e484e=new H(),_0x3e9f41={'action':'g','request':{'p':_0x21c8ae['_path']['toString'](),'q':_0x21c8ae['_queryObject']},'onComplete':_0x287b7c=>{const _0x52db83=_0x287b7c['d'];_0x287b7c['s']==='ok'?_0x5e484e['resolve'](_0x52db83):_0x5e484e['reject'](_0x52db83);}};this['outstandingGets_']['push'](_0x3e9f41),this['outstandingGetCount_']++;const _0x1454ad=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1454ad),_0x5e484e['promise'];}['listen'](_0x3b958f,_0x25e41b,_0xd39540,_0x445118){this['initConnection_']();const _0x557192=_0x3b958f['_queryIdentifier'],_0x16b80d=_0x3b958f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x16b80d+'\x20'+_0x557192),this['listens']['has'](_0x16b80d)||this['listens']['set'](_0x16b80d,new Map()),f(_0x3b958f['_queryParams']['isDefault']()||!_0x3b958f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x16b80d)['has'](_0x557192),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x374b29={'onComplete':_0x445118,'hashFn':_0x25e41b,'query':_0x3b958f,'tag':_0xd39540};this['listens']['get'](_0x16b80d)['set'](_0x557192,_0x374b29),this['connected_']&&this['sendListen_'](_0x374b29);}['sendGet_'](_0x2be417){const _0x2293bc=this['outstandingGets_'][_0x2be417];this['sendRequest']('g',_0x2293bc['request'],_0x588b20=>{delete this['outstandingGets_'][_0x2be417],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2293bc['onComplete']&&_0x2293bc['onComplete'](_0x588b20);});}['sendListen_'](_0x263f43){const _0x4bccc9=_0x263f43['query'],_0x37d2dc=_0x4bccc9['_path']['toString'](),_0x3c336c=_0x4bccc9['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x37d2dc+'\x20for\x20'+_0x3c336c);const _0x2f74dc={'p':_0x37d2dc},_0x19a0da='q';_0x263f43['tag']&&(_0x2f74dc['q']=_0x4bccc9['_queryObject'],_0x2f74dc['t']=_0x263f43['tag']),_0x2f74dc['h']=_0x263f43['hashFn'](),this['sendRequest'](_0x19a0da,_0x2f74dc,_0x4aa566=>{const _0x28c324=_0x4aa566['d'],_0x108aa1=_0x4aa566['s'];se['warnOnListenWarnings_'](_0x28c324,_0x4bccc9),(this['listens']['get'](_0x37d2dc)&&this['listens']['get'](_0x37d2dc)['get'](_0x3c336c))===_0x263f43&&(this['log_']('listen\x20response',_0x4aa566),_0x108aa1!=='ok'&&this['removeListen_'](_0x37d2dc,_0x3c336c),_0x263f43['onComplete']&&_0x263f43['onComplete'](_0x108aa1,_0x28c324));});}static['warnOnListenWarnings_'](_0x12f9d0,_0x1bdf04){if(_0x12f9d0&&typeof _0x12f9d0=='object'&&Q(_0x12f9d0,'w')){const _0x1338fb=Le(_0x12f9d0,'w');if(Array['isArray'](_0x1338fb)&&~_0x1338fb['indexOf']('no_index')){const _0x48f740='\x22.indexOn\x22:\x20\x22'+_0x1bdf04['_queryParams']['getIndex']()['toString']()+'\x22',_0x45b38f=_0x1bdf04['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x48f740+'\x20at\x20'+_0x45b38f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1a4905){this['authToken_']=_0x1a4905,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1a4905);}['reduceReconnectDelayIfAdminCredential_'](_0xffb44b){(_0xffb44b&&_0xffb44b['length']===0x28||wc(_0xffb44b))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0xa65fab){this['appCheckToken_']=_0xa65fab,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x30dabd=this['authToken_'],_0x309481=Ic(_0x30dabd)?'auth':'gauth',_0x3528a={'cred':_0x30dabd};this['authOverride_']===null?_0x3528a['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x3528a['authvar']=this['authOverride_']),this['sendRequest'](_0x309481,_0x3528a,_0x1274c9=>{const _0x931c2a=_0x1274c9['s'],_0x580582=_0x1274c9['d']||'error';this['authToken_']===_0x30dabd&&(_0x931c2a==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x931c2a,_0x580582));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2d6625=>{const _0x2eefcf=_0x2d6625['s'],_0x10a580=_0x2d6625['d']||'error';_0x2eefcf==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2eefcf,_0x10a580);});}['unlisten'](_0x541bde,_0x4e0207){const _0x13838b=_0x541bde['_path']['toString'](),_0x3c6339=_0x541bde['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x13838b+'\x20'+_0x3c6339),f(_0x541bde['_queryParams']['isDefault']()||!_0x541bde['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x13838b,_0x3c6339)&&this['connected_']&&this['sendUnlisten_'](_0x13838b,_0x3c6339,_0x541bde['_queryObject'],_0x4e0207);}['sendUnlisten_'](_0x5426cf,_0x30acbd,_0x4e6e6e,_0x3d25cb){this['log_']('Unlisten\x20on\x20'+_0x5426cf+'\x20for\x20'+_0x30acbd);const _0x122cfc={'p':_0x5426cf},_0x2545cf='n';_0x3d25cb&&(_0x122cfc['q']=_0x4e6e6e,_0x122cfc['t']=_0x3d25cb),this['sendRequest'](_0x2545cf,_0x122cfc);}['onDisconnectPut'](_0x3bccdf,_0x4f9de8,_0x2d189f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3bccdf,_0x4f9de8,_0x2d189f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3bccdf,'action':'o','data':_0x4f9de8,'onComplete':_0x2d189f});}['onDisconnectMerge'](_0x94df6,_0x3bdeeb,_0x2e54e7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x94df6,_0x3bdeeb,_0x2e54e7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x94df6,'action':'om','data':_0x3bdeeb,'onComplete':_0x2e54e7});}['onDisconnectCancel'](_0xed2827,_0x5a87d4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xed2827,null,_0x5a87d4):this['onDisconnectRequestQueue_']['push']({'pathString':_0xed2827,'action':'oc','data':null,'onComplete':_0x5a87d4});}['sendOnDisconnect_'](_0x3baf66,_0x4a64a6,_0x45649b,_0x209021){const _0x358d3e={'p':_0x4a64a6,'d':_0x45649b};this['log_']('onDisconnect\x20'+_0x3baf66,_0x358d3e),this['sendRequest'](_0x3baf66,_0x358d3e,_0x2cbf0d=>{_0x209021&&setTimeout(()=>{_0x209021(_0x2cbf0d['s'],_0x2cbf0d['d']);},Math['floor'](0x0));});}['put'](_0x501dab,_0x409b27,_0x28523b,_0x4a846a){this['putInternal']('p',_0x501dab,_0x409b27,_0x28523b,_0x4a846a);}['merge'](_0x3d359c,_0x2de7cd,_0xb4740c,_0x3e7269){this['putInternal']('m',_0x3d359c,_0x2de7cd,_0xb4740c,_0x3e7269);}['putInternal'](_0x475df3,_0x3de992,_0x25df0b,_0x114eef,_0x30467b){this['initConnection_']();const _0x75c94={'p':_0x3de992,'d':_0x25df0b};_0x30467b!==void 0x0&&(_0x75c94['h']=_0x30467b),this['outstandingPuts_']['push']({'action':_0x475df3,'request':_0x75c94,'onComplete':_0x114eef}),this['outstandingPutCount_']++;const _0x34b459=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x34b459):this['log_']('Buffering\x20put:\x20'+_0x3de992);}['sendPut_'](_0x447397){const _0x4aeb2e=this['outstandingPuts_'][_0x447397]['action'],_0x3a6c0e=this['outstandingPuts_'][_0x447397]['request'],_0x27540c=this['outstandingPuts_'][_0x447397]['onComplete'];this['outstandingPuts_'][_0x447397]['queued']=this['connected_'],this['sendRequest'](_0x4aeb2e,_0x3a6c0e,_0x962d76=>{this['log_'](_0x4aeb2e+'\x20response',_0x962d76),delete this['outstandingPuts_'][_0x447397],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x27540c&&_0x27540c(_0x962d76['s'],_0x962d76['d']);});}['reportStats'](_0x217c6f){if(this['connected_']){const _0x4491b1={'c':_0x217c6f};this['log_']('reportStats',_0x4491b1),this['sendRequest']('s',_0x4491b1,_0x2e0f8e=>{if(_0x2e0f8e['s']!=='ok'){const _0x448f50=_0x2e0f8e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x448f50);}});}}['onDataMessage_'](_0x4c2fd0){if('r'in _0x4c2fd0){this['log_']('from\x20server:\x20'+O(_0x4c2fd0));const _0x3fd526=_0x4c2fd0['r'],_0x35ac7d=this['requestCBHash_'][_0x3fd526];_0x35ac7d&&(delete this['requestCBHash_'][_0x3fd526],_0x35ac7d(_0x4c2fd0['b']));}else{if('error'in _0x4c2fd0)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4c2fd0['error'];'a'in _0x4c2fd0&&this['onDataPush_'](_0x4c2fd0['a'],_0x4c2fd0['b']);}}['onDataPush_'](_0x3c6727,_0x5e377d){this['log_']('handleServerMessage',_0x3c6727,_0x5e377d),_0x3c6727==='d'?this['onDataUpdate_'](_0x5e377d['p'],_0x5e377d['d'],!0x1,_0x5e377d['t']):_0x3c6727==='m'?this['onDataUpdate_'](_0x5e377d['p'],_0x5e377d['d'],!0x0,_0x5e377d['t']):_0x3c6727==='c'?this['onListenRevoked_'](_0x5e377d['p'],_0x5e377d['q']):_0x3c6727==='ac'?this['onAuthRevoked_'](_0x5e377d['s'],_0x5e377d['d']):_0x3c6727==='apc'?this['onAppCheckRevoked_'](_0x5e377d['s'],_0x5e377d['d']):_0x3c6727==='sd'?this['onSecurityDebugPacket_'](_0x5e377d):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3c6727)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x53f8a9,_0x3c2d9c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x53f8a9),this['lastSessionId']=_0x3c2d9c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4abbda){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4abbda));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x26b37c){_0x26b37c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x26b37c;}['onOnline_'](_0x47b691){_0x47b691?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5bd7fa=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x56aa6b=Math['max'](0x0,this['reconnectDelay_']-_0x5bd7fa);_0x56aa6b=Math['random']()*_0x56aa6b,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x56aa6b+'ms'),this['scheduleConnect_'](_0x56aa6b),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x269b20=this['onDataMessage_']['bind'](this),_0x5c3ca0=this['onReady_']['bind'](this),_0x3a6875=this['onRealtimeDisconnect_']['bind'](this),_0x20a9ea=this['id']+':'+se['nextConnectionId_']++,_0x2e20ec=this['lastSessionId'];let _0x213d2b=!0x1,_0x59a434=null;const _0x3f9ed4=function(){_0x59a434?_0x59a434['close']():(_0x213d2b=!0x0,_0x3a6875());},_0x388c74=function(_0x85e325){f(_0x59a434,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x59a434['sendRequest'](_0x85e325);};this['realtime_']={'close':_0x3f9ed4,'sendRequest':_0x388c74};const _0x1fdd9e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x28296c,_0x315040]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1fdd9e),this['appCheckTokenProvider_']['getToken'](_0x1fdd9e)]);_0x213d2b?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x28296c&&_0x28296c['accessToken'],this['appCheckToken_']=_0x315040&&_0x315040['token'],_0x59a434=new Sh(_0x20a9ea,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x269b20,_0x5c3ca0,_0x3a6875,_0x30113b=>{U(_0x30113b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2e20ec));}catch(_0x4de0e4){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4de0e4),_0x213d2b||(this['repoInfo_']['nodeAdmin']&&U(_0x4de0e4),_0x3f9ed4());}}}['interrupt'](_0x812113){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x812113),this['interruptReasons_'][_0x812113]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x7a1c91){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x7a1c91),delete this['interruptReasons_'][_0x7a1c91],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1e732f){const _0x3b15bc=_0x1e732f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3b15bc});}['cancelSentTransactions_'](){for(let _0x5cb4ba=0x0;_0x5cb4ba<this['outstandingPuts_']['length'];_0x5cb4ba++){const _0x54d943=this['outstandingPuts_'][_0x5cb4ba];_0x54d943&&'h'in _0x54d943['request']&&_0x54d943['queued']&&(_0x54d943['onComplete']&&_0x54d943['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5cb4ba],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4a3441,_0x11f388){let _0x3f67c0;_0x11f388?_0x3f67c0=_0x11f388['map'](_0x52dbfd=>$i(_0x52dbfd))['join']('$'):_0x3f67c0='default';const _0x1ead70=this['removeListen_'](_0x4a3441,_0x3f67c0);_0x1ead70&&_0x1ead70['onComplete']&&_0x1ead70['onComplete']('permission_denied');}['removeListen_'](_0x5c1b48,_0x2898e5){const _0x1fbb17=new C(_0x5c1b48)['toString']();let _0x2a5d40;if(this['listens']['has'](_0x1fbb17)){const _0x40b3c8=this['listens']['get'](_0x1fbb17);_0x2a5d40=_0x40b3c8['get'](_0x2898e5),_0x40b3c8['delete'](_0x2898e5),_0x40b3c8['size']===0x0&&this['listens']['delete'](_0x1fbb17);}else _0x2a5d40=void 0x0;return _0x2a5d40;}['onAuthRevoked_'](_0x2fd6d4,_0x5de06d){L('Auth\x20token\x20revoked:\x20'+_0x2fd6d4+'/'+_0x5de06d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2fd6d4==='invalid_token'||_0x2fd6d4==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2eedb2,_0x110a79){L('App\x20check\x20token\x20revoked:\x20'+_0x2eedb2+'/'+_0x110a79),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2eedb2==='invalid_token'||_0x2eedb2==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x366bcf){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x366bcf):'msg'in _0x366bcf&&console['log']('FIREBASE:\x20'+_0x366bcf['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1efcef of this['listens']['values']())for(const _0x5198dd of _0x1efcef['values']())this['sendListen_'](_0x5198dd);for(let _0x1198e1=0x0;_0x1198e1<this['outstandingPuts_']['length'];_0x1198e1++)this['outstandingPuts_'][_0x1198e1]&&this['sendPut_'](_0x1198e1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1bddc5=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1bddc5['action'],_0x1bddc5['pathString'],_0x1bddc5['data'],_0x1bddc5['onComplete']);}for(let _0x20069d=0x0;_0x20069d<this['outstandingGets_']['length'];_0x20069d++)this['outstandingGets_'][_0x20069d]&&this['sendGet_'](_0x20069d);}['sendConnectStats_'](){const _0x341178={};let _0x3fbc8f='js';_0x341178['sdk.'+_0x3fbc8f+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x341178['framework.cordova']=0x1:Kr()&&(_0x341178['framework.reactnative']=0x1),this['reportStats'](_0x341178);}['shouldReconnect_'](){const _0x8b16ad=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x8b16ad;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3e0d43,_0x42e8c6){this['name']=_0x3e0d43,this['node']=_0x42e8c6;}static['Wrap'](_0x770a2e,_0x49f63b){return new E(_0x770a2e,_0x49f63b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3d3764,_0x1f4215){const _0x1bff21=new E(We,_0x3d3764),_0x803b57=new E(We,_0x1f4215);return this['compare'](_0x1bff21,_0x803b57)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2673d5){sn=_0x2673d5;}['compare'](_0x358fa1,_0x33dcde){return qe(_0x358fa1['name'],_0x33dcde['name']);}['isDefinedOn'](_0x152fcc){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x320406,_0x256ebd){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x1e95e1,_0x33c41e){return f(typeof _0x1e95e1=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x1e95e1,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0xf1a1d7,_0x25d316,_0x1f7f6e,_0x388d6d,_0x264df0=null){this['isReverse_']=_0x388d6d,this['resultGenerator_']=_0x264df0,this['nodeStack_']=[];let _0x4c1269=0x1;for(;!_0xf1a1d7['isEmpty']();)if(_0xf1a1d7=_0xf1a1d7,_0x4c1269=_0x25d316?_0x1f7f6e(_0xf1a1d7['key'],_0x25d316):0x1,_0x388d6d&&(_0x4c1269*=-0x1),_0x4c1269<0x0)this['isReverse_']?_0xf1a1d7=_0xf1a1d7['left']:_0xf1a1d7=_0xf1a1d7['right'];else{if(_0x4c1269===0x0){this['nodeStack_']['push'](_0xf1a1d7);break;}else this['nodeStack_']['push'](_0xf1a1d7),this['isReverse_']?_0xf1a1d7=_0xf1a1d7['right']:_0xf1a1d7=_0xf1a1d7['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x542e79=this['nodeStack_']['pop'](),_0x43001b;if(this['resultGenerator_']?_0x43001b=this['resultGenerator_'](_0x542e79['key'],_0x542e79['value']):_0x43001b={'key':_0x542e79['key'],'value':_0x542e79['value']},this['isReverse_']){for(_0x542e79=_0x542e79['left'];!_0x542e79['isEmpty']();)this['nodeStack_']['push'](_0x542e79),_0x542e79=_0x542e79['right'];}else{for(_0x542e79=_0x542e79['right'];!_0x542e79['isEmpty']();)this['nodeStack_']['push'](_0x542e79),_0x542e79=_0x542e79['left'];}return _0x43001b;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2de329=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2de329['key'],_0x2de329['value']):{'key':_0x2de329['key'],'value':_0x2de329['value']};}}class M{constructor(_0x3681af,_0x29f1d7,_0x43a570,_0x3816a5,_0x433b89){this['key']=_0x3681af,this['value']=_0x29f1d7,this['color']=_0x43a570??M['RED'],this['left']=_0x3816a5??B['EMPTY_NODE'],this['right']=_0x433b89??B['EMPTY_NODE'];}['copy'](_0x9eb4d1,_0x2545f2,_0x365d3a,_0x4385f2,_0x1f36cd){return new M(_0x9eb4d1??this['key'],_0x2545f2??this['value'],_0x365d3a??this['color'],_0x4385f2??this['left'],_0x1f36cd??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2758c6){return this['left']['inorderTraversal'](_0x2758c6)||!!_0x2758c6(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2758c6);}['reverseTraversal'](_0xb05df7){return this['right']['reverseTraversal'](_0xb05df7)||_0xb05df7(this['key'],this['value'])||this['left']['reverseTraversal'](_0xb05df7);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2623d0,_0x5b9940,_0x3d2c9d){let _0x4a14bc=this;const _0x1228d5=_0x3d2c9d(_0x2623d0,_0x4a14bc['key']);return _0x1228d5<0x0?_0x4a14bc=_0x4a14bc['copy'](null,null,null,_0x4a14bc['left']['insert'](_0x2623d0,_0x5b9940,_0x3d2c9d),null):_0x1228d5===0x0?_0x4a14bc=_0x4a14bc['copy'](null,_0x5b9940,null,null,null):_0x4a14bc=_0x4a14bc['copy'](null,null,null,null,_0x4a14bc['right']['insert'](_0x2623d0,_0x5b9940,_0x3d2c9d)),_0x4a14bc['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4dcfea=this;return!_0x4dcfea['left']['isRed_']()&&!_0x4dcfea['left']['left']['isRed_']()&&(_0x4dcfea=_0x4dcfea['moveRedLeft_']()),_0x4dcfea=_0x4dcfea['copy'](null,null,null,_0x4dcfea['left']['removeMin_'](),null),_0x4dcfea['fixUp_']();}['remove'](_0x3a2654,_0x49a004){let _0x48f97f,_0x37efb2;if(_0x48f97f=this,_0x49a004(_0x3a2654,_0x48f97f['key'])<0x0)!_0x48f97f['left']['isEmpty']()&&!_0x48f97f['left']['isRed_']()&&!_0x48f97f['left']['left']['isRed_']()&&(_0x48f97f=_0x48f97f['moveRedLeft_']()),_0x48f97f=_0x48f97f['copy'](null,null,null,_0x48f97f['left']['remove'](_0x3a2654,_0x49a004),null);else{if(_0x48f97f['left']['isRed_']()&&(_0x48f97f=_0x48f97f['rotateRight_']()),!_0x48f97f['right']['isEmpty']()&&!_0x48f97f['right']['isRed_']()&&!_0x48f97f['right']['left']['isRed_']()&&(_0x48f97f=_0x48f97f['moveRedRight_']()),_0x49a004(_0x3a2654,_0x48f97f['key'])===0x0){if(_0x48f97f['right']['isEmpty']())return B['EMPTY_NODE'];_0x37efb2=_0x48f97f['right']['min_'](),_0x48f97f=_0x48f97f['copy'](_0x37efb2['key'],_0x37efb2['value'],null,null,_0x48f97f['right']['removeMin_']());}_0x48f97f=_0x48f97f['copy'](null,null,null,null,_0x48f97f['right']['remove'](_0x3a2654,_0x49a004));}return _0x48f97f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x52dd31=this;return _0x52dd31['right']['isRed_']()&&!_0x52dd31['left']['isRed_']()&&(_0x52dd31=_0x52dd31['rotateLeft_']()),_0x52dd31['left']['isRed_']()&&_0x52dd31['left']['left']['isRed_']()&&(_0x52dd31=_0x52dd31['rotateRight_']()),_0x52dd31['left']['isRed_']()&&_0x52dd31['right']['isRed_']()&&(_0x52dd31=_0x52dd31['colorFlip_']()),_0x52dd31;}['moveRedLeft_'](){let _0x1049f3=this['colorFlip_']();return _0x1049f3['right']['left']['isRed_']()&&(_0x1049f3=_0x1049f3['copy'](null,null,null,null,_0x1049f3['right']['rotateRight_']()),_0x1049f3=_0x1049f3['rotateLeft_'](),_0x1049f3=_0x1049f3['colorFlip_']()),_0x1049f3;}['moveRedRight_'](){let _0x55ede8=this['colorFlip_']();return _0x55ede8['left']['left']['isRed_']()&&(_0x55ede8=_0x55ede8['rotateRight_'](),_0x55ede8=_0x55ede8['colorFlip_']()),_0x55ede8;}['rotateLeft_'](){const _0x2a35a4=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2a35a4,null);}['rotateRight_'](){const _0x43a027=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x43a027);}['colorFlip_'](){const _0x3aa2ad=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x239455=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3aa2ad,_0x239455);}['checkMaxDepth_'](){const _0x12c6ee=this['check_']();return Math['pow'](0x2,_0x12c6ee)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x21f8d8=this['left']['check_']();if(_0x21f8d8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x21f8d8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x92ef22,_0x5b9ed1,_0x40fddc,_0x32084d,_0x1babb8){return this;}['insert'](_0x2301e2,_0x13263f,_0x2d1100){return new M(_0x2301e2,_0x13263f,null);}['remove'](_0x34446e,_0x423150){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x16a92c){return!0x1;}['reverseTraversal'](_0x3061cb){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x53791d,_0x1d1ddc=B['EMPTY_NODE']){this['comparator_']=_0x53791d,this['root_']=_0x1d1ddc;}['insert'](_0x58f265,_0x1b7a48){return new B(this['comparator_'],this['root_']['insert'](_0x58f265,_0x1b7a48,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x18a3a8){return new B(this['comparator_'],this['root_']['remove'](_0x18a3a8,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x424f38){let _0x116d49,_0x495aec=this['root_'];for(;!_0x495aec['isEmpty']();){if(_0x116d49=this['comparator_'](_0x424f38,_0x495aec['key']),_0x116d49===0x0)return _0x495aec['value'];_0x116d49<0x0?_0x495aec=_0x495aec['left']:_0x116d49>0x0&&(_0x495aec=_0x495aec['right']);}return null;}['getPredecessorKey'](_0x50d8a8){let _0x4a5b09,_0x14d23a=this['root_'],_0x23d9fc=null;for(;!_0x14d23a['isEmpty']();)if(_0x4a5b09=this['comparator_'](_0x50d8a8,_0x14d23a['key']),_0x4a5b09===0x0){if(_0x14d23a['left']['isEmpty']())return _0x23d9fc?_0x23d9fc['key']:null;for(_0x14d23a=_0x14d23a['left'];!_0x14d23a['right']['isEmpty']();)_0x14d23a=_0x14d23a['right'];return _0x14d23a['key'];}else _0x4a5b09<0x0?_0x14d23a=_0x14d23a['left']:_0x4a5b09>0x0&&(_0x23d9fc=_0x14d23a,_0x14d23a=_0x14d23a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x350272){return this['root_']['inorderTraversal'](_0x350272);}['reverseTraversal'](_0x56cde4){return this['root_']['reverseTraversal'](_0x56cde4);}['getIterator'](_0x5189e3){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x5189e3);}['getIteratorFrom'](_0xc4612a,_0x95090a){return new rn(this['root_'],_0xc4612a,this['comparator_'],!0x1,_0x95090a);}['getReverseIteratorFrom'](_0x36aaab,_0x49b815){return new rn(this['root_'],_0x36aaab,this['comparator_'],!0x0,_0x49b815);}['getReverseIterator'](_0x951ab5){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x951ab5);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x4a6f1a,_0x79fd54){return qe(_0x4a6f1a['name'],_0x79fd54['name']);}function Qi(_0x3d33dd,_0x18362c){return qe(_0x3d33dd,_0x18362c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2db952){Ci=_0x2db952;}const Po=function(_0x2d1163){return typeof _0x2d1163=='number'?'number:'+ao(_0x2d1163):'string:'+_0x2d1163;},No=function(_0x524316){if(_0x524316['isLeafNode']()){const _0x577d89=_0x524316['val']();f(typeof _0x577d89=='string'||typeof _0x577d89=='number'||typeof _0x577d89=='object'&&Q(_0x577d89,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x524316===Ci||_0x524316['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x524316===Ci||_0x524316['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1ac1a4){nr=_0x1ac1a4;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0xf4b441,_0x19430=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xf4b441,this['priorityNode_']=_0x19430,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x26a035){return new D(this['value_'],_0x26a035);}['getImmediateChild'](_0x519b5b){return _0x519b5b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2dadb5){return v(_0x2dadb5)?this:y(_0x2dadb5)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1b4099,_0x35d769){return null;}['updateImmediateChild'](_0x1828d8,_0x516a77){return _0x1828d8==='.priority'?this['updatePriority'](_0x516a77):_0x516a77['isEmpty']()&&_0x1828d8!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1828d8,_0x516a77)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x26b904,_0x5d6480){const _0x52b2be=y(_0x26b904);return _0x52b2be===null?_0x5d6480:_0x5d6480['isEmpty']()&&_0x52b2be!=='.priority'?this:(f(_0x52b2be!=='.priority'||Ce(_0x26b904)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x52b2be,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x26b904),_0x5d6480)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x483772,_0x1fa9be){return!0x1;}['val'](_0x1448b6){return _0x1448b6&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x547af9='';this['priorityNode_']['isEmpty']()||(_0x547af9+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3110d8=typeof this['value_'];_0x547af9+=_0x3110d8+':',_0x3110d8==='number'?_0x547af9+=ao(this['value_']):_0x547af9+=this['value_'],this['lazyHash_']=ro(_0x547af9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x516477){return _0x516477===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x516477 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x516477['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x516477));}['compareToLeafNode_'](_0x3f0847){const _0x5d40b1=typeof _0x3f0847['value_'],_0x5716be=typeof this['value_'],_0x4d4ed3=D['VALUE_TYPE_ORDER']['indexOf'](_0x5d40b1),_0x56fc39=D['VALUE_TYPE_ORDER']['indexOf'](_0x5716be);return f(_0x4d4ed3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5d40b1),f(_0x56fc39>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5716be),_0x4d4ed3===_0x56fc39?_0x5716be==='object'?0x0:this['value_']<_0x3f0847['value_']?-0x1:this['value_']===_0x3f0847['value_']?0x0:0x1:_0x56fc39-_0x4d4ed3;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5544ad){if(_0x5544ad===this)return!0x0;if(_0x5544ad['isLeafNode']()){const _0x571b22=_0x5544ad;return this['value_']===_0x571b22['value_']&&this['priorityNode_']['equals'](_0x571b22['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1beb5d){Oo=_0x1beb5d;}function Wh(_0x568e79){Do=_0x568e79;}class Bh extends Fn{['compare'](_0xeffb69,_0x3b7808){const _0x17bac4=_0xeffb69['node']['getPriority'](),_0xce50e6=_0x3b7808['node']['getPriority'](),_0x17141c=_0x17bac4['compareTo'](_0xce50e6);return _0x17141c===0x0?qe(_0xeffb69['name'],_0x3b7808['name']):_0x17141c;}['isDefinedOn'](_0x395d0d){return!_0x395d0d['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1ff1ed,_0x26c303){return!_0x1ff1ed['getPriority']()['equals'](_0x26c303['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5afbf1,_0x36c877){const _0x52e398=Oo(_0x5afbf1);return new E(_0x36c877,new D('[PRIORITY-POST]',_0x52e398));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x208047){const _0x574c42=_0x2c9153=>parseInt(Math['log'](_0x2c9153)/Vh,0xa),_0x4330af=_0x1e34d9=>parseInt(Array(_0x1e34d9+0x1)['join']('1'),0x2);this['count']=_0x574c42(_0x208047+0x1),this['current_']=this['count']-0x1;const _0x33ac89=_0x4330af(this['count']);this['bits_']=_0x208047+0x1&_0x33ac89;}['nextBitIsOne'](){const _0x469082=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x469082;}}const yn=function(_0x1f0fd3,_0x577a30,_0x4bad85,_0x1fd065){_0x1f0fd3['sort'](_0x577a30);const _0x4c96ea=function(_0x4f0f1c,_0x59daf0){const _0x40c93e=_0x59daf0-_0x4f0f1c;let _0x37589d,_0x2bf566;if(_0x40c93e===0x0)return null;if(_0x40c93e===0x1)return _0x37589d=_0x1f0fd3[_0x4f0f1c],_0x2bf566=_0x4bad85?_0x4bad85(_0x37589d):_0x37589d,new M(_0x2bf566,_0x37589d['node'],M['BLACK'],null,null);{const _0x54bebc=parseInt(_0x40c93e/0x2,0xa)+_0x4f0f1c,_0x35bb64=_0x4c96ea(_0x4f0f1c,_0x54bebc),_0x2e9c7a=_0x4c96ea(_0x54bebc+0x1,_0x59daf0);return _0x37589d=_0x1f0fd3[_0x54bebc],_0x2bf566=_0x4bad85?_0x4bad85(_0x37589d):_0x37589d,new M(_0x2bf566,_0x37589d['node'],M['BLACK'],_0x35bb64,_0x2e9c7a);}},_0x5e89b9=function(_0x1d2fb9){let _0x5aa8fd=null,_0x2cfb24=null,_0x4f72cc=_0x1f0fd3['length'];const _0x434b25=function(_0x222f56,_0x3f4c44){const _0x4e1304=_0x4f72cc-_0x222f56,_0x4ea6aa=_0x4f72cc;_0x4f72cc-=_0x222f56;const _0x2231f0=_0x4c96ea(_0x4e1304+0x1,_0x4ea6aa),_0x35442d=_0x1f0fd3[_0x4e1304],_0x25c3f2=_0x4bad85?_0x4bad85(_0x35442d):_0x35442d;_0x304e29(new M(_0x25c3f2,_0x35442d['node'],_0x3f4c44,null,_0x2231f0));},_0x304e29=function(_0x381896){_0x5aa8fd?(_0x5aa8fd['left']=_0x381896,_0x5aa8fd=_0x381896):(_0x2cfb24=_0x381896,_0x5aa8fd=_0x381896);};for(let _0x48cfdc=0x0;_0x48cfdc<_0x1d2fb9['count'];++_0x48cfdc){const _0x250b4d=_0x1d2fb9['nextBitIsOne'](),_0x16c2c3=Math['pow'](0x2,_0x1d2fb9['count']-(_0x48cfdc+0x1));_0x250b4d?_0x434b25(_0x16c2c3,M['BLACK']):(_0x434b25(_0x16c2c3,M['BLACK']),_0x434b25(_0x16c2c3,M['RED']));}return _0x2cfb24;},_0x347bca=new Hh(_0x1f0fd3['length']),_0xcb5b50=_0x5e89b9(_0x347bca);return new B(_0x1fd065||_0x577a30,_0xcb5b50);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x32612a,_0x106757){this['indexes_']=_0x32612a,this['indexSet_']=_0x106757;}['get'](_0x4a0e77){const _0x59f555=Le(this['indexes_'],_0x4a0e77);if(!_0x59f555)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4a0e77);return _0x59f555 instanceof B?_0x59f555:null;}['hasIndex'](_0x10cb0b){return Q(this['indexSet_'],_0x10cb0b['toString']());}['addIndex'](_0x319925,_0x5924b6){f(_0x319925!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x95319e=[];let _0x20d989=!0x1;const _0x4975e1=_0x5924b6['getIterator'](E['Wrap']);let _0x2111de=_0x4975e1['getNext']();for(;_0x2111de;)_0x20d989=_0x20d989||_0x319925['isDefinedOn'](_0x2111de['node']),_0x95319e['push'](_0x2111de),_0x2111de=_0x4975e1['getNext']();let _0x43475c;_0x20d989?_0x43475c=yn(_0x95319e,_0x319925['getCompare']()):_0x43475c=Qe;const _0x16a95d=_0x319925['toString'](),_0x53510c={...this['indexSet_']};_0x53510c[_0x16a95d]=_0x319925;const _0xc5406b={...this['indexes_']};return _0xc5406b[_0x16a95d]=_0x43475c,new te(_0xc5406b,_0x53510c);}['addToIndexes'](_0x373e1b,_0x15e51e){const _0x1c84dc=_n(this['indexes_'],(_0x7b8da,_0x4da765)=>{const _0x4841ed=Le(this['indexSet_'],_0x4da765);if(f(_0x4841ed,'Missing\x20index\x20implementation\x20for\x20'+_0x4da765),_0x7b8da===Qe){if(_0x4841ed['isDefinedOn'](_0x373e1b['node'])){const _0x325c8a=[],_0x1b20e0=_0x15e51e['getIterator'](E['Wrap']);let _0x53c76e=_0x1b20e0['getNext']();for(;_0x53c76e;)_0x53c76e['name']!==_0x373e1b['name']&&_0x325c8a['push'](_0x53c76e),_0x53c76e=_0x1b20e0['getNext']();return _0x325c8a['push'](_0x373e1b),yn(_0x325c8a,_0x4841ed['getCompare']());}else return Qe;}else{const _0x113585=_0x15e51e['get'](_0x373e1b['name']);let _0x128936=_0x7b8da;return _0x113585&&(_0x128936=_0x128936['remove'](new E(_0x373e1b['name'],_0x113585))),_0x128936['insert'](_0x373e1b,_0x373e1b['node']);}});return new te(_0x1c84dc,this['indexSet_']);}['removeFromIndexes'](_0x45a238,_0x34920b){const _0x4ed80b=_n(this['indexes_'],_0x46b298=>{if(_0x46b298===Qe)return _0x46b298;{const _0x1c08f4=_0x34920b['get'](_0x45a238['name']);return _0x1c08f4?_0x46b298['remove'](new E(_0x45a238['name'],_0x1c08f4)):_0x46b298;}});return new te(_0x4ed80b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x466ae8,_0x1f9a1d,_0x157be0){this['children_']=_0x466ae8,this['priorityNode_']=_0x1f9a1d,this['indexMap_']=_0x157be0,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x271192){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x271192,this['indexMap_']);}['getImmediateChild'](_0x1385af){if(_0x1385af==='.priority')return this['getPriority']();{const _0x409b30=this['children_']['get'](_0x1385af);return _0x409b30===null?It:_0x409b30;}}['getChild'](_0x24b38f){const _0x27542d=y(_0x24b38f);return _0x27542d===null?this:this['getImmediateChild'](_0x27542d)['getChild'](S(_0x24b38f));}['hasChild'](_0x236b3f){return this['children_']['get'](_0x236b3f)!==null;}['updateImmediateChild'](_0x3dfb05,_0x5dd3cd){if(f(_0x5dd3cd,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3dfb05==='.priority')return this['updatePriority'](_0x5dd3cd);{const _0x3fb458=new E(_0x3dfb05,_0x5dd3cd);let _0x51ba57,_0x1d239d;_0x5dd3cd['isEmpty']()?(_0x51ba57=this['children_']['remove'](_0x3dfb05),_0x1d239d=this['indexMap_']['removeFromIndexes'](_0x3fb458,this['children_'])):(_0x51ba57=this['children_']['insert'](_0x3dfb05,_0x5dd3cd),_0x1d239d=this['indexMap_']['addToIndexes'](_0x3fb458,this['children_']));const _0x4b77b6=_0x51ba57['isEmpty']()?It:this['priorityNode_'];return new g(_0x51ba57,_0x4b77b6,_0x1d239d);}}['updateChild'](_0x5136be,_0x1bc891){const _0x16747a=y(_0x5136be);if(_0x16747a===null)return _0x1bc891;{f(y(_0x5136be)!=='.priority'||Ce(_0x5136be)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xc29d12=this['getImmediateChild'](_0x16747a)['updateChild'](S(_0x5136be),_0x1bc891);return this['updateImmediateChild'](_0x16747a,_0xc29d12);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1e6681){if(this['isEmpty']())return null;const _0x50f652={};let _0x5ab527=0x0,_0x4a8d7e=0x0,_0x19d9ff=!0x0;if(this['forEachChild'](R,(_0x3d0ae6,_0xcc2b9e)=>{_0x50f652[_0x3d0ae6]=_0xcc2b9e['val'](_0x1e6681),_0x5ab527++,_0x19d9ff&&g['INTEGER_REGEXP_']['test'](_0x3d0ae6)?_0x4a8d7e=Math['max'](_0x4a8d7e,Number(_0x3d0ae6)):_0x19d9ff=!0x1;}),!_0x1e6681&&_0x19d9ff&&_0x4a8d7e<0x2*_0x5ab527){const _0x4a5d02=[];for(const _0x5ca482 in _0x50f652)_0x4a5d02[_0x5ca482]=_0x50f652[_0x5ca482];return _0x4a5d02;}else return _0x1e6681&&!this['getPriority']()['isEmpty']()&&(_0x50f652['.priority']=this['getPriority']()['val']()),_0x50f652;}['hash'](){if(this['lazyHash_']===null){let _0x530da6='';this['getPriority']()['isEmpty']()||(_0x530da6+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x217002,_0x2c6f41)=>{const _0x3b74c3=_0x2c6f41['hash']();_0x3b74c3!==''&&(_0x530da6+=':'+_0x217002+':'+_0x3b74c3);}),this['lazyHash_']=_0x530da6===''?'':ro(_0x530da6);}return this['lazyHash_'];}['getPredecessorChildName'](_0x227901,_0x574dfc,_0x1e0d61){const _0x4b7942=this['resolveIndex_'](_0x1e0d61);if(_0x4b7942){const _0x3f84bc=_0x4b7942['getPredecessorKey'](new E(_0x227901,_0x574dfc));return _0x3f84bc?_0x3f84bc['name']:null;}else return this['children_']['getPredecessorKey'](_0x227901);}['getFirstChildName'](_0xa3b920){const _0x116027=this['resolveIndex_'](_0xa3b920);if(_0x116027){const _0x34d4ba=_0x116027['minKey']();return _0x34d4ba&&_0x34d4ba['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3c2fd2){const _0x420515=this['getFirstChildName'](_0x3c2fd2);return _0x420515?new E(_0x420515,this['children_']['get'](_0x420515)):null;}['getLastChildName'](_0x3bb54d){const _0x7c9ab9=this['resolveIndex_'](_0x3bb54d);if(_0x7c9ab9){const _0x49afe0=_0x7c9ab9['maxKey']();return _0x49afe0&&_0x49afe0['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xb09286){const _0x3104bf=this['getLastChildName'](_0xb09286);return _0x3104bf?new E(_0x3104bf,this['children_']['get'](_0x3104bf)):null;}['forEachChild'](_0x48d3a0,_0x123e3b){const _0x140a76=this['resolveIndex_'](_0x48d3a0);return _0x140a76?_0x140a76['inorderTraversal'](_0x339931=>_0x123e3b(_0x339931['name'],_0x339931['node'])):this['children_']['inorderTraversal'](_0x123e3b);}['getIterator'](_0x1a9a66){return this['getIteratorFrom'](_0x1a9a66['minPost'](),_0x1a9a66);}['getIteratorFrom'](_0x220f84,_0xdd7009){const _0x233f80=this['resolveIndex_'](_0xdd7009);if(_0x233f80)return _0x233f80['getIteratorFrom'](_0x220f84,_0x17341f=>_0x17341f);{const _0x18d846=this['children_']['getIteratorFrom'](_0x220f84['name'],E['Wrap']);let _0x1a59bc=_0x18d846['peek']();for(;_0x1a59bc!=null&&_0xdd7009['compare'](_0x1a59bc,_0x220f84)<0x0;)_0x18d846['getNext'](),_0x1a59bc=_0x18d846['peek']();return _0x18d846;}}['getReverseIterator'](_0x434533){return this['getReverseIteratorFrom'](_0x434533['maxPost'](),_0x434533);}['getReverseIteratorFrom'](_0x1195ea,_0x35cbf3){const _0x6d112f=this['resolveIndex_'](_0x35cbf3);if(_0x6d112f)return _0x6d112f['getReverseIteratorFrom'](_0x1195ea,_0x165d2b=>_0x165d2b);{const _0x5ee909=this['children_']['getReverseIteratorFrom'](_0x1195ea['name'],E['Wrap']);let _0x17a9e0=_0x5ee909['peek']();for(;_0x17a9e0!=null&&_0x35cbf3['compare'](_0x17a9e0,_0x1195ea)>0x0;)_0x5ee909['getNext'](),_0x17a9e0=_0x5ee909['peek']();return _0x5ee909;}}['compareTo'](_0x3bce5f){return this['isEmpty']()?_0x3bce5f['isEmpty']()?0x0:-0x1:_0x3bce5f['isLeafNode']()||_0x3bce5f['isEmpty']()?0x1:_0x3bce5f===Kt?-0x1:0x0;}['withIndex'](_0x1e4e5a){if(_0x1e4e5a===ve||this['indexMap_']['hasIndex'](_0x1e4e5a))return this;{const _0x20202c=this['indexMap_']['addIndex'](_0x1e4e5a,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x20202c);}}['isIndexed'](_0x553a77){return _0x553a77===ve||this['indexMap_']['hasIndex'](_0x553a77);}['equals'](_0x506eeb){if(_0x506eeb===this)return!0x0;if(_0x506eeb['isLeafNode']())return!0x1;{const _0x377303=_0x506eeb;if(this['getPriority']()['equals'](_0x377303['getPriority']())){if(this['children_']['count']()===_0x377303['children_']['count']()){const _0x44bdd4=this['getIterator'](R),_0x19ef2b=_0x377303['getIterator'](R);let _0x1f7a55=_0x44bdd4['getNext'](),_0xc50b35=_0x19ef2b['getNext']();for(;_0x1f7a55&&_0xc50b35;){if(_0x1f7a55['name']!==_0xc50b35['name']||!_0x1f7a55['node']['equals'](_0xc50b35['node']))return!0x1;_0x1f7a55=_0x44bdd4['getNext'](),_0xc50b35=_0x19ef2b['getNext']();}return _0x1f7a55===null&&_0xc50b35===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4ca94c){return _0x4ca94c===ve?null:this['indexMap_']['get'](_0x4ca94c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4fe9eb){return _0x4fe9eb===this?0x0:0x1;}['equals'](_0x43f1ef){return _0x43f1ef===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1c37ea){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x52cd91,_0x37e2e1=null){if(_0x52cd91===null)return g['EMPTY_NODE'];if(typeof _0x52cd91=='object'&&'.priority'in _0x52cd91&&(_0x37e2e1=_0x52cd91['.priority']),f(_0x37e2e1===null||typeof _0x37e2e1=='string'||typeof _0x37e2e1=='number'||typeof _0x37e2e1=='object'&&'.sv'in _0x37e2e1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x37e2e1),typeof _0x52cd91=='object'&&'.value'in _0x52cd91&&_0x52cd91['.value']!==null&&(_0x52cd91=_0x52cd91['.value']),typeof _0x52cd91!='object'||'.sv'in _0x52cd91){const _0x2a3538=_0x52cd91;return new D(_0x2a3538,A(_0x37e2e1));}if(!(_0x52cd91 instanceof Array)&&Gh){const _0x50ef10=[];let _0x5acc08=!0x1;if(x(_0x52cd91,(_0x38739d,_0x43a264)=>{if(_0x38739d['substring'](0x0,0x1)!=='.'){const _0x29d772=A(_0x43a264);_0x29d772['isEmpty']()||(_0x5acc08=_0x5acc08||!_0x29d772['getPriority']()['isEmpty'](),_0x50ef10['push'](new E(_0x38739d,_0x29d772)));}}),_0x50ef10['length']===0x0)return g['EMPTY_NODE'];const _0x4e8b7c=yn(_0x50ef10,xh,_0x2f0584=>_0x2f0584['name'],Qi);if(_0x5acc08){const _0x60dd44=yn(_0x50ef10,R['getCompare']());return new g(_0x4e8b7c,A(_0x37e2e1),new te({'.priority':_0x60dd44},{'.priority':R}));}else return new g(_0x4e8b7c,A(_0x37e2e1),te['Default']);}else{let _0xd73901=g['EMPTY_NODE'];return x(_0x52cd91,(_0x13225a,_0x15e345)=>{if(Q(_0x52cd91,_0x13225a)&&_0x13225a['substring'](0x0,0x1)!=='.'){const _0x157984=A(_0x15e345);(_0x157984['isLeafNode']()||!_0x157984['isEmpty']())&&(_0xd73901=_0xd73901['updateImmediateChild'](_0x13225a,_0x157984));}}),_0xd73901['updatePriority'](A(_0x37e2e1));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0xfa3431){super(),this['indexPath_']=_0xfa3431,f(!v(_0xfa3431)&&y(_0xfa3431)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2060db){return _0x2060db['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2ed030){return!_0x2ed030['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4c7719,_0x35afa7){const _0x29309c=this['extractChild'](_0x4c7719['node']),_0x5e9adc=this['extractChild'](_0x35afa7['node']),_0x2dc4a8=_0x29309c['compareTo'](_0x5e9adc);return _0x2dc4a8===0x0?qe(_0x4c7719['name'],_0x35afa7['name']):_0x2dc4a8;}['makePost'](_0x458b3d,_0x364d4e){const _0x1e76ff=A(_0x458b3d),_0x440561=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1e76ff);return new E(_0x364d4e,_0x440561);}['maxPost'](){const _0x578709=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x578709);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x10cd6e,_0x4d2514){const _0x53d532=_0x10cd6e['node']['compareTo'](_0x4d2514['node']);return _0x53d532===0x0?qe(_0x10cd6e['name'],_0x4d2514['name']):_0x53d532;}['isDefinedOn'](_0x1f3c21){return!0x0;}['indexedValueChanged'](_0x101ac4,_0xdf9932){return!_0x101ac4['equals'](_0xdf9932);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3b1b6b,_0x51e0f1){const _0x19e13c=A(_0x3b1b6b);return new E(_0x51e0f1,_0x19e13c);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x38ee37){return{'type':'value','snapshotNode':_0x38ee37};}function rt(_0x58ebdb,_0x35f462){return{'type':'child_added','snapshotNode':_0x35f462,'childName':_0x58ebdb};}function Lt(_0x49b811,_0x1b7491){return{'type':'child_removed','snapshotNode':_0x1b7491,'childName':_0x49b811};}function xt(_0x5e22e9,_0x552b30,_0x35a16c){return{'type':'child_changed','snapshotNode':_0x552b30,'childName':_0x5e22e9,'oldSnap':_0x35a16c};}function zh(_0x58d728,_0x11c2d4){return{'type':'child_moved','snapshotNode':_0x11c2d4,'childName':_0x58d728};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x5b7a05){this['index_']=_0x5b7a05;}['updateChild'](_0x5baec0,_0x31aace,_0x16c7e5,_0x43c040,_0x437936,_0x1121eb){f(_0x5baec0['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x48a29c=_0x5baec0['getImmediateChild'](_0x31aace);return _0x48a29c['getChild'](_0x43c040)['equals'](_0x16c7e5['getChild'](_0x43c040))&&_0x48a29c['isEmpty']()===_0x16c7e5['isEmpty']()||(_0x1121eb!=null&&(_0x16c7e5['isEmpty']()?_0x5baec0['hasChild'](_0x31aace)?_0x1121eb['trackChildChange'](Lt(_0x31aace,_0x48a29c)):f(_0x5baec0['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x48a29c['isEmpty']()?_0x1121eb['trackChildChange'](rt(_0x31aace,_0x16c7e5)):_0x1121eb['trackChildChange'](xt(_0x31aace,_0x16c7e5,_0x48a29c))),_0x5baec0['isLeafNode']()&&_0x16c7e5['isEmpty']())?_0x5baec0:_0x5baec0['updateImmediateChild'](_0x31aace,_0x16c7e5)['withIndex'](this['index_']);}['updateFullNode'](_0x25f37e,_0x550d69,_0x3d7734){return _0x3d7734!=null&&(_0x25f37e['isLeafNode']()||_0x25f37e['forEachChild'](R,(_0x59c35f,_0xc01029)=>{_0x550d69['hasChild'](_0x59c35f)||_0x3d7734['trackChildChange'](Lt(_0x59c35f,_0xc01029));}),_0x550d69['isLeafNode']()||_0x550d69['forEachChild'](R,(_0x2f0483,_0x514805)=>{if(_0x25f37e['hasChild'](_0x2f0483)){const _0x44fc11=_0x25f37e['getImmediateChild'](_0x2f0483);_0x44fc11['equals'](_0x514805)||_0x3d7734['trackChildChange'](xt(_0x2f0483,_0x514805,_0x44fc11));}else _0x3d7734['trackChildChange'](rt(_0x2f0483,_0x514805));})),_0x550d69['withIndex'](this['index_']);}['updatePriority'](_0x29d1cd,_0x3206b1){return _0x29d1cd['isEmpty']()?g['EMPTY_NODE']:_0x29d1cd['updatePriority'](_0x3206b1);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2d8ce8){this['indexedFilter_']=new Xi(_0x2d8ce8['getIndex']()),this['index_']=_0x2d8ce8['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x2d8ce8),this['endPost_']=Ft['getEndPost_'](_0x2d8ce8),this['startIsInclusive_']=!_0x2d8ce8['startAfterSet_'],this['endIsInclusive_']=!_0x2d8ce8['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x297e84){const _0x1ba926=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x297e84)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x297e84)<0x0,_0x314059=this['endIsInclusive_']?this['index_']['compare'](_0x297e84,this['getEndPost']())<=0x0:this['index_']['compare'](_0x297e84,this['getEndPost']())<0x0;return _0x1ba926&&_0x314059;}['updateChild'](_0x32092d,_0x163352,_0x3e414d,_0x5d7749,_0x3be85d,_0x562dd3){return this['matches'](new E(_0x163352,_0x3e414d))||(_0x3e414d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x32092d,_0x163352,_0x3e414d,_0x5d7749,_0x3be85d,_0x562dd3);}['updateFullNode'](_0x5b4a52,_0x308ded,_0x3e4754){_0x308ded['isLeafNode']()&&(_0x308ded=g['EMPTY_NODE']);let _0x5be4ab=_0x308ded['withIndex'](this['index_']);_0x5be4ab=_0x5be4ab['updatePriority'](g['EMPTY_NODE']);const _0x71f117=this;return _0x308ded['forEachChild'](R,(_0x431cd9,_0x21b547)=>{_0x71f117['matches'](new E(_0x431cd9,_0x21b547))||(_0x5be4ab=_0x5be4ab['updateImmediateChild'](_0x431cd9,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5b4a52,_0x5be4ab,_0x3e4754);}['updatePriority'](_0x56bfd5,_0x12c1ca){return _0x56bfd5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5152c2){if(_0x5152c2['hasStart']()){const _0x3f850c=_0x5152c2['getIndexStartName']();return _0x5152c2['getIndex']()['makePost'](_0x5152c2['getIndexStartValue'](),_0x3f850c);}else return _0x5152c2['getIndex']()['minPost']();}static['getEndPost_'](_0x18066f){if(_0x18066f['hasEnd']()){const _0x82ab83=_0x18066f['getIndexEndName']();return _0x18066f['getIndex']()['makePost'](_0x18066f['getIndexEndValue'](),_0x82ab83);}else return _0x18066f['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1f884d){this['withinDirectionalStart']=_0x32a232=>this['reverse_']?this['withinEndPost'](_0x32a232):this['withinStartPost'](_0x32a232),this['withinDirectionalEnd']=_0x394fa1=>this['reverse_']?this['withinStartPost'](_0x394fa1):this['withinEndPost'](_0x394fa1),this['withinStartPost']=_0x5b3dd1=>{const _0x23b0b9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5b3dd1);return this['startIsInclusive_']?_0x23b0b9<=0x0:_0x23b0b9<0x0;},this['withinEndPost']=_0x4f2a98=>{const _0x4d264e=this['index_']['compare'](_0x4f2a98,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4d264e<=0x0:_0x4d264e<0x0;},this['rangedFilter_']=new Ft(_0x1f884d),this['index_']=_0x1f884d['getIndex'](),this['limit_']=_0x1f884d['getLimit'](),this['reverse_']=!_0x1f884d['isViewFromLeft'](),this['startIsInclusive_']=!_0x1f884d['startAfterSet_'],this['endIsInclusive_']=!_0x1f884d['endBeforeSet_'];}['updateChild'](_0x1e7935,_0x25ac55,_0x4f2bce,_0x58037a,_0x2c8703,_0x2182ac){return this['rangedFilter_']['matches'](new E(_0x25ac55,_0x4f2bce))||(_0x4f2bce=g['EMPTY_NODE']),_0x1e7935['getImmediateChild'](_0x25ac55)['equals'](_0x4f2bce)?_0x1e7935:_0x1e7935['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1e7935,_0x25ac55,_0x4f2bce,_0x58037a,_0x2c8703,_0x2182ac):this['fullLimitUpdateChild_'](_0x1e7935,_0x25ac55,_0x4f2bce,_0x2c8703,_0x2182ac);}['updateFullNode'](_0x2da5b5,_0x425275,_0x13565b){let _0x3e86d0;if(_0x425275['isLeafNode']()||_0x425275['isEmpty']())_0x3e86d0=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x425275['numChildren']()&&_0x425275['isIndexed'](this['index_'])){_0x3e86d0=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x20acfb;this['reverse_']?_0x20acfb=_0x425275['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x20acfb=_0x425275['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3607e6=0x0;for(;_0x20acfb['hasNext']()&&_0x3607e6<this['limit_'];){const _0x426357=_0x20acfb['getNext']();if(this['withinDirectionalStart'](_0x426357)){if(this['withinDirectionalEnd'](_0x426357))_0x3e86d0=_0x3e86d0['updateImmediateChild'](_0x426357['name'],_0x426357['node']),_0x3607e6++;else break;}else continue;}}else{_0x3e86d0=_0x425275['withIndex'](this['index_']),_0x3e86d0=_0x3e86d0['updatePriority'](g['EMPTY_NODE']);let _0x111b71;this['reverse_']?_0x111b71=_0x3e86d0['getReverseIterator'](this['index_']):_0x111b71=_0x3e86d0['getIterator'](this['index_']);let _0x28e0e8=0x0;for(;_0x111b71['hasNext']();){const _0x15775a=_0x111b71['getNext']();_0x28e0e8<this['limit_']&&this['withinDirectionalStart'](_0x15775a)&&this['withinDirectionalEnd'](_0x15775a)?_0x28e0e8++:_0x3e86d0=_0x3e86d0['updateImmediateChild'](_0x15775a['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2da5b5,_0x3e86d0,_0x13565b);}['updatePriority'](_0x2986ee,_0x3e90ce){return _0x2986ee;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5b8a26,_0x52b8c9,_0x315162,_0x41ae81,_0x1a2731){let _0x38ca5e;if(this['reverse_']){const _0x456d8b=this['index_']['getCompare']();_0x38ca5e=(_0xdd8e9e,_0x2f5e56)=>_0x456d8b(_0x2f5e56,_0xdd8e9e);}else _0x38ca5e=this['index_']['getCompare']();const _0xb669f7=_0x5b8a26;f(_0xb669f7['numChildren']()===this['limit_'],'');const _0x450a45=new E(_0x52b8c9,_0x315162),_0x26ba6f=this['reverse_']?_0xb669f7['getFirstChild'](this['index_']):_0xb669f7['getLastChild'](this['index_']),_0x44fbca=this['rangedFilter_']['matches'](_0x450a45);if(_0xb669f7['hasChild'](_0x52b8c9)){const _0x49ed6b=_0xb669f7['getImmediateChild'](_0x52b8c9);let _0x393ada=_0x41ae81['getChildAfterChild'](this['index_'],_0x26ba6f,this['reverse_']);for(;_0x393ada!=null&&(_0x393ada['name']===_0x52b8c9||_0xb669f7['hasChild'](_0x393ada['name']));)_0x393ada=_0x41ae81['getChildAfterChild'](this['index_'],_0x393ada,this['reverse_']);const _0x3aa0ce=_0x393ada==null?0x1:_0x38ca5e(_0x393ada,_0x450a45);if(_0x44fbca&&!_0x315162['isEmpty']()&&_0x3aa0ce>=0x0)return _0x1a2731!=null&&_0x1a2731['trackChildChange'](xt(_0x52b8c9,_0x315162,_0x49ed6b)),_0xb669f7['updateImmediateChild'](_0x52b8c9,_0x315162);{_0x1a2731!=null&&_0x1a2731['trackChildChange'](Lt(_0x52b8c9,_0x49ed6b));const _0x342669=_0xb669f7['updateImmediateChild'](_0x52b8c9,g['EMPTY_NODE']);return _0x393ada!=null&&this['rangedFilter_']['matches'](_0x393ada)?(_0x1a2731!=null&&_0x1a2731['trackChildChange'](rt(_0x393ada['name'],_0x393ada['node'])),_0x342669['updateImmediateChild'](_0x393ada['name'],_0x393ada['node'])):_0x342669;}}else return _0x315162['isEmpty']()?_0x5b8a26:_0x44fbca&&_0x38ca5e(_0x26ba6f,_0x450a45)>=0x0?(_0x1a2731!=null&&(_0x1a2731['trackChildChange'](Lt(_0x26ba6f['name'],_0x26ba6f['node'])),_0x1a2731['trackChildChange'](rt(_0x52b8c9,_0x315162))),_0xb669f7['updateImmediateChild'](_0x52b8c9,_0x315162)['updateImmediateChild'](_0x26ba6f['name'],g['EMPTY_NODE'])):_0x5b8a26;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1e5781=new Zi();return _0x1e5781['limitSet_']=this['limitSet_'],_0x1e5781['limit_']=this['limit_'],_0x1e5781['startSet_']=this['startSet_'],_0x1e5781['startAfterSet_']=this['startAfterSet_'],_0x1e5781['indexStartValue_']=this['indexStartValue_'],_0x1e5781['startNameSet_']=this['startNameSet_'],_0x1e5781['indexStartName_']=this['indexStartName_'],_0x1e5781['endSet_']=this['endSet_'],_0x1e5781['endBeforeSet_']=this['endBeforeSet_'],_0x1e5781['indexEndValue_']=this['indexEndValue_'],_0x1e5781['endNameSet_']=this['endNameSet_'],_0x1e5781['indexEndName_']=this['indexEndName_'],_0x1e5781['index_']=this['index_'],_0x1e5781['viewFrom_']=this['viewFrom_'],_0x1e5781;}}function Kh(_0x1194cd){return _0x1194cd['loadsAllData']()?new Xi(_0x1194cd['getIndex']()):_0x1194cd['hasLimit']()?new jh(_0x1194cd):new Ft(_0x1194cd);}function Yh(_0x868768,_0x58626b){const _0x3bdcdd=_0x868768['copy']();return _0x3bdcdd['limitSet_']=!0x0,_0x3bdcdd['limit_']=_0x58626b,_0x3bdcdd['viewFrom_']='l',_0x3bdcdd;}function Qh(_0x1d561b,_0xa7408,_0x16f0e1){const _0x377f54=_0x1d561b['copy']();return _0x377f54['startSet_']=!0x0,_0xa7408===void 0x0&&(_0xa7408=null),_0x377f54['indexStartValue_']=_0xa7408,_0x16f0e1!=null?(_0x377f54['startNameSet_']=!0x0,_0x377f54['indexStartName_']=_0x16f0e1):(_0x377f54['startNameSet_']=!0x1,_0x377f54['indexStartName_']=''),_0x377f54;}function Jh(_0xc9cb08,_0xe3a4cc,_0x10b33f){const _0x1e7f3d=_0xc9cb08['copy']();return _0x1e7f3d['endSet_']=!0x0,_0xe3a4cc===void 0x0&&(_0xe3a4cc=null),_0x1e7f3d['indexEndValue_']=_0xe3a4cc,_0x10b33f!==void 0x0?(_0x1e7f3d['endNameSet_']=!0x0,_0x1e7f3d['indexEndName_']=_0x10b33f):(_0x1e7f3d['endNameSet_']=!0x1,_0x1e7f3d['indexEndName_']=''),_0x1e7f3d;}function xo(_0x1dc91b,_0x36cb40){const _0x39271c=_0x1dc91b['copy']();return _0x39271c['index_']=_0x36cb40,_0x39271c;}function ir(_0x2a7cdc){const _0x529b8d={};if(_0x2a7cdc['isDefault']())return _0x529b8d;let _0x5dd2a4;if(_0x2a7cdc['index_']===R?_0x5dd2a4='$priority':_0x2a7cdc['index_']===Mo?_0x5dd2a4='$value':_0x2a7cdc['index_']===ve?_0x5dd2a4='$key':(f(_0x2a7cdc['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x5dd2a4=_0x2a7cdc['index_']['toString']()),_0x529b8d['orderBy']=O(_0x5dd2a4),_0x2a7cdc['startSet_']){const _0x5710e6=_0x2a7cdc['startAfterSet_']?'startAfter':'startAt';_0x529b8d[_0x5710e6]=O(_0x2a7cdc['indexStartValue_']),_0x2a7cdc['startNameSet_']&&(_0x529b8d[_0x5710e6]+=','+O(_0x2a7cdc['indexStartName_']));}if(_0x2a7cdc['endSet_']){const _0x2ea7de=_0x2a7cdc['endBeforeSet_']?'endBefore':'endAt';_0x529b8d[_0x2ea7de]=O(_0x2a7cdc['indexEndValue_']),_0x2a7cdc['endNameSet_']&&(_0x529b8d[_0x2ea7de]+=','+O(_0x2a7cdc['indexEndName_']));}return _0x2a7cdc['limitSet_']&&(_0x2a7cdc['isViewFromLeft']()?_0x529b8d['limitToFirst']=_0x2a7cdc['limit_']:_0x529b8d['limitToLast']=_0x2a7cdc['limit_']),_0x529b8d;}function sr(_0x44d178){const _0x416792={};if(_0x44d178['startSet_']&&(_0x416792['sp']=_0x44d178['indexStartValue_'],_0x44d178['startNameSet_']&&(_0x416792['sn']=_0x44d178['indexStartName_']),_0x416792['sin']=!_0x44d178['startAfterSet_']),_0x44d178['endSet_']&&(_0x416792['ep']=_0x44d178['indexEndValue_'],_0x44d178['endNameSet_']&&(_0x416792['en']=_0x44d178['indexEndName_']),_0x416792['ein']=!_0x44d178['endBeforeSet_']),_0x44d178['limitSet_']){_0x416792['l']=_0x44d178['limit_'];let _0xac96c5=_0x44d178['viewFrom_'];_0xac96c5===''&&(_0x44d178['isViewFromLeft']()?_0xac96c5='l':_0xac96c5='r'),_0x416792['vf']=_0xac96c5;}return _0x44d178['index_']!==R&&(_0x416792['i']=_0x44d178['index_']['toString']()),_0x416792;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xbed114){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4b0a4,_0x73ade0){return _0x73ade0!==void 0x0?'tag$'+_0x73ade0:(f(_0x4b0a4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4b0a4['_path']['toString']());}constructor(_0x8303d3,_0x2dc70d,_0x26d4a3,_0x1c9916){super(),this['repoInfo_']=_0x8303d3,this['onDataUpdate_']=_0x2dc70d,this['authTokenProvider_']=_0x26d4a3,this['appCheckTokenProvider_']=_0x1c9916,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1575a4,_0x350803,_0x201d2b,_0x4b16c8){const _0xb89927=_0x1575a4['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xb89927+'\x20'+_0x1575a4['_queryIdentifier']);const _0x58a4cc=vn['getListenId_'](_0x1575a4,_0x201d2b),_0x485b12={};this['listens_'][_0x58a4cc]=_0x485b12;const _0x3de17a=ir(_0x1575a4['_queryParams']);this['restRequest_'](_0xb89927+'.json',_0x3de17a,(_0x35b3a3,_0x4e2213)=>{let _0x576785=_0x4e2213;if(_0x35b3a3===0x194&&(_0x576785=null,_0x35b3a3=null),_0x35b3a3===null&&this['onDataUpdate_'](_0xb89927,_0x576785,!0x1,_0x201d2b),Le(this['listens_'],_0x58a4cc)===_0x485b12){let _0x2bf9d7;_0x35b3a3?_0x35b3a3===0x191?_0x2bf9d7='permission_denied':_0x2bf9d7='rest_error:'+_0x35b3a3:_0x2bf9d7='ok',_0x4b16c8(_0x2bf9d7,null);}});}['unlisten'](_0x2b5dd3,_0x1197e5){const _0xd828a7=vn['getListenId_'](_0x2b5dd3,_0x1197e5);delete this['listens_'][_0xd828a7];}['get'](_0x3e7ef9){const _0x2ddc85=ir(_0x3e7ef9['_queryParams']),_0x58ff02=_0x3e7ef9['_path']['toString'](),_0x438e03=new H();return this['restRequest_'](_0x58ff02+'.json',_0x2ddc85,(_0x58eb57,_0xaabe63)=>{let _0x40c3c9=_0xaabe63;_0x58eb57===0x194&&(_0x40c3c9=null,_0x58eb57=null),_0x58eb57===null?(this['onDataUpdate_'](_0x58ff02,_0x40c3c9,!0x1,null),_0x438e03['resolve'](_0x40c3c9)):_0x438e03['reject'](new Error(_0x40c3c9));}),_0x438e03['promise'];}['refreshAuthToken'](_0x4753ab){}['restRequest_'](_0x7bd4a6,_0x1fd491={},_0x808b4b){return _0x1fd491['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x1a8a65,_0x117dd4])=>{_0x1a8a65&&_0x1a8a65['accessToken']&&(_0x1fd491['auth']=_0x1a8a65['accessToken']),_0x117dd4&&_0x117dd4['token']&&(_0x1fd491['ac']=_0x117dd4['token']);const _0x1d3a16=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x7bd4a6+'?ns='+this['repoInfo_']['namespace']+ut(_0x1fd491);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1d3a16);const _0x2df976=new XMLHttpRequest();_0x2df976['onreadystatechange']=()=>{if(_0x808b4b&&_0x2df976['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1d3a16+'\x20received.\x20status:',_0x2df976['status'],'response:',_0x2df976['responseText']);let _0x46ed89=null;if(_0x2df976['status']>=0xc8&&_0x2df976['status']<0x12c){try{_0x46ed89=Nt(_0x2df976['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1d3a16+':\x20'+_0x2df976['responseText']);}_0x808b4b(null,_0x46ed89);}else _0x2df976['status']!==0x191&&_0x2df976['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1d3a16+'\x20Status:\x20'+_0x2df976['status']),_0x808b4b(_0x2df976['status']);_0x808b4b=null;}},_0x2df976['open']('GET',_0x1d3a16,!0x0),_0x2df976['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3d1069){return this['rootNode_']['getChild'](_0x3d1069);}['updateSnapshot'](_0x280c68,_0x19b38a){this['rootNode_']=this['rootNode_']['updateChild'](_0x280c68,_0x19b38a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0xc01bb1,_0x12594d,_0x22da9e){if(v(_0x12594d))_0xc01bb1['value']=_0x22da9e,_0xc01bb1['children']['clear']();else{if(_0xc01bb1['value']!==null)_0xc01bb1['value']=_0xc01bb1['value']['updateChild'](_0x12594d,_0x22da9e);else{const _0x225c90=y(_0x12594d);_0xc01bb1['children']['has'](_0x225c90)||_0xc01bb1['children']['set'](_0x225c90,En());const _0x24b68e=_0xc01bb1['children']['get'](_0x225c90);_0x12594d=S(_0x12594d),pt(_0x24b68e,_0x12594d,_0x22da9e);}}}function Ti(_0x1a09ed,_0x21ab71){if(v(_0x21ab71))return _0x1a09ed['value']=null,_0x1a09ed['children']['clear'](),!0x0;if(_0x1a09ed['value']!==null){if(_0x1a09ed['value']['isLeafNode']())return!0x1;{const _0x1c33a9=_0x1a09ed['value'];return _0x1a09ed['value']=null,_0x1c33a9['forEachChild'](R,(_0x85e68e,_0x20a549)=>{pt(_0x1a09ed,new C(_0x85e68e),_0x20a549);}),Ti(_0x1a09ed,_0x21ab71);}}else{if(_0x1a09ed['children']['size']>0x0){const _0x2320e4=y(_0x21ab71);return _0x21ab71=S(_0x21ab71),_0x1a09ed['children']['has'](_0x2320e4)&&Ti(_0x1a09ed['children']['get'](_0x2320e4),_0x21ab71)&&_0x1a09ed['children']['delete'](_0x2320e4),_0x1a09ed['children']['size']===0x0;}else return!0x0;}}function Si(_0x207844,_0x46fcca,_0x45053e){_0x207844['value']!==null?_0x45053e(_0x46fcca,_0x207844['value']):Zh(_0x207844,(_0x442410,_0x441189)=>{const _0x30e74e=new C(_0x46fcca['toString']()+'/'+_0x442410);Si(_0x441189,_0x30e74e,_0x45053e);});}function Zh(_0xf316e9,_0xbc6c37){_0xf316e9['children']['forEach']((_0x37eecc,_0x5cdce5)=>{_0xbc6c37(_0x5cdce5,_0x37eecc);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3e75de){this['collection_']=_0x3e75de,this['last_']=null;}['get'](){const _0x337d39=this['collection_']['get'](),_0x15e2af={..._0x337d39};return this['last_']&&x(this['last_'],(_0x5b04f7,_0x5bd4cf)=>{_0x15e2af[_0x5b04f7]=_0x15e2af[_0x5b04f7]-_0x5bd4cf;}),this['last_']=_0x337d39,_0x15e2af;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x56ff48,_0x2c8c1c){this['server_']=_0x2c8c1c,this['statsToReport_']={},this['statsListener_']=new eu(_0x56ff48);const _0x5a115b=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5a115b));}['reportStats_'](){const _0x294f84=this['statsListener_']['get'](),_0xaa21a6={};let _0x2c8792=!0x1;x(_0x294f84,(_0xe052e8,_0x48e95d)=>{_0x48e95d>0x0&&Q(this['statsToReport_'],_0xe052e8)&&(_0xaa21a6[_0xe052e8]=_0x48e95d,_0x2c8792=!0x0);}),_0x2c8792&&this['server_']['reportStats'](_0xaa21a6),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x58a1b6){_0x58a1b6[_0x58a1b6['OVERWRITE']=0x0]='OVERWRITE',_0x58a1b6[_0x58a1b6['MERGE']=0x1]='MERGE',_0x58a1b6[_0x58a1b6['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x58a1b6[_0x58a1b6['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x599119){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x599119,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x46deca,_0x3b6ffd,_0x199f86){this['path']=_0x46deca,this['affectedTree']=_0x3b6ffd,this['revert']=_0x199f86,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x27c30a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x6c17fe=this['affectedTree']['subtree'](new C(_0x27c30a));return new In(w(),_0x6c17fe,this['revert']);}}else return f(y(this['path'])===_0x27c30a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x58e738,_0x367ca4){this['source']=_0x58e738,this['path']=_0x367ca4,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4903c1){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x21907b,_0x58e6d8,_0x5ecfbb){this['source']=_0x21907b,this['path']=_0x58e6d8,this['snap']=_0x5ecfbb,this['type']=z['OVERWRITE'];}['operationForChild'](_0xa6933d){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xa6933d)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x2610ca,_0x1f77f4,_0x24ee85){this['source']=_0x2610ca,this['path']=_0x1f77f4,this['children']=_0x24ee85,this['type']=z['MERGE'];}['operationForChild'](_0xd97932){if(v(this['path'])){const _0x155223=this['children']['subtree'](new C(_0xd97932));return _0x155223['isEmpty']()?null:_0x155223['value']?new Be(this['source'],w(),_0x155223['value']):new ot(this['source'],w(),_0x155223);}else return f(y(this['path'])===_0xd97932,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x327e50,_0x2e79ad,_0x283d04){this['node_']=_0x327e50,this['fullyInitialized_']=_0x2e79ad,this['filtered_']=_0x283d04;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x56b7ed){if(v(_0x56b7ed))return this['isFullyInitialized']()&&!this['filtered_'];const _0x9b5a0=y(_0x56b7ed);return this['isCompleteForChild'](_0x9b5a0);}['isCompleteForChild'](_0x337229){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x337229);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3e8e37){this['query_']=_0x3e8e37,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x7d213a,_0x2ee16e,_0x39fb36,_0x782ed7){const _0x2e258b=[],_0x5581dd=[];return _0x2ee16e['forEach'](_0x5a8bd8=>{_0x5a8bd8['type']==='child_changed'&&_0x7d213a['index_']['indexedValueChanged'](_0x5a8bd8['oldSnap'],_0x5a8bd8['snapshotNode'])&&_0x5581dd['push'](zh(_0x5a8bd8['childName'],_0x5a8bd8['snapshotNode']));}),wt(_0x7d213a,_0x2e258b,'child_removed',_0x2ee16e,_0x782ed7,_0x39fb36),wt(_0x7d213a,_0x2e258b,'child_added',_0x2ee16e,_0x782ed7,_0x39fb36),wt(_0x7d213a,_0x2e258b,'child_moved',_0x5581dd,_0x782ed7,_0x39fb36),wt(_0x7d213a,_0x2e258b,'child_changed',_0x2ee16e,_0x782ed7,_0x39fb36),wt(_0x7d213a,_0x2e258b,'value',_0x2ee16e,_0x782ed7,_0x39fb36),_0x2e258b;}function wt(_0x4cbbc2,_0x177489,_0x34640f,_0x20262e,_0x3a3c6c,_0xf0d03a){const _0x211415=_0x20262e['filter'](_0x104ddc=>_0x104ddc['type']===_0x34640f);_0x211415['sort']((_0xee2688,_0x4bc096)=>au(_0x4cbbc2,_0xee2688,_0x4bc096)),_0x211415['forEach'](_0x1148a8=>{const _0x1ce931=ou(_0x4cbbc2,_0x1148a8,_0xf0d03a);_0x3a3c6c['forEach'](_0x2b1e59=>{_0x2b1e59['respondsTo'](_0x1148a8['type'])&&_0x177489['push'](_0x2b1e59['createEvent'](_0x1ce931,_0x4cbbc2['query_']));});});}function ou(_0x598322,_0x26a796,_0x56de71){return _0x26a796['type']==='value'||_0x26a796['type']==='child_removed'||(_0x26a796['prevName']=_0x56de71['getPredecessorChildName'](_0x26a796['childName'],_0x26a796['snapshotNode'],_0x598322['index_'])),_0x26a796;}function au(_0x5e2b0e,_0x25969f,_0x2024b4){if(_0x25969f['childName']==null||_0x2024b4['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x4dd81e=new E(_0x25969f['childName'],_0x25969f['snapshotNode']),_0x2a9464=new E(_0x2024b4['childName'],_0x2024b4['snapshotNode']);return _0x5e2b0e['index_']['compare'](_0x4dd81e,_0x2a9464);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x176a52,_0x563d2e){return{'eventCache':_0x176a52,'serverCache':_0x563d2e};}function Rt(_0xf3b43,_0x9a4d91,_0x5a4a97,_0x35d536){return Un(new Te(_0x9a4d91,_0x5a4a97,_0x35d536),_0xf3b43['serverCache']);}function Fo(_0x367bcb,_0x363136,_0xadc742,_0x48780e){return Un(_0x367bcb['eventCache'],new Te(_0x363136,_0xadc742,_0x48780e));}function wn(_0x2921b8){return _0x2921b8['eventCache']['isFullyInitialized']()?_0x2921b8['eventCache']['getNode']():null;}function Ve(_0x4045b8){return _0x4045b8['serverCache']['isFullyInitialized']()?_0x4045b8['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x965b33){let _0x2f9197=new b(null);return x(_0x965b33,(_0x88533d,_0x50541c)=>{_0x2f9197=_0x2f9197['set'](new C(_0x88533d),_0x50541c);}),_0x2f9197;}constructor(_0x2088f6,_0xf964bc=cu()){this['value']=_0x2088f6,this['children']=_0xf964bc;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x44d49c,_0x107689){if(this['value']!=null&&_0x107689(this['value']))return{'path':w(),'value':this['value']};if(v(_0x44d49c))return null;{const _0x588c25=y(_0x44d49c),_0x2440f4=this['children']['get'](_0x588c25);if(_0x2440f4!==null){const _0xbb566c=_0x2440f4['findRootMostMatchingPathAndValue'](S(_0x44d49c),_0x107689);return _0xbb566c!=null?{'path':k(new C(_0x588c25),_0xbb566c['path']),'value':_0xbb566c['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x15a29a){return this['findRootMostMatchingPathAndValue'](_0x15a29a,()=>!0x0);}['subtree'](_0x5b785f){if(v(_0x5b785f))return this;{const _0x23cf47=y(_0x5b785f),_0xdb0dad=this['children']['get'](_0x23cf47);return _0xdb0dad!==null?_0xdb0dad['subtree'](S(_0x5b785f)):new b(null);}}['set'](_0x2ba3cd,_0x5e3fd9){if(v(_0x2ba3cd))return new b(_0x5e3fd9,this['children']);{const _0x51e13e=y(_0x2ba3cd),_0x836031=(this['children']['get'](_0x51e13e)||new b(null))['set'](S(_0x2ba3cd),_0x5e3fd9),_0x41db4e=this['children']['insert'](_0x51e13e,_0x836031);return new b(this['value'],_0x41db4e);}}['remove'](_0x20014e){if(v(_0x20014e))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5a453b=y(_0x20014e),_0x429eef=this['children']['get'](_0x5a453b);if(_0x429eef){const _0xce19e2=_0x429eef['remove'](S(_0x20014e));let _0x1c0cfc;return _0xce19e2['isEmpty']()?_0x1c0cfc=this['children']['remove'](_0x5a453b):_0x1c0cfc=this['children']['insert'](_0x5a453b,_0xce19e2),this['value']===null&&_0x1c0cfc['isEmpty']()?new b(null):new b(this['value'],_0x1c0cfc);}else return this;}}['get'](_0x4b7469){if(v(_0x4b7469))return this['value'];{const _0x3b46e2=y(_0x4b7469),_0x5be264=this['children']['get'](_0x3b46e2);return _0x5be264?_0x5be264['get'](S(_0x4b7469)):null;}}['setTree'](_0x4cc5b3,_0x20bdc8){if(v(_0x4cc5b3))return _0x20bdc8;{const _0x38ec8e=y(_0x4cc5b3),_0x22702c=(this['children']['get'](_0x38ec8e)||new b(null))['setTree'](S(_0x4cc5b3),_0x20bdc8);let _0x22f47c;return _0x22702c['isEmpty']()?_0x22f47c=this['children']['remove'](_0x38ec8e):_0x22f47c=this['children']['insert'](_0x38ec8e,_0x22702c),new b(this['value'],_0x22f47c);}}['fold'](_0x3dd42f){return this['fold_'](w(),_0x3dd42f);}['fold_'](_0x38b3a6,_0x364f95){const _0x23c7c6={};return this['children']['inorderTraversal']((_0x372bc4,_0x1d276d)=>{_0x23c7c6[_0x372bc4]=_0x1d276d['fold_'](k(_0x38b3a6,_0x372bc4),_0x364f95);}),_0x364f95(_0x38b3a6,this['value'],_0x23c7c6);}['findOnPath'](_0xcbfa3e,_0x233ae6){return this['findOnPath_'](_0xcbfa3e,w(),_0x233ae6);}['findOnPath_'](_0x2072cf,_0x5ec7f6,_0x2e6c2c){const _0x12fcca=this['value']?_0x2e6c2c(_0x5ec7f6,this['value']):!0x1;if(_0x12fcca)return _0x12fcca;if(v(_0x2072cf))return null;{const _0x23deb6=y(_0x2072cf),_0x4daa5e=this['children']['get'](_0x23deb6);return _0x4daa5e?_0x4daa5e['findOnPath_'](S(_0x2072cf),k(_0x5ec7f6,_0x23deb6),_0x2e6c2c):null;}}['foreachOnPath'](_0x3c2e4f,_0x11a71d){return this['foreachOnPath_'](_0x3c2e4f,w(),_0x11a71d);}['foreachOnPath_'](_0x7c468,_0x2531f9,_0x189c1b){if(v(_0x7c468))return this;{this['value']&&_0x189c1b(_0x2531f9,this['value']);const _0x38fbde=y(_0x7c468),_0x3d61e4=this['children']['get'](_0x38fbde);return _0x3d61e4?_0x3d61e4['foreachOnPath_'](S(_0x7c468),k(_0x2531f9,_0x38fbde),_0x189c1b):new b(null);}}['foreach'](_0x40e413){this['foreach_'](w(),_0x40e413);}['foreach_'](_0x213c54,_0x2d7a51){this['children']['inorderTraversal']((_0x480e3d,_0x599b7e)=>{_0x599b7e['foreach_'](k(_0x213c54,_0x480e3d),_0x2d7a51);}),this['value']&&_0x2d7a51(_0x213c54,this['value']);}['foreachChild'](_0x2b7c23){this['children']['inorderTraversal']((_0x276b03,_0x3fd26f)=>{_0x3fd26f['value']&&_0x2b7c23(_0x276b03,_0x3fd26f['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x2d8175){this['writeTree_']=_0x2d8175;}static['empty'](){return new K(new b(null));}}function At(_0x3fc664,_0xaca8f3,_0x2ba215){if(v(_0xaca8f3))return new K(new b(_0x2ba215));{const _0x343bca=_0x3fc664['writeTree_']['findRootMostValueAndPath'](_0xaca8f3);if(_0x343bca!=null){const _0x10ce3d=_0x343bca['path'];let _0x2951aa=_0x343bca['value'];const _0x18d067=F(_0x10ce3d,_0xaca8f3);return _0x2951aa=_0x2951aa['updateChild'](_0x18d067,_0x2ba215),new K(_0x3fc664['writeTree_']['set'](_0x10ce3d,_0x2951aa));}else{const _0x36abbc=new b(_0x2ba215),_0xb835eb=_0x3fc664['writeTree_']['setTree'](_0xaca8f3,_0x36abbc);return new K(_0xb835eb);}}}function bi(_0x202727,_0x5a41b6,_0x100aec){let _0x25cfb9=_0x202727;return x(_0x100aec,(_0x105870,_0x455be3)=>{_0x25cfb9=At(_0x25cfb9,k(_0x5a41b6,_0x105870),_0x455be3);}),_0x25cfb9;}function or(_0x5b68ff,_0x125143){if(v(_0x125143))return K['empty']();{const _0x303710=_0x5b68ff['writeTree_']['setTree'](_0x125143,new b(null));return new K(_0x303710);}}function Ri(_0x2647f6,_0xd79c7d){return ze(_0x2647f6,_0xd79c7d)!=null;}function ze(_0x485fd9,_0x35e041){const _0xa2638a=_0x485fd9['writeTree_']['findRootMostValueAndPath'](_0x35e041);return _0xa2638a!=null?_0x485fd9['writeTree_']['get'](_0xa2638a['path'])['getChild'](F(_0xa2638a['path'],_0x35e041)):null;}function ar(_0x287076){const _0x4fcdf2=[],_0x2a87ba=_0x287076['writeTree_']['value'];return _0x2a87ba!=null?_0x2a87ba['isLeafNode']()||_0x2a87ba['forEachChild'](R,(_0x53e94e,_0x1d244e)=>{_0x4fcdf2['push'](new E(_0x53e94e,_0x1d244e));}):_0x287076['writeTree_']['children']['inorderTraversal']((_0x33825a,_0x57e903)=>{_0x57e903['value']!=null&&_0x4fcdf2['push'](new E(_0x33825a,_0x57e903['value']));}),_0x4fcdf2;}function Ee(_0x16668e,_0xe9724e){if(v(_0xe9724e))return _0x16668e;{const _0x38569f=ze(_0x16668e,_0xe9724e);return _0x38569f!=null?new K(new b(_0x38569f)):new K(_0x16668e['writeTree_']['subtree'](_0xe9724e));}}function Ai(_0x4f9fbd){return _0x4f9fbd['writeTree_']['isEmpty']();}function at(_0x5581d5,_0x13dc45){return Uo(w(),_0x5581d5['writeTree_'],_0x13dc45);}function Uo(_0x95da96,_0x5924a2,_0x7137ea){if(_0x5924a2['value']!=null)return _0x7137ea['updateChild'](_0x95da96,_0x5924a2['value']);{let _0x421090=null;return _0x5924a2['children']['inorderTraversal']((_0x4dd9a1,_0x353962)=>{_0x4dd9a1==='.priority'?(f(_0x353962['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x421090=_0x353962['value']):_0x7137ea=Uo(k(_0x95da96,_0x4dd9a1),_0x353962,_0x7137ea);}),!_0x7137ea['getChild'](_0x95da96)['isEmpty']()&&_0x421090!==null&&(_0x7137ea=_0x7137ea['updateChild'](k(_0x95da96,'.priority'),_0x421090)),_0x7137ea;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x53419f,_0x234fa6){return Ho(_0x234fa6,_0x53419f);}function lu(_0x42e1a5,_0x31947f,_0x1ff59b,_0x29120f,_0x13d697){f(_0x29120f>_0x42e1a5['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x13d697===void 0x0&&(_0x13d697=!0x0),_0x42e1a5['allWrites']['push']({'path':_0x31947f,'snap':_0x1ff59b,'writeId':_0x29120f,'visible':_0x13d697}),_0x13d697&&(_0x42e1a5['visibleWrites']=At(_0x42e1a5['visibleWrites'],_0x31947f,_0x1ff59b)),_0x42e1a5['lastWriteId']=_0x29120f;}function hu(_0x34e7d1,_0x3b65c2,_0x43542d,_0x50979b){f(_0x50979b>_0x34e7d1['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x34e7d1['allWrites']['push']({'path':_0x3b65c2,'children':_0x43542d,'writeId':_0x50979b,'visible':!0x0}),_0x34e7d1['visibleWrites']=bi(_0x34e7d1['visibleWrites'],_0x3b65c2,_0x43542d),_0x34e7d1['lastWriteId']=_0x50979b;}function uu(_0x29a97b,_0x4f3e79){for(let _0xa4580d=0x0;_0xa4580d<_0x29a97b['allWrites']['length'];_0xa4580d++){const _0x5c04e5=_0x29a97b['allWrites'][_0xa4580d];if(_0x5c04e5['writeId']===_0x4f3e79)return _0x5c04e5;}return null;}function du(_0x4218f8,_0x4125fe){const _0x311224=_0x4218f8['allWrites']['findIndex'](_0x2fa468=>_0x2fa468['writeId']===_0x4125fe);f(_0x311224>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1f4a32=_0x4218f8['allWrites'][_0x311224];_0x4218f8['allWrites']['splice'](_0x311224,0x1);let _0x22c9b2=_0x1f4a32['visible'],_0x13eabb=!0x1,_0x362c79=_0x4218f8['allWrites']['length']-0x1;for(;_0x22c9b2&&_0x362c79>=0x0;){const _0x9a9aa8=_0x4218f8['allWrites'][_0x362c79];_0x9a9aa8['visible']&&(_0x362c79>=_0x311224&&fu(_0x9a9aa8,_0x1f4a32['path'])?_0x22c9b2=!0x1:G(_0x1f4a32['path'],_0x9a9aa8['path'])&&(_0x13eabb=!0x0)),_0x362c79--;}if(_0x22c9b2){if(_0x13eabb)return pu(_0x4218f8),!0x0;if(_0x1f4a32['snap'])_0x4218f8['visibleWrites']=or(_0x4218f8['visibleWrites'],_0x1f4a32['path']);else{const _0x5c788a=_0x1f4a32['children'];x(_0x5c788a,_0x4d276c=>{_0x4218f8['visibleWrites']=or(_0x4218f8['visibleWrites'],k(_0x1f4a32['path'],_0x4d276c));});}return!0x0;}else return!0x1;}function fu(_0x523859,_0x20623a){if(_0x523859['snap'])return G(_0x523859['path'],_0x20623a);for(const _0x36ad72 in _0x523859['children'])if(_0x523859['children']['hasOwnProperty'](_0x36ad72)&&G(k(_0x523859['path'],_0x36ad72),_0x20623a))return!0x0;return!0x1;}function pu(_0x263aec){_0x263aec['visibleWrites']=Wo(_0x263aec['allWrites'],_u,w()),_0x263aec['allWrites']['length']>0x0?_0x263aec['lastWriteId']=_0x263aec['allWrites'][_0x263aec['allWrites']['length']-0x1]['writeId']:_0x263aec['lastWriteId']=-0x1;}function _u(_0x484bb5){return _0x484bb5['visible'];}function Wo(_0x276795,_0x11d330,_0x4a2d1b){let _0x24e4e5=K['empty']();for(let _0x279b0f=0x0;_0x279b0f<_0x276795['length'];++_0x279b0f){const _0x372449=_0x276795[_0x279b0f];if(_0x11d330(_0x372449)){const _0x10a3f9=_0x372449['path'];let _0x40f561;if(_0x372449['snap'])G(_0x4a2d1b,_0x10a3f9)?(_0x40f561=F(_0x4a2d1b,_0x10a3f9),_0x24e4e5=At(_0x24e4e5,_0x40f561,_0x372449['snap'])):G(_0x10a3f9,_0x4a2d1b)&&(_0x40f561=F(_0x10a3f9,_0x4a2d1b),_0x24e4e5=At(_0x24e4e5,w(),_0x372449['snap']['getChild'](_0x40f561)));else{if(_0x372449['children']){if(G(_0x4a2d1b,_0x10a3f9))_0x40f561=F(_0x4a2d1b,_0x10a3f9),_0x24e4e5=bi(_0x24e4e5,_0x40f561,_0x372449['children']);else{if(G(_0x10a3f9,_0x4a2d1b)){if(_0x40f561=F(_0x10a3f9,_0x4a2d1b),v(_0x40f561))_0x24e4e5=bi(_0x24e4e5,w(),_0x372449['children']);else{const _0x4619d4=Le(_0x372449['children'],y(_0x40f561));if(_0x4619d4){const _0x4c0ff7=_0x4619d4['getChild'](S(_0x40f561));_0x24e4e5=At(_0x24e4e5,w(),_0x4c0ff7);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x24e4e5;}function Bo(_0x3efd1c,_0x4d265f,_0x364fb7,_0x4bae38,_0x28388a){if(!_0x4bae38&&!_0x28388a){const _0x5cd199=ze(_0x3efd1c['visibleWrites'],_0x4d265f);if(_0x5cd199!=null)return _0x5cd199;{const _0x1f4a79=Ee(_0x3efd1c['visibleWrites'],_0x4d265f);if(Ai(_0x1f4a79))return _0x364fb7;if(_0x364fb7==null&&!Ri(_0x1f4a79,w()))return null;{const _0x103af2=_0x364fb7||g['EMPTY_NODE'];return at(_0x1f4a79,_0x103af2);}}}else{const _0x2d43a9=Ee(_0x3efd1c['visibleWrites'],_0x4d265f);if(!_0x28388a&&Ai(_0x2d43a9))return _0x364fb7;if(!_0x28388a&&_0x364fb7==null&&!Ri(_0x2d43a9,w()))return null;{const _0xa3b7cf=function(_0x3cdb62){return(_0x3cdb62['visible']||_0x28388a)&&(!_0x4bae38||!~_0x4bae38['indexOf'](_0x3cdb62['writeId']))&&(G(_0x3cdb62['path'],_0x4d265f)||G(_0x4d265f,_0x3cdb62['path']));},_0x278505=Wo(_0x3efd1c['allWrites'],_0xa3b7cf,_0x4d265f),_0x4d6cbc=_0x364fb7||g['EMPTY_NODE'];return at(_0x278505,_0x4d6cbc);}}}function gu(_0x231a4a,_0x4bf70a,_0x18cc53){let _0x259126=g['EMPTY_NODE'];const _0x22aaa1=ze(_0x231a4a['visibleWrites'],_0x4bf70a);if(_0x22aaa1)return _0x22aaa1['isLeafNode']()||_0x22aaa1['forEachChild'](R,(_0x91a2a3,_0x1214f4)=>{_0x259126=_0x259126['updateImmediateChild'](_0x91a2a3,_0x1214f4);}),_0x259126;if(_0x18cc53){const _0x5036b2=Ee(_0x231a4a['visibleWrites'],_0x4bf70a);return _0x18cc53['forEachChild'](R,(_0x4df171,_0x591da1)=>{const _0x142b80=at(Ee(_0x5036b2,new C(_0x4df171)),_0x591da1);_0x259126=_0x259126['updateImmediateChild'](_0x4df171,_0x142b80);}),ar(_0x5036b2)['forEach'](_0x3c68bf=>{_0x259126=_0x259126['updateImmediateChild'](_0x3c68bf['name'],_0x3c68bf['node']);}),_0x259126;}else{const _0x23b708=Ee(_0x231a4a['visibleWrites'],_0x4bf70a);return ar(_0x23b708)['forEach'](_0x131d29=>{_0x259126=_0x259126['updateImmediateChild'](_0x131d29['name'],_0x131d29['node']);}),_0x259126;}}function mu(_0x411860,_0x10861b,_0x293f0b,_0x21d2b1,_0x16352f){f(_0x21d2b1||_0x16352f,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1bd07e=k(_0x10861b,_0x293f0b);if(Ri(_0x411860['visibleWrites'],_0x1bd07e))return null;{const _0x4ccb8b=Ee(_0x411860['visibleWrites'],_0x1bd07e);return Ai(_0x4ccb8b)?_0x16352f['getChild'](_0x293f0b):at(_0x4ccb8b,_0x16352f['getChild'](_0x293f0b));}}function yu(_0x1c5737,_0x1dbed2,_0x270290,_0x4ddea0){const _0x415bf1=k(_0x1dbed2,_0x270290),_0x41c85d=ze(_0x1c5737['visibleWrites'],_0x415bf1);if(_0x41c85d!=null)return _0x41c85d;if(_0x4ddea0['isCompleteForChild'](_0x270290)){const _0x5d5038=Ee(_0x1c5737['visibleWrites'],_0x415bf1);return at(_0x5d5038,_0x4ddea0['getNode']()['getImmediateChild'](_0x270290));}else return null;}function vu(_0x494671,_0x58c65b){return ze(_0x494671['visibleWrites'],_0x58c65b);}function Eu(_0x120850,_0x21d3ed,_0x14c195,_0x5226e7,_0x5bcace,_0x2507a3,_0x3b2725){let _0x116809;const _0x29fadb=Ee(_0x120850['visibleWrites'],_0x21d3ed),_0x522f52=ze(_0x29fadb,w());if(_0x522f52!=null)_0x116809=_0x522f52;else{if(_0x14c195!=null)_0x116809=at(_0x29fadb,_0x14c195);else return[];}if(_0x116809=_0x116809['withIndex'](_0x3b2725),!_0x116809['isEmpty']()&&!_0x116809['isLeafNode']()){const _0x5e198e=[],_0x34c89d=_0x3b2725['getCompare'](),_0x3f5f55=_0x2507a3?_0x116809['getReverseIteratorFrom'](_0x5226e7,_0x3b2725):_0x116809['getIteratorFrom'](_0x5226e7,_0x3b2725);let _0x3e2298=_0x3f5f55['getNext']();for(;_0x3e2298&&_0x5e198e['length']<_0x5bcace;)_0x34c89d(_0x3e2298,_0x5226e7)!==0x0&&_0x5e198e['push'](_0x3e2298),_0x3e2298=_0x3f5f55['getNext']();return _0x5e198e;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x170002,_0x7bd22e,_0x2b777d,_0x283dca){return Bo(_0x170002['writeTree'],_0x170002['treePath'],_0x7bd22e,_0x2b777d,_0x283dca);}function is(_0x507b93,_0x141d9c){return gu(_0x507b93['writeTree'],_0x507b93['treePath'],_0x141d9c);}function cr(_0x3c08be,_0xec5f6,_0x54aead,_0x4dc3da){return mu(_0x3c08be['writeTree'],_0x3c08be['treePath'],_0xec5f6,_0x54aead,_0x4dc3da);}function Tn(_0x24e719,_0x1e48a0){return vu(_0x24e719['writeTree'],k(_0x24e719['treePath'],_0x1e48a0));}function wu(_0x13d3d3,_0x591a06,_0x1934af,_0x38c204,_0x528d80,_0x4dc85c){return Eu(_0x13d3d3['writeTree'],_0x13d3d3['treePath'],_0x591a06,_0x1934af,_0x38c204,_0x528d80,_0x4dc85c);}function ss(_0x4a4b9c,_0x40732d,_0x939cc8){return yu(_0x4a4b9c['writeTree'],_0x4a4b9c['treePath'],_0x40732d,_0x939cc8);}function Vo(_0x1d8a5b,_0x4dd333){return Ho(k(_0x1d8a5b['treePath'],_0x4dd333),_0x1d8a5b['writeTree']);}function Ho(_0x5eff30,_0x267649){return{'treePath':_0x5eff30,'writeTree':_0x267649};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3ce474){const _0x292406=_0x3ce474['type'],_0x4207dd=_0x3ce474['childName'];f(_0x292406==='child_added'||_0x292406==='child_changed'||_0x292406==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4207dd!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3bac55=this['changeMap']['get'](_0x4207dd);if(_0x3bac55){const _0x3d3685=_0x3bac55['type'];if(_0x292406==='child_added'&&_0x3d3685==='child_removed')this['changeMap']['set'](_0x4207dd,xt(_0x4207dd,_0x3ce474['snapshotNode'],_0x3bac55['snapshotNode']));else{if(_0x292406==='child_removed'&&_0x3d3685==='child_added')this['changeMap']['delete'](_0x4207dd);else{if(_0x292406==='child_removed'&&_0x3d3685==='child_changed')this['changeMap']['set'](_0x4207dd,Lt(_0x4207dd,_0x3bac55['oldSnap']));else{if(_0x292406==='child_changed'&&_0x3d3685==='child_added')this['changeMap']['set'](_0x4207dd,rt(_0x4207dd,_0x3ce474['snapshotNode']));else{if(_0x292406==='child_changed'&&_0x3d3685==='child_changed')this['changeMap']['set'](_0x4207dd,xt(_0x4207dd,_0x3ce474['snapshotNode'],_0x3bac55['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x3ce474+'\x20occurred\x20after\x20'+_0x3bac55);}}}}}else this['changeMap']['set'](_0x4207dd,_0x3ce474);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x26bfcd){return null;}['getChildAfterChild'](_0x1ed13e,_0x16c4af,_0x284d6a){return null;}}const $o=new Tu();class rs{constructor(_0x393fe9,_0x19eb66,_0x599315=null){this['writes_']=_0x393fe9,this['viewCache_']=_0x19eb66,this['optCompleteServerCache_']=_0x599315;}['getCompleteChild'](_0x1c610f){const _0x297e7f=this['viewCache_']['eventCache'];if(_0x297e7f['isCompleteForChild'](_0x1c610f))return _0x297e7f['getNode']()['getImmediateChild'](_0x1c610f);{const _0x18173e=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x1c610f,_0x18173e);}}['getChildAfterChild'](_0x183192,_0x19dec7,_0x4cbd41){const _0xd4c0dc=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x5782ee=wu(this['writes_'],_0xd4c0dc,_0x19dec7,0x1,_0x4cbd41,_0x183192);return _0x5782ee['length']===0x0?null:_0x5782ee[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x41742a){return{'filter':_0x41742a};}function bu(_0x80197f,_0x53b9d2){f(_0x53b9d2['eventCache']['getNode']()['isIndexed'](_0x80197f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x53b9d2['serverCache']['getNode']()['isIndexed'](_0x80197f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x3686b7,_0x5af788,_0x2ab43a,_0x50cf8c,_0x18b4b4){const _0x130a2b=new Cu();let _0x53bd1b,_0x449726;if(_0x2ab43a['type']===z['OVERWRITE']){const _0x259a19=_0x2ab43a;_0x259a19['source']['fromUser']?_0x53bd1b=ki(_0x3686b7,_0x5af788,_0x259a19['path'],_0x259a19['snap'],_0x50cf8c,_0x18b4b4,_0x130a2b):(f(_0x259a19['source']['fromServer'],'Unknown\x20source.'),_0x449726=_0x259a19['source']['tagged']||_0x5af788['serverCache']['isFiltered']()&&!v(_0x259a19['path']),_0x53bd1b=Sn(_0x3686b7,_0x5af788,_0x259a19['path'],_0x259a19['snap'],_0x50cf8c,_0x18b4b4,_0x449726,_0x130a2b));}else{if(_0x2ab43a['type']===z['MERGE']){const _0x1d91f9=_0x2ab43a;_0x1d91f9['source']['fromUser']?_0x53bd1b=ku(_0x3686b7,_0x5af788,_0x1d91f9['path'],_0x1d91f9['children'],_0x50cf8c,_0x18b4b4,_0x130a2b):(f(_0x1d91f9['source']['fromServer'],'Unknown\x20source.'),_0x449726=_0x1d91f9['source']['tagged']||_0x5af788['serverCache']['isFiltered'](),_0x53bd1b=Pi(_0x3686b7,_0x5af788,_0x1d91f9['path'],_0x1d91f9['children'],_0x50cf8c,_0x18b4b4,_0x449726,_0x130a2b));}else{if(_0x2ab43a['type']===z['ACK_USER_WRITE']){const _0x17408e=_0x2ab43a;_0x17408e['revert']?_0x53bd1b=Ou(_0x3686b7,_0x5af788,_0x17408e['path'],_0x50cf8c,_0x18b4b4,_0x130a2b):_0x53bd1b=Pu(_0x3686b7,_0x5af788,_0x17408e['path'],_0x17408e['affectedTree'],_0x50cf8c,_0x18b4b4,_0x130a2b);}else{if(_0x2ab43a['type']===z['LISTEN_COMPLETE'])_0x53bd1b=Nu(_0x3686b7,_0x5af788,_0x2ab43a['path'],_0x50cf8c,_0x130a2b);else throw ht('Unknown\x20operation\x20type:\x20'+_0x2ab43a['type']);}}}const _0x119eeb=_0x130a2b['getChanges']();return Au(_0x5af788,_0x53bd1b,_0x119eeb),{'viewCache':_0x53bd1b,'changes':_0x119eeb};}function Au(_0x23dcbe,_0x376921,_0x55a719){const _0x5e5a96=_0x376921['eventCache'];if(_0x5e5a96['isFullyInitialized']()){const _0x2eb738=_0x5e5a96['getNode']()['isLeafNode']()||_0x5e5a96['getNode']()['isEmpty'](),_0x23d029=wn(_0x23dcbe);(_0x55a719['length']>0x0||!_0x23dcbe['eventCache']['isFullyInitialized']()||_0x2eb738&&!_0x5e5a96['getNode']()['equals'](_0x23d029)||!_0x5e5a96['getNode']()['getPriority']()['equals'](_0x23d029['getPriority']()))&&_0x55a719['push'](Lo(wn(_0x376921)));}}function Go(_0xdb6049,_0x48200c,_0x18de51,_0x1142bf,_0x428427,_0x148c49){const _0x42cae1=_0x48200c['eventCache'];if(Tn(_0x1142bf,_0x18de51)!=null)return _0x48200c;{let _0x383329,_0x5a0d1;if(v(_0x18de51)){if(f(_0x48200c['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x48200c['serverCache']['isFiltered']()){const _0x1d338e=Ve(_0x48200c),_0x2ac62b=_0x1d338e instanceof g?_0x1d338e:g['EMPTY_NODE'],_0x13efc4=is(_0x1142bf,_0x2ac62b);_0x383329=_0xdb6049['filter']['updateFullNode'](_0x48200c['eventCache']['getNode'](),_0x13efc4,_0x148c49);}else{const _0x307567=Cn(_0x1142bf,Ve(_0x48200c));_0x383329=_0xdb6049['filter']['updateFullNode'](_0x48200c['eventCache']['getNode'](),_0x307567,_0x148c49);}}else{const _0x34a99c=y(_0x18de51);if(_0x34a99c==='.priority'){f(Ce(_0x18de51)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x271595=_0x42cae1['getNode']();_0x5a0d1=_0x48200c['serverCache']['getNode']();const _0x44d7a5=cr(_0x1142bf,_0x18de51,_0x271595,_0x5a0d1);_0x44d7a5!=null?_0x383329=_0xdb6049['filter']['updatePriority'](_0x271595,_0x44d7a5):_0x383329=_0x42cae1['getNode']();}else{const _0x6e6982=S(_0x18de51);let _0x50f05f;if(_0x42cae1['isCompleteForChild'](_0x34a99c)){_0x5a0d1=_0x48200c['serverCache']['getNode']();const _0x2db016=cr(_0x1142bf,_0x18de51,_0x42cae1['getNode'](),_0x5a0d1);_0x2db016!=null?_0x50f05f=_0x42cae1['getNode']()['getImmediateChild'](_0x34a99c)['updateChild'](_0x6e6982,_0x2db016):_0x50f05f=_0x42cae1['getNode']()['getImmediateChild'](_0x34a99c);}else _0x50f05f=ss(_0x1142bf,_0x34a99c,_0x48200c['serverCache']);_0x50f05f!=null?_0x383329=_0xdb6049['filter']['updateChild'](_0x42cae1['getNode'](),_0x34a99c,_0x50f05f,_0x6e6982,_0x428427,_0x148c49):_0x383329=_0x42cae1['getNode']();}}return Rt(_0x48200c,_0x383329,_0x42cae1['isFullyInitialized']()||v(_0x18de51),_0xdb6049['filter']['filtersNodes']());}}function Sn(_0x1e3512,_0x261c22,_0x3f1e5a,_0x5c5655,_0x59c749,_0x5a5516,_0x227af6,_0x2940a7){const _0x182042=_0x261c22['serverCache'];let _0x1231ad;const _0x35cecb=_0x227af6?_0x1e3512['filter']:_0x1e3512['filter']['getIndexedFilter']();if(v(_0x3f1e5a))_0x1231ad=_0x35cecb['updateFullNode'](_0x182042['getNode'](),_0x5c5655,null);else{if(_0x35cecb['filtersNodes']()&&!_0x182042['isFiltered']()){const _0x5689b3=_0x182042['getNode']()['updateChild'](_0x3f1e5a,_0x5c5655);_0x1231ad=_0x35cecb['updateFullNode'](_0x182042['getNode'](),_0x5689b3,null);}else{const _0x111fe1=y(_0x3f1e5a);if(!_0x182042['isCompleteForPath'](_0x3f1e5a)&&Ce(_0x3f1e5a)>0x1)return _0x261c22;const _0x654aca=S(_0x3f1e5a),_0x260f80=_0x182042['getNode']()['getImmediateChild'](_0x111fe1)['updateChild'](_0x654aca,_0x5c5655);_0x111fe1==='.priority'?_0x1231ad=_0x35cecb['updatePriority'](_0x182042['getNode'](),_0x260f80):_0x1231ad=_0x35cecb['updateChild'](_0x182042['getNode'](),_0x111fe1,_0x260f80,_0x654aca,$o,null);}}const _0x53777d=Fo(_0x261c22,_0x1231ad,_0x182042['isFullyInitialized']()||v(_0x3f1e5a),_0x35cecb['filtersNodes']()),_0x166413=new rs(_0x59c749,_0x53777d,_0x5a5516);return Go(_0x1e3512,_0x53777d,_0x3f1e5a,_0x59c749,_0x166413,_0x2940a7);}function ki(_0x4a122e,_0x2ed070,_0x5d431f,_0x26b5c6,_0x5c6ad5,_0x3660a2,_0x30f658){const _0x276d25=_0x2ed070['eventCache'];let _0x29593a,_0x3bb88b;const _0x27b118=new rs(_0x5c6ad5,_0x2ed070,_0x3660a2);if(v(_0x5d431f))_0x3bb88b=_0x4a122e['filter']['updateFullNode'](_0x2ed070['eventCache']['getNode'](),_0x26b5c6,_0x30f658),_0x29593a=Rt(_0x2ed070,_0x3bb88b,!0x0,_0x4a122e['filter']['filtersNodes']());else{const _0x89abe6=y(_0x5d431f);if(_0x89abe6==='.priority')_0x3bb88b=_0x4a122e['filter']['updatePriority'](_0x2ed070['eventCache']['getNode'](),_0x26b5c6),_0x29593a=Rt(_0x2ed070,_0x3bb88b,_0x276d25['isFullyInitialized'](),_0x276d25['isFiltered']());else{const _0x4de7f8=S(_0x5d431f),_0x190be9=_0x276d25['getNode']()['getImmediateChild'](_0x89abe6);let _0x3778a6;if(v(_0x4de7f8))_0x3778a6=_0x26b5c6;else{const _0x5166e5=_0x27b118['getCompleteChild'](_0x89abe6);_0x5166e5!=null?ji(_0x4de7f8)==='.priority'&&_0x5166e5['getChild'](Ro(_0x4de7f8))['isEmpty']()?_0x3778a6=_0x5166e5:_0x3778a6=_0x5166e5['updateChild'](_0x4de7f8,_0x26b5c6):_0x3778a6=g['EMPTY_NODE'];}if(_0x190be9['equals'](_0x3778a6))_0x29593a=_0x2ed070;else{const _0x23a0d5=_0x4a122e['filter']['updateChild'](_0x276d25['getNode'](),_0x89abe6,_0x3778a6,_0x4de7f8,_0x27b118,_0x30f658);_0x29593a=Rt(_0x2ed070,_0x23a0d5,_0x276d25['isFullyInitialized'](),_0x4a122e['filter']['filtersNodes']());}}}return _0x29593a;}function lr(_0xc00570,_0x460d91){return _0xc00570['eventCache']['isCompleteForChild'](_0x460d91);}function ku(_0x1f76f5,_0x142214,_0x145ddc,_0x279fcb,_0x5f383c,_0x2de0f3,_0x5ccc39){let _0x3d2019=_0x142214;return _0x279fcb['foreach']((_0x1a338f,_0x5d229d)=>{const _0x3d6466=k(_0x145ddc,_0x1a338f);lr(_0x142214,y(_0x3d6466))&&(_0x3d2019=ki(_0x1f76f5,_0x3d2019,_0x3d6466,_0x5d229d,_0x5f383c,_0x2de0f3,_0x5ccc39));}),_0x279fcb['foreach']((_0x51c1a0,_0x235876)=>{const _0x1ca689=k(_0x145ddc,_0x51c1a0);lr(_0x142214,y(_0x1ca689))||(_0x3d2019=ki(_0x1f76f5,_0x3d2019,_0x1ca689,_0x235876,_0x5f383c,_0x2de0f3,_0x5ccc39));}),_0x3d2019;}function hr(_0xae59bb,_0x180b47,_0x11bb61){return _0x11bb61['foreach']((_0x20d1db,_0x54acb3)=>{_0x180b47=_0x180b47['updateChild'](_0x20d1db,_0x54acb3);}),_0x180b47;}function Pi(_0x2def67,_0x2d5828,_0x384919,_0x33910d,_0x2b3c34,_0x289687,_0x6a2882,_0x4ca82a){if(_0x2d5828['serverCache']['getNode']()['isEmpty']()&&!_0x2d5828['serverCache']['isFullyInitialized']())return _0x2d5828;let _0x126deb=_0x2d5828,_0x44a1cd;v(_0x384919)?_0x44a1cd=_0x33910d:_0x44a1cd=new b(null)['setTree'](_0x384919,_0x33910d);const _0x22e8cf=_0x2d5828['serverCache']['getNode']();return _0x44a1cd['children']['inorderTraversal']((_0x1cfc0a,_0x31d8c6)=>{if(_0x22e8cf['hasChild'](_0x1cfc0a)){const _0x28695b=_0x2d5828['serverCache']['getNode']()['getImmediateChild'](_0x1cfc0a),_0x2efafa=hr(_0x2def67,_0x28695b,_0x31d8c6);_0x126deb=Sn(_0x2def67,_0x126deb,new C(_0x1cfc0a),_0x2efafa,_0x2b3c34,_0x289687,_0x6a2882,_0x4ca82a);}}),_0x44a1cd['children']['inorderTraversal']((_0x528fa1,_0x388a13)=>{const _0x1b115a=!_0x2d5828['serverCache']['isCompleteForChild'](_0x528fa1)&&_0x388a13['value']===null;if(!_0x22e8cf['hasChild'](_0x528fa1)&&!_0x1b115a){const _0x41ea16=_0x2d5828['serverCache']['getNode']()['getImmediateChild'](_0x528fa1),_0x96428d=hr(_0x2def67,_0x41ea16,_0x388a13);_0x126deb=Sn(_0x2def67,_0x126deb,new C(_0x528fa1),_0x96428d,_0x2b3c34,_0x289687,_0x6a2882,_0x4ca82a);}}),_0x126deb;}function Pu(_0x564d93,_0x15ae9f,_0x44b12c,_0x481553,_0x3d2f21,_0x578409,_0x4cede2){if(Tn(_0x3d2f21,_0x44b12c)!=null)return _0x15ae9f;const _0x154b81=_0x15ae9f['serverCache']['isFiltered'](),_0x9ebf1d=_0x15ae9f['serverCache'];if(_0x481553['value']!=null){if(v(_0x44b12c)&&_0x9ebf1d['isFullyInitialized']()||_0x9ebf1d['isCompleteForPath'](_0x44b12c))return Sn(_0x564d93,_0x15ae9f,_0x44b12c,_0x9ebf1d['getNode']()['getChild'](_0x44b12c),_0x3d2f21,_0x578409,_0x154b81,_0x4cede2);if(v(_0x44b12c)){let _0x534422=new b(null);return _0x9ebf1d['getNode']()['forEachChild'](ve,(_0x22e274,_0x5effd0)=>{_0x534422=_0x534422['set'](new C(_0x22e274),_0x5effd0);}),Pi(_0x564d93,_0x15ae9f,_0x44b12c,_0x534422,_0x3d2f21,_0x578409,_0x154b81,_0x4cede2);}else return _0x15ae9f;}else{let _0x3412dc=new b(null);return _0x481553['foreach']((_0x46418a,_0x41c56d)=>{const _0x4fce83=k(_0x44b12c,_0x46418a);_0x9ebf1d['isCompleteForPath'](_0x4fce83)&&(_0x3412dc=_0x3412dc['set'](_0x46418a,_0x9ebf1d['getNode']()['getChild'](_0x4fce83)));}),Pi(_0x564d93,_0x15ae9f,_0x44b12c,_0x3412dc,_0x3d2f21,_0x578409,_0x154b81,_0x4cede2);}}function Nu(_0x2b6b35,_0x965ac5,_0x2e6a1d,_0x1feb1b,_0x2b277e){const _0x341ab4=_0x965ac5['serverCache'],_0x3bbed3=Fo(_0x965ac5,_0x341ab4['getNode'](),_0x341ab4['isFullyInitialized']()||v(_0x2e6a1d),_0x341ab4['isFiltered']());return Go(_0x2b6b35,_0x3bbed3,_0x2e6a1d,_0x1feb1b,$o,_0x2b277e);}function Ou(_0xb2feed,_0x10ac76,_0x227e8d,_0x19a443,_0x44fbfb,_0x44618c){let _0x53e339;if(Tn(_0x19a443,_0x227e8d)!=null)return _0x10ac76;{const _0x2916a4=new rs(_0x19a443,_0x10ac76,_0x44fbfb),_0x5da6ef=_0x10ac76['eventCache']['getNode']();let _0x572836;if(v(_0x227e8d)||y(_0x227e8d)==='.priority'){let _0x279f85;if(_0x10ac76['serverCache']['isFullyInitialized']())_0x279f85=Cn(_0x19a443,Ve(_0x10ac76));else{const _0x25ca1e=_0x10ac76['serverCache']['getNode']();f(_0x25ca1e instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x279f85=is(_0x19a443,_0x25ca1e);}_0x279f85=_0x279f85,_0x572836=_0xb2feed['filter']['updateFullNode'](_0x5da6ef,_0x279f85,_0x44618c);}else{const _0x33a0d9=y(_0x227e8d);let _0x24dfd3=ss(_0x19a443,_0x33a0d9,_0x10ac76['serverCache']);_0x24dfd3==null&&_0x10ac76['serverCache']['isCompleteForChild'](_0x33a0d9)&&(_0x24dfd3=_0x5da6ef['getImmediateChild'](_0x33a0d9)),_0x24dfd3!=null?_0x572836=_0xb2feed['filter']['updateChild'](_0x5da6ef,_0x33a0d9,_0x24dfd3,S(_0x227e8d),_0x2916a4,_0x44618c):_0x10ac76['eventCache']['getNode']()['hasChild'](_0x33a0d9)?_0x572836=_0xb2feed['filter']['updateChild'](_0x5da6ef,_0x33a0d9,g['EMPTY_NODE'],S(_0x227e8d),_0x2916a4,_0x44618c):_0x572836=_0x5da6ef,_0x572836['isEmpty']()&&_0x10ac76['serverCache']['isFullyInitialized']()&&(_0x53e339=Cn(_0x19a443,Ve(_0x10ac76)),_0x53e339['isLeafNode']()&&(_0x572836=_0xb2feed['filter']['updateFullNode'](_0x572836,_0x53e339,_0x44618c)));}return _0x53e339=_0x10ac76['serverCache']['isFullyInitialized']()||Tn(_0x19a443,w())!=null,Rt(_0x10ac76,_0x572836,_0x53e339,_0xb2feed['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3b4617,_0x183fa2){this['query_']=_0x3b4617,this['eventRegistrations_']=[];const _0x1f243d=this['query_']['_queryParams'],_0x2d59db=new Xi(_0x1f243d['getIndex']()),_0x20faae=Kh(_0x1f243d);this['processor_']=Su(_0x20faae);const _0x4e2e41=_0x183fa2['serverCache'],_0x552e89=_0x183fa2['eventCache'],_0x30919e=_0x2d59db['updateFullNode'](g['EMPTY_NODE'],_0x4e2e41['getNode'](),null),_0x3ba4c2=_0x20faae['updateFullNode'](g['EMPTY_NODE'],_0x552e89['getNode'](),null),_0x258ebc=new Te(_0x30919e,_0x4e2e41['isFullyInitialized'](),_0x2d59db['filtersNodes']()),_0x2ad276=new Te(_0x3ba4c2,_0x552e89['isFullyInitialized'](),_0x20faae['filtersNodes']());this['viewCache_']=Un(_0x2ad276,_0x258ebc),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x24e4db){return _0x24e4db['viewCache_']['serverCache']['getNode']();}function Lu(_0x228b93){return wn(_0x228b93['viewCache_']);}function xu(_0x1f1204,_0x57ebb6){const _0x3c4cdc=Ve(_0x1f1204['viewCache_']);return _0x3c4cdc&&(_0x1f1204['query']['_queryParams']['loadsAllData']()||!v(_0x57ebb6)&&!_0x3c4cdc['getImmediateChild'](y(_0x57ebb6))['isEmpty']())?_0x3c4cdc['getChild'](_0x57ebb6):null;}function ur(_0x2a23a6){return _0x2a23a6['eventRegistrations_']['length']===0x0;}function Fu(_0x4db8e3,_0x1525a3){_0x4db8e3['eventRegistrations_']['push'](_0x1525a3);}function dr(_0x1c51e4,_0x5c8416,_0x478a45){const _0x615ae5=[];if(_0x478a45){f(_0x5c8416==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3ac8d3=_0x1c51e4['query']['_path'];_0x1c51e4['eventRegistrations_']['forEach'](_0x24a8cb=>{const _0x5d076a=_0x24a8cb['createCancelEvent'](_0x478a45,_0x3ac8d3);_0x5d076a&&_0x615ae5['push'](_0x5d076a);});}if(_0x5c8416){let _0x414d32=[];for(let _0x176c4e=0x0;_0x176c4e<_0x1c51e4['eventRegistrations_']['length'];++_0x176c4e){const _0x23f066=_0x1c51e4['eventRegistrations_'][_0x176c4e];if(!_0x23f066['matches'](_0x5c8416))_0x414d32['push'](_0x23f066);else{if(_0x5c8416['hasAnyCallback']()){_0x414d32=_0x414d32['concat'](_0x1c51e4['eventRegistrations_']['slice'](_0x176c4e+0x1));break;}}}_0x1c51e4['eventRegistrations_']=_0x414d32;}else _0x1c51e4['eventRegistrations_']=[];return _0x615ae5;}function fr(_0x1343f7,_0x4b0987,_0xa73bf0,_0x43ffc6){_0x4b0987['type']===z['MERGE']&&_0x4b0987['source']['queryId']!==null&&(f(Ve(_0x1343f7['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x1343f7['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1acabe=_0x1343f7['viewCache_'],_0x2a8e93=Ru(_0x1343f7['processor_'],_0x1acabe,_0x4b0987,_0xa73bf0,_0x43ffc6);return bu(_0x1343f7['processor_'],_0x2a8e93['viewCache']),f(_0x2a8e93['viewCache']['serverCache']['isFullyInitialized']()||!_0x1acabe['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1343f7['viewCache_']=_0x2a8e93['viewCache'],qo(_0x1343f7,_0x2a8e93['changes'],_0x2a8e93['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5cc9f4,_0x1acd6a){const _0x4f1948=_0x5cc9f4['viewCache_']['eventCache'],_0x3a217f=[];return _0x4f1948['getNode']()['isLeafNode']()||_0x4f1948['getNode']()['forEachChild'](R,(_0x4c5f1e,_0x167424)=>{_0x3a217f['push'](rt(_0x4c5f1e,_0x167424));}),_0x4f1948['isFullyInitialized']()&&_0x3a217f['push'](Lo(_0x4f1948['getNode']())),qo(_0x5cc9f4,_0x3a217f,_0x4f1948['getNode'](),_0x1acd6a);}function qo(_0x21212c,_0x992b5b,_0x2fc701,_0x47729){const _0x552667=_0x47729?[_0x47729]:_0x21212c['eventRegistrations_'];return ru(_0x21212c['eventGenerator_'],_0x992b5b,_0x2fc701,_0x552667);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x64ab85){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x64ab85;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x10d739){return _0x10d739['views']['size']===0x0;}function os(_0x1d3d4f,_0x3d95ca,_0x5afe7e,_0x5c05f3){const _0x4230f0=_0x3d95ca['source']['queryId'];if(_0x4230f0!==null){const _0x105457=_0x1d3d4f['views']['get'](_0x4230f0);return f(_0x105457!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x105457,_0x3d95ca,_0x5afe7e,_0x5c05f3);}else{let _0x3e6f36=[];for(const _0x2f7a6d of _0x1d3d4f['views']['values']())_0x3e6f36=_0x3e6f36['concat'](fr(_0x2f7a6d,_0x3d95ca,_0x5afe7e,_0x5c05f3));return _0x3e6f36;}}function jo(_0x26a3d7,_0x5add3b,_0x1384c0,_0x1f4d97,_0x3064ee){const _0xa5770b=_0x5add3b['_queryIdentifier'],_0x1a8a92=_0x26a3d7['views']['get'](_0xa5770b);if(!_0x1a8a92){let _0x350c3b=Cn(_0x1384c0,_0x3064ee?_0x1f4d97:null),_0x2727a3=!0x1;_0x350c3b?_0x2727a3=!0x0:_0x1f4d97 instanceof g?(_0x350c3b=is(_0x1384c0,_0x1f4d97),_0x2727a3=!0x1):(_0x350c3b=g['EMPTY_NODE'],_0x2727a3=!0x1);const _0x295790=Un(new Te(_0x350c3b,_0x2727a3,!0x1),new Te(_0x1f4d97,_0x3064ee,!0x1));return new Du(_0x5add3b,_0x295790);}return _0x1a8a92;}function Hu(_0x47f717,_0x2542c5,_0x32689e,_0x3dff6e,_0x2e08b0,_0x49ce4d){const _0x57e033=jo(_0x47f717,_0x2542c5,_0x3dff6e,_0x2e08b0,_0x49ce4d);return _0x47f717['views']['has'](_0x2542c5['_queryIdentifier'])||_0x47f717['views']['set'](_0x2542c5['_queryIdentifier'],_0x57e033),Fu(_0x57e033,_0x32689e),Uu(_0x57e033,_0x32689e);}function $u(_0x3ddbfb,_0x1d49de,_0x44d4f4,_0x200235){const _0x29a387=_0x1d49de['_queryIdentifier'],_0x39b82d=[];let _0x78d1df=[];const _0x450fd1=Se(_0x3ddbfb);if(_0x29a387==='default'){for(const [_0x5710d1,_0x4681d4]of _0x3ddbfb['views']['entries']())_0x78d1df=_0x78d1df['concat'](dr(_0x4681d4,_0x44d4f4,_0x200235)),ur(_0x4681d4)&&(_0x3ddbfb['views']['delete'](_0x5710d1),_0x4681d4['query']['_queryParams']['loadsAllData']()||_0x39b82d['push'](_0x4681d4['query']));}else{const _0x3d1feb=_0x3ddbfb['views']['get'](_0x29a387);_0x3d1feb&&(_0x78d1df=_0x78d1df['concat'](dr(_0x3d1feb,_0x44d4f4,_0x200235)),ur(_0x3d1feb)&&(_0x3ddbfb['views']['delete'](_0x29a387),_0x3d1feb['query']['_queryParams']['loadsAllData']()||_0x39b82d['push'](_0x3d1feb['query'])));}return _0x450fd1&&!Se(_0x3ddbfb)&&_0x39b82d['push'](new(Bu())(_0x1d49de['_repo'],_0x1d49de['_path'])),{'removed':_0x39b82d,'events':_0x78d1df};}function Ko(_0x1a3588){const _0xa4510d=[];for(const _0x332b87 of _0x1a3588['views']['values']())_0x332b87['query']['_queryParams']['loadsAllData']()||_0xa4510d['push'](_0x332b87);return _0xa4510d;}function Ie(_0x281829,_0x5db592){let _0x5ee565=null;for(const _0x5672b1 of _0x281829['views']['values']())_0x5ee565=_0x5ee565||xu(_0x5672b1,_0x5db592);return _0x5ee565;}function Yo(_0x2669b4,_0x1459c2){if(_0x1459c2['_queryParams']['loadsAllData']())return Bn(_0x2669b4);{const _0x18156f=_0x1459c2['_queryIdentifier'];return _0x2669b4['views']['get'](_0x18156f);}}function Qo(_0x19c09d,_0x187252){return Yo(_0x19c09d,_0x187252)!=null;}function Se(_0x4c187e){return Bn(_0x4c187e)!=null;}function Bn(_0x440c07){for(const _0x1f5acf of _0x440c07['views']['values']())if(_0x1f5acf['query']['_queryParams']['loadsAllData']())return _0x1f5acf;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xe472ec){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xe472ec;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x296102){this['listenProvider_']=_0x296102,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x5e4934,_0x12b6d0,_0x13ba22,_0x110fe4,_0x3bd592){return lu(_0x5e4934['pendingWriteTree_'],_0x12b6d0,_0x13ba22,_0x110fe4,_0x3bd592),_0x3bd592?_t(_0x5e4934,new Be(es(),_0x12b6d0,_0x13ba22)):[];}function ju(_0x2dd3d5,_0x584791,_0x185b59,_0x5588e6){hu(_0x2dd3d5['pendingWriteTree_'],_0x584791,_0x185b59,_0x5588e6);const _0x202528=b['fromObject'](_0x185b59);return _t(_0x2dd3d5,new ot(es(),_0x584791,_0x202528));}function _e(_0x14e0ab,_0x3191cf,_0x458c5d=!0x1){const _0x392740=uu(_0x14e0ab['pendingWriteTree_'],_0x3191cf);if(du(_0x14e0ab['pendingWriteTree_'],_0x3191cf)){let _0x3f414d=new b(null);return _0x392740['snap']!=null?_0x3f414d=_0x3f414d['set'](w(),!0x0):x(_0x392740['children'],_0x54e840=>{_0x3f414d=_0x3f414d['set'](new C(_0x54e840),!0x0);}),_t(_0x14e0ab,new In(_0x392740['path'],_0x3f414d,_0x458c5d));}else return[];}function Yt(_0x2c0783,_0x1618b0,_0x344412){return _t(_0x2c0783,new Be(ts(),_0x1618b0,_0x344412));}function Ku(_0x444e3d,_0x214db9,_0x5bb4c8){const _0x5dc5c2=b['fromObject'](_0x5bb4c8);return _t(_0x444e3d,new ot(ts(),_0x214db9,_0x5dc5c2));}function Yu(_0x4158c4,_0x6841b8){return _t(_0x4158c4,new Ut(ts(),_0x6841b8));}function Qu(_0x545c87,_0x2de09f,_0x4f719c){const _0x1a6994=cs(_0x545c87,_0x4f719c);if(_0x1a6994){const _0x3022c1=ls(_0x1a6994),_0x198394=_0x3022c1['path'],_0x1c3134=_0x3022c1['queryId'],_0x1f73b9=F(_0x198394,_0x2de09f),_0x3e6536=new Ut(ns(_0x1c3134),_0x1f73b9);return hs(_0x545c87,_0x198394,_0x3e6536);}else return[];}function An(_0x5ad345,_0x57accb,_0x36b20c,_0x4999c1,_0x2e34b6=!0x1){const _0x23145d=_0x57accb['_path'],_0x5a45e2=_0x5ad345['syncPointTree_']['get'](_0x23145d);let _0x3a390f=[];if(_0x5a45e2&&(_0x57accb['_queryIdentifier']==='default'||Qo(_0x5a45e2,_0x57accb))){const _0x39dded=$u(_0x5a45e2,_0x57accb,_0x36b20c,_0x4999c1);Vu(_0x5a45e2)&&(_0x5ad345['syncPointTree_']=_0x5ad345['syncPointTree_']['remove'](_0x23145d));const _0x26ad8=_0x39dded['removed'];if(_0x3a390f=_0x39dded['events'],!_0x2e34b6){const _0xb3d50b=_0x26ad8['findIndex'](_0x1e552d=>_0x1e552d['_queryParams']['loadsAllData']())!==-0x1,_0x35c984=_0x5ad345['syncPointTree_']['findOnPath'](_0x23145d,(_0x46d9ff,_0x5d0203)=>Se(_0x5d0203));if(_0xb3d50b&&!_0x35c984){const _0xb13cdb=_0x5ad345['syncPointTree_']['subtree'](_0x23145d);if(!_0xb13cdb['isEmpty']()){const _0x42bf57=Zu(_0xb13cdb);for(let _0x32b34d=0x0;_0x32b34d<_0x42bf57['length'];++_0x32b34d){const _0x16a027=_0x42bf57[_0x32b34d],_0xe10696=_0x16a027['query'],_0xc8b355=ea(_0x5ad345,_0x16a027);_0x5ad345['listenProvider_']['startListening'](kt(_0xe10696),Wt(_0x5ad345,_0xe10696),_0xc8b355['hashFn'],_0xc8b355['onComplete']);}}}!_0x35c984&&_0x26ad8['length']>0x0&&!_0x4999c1&&(_0xb3d50b?_0x5ad345['listenProvider_']['stopListening'](kt(_0x57accb),null):_0x26ad8['forEach'](_0x5176d7=>{const _0x2bf774=_0x5ad345['queryToTagMap']['get'](Hn(_0x5176d7));_0x5ad345['listenProvider_']['stopListening'](kt(_0x5176d7),_0x2bf774);}));}ed(_0x5ad345,_0x26ad8);}return _0x3a390f;}function Jo(_0x144b54,_0x18ceed,_0x15487f,_0x492f51){const _0x47fcd0=cs(_0x144b54,_0x492f51);if(_0x47fcd0!=null){const _0x3951c2=ls(_0x47fcd0),_0xc241f7=_0x3951c2['path'],_0x45044f=_0x3951c2['queryId'],_0x1e27ab=F(_0xc241f7,_0x18ceed),_0x2b9669=new Be(ns(_0x45044f),_0x1e27ab,_0x15487f);return hs(_0x144b54,_0xc241f7,_0x2b9669);}else return[];}function Ju(_0x4c7f95,_0x4a9b3c,_0x240720,_0x4c1bdd){const _0x305ddb=cs(_0x4c7f95,_0x4c1bdd);if(_0x305ddb){const _0x245f2b=ls(_0x305ddb),_0x88c17e=_0x245f2b['path'],_0x110dc5=_0x245f2b['queryId'],_0x1c94ef=F(_0x88c17e,_0x4a9b3c),_0x2f4145=b['fromObject'](_0x240720),_0x46d607=new ot(ns(_0x110dc5),_0x1c94ef,_0x2f4145);return hs(_0x4c7f95,_0x88c17e,_0x46d607);}else return[];}function Ni(_0x2d7206,_0x4c37a9,_0x112206,_0x3d15c9=!0x1){const _0x716400=_0x4c37a9['_path'];let _0x1b2d26=null,_0x39c8b4=!0x1;_0x2d7206['syncPointTree_']['foreachOnPath'](_0x716400,(_0x376ca8,_0x4ece27)=>{const _0x5512e2=F(_0x376ca8,_0x716400);_0x1b2d26=_0x1b2d26||Ie(_0x4ece27,_0x5512e2),_0x39c8b4=_0x39c8b4||Se(_0x4ece27);});let _0x5e396a=_0x2d7206['syncPointTree_']['get'](_0x716400);_0x5e396a?(_0x39c8b4=_0x39c8b4||Se(_0x5e396a),_0x1b2d26=_0x1b2d26||Ie(_0x5e396a,w())):(_0x5e396a=new zo(),_0x2d7206['syncPointTree_']=_0x2d7206['syncPointTree_']['set'](_0x716400,_0x5e396a));let _0x1dc2d3;_0x1b2d26!=null?_0x1dc2d3=!0x0:(_0x1dc2d3=!0x1,_0x1b2d26=g['EMPTY_NODE'],_0x2d7206['syncPointTree_']['subtree'](_0x716400)['foreachChild']((_0x1d6097,_0x33787b)=>{const _0x1a3bd2=Ie(_0x33787b,w());_0x1a3bd2&&(_0x1b2d26=_0x1b2d26['updateImmediateChild'](_0x1d6097,_0x1a3bd2));}));const _0x1523c9=Qo(_0x5e396a,_0x4c37a9);if(!_0x1523c9&&!_0x4c37a9['_queryParams']['loadsAllData']()){const _0x44253b=Hn(_0x4c37a9);f(!_0x2d7206['queryToTagMap']['has'](_0x44253b),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1293ad=td();_0x2d7206['queryToTagMap']['set'](_0x44253b,_0x1293ad),_0x2d7206['tagToQueryMap']['set'](_0x1293ad,_0x44253b);}const _0x248de2=Wn(_0x2d7206['pendingWriteTree_'],_0x716400);let _0x4443d7=Hu(_0x5e396a,_0x4c37a9,_0x112206,_0x248de2,_0x1b2d26,_0x1dc2d3);if(!_0x1523c9&&!_0x39c8b4&&!_0x3d15c9){const _0x4bf7c1=Yo(_0x5e396a,_0x4c37a9);_0x4443d7=_0x4443d7['concat'](nd(_0x2d7206,_0x4c37a9,_0x4bf7c1));}return _0x4443d7;}function Vn(_0x157de9,_0x3945cc,_0x2d11a2){const _0x38d7c3=_0x157de9['pendingWriteTree_'],_0x54ce49=_0x157de9['syncPointTree_']['findOnPath'](_0x3945cc,(_0x12d8d5,_0x43af74)=>{const _0x42b08a=F(_0x12d8d5,_0x3945cc),_0x4eca7a=Ie(_0x43af74,_0x42b08a);if(_0x4eca7a)return _0x4eca7a;});return Bo(_0x38d7c3,_0x3945cc,_0x54ce49,_0x2d11a2,!0x0);}function Xu(_0x15d556,_0x34394d){const _0x6ba0fc=_0x34394d['_path'];let _0x50ed3c=null;_0x15d556['syncPointTree_']['foreachOnPath'](_0x6ba0fc,(_0x1a2a36,_0x2b30e1)=>{const _0x2c9560=F(_0x1a2a36,_0x6ba0fc);_0x50ed3c=_0x50ed3c||Ie(_0x2b30e1,_0x2c9560);});let _0x5ac968=_0x15d556['syncPointTree_']['get'](_0x6ba0fc);_0x5ac968?_0x50ed3c=_0x50ed3c||Ie(_0x5ac968,w()):(_0x5ac968=new zo(),_0x15d556['syncPointTree_']=_0x15d556['syncPointTree_']['set'](_0x6ba0fc,_0x5ac968));const _0xf165e7=_0x50ed3c!=null,_0xce7b86=_0xf165e7?new Te(_0x50ed3c,!0x0,!0x1):null,_0x3560c6=Wn(_0x15d556['pendingWriteTree_'],_0x34394d['_path']),_0x4e9cbf=jo(_0x5ac968,_0x34394d,_0x3560c6,_0xf165e7?_0xce7b86['getNode']():g['EMPTY_NODE'],_0xf165e7);return Lu(_0x4e9cbf);}function _t(_0x3eb738,_0xa3a41){return Xo(_0xa3a41,_0x3eb738['syncPointTree_'],null,Wn(_0x3eb738['pendingWriteTree_'],w()));}function Xo(_0x30e301,_0x32074d,_0x799591,_0x785b03){if(v(_0x30e301['path']))return Zo(_0x30e301,_0x32074d,_0x799591,_0x785b03);{const _0x3fc15a=_0x32074d['get'](w());_0x799591==null&&_0x3fc15a!=null&&(_0x799591=Ie(_0x3fc15a,w()));let _0x1a7b9c=[];const _0x31279f=y(_0x30e301['path']),_0x1bddf0=_0x30e301['operationForChild'](_0x31279f),_0x1244fa=_0x32074d['children']['get'](_0x31279f);if(_0x1244fa&&_0x1bddf0){const _0x2b5bd8=_0x799591?_0x799591['getImmediateChild'](_0x31279f):null,_0x19a766=Vo(_0x785b03,_0x31279f);_0x1a7b9c=_0x1a7b9c['concat'](Xo(_0x1bddf0,_0x1244fa,_0x2b5bd8,_0x19a766));}return _0x3fc15a&&(_0x1a7b9c=_0x1a7b9c['concat'](os(_0x3fc15a,_0x30e301,_0x785b03,_0x799591))),_0x1a7b9c;}}function Zo(_0x179671,_0x81240f,_0x2daf8a,_0x3cf680){const _0x2e9910=_0x81240f['get'](w());_0x2daf8a==null&&_0x2e9910!=null&&(_0x2daf8a=Ie(_0x2e9910,w()));let _0x1d1167=[];return _0x81240f['children']['inorderTraversal']((_0xe41d23,_0x3a3f61)=>{const _0x5e329d=_0x2daf8a?_0x2daf8a['getImmediateChild'](_0xe41d23):null,_0x3e41f5=Vo(_0x3cf680,_0xe41d23),_0x7b1e6=_0x179671['operationForChild'](_0xe41d23);_0x7b1e6&&(_0x1d1167=_0x1d1167['concat'](Zo(_0x7b1e6,_0x3a3f61,_0x5e329d,_0x3e41f5)));}),_0x2e9910&&(_0x1d1167=_0x1d1167['concat'](os(_0x2e9910,_0x179671,_0x3cf680,_0x2daf8a))),_0x1d1167;}function ea(_0x51c69c,_0x526fc0){const _0x5eba72=_0x526fc0['query'],_0x1163e8=Wt(_0x51c69c,_0x5eba72);return{'hashFn':()=>(Mu(_0x526fc0)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x280e8e=>{if(_0x280e8e==='ok')return _0x1163e8?Qu(_0x51c69c,_0x5eba72['_path'],_0x1163e8):Yu(_0x51c69c,_0x5eba72['_path']);{const _0x12f077=Kl(_0x280e8e,_0x5eba72);return An(_0x51c69c,_0x5eba72,null,_0x12f077);}}};}function Wt(_0x3efbd7,_0x115bf7){const _0x43eb83=Hn(_0x115bf7);return _0x3efbd7['queryToTagMap']['get'](_0x43eb83);}function Hn(_0x5943bf){return _0x5943bf['_path']['toString']()+'$'+_0x5943bf['_queryIdentifier'];}function cs(_0x1e09d9,_0x3859d8){return _0x1e09d9['tagToQueryMap']['get'](_0x3859d8);}function ls(_0x189204){const _0x28b062=_0x189204['indexOf']('$');return f(_0x28b062!==-0x1&&_0x28b062<_0x189204['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x189204['substr'](_0x28b062+0x1),'path':new C(_0x189204['substr'](0x0,_0x28b062))};}function hs(_0x40a3f3,_0x31e919,_0x4ec4bc){const _0x3da7e9=_0x40a3f3['syncPointTree_']['get'](_0x31e919);f(_0x3da7e9,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2baa6f=Wn(_0x40a3f3['pendingWriteTree_'],_0x31e919);return os(_0x3da7e9,_0x4ec4bc,_0x2baa6f,null);}function Zu(_0x4a42a4){return _0x4a42a4['fold']((_0x382cd3,_0x566601,_0x377ab2)=>{if(_0x566601&&Se(_0x566601))return[Bn(_0x566601)];{let _0x3c69e0=[];return _0x566601&&(_0x3c69e0=Ko(_0x566601)),x(_0x377ab2,(_0x473a79,_0x5c8bd1)=>{_0x3c69e0=_0x3c69e0['concat'](_0x5c8bd1);}),_0x3c69e0;}});}function kt(_0x1a99fe){return _0x1a99fe['_queryParams']['loadsAllData']()&&!_0x1a99fe['_queryParams']['isDefault']()?new(qu())(_0x1a99fe['_repo'],_0x1a99fe['_path']):_0x1a99fe;}function ed(_0x4794d5,_0x1441df){for(let _0x30d12c=0x0;_0x30d12c<_0x1441df['length'];++_0x30d12c){const _0x27fbd7=_0x1441df[_0x30d12c];if(!_0x27fbd7['_queryParams']['loadsAllData']()){const _0xd5b5b3=Hn(_0x27fbd7),_0xcadff9=_0x4794d5['queryToTagMap']['get'](_0xd5b5b3);_0x4794d5['queryToTagMap']['delete'](_0xd5b5b3),_0x4794d5['tagToQueryMap']['delete'](_0xcadff9);}}}function td(){return zu++;}function nd(_0x1159be,_0x3273e4,_0x189721){const _0x4e35f6=_0x3273e4['_path'],_0x53034e=Wt(_0x1159be,_0x3273e4),_0x3c1bed=ea(_0x1159be,_0x189721),_0x45de72=_0x1159be['listenProvider_']['startListening'](kt(_0x3273e4),_0x53034e,_0x3c1bed['hashFn'],_0x3c1bed['onComplete']),_0x30858c=_0x1159be['syncPointTree_']['subtree'](_0x4e35f6);if(_0x53034e)f(!Se(_0x30858c['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x47d23b=_0x30858c['fold']((_0x11c96c,_0x25eafc,_0x3e0459)=>{if(!v(_0x11c96c)&&_0x25eafc&&Se(_0x25eafc))return[Bn(_0x25eafc)['query']];{let _0x20f063=[];return _0x25eafc&&(_0x20f063=_0x20f063['concat'](Ko(_0x25eafc)['map'](_0x58d968=>_0x58d968['query']))),x(_0x3e0459,(_0x5205df,_0x51fa7e)=>{_0x20f063=_0x20f063['concat'](_0x51fa7e);}),_0x20f063;}});for(let _0x2beadc=0x0;_0x2beadc<_0x47d23b['length'];++_0x2beadc){const _0x34d93b=_0x47d23b[_0x2beadc];_0x1159be['listenProvider_']['stopListening'](kt(_0x34d93b),Wt(_0x1159be,_0x34d93b));}}return _0x45de72;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x27f612){this['node_']=_0x27f612;}['getImmediateChild'](_0x531caa){const _0x4142ee=this['node_']['getImmediateChild'](_0x531caa);return new us(_0x4142ee);}['node'](){return this['node_'];}}class ds{constructor(_0x3da1fd,_0x20b9ab){this['syncTree_']=_0x3da1fd,this['path_']=_0x20b9ab;}['getImmediateChild'](_0xfc32ed){const _0x5144f1=k(this['path_'],_0xfc32ed);return new ds(this['syncTree_'],_0x5144f1);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0xe89f1c){return _0xe89f1c=_0xe89f1c||{},_0xe89f1c['timestamp']=_0xe89f1c['timestamp']||new Date()['getTime'](),_0xe89f1c;},_r=function(_0xc2b468,_0x1c26d5,_0x2ae009){if(!_0xc2b468||typeof _0xc2b468!='object')return _0xc2b468;if(f('.sv'in _0xc2b468,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xc2b468['.sv']=='string')return sd(_0xc2b468['.sv'],_0x1c26d5,_0x2ae009);if(typeof _0xc2b468['.sv']=='object')return rd(_0xc2b468['.sv'],_0x1c26d5);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xc2b468,null,0x2));},sd=function(_0x3016cc,_0x1127da,_0x4ee695){switch(_0x3016cc){case'timestamp':return _0x4ee695['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3016cc);}},rd=function(_0x5041ce,_0x220103,_0x1d56e7){_0x5041ce['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5041ce,null,0x2));const _0x13ac39=_0x5041ce['increment'];typeof _0x13ac39!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x13ac39);const _0xed6e87=_0x220103['node']();if(f(_0xed6e87!==null&&typeof _0xed6e87<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xed6e87['isLeafNode']())return _0x13ac39;const _0x2cafeb=_0xed6e87['getValue']();return typeof _0x2cafeb!='number'?_0x13ac39:_0x2cafeb+_0x13ac39;},ta=function(_0x506c3f,_0x3e9fde,_0x556252,_0x3c8713){return ps(_0x3e9fde,new ds(_0x556252,_0x506c3f),_0x3c8713);},fs=function(_0x22d816,_0x1e8ac1,_0xadfed8){return ps(_0x22d816,new us(_0x1e8ac1),_0xadfed8);};function ps(_0x105fa4,_0x497da9,_0x543926){const _0x54135e=_0x105fa4['getPriority']()['val'](),_0x5a6906=_r(_0x54135e,_0x497da9['getImmediateChild']('.priority'),_0x543926);let _0x16f73c;if(_0x105fa4['isLeafNode']()){const _0x2bd685=_0x105fa4,_0x7245d9=_r(_0x2bd685['getValue'](),_0x497da9,_0x543926);return _0x7245d9!==_0x2bd685['getValue']()||_0x5a6906!==_0x2bd685['getPriority']()['val']()?new D(_0x7245d9,A(_0x5a6906)):_0x105fa4;}else{const _0x1647e3=_0x105fa4;return _0x16f73c=_0x1647e3,_0x5a6906!==_0x1647e3['getPriority']()['val']()&&(_0x16f73c=_0x16f73c['updatePriority'](new D(_0x5a6906))),_0x1647e3['forEachChild'](R,(_0x5ce114,_0x1e7f95)=>{const _0xaa22a4=ps(_0x1e7f95,_0x497da9['getImmediateChild'](_0x5ce114),_0x543926);_0xaa22a4!==_0x1e7f95&&(_0x16f73c=_0x16f73c['updateImmediateChild'](_0x5ce114,_0xaa22a4));}),_0x16f73c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x270563='',_0x3221e3=null,_0x47d2ab={'children':{},'childCount':0x0}){this['name']=_0x270563,this['parent']=_0x3221e3,this['node']=_0x47d2ab;}}function $n(_0x3145fa,_0x1deef2){let _0x42de9f=_0x1deef2 instanceof C?_0x1deef2:new C(_0x1deef2),_0x2a532c=_0x3145fa,_0x1d2927=y(_0x42de9f);for(;_0x1d2927!==null;){const _0x36c0ea=Le(_0x2a532c['node']['children'],_0x1d2927)||{'children':{},'childCount':0x0};_0x2a532c=new _s(_0x1d2927,_0x2a532c,_0x36c0ea),_0x42de9f=S(_0x42de9f),_0x1d2927=y(_0x42de9f);}return _0x2a532c;}function je(_0x14e5c9){return _0x14e5c9['node']['value'];}function gs(_0x4a8eff,_0x5a7cc5){_0x4a8eff['node']['value']=_0x5a7cc5,Oi(_0x4a8eff);}function na(_0x262370){return _0x262370['node']['childCount']>0x0;}function od(_0x25178e){return je(_0x25178e)===void 0x0&&!na(_0x25178e);}function Gn(_0x23f8b4,_0x298286){x(_0x23f8b4['node']['children'],(_0x45d1cb,_0x58b455)=>{_0x298286(new _s(_0x45d1cb,_0x23f8b4,_0x58b455));});}function ia(_0x3996b6,_0x47968f,_0x4f21cc,_0x28ee69){_0x4f21cc&&_0x47968f(_0x3996b6),Gn(_0x3996b6,_0x1c423e=>{ia(_0x1c423e,_0x47968f,!0x0);});}function ad(_0x151dae,_0x581c43,_0x214c94){let _0x11f499=_0x151dae['parent'];for(;_0x11f499!==null;){if(_0x581c43(_0x11f499))return!0x0;_0x11f499=_0x11f499['parent'];}return!0x1;}function Qt(_0x3caba4){return new C(_0x3caba4['parent']===null?_0x3caba4['name']:Qt(_0x3caba4['parent'])+'/'+_0x3caba4['name']);}function Oi(_0x5e3f4a){_0x5e3f4a['parent']!==null&&cd(_0x5e3f4a['parent'],_0x5e3f4a['name'],_0x5e3f4a);}function cd(_0x33acc4,_0x3ff91d,_0x1f3f92){const _0x4516e5=od(_0x1f3f92),_0x5728df=Q(_0x33acc4['node']['children'],_0x3ff91d);_0x4516e5&&_0x5728df?(delete _0x33acc4['node']['children'][_0x3ff91d],_0x33acc4['node']['childCount']--,Oi(_0x33acc4)):!_0x4516e5&&!_0x5728df&&(_0x33acc4['node']['children'][_0x3ff91d]=_0x1f3f92['node'],_0x33acc4['node']['childCount']++,Oi(_0x33acc4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x48d4a3){return typeof _0x48d4a3=='string'&&_0x48d4a3['length']!==0x0&&!ld['test'](_0x48d4a3);},sa=function(_0x45c3f3){return typeof _0x45c3f3=='string'&&_0x45c3f3['length']!==0x0&&!hd['test'](_0x45c3f3);},ud=function(_0xa60628){return _0xa60628&&(_0xa60628=_0xa60628['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xa60628);},Bt=function(_0x4c5181){return _0x4c5181===null||typeof _0x4c5181=='string'||typeof _0x4c5181=='number'&&!xn(_0x4c5181)||_0x4c5181&&typeof _0x4c5181=='object'&&Q(_0x4c5181,'.sv');},He=function(_0x1d5739,_0xddeaae,_0x357ed1,_0x3371bf){_0x3371bf&&_0xddeaae===void 0x0||Jt(it(_0x1d5739,'value'),_0xddeaae,_0x357ed1);},Jt=function(_0x21cdc1,_0x34f59a,_0x1b0046){const _0x15f67c=_0x1b0046 instanceof C?new Ah(_0x1b0046,_0x21cdc1):_0x1b0046;if(_0x34f59a===void 0x0)throw new Error(_0x21cdc1+'contains\x20undefined\x20'+Oe(_0x15f67c));if(typeof _0x34f59a=='function')throw new Error(_0x21cdc1+'contains\x20a\x20function\x20'+Oe(_0x15f67c)+'\x20with\x20contents\x20=\x20'+_0x34f59a['toString']());if(xn(_0x34f59a))throw new Error(_0x21cdc1+'contains\x20'+_0x34f59a['toString']()+'\x20'+Oe(_0x15f67c));if(typeof _0x34f59a=='string'&&_0x34f59a['length']>ui/0x3&&Ln(_0x34f59a)>ui)throw new Error(_0x21cdc1+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x15f67c)+'\x20(\x27'+_0x34f59a['substring'](0x0,0x32)+'...\x27)');if(_0x34f59a&&typeof _0x34f59a=='object'){let _0x2225fb=!0x1,_0x1051ee=!0x1;if(x(_0x34f59a,(_0x1b08a1,_0x2e4412)=>{if(_0x1b08a1==='.value')_0x2225fb=!0x0;else{if(_0x1b08a1!=='.priority'&&_0x1b08a1!=='.sv'&&(_0x1051ee=!0x0,!ms(_0x1b08a1)))throw new Error(_0x21cdc1+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1b08a1+')\x20'+Oe(_0x15f67c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x15f67c,_0x1b08a1),Jt(_0x21cdc1,_0x2e4412,_0x15f67c),Ph(_0x15f67c);}),_0x2225fb&&_0x1051ee)throw new Error(_0x21cdc1+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x15f67c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4eb0d0,_0x4cc6f1){let _0x1d7e01,_0x309a13;for(_0x1d7e01=0x0;_0x1d7e01<_0x4cc6f1['length'];_0x1d7e01++){_0x309a13=_0x4cc6f1[_0x1d7e01];const _0x23192f=Mt(_0x309a13);for(let _0x193ef3=0x0;_0x193ef3<_0x23192f['length'];_0x193ef3++)if(!(_0x23192f[_0x193ef3]==='.priority'&&_0x193ef3===_0x23192f['length']-0x1)){if(!ms(_0x23192f[_0x193ef3]))throw new Error(_0x4eb0d0+'contains\x20an\x20invalid\x20key\x20('+_0x23192f[_0x193ef3]+')\x20in\x20path\x20'+_0x309a13['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4cc6f1['sort'](Rh);let _0x416662=null;for(_0x1d7e01=0x0;_0x1d7e01<_0x4cc6f1['length'];_0x1d7e01++){if(_0x309a13=_0x4cc6f1[_0x1d7e01],_0x416662!==null&&G(_0x416662,_0x309a13))throw new Error(_0x4eb0d0+'contains\x20a\x20path\x20'+_0x416662['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x309a13['toString']());_0x416662=_0x309a13;}},ra=function(_0x18fe3b,_0x3c6519,_0x3f0c93,_0x1f64ed){const _0x44fba1=it(_0x18fe3b,'values');if(!(_0x3c6519&&typeof _0x3c6519=='object')||Array['isArray'](_0x3c6519))throw new Error(_0x44fba1+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x58b00d=[];x(_0x3c6519,(_0x21b5ba,_0x3bf98a)=>{const _0x11b867=new C(_0x21b5ba);if(Jt(_0x44fba1,_0x3bf98a,k(_0x3f0c93,_0x11b867)),ji(_0x11b867)==='.priority'&&!Bt(_0x3bf98a))throw new Error(_0x44fba1+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x11b867['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x58b00d['push'](_0x11b867);}),dd(_0x44fba1,_0x58b00d);},fd=function(_0x705400,_0x5c2ec7,_0x250810){if(xn(_0x5c2ec7))throw new Error(it(_0x705400,'priority')+'is\x20'+_0x5c2ec7['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x5c2ec7))throw new Error(it(_0x705400,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x1e77a7,_0x2b7a35,_0x592522,_0x1f3651){if(!sa(_0x592522))throw new Error(it(_0x1e77a7,_0x2b7a35)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x592522+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4a46a3,_0x42816e,_0x34fcf4,_0xc16757){_0x34fcf4&&(_0x34fcf4=_0x34fcf4['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4a46a3,_0x42816e,_0x34fcf4);},Me=function(_0xcada2d,_0x50a2bd){if(y(_0x50a2bd)==='.info')throw new Error(_0xcada2d+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1bf247,_0x51cccf){const _0x2903c2=_0x51cccf['path']['toString']();if(typeof _0x51cccf['repoInfo']['host']!='string'||_0x51cccf['repoInfo']['host']['length']===0x0||!ms(_0x51cccf['repoInfo']['namespace'])&&_0x51cccf['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2903c2['length']!==0x0&&!ud(_0x2903c2))throw new Error(it(_0x1bf247,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x336f79,_0xc600f3){let _0x563e97=null;for(let _0x43fc61=0x0;_0x43fc61<_0xc600f3['length'];_0x43fc61++){const _0x2a176b=_0xc600f3[_0x43fc61],_0x423ad0=_0x2a176b['getPath']();_0x563e97!==null&&!Ki(_0x423ad0,_0x563e97['path'])&&(_0x336f79['eventLists_']['push'](_0x563e97),_0x563e97=null),_0x563e97===null&&(_0x563e97={'events':[],'path':_0x423ad0}),_0x563e97['events']['push'](_0x2a176b);}_0x563e97&&_0x336f79['eventLists_']['push'](_0x563e97);}function oa(_0x39d753,_0x22c743,_0x32c53a){qn(_0x39d753,_0x32c53a),aa(_0x39d753,_0x22a6ba=>Ki(_0x22a6ba,_0x22c743));}function V(_0x266c80,_0x56d0c7,_0x1ce532){qn(_0x266c80,_0x1ce532),aa(_0x266c80,_0x1b6f61=>G(_0x1b6f61,_0x56d0c7)||G(_0x56d0c7,_0x1b6f61));}function aa(_0x56e0da,_0x1cbe83){_0x56e0da['recursionDepth_']++;let _0x30f38b=!0x0;for(let _0x3c5b51=0x0;_0x3c5b51<_0x56e0da['eventLists_']['length'];_0x3c5b51++){const _0x2b44bb=_0x56e0da['eventLists_'][_0x3c5b51];if(_0x2b44bb){const _0x5becee=_0x2b44bb['path'];_0x1cbe83(_0x5becee)?(md(_0x56e0da['eventLists_'][_0x3c5b51]),_0x56e0da['eventLists_'][_0x3c5b51]=null):_0x30f38b=!0x1;}}_0x30f38b&&(_0x56e0da['eventLists_']=[]),_0x56e0da['recursionDepth_']--;}function md(_0x33e266){for(let _0x188a1c=0x0;_0x188a1c<_0x33e266['events']['length'];_0x188a1c++){const _0x1e3ae3=_0x33e266['events'][_0x188a1c];if(_0x1e3ae3!==null){_0x33e266['events'][_0x188a1c]=null;const _0x15ddac=_0x1e3ae3['getEventRunner']();St&&L('event:\x20'+_0x1e3ae3['toString']()),ft(_0x15ddac);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4859d1,_0x34cdbb,_0x3f998e,_0x411469){this['repoInfo_']=_0x4859d1,this['forceRestClient_']=_0x34cdbb,this['authTokenProvider_']=_0x3f998e,this['appCheckProvider_']=_0x411469,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2f3b82,_0x22ab5e,_0x1d16a2){if(_0x2f3b82['stats_']=qi(_0x2f3b82['repoInfo_']),_0x2f3b82['forceRestClient_']||Xl())_0x2f3b82['server_']=new vn(_0x2f3b82['repoInfo_'],(_0x3fb837,_0x31f858,_0x1a301f,_0x3a93bf)=>{gr(_0x2f3b82,_0x3fb837,_0x31f858,_0x1a301f,_0x3a93bf);},_0x2f3b82['authTokenProvider_'],_0x2f3b82['appCheckProvider_']),setTimeout(()=>mr(_0x2f3b82,!0x0),0x0);else{if(typeof _0x1d16a2<'u'&&_0x1d16a2!==null){if(typeof _0x1d16a2!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1d16a2);}catch(_0x26b496){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x26b496);}}_0x2f3b82['persistentConnection_']=new se(_0x2f3b82['repoInfo_'],_0x22ab5e,(_0x199cca,_0x107327,_0x2e9fd9,_0xde357e)=>{gr(_0x2f3b82,_0x199cca,_0x107327,_0x2e9fd9,_0xde357e);},_0x525460=>{mr(_0x2f3b82,_0x525460);},_0x1d073f=>{Id(_0x2f3b82,_0x1d073f);},_0x2f3b82['authTokenProvider_'],_0x2f3b82['appCheckProvider_'],_0x1d16a2),_0x2f3b82['server_']=_0x2f3b82['persistentConnection_'];}_0x2f3b82['authTokenProvider_']['addTokenChangeListener'](_0x2b13c5=>{_0x2f3b82['server_']['refreshAuthToken'](_0x2b13c5);}),_0x2f3b82['appCheckProvider_']['addTokenChangeListener'](_0x4bb21a=>{_0x2f3b82['server_']['refreshAppCheckToken'](_0x4bb21a['token']);}),_0x2f3b82['statsReporter_']=ih(_0x2f3b82['repoInfo_'],()=>new iu(_0x2f3b82['stats_'],_0x2f3b82['server_'])),_0x2f3b82['infoData_']=new Xh(),_0x2f3b82['infoSyncTree_']=new pr({'startListening':(_0x39180b,_0x3de6b3,_0x597378,_0x2e882e)=>{let _0x1892c1=[];const _0x15cce7=_0x2f3b82['infoData_']['getNode'](_0x39180b['_path']);return _0x15cce7['isEmpty']()||(_0x1892c1=Yt(_0x2f3b82['infoSyncTree_'],_0x39180b['_path'],_0x15cce7),setTimeout(()=>{_0x2e882e('ok');},0x0)),_0x1892c1;},'stopListening':()=>{}}),vs(_0x2f3b82,'connected',!0x1),_0x2f3b82['serverSyncTree_']=new pr({'startListening':(_0x7e79b,_0x14e3f3,_0x5d7f25,_0xfda3d8)=>(_0x2f3b82['server_']['listen'](_0x7e79b,_0x5d7f25,_0x14e3f3,(_0x23bb9a,_0x52a38d)=>{const _0x20e9b2=_0xfda3d8(_0x23bb9a,_0x52a38d);V(_0x2f3b82['eventQueue_'],_0x7e79b['_path'],_0x20e9b2);}),[]),'stopListening':(_0x4f5b08,_0x51ea79)=>{_0x2f3b82['server_']['unlisten'](_0x4f5b08,_0x51ea79);}});}function la(_0x121d4b){const _0x478cce=_0x121d4b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x478cce;}function Xt(_0x4189b5){return id({'timestamp':la(_0x4189b5)});}function gr(_0x1626f3,_0x5d1d62,_0x4cda51,_0x594e12,_0xbce997){_0x1626f3['dataUpdateCount']++;const _0x685473=new C(_0x5d1d62);_0x4cda51=_0x1626f3['interceptServerDataCallback_']?_0x1626f3['interceptServerDataCallback_'](_0x5d1d62,_0x4cda51):_0x4cda51;let _0x2c0c11=[];if(_0xbce997){if(_0x594e12){const _0x525440=_n(_0x4cda51,_0x4ba89b=>A(_0x4ba89b));_0x2c0c11=Ju(_0x1626f3['serverSyncTree_'],_0x685473,_0x525440,_0xbce997);}else{const _0x54c71e=A(_0x4cda51);_0x2c0c11=Jo(_0x1626f3['serverSyncTree_'],_0x685473,_0x54c71e,_0xbce997);}}else{if(_0x594e12){const _0x3dba2f=_n(_0x4cda51,_0x21a2e2=>A(_0x21a2e2));_0x2c0c11=Ku(_0x1626f3['serverSyncTree_'],_0x685473,_0x3dba2f);}else{const _0x24e2ea=A(_0x4cda51);_0x2c0c11=Yt(_0x1626f3['serverSyncTree_'],_0x685473,_0x24e2ea);}}let _0x4a9856=_0x685473;_0x2c0c11['length']>0x0&&(_0x4a9856=ct(_0x1626f3,_0x685473)),V(_0x1626f3['eventQueue_'],_0x4a9856,_0x2c0c11);}function mr(_0x1c6d51,_0xa5def9){vs(_0x1c6d51,'connected',_0xa5def9),_0xa5def9===!0x1&&Sd(_0x1c6d51);}function Id(_0x2c590c,_0x14e79b){x(_0x14e79b,(_0x53b5b7,_0x5ee997)=>{vs(_0x2c590c,_0x53b5b7,_0x5ee997);});}function vs(_0xaa0795,_0x123548,_0x215499){const _0x3a88d8=new C('/.info/'+_0x123548),_0x5b6d0b=A(_0x215499);_0xaa0795['infoData_']['updateSnapshot'](_0x3a88d8,_0x5b6d0b);const _0x586e6c=Yt(_0xaa0795['infoSyncTree_'],_0x3a88d8,_0x5b6d0b);V(_0xaa0795['eventQueue_'],_0x3a88d8,_0x586e6c);}function zn(_0x2f7c34){return _0x2f7c34['nextWriteId_']++;}function wd(_0x588c36,_0x554357,_0x5acd00){const _0x5ef083=Xu(_0x588c36['serverSyncTree_'],_0x554357);return _0x5ef083!=null?Promise['resolve'](_0x5ef083):_0x588c36['server_']['get'](_0x554357)['then'](_0x460a18=>{const _0x1ef854=A(_0x460a18)['withIndex'](_0x554357['_queryParams']['getIndex']());Ni(_0x588c36['serverSyncTree_'],_0x554357,_0x5acd00,!0x0);let _0x568e94;if(_0x554357['_queryParams']['loadsAllData']())_0x568e94=Yt(_0x588c36['serverSyncTree_'],_0x554357['_path'],_0x1ef854);else{const _0xa2099=Wt(_0x588c36['serverSyncTree_'],_0x554357);_0x568e94=Jo(_0x588c36['serverSyncTree_'],_0x554357['_path'],_0x1ef854,_0xa2099);}return V(_0x588c36['eventQueue_'],_0x554357['_path'],_0x568e94),An(_0x588c36['serverSyncTree_'],_0x554357,_0x5acd00,null,!0x0),_0x1ef854;},_0x6725a7=>(gt(_0x588c36,'get\x20for\x20query\x20'+O(_0x554357)+'\x20failed:\x20'+_0x6725a7),Promise['reject'](new Error(_0x6725a7))));}function Cd(_0x2a36a8,_0x435e9f,_0x39e7cb,_0x2ebdab,_0x12b518){gt(_0x2a36a8,'set',{'path':_0x435e9f['toString'](),'value':_0x39e7cb,'priority':_0x2ebdab});const _0x2b1299=Xt(_0x2a36a8),_0xdc4380=A(_0x39e7cb,_0x2ebdab),_0x2fa093=Vn(_0x2a36a8['serverSyncTree_'],_0x435e9f),_0xa1ca6d=fs(_0xdc4380,_0x2fa093,_0x2b1299),_0x5e2442=zn(_0x2a36a8),_0x4e5a42=as(_0x2a36a8['serverSyncTree_'],_0x435e9f,_0xa1ca6d,_0x5e2442,!0x0);qn(_0x2a36a8['eventQueue_'],_0x4e5a42),_0x2a36a8['server_']['put'](_0x435e9f['toString'](),_0xdc4380['val'](!0x0),(_0x1cb910,_0x3c43a3)=>{const _0x658a6d=_0x1cb910==='ok';_0x658a6d||U('set\x20at\x20'+_0x435e9f+'\x20failed:\x20'+_0x1cb910);const _0x2164fc=_e(_0x2a36a8['serverSyncTree_'],_0x5e2442,!_0x658a6d);V(_0x2a36a8['eventQueue_'],_0x435e9f,_0x2164fc),be(_0x2a36a8,_0x12b518,_0x1cb910,_0x3c43a3);});const _0x55b05b=Is(_0x2a36a8,_0x435e9f);ct(_0x2a36a8,_0x55b05b),V(_0x2a36a8['eventQueue_'],_0x55b05b,[]);}function Td(_0x1cc18c,_0xe58cf6,_0x2c869d,_0x4160e4){gt(_0x1cc18c,'update',{'path':_0xe58cf6['toString'](),'value':_0x2c869d});let _0x5a6cda=!0x0;const _0x270304=Xt(_0x1cc18c),_0x3f33e0={};if(x(_0x2c869d,(_0x54bbc7,_0x10cc29)=>{_0x5a6cda=!0x1,_0x3f33e0[_0x54bbc7]=ta(k(_0xe58cf6,_0x54bbc7),A(_0x10cc29),_0x1cc18c['serverSyncTree_'],_0x270304);}),_0x5a6cda)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1cc18c,_0x4160e4,'ok',void 0x0);else{const _0x15529e=zn(_0x1cc18c),_0x36c88d=ju(_0x1cc18c['serverSyncTree_'],_0xe58cf6,_0x3f33e0,_0x15529e);qn(_0x1cc18c['eventQueue_'],_0x36c88d),_0x1cc18c['server_']['merge'](_0xe58cf6['toString'](),_0x2c869d,(_0x3667fa,_0xd63c1b)=>{const _0x26e61b=_0x3667fa==='ok';_0x26e61b||U('update\x20at\x20'+_0xe58cf6+'\x20failed:\x20'+_0x3667fa);const _0x410ca3=_e(_0x1cc18c['serverSyncTree_'],_0x15529e,!_0x26e61b),_0x1e1d1c=_0x410ca3['length']>0x0?ct(_0x1cc18c,_0xe58cf6):_0xe58cf6;V(_0x1cc18c['eventQueue_'],_0x1e1d1c,_0x410ca3),be(_0x1cc18c,_0x4160e4,_0x3667fa,_0xd63c1b);}),x(_0x2c869d,_0x5bb536=>{const _0x2bd2eb=Is(_0x1cc18c,k(_0xe58cf6,_0x5bb536));ct(_0x1cc18c,_0x2bd2eb);}),V(_0x1cc18c['eventQueue_'],_0xe58cf6,[]);}}function Sd(_0x39b3e4){gt(_0x39b3e4,'onDisconnectEvents');const _0x5ed430=Xt(_0x39b3e4),_0x93f541=En();Si(_0x39b3e4['onDisconnect_'],w(),(_0x2618d7,_0x14a3b9)=>{const _0x19756a=ta(_0x2618d7,_0x14a3b9,_0x39b3e4['serverSyncTree_'],_0x5ed430);pt(_0x93f541,_0x2618d7,_0x19756a);});let _0x58eb55=[];Si(_0x93f541,w(),(_0x5ec65c,_0x29ceb7)=>{_0x58eb55=_0x58eb55['concat'](Yt(_0x39b3e4['serverSyncTree_'],_0x5ec65c,_0x29ceb7));const _0xfae6ec=Is(_0x39b3e4,_0x5ec65c);ct(_0x39b3e4,_0xfae6ec);}),_0x39b3e4['onDisconnect_']=En(),V(_0x39b3e4['eventQueue_'],w(),_0x58eb55);}function bd(_0x47478d,_0x4e7f01,_0xec333c){_0x47478d['server_']['onDisconnectCancel'](_0x4e7f01['toString'](),(_0x2c4bef,_0x59f7d3)=>{_0x2c4bef==='ok'&&Ti(_0x47478d['onDisconnect_'],_0x4e7f01),be(_0x47478d,_0xec333c,_0x2c4bef,_0x59f7d3);});}function yr(_0x2a67c9,_0x19420f,_0x38ce71,_0x3fd864){const _0x455afa=A(_0x38ce71);_0x2a67c9['server_']['onDisconnectPut'](_0x19420f['toString'](),_0x455afa['val'](!0x0),(_0x1d4458,_0x8e6a99)=>{_0x1d4458==='ok'&&pt(_0x2a67c9['onDisconnect_'],_0x19420f,_0x455afa),be(_0x2a67c9,_0x3fd864,_0x1d4458,_0x8e6a99);});}function Rd(_0x57e694,_0x5941a6,_0x219b61,_0x9c29b9,_0x5b8865){const _0x5564df=A(_0x219b61,_0x9c29b9);_0x57e694['server_']['onDisconnectPut'](_0x5941a6['toString'](),_0x5564df['val'](!0x0),(_0x382e1e,_0x53c013)=>{_0x382e1e==='ok'&&pt(_0x57e694['onDisconnect_'],_0x5941a6,_0x5564df),be(_0x57e694,_0x5b8865,_0x382e1e,_0x53c013);});}function Ad(_0x41c075,_0x2c7f6f,_0x596188,_0x5ce888){if(pn(_0x596188)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x41c075,_0x5ce888,'ok',void 0x0);return;}_0x41c075['server_']['onDisconnectMerge'](_0x2c7f6f['toString'](),_0x596188,(_0x417a85,_0x3b56a0)=>{_0x417a85==='ok'&&x(_0x596188,(_0x1f26f9,_0x44e490)=>{const _0x4908c9=A(_0x44e490);pt(_0x41c075['onDisconnect_'],k(_0x2c7f6f,_0x1f26f9),_0x4908c9);}),be(_0x41c075,_0x5ce888,_0x417a85,_0x3b56a0);});}function kd(_0x3ae31a,_0x5eefba,_0x555fad){let _0x3aac37;y(_0x5eefba['_path'])==='.info'?_0x3aac37=Ni(_0x3ae31a['infoSyncTree_'],_0x5eefba,_0x555fad):_0x3aac37=Ni(_0x3ae31a['serverSyncTree_'],_0x5eefba,_0x555fad),oa(_0x3ae31a['eventQueue_'],_0x5eefba['_path'],_0x3aac37);}function Pd(_0xd267ab,_0x10ac9d,_0x2f223c){let _0x4ea923;y(_0x10ac9d['_path'])==='.info'?_0x4ea923=An(_0xd267ab['infoSyncTree_'],_0x10ac9d,_0x2f223c):_0x4ea923=An(_0xd267ab['serverSyncTree_'],_0x10ac9d,_0x2f223c),oa(_0xd267ab['eventQueue_'],_0x10ac9d['_path'],_0x4ea923);}function ha(_0x2b310d){_0x2b310d['persistentConnection_']&&_0x2b310d['persistentConnection_']['interrupt'](ca);}function Nd(_0x863392){_0x863392['persistentConnection_']&&_0x863392['persistentConnection_']['resume'](ca);}function gt(_0x1ecf9e,..._0x16ed7c){let _0x19c3cb='';_0x1ecf9e['persistentConnection_']&&(_0x19c3cb=_0x1ecf9e['persistentConnection_']['id']+':'),L(_0x19c3cb,..._0x16ed7c);}function be(_0x37adc9,_0xbfcaf3,_0x291e5f,_0x3f8021){_0xbfcaf3&&ft(()=>{if(_0x291e5f==='ok')_0xbfcaf3(null);else{const _0x4805b5=(_0x291e5f||'error')['toUpperCase']();let _0x28529a=_0x4805b5;_0x3f8021&&(_0x28529a+=':\x20'+_0x3f8021);const _0x16000a=new Error(_0x28529a);_0x16000a['code']=_0x4805b5,_0xbfcaf3(_0x16000a);}});}function Od(_0x494199,_0x1c54ef,_0x58d6c7,_0x1e0d9b,_0x267a9e,_0x25ea0a){gt(_0x494199,'transaction\x20on\x20'+_0x1c54ef);const _0xe967dc={'path':_0x1c54ef,'update':_0x58d6c7,'onComplete':_0x1e0d9b,'status':null,'order':so(),'applyLocally':_0x25ea0a,'retryCount':0x0,'unwatcher':_0x267a9e,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3d6110=Es(_0x494199,_0x1c54ef,void 0x0);_0xe967dc['currentInputSnapshot']=_0x3d6110;const _0x21fdec=_0xe967dc['update'](_0x3d6110['val']());if(_0x21fdec===void 0x0)_0xe967dc['unwatcher'](),_0xe967dc['currentOutputSnapshotRaw']=null,_0xe967dc['currentOutputSnapshotResolved']=null,_0xe967dc['onComplete']&&_0xe967dc['onComplete'](null,!0x1,_0xe967dc['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x21fdec,_0xe967dc['path']),_0xe967dc['status']=0x0;const _0x4d5de0=$n(_0x494199['transactionQueueTree_'],_0x1c54ef),_0x3aae31=je(_0x4d5de0)||[];_0x3aae31['push'](_0xe967dc),gs(_0x4d5de0,_0x3aae31);let _0x30833f;typeof _0x21fdec=='object'&&_0x21fdec!==null&&Q(_0x21fdec,'.priority')?(_0x30833f=Le(_0x21fdec,'.priority'),f(Bt(_0x30833f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x30833f=(Vn(_0x494199['serverSyncTree_'],_0x1c54ef)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x450af5=Xt(_0x494199),_0x5d2c40=A(_0x21fdec,_0x30833f),_0x1bbc17=fs(_0x5d2c40,_0x3d6110,_0x450af5);_0xe967dc['currentOutputSnapshotRaw']=_0x5d2c40,_0xe967dc['currentOutputSnapshotResolved']=_0x1bbc17,_0xe967dc['currentWriteId']=zn(_0x494199);const _0x473e77=as(_0x494199['serverSyncTree_'],_0x1c54ef,_0x1bbc17,_0xe967dc['currentWriteId'],_0xe967dc['applyLocally']);V(_0x494199['eventQueue_'],_0x1c54ef,_0x473e77),jn(_0x494199,_0x494199['transactionQueueTree_']);}}function Es(_0x11e774,_0x37b9ec,_0x40a7c9){return Vn(_0x11e774['serverSyncTree_'],_0x37b9ec,_0x40a7c9)||g['EMPTY_NODE'];}function jn(_0x267d50,_0x55c357=_0x267d50['transactionQueueTree_']){if(_0x55c357||Kn(_0x267d50,_0x55c357),je(_0x55c357)){const _0x4a821c=da(_0x267d50,_0x55c357);f(_0x4a821c['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4a821c['every'](_0xed84c3=>_0xed84c3['status']===0x0)&&Dd(_0x267d50,Qt(_0x55c357),_0x4a821c);}else na(_0x55c357)&&Gn(_0x55c357,_0x25d587=>{jn(_0x267d50,_0x25d587);});}function Dd(_0x5fc905,_0x206f7b,_0x5affc8){const _0x1be6de=_0x5affc8['map'](_0x3a906f=>_0x3a906f['currentWriteId']),_0x1d8ca4=Es(_0x5fc905,_0x206f7b,_0x1be6de);let _0xff9176=_0x1d8ca4;const _0x65720f=_0x1d8ca4['hash']();for(let _0x7352f=0x0;_0x7352f<_0x5affc8['length'];_0x7352f++){const _0x322f5d=_0x5affc8[_0x7352f];f(_0x322f5d['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x322f5d['status']=0x1,_0x322f5d['retryCount']++;const _0x4c4c81=F(_0x206f7b,_0x322f5d['path']);_0xff9176=_0xff9176['updateChild'](_0x4c4c81,_0x322f5d['currentOutputSnapshotRaw']);}const _0x1f4417=_0xff9176['val'](!0x0),_0x2b6262=_0x206f7b;_0x5fc905['server_']['put'](_0x2b6262['toString'](),_0x1f4417,_0x3936cb=>{gt(_0x5fc905,'transaction\x20put\x20response',{'path':_0x2b6262['toString'](),'status':_0x3936cb});let _0xeec713=[];if(_0x3936cb==='ok'){const _0x4b13ab=[];for(let _0xc1c320=0x0;_0xc1c320<_0x5affc8['length'];_0xc1c320++)_0x5affc8[_0xc1c320]['status']=0x2,_0xeec713=_0xeec713['concat'](_e(_0x5fc905['serverSyncTree_'],_0x5affc8[_0xc1c320]['currentWriteId'])),_0x5affc8[_0xc1c320]['onComplete']&&_0x4b13ab['push'](()=>_0x5affc8[_0xc1c320]['onComplete'](null,!0x0,_0x5affc8[_0xc1c320]['currentOutputSnapshotResolved'])),_0x5affc8[_0xc1c320]['unwatcher']();Kn(_0x5fc905,$n(_0x5fc905['transactionQueueTree_'],_0x206f7b)),jn(_0x5fc905,_0x5fc905['transactionQueueTree_']),V(_0x5fc905['eventQueue_'],_0x206f7b,_0xeec713);for(let _0xbdcc82=0x0;_0xbdcc82<_0x4b13ab['length'];_0xbdcc82++)ft(_0x4b13ab[_0xbdcc82]);}else{if(_0x3936cb==='datastale'){for(let _0x4d0088=0x0;_0x4d0088<_0x5affc8['length'];_0x4d0088++)_0x5affc8[_0x4d0088]['status']===0x3?_0x5affc8[_0x4d0088]['status']=0x4:_0x5affc8[_0x4d0088]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2b6262['toString']()+'\x20failed:\x20'+_0x3936cb);for(let _0x25aade=0x0;_0x25aade<_0x5affc8['length'];_0x25aade++)_0x5affc8[_0x25aade]['status']=0x4,_0x5affc8[_0x25aade]['abortReason']=_0x3936cb;}ct(_0x5fc905,_0x206f7b);}},_0x65720f);}function ct(_0x5d7f6b,_0x385aa3){const _0x2f4c39=ua(_0x5d7f6b,_0x385aa3),_0x2f43d4=Qt(_0x2f4c39),_0xe20735=da(_0x5d7f6b,_0x2f4c39);return Md(_0x5d7f6b,_0xe20735,_0x2f43d4),_0x2f43d4;}function Md(_0x18bb0f,_0x22780c,_0x4ae8f0){if(_0x22780c['length']===0x0)return;const _0x3c0341=[];let _0x180630=[];const _0x44f54c=_0x22780c['filter'](_0x6570c9=>_0x6570c9['status']===0x0)['map'](_0x3f01ee=>_0x3f01ee['currentWriteId']);for(let _0x2cbdd6=0x0;_0x2cbdd6<_0x22780c['length'];_0x2cbdd6++){const _0x59a2e4=_0x22780c[_0x2cbdd6],_0x5ec564=F(_0x4ae8f0,_0x59a2e4['path']);let _0x22158a=!0x1,_0x41f0c5;if(f(_0x5ec564!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x59a2e4['status']===0x4)_0x22158a=!0x0,_0x41f0c5=_0x59a2e4['abortReason'],_0x180630=_0x180630['concat'](_e(_0x18bb0f['serverSyncTree_'],_0x59a2e4['currentWriteId'],!0x0));else{if(_0x59a2e4['status']===0x0){if(_0x59a2e4['retryCount']>=yd)_0x22158a=!0x0,_0x41f0c5='maxretry',_0x180630=_0x180630['concat'](_e(_0x18bb0f['serverSyncTree_'],_0x59a2e4['currentWriteId'],!0x0));else{const _0x13854d=Es(_0x18bb0f,_0x59a2e4['path'],_0x44f54c);_0x59a2e4['currentInputSnapshot']=_0x13854d;const _0x2f47b3=_0x22780c[_0x2cbdd6]['update'](_0x13854d['val']());if(_0x2f47b3!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2f47b3,_0x59a2e4['path']);let _0x1e5f45=A(_0x2f47b3);typeof _0x2f47b3=='object'&&_0x2f47b3!=null&&Q(_0x2f47b3,'.priority')||(_0x1e5f45=_0x1e5f45['updatePriority'](_0x13854d['getPriority']()));const _0x5cbe5d=_0x59a2e4['currentWriteId'],_0x2c303b=Xt(_0x18bb0f),_0x3cd923=fs(_0x1e5f45,_0x13854d,_0x2c303b);_0x59a2e4['currentOutputSnapshotRaw']=_0x1e5f45,_0x59a2e4['currentOutputSnapshotResolved']=_0x3cd923,_0x59a2e4['currentWriteId']=zn(_0x18bb0f),_0x44f54c['splice'](_0x44f54c['indexOf'](_0x5cbe5d),0x1),_0x180630=_0x180630['concat'](as(_0x18bb0f['serverSyncTree_'],_0x59a2e4['path'],_0x3cd923,_0x59a2e4['currentWriteId'],_0x59a2e4['applyLocally'])),_0x180630=_0x180630['concat'](_e(_0x18bb0f['serverSyncTree_'],_0x5cbe5d,!0x0));}else _0x22158a=!0x0,_0x41f0c5='nodata',_0x180630=_0x180630['concat'](_e(_0x18bb0f['serverSyncTree_'],_0x59a2e4['currentWriteId'],!0x0));}}}V(_0x18bb0f['eventQueue_'],_0x4ae8f0,_0x180630),_0x180630=[],_0x22158a&&(_0x22780c[_0x2cbdd6]['status']=0x2,function(_0x1c777a){setTimeout(_0x1c777a,Math['floor'](0x0));}(_0x22780c[_0x2cbdd6]['unwatcher']),_0x22780c[_0x2cbdd6]['onComplete']&&(_0x41f0c5==='nodata'?_0x3c0341['push'](()=>_0x22780c[_0x2cbdd6]['onComplete'](null,!0x1,_0x22780c[_0x2cbdd6]['currentInputSnapshot'])):_0x3c0341['push'](()=>_0x22780c[_0x2cbdd6]['onComplete'](new Error(_0x41f0c5),!0x1,null))));}Kn(_0x18bb0f,_0x18bb0f['transactionQueueTree_']);for(let _0x336f2a=0x0;_0x336f2a<_0x3c0341['length'];_0x336f2a++)ft(_0x3c0341[_0x336f2a]);jn(_0x18bb0f,_0x18bb0f['transactionQueueTree_']);}function ua(_0x250023,_0x35ba50){let _0x197325,_0x154585=_0x250023['transactionQueueTree_'];for(_0x197325=y(_0x35ba50);_0x197325!==null&&je(_0x154585)===void 0x0;)_0x154585=$n(_0x154585,_0x197325),_0x35ba50=S(_0x35ba50),_0x197325=y(_0x35ba50);return _0x154585;}function da(_0x58b599,_0x20c56b){const _0x45be60=[];return fa(_0x58b599,_0x20c56b,_0x45be60),_0x45be60['sort']((_0x11139d,_0x1ac8e3)=>_0x11139d['order']-_0x1ac8e3['order']),_0x45be60;}function fa(_0x2ba387,_0x50c26c,_0x374561){const _0xfc02c=je(_0x50c26c);if(_0xfc02c){for(let _0xc7ba31=0x0;_0xc7ba31<_0xfc02c['length'];_0xc7ba31++)_0x374561['push'](_0xfc02c[_0xc7ba31]);}Gn(_0x50c26c,_0x230489=>{fa(_0x2ba387,_0x230489,_0x374561);});}function Kn(_0x2e38ac,_0x34753b){const _0x5c06fb=je(_0x34753b);if(_0x5c06fb){let _0x3ced48=0x0;for(let _0x26b333=0x0;_0x26b333<_0x5c06fb['length'];_0x26b333++)_0x5c06fb[_0x26b333]['status']!==0x2&&(_0x5c06fb[_0x3ced48]=_0x5c06fb[_0x26b333],_0x3ced48++);_0x5c06fb['length']=_0x3ced48,gs(_0x34753b,_0x5c06fb['length']>0x0?_0x5c06fb:void 0x0);}Gn(_0x34753b,_0x27aedb=>{Kn(_0x2e38ac,_0x27aedb);});}function Is(_0x186fb9,_0x267fd6){const _0xb93ead=Qt(ua(_0x186fb9,_0x267fd6)),_0x3a711e=$n(_0x186fb9['transactionQueueTree_'],_0x267fd6);return ad(_0x3a711e,_0x31ae83=>{di(_0x186fb9,_0x31ae83);}),di(_0x186fb9,_0x3a711e),ia(_0x3a711e,_0x39e4e9=>{di(_0x186fb9,_0x39e4e9);}),_0xb93ead;}function di(_0x174cb6,_0x37eff7){const _0x5f1fc7=je(_0x37eff7);if(_0x5f1fc7){const _0x23a555=[];let _0x31c55c=[],_0x152555=-0x1;for(let _0x116e46=0x0;_0x116e46<_0x5f1fc7['length'];_0x116e46++)_0x5f1fc7[_0x116e46]['status']===0x3||(_0x5f1fc7[_0x116e46]['status']===0x1?(f(_0x152555===_0x116e46-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x152555=_0x116e46,_0x5f1fc7[_0x116e46]['status']=0x3,_0x5f1fc7[_0x116e46]['abortReason']='set'):(f(_0x5f1fc7[_0x116e46]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5f1fc7[_0x116e46]['unwatcher'](),_0x31c55c=_0x31c55c['concat'](_e(_0x174cb6['serverSyncTree_'],_0x5f1fc7[_0x116e46]['currentWriteId'],!0x0)),_0x5f1fc7[_0x116e46]['onComplete']&&_0x23a555['push'](_0x5f1fc7[_0x116e46]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x152555===-0x1?gs(_0x37eff7,void 0x0):_0x5f1fc7['length']=_0x152555+0x1,V(_0x174cb6['eventQueue_'],Qt(_0x37eff7),_0x31c55c);for(let _0x137b2e=0x0;_0x137b2e<_0x23a555['length'];_0x137b2e++)ft(_0x23a555[_0x137b2e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x5a81b7){let _0x550467='';const _0x509206=_0x5a81b7['split']('/');for(let _0x3ffbb6=0x0;_0x3ffbb6<_0x509206['length'];_0x3ffbb6++)if(_0x509206[_0x3ffbb6]['length']>0x0){let _0x1f4907=_0x509206[_0x3ffbb6];try{_0x1f4907=decodeURIComponent(_0x1f4907['replace'](/\+/g,'\x20'));}catch{}_0x550467+='/'+_0x1f4907;}return _0x550467;}function xd(_0x5593f2){const _0x29fa2b={};_0x5593f2['charAt'](0x0)==='?'&&(_0x5593f2=_0x5593f2['substring'](0x1));for(const _0x2ee2a3 of _0x5593f2['split']('&')){if(_0x2ee2a3['length']===0x0)continue;const _0x377a50=_0x2ee2a3['split']('=');_0x377a50['length']===0x2?_0x29fa2b[decodeURIComponent(_0x377a50[0x0])]=decodeURIComponent(_0x377a50[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2ee2a3+'\x27\x20in\x20query\x20\x27'+_0x5593f2+'\x27');}return _0x29fa2b;}const vr=function(_0x47fbba,_0x53e842){const _0x1daa83=Fd(_0x47fbba),_0x1bd416=_0x1daa83['namespace'];_0x1daa83['domain']==='firebase.com'&&ae(_0x1daa83['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x1bd416||_0x1bd416==='undefined')&&_0x1daa83['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1daa83['secure']||$l();const _0x347f4a=_0x1daa83['scheme']==='ws'||_0x1daa83['scheme']==='wss';return{'repoInfo':new yo(_0x1daa83['host'],_0x1daa83['secure'],_0x1bd416,_0x347f4a,_0x53e842,'',_0x1bd416!==_0x1daa83['subdomain']),'path':new C(_0x1daa83['pathString'])};},Fd=function(_0x3e9e8a){let _0x46821c='',_0x460287='',_0x3787bc='',_0x51d150='',_0x7fabb5='',_0x4caacb=!0x0,_0x5f31d5='https',_0x60c2dd=0x1bb;if(typeof _0x3e9e8a=='string'){let _0xc7e0a8=_0x3e9e8a['indexOf']('//');_0xc7e0a8>=0x0&&(_0x5f31d5=_0x3e9e8a['substring'](0x0,_0xc7e0a8-0x1),_0x3e9e8a=_0x3e9e8a['substring'](_0xc7e0a8+0x2));let _0x2a47c2=_0x3e9e8a['indexOf']('/');_0x2a47c2===-0x1&&(_0x2a47c2=_0x3e9e8a['length']);let _0x1eae32=_0x3e9e8a['indexOf']('?');_0x1eae32===-0x1&&(_0x1eae32=_0x3e9e8a['length']),_0x46821c=_0x3e9e8a['substring'](0x0,Math['min'](_0x2a47c2,_0x1eae32)),_0x2a47c2<_0x1eae32&&(_0x51d150=Ld(_0x3e9e8a['substring'](_0x2a47c2,_0x1eae32)));const _0x179771=xd(_0x3e9e8a['substring'](Math['min'](_0x3e9e8a['length'],_0x1eae32)));_0xc7e0a8=_0x46821c['indexOf'](':'),_0xc7e0a8>=0x0?(_0x4caacb=_0x5f31d5==='https'||_0x5f31d5==='wss',_0x60c2dd=parseInt(_0x46821c['substring'](_0xc7e0a8+0x1),0xa)):_0xc7e0a8=_0x46821c['length'];const _0x57efdf=_0x46821c['slice'](0x0,_0xc7e0a8);if(_0x57efdf['toLowerCase']()==='localhost')_0x460287='localhost';else{if(_0x57efdf['split']('.')['length']<=0x2)_0x460287=_0x57efdf;else{const _0x3a8035=_0x46821c['indexOf']('.');_0x3787bc=_0x46821c['substring'](0x0,_0x3a8035)['toLowerCase'](),_0x460287=_0x46821c['substring'](_0x3a8035+0x1),_0x7fabb5=_0x3787bc;}}'ns'in _0x179771&&(_0x7fabb5=_0x179771['ns']);}return{'host':_0x46821c,'port':_0x60c2dd,'domain':_0x460287,'subdomain':_0x3787bc,'secure':_0x4caacb,'scheme':_0x5f31d5,'pathString':_0x51d150,'namespace':_0x7fabb5};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x96ef82=0x0;const _0x536c20=[];return function(_0x28722c){const _0x4da139=_0x28722c===_0x96ef82;_0x96ef82=_0x28722c;let _0x2e1ab4;const _0x1f1ac0=new Array(0x8);for(_0x2e1ab4=0x7;_0x2e1ab4>=0x0;_0x2e1ab4--)_0x1f1ac0[_0x2e1ab4]=Er['charAt'](_0x28722c%0x40),_0x28722c=Math['floor'](_0x28722c/0x40);f(_0x28722c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x335a93=_0x1f1ac0['join']('');if(_0x4da139){for(_0x2e1ab4=0xb;_0x2e1ab4>=0x0&&_0x536c20[_0x2e1ab4]===0x3f;_0x2e1ab4--)_0x536c20[_0x2e1ab4]=0x0;_0x536c20[_0x2e1ab4]++;}else{for(_0x2e1ab4=0x0;_0x2e1ab4<0xc;_0x2e1ab4++)_0x536c20[_0x2e1ab4]=Math['floor'](Math['random']()*0x40);}for(_0x2e1ab4=0x0;_0x2e1ab4<0xc;_0x2e1ab4++)_0x335a93+=Er['charAt'](_0x536c20[_0x2e1ab4]);return f(_0x335a93['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x335a93;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x16e291,_0x2f55e7,_0x27a8d3,_0x39cc02){this['eventType']=_0x16e291,this['eventRegistration']=_0x2f55e7,this['snapshot']=_0x27a8d3,this['prevName']=_0x39cc02;}['getPath'](){const _0x14248e=this['snapshot']['ref'];return this['eventType']==='value'?_0x14248e['_path']:_0x14248e['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2e4f5e,_0x5abe6d,_0x583f88){this['eventRegistration']=_0x2e4f5e,this['error']=_0x5abe6d,this['path']=_0x583f88;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1f2f03,_0x2f5759){this['snapshotCallback']=_0x1f2f03,this['cancelCallback']=_0x2f5759;}['onValue'](_0x3807fc,_0x5af5a1){this['snapshotCallback']['call'](null,_0x3807fc,_0x5af5a1);}['onCancel'](_0x157ea4){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x157ea4);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1e63ad){return this['snapshotCallback']===_0x1e63ad['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1e63ad['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1e63ad['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2e0c77,_0x16d03e){this['_repo']=_0x2e0c77,this['_path']=_0x16d03e;}['cancel'](){const _0x56ab70=new H();return bd(this['_repo'],this['_path'],_0x56ab70['wrapCallback'](()=>{})),_0x56ab70['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x18d390=new H();return yr(this['_repo'],this['_path'],null,_0x18d390['wrapCallback'](()=>{})),_0x18d390['promise'];}['set'](_0x5e9292){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x5e9292,this['_path'],!0x1);const _0x12f930=new H();return yr(this['_repo'],this['_path'],_0x5e9292,_0x12f930['wrapCallback'](()=>{})),_0x12f930['promise'];}['setWithPriority'](_0x4a99c4,_0x4b89c9){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x4a99c4,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4b89c9);const _0x558014=new H();return Rd(this['_repo'],this['_path'],_0x4a99c4,_0x4b89c9,_0x558014['wrapCallback'](()=>{})),_0x558014['promise'];}['update'](_0x1720c1){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1720c1,this['_path']);const _0x4971d9=new H();return Ad(this['_repo'],this['_path'],_0x1720c1,_0x4971d9['wrapCallback'](()=>{})),_0x4971d9['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x5b0f53,_0x26efa5,_0x12e267,_0x12cb0f){this['_repo']=_0x5b0f53,this['_path']=_0x26efa5,this['_queryParams']=_0x12e267,this['_orderByCalled']=_0x12cb0f;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x92c58a=sr(this['_queryParams']),_0x15cbad=$i(_0x92c58a);return _0x15cbad==='{}'?'default':_0x15cbad;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x27163b){if(_0x27163b=P(_0x27163b),!(_0x27163b instanceof Ae))return!0x1;const _0xac4333=this['_repo']===_0x27163b['_repo'],_0x325718=Ki(this['_path'],_0x27163b['_path']),_0x59e188=this['_queryIdentifier']===_0x27163b['_queryIdentifier'];return _0xac4333&&_0x325718&&_0x59e188;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1a1c2f,_0x3b84f0){if(_0x1a1c2f['_orderByCalled']===!0x0)throw new Error(_0x3b84f0+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x3e4e1d){let _0x1b5a7e=null,_0x19d7f5=null;if(_0x3e4e1d['hasStart']()&&(_0x1b5a7e=_0x3e4e1d['getIndexStartValue']()),_0x3e4e1d['hasEnd']()&&(_0x19d7f5=_0x3e4e1d['getIndexEndValue']()),_0x3e4e1d['getIndex']()===ve){const _0x53976d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1d1080='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3e4e1d['hasStart']()){if(_0x3e4e1d['getIndexStartName']()!==We)throw new Error(_0x53976d);if(typeof _0x1b5a7e!='string')throw new Error(_0x1d1080);}if(_0x3e4e1d['hasEnd']()){if(_0x3e4e1d['getIndexEndName']()!==we)throw new Error(_0x53976d);if(typeof _0x19d7f5!='string')throw new Error(_0x1d1080);}}else{if(_0x3e4e1d['getIndex']()===R){if(_0x1b5a7e!=null&&!Bt(_0x1b5a7e)||_0x19d7f5!=null&&!Bt(_0x19d7f5))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3e4e1d['getIndex']()instanceof Ji||_0x3e4e1d['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x1b5a7e!=null&&typeof _0x1b5a7e=='object'||_0x19d7f5!=null&&typeof _0x19d7f5=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3929a8){if(_0x3929a8['hasStart']()&&_0x3929a8['hasEnd']()&&_0x3929a8['hasLimit']()&&!_0x3929a8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x454e2d,_0x1c9521){super(_0x454e2d,_0x1c9521,new Zi(),!0x1);}get['parent'](){const _0x560a9a=Ro(this['_path']);return _0x560a9a===null?null:new ee(this['_repo'],_0x560a9a);}get['root'](){let _0x1c15e0=this;for(;_0x1c15e0['parent']!==null;)_0x1c15e0=_0x1c15e0['parent'];return _0x1c15e0;}}class lt{constructor(_0x175c6f,_0x284755,_0x24e85b){this['_node']=_0x175c6f,this['ref']=_0x284755,this['_index']=_0x24e85b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x336876){const _0x2d221c=new C(_0x336876),_0x437ddd=Vt(this['ref'],_0x336876);return new lt(this['_node']['getChild'](_0x2d221c),_0x437ddd,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xcb964c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2b7c48,_0x1a90d2)=>_0xcb964c(new lt(_0x1a90d2,Vt(this['ref'],_0x2b7c48),R)));}['hasChild'](_0x29e7f6){const _0x24b200=new C(_0x29e7f6);return!this['_node']['getChild'](_0x24b200)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x408697,_0xf1e21){return _0x408697=P(_0x408697),_0x408697['_checkNotDeleted']('ref'),_0xf1e21!==void 0x0?Vt(_0x408697['_root'],_0xf1e21):_0x408697['_root'];}function Vt(_0x53adbc,_0x41281a){return _0x53adbc=P(_0x53adbc),y(_0x53adbc['_path'])===null?pd('child','path',_0x41281a):ys('child','path',_0x41281a),new ee(_0x53adbc['_repo'],k(_0x53adbc['_path'],_0x41281a));}function v_(_0x3d8c06){return _0x3d8c06=P(_0x3d8c06),new Vd(_0x3d8c06['_repo'],_0x3d8c06['_path']);}function E_(_0x4900f0,_0x196f6b){_0x4900f0=P(_0x4900f0),Me('push',_0x4900f0['_path']),He('push',_0x196f6b,_0x4900f0['_path'],!0x0);const _0x5332fb=la(_0x4900f0['_repo']),_0x1379be=Ud(_0x5332fb),_0x58fe55=Vt(_0x4900f0,_0x1379be),_0x53689b=Vt(_0x4900f0,_0x1379be);let _0x4b28c4;return _0x196f6b!=null?_0x4b28c4=Hd(_0x53689b,_0x196f6b)['then'](()=>_0x53689b):_0x4b28c4=Promise['resolve'](_0x53689b),_0x58fe55['then']=_0x4b28c4['then']['bind'](_0x4b28c4),_0x58fe55['catch']=_0x4b28c4['then']['bind'](_0x4b28c4,void 0x0),_0x58fe55;}function Hd(_0x14a2b3,_0x489c7e){_0x14a2b3=P(_0x14a2b3),Me('set',_0x14a2b3['_path']),He('set',_0x489c7e,_0x14a2b3['_path'],!0x1);const _0x36683e=new H();return Cd(_0x14a2b3['_repo'],_0x14a2b3['_path'],_0x489c7e,null,_0x36683e['wrapCallback'](()=>{})),_0x36683e['promise'];}function I_(_0x25ef7b,_0x3b3cc5){ra('update',_0x3b3cc5,_0x25ef7b['_path']);const _0x4e7030=new H();return Td(_0x25ef7b['_repo'],_0x25ef7b['_path'],_0x3b3cc5,_0x4e7030['wrapCallback'](()=>{})),_0x4e7030['promise'];}function w_(_0x4691c7){_0x4691c7=P(_0x4691c7);const _0xd17a90=new pa(()=>{}),_0x380cf6=new Qn(_0xd17a90);return wd(_0x4691c7['_repo'],_0x4691c7,_0x380cf6)['then'](_0x2fd5d6=>new lt(_0x2fd5d6,new ee(_0x4691c7['_repo'],_0x4691c7['_path']),_0x4691c7['_queryParams']['getIndex']()));}class Qn{constructor(_0x4ae71d){this['callbackContext']=_0x4ae71d;}['respondsTo'](_0x149a33){return _0x149a33==='value';}['createEvent'](_0x16ac13,_0x309760){const _0x52e519=_0x309760['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x16ac13['snapshotNode'],new ee(_0x309760['_repo'],_0x309760['_path']),_0x52e519));}['getEventRunner'](_0x50692c){return _0x50692c['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x50692c['error']):()=>this['callbackContext']['onValue'](_0x50692c['snapshot'],null);}['createCancelEvent'](_0x3d69b1,_0x229c35){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x3d69b1,_0x229c35):null;}['matches'](_0x92c8e1){return _0x92c8e1 instanceof Qn?!_0x92c8e1['callbackContext']||!this['callbackContext']?!0x0:_0x92c8e1['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x1aac66,_0x7ea20f,_0x18fd53,_0xf0e779,_0x463816){const _0xb38636=new pa(_0x18fd53,void 0x0),_0xf59452=new Qn(_0xb38636);return kd(_0x1aac66['_repo'],_0x1aac66,_0xf59452),()=>Pd(_0x1aac66['_repo'],_0x1aac66,_0xf59452);}function Gd(_0x1dec91,_0x4fec73,_0xfd7475,_0x4a76e2){return $d(_0x1dec91,'value',_0x4fec73);}class mt{}class ma extends mt{constructor(_0x5d341d,_0x1c42ce){super(),this['_value']=_0x5d341d,this['_key']=_0x1c42ce,this['type']='endAt';}['_apply'](_0x5175b3){He('endAt',this['_value'],_0x5175b3['_path'],!0x0);const _0x4d68b3=Jh(_0x5175b3['_queryParams'],this['_value'],this['_key']);if(ga(_0x4d68b3),Yn(_0x4d68b3),_0x5175b3['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x5175b3['_repo'],_0x5175b3['_path'],_0x4d68b3,_0x5175b3['_orderByCalled']);}}function C_(_0x13346e,_0x28b088){return new ma(_0x13346e,_0x28b088);}class ya extends mt{constructor(_0x5acdc8,_0x501a05){super(),this['_value']=_0x5acdc8,this['_key']=_0x501a05,this['type']='startAt';}['_apply'](_0x45136e){He('startAt',this['_value'],_0x45136e['_path'],!0x0);const _0xc360f4=Qh(_0x45136e['_queryParams'],this['_value'],this['_key']);if(ga(_0xc360f4),Yn(_0xc360f4),_0x45136e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x45136e['_repo'],_0x45136e['_path'],_0xc360f4,_0x45136e['_orderByCalled']);}}function T_(_0x169733=null,_0x35cdbc){return new ya(_0x169733,_0x35cdbc);}class qd extends mt{constructor(_0x3deed5){super(),this['_limit']=_0x3deed5,this['type']='limitToFirst';}['_apply'](_0x76ee4e){if(_0x76ee4e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x76ee4e['_repo'],_0x76ee4e['_path'],Yh(_0x76ee4e['_queryParams'],this['_limit']),_0x76ee4e['_orderByCalled']);}}function S_(_0x398d5d){if(Math['floor'](_0x398d5d)!==_0x398d5d||_0x398d5d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x398d5d);}class zd extends mt{constructor(_0x3827de){super(),this['_path']=_0x3827de,this['type']='orderByChild';}['_apply'](_0xfee6b9){_a(_0xfee6b9,'orderByChild');const _0x42b95e=new C(this['_path']);if(v(_0x42b95e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x406920=new Ji(_0x42b95e),_0x553763=xo(_0xfee6b9['_queryParams'],_0x406920);return Yn(_0x553763),new Ae(_0xfee6b9['_repo'],_0xfee6b9['_path'],_0x553763,!0x0);}}function b_(_0x183cf4){if(_0x183cf4==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x183cf4==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x183cf4==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x183cf4),new zd(_0x183cf4);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5b4641){_a(_0x5b4641,'orderByKey');const _0x26fba9=xo(_0x5b4641['_queryParams'],ve);return Yn(_0x26fba9),new Ae(_0x5b4641['_repo'],_0x5b4641['_path'],_0x26fba9,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x34c165,_0x17d582){super(),this['_value']=_0x34c165,this['_key']=_0x17d582,this['type']='equalTo';}['_apply'](_0x4c1c48){if(He('equalTo',this['_value'],_0x4c1c48['_path'],!0x1),_0x4c1c48['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4c1c48['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4c1c48));}}function A_(_0x497a6d,_0x1c10b1){return new Kd(_0x497a6d,_0x1c10b1);}function k_(_0x2a6b8d,..._0x1f837b){let _0x124bd0=P(_0x2a6b8d);for(const _0x5601d2 of _0x1f837b)_0x124bd0=_0x5601d2['_apply'](_0x124bd0);return _0x124bd0;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0xc1198d,_0x34dee8,_0x592331,_0xd33349){const _0x337542=_0x34dee8['lastIndexOf'](':'),_0x4bf51c=_0x34dee8['substring'](0x0,_0x337542),_0x1c76bb=qt(_0x4bf51c);_0xc1198d['repoInfo_']=new yo(_0x34dee8,_0x1c76bb,_0xc1198d['repoInfo_']['namespace'],_0xc1198d['repoInfo_']['webSocketOnly'],_0xc1198d['repoInfo_']['nodeAdmin'],_0xc1198d['repoInfo_']['persistenceKey'],_0xc1198d['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x592331),_0xd33349&&(_0xc1198d['authTokenProvider_']=_0xd33349);}function Xd(_0x426342,_0x120e44,_0x34f604,_0x49be12,_0x3ffbce){let _0x2a9a1e=_0x49be12||_0x426342['options']['databaseURL'];_0x2a9a1e===void 0x0&&(_0x426342['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x426342['options']['projectId']),_0x2a9a1e=_0x426342['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x5b0309=vr(_0x2a9a1e,_0x3ffbce),_0x33d699=_0x5b0309['repoInfo'],_0x18b5fc;typeof process<'u'&&Bs&&(_0x18b5fc=Bs[Yd]),_0x18b5fc?(_0x2a9a1e='http://'+_0x18b5fc+'?ns='+_0x33d699['namespace'],_0x5b0309=vr(_0x2a9a1e,_0x3ffbce),_0x33d699=_0x5b0309['repoInfo']):_0x5b0309['repoInfo']['secure'];const _0x4970f5=new eh(_0x426342['name'],_0x426342['options'],_0x120e44);_d('Invalid\x20Firebase\x20Database\x20URL',_0x5b0309),v(_0x5b0309['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xab473b=ef(_0x33d699,_0x426342,_0x4970f5,new Zl(_0x426342,_0x34f604));return new tf(_0xab473b,_0x426342);}function Zd(_0x219702,_0x2e5ca8){const _0xfdaa9f=Di[_0x2e5ca8];(!_0xfdaa9f||_0xfdaa9f[_0x219702['key']]!==_0x219702)&&ae('Database\x20'+_0x2e5ca8+'('+_0x219702['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x219702),delete _0xfdaa9f[_0x219702['key']];}function ef(_0x17f15f,_0xce224,_0x44a515,_0x494782){let _0x1f7231=Di[_0xce224['name']];_0x1f7231||(_0x1f7231={},Di[_0xce224['name']]=_0x1f7231);let _0x305aa1=_0x1f7231[_0x17f15f['toURLString']()];return _0x305aa1&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x305aa1=new vd(_0x17f15f,Qd,_0x44a515,_0x494782),_0x1f7231[_0x17f15f['toURLString']()]=_0x305aa1,_0x305aa1;}class tf{constructor(_0x4e879f,_0x3130a0){this['_repoInternal']=_0x4e879f,this['app']=_0x3130a0,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3e8ce1){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3e8ce1+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x5c8aa7=Zr(),_0x1e40da){const _0x4d2ff4=Hi(_0x5c8aa7,'database')['getImmediate']({'identifier':_0x1e40da});if(!_0x4d2ff4['_instanceStarted']){const _0x4e07bc=hc('database');_0x4e07bc&&nf(_0x4d2ff4,..._0x4e07bc);}return _0x4d2ff4;}function nf(_0x45f487,_0x65b8cf,_0x4bf7b1,_0x3d7eb1={}){_0x45f487=P(_0x45f487),_0x45f487['_checkNotDeleted']('useEmulator');const _0x429bc2=_0x65b8cf+':'+_0x4bf7b1,_0x3126ff=_0x45f487['_repoInternal'];if(_0x45f487['_instanceStarted']){if(_0x429bc2===_0x45f487['_repoInternal']['repoInfo_']['host']&&xe(_0x3d7eb1,_0x3126ff['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x361bde;if(_0x3126ff['repoInfo_']['nodeAdmin'])_0x3d7eb1['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x361bde=new an(an['OWNER']);else{if(_0x3d7eb1['mockUserToken']){const _0x120047=typeof _0x3d7eb1['mockUserToken']=='string'?_0x3d7eb1['mockUserToken']:uc(_0x3d7eb1['mockUserToken'],_0x45f487['app']['options']['projectId']);_0x361bde=new an(_0x120047);}}qt(_0x65b8cf)&&Qr(_0x65b8cf),Jd(_0x3126ff,_0x429bc2,_0x3d7eb1,_0x361bde);}function N_(_0xfb66ff){_0xfb66ff=P(_0xfb66ff),_0xfb66ff['_checkNotDeleted']('goOffline'),ha(_0xfb66ff['_repo']);}function O_(_0x20b5ed){_0x20b5ed=P(_0x20b5ed),_0x20b5ed['_checkNotDeleted']('goOnline'),Nd(_0x20b5ed['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x39b05c){Ul(dt),st(new Fe('database',(_0x390866,{instanceIdentifier:_0x99e5d0})=>{const _0x44be25=_0x390866['getProvider']('app')['getImmediate'](),_0xb4bfb5=_0x390866['getProvider']('auth-internal'),_0x879876=_0x390866['getProvider']('app-check-internal');return Xd(_0x44be25,_0xb4bfb5,_0x879876,_0x99e5d0);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x39b05c),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x425353,_0x571261){this['committed']=_0x425353,this['snapshot']=_0x571261;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x2fede4,_0x17c540,_0x1f5979){if(_0x2fede4=P(_0x2fede4),Me('Reference.transaction',_0x2fede4['_path']),_0x2fede4['key']==='.length'||_0x2fede4['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2fede4['key']+'\x20is\x20a\x20read-only\x20object.';const _0x156010=!0x0,_0x257a55=new H(),_0x2f1bbf=(_0x4c538f,_0x5d4ff1,_0x137925)=>{let _0x588cb4=null;_0x4c538f?_0x257a55['reject'](_0x4c538f):(_0x588cb4=new lt(_0x137925,new ee(_0x2fede4['_repo'],_0x2fede4['_path']),R),_0x257a55['resolve'](new of(_0x5d4ff1,_0x588cb4)));},_0x134d40=Gd(_0x2fede4,()=>{});return Od(_0x2fede4['_repo'],_0x2fede4['_path'],_0x17c540,_0x2f1bbf,_0x134d40,_0x156010),_0x257a55['promise'];}se['prototype']['simpleListen']=function(_0x265126,_0x250681){this['sendRequest']('q',{'p':_0x265126},_0x250681);},se['prototype']['echo']=function(_0x1b2360,_0x2a5c5e){this['sendRequest']('echo',{'d':_0x1b2360},_0x2a5c5e);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5ce531,..._0x9d314c){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5ce531,..._0x9d314c);}function cn(_0x1fb90e,..._0x382658){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x1fb90e,..._0x382658);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5ca439,..._0x3e032f){throw ws(_0x5ca439,..._0x3e032f);}function X(_0x2e4cad,..._0x3f6af3){return ws(_0x2e4cad,..._0x3f6af3);}function Ia(_0x3d000e,_0x4570da,_0x8e3b48){const _0x1cab3e={...af(),[_0x4570da]:_0x8e3b48};return new Gt('auth','Firebase',_0x1cab3e)['create'](_0x4570da,{'appName':_0x3d000e['name']});}function re(_0x270afc){return Ia(_0x270afc,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4cb808,..._0x29f979){if(typeof _0x4cb808!='string'){const _0x299182=_0x29f979[0x0],_0x295b97=[..._0x29f979['slice'](0x1)];return _0x295b97[0x0]&&(_0x295b97[0x0]['appName']=_0x4cb808['name']),_0x4cb808['_errorFactory']['create'](_0x299182,..._0x295b97);}return Ea['create'](_0x4cb808,..._0x29f979);}function m(_0x547d0c,_0x4af7f4,..._0x9ceeb6){if(!_0x547d0c)throw ws(_0x4af7f4,..._0x9ceeb6);}function ne(_0x556c23){const _0x3295de='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x556c23;throw cn(_0x3295de),new Error(_0x3295de);}function ce(_0x264eb7,_0x1c3640){_0x264eb7||ne(_0x1c3640);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3f8e57;return typeof self<'u'&&((_0x3f8e57=self['location'])==null?void 0x0:_0x3f8e57['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x330970;return typeof self<'u'&&((_0x330970=self['location'])==null?void 0x0:_0x330970['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1d8c07=navigator;return _0x1d8c07['languages']&&_0x1d8c07['languages'][0x0]||_0x1d8c07['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x271a5a,_0x41dc4c){this['shortDelay']=_0x271a5a,this['longDelay']=_0x41dc4c,ce(_0x41dc4c>_0x271a5a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x231c6b,_0x916730){ce(_0x231c6b['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5531fd}=_0x231c6b['emulator'];return _0x916730?''+_0x5531fd+(_0x916730['startsWith']('/')?_0x916730['slice'](0x1):_0x916730):_0x5531fd;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x85d229,_0x2dd06d,_0x9be3f5){this['fetchImpl']=_0x85d229,_0x2dd06d&&(this['headersImpl']=_0x2dd06d),_0x9be3f5&&(this['responseImpl']=_0x9be3f5);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x22a772,_0x1203f8){return _0x22a772['tenantId']&&!_0x1203f8['tenantId']?{..._0x1203f8,'tenantId':_0x22a772['tenantId']}:_0x1203f8;}async function Pe(_0x7cafd1,_0x1d541a,_0x164af5,_0x5b7ca6,_0x2f08c0={}){return Ca(_0x7cafd1,_0x2f08c0,async()=>{let _0xcee662={},_0x12c125={};_0x5b7ca6&&(_0x1d541a==='GET'?_0x12c125=_0x5b7ca6:_0xcee662={'body':JSON['stringify'](_0x5b7ca6)});const _0x22b264=ut({..._0x12c125,'key':_0x7cafd1['config']['apiKey']})['slice'](0x1),_0x1876af=await _0x7cafd1['_getAdditionalHeaders']();_0x1876af['Content-Type']='application/json',_0x7cafd1['languageCode']&&(_0x1876af['X-Firebase-Locale']=_0x7cafd1['languageCode']);const _0x2d7e73={'method':_0x1d541a,'headers':_0x1876af,..._0xcee662};return dc()||(_0x2d7e73['referrerPolicy']='strict-origin-when-cross-origin'),_0x7cafd1['emulatorConfig']&&qt(_0x7cafd1['emulatorConfig']['host'])&&(_0x2d7e73['credentials']='include'),wa['fetch']()(await Ta(_0x7cafd1,_0x7cafd1['config']['apiHost'],_0x164af5,_0x22b264),_0x2d7e73);});}async function Ca(_0x51cffb,_0x7b938c,_0x3b5788){_0x51cffb['_canInitEmulator']=!0x1;const _0x57d5a3={...df,..._0x7b938c};try{const _0x2195e3=new gf(_0x51cffb),_0x3f7348=await Promise['race']([_0x3b5788(),_0x2195e3['promise']]);_0x2195e3['clearNetworkTimeout']();const _0x5f753e=await _0x3f7348['json']();if('needConfirmation'in _0x5f753e)throw on(_0x51cffb,'account-exists-with-different-credential',_0x5f753e);if(_0x3f7348['ok']&&!('errorMessage'in _0x5f753e))return _0x5f753e;{const _0x1b5b0d=_0x3f7348['ok']?_0x5f753e['errorMessage']:_0x5f753e['error']['message'],[_0x162e49,_0x172d27]=_0x1b5b0d['split']('\x20:\x20');if(_0x162e49==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x51cffb,'credential-already-in-use',_0x5f753e);if(_0x162e49==='EMAIL_EXISTS')throw on(_0x51cffb,'email-already-in-use',_0x5f753e);if(_0x162e49==='USER_DISABLED')throw on(_0x51cffb,'user-disabled',_0x5f753e);const _0x1757a9=_0x57d5a3[_0x162e49]||_0x162e49['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x172d27)throw Ia(_0x51cffb,_0x1757a9,_0x172d27);Y(_0x51cffb,_0x1757a9);}}catch(_0xc95a33){if(_0xc95a33 instanceof Re)throw _0xc95a33;Y(_0x51cffb,'network-request-failed',{'message':String(_0xc95a33)});}}async function en(_0x258e75,_0x283289,_0x4c9feb,_0x23ca2d,_0x5bed41={}){const _0x34f970=await Pe(_0x258e75,_0x283289,_0x4c9feb,_0x23ca2d,_0x5bed41);return'mfaPendingCredential'in _0x34f970&&Y(_0x258e75,'multi-factor-auth-required',{'_serverResponse':_0x34f970}),_0x34f970;}async function Ta(_0x11b09f,_0x2bcb51,_0x5155e4,_0xa70d48){const _0x7e2f95=''+_0x2bcb51+_0x5155e4+'?'+_0xa70d48,_0x1c0a0b=_0x11b09f,_0x51a3e7=_0x1c0a0b['config']['emulator']?Cs(_0x11b09f['config'],_0x7e2f95):_0x11b09f['config']['apiScheme']+'://'+_0x7e2f95;return ff['includes'](_0x5155e4)&&(await _0x1c0a0b['_persistenceManagerAvailable'],_0x1c0a0b['_getPersistenceType']()==='COOKIE')?_0x1c0a0b['_getPersistence']()['_getFinalTarget'](_0x51a3e7)['toString']():_0x51a3e7;}function _f(_0x69022a){switch(_0x69022a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x53db30){this['auth']=_0x53db30,this['timer']=null,this['promise']=new Promise((_0x152725,_0x1a517a)=>{this['timer']=setTimeout(()=>_0x1a517a(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x502d84,_0x324547,_0x3be845){const _0x4bbf11={'appName':_0x502d84['name']};_0x3be845['email']&&(_0x4bbf11['email']=_0x3be845['email']),_0x3be845['phoneNumber']&&(_0x4bbf11['phoneNumber']=_0x3be845['phoneNumber']);const _0x541c7c=X(_0x502d84,_0x324547,_0x4bbf11);return _0x541c7c['customData']['_tokenResponse']=_0x3be845,_0x541c7c;}function wr(_0x333cc4){return _0x333cc4!==void 0x0&&_0x333cc4['enterprise']!==void 0x0;}class mf{constructor(_0x265a1a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x265a1a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x265a1a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x265a1a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x48c053){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xa4806 of this['recaptchaEnforcementState'])if(_0xa4806['provider']&&_0xa4806['provider']===_0x48c053)return _f(_0xa4806['enforcementState']);return null;}['isProviderEnabled'](_0x445736){return this['getProviderEnforcementState'](_0x445736)==='ENFORCE'||this['getProviderEnforcementState'](_0x445736)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x3cdb9f,_0x48334a){return Pe(_0x3cdb9f,'GET','/v2/recaptchaConfig',ke(_0x3cdb9f,_0x48334a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x31c70c,_0x3764bf){return Pe(_0x31c70c,'POST','/v1/accounts:delete',_0x3764bf);}async function Pn(_0x1e05e5,_0x334e9d){return Pe(_0x1e05e5,'POST','/v1/accounts:lookup',_0x334e9d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1e0f63){if(_0x1e0f63)try{const _0x2912ac=new Date(Number(_0x1e0f63));if(!isNaN(_0x2912ac['getTime']()))return _0x2912ac['toUTCString']();}catch{}}async function Ef(_0x4039d9,_0x7646ad=!0x1){const _0x366955=P(_0x4039d9),_0x33cd0d=await _0x366955['getIdToken'](_0x7646ad),_0x43276f=Ts(_0x33cd0d);m(_0x43276f&&_0x43276f['exp']&&_0x43276f['auth_time']&&_0x43276f['iat'],_0x366955['auth'],'internal-error');const _0x124000=typeof _0x43276f['firebase']=='object'?_0x43276f['firebase']:void 0x0,_0x6290f=_0x124000==null?void 0x0:_0x124000['sign_in_provider'];return{'claims':_0x43276f,'token':_0x33cd0d,'authTime':Pt(fi(_0x43276f['auth_time'])),'issuedAtTime':Pt(fi(_0x43276f['iat'])),'expirationTime':Pt(fi(_0x43276f['exp'])),'signInProvider':_0x6290f||null,'signInSecondFactor':(_0x124000==null?void 0x0:_0x124000['sign_in_second_factor'])||null};}function fi(_0x3194f0){return Number(_0x3194f0)*0x3e8;}function Ts(_0x3f181e){const [_0x642b50,_0x515200,_0x15046d]=_0x3f181e['split']('.');if(_0x642b50===void 0x0||_0x515200===void 0x0||_0x15046d===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x433ef2=fn(_0x515200);return _0x433ef2?JSON['parse'](_0x433ef2):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3e08ee){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3e08ee==null?void 0x0:_0x3e08ee['toString']()),null;}}function Cr(_0xd0fab4){const _0x4e4fd0=Ts(_0xd0fab4);return m(_0x4e4fd0,'internal-error'),m(typeof _0x4e4fd0['exp']<'u','internal-error'),m(typeof _0x4e4fd0['iat']<'u','internal-error'),Number(_0x4e4fd0['exp'])-Number(_0x4e4fd0['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x5d2a46,_0x5ab99c,_0x57bf2e=!0x1){if(_0x57bf2e)return _0x5ab99c;try{return await _0x5ab99c;}catch(_0x4874c7){throw _0x4874c7 instanceof Re&&If(_0x4874c7)&&_0x5d2a46['auth']['currentUser']===_0x5d2a46&&await _0x5d2a46['auth']['signOut'](),_0x4874c7;}}function If({code:_0x408ecd}){return _0x408ecd==='auth/user-disabled'||_0x408ecd==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5d6658){this['user']=_0x5d6658,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x3aeffd){if(_0x3aeffd){const _0x32c1cf=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x32c1cf;}else{this['errorBackoff']=0x7530;const _0x35a43f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x35a43f);}}['schedule'](_0x3e9259=!0x1){if(!this['isRunning'])return;const _0x3d664c=this['getInterval'](_0x3e9259);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3d664c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2520eb){(_0x2520eb==null?void 0x0:_0x2520eb['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x5b8db7,_0x3479a1){this['createdAt']=_0x5b8db7,this['lastLoginAt']=_0x3479a1,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x369d70){this['createdAt']=_0x369d70['createdAt'],this['lastLoginAt']=_0x369d70['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2bc933){var _0x3f8502;const _0x1547de=_0x2bc933['auth'],_0x2e5281=await _0x2bc933['getIdToken'](),_0x58887e=await Ht(_0x2bc933,Pn(_0x1547de,{'idToken':_0x2e5281}));m(_0x58887e==null?void 0x0:_0x58887e['users']['length'],_0x1547de,'internal-error');const _0x382f8b=_0x58887e['users'][0x0];_0x2bc933['_notifyReloadListener'](_0x382f8b);const _0x3ed52d=(_0x3f8502=_0x382f8b['providerUserInfo'])!=null&&_0x3f8502['length']?Sa(_0x382f8b['providerUserInfo']):[],_0x348c6b=Tf(_0x2bc933['providerData'],_0x3ed52d),_0x310da5=_0x2bc933['isAnonymous'],_0x25342d=!(_0x2bc933['email']&&_0x382f8b['passwordHash'])&&!(_0x348c6b!=null&&_0x348c6b['length']),_0x2fc69d=_0x310da5?_0x25342d:!0x1,_0x2143c5={'uid':_0x382f8b['localId'],'displayName':_0x382f8b['displayName']||null,'photoURL':_0x382f8b['photoUrl']||null,'email':_0x382f8b['email']||null,'emailVerified':_0x382f8b['emailVerified']||!0x1,'phoneNumber':_0x382f8b['phoneNumber']||null,'tenantId':_0x382f8b['tenantId']||null,'providerData':_0x348c6b,'metadata':new Li(_0x382f8b['createdAt'],_0x382f8b['lastLoginAt']),'isAnonymous':_0x2fc69d};Object['assign'](_0x2bc933,_0x2143c5);}async function Cf(_0x20d061){const _0x229d57=P(_0x20d061);await Nn(_0x229d57),await _0x229d57['auth']['_persistUserIfCurrent'](_0x229d57),_0x229d57['auth']['_notifyListenersIfCurrent'](_0x229d57);}function Tf(_0x180233,_0x3269a6){return[..._0x180233['filter'](_0xb273e0=>!_0x3269a6['some'](_0x3ab7ac=>_0x3ab7ac['providerId']===_0xb273e0['providerId'])),..._0x3269a6];}function Sa(_0x315726){return _0x315726['map'](({providerId:_0x11ff59,..._0x2f345b})=>({'providerId':_0x11ff59,'uid':_0x2f345b['rawId']||'','displayName':_0x2f345b['displayName']||null,'email':_0x2f345b['email']||null,'phoneNumber':_0x2f345b['phoneNumber']||null,'photoURL':_0x2f345b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x3d051f,_0x44c341){const _0x533b64=await Ca(_0x3d051f,{},async()=>{const _0x4667f4=ut({'grant_type':'refresh_token','refresh_token':_0x44c341})['slice'](0x1),{tokenApiHost:_0x12c3a6,apiKey:_0x401725}=_0x3d051f['config'],_0x28d86f=await Ta(_0x3d051f,_0x12c3a6,'/v1/token','key='+_0x401725),_0x3107f6=await _0x3d051f['_getAdditionalHeaders']();_0x3107f6['Content-Type']='application/x-www-form-urlencoded';const _0x75ceb1={'method':'POST','headers':_0x3107f6,'body':_0x4667f4};return _0x3d051f['emulatorConfig']&&qt(_0x3d051f['emulatorConfig']['host'])&&(_0x75ceb1['credentials']='include'),wa['fetch']()(_0x28d86f,_0x75ceb1);});return{'accessToken':_0x533b64['access_token'],'expiresIn':_0x533b64['expires_in'],'refreshToken':_0x533b64['refresh_token']};}async function bf(_0x461661,_0x400265){return Pe(_0x461661,'POST','/v2/accounts:revokeToken',ke(_0x461661,_0x400265));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xf3156f){m(_0xf3156f['idToken'],'internal-error'),m(typeof _0xf3156f['idToken']<'u','internal-error'),m(typeof _0xf3156f['refreshToken']<'u','internal-error');const _0x3d6326='expiresIn'in _0xf3156f&&typeof _0xf3156f['expiresIn']<'u'?Number(_0xf3156f['expiresIn']):Cr(_0xf3156f['idToken']);this['updateTokensAndExpiration'](_0xf3156f['idToken'],_0xf3156f['refreshToken'],_0x3d6326);}['updateFromIdToken'](_0x2ac6f0){m(_0x2ac6f0['length']!==0x0,'internal-error');const _0x5622bd=Cr(_0x2ac6f0);this['updateTokensAndExpiration'](_0x2ac6f0,null,_0x5622bd);}async['getToken'](_0x395b0b,_0x446e70=!0x1){return!_0x446e70&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x395b0b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x395b0b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2b3831,_0x5f0b3a){const {accessToken:_0xacc756,refreshToken:_0x516263,expiresIn:_0x18b2da}=await Sf(_0x2b3831,_0x5f0b3a);this['updateTokensAndExpiration'](_0xacc756,_0x516263,Number(_0x18b2da));}['updateTokensAndExpiration'](_0x4c5416,_0x590fab,_0xbc0929){this['refreshToken']=_0x590fab||null,this['accessToken']=_0x4c5416||null,this['expirationTime']=Date['now']()+_0xbc0929*0x3e8;}static['fromJSON'](_0x1b7987,_0x4119a1){const {refreshToken:_0x569a39,accessToken:_0xbb61e8,expirationTime:_0x4ab849}=_0x4119a1,_0x47d29e=new et();return _0x569a39&&(m(typeof _0x569a39=='string','internal-error',{'appName':_0x1b7987}),_0x47d29e['refreshToken']=_0x569a39),_0xbb61e8&&(m(typeof _0xbb61e8=='string','internal-error',{'appName':_0x1b7987}),_0x47d29e['accessToken']=_0xbb61e8),_0x4ab849&&(m(typeof _0x4ab849=='number','internal-error',{'appName':_0x1b7987}),_0x47d29e['expirationTime']=_0x4ab849),_0x47d29e;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x211f8e){this['accessToken']=_0x211f8e['accessToken'],this['refreshToken']=_0x211f8e['refreshToken'],this['expirationTime']=_0x211f8e['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x36b04d,_0x53e0b7){m(typeof _0x36b04d=='string'||typeof _0x36b04d>'u','internal-error',{'appName':_0x53e0b7});}class j{constructor({uid:_0x5068ff,auth:_0x1a0d66,stsTokenManager:_0x1020cf,..._0x145ee0}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5068ff,this['auth']=_0x1a0d66,this['stsTokenManager']=_0x1020cf,this['accessToken']=_0x1020cf['accessToken'],this['displayName']=_0x145ee0['displayName']||null,this['email']=_0x145ee0['email']||null,this['emailVerified']=_0x145ee0['emailVerified']||!0x1,this['phoneNumber']=_0x145ee0['phoneNumber']||null,this['photoURL']=_0x145ee0['photoURL']||null,this['isAnonymous']=_0x145ee0['isAnonymous']||!0x1,this['tenantId']=_0x145ee0['tenantId']||null,this['providerData']=_0x145ee0['providerData']?[..._0x145ee0['providerData']]:[],this['metadata']=new Li(_0x145ee0['createdAt']||void 0x0,_0x145ee0['lastLoginAt']||void 0x0);}async['getIdToken'](_0x410dc8){const _0x2bf070=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x410dc8));return m(_0x2bf070,this['auth'],'internal-error'),this['accessToken']!==_0x2bf070&&(this['accessToken']=_0x2bf070,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2bf070;}['getIdTokenResult'](_0x77c2e9){return Ef(this,_0x77c2e9);}['reload'](){return Cf(this);}['_assign'](_0x2ff09a){this!==_0x2ff09a&&(m(this['uid']===_0x2ff09a['uid'],this['auth'],'internal-error'),this['displayName']=_0x2ff09a['displayName'],this['photoURL']=_0x2ff09a['photoURL'],this['email']=_0x2ff09a['email'],this['emailVerified']=_0x2ff09a['emailVerified'],this['phoneNumber']=_0x2ff09a['phoneNumber'],this['isAnonymous']=_0x2ff09a['isAnonymous'],this['tenantId']=_0x2ff09a['tenantId'],this['providerData']=_0x2ff09a['providerData']['map'](_0x33f7f6=>({..._0x33f7f6})),this['metadata']['_copy'](_0x2ff09a['metadata']),this['stsTokenManager']['_assign'](_0x2ff09a['stsTokenManager']));}['_clone'](_0x18dd7f){const _0x43fa77=new j({...this,'auth':_0x18dd7f,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x43fa77['metadata']['_copy'](this['metadata']),_0x43fa77;}['_onReload'](_0x54b9cb){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x54b9cb,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2c0960){this['reloadListener']?this['reloadListener'](_0x2c0960):this['reloadUserInfo']=_0x2c0960;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x114e44,_0xbc5ed0=!0x1){let _0x196b64=!0x1;_0x114e44['idToken']&&_0x114e44['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x114e44),_0x196b64=!0x0),_0xbc5ed0&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x196b64&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x528e10=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x528e10})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4679e2=>({..._0x4679e2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2ab99a,_0x1f94d9){const _0x3ec325=_0x1f94d9['displayName']??void 0x0,_0x1bdbef=_0x1f94d9['email']??void 0x0,_0x147cb0=_0x1f94d9['phoneNumber']??void 0x0,_0x9095e4=_0x1f94d9['photoURL']??void 0x0,_0x17d5a5=_0x1f94d9['tenantId']??void 0x0,_0x66d627=_0x1f94d9['_redirectEventId']??void 0x0,_0x5552f6=_0x1f94d9['createdAt']??void 0x0,_0x40d6a0=_0x1f94d9['lastLoginAt']??void 0x0,{uid:_0xb01fcf,emailVerified:_0x836908,isAnonymous:_0x20c266,providerData:_0x55ac36,stsTokenManager:_0x57924a}=_0x1f94d9;m(_0xb01fcf&&_0x57924a,_0x2ab99a,'internal-error');const _0xf628f3=et['fromJSON'](this['name'],_0x57924a);m(typeof _0xb01fcf=='string',_0x2ab99a,'internal-error'),le(_0x3ec325,_0x2ab99a['name']),le(_0x1bdbef,_0x2ab99a['name']),m(typeof _0x836908=='boolean',_0x2ab99a,'internal-error'),m(typeof _0x20c266=='boolean',_0x2ab99a,'internal-error'),le(_0x147cb0,_0x2ab99a['name']),le(_0x9095e4,_0x2ab99a['name']),le(_0x17d5a5,_0x2ab99a['name']),le(_0x66d627,_0x2ab99a['name']),le(_0x5552f6,_0x2ab99a['name']),le(_0x40d6a0,_0x2ab99a['name']);const _0xd7d1e2=new j({'uid':_0xb01fcf,'auth':_0x2ab99a,'email':_0x1bdbef,'emailVerified':_0x836908,'displayName':_0x3ec325,'isAnonymous':_0x20c266,'photoURL':_0x9095e4,'phoneNumber':_0x147cb0,'tenantId':_0x17d5a5,'stsTokenManager':_0xf628f3,'createdAt':_0x5552f6,'lastLoginAt':_0x40d6a0});return _0x55ac36&&Array['isArray'](_0x55ac36)&&(_0xd7d1e2['providerData']=_0x55ac36['map'](_0x45f89b=>({..._0x45f89b}))),_0x66d627&&(_0xd7d1e2['_redirectEventId']=_0x66d627),_0xd7d1e2;}static async['_fromIdTokenResponse'](_0x5b7cff,_0x24dc39,_0x42885b=!0x1){const _0x1deb41=new et();_0x1deb41['updateFromServerResponse'](_0x24dc39);const _0x4190e4=new j({'uid':_0x24dc39['localId'],'auth':_0x5b7cff,'stsTokenManager':_0x1deb41,'isAnonymous':_0x42885b});return await Nn(_0x4190e4),_0x4190e4;}static async['_fromGetAccountInfoResponse'](_0x38a7c8,_0x236e8f,_0x4f6c6c){const _0x111cda=_0x236e8f['users'][0x0];m(_0x111cda['localId']!==void 0x0,'internal-error');const _0x362795=_0x111cda['providerUserInfo']!==void 0x0?Sa(_0x111cda['providerUserInfo']):[],_0x35161d=!(_0x111cda['email']&&_0x111cda['passwordHash'])&&!(_0x362795!=null&&_0x362795['length']),_0xae75e3=new et();_0xae75e3['updateFromIdToken'](_0x4f6c6c);const _0x368b97=new j({'uid':_0x111cda['localId'],'auth':_0x38a7c8,'stsTokenManager':_0xae75e3,'isAnonymous':_0x35161d}),_0x50b169={'uid':_0x111cda['localId'],'displayName':_0x111cda['displayName']||null,'photoURL':_0x111cda['photoUrl']||null,'email':_0x111cda['email']||null,'emailVerified':_0x111cda['emailVerified']||!0x1,'phoneNumber':_0x111cda['phoneNumber']||null,'tenantId':_0x111cda['tenantId']||null,'providerData':_0x362795,'metadata':new Li(_0x111cda['createdAt'],_0x111cda['lastLoginAt']),'isAnonymous':!(_0x111cda['email']&&_0x111cda['passwordHash'])&&!(_0x362795!=null&&_0x362795['length'])};return Object['assign'](_0x368b97,_0x50b169),_0x368b97;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x888c88){ce(_0x888c88 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1ba7c0=Tr['get'](_0x888c88);return _0x1ba7c0?(ce(_0x1ba7c0 instanceof _0x888c88,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1ba7c0):(_0x1ba7c0=new _0x888c88(),Tr['set'](_0x888c88,_0x1ba7c0),_0x1ba7c0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1f9493,_0x108abb){this['storage'][_0x1f9493]=_0x108abb;}async['_get'](_0x42e7fb){const _0x23eb9d=this['storage'][_0x42e7fb];return _0x23eb9d===void 0x0?null:_0x23eb9d;}async['_remove'](_0x3981ff){delete this['storage'][_0x3981ff];}['_addListener'](_0x25b8b6,_0x22e317){}['_removeListener'](_0x3ddbc8,_0x12e116){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0xe94097,_0x515d0c,_0x51d5f7){return'firebase:'+_0xe94097+':'+_0x515d0c+':'+_0x51d5f7;}class tt{constructor(_0x451b59,_0x146ca9,_0x4f27a3){this['persistence']=_0x451b59,this['auth']=_0x146ca9,this['userKey']=_0x4f27a3;const {config:_0x5e8093,name:_0x3f51b1}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x5e8093['apiKey'],_0x3f51b1),this['fullPersistenceKey']=ln('persistence',_0x5e8093['apiKey'],_0x3f51b1),this['boundEventHandler']=_0x146ca9['_onStorageEvent']['bind'](_0x146ca9),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x59355e){return this['persistence']['_set'](this['fullUserKey'],_0x59355e['toJSON']());}async['getCurrentUser'](){const _0x56d6bf=await this['persistence']['_get'](this['fullUserKey']);if(!_0x56d6bf)return null;if(typeof _0x56d6bf=='string'){const _0x5a6614=await Pn(this['auth'],{'idToken':_0x56d6bf})['catch'](()=>{});return _0x5a6614?j['_fromGetAccountInfoResponse'](this['auth'],_0x5a6614,_0x56d6bf):null;}return j['_fromJSON'](this['auth'],_0x56d6bf);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x258601){if(this['persistence']===_0x258601)return;const _0x1982c2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x258601,_0x1982c2)return this['setCurrentUser'](_0x1982c2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x16c23d,_0x4428ed,_0x1c668a='authUser'){if(!_0x4428ed['length'])return new tt(ie(Sr),_0x16c23d,_0x1c668a);const _0x2a9088=(await Promise['all'](_0x4428ed['map'](async _0x30854c=>{if(await _0x30854c['_isAvailable']())return _0x30854c;})))['filter'](_0x30f365=>_0x30f365);let _0x5a68ad=_0x2a9088[0x0]||ie(Sr);const _0x531630=ln(_0x1c668a,_0x16c23d['config']['apiKey'],_0x16c23d['name']);let _0x155f96=null;for(const _0x3e40c7 of _0x4428ed)try{const _0x5a2ed8=await _0x3e40c7['_get'](_0x531630);if(_0x5a2ed8){let _0x1ae4c2;if(typeof _0x5a2ed8=='string'){const _0x14a0e0=await Pn(_0x16c23d,{'idToken':_0x5a2ed8})['catch'](()=>{});if(!_0x14a0e0)break;_0x1ae4c2=await j['_fromGetAccountInfoResponse'](_0x16c23d,_0x14a0e0,_0x5a2ed8);}else _0x1ae4c2=j['_fromJSON'](_0x16c23d,_0x5a2ed8);_0x3e40c7!==_0x5a68ad&&(_0x155f96=_0x1ae4c2),_0x5a68ad=_0x3e40c7;break;}}catch{}const _0x144026=_0x2a9088['filter'](_0x1b461b=>_0x1b461b['_shouldAllowMigration']);return!_0x5a68ad['_shouldAllowMigration']||!_0x144026['length']?new tt(_0x5a68ad,_0x16c23d,_0x1c668a):(_0x5a68ad=_0x144026[0x0],_0x155f96&&await _0x5a68ad['_set'](_0x531630,_0x155f96['toJSON']()),await Promise['all'](_0x4428ed['map'](async _0x59a6b5=>{if(_0x59a6b5!==_0x5a68ad)try{await _0x59a6b5['_remove'](_0x531630);}catch{}})),new tt(_0x5a68ad,_0x16c23d,_0x1c668a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5b9587){const _0x5aba2b=_0x5b9587['toLowerCase']();if(_0x5aba2b['includes']('opera/')||_0x5aba2b['includes']('opr/')||_0x5aba2b['includes']('opios/'))return'Opera';if(Pa(_0x5aba2b))return'IEMobile';if(_0x5aba2b['includes']('msie')||_0x5aba2b['includes']('trident/'))return'IE';if(_0x5aba2b['includes']('edge/'))return'Edge';if(Ra(_0x5aba2b))return'Firefox';if(_0x5aba2b['includes']('silk/'))return'Silk';if(Oa(_0x5aba2b))return'Blackberry';if(Da(_0x5aba2b))return'Webos';if(Aa(_0x5aba2b))return'Safari';if((_0x5aba2b['includes']('chrome/')||ka(_0x5aba2b))&&!_0x5aba2b['includes']('edge/'))return'Chrome';if(Na(_0x5aba2b))return'Android';{const _0x4b49e7=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x96ae46=_0x5b9587['match'](_0x4b49e7);if((_0x96ae46==null?void 0x0:_0x96ae46['length'])===0x2)return _0x96ae46[0x1];}return'Other';}function Ra(_0x14c660=W()){return/firefox\//i['test'](_0x14c660);}function Aa(_0x1654ad=W()){const _0xf60c96=_0x1654ad['toLowerCase']();return _0xf60c96['includes']('safari/')&&!_0xf60c96['includes']('chrome/')&&!_0xf60c96['includes']('crios/')&&!_0xf60c96['includes']('android');}function ka(_0x14218a=W()){return/crios\//i['test'](_0x14218a);}function Pa(_0x5e1297=W()){return/iemobile/i['test'](_0x5e1297);}function Na(_0x161da7=W()){return/android/i['test'](_0x161da7);}function Oa(_0x1bf2d9=W()){return/blackberry/i['test'](_0x1bf2d9);}function Da(_0x488f4a=W()){return/webos/i['test'](_0x488f4a);}function Ss(_0x39577c=W()){return/iphone|ipad|ipod/i['test'](_0x39577c)||/macintosh/i['test'](_0x39577c)&&/mobile/i['test'](_0x39577c);}function Rf(_0x3fdee6=W()){var _0x33489b;return Ss(_0x3fdee6)&&!!((_0x33489b=window['navigator'])!=null&&_0x33489b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2deb92=W()){return Ss(_0x2deb92)||Na(_0x2deb92)||Da(_0x2deb92)||Oa(_0x2deb92)||/windows phone/i['test'](_0x2deb92)||Pa(_0x2deb92);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x26d95e,_0x4f89ac=[]){let _0x89257b;switch(_0x26d95e){case'Browser':_0x89257b=br(W());break;case'Worker':_0x89257b=br(W())+'-'+_0x26d95e;break;default:_0x89257b=_0x26d95e;}const _0x5ce0d7=_0x4f89ac['length']?_0x4f89ac['join'](','):'FirebaseCore-web';return _0x89257b+'/JsCore/'+dt+'/'+_0x5ce0d7;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x509a5c){this['auth']=_0x509a5c,this['queue']=[];}['pushCallback'](_0x3444e2,_0x160288){const _0xb2bb19=_0x5d9f0f=>new Promise((_0x508310,_0x13a8d7)=>{try{const _0x837359=_0x3444e2(_0x5d9f0f);_0x508310(_0x837359);}catch(_0x37a27d){_0x13a8d7(_0x37a27d);}});_0xb2bb19['onAbort']=_0x160288,this['queue']['push'](_0xb2bb19);const _0x1781d5=this['queue']['length']-0x1;return()=>{this['queue'][_0x1781d5]=()=>Promise['resolve']();};}async['runMiddleware'](_0x40ca19){if(this['auth']['currentUser']===_0x40ca19)return;const _0x3ffa74=[];try{for(const _0x307f44 of this['queue'])await _0x307f44(_0x40ca19),_0x307f44['onAbort']&&_0x3ffa74['push'](_0x307f44['onAbort']);}catch(_0x59b7ee){_0x3ffa74['reverse']();for(const _0x2ac26d of _0x3ffa74)try{_0x2ac26d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x59b7ee==null?void 0x0:_0x59b7ee['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x126c1f,_0x532319={}){return Pe(_0x126c1f,'GET','/v2/passwordPolicy',ke(_0x126c1f,_0x532319));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x23b48e){var _0x499231;const _0x6f440a=_0x23b48e['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x6f440a['minPasswordLength']??Nf,_0x6f440a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x6f440a['maxPasswordLength']),_0x6f440a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x6f440a['containsLowercaseCharacter']),_0x6f440a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x6f440a['containsUppercaseCharacter']),_0x6f440a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x6f440a['containsNumericCharacter']),_0x6f440a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x6f440a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x23b48e['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x499231=_0x23b48e['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x499231['join'](''))??'',this['forceUpgradeOnSignin']=_0x23b48e['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x23b48e['schemaVersion'];}['validatePassword'](_0x4fe41b){const _0x2ba594={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4fe41b,_0x2ba594),this['validatePasswordCharacterOptions'](_0x4fe41b,_0x2ba594),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['meetsMinPasswordLength']??!0x0),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['meetsMaxPasswordLength']??!0x0),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['containsLowercaseLetter']??!0x0),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['containsUppercaseLetter']??!0x0),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['containsNumericCharacter']??!0x0),_0x2ba594['isValid']&&(_0x2ba594['isValid']=_0x2ba594['containsNonAlphanumericCharacter']??!0x0),_0x2ba594;}['validatePasswordLengthOptions'](_0x2b5635,_0x21ebaf){const _0xd76c82=this['customStrengthOptions']['minPasswordLength'],_0x405a76=this['customStrengthOptions']['maxPasswordLength'];_0xd76c82&&(_0x21ebaf['meetsMinPasswordLength']=_0x2b5635['length']>=_0xd76c82),_0x405a76&&(_0x21ebaf['meetsMaxPasswordLength']=_0x2b5635['length']<=_0x405a76);}['validatePasswordCharacterOptions'](_0x3cc03e,_0x5133b8){this['updatePasswordCharacterOptionsStatuses'](_0x5133b8,!0x1,!0x1,!0x1,!0x1);let _0x3ffa07;for(let _0x2e85be=0x0;_0x2e85be<_0x3cc03e['length'];_0x2e85be++)_0x3ffa07=_0x3cc03e['charAt'](_0x2e85be),this['updatePasswordCharacterOptionsStatuses'](_0x5133b8,_0x3ffa07>='a'&&_0x3ffa07<='z',_0x3ffa07>='A'&&_0x3ffa07<='Z',_0x3ffa07>='0'&&_0x3ffa07<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3ffa07));}['updatePasswordCharacterOptionsStatuses'](_0x142cf6,_0x5789da,_0x51efe9,_0x5eeca8,_0xe89ce3){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x142cf6['containsLowercaseLetter']||(_0x142cf6['containsLowercaseLetter']=_0x5789da)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x142cf6['containsUppercaseLetter']||(_0x142cf6['containsUppercaseLetter']=_0x51efe9)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x142cf6['containsNumericCharacter']||(_0x142cf6['containsNumericCharacter']=_0x5eeca8)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x142cf6['containsNonAlphanumericCharacter']||(_0x142cf6['containsNonAlphanumericCharacter']=_0xe89ce3));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x9540ef,_0x104a70,_0x19a8e8,_0x1e4db8){this['app']=_0x9540ef,this['heartbeatServiceProvider']=_0x104a70,this['appCheckServiceProvider']=_0x19a8e8,this['config']=_0x1e4db8,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x9540ef['name'],this['clientVersion']=_0x1e4db8['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x12029e=>this['_resolvePersistenceManagerAvailable']=_0x12029e);}['_initializeWithPersistence'](_0x4acc32,_0x5b8e73){return _0x5b8e73&&(this['_popupRedirectResolver']=ie(_0x5b8e73)),this['_initializationPromise']=this['queue'](async()=>{var _0x4fa4dc,_0x2b3a74,_0xd4fc39;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4acc32),(_0x4fa4dc=this['_resolvePersistenceManagerAvailable'])==null||_0x4fa4dc['call'](this),!this['_deleted'])){if((_0x2b3a74=this['_popupRedirectResolver'])!=null&&_0x2b3a74['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5b8e73),this['lastNotifiedUid']=((_0xd4fc39=this['currentUser'])==null?void 0x0:_0xd4fc39['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x5b9a61=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x5b9a61)){if(this['currentUser']&&_0x5b9a61&&this['currentUser']['uid']===_0x5b9a61['uid']){this['_currentUser']['_assign'](_0x5b9a61),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x5b9a61,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2e2ee9){try{const _0x599398=await Pn(this,{'idToken':_0x2e2ee9}),_0x20d6a4=await j['_fromGetAccountInfoResponse'](this,_0x599398,_0x2e2ee9);await this['directlySetCurrentUser'](_0x20d6a4);}catch(_0x20a59d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x20a59d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3f6ebc){var _0x3dbac1;if($(this['app'])){const _0x21e519=this['app']['settings']['authIdToken'];return _0x21e519?new Promise(_0x1e52c0=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x21e519)['then'](_0x1e52c0,_0x1e52c0));}):this['directlySetCurrentUser'](null);}const _0x471e1a=await this['assertedPersistence']['getCurrentUser']();let _0x328ec3=_0x471e1a,_0x3fa369=!0x1;if(_0x3f6ebc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5e8074=(_0x3dbac1=this['redirectUser'])==null?void 0x0:_0x3dbac1['_redirectEventId'],_0x129d88=_0x328ec3==null?void 0x0:_0x328ec3['_redirectEventId'],_0x3013f9=await this['tryRedirectSignIn'](_0x3f6ebc);(!_0x5e8074||_0x5e8074===_0x129d88)&&(_0x3013f9!=null&&_0x3013f9['user'])&&(_0x328ec3=_0x3013f9['user'],_0x3fa369=!0x0);}if(!_0x328ec3)return this['directlySetCurrentUser'](null);if(!_0x328ec3['_redirectEventId']){if(_0x3fa369)try{await this['beforeStateQueue']['runMiddleware'](_0x328ec3);}catch(_0xd67c7b){_0x328ec3=_0x471e1a,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xd67c7b));}return _0x328ec3?this['reloadAndSetCurrentUserOrClear'](_0x328ec3):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x328ec3['_redirectEventId']?this['directlySetCurrentUser'](_0x328ec3):this['reloadAndSetCurrentUserOrClear'](_0x328ec3);}async['tryRedirectSignIn'](_0x4c9c94){let _0x558ea2=null;try{_0x558ea2=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4c9c94,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x558ea2;}async['reloadAndSetCurrentUserOrClear'](_0x4c7b5b){try{await Nn(_0x4c7b5b);}catch(_0x11ea97){if((_0x11ea97==null?void 0x0:_0x11ea97['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4c7b5b);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x49633f){if($(this['app']))return Promise['reject'](re(this));const _0x83adc9=_0x49633f?P(_0x49633f):null;return _0x83adc9&&m(_0x83adc9['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x83adc9&&_0x83adc9['_clone'](this));}async['_updateCurrentUser'](_0x566d20,_0x5980e1=!0x1){if(!this['_deleted'])return _0x566d20&&m(this['tenantId']===_0x566d20['tenantId'],this,'tenant-id-mismatch'),_0x5980e1||await this['beforeStateQueue']['runMiddleware'](_0x566d20),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x566d20),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2062bc){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2062bc));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x265a98){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x141a76=this['_getPasswordPolicyInternal']();return _0x141a76['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x141a76['validatePassword'](_0x265a98);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x563d1=await Pf(this),_0x4b4b98=new Of(_0x563d1);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4b4b98:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4b4b98;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4f9d7d){this['_errorFactory']=new Gt('auth','Firebase',_0x4f9d7d());}['onAuthStateChanged'](_0x1bb20b,_0x486ad2,_0x477e75){return this['registerStateListener'](this['authStateSubscription'],_0x1bb20b,_0x486ad2,_0x477e75);}['beforeAuthStateChanged'](_0x41cd69,_0x42cb70){return this['beforeStateQueue']['pushCallback'](_0x41cd69,_0x42cb70);}['onIdTokenChanged'](_0x3ae1f1,_0x1e959c,_0x25d5a3){return this['registerStateListener'](this['idTokenSubscription'],_0x3ae1f1,_0x1e959c,_0x25d5a3);}['authStateReady'](){return new Promise((_0x5e13cd,_0x1aee28)=>{if(this['currentUser'])_0x5e13cd();else{const _0x161f06=this['onAuthStateChanged'](()=>{_0x161f06(),_0x5e13cd();},_0x1aee28);}});}async['revokeAccessToken'](_0x1cfdc6){if(this['currentUser']){const _0xe66fc4=await this['currentUser']['getIdToken'](),_0x1b8916={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1cfdc6,'idToken':_0xe66fc4};this['tenantId']!=null&&(_0x1b8916['tenantId']=this['tenantId']),await bf(this,_0x1b8916);}}['toJSON'](){var _0x2b54a8;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2b54a8=this['_currentUser'])==null?void 0x0:_0x2b54a8['toJSON']()};}async['_setRedirectUser'](_0x594274,_0x4ee639){const _0x856feb=await this['getOrInitRedirectPersistenceManager'](_0x4ee639);return _0x594274===null?_0x856feb['removeCurrentUser']():_0x856feb['setCurrentUser'](_0x594274);}async['getOrInitRedirectPersistenceManager'](_0x5930d9){if(!this['redirectPersistenceManager']){const _0x2a5711=_0x5930d9&&ie(_0x5930d9)||this['_popupRedirectResolver'];m(_0x2a5711,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x2a5711['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1bd2cd){var _0x354ec9,_0x12ee4a;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x354ec9=this['_currentUser'])==null?void 0x0:_0x354ec9['_redirectEventId'])===_0x1bd2cd?this['_currentUser']:((_0x12ee4a=this['redirectUser'])==null?void 0x0:_0x12ee4a['_redirectEventId'])===_0x1bd2cd?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5b6dfa){if(_0x5b6dfa===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5b6dfa));}['_notifyListenersIfCurrent'](_0x59311e){_0x59311e===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2c6773;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5587bb=((_0x2c6773=this['currentUser'])==null?void 0x0:_0x2c6773['uid'])??null;this['lastNotifiedUid']!==_0x5587bb&&(this['lastNotifiedUid']=_0x5587bb,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5e63ef,_0x565040,_0x5e13f5,_0x5ab4b1){if(this['_deleted'])return()=>{};const _0x1798a3=typeof _0x565040=='function'?_0x565040:_0x565040['next']['bind'](_0x565040);let _0x69b3e7=!0x1;const _0x4873d4=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4873d4,this,'internal-error'),_0x4873d4['then'](()=>{_0x69b3e7||_0x1798a3(this['currentUser']);}),typeof _0x565040=='function'){const _0x40e103=_0x5e63ef['addObserver'](_0x565040,_0x5e13f5,_0x5ab4b1);return()=>{_0x69b3e7=!0x0,_0x40e103();};}else{const _0x591d93=_0x5e63ef['addObserver'](_0x565040);return()=>{_0x69b3e7=!0x0,_0x591d93();};}}async['directlySetCurrentUser'](_0x1b9db9){this['currentUser']&&this['currentUser']!==_0x1b9db9&&this['_currentUser']['_stopProactiveRefresh'](),_0x1b9db9&&this['isProactiveRefreshEnabled']&&_0x1b9db9['_startProactiveRefresh'](),this['currentUser']=_0x1b9db9,_0x1b9db9?await this['assertedPersistence']['setCurrentUser'](_0x1b9db9):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x20bc2d){return this['operations']=this['operations']['then'](_0x20bc2d,_0x20bc2d),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x58c694){!_0x58c694||this['frameworks']['includes'](_0x58c694)||(this['frameworks']['push'](_0x58c694),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x95e1bc;const _0x14e684={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x14e684['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x199613=await((_0x95e1bc=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x95e1bc['getHeartbeatsHeader']());_0x199613&&(_0x14e684['X-Firebase-Client']=_0x199613);const _0x483cdb=await this['_getAppCheckToken']();return _0x483cdb&&(_0x14e684['X-Firebase-AppCheck']=_0x483cdb),_0x14e684;}async['_getAppCheckToken'](){var _0x280e52;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1b9ee3=await((_0x280e52=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x280e52['getToken']());return _0x1b9ee3!=null&&_0x1b9ee3['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1b9ee3['error']),_0x1b9ee3==null?void 0x0:_0x1b9ee3['token'];}}function Ke(_0x401294){return P(_0x401294);}class Rr{constructor(_0x111fc8){this['auth']=_0x111fc8,this['observer']=null,this['addObserver']=Tc(_0x19b2ea=>this['observer']=_0x19b2ea);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x29e4c7){Jn=_0x29e4c7;}function xa(_0x546d6c){return Jn['loadJS'](_0x546d6c);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x360d17){return'__'+_0x360d17+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x6ce667){_0x6ce667();}['execute'](_0x570460,_0xf52112){return Promise['resolve']('token');}['render'](_0x3bcf92,_0x40ff0a){return'';}}class Wf{['ready'](_0x253fed){_0x253fed();}['execute'](_0x20c483,_0x47b9f3){return Promise['resolve']('token');}['render'](_0x580ff4,_0x500625){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x4f4a3a){this['type']=Bf,this['auth']=Ke(_0x4f4a3a);}async['verify'](_0x201a63='verify',_0x2d0bb0=!0x1){async function _0x1b6ad9(_0x209590){if(!_0x2d0bb0){if(_0x209590['tenantId']==null&&_0x209590['_agentRecaptchaConfig']!=null)return _0x209590['_agentRecaptchaConfig']['siteKey'];if(_0x209590['tenantId']!=null&&_0x209590['_tenantRecaptchaConfigs'][_0x209590['tenantId']]!==void 0x0)return _0x209590['_tenantRecaptchaConfigs'][_0x209590['tenantId']]['siteKey'];}return new Promise(async(_0x5d2074,_0x37d84a)=>{yf(_0x209590,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x7fd54=>{if(_0x7fd54['recaptchaKey']===void 0x0)_0x37d84a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3dd57f=new mf(_0x7fd54);return _0x209590['tenantId']==null?_0x209590['_agentRecaptchaConfig']=_0x3dd57f:_0x209590['_tenantRecaptchaConfigs'][_0x209590['tenantId']]=_0x3dd57f,_0x5d2074(_0x3dd57f['siteKey']);}})['catch'](_0x3ce69c=>{_0x37d84a(_0x3ce69c);});});}function _0x4e6356(_0x149830,_0x2c5f0e,_0x243bf7){const _0x10611a=window['grecaptcha'];wr(_0x10611a)?_0x10611a['enterprise']['ready'](()=>{_0x10611a['enterprise']['execute'](_0x149830,{'action':_0x201a63})['then'](_0x761828=>{_0x2c5f0e(_0x761828);})['catch'](()=>{_0x2c5f0e(Fa);});}):_0x243bf7(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x8559dd,_0x467343)=>{_0x1b6ad9(this['auth'])['then'](async _0x497f63=>{if(!_0x2d0bb0&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x4e6356(_0x497f63,_0x8559dd,_0x467343);else{if(typeof window>'u'){_0x467343(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x42223d=Lf();_0x42223d['length']!==0x0&&(_0x42223d+=_0x497f63+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x297fa0;(_0x297fa0=he['scriptInjectionDeferred'])==null||_0x297fa0['resolve']();},xa(_0x42223d)['then'](()=>{var _0x15b109;return(_0x15b109=he['scriptInjectionDeferred'])==null?void 0x0:_0x15b109['promise'];})['then'](()=>{_0x4e6356(_0x497f63,_0x8559dd,_0x467343);})['catch'](_0x5c7147=>{_0x467343(_0x5c7147);});}})['catch'](_0x2c2130=>{_0x467343(_0x2c2130);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5ddc62,_0x239511,_0x2873d2,_0x170a0d=!0x1,_0x3dd335=!0x1){const _0x1511cc=new he(_0x5ddc62);let _0x59d232;if(_0x3dd335)_0x59d232=Fa;else try{_0x59d232=await _0x1511cc['verify'](_0x2873d2);}catch{_0x59d232=await _0x1511cc['verify'](_0x2873d2,!0x0);}const _0x1ddc7d={..._0x239511};if(_0x2873d2==='mfaSmsEnrollment'||_0x2873d2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1ddc7d){const _0x58b7d6=_0x1ddc7d['phoneEnrollmentInfo']['phoneNumber'],_0x5ccf96=_0x1ddc7d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1ddc7d,{'phoneEnrollmentInfo':{'phoneNumber':_0x58b7d6,'recaptchaToken':_0x5ccf96,'captchaResponse':_0x59d232,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1ddc7d){const _0x43b7ce=_0x1ddc7d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1ddc7d,{'phoneSignInInfo':{'recaptchaToken':_0x43b7ce,'captchaResponse':_0x59d232,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1ddc7d;}return _0x170a0d?Object['assign'](_0x1ddc7d,{'captchaResp':_0x59d232}):Object['assign'](_0x1ddc7d,{'captchaResponse':_0x59d232}),Object['assign'](_0x1ddc7d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1ddc7d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1ddc7d;}async function xi(_0x4d0335,_0x58faa5,_0x129d2f,_0x58ac53,_0x508895){var _0x14cc44;if((_0x14cc44=_0x4d0335['_getRecaptchaConfig']())!=null&&_0x14cc44['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x424fff=await kr(_0x4d0335,_0x58faa5,_0x129d2f,_0x129d2f==='getOobCode');return _0x58ac53(_0x4d0335,_0x424fff);}else return _0x58ac53(_0x4d0335,_0x58faa5)['catch'](async _0x2a70e3=>{if(_0x2a70e3['code']==='auth/missing-recaptcha-token'){console['log'](_0x129d2f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5ea217=await kr(_0x4d0335,_0x58faa5,_0x129d2f,_0x129d2f==='getOobCode');return _0x58ac53(_0x4d0335,_0x5ea217);}else return Promise['reject'](_0x2a70e3);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x20d650,_0x105cce){const _0x43a276=Hi(_0x20d650,'auth');if(_0x43a276['isInitialized']()){const _0x2a3faa=_0x43a276['getImmediate'](),_0x514397=_0x43a276['getOptions']();if(xe(_0x514397,_0x105cce??{}))return _0x2a3faa;Y(_0x2a3faa,'already-initialized');}return _0x43a276['initialize']({'options':_0x105cce});}function Hf(_0x2288f3,_0x16e4e2){const _0x293eee=(_0x16e4e2==null?void 0x0:_0x16e4e2['persistence'])||[],_0x4ebced=(Array['isArray'](_0x293eee)?_0x293eee:[_0x293eee])['map'](ie);_0x16e4e2!=null&&_0x16e4e2['errorMap']&&_0x2288f3['_updateErrorMap'](_0x16e4e2['errorMap']),_0x2288f3['_initializeWithPersistence'](_0x4ebced,_0x16e4e2==null?void 0x0:_0x16e4e2['popupRedirectResolver']);}function $f(_0x4e416b,_0x2640a1,_0x58fb7b){const _0x16935e=Ke(_0x4e416b);m(/^https?:\/\//['test'](_0x2640a1),_0x16935e,'invalid-emulator-scheme');const _0x4345c8=!0x1,_0x442b54=Ua(_0x2640a1),{host:_0x156678,port:_0xfb6b8c}=Gf(_0x2640a1),_0x14a4d9=_0xfb6b8c===null?'':':'+_0xfb6b8c,_0x4dee77={'url':_0x442b54+'//'+_0x156678+_0x14a4d9+'/'},_0x37b97b=Object['freeze']({'host':_0x156678,'port':_0xfb6b8c,'protocol':_0x442b54['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4345c8})});if(!_0x16935e['_canInitEmulator']){m(_0x16935e['config']['emulator']&&_0x16935e['emulatorConfig'],_0x16935e,'emulator-config-failed'),m(xe(_0x4dee77,_0x16935e['config']['emulator'])&&xe(_0x37b97b,_0x16935e['emulatorConfig']),_0x16935e,'emulator-config-failed');return;}_0x16935e['config']['emulator']=_0x4dee77,_0x16935e['emulatorConfig']=_0x37b97b,_0x16935e['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x156678)?Qr(_0x442b54+'//'+_0x156678+_0x14a4d9):qf();}function Ua(_0x21eace){const _0x4b52d9=_0x21eace['indexOf'](':');return _0x4b52d9<0x0?'':_0x21eace['substr'](0x0,_0x4b52d9+0x1);}function Gf(_0x25399f){const _0x50b788=Ua(_0x25399f),_0x5da9c4=/(\/\/)?([^?#/]+)/['exec'](_0x25399f['substr'](_0x50b788['length']));if(!_0x5da9c4)return{'host':'','port':null};const _0x4be5f8=_0x5da9c4[0x2]['split']('@')['pop']()||'',_0x6da9ce=/^(\[[^\]]+\])(:|$)/['exec'](_0x4be5f8);if(_0x6da9ce){const _0x2474e8=_0x6da9ce[0x1];return{'host':_0x2474e8,'port':Pr(_0x4be5f8['substr'](_0x2474e8['length']+0x1))};}else{const [_0x55c028,_0x3628ea]=_0x4be5f8['split'](':');return{'host':_0x55c028,'port':Pr(_0x3628ea)};}}function Pr(_0x59e471){if(!_0x59e471)return null;const _0xb214f4=Number(_0x59e471);return isNaN(_0xb214f4)?null:_0xb214f4;}function qf(){function _0x5de82f(){const _0x101ae3=document['createElement']('p'),_0x13e441=_0x101ae3['style'];_0x101ae3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x13e441['position']='fixed',_0x13e441['width']='100%',_0x13e441['backgroundColor']='#ffffff',_0x13e441['border']='.1em\x20solid\x20#000000',_0x13e441['color']='#b50000',_0x13e441['bottom']='0px',_0x13e441['left']='0px',_0x13e441['margin']='0px',_0x13e441['zIndex']='10000',_0x13e441['textAlign']='center',_0x101ae3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x101ae3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x5de82f):_0x5de82f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5bd917,_0x6eec70){this['providerId']=_0x5bd917,this['signInMethod']=_0x6eec70;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3c3fef){return ne('not\x20implemented');}['_linkToIdToken'](_0x234e93,_0x5ccaf4){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2547fa){return ne('not\x20implemented');}}async function zf(_0x293a09,_0x5e4f41){return Pe(_0x293a09,'POST','/v1/accounts:signUp',_0x5e4f41);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x5c8e95,_0x2d83f5){return en(_0x5c8e95,'POST','/v1/accounts:signInWithPassword',ke(_0x5c8e95,_0x2d83f5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x59f170,_0x2ab6ed){return en(_0x59f170,'POST','/v1/accounts:signInWithEmailLink',ke(_0x59f170,_0x2ab6ed));}async function Yf(_0x52da1e,_0x4156b3){return en(_0x52da1e,'POST','/v1/accounts:signInWithEmailLink',ke(_0x52da1e,_0x4156b3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0xb41e06,_0x2b5bf0,_0x2cb488,_0xf73e4b=null){super('password',_0x2cb488),this['_email']=_0xb41e06,this['_password']=_0x2b5bf0,this['_tenantId']=_0xf73e4b;}static['_fromEmailAndPassword'](_0x576f81,_0x374110){return new $t(_0x576f81,_0x374110,'password');}static['_fromEmailAndCode'](_0x3963c5,_0x36fe6a,_0x599383=null){return new $t(_0x3963c5,_0x36fe6a,'emailLink',_0x599383);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1edd80){const _0x115e79=typeof _0x1edd80=='string'?JSON['parse'](_0x1edd80):_0x1edd80;if(_0x115e79!=null&&_0x115e79['email']&&(_0x115e79!=null&&_0x115e79['password'])){if(_0x115e79['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x115e79['email'],_0x115e79['password']);if(_0x115e79['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x115e79['email'],_0x115e79['password'],_0x115e79['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4f7ec3){switch(this['signInMethod']){case'password':const _0x489671={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4f7ec3,_0x489671,'signInWithPassword',jf);case'emailLink':return Kf(_0x4f7ec3,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4f7ec3,'internal-error');}}async['_linkToIdToken'](_0x201a91,_0x1d8882){switch(this['signInMethod']){case'password':const _0x3c5e43={'idToken':_0x1d8882,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x201a91,_0x3c5e43,'signUpPassword',zf);case'emailLink':return Yf(_0x201a91,{'idToken':_0x1d8882,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x201a91,'internal-error');}}['_getReauthenticationResolver'](_0x4a5c8e){return this['_getIdTokenResponse'](_0x4a5c8e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x44554b,_0x588c9d){return en(_0x44554b,'POST','/v1/accounts:signInWithIdp',ke(_0x44554b,_0x588c9d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x335530){const _0x14f037=new $e(_0x335530['providerId'],_0x335530['signInMethod']);return _0x335530['idToken']||_0x335530['accessToken']?(_0x335530['idToken']&&(_0x14f037['idToken']=_0x335530['idToken']),_0x335530['accessToken']&&(_0x14f037['accessToken']=_0x335530['accessToken']),_0x335530['nonce']&&!_0x335530['pendingToken']&&(_0x14f037['nonce']=_0x335530['nonce']),_0x335530['pendingToken']&&(_0x14f037['pendingToken']=_0x335530['pendingToken'])):_0x335530['oauthToken']&&_0x335530['oauthTokenSecret']?(_0x14f037['accessToken']=_0x335530['oauthToken'],_0x14f037['secret']=_0x335530['oauthTokenSecret']):Y('argument-error'),_0x14f037;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2a770a){const _0x37f925=typeof _0x2a770a=='string'?JSON['parse'](_0x2a770a):_0x2a770a,{providerId:_0x540208,signInMethod:_0x4dfe70,..._0x502ea6}=_0x37f925;if(!_0x540208||!_0x4dfe70)return null;const _0x1f0f2f=new $e(_0x540208,_0x4dfe70);return _0x1f0f2f['idToken']=_0x502ea6['idToken']||void 0x0,_0x1f0f2f['accessToken']=_0x502ea6['accessToken']||void 0x0,_0x1f0f2f['secret']=_0x502ea6['secret'],_0x1f0f2f['nonce']=_0x502ea6['nonce'],_0x1f0f2f['pendingToken']=_0x502ea6['pendingToken']||null,_0x1f0f2f;}['_getIdTokenResponse'](_0xff352e){const _0x1cdcb5=this['buildRequest']();return nt(_0xff352e,_0x1cdcb5);}['_linkToIdToken'](_0x3f6ae8,_0xf545cf){const _0x1bb36d=this['buildRequest']();return _0x1bb36d['idToken']=_0xf545cf,nt(_0x3f6ae8,_0x1bb36d);}['_getReauthenticationResolver'](_0x48d21e){const _0x2f8fbf=this['buildRequest']();return _0x2f8fbf['autoCreate']=!0x1,nt(_0x48d21e,_0x2f8fbf);}['buildRequest'](){const _0x277c3f={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x277c3f['pendingToken']=this['pendingToken'];else{const _0x72193b={};this['idToken']&&(_0x72193b['id_token']=this['idToken']),this['accessToken']&&(_0x72193b['access_token']=this['accessToken']),this['secret']&&(_0x72193b['oauth_token_secret']=this['secret']),_0x72193b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x72193b['nonce']=this['nonce']),_0x277c3f['postBody']=ut(_0x72193b);}return _0x277c3f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1fb7a1){switch(_0x1fb7a1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x2b7de6){const _0x4de272=Ct(Tt(_0x2b7de6))['link'],_0x10d2b3=_0x4de272?Ct(Tt(_0x4de272))['deep_link_id']:null,_0x4116ff=Ct(Tt(_0x2b7de6))['deep_link_id'];return(_0x4116ff?Ct(Tt(_0x4116ff))['link']:null)||_0x4116ff||_0x10d2b3||_0x4de272||_0x2b7de6;}class Rs{constructor(_0x1ffa5a){const _0x5f4306=Ct(Tt(_0x1ffa5a)),_0x59017c=_0x5f4306['apiKey']??null,_0x1c9184=_0x5f4306['oobCode']??null,_0x22d2b6=Jf(_0x5f4306['mode']??null);m(_0x59017c&&_0x1c9184&&_0x22d2b6,'argument-error'),this['apiKey']=_0x59017c,this['operation']=_0x22d2b6,this['code']=_0x1c9184,this['continueUrl']=_0x5f4306['continueUrl']??null,this['languageCode']=_0x5f4306['lang']??null,this['tenantId']=_0x5f4306['tenantId']??null;}static['parseLink'](_0x117d9e){const _0x2ded8a=Xf(_0x117d9e);try{return new Rs(_0x2ded8a);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x520af7,_0xfaf9f){return $t['_fromEmailAndPassword'](_0x520af7,_0xfaf9f);}static['credentialWithLink'](_0x3ab64a,_0x2a75d4){const _0x538308=Rs['parseLink'](_0x2a75d4);return m(_0x538308,'argument-error'),$t['_fromEmailAndCode'](_0x3ab64a,_0x538308['code'],_0x538308['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x536bdd){this['providerId']=_0x536bdd,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x79e968){this['defaultLanguageCode']=_0x79e968;}['setCustomParameters'](_0x1d9711){return this['customParameters']=_0x1d9711,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5367c2){return this['scopes']['includes'](_0x5367c2)||this['scopes']['push'](_0x5367c2),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2cc0ee){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2cc0ee});}static['credentialFromResult'](_0x27a8e0){return ue['credentialFromTaggedObject'](_0x27a8e0);}static['credentialFromError'](_0x14d68b){return ue['credentialFromTaggedObject'](_0x14d68b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4c811f}){if(!_0x4c811f||!('oauthAccessToken'in _0x4c811f)||!_0x4c811f['oauthAccessToken'])return null;try{return ue['credential'](_0x4c811f['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x281727,_0x4de406){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x281727,'accessToken':_0x4de406});}static['credentialFromResult'](_0x2ebc81){return de['credentialFromTaggedObject'](_0x2ebc81);}static['credentialFromError'](_0x5e675f){return de['credentialFromTaggedObject'](_0x5e675f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ced59}){if(!_0x1ced59)return null;const {oauthIdToken:_0xa0099a,oauthAccessToken:_0x1b2cf6}=_0x1ced59;if(!_0xa0099a&&!_0x1b2cf6)return null;try{return de['credential'](_0xa0099a,_0x1b2cf6);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x9dfd2){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x9dfd2});}static['credentialFromResult'](_0x36ebcc){return fe['credentialFromTaggedObject'](_0x36ebcc);}static['credentialFromError'](_0x82f31f){return fe['credentialFromTaggedObject'](_0x82f31f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1fbe96}){if(!_0x1fbe96||!('oauthAccessToken'in _0x1fbe96)||!_0x1fbe96['oauthAccessToken'])return null;try{return fe['credential'](_0x1fbe96['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x44a6d3,_0x5d8570){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x44a6d3,'oauthTokenSecret':_0x5d8570});}static['credentialFromResult'](_0x226467){return pe['credentialFromTaggedObject'](_0x226467);}static['credentialFromError'](_0x33c2ae){return pe['credentialFromTaggedObject'](_0x33c2ae['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x179c4e}){if(!_0x179c4e)return null;const {oauthAccessToken:_0x138d41,oauthTokenSecret:_0x39d43f}=_0x179c4e;if(!_0x138d41||!_0x39d43f)return null;try{return pe['credential'](_0x138d41,_0x39d43f);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x46f170,_0x2347de){return en(_0x46f170,'POST','/v1/accounts:signUp',ke(_0x46f170,_0x2347de));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x162283){this['user']=_0x162283['user'],this['providerId']=_0x162283['providerId'],this['_tokenResponse']=_0x162283['_tokenResponse'],this['operationType']=_0x162283['operationType'];}static async['_fromIdTokenResponse'](_0x2017ac,_0xe86042,_0x2f192b,_0x1b127b=!0x1){const _0x44ce81=await j['_fromIdTokenResponse'](_0x2017ac,_0x2f192b,_0x1b127b),_0x29a75e=Nr(_0x2f192b);return new Ge({'user':_0x44ce81,'providerId':_0x29a75e,'_tokenResponse':_0x2f192b,'operationType':_0xe86042});}static async['_forOperation'](_0x1b4d47,_0x23da04,_0x3dfb95){await _0x1b4d47['_updateTokensIfNecessary'](_0x3dfb95,!0x0);const _0x51bde3=Nr(_0x3dfb95);return new Ge({'user':_0x1b4d47,'providerId':_0x51bde3,'_tokenResponse':_0x3dfb95,'operationType':_0x23da04});}}function Nr(_0x2ba474){return _0x2ba474['providerId']?_0x2ba474['providerId']:'phoneNumber'in _0x2ba474?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x2bfeb4,_0xd4bbc,_0x1a5181,_0x2bb560){super(_0xd4bbc['code'],_0xd4bbc['message']),this['operationType']=_0x1a5181,this['user']=_0x2bb560,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x2bfeb4['name'],'tenantId':_0x2bfeb4['tenantId']??void 0x0,'_serverResponse':_0xd4bbc['customData']['_serverResponse'],'operationType':_0x1a5181};}static['_fromErrorAndOperation'](_0x31410d,_0x40f59a,_0x4c9a75,_0x352c7a){return new On(_0x31410d,_0x40f59a,_0x4c9a75,_0x352c7a);}}function Ba(_0x3c707b,_0x3bfdb4,_0x4b0441,_0x2256e2){return(_0x3bfdb4==='reauthenticate'?_0x4b0441['_getReauthenticationResolver'](_0x3c707b):_0x4b0441['_getIdTokenResponse'](_0x3c707b))['catch'](_0x37b6a3=>{throw _0x37b6a3['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3c707b,_0x37b6a3,_0x3bfdb4,_0x2256e2):_0x37b6a3;});}async function ep(_0x344140,_0x57854f,_0x2e1858=!0x1){const _0x516f56=await Ht(_0x344140,_0x57854f['_linkToIdToken'](_0x344140['auth'],await _0x344140['getIdToken']()),_0x2e1858);return Ge['_forOperation'](_0x344140,'link',_0x516f56);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x2da5a4,_0xa53faf,_0x386286=!0x1){const {auth:_0x23a3b1}=_0x2da5a4;if($(_0x23a3b1['app']))return Promise['reject'](re(_0x23a3b1));const _0x3e85a4='reauthenticate';try{const _0x3aec17=await Ht(_0x2da5a4,Ba(_0x23a3b1,_0x3e85a4,_0xa53faf,_0x2da5a4),_0x386286);m(_0x3aec17['idToken'],_0x23a3b1,'internal-error');const _0x1aca5f=Ts(_0x3aec17['idToken']);m(_0x1aca5f,_0x23a3b1,'internal-error');const {sub:_0x33a6d1}=_0x1aca5f;return m(_0x2da5a4['uid']===_0x33a6d1,_0x23a3b1,'user-mismatch'),Ge['_forOperation'](_0x2da5a4,_0x3e85a4,_0x3aec17);}catch(_0x193dfe){throw(_0x193dfe==null?void 0x0:_0x193dfe['code'])==='auth/user-not-found'&&Y(_0x23a3b1,'user-mismatch'),_0x193dfe;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x5961b7,_0x16561f,_0x2a0092=!0x1){if($(_0x5961b7['app']))return Promise['reject'](re(_0x5961b7));const _0xffe2c6='signIn',_0x5920d1=await Ba(_0x5961b7,_0xffe2c6,_0x16561f),_0xb44954=await Ge['_fromIdTokenResponse'](_0x5961b7,_0xffe2c6,_0x5920d1);return _0x2a0092||await _0x5961b7['_updateCurrentUser'](_0xb44954['user']),_0xb44954;}async function np(_0x469840,_0x3ea807){return Va(Ke(_0x469840),_0x3ea807);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x1310ab){const _0x1a474c=Ke(_0x1310ab);_0x1a474c['_getPasswordPolicyInternal']()&&await _0x1a474c['_updatePasswordPolicy']();}async function L_(_0x359b3b,_0x40b863,_0x13ea14){if($(_0x359b3b['app']))return Promise['reject'](re(_0x359b3b));const _0xa46a51=Ke(_0x359b3b),_0x334141=await xi(_0xa46a51,{'returnSecureToken':!0x0,'email':_0x40b863,'password':_0x13ea14,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x10ae84=>{throw _0x10ae84['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x359b3b),_0x10ae84;}),_0x523381=await Ge['_fromIdTokenResponse'](_0xa46a51,'signIn',_0x334141);return await _0xa46a51['_updateCurrentUser'](_0x523381['user']),_0x523381;}function x_(_0x29969a,_0x169471,_0x43049b){return $(_0x29969a['app'])?Promise['reject'](re(_0x29969a)):np(P(_0x29969a),yt['credential'](_0x169471,_0x43049b))['catch'](async _0x26b9e0=>{throw _0x26b9e0['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x29969a),_0x26b9e0;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x4ed6de,_0xec0b17){return P(_0x4ed6de)['setPersistence'](_0xec0b17);}function ip(_0x338951,_0x6a4d82,_0x26797a,_0xeb4414){return P(_0x338951)['onIdTokenChanged'](_0x6a4d82,_0x26797a,_0xeb4414);}function sp(_0x1bfd50,_0x3d5908,_0x5e61c1){return P(_0x1bfd50)['beforeAuthStateChanged'](_0x3d5908,_0x5e61c1);}function U_(_0x370dd2,_0xf2b355,_0x496df7,_0x28cd00){return P(_0x370dd2)['onAuthStateChanged'](_0xf2b355,_0x496df7,_0x28cd00);}function W_(_0x518fad){return P(_0x518fad)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x1e92df,_0x3db6f9){this['storageRetriever']=_0x1e92df,this['type']=_0x3db6f9;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4b27e3,_0x50f746){return this['storage']['setItem'](_0x4b27e3,JSON['stringify'](_0x50f746)),Promise['resolve']();}['_get'](_0x5c097c){const _0x414df1=this['storage']['getItem'](_0x5c097c);return Promise['resolve'](_0x414df1?JSON['parse'](_0x414df1):null);}['_remove'](_0x39a642){return this['storage']['removeItem'](_0x39a642),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xd01a57,_0x633bcf)=>this['onStorageEvent'](_0xd01a57,_0x633bcf),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x56667d){for(const _0x42b28d of Object['keys'](this['listeners'])){const _0x2e6109=this['storage']['getItem'](_0x42b28d),_0xda7fa8=this['localCache'][_0x42b28d];_0x2e6109!==_0xda7fa8&&_0x56667d(_0x42b28d,_0xda7fa8,_0x2e6109);}}['onStorageEvent'](_0x4a0794,_0x563c30=!0x1){if(!_0x4a0794['key']){this['forAllChangedKeys']((_0x3f3929,_0x317301,_0x38e8b5)=>{this['notifyListeners'](_0x3f3929,_0x38e8b5);});return;}const _0x246ad3=_0x4a0794['key'];_0x563c30?this['detachListener']():this['stopPolling']();const _0x589d59=()=>{const _0x3886c5=this['storage']['getItem'](_0x246ad3);!_0x563c30&&this['localCache'][_0x246ad3]===_0x3886c5||this['notifyListeners'](_0x246ad3,_0x3886c5);},_0x4fb4f1=this['storage']['getItem'](_0x246ad3);Af()&&_0x4fb4f1!==_0x4a0794['newValue']&&_0x4a0794['newValue']!==_0x4a0794['oldValue']?setTimeout(_0x589d59,op):_0x589d59();}['notifyListeners'](_0x15ff61,_0x2a93d1){this['localCache'][_0x15ff61]=_0x2a93d1;const _0x40aee4=this['listeners'][_0x15ff61];if(_0x40aee4){for(const _0x2a63bc of Array['from'](_0x40aee4))_0x2a63bc(_0x2a93d1&&JSON['parse'](_0x2a93d1));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1e4551,_0x50c8b6,_0x512277)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1e4551,'oldValue':_0x50c8b6,'newValue':_0x512277}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x405dff,_0x3386a2){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x405dff]||(this['listeners'][_0x405dff]=new Set(),this['localCache'][_0x405dff]=this['storage']['getItem'](_0x405dff)),this['listeners'][_0x405dff]['add'](_0x3386a2);}['_removeListener'](_0x31b343,_0x3b4524){this['listeners'][_0x31b343]&&(this['listeners'][_0x31b343]['delete'](_0x3b4524),this['listeners'][_0x31b343]['size']===0x0&&delete this['listeners'][_0x31b343]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x9394ef,_0x1e720d){await super['_set'](_0x9394ef,_0x1e720d),this['localCache'][_0x9394ef]=JSON['stringify'](_0x1e720d);}async['_get'](_0x3d36ff){const _0x1b8f32=await super['_get'](_0x3d36ff);return this['localCache'][_0x3d36ff]=JSON['stringify'](_0x1b8f32),_0x1b8f32;}async['_remove'](_0x36e1a5){await super['_remove'](_0x36e1a5),delete this['localCache'][_0x36e1a5];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x45eaa7,_0x59ade9){}['_removeListener'](_0x12a7c0,_0x371bd9){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2ff1ab){return Promise['all'](_0x2ff1ab['map'](async _0x205a46=>{try{return{'fulfilled':!0x0,'value':await _0x205a46};}catch(_0x12bfe1){return{'fulfilled':!0x1,'reason':_0x12bfe1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x495878){this['eventTarget']=_0x495878,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1c0859){const _0x326ad5=this['receivers']['find'](_0x5425c0=>_0x5425c0['isListeningto'](_0x1c0859));if(_0x326ad5)return _0x326ad5;const _0x1a286d=new Xn(_0x1c0859);return this['receivers']['push'](_0x1a286d),_0x1a286d;}['isListeningto'](_0x5e0fcc){return this['eventTarget']===_0x5e0fcc;}async['handleEvent'](_0x47029d){const _0x2465cc=_0x47029d,{eventId:_0x3fe40c,eventType:_0x127a44,data:_0x184927}=_0x2465cc['data'],_0x20d877=this['handlersMap'][_0x127a44];if(!(_0x20d877!=null&&_0x20d877['size']))return;_0x2465cc['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3fe40c,'eventType':_0x127a44});const _0x5ea4cf=Array['from'](_0x20d877)['map'](async _0x200048=>_0x200048(_0x2465cc['origin'],_0x184927)),_0x570954=await cp(_0x5ea4cf);_0x2465cc['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3fe40c,'eventType':_0x127a44,'response':_0x570954});}['_subscribe'](_0x78d31,_0x5f5c58){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x78d31]||(this['handlersMap'][_0x78d31]=new Set()),this['handlersMap'][_0x78d31]['add'](_0x5f5c58);}['_unsubscribe'](_0x5c1cf1,_0x47d4f4){this['handlersMap'][_0x5c1cf1]&&_0x47d4f4&&this['handlersMap'][_0x5c1cf1]['delete'](_0x47d4f4),(!_0x47d4f4||this['handlersMap'][_0x5c1cf1]['size']===0x0)&&delete this['handlersMap'][_0x5c1cf1],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5484a3='',_0x33b35a=0xa){let _0x2a84c5='';for(let _0x533405=0x0;_0x533405<_0x33b35a;_0x533405++)_0x2a84c5+=Math['floor'](Math['random']()*0xa);return _0x5484a3+_0x2a84c5;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x296904){this['target']=_0x296904,this['handlers']=new Set();}['removeMessageHandler'](_0x7391f5){_0x7391f5['messageChannel']&&(_0x7391f5['messageChannel']['port1']['removeEventListener']('message',_0x7391f5['onMessage']),_0x7391f5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x7391f5);}async['_send'](_0x23f9f7,_0x2be07a,_0x3833eb=0x32){const _0x416d02=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x416d02)throw new Error('connection_unavailable');let _0x4c2c75,_0x4795d6;return new Promise((_0x12f103,_0x2b78c4)=>{const _0x426275=As('',0x14);_0x416d02['port1']['start']();const _0x21d339=setTimeout(()=>{_0x2b78c4(new Error('unsupported_event'));},_0x3833eb);_0x4795d6={'messageChannel':_0x416d02,'onMessage'(_0x2e9be7){const _0x194782=_0x2e9be7;if(_0x194782['data']['eventId']===_0x426275)switch(_0x194782['data']['status']){case'ack':clearTimeout(_0x21d339),_0x4c2c75=setTimeout(()=>{_0x2b78c4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4c2c75),_0x12f103(_0x194782['data']['response']);break;default:clearTimeout(_0x21d339),clearTimeout(_0x4c2c75),_0x2b78c4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4795d6),_0x416d02['port1']['addEventListener']('message',_0x4795d6['onMessage']),this['target']['postMessage']({'eventType':_0x23f9f7,'eventId':_0x426275,'data':_0x2be07a},[_0x416d02['port2']]);})['finally'](()=>{_0x4795d6&&this['removeMessageHandler'](_0x4795d6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x544114){Z()['location']['href']=_0x544114;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4b5c02;return((_0x4b5c02=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4b5c02['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x19c0e2){this['request']=_0x19c0e2;}['toPromise'](){return new Promise((_0x1198fe,_0xb05fe0)=>{this['request']['addEventListener']('success',()=>{_0x1198fe(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xb05fe0(this['request']['error']);});});}}function Zn(_0x896bfd,_0x592d09){return _0x896bfd['transaction']([Mn],_0x592d09?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x355e91=indexedDB['deleteDatabase'](Ka);return new nn(_0x355e91)['toPromise']();}function Qa(){const _0x33e3e3=indexedDB['open'](Ka,pp);return new Promise((_0x2a317f,_0x2fc50c)=>{_0x33e3e3['addEventListener']('error',()=>{_0x2fc50c(_0x33e3e3['error']);}),_0x33e3e3['addEventListener']('upgradeneeded',()=>{const _0x5cd561=_0x33e3e3['result'];try{_0x5cd561['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x181ad3){_0x2fc50c(_0x181ad3);}}),_0x33e3e3['addEventListener']('success',async()=>{const _0x4885a2=_0x33e3e3['result'];_0x4885a2['objectStoreNames']['contains'](Mn)?_0x2a317f(_0x4885a2):(_0x4885a2['close'](),await _p(),_0x2a317f(await Qa()));});});}async function Or(_0x175feb,_0x5a9197,_0x55b167){const _0xe2a2ed=Zn(_0x175feb,!0x0)['put']({[Ya]:_0x5a9197,'value':_0x55b167});return new nn(_0xe2a2ed)['toPromise']();}async function gp(_0x4f63ab,_0x530d98){const _0x52561d=Zn(_0x4f63ab,!0x1)['get'](_0x530d98),_0x307788=await new nn(_0x52561d)['toPromise']();return _0x307788===void 0x0?null:_0x307788['value'];}function Dr(_0x39127f,_0x3f9b26){const _0x221e78=Zn(_0x39127f,!0x0)['delete'](_0x3f9b26);return new nn(_0x221e78)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x576fcc){let _0x53dd21=0x0;for(;;)try{const _0x3f909c=await this['_openDb']();return await _0x576fcc(_0x3f909c);}catch(_0x309b47){if(_0x53dd21++>yp)throw _0x309b47;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x3b5936,_0xe6848c)=>({'keyProcessed':(await this['_poll']())['includes'](_0xe6848c['key'])})),this['receiver']['_subscribe']('ping',async(_0x4557f6,_0x20c014)=>['keyChanged']);}async['initializeSender'](){var _0x3d6c92,_0x22537f;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0xfbda7c=await this['sender']['_send']('ping',{},0x320);_0xfbda7c&&(_0x3d6c92=_0xfbda7c[0x0])!=null&&_0x3d6c92['fulfilled']&&(_0x22537f=_0xfbda7c[0x0])!=null&&_0x22537f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4c32d5){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4c32d5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x45ef39=>{await Or(_0x45ef39,Dn,'1'),await Dr(_0x45ef39,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x20f72e){this['pendingWrites']++;try{await _0x20f72e();}finally{this['pendingWrites']--;}}async['_set'](_0x5c7a86,_0x1ec0a4){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x518b1c=>Or(_0x518b1c,_0x5c7a86,_0x1ec0a4)),this['localCache'][_0x5c7a86]=_0x1ec0a4,this['notifyServiceWorker'](_0x5c7a86)));}async['_get'](_0x1bcce3){const _0x522058=await this['_withRetries'](_0x10dc89=>gp(_0x10dc89,_0x1bcce3));return this['localCache'][_0x1bcce3]=_0x522058,_0x522058;}async['_remove'](_0x40cb68){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x40f3e3=>Dr(_0x40f3e3,_0x40cb68)),delete this['localCache'][_0x40cb68],this['notifyServiceWorker'](_0x40cb68)));}async['_poll'](){const _0x58a866=await this['_withRetries'](_0x53d714=>{const _0x3794e5=Zn(_0x53d714,!0x1)['getAll']();return new nn(_0x3794e5)['toPromise']();});if(!_0x58a866)return[];if(this['pendingWrites']!==0x0)return[];const _0x18c3c3=[],_0xc67d62=new Set();if(_0x58a866['length']!==0x0){for(const {fbase_key:_0x1efeb2,value:_0x138378}of _0x58a866)_0xc67d62['add'](_0x1efeb2),JSON['stringify'](this['localCache'][_0x1efeb2])!==JSON['stringify'](_0x138378)&&(this['notifyListeners'](_0x1efeb2,_0x138378),_0x18c3c3['push'](_0x1efeb2));}for(const _0xda0351 of Object['keys'](this['localCache']))this['localCache'][_0xda0351]&&!_0xc67d62['has'](_0xda0351)&&(this['notifyListeners'](_0xda0351,null),_0x18c3c3['push'](_0xda0351));return _0x18c3c3;}['notifyListeners'](_0x416e30,_0x342d56){this['localCache'][_0x416e30]=_0x342d56;const _0x3f4c0d=this['listeners'][_0x416e30];if(_0x3f4c0d){for(const _0x5efd08 of Array['from'](_0x3f4c0d))_0x5efd08(_0x342d56);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x265ea1,_0x558b98){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x265ea1]||(this['listeners'][_0x265ea1]=new Set(),this['_get'](_0x265ea1)),this['listeners'][_0x265ea1]['add'](_0x558b98);}['_removeListener'](_0x24ad81,_0x1746ef){this['listeners'][_0x24ad81]&&(this['listeners'][_0x24ad81]['delete'](_0x1746ef),this['listeners'][_0x24ad81]['size']===0x0&&delete this['listeners'][_0x24ad81]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1363c1,_0xdd1f23){return _0xdd1f23?ie(_0xdd1f23):(m(_0x1363c1['_popupRedirectResolver'],_0x1363c1,'argument-error'),_0x1363c1['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x5e3b2a){super('custom','custom'),this['params']=_0x5e3b2a;}['_getIdTokenResponse'](_0x3da190){return nt(_0x3da190,this['_buildIdpRequest']());}['_linkToIdToken'](_0xc51517,_0x2051a8){return nt(_0xc51517,this['_buildIdpRequest'](_0x2051a8));}['_getReauthenticationResolver'](_0x51d5de){return nt(_0x51d5de,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x599aa0){const _0x155444={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x599aa0&&(_0x155444['idToken']=_0x599aa0),_0x155444;}}function Ip(_0x891d51){return Va(_0x891d51['auth'],new ks(_0x891d51),_0x891d51['bypassAuthState']);}function wp(_0x5cb9ea){const {auth:_0x44e127,user:_0xbdec00}=_0x5cb9ea;return m(_0xbdec00,_0x44e127,'internal-error'),tp(_0xbdec00,new ks(_0x5cb9ea),_0x5cb9ea['bypassAuthState']);}async function Cp(_0x1fb289){const {auth:_0x1388dd,user:_0x17efad}=_0x1fb289;return m(_0x17efad,_0x1388dd,'internal-error'),ep(_0x17efad,new ks(_0x1fb289),_0x1fb289['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x47102c,_0x2a51cc,_0x1bcb51,_0x163008,_0x5ddf78=!0x1){this['auth']=_0x47102c,this['resolver']=_0x1bcb51,this['user']=_0x163008,this['bypassAuthState']=_0x5ddf78,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2a51cc)?_0x2a51cc:[_0x2a51cc];}['execute'](){return new Promise(async(_0x4e385,_0x22c3ec)=>{this['pendingPromise']={'resolve':_0x4e385,'reject':_0x22c3ec};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3407ac){this['reject'](_0x3407ac);}});}async['onAuthEvent'](_0x48f38d){const {urlResponse:_0x18e7c8,sessionId:_0x59dd6d,postBody:_0x36d143,tenantId:_0xd8550,error:_0x38e853,type:_0x3a097f}=_0x48f38d;if(_0x38e853){this['reject'](_0x38e853);return;}const _0x2c2998={'auth':this['auth'],'requestUri':_0x18e7c8,'sessionId':_0x59dd6d,'tenantId':_0xd8550||void 0x0,'postBody':_0x36d143||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3a097f)(_0x2c2998));}catch(_0x25fd23){this['reject'](_0x25fd23);}}['onError'](_0x30805b){this['reject'](_0x30805b);}['getIdpTask'](_0x3a2255){switch(_0x3a2255){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x585ec6){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x585ec6),this['unregisterAndCleanUp']();}['reject'](_0x2dfaba){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2dfaba),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x101354,_0x1371c3,_0x425be7,_0x38d3fb,_0xf4c31d){super(_0x101354,_0x1371c3,_0x38d3fb,_0xf4c31d),this['provider']=_0x425be7,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4d6f04=await this['execute']();return m(_0x4d6f04,this['auth'],'internal-error'),_0x4d6f04;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x40aefc=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x40aefc),this['authWindow']['associatedEvent']=_0x40aefc,this['resolver']['_originValidation'](this['auth'])['catch'](_0xb0fb24=>{this['reject'](_0xb0fb24);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x305468=>{_0x305468||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x2a3a79;return((_0x2a3a79=this['authWindow'])==null?void 0x0:_0x2a3a79['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x10df22=()=>{var _0xadffcc,_0x496f5c;if((_0x496f5c=(_0xadffcc=this['authWindow'])==null?void 0x0:_0xadffcc['window'])!=null&&_0x496f5c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x10df22,Tp['get']());};_0x10df22();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x4b8cbd,_0x3bf08a,_0x45a216=!0x1){super(_0x4b8cbd,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3bf08a,void 0x0,_0x45a216),this['eventId']=null;}async['execute'](){let _0xd4a43f=hn['get'](this['auth']['_key']());if(!_0xd4a43f){try{const _0x5d2f62=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0xd4a43f=()=>Promise['resolve'](_0x5d2f62);}catch(_0x1066a0){_0xd4a43f=()=>Promise['reject'](_0x1066a0);}hn['set'](this['auth']['_key'](),_0xd4a43f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xd4a43f();}async['onAuthEvent'](_0xdcdeec){if(_0xdcdeec['type']==='signInViaRedirect')return super['onAuthEvent'](_0xdcdeec);if(_0xdcdeec['type']==='unknown'){this['resolve'](null);return;}if(_0xdcdeec['eventId']){const _0x2fae54=await this['auth']['_redirectUserForId'](_0xdcdeec['eventId']);if(_0x2fae54)return this['user']=_0x2fae54,super['onAuthEvent'](_0xdcdeec);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x34c2b6,_0x3df5d7){const _0x555cbd=Pp(_0x3df5d7),_0x565d88=kp(_0x34c2b6);if(!await _0x565d88['_isAvailable']())return!0x1;const _0xdc3dbc=await _0x565d88['_get'](_0x555cbd)==='true';return await _0x565d88['_remove'](_0x555cbd),_0xdc3dbc;}function Ap(_0x570f51,_0xb0bf59){hn['set'](_0x570f51['_key'](),_0xb0bf59);}function kp(_0x107f8b){return ie(_0x107f8b['_redirectPersistence']);}function Pp(_0x1482de){return ln(Sp,_0x1482de['config']['apiKey'],_0x1482de['name']);}async function Np(_0x563cef,_0x5d0eb3,_0x47f1fb=!0x1){if($(_0x563cef['app']))return Promise['reject'](re(_0x563cef));const _0x15d8f8=Ke(_0x563cef),_0x3b9a2d=Ep(_0x15d8f8,_0x5d0eb3),_0x48a0d3=await new bp(_0x15d8f8,_0x3b9a2d,_0x47f1fb)['execute']();return _0x48a0d3&&!_0x47f1fb&&(delete _0x48a0d3['user']['_redirectEventId'],await _0x15d8f8['_persistUserIfCurrent'](_0x48a0d3['user']),await _0x15d8f8['_setRedirectUser'](null,_0x5d0eb3)),_0x48a0d3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x5532ef){this['auth']=_0x5532ef,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1131d8){this['consumers']['add'](_0x1131d8),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1131d8)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1131d8),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2ad192){this['consumers']['delete'](_0x2ad192);}['onEvent'](_0x3308b8){if(this['hasEventBeenHandled'](_0x3308b8))return!0x1;let _0x1b46d0=!0x1;return this['consumers']['forEach'](_0x53999b=>{this['isEventForConsumer'](_0x3308b8,_0x53999b)&&(_0x1b46d0=!0x0,this['sendToConsumer'](_0x3308b8,_0x53999b),this['saveEventToCache'](_0x3308b8));}),this['hasHandledPotentialRedirect']||!Mp(_0x3308b8)||(this['hasHandledPotentialRedirect']=!0x0,_0x1b46d0||(this['queuedRedirectEvent']=_0x3308b8,_0x1b46d0=!0x0)),_0x1b46d0;}['sendToConsumer'](_0x4920b4,_0x26c95a){var _0xdb0e76;if(_0x4920b4['error']&&!Za(_0x4920b4)){const _0x322a64=((_0xdb0e76=_0x4920b4['error']['code'])==null?void 0x0:_0xdb0e76['split']('auth/')[0x1])||'internal-error';_0x26c95a['onError'](X(this['auth'],_0x322a64));}else _0x26c95a['onAuthEvent'](_0x4920b4);}['isEventForConsumer'](_0x4ae4f7,_0x4f922b){const _0x13bafe=_0x4f922b['eventId']===null||!!_0x4ae4f7['eventId']&&_0x4ae4f7['eventId']===_0x4f922b['eventId'];return _0x4f922b['filter']['includes'](_0x4ae4f7['type'])&&_0x13bafe;}['hasEventBeenHandled'](_0x1b8003){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1b8003));}['saveEventToCache'](_0x249857){this['cachedEventUids']['add'](Mr(_0x249857)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x906246){return[_0x906246['type'],_0x906246['eventId'],_0x906246['sessionId'],_0x906246['tenantId']]['filter'](_0x860f84=>_0x860f84)['join']('-');}function Za({type:_0x222427,error:_0x7cc62f}){return _0x222427==='unknown'&&(_0x7cc62f==null?void 0x0:_0x7cc62f['code'])==='auth/no-auth-event';}function Mp(_0x24fb53){switch(_0x24fb53['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x24fb53);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x114867,_0x24ef94={}){return Pe(_0x114867,'GET','/v1/projects',_0x24ef94);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3f0fd9){if(_0x3f0fd9['config']['emulator'])return;const {authorizedDomains:_0x20d341}=await Lp(_0x3f0fd9);for(const _0x4c6690 of _0x20d341)try{if(Wp(_0x4c6690))return;}catch{}Y(_0x3f0fd9,'unauthorized-domain');}function Wp(_0x544dee){const _0x4b2cff=Mi(),{protocol:_0x5ac3f6,hostname:_0x2f9dde}=new URL(_0x4b2cff);if(_0x544dee['startsWith']('chrome-extension://')){const _0x3e2def=new URL(_0x544dee);return _0x3e2def['hostname']===''&&_0x2f9dde===''?_0x5ac3f6==='chrome-extension:'&&_0x544dee['replace']('chrome-extension://','')===_0x4b2cff['replace']('chrome-extension://',''):_0x5ac3f6==='chrome-extension:'&&_0x3e2def['hostname']===_0x2f9dde;}if(!Fp['test'](_0x5ac3f6))return!0x1;if(xp['test'](_0x544dee))return _0x2f9dde===_0x544dee;const _0x5ed729=_0x544dee['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5ed729+'|'+_0x5ed729+')$','i')['test'](_0x2f9dde);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x177ce6=Z()['___jsl'];if(_0x177ce6!=null&&_0x177ce6['H']){for(const _0x9f725d of Object['keys'](_0x177ce6['H']))if(_0x177ce6['H'][_0x9f725d]['r']=_0x177ce6['H'][_0x9f725d]['r']||[],_0x177ce6['H'][_0x9f725d]['L']=_0x177ce6['H'][_0x9f725d]['L']||[],_0x177ce6['H'][_0x9f725d]['r']=[..._0x177ce6['H'][_0x9f725d]['L']],_0x177ce6['CP']){for(let _0x4522d2=0x0;_0x4522d2<_0x177ce6['CP']['length'];_0x4522d2++)_0x177ce6['CP'][_0x4522d2]=null;}}}function Vp(_0x12211a){return new Promise((_0x1ff3ea,_0x12cc5b)=>{var _0x20d0ab,_0x2da3fa,_0x58a1ec;function _0x2e1faa(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1ff3ea(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x12cc5b(X(_0x12211a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2da3fa=(_0x20d0ab=Z()['gapi'])==null?void 0x0:_0x20d0ab['iframes'])!=null&&_0x2da3fa['Iframe'])_0x1ff3ea(gapi['iframes']['getContext']());else{if((_0x58a1ec=Z()['gapi'])!=null&&_0x58a1ec['load'])_0x2e1faa();else{const _0x4874c6=Ff('iframefcb');return Z()[_0x4874c6]=()=>{gapi['load']?_0x2e1faa():_0x12cc5b(X(_0x12211a,'network-request-failed'));},xa(xf()+'?onload='+_0x4874c6)['catch'](_0x34c2c7=>_0x12cc5b(_0x34c2c7));}}})['catch'](_0x1e2cef=>{throw un=null,_0x1e2cef;});}let un=null;function Hp(_0x355df6){return un=un||Vp(_0x355df6),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x3ea99a){const _0x55d7a3=_0x3ea99a['config'];m(_0x55d7a3['authDomain'],_0x3ea99a,'auth-domain-config-required');const _0x2669d4=_0x55d7a3['emulator']?Cs(_0x55d7a3,qp):'https://'+_0x3ea99a['config']['authDomain']+'/'+Gp,_0x44997c={'apiKey':_0x55d7a3['apiKey'],'appName':_0x3ea99a['name'],'v':dt},_0x11342f=jp['get'](_0x3ea99a['config']['apiHost']);_0x11342f&&(_0x44997c['eid']=_0x11342f);const _0x3ca777=_0x3ea99a['_getFrameworks']();return _0x3ca777['length']&&(_0x44997c['fw']=_0x3ca777['join'](',')),_0x2669d4+'?'+ut(_0x44997c)['slice'](0x1);}async function Yp(_0x558943){const _0x9999a8=await Hp(_0x558943),_0x5b657d=Z()['gapi'];return m(_0x5b657d,_0x558943,'internal-error'),_0x9999a8['open']({'where':document['body'],'url':Kp(_0x558943),'messageHandlersFilter':_0x5b657d['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x38f758=>new Promise(async(_0x4ebfde,_0x16cc71)=>{await _0x38f758['restyle']({'setHideOnLeave':!0x1});const _0x4cd02a=X(_0x558943,'network-request-failed'),_0x440c6f=Z()['setTimeout'](()=>{_0x16cc71(_0x4cd02a);},$p['get']());function _0x2e2b78(){Z()['clearTimeout'](_0x440c6f),_0x4ebfde(_0x38f758);}_0x38f758['ping'](_0x2e2b78)['then'](_0x2e2b78,()=>{_0x16cc71(_0x4cd02a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x18b4df){this['window']=_0x18b4df,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x32a489,_0x46c7cc,_0x481de8,_0x498fee=Jp,_0x4a603d=Xp){const _0x53c0a5=Math['max']((window['screen']['availHeight']-_0x4a603d)/0x2,0x0)['toString'](),_0x12c9ff=Math['max']((window['screen']['availWidth']-_0x498fee)/0x2,0x0)['toString']();let _0x4203e6='';const _0x117c3e={...Qp,'width':_0x498fee['toString'](),'height':_0x4a603d['toString'](),'top':_0x53c0a5,'left':_0x12c9ff},_0x349019=W()['toLowerCase']();_0x481de8&&(_0x4203e6=ka(_0x349019)?Zp:_0x481de8),Ra(_0x349019)&&(_0x46c7cc=_0x46c7cc||e_,_0x117c3e['scrollbars']='yes');const _0x246063=Object['entries'](_0x117c3e)['reduce']((_0x46a796,[_0x59262e,_0x21cc68])=>''+_0x46a796+_0x59262e+'='+_0x21cc68+',','');if(Rf(_0x349019)&&_0x4203e6!=='_self')return n_(_0x46c7cc||'',_0x4203e6),new xr(null);const _0x51521f=window['open'](_0x46c7cc||'',_0x4203e6,_0x246063);m(_0x51521f,_0x32a489,'popup-blocked');try{_0x51521f['focus']();}catch{}return new xr(_0x51521f);}function n_(_0x379ebf,_0x1e4b22){const _0x53a0ba=document['createElement']('a');_0x53a0ba['href']=_0x379ebf,_0x53a0ba['target']=_0x1e4b22;const _0x458864=document['createEvent']('MouseEvent');_0x458864['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x53a0ba['dispatchEvent'](_0x458864);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x2c9253,_0x420cf1,_0x10d3e3,_0xfea2a4,_0x452cc8,_0x703e40){m(_0x2c9253['config']['authDomain'],_0x2c9253,'auth-domain-config-required'),m(_0x2c9253['config']['apiKey'],_0x2c9253,'invalid-api-key');const _0xfb1bb5={'apiKey':_0x2c9253['config']['apiKey'],'appName':_0x2c9253['name'],'authType':_0x10d3e3,'redirectUrl':_0xfea2a4,'v':dt,'eventId':_0x452cc8};if(_0x420cf1 instanceof Wa){_0x420cf1['setDefaultLanguage'](_0x2c9253['languageCode']),_0xfb1bb5['providerId']=_0x420cf1['providerId']||'',pn(_0x420cf1['getCustomParameters']())||(_0xfb1bb5['customParameters']=JSON['stringify'](_0x420cf1['getCustomParameters']()));for(const [_0x1eda69,_0x21c0f4]of Object['entries']({}))_0xfb1bb5[_0x1eda69]=_0x21c0f4;}if(_0x420cf1 instanceof tn){const _0x2660d3=_0x420cf1['getScopes']()['filter'](_0xccc94b=>_0xccc94b!=='');_0x2660d3['length']>0x0&&(_0xfb1bb5['scopes']=_0x2660d3['join'](','));}_0x2c9253['tenantId']&&(_0xfb1bb5['tid']=_0x2c9253['tenantId']);const _0x26b7c6=_0xfb1bb5;for(const _0x2f0bfb of Object['keys'](_0x26b7c6))_0x26b7c6[_0x2f0bfb]===void 0x0&&delete _0x26b7c6[_0x2f0bfb];const _0x49f527=await _0x2c9253['_getAppCheckToken'](),_0x15e83a=_0x49f527?'#'+r_+'='+encodeURIComponent(_0x49f527):'';return o_(_0x2c9253)+'?'+ut(_0x26b7c6)['slice'](0x1)+_0x15e83a;}function o_({config:_0x5d5a19}){return _0x5d5a19['emulator']?Cs(_0x5d5a19,s_):'https://'+_0x5d5a19['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x3cf433,_0x460d10,_0x4b65a6,_0x2533e9){var _0x3f6784;ce((_0x3f6784=this['eventManagers'][_0x3cf433['_key']()])==null?void 0x0:_0x3f6784['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3fd67c=await Fr(_0x3cf433,_0x460d10,_0x4b65a6,Mi(),_0x2533e9);return t_(_0x3cf433,_0x3fd67c,As());}async['_openRedirect'](_0x111633,_0xcca5ff,_0x12234c,_0x32d898){await this['_originValidation'](_0x111633);const _0x627d5b=await Fr(_0x111633,_0xcca5ff,_0x12234c,Mi(),_0x32d898);return hp(_0x627d5b),new Promise(()=>{});}['_initialize'](_0x4e45db){const _0x2977e7=_0x4e45db['_key']();if(this['eventManagers'][_0x2977e7]){const {manager:_0x5099d2,promise:_0xcb56be}=this['eventManagers'][_0x2977e7];return _0x5099d2?Promise['resolve'](_0x5099d2):(ce(_0xcb56be,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xcb56be);}const _0x20d7e7=this['initAndGetManager'](_0x4e45db);return this['eventManagers'][_0x2977e7]={'promise':_0x20d7e7},_0x20d7e7['catch'](()=>{delete this['eventManagers'][_0x2977e7];}),_0x20d7e7;}async['initAndGetManager'](_0xa82393){const _0x1c144a=await Yp(_0xa82393),_0x5af9c1=new Dp(_0xa82393);return _0x1c144a['register']('authEvent',_0x3863e0=>(m(_0x3863e0==null?void 0x0:_0x3863e0['authEvent'],_0xa82393,'invalid-auth-event'),{'status':_0x5af9c1['onEvent'](_0x3863e0['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xa82393['_key']()]={'manager':_0x5af9c1},this['iframes'][_0xa82393['_key']()]=_0x1c144a,_0x5af9c1;}['_isIframeWebStorageSupported'](_0x4b29b9,_0x835594){this['iframes'][_0x4b29b9['_key']()]['send'](pi,{'type':pi},_0x34e5ec=>{var _0x305f61;const _0x1f20e5=(_0x305f61=_0x34e5ec==null?void 0x0:_0x34e5ec[0x0])==null?void 0x0:_0x305f61[pi];_0x1f20e5!==void 0x0&&_0x835594(!!_0x1f20e5),Y(_0x4b29b9,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x569edd){const _0xcfd8ce=_0x569edd['_key']();return this['originValidationPromises'][_0xcfd8ce]||(this['originValidationPromises'][_0xcfd8ce]=Up(_0x569edd)),this['originValidationPromises'][_0xcfd8ce];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x151247){this['auth']=_0x151247,this['internalListeners']=new Map();}['getUid'](){var _0x7fdc42;return this['assertAuthConfigured'](),((_0x7fdc42=this['auth']['currentUser'])==null?void 0x0:_0x7fdc42['uid'])||null;}async['getToken'](_0xb52722){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xb52722)}:null;}['addAuthTokenListener'](_0x2441a9){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2441a9))return;const _0x1ff5a7=this['auth']['onIdTokenChanged'](_0x19d6db=>{_0x2441a9((_0x19d6db==null?void 0x0:_0x19d6db['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2441a9,_0x1ff5a7),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x47cee4){this['assertAuthConfigured']();const _0x1f97d0=this['internalListeners']['get'](_0x47cee4);_0x1f97d0&&(this['internalListeners']['delete'](_0x47cee4),_0x1f97d0(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1ef529){switch(_0x1ef529){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2acedd){st(new Fe('auth',(_0x2a0374,{options:_0x3656c3})=>{const _0x2caa1c=_0x2a0374['getProvider']('app')['getImmediate'](),_0xa79ce4=_0x2a0374['getProvider']('heartbeat'),_0x527b87=_0x2a0374['getProvider']('app-check-internal'),{apiKey:_0x408bc7,authDomain:_0x16435d}=_0x2caa1c['options'];m(_0x408bc7&&!_0x408bc7['includes'](':'),'invalid-api-key',{'appName':_0x2caa1c['name']});const _0x28254c={'apiKey':_0x408bc7,'authDomain':_0x16435d,'clientPlatform':_0x2acedd,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2acedd)},_0x2d8591=new Df(_0x2caa1c,_0xa79ce4,_0x527b87,_0x28254c);return Hf(_0x2d8591,_0x3656c3),_0x2d8591;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3eef36,_0x1b4bd3,_0x2c99a9)=>{_0x3eef36['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x1e7503=>{const _0x2e6de4=Ke(_0x1e7503['getProvider']('auth')['getImmediate']());return(_0x550266=>new l_(_0x550266))(_0x2e6de4);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2acedd)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x173a1c=>async _0x33429d=>{const _0x4619e6=_0x33429d&&await _0x33429d['getIdTokenResult'](),_0x148ff4=_0x4619e6&&(new Date()['getTime']()-Date['parse'](_0x4619e6['issuedAtTime']))/0x3e8;if(_0x148ff4&&_0x148ff4>f_)return;const _0x2a92b3=_0x4619e6==null?void 0x0:_0x4619e6['token'];Br!==_0x2a92b3&&(Br=_0x2a92b3,await fetch(_0x173a1c,{'method':_0x2a92b3?'POST':'DELETE','headers':_0x2a92b3?{'Authorization':'Bearer\x20'+_0x2a92b3}:{}}));};function B_(_0x11b9d9=Zr()){const _0x3e70d7=Hi(_0x11b9d9,'auth');if(_0x3e70d7['isInitialized']())return _0x3e70d7['getImmediate']();const _0x51f4c9=Vf(_0x11b9d9,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0xd0d0ce=jr('authTokenSyncURL');if(_0xd0d0ce&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x55ecdf=new URL(_0xd0d0ce,location['origin']);if(location['origin']===_0x55ecdf['origin']){const _0x4139de=p_(_0x55ecdf['toString']());sp(_0x51f4c9,_0x4139de,()=>_0x4139de(_0x51f4c9['currentUser'])),ip(_0x51f4c9,_0x1d5177=>_0x4139de(_0x1d5177));}}const _0x2e6ba7=qr('auth');return _0x2e6ba7&&$f(_0x51f4c9,'http://'+_0x2e6ba7),_0x51f4c9;}function __(){var _0x3e5346;return((_0x3e5346=document['getElementsByTagName']('head'))==null?void 0x0:_0x3e5346[0x0])??document;}Mf({'loadJS'(_0x37d3c4){return new Promise((_0x52fe62,_0x1380f9)=>{const _0x42acc9=document['createElement']('script');_0x42acc9['setAttribute']('src',_0x37d3c4),_0x42acc9['onload']=_0x52fe62,_0x42acc9['onerror']=_0x4f4517=>{const _0x522fbf=X('internal-error');_0x522fbf['customData']=_0x4f4517,_0x1380f9(_0x522fbf);},_0x42acc9['type']='text/javascript',_0x42acc9['charset']='UTF-8',__()['appendChild'](_0x42acc9);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};