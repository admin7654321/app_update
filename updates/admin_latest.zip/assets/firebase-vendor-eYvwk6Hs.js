const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x42169f,_0x1cf82b){if(!_0x42169f)throw ht(_0x1cf82b);},ht=function(_0x46da4c){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x46da4c);},Hr=function(_0x3335ff){const _0x362a03=[];let _0x2d8c25=0x0;for(let _0x13bfbc=0x0;_0x13bfbc<_0x3335ff['length'];_0x13bfbc++){let _0x12fe3d=_0x3335ff['charCodeAt'](_0x13bfbc);_0x12fe3d<0x80?_0x362a03[_0x2d8c25++]=_0x12fe3d:_0x12fe3d<0x800?(_0x362a03[_0x2d8c25++]=_0x12fe3d>>0x6|0xc0,_0x362a03[_0x2d8c25++]=_0x12fe3d&0x3f|0x80):(_0x12fe3d&0xfc00)===0xd800&&_0x13bfbc+0x1<_0x3335ff['length']&&(_0x3335ff['charCodeAt'](_0x13bfbc+0x1)&0xfc00)===0xdc00?(_0x12fe3d=0x10000+((_0x12fe3d&0x3ff)<<0xa)+(_0x3335ff['charCodeAt'](++_0x13bfbc)&0x3ff),_0x362a03[_0x2d8c25++]=_0x12fe3d>>0x12|0xf0,_0x362a03[_0x2d8c25++]=_0x12fe3d>>0xc&0x3f|0x80,_0x362a03[_0x2d8c25++]=_0x12fe3d>>0x6&0x3f|0x80,_0x362a03[_0x2d8c25++]=_0x12fe3d&0x3f|0x80):(_0x362a03[_0x2d8c25++]=_0x12fe3d>>0xc|0xe0,_0x362a03[_0x2d8c25++]=_0x12fe3d>>0x6&0x3f|0x80,_0x362a03[_0x2d8c25++]=_0x12fe3d&0x3f|0x80);}return _0x362a03;},nc=function(_0x21837f){const _0x280240=[];let _0x20d2c8=0x0,_0x7fe805=0x0;for(;_0x20d2c8<_0x21837f['length'];){const _0x5b1ad9=_0x21837f[_0x20d2c8++];if(_0x5b1ad9<0x80)_0x280240[_0x7fe805++]=String['fromCharCode'](_0x5b1ad9);else{if(_0x5b1ad9>0xbf&&_0x5b1ad9<0xe0){const _0x566e4e=_0x21837f[_0x20d2c8++];_0x280240[_0x7fe805++]=String['fromCharCode']((_0x5b1ad9&0x1f)<<0x6|_0x566e4e&0x3f);}else{if(_0x5b1ad9>0xef&&_0x5b1ad9<0x16d){const _0x3d137f=_0x21837f[_0x20d2c8++],_0x3a5a87=_0x21837f[_0x20d2c8++],_0x267c04=_0x21837f[_0x20d2c8++],_0x10523c=((_0x5b1ad9&0x7)<<0x12|(_0x3d137f&0x3f)<<0xc|(_0x3a5a87&0x3f)<<0x6|_0x267c04&0x3f)-0x10000;_0x280240[_0x7fe805++]=String['fromCharCode'](0xd800+(_0x10523c>>0xa)),_0x280240[_0x7fe805++]=String['fromCharCode'](0xdc00+(_0x10523c&0x3ff));}else{const _0x4a1419=_0x21837f[_0x20d2c8++],_0x4b32d4=_0x21837f[_0x20d2c8++];_0x280240[_0x7fe805++]=String['fromCharCode']((_0x5b1ad9&0xf)<<0xc|(_0x4a1419&0x3f)<<0x6|_0x4b32d4&0x3f);}}}}return _0x280240['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x413ab4,_0x37905f){if(!Array['isArray'](_0x413ab4))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x297e47=_0x37905f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x41f43f=[];for(let _0x1b8aa0=0x0;_0x1b8aa0<_0x413ab4['length'];_0x1b8aa0+=0x3){const _0x2de735=_0x413ab4[_0x1b8aa0],_0x27f76e=_0x1b8aa0+0x1<_0x413ab4['length'],_0x340f87=_0x27f76e?_0x413ab4[_0x1b8aa0+0x1]:0x0,_0x4f14c7=_0x1b8aa0+0x2<_0x413ab4['length'],_0xb133a4=_0x4f14c7?_0x413ab4[_0x1b8aa0+0x2]:0x0,_0x41ea81=_0x2de735>>0x2,_0x113e63=(_0x2de735&0x3)<<0x4|_0x340f87>>0x4;let _0x58ba84=(_0x340f87&0xf)<<0x2|_0xb133a4>>0x6,_0x48df30=_0xb133a4&0x3f;_0x4f14c7||(_0x48df30=0x40,_0x27f76e||(_0x58ba84=0x40)),_0x41f43f['push'](_0x297e47[_0x41ea81],_0x297e47[_0x113e63],_0x297e47[_0x58ba84],_0x297e47[_0x48df30]);}return _0x41f43f['join']('');},'encodeString'(_0x5e2a98,_0x4722a8){return this['HAS_NATIVE_SUPPORT']&&!_0x4722a8?btoa(_0x5e2a98):this['encodeByteArray'](Hr(_0x5e2a98),_0x4722a8);},'decodeString'(_0x1dbf7f,_0x42898a){return this['HAS_NATIVE_SUPPORT']&&!_0x42898a?atob(_0x1dbf7f):nc(this['decodeStringToByteArray'](_0x1dbf7f,_0x42898a));},'decodeStringToByteArray'(_0x39cc74,_0x483723){this['init_']();const _0xf21389=_0x483723?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4fe3af=[];for(let _0x15799c=0x0;_0x15799c<_0x39cc74['length'];){const _0x43a6da=_0xf21389[_0x39cc74['charAt'](_0x15799c++)],_0x37f2bc=_0x15799c<_0x39cc74['length']?_0xf21389[_0x39cc74['charAt'](_0x15799c)]:0x0;++_0x15799c;const _0x443b61=_0x15799c<_0x39cc74['length']?_0xf21389[_0x39cc74['charAt'](_0x15799c)]:0x40;++_0x15799c;const _0x4901ce=_0x15799c<_0x39cc74['length']?_0xf21389[_0x39cc74['charAt'](_0x15799c)]:0x40;if(++_0x15799c,_0x43a6da==null||_0x37f2bc==null||_0x443b61==null||_0x4901ce==null)throw new ic();const _0xaabaf=_0x43a6da<<0x2|_0x37f2bc>>0x4;if(_0x4fe3af['push'](_0xaabaf),_0x443b61!==0x40){const _0x19828a=_0x37f2bc<<0x4&0xf0|_0x443b61>>0x2;if(_0x4fe3af['push'](_0x19828a),_0x4901ce!==0x40){const _0x151df7=_0x443b61<<0x6&0xc0|_0x4901ce;_0x4fe3af['push'](_0x151df7);}}}return _0x4fe3af;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x906b1e=0x0;_0x906b1e<this['ENCODED_VALS']['length'];_0x906b1e++)this['byteToCharMap_'][_0x906b1e]=this['ENCODED_VALS']['charAt'](_0x906b1e),this['charToByteMap_'][this['byteToCharMap_'][_0x906b1e]]=_0x906b1e,this['byteToCharMapWebSafe_'][_0x906b1e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x906b1e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x906b1e]]=_0x906b1e,_0x906b1e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x906b1e)]=_0x906b1e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x906b1e)]=_0x906b1e);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0xc6d55){const _0x2fac54=Hr(_0xc6d55);return Fi['encodeByteArray'](_0x2fac54,!0x0);},dn=function(_0xe92376){return $r(_0xe92376)['replace'](/\./g,'');},fn=function(_0x1bfe1c){try{return Fi['decodeString'](_0x1bfe1c,!0x0);}catch(_0x3e9d51){console['error']('base64Decode\x20failed:\x20',_0x3e9d51);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3af057){return Gr(void 0x0,_0x3af057);}function Gr(_0x3c7bec,_0x266bd6){if(!(_0x266bd6 instanceof Object))return _0x266bd6;switch(_0x266bd6['constructor']){case Date:const _0x31608e=_0x266bd6;return new Date(_0x31608e['getTime']());case Object:_0x3c7bec===void 0x0&&(_0x3c7bec={});break;case Array:_0x3c7bec=[];break;default:return _0x266bd6;}for(const _0x42a794 in _0x266bd6)!_0x266bd6['hasOwnProperty'](_0x42a794)||!rc(_0x42a794)||(_0x3c7bec[_0x42a794]=Gr(_0x3c7bec[_0x42a794],_0x266bd6[_0x42a794]));return _0x3c7bec;}function rc(_0x260411){return _0x260411!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x4e3c4d=Ps['__FIREBASE_DEFAULTS__'];if(_0x4e3c4d)return JSON['parse'](_0x4e3c4d);},lc=()=>{if(typeof document>'u')return;let _0x4964b0;try{_0x4964b0=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x334dae=_0x4964b0&&fn(_0x4964b0[0x1]);return _0x334dae&&JSON['parse'](_0x334dae);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x4ab59f){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4ab59f);return;}},qr=_0x20c521=>{var _0x4c42e3,_0x2ba9dd;return(_0x2ba9dd=(_0x4c42e3=Ui())==null?void 0x0:_0x4c42e3['emulatorHosts'])==null?void 0x0:_0x2ba9dd[_0x20c521];},hc=_0x3c3d5b=>{const _0xa33054=qr(_0x3c3d5b);if(!_0xa33054)return;const _0x2e8010=_0xa33054['lastIndexOf'](':');if(_0x2e8010<=0x0||_0x2e8010+0x1===_0xa33054['length'])throw new Error('Invalid\x20host\x20'+_0xa33054+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3bbe02=parseInt(_0xa33054['substring'](_0x2e8010+0x1),0xa);return _0xa33054[0x0]==='['?[_0xa33054['substring'](0x1,_0x2e8010-0x1),_0x3bbe02]:[_0xa33054['substring'](0x0,_0x2e8010),_0x3bbe02];},zr=()=>{var _0x18569e;return(_0x18569e=Ui())==null?void 0x0:_0x18569e['config'];},jr=_0x43729e=>{var _0x342008;return(_0x342008=Ui())==null?void 0x0:_0x342008['_'+_0x43729e];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4fd50c,_0x231ca1)=>{this['resolve']=_0x4fd50c,this['reject']=_0x231ca1;});}['wrapCallback'](_0x51ea60){return(_0x7f57e5,_0x24e95d)=>{_0x7f57e5?this['reject'](_0x7f57e5):this['resolve'](_0x24e95d),typeof _0x51ea60=='function'&&(this['promise']['catch'](()=>{}),_0x51ea60['length']===0x1?_0x51ea60(_0x7f57e5):_0x51ea60(_0x7f57e5,_0x24e95d));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x703f20,_0x2223fa){if(_0x703f20['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xe3e02c={'alg':'none','type':'JWT'},_0x10da54=_0x2223fa||'demo-project',_0x3c6f39=_0x703f20['iat']||0x0,_0x9778=_0x703f20['sub']||_0x703f20['user_id'];if(!_0x9778)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1de626={'iss':'https://securetoken.google.com/'+_0x10da54,'aud':_0x10da54,'iat':_0x3c6f39,'exp':_0x3c6f39+0xe10,'auth_time':_0x3c6f39,'sub':_0x9778,'user_id':_0x9778,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x703f20};return[dn(JSON['stringify'](_0xe3e02c)),dn(JSON['stringify'](_0x1de626)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x6da332=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x6da332=='object'&&_0x6da332['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x215f29=W();return _0x215f29['indexOf']('MSIE\x20')>=0x0||_0x215f29['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2a293c,_0xe7f77e)=>{try{let _0x6df9e0=!0x0;const _0xaa753e='validate-browser-context-for-indexeddb-analytics-module',_0x12310a=self['indexedDB']['open'](_0xaa753e);_0x12310a['onsuccess']=()=>{_0x12310a['result']['close'](),_0x6df9e0||self['indexedDB']['deleteDatabase'](_0xaa753e),_0x2a293c(!0x0);},_0x12310a['onupgradeneeded']=()=>{_0x6df9e0=!0x1;},_0x12310a['onerror']=()=>{var _0x154c7e;_0xe7f77e(((_0x154c7e=_0x12310a['error'])==null?void 0x0:_0x154c7e['message'])||'');};}catch(_0x21aa4f){_0xe7f77e(_0x21aa4f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x16d599,_0xaf766a,_0x1a37a6){super(_0xaf766a),this['code']=_0x16d599,this['customData']=_0x1a37a6,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x1d8c46,_0x9a325,_0x570198){this['service']=_0x1d8c46,this['serviceName']=_0x9a325,this['errors']=_0x570198;}['create'](_0x25b753,..._0x367f2e){const _0x22f771=_0x367f2e[0x0]||{},_0x9aa053=this['service']+'/'+_0x25b753,_0x2d7709=this['errors'][_0x25b753],_0x4b1810=_0x2d7709?vc(_0x2d7709,_0x22f771):'Error',_0x4caaad=this['serviceName']+':\x20'+_0x4b1810+'\x20('+_0x9aa053+').';return new Re(_0x9aa053,_0x4caaad,_0x22f771);}}function vc(_0x3375e5,_0x1d1bd3){return _0x3375e5['replace'](Ec,(_0xf142f9,_0x79228e)=>{const _0x4a1f5c=_0x1d1bd3[_0x79228e];return _0x4a1f5c!=null?String(_0x4a1f5c):'<'+_0x79228e+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x415bd0){return JSON['parse'](_0x415bd0);}function O(_0x1c883d){return JSON['stringify'](_0x1c883d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x4381fa){let _0x24e873={},_0x29da54={},_0x36d756={},_0x1e8479='';try{const _0x3d1e3d=_0x4381fa['split']('.');_0x24e873=Nt(fn(_0x3d1e3d[0x0])||''),_0x29da54=Nt(fn(_0x3d1e3d[0x1])||''),_0x1e8479=_0x3d1e3d[0x2],_0x36d756=_0x29da54['d']||{},delete _0x29da54['d'];}catch{}return{'header':_0x24e873,'claims':_0x29da54,'data':_0x36d756,'signature':_0x1e8479};},Ic=function(_0x2bc8af){const _0x4eefe0=Yr(_0x2bc8af),_0x185476=_0x4eefe0['claims'];return!!_0x185476&&typeof _0x185476=='object'&&_0x185476['hasOwnProperty']('iat');},wc=function(_0x28f0e0){const _0x13369e=Yr(_0x28f0e0)['claims'];return typeof _0x13369e=='object'&&_0x13369e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1f575c,_0x2316a5){return Object['prototype']['hasOwnProperty']['call'](_0x1f575c,_0x2316a5);}function Le(_0x56d351,_0x1776f0){if(Object['prototype']['hasOwnProperty']['call'](_0x56d351,_0x1776f0))return _0x56d351[_0x1776f0];}function pn(_0x440994){for(const _0x33f0ab in _0x440994)if(Object['prototype']['hasOwnProperty']['call'](_0x440994,_0x33f0ab))return!0x1;return!0x0;}function _n(_0x4b6ec3,_0x116532,_0x4ecafb){const _0x9e01f4={};for(const _0x59e00d in _0x4b6ec3)Object['prototype']['hasOwnProperty']['call'](_0x4b6ec3,_0x59e00d)&&(_0x9e01f4[_0x59e00d]=_0x116532['call'](_0x4ecafb,_0x4b6ec3[_0x59e00d],_0x59e00d,_0x4b6ec3));return _0x9e01f4;}function xe(_0x2f6331,_0xfe73fa){if(_0x2f6331===_0xfe73fa)return!0x0;const _0x236e5b=Object['keys'](_0x2f6331),_0x1cf6cf=Object['keys'](_0xfe73fa);for(const _0x4c4141 of _0x236e5b){if(!_0x1cf6cf['includes'](_0x4c4141))return!0x1;const _0x223b6e=_0x2f6331[_0x4c4141],_0x51d8ff=_0xfe73fa[_0x4c4141];if(Ns(_0x223b6e)&&Ns(_0x51d8ff)){if(!xe(_0x223b6e,_0x51d8ff))return!0x1;}else{if(_0x223b6e!==_0x51d8ff)return!0x1;}}for(const _0x1d7ad0 of _0x1cf6cf)if(!_0x236e5b['includes'](_0x1d7ad0))return!0x1;return!0x0;}function Ns(_0x5bfeeb){return _0x5bfeeb!==null&&typeof _0x5bfeeb=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x1dbcda){const _0xa24207=[];for(const [_0x16ef21,_0x4d038a]of Object['entries'](_0x1dbcda))Array['isArray'](_0x4d038a)?_0x4d038a['forEach'](_0x295d73=>{_0xa24207['push'](encodeURIComponent(_0x16ef21)+'='+encodeURIComponent(_0x295d73));}):_0xa24207['push'](encodeURIComponent(_0x16ef21)+'='+encodeURIComponent(_0x4d038a));return _0xa24207['length']?'&'+_0xa24207['join']('&'):'';}function Ct(_0x577ac7){const _0xf2017f={};return _0x577ac7['replace'](/^\?/,'')['split']('&')['forEach'](_0x65f87e=>{if(_0x65f87e){const [_0x2b74f0,_0x1fd9f8]=_0x65f87e['split']('=');_0xf2017f[decodeURIComponent(_0x2b74f0)]=decodeURIComponent(_0x1fd9f8);}}),_0xf2017f;}function Tt(_0x1eed2c){const _0x31bad2=_0x1eed2c['indexOf']('?');if(!_0x31bad2)return'';const _0x388c27=_0x1eed2c['indexOf']('#',_0x31bad2);return _0x1eed2c['substring'](_0x31bad2,_0x388c27>0x0?_0x388c27:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x37cc18=0x1;_0x37cc18<this['blockSize'];++_0x37cc18)this['pad_'][_0x37cc18]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xba2c6a,_0x1add0a){_0x1add0a||(_0x1add0a=0x0);const _0x2112c1=this['W_'];if(typeof _0xba2c6a=='string'){for(let _0x6a4e59=0x0;_0x6a4e59<0x10;_0x6a4e59++)_0x2112c1[_0x6a4e59]=_0xba2c6a['charCodeAt'](_0x1add0a)<<0x18|_0xba2c6a['charCodeAt'](_0x1add0a+0x1)<<0x10|_0xba2c6a['charCodeAt'](_0x1add0a+0x2)<<0x8|_0xba2c6a['charCodeAt'](_0x1add0a+0x3),_0x1add0a+=0x4;}else{for(let _0x28f920=0x0;_0x28f920<0x10;_0x28f920++)_0x2112c1[_0x28f920]=_0xba2c6a[_0x1add0a]<<0x18|_0xba2c6a[_0x1add0a+0x1]<<0x10|_0xba2c6a[_0x1add0a+0x2]<<0x8|_0xba2c6a[_0x1add0a+0x3],_0x1add0a+=0x4;}for(let _0x35cc86=0x10;_0x35cc86<0x50;_0x35cc86++){const _0x55c853=_0x2112c1[_0x35cc86-0x3]^_0x2112c1[_0x35cc86-0x8]^_0x2112c1[_0x35cc86-0xe]^_0x2112c1[_0x35cc86-0x10];_0x2112c1[_0x35cc86]=(_0x55c853<<0x1|_0x55c853>>>0x1f)&0xffffffff;}let _0xfef192=this['chain_'][0x0],_0x8e5bd0=this['chain_'][0x1],_0x1d7a51=this['chain_'][0x2],_0x785c16=this['chain_'][0x3],_0x5ac6f8=this['chain_'][0x4],_0x174138,_0x5369af;for(let _0x5e642e=0x0;_0x5e642e<0x50;_0x5e642e++){_0x5e642e<0x28?_0x5e642e<0x14?(_0x174138=_0x785c16^_0x8e5bd0&(_0x1d7a51^_0x785c16),_0x5369af=0x5a827999):(_0x174138=_0x8e5bd0^_0x1d7a51^_0x785c16,_0x5369af=0x6ed9eba1):_0x5e642e<0x3c?(_0x174138=_0x8e5bd0&_0x1d7a51|_0x785c16&(_0x8e5bd0|_0x1d7a51),_0x5369af=0x8f1bbcdc):(_0x174138=_0x8e5bd0^_0x1d7a51^_0x785c16,_0x5369af=0xca62c1d6);const _0x441597=(_0xfef192<<0x5|_0xfef192>>>0x1b)+_0x174138+_0x5ac6f8+_0x5369af+_0x2112c1[_0x5e642e]&0xffffffff;_0x5ac6f8=_0x785c16,_0x785c16=_0x1d7a51,_0x1d7a51=(_0x8e5bd0<<0x1e|_0x8e5bd0>>>0x2)&0xffffffff,_0x8e5bd0=_0xfef192,_0xfef192=_0x441597;}this['chain_'][0x0]=this['chain_'][0x0]+_0xfef192&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x8e5bd0&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1d7a51&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x785c16&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5ac6f8&0xffffffff;}['update'](_0xe5ee2c,_0x12e00d){if(_0xe5ee2c==null)return;_0x12e00d===void 0x0&&(_0x12e00d=_0xe5ee2c['length']);const _0x109e84=_0x12e00d-this['blockSize'];let _0x35712a=0x0;const _0xc0eee2=this['buf_'];let _0x33ac7a=this['inbuf_'];for(;_0x35712a<_0x12e00d;){if(_0x33ac7a===0x0){for(;_0x35712a<=_0x109e84;)this['compress_'](_0xe5ee2c,_0x35712a),_0x35712a+=this['blockSize'];}if(typeof _0xe5ee2c=='string'){for(;_0x35712a<_0x12e00d;)if(_0xc0eee2[_0x33ac7a]=_0xe5ee2c['charCodeAt'](_0x35712a),++_0x33ac7a,++_0x35712a,_0x33ac7a===this['blockSize']){this['compress_'](_0xc0eee2),_0x33ac7a=0x0;break;}}else{for(;_0x35712a<_0x12e00d;)if(_0xc0eee2[_0x33ac7a]=_0xe5ee2c[_0x35712a],++_0x33ac7a,++_0x35712a,_0x33ac7a===this['blockSize']){this['compress_'](_0xc0eee2),_0x33ac7a=0x0;break;}}}this['inbuf_']=_0x33ac7a,this['total_']+=_0x12e00d;}['digest'](){const _0x487556=[];let _0x3db226=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5c2df6=this['blockSize']-0x1;_0x5c2df6>=0x38;_0x5c2df6--)this['buf_'][_0x5c2df6]=_0x3db226&0xff,_0x3db226/=0x100;this['compress_'](this['buf_']);let _0x134b10=0x0;for(let _0x1a6e3c=0x0;_0x1a6e3c<0x5;_0x1a6e3c++)for(let _0x466332=0x18;_0x466332>=0x0;_0x466332-=0x8)_0x487556[_0x134b10]=this['chain_'][_0x1a6e3c]>>_0x466332&0xff,++_0x134b10;return _0x487556;}}function Tc(_0x4ffe0d,_0x1dde80){const _0x5db8a6=new Sc(_0x4ffe0d,_0x1dde80);return _0x5db8a6['subscribe']['bind'](_0x5db8a6);}class Sc{constructor(_0x3e83cc,_0x7a039e){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x7a039e,this['task']['then'](()=>{_0x3e83cc(this);})['catch'](_0x4ff03d=>{this['error'](_0x4ff03d);});}['next'](_0x599005){this['forEachObserver'](_0x11ea00=>{_0x11ea00['next'](_0x599005);});}['error'](_0x1741ab){this['forEachObserver'](_0x47e70c=>{_0x47e70c['error'](_0x1741ab);}),this['close'](_0x1741ab);}['complete'](){this['forEachObserver'](_0x2351a3=>{_0x2351a3['complete']();}),this['close']();}['subscribe'](_0x5ebfbe,_0x2b2725,_0x145752){let _0x5848b9;if(_0x5ebfbe===void 0x0&&_0x2b2725===void 0x0&&_0x145752===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x5ebfbe,['next','error','complete'])?_0x5848b9=_0x5ebfbe:_0x5848b9={'next':_0x5ebfbe,'error':_0x2b2725,'complete':_0x145752},_0x5848b9['next']===void 0x0&&(_0x5848b9['next']=ti),_0x5848b9['error']===void 0x0&&(_0x5848b9['error']=ti),_0x5848b9['complete']===void 0x0&&(_0x5848b9['complete']=ti);const _0x19812e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5848b9['error'](this['finalError']):_0x5848b9['complete']();}catch{}}),this['observers']['push'](_0x5848b9),_0x19812e;}['unsubscribeOne'](_0x1c43f7){this['observers']===void 0x0||this['observers'][_0x1c43f7]===void 0x0||(delete this['observers'][_0x1c43f7],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x21d204){if(!this['finalized']){for(let _0x3a1df7=0x0;_0x3a1df7<this['observers']['length'];_0x3a1df7++)this['sendOne'](_0x3a1df7,_0x21d204);}}['sendOne'](_0x44e66b,_0x38b6bc){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x44e66b]!==void 0x0)try{_0x38b6bc(this['observers'][_0x44e66b]);}catch(_0x15ddfd){typeof console<'u'&&console['error']&&console['error'](_0x15ddfd);}});}['close'](_0x1f990e){this['finalized']||(this['finalized']=!0x0,_0x1f990e!==void 0x0&&(this['finalError']=_0x1f990e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4364de,_0x2890ed){if(typeof _0x4364de!='object'||_0x4364de===null)return!0x1;for(const _0x933cfb of _0x2890ed)if(_0x933cfb in _0x4364de&&typeof _0x4364de[_0x933cfb]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x466a8e,_0x434204){return _0x466a8e+'\x20failed:\x20'+_0x434204+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2dc15d){const _0x4032a9=[];let _0x111298=0x0;for(let _0x2a86fa=0x0;_0x2a86fa<_0x2dc15d['length'];_0x2a86fa++){let _0x489f4a=_0x2dc15d['charCodeAt'](_0x2a86fa);if(_0x489f4a>=0xd800&&_0x489f4a<=0xdbff){const _0x1a46eb=_0x489f4a-0xd800;_0x2a86fa++,f(_0x2a86fa<_0x2dc15d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x266af8=_0x2dc15d['charCodeAt'](_0x2a86fa)-0xdc00;_0x489f4a=0x10000+(_0x1a46eb<<0xa)+_0x266af8;}_0x489f4a<0x80?_0x4032a9[_0x111298++]=_0x489f4a:_0x489f4a<0x800?(_0x4032a9[_0x111298++]=_0x489f4a>>0x6|0xc0,_0x4032a9[_0x111298++]=_0x489f4a&0x3f|0x80):_0x489f4a<0x10000?(_0x4032a9[_0x111298++]=_0x489f4a>>0xc|0xe0,_0x4032a9[_0x111298++]=_0x489f4a>>0x6&0x3f|0x80,_0x4032a9[_0x111298++]=_0x489f4a&0x3f|0x80):(_0x4032a9[_0x111298++]=_0x489f4a>>0x12|0xf0,_0x4032a9[_0x111298++]=_0x489f4a>>0xc&0x3f|0x80,_0x4032a9[_0x111298++]=_0x489f4a>>0x6&0x3f|0x80,_0x4032a9[_0x111298++]=_0x489f4a&0x3f|0x80);}return _0x4032a9;},Ln=function(_0x1e5e71){let _0x5c4f01=0x0;for(let _0x3afb22=0x0;_0x3afb22<_0x1e5e71['length'];_0x3afb22++){const _0x1b54b3=_0x1e5e71['charCodeAt'](_0x3afb22);_0x1b54b3<0x80?_0x5c4f01++:_0x1b54b3<0x800?_0x5c4f01+=0x2:_0x1b54b3>=0xd800&&_0x1b54b3<=0xdbff?(_0x5c4f01+=0x4,_0x3afb22++):_0x5c4f01+=0x3;}return _0x5c4f01;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x472c7f){return _0x472c7f&&_0x472c7f['_delegate']?_0x472c7f['_delegate']:_0x472c7f;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0xa1bb6b){try{return(_0xa1bb6b['startsWith']('http://')||_0xa1bb6b['startsWith']('https://')?new URL(_0xa1bb6b)['hostname']:_0xa1bb6b)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x481d49){return(await fetch(_0x481d49,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x38390f,_0x537fe1,_0x5028d6){this['name']=_0x38390f,this['instanceFactory']=_0x537fe1,this['type']=_0x5028d6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x520591){return this['instantiationMode']=_0x520591,this;}['setMultipleInstances'](_0xd9395){return this['multipleInstances']=_0xd9395,this;}['setServiceProps'](_0x1fb55b){return this['serviceProps']=_0x1fb55b,this;}['setInstanceCreatedCallback'](_0x11d1c9){return this['onInstanceCreated']=_0x11d1c9,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x117ce3,_0xd595b8){this['name']=_0x117ce3,this['container']=_0xd595b8,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2f9b49){const _0x53dcd8=this['normalizeInstanceIdentifier'](_0x2f9b49);if(!this['instancesDeferred']['has'](_0x53dcd8)){const _0x5ad756=new H();if(this['instancesDeferred']['set'](_0x53dcd8,_0x5ad756),this['isInitialized'](_0x53dcd8)||this['shouldAutoInitialize']())try{const _0x387eb4=this['getOrInitializeService']({'instanceIdentifier':_0x53dcd8});_0x387eb4&&_0x5ad756['resolve'](_0x387eb4);}catch{}}return this['instancesDeferred']['get'](_0x53dcd8)['promise'];}['getImmediate'](_0xd8950e){const _0x1d2bac=this['normalizeInstanceIdentifier'](_0xd8950e==null?void 0x0:_0xd8950e['identifier']),_0x1746ec=(_0xd8950e==null?void 0x0:_0xd8950e['optional'])??!0x1;if(this['isInitialized'](_0x1d2bac)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1d2bac});}catch(_0xe01721){if(_0x1746ec)return null;throw _0xe01721;}else{if(_0x1746ec)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x530a3c){if(_0x530a3c['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x530a3c['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x530a3c,!!this['shouldAutoInitialize']()){if(Pc(_0x530a3c))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x400f36,_0x5954cf]of this['instancesDeferred']['entries']()){const _0x2ea4e8=this['normalizeInstanceIdentifier'](_0x400f36);try{const _0x82dd0f=this['getOrInitializeService']({'instanceIdentifier':_0x2ea4e8});_0x5954cf['resolve'](_0x82dd0f);}catch{}}}}['clearInstance'](_0x575559=Ne){this['instancesDeferred']['delete'](_0x575559),this['instancesOptions']['delete'](_0x575559),this['instances']['delete'](_0x575559);}async['delete'](){const _0x510407=Array['from'](this['instances']['values']());await Promise['all']([..._0x510407['filter'](_0x508363=>'INTERNAL'in _0x508363)['map'](_0x72efc8=>_0x72efc8['INTERNAL']['delete']()),..._0x510407['filter'](_0x22b2f5=>'_delete'in _0x22b2f5)['map'](_0x4e8d83=>_0x4e8d83['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2bb2fd=Ne){return this['instances']['has'](_0x2bb2fd);}['getOptions'](_0x36b02a=Ne){return this['instancesOptions']['get'](_0x36b02a)||{};}['initialize'](_0x576b6b={}){const {options:_0x571b5a={}}=_0x576b6b,_0x545268=this['normalizeInstanceIdentifier'](_0x576b6b['instanceIdentifier']);if(this['isInitialized'](_0x545268))throw Error(this['name']+'('+_0x545268+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3aee0d=this['getOrInitializeService']({'instanceIdentifier':_0x545268,'options':_0x571b5a});for(const [_0x3f375f,_0x291358]of this['instancesDeferred']['entries']()){const _0x2444dc=this['normalizeInstanceIdentifier'](_0x3f375f);_0x545268===_0x2444dc&&_0x291358['resolve'](_0x3aee0d);}return _0x3aee0d;}['onInit'](_0x4250b5,_0x5835d3){const _0x594ffd=this['normalizeInstanceIdentifier'](_0x5835d3),_0x1d5192=this['onInitCallbacks']['get'](_0x594ffd)??new Set();_0x1d5192['add'](_0x4250b5),this['onInitCallbacks']['set'](_0x594ffd,_0x1d5192);const _0x72bd76=this['instances']['get'](_0x594ffd);return _0x72bd76&&_0x4250b5(_0x72bd76,_0x594ffd),()=>{_0x1d5192['delete'](_0x4250b5);};}['invokeOnInitCallbacks'](_0x1dd15f,_0x48ee8d){const _0x5d9c14=this['onInitCallbacks']['get'](_0x48ee8d);if(_0x5d9c14){for(const _0x59fe01 of _0x5d9c14)try{_0x59fe01(_0x1dd15f,_0x48ee8d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2edfe4,options:_0x2b39b4={}}){let _0x1b664d=this['instances']['get'](_0x2edfe4);if(!_0x1b664d&&this['component']&&(_0x1b664d=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2edfe4),'options':_0x2b39b4}),this['instances']['set'](_0x2edfe4,_0x1b664d),this['instancesOptions']['set'](_0x2edfe4,_0x2b39b4),this['invokeOnInitCallbacks'](_0x1b664d,_0x2edfe4),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2edfe4,_0x1b664d);}catch{}return _0x1b664d||null;}['normalizeInstanceIdentifier'](_0x23a19d=Ne){return this['component']?this['component']['multipleInstances']?_0x23a19d:Ne:_0x23a19d;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x46a35b){return _0x46a35b===Ne?void 0x0:_0x46a35b;}function Pc(_0x4b7a52){return _0x4b7a52['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x473346){this['name']=_0x473346,this['providers']=new Map();}['addComponent'](_0x2dd064){const _0x5aac62=this['getProvider'](_0x2dd064['name']);if(_0x5aac62['isComponentSet']())throw new Error('Component\x20'+_0x2dd064['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5aac62['setComponent'](_0x2dd064);}['addOrOverwriteComponent'](_0x3cc3de){this['getProvider'](_0x3cc3de['name'])['isComponentSet']()&&this['providers']['delete'](_0x3cc3de['name']),this['addComponent'](_0x3cc3de);}['getProvider'](_0x3cd184){if(this['providers']['has'](_0x3cd184))return this['providers']['get'](_0x3cd184);const _0x2e3326=new Ac(_0x3cd184,this);return this['providers']['set'](_0x3cd184,_0x2e3326),_0x2e3326;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1ad489){_0x1ad489[_0x1ad489['DEBUG']=0x0]='DEBUG',_0x1ad489[_0x1ad489['VERBOSE']=0x1]='VERBOSE',_0x1ad489[_0x1ad489['INFO']=0x2]='INFO',_0x1ad489[_0x1ad489['WARN']=0x3]='WARN',_0x1ad489[_0x1ad489['ERROR']=0x4]='ERROR',_0x1ad489[_0x1ad489['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x19a6c4,_0x492628,..._0x158389)=>{if(_0x492628<_0x19a6c4['logLevel'])return;const _0x1a5a13=new Date()['toISOString'](),_0x7c13c0=Mc[_0x492628];if(_0x7c13c0)console[_0x7c13c0]('['+_0x1a5a13+']\x20\x20'+_0x19a6c4['name']+':',..._0x158389);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x492628+')');};class Bi{constructor(_0x15beab){this['name']=_0x15beab,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2326d2){if(!(_0x2326d2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2326d2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2326d2;}['setLogLevel'](_0x146731){this['_logLevel']=typeof _0x146731=='string'?Oc[_0x146731]:_0x146731;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x50e5e5){if(typeof _0x50e5e5!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x50e5e5;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5e56aa){this['_userLogHandler']=_0x5e56aa;}['debug'](..._0x2f4bcb){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2f4bcb),this['_logHandler'](this,T['DEBUG'],..._0x2f4bcb);}['log'](..._0x33503c){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x33503c),this['_logHandler'](this,T['VERBOSE'],..._0x33503c);}['info'](..._0x4a36c8){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4a36c8),this['_logHandler'](this,T['INFO'],..._0x4a36c8);}['warn'](..._0x13db81){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x13db81),this['_logHandler'](this,T['WARN'],..._0x13db81);}['error'](..._0x21e92b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x21e92b),this['_logHandler'](this,T['ERROR'],..._0x21e92b);}}const xc=(_0x386b31,_0x4e790e)=>_0x4e790e['some'](_0x2f9c46=>_0x386b31 instanceof _0x2f9c46);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x331028){const _0x3a4e43=new Promise((_0x1e8245,_0x4c3862)=>{const _0x2af4e1=()=>{_0x331028['removeEventListener']('success',_0x59106d),_0x331028['removeEventListener']('error',_0x32e941);},_0x59106d=()=>{_0x1e8245(ge(_0x331028['result'])),_0x2af4e1();},_0x32e941=()=>{_0x4c3862(_0x331028['error']),_0x2af4e1();};_0x331028['addEventListener']('success',_0x59106d),_0x331028['addEventListener']('error',_0x32e941);});return _0x3a4e43['then'](_0x2c071b=>{_0x2c071b instanceof IDBCursor&&Jr['set'](_0x2c071b,_0x331028);})['catch'](()=>{}),Vi['set'](_0x3a4e43,_0x331028),_0x3a4e43;}function Bc(_0x5e7f02){if(_i['has'](_0x5e7f02))return;const _0x14595d=new Promise((_0x3645a6,_0x2106d3)=>{const _0x1c3274=()=>{_0x5e7f02['removeEventListener']('complete',_0x42f7ac),_0x5e7f02['removeEventListener']('error',_0xa739c1),_0x5e7f02['removeEventListener']('abort',_0xa739c1);},_0x42f7ac=()=>{_0x3645a6(),_0x1c3274();},_0xa739c1=()=>{_0x2106d3(_0x5e7f02['error']||new DOMException('AbortError','AbortError')),_0x1c3274();};_0x5e7f02['addEventListener']('complete',_0x42f7ac),_0x5e7f02['addEventListener']('error',_0xa739c1),_0x5e7f02['addEventListener']('abort',_0xa739c1);});_i['set'](_0x5e7f02,_0x14595d);}let gi={'get'(_0x51bc9c,_0x5c8caf,_0x7d598f){if(_0x51bc9c instanceof IDBTransaction){if(_0x5c8caf==='done')return _i['get'](_0x51bc9c);if(_0x5c8caf==='objectStoreNames')return _0x51bc9c['objectStoreNames']||Xr['get'](_0x51bc9c);if(_0x5c8caf==='store')return _0x7d598f['objectStoreNames'][0x1]?void 0x0:_0x7d598f['objectStore'](_0x7d598f['objectStoreNames'][0x0]);}return ge(_0x51bc9c[_0x5c8caf]);},'set'(_0x1dbc07,_0x431a62,_0x3aaf92){return _0x1dbc07[_0x431a62]=_0x3aaf92,!0x0;},'has'(_0x33e050,_0x6a8da7){return _0x33e050 instanceof IDBTransaction&&(_0x6a8da7==='done'||_0x6a8da7==='store')?!0x0:_0x6a8da7 in _0x33e050;}};function Vc(_0x420244){gi=_0x420244(gi);}function Hc(_0x414c24){return _0x414c24===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x8abc22,..._0x2a396c){const _0x199c71=_0x414c24['call'](ii(this),_0x8abc22,..._0x2a396c);return Xr['set'](_0x199c71,_0x8abc22['sort']?_0x8abc22['sort']():[_0x8abc22]),ge(_0x199c71);}:Uc()['includes'](_0x414c24)?function(..._0x4afd0c){return _0x414c24['apply'](ii(this),_0x4afd0c),ge(Jr['get'](this));}:function(..._0x187731){return ge(_0x414c24['apply'](ii(this),_0x187731));};}function $c(_0x3c78b6){return typeof _0x3c78b6=='function'?Hc(_0x3c78b6):(_0x3c78b6 instanceof IDBTransaction&&Bc(_0x3c78b6),xc(_0x3c78b6,Fc())?new Proxy(_0x3c78b6,gi):_0x3c78b6);}function ge(_0x1bf214){if(_0x1bf214 instanceof IDBRequest)return Wc(_0x1bf214);if(ni['has'](_0x1bf214))return ni['get'](_0x1bf214);const _0x366f54=$c(_0x1bf214);return _0x366f54!==_0x1bf214&&(ni['set'](_0x1bf214,_0x366f54),Vi['set'](_0x366f54,_0x1bf214)),_0x366f54;}const ii=_0x273660=>Vi['get'](_0x273660);function Gc(_0x1e9882,_0x26eca2,{blocked:_0x1c5415,upgrade:_0x4dd6c5,blocking:_0x2b20e7,terminated:_0x353038}={}){const _0x54274a=indexedDB['open'](_0x1e9882,_0x26eca2),_0x3100d4=ge(_0x54274a);return _0x4dd6c5&&_0x54274a['addEventListener']('upgradeneeded',_0x38524b=>{_0x4dd6c5(ge(_0x54274a['result']),_0x38524b['oldVersion'],_0x38524b['newVersion'],ge(_0x54274a['transaction']),_0x38524b);}),_0x1c5415&&_0x54274a['addEventListener']('blocked',_0x299fd3=>_0x1c5415(_0x299fd3['oldVersion'],_0x299fd3['newVersion'],_0x299fd3)),_0x3100d4['then'](_0x381f5e=>{_0x353038&&_0x381f5e['addEventListener']('close',()=>_0x353038()),_0x2b20e7&&_0x381f5e['addEventListener']('versionchange',_0x5138ff=>_0x2b20e7(_0x5138ff['oldVersion'],_0x5138ff['newVersion'],_0x5138ff));})['catch'](()=>{}),_0x3100d4;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x27bfd0,_0x53875d){if(!(_0x27bfd0 instanceof IDBDatabase&&!(_0x53875d in _0x27bfd0)&&typeof _0x53875d=='string'))return;if(si['get'](_0x53875d))return si['get'](_0x53875d);const _0x18dd11=_0x53875d['replace'](/FromIndex$/,''),_0x597c12=_0x53875d!==_0x18dd11,_0x228951=zc['includes'](_0x18dd11);if(!(_0x18dd11 in(_0x597c12?IDBIndex:IDBObjectStore)['prototype'])||!(_0x228951||qc['includes'](_0x18dd11)))return;const _0x495b32=async function(_0x3aab8b,..._0x508704){const _0x981443=this['transaction'](_0x3aab8b,_0x228951?'readwrite':'readonly');let _0x16b121=_0x981443['store'];return _0x597c12&&(_0x16b121=_0x16b121['index'](_0x508704['shift']())),(await Promise['all']([_0x16b121[_0x18dd11](..._0x508704),_0x228951&&_0x981443['done']]))[0x0];};return si['set'](_0x53875d,_0x495b32),_0x495b32;}Vc(_0x359c39=>({..._0x359c39,'get':(_0x23b40a,_0x1729c6,_0x49a1d4)=>Ms(_0x23b40a,_0x1729c6)||_0x359c39['get'](_0x23b40a,_0x1729c6,_0x49a1d4),'has':(_0x16bc37,_0x40574d)=>!!Ms(_0x16bc37,_0x40574d)||_0x359c39['has'](_0x16bc37,_0x40574d)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x13e524){this['container']=_0x13e524;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x26a5cd=>{if(Kc(_0x26a5cd)){const _0x18f45c=_0x26a5cd['getImmediate']();return _0x18f45c['library']+'/'+_0x18f45c['version'];}else return null;})['filter'](_0x3ccd50=>_0x3ccd50)['join']('\x20');}}function Kc(_0x11cb4c){const _0x1fef26=_0x11cb4c['getComponent']();return(_0x1fef26==null?void 0x0:_0x1fef26['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x5278d6,_0x27db72){try{_0x5278d6['container']['addComponent'](_0x27db72);}catch(_0x3d7922){oe['debug']('Component\x20'+_0x27db72['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5278d6['name'],_0x3d7922);}}function st(_0x44ebbf){const _0x95701c=_0x44ebbf['name'];if(Ei['has'](_0x95701c))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x95701c+'.'),!0x1;Ei['set'](_0x95701c,_0x44ebbf);for(const _0x575dc2 of Ue['values']())xs(_0x575dc2,_0x44ebbf);for(const _0x4b797b of vi['values']())xs(_0x4b797b,_0x44ebbf);return!0x0;}function Hi(_0x284bb9,_0x300d49){const _0x31178b=_0x284bb9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x31178b&&_0x31178b['triggerHeartbeat'](),_0x284bb9['container']['getProvider'](_0x300d49);}function $(_0x3b3781){return _0x3b3781==null?!0x1:_0x3b3781['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x546e35,_0xcc69fd,_0x55895b){this['_isDeleted']=!0x1,this['_options']={..._0x546e35},this['_config']={..._0xcc69fd},this['_name']=_0xcc69fd['name'],this['_automaticDataCollectionEnabled']=_0xcc69fd['automaticDataCollectionEnabled'],this['_container']=_0x55895b,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x12a862){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x12a862;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3f876a){this['_isDeleted']=_0x3f876a;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x24489f,_0x5f89ae={}){let _0x236969=_0x24489f;typeof _0x5f89ae!='object'&&(_0x5f89ae={'name':_0x5f89ae});const _0x577ed2={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x5f89ae},_0x443a2d=_0x577ed2['name'];if(typeof _0x443a2d!='string'||!_0x443a2d)throw me['create']('bad-app-name',{'appName':String(_0x443a2d)});if(_0x236969||(_0x236969=zr()),!_0x236969)throw me['create']('no-options');const _0x236121=Ue['get'](_0x443a2d);if(_0x236121){if(xe(_0x236969,_0x236121['options'])&&xe(_0x577ed2,_0x236121['config']))return _0x236121;throw me['create']('duplicate-app',{'appName':_0x443a2d});}const _0xeac160=new Nc(_0x443a2d);for(const _0x26e01b of Ei['values']())_0xeac160['addComponent'](_0x26e01b);const _0x3a3ee8=new Tl(_0x236969,_0x577ed2,_0xeac160);return Ue['set'](_0x443a2d,_0x3a3ee8),_0x3a3ee8;}function Zr(_0x117453=yi){const _0x58eefb=Ue['get'](_0x117453);if(!_0x58eefb&&_0x117453===yi&&zr())return Sl();if(!_0x58eefb)throw me['create']('no-app',{'appName':_0x117453});return _0x58eefb;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x1be858){let _0x5e0f8e=!0x1;const _0x56380d=_0x1be858['name'];Ue['has'](_0x56380d)?(_0x5e0f8e=!0x0,Ue['delete'](_0x56380d)):vi['has'](_0x56380d)&&_0x1be858['decRefCount']()<=0x0&&(vi['delete'](_0x56380d),_0x5e0f8e=!0x0),_0x5e0f8e&&(await Promise['all'](_0x1be858['container']['getProviders']()['map'](_0x1ad6f9=>_0x1ad6f9['delete']())),_0x1be858['isDeleted']=!0x0);}function ye(_0x2f0bcf,_0x294100,_0x4bbf47){let _0x3a1da5=wl[_0x2f0bcf]??_0x2f0bcf;_0x4bbf47&&(_0x3a1da5+='-'+_0x4bbf47);const _0x415142=_0x3a1da5['match'](/\s|\//),_0xade0f=_0x294100['match'](/\s|\//);if(_0x415142||_0xade0f){const _0x159299=['Unable\x20to\x20register\x20library\x20\x22'+_0x3a1da5+'\x22\x20with\x20version\x20\x22'+_0x294100+'\x22:'];_0x415142&&_0x159299['push']('library\x20name\x20\x22'+_0x3a1da5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x415142&&_0xade0f&&_0x159299['push']('and'),_0xade0f&&_0x159299['push']('version\x20name\x20\x22'+_0x294100+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x159299['join']('\x20'));return;}st(new Fe(_0x3a1da5+'-version',()=>({'library':_0x3a1da5,'version':_0x294100}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1cf6c5,_0x49dae8)=>{switch(_0x49dae8){case 0x0:try{_0x1cf6c5['createObjectStore'](Ot);}catch(_0x473aa9){console['warn'](_0x473aa9);}}}})['catch'](_0x3a100c=>{throw me['create']('idb-open',{'originalErrorMessage':_0x3a100c['message']});})),ri;}async function Al(_0x394261){try{const _0x3518b0=(await eo())['transaction'](Ot),_0x18a7e5=await _0x3518b0['objectStore'](Ot)['get'](to(_0x394261));return await _0x3518b0['done'],_0x18a7e5;}catch(_0x27fb74){if(_0x27fb74 instanceof Re)oe['warn'](_0x27fb74['message']);else{const _0x48ddf6=me['create']('idb-get',{'originalErrorMessage':_0x27fb74==null?void 0x0:_0x27fb74['message']});oe['warn'](_0x48ddf6['message']);}}}async function Fs(_0x2edf4e,_0xe6e01b){try{const _0x11aa35=(await eo())['transaction'](Ot,'readwrite');await _0x11aa35['objectStore'](Ot)['put'](_0xe6e01b,to(_0x2edf4e)),await _0x11aa35['done'];}catch(_0x53da39){if(_0x53da39 instanceof Re)oe['warn'](_0x53da39['message']);else{const _0x73d079=me['create']('idb-set',{'originalErrorMessage':_0x53da39==null?void 0x0:_0x53da39['message']});oe['warn'](_0x73d079['message']);}}}function to(_0x3356e7){return _0x3356e7['name']+'!'+_0x3356e7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x1cdd74){this['container']=_0x1cdd74,this['_heartbeatsCache']=null;const _0x32f4d6=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x32f4d6),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3cfa05=>(this['_heartbeatsCache']=_0x3cfa05,_0x3cfa05));}async['triggerHeartbeat'](){var _0x1d0351,_0x1e7ffc;try{const _0x124441=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x565746=Us();if(((_0x1d0351=this['_heartbeatsCache'])==null?void 0x0:_0x1d0351['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x1e7ffc=this['_heartbeatsCache'])==null?void 0x0:_0x1e7ffc['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x565746||this['_heartbeatsCache']['heartbeats']['some'](_0x815eed=>_0x815eed['date']===_0x565746))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x565746,'agent':_0x124441}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x3a4d19=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3a4d19,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x46e8b0){oe['warn'](_0x46e8b0);}}async['getHeartbeatsHeader'](){var _0x916194;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x916194=this['_heartbeatsCache'])==null?void 0x0:_0x916194['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1832b7=Us(),{heartbeatsToSend:_0x498b74,unsentEntries:_0x4eee6c}=Ol(this['_heartbeatsCache']['heartbeats']),_0x225412=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x498b74}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1832b7,_0x4eee6c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4eee6c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x225412;}catch(_0x4244ec){return oe['warn'](_0x4244ec),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x29ef4c,_0x52ec8b=kl){const _0x4ecef0=[];let _0x288476=_0x29ef4c['slice']();for(const _0x36175d of _0x29ef4c){const _0x40b048=_0x4ecef0['find'](_0x13f7b7=>_0x13f7b7['agent']===_0x36175d['agent']);if(_0x40b048){if(_0x40b048['dates']['push'](_0x36175d['date']),Ws(_0x4ecef0)>_0x52ec8b){_0x40b048['dates']['pop']();break;}}else{if(_0x4ecef0['push']({'agent':_0x36175d['agent'],'dates':[_0x36175d['date']]}),Ws(_0x4ecef0)>_0x52ec8b){_0x4ecef0['pop']();break;}}_0x288476=_0x288476['slice'](0x1);}return{'heartbeatsToSend':_0x4ecef0,'unsentEntries':_0x288476};}class Dl{constructor(_0x5ba926){this['app']=_0x5ba926,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2f99e4=await Al(this['app']);return _0x2f99e4!=null&&_0x2f99e4['heartbeats']?_0x2f99e4:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4cae4d){if(await this['_canUseIndexedDBPromise']){const _0x376ca8=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4cae4d['lastSentHeartbeatDate']??_0x376ca8['lastSentHeartbeatDate'],'heartbeats':_0x4cae4d['heartbeats']});}else return;}async['add'](_0x1afcda){if(await this['_canUseIndexedDBPromise']){const _0x1b032f=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1afcda['lastSentHeartbeatDate']??_0x1b032f['lastSentHeartbeatDate'],'heartbeats':[..._0x1b032f['heartbeats'],..._0x1afcda['heartbeats']]});}else return;}}function Ws(_0x3d93b2){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3d93b2}))['length'];}function Ml(_0x3925e4){if(_0x3925e4['length']===0x0)return-0x1;let _0x10e62a=0x0,_0x11d1de=_0x3925e4[0x0]['date'];for(let _0x540078=0x1;_0x540078<_0x3925e4['length'];_0x540078++)_0x3925e4[_0x540078]['date']<_0x11d1de&&(_0x11d1de=_0x3925e4[_0x540078]['date'],_0x10e62a=_0x540078);return _0x10e62a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x394ef2){st(new Fe('platform-logger',_0x8f6ddc=>new jc(_0x8f6ddc),'PRIVATE')),st(new Fe('heartbeat',_0x3ea02e=>new Nl(_0x3ea02e),'PRIVATE')),ye(mi,Ls,_0x394ef2),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5e3fb0){no=_0x5e3fb0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3960e8){this['domStorage_']=_0x3960e8,this['prefix_']='firebase:';}['set'](_0x13ea32,_0x1480de){_0x1480de==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x13ea32)):this['domStorage_']['setItem'](this['prefixedName_'](_0x13ea32),O(_0x1480de));}['get'](_0x3720b6){const _0xc96888=this['domStorage_']['getItem'](this['prefixedName_'](_0x3720b6));return _0xc96888==null?null:Nt(_0xc96888);}['remove'](_0x3a6107){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3a6107));}['prefixedName_'](_0x31774f){return this['prefix_']+_0x31774f;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x3fed92,_0x263829){_0x263829==null?delete this['cache_'][_0x3fed92]:this['cache_'][_0x3fed92]=_0x263829;}['get'](_0x37f2b3){return Q(this['cache_'],_0x37f2b3)?this['cache_'][_0x37f2b3]:null;}['remove'](_0x49bf25){delete this['cache_'][_0x49bf25];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x56f5a4){try{if(typeof window<'u'&&typeof window[_0x56f5a4]<'u'){const _0x45bd0a=window[_0x56f5a4];return _0x45bd0a['setItem']('firebase:sentinel','cache'),_0x45bd0a['removeItem']('firebase:sentinel'),new Wl(_0x45bd0a);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x402717=0x1;return function(){return _0x402717++;};}()),ro=function(_0x56fbb4){const _0x4f9e6d=Rc(_0x56fbb4),_0x52f1e8=new Cc();_0x52f1e8['update'](_0x4f9e6d);const _0x1369a0=_0x52f1e8['digest']();return Fi['encodeByteArray'](_0x1369a0);},zt=function(..._0x4dcd75){let _0x2fae05='';for(let _0x1910dd=0x0;_0x1910dd<_0x4dcd75['length'];_0x1910dd++){const _0x2c9f46=_0x4dcd75[_0x1910dd];Array['isArray'](_0x2c9f46)||_0x2c9f46&&typeof _0x2c9f46=='object'&&typeof _0x2c9f46['length']=='number'?_0x2fae05+=zt['apply'](null,_0x2c9f46):typeof _0x2c9f46=='object'?_0x2fae05+=O(_0x2c9f46):_0x2fae05+=_0x2c9f46,_0x2fae05+='\x20';}return _0x2fae05;};let St=null,$s=!0x0;const Hl=function(_0x7e8bf2,_0x3bbd6f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0xa41fcb){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x45f7f7=zt['apply'](null,_0xa41fcb);St(_0x45f7f7);}},jt=function(_0x518181){return function(..._0x3d7f54){L(_0x518181,..._0x3d7f54);};},Ii=function(..._0x1d27bb){const _0x547955='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1d27bb);Ze['error'](_0x547955);},ae=function(..._0x33d9c7){const _0x10a20a='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x33d9c7);throw Ze['error'](_0x10a20a),new Error(_0x10a20a);},U=function(..._0x238b2f){const _0xb5f452='FIREBASE\x20WARNING:\x20'+zt(..._0x238b2f);Ze['warn'](_0xb5f452);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x1a4638){return typeof _0x1a4638=='number'&&(_0x1a4638!==_0x1a4638||_0x1a4638===Number['POSITIVE_INFINITY']||_0x1a4638===Number['NEGATIVE_INFINITY']);},Gl=function(_0x1b0f60){if(document['readyState']==='complete')_0x1b0f60();else{let _0xd908c1=!0x1;const _0xec6009=function(){if(!document['body']){setTimeout(_0xec6009,Math['floor'](0xa));return;}_0xd908c1||(_0xd908c1=!0x0,_0x1b0f60());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xec6009,!0x1),window['addEventListener']('load',_0xec6009,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xec6009();}),window['attachEvent']('onload',_0xec6009));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x2a68b7,_0x30caaf){if(_0x2a68b7===_0x30caaf)return 0x0;if(_0x2a68b7===We||_0x30caaf===we)return-0x1;if(_0x30caaf===We||_0x2a68b7===we)return 0x1;{const _0x1ba065=Gs(_0x2a68b7),_0x12ba8c=Gs(_0x30caaf);return _0x1ba065!==null?_0x12ba8c!==null?_0x1ba065-_0x12ba8c===0x0?_0x2a68b7['length']-_0x30caaf['length']:_0x1ba065-_0x12ba8c:-0x1:_0x12ba8c!==null?0x1:_0x2a68b7<_0x30caaf?-0x1:0x1;}},ql=function(_0x6ec3a5,_0x34c54f){return _0x6ec3a5===_0x34c54f?0x0:_0x6ec3a5<_0x34c54f?-0x1:0x1;},vt=function(_0x209b4a,_0x1210bc){if(_0x1210bc&&_0x209b4a in _0x1210bc)return _0x1210bc[_0x209b4a];throw new Error('Missing\x20required\x20key\x20('+_0x209b4a+')\x20in\x20object:\x20'+O(_0x1210bc));},$i=function(_0x42984e){if(typeof _0x42984e!='object'||_0x42984e===null)return O(_0x42984e);const _0x46223a=[];for(const _0x5241c9 in _0x42984e)_0x46223a['push'](_0x5241c9);_0x46223a['sort']();let _0xce6f91='{';for(let _0x5d7047=0x0;_0x5d7047<_0x46223a['length'];_0x5d7047++)_0x5d7047!==0x0&&(_0xce6f91+=','),_0xce6f91+=O(_0x46223a[_0x5d7047]),_0xce6f91+=':',_0xce6f91+=$i(_0x42984e[_0x46223a[_0x5d7047]]);return _0xce6f91+='}',_0xce6f91;},oo=function(_0x56e475,_0x48d8c0){const _0x2becf2=_0x56e475['length'];if(_0x2becf2<=_0x48d8c0)return[_0x56e475];const _0x120b2a=[];for(let _0x1fa55d=0x0;_0x1fa55d<_0x2becf2;_0x1fa55d+=_0x48d8c0)_0x1fa55d+_0x48d8c0>_0x2becf2?_0x120b2a['push'](_0x56e475['substring'](_0x1fa55d,_0x2becf2)):_0x120b2a['push'](_0x56e475['substring'](_0x1fa55d,_0x1fa55d+_0x48d8c0));return _0x120b2a;};function x(_0x534beb,_0x21e78b){for(const _0x2abcc7 in _0x534beb)_0x534beb['hasOwnProperty'](_0x2abcc7)&&_0x21e78b(_0x2abcc7,_0x534beb[_0x2abcc7]);}const ao=function(_0x582129){f(!xn(_0x582129),'Invalid\x20JSON\x20number');const _0x2da870=0xb,_0x30c3c1=0x34,_0x1b6880=(0x1<<_0x2da870-0x1)-0x1;let _0x41b0d8,_0x3e10b6,_0x54e4cb,_0x4d5b73,_0x33d5ef;_0x582129===0x0?(_0x3e10b6=0x0,_0x54e4cb=0x0,_0x41b0d8=0x1/_0x582129===-0x1/0x0?0x1:0x0):(_0x41b0d8=_0x582129<0x0,_0x582129=Math['abs'](_0x582129),_0x582129>=Math['pow'](0x2,0x1-_0x1b6880)?(_0x4d5b73=Math['min'](Math['floor'](Math['log'](_0x582129)/Math['LN2']),_0x1b6880),_0x3e10b6=_0x4d5b73+_0x1b6880,_0x54e4cb=Math['round'](_0x582129*Math['pow'](0x2,_0x30c3c1-_0x4d5b73)-Math['pow'](0x2,_0x30c3c1))):(_0x3e10b6=0x0,_0x54e4cb=Math['round'](_0x582129/Math['pow'](0x2,0x1-_0x1b6880-_0x30c3c1))));const _0x273fa2=[];for(_0x33d5ef=_0x30c3c1;_0x33d5ef;_0x33d5ef-=0x1)_0x273fa2['push'](_0x54e4cb%0x2?0x1:0x0),_0x54e4cb=Math['floor'](_0x54e4cb/0x2);for(_0x33d5ef=_0x2da870;_0x33d5ef;_0x33d5ef-=0x1)_0x273fa2['push'](_0x3e10b6%0x2?0x1:0x0),_0x3e10b6=Math['floor'](_0x3e10b6/0x2);_0x273fa2['push'](_0x41b0d8?0x1:0x0),_0x273fa2['reverse']();const _0x1864fc=_0x273fa2['join']('');let _0x28d5db='';for(_0x33d5ef=0x0;_0x33d5ef<0x40;_0x33d5ef+=0x8){let _0x25e133=parseInt(_0x1864fc['substr'](_0x33d5ef,0x8),0x2)['toString'](0x10);_0x25e133['length']===0x1&&(_0x25e133='0'+_0x25e133),_0x28d5db=_0x28d5db+_0x25e133;}return _0x28d5db['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x5a7a01,_0x32fbba){let _0x4d90db='Unknown\x20Error';_0x5a7a01==='too_big'?_0x4d90db='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5a7a01==='permission_denied'?_0x4d90db='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5a7a01==='unavailable'&&(_0x4d90db='The\x20service\x20is\x20unavailable');const _0x352f06=new Error(_0x5a7a01+'\x20at\x20'+_0x32fbba['_path']['toString']()+':\x20'+_0x4d90db);return _0x352f06['code']=_0x5a7a01['toUpperCase'](),_0x352f06;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x44f7c9){if(Yl['test'](_0x44f7c9)){const _0x2c864d=Number(_0x44f7c9);if(_0x2c864d>=Ql&&_0x2c864d<=Jl)return _0x2c864d;}return null;},ft=function(_0x54fa75){try{_0x54fa75();}catch(_0x5aaa94){setTimeout(()=>{const _0x5b537d=_0x5aaa94['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5b537d),_0x5aaa94;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x48488d,_0x1286a0){const _0x3a1e17=setTimeout(_0x48488d,_0x1286a0);return typeof _0x3a1e17=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3a1e17):typeof _0x3a1e17=='object'&&_0x3a1e17['unref']&&_0x3a1e17['unref'](),_0x3a1e17;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3ac403,_0x20b2a3){this['appCheckProvider']=_0x20b2a3,this['appName']=_0x3ac403['name'],$(_0x3ac403)&&_0x3ac403['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3ac403['settings']['appCheckToken']),this['appCheck']=_0x20b2a3==null?void 0x0:_0x20b2a3['getImmediate']({'optional':!0x0}),this['appCheck']||_0x20b2a3==null||_0x20b2a3['get']()['then'](_0xc9d24d=>this['appCheck']=_0xc9d24d);}['getToken'](_0x550172){if(this['serverAppAppCheckToken']){if(_0x550172)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x550172):new Promise((_0x4c3189,_0x19aa7b)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x550172)['then'](_0x4c3189,_0x19aa7b):_0x4c3189(null);},0x0);});}['addTokenChangeListener'](_0x232692){var _0x5b339b;(_0x5b339b=this['appCheckProvider'])==null||_0x5b339b['get']()['then'](_0x533d34=>_0x533d34['addTokenListener'](_0x232692));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2e15b9,_0x5bce32,_0x32bbe1){this['appName_']=_0x2e15b9,this['firebaseOptions_']=_0x5bce32,this['authProvider_']=_0x32bbe1,this['auth_']=null,this['auth_']=_0x32bbe1['getImmediate']({'optional':!0x0}),this['auth_']||_0x32bbe1['onInit'](_0xdb39a7=>this['auth_']=_0xdb39a7);}['getToken'](_0x334a20){return this['auth_']?this['auth_']['getToken'](_0x334a20)['catch'](_0xd8c982=>_0xd8c982&&_0xd8c982['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xd8c982)):new Promise((_0x115397,_0x2b858d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x334a20)['then'](_0x115397,_0x2b858d):_0x115397(null);},0x0);});}['addTokenChangeListener'](_0x3daad6){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3daad6):this['authProvider_']['get']()['then'](_0x552627=>_0x552627['addAuthTokenListener'](_0x3daad6));}['removeTokenChangeListener'](_0x19197b){this['authProvider_']['get']()['then'](_0x201120=>_0x201120['removeAuthTokenListener'](_0x19197b));}['notifyForInvalidToken'](){let _0x498f92='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x498f92+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x498f92+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x498f92+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x498f92);}}class an{constructor(_0x22e728){this['accessToken']=_0x22e728;}['getToken'](_0x36c382){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x35baf6){_0x35baf6(this['accessToken']);}['removeTokenChangeListener'](_0x3e2753){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x352438,_0x535d08,_0x4c43e4,_0x4209dc,_0x36c3ec=!0x1,_0x1fe72a='',_0x25cf68=!0x1,_0x1fc73a=!0x1,_0x4eb9ee=null){this['secure']=_0x535d08,this['namespace']=_0x4c43e4,this['webSocketOnly']=_0x4209dc,this['nodeAdmin']=_0x36c3ec,this['persistenceKey']=_0x1fe72a,this['includeNamespaceInQueryParams']=_0x25cf68,this['isUsingEmulator']=_0x1fc73a,this['emulatorOptions']=_0x4eb9ee,this['_host']=_0x352438['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x352438)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1a09cf){_0x1a09cf!==this['internalHost']&&(this['internalHost']=_0x1a09cf,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x8bcc78=this['toURLString']();return this['persistenceKey']&&(_0x8bcc78+='<'+this['persistenceKey']+'>'),_0x8bcc78;}['toURLString'](){const _0x596744=this['secure']?'https://':'http://',_0x1fa714=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x596744+this['host']+'/'+_0x1fa714;}}function th(_0x1a41a0){return _0x1a41a0['host']!==_0x1a41a0['internalHost']||_0x1a41a0['isCustomHost']()||_0x1a41a0['includeNamespaceInQueryParams'];}function vo(_0x48baec,_0x5b387a,_0x2692d7){f(typeof _0x5b387a=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2692d7=='object','typeof\x20params\x20must\x20==\x20object');let _0x13fdb1;if(_0x5b387a===go)_0x13fdb1=(_0x48baec['secure']?'wss://':'ws://')+_0x48baec['internalHost']+'/.ws?';else{if(_0x5b387a===mo)_0x13fdb1=(_0x48baec['secure']?'https://':'http://')+_0x48baec['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5b387a);}th(_0x48baec)&&(_0x2692d7['ns']=_0x48baec['namespace']);const _0xca4968=[];return x(_0x2692d7,(_0x1a53d9,_0x504770)=>{_0xca4968['push'](_0x1a53d9+'='+_0x504770);}),_0x13fdb1+_0xca4968['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x53550c,_0x5d4c18=0x1){Q(this['counters_'],_0x53550c)||(this['counters_'][_0x53550c]=0x0),this['counters_'][_0x53550c]+=_0x5d4c18;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3adf27){const _0x35e64a=_0x3adf27['toString']();return oi[_0x35e64a]||(oi[_0x35e64a]=new nh()),oi[_0x35e64a];}function ih(_0x3f1cd5,_0xb0e8d6){const _0x424211=_0x3f1cd5['toString']();return ai[_0x424211]||(ai[_0x424211]=_0xb0e8d6()),ai[_0x424211];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5e0196){this['onMessage_']=_0x5e0196,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x40b99d,_0x1e6282){this['closeAfterResponse']=_0x40b99d,this['onClose']=_0x1e6282,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3d2820,_0x2fb283){for(this['pendingResponses'][_0x3d2820]=_0x2fb283;this['pendingResponses'][this['currentResponseNum']];){const _0x1d203c=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x673196=0x0;_0x673196<_0x1d203c['length'];++_0x673196)_0x1d203c[_0x673196]&&ft(()=>{this['onMessage_'](_0x1d203c[_0x673196]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3259f1,_0x2e59b8,_0x14898c,_0x8716c2,_0x2406f7,_0x56637e,_0x5edac3){this['connId']=_0x3259f1,this['repoInfo']=_0x2e59b8,this['applicationId']=_0x14898c,this['appCheckToken']=_0x8716c2,this['authToken']=_0x2406f7,this['transportSessionId']=_0x56637e,this['lastSessionId']=_0x5edac3,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x3259f1),this['stats_']=qi(_0x2e59b8),this['urlFn']=_0x169f31=>(this['appCheckToken']&&(_0x169f31[wi]=this['appCheckToken']),vo(_0x2e59b8,mo,_0x169f31));}['open'](_0x1f8031,_0x418702){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x418702,this['myPacketOrderer']=new sh(_0x1f8031),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x3c07ad)=>{const [_0x11ba6b,_0x3697d0,_0x3bd78b,_0x2910a1,_0x343d23]=_0x3c07ad;if(this['incrementIncomingBytes_'](_0x3c07ad),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x11ba6b===qs)this['id']=_0x3697d0,this['password']=_0x3bd78b;else{if(_0x11ba6b===rh)_0x3697d0?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3697d0,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x11ba6b);}}},(..._0x2d41ca)=>{const [_0x33c5c4,_0x186265]=_0x2d41ca;this['incrementIncomingBytes_'](_0x2d41ca),this['myPacketOrderer']['handleResponse'](_0x33c5c4,_0x186265);},()=>{this['onClosed_']();},this['urlFn']);const _0x166cc3={};_0x166cc3[qs]='t',_0x166cc3[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x166cc3[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x166cc3[co]=Gi,this['transportSessionId']&&(_0x166cc3[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x166cc3[po]=this['lastSessionId']),this['applicationId']&&(_0x166cc3[_o]=this['applicationId']),this['appCheckToken']&&(_0x166cc3[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x166cc3[ho]=uo);const _0x257907=this['urlFn'](_0x166cc3);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x257907),this['scriptTagHolder']['addTag'](_0x257907,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x151e54){const _0x23eb7c=O(_0x151e54);this['bytesSent']+=_0x23eb7c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x23eb7c['length']);const _0x381a77=$r(_0x23eb7c),_0x2c6380=oo(_0x381a77,fh);for(let _0x29c221=0x0;_0x29c221<_0x2c6380['length'];_0x29c221++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2c6380['length'],_0x2c6380[_0x29c221]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x435aa2,_0x39d81e){this['myDisconnFrame']=document['createElement']('iframe');const _0x338f31={};_0x338f31[dh]='t',_0x338f31[Eo]=_0x435aa2,_0x338f31[Io]=_0x39d81e,this['myDisconnFrame']['src']=this['urlFn'](_0x338f31),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x161d3b){const _0x461c35=O(_0x161d3b)['length'];this['bytesReceived']+=_0x461c35,this['stats_']['incrementCounter']('bytes_received',_0x461c35);}}class zi{constructor(_0x4b45f7,_0x4cd9c2,_0x4f6da1,_0x2fc5e9){this['onDisconnect']=_0x4f6da1,this['urlFn']=_0x2fc5e9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x4b45f7,window[ah+this['uniqueCallbackIdentifier']]=_0x4cd9c2,this['myIFrame']=zi['createIFrame_']();let _0x3f5a19='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3f5a19='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x47ddd6='<html><body>'+_0x3f5a19+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x47ddd6),this['myIFrame']['doc']['close']();}catch(_0xc5475d){L('frame\x20writing\x20exception'),_0xc5475d['stack']&&L(_0xc5475d['stack']),L(_0xc5475d);}}}static['createIFrame_'](){const _0x44327c=document['createElement']('iframe');if(_0x44327c['style']['display']='none',document['body']){document['body']['appendChild'](_0x44327c);try{_0x44327c['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1ba665=document['domain'];_0x44327c['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1ba665+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x44327c['contentDocument']?_0x44327c['doc']=_0x44327c['contentDocument']:_0x44327c['contentWindow']?_0x44327c['doc']=_0x44327c['contentWindow']['document']:_0x44327c['document']&&(_0x44327c['doc']=_0x44327c['document']),_0x44327c;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1f0d6a=this['onDisconnect'];_0x1f0d6a&&(this['onDisconnect']=null,_0x1f0d6a());}['startLongPoll'](_0x3dfa94,_0x553d64){for(this['myID']=_0x3dfa94,this['myPW']=_0x553d64,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2cdb89={};_0x2cdb89[Eo]=this['myID'],_0x2cdb89[Io]=this['myPW'],_0x2cdb89[wo]=this['currentSerial'];let _0x426418=this['urlFn'](_0x2cdb89),_0x5d319f='',_0xb5da5b=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5d319f['length']<=Co;){const _0x8acee8=this['pendingSegs']['shift']();_0x5d319f=_0x5d319f+'&'+lh+_0xb5da5b+'='+_0x8acee8['seg']+'&'+hh+_0xb5da5b+'='+_0x8acee8['ts']+'&'+uh+_0xb5da5b+'='+_0x8acee8['d'],_0xb5da5b++;}return _0x426418=_0x426418+_0x5d319f,this['addLongPollTag_'](_0x426418,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1c0e35,_0x58783f,_0x492609){this['pendingSegs']['push']({'seg':_0x1c0e35,'ts':_0x58783f,'d':_0x492609}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x3fe5ff,_0xaae7c6){this['outstandingRequests']['add'](_0xaae7c6);const _0x5ccbf3=()=>{this['outstandingRequests']['delete'](_0xaae7c6),this['newRequest_']();},_0x1b99be=setTimeout(_0x5ccbf3,Math['floor'](ph)),_0xc40ecf=()=>{clearTimeout(_0x1b99be),_0x5ccbf3();};this['addTag'](_0x3fe5ff,_0xc40ecf);}['addTag'](_0x547f4b,_0x154440){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x7c9298=this['myIFrame']['doc']['createElement']('script');_0x7c9298['type']='text/javascript',_0x7c9298['async']=!0x0,_0x7c9298['src']=_0x547f4b,_0x7c9298['onload']=_0x7c9298['onreadystatechange']=function(){const _0x220d88=_0x7c9298['readyState'];(!_0x220d88||_0x220d88==='loaded'||_0x220d88==='complete')&&(_0x7c9298['onload']=_0x7c9298['onreadystatechange']=null,_0x7c9298['parentNode']&&_0x7c9298['parentNode']['removeChild'](_0x7c9298),_0x154440());},_0x7c9298['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x547f4b),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x7c9298);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x39d677,_0x514e90,_0x4de729,_0x5d5b11,_0x53d0af,_0x178a49,_0x3c87ba){this['connId']=_0x39d677,this['applicationId']=_0x4de729,this['appCheckToken']=_0x5d5b11,this['authToken']=_0x53d0af,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x514e90),this['connURL']=q['connectionURL_'](_0x514e90,_0x178a49,_0x3c87ba,_0x5d5b11,_0x4de729),this['nodeAdmin']=_0x514e90['nodeAdmin'];}static['connectionURL_'](_0x1b6931,_0x2b7502,_0x2b2637,_0x54b4a5,_0x356e9d){const _0x2fd84b={};return _0x2fd84b[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2fd84b[ho]=uo),_0x2b7502&&(_0x2fd84b[lo]=_0x2b7502),_0x2b2637&&(_0x2fd84b[po]=_0x2b2637),_0x54b4a5&&(_0x2fd84b[wi]=_0x54b4a5),_0x356e9d&&(_0x2fd84b[_o]=_0x356e9d),vo(_0x1b6931,go,_0x2fd84b);}['open'](_0x488e73,_0x27c4e0){this['onDisconnect']=_0x27c4e0,this['onMessage']=_0x488e73,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x33899d;_c(),this['mySock']=new gn(this['connURL'],[],_0x33899d);}catch(_0x1fa3f2){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x39dce6=_0x1fa3f2['message']||_0x1fa3f2['data'];_0x39dce6&&this['log_'](_0x39dce6),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x4d1c8c=>{this['handleIncomingFrame'](_0x4d1c8c);},this['mySock']['onerror']=_0x4a4b55=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x428917=_0x4a4b55['message']||_0x4a4b55['data'];_0x428917&&this['log_'](_0x428917),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5045b8=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xbd7dc=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x494102=navigator['userAgent']['match'](_0xbd7dc);_0x494102&&_0x494102['length']>0x1&&parseFloat(_0x494102[0x1])<4.4&&(_0x5045b8=!0x0);}return!_0x5045b8&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x207c26){if(this['frames']['push'](_0x207c26),this['frames']['length']===this['totalFrames']){const _0x887b85=this['frames']['join']('');this['frames']=null;const _0x2b4bd2=Nt(_0x887b85);this['onMessage'](_0x2b4bd2);}}['handleNewFrameCount_'](_0x221371){this['totalFrames']=_0x221371,this['frames']=[];}['extractFrameCount_'](_0x3642ef){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x3642ef['length']<=0x6){const _0x680c26=Number(_0x3642ef);if(!isNaN(_0x680c26))return this['handleNewFrameCount_'](_0x680c26),null;}return this['handleNewFrameCount_'](0x1),_0x3642ef;}['handleIncomingFrame'](_0x4cd6a2){if(this['mySock']===null)return;const _0x31b27c=_0x4cd6a2['data'];if(this['bytesReceived']+=_0x31b27c['length'],this['stats_']['incrementCounter']('bytes_received',_0x31b27c['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x31b27c);else{const _0x307f4c=this['extractFrameCount_'](_0x31b27c);_0x307f4c!==null&&this['appendFrame_'](_0x307f4c);}}['send'](_0x4812e3){this['resetKeepAlive']();const _0x3b427f=O(_0x4812e3);this['bytesSent']+=_0x3b427f['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3b427f['length']);const _0x564400=oo(_0x3b427f,gh);_0x564400['length']>0x1&&this['sendString_'](String(_0x564400['length']));for(let _0x2a68ba=0x0;_0x2a68ba<_0x564400['length'];_0x2a68ba++)this['sendString_'](_0x564400[_0x2a68ba]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x7bae93){try{this['mySock']['send'](_0x7bae93);}catch(_0x5bbc13){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5bbc13['message']||_0x5bbc13['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x13b7ee){this['initTransports_'](_0x13b7ee);}['initTransports_'](_0x1bd966){const _0x179c4a=q&&q['isAvailable']();let _0x1a24bd=_0x179c4a&&!q['previouslyFailed']();if(_0x1bd966['webSocketOnly']&&(_0x179c4a||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1a24bd=!0x0),_0x1a24bd)this['transports_']=[q];else{const _0x57e3b4=this['transports_']=[];for(const _0x57e3b8 of Dt['ALL_TRANSPORTS'])_0x57e3b8&&_0x57e3b8['isAvailable']()&&_0x57e3b4['push'](_0x57e3b8);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x1083ab,_0x17f91e,_0x28fdef,_0x42f29e,_0x306f5f,_0x1aab8c,_0x2bab39,_0x49c839,_0x49e0bf,_0x357a05){this['id']=_0x1083ab,this['repoInfo_']=_0x17f91e,this['applicationId_']=_0x28fdef,this['appCheckToken_']=_0x42f29e,this['authToken_']=_0x306f5f,this['onMessage_']=_0x1aab8c,this['onReady_']=_0x2bab39,this['onDisconnect_']=_0x49c839,this['onKill_']=_0x49e0bf,this['lastSessionId']=_0x357a05,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x17f91e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2b731a=this['transportManager_']['initialTransport']();this['conn_']=new _0x2b731a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2b731a['responsesRequiredToBeHealthy']||0x0;const _0x173264=this['connReceiver_'](this['conn_']),_0x47d555=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x173264,_0x47d555);},Math['floor'](0x0));const _0x3d25b9=_0x2b731a['healthyTimeout']||0x0;_0x3d25b9>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3d25b9)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x456732){return _0x377dea=>{_0x456732===this['conn_']?this['onConnectionLost_'](_0x377dea):_0x456732===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3adc13){return _0x589bb3=>{this['state_']!==0x2&&(_0x3adc13===this['rx_']?this['onPrimaryMessageReceived_'](_0x589bb3):_0x3adc13===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x589bb3):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3ed333){const _0x129a36={'t':'d','d':_0x3ed333};this['sendData_'](_0x129a36);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5b5cd0){if(ci in _0x5b5cd0){const _0x4cd899=_0x5b5cd0[ci];_0x4cd899===Ys?this['upgradeIfSecondaryHealthy_']():_0x4cd899===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4cd899===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x158acc){const _0x4fe735=vt('t',_0x158acc),_0x49fb7f=vt('d',_0x158acc);if(_0x4fe735==='c')this['onSecondaryControl_'](_0x49fb7f);else{if(_0x4fe735==='d')this['pendingDataMessages']['push'](_0x49fb7f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4fe735);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5740a0){const _0x842804=vt('t',_0x5740a0),_0x3e1762=vt('d',_0x5740a0);_0x842804==='c'?this['onControl_'](_0x3e1762):_0x842804==='d'&&this['onDataMessage_'](_0x3e1762);}['onDataMessage_'](_0x1455e2){this['onPrimaryResponse_'](),this['onMessage_'](_0x1455e2);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x129700){const _0xe004e0=vt(ci,_0x129700);if(zs in _0x129700){const _0x1519ee=_0x129700[zs];if(_0xe004e0===Th){const _0x144b76={..._0x1519ee};this['repoInfo_']['isUsingEmulator']&&(_0x144b76['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x144b76);}else{if(_0xe004e0===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4e38be=0x0;_0x4e38be<this['pendingDataMessages']['length'];++_0x4e38be)this['onDataMessage_'](this['pendingDataMessages'][_0x4e38be]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xe004e0===wh?this['onConnectionShutdown_'](_0x1519ee):_0xe004e0===js?this['onReset_'](_0x1519ee):_0xe004e0===Ch?Ii('Server\x20Error:\x20'+_0x1519ee):_0xe004e0===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xe004e0);}}}['onHandshake_'](_0x1c38e4){const _0x2056c7=_0x1c38e4['ts'],_0x196d2d=_0x1c38e4['v'],_0x54d21f=_0x1c38e4['h'];this['sessionId']=_0x1c38e4['s'],this['repoInfo_']['host']=_0x54d21f,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x2056c7),Gi!==_0x196d2d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x24abd2=this['transportManager_']['upgradeTransport']();_0x24abd2&&this['startUpgrade_'](_0x24abd2);}['startUpgrade_'](_0xcff7b7){this['secondaryConn_']=new _0xcff7b7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xcff7b7['responsesRequiredToBeHealthy']||0x0;const _0x574c4e=this['connReceiver_'](this['secondaryConn_']),_0xc6c059=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x574c4e,_0xc6c059),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x115708){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x115708),this['repoInfo_']['host']=_0x115708,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x193f14,_0x57d646){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x193f14,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x57d646,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x338d37=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x338d37||this['rx_']===_0x338d37)&&this['close']();}['onConnectionLost_'](_0x574eea){this['conn_']=null,!_0x574eea&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x1570c8){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x1570c8),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x216528){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x216528);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4e4ee1,_0xd465de,_0x52f8cf,_0x3343df){}['merge'](_0x42e56c,_0x5a9ab9,_0x485b89,_0x5bfdb0){}['refreshAuthToken'](_0x3108d1){}['refreshAppCheckToken'](_0x4ded5c){}['onDisconnectPut'](_0x43cd91,_0x2a389a,_0x4ae040){}['onDisconnectMerge'](_0x15d373,_0x476961,_0x2ee9d1){}['onDisconnectCancel'](_0x498bf9,_0x54c714){}['reportStats'](_0x5c7715){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x15d330){this['allowedEvents_']=_0x15d330,this['listeners_']={},f(Array['isArray'](_0x15d330)&&_0x15d330['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x372fb2,..._0x4ddb5a){if(Array['isArray'](this['listeners_'][_0x372fb2])){const _0x291492=[...this['listeners_'][_0x372fb2]];for(let _0x34fb4a=0x0;_0x34fb4a<_0x291492['length'];_0x34fb4a++)_0x291492[_0x34fb4a]['callback']['apply'](_0x291492[_0x34fb4a]['context'],_0x4ddb5a);}}['on'](_0x7142cf,_0x349c1c,_0x5c21b8){this['validateEventType_'](_0x7142cf),this['listeners_'][_0x7142cf]=this['listeners_'][_0x7142cf]||[],this['listeners_'][_0x7142cf]['push']({'callback':_0x349c1c,'context':_0x5c21b8});const _0x227055=this['getInitialEvent'](_0x7142cf);_0x227055&&_0x349c1c['apply'](_0x5c21b8,_0x227055);}['off'](_0x24d07d,_0x1117c3,_0x3cc641){this['validateEventType_'](_0x24d07d);const _0x3430de=this['listeners_'][_0x24d07d]||[];for(let _0x17e573=0x0;_0x17e573<_0x3430de['length'];_0x17e573++)if(_0x3430de[_0x17e573]['callback']===_0x1117c3&&(!_0x3cc641||_0x3cc641===_0x3430de[_0x17e573]['context'])){_0x3430de['splice'](_0x17e573,0x1);return;}}['validateEventType_'](_0x2b395b){f(this['allowedEvents_']['find'](_0x4fcff5=>_0x4fcff5===_0x2b395b),'Unknown\x20event:\x20'+_0x2b395b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x15be99){return f(_0x15be99==='online','Unknown\x20event\x20type:\x20'+_0x15be99),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x401077,_0x28ca41){if(_0x28ca41===void 0x0){this['pieces_']=_0x401077['split']('/');let _0x867475=0x0;for(let _0x47f15b=0x0;_0x47f15b<this['pieces_']['length'];_0x47f15b++)this['pieces_'][_0x47f15b]['length']>0x0&&(this['pieces_'][_0x867475]=this['pieces_'][_0x47f15b],_0x867475++);this['pieces_']['length']=_0x867475,this['pieceNum_']=0x0;}else this['pieces_']=_0x401077,this['pieceNum_']=_0x28ca41;}['toString'](){let _0x355245='';for(let _0xc60ad1=this['pieceNum_'];_0xc60ad1<this['pieces_']['length'];_0xc60ad1++)this['pieces_'][_0xc60ad1]!==''&&(_0x355245+='/'+this['pieces_'][_0xc60ad1]);return _0x355245||'/';}}function w(){return new C('');}function y(_0x4ca985){return _0x4ca985['pieceNum_']>=_0x4ca985['pieces_']['length']?null:_0x4ca985['pieces_'][_0x4ca985['pieceNum_']];}function Ce(_0x4fca12){return _0x4fca12['pieces_']['length']-_0x4fca12['pieceNum_'];}function S(_0x3e900b){let _0x152da9=_0x3e900b['pieceNum_'];return _0x152da9<_0x3e900b['pieces_']['length']&&_0x152da9++,new C(_0x3e900b['pieces_'],_0x152da9);}function ji(_0x342dc2){return _0x342dc2['pieceNum_']<_0x342dc2['pieces_']['length']?_0x342dc2['pieces_'][_0x342dc2['pieces_']['length']-0x1]:null;}function bh(_0x10d921){let _0x4b062c='';for(let _0x4e3021=_0x10d921['pieceNum_'];_0x4e3021<_0x10d921['pieces_']['length'];_0x4e3021++)_0x10d921['pieces_'][_0x4e3021]!==''&&(_0x4b062c+='/'+encodeURIComponent(String(_0x10d921['pieces_'][_0x4e3021])));return _0x4b062c||'/';}function Mt(_0x4cd01b,_0xad0955=0x0){return _0x4cd01b['pieces_']['slice'](_0x4cd01b['pieceNum_']+_0xad0955);}function Ro(_0x5f305a){if(_0x5f305a['pieceNum_']>=_0x5f305a['pieces_']['length'])return null;const _0x73130=[];for(let _0x3e35a5=_0x5f305a['pieceNum_'];_0x3e35a5<_0x5f305a['pieces_']['length']-0x1;_0x3e35a5++)_0x73130['push'](_0x5f305a['pieces_'][_0x3e35a5]);return new C(_0x73130,0x0);}function k(_0x5a8754,_0x3a963f){const _0x56ab8f=[];for(let _0x49d7ec=_0x5a8754['pieceNum_'];_0x49d7ec<_0x5a8754['pieces_']['length'];_0x49d7ec++)_0x56ab8f['push'](_0x5a8754['pieces_'][_0x49d7ec]);if(_0x3a963f instanceof C){for(let _0x49e0f8=_0x3a963f['pieceNum_'];_0x49e0f8<_0x3a963f['pieces_']['length'];_0x49e0f8++)_0x56ab8f['push'](_0x3a963f['pieces_'][_0x49e0f8]);}else{const _0x367478=_0x3a963f['split']('/');for(let _0x48b73a=0x0;_0x48b73a<_0x367478['length'];_0x48b73a++)_0x367478[_0x48b73a]['length']>0x0&&_0x56ab8f['push'](_0x367478[_0x48b73a]);}return new C(_0x56ab8f,0x0);}function v(_0x2349dd){return _0x2349dd['pieceNum_']>=_0x2349dd['pieces_']['length'];}function F(_0x356e87,_0x4e4278){const _0x2eb131=y(_0x356e87),_0x16a438=y(_0x4e4278);if(_0x2eb131===null)return _0x4e4278;if(_0x2eb131===_0x16a438)return F(S(_0x356e87),S(_0x4e4278));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4e4278+')\x20is\x20not\x20within\x20outerPath\x20('+_0x356e87+')');}function Rh(_0x49fcfa,_0x165607){const _0x403bd5=Mt(_0x49fcfa,0x0),_0x71cf1f=Mt(_0x165607,0x0);for(let _0x59d162=0x0;_0x59d162<_0x403bd5['length']&&_0x59d162<_0x71cf1f['length'];_0x59d162++){const _0xffbb8b=qe(_0x403bd5[_0x59d162],_0x71cf1f[_0x59d162]);if(_0xffbb8b!==0x0)return _0xffbb8b;}return _0x403bd5['length']===_0x71cf1f['length']?0x0:_0x403bd5['length']<_0x71cf1f['length']?-0x1:0x1;}function Ki(_0x3fda33,_0x23ca6d){if(Ce(_0x3fda33)!==Ce(_0x23ca6d))return!0x1;for(let _0x59d774=_0x3fda33['pieceNum_'],_0x48bdc1=_0x23ca6d['pieceNum_'];_0x59d774<=_0x3fda33['pieces_']['length'];_0x59d774++,_0x48bdc1++)if(_0x3fda33['pieces_'][_0x59d774]!==_0x23ca6d['pieces_'][_0x48bdc1])return!0x1;return!0x0;}function G(_0x3f042a,_0x53f36e){let _0x23a38f=_0x3f042a['pieceNum_'],_0x42bd1f=_0x53f36e['pieceNum_'];if(Ce(_0x3f042a)>Ce(_0x53f36e))return!0x1;for(;_0x23a38f<_0x3f042a['pieces_']['length'];){if(_0x3f042a['pieces_'][_0x23a38f]!==_0x53f36e['pieces_'][_0x42bd1f])return!0x1;++_0x23a38f,++_0x42bd1f;}return!0x0;}class Ah{constructor(_0x5a8e64,_0x1e017e){this['errorPrefix_']=_0x1e017e,this['parts_']=Mt(_0x5a8e64,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xcccc80=0x0;_0xcccc80<this['parts_']['length'];_0xcccc80++)this['byteLength_']+=Ln(this['parts_'][_0xcccc80]);Ao(this);}}function kh(_0x42ebfe,_0x5b511f){_0x42ebfe['parts_']['length']>0x0&&(_0x42ebfe['byteLength_']+=0x1),_0x42ebfe['parts_']['push'](_0x5b511f),_0x42ebfe['byteLength_']+=Ln(_0x5b511f),Ao(_0x42ebfe);}function Ph(_0x4c8b84){const _0x17a3b6=_0x4c8b84['parts_']['pop']();_0x4c8b84['byteLength_']-=Ln(_0x17a3b6),_0x4c8b84['parts_']['length']>0x0&&(_0x4c8b84['byteLength_']-=0x1);}function Ao(_0x416944){if(_0x416944['byteLength_']>Zs)throw new Error(_0x416944['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x416944['byteLength_']+').');if(_0x416944['parts_']['length']>Xs)throw new Error(_0x416944['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x416944));}function Oe(_0x27d433){return _0x27d433['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x27d433['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x8fde7c,_0x538ce2;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x538ce2='visibilitychange',_0x8fde7c='hidden'):typeof document['mozHidden']<'u'?(_0x538ce2='mozvisibilitychange',_0x8fde7c='mozHidden'):typeof document['msHidden']<'u'?(_0x538ce2='msvisibilitychange',_0x8fde7c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x538ce2='webkitvisibilitychange',_0x8fde7c='webkitHidden')),this['visible_']=!0x0,_0x538ce2&&document['addEventListener'](_0x538ce2,()=>{const _0x5c865b=!document[_0x8fde7c];_0x5c865b!==this['visible_']&&(this['visible_']=_0x5c865b,this['trigger']('visible',_0x5c865b));},!0x1);}['getInitialEvent'](_0x4dd358){return f(_0x4dd358==='visible','Unknown\x20event\x20type:\x20'+_0x4dd358),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x54a7f0,_0x2dfe95,_0x17d05a,_0x5d4e7a,_0xb0eb26,_0x37693d,_0x30469d,_0x486d61){if(super(),this['repoInfo_']=_0x54a7f0,this['applicationId_']=_0x2dfe95,this['onDataUpdate_']=_0x17d05a,this['onConnectStatus_']=_0x5d4e7a,this['onServerInfoUpdate_']=_0xb0eb26,this['authTokenProvider_']=_0x37693d,this['appCheckTokenProvider_']=_0x30469d,this['authOverride_']=_0x486d61,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x486d61)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x54a7f0['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x54eeec,_0x29e2dc,_0x5b044f){const _0x2bec30=++this['requestNumber_'],_0x54e366={'r':_0x2bec30,'a':_0x54eeec,'b':_0x29e2dc};this['log_'](O(_0x54e366)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x54e366),_0x5b044f&&(this['requestCBHash_'][_0x2bec30]=_0x5b044f);}['get'](_0x3f6a83){this['initConnection_']();const _0x1d5148=new H(),_0x5dff34={'action':'g','request':{'p':_0x3f6a83['_path']['toString'](),'q':_0x3f6a83['_queryObject']},'onComplete':_0xab6afb=>{const _0x23c722=_0xab6afb['d'];_0xab6afb['s']==='ok'?_0x1d5148['resolve'](_0x23c722):_0x1d5148['reject'](_0x23c722);}};this['outstandingGets_']['push'](_0x5dff34),this['outstandingGetCount_']++;const _0x184613=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x184613),_0x1d5148['promise'];}['listen'](_0x2edc73,_0x41e5ab,_0x50f661,_0x19bbe1){this['initConnection_']();const _0xcb311f=_0x2edc73['_queryIdentifier'],_0x3cc9dc=_0x2edc73['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3cc9dc+'\x20'+_0xcb311f),this['listens']['has'](_0x3cc9dc)||this['listens']['set'](_0x3cc9dc,new Map()),f(_0x2edc73['_queryParams']['isDefault']()||!_0x2edc73['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3cc9dc)['has'](_0xcb311f),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1aaebd={'onComplete':_0x19bbe1,'hashFn':_0x41e5ab,'query':_0x2edc73,'tag':_0x50f661};this['listens']['get'](_0x3cc9dc)['set'](_0xcb311f,_0x1aaebd),this['connected_']&&this['sendListen_'](_0x1aaebd);}['sendGet_'](_0x48a091){const _0x181b80=this['outstandingGets_'][_0x48a091];this['sendRequest']('g',_0x181b80['request'],_0x2b356f=>{delete this['outstandingGets_'][_0x48a091],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x181b80['onComplete']&&_0x181b80['onComplete'](_0x2b356f);});}['sendListen_'](_0x1215e4){const _0x38ee0d=_0x1215e4['query'],_0x3ee76d=_0x38ee0d['_path']['toString'](),_0x5bb7d2=_0x38ee0d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x3ee76d+'\x20for\x20'+_0x5bb7d2);const _0xee7d3e={'p':_0x3ee76d},_0x53d201='q';_0x1215e4['tag']&&(_0xee7d3e['q']=_0x38ee0d['_queryObject'],_0xee7d3e['t']=_0x1215e4['tag']),_0xee7d3e['h']=_0x1215e4['hashFn'](),this['sendRequest'](_0x53d201,_0xee7d3e,_0x35855a=>{const _0x3fafaa=_0x35855a['d'],_0x4e1475=_0x35855a['s'];se['warnOnListenWarnings_'](_0x3fafaa,_0x38ee0d),(this['listens']['get'](_0x3ee76d)&&this['listens']['get'](_0x3ee76d)['get'](_0x5bb7d2))===_0x1215e4&&(this['log_']('listen\x20response',_0x35855a),_0x4e1475!=='ok'&&this['removeListen_'](_0x3ee76d,_0x5bb7d2),_0x1215e4['onComplete']&&_0x1215e4['onComplete'](_0x4e1475,_0x3fafaa));});}static['warnOnListenWarnings_'](_0x527266,_0x31cb77){if(_0x527266&&typeof _0x527266=='object'&&Q(_0x527266,'w')){const _0xe8b0a8=Le(_0x527266,'w');if(Array['isArray'](_0xe8b0a8)&&~_0xe8b0a8['indexOf']('no_index')){const _0x19c581='\x22.indexOn\x22:\x20\x22'+_0x31cb77['_queryParams']['getIndex']()['toString']()+'\x22',_0x455285=_0x31cb77['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x19c581+'\x20at\x20'+_0x455285+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x29d089){this['authToken_']=_0x29d089,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x29d089);}['reduceReconnectDelayIfAdminCredential_'](_0x303865){(_0x303865&&_0x303865['length']===0x28||wc(_0x303865))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x395630){this['appCheckToken_']=_0x395630,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x378a7b=this['authToken_'],_0x1c3a6a=Ic(_0x378a7b)?'auth':'gauth',_0x285b40={'cred':_0x378a7b};this['authOverride_']===null?_0x285b40['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x285b40['authvar']=this['authOverride_']),this['sendRequest'](_0x1c3a6a,_0x285b40,_0x28b5df=>{const _0x355a9c=_0x28b5df['s'],_0x365225=_0x28b5df['d']||'error';this['authToken_']===_0x378a7b&&(_0x355a9c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x355a9c,_0x365225));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5be70f=>{const _0x233fb3=_0x5be70f['s'],_0xfe82dd=_0x5be70f['d']||'error';_0x233fb3==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x233fb3,_0xfe82dd);});}['unlisten'](_0x51aafa,_0x41208e){const _0x5540e1=_0x51aafa['_path']['toString'](),_0x16df3e=_0x51aafa['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5540e1+'\x20'+_0x16df3e),f(_0x51aafa['_queryParams']['isDefault']()||!_0x51aafa['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5540e1,_0x16df3e)&&this['connected_']&&this['sendUnlisten_'](_0x5540e1,_0x16df3e,_0x51aafa['_queryObject'],_0x41208e);}['sendUnlisten_'](_0x5f1ee8,_0x56c2d8,_0x5a93fc,_0x14f42e){this['log_']('Unlisten\x20on\x20'+_0x5f1ee8+'\x20for\x20'+_0x56c2d8);const _0x1a4283={'p':_0x5f1ee8},_0xfce0f2='n';_0x14f42e&&(_0x1a4283['q']=_0x5a93fc,_0x1a4283['t']=_0x14f42e),this['sendRequest'](_0xfce0f2,_0x1a4283);}['onDisconnectPut'](_0x8c605b,_0x3fdc93,_0x3f9f16){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x8c605b,_0x3fdc93,_0x3f9f16):this['onDisconnectRequestQueue_']['push']({'pathString':_0x8c605b,'action':'o','data':_0x3fdc93,'onComplete':_0x3f9f16});}['onDisconnectMerge'](_0x128dba,_0x248ba2,_0x149739){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x128dba,_0x248ba2,_0x149739):this['onDisconnectRequestQueue_']['push']({'pathString':_0x128dba,'action':'om','data':_0x248ba2,'onComplete':_0x149739});}['onDisconnectCancel'](_0x48c626,_0x4c4924){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x48c626,null,_0x4c4924):this['onDisconnectRequestQueue_']['push']({'pathString':_0x48c626,'action':'oc','data':null,'onComplete':_0x4c4924});}['sendOnDisconnect_'](_0x2a6c3e,_0x4a30e9,_0x1b7e8c,_0xb792f9){const _0xf80c3f={'p':_0x4a30e9,'d':_0x1b7e8c};this['log_']('onDisconnect\x20'+_0x2a6c3e,_0xf80c3f),this['sendRequest'](_0x2a6c3e,_0xf80c3f,_0x5cecfa=>{_0xb792f9&&setTimeout(()=>{_0xb792f9(_0x5cecfa['s'],_0x5cecfa['d']);},Math['floor'](0x0));});}['put'](_0x43005a,_0x39177e,_0xa15499,_0x4a5f42){this['putInternal']('p',_0x43005a,_0x39177e,_0xa15499,_0x4a5f42);}['merge'](_0x2ae5fa,_0x159cc1,_0x5071c7,_0x1d354a){this['putInternal']('m',_0x2ae5fa,_0x159cc1,_0x5071c7,_0x1d354a);}['putInternal'](_0x4826f7,_0x3ffa2e,_0x54490b,_0x51472c,_0x533d2f){this['initConnection_']();const _0x1c1323={'p':_0x3ffa2e,'d':_0x54490b};_0x533d2f!==void 0x0&&(_0x1c1323['h']=_0x533d2f),this['outstandingPuts_']['push']({'action':_0x4826f7,'request':_0x1c1323,'onComplete':_0x51472c}),this['outstandingPutCount_']++;const _0x15870a=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x15870a):this['log_']('Buffering\x20put:\x20'+_0x3ffa2e);}['sendPut_'](_0x4a1296){const _0x103355=this['outstandingPuts_'][_0x4a1296]['action'],_0x4412a8=this['outstandingPuts_'][_0x4a1296]['request'],_0x54971c=this['outstandingPuts_'][_0x4a1296]['onComplete'];this['outstandingPuts_'][_0x4a1296]['queued']=this['connected_'],this['sendRequest'](_0x103355,_0x4412a8,_0x407b17=>{this['log_'](_0x103355+'\x20response',_0x407b17),delete this['outstandingPuts_'][_0x4a1296],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x54971c&&_0x54971c(_0x407b17['s'],_0x407b17['d']);});}['reportStats'](_0x5c8ad9){if(this['connected_']){const _0x5a225d={'c':_0x5c8ad9};this['log_']('reportStats',_0x5a225d),this['sendRequest']('s',_0x5a225d,_0x23f788=>{if(_0x23f788['s']!=='ok'){const _0x31383d=_0x23f788['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x31383d);}});}}['onDataMessage_'](_0x1843c3){if('r'in _0x1843c3){this['log_']('from\x20server:\x20'+O(_0x1843c3));const _0x2e489e=_0x1843c3['r'],_0x322f3b=this['requestCBHash_'][_0x2e489e];_0x322f3b&&(delete this['requestCBHash_'][_0x2e489e],_0x322f3b(_0x1843c3['b']));}else{if('error'in _0x1843c3)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1843c3['error'];'a'in _0x1843c3&&this['onDataPush_'](_0x1843c3['a'],_0x1843c3['b']);}}['onDataPush_'](_0x361406,_0x1c5695){this['log_']('handleServerMessage',_0x361406,_0x1c5695),_0x361406==='d'?this['onDataUpdate_'](_0x1c5695['p'],_0x1c5695['d'],!0x1,_0x1c5695['t']):_0x361406==='m'?this['onDataUpdate_'](_0x1c5695['p'],_0x1c5695['d'],!0x0,_0x1c5695['t']):_0x361406==='c'?this['onListenRevoked_'](_0x1c5695['p'],_0x1c5695['q']):_0x361406==='ac'?this['onAuthRevoked_'](_0x1c5695['s'],_0x1c5695['d']):_0x361406==='apc'?this['onAppCheckRevoked_'](_0x1c5695['s'],_0x1c5695['d']):_0x361406==='sd'?this['onSecurityDebugPacket_'](_0x1c5695):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x361406)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1be848,_0x6a10ef){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1be848),this['lastSessionId']=_0x6a10ef,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5d0633){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5d0633));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x50c50c){_0x50c50c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x50c50c;}['onOnline_'](_0x4dc404){_0x4dc404?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2155ba=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x58457f=Math['max'](0x0,this['reconnectDelay_']-_0x2155ba);_0x58457f=Math['random']()*_0x58457f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x58457f+'ms'),this['scheduleConnect_'](_0x58457f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1b4008=this['onDataMessage_']['bind'](this),_0xd8845=this['onReady_']['bind'](this),_0x20e244=this['onRealtimeDisconnect_']['bind'](this),_0x2e7876=this['id']+':'+se['nextConnectionId_']++,_0x4cf017=this['lastSessionId'];let _0x1bf169=!0x1,_0x3e2ec2=null;const _0x308a52=function(){_0x3e2ec2?_0x3e2ec2['close']():(_0x1bf169=!0x0,_0x20e244());},_0x54cd57=function(_0x1b0dff){f(_0x3e2ec2,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3e2ec2['sendRequest'](_0x1b0dff);};this['realtime_']={'close':_0x308a52,'sendRequest':_0x54cd57};const _0x536046=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x25a32d,_0xd8d906]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x536046),this['appCheckTokenProvider_']['getToken'](_0x536046)]);_0x1bf169?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x25a32d&&_0x25a32d['accessToken'],this['appCheckToken_']=_0xd8d906&&_0xd8d906['token'],_0x3e2ec2=new Sh(_0x2e7876,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1b4008,_0xd8845,_0x20e244,_0x279133=>{U(_0x279133+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x4cf017));}catch(_0x2b00bd){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2b00bd),_0x1bf169||(this['repoInfo_']['nodeAdmin']&&U(_0x2b00bd),_0x308a52());}}}['interrupt'](_0x164765){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x164765),this['interruptReasons_'][_0x164765]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xdbf577){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xdbf577),delete this['interruptReasons_'][_0xdbf577],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5255c8){const _0x3b2ae0=_0x5255c8-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3b2ae0});}['cancelSentTransactions_'](){for(let _0x593753=0x0;_0x593753<this['outstandingPuts_']['length'];_0x593753++){const _0x567545=this['outstandingPuts_'][_0x593753];_0x567545&&'h'in _0x567545['request']&&_0x567545['queued']&&(_0x567545['onComplete']&&_0x567545['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x593753],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x242691,_0x455dab){let _0x3b4ed7;_0x455dab?_0x3b4ed7=_0x455dab['map'](_0x161374=>$i(_0x161374))['join']('$'):_0x3b4ed7='default';const _0x176f0b=this['removeListen_'](_0x242691,_0x3b4ed7);_0x176f0b&&_0x176f0b['onComplete']&&_0x176f0b['onComplete']('permission_denied');}['removeListen_'](_0x3c5a18,_0x2611d2){const _0x1fac21=new C(_0x3c5a18)['toString']();let _0x3757aa;if(this['listens']['has'](_0x1fac21)){const _0x5e4263=this['listens']['get'](_0x1fac21);_0x3757aa=_0x5e4263['get'](_0x2611d2),_0x5e4263['delete'](_0x2611d2),_0x5e4263['size']===0x0&&this['listens']['delete'](_0x1fac21);}else _0x3757aa=void 0x0;return _0x3757aa;}['onAuthRevoked_'](_0x587180,_0x590b7f){L('Auth\x20token\x20revoked:\x20'+_0x587180+'/'+_0x590b7f),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x587180==='invalid_token'||_0x587180==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2affce,_0x2dbe1f){L('App\x20check\x20token\x20revoked:\x20'+_0x2affce+'/'+_0x2dbe1f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2affce==='invalid_token'||_0x2affce==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x56ae76){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x56ae76):'msg'in _0x56ae76&&console['log']('FIREBASE:\x20'+_0x56ae76['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3a72fe of this['listens']['values']())for(const _0xb77d7c of _0x3a72fe['values']())this['sendListen_'](_0xb77d7c);for(let _0x4ddcfb=0x0;_0x4ddcfb<this['outstandingPuts_']['length'];_0x4ddcfb++)this['outstandingPuts_'][_0x4ddcfb]&&this['sendPut_'](_0x4ddcfb);for(;this['onDisconnectRequestQueue_']['length'];){const _0x22da47=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x22da47['action'],_0x22da47['pathString'],_0x22da47['data'],_0x22da47['onComplete']);}for(let _0x3fe540=0x0;_0x3fe540<this['outstandingGets_']['length'];_0x3fe540++)this['outstandingGets_'][_0x3fe540]&&this['sendGet_'](_0x3fe540);}['sendConnectStats_'](){const _0x24b7ef={};let _0x1cdd0='js';_0x24b7ef['sdk.'+_0x1cdd0+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x24b7ef['framework.cordova']=0x1:Kr()&&(_0x24b7ef['framework.reactnative']=0x1),this['reportStats'](_0x24b7ef);}['shouldReconnect_'](){const _0x34eb35=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x34eb35;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x524968,_0x22e798){this['name']=_0x524968,this['node']=_0x22e798;}static['Wrap'](_0x184ab0,_0x3c0d12){return new E(_0x184ab0,_0x3c0d12);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x54b6e8,_0x3572e6){const _0x39b8e0=new E(We,_0x54b6e8),_0x254b2d=new E(We,_0x3572e6);return this['compare'](_0x39b8e0,_0x254b2d)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x3dbdd0){sn=_0x3dbdd0;}['compare'](_0x11419a,_0x11a4cf){return qe(_0x11419a['name'],_0x11a4cf['name']);}['isDefinedOn'](_0xa7eb48){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x16b672,_0xb8a768){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xebb842,_0x15f4eb){return f(typeof _0xebb842=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xebb842,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x55882f,_0x118f0d,_0x230e75,_0x142bce,_0x105ed5=null){this['isReverse_']=_0x142bce,this['resultGenerator_']=_0x105ed5,this['nodeStack_']=[];let _0xd0fa07=0x1;for(;!_0x55882f['isEmpty']();)if(_0x55882f=_0x55882f,_0xd0fa07=_0x118f0d?_0x230e75(_0x55882f['key'],_0x118f0d):0x1,_0x142bce&&(_0xd0fa07*=-0x1),_0xd0fa07<0x0)this['isReverse_']?_0x55882f=_0x55882f['left']:_0x55882f=_0x55882f['right'];else{if(_0xd0fa07===0x0){this['nodeStack_']['push'](_0x55882f);break;}else this['nodeStack_']['push'](_0x55882f),this['isReverse_']?_0x55882f=_0x55882f['right']:_0x55882f=_0x55882f['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x321478=this['nodeStack_']['pop'](),_0x1bacf9;if(this['resultGenerator_']?_0x1bacf9=this['resultGenerator_'](_0x321478['key'],_0x321478['value']):_0x1bacf9={'key':_0x321478['key'],'value':_0x321478['value']},this['isReverse_']){for(_0x321478=_0x321478['left'];!_0x321478['isEmpty']();)this['nodeStack_']['push'](_0x321478),_0x321478=_0x321478['right'];}else{for(_0x321478=_0x321478['right'];!_0x321478['isEmpty']();)this['nodeStack_']['push'](_0x321478),_0x321478=_0x321478['left'];}return _0x1bacf9;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x280411=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x280411['key'],_0x280411['value']):{'key':_0x280411['key'],'value':_0x280411['value']};}}class M{constructor(_0x35485a,_0x2ff7c3,_0x18fbc6,_0x257386,_0x19edf2){this['key']=_0x35485a,this['value']=_0x2ff7c3,this['color']=_0x18fbc6??M['RED'],this['left']=_0x257386??B['EMPTY_NODE'],this['right']=_0x19edf2??B['EMPTY_NODE'];}['copy'](_0x5e5061,_0x59520e,_0x592669,_0x304ac4,_0x4c8219){return new M(_0x5e5061??this['key'],_0x59520e??this['value'],_0x592669??this['color'],_0x304ac4??this['left'],_0x4c8219??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x30122e){return this['left']['inorderTraversal'](_0x30122e)||!!_0x30122e(this['key'],this['value'])||this['right']['inorderTraversal'](_0x30122e);}['reverseTraversal'](_0x54f0a8){return this['right']['reverseTraversal'](_0x54f0a8)||_0x54f0a8(this['key'],this['value'])||this['left']['reverseTraversal'](_0x54f0a8);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x350ed3,_0x24bfc8,_0x99cb0e){let _0x507242=this;const _0x361455=_0x99cb0e(_0x350ed3,_0x507242['key']);return _0x361455<0x0?_0x507242=_0x507242['copy'](null,null,null,_0x507242['left']['insert'](_0x350ed3,_0x24bfc8,_0x99cb0e),null):_0x361455===0x0?_0x507242=_0x507242['copy'](null,_0x24bfc8,null,null,null):_0x507242=_0x507242['copy'](null,null,null,null,_0x507242['right']['insert'](_0x350ed3,_0x24bfc8,_0x99cb0e)),_0x507242['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5bd324=this;return!_0x5bd324['left']['isRed_']()&&!_0x5bd324['left']['left']['isRed_']()&&(_0x5bd324=_0x5bd324['moveRedLeft_']()),_0x5bd324=_0x5bd324['copy'](null,null,null,_0x5bd324['left']['removeMin_'](),null),_0x5bd324['fixUp_']();}['remove'](_0x526a39,_0x11a30b){let _0x1be408,_0xe36d12;if(_0x1be408=this,_0x11a30b(_0x526a39,_0x1be408['key'])<0x0)!_0x1be408['left']['isEmpty']()&&!_0x1be408['left']['isRed_']()&&!_0x1be408['left']['left']['isRed_']()&&(_0x1be408=_0x1be408['moveRedLeft_']()),_0x1be408=_0x1be408['copy'](null,null,null,_0x1be408['left']['remove'](_0x526a39,_0x11a30b),null);else{if(_0x1be408['left']['isRed_']()&&(_0x1be408=_0x1be408['rotateRight_']()),!_0x1be408['right']['isEmpty']()&&!_0x1be408['right']['isRed_']()&&!_0x1be408['right']['left']['isRed_']()&&(_0x1be408=_0x1be408['moveRedRight_']()),_0x11a30b(_0x526a39,_0x1be408['key'])===0x0){if(_0x1be408['right']['isEmpty']())return B['EMPTY_NODE'];_0xe36d12=_0x1be408['right']['min_'](),_0x1be408=_0x1be408['copy'](_0xe36d12['key'],_0xe36d12['value'],null,null,_0x1be408['right']['removeMin_']());}_0x1be408=_0x1be408['copy'](null,null,null,null,_0x1be408['right']['remove'](_0x526a39,_0x11a30b));}return _0x1be408['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x6c2fa8=this;return _0x6c2fa8['right']['isRed_']()&&!_0x6c2fa8['left']['isRed_']()&&(_0x6c2fa8=_0x6c2fa8['rotateLeft_']()),_0x6c2fa8['left']['isRed_']()&&_0x6c2fa8['left']['left']['isRed_']()&&(_0x6c2fa8=_0x6c2fa8['rotateRight_']()),_0x6c2fa8['left']['isRed_']()&&_0x6c2fa8['right']['isRed_']()&&(_0x6c2fa8=_0x6c2fa8['colorFlip_']()),_0x6c2fa8;}['moveRedLeft_'](){let _0x3206ee=this['colorFlip_']();return _0x3206ee['right']['left']['isRed_']()&&(_0x3206ee=_0x3206ee['copy'](null,null,null,null,_0x3206ee['right']['rotateRight_']()),_0x3206ee=_0x3206ee['rotateLeft_'](),_0x3206ee=_0x3206ee['colorFlip_']()),_0x3206ee;}['moveRedRight_'](){let _0xbf015f=this['colorFlip_']();return _0xbf015f['left']['left']['isRed_']()&&(_0xbf015f=_0xbf015f['rotateRight_'](),_0xbf015f=_0xbf015f['colorFlip_']()),_0xbf015f;}['rotateLeft_'](){const _0x5ec4e8=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5ec4e8,null);}['rotateRight_'](){const _0x30cb25=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x30cb25);}['colorFlip_'](){const _0x4f3a0b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5437f7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x4f3a0b,_0x5437f7);}['checkMaxDepth_'](){const _0x599b4e=this['check_']();return Math['pow'](0x2,_0x599b4e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x503de9=this['left']['check_']();if(_0x503de9!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x503de9+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x268a57,_0x57d6f3,_0x103665,_0x1810ae,_0x3d4b79){return this;}['insert'](_0x17122b,_0x1f0a2c,_0xc762d8){return new M(_0x17122b,_0x1f0a2c,null);}['remove'](_0x21e345,_0x3d6673){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2ea4f3){return!0x1;}['reverseTraversal'](_0x1b90eb){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x308642,_0x3dfcbc=B['EMPTY_NODE']){this['comparator_']=_0x308642,this['root_']=_0x3dfcbc;}['insert'](_0x4f6262,_0x4215a5){return new B(this['comparator_'],this['root_']['insert'](_0x4f6262,_0x4215a5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x540750){return new B(this['comparator_'],this['root_']['remove'](_0x540750,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4695f3){let _0x52636c,_0x4c7da9=this['root_'];for(;!_0x4c7da9['isEmpty']();){if(_0x52636c=this['comparator_'](_0x4695f3,_0x4c7da9['key']),_0x52636c===0x0)return _0x4c7da9['value'];_0x52636c<0x0?_0x4c7da9=_0x4c7da9['left']:_0x52636c>0x0&&(_0x4c7da9=_0x4c7da9['right']);}return null;}['getPredecessorKey'](_0x4af05c){let _0x41f2ea,_0x7b8308=this['root_'],_0x25430d=null;for(;!_0x7b8308['isEmpty']();)if(_0x41f2ea=this['comparator_'](_0x4af05c,_0x7b8308['key']),_0x41f2ea===0x0){if(_0x7b8308['left']['isEmpty']())return _0x25430d?_0x25430d['key']:null;for(_0x7b8308=_0x7b8308['left'];!_0x7b8308['right']['isEmpty']();)_0x7b8308=_0x7b8308['right'];return _0x7b8308['key'];}else _0x41f2ea<0x0?_0x7b8308=_0x7b8308['left']:_0x41f2ea>0x0&&(_0x25430d=_0x7b8308,_0x7b8308=_0x7b8308['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2ae597){return this['root_']['inorderTraversal'](_0x2ae597);}['reverseTraversal'](_0x342bee){return this['root_']['reverseTraversal'](_0x342bee);}['getIterator'](_0x151b3a){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x151b3a);}['getIteratorFrom'](_0x1b1739,_0x28bb94){return new rn(this['root_'],_0x1b1739,this['comparator_'],!0x1,_0x28bb94);}['getReverseIteratorFrom'](_0x45491a,_0x31f46c){return new rn(this['root_'],_0x45491a,this['comparator_'],!0x0,_0x31f46c);}['getReverseIterator'](_0x1f02e6){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1f02e6);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2c9af1,_0x18de89){return qe(_0x2c9af1['name'],_0x18de89['name']);}function Qi(_0x3dca67,_0x4f490d){return qe(_0x3dca67,_0x4f490d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0xd270c6){Ci=_0xd270c6;}const Po=function(_0x150281){return typeof _0x150281=='number'?'number:'+ao(_0x150281):'string:'+_0x150281;},No=function(_0x3a1f0b){if(_0x3a1f0b['isLeafNode']()){const _0x66d9f=_0x3a1f0b['val']();f(typeof _0x66d9f=='string'||typeof _0x66d9f=='number'||typeof _0x66d9f=='object'&&Q(_0x66d9f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3a1f0b===Ci||_0x3a1f0b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3a1f0b===Ci||_0x3a1f0b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1ab3c3){nr=_0x1ab3c3;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x3abd14,_0x5b5793=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3abd14,this['priorityNode_']=_0x5b5793,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x6eeb75){return new D(this['value_'],_0x6eeb75);}['getImmediateChild'](_0x10bde9){return _0x10bde9==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1b5612){return v(_0x1b5612)?this:y(_0x1b5612)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x381d99,_0x60bce){return null;}['updateImmediateChild'](_0x433a36,_0x263996){return _0x433a36==='.priority'?this['updatePriority'](_0x263996):_0x263996['isEmpty']()&&_0x433a36!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x433a36,_0x263996)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3b4d60,_0x3a0cbd){const _0x47e76f=y(_0x3b4d60);return _0x47e76f===null?_0x3a0cbd:_0x3a0cbd['isEmpty']()&&_0x47e76f!=='.priority'?this:(f(_0x47e76f!=='.priority'||Ce(_0x3b4d60)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x47e76f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3b4d60),_0x3a0cbd)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5bfccd,_0x47eae6){return!0x1;}['val'](_0x402449){return _0x402449&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x46da39='';this['priorityNode_']['isEmpty']()||(_0x46da39+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x468d3a=typeof this['value_'];_0x46da39+=_0x468d3a+':',_0x468d3a==='number'?_0x46da39+=ao(this['value_']):_0x46da39+=this['value_'],this['lazyHash_']=ro(_0x46da39);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x406aa9){return _0x406aa9===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x406aa9 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x406aa9['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x406aa9));}['compareToLeafNode_'](_0x511acd){const _0x3b5d94=typeof _0x511acd['value_'],_0x1904e5=typeof this['value_'],_0x29391b=D['VALUE_TYPE_ORDER']['indexOf'](_0x3b5d94),_0x2eb752=D['VALUE_TYPE_ORDER']['indexOf'](_0x1904e5);return f(_0x29391b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3b5d94),f(_0x2eb752>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1904e5),_0x29391b===_0x2eb752?_0x1904e5==='object'?0x0:this['value_']<_0x511acd['value_']?-0x1:this['value_']===_0x511acd['value_']?0x0:0x1:_0x2eb752-_0x29391b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2958f7){if(_0x2958f7===this)return!0x0;if(_0x2958f7['isLeafNode']()){const _0x2e4c5e=_0x2958f7;return this['value_']===_0x2e4c5e['value_']&&this['priorityNode_']['equals'](_0x2e4c5e['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x455f7a){Oo=_0x455f7a;}function Wh(_0x3b7919){Do=_0x3b7919;}class Bh extends Fn{['compare'](_0x4e761b,_0x5e9d4e){const _0x2bc352=_0x4e761b['node']['getPriority'](),_0x4e8a01=_0x5e9d4e['node']['getPriority'](),_0x17215d=_0x2bc352['compareTo'](_0x4e8a01);return _0x17215d===0x0?qe(_0x4e761b['name'],_0x5e9d4e['name']):_0x17215d;}['isDefinedOn'](_0x5b36f9){return!_0x5b36f9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x537b81,_0x1a3d99){return!_0x537b81['getPriority']()['equals'](_0x1a3d99['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x133fab,_0x5476b1){const _0x154615=Oo(_0x133fab);return new E(_0x5476b1,new D('[PRIORITY-POST]',_0x154615));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x28d5a0){const _0x415340=_0x5829ed=>parseInt(Math['log'](_0x5829ed)/Vh,0xa),_0x1b521b=_0x201148=>parseInt(Array(_0x201148+0x1)['join']('1'),0x2);this['count']=_0x415340(_0x28d5a0+0x1),this['current_']=this['count']-0x1;const _0x953cbb=_0x1b521b(this['count']);this['bits_']=_0x28d5a0+0x1&_0x953cbb;}['nextBitIsOne'](){const _0xb72404=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xb72404;}}const yn=function(_0xc6e1c0,_0x46dcf1,_0x24d14a,_0x544bd6){_0xc6e1c0['sort'](_0x46dcf1);const _0x134827=function(_0x14ed16,_0x51237b){const _0x31adf7=_0x51237b-_0x14ed16;let _0x34ca68,_0x2d9876;if(_0x31adf7===0x0)return null;if(_0x31adf7===0x1)return _0x34ca68=_0xc6e1c0[_0x14ed16],_0x2d9876=_0x24d14a?_0x24d14a(_0x34ca68):_0x34ca68,new M(_0x2d9876,_0x34ca68['node'],M['BLACK'],null,null);{const _0x9b8402=parseInt(_0x31adf7/0x2,0xa)+_0x14ed16,_0x49e662=_0x134827(_0x14ed16,_0x9b8402),_0x197600=_0x134827(_0x9b8402+0x1,_0x51237b);return _0x34ca68=_0xc6e1c0[_0x9b8402],_0x2d9876=_0x24d14a?_0x24d14a(_0x34ca68):_0x34ca68,new M(_0x2d9876,_0x34ca68['node'],M['BLACK'],_0x49e662,_0x197600);}},_0x35814e=function(_0x1383b8){let _0x265551=null,_0x1ba6b1=null,_0x3e20ca=_0xc6e1c0['length'];const _0x1cab65=function(_0x32725c,_0x4c76b7){const _0x416f82=_0x3e20ca-_0x32725c,_0x221253=_0x3e20ca;_0x3e20ca-=_0x32725c;const _0x1e8a37=_0x134827(_0x416f82+0x1,_0x221253),_0x3b37de=_0xc6e1c0[_0x416f82],_0x1b9993=_0x24d14a?_0x24d14a(_0x3b37de):_0x3b37de;_0x15911e(new M(_0x1b9993,_0x3b37de['node'],_0x4c76b7,null,_0x1e8a37));},_0x15911e=function(_0x369955){_0x265551?(_0x265551['left']=_0x369955,_0x265551=_0x369955):(_0x1ba6b1=_0x369955,_0x265551=_0x369955);};for(let _0x30a1f9=0x0;_0x30a1f9<_0x1383b8['count'];++_0x30a1f9){const _0xac003e=_0x1383b8['nextBitIsOne'](),_0x22e381=Math['pow'](0x2,_0x1383b8['count']-(_0x30a1f9+0x1));_0xac003e?_0x1cab65(_0x22e381,M['BLACK']):(_0x1cab65(_0x22e381,M['BLACK']),_0x1cab65(_0x22e381,M['RED']));}return _0x1ba6b1;},_0x113664=new Hh(_0xc6e1c0['length']),_0x1cfa3d=_0x35814e(_0x113664);return new B(_0x544bd6||_0x46dcf1,_0x1cfa3d);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x39fc55,_0x36c254){this['indexes_']=_0x39fc55,this['indexSet_']=_0x36c254;}['get'](_0x1a4f24){const _0xa4efa5=Le(this['indexes_'],_0x1a4f24);if(!_0xa4efa5)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1a4f24);return _0xa4efa5 instanceof B?_0xa4efa5:null;}['hasIndex'](_0xfb6879){return Q(this['indexSet_'],_0xfb6879['toString']());}['addIndex'](_0x59e852,_0xbb2be7){f(_0x59e852!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x255ab0=[];let _0x4b75a0=!0x1;const _0x5310e5=_0xbb2be7['getIterator'](E['Wrap']);let _0x2a38fa=_0x5310e5['getNext']();for(;_0x2a38fa;)_0x4b75a0=_0x4b75a0||_0x59e852['isDefinedOn'](_0x2a38fa['node']),_0x255ab0['push'](_0x2a38fa),_0x2a38fa=_0x5310e5['getNext']();let _0x37a384;_0x4b75a0?_0x37a384=yn(_0x255ab0,_0x59e852['getCompare']()):_0x37a384=Qe;const _0x1d91b5=_0x59e852['toString'](),_0x37356a={...this['indexSet_']};_0x37356a[_0x1d91b5]=_0x59e852;const _0x2f4118={...this['indexes_']};return _0x2f4118[_0x1d91b5]=_0x37a384,new te(_0x2f4118,_0x37356a);}['addToIndexes'](_0xa456f7,_0x32dec0){const _0x3870cf=_n(this['indexes_'],(_0x515ae6,_0x288e77)=>{const _0x562e0e=Le(this['indexSet_'],_0x288e77);if(f(_0x562e0e,'Missing\x20index\x20implementation\x20for\x20'+_0x288e77),_0x515ae6===Qe){if(_0x562e0e['isDefinedOn'](_0xa456f7['node'])){const _0x232350=[],_0x58ab47=_0x32dec0['getIterator'](E['Wrap']);let _0x2c7111=_0x58ab47['getNext']();for(;_0x2c7111;)_0x2c7111['name']!==_0xa456f7['name']&&_0x232350['push'](_0x2c7111),_0x2c7111=_0x58ab47['getNext']();return _0x232350['push'](_0xa456f7),yn(_0x232350,_0x562e0e['getCompare']());}else return Qe;}else{const _0x594762=_0x32dec0['get'](_0xa456f7['name']);let _0x520e29=_0x515ae6;return _0x594762&&(_0x520e29=_0x520e29['remove'](new E(_0xa456f7['name'],_0x594762))),_0x520e29['insert'](_0xa456f7,_0xa456f7['node']);}});return new te(_0x3870cf,this['indexSet_']);}['removeFromIndexes'](_0x259196,_0x147358){const _0xf23d1f=_n(this['indexes_'],_0x1f03c9=>{if(_0x1f03c9===Qe)return _0x1f03c9;{const _0x3efd5c=_0x147358['get'](_0x259196['name']);return _0x3efd5c?_0x1f03c9['remove'](new E(_0x259196['name'],_0x3efd5c)):_0x1f03c9;}});return new te(_0xf23d1f,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x437113,_0x280c87,_0x26d5d1){this['children_']=_0x437113,this['priorityNode_']=_0x280c87,this['indexMap_']=_0x26d5d1,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x29d197){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x29d197,this['indexMap_']);}['getImmediateChild'](_0x6a8db9){if(_0x6a8db9==='.priority')return this['getPriority']();{const _0x527083=this['children_']['get'](_0x6a8db9);return _0x527083===null?It:_0x527083;}}['getChild'](_0x58011f){const _0x46eeba=y(_0x58011f);return _0x46eeba===null?this:this['getImmediateChild'](_0x46eeba)['getChild'](S(_0x58011f));}['hasChild'](_0x4af5c5){return this['children_']['get'](_0x4af5c5)!==null;}['updateImmediateChild'](_0x4d76f4,_0x250bea){if(f(_0x250bea,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4d76f4==='.priority')return this['updatePriority'](_0x250bea);{const _0x31d2e2=new E(_0x4d76f4,_0x250bea);let _0x5a2684,_0x87bac;_0x250bea['isEmpty']()?(_0x5a2684=this['children_']['remove'](_0x4d76f4),_0x87bac=this['indexMap_']['removeFromIndexes'](_0x31d2e2,this['children_'])):(_0x5a2684=this['children_']['insert'](_0x4d76f4,_0x250bea),_0x87bac=this['indexMap_']['addToIndexes'](_0x31d2e2,this['children_']));const _0x220e64=_0x5a2684['isEmpty']()?It:this['priorityNode_'];return new g(_0x5a2684,_0x220e64,_0x87bac);}}['updateChild'](_0x5ff1be,_0x16b859){const _0x1ce741=y(_0x5ff1be);if(_0x1ce741===null)return _0x16b859;{f(y(_0x5ff1be)!=='.priority'||Ce(_0x5ff1be)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x326bce=this['getImmediateChild'](_0x1ce741)['updateChild'](S(_0x5ff1be),_0x16b859);return this['updateImmediateChild'](_0x1ce741,_0x326bce);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5302c6){if(this['isEmpty']())return null;const _0x59e719={};let _0x239941=0x0,_0x555c53=0x0,_0x239c23=!0x0;if(this['forEachChild'](R,(_0x1a4541,_0x4fdc0f)=>{_0x59e719[_0x1a4541]=_0x4fdc0f['val'](_0x5302c6),_0x239941++,_0x239c23&&g['INTEGER_REGEXP_']['test'](_0x1a4541)?_0x555c53=Math['max'](_0x555c53,Number(_0x1a4541)):_0x239c23=!0x1;}),!_0x5302c6&&_0x239c23&&_0x555c53<0x2*_0x239941){const _0x3ce241=[];for(const _0x231d1f in _0x59e719)_0x3ce241[_0x231d1f]=_0x59e719[_0x231d1f];return _0x3ce241;}else return _0x5302c6&&!this['getPriority']()['isEmpty']()&&(_0x59e719['.priority']=this['getPriority']()['val']()),_0x59e719;}['hash'](){if(this['lazyHash_']===null){let _0x4822a9='';this['getPriority']()['isEmpty']()||(_0x4822a9+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4de118,_0x2523b4)=>{const _0x3d2772=_0x2523b4['hash']();_0x3d2772!==''&&(_0x4822a9+=':'+_0x4de118+':'+_0x3d2772);}),this['lazyHash_']=_0x4822a9===''?'':ro(_0x4822a9);}return this['lazyHash_'];}['getPredecessorChildName'](_0x2d9f0a,_0x4bd523,_0x4312aa){const _0x26d5c6=this['resolveIndex_'](_0x4312aa);if(_0x26d5c6){const _0x32678c=_0x26d5c6['getPredecessorKey'](new E(_0x2d9f0a,_0x4bd523));return _0x32678c?_0x32678c['name']:null;}else return this['children_']['getPredecessorKey'](_0x2d9f0a);}['getFirstChildName'](_0x32194b){const _0xed2523=this['resolveIndex_'](_0x32194b);if(_0xed2523){const _0x467018=_0xed2523['minKey']();return _0x467018&&_0x467018['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x490fbe){const _0x545c8a=this['getFirstChildName'](_0x490fbe);return _0x545c8a?new E(_0x545c8a,this['children_']['get'](_0x545c8a)):null;}['getLastChildName'](_0x36110e){const _0x3491c6=this['resolveIndex_'](_0x36110e);if(_0x3491c6){const _0x395a65=_0x3491c6['maxKey']();return _0x395a65&&_0x395a65['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x409644){const _0x8378ea=this['getLastChildName'](_0x409644);return _0x8378ea?new E(_0x8378ea,this['children_']['get'](_0x8378ea)):null;}['forEachChild'](_0x5a4fe8,_0x23ec8c){const _0x3b4902=this['resolveIndex_'](_0x5a4fe8);return _0x3b4902?_0x3b4902['inorderTraversal'](_0x50a024=>_0x23ec8c(_0x50a024['name'],_0x50a024['node'])):this['children_']['inorderTraversal'](_0x23ec8c);}['getIterator'](_0x56a678){return this['getIteratorFrom'](_0x56a678['minPost'](),_0x56a678);}['getIteratorFrom'](_0x12549b,_0x302281){const _0x23b8ee=this['resolveIndex_'](_0x302281);if(_0x23b8ee)return _0x23b8ee['getIteratorFrom'](_0x12549b,_0x5571c7=>_0x5571c7);{const _0x70a067=this['children_']['getIteratorFrom'](_0x12549b['name'],E['Wrap']);let _0x5395c1=_0x70a067['peek']();for(;_0x5395c1!=null&&_0x302281['compare'](_0x5395c1,_0x12549b)<0x0;)_0x70a067['getNext'](),_0x5395c1=_0x70a067['peek']();return _0x70a067;}}['getReverseIterator'](_0x4edf66){return this['getReverseIteratorFrom'](_0x4edf66['maxPost'](),_0x4edf66);}['getReverseIteratorFrom'](_0x561557,_0x5a3b90){const _0x356230=this['resolveIndex_'](_0x5a3b90);if(_0x356230)return _0x356230['getReverseIteratorFrom'](_0x561557,_0x1c7124=>_0x1c7124);{const _0x4dcaad=this['children_']['getReverseIteratorFrom'](_0x561557['name'],E['Wrap']);let _0x1e5e10=_0x4dcaad['peek']();for(;_0x1e5e10!=null&&_0x5a3b90['compare'](_0x1e5e10,_0x561557)>0x0;)_0x4dcaad['getNext'](),_0x1e5e10=_0x4dcaad['peek']();return _0x4dcaad;}}['compareTo'](_0x219fc7){return this['isEmpty']()?_0x219fc7['isEmpty']()?0x0:-0x1:_0x219fc7['isLeafNode']()||_0x219fc7['isEmpty']()?0x1:_0x219fc7===Kt?-0x1:0x0;}['withIndex'](_0x5ca001){if(_0x5ca001===ve||this['indexMap_']['hasIndex'](_0x5ca001))return this;{const _0x7942fb=this['indexMap_']['addIndex'](_0x5ca001,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x7942fb);}}['isIndexed'](_0x269f36){return _0x269f36===ve||this['indexMap_']['hasIndex'](_0x269f36);}['equals'](_0x649641){if(_0x649641===this)return!0x0;if(_0x649641['isLeafNode']())return!0x1;{const _0x49657f=_0x649641;if(this['getPriority']()['equals'](_0x49657f['getPriority']())){if(this['children_']['count']()===_0x49657f['children_']['count']()){const _0x52542c=this['getIterator'](R),_0x6a32a1=_0x49657f['getIterator'](R);let _0x301fca=_0x52542c['getNext'](),_0x35f4f7=_0x6a32a1['getNext']();for(;_0x301fca&&_0x35f4f7;){if(_0x301fca['name']!==_0x35f4f7['name']||!_0x301fca['node']['equals'](_0x35f4f7['node']))return!0x1;_0x301fca=_0x52542c['getNext'](),_0x35f4f7=_0x6a32a1['getNext']();}return _0x301fca===null&&_0x35f4f7===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3dbeec){return _0x3dbeec===ve?null:this['indexMap_']['get'](_0x3dbeec['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3e942a){return _0x3e942a===this?0x0:0x1;}['equals'](_0x581101){return _0x581101===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5caa17){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x295653,_0x3856f1=null){if(_0x295653===null)return g['EMPTY_NODE'];if(typeof _0x295653=='object'&&'.priority'in _0x295653&&(_0x3856f1=_0x295653['.priority']),f(_0x3856f1===null||typeof _0x3856f1=='string'||typeof _0x3856f1=='number'||typeof _0x3856f1=='object'&&'.sv'in _0x3856f1,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3856f1),typeof _0x295653=='object'&&'.value'in _0x295653&&_0x295653['.value']!==null&&(_0x295653=_0x295653['.value']),typeof _0x295653!='object'||'.sv'in _0x295653){const _0x53936a=_0x295653;return new D(_0x53936a,A(_0x3856f1));}if(!(_0x295653 instanceof Array)&&Gh){const _0x18a4b2=[];let _0x1a51cd=!0x1;if(x(_0x295653,(_0x4b2640,_0x3fbb91)=>{if(_0x4b2640['substring'](0x0,0x1)!=='.'){const _0x33b96a=A(_0x3fbb91);_0x33b96a['isEmpty']()||(_0x1a51cd=_0x1a51cd||!_0x33b96a['getPriority']()['isEmpty'](),_0x18a4b2['push'](new E(_0x4b2640,_0x33b96a)));}}),_0x18a4b2['length']===0x0)return g['EMPTY_NODE'];const _0x7bb40c=yn(_0x18a4b2,xh,_0x5edc84=>_0x5edc84['name'],Qi);if(_0x1a51cd){const _0xcedd96=yn(_0x18a4b2,R['getCompare']());return new g(_0x7bb40c,A(_0x3856f1),new te({'.priority':_0xcedd96},{'.priority':R}));}else return new g(_0x7bb40c,A(_0x3856f1),te['Default']);}else{let _0x13ac9d=g['EMPTY_NODE'];return x(_0x295653,(_0x3f83ee,_0x5a3b7e)=>{if(Q(_0x295653,_0x3f83ee)&&_0x3f83ee['substring'](0x0,0x1)!=='.'){const _0x4398d4=A(_0x5a3b7e);(_0x4398d4['isLeafNode']()||!_0x4398d4['isEmpty']())&&(_0x13ac9d=_0x13ac9d['updateImmediateChild'](_0x3f83ee,_0x4398d4));}}),_0x13ac9d['updatePriority'](A(_0x3856f1));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x5df790){super(),this['indexPath_']=_0x5df790,f(!v(_0x5df790)&&y(_0x5df790)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4377df){return _0x4377df['getChild'](this['indexPath_']);}['isDefinedOn'](_0x431bff){return!_0x431bff['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x596f58,_0x115d8b){const _0xd74034=this['extractChild'](_0x596f58['node']),_0x1d5bb5=this['extractChild'](_0x115d8b['node']),_0x445e5f=_0xd74034['compareTo'](_0x1d5bb5);return _0x445e5f===0x0?qe(_0x596f58['name'],_0x115d8b['name']):_0x445e5f;}['makePost'](_0x1f085d,_0x4c7113){const _0x4f93d7=A(_0x1f085d),_0x24770b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4f93d7);return new E(_0x4c7113,_0x24770b);}['maxPost'](){const _0x4e1d75=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4e1d75);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x31bfe9,_0x284af9){const _0x282166=_0x31bfe9['node']['compareTo'](_0x284af9['node']);return _0x282166===0x0?qe(_0x31bfe9['name'],_0x284af9['name']):_0x282166;}['isDefinedOn'](_0x37799a){return!0x0;}['indexedValueChanged'](_0x9adeb,_0x4b7e60){return!_0x9adeb['equals'](_0x4b7e60);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x29fbe8,_0xf133fb){const _0x2af509=A(_0x29fbe8);return new E(_0xf133fb,_0x2af509);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x198dd3){return{'type':'value','snapshotNode':_0x198dd3};}function rt(_0x29b913,_0x33db8b){return{'type':'child_added','snapshotNode':_0x33db8b,'childName':_0x29b913};}function Lt(_0x2647eb,_0x3db5d5){return{'type':'child_removed','snapshotNode':_0x3db5d5,'childName':_0x2647eb};}function xt(_0x2c9e71,_0x2d4bbf,_0x55e4fa){return{'type':'child_changed','snapshotNode':_0x2d4bbf,'childName':_0x2c9e71,'oldSnap':_0x55e4fa};}function zh(_0x18cfaf,_0x469e75){return{'type':'child_moved','snapshotNode':_0x469e75,'childName':_0x18cfaf};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x2b1a48){this['index_']=_0x2b1a48;}['updateChild'](_0x17e083,_0x28ca93,_0x33dcfe,_0x31aa2a,_0x10c080,_0x407cca){f(_0x17e083['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x21fb12=_0x17e083['getImmediateChild'](_0x28ca93);return _0x21fb12['getChild'](_0x31aa2a)['equals'](_0x33dcfe['getChild'](_0x31aa2a))&&_0x21fb12['isEmpty']()===_0x33dcfe['isEmpty']()||(_0x407cca!=null&&(_0x33dcfe['isEmpty']()?_0x17e083['hasChild'](_0x28ca93)?_0x407cca['trackChildChange'](Lt(_0x28ca93,_0x21fb12)):f(_0x17e083['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x21fb12['isEmpty']()?_0x407cca['trackChildChange'](rt(_0x28ca93,_0x33dcfe)):_0x407cca['trackChildChange'](xt(_0x28ca93,_0x33dcfe,_0x21fb12))),_0x17e083['isLeafNode']()&&_0x33dcfe['isEmpty']())?_0x17e083:_0x17e083['updateImmediateChild'](_0x28ca93,_0x33dcfe)['withIndex'](this['index_']);}['updateFullNode'](_0xe9df24,_0x4056c1,_0x191629){return _0x191629!=null&&(_0xe9df24['isLeafNode']()||_0xe9df24['forEachChild'](R,(_0x114cd3,_0x3288b8)=>{_0x4056c1['hasChild'](_0x114cd3)||_0x191629['trackChildChange'](Lt(_0x114cd3,_0x3288b8));}),_0x4056c1['isLeafNode']()||_0x4056c1['forEachChild'](R,(_0x15b71e,_0x502822)=>{if(_0xe9df24['hasChild'](_0x15b71e)){const _0x3a5c6b=_0xe9df24['getImmediateChild'](_0x15b71e);_0x3a5c6b['equals'](_0x502822)||_0x191629['trackChildChange'](xt(_0x15b71e,_0x502822,_0x3a5c6b));}else _0x191629['trackChildChange'](rt(_0x15b71e,_0x502822));})),_0x4056c1['withIndex'](this['index_']);}['updatePriority'](_0x1046f9,_0x3e2e9f){return _0x1046f9['isEmpty']()?g['EMPTY_NODE']:_0x1046f9['updatePriority'](_0x3e2e9f);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x5db983){this['indexedFilter_']=new Xi(_0x5db983['getIndex']()),this['index_']=_0x5db983['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x5db983),this['endPost_']=Ft['getEndPost_'](_0x5db983),this['startIsInclusive_']=!_0x5db983['startAfterSet_'],this['endIsInclusive_']=!_0x5db983['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x34b24e){const _0x235901=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x34b24e)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x34b24e)<0x0,_0x31867a=this['endIsInclusive_']?this['index_']['compare'](_0x34b24e,this['getEndPost']())<=0x0:this['index_']['compare'](_0x34b24e,this['getEndPost']())<0x0;return _0x235901&&_0x31867a;}['updateChild'](_0x3875ca,_0x28fc1a,_0x377962,_0x2f3e57,_0x41af5d,_0x1836a6){return this['matches'](new E(_0x28fc1a,_0x377962))||(_0x377962=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3875ca,_0x28fc1a,_0x377962,_0x2f3e57,_0x41af5d,_0x1836a6);}['updateFullNode'](_0x3d27fb,_0x16d78d,_0x2cb842){_0x16d78d['isLeafNode']()&&(_0x16d78d=g['EMPTY_NODE']);let _0x19e754=_0x16d78d['withIndex'](this['index_']);_0x19e754=_0x19e754['updatePriority'](g['EMPTY_NODE']);const _0x40db10=this;return _0x16d78d['forEachChild'](R,(_0xe71754,_0x464e3b)=>{_0x40db10['matches'](new E(_0xe71754,_0x464e3b))||(_0x19e754=_0x19e754['updateImmediateChild'](_0xe71754,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3d27fb,_0x19e754,_0x2cb842);}['updatePriority'](_0xb544a3,_0x25b615){return _0xb544a3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2fb62a){if(_0x2fb62a['hasStart']()){const _0x257a53=_0x2fb62a['getIndexStartName']();return _0x2fb62a['getIndex']()['makePost'](_0x2fb62a['getIndexStartValue'](),_0x257a53);}else return _0x2fb62a['getIndex']()['minPost']();}static['getEndPost_'](_0x1402c9){if(_0x1402c9['hasEnd']()){const _0x4f43bc=_0x1402c9['getIndexEndName']();return _0x1402c9['getIndex']()['makePost'](_0x1402c9['getIndexEndValue'](),_0x4f43bc);}else return _0x1402c9['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4b67c5){this['withinDirectionalStart']=_0x134f84=>this['reverse_']?this['withinEndPost'](_0x134f84):this['withinStartPost'](_0x134f84),this['withinDirectionalEnd']=_0x52bd6a=>this['reverse_']?this['withinStartPost'](_0x52bd6a):this['withinEndPost'](_0x52bd6a),this['withinStartPost']=_0x48e0f4=>{const _0x3eacaf=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x48e0f4);return this['startIsInclusive_']?_0x3eacaf<=0x0:_0x3eacaf<0x0;},this['withinEndPost']=_0x13a3e2=>{const _0x110330=this['index_']['compare'](_0x13a3e2,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x110330<=0x0:_0x110330<0x0;},this['rangedFilter_']=new Ft(_0x4b67c5),this['index_']=_0x4b67c5['getIndex'](),this['limit_']=_0x4b67c5['getLimit'](),this['reverse_']=!_0x4b67c5['isViewFromLeft'](),this['startIsInclusive_']=!_0x4b67c5['startAfterSet_'],this['endIsInclusive_']=!_0x4b67c5['endBeforeSet_'];}['updateChild'](_0x28e582,_0x28338f,_0x24f9a0,_0x480207,_0x2269a7,_0x3fc448){return this['rangedFilter_']['matches'](new E(_0x28338f,_0x24f9a0))||(_0x24f9a0=g['EMPTY_NODE']),_0x28e582['getImmediateChild'](_0x28338f)['equals'](_0x24f9a0)?_0x28e582:_0x28e582['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x28e582,_0x28338f,_0x24f9a0,_0x480207,_0x2269a7,_0x3fc448):this['fullLimitUpdateChild_'](_0x28e582,_0x28338f,_0x24f9a0,_0x2269a7,_0x3fc448);}['updateFullNode'](_0x915e98,_0x2788d8,_0x17ebe4){let _0x794e6e;if(_0x2788d8['isLeafNode']()||_0x2788d8['isEmpty']())_0x794e6e=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2788d8['numChildren']()&&_0x2788d8['isIndexed'](this['index_'])){_0x794e6e=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x457e03;this['reverse_']?_0x457e03=_0x2788d8['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x457e03=_0x2788d8['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x50ebae=0x0;for(;_0x457e03['hasNext']()&&_0x50ebae<this['limit_'];){const _0x3435e4=_0x457e03['getNext']();if(this['withinDirectionalStart'](_0x3435e4)){if(this['withinDirectionalEnd'](_0x3435e4))_0x794e6e=_0x794e6e['updateImmediateChild'](_0x3435e4['name'],_0x3435e4['node']),_0x50ebae++;else break;}else continue;}}else{_0x794e6e=_0x2788d8['withIndex'](this['index_']),_0x794e6e=_0x794e6e['updatePriority'](g['EMPTY_NODE']);let _0x179b98;this['reverse_']?_0x179b98=_0x794e6e['getReverseIterator'](this['index_']):_0x179b98=_0x794e6e['getIterator'](this['index_']);let _0x1d6876=0x0;for(;_0x179b98['hasNext']();){const _0x40a9cb=_0x179b98['getNext']();_0x1d6876<this['limit_']&&this['withinDirectionalStart'](_0x40a9cb)&&this['withinDirectionalEnd'](_0x40a9cb)?_0x1d6876++:_0x794e6e=_0x794e6e['updateImmediateChild'](_0x40a9cb['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x915e98,_0x794e6e,_0x17ebe4);}['updatePriority'](_0xeb3cec,_0x2aa608){return _0xeb3cec;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x34d260,_0x5a3a00,_0x8937fd,_0xeb2e69,_0x4580e4){let _0x58b2e7;if(this['reverse_']){const _0x24cae8=this['index_']['getCompare']();_0x58b2e7=(_0x2cfa70,_0x3230ae)=>_0x24cae8(_0x3230ae,_0x2cfa70);}else _0x58b2e7=this['index_']['getCompare']();const _0x47ecd3=_0x34d260;f(_0x47ecd3['numChildren']()===this['limit_'],'');const _0x4f1a20=new E(_0x5a3a00,_0x8937fd),_0x58d53a=this['reverse_']?_0x47ecd3['getFirstChild'](this['index_']):_0x47ecd3['getLastChild'](this['index_']),_0x4fccc4=this['rangedFilter_']['matches'](_0x4f1a20);if(_0x47ecd3['hasChild'](_0x5a3a00)){const _0x48f685=_0x47ecd3['getImmediateChild'](_0x5a3a00);let _0xa0e330=_0xeb2e69['getChildAfterChild'](this['index_'],_0x58d53a,this['reverse_']);for(;_0xa0e330!=null&&(_0xa0e330['name']===_0x5a3a00||_0x47ecd3['hasChild'](_0xa0e330['name']));)_0xa0e330=_0xeb2e69['getChildAfterChild'](this['index_'],_0xa0e330,this['reverse_']);const _0x49929c=_0xa0e330==null?0x1:_0x58b2e7(_0xa0e330,_0x4f1a20);if(_0x4fccc4&&!_0x8937fd['isEmpty']()&&_0x49929c>=0x0)return _0x4580e4!=null&&_0x4580e4['trackChildChange'](xt(_0x5a3a00,_0x8937fd,_0x48f685)),_0x47ecd3['updateImmediateChild'](_0x5a3a00,_0x8937fd);{_0x4580e4!=null&&_0x4580e4['trackChildChange'](Lt(_0x5a3a00,_0x48f685));const _0xa5d153=_0x47ecd3['updateImmediateChild'](_0x5a3a00,g['EMPTY_NODE']);return _0xa0e330!=null&&this['rangedFilter_']['matches'](_0xa0e330)?(_0x4580e4!=null&&_0x4580e4['trackChildChange'](rt(_0xa0e330['name'],_0xa0e330['node'])),_0xa5d153['updateImmediateChild'](_0xa0e330['name'],_0xa0e330['node'])):_0xa5d153;}}else return _0x8937fd['isEmpty']()?_0x34d260:_0x4fccc4&&_0x58b2e7(_0x58d53a,_0x4f1a20)>=0x0?(_0x4580e4!=null&&(_0x4580e4['trackChildChange'](Lt(_0x58d53a['name'],_0x58d53a['node'])),_0x4580e4['trackChildChange'](rt(_0x5a3a00,_0x8937fd))),_0x47ecd3['updateImmediateChild'](_0x5a3a00,_0x8937fd)['updateImmediateChild'](_0x58d53a['name'],g['EMPTY_NODE'])):_0x34d260;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4abdce=new Zi();return _0x4abdce['limitSet_']=this['limitSet_'],_0x4abdce['limit_']=this['limit_'],_0x4abdce['startSet_']=this['startSet_'],_0x4abdce['startAfterSet_']=this['startAfterSet_'],_0x4abdce['indexStartValue_']=this['indexStartValue_'],_0x4abdce['startNameSet_']=this['startNameSet_'],_0x4abdce['indexStartName_']=this['indexStartName_'],_0x4abdce['endSet_']=this['endSet_'],_0x4abdce['endBeforeSet_']=this['endBeforeSet_'],_0x4abdce['indexEndValue_']=this['indexEndValue_'],_0x4abdce['endNameSet_']=this['endNameSet_'],_0x4abdce['indexEndName_']=this['indexEndName_'],_0x4abdce['index_']=this['index_'],_0x4abdce['viewFrom_']=this['viewFrom_'],_0x4abdce;}}function Kh(_0x5ba968){return _0x5ba968['loadsAllData']()?new Xi(_0x5ba968['getIndex']()):_0x5ba968['hasLimit']()?new jh(_0x5ba968):new Ft(_0x5ba968);}function Yh(_0x3c7e51,_0x1c7b05){const _0xb71c3c=_0x3c7e51['copy']();return _0xb71c3c['limitSet_']=!0x0,_0xb71c3c['limit_']=_0x1c7b05,_0xb71c3c['viewFrom_']='l',_0xb71c3c;}function Qh(_0x36515d,_0x494e0f,_0x439355){const _0x3132b0=_0x36515d['copy']();return _0x3132b0['startSet_']=!0x0,_0x494e0f===void 0x0&&(_0x494e0f=null),_0x3132b0['indexStartValue_']=_0x494e0f,_0x439355!=null?(_0x3132b0['startNameSet_']=!0x0,_0x3132b0['indexStartName_']=_0x439355):(_0x3132b0['startNameSet_']=!0x1,_0x3132b0['indexStartName_']=''),_0x3132b0;}function Jh(_0x5bd1f0,_0x1c84c0,_0x4c1f3b){const _0xf07f8c=_0x5bd1f0['copy']();return _0xf07f8c['endSet_']=!0x0,_0x1c84c0===void 0x0&&(_0x1c84c0=null),_0xf07f8c['indexEndValue_']=_0x1c84c0,_0x4c1f3b!==void 0x0?(_0xf07f8c['endNameSet_']=!0x0,_0xf07f8c['indexEndName_']=_0x4c1f3b):(_0xf07f8c['endNameSet_']=!0x1,_0xf07f8c['indexEndName_']=''),_0xf07f8c;}function xo(_0x3a3b33,_0x5acc99){const _0x4acc3e=_0x3a3b33['copy']();return _0x4acc3e['index_']=_0x5acc99,_0x4acc3e;}function ir(_0x3f14a0){const _0x4ecb37={};if(_0x3f14a0['isDefault']())return _0x4ecb37;let _0x4b12e2;if(_0x3f14a0['index_']===R?_0x4b12e2='$priority':_0x3f14a0['index_']===Mo?_0x4b12e2='$value':_0x3f14a0['index_']===ve?_0x4b12e2='$key':(f(_0x3f14a0['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4b12e2=_0x3f14a0['index_']['toString']()),_0x4ecb37['orderBy']=O(_0x4b12e2),_0x3f14a0['startSet_']){const _0x585b8b=_0x3f14a0['startAfterSet_']?'startAfter':'startAt';_0x4ecb37[_0x585b8b]=O(_0x3f14a0['indexStartValue_']),_0x3f14a0['startNameSet_']&&(_0x4ecb37[_0x585b8b]+=','+O(_0x3f14a0['indexStartName_']));}if(_0x3f14a0['endSet_']){const _0x443ec5=_0x3f14a0['endBeforeSet_']?'endBefore':'endAt';_0x4ecb37[_0x443ec5]=O(_0x3f14a0['indexEndValue_']),_0x3f14a0['endNameSet_']&&(_0x4ecb37[_0x443ec5]+=','+O(_0x3f14a0['indexEndName_']));}return _0x3f14a0['limitSet_']&&(_0x3f14a0['isViewFromLeft']()?_0x4ecb37['limitToFirst']=_0x3f14a0['limit_']:_0x4ecb37['limitToLast']=_0x3f14a0['limit_']),_0x4ecb37;}function sr(_0x521d0b){const _0x51809e={};if(_0x521d0b['startSet_']&&(_0x51809e['sp']=_0x521d0b['indexStartValue_'],_0x521d0b['startNameSet_']&&(_0x51809e['sn']=_0x521d0b['indexStartName_']),_0x51809e['sin']=!_0x521d0b['startAfterSet_']),_0x521d0b['endSet_']&&(_0x51809e['ep']=_0x521d0b['indexEndValue_'],_0x521d0b['endNameSet_']&&(_0x51809e['en']=_0x521d0b['indexEndName_']),_0x51809e['ein']=!_0x521d0b['endBeforeSet_']),_0x521d0b['limitSet_']){_0x51809e['l']=_0x521d0b['limit_'];let _0x39e292=_0x521d0b['viewFrom_'];_0x39e292===''&&(_0x521d0b['isViewFromLeft']()?_0x39e292='l':_0x39e292='r'),_0x51809e['vf']=_0x39e292;}return _0x521d0b['index_']!==R&&(_0x51809e['i']=_0x521d0b['index_']['toString']()),_0x51809e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x3022a9){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x54b5d3,_0x52fdca){return _0x52fdca!==void 0x0?'tag$'+_0x52fdca:(f(_0x54b5d3['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x54b5d3['_path']['toString']());}constructor(_0x557a2a,_0x43735b,_0x496390,_0x171910){super(),this['repoInfo_']=_0x557a2a,this['onDataUpdate_']=_0x43735b,this['authTokenProvider_']=_0x496390,this['appCheckTokenProvider_']=_0x171910,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x2ee374,_0x45ecff,_0x55215f,_0x12fcdb){const _0x54e48e=_0x2ee374['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x54e48e+'\x20'+_0x2ee374['_queryIdentifier']);const _0x1fec37=vn['getListenId_'](_0x2ee374,_0x55215f),_0x1edfef={};this['listens_'][_0x1fec37]=_0x1edfef;const _0x480490=ir(_0x2ee374['_queryParams']);this['restRequest_'](_0x54e48e+'.json',_0x480490,(_0x1acfc6,_0x1848b9)=>{let _0x3c9336=_0x1848b9;if(_0x1acfc6===0x194&&(_0x3c9336=null,_0x1acfc6=null),_0x1acfc6===null&&this['onDataUpdate_'](_0x54e48e,_0x3c9336,!0x1,_0x55215f),Le(this['listens_'],_0x1fec37)===_0x1edfef){let _0x302420;_0x1acfc6?_0x1acfc6===0x191?_0x302420='permission_denied':_0x302420='rest_error:'+_0x1acfc6:_0x302420='ok',_0x12fcdb(_0x302420,null);}});}['unlisten'](_0x36fd93,_0x5d928f){const _0x86bca5=vn['getListenId_'](_0x36fd93,_0x5d928f);delete this['listens_'][_0x86bca5];}['get'](_0x12863a){const _0x37bd08=ir(_0x12863a['_queryParams']),_0x5c51dc=_0x12863a['_path']['toString'](),_0x332e5d=new H();return this['restRequest_'](_0x5c51dc+'.json',_0x37bd08,(_0x525e11,_0xdd1f16)=>{let _0x30edb9=_0xdd1f16;_0x525e11===0x194&&(_0x30edb9=null,_0x525e11=null),_0x525e11===null?(this['onDataUpdate_'](_0x5c51dc,_0x30edb9,!0x1,null),_0x332e5d['resolve'](_0x30edb9)):_0x332e5d['reject'](new Error(_0x30edb9));}),_0x332e5d['promise'];}['refreshAuthToken'](_0x4bf3ae){}['restRequest_'](_0x502781,_0x21b8b5={},_0x62707d){return _0x21b8b5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3d6272,_0x1ca589])=>{_0x3d6272&&_0x3d6272['accessToken']&&(_0x21b8b5['auth']=_0x3d6272['accessToken']),_0x1ca589&&_0x1ca589['token']&&(_0x21b8b5['ac']=_0x1ca589['token']);const _0x2236b6=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x502781+'?ns='+this['repoInfo_']['namespace']+ut(_0x21b8b5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2236b6);const _0x2a027f=new XMLHttpRequest();_0x2a027f['onreadystatechange']=()=>{if(_0x62707d&&_0x2a027f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2236b6+'\x20received.\x20status:',_0x2a027f['status'],'response:',_0x2a027f['responseText']);let _0x43e00e=null;if(_0x2a027f['status']>=0xc8&&_0x2a027f['status']<0x12c){try{_0x43e00e=Nt(_0x2a027f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2236b6+':\x20'+_0x2a027f['responseText']);}_0x62707d(null,_0x43e00e);}else _0x2a027f['status']!==0x191&&_0x2a027f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2236b6+'\x20Status:\x20'+_0x2a027f['status']),_0x62707d(_0x2a027f['status']);_0x62707d=null;}},_0x2a027f['open']('GET',_0x2236b6,!0x0),_0x2a027f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x227eaf){return this['rootNode_']['getChild'](_0x227eaf);}['updateSnapshot'](_0x11f36a,_0x29a58a){this['rootNode_']=this['rootNode_']['updateChild'](_0x11f36a,_0x29a58a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x1ab651,_0x5cb4f5,_0x446a5f){if(v(_0x5cb4f5))_0x1ab651['value']=_0x446a5f,_0x1ab651['children']['clear']();else{if(_0x1ab651['value']!==null)_0x1ab651['value']=_0x1ab651['value']['updateChild'](_0x5cb4f5,_0x446a5f);else{const _0x2469f3=y(_0x5cb4f5);_0x1ab651['children']['has'](_0x2469f3)||_0x1ab651['children']['set'](_0x2469f3,En());const _0x298f88=_0x1ab651['children']['get'](_0x2469f3);_0x5cb4f5=S(_0x5cb4f5),pt(_0x298f88,_0x5cb4f5,_0x446a5f);}}}function Ti(_0x59462d,_0x53610d){if(v(_0x53610d))return _0x59462d['value']=null,_0x59462d['children']['clear'](),!0x0;if(_0x59462d['value']!==null){if(_0x59462d['value']['isLeafNode']())return!0x1;{const _0x4d2cd8=_0x59462d['value'];return _0x59462d['value']=null,_0x4d2cd8['forEachChild'](R,(_0xad4e70,_0x49fc94)=>{pt(_0x59462d,new C(_0xad4e70),_0x49fc94);}),Ti(_0x59462d,_0x53610d);}}else{if(_0x59462d['children']['size']>0x0){const _0x59df32=y(_0x53610d);return _0x53610d=S(_0x53610d),_0x59462d['children']['has'](_0x59df32)&&Ti(_0x59462d['children']['get'](_0x59df32),_0x53610d)&&_0x59462d['children']['delete'](_0x59df32),_0x59462d['children']['size']===0x0;}else return!0x0;}}function Si(_0x2043eb,_0xea9158,_0x4e4e15){_0x2043eb['value']!==null?_0x4e4e15(_0xea9158,_0x2043eb['value']):Zh(_0x2043eb,(_0x435dda,_0x321b6b)=>{const _0xa03a92=new C(_0xea9158['toString']()+'/'+_0x435dda);Si(_0x321b6b,_0xa03a92,_0x4e4e15);});}function Zh(_0x1bc4eb,_0x2ce0dc){_0x1bc4eb['children']['forEach']((_0x391e29,_0xd7b486)=>{_0x2ce0dc(_0xd7b486,_0x391e29);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2183c2){this['collection_']=_0x2183c2,this['last_']=null;}['get'](){const _0x15a9f2=this['collection_']['get'](),_0x309a29={..._0x15a9f2};return this['last_']&&x(this['last_'],(_0xbefda2,_0x1e568)=>{_0x309a29[_0xbefda2]=_0x309a29[_0xbefda2]-_0x1e568;}),this['last_']=_0x15a9f2,_0x309a29;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3c9a4e,_0x4bba98){this['server_']=_0x4bba98,this['statsToReport_']={},this['statsListener_']=new eu(_0x3c9a4e);const _0x43023d=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x43023d));}['reportStats_'](){const _0x5912ca=this['statsListener_']['get'](),_0x3a764b={};let _0xd5700a=!0x1;x(_0x5912ca,(_0x2e12b9,_0x2655b4)=>{_0x2655b4>0x0&&Q(this['statsToReport_'],_0x2e12b9)&&(_0x3a764b[_0x2e12b9]=_0x2655b4,_0xd5700a=!0x0);}),_0xd5700a&&this['server_']['reportStats'](_0x3a764b),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x861d27){_0x861d27[_0x861d27['OVERWRITE']=0x0]='OVERWRITE',_0x861d27[_0x861d27['MERGE']=0x1]='MERGE',_0x861d27[_0x861d27['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x861d27[_0x861d27['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x3f2e96){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3f2e96,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x4d6d61,_0x4a57ae,_0x5e0b6f){this['path']=_0x4d6d61,this['affectedTree']=_0x4a57ae,this['revert']=_0x5e0b6f,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x333c4d){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5f759a=this['affectedTree']['subtree'](new C(_0x333c4d));return new In(w(),_0x5f759a,this['revert']);}}else return f(y(this['path'])===_0x333c4d,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x41dbeb,_0x2e8d47){this['source']=_0x41dbeb,this['path']=_0x2e8d47,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1744c3){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5472a5,_0x37023b,_0xa2b6d0){this['source']=_0x5472a5,this['path']=_0x37023b,this['snap']=_0xa2b6d0,this['type']=z['OVERWRITE'];}['operationForChild'](_0x59dc6d){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x59dc6d)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x5d6b5b,_0x5124fb,_0x307079){this['source']=_0x5d6b5b,this['path']=_0x5124fb,this['children']=_0x307079,this['type']=z['MERGE'];}['operationForChild'](_0x46709c){if(v(this['path'])){const _0x23bd22=this['children']['subtree'](new C(_0x46709c));return _0x23bd22['isEmpty']()?null:_0x23bd22['value']?new Be(this['source'],w(),_0x23bd22['value']):new ot(this['source'],w(),_0x23bd22);}else return f(y(this['path'])===_0x46709c,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x3a924b,_0x33b163,_0x16fca2){this['node_']=_0x3a924b,this['fullyInitialized_']=_0x33b163,this['filtered_']=_0x16fca2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4f6217){if(v(_0x4f6217))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4439c9=y(_0x4f6217);return this['isCompleteForChild'](_0x4439c9);}['isCompleteForChild'](_0x3aa9a2){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3aa9a2);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x50f2ad){this['query_']=_0x50f2ad,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x47cff9,_0x432eda,_0x1bf91c,_0x29b7d0){const _0x592996=[],_0x49bec9=[];return _0x432eda['forEach'](_0x1f97b8=>{_0x1f97b8['type']==='child_changed'&&_0x47cff9['index_']['indexedValueChanged'](_0x1f97b8['oldSnap'],_0x1f97b8['snapshotNode'])&&_0x49bec9['push'](zh(_0x1f97b8['childName'],_0x1f97b8['snapshotNode']));}),wt(_0x47cff9,_0x592996,'child_removed',_0x432eda,_0x29b7d0,_0x1bf91c),wt(_0x47cff9,_0x592996,'child_added',_0x432eda,_0x29b7d0,_0x1bf91c),wt(_0x47cff9,_0x592996,'child_moved',_0x49bec9,_0x29b7d0,_0x1bf91c),wt(_0x47cff9,_0x592996,'child_changed',_0x432eda,_0x29b7d0,_0x1bf91c),wt(_0x47cff9,_0x592996,'value',_0x432eda,_0x29b7d0,_0x1bf91c),_0x592996;}function wt(_0x1df9e2,_0x4daf21,_0xa1c35a,_0x5070ac,_0x1218e2,_0x37379d){const _0x30d48a=_0x5070ac['filter'](_0x1db2f0=>_0x1db2f0['type']===_0xa1c35a);_0x30d48a['sort']((_0x47af3b,_0x4a227b)=>au(_0x1df9e2,_0x47af3b,_0x4a227b)),_0x30d48a['forEach'](_0x1d794b=>{const _0x459d46=ou(_0x1df9e2,_0x1d794b,_0x37379d);_0x1218e2['forEach'](_0x40ee32=>{_0x40ee32['respondsTo'](_0x1d794b['type'])&&_0x4daf21['push'](_0x40ee32['createEvent'](_0x459d46,_0x1df9e2['query_']));});});}function ou(_0x2bad27,_0x38fac2,_0x812326){return _0x38fac2['type']==='value'||_0x38fac2['type']==='child_removed'||(_0x38fac2['prevName']=_0x812326['getPredecessorChildName'](_0x38fac2['childName'],_0x38fac2['snapshotNode'],_0x2bad27['index_'])),_0x38fac2;}function au(_0x4860d7,_0x218e58,_0x4c0bcf){if(_0x218e58['childName']==null||_0x4c0bcf['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x41f78f=new E(_0x218e58['childName'],_0x218e58['snapshotNode']),_0x462c60=new E(_0x4c0bcf['childName'],_0x4c0bcf['snapshotNode']);return _0x4860d7['index_']['compare'](_0x41f78f,_0x462c60);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x185185,_0x120747){return{'eventCache':_0x185185,'serverCache':_0x120747};}function Rt(_0x519fd4,_0x284ec0,_0x28bec8,_0x3fbafe){return Un(new Te(_0x284ec0,_0x28bec8,_0x3fbafe),_0x519fd4['serverCache']);}function Fo(_0x2ca254,_0x5b492b,_0x5b4511,_0x5a9f1c){return Un(_0x2ca254['eventCache'],new Te(_0x5b492b,_0x5b4511,_0x5a9f1c));}function wn(_0x51c362){return _0x51c362['eventCache']['isFullyInitialized']()?_0x51c362['eventCache']['getNode']():null;}function Ve(_0x7ea35c){return _0x7ea35c['serverCache']['isFullyInitialized']()?_0x7ea35c['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x3c2011){let _0x2095d6=new b(null);return x(_0x3c2011,(_0x521c1e,_0x212945)=>{_0x2095d6=_0x2095d6['set'](new C(_0x521c1e),_0x212945);}),_0x2095d6;}constructor(_0x43ea31,_0x264bab=cu()){this['value']=_0x43ea31,this['children']=_0x264bab;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x37d155,_0xe5d8f2){if(this['value']!=null&&_0xe5d8f2(this['value']))return{'path':w(),'value':this['value']};if(v(_0x37d155))return null;{const _0x4907ce=y(_0x37d155),_0x44b084=this['children']['get'](_0x4907ce);if(_0x44b084!==null){const _0x45fd7c=_0x44b084['findRootMostMatchingPathAndValue'](S(_0x37d155),_0xe5d8f2);return _0x45fd7c!=null?{'path':k(new C(_0x4907ce),_0x45fd7c['path']),'value':_0x45fd7c['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1a7ed2){return this['findRootMostMatchingPathAndValue'](_0x1a7ed2,()=>!0x0);}['subtree'](_0x2d63de){if(v(_0x2d63de))return this;{const _0x1ad7ab=y(_0x2d63de),_0x3d9048=this['children']['get'](_0x1ad7ab);return _0x3d9048!==null?_0x3d9048['subtree'](S(_0x2d63de)):new b(null);}}['set'](_0x31f9e3,_0x2cb0ec){if(v(_0x31f9e3))return new b(_0x2cb0ec,this['children']);{const _0x5431cb=y(_0x31f9e3),_0x1560d7=(this['children']['get'](_0x5431cb)||new b(null))['set'](S(_0x31f9e3),_0x2cb0ec),_0x3ee42d=this['children']['insert'](_0x5431cb,_0x1560d7);return new b(this['value'],_0x3ee42d);}}['remove'](_0x586e78){if(v(_0x586e78))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5b419b=y(_0x586e78),_0x2db549=this['children']['get'](_0x5b419b);if(_0x2db549){const _0x367dd6=_0x2db549['remove'](S(_0x586e78));let _0x312dbb;return _0x367dd6['isEmpty']()?_0x312dbb=this['children']['remove'](_0x5b419b):_0x312dbb=this['children']['insert'](_0x5b419b,_0x367dd6),this['value']===null&&_0x312dbb['isEmpty']()?new b(null):new b(this['value'],_0x312dbb);}else return this;}}['get'](_0x3d0fb2){if(v(_0x3d0fb2))return this['value'];{const _0x1cebd6=y(_0x3d0fb2),_0x4987f1=this['children']['get'](_0x1cebd6);return _0x4987f1?_0x4987f1['get'](S(_0x3d0fb2)):null;}}['setTree'](_0x46af08,_0xaeec1){if(v(_0x46af08))return _0xaeec1;{const _0x25405b=y(_0x46af08),_0x4e5b49=(this['children']['get'](_0x25405b)||new b(null))['setTree'](S(_0x46af08),_0xaeec1);let _0x543296;return _0x4e5b49['isEmpty']()?_0x543296=this['children']['remove'](_0x25405b):_0x543296=this['children']['insert'](_0x25405b,_0x4e5b49),new b(this['value'],_0x543296);}}['fold'](_0x378dd6){return this['fold_'](w(),_0x378dd6);}['fold_'](_0x52637a,_0x2f1aa0){const _0x2dd7ac={};return this['children']['inorderTraversal']((_0x2cb7ae,_0x37dfe6)=>{_0x2dd7ac[_0x2cb7ae]=_0x37dfe6['fold_'](k(_0x52637a,_0x2cb7ae),_0x2f1aa0);}),_0x2f1aa0(_0x52637a,this['value'],_0x2dd7ac);}['findOnPath'](_0x978ab4,_0xa7ba24){return this['findOnPath_'](_0x978ab4,w(),_0xa7ba24);}['findOnPath_'](_0x565b8f,_0x2d2590,_0x423a87){const _0x39d92d=this['value']?_0x423a87(_0x2d2590,this['value']):!0x1;if(_0x39d92d)return _0x39d92d;if(v(_0x565b8f))return null;{const _0x1c686a=y(_0x565b8f),_0x1f6049=this['children']['get'](_0x1c686a);return _0x1f6049?_0x1f6049['findOnPath_'](S(_0x565b8f),k(_0x2d2590,_0x1c686a),_0x423a87):null;}}['foreachOnPath'](_0x5a65db,_0x466737){return this['foreachOnPath_'](_0x5a65db,w(),_0x466737);}['foreachOnPath_'](_0x3b0d19,_0x38e04b,_0x54accf){if(v(_0x3b0d19))return this;{this['value']&&_0x54accf(_0x38e04b,this['value']);const _0x235ad2=y(_0x3b0d19),_0x971687=this['children']['get'](_0x235ad2);return _0x971687?_0x971687['foreachOnPath_'](S(_0x3b0d19),k(_0x38e04b,_0x235ad2),_0x54accf):new b(null);}}['foreach'](_0x5e548a){this['foreach_'](w(),_0x5e548a);}['foreach_'](_0x15a523,_0x3c051a){this['children']['inorderTraversal']((_0x2dbd4a,_0x245311)=>{_0x245311['foreach_'](k(_0x15a523,_0x2dbd4a),_0x3c051a);}),this['value']&&_0x3c051a(_0x15a523,this['value']);}['foreachChild'](_0x30a295){this['children']['inorderTraversal']((_0x74acc7,_0x3c3dad)=>{_0x3c3dad['value']&&_0x30a295(_0x74acc7,_0x3c3dad['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x3ce818){this['writeTree_']=_0x3ce818;}static['empty'](){return new K(new b(null));}}function At(_0x11b4e6,_0x293157,_0x3b54e4){if(v(_0x293157))return new K(new b(_0x3b54e4));{const _0xe54113=_0x11b4e6['writeTree_']['findRootMostValueAndPath'](_0x293157);if(_0xe54113!=null){const _0x493b58=_0xe54113['path'];let _0xb183d=_0xe54113['value'];const _0x1cdbd5=F(_0x493b58,_0x293157);return _0xb183d=_0xb183d['updateChild'](_0x1cdbd5,_0x3b54e4),new K(_0x11b4e6['writeTree_']['set'](_0x493b58,_0xb183d));}else{const _0xf456ce=new b(_0x3b54e4),_0x4e2d16=_0x11b4e6['writeTree_']['setTree'](_0x293157,_0xf456ce);return new K(_0x4e2d16);}}}function bi(_0x227270,_0x19c0b7,_0x39cfd5){let _0x30f273=_0x227270;return x(_0x39cfd5,(_0x42213b,_0x1f35b3)=>{_0x30f273=At(_0x30f273,k(_0x19c0b7,_0x42213b),_0x1f35b3);}),_0x30f273;}function or(_0xe80a3b,_0x3273){if(v(_0x3273))return K['empty']();{const _0x438329=_0xe80a3b['writeTree_']['setTree'](_0x3273,new b(null));return new K(_0x438329);}}function Ri(_0x5394e6,_0x26e647){return ze(_0x5394e6,_0x26e647)!=null;}function ze(_0xf88e80,_0x40ac98){const _0x1ceb0f=_0xf88e80['writeTree_']['findRootMostValueAndPath'](_0x40ac98);return _0x1ceb0f!=null?_0xf88e80['writeTree_']['get'](_0x1ceb0f['path'])['getChild'](F(_0x1ceb0f['path'],_0x40ac98)):null;}function ar(_0x4aef07){const _0x14bb4b=[],_0x163ea1=_0x4aef07['writeTree_']['value'];return _0x163ea1!=null?_0x163ea1['isLeafNode']()||_0x163ea1['forEachChild'](R,(_0x45d57f,_0x39e27a)=>{_0x14bb4b['push'](new E(_0x45d57f,_0x39e27a));}):_0x4aef07['writeTree_']['children']['inorderTraversal']((_0x2ec8fa,_0x26f7eb)=>{_0x26f7eb['value']!=null&&_0x14bb4b['push'](new E(_0x2ec8fa,_0x26f7eb['value']));}),_0x14bb4b;}function Ee(_0x71205d,_0x1c59c7){if(v(_0x1c59c7))return _0x71205d;{const _0x5d747d=ze(_0x71205d,_0x1c59c7);return _0x5d747d!=null?new K(new b(_0x5d747d)):new K(_0x71205d['writeTree_']['subtree'](_0x1c59c7));}}function Ai(_0x52577e){return _0x52577e['writeTree_']['isEmpty']();}function at(_0x4d0f7a,_0x126a69){return Uo(w(),_0x4d0f7a['writeTree_'],_0x126a69);}function Uo(_0x50edcd,_0x1c2e8b,_0x473c66){if(_0x1c2e8b['value']!=null)return _0x473c66['updateChild'](_0x50edcd,_0x1c2e8b['value']);{let _0x5a1c06=null;return _0x1c2e8b['children']['inorderTraversal']((_0x54e52b,_0x5b3185)=>{_0x54e52b==='.priority'?(f(_0x5b3185['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5a1c06=_0x5b3185['value']):_0x473c66=Uo(k(_0x50edcd,_0x54e52b),_0x5b3185,_0x473c66);}),!_0x473c66['getChild'](_0x50edcd)['isEmpty']()&&_0x5a1c06!==null&&(_0x473c66=_0x473c66['updateChild'](k(_0x50edcd,'.priority'),_0x5a1c06)),_0x473c66;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x164bc1,_0x205bea){return Ho(_0x205bea,_0x164bc1);}function lu(_0x307857,_0x569f13,_0x2caf30,_0x2e98ca,_0x466acf){f(_0x2e98ca>_0x307857['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x466acf===void 0x0&&(_0x466acf=!0x0),_0x307857['allWrites']['push']({'path':_0x569f13,'snap':_0x2caf30,'writeId':_0x2e98ca,'visible':_0x466acf}),_0x466acf&&(_0x307857['visibleWrites']=At(_0x307857['visibleWrites'],_0x569f13,_0x2caf30)),_0x307857['lastWriteId']=_0x2e98ca;}function hu(_0x36060c,_0x5371b7,_0x419d23,_0x2e87b3){f(_0x2e87b3>_0x36060c['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x36060c['allWrites']['push']({'path':_0x5371b7,'children':_0x419d23,'writeId':_0x2e87b3,'visible':!0x0}),_0x36060c['visibleWrites']=bi(_0x36060c['visibleWrites'],_0x5371b7,_0x419d23),_0x36060c['lastWriteId']=_0x2e87b3;}function uu(_0x5d526a,_0x25e3f8){for(let _0xd497c1=0x0;_0xd497c1<_0x5d526a['allWrites']['length'];_0xd497c1++){const _0x31dfd4=_0x5d526a['allWrites'][_0xd497c1];if(_0x31dfd4['writeId']===_0x25e3f8)return _0x31dfd4;}return null;}function du(_0x17d40d,_0x3eba23){const _0x486e08=_0x17d40d['allWrites']['findIndex'](_0x419cd6=>_0x419cd6['writeId']===_0x3eba23);f(_0x486e08>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1d524e=_0x17d40d['allWrites'][_0x486e08];_0x17d40d['allWrites']['splice'](_0x486e08,0x1);let _0x4750e0=_0x1d524e['visible'],_0x37f719=!0x1,_0x1d0968=_0x17d40d['allWrites']['length']-0x1;for(;_0x4750e0&&_0x1d0968>=0x0;){const _0x68d533=_0x17d40d['allWrites'][_0x1d0968];_0x68d533['visible']&&(_0x1d0968>=_0x486e08&&fu(_0x68d533,_0x1d524e['path'])?_0x4750e0=!0x1:G(_0x1d524e['path'],_0x68d533['path'])&&(_0x37f719=!0x0)),_0x1d0968--;}if(_0x4750e0){if(_0x37f719)return pu(_0x17d40d),!0x0;if(_0x1d524e['snap'])_0x17d40d['visibleWrites']=or(_0x17d40d['visibleWrites'],_0x1d524e['path']);else{const _0x5a321a=_0x1d524e['children'];x(_0x5a321a,_0x2746a8=>{_0x17d40d['visibleWrites']=or(_0x17d40d['visibleWrites'],k(_0x1d524e['path'],_0x2746a8));});}return!0x0;}else return!0x1;}function fu(_0x5f1103,_0x32351c){if(_0x5f1103['snap'])return G(_0x5f1103['path'],_0x32351c);for(const _0x101868 in _0x5f1103['children'])if(_0x5f1103['children']['hasOwnProperty'](_0x101868)&&G(k(_0x5f1103['path'],_0x101868),_0x32351c))return!0x0;return!0x1;}function pu(_0x486136){_0x486136['visibleWrites']=Wo(_0x486136['allWrites'],_u,w()),_0x486136['allWrites']['length']>0x0?_0x486136['lastWriteId']=_0x486136['allWrites'][_0x486136['allWrites']['length']-0x1]['writeId']:_0x486136['lastWriteId']=-0x1;}function _u(_0x5259bf){return _0x5259bf['visible'];}function Wo(_0x4730fa,_0x3e3329,_0x2ddf34){let _0x1a2a9f=K['empty']();for(let _0x371935=0x0;_0x371935<_0x4730fa['length'];++_0x371935){const _0x4208d1=_0x4730fa[_0x371935];if(_0x3e3329(_0x4208d1)){const _0x1a3e28=_0x4208d1['path'];let _0x2a9a1d;if(_0x4208d1['snap'])G(_0x2ddf34,_0x1a3e28)?(_0x2a9a1d=F(_0x2ddf34,_0x1a3e28),_0x1a2a9f=At(_0x1a2a9f,_0x2a9a1d,_0x4208d1['snap'])):G(_0x1a3e28,_0x2ddf34)&&(_0x2a9a1d=F(_0x1a3e28,_0x2ddf34),_0x1a2a9f=At(_0x1a2a9f,w(),_0x4208d1['snap']['getChild'](_0x2a9a1d)));else{if(_0x4208d1['children']){if(G(_0x2ddf34,_0x1a3e28))_0x2a9a1d=F(_0x2ddf34,_0x1a3e28),_0x1a2a9f=bi(_0x1a2a9f,_0x2a9a1d,_0x4208d1['children']);else{if(G(_0x1a3e28,_0x2ddf34)){if(_0x2a9a1d=F(_0x1a3e28,_0x2ddf34),v(_0x2a9a1d))_0x1a2a9f=bi(_0x1a2a9f,w(),_0x4208d1['children']);else{const _0xa96b89=Le(_0x4208d1['children'],y(_0x2a9a1d));if(_0xa96b89){const _0x4350dd=_0xa96b89['getChild'](S(_0x2a9a1d));_0x1a2a9f=At(_0x1a2a9f,w(),_0x4350dd);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1a2a9f;}function Bo(_0x2108e5,_0x18b766,_0xda32a2,_0x1d050e,_0x402536){if(!_0x1d050e&&!_0x402536){const _0x2870d9=ze(_0x2108e5['visibleWrites'],_0x18b766);if(_0x2870d9!=null)return _0x2870d9;{const _0x271ea6=Ee(_0x2108e5['visibleWrites'],_0x18b766);if(Ai(_0x271ea6))return _0xda32a2;if(_0xda32a2==null&&!Ri(_0x271ea6,w()))return null;{const _0x1308bf=_0xda32a2||g['EMPTY_NODE'];return at(_0x271ea6,_0x1308bf);}}}else{const _0x12e2d6=Ee(_0x2108e5['visibleWrites'],_0x18b766);if(!_0x402536&&Ai(_0x12e2d6))return _0xda32a2;if(!_0x402536&&_0xda32a2==null&&!Ri(_0x12e2d6,w()))return null;{const _0x266968=function(_0x4207a0){return(_0x4207a0['visible']||_0x402536)&&(!_0x1d050e||!~_0x1d050e['indexOf'](_0x4207a0['writeId']))&&(G(_0x4207a0['path'],_0x18b766)||G(_0x18b766,_0x4207a0['path']));},_0x2db4a9=Wo(_0x2108e5['allWrites'],_0x266968,_0x18b766),_0x3095f5=_0xda32a2||g['EMPTY_NODE'];return at(_0x2db4a9,_0x3095f5);}}}function gu(_0x5f53ce,_0x2c8841,_0x26e6cc){let _0x5a2a35=g['EMPTY_NODE'];const _0x564303=ze(_0x5f53ce['visibleWrites'],_0x2c8841);if(_0x564303)return _0x564303['isLeafNode']()||_0x564303['forEachChild'](R,(_0x4cfae0,_0x5ae957)=>{_0x5a2a35=_0x5a2a35['updateImmediateChild'](_0x4cfae0,_0x5ae957);}),_0x5a2a35;if(_0x26e6cc){const _0x3bbac1=Ee(_0x5f53ce['visibleWrites'],_0x2c8841);return _0x26e6cc['forEachChild'](R,(_0x2838ec,_0x3db9ef)=>{const _0x1fb978=at(Ee(_0x3bbac1,new C(_0x2838ec)),_0x3db9ef);_0x5a2a35=_0x5a2a35['updateImmediateChild'](_0x2838ec,_0x1fb978);}),ar(_0x3bbac1)['forEach'](_0x58ec3f=>{_0x5a2a35=_0x5a2a35['updateImmediateChild'](_0x58ec3f['name'],_0x58ec3f['node']);}),_0x5a2a35;}else{const _0x5b48d1=Ee(_0x5f53ce['visibleWrites'],_0x2c8841);return ar(_0x5b48d1)['forEach'](_0x56437a=>{_0x5a2a35=_0x5a2a35['updateImmediateChild'](_0x56437a['name'],_0x56437a['node']);}),_0x5a2a35;}}function mu(_0x2d3ce1,_0x140e6d,_0xbefd66,_0x4caf1d,_0x1d07aa){f(_0x4caf1d||_0x1d07aa,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x17ea18=k(_0x140e6d,_0xbefd66);if(Ri(_0x2d3ce1['visibleWrites'],_0x17ea18))return null;{const _0x57f91c=Ee(_0x2d3ce1['visibleWrites'],_0x17ea18);return Ai(_0x57f91c)?_0x1d07aa['getChild'](_0xbefd66):at(_0x57f91c,_0x1d07aa['getChild'](_0xbefd66));}}function yu(_0x45ef26,_0x5e7464,_0x1a1807,_0x4175ea){const _0x20dcd6=k(_0x5e7464,_0x1a1807),_0x1df276=ze(_0x45ef26['visibleWrites'],_0x20dcd6);if(_0x1df276!=null)return _0x1df276;if(_0x4175ea['isCompleteForChild'](_0x1a1807)){const _0x1e407a=Ee(_0x45ef26['visibleWrites'],_0x20dcd6);return at(_0x1e407a,_0x4175ea['getNode']()['getImmediateChild'](_0x1a1807));}else return null;}function vu(_0x5023f9,_0x43a2fc){return ze(_0x5023f9['visibleWrites'],_0x43a2fc);}function Eu(_0x4383f,_0x538a9e,_0xd63304,_0x35ea56,_0x63de3c,_0x4da337,_0x1cbcc8){let _0x58248c;const _0x3388e5=Ee(_0x4383f['visibleWrites'],_0x538a9e),_0x1fa71f=ze(_0x3388e5,w());if(_0x1fa71f!=null)_0x58248c=_0x1fa71f;else{if(_0xd63304!=null)_0x58248c=at(_0x3388e5,_0xd63304);else return[];}if(_0x58248c=_0x58248c['withIndex'](_0x1cbcc8),!_0x58248c['isEmpty']()&&!_0x58248c['isLeafNode']()){const _0x259035=[],_0xc8bfad=_0x1cbcc8['getCompare'](),_0x17e981=_0x4da337?_0x58248c['getReverseIteratorFrom'](_0x35ea56,_0x1cbcc8):_0x58248c['getIteratorFrom'](_0x35ea56,_0x1cbcc8);let _0x3c7d7f=_0x17e981['getNext']();for(;_0x3c7d7f&&_0x259035['length']<_0x63de3c;)_0xc8bfad(_0x3c7d7f,_0x35ea56)!==0x0&&_0x259035['push'](_0x3c7d7f),_0x3c7d7f=_0x17e981['getNext']();return _0x259035;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x12f009,_0x5c34cc,_0x566c60,_0x7ef871){return Bo(_0x12f009['writeTree'],_0x12f009['treePath'],_0x5c34cc,_0x566c60,_0x7ef871);}function is(_0x4a59fc,_0x410a8c){return gu(_0x4a59fc['writeTree'],_0x4a59fc['treePath'],_0x410a8c);}function cr(_0x55e64f,_0x70cc1a,_0x2f9c1e,_0x28881b){return mu(_0x55e64f['writeTree'],_0x55e64f['treePath'],_0x70cc1a,_0x2f9c1e,_0x28881b);}function Tn(_0x5bb098,_0x3e89e5){return vu(_0x5bb098['writeTree'],k(_0x5bb098['treePath'],_0x3e89e5));}function wu(_0x1d9e63,_0x1e2cd4,_0x572985,_0x2a8423,_0x874d9e,_0x7400fe){return Eu(_0x1d9e63['writeTree'],_0x1d9e63['treePath'],_0x1e2cd4,_0x572985,_0x2a8423,_0x874d9e,_0x7400fe);}function ss(_0x107f43,_0x4bd00b,_0x4173ee){return yu(_0x107f43['writeTree'],_0x107f43['treePath'],_0x4bd00b,_0x4173ee);}function Vo(_0x476af9,_0x9e165e){return Ho(k(_0x476af9['treePath'],_0x9e165e),_0x476af9['writeTree']);}function Ho(_0x5270bc,_0x307ee6){return{'treePath':_0x5270bc,'writeTree':_0x307ee6};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x4135b3){const _0x440ccf=_0x4135b3['type'],_0xde8eb4=_0x4135b3['childName'];f(_0x440ccf==='child_added'||_0x440ccf==='child_changed'||_0x440ccf==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xde8eb4!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3b3e3e=this['changeMap']['get'](_0xde8eb4);if(_0x3b3e3e){const _0x4a0a5d=_0x3b3e3e['type'];if(_0x440ccf==='child_added'&&_0x4a0a5d==='child_removed')this['changeMap']['set'](_0xde8eb4,xt(_0xde8eb4,_0x4135b3['snapshotNode'],_0x3b3e3e['snapshotNode']));else{if(_0x440ccf==='child_removed'&&_0x4a0a5d==='child_added')this['changeMap']['delete'](_0xde8eb4);else{if(_0x440ccf==='child_removed'&&_0x4a0a5d==='child_changed')this['changeMap']['set'](_0xde8eb4,Lt(_0xde8eb4,_0x3b3e3e['oldSnap']));else{if(_0x440ccf==='child_changed'&&_0x4a0a5d==='child_added')this['changeMap']['set'](_0xde8eb4,rt(_0xde8eb4,_0x4135b3['snapshotNode']));else{if(_0x440ccf==='child_changed'&&_0x4a0a5d==='child_changed')this['changeMap']['set'](_0xde8eb4,xt(_0xde8eb4,_0x4135b3['snapshotNode'],_0x3b3e3e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x4135b3+'\x20occurred\x20after\x20'+_0x3b3e3e);}}}}}else this['changeMap']['set'](_0xde8eb4,_0x4135b3);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1af353){return null;}['getChildAfterChild'](_0x4c888f,_0x252a62,_0x432546){return null;}}const $o=new Tu();class rs{constructor(_0x147609,_0x11890c,_0x29f21b=null){this['writes_']=_0x147609,this['viewCache_']=_0x11890c,this['optCompleteServerCache_']=_0x29f21b;}['getCompleteChild'](_0x19e9a2){const _0xed6d40=this['viewCache_']['eventCache'];if(_0xed6d40['isCompleteForChild'](_0x19e9a2))return _0xed6d40['getNode']()['getImmediateChild'](_0x19e9a2);{const _0x5d9456=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x19e9a2,_0x5d9456);}}['getChildAfterChild'](_0x28b46e,_0x1ad411,_0x88755a){const _0x1f191b=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x160b5e=wu(this['writes_'],_0x1f191b,_0x1ad411,0x1,_0x88755a,_0x28b46e);return _0x160b5e['length']===0x0?null:_0x160b5e[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x570be3){return{'filter':_0x570be3};}function bu(_0x41c700,_0x144209){f(_0x144209['eventCache']['getNode']()['isIndexed'](_0x41c700['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x144209['serverCache']['getNode']()['isIndexed'](_0x41c700['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x200c36,_0x4b53ea,_0x2ddaf,_0x2b6d00,_0x39fd4d){const _0x1848bf=new Cu();let _0x2792b2,_0x51e168;if(_0x2ddaf['type']===z['OVERWRITE']){const _0x5cbbf2=_0x2ddaf;_0x5cbbf2['source']['fromUser']?_0x2792b2=ki(_0x200c36,_0x4b53ea,_0x5cbbf2['path'],_0x5cbbf2['snap'],_0x2b6d00,_0x39fd4d,_0x1848bf):(f(_0x5cbbf2['source']['fromServer'],'Unknown\x20source.'),_0x51e168=_0x5cbbf2['source']['tagged']||_0x4b53ea['serverCache']['isFiltered']()&&!v(_0x5cbbf2['path']),_0x2792b2=Sn(_0x200c36,_0x4b53ea,_0x5cbbf2['path'],_0x5cbbf2['snap'],_0x2b6d00,_0x39fd4d,_0x51e168,_0x1848bf));}else{if(_0x2ddaf['type']===z['MERGE']){const _0x490e87=_0x2ddaf;_0x490e87['source']['fromUser']?_0x2792b2=ku(_0x200c36,_0x4b53ea,_0x490e87['path'],_0x490e87['children'],_0x2b6d00,_0x39fd4d,_0x1848bf):(f(_0x490e87['source']['fromServer'],'Unknown\x20source.'),_0x51e168=_0x490e87['source']['tagged']||_0x4b53ea['serverCache']['isFiltered'](),_0x2792b2=Pi(_0x200c36,_0x4b53ea,_0x490e87['path'],_0x490e87['children'],_0x2b6d00,_0x39fd4d,_0x51e168,_0x1848bf));}else{if(_0x2ddaf['type']===z['ACK_USER_WRITE']){const _0x1dcac2=_0x2ddaf;_0x1dcac2['revert']?_0x2792b2=Ou(_0x200c36,_0x4b53ea,_0x1dcac2['path'],_0x2b6d00,_0x39fd4d,_0x1848bf):_0x2792b2=Pu(_0x200c36,_0x4b53ea,_0x1dcac2['path'],_0x1dcac2['affectedTree'],_0x2b6d00,_0x39fd4d,_0x1848bf);}else{if(_0x2ddaf['type']===z['LISTEN_COMPLETE'])_0x2792b2=Nu(_0x200c36,_0x4b53ea,_0x2ddaf['path'],_0x2b6d00,_0x1848bf);else throw ht('Unknown\x20operation\x20type:\x20'+_0x2ddaf['type']);}}}const _0x1c221f=_0x1848bf['getChanges']();return Au(_0x4b53ea,_0x2792b2,_0x1c221f),{'viewCache':_0x2792b2,'changes':_0x1c221f};}function Au(_0x446e32,_0x7eb7c6,_0x48c941){const _0x4908a4=_0x7eb7c6['eventCache'];if(_0x4908a4['isFullyInitialized']()){const _0x338d2f=_0x4908a4['getNode']()['isLeafNode']()||_0x4908a4['getNode']()['isEmpty'](),_0x1ad77a=wn(_0x446e32);(_0x48c941['length']>0x0||!_0x446e32['eventCache']['isFullyInitialized']()||_0x338d2f&&!_0x4908a4['getNode']()['equals'](_0x1ad77a)||!_0x4908a4['getNode']()['getPriority']()['equals'](_0x1ad77a['getPriority']()))&&_0x48c941['push'](Lo(wn(_0x7eb7c6)));}}function Go(_0x9c04,_0x42c00e,_0x14e6fe,_0x4d4de0,_0x220bc3,_0x1c6be8){const _0x3c2d28=_0x42c00e['eventCache'];if(Tn(_0x4d4de0,_0x14e6fe)!=null)return _0x42c00e;{let _0x142599,_0x377447;if(v(_0x14e6fe)){if(f(_0x42c00e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x42c00e['serverCache']['isFiltered']()){const _0x421242=Ve(_0x42c00e),_0x275bfe=_0x421242 instanceof g?_0x421242:g['EMPTY_NODE'],_0x3acb51=is(_0x4d4de0,_0x275bfe);_0x142599=_0x9c04['filter']['updateFullNode'](_0x42c00e['eventCache']['getNode'](),_0x3acb51,_0x1c6be8);}else{const _0xcfacec=Cn(_0x4d4de0,Ve(_0x42c00e));_0x142599=_0x9c04['filter']['updateFullNode'](_0x42c00e['eventCache']['getNode'](),_0xcfacec,_0x1c6be8);}}else{const _0x4c101e=y(_0x14e6fe);if(_0x4c101e==='.priority'){f(Ce(_0x14e6fe)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x469bdd=_0x3c2d28['getNode']();_0x377447=_0x42c00e['serverCache']['getNode']();const _0x48b35c=cr(_0x4d4de0,_0x14e6fe,_0x469bdd,_0x377447);_0x48b35c!=null?_0x142599=_0x9c04['filter']['updatePriority'](_0x469bdd,_0x48b35c):_0x142599=_0x3c2d28['getNode']();}else{const _0x1c7492=S(_0x14e6fe);let _0x31ad64;if(_0x3c2d28['isCompleteForChild'](_0x4c101e)){_0x377447=_0x42c00e['serverCache']['getNode']();const _0x2575ae=cr(_0x4d4de0,_0x14e6fe,_0x3c2d28['getNode'](),_0x377447);_0x2575ae!=null?_0x31ad64=_0x3c2d28['getNode']()['getImmediateChild'](_0x4c101e)['updateChild'](_0x1c7492,_0x2575ae):_0x31ad64=_0x3c2d28['getNode']()['getImmediateChild'](_0x4c101e);}else _0x31ad64=ss(_0x4d4de0,_0x4c101e,_0x42c00e['serverCache']);_0x31ad64!=null?_0x142599=_0x9c04['filter']['updateChild'](_0x3c2d28['getNode'](),_0x4c101e,_0x31ad64,_0x1c7492,_0x220bc3,_0x1c6be8):_0x142599=_0x3c2d28['getNode']();}}return Rt(_0x42c00e,_0x142599,_0x3c2d28['isFullyInitialized']()||v(_0x14e6fe),_0x9c04['filter']['filtersNodes']());}}function Sn(_0x30083f,_0x5bcd19,_0x5dac5e,_0x3eb00a,_0x560347,_0x43478e,_0x1c73ff,_0x2438c1){const _0x10a3e5=_0x5bcd19['serverCache'];let _0xbcc59f;const _0x57385b=_0x1c73ff?_0x30083f['filter']:_0x30083f['filter']['getIndexedFilter']();if(v(_0x5dac5e))_0xbcc59f=_0x57385b['updateFullNode'](_0x10a3e5['getNode'](),_0x3eb00a,null);else{if(_0x57385b['filtersNodes']()&&!_0x10a3e5['isFiltered']()){const _0x303ff0=_0x10a3e5['getNode']()['updateChild'](_0x5dac5e,_0x3eb00a);_0xbcc59f=_0x57385b['updateFullNode'](_0x10a3e5['getNode'](),_0x303ff0,null);}else{const _0x4e6ff8=y(_0x5dac5e);if(!_0x10a3e5['isCompleteForPath'](_0x5dac5e)&&Ce(_0x5dac5e)>0x1)return _0x5bcd19;const _0x5de29b=S(_0x5dac5e),_0x531953=_0x10a3e5['getNode']()['getImmediateChild'](_0x4e6ff8)['updateChild'](_0x5de29b,_0x3eb00a);_0x4e6ff8==='.priority'?_0xbcc59f=_0x57385b['updatePriority'](_0x10a3e5['getNode'](),_0x531953):_0xbcc59f=_0x57385b['updateChild'](_0x10a3e5['getNode'](),_0x4e6ff8,_0x531953,_0x5de29b,$o,null);}}const _0x2227ac=Fo(_0x5bcd19,_0xbcc59f,_0x10a3e5['isFullyInitialized']()||v(_0x5dac5e),_0x57385b['filtersNodes']()),_0x47ebab=new rs(_0x560347,_0x2227ac,_0x43478e);return Go(_0x30083f,_0x2227ac,_0x5dac5e,_0x560347,_0x47ebab,_0x2438c1);}function ki(_0x37c215,_0x2d5159,_0x38d20d,_0x191ae4,_0x20d0eb,_0x5c0079,_0x43fa54){const _0x116df1=_0x2d5159['eventCache'];let _0x2098ed,_0xa931db;const _0x1e06c9=new rs(_0x20d0eb,_0x2d5159,_0x5c0079);if(v(_0x38d20d))_0xa931db=_0x37c215['filter']['updateFullNode'](_0x2d5159['eventCache']['getNode'](),_0x191ae4,_0x43fa54),_0x2098ed=Rt(_0x2d5159,_0xa931db,!0x0,_0x37c215['filter']['filtersNodes']());else{const _0x3a04f2=y(_0x38d20d);if(_0x3a04f2==='.priority')_0xa931db=_0x37c215['filter']['updatePriority'](_0x2d5159['eventCache']['getNode'](),_0x191ae4),_0x2098ed=Rt(_0x2d5159,_0xa931db,_0x116df1['isFullyInitialized'](),_0x116df1['isFiltered']());else{const _0x185912=S(_0x38d20d),_0x3835d2=_0x116df1['getNode']()['getImmediateChild'](_0x3a04f2);let _0x22e1fb;if(v(_0x185912))_0x22e1fb=_0x191ae4;else{const _0x4607f9=_0x1e06c9['getCompleteChild'](_0x3a04f2);_0x4607f9!=null?ji(_0x185912)==='.priority'&&_0x4607f9['getChild'](Ro(_0x185912))['isEmpty']()?_0x22e1fb=_0x4607f9:_0x22e1fb=_0x4607f9['updateChild'](_0x185912,_0x191ae4):_0x22e1fb=g['EMPTY_NODE'];}if(_0x3835d2['equals'](_0x22e1fb))_0x2098ed=_0x2d5159;else{const _0x4ee091=_0x37c215['filter']['updateChild'](_0x116df1['getNode'](),_0x3a04f2,_0x22e1fb,_0x185912,_0x1e06c9,_0x43fa54);_0x2098ed=Rt(_0x2d5159,_0x4ee091,_0x116df1['isFullyInitialized'](),_0x37c215['filter']['filtersNodes']());}}}return _0x2098ed;}function lr(_0x58b0b9,_0x520feb){return _0x58b0b9['eventCache']['isCompleteForChild'](_0x520feb);}function ku(_0x3e9231,_0x49d547,_0x3e60a7,_0x5e0f11,_0x54398c,_0x5d4e06,_0x43e0e6){let _0x2a86d0=_0x49d547;return _0x5e0f11['foreach']((_0x30f4f6,_0x383f46)=>{const _0x30cddd=k(_0x3e60a7,_0x30f4f6);lr(_0x49d547,y(_0x30cddd))&&(_0x2a86d0=ki(_0x3e9231,_0x2a86d0,_0x30cddd,_0x383f46,_0x54398c,_0x5d4e06,_0x43e0e6));}),_0x5e0f11['foreach']((_0x30324d,_0x7065ac)=>{const _0x3e8940=k(_0x3e60a7,_0x30324d);lr(_0x49d547,y(_0x3e8940))||(_0x2a86d0=ki(_0x3e9231,_0x2a86d0,_0x3e8940,_0x7065ac,_0x54398c,_0x5d4e06,_0x43e0e6));}),_0x2a86d0;}function hr(_0x524d6d,_0x3b0c9b,_0x113131){return _0x113131['foreach']((_0x1348c9,_0x145dbf)=>{_0x3b0c9b=_0x3b0c9b['updateChild'](_0x1348c9,_0x145dbf);}),_0x3b0c9b;}function Pi(_0x2ceb20,_0xd3f657,_0x35d95f,_0x214e20,_0x40120b,_0x4e0595,_0x1a7036,_0x1a3d3d){if(_0xd3f657['serverCache']['getNode']()['isEmpty']()&&!_0xd3f657['serverCache']['isFullyInitialized']())return _0xd3f657;let _0x4e5746=_0xd3f657,_0x1c3ccf;v(_0x35d95f)?_0x1c3ccf=_0x214e20:_0x1c3ccf=new b(null)['setTree'](_0x35d95f,_0x214e20);const _0x47350b=_0xd3f657['serverCache']['getNode']();return _0x1c3ccf['children']['inorderTraversal']((_0x1052c8,_0x176da5)=>{if(_0x47350b['hasChild'](_0x1052c8)){const _0x2b51c5=_0xd3f657['serverCache']['getNode']()['getImmediateChild'](_0x1052c8),_0x12d787=hr(_0x2ceb20,_0x2b51c5,_0x176da5);_0x4e5746=Sn(_0x2ceb20,_0x4e5746,new C(_0x1052c8),_0x12d787,_0x40120b,_0x4e0595,_0x1a7036,_0x1a3d3d);}}),_0x1c3ccf['children']['inorderTraversal']((_0x3cdd5d,_0x275fa4)=>{const _0x4792e7=!_0xd3f657['serverCache']['isCompleteForChild'](_0x3cdd5d)&&_0x275fa4['value']===null;if(!_0x47350b['hasChild'](_0x3cdd5d)&&!_0x4792e7){const _0x5019ac=_0xd3f657['serverCache']['getNode']()['getImmediateChild'](_0x3cdd5d),_0x1056a9=hr(_0x2ceb20,_0x5019ac,_0x275fa4);_0x4e5746=Sn(_0x2ceb20,_0x4e5746,new C(_0x3cdd5d),_0x1056a9,_0x40120b,_0x4e0595,_0x1a7036,_0x1a3d3d);}}),_0x4e5746;}function Pu(_0x257e31,_0x9916a,_0x1659aa,_0x2a7e67,_0x5ead1b,_0x129307,_0x471e0a){if(Tn(_0x5ead1b,_0x1659aa)!=null)return _0x9916a;const _0x3275ba=_0x9916a['serverCache']['isFiltered'](),_0x5e8ffb=_0x9916a['serverCache'];if(_0x2a7e67['value']!=null){if(v(_0x1659aa)&&_0x5e8ffb['isFullyInitialized']()||_0x5e8ffb['isCompleteForPath'](_0x1659aa))return Sn(_0x257e31,_0x9916a,_0x1659aa,_0x5e8ffb['getNode']()['getChild'](_0x1659aa),_0x5ead1b,_0x129307,_0x3275ba,_0x471e0a);if(v(_0x1659aa)){let _0x363ad2=new b(null);return _0x5e8ffb['getNode']()['forEachChild'](ve,(_0x59c2c2,_0x34160b)=>{_0x363ad2=_0x363ad2['set'](new C(_0x59c2c2),_0x34160b);}),Pi(_0x257e31,_0x9916a,_0x1659aa,_0x363ad2,_0x5ead1b,_0x129307,_0x3275ba,_0x471e0a);}else return _0x9916a;}else{let _0x46d591=new b(null);return _0x2a7e67['foreach']((_0x714f5,_0x3fae88)=>{const _0x1ce9d5=k(_0x1659aa,_0x714f5);_0x5e8ffb['isCompleteForPath'](_0x1ce9d5)&&(_0x46d591=_0x46d591['set'](_0x714f5,_0x5e8ffb['getNode']()['getChild'](_0x1ce9d5)));}),Pi(_0x257e31,_0x9916a,_0x1659aa,_0x46d591,_0x5ead1b,_0x129307,_0x3275ba,_0x471e0a);}}function Nu(_0x404c84,_0x45e378,_0x598575,_0x28c4a3,_0x41e56a){const _0x5de823=_0x45e378['serverCache'],_0x398d6b=Fo(_0x45e378,_0x5de823['getNode'](),_0x5de823['isFullyInitialized']()||v(_0x598575),_0x5de823['isFiltered']());return Go(_0x404c84,_0x398d6b,_0x598575,_0x28c4a3,$o,_0x41e56a);}function Ou(_0x564f81,_0x417175,_0x22ef2d,_0x2a3fb3,_0x17af5a,_0x344d7c){let _0x5d1047;if(Tn(_0x2a3fb3,_0x22ef2d)!=null)return _0x417175;{const _0x58d6d3=new rs(_0x2a3fb3,_0x417175,_0x17af5a),_0x48a186=_0x417175['eventCache']['getNode']();let _0x445744;if(v(_0x22ef2d)||y(_0x22ef2d)==='.priority'){let _0x36383b;if(_0x417175['serverCache']['isFullyInitialized']())_0x36383b=Cn(_0x2a3fb3,Ve(_0x417175));else{const _0x20aa19=_0x417175['serverCache']['getNode']();f(_0x20aa19 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x36383b=is(_0x2a3fb3,_0x20aa19);}_0x36383b=_0x36383b,_0x445744=_0x564f81['filter']['updateFullNode'](_0x48a186,_0x36383b,_0x344d7c);}else{const _0x86454b=y(_0x22ef2d);let _0x3f047a=ss(_0x2a3fb3,_0x86454b,_0x417175['serverCache']);_0x3f047a==null&&_0x417175['serverCache']['isCompleteForChild'](_0x86454b)&&(_0x3f047a=_0x48a186['getImmediateChild'](_0x86454b)),_0x3f047a!=null?_0x445744=_0x564f81['filter']['updateChild'](_0x48a186,_0x86454b,_0x3f047a,S(_0x22ef2d),_0x58d6d3,_0x344d7c):_0x417175['eventCache']['getNode']()['hasChild'](_0x86454b)?_0x445744=_0x564f81['filter']['updateChild'](_0x48a186,_0x86454b,g['EMPTY_NODE'],S(_0x22ef2d),_0x58d6d3,_0x344d7c):_0x445744=_0x48a186,_0x445744['isEmpty']()&&_0x417175['serverCache']['isFullyInitialized']()&&(_0x5d1047=Cn(_0x2a3fb3,Ve(_0x417175)),_0x5d1047['isLeafNode']()&&(_0x445744=_0x564f81['filter']['updateFullNode'](_0x445744,_0x5d1047,_0x344d7c)));}return _0x5d1047=_0x417175['serverCache']['isFullyInitialized']()||Tn(_0x2a3fb3,w())!=null,Rt(_0x417175,_0x445744,_0x5d1047,_0x564f81['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x367381,_0x9452f1){this['query_']=_0x367381,this['eventRegistrations_']=[];const _0x2c73e2=this['query_']['_queryParams'],_0x3dd307=new Xi(_0x2c73e2['getIndex']()),_0x3180f5=Kh(_0x2c73e2);this['processor_']=Su(_0x3180f5);const _0x443961=_0x9452f1['serverCache'],_0x40d1a2=_0x9452f1['eventCache'],_0x783c8a=_0x3dd307['updateFullNode'](g['EMPTY_NODE'],_0x443961['getNode'](),null),_0x1c3290=_0x3180f5['updateFullNode'](g['EMPTY_NODE'],_0x40d1a2['getNode'](),null),_0x4dca07=new Te(_0x783c8a,_0x443961['isFullyInitialized'](),_0x3dd307['filtersNodes']()),_0x479af6=new Te(_0x1c3290,_0x40d1a2['isFullyInitialized'](),_0x3180f5['filtersNodes']());this['viewCache_']=Un(_0x479af6,_0x4dca07),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x20271d){return _0x20271d['viewCache_']['serverCache']['getNode']();}function Lu(_0x4d2126){return wn(_0x4d2126['viewCache_']);}function xu(_0x51d307,_0x41d4ee){const _0x1e42c6=Ve(_0x51d307['viewCache_']);return _0x1e42c6&&(_0x51d307['query']['_queryParams']['loadsAllData']()||!v(_0x41d4ee)&&!_0x1e42c6['getImmediateChild'](y(_0x41d4ee))['isEmpty']())?_0x1e42c6['getChild'](_0x41d4ee):null;}function ur(_0x185878){return _0x185878['eventRegistrations_']['length']===0x0;}function Fu(_0x2d8f9b,_0x5f4b5d){_0x2d8f9b['eventRegistrations_']['push'](_0x5f4b5d);}function dr(_0x48d20d,_0x4f346f,_0x2b18b8){const _0x1dab83=[];if(_0x2b18b8){f(_0x4f346f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x4fdb70=_0x48d20d['query']['_path'];_0x48d20d['eventRegistrations_']['forEach'](_0x458fa2=>{const _0x1fd172=_0x458fa2['createCancelEvent'](_0x2b18b8,_0x4fdb70);_0x1fd172&&_0x1dab83['push'](_0x1fd172);});}if(_0x4f346f){let _0x196356=[];for(let _0xfa0dbe=0x0;_0xfa0dbe<_0x48d20d['eventRegistrations_']['length'];++_0xfa0dbe){const _0x5c9cab=_0x48d20d['eventRegistrations_'][_0xfa0dbe];if(!_0x5c9cab['matches'](_0x4f346f))_0x196356['push'](_0x5c9cab);else{if(_0x4f346f['hasAnyCallback']()){_0x196356=_0x196356['concat'](_0x48d20d['eventRegistrations_']['slice'](_0xfa0dbe+0x1));break;}}}_0x48d20d['eventRegistrations_']=_0x196356;}else _0x48d20d['eventRegistrations_']=[];return _0x1dab83;}function fr(_0x34fc94,_0x18b1bc,_0x5828e0,_0x30a389){_0x18b1bc['type']===z['MERGE']&&_0x18b1bc['source']['queryId']!==null&&(f(Ve(_0x34fc94['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x34fc94['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5dd4df=_0x34fc94['viewCache_'],_0x2298f1=Ru(_0x34fc94['processor_'],_0x5dd4df,_0x18b1bc,_0x5828e0,_0x30a389);return bu(_0x34fc94['processor_'],_0x2298f1['viewCache']),f(_0x2298f1['viewCache']['serverCache']['isFullyInitialized']()||!_0x5dd4df['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x34fc94['viewCache_']=_0x2298f1['viewCache'],qo(_0x34fc94,_0x2298f1['changes'],_0x2298f1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x594c86,_0x453eb9){const _0x514aa1=_0x594c86['viewCache_']['eventCache'],_0xa64193=[];return _0x514aa1['getNode']()['isLeafNode']()||_0x514aa1['getNode']()['forEachChild'](R,(_0x35037d,_0x2daadc)=>{_0xa64193['push'](rt(_0x35037d,_0x2daadc));}),_0x514aa1['isFullyInitialized']()&&_0xa64193['push'](Lo(_0x514aa1['getNode']())),qo(_0x594c86,_0xa64193,_0x514aa1['getNode'](),_0x453eb9);}function qo(_0x25791f,_0x5a8e40,_0x176fb9,_0xd6ce1c){const _0x18491d=_0xd6ce1c?[_0xd6ce1c]:_0x25791f['eventRegistrations_'];return ru(_0x25791f['eventGenerator_'],_0x5a8e40,_0x176fb9,_0x18491d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x52a613){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x52a613;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0xe594c6){return _0xe594c6['views']['size']===0x0;}function os(_0x5c02c4,_0x1aac34,_0x218169,_0x38ac1c){const _0xf53867=_0x1aac34['source']['queryId'];if(_0xf53867!==null){const _0x549d35=_0x5c02c4['views']['get'](_0xf53867);return f(_0x549d35!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x549d35,_0x1aac34,_0x218169,_0x38ac1c);}else{let _0x204a52=[];for(const _0x26bdeb of _0x5c02c4['views']['values']())_0x204a52=_0x204a52['concat'](fr(_0x26bdeb,_0x1aac34,_0x218169,_0x38ac1c));return _0x204a52;}}function jo(_0x33a156,_0x3ee095,_0x5048ca,_0x337a22,_0x403c71){const _0x5712ec=_0x3ee095['_queryIdentifier'],_0x466520=_0x33a156['views']['get'](_0x5712ec);if(!_0x466520){let _0x2b58c5=Cn(_0x5048ca,_0x403c71?_0x337a22:null),_0x571f4e=!0x1;_0x2b58c5?_0x571f4e=!0x0:_0x337a22 instanceof g?(_0x2b58c5=is(_0x5048ca,_0x337a22),_0x571f4e=!0x1):(_0x2b58c5=g['EMPTY_NODE'],_0x571f4e=!0x1);const _0xce3d51=Un(new Te(_0x2b58c5,_0x571f4e,!0x1),new Te(_0x337a22,_0x403c71,!0x1));return new Du(_0x3ee095,_0xce3d51);}return _0x466520;}function Hu(_0x44d8ff,_0x53a4dd,_0x27979a,_0x17dfc3,_0x5d3a00,_0x1c28cb){const _0x1672cd=jo(_0x44d8ff,_0x53a4dd,_0x17dfc3,_0x5d3a00,_0x1c28cb);return _0x44d8ff['views']['has'](_0x53a4dd['_queryIdentifier'])||_0x44d8ff['views']['set'](_0x53a4dd['_queryIdentifier'],_0x1672cd),Fu(_0x1672cd,_0x27979a),Uu(_0x1672cd,_0x27979a);}function $u(_0x16f19f,_0x3bf593,_0x3f4362,_0x14701d){const _0x1257c2=_0x3bf593['_queryIdentifier'],_0x457d5d=[];let _0x4ecb3b=[];const _0x3bf96d=Se(_0x16f19f);if(_0x1257c2==='default'){for(const [_0x42ff86,_0x5822a9]of _0x16f19f['views']['entries']())_0x4ecb3b=_0x4ecb3b['concat'](dr(_0x5822a9,_0x3f4362,_0x14701d)),ur(_0x5822a9)&&(_0x16f19f['views']['delete'](_0x42ff86),_0x5822a9['query']['_queryParams']['loadsAllData']()||_0x457d5d['push'](_0x5822a9['query']));}else{const _0x339f09=_0x16f19f['views']['get'](_0x1257c2);_0x339f09&&(_0x4ecb3b=_0x4ecb3b['concat'](dr(_0x339f09,_0x3f4362,_0x14701d)),ur(_0x339f09)&&(_0x16f19f['views']['delete'](_0x1257c2),_0x339f09['query']['_queryParams']['loadsAllData']()||_0x457d5d['push'](_0x339f09['query'])));}return _0x3bf96d&&!Se(_0x16f19f)&&_0x457d5d['push'](new(Bu())(_0x3bf593['_repo'],_0x3bf593['_path'])),{'removed':_0x457d5d,'events':_0x4ecb3b};}function Ko(_0x2a1daf){const _0x465d23=[];for(const _0x4c17d2 of _0x2a1daf['views']['values']())_0x4c17d2['query']['_queryParams']['loadsAllData']()||_0x465d23['push'](_0x4c17d2);return _0x465d23;}function Ie(_0x391712,_0x147cfb){let _0x57d935=null;for(const _0x1a98dd of _0x391712['views']['values']())_0x57d935=_0x57d935||xu(_0x1a98dd,_0x147cfb);return _0x57d935;}function Yo(_0x56cfe0,_0x4e9c6d){if(_0x4e9c6d['_queryParams']['loadsAllData']())return Bn(_0x56cfe0);{const _0x3d89b0=_0x4e9c6d['_queryIdentifier'];return _0x56cfe0['views']['get'](_0x3d89b0);}}function Qo(_0x513512,_0xf3f050){return Yo(_0x513512,_0xf3f050)!=null;}function Se(_0x56a7cb){return Bn(_0x56a7cb)!=null;}function Bn(_0xccdfd2){for(const _0x31c54b of _0xccdfd2['views']['values']())if(_0x31c54b['query']['_queryParams']['loadsAllData']())return _0x31c54b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x12e92d){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x12e92d;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3754d6){this['listenProvider_']=_0x3754d6,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x14ef1e,_0x30408d,_0x1e4bf0,_0x1d8df3,_0x55511e){return lu(_0x14ef1e['pendingWriteTree_'],_0x30408d,_0x1e4bf0,_0x1d8df3,_0x55511e),_0x55511e?_t(_0x14ef1e,new Be(es(),_0x30408d,_0x1e4bf0)):[];}function ju(_0x1996a3,_0x7ebc08,_0x39c33d,_0x37c4e9){hu(_0x1996a3['pendingWriteTree_'],_0x7ebc08,_0x39c33d,_0x37c4e9);const _0x45b00d=b['fromObject'](_0x39c33d);return _t(_0x1996a3,new ot(es(),_0x7ebc08,_0x45b00d));}function _e(_0x1f7013,_0x23bb7e,_0x516f48=!0x1){const _0x4d37cd=uu(_0x1f7013['pendingWriteTree_'],_0x23bb7e);if(du(_0x1f7013['pendingWriteTree_'],_0x23bb7e)){let _0x579488=new b(null);return _0x4d37cd['snap']!=null?_0x579488=_0x579488['set'](w(),!0x0):x(_0x4d37cd['children'],_0x154658=>{_0x579488=_0x579488['set'](new C(_0x154658),!0x0);}),_t(_0x1f7013,new In(_0x4d37cd['path'],_0x579488,_0x516f48));}else return[];}function Yt(_0x125c17,_0x8340e,_0x7ed995){return _t(_0x125c17,new Be(ts(),_0x8340e,_0x7ed995));}function Ku(_0x1cc29c,_0x320839,_0x48bc23){const _0x30fefb=b['fromObject'](_0x48bc23);return _t(_0x1cc29c,new ot(ts(),_0x320839,_0x30fefb));}function Yu(_0x579a6f,_0x1fc6c4){return _t(_0x579a6f,new Ut(ts(),_0x1fc6c4));}function Qu(_0x4f8fd0,_0x28cf06,_0x54ea3e){const _0x54cc2d=cs(_0x4f8fd0,_0x54ea3e);if(_0x54cc2d){const _0x34599f=ls(_0x54cc2d),_0x1964de=_0x34599f['path'],_0x1c5838=_0x34599f['queryId'],_0x326f93=F(_0x1964de,_0x28cf06),_0x53279f=new Ut(ns(_0x1c5838),_0x326f93);return hs(_0x4f8fd0,_0x1964de,_0x53279f);}else return[];}function An(_0xe14319,_0x63d69e,_0x27bba4,_0x37735a,_0xb02c19=!0x1){const _0x49ba5a=_0x63d69e['_path'],_0x4a2edc=_0xe14319['syncPointTree_']['get'](_0x49ba5a);let _0x62c785=[];if(_0x4a2edc&&(_0x63d69e['_queryIdentifier']==='default'||Qo(_0x4a2edc,_0x63d69e))){const _0x5178d3=$u(_0x4a2edc,_0x63d69e,_0x27bba4,_0x37735a);Vu(_0x4a2edc)&&(_0xe14319['syncPointTree_']=_0xe14319['syncPointTree_']['remove'](_0x49ba5a));const _0x3fb024=_0x5178d3['removed'];if(_0x62c785=_0x5178d3['events'],!_0xb02c19){const _0x5e7695=_0x3fb024['findIndex'](_0x2aa899=>_0x2aa899['_queryParams']['loadsAllData']())!==-0x1,_0xd66ccd=_0xe14319['syncPointTree_']['findOnPath'](_0x49ba5a,(_0x181bda,_0x3325a1)=>Se(_0x3325a1));if(_0x5e7695&&!_0xd66ccd){const _0x6258c0=_0xe14319['syncPointTree_']['subtree'](_0x49ba5a);if(!_0x6258c0['isEmpty']()){const _0xe80768=Zu(_0x6258c0);for(let _0x2dac99=0x0;_0x2dac99<_0xe80768['length'];++_0x2dac99){const _0x54394f=_0xe80768[_0x2dac99],_0x314aac=_0x54394f['query'],_0x2dce7=ea(_0xe14319,_0x54394f);_0xe14319['listenProvider_']['startListening'](kt(_0x314aac),Wt(_0xe14319,_0x314aac),_0x2dce7['hashFn'],_0x2dce7['onComplete']);}}}!_0xd66ccd&&_0x3fb024['length']>0x0&&!_0x37735a&&(_0x5e7695?_0xe14319['listenProvider_']['stopListening'](kt(_0x63d69e),null):_0x3fb024['forEach'](_0x17614e=>{const _0x5d5036=_0xe14319['queryToTagMap']['get'](Hn(_0x17614e));_0xe14319['listenProvider_']['stopListening'](kt(_0x17614e),_0x5d5036);}));}ed(_0xe14319,_0x3fb024);}return _0x62c785;}function Jo(_0x4cf12b,_0x4ce11f,_0x37d9ca,_0x56e9bc){const _0x17bd50=cs(_0x4cf12b,_0x56e9bc);if(_0x17bd50!=null){const _0x3019ea=ls(_0x17bd50),_0x16012f=_0x3019ea['path'],_0x495881=_0x3019ea['queryId'],_0x5f3aa5=F(_0x16012f,_0x4ce11f),_0x2b50a5=new Be(ns(_0x495881),_0x5f3aa5,_0x37d9ca);return hs(_0x4cf12b,_0x16012f,_0x2b50a5);}else return[];}function Ju(_0x4b83c2,_0xcfad28,_0x3882fe,_0x3c793f){const _0xd677dc=cs(_0x4b83c2,_0x3c793f);if(_0xd677dc){const _0x174765=ls(_0xd677dc),_0x2b2686=_0x174765['path'],_0x251d37=_0x174765['queryId'],_0x86ba7c=F(_0x2b2686,_0xcfad28),_0x2d5b16=b['fromObject'](_0x3882fe),_0x3255f6=new ot(ns(_0x251d37),_0x86ba7c,_0x2d5b16);return hs(_0x4b83c2,_0x2b2686,_0x3255f6);}else return[];}function Ni(_0x123c54,_0x3aeac0,_0x2b92b3,_0x27d31f=!0x1){const _0x4b3d8b=_0x3aeac0['_path'];let _0x46eb2c=null,_0x2e4cea=!0x1;_0x123c54['syncPointTree_']['foreachOnPath'](_0x4b3d8b,(_0x20a9a7,_0x427100)=>{const _0x581405=F(_0x20a9a7,_0x4b3d8b);_0x46eb2c=_0x46eb2c||Ie(_0x427100,_0x581405),_0x2e4cea=_0x2e4cea||Se(_0x427100);});let _0xb45954=_0x123c54['syncPointTree_']['get'](_0x4b3d8b);_0xb45954?(_0x2e4cea=_0x2e4cea||Se(_0xb45954),_0x46eb2c=_0x46eb2c||Ie(_0xb45954,w())):(_0xb45954=new zo(),_0x123c54['syncPointTree_']=_0x123c54['syncPointTree_']['set'](_0x4b3d8b,_0xb45954));let _0x343b16;_0x46eb2c!=null?_0x343b16=!0x0:(_0x343b16=!0x1,_0x46eb2c=g['EMPTY_NODE'],_0x123c54['syncPointTree_']['subtree'](_0x4b3d8b)['foreachChild']((_0x1971e7,_0x3bb756)=>{const _0x38bcea=Ie(_0x3bb756,w());_0x38bcea&&(_0x46eb2c=_0x46eb2c['updateImmediateChild'](_0x1971e7,_0x38bcea));}));const _0x40b7de=Qo(_0xb45954,_0x3aeac0);if(!_0x40b7de&&!_0x3aeac0['_queryParams']['loadsAllData']()){const _0x1f4c1f=Hn(_0x3aeac0);f(!_0x123c54['queryToTagMap']['has'](_0x1f4c1f),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1f9561=td();_0x123c54['queryToTagMap']['set'](_0x1f4c1f,_0x1f9561),_0x123c54['tagToQueryMap']['set'](_0x1f9561,_0x1f4c1f);}const _0x495271=Wn(_0x123c54['pendingWriteTree_'],_0x4b3d8b);let _0x2f823f=Hu(_0xb45954,_0x3aeac0,_0x2b92b3,_0x495271,_0x46eb2c,_0x343b16);if(!_0x40b7de&&!_0x2e4cea&&!_0x27d31f){const _0x1c8254=Yo(_0xb45954,_0x3aeac0);_0x2f823f=_0x2f823f['concat'](nd(_0x123c54,_0x3aeac0,_0x1c8254));}return _0x2f823f;}function Vn(_0x3ac527,_0x3d2a32,_0x371963){const _0x5e3b2f=_0x3ac527['pendingWriteTree_'],_0x1c06a5=_0x3ac527['syncPointTree_']['findOnPath'](_0x3d2a32,(_0x3be035,_0x51ab55)=>{const _0x3d851b=F(_0x3be035,_0x3d2a32),_0x5f3305=Ie(_0x51ab55,_0x3d851b);if(_0x5f3305)return _0x5f3305;});return Bo(_0x5e3b2f,_0x3d2a32,_0x1c06a5,_0x371963,!0x0);}function Xu(_0x30d3ed,_0x3c1f2b){const _0x4d422a=_0x3c1f2b['_path'];let _0x482c88=null;_0x30d3ed['syncPointTree_']['foreachOnPath'](_0x4d422a,(_0xbba430,_0x3bf783)=>{const _0x2551b9=F(_0xbba430,_0x4d422a);_0x482c88=_0x482c88||Ie(_0x3bf783,_0x2551b9);});let _0x4ed8d7=_0x30d3ed['syncPointTree_']['get'](_0x4d422a);_0x4ed8d7?_0x482c88=_0x482c88||Ie(_0x4ed8d7,w()):(_0x4ed8d7=new zo(),_0x30d3ed['syncPointTree_']=_0x30d3ed['syncPointTree_']['set'](_0x4d422a,_0x4ed8d7));const _0x2a5347=_0x482c88!=null,_0x295f87=_0x2a5347?new Te(_0x482c88,!0x0,!0x1):null,_0x3998d3=Wn(_0x30d3ed['pendingWriteTree_'],_0x3c1f2b['_path']),_0x4ead9e=jo(_0x4ed8d7,_0x3c1f2b,_0x3998d3,_0x2a5347?_0x295f87['getNode']():g['EMPTY_NODE'],_0x2a5347);return Lu(_0x4ead9e);}function _t(_0x51f1f6,_0x197056){return Xo(_0x197056,_0x51f1f6['syncPointTree_'],null,Wn(_0x51f1f6['pendingWriteTree_'],w()));}function Xo(_0x5e7256,_0x21313f,_0x1c70ad,_0x45a65e){if(v(_0x5e7256['path']))return Zo(_0x5e7256,_0x21313f,_0x1c70ad,_0x45a65e);{const _0x15e56f=_0x21313f['get'](w());_0x1c70ad==null&&_0x15e56f!=null&&(_0x1c70ad=Ie(_0x15e56f,w()));let _0x3a9947=[];const _0x1f08d6=y(_0x5e7256['path']),_0xd4e9ee=_0x5e7256['operationForChild'](_0x1f08d6),_0x3c9aba=_0x21313f['children']['get'](_0x1f08d6);if(_0x3c9aba&&_0xd4e9ee){const _0x30c2f8=_0x1c70ad?_0x1c70ad['getImmediateChild'](_0x1f08d6):null,_0x471abb=Vo(_0x45a65e,_0x1f08d6);_0x3a9947=_0x3a9947['concat'](Xo(_0xd4e9ee,_0x3c9aba,_0x30c2f8,_0x471abb));}return _0x15e56f&&(_0x3a9947=_0x3a9947['concat'](os(_0x15e56f,_0x5e7256,_0x45a65e,_0x1c70ad))),_0x3a9947;}}function Zo(_0x5522be,_0x2ee757,_0x13744f,_0x4c7160){const _0x3893c6=_0x2ee757['get'](w());_0x13744f==null&&_0x3893c6!=null&&(_0x13744f=Ie(_0x3893c6,w()));let _0x39fd51=[];return _0x2ee757['children']['inorderTraversal']((_0x56438f,_0x433b61)=>{const _0x4f4f80=_0x13744f?_0x13744f['getImmediateChild'](_0x56438f):null,_0x497131=Vo(_0x4c7160,_0x56438f),_0x3b658f=_0x5522be['operationForChild'](_0x56438f);_0x3b658f&&(_0x39fd51=_0x39fd51['concat'](Zo(_0x3b658f,_0x433b61,_0x4f4f80,_0x497131)));}),_0x3893c6&&(_0x39fd51=_0x39fd51['concat'](os(_0x3893c6,_0x5522be,_0x4c7160,_0x13744f))),_0x39fd51;}function ea(_0x40aac3,_0x2d4f68){const _0x22841f=_0x2d4f68['query'],_0x13658a=Wt(_0x40aac3,_0x22841f);return{'hashFn':()=>(Mu(_0x2d4f68)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1546ab=>{if(_0x1546ab==='ok')return _0x13658a?Qu(_0x40aac3,_0x22841f['_path'],_0x13658a):Yu(_0x40aac3,_0x22841f['_path']);{const _0x2aa3ce=Kl(_0x1546ab,_0x22841f);return An(_0x40aac3,_0x22841f,null,_0x2aa3ce);}}};}function Wt(_0x1876d2,_0x31309d){const _0x57af0e=Hn(_0x31309d);return _0x1876d2['queryToTagMap']['get'](_0x57af0e);}function Hn(_0x50726c){return _0x50726c['_path']['toString']()+'$'+_0x50726c['_queryIdentifier'];}function cs(_0x190909,_0x5bdbdc){return _0x190909['tagToQueryMap']['get'](_0x5bdbdc);}function ls(_0x381f94){const _0x8cc14=_0x381f94['indexOf']('$');return f(_0x8cc14!==-0x1&&_0x8cc14<_0x381f94['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x381f94['substr'](_0x8cc14+0x1),'path':new C(_0x381f94['substr'](0x0,_0x8cc14))};}function hs(_0x3034aa,_0x1db3ca,_0x4774ee){const _0x5bf660=_0x3034aa['syncPointTree_']['get'](_0x1db3ca);f(_0x5bf660,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x22e918=Wn(_0x3034aa['pendingWriteTree_'],_0x1db3ca);return os(_0x5bf660,_0x4774ee,_0x22e918,null);}function Zu(_0x4a4615){return _0x4a4615['fold']((_0x54b3a2,_0x29bb5a,_0x4421a4)=>{if(_0x29bb5a&&Se(_0x29bb5a))return[Bn(_0x29bb5a)];{let _0x256b6e=[];return _0x29bb5a&&(_0x256b6e=Ko(_0x29bb5a)),x(_0x4421a4,(_0x26c9fb,_0x17485c)=>{_0x256b6e=_0x256b6e['concat'](_0x17485c);}),_0x256b6e;}});}function kt(_0x48538f){return _0x48538f['_queryParams']['loadsAllData']()&&!_0x48538f['_queryParams']['isDefault']()?new(qu())(_0x48538f['_repo'],_0x48538f['_path']):_0x48538f;}function ed(_0x29155e,_0x5817c8){for(let _0x52bc5b=0x0;_0x52bc5b<_0x5817c8['length'];++_0x52bc5b){const _0x1ff95b=_0x5817c8[_0x52bc5b];if(!_0x1ff95b['_queryParams']['loadsAllData']()){const _0x4fcd14=Hn(_0x1ff95b),_0x1cc8cb=_0x29155e['queryToTagMap']['get'](_0x4fcd14);_0x29155e['queryToTagMap']['delete'](_0x4fcd14),_0x29155e['tagToQueryMap']['delete'](_0x1cc8cb);}}}function td(){return zu++;}function nd(_0x442964,_0xd353e1,_0x42a5d8){const _0x824451=_0xd353e1['_path'],_0x16467d=Wt(_0x442964,_0xd353e1),_0x5e0b93=ea(_0x442964,_0x42a5d8),_0x111672=_0x442964['listenProvider_']['startListening'](kt(_0xd353e1),_0x16467d,_0x5e0b93['hashFn'],_0x5e0b93['onComplete']),_0x35817c=_0x442964['syncPointTree_']['subtree'](_0x824451);if(_0x16467d)f(!Se(_0x35817c['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x580e20=_0x35817c['fold']((_0x3fc8b9,_0x44babc,_0x5d935b)=>{if(!v(_0x3fc8b9)&&_0x44babc&&Se(_0x44babc))return[Bn(_0x44babc)['query']];{let _0x2fe28a=[];return _0x44babc&&(_0x2fe28a=_0x2fe28a['concat'](Ko(_0x44babc)['map'](_0xf16252=>_0xf16252['query']))),x(_0x5d935b,(_0x2cf19b,_0x5544d0)=>{_0x2fe28a=_0x2fe28a['concat'](_0x5544d0);}),_0x2fe28a;}});for(let _0x4113fd=0x0;_0x4113fd<_0x580e20['length'];++_0x4113fd){const _0x45de38=_0x580e20[_0x4113fd];_0x442964['listenProvider_']['stopListening'](kt(_0x45de38),Wt(_0x442964,_0x45de38));}}return _0x111672;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x416c3b){this['node_']=_0x416c3b;}['getImmediateChild'](_0x149603){const _0x559df7=this['node_']['getImmediateChild'](_0x149603);return new us(_0x559df7);}['node'](){return this['node_'];}}class ds{constructor(_0x27de40,_0x44182d){this['syncTree_']=_0x27de40,this['path_']=_0x44182d;}['getImmediateChild'](_0x3f7be1){const _0x25ba8b=k(this['path_'],_0x3f7be1);return new ds(this['syncTree_'],_0x25ba8b);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x50b619){return _0x50b619=_0x50b619||{},_0x50b619['timestamp']=_0x50b619['timestamp']||new Date()['getTime'](),_0x50b619;},_r=function(_0x43c56f,_0x2d64a7,_0x29aa70){if(!_0x43c56f||typeof _0x43c56f!='object')return _0x43c56f;if(f('.sv'in _0x43c56f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x43c56f['.sv']=='string')return sd(_0x43c56f['.sv'],_0x2d64a7,_0x29aa70);if(typeof _0x43c56f['.sv']=='object')return rd(_0x43c56f['.sv'],_0x2d64a7);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x43c56f,null,0x2));},sd=function(_0x3486ce,_0x25d633,_0x4d97bb){switch(_0x3486ce){case'timestamp':return _0x4d97bb['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3486ce);}},rd=function(_0x3d8420,_0x10affa,_0xecbac){_0x3d8420['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3d8420,null,0x2));const _0x398276=_0x3d8420['increment'];typeof _0x398276!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x398276);const _0x4422a1=_0x10affa['node']();if(f(_0x4422a1!==null&&typeof _0x4422a1<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4422a1['isLeafNode']())return _0x398276;const _0xdd0ca=_0x4422a1['getValue']();return typeof _0xdd0ca!='number'?_0x398276:_0xdd0ca+_0x398276;},ta=function(_0x58795f,_0x33b060,_0x490cba,_0x177431){return ps(_0x33b060,new ds(_0x490cba,_0x58795f),_0x177431);},fs=function(_0x2d9123,_0xdb69c2,_0x1f5c4c){return ps(_0x2d9123,new us(_0xdb69c2),_0x1f5c4c);};function ps(_0xef4019,_0x5645aa,_0x397280){const _0x313cbb=_0xef4019['getPriority']()['val'](),_0x101c3d=_r(_0x313cbb,_0x5645aa['getImmediateChild']('.priority'),_0x397280);let _0x2d8b0a;if(_0xef4019['isLeafNode']()){const _0x39a3c3=_0xef4019,_0x493258=_r(_0x39a3c3['getValue'](),_0x5645aa,_0x397280);return _0x493258!==_0x39a3c3['getValue']()||_0x101c3d!==_0x39a3c3['getPriority']()['val']()?new D(_0x493258,A(_0x101c3d)):_0xef4019;}else{const _0x2bd099=_0xef4019;return _0x2d8b0a=_0x2bd099,_0x101c3d!==_0x2bd099['getPriority']()['val']()&&(_0x2d8b0a=_0x2d8b0a['updatePriority'](new D(_0x101c3d))),_0x2bd099['forEachChild'](R,(_0x471422,_0x4b7ecb)=>{const _0x4bdd4e=ps(_0x4b7ecb,_0x5645aa['getImmediateChild'](_0x471422),_0x397280);_0x4bdd4e!==_0x4b7ecb&&(_0x2d8b0a=_0x2d8b0a['updateImmediateChild'](_0x471422,_0x4bdd4e));}),_0x2d8b0a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x2fbe08='',_0x53f3fd=null,_0x51977e={'children':{},'childCount':0x0}){this['name']=_0x2fbe08,this['parent']=_0x53f3fd,this['node']=_0x51977e;}}function $n(_0x10321a,_0x3e8789){let _0x21ef14=_0x3e8789 instanceof C?_0x3e8789:new C(_0x3e8789),_0x208b20=_0x10321a,_0x141799=y(_0x21ef14);for(;_0x141799!==null;){const _0x28b81f=Le(_0x208b20['node']['children'],_0x141799)||{'children':{},'childCount':0x0};_0x208b20=new _s(_0x141799,_0x208b20,_0x28b81f),_0x21ef14=S(_0x21ef14),_0x141799=y(_0x21ef14);}return _0x208b20;}function je(_0x200f4d){return _0x200f4d['node']['value'];}function gs(_0x501a9e,_0x557fb2){_0x501a9e['node']['value']=_0x557fb2,Oi(_0x501a9e);}function na(_0x525e17){return _0x525e17['node']['childCount']>0x0;}function od(_0x1e2543){return je(_0x1e2543)===void 0x0&&!na(_0x1e2543);}function Gn(_0x2cee09,_0x2ed10a){x(_0x2cee09['node']['children'],(_0x583f43,_0x2c42d3)=>{_0x2ed10a(new _s(_0x583f43,_0x2cee09,_0x2c42d3));});}function ia(_0x327004,_0x5cc633,_0x54f45d,_0x4862c9){_0x54f45d&&_0x5cc633(_0x327004),Gn(_0x327004,_0x273846=>{ia(_0x273846,_0x5cc633,!0x0);});}function ad(_0x365eb9,_0x72b498,_0x3b269f){let _0x47414b=_0x365eb9['parent'];for(;_0x47414b!==null;){if(_0x72b498(_0x47414b))return!0x0;_0x47414b=_0x47414b['parent'];}return!0x1;}function Qt(_0x1c54f5){return new C(_0x1c54f5['parent']===null?_0x1c54f5['name']:Qt(_0x1c54f5['parent'])+'/'+_0x1c54f5['name']);}function Oi(_0x2f6e68){_0x2f6e68['parent']!==null&&cd(_0x2f6e68['parent'],_0x2f6e68['name'],_0x2f6e68);}function cd(_0x3bf344,_0xcb2a7d,_0x2d6020){const _0x328c79=od(_0x2d6020),_0x221283=Q(_0x3bf344['node']['children'],_0xcb2a7d);_0x328c79&&_0x221283?(delete _0x3bf344['node']['children'][_0xcb2a7d],_0x3bf344['node']['childCount']--,Oi(_0x3bf344)):!_0x328c79&&!_0x221283&&(_0x3bf344['node']['children'][_0xcb2a7d]=_0x2d6020['node'],_0x3bf344['node']['childCount']++,Oi(_0x3bf344));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x5e1e1a){return typeof _0x5e1e1a=='string'&&_0x5e1e1a['length']!==0x0&&!ld['test'](_0x5e1e1a);},sa=function(_0x454c5f){return typeof _0x454c5f=='string'&&_0x454c5f['length']!==0x0&&!hd['test'](_0x454c5f);},ud=function(_0x5f5f){return _0x5f5f&&(_0x5f5f=_0x5f5f['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x5f5f);},Bt=function(_0x2823e6){return _0x2823e6===null||typeof _0x2823e6=='string'||typeof _0x2823e6=='number'&&!xn(_0x2823e6)||_0x2823e6&&typeof _0x2823e6=='object'&&Q(_0x2823e6,'.sv');},He=function(_0xd6751d,_0x470a64,_0x5fdf2a,_0x1af4a9){_0x1af4a9&&_0x470a64===void 0x0||Jt(it(_0xd6751d,'value'),_0x470a64,_0x5fdf2a);},Jt=function(_0x5465c9,_0x598c71,_0x4ef0fe){const _0xebcd2b=_0x4ef0fe instanceof C?new Ah(_0x4ef0fe,_0x5465c9):_0x4ef0fe;if(_0x598c71===void 0x0)throw new Error(_0x5465c9+'contains\x20undefined\x20'+Oe(_0xebcd2b));if(typeof _0x598c71=='function')throw new Error(_0x5465c9+'contains\x20a\x20function\x20'+Oe(_0xebcd2b)+'\x20with\x20contents\x20=\x20'+_0x598c71['toString']());if(xn(_0x598c71))throw new Error(_0x5465c9+'contains\x20'+_0x598c71['toString']()+'\x20'+Oe(_0xebcd2b));if(typeof _0x598c71=='string'&&_0x598c71['length']>ui/0x3&&Ln(_0x598c71)>ui)throw new Error(_0x5465c9+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0xebcd2b)+'\x20(\x27'+_0x598c71['substring'](0x0,0x32)+'...\x27)');if(_0x598c71&&typeof _0x598c71=='object'){let _0x1496f2=!0x1,_0x3b7425=!0x1;if(x(_0x598c71,(_0x561afe,_0x245bfc)=>{if(_0x561afe==='.value')_0x1496f2=!0x0;else{if(_0x561afe!=='.priority'&&_0x561afe!=='.sv'&&(_0x3b7425=!0x0,!ms(_0x561afe)))throw new Error(_0x5465c9+'\x20contains\x20an\x20invalid\x20key\x20('+_0x561afe+')\x20'+Oe(_0xebcd2b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xebcd2b,_0x561afe),Jt(_0x5465c9,_0x245bfc,_0xebcd2b),Ph(_0xebcd2b);}),_0x1496f2&&_0x3b7425)throw new Error(_0x5465c9+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0xebcd2b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5d77b5,_0x4c1fba){let _0x4cee9f,_0x2c50d9;for(_0x4cee9f=0x0;_0x4cee9f<_0x4c1fba['length'];_0x4cee9f++){_0x2c50d9=_0x4c1fba[_0x4cee9f];const _0x1cddaf=Mt(_0x2c50d9);for(let _0x1fe4ca=0x0;_0x1fe4ca<_0x1cddaf['length'];_0x1fe4ca++)if(!(_0x1cddaf[_0x1fe4ca]==='.priority'&&_0x1fe4ca===_0x1cddaf['length']-0x1)){if(!ms(_0x1cddaf[_0x1fe4ca]))throw new Error(_0x5d77b5+'contains\x20an\x20invalid\x20key\x20('+_0x1cddaf[_0x1fe4ca]+')\x20in\x20path\x20'+_0x2c50d9['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4c1fba['sort'](Rh);let _0x314b1e=null;for(_0x4cee9f=0x0;_0x4cee9f<_0x4c1fba['length'];_0x4cee9f++){if(_0x2c50d9=_0x4c1fba[_0x4cee9f],_0x314b1e!==null&&G(_0x314b1e,_0x2c50d9))throw new Error(_0x5d77b5+'contains\x20a\x20path\x20'+_0x314b1e['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2c50d9['toString']());_0x314b1e=_0x2c50d9;}},ra=function(_0x1282c8,_0x5c1ffd,_0x5ba3ab,_0x3a0508){const _0x454d64=it(_0x1282c8,'values');if(!(_0x5c1ffd&&typeof _0x5c1ffd=='object')||Array['isArray'](_0x5c1ffd))throw new Error(_0x454d64+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1cc226=[];x(_0x5c1ffd,(_0x4ab778,_0x55ee74)=>{const _0x560000=new C(_0x4ab778);if(Jt(_0x454d64,_0x55ee74,k(_0x5ba3ab,_0x560000)),ji(_0x560000)==='.priority'&&!Bt(_0x55ee74))throw new Error(_0x454d64+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x560000['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1cc226['push'](_0x560000);}),dd(_0x454d64,_0x1cc226);},fd=function(_0x111864,_0x3d306c,_0x139855){if(xn(_0x3d306c))throw new Error(it(_0x111864,'priority')+'is\x20'+_0x3d306c['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3d306c))throw new Error(it(_0x111864,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x33f694,_0x595eb4,_0x1a0e01,_0x148e31){if(!sa(_0x1a0e01))throw new Error(it(_0x33f694,_0x595eb4)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1a0e01+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x502011,_0x61ef2f,_0x488ce6,_0x4dc35c){_0x488ce6&&(_0x488ce6=_0x488ce6['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x502011,_0x61ef2f,_0x488ce6);},Me=function(_0x79d956,_0x5799df){if(y(_0x5799df)==='.info')throw new Error(_0x79d956+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x151c53,_0x2d1151){const _0x4d19fd=_0x2d1151['path']['toString']();if(typeof _0x2d1151['repoInfo']['host']!='string'||_0x2d1151['repoInfo']['host']['length']===0x0||!ms(_0x2d1151['repoInfo']['namespace'])&&_0x2d1151['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4d19fd['length']!==0x0&&!ud(_0x4d19fd))throw new Error(it(_0x151c53,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x108e88,_0x22028c){let _0x9436ae=null;for(let _0x3a96c0=0x0;_0x3a96c0<_0x22028c['length'];_0x3a96c0++){const _0x316f7e=_0x22028c[_0x3a96c0],_0x32997d=_0x316f7e['getPath']();_0x9436ae!==null&&!Ki(_0x32997d,_0x9436ae['path'])&&(_0x108e88['eventLists_']['push'](_0x9436ae),_0x9436ae=null),_0x9436ae===null&&(_0x9436ae={'events':[],'path':_0x32997d}),_0x9436ae['events']['push'](_0x316f7e);}_0x9436ae&&_0x108e88['eventLists_']['push'](_0x9436ae);}function oa(_0x1a8554,_0x36bd75,_0x3d18a5){qn(_0x1a8554,_0x3d18a5),aa(_0x1a8554,_0x565de6=>Ki(_0x565de6,_0x36bd75));}function V(_0xcc5ca8,_0x43fb87,_0x19ddab){qn(_0xcc5ca8,_0x19ddab),aa(_0xcc5ca8,_0x23197d=>G(_0x23197d,_0x43fb87)||G(_0x43fb87,_0x23197d));}function aa(_0xd4ac7d,_0x191049){_0xd4ac7d['recursionDepth_']++;let _0x48e68e=!0x0;for(let _0x3b3b85=0x0;_0x3b3b85<_0xd4ac7d['eventLists_']['length'];_0x3b3b85++){const _0x4d13d7=_0xd4ac7d['eventLists_'][_0x3b3b85];if(_0x4d13d7){const _0x2c9e2f=_0x4d13d7['path'];_0x191049(_0x2c9e2f)?(md(_0xd4ac7d['eventLists_'][_0x3b3b85]),_0xd4ac7d['eventLists_'][_0x3b3b85]=null):_0x48e68e=!0x1;}}_0x48e68e&&(_0xd4ac7d['eventLists_']=[]),_0xd4ac7d['recursionDepth_']--;}function md(_0x5a1b28){for(let _0xbfb5b7=0x0;_0xbfb5b7<_0x5a1b28['events']['length'];_0xbfb5b7++){const _0x1c515d=_0x5a1b28['events'][_0xbfb5b7];if(_0x1c515d!==null){_0x5a1b28['events'][_0xbfb5b7]=null;const _0x2f2e70=_0x1c515d['getEventRunner']();St&&L('event:\x20'+_0x1c515d['toString']()),ft(_0x2f2e70);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x43b35a,_0x17a6b7,_0x246bfc,_0x3d1f03){this['repoInfo_']=_0x43b35a,this['forceRestClient_']=_0x17a6b7,this['authTokenProvider_']=_0x246bfc,this['appCheckProvider_']=_0x3d1f03,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1dcb04,_0x262a0e,_0x284120){if(_0x1dcb04['stats_']=qi(_0x1dcb04['repoInfo_']),_0x1dcb04['forceRestClient_']||Xl())_0x1dcb04['server_']=new vn(_0x1dcb04['repoInfo_'],(_0x4c7b9a,_0x579b9d,_0x128330,_0x385b1e)=>{gr(_0x1dcb04,_0x4c7b9a,_0x579b9d,_0x128330,_0x385b1e);},_0x1dcb04['authTokenProvider_'],_0x1dcb04['appCheckProvider_']),setTimeout(()=>mr(_0x1dcb04,!0x0),0x0);else{if(typeof _0x284120<'u'&&_0x284120!==null){if(typeof _0x284120!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x284120);}catch(_0x528843){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x528843);}}_0x1dcb04['persistentConnection_']=new se(_0x1dcb04['repoInfo_'],_0x262a0e,(_0x17ec39,_0x49bcca,_0x169833,_0x417306)=>{gr(_0x1dcb04,_0x17ec39,_0x49bcca,_0x169833,_0x417306);},_0x75c4dd=>{mr(_0x1dcb04,_0x75c4dd);},_0x58dcb9=>{Id(_0x1dcb04,_0x58dcb9);},_0x1dcb04['authTokenProvider_'],_0x1dcb04['appCheckProvider_'],_0x284120),_0x1dcb04['server_']=_0x1dcb04['persistentConnection_'];}_0x1dcb04['authTokenProvider_']['addTokenChangeListener'](_0x218989=>{_0x1dcb04['server_']['refreshAuthToken'](_0x218989);}),_0x1dcb04['appCheckProvider_']['addTokenChangeListener'](_0x3d1efc=>{_0x1dcb04['server_']['refreshAppCheckToken'](_0x3d1efc['token']);}),_0x1dcb04['statsReporter_']=ih(_0x1dcb04['repoInfo_'],()=>new iu(_0x1dcb04['stats_'],_0x1dcb04['server_'])),_0x1dcb04['infoData_']=new Xh(),_0x1dcb04['infoSyncTree_']=new pr({'startListening':(_0x23589e,_0x3d7639,_0x2386af,_0x597462)=>{let _0xf5a501=[];const _0x3ff8e7=_0x1dcb04['infoData_']['getNode'](_0x23589e['_path']);return _0x3ff8e7['isEmpty']()||(_0xf5a501=Yt(_0x1dcb04['infoSyncTree_'],_0x23589e['_path'],_0x3ff8e7),setTimeout(()=>{_0x597462('ok');},0x0)),_0xf5a501;},'stopListening':()=>{}}),vs(_0x1dcb04,'connected',!0x1),_0x1dcb04['serverSyncTree_']=new pr({'startListening':(_0xe221a5,_0x30e74e,_0x11388c,_0x1a7829)=>(_0x1dcb04['server_']['listen'](_0xe221a5,_0x11388c,_0x30e74e,(_0x5a72bf,_0x3f7851)=>{const _0x30d397=_0x1a7829(_0x5a72bf,_0x3f7851);V(_0x1dcb04['eventQueue_'],_0xe221a5['_path'],_0x30d397);}),[]),'stopListening':(_0x2e1934,_0x49636b)=>{_0x1dcb04['server_']['unlisten'](_0x2e1934,_0x49636b);}});}function la(_0x25f849){const _0x3ec661=_0x25f849['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3ec661;}function Xt(_0x50f67c){return id({'timestamp':la(_0x50f67c)});}function gr(_0x5b4432,_0x2be1ce,_0x5218e6,_0x239a64,_0x178dec){_0x5b4432['dataUpdateCount']++;const _0x4b8deb=new C(_0x2be1ce);_0x5218e6=_0x5b4432['interceptServerDataCallback_']?_0x5b4432['interceptServerDataCallback_'](_0x2be1ce,_0x5218e6):_0x5218e6;let _0x33d1b4=[];if(_0x178dec){if(_0x239a64){const _0x41788e=_n(_0x5218e6,_0xbe9c88=>A(_0xbe9c88));_0x33d1b4=Ju(_0x5b4432['serverSyncTree_'],_0x4b8deb,_0x41788e,_0x178dec);}else{const _0x23d509=A(_0x5218e6);_0x33d1b4=Jo(_0x5b4432['serverSyncTree_'],_0x4b8deb,_0x23d509,_0x178dec);}}else{if(_0x239a64){const _0x45eb5a=_n(_0x5218e6,_0x4341c3=>A(_0x4341c3));_0x33d1b4=Ku(_0x5b4432['serverSyncTree_'],_0x4b8deb,_0x45eb5a);}else{const _0x1a9ade=A(_0x5218e6);_0x33d1b4=Yt(_0x5b4432['serverSyncTree_'],_0x4b8deb,_0x1a9ade);}}let _0x22459e=_0x4b8deb;_0x33d1b4['length']>0x0&&(_0x22459e=ct(_0x5b4432,_0x4b8deb)),V(_0x5b4432['eventQueue_'],_0x22459e,_0x33d1b4);}function mr(_0x2ef08d,_0x26c06c){vs(_0x2ef08d,'connected',_0x26c06c),_0x26c06c===!0x1&&Sd(_0x2ef08d);}function Id(_0x2a20a3,_0x1e8eeb){x(_0x1e8eeb,(_0x42245f,_0x12438a)=>{vs(_0x2a20a3,_0x42245f,_0x12438a);});}function vs(_0xd88c54,_0x5dc7ed,_0x2f70b9){const _0x423ac8=new C('/.info/'+_0x5dc7ed),_0x5acc6c=A(_0x2f70b9);_0xd88c54['infoData_']['updateSnapshot'](_0x423ac8,_0x5acc6c);const _0x1a6f13=Yt(_0xd88c54['infoSyncTree_'],_0x423ac8,_0x5acc6c);V(_0xd88c54['eventQueue_'],_0x423ac8,_0x1a6f13);}function zn(_0x1f631b){return _0x1f631b['nextWriteId_']++;}function wd(_0x4ae966,_0x431487,_0x207a4c){const _0x41130a=Xu(_0x4ae966['serverSyncTree_'],_0x431487);return _0x41130a!=null?Promise['resolve'](_0x41130a):_0x4ae966['server_']['get'](_0x431487)['then'](_0x5e6615=>{const _0x4a8009=A(_0x5e6615)['withIndex'](_0x431487['_queryParams']['getIndex']());Ni(_0x4ae966['serverSyncTree_'],_0x431487,_0x207a4c,!0x0);let _0x103a37;if(_0x431487['_queryParams']['loadsAllData']())_0x103a37=Yt(_0x4ae966['serverSyncTree_'],_0x431487['_path'],_0x4a8009);else{const _0x515ccd=Wt(_0x4ae966['serverSyncTree_'],_0x431487);_0x103a37=Jo(_0x4ae966['serverSyncTree_'],_0x431487['_path'],_0x4a8009,_0x515ccd);}return V(_0x4ae966['eventQueue_'],_0x431487['_path'],_0x103a37),An(_0x4ae966['serverSyncTree_'],_0x431487,_0x207a4c,null,!0x0),_0x4a8009;},_0x3de61f=>(gt(_0x4ae966,'get\x20for\x20query\x20'+O(_0x431487)+'\x20failed:\x20'+_0x3de61f),Promise['reject'](new Error(_0x3de61f))));}function Cd(_0x513780,_0x30f129,_0x40e3e0,_0xcf4bfe,_0x1528f6){gt(_0x513780,'set',{'path':_0x30f129['toString'](),'value':_0x40e3e0,'priority':_0xcf4bfe});const _0x57aae2=Xt(_0x513780),_0xae5c26=A(_0x40e3e0,_0xcf4bfe),_0x1b47a7=Vn(_0x513780['serverSyncTree_'],_0x30f129),_0x50db6e=fs(_0xae5c26,_0x1b47a7,_0x57aae2),_0x438635=zn(_0x513780),_0x50ec97=as(_0x513780['serverSyncTree_'],_0x30f129,_0x50db6e,_0x438635,!0x0);qn(_0x513780['eventQueue_'],_0x50ec97),_0x513780['server_']['put'](_0x30f129['toString'](),_0xae5c26['val'](!0x0),(_0x591dae,_0x400164)=>{const _0x332d9b=_0x591dae==='ok';_0x332d9b||U('set\x20at\x20'+_0x30f129+'\x20failed:\x20'+_0x591dae);const _0x18830b=_e(_0x513780['serverSyncTree_'],_0x438635,!_0x332d9b);V(_0x513780['eventQueue_'],_0x30f129,_0x18830b),be(_0x513780,_0x1528f6,_0x591dae,_0x400164);});const _0x599922=Is(_0x513780,_0x30f129);ct(_0x513780,_0x599922),V(_0x513780['eventQueue_'],_0x599922,[]);}function Td(_0xc93833,_0x33c4e1,_0xcfd629,_0x250da3){gt(_0xc93833,'update',{'path':_0x33c4e1['toString'](),'value':_0xcfd629});let _0xe986ba=!0x0;const _0x811567=Xt(_0xc93833),_0x5f4401={};if(x(_0xcfd629,(_0x3af25e,_0x69e0d7)=>{_0xe986ba=!0x1,_0x5f4401[_0x3af25e]=ta(k(_0x33c4e1,_0x3af25e),A(_0x69e0d7),_0xc93833['serverSyncTree_'],_0x811567);}),_0xe986ba)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xc93833,_0x250da3,'ok',void 0x0);else{const _0x27c232=zn(_0xc93833),_0x16b3ba=ju(_0xc93833['serverSyncTree_'],_0x33c4e1,_0x5f4401,_0x27c232);qn(_0xc93833['eventQueue_'],_0x16b3ba),_0xc93833['server_']['merge'](_0x33c4e1['toString'](),_0xcfd629,(_0x4bfd33,_0x3b5de6)=>{const _0x1160fc=_0x4bfd33==='ok';_0x1160fc||U('update\x20at\x20'+_0x33c4e1+'\x20failed:\x20'+_0x4bfd33);const _0x569d39=_e(_0xc93833['serverSyncTree_'],_0x27c232,!_0x1160fc),_0x5b35cc=_0x569d39['length']>0x0?ct(_0xc93833,_0x33c4e1):_0x33c4e1;V(_0xc93833['eventQueue_'],_0x5b35cc,_0x569d39),be(_0xc93833,_0x250da3,_0x4bfd33,_0x3b5de6);}),x(_0xcfd629,_0x4053b5=>{const _0x13c070=Is(_0xc93833,k(_0x33c4e1,_0x4053b5));ct(_0xc93833,_0x13c070);}),V(_0xc93833['eventQueue_'],_0x33c4e1,[]);}}function Sd(_0x5c8b7e){gt(_0x5c8b7e,'onDisconnectEvents');const _0xb550fc=Xt(_0x5c8b7e),_0x173c05=En();Si(_0x5c8b7e['onDisconnect_'],w(),(_0x2dd078,_0x5923c1)=>{const _0x1d6188=ta(_0x2dd078,_0x5923c1,_0x5c8b7e['serverSyncTree_'],_0xb550fc);pt(_0x173c05,_0x2dd078,_0x1d6188);});let _0x232b2c=[];Si(_0x173c05,w(),(_0x5cad93,_0x3d11c1)=>{_0x232b2c=_0x232b2c['concat'](Yt(_0x5c8b7e['serverSyncTree_'],_0x5cad93,_0x3d11c1));const _0x2105f6=Is(_0x5c8b7e,_0x5cad93);ct(_0x5c8b7e,_0x2105f6);}),_0x5c8b7e['onDisconnect_']=En(),V(_0x5c8b7e['eventQueue_'],w(),_0x232b2c);}function bd(_0x1a407e,_0x203ed9,_0x41d024){_0x1a407e['server_']['onDisconnectCancel'](_0x203ed9['toString'](),(_0x3807e5,_0x582360)=>{_0x3807e5==='ok'&&Ti(_0x1a407e['onDisconnect_'],_0x203ed9),be(_0x1a407e,_0x41d024,_0x3807e5,_0x582360);});}function yr(_0x3b769f,_0x5ccada,_0x5d99e7,_0x122e55){const _0x1131a4=A(_0x5d99e7);_0x3b769f['server_']['onDisconnectPut'](_0x5ccada['toString'](),_0x1131a4['val'](!0x0),(_0x5c8c8b,_0x2a2b88)=>{_0x5c8c8b==='ok'&&pt(_0x3b769f['onDisconnect_'],_0x5ccada,_0x1131a4),be(_0x3b769f,_0x122e55,_0x5c8c8b,_0x2a2b88);});}function Rd(_0x3b1f0d,_0x4831b1,_0x230104,_0x307159,_0x47491f){const _0x2a9e43=A(_0x230104,_0x307159);_0x3b1f0d['server_']['onDisconnectPut'](_0x4831b1['toString'](),_0x2a9e43['val'](!0x0),(_0x524d37,_0x15b819)=>{_0x524d37==='ok'&&pt(_0x3b1f0d['onDisconnect_'],_0x4831b1,_0x2a9e43),be(_0x3b1f0d,_0x47491f,_0x524d37,_0x15b819);});}function Ad(_0x2ce4bd,_0x5c22bb,_0x157145,_0x2b137d){if(pn(_0x157145)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2ce4bd,_0x2b137d,'ok',void 0x0);return;}_0x2ce4bd['server_']['onDisconnectMerge'](_0x5c22bb['toString'](),_0x157145,(_0x394637,_0x504e7d)=>{_0x394637==='ok'&&x(_0x157145,(_0x34dfbc,_0x15b060)=>{const _0x411a3d=A(_0x15b060);pt(_0x2ce4bd['onDisconnect_'],k(_0x5c22bb,_0x34dfbc),_0x411a3d);}),be(_0x2ce4bd,_0x2b137d,_0x394637,_0x504e7d);});}function kd(_0x2710ca,_0x33445c,_0x4865fa){let _0x3887b4;y(_0x33445c['_path'])==='.info'?_0x3887b4=Ni(_0x2710ca['infoSyncTree_'],_0x33445c,_0x4865fa):_0x3887b4=Ni(_0x2710ca['serverSyncTree_'],_0x33445c,_0x4865fa),oa(_0x2710ca['eventQueue_'],_0x33445c['_path'],_0x3887b4);}function Pd(_0x53ea86,_0x7d1a8e,_0x5be5bf){let _0x1c4d56;y(_0x7d1a8e['_path'])==='.info'?_0x1c4d56=An(_0x53ea86['infoSyncTree_'],_0x7d1a8e,_0x5be5bf):_0x1c4d56=An(_0x53ea86['serverSyncTree_'],_0x7d1a8e,_0x5be5bf),oa(_0x53ea86['eventQueue_'],_0x7d1a8e['_path'],_0x1c4d56);}function ha(_0x398709){_0x398709['persistentConnection_']&&_0x398709['persistentConnection_']['interrupt'](ca);}function Nd(_0x5ddcf4){_0x5ddcf4['persistentConnection_']&&_0x5ddcf4['persistentConnection_']['resume'](ca);}function gt(_0x30f169,..._0x329ae4){let _0x18a2a5='';_0x30f169['persistentConnection_']&&(_0x18a2a5=_0x30f169['persistentConnection_']['id']+':'),L(_0x18a2a5,..._0x329ae4);}function be(_0x19eadc,_0x238fc0,_0xeeb93c,_0x3b862c){_0x238fc0&&ft(()=>{if(_0xeeb93c==='ok')_0x238fc0(null);else{const _0x2ab2f5=(_0xeeb93c||'error')['toUpperCase']();let _0x3baa19=_0x2ab2f5;_0x3b862c&&(_0x3baa19+=':\x20'+_0x3b862c);const _0x129621=new Error(_0x3baa19);_0x129621['code']=_0x2ab2f5,_0x238fc0(_0x129621);}});}function Od(_0x530572,_0x2f5685,_0x289813,_0x509ffd,_0x5381b0,_0x39bfe3){gt(_0x530572,'transaction\x20on\x20'+_0x2f5685);const _0x4204fb={'path':_0x2f5685,'update':_0x289813,'onComplete':_0x509ffd,'status':null,'order':so(),'applyLocally':_0x39bfe3,'retryCount':0x0,'unwatcher':_0x5381b0,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2040ce=Es(_0x530572,_0x2f5685,void 0x0);_0x4204fb['currentInputSnapshot']=_0x2040ce;const _0x5acc1b=_0x4204fb['update'](_0x2040ce['val']());if(_0x5acc1b===void 0x0)_0x4204fb['unwatcher'](),_0x4204fb['currentOutputSnapshotRaw']=null,_0x4204fb['currentOutputSnapshotResolved']=null,_0x4204fb['onComplete']&&_0x4204fb['onComplete'](null,!0x1,_0x4204fb['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5acc1b,_0x4204fb['path']),_0x4204fb['status']=0x0;const _0x4cfe3d=$n(_0x530572['transactionQueueTree_'],_0x2f5685),_0x5cfa8d=je(_0x4cfe3d)||[];_0x5cfa8d['push'](_0x4204fb),gs(_0x4cfe3d,_0x5cfa8d);let _0xce8c39;typeof _0x5acc1b=='object'&&_0x5acc1b!==null&&Q(_0x5acc1b,'.priority')?(_0xce8c39=Le(_0x5acc1b,'.priority'),f(Bt(_0xce8c39),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xce8c39=(Vn(_0x530572['serverSyncTree_'],_0x2f5685)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xc1a88f=Xt(_0x530572),_0x250d76=A(_0x5acc1b,_0xce8c39),_0x45164d=fs(_0x250d76,_0x2040ce,_0xc1a88f);_0x4204fb['currentOutputSnapshotRaw']=_0x250d76,_0x4204fb['currentOutputSnapshotResolved']=_0x45164d,_0x4204fb['currentWriteId']=zn(_0x530572);const _0x2fed9f=as(_0x530572['serverSyncTree_'],_0x2f5685,_0x45164d,_0x4204fb['currentWriteId'],_0x4204fb['applyLocally']);V(_0x530572['eventQueue_'],_0x2f5685,_0x2fed9f),jn(_0x530572,_0x530572['transactionQueueTree_']);}}function Es(_0x166041,_0x5bb077,_0x2badf6){return Vn(_0x166041['serverSyncTree_'],_0x5bb077,_0x2badf6)||g['EMPTY_NODE'];}function jn(_0x584dd7,_0x294bb0=_0x584dd7['transactionQueueTree_']){if(_0x294bb0||Kn(_0x584dd7,_0x294bb0),je(_0x294bb0)){const _0x304e81=da(_0x584dd7,_0x294bb0);f(_0x304e81['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x304e81['every'](_0x3f562a=>_0x3f562a['status']===0x0)&&Dd(_0x584dd7,Qt(_0x294bb0),_0x304e81);}else na(_0x294bb0)&&Gn(_0x294bb0,_0x1a724e=>{jn(_0x584dd7,_0x1a724e);});}function Dd(_0x223082,_0x2dd948,_0x227426){const _0x34bea2=_0x227426['map'](_0x55fce3=>_0x55fce3['currentWriteId']),_0x43668a=Es(_0x223082,_0x2dd948,_0x34bea2);let _0x556ab3=_0x43668a;const _0x3beab1=_0x43668a['hash']();for(let _0x33ee95=0x0;_0x33ee95<_0x227426['length'];_0x33ee95++){const _0x4173a3=_0x227426[_0x33ee95];f(_0x4173a3['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4173a3['status']=0x1,_0x4173a3['retryCount']++;const _0x4b01ec=F(_0x2dd948,_0x4173a3['path']);_0x556ab3=_0x556ab3['updateChild'](_0x4b01ec,_0x4173a3['currentOutputSnapshotRaw']);}const _0x2e8e74=_0x556ab3['val'](!0x0),_0x2321b6=_0x2dd948;_0x223082['server_']['put'](_0x2321b6['toString'](),_0x2e8e74,_0x882037=>{gt(_0x223082,'transaction\x20put\x20response',{'path':_0x2321b6['toString'](),'status':_0x882037});let _0x436647=[];if(_0x882037==='ok'){const _0x4f2576=[];for(let _0x4ad56e=0x0;_0x4ad56e<_0x227426['length'];_0x4ad56e++)_0x227426[_0x4ad56e]['status']=0x2,_0x436647=_0x436647['concat'](_e(_0x223082['serverSyncTree_'],_0x227426[_0x4ad56e]['currentWriteId'])),_0x227426[_0x4ad56e]['onComplete']&&_0x4f2576['push'](()=>_0x227426[_0x4ad56e]['onComplete'](null,!0x0,_0x227426[_0x4ad56e]['currentOutputSnapshotResolved'])),_0x227426[_0x4ad56e]['unwatcher']();Kn(_0x223082,$n(_0x223082['transactionQueueTree_'],_0x2dd948)),jn(_0x223082,_0x223082['transactionQueueTree_']),V(_0x223082['eventQueue_'],_0x2dd948,_0x436647);for(let _0x55f40f=0x0;_0x55f40f<_0x4f2576['length'];_0x55f40f++)ft(_0x4f2576[_0x55f40f]);}else{if(_0x882037==='datastale'){for(let _0x2b101a=0x0;_0x2b101a<_0x227426['length'];_0x2b101a++)_0x227426[_0x2b101a]['status']===0x3?_0x227426[_0x2b101a]['status']=0x4:_0x227426[_0x2b101a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2321b6['toString']()+'\x20failed:\x20'+_0x882037);for(let _0x561b2e=0x0;_0x561b2e<_0x227426['length'];_0x561b2e++)_0x227426[_0x561b2e]['status']=0x4,_0x227426[_0x561b2e]['abortReason']=_0x882037;}ct(_0x223082,_0x2dd948);}},_0x3beab1);}function ct(_0x6803d5,_0x38eb8f){const _0xcc47ec=ua(_0x6803d5,_0x38eb8f),_0x1aa751=Qt(_0xcc47ec),_0x512505=da(_0x6803d5,_0xcc47ec);return Md(_0x6803d5,_0x512505,_0x1aa751),_0x1aa751;}function Md(_0x319bb2,_0x24357c,_0x3f43c0){if(_0x24357c['length']===0x0)return;const _0x42c4b1=[];let _0x7878d0=[];const _0x2c45fd=_0x24357c['filter'](_0x255736=>_0x255736['status']===0x0)['map'](_0x315369=>_0x315369['currentWriteId']);for(let _0x500dde=0x0;_0x500dde<_0x24357c['length'];_0x500dde++){const _0x2e3cbd=_0x24357c[_0x500dde],_0x81f753=F(_0x3f43c0,_0x2e3cbd['path']);let _0x204d22=!0x1,_0xadc03a;if(f(_0x81f753!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2e3cbd['status']===0x4)_0x204d22=!0x0,_0xadc03a=_0x2e3cbd['abortReason'],_0x7878d0=_0x7878d0['concat'](_e(_0x319bb2['serverSyncTree_'],_0x2e3cbd['currentWriteId'],!0x0));else{if(_0x2e3cbd['status']===0x0){if(_0x2e3cbd['retryCount']>=yd)_0x204d22=!0x0,_0xadc03a='maxretry',_0x7878d0=_0x7878d0['concat'](_e(_0x319bb2['serverSyncTree_'],_0x2e3cbd['currentWriteId'],!0x0));else{const _0x53a1e8=Es(_0x319bb2,_0x2e3cbd['path'],_0x2c45fd);_0x2e3cbd['currentInputSnapshot']=_0x53a1e8;const _0x5c3c13=_0x24357c[_0x500dde]['update'](_0x53a1e8['val']());if(_0x5c3c13!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5c3c13,_0x2e3cbd['path']);let _0x26bd01=A(_0x5c3c13);typeof _0x5c3c13=='object'&&_0x5c3c13!=null&&Q(_0x5c3c13,'.priority')||(_0x26bd01=_0x26bd01['updatePriority'](_0x53a1e8['getPriority']()));const _0x5c3d9b=_0x2e3cbd['currentWriteId'],_0x2fa2df=Xt(_0x319bb2),_0x431357=fs(_0x26bd01,_0x53a1e8,_0x2fa2df);_0x2e3cbd['currentOutputSnapshotRaw']=_0x26bd01,_0x2e3cbd['currentOutputSnapshotResolved']=_0x431357,_0x2e3cbd['currentWriteId']=zn(_0x319bb2),_0x2c45fd['splice'](_0x2c45fd['indexOf'](_0x5c3d9b),0x1),_0x7878d0=_0x7878d0['concat'](as(_0x319bb2['serverSyncTree_'],_0x2e3cbd['path'],_0x431357,_0x2e3cbd['currentWriteId'],_0x2e3cbd['applyLocally'])),_0x7878d0=_0x7878d0['concat'](_e(_0x319bb2['serverSyncTree_'],_0x5c3d9b,!0x0));}else _0x204d22=!0x0,_0xadc03a='nodata',_0x7878d0=_0x7878d0['concat'](_e(_0x319bb2['serverSyncTree_'],_0x2e3cbd['currentWriteId'],!0x0));}}}V(_0x319bb2['eventQueue_'],_0x3f43c0,_0x7878d0),_0x7878d0=[],_0x204d22&&(_0x24357c[_0x500dde]['status']=0x2,function(_0x31cbb4){setTimeout(_0x31cbb4,Math['floor'](0x0));}(_0x24357c[_0x500dde]['unwatcher']),_0x24357c[_0x500dde]['onComplete']&&(_0xadc03a==='nodata'?_0x42c4b1['push'](()=>_0x24357c[_0x500dde]['onComplete'](null,!0x1,_0x24357c[_0x500dde]['currentInputSnapshot'])):_0x42c4b1['push'](()=>_0x24357c[_0x500dde]['onComplete'](new Error(_0xadc03a),!0x1,null))));}Kn(_0x319bb2,_0x319bb2['transactionQueueTree_']);for(let _0x4b29fb=0x0;_0x4b29fb<_0x42c4b1['length'];_0x4b29fb++)ft(_0x42c4b1[_0x4b29fb]);jn(_0x319bb2,_0x319bb2['transactionQueueTree_']);}function ua(_0x1f4f43,_0x5019b1){let _0x2b19e1,_0x335854=_0x1f4f43['transactionQueueTree_'];for(_0x2b19e1=y(_0x5019b1);_0x2b19e1!==null&&je(_0x335854)===void 0x0;)_0x335854=$n(_0x335854,_0x2b19e1),_0x5019b1=S(_0x5019b1),_0x2b19e1=y(_0x5019b1);return _0x335854;}function da(_0x4ffcce,_0x10298f){const _0x3ca9ac=[];return fa(_0x4ffcce,_0x10298f,_0x3ca9ac),_0x3ca9ac['sort']((_0xe86f40,_0xbc2e1b)=>_0xe86f40['order']-_0xbc2e1b['order']),_0x3ca9ac;}function fa(_0x3e5488,_0xc00661,_0x46f09d){const _0x2312d6=je(_0xc00661);if(_0x2312d6){for(let _0x66f48b=0x0;_0x66f48b<_0x2312d6['length'];_0x66f48b++)_0x46f09d['push'](_0x2312d6[_0x66f48b]);}Gn(_0xc00661,_0x587032=>{fa(_0x3e5488,_0x587032,_0x46f09d);});}function Kn(_0xd1c9d9,_0x1cd0f5){const _0x4b9b37=je(_0x1cd0f5);if(_0x4b9b37){let _0x5386cb=0x0;for(let _0x3ec24e=0x0;_0x3ec24e<_0x4b9b37['length'];_0x3ec24e++)_0x4b9b37[_0x3ec24e]['status']!==0x2&&(_0x4b9b37[_0x5386cb]=_0x4b9b37[_0x3ec24e],_0x5386cb++);_0x4b9b37['length']=_0x5386cb,gs(_0x1cd0f5,_0x4b9b37['length']>0x0?_0x4b9b37:void 0x0);}Gn(_0x1cd0f5,_0x1e33d7=>{Kn(_0xd1c9d9,_0x1e33d7);});}function Is(_0x58e374,_0x1d6e20){const _0x38a2ae=Qt(ua(_0x58e374,_0x1d6e20)),_0x4abaef=$n(_0x58e374['transactionQueueTree_'],_0x1d6e20);return ad(_0x4abaef,_0x23c0ac=>{di(_0x58e374,_0x23c0ac);}),di(_0x58e374,_0x4abaef),ia(_0x4abaef,_0x3d4d32=>{di(_0x58e374,_0x3d4d32);}),_0x38a2ae;}function di(_0x304c1d,_0x2a8554){const _0x9fda7d=je(_0x2a8554);if(_0x9fda7d){const _0x5cce96=[];let _0x215b49=[],_0x2274e9=-0x1;for(let _0x57e113=0x0;_0x57e113<_0x9fda7d['length'];_0x57e113++)_0x9fda7d[_0x57e113]['status']===0x3||(_0x9fda7d[_0x57e113]['status']===0x1?(f(_0x2274e9===_0x57e113-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2274e9=_0x57e113,_0x9fda7d[_0x57e113]['status']=0x3,_0x9fda7d[_0x57e113]['abortReason']='set'):(f(_0x9fda7d[_0x57e113]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x9fda7d[_0x57e113]['unwatcher'](),_0x215b49=_0x215b49['concat'](_e(_0x304c1d['serverSyncTree_'],_0x9fda7d[_0x57e113]['currentWriteId'],!0x0)),_0x9fda7d[_0x57e113]['onComplete']&&_0x5cce96['push'](_0x9fda7d[_0x57e113]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2274e9===-0x1?gs(_0x2a8554,void 0x0):_0x9fda7d['length']=_0x2274e9+0x1,V(_0x304c1d['eventQueue_'],Qt(_0x2a8554),_0x215b49);for(let _0xe8a866=0x0;_0xe8a866<_0x5cce96['length'];_0xe8a866++)ft(_0x5cce96[_0xe8a866]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4e5c16){let _0x1bf32a='';const _0x52c351=_0x4e5c16['split']('/');for(let _0x31daca=0x0;_0x31daca<_0x52c351['length'];_0x31daca++)if(_0x52c351[_0x31daca]['length']>0x0){let _0x21a00a=_0x52c351[_0x31daca];try{_0x21a00a=decodeURIComponent(_0x21a00a['replace'](/\+/g,'\x20'));}catch{}_0x1bf32a+='/'+_0x21a00a;}return _0x1bf32a;}function xd(_0x3dd215){const _0x4f78e1={};_0x3dd215['charAt'](0x0)==='?'&&(_0x3dd215=_0x3dd215['substring'](0x1));for(const _0x1fc9b8 of _0x3dd215['split']('&')){if(_0x1fc9b8['length']===0x0)continue;const _0x40ce4c=_0x1fc9b8['split']('=');_0x40ce4c['length']===0x2?_0x4f78e1[decodeURIComponent(_0x40ce4c[0x0])]=decodeURIComponent(_0x40ce4c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1fc9b8+'\x27\x20in\x20query\x20\x27'+_0x3dd215+'\x27');}return _0x4f78e1;}const vr=function(_0x403368,_0x3fcb74){const _0x9f8c31=Fd(_0x403368),_0x7e0941=_0x9f8c31['namespace'];_0x9f8c31['domain']==='firebase.com'&&ae(_0x9f8c31['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x7e0941||_0x7e0941==='undefined')&&_0x9f8c31['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x9f8c31['secure']||$l();const _0x169b2e=_0x9f8c31['scheme']==='ws'||_0x9f8c31['scheme']==='wss';return{'repoInfo':new yo(_0x9f8c31['host'],_0x9f8c31['secure'],_0x7e0941,_0x169b2e,_0x3fcb74,'',_0x7e0941!==_0x9f8c31['subdomain']),'path':new C(_0x9f8c31['pathString'])};},Fd=function(_0x3c7dab){let _0x545583='',_0x2417be='',_0x2f30c2='',_0x35b21f='',_0x4fab82='',_0x3cbb1f=!0x0,_0x1f29e2='https',_0x557e1f=0x1bb;if(typeof _0x3c7dab=='string'){let _0x3dc39c=_0x3c7dab['indexOf']('//');_0x3dc39c>=0x0&&(_0x1f29e2=_0x3c7dab['substring'](0x0,_0x3dc39c-0x1),_0x3c7dab=_0x3c7dab['substring'](_0x3dc39c+0x2));let _0x294c81=_0x3c7dab['indexOf']('/');_0x294c81===-0x1&&(_0x294c81=_0x3c7dab['length']);let _0x4bc9eb=_0x3c7dab['indexOf']('?');_0x4bc9eb===-0x1&&(_0x4bc9eb=_0x3c7dab['length']),_0x545583=_0x3c7dab['substring'](0x0,Math['min'](_0x294c81,_0x4bc9eb)),_0x294c81<_0x4bc9eb&&(_0x35b21f=Ld(_0x3c7dab['substring'](_0x294c81,_0x4bc9eb)));const _0x17b8b5=xd(_0x3c7dab['substring'](Math['min'](_0x3c7dab['length'],_0x4bc9eb)));_0x3dc39c=_0x545583['indexOf'](':'),_0x3dc39c>=0x0?(_0x3cbb1f=_0x1f29e2==='https'||_0x1f29e2==='wss',_0x557e1f=parseInt(_0x545583['substring'](_0x3dc39c+0x1),0xa)):_0x3dc39c=_0x545583['length'];const _0x4d843b=_0x545583['slice'](0x0,_0x3dc39c);if(_0x4d843b['toLowerCase']()==='localhost')_0x2417be='localhost';else{if(_0x4d843b['split']('.')['length']<=0x2)_0x2417be=_0x4d843b;else{const _0x56fbe1=_0x545583['indexOf']('.');_0x2f30c2=_0x545583['substring'](0x0,_0x56fbe1)['toLowerCase'](),_0x2417be=_0x545583['substring'](_0x56fbe1+0x1),_0x4fab82=_0x2f30c2;}}'ns'in _0x17b8b5&&(_0x4fab82=_0x17b8b5['ns']);}return{'host':_0x545583,'port':_0x557e1f,'domain':_0x2417be,'subdomain':_0x2f30c2,'secure':_0x3cbb1f,'scheme':_0x1f29e2,'pathString':_0x35b21f,'namespace':_0x4fab82};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x401784=0x0;const _0x22eee9=[];return function(_0x150189){const _0x520543=_0x150189===_0x401784;_0x401784=_0x150189;let _0x4fd893;const _0x26757f=new Array(0x8);for(_0x4fd893=0x7;_0x4fd893>=0x0;_0x4fd893--)_0x26757f[_0x4fd893]=Er['charAt'](_0x150189%0x40),_0x150189=Math['floor'](_0x150189/0x40);f(_0x150189===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x33afe5=_0x26757f['join']('');if(_0x520543){for(_0x4fd893=0xb;_0x4fd893>=0x0&&_0x22eee9[_0x4fd893]===0x3f;_0x4fd893--)_0x22eee9[_0x4fd893]=0x0;_0x22eee9[_0x4fd893]++;}else{for(_0x4fd893=0x0;_0x4fd893<0xc;_0x4fd893++)_0x22eee9[_0x4fd893]=Math['floor'](Math['random']()*0x40);}for(_0x4fd893=0x0;_0x4fd893<0xc;_0x4fd893++)_0x33afe5+=Er['charAt'](_0x22eee9[_0x4fd893]);return f(_0x33afe5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x33afe5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x35451e,_0x6085cf,_0x4d5090,_0x1f87d1){this['eventType']=_0x35451e,this['eventRegistration']=_0x6085cf,this['snapshot']=_0x4d5090,this['prevName']=_0x1f87d1;}['getPath'](){const _0x347cb1=this['snapshot']['ref'];return this['eventType']==='value'?_0x347cb1['_path']:_0x347cb1['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x51c6ee,_0xe21a2,_0x3c7078){this['eventRegistration']=_0x51c6ee,this['error']=_0xe21a2,this['path']=_0x3c7078;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x38d5f6,_0x43a236){this['snapshotCallback']=_0x38d5f6,this['cancelCallback']=_0x43a236;}['onValue'](_0x542694,_0x1c2d47){this['snapshotCallback']['call'](null,_0x542694,_0x1c2d47);}['onCancel'](_0x49b0a0){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x49b0a0);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4815b0){return this['snapshotCallback']===_0x4815b0['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4815b0['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4815b0['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x444546,_0x536673){this['_repo']=_0x444546,this['_path']=_0x536673;}['cancel'](){const _0x5587c7=new H();return bd(this['_repo'],this['_path'],_0x5587c7['wrapCallback'](()=>{})),_0x5587c7['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x15b6d0=new H();return yr(this['_repo'],this['_path'],null,_0x15b6d0['wrapCallback'](()=>{})),_0x15b6d0['promise'];}['set'](_0x701e95){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x701e95,this['_path'],!0x1);const _0x1954a0=new H();return yr(this['_repo'],this['_path'],_0x701e95,_0x1954a0['wrapCallback'](()=>{})),_0x1954a0['promise'];}['setWithPriority'](_0x23dfbd,_0x2694ad){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x23dfbd,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x2694ad);const _0xacd81a=new H();return Rd(this['_repo'],this['_path'],_0x23dfbd,_0x2694ad,_0xacd81a['wrapCallback'](()=>{})),_0xacd81a['promise'];}['update'](_0x581a51){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x581a51,this['_path']);const _0x4c8f0c=new H();return Ad(this['_repo'],this['_path'],_0x581a51,_0x4c8f0c['wrapCallback'](()=>{})),_0x4c8f0c['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x5313ec,_0x33a740,_0x2f60d4,_0x1601b9){this['_repo']=_0x5313ec,this['_path']=_0x33a740,this['_queryParams']=_0x2f60d4,this['_orderByCalled']=_0x1601b9;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2343be=sr(this['_queryParams']),_0x12dd9c=$i(_0x2343be);return _0x12dd9c==='{}'?'default':_0x12dd9c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2cd40e){if(_0x2cd40e=P(_0x2cd40e),!(_0x2cd40e instanceof Ae))return!0x1;const _0x4ebff8=this['_repo']===_0x2cd40e['_repo'],_0x247437=Ki(this['_path'],_0x2cd40e['_path']),_0x38097c=this['_queryIdentifier']===_0x2cd40e['_queryIdentifier'];return _0x4ebff8&&_0x247437&&_0x38097c;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x598be1,_0x112fcb){if(_0x598be1['_orderByCalled']===!0x0)throw new Error(_0x112fcb+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x19cf10){let _0x3238df=null,_0x442508=null;if(_0x19cf10['hasStart']()&&(_0x3238df=_0x19cf10['getIndexStartValue']()),_0x19cf10['hasEnd']()&&(_0x442508=_0x19cf10['getIndexEndValue']()),_0x19cf10['getIndex']()===ve){const _0x3943e2='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3fad12='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x19cf10['hasStart']()){if(_0x19cf10['getIndexStartName']()!==We)throw new Error(_0x3943e2);if(typeof _0x3238df!='string')throw new Error(_0x3fad12);}if(_0x19cf10['hasEnd']()){if(_0x19cf10['getIndexEndName']()!==we)throw new Error(_0x3943e2);if(typeof _0x442508!='string')throw new Error(_0x3fad12);}}else{if(_0x19cf10['getIndex']()===R){if(_0x3238df!=null&&!Bt(_0x3238df)||_0x442508!=null&&!Bt(_0x442508))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x19cf10['getIndex']()instanceof Ji||_0x19cf10['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3238df!=null&&typeof _0x3238df=='object'||_0x442508!=null&&typeof _0x442508=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x5d2c13){if(_0x5d2c13['hasStart']()&&_0x5d2c13['hasEnd']()&&_0x5d2c13['hasLimit']()&&!_0x5d2c13['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x284b85,_0x8a67d4){super(_0x284b85,_0x8a67d4,new Zi(),!0x1);}get['parent'](){const _0x449741=Ro(this['_path']);return _0x449741===null?null:new ee(this['_repo'],_0x449741);}get['root'](){let _0x3d54f4=this;for(;_0x3d54f4['parent']!==null;)_0x3d54f4=_0x3d54f4['parent'];return _0x3d54f4;}}class lt{constructor(_0xa8838c,_0x3d5489,_0x4cb95d){this['_node']=_0xa8838c,this['ref']=_0x3d5489,this['_index']=_0x4cb95d;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x71424f){const _0xdaa9cf=new C(_0x71424f),_0x1fd7ca=Vt(this['ref'],_0x71424f);return new lt(this['_node']['getChild'](_0xdaa9cf),_0x1fd7ca,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5d43db){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4ec45f,_0x377467)=>_0x5d43db(new lt(_0x377467,Vt(this['ref'],_0x4ec45f),R)));}['hasChild'](_0x4fa378){const _0x18bdab=new C(_0x4fa378);return!this['_node']['getChild'](_0x18bdab)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x2743e9,_0x4ac540){return _0x2743e9=P(_0x2743e9),_0x2743e9['_checkNotDeleted']('ref'),_0x4ac540!==void 0x0?Vt(_0x2743e9['_root'],_0x4ac540):_0x2743e9['_root'];}function Vt(_0x65ab71,_0x212602){return _0x65ab71=P(_0x65ab71),y(_0x65ab71['_path'])===null?pd('child','path',_0x212602):ys('child','path',_0x212602),new ee(_0x65ab71['_repo'],k(_0x65ab71['_path'],_0x212602));}function v_(_0x2bdeba){return _0x2bdeba=P(_0x2bdeba),new Vd(_0x2bdeba['_repo'],_0x2bdeba['_path']);}function E_(_0x591120,_0x1bb7ca){_0x591120=P(_0x591120),Me('push',_0x591120['_path']),He('push',_0x1bb7ca,_0x591120['_path'],!0x0);const _0x38aea3=la(_0x591120['_repo']),_0x3b74d4=Ud(_0x38aea3),_0x242f7b=Vt(_0x591120,_0x3b74d4),_0x11f836=Vt(_0x591120,_0x3b74d4);let _0x103ff2;return _0x1bb7ca!=null?_0x103ff2=Hd(_0x11f836,_0x1bb7ca)['then'](()=>_0x11f836):_0x103ff2=Promise['resolve'](_0x11f836),_0x242f7b['then']=_0x103ff2['then']['bind'](_0x103ff2),_0x242f7b['catch']=_0x103ff2['then']['bind'](_0x103ff2,void 0x0),_0x242f7b;}function Hd(_0x1fe251,_0x23f0b9){_0x1fe251=P(_0x1fe251),Me('set',_0x1fe251['_path']),He('set',_0x23f0b9,_0x1fe251['_path'],!0x1);const _0x14e6eb=new H();return Cd(_0x1fe251['_repo'],_0x1fe251['_path'],_0x23f0b9,null,_0x14e6eb['wrapCallback'](()=>{})),_0x14e6eb['promise'];}function I_(_0x10116f,_0x449788){ra('update',_0x449788,_0x10116f['_path']);const _0xd25460=new H();return Td(_0x10116f['_repo'],_0x10116f['_path'],_0x449788,_0xd25460['wrapCallback'](()=>{})),_0xd25460['promise'];}function w_(_0x22fb79){_0x22fb79=P(_0x22fb79);const _0x9f70ef=new pa(()=>{}),_0x5588f3=new Qn(_0x9f70ef);return wd(_0x22fb79['_repo'],_0x22fb79,_0x5588f3)['then'](_0x520f63=>new lt(_0x520f63,new ee(_0x22fb79['_repo'],_0x22fb79['_path']),_0x22fb79['_queryParams']['getIndex']()));}class Qn{constructor(_0x41480c){this['callbackContext']=_0x41480c;}['respondsTo'](_0x3073ae){return _0x3073ae==='value';}['createEvent'](_0x4bd30f,_0x1c4b51){const _0x4bcd2d=_0x1c4b51['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4bd30f['snapshotNode'],new ee(_0x1c4b51['_repo'],_0x1c4b51['_path']),_0x4bcd2d));}['getEventRunner'](_0x3bc67c){return _0x3bc67c['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3bc67c['error']):()=>this['callbackContext']['onValue'](_0x3bc67c['snapshot'],null);}['createCancelEvent'](_0x2f74f6,_0x122ab8){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x2f74f6,_0x122ab8):null;}['matches'](_0x415afc){return _0x415afc instanceof Qn?!_0x415afc['callbackContext']||!this['callbackContext']?!0x0:_0x415afc['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x590797,_0x39f989,_0x212323,_0x27ff01,_0x11ae93){const _0x456b16=new pa(_0x212323,void 0x0),_0x23d186=new Qn(_0x456b16);return kd(_0x590797['_repo'],_0x590797,_0x23d186),()=>Pd(_0x590797['_repo'],_0x590797,_0x23d186);}function Gd(_0x26eb31,_0x47f595,_0x5ca8e8,_0x283044){return $d(_0x26eb31,'value',_0x47f595);}class mt{}class ma extends mt{constructor(_0x12793a,_0x2a7072){super(),this['_value']=_0x12793a,this['_key']=_0x2a7072,this['type']='endAt';}['_apply'](_0x345178){He('endAt',this['_value'],_0x345178['_path'],!0x0);const _0x5bc156=Jh(_0x345178['_queryParams'],this['_value'],this['_key']);if(ga(_0x5bc156),Yn(_0x5bc156),_0x345178['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x345178['_repo'],_0x345178['_path'],_0x5bc156,_0x345178['_orderByCalled']);}}function C_(_0x3e6072,_0x390778){return new ma(_0x3e6072,_0x390778);}class ya extends mt{constructor(_0x1bd768,_0x1afb54){super(),this['_value']=_0x1bd768,this['_key']=_0x1afb54,this['type']='startAt';}['_apply'](_0x18605b){He('startAt',this['_value'],_0x18605b['_path'],!0x0);const _0x136131=Qh(_0x18605b['_queryParams'],this['_value'],this['_key']);if(ga(_0x136131),Yn(_0x136131),_0x18605b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x18605b['_repo'],_0x18605b['_path'],_0x136131,_0x18605b['_orderByCalled']);}}function T_(_0x14613a=null,_0x2a86eb){return new ya(_0x14613a,_0x2a86eb);}class qd extends mt{constructor(_0x56db8b){super(),this['_limit']=_0x56db8b,this['type']='limitToFirst';}['_apply'](_0x25bc07){if(_0x25bc07['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x25bc07['_repo'],_0x25bc07['_path'],Yh(_0x25bc07['_queryParams'],this['_limit']),_0x25bc07['_orderByCalled']);}}function S_(_0x26998d){if(Math['floor'](_0x26998d)!==_0x26998d||_0x26998d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x26998d);}class zd extends mt{constructor(_0x25a2d1){super(),this['_path']=_0x25a2d1,this['type']='orderByChild';}['_apply'](_0x4f0848){_a(_0x4f0848,'orderByChild');const _0x514abc=new C(this['_path']);if(v(_0x514abc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5b3018=new Ji(_0x514abc),_0x1232ff=xo(_0x4f0848['_queryParams'],_0x5b3018);return Yn(_0x1232ff),new Ae(_0x4f0848['_repo'],_0x4f0848['_path'],_0x1232ff,!0x0);}}function b_(_0x4c682e){if(_0x4c682e==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4c682e==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4c682e==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x4c682e),new zd(_0x4c682e);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2453c9){_a(_0x2453c9,'orderByKey');const _0x327a6d=xo(_0x2453c9['_queryParams'],ve);return Yn(_0x327a6d),new Ae(_0x2453c9['_repo'],_0x2453c9['_path'],_0x327a6d,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x229205,_0x1c5366){super(),this['_value']=_0x229205,this['_key']=_0x1c5366,this['type']='equalTo';}['_apply'](_0x3de2e7){if(He('equalTo',this['_value'],_0x3de2e7['_path'],!0x1),_0x3de2e7['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3de2e7['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3de2e7));}}function A_(_0x2955ed,_0x5a3314){return new Kd(_0x2955ed,_0x5a3314);}function k_(_0x57ab6a,..._0x2d4a7e){let _0x16099b=P(_0x57ab6a);for(const _0x1b56b4 of _0x2d4a7e)_0x16099b=_0x1b56b4['_apply'](_0x16099b);return _0x16099b;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1dd84e,_0x4fc752,_0x233ce7,_0x380bc6){const _0x198bca=_0x4fc752['lastIndexOf'](':'),_0x2abc27=_0x4fc752['substring'](0x0,_0x198bca),_0x12b8b1=qt(_0x2abc27);_0x1dd84e['repoInfo_']=new yo(_0x4fc752,_0x12b8b1,_0x1dd84e['repoInfo_']['namespace'],_0x1dd84e['repoInfo_']['webSocketOnly'],_0x1dd84e['repoInfo_']['nodeAdmin'],_0x1dd84e['repoInfo_']['persistenceKey'],_0x1dd84e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x233ce7),_0x380bc6&&(_0x1dd84e['authTokenProvider_']=_0x380bc6);}function Xd(_0x39f3ad,_0x5eb119,_0x1799e5,_0x3250e5,_0x46e487){let _0x6d87db=_0x3250e5||_0x39f3ad['options']['databaseURL'];_0x6d87db===void 0x0&&(_0x39f3ad['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x39f3ad['options']['projectId']),_0x6d87db=_0x39f3ad['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x408538=vr(_0x6d87db,_0x46e487),_0x4aef45=_0x408538['repoInfo'],_0x1fc113;typeof process<'u'&&Bs&&(_0x1fc113=Bs[Yd]),_0x1fc113?(_0x6d87db='http://'+_0x1fc113+'?ns='+_0x4aef45['namespace'],_0x408538=vr(_0x6d87db,_0x46e487),_0x4aef45=_0x408538['repoInfo']):_0x408538['repoInfo']['secure'];const _0x3c633e=new eh(_0x39f3ad['name'],_0x39f3ad['options'],_0x5eb119);_d('Invalid\x20Firebase\x20Database\x20URL',_0x408538),v(_0x408538['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2fae18=ef(_0x4aef45,_0x39f3ad,_0x3c633e,new Zl(_0x39f3ad,_0x1799e5));return new tf(_0x2fae18,_0x39f3ad);}function Zd(_0x427f14,_0x49f9ed){const _0x4a6ef5=Di[_0x49f9ed];(!_0x4a6ef5||_0x4a6ef5[_0x427f14['key']]!==_0x427f14)&&ae('Database\x20'+_0x49f9ed+'('+_0x427f14['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x427f14),delete _0x4a6ef5[_0x427f14['key']];}function ef(_0x106d71,_0x469fc6,_0x1dc987,_0xe5133e){let _0x38b78f=Di[_0x469fc6['name']];_0x38b78f||(_0x38b78f={},Di[_0x469fc6['name']]=_0x38b78f);let _0x37e6db=_0x38b78f[_0x106d71['toURLString']()];return _0x37e6db&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x37e6db=new vd(_0x106d71,Qd,_0x1dc987,_0xe5133e),_0x38b78f[_0x106d71['toURLString']()]=_0x37e6db,_0x37e6db;}class tf{constructor(_0x36c0bc,_0x2606ca){this['_repoInternal']=_0x36c0bc,this['app']=_0x2606ca,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x375a66){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x375a66+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x115089=Zr(),_0x44eda0){const _0x3a3bc4=Hi(_0x115089,'database')['getImmediate']({'identifier':_0x44eda0});if(!_0x3a3bc4['_instanceStarted']){const _0x175ce6=hc('database');_0x175ce6&&nf(_0x3a3bc4,..._0x175ce6);}return _0x3a3bc4;}function nf(_0x33b54a,_0x61bc13,_0x33eb23,_0x262520={}){_0x33b54a=P(_0x33b54a),_0x33b54a['_checkNotDeleted']('useEmulator');const _0x35974f=_0x61bc13+':'+_0x33eb23,_0x1b9ce8=_0x33b54a['_repoInternal'];if(_0x33b54a['_instanceStarted']){if(_0x35974f===_0x33b54a['_repoInternal']['repoInfo_']['host']&&xe(_0x262520,_0x1b9ce8['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4955ec;if(_0x1b9ce8['repoInfo_']['nodeAdmin'])_0x262520['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4955ec=new an(an['OWNER']);else{if(_0x262520['mockUserToken']){const _0x519f31=typeof _0x262520['mockUserToken']=='string'?_0x262520['mockUserToken']:uc(_0x262520['mockUserToken'],_0x33b54a['app']['options']['projectId']);_0x4955ec=new an(_0x519f31);}}qt(_0x61bc13)&&Qr(_0x61bc13),Jd(_0x1b9ce8,_0x35974f,_0x262520,_0x4955ec);}function N_(_0x46e227){_0x46e227=P(_0x46e227),_0x46e227['_checkNotDeleted']('goOffline'),ha(_0x46e227['_repo']);}function O_(_0x467fde){_0x467fde=P(_0x467fde),_0x467fde['_checkNotDeleted']('goOnline'),Nd(_0x467fde['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x37315d){Ul(dt),st(new Fe('database',(_0x230993,{instanceIdentifier:_0x3ee2e1})=>{const _0x5cc74d=_0x230993['getProvider']('app')['getImmediate'](),_0x3e5b94=_0x230993['getProvider']('auth-internal'),_0x2a6f42=_0x230993['getProvider']('app-check-internal');return Xd(_0x5cc74d,_0x3e5b94,_0x2a6f42,_0x3ee2e1);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x37315d),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x2e8c08,_0x35de3f){this['committed']=_0x2e8c08,this['snapshot']=_0x35de3f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x250937,_0x542c2a,_0x61f011){if(_0x250937=P(_0x250937),Me('Reference.transaction',_0x250937['_path']),_0x250937['key']==='.length'||_0x250937['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x250937['key']+'\x20is\x20a\x20read-only\x20object.';const _0x27adbc=!0x0,_0x38181e=new H(),_0x21a599=(_0x8aa418,_0x3205b4,_0x4f20cb)=>{let _0x34c38a=null;_0x8aa418?_0x38181e['reject'](_0x8aa418):(_0x34c38a=new lt(_0x4f20cb,new ee(_0x250937['_repo'],_0x250937['_path']),R),_0x38181e['resolve'](new of(_0x3205b4,_0x34c38a)));},_0x155333=Gd(_0x250937,()=>{});return Od(_0x250937['_repo'],_0x250937['_path'],_0x542c2a,_0x21a599,_0x155333,_0x27adbc),_0x38181e['promise'];}se['prototype']['simpleListen']=function(_0x2f836f,_0x46bbe0){this['sendRequest']('q',{'p':_0x2f836f},_0x46bbe0);},se['prototype']['echo']=function(_0x417df1,_0x416201){this['sendRequest']('echo',{'d':_0x417df1},_0x416201);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x430816,..._0x517c50){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x430816,..._0x517c50);}function cn(_0x328f16,..._0xefb00f){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x328f16,..._0xefb00f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1d55d5,..._0x12b483){throw ws(_0x1d55d5,..._0x12b483);}function X(_0x26c15e,..._0x210b69){return ws(_0x26c15e,..._0x210b69);}function Ia(_0x4c2d43,_0x168d6a,_0x127dc8){const _0x37562a={...af(),[_0x168d6a]:_0x127dc8};return new Gt('auth','Firebase',_0x37562a)['create'](_0x168d6a,{'appName':_0x4c2d43['name']});}function re(_0x21accb){return Ia(_0x21accb,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x471e78,..._0x1aab65){if(typeof _0x471e78!='string'){const _0xdd84d6=_0x1aab65[0x0],_0x459ebe=[..._0x1aab65['slice'](0x1)];return _0x459ebe[0x0]&&(_0x459ebe[0x0]['appName']=_0x471e78['name']),_0x471e78['_errorFactory']['create'](_0xdd84d6,..._0x459ebe);}return Ea['create'](_0x471e78,..._0x1aab65);}function m(_0x7e1ce5,_0x2acfb9,..._0x34c5f1){if(!_0x7e1ce5)throw ws(_0x2acfb9,..._0x34c5f1);}function ne(_0x285b0f){const _0x3273a0='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x285b0f;throw cn(_0x3273a0),new Error(_0x3273a0);}function ce(_0x51c98c,_0x167504){_0x51c98c||ne(_0x167504);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x43c900;return typeof self<'u'&&((_0x43c900=self['location'])==null?void 0x0:_0x43c900['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x41594a;return typeof self<'u'&&((_0x41594a=self['location'])==null?void 0x0:_0x41594a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x288767=navigator;return _0x288767['languages']&&_0x288767['languages'][0x0]||_0x288767['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5cd3e8,_0x2ede68){this['shortDelay']=_0x5cd3e8,this['longDelay']=_0x2ede68,ce(_0x2ede68>_0x5cd3e8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2352ca,_0x3408f7){ce(_0x2352ca['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x50d9bb}=_0x2352ca['emulator'];return _0x3408f7?''+_0x50d9bb+(_0x3408f7['startsWith']('/')?_0x3408f7['slice'](0x1):_0x3408f7):_0x50d9bb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x311a7b,_0x347e4e,_0x35ef5e){this['fetchImpl']=_0x311a7b,_0x347e4e&&(this['headersImpl']=_0x347e4e),_0x35ef5e&&(this['responseImpl']=_0x35ef5e);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x25646f,_0x24e3c9){return _0x25646f['tenantId']&&!_0x24e3c9['tenantId']?{..._0x24e3c9,'tenantId':_0x25646f['tenantId']}:_0x24e3c9;}async function Pe(_0x4c3c9c,_0x4893f1,_0x2f8d9c,_0x36895a,_0x595aee={}){return Ca(_0x4c3c9c,_0x595aee,async()=>{let _0x477bdd={},_0x807ae2={};_0x36895a&&(_0x4893f1==='GET'?_0x807ae2=_0x36895a:_0x477bdd={'body':JSON['stringify'](_0x36895a)});const _0x536064=ut({..._0x807ae2,'key':_0x4c3c9c['config']['apiKey']})['slice'](0x1),_0x352ca9=await _0x4c3c9c['_getAdditionalHeaders']();_0x352ca9['Content-Type']='application/json',_0x4c3c9c['languageCode']&&(_0x352ca9['X-Firebase-Locale']=_0x4c3c9c['languageCode']);const _0x41463a={'method':_0x4893f1,'headers':_0x352ca9,..._0x477bdd};return dc()||(_0x41463a['referrerPolicy']='strict-origin-when-cross-origin'),_0x4c3c9c['emulatorConfig']&&qt(_0x4c3c9c['emulatorConfig']['host'])&&(_0x41463a['credentials']='include'),wa['fetch']()(await Ta(_0x4c3c9c,_0x4c3c9c['config']['apiHost'],_0x2f8d9c,_0x536064),_0x41463a);});}async function Ca(_0x453009,_0xf9ca7a,_0x386ccc){_0x453009['_canInitEmulator']=!0x1;const _0x15831b={...df,..._0xf9ca7a};try{const _0x1354fe=new gf(_0x453009),_0x2de415=await Promise['race']([_0x386ccc(),_0x1354fe['promise']]);_0x1354fe['clearNetworkTimeout']();const _0x40f40e=await _0x2de415['json']();if('needConfirmation'in _0x40f40e)throw on(_0x453009,'account-exists-with-different-credential',_0x40f40e);if(_0x2de415['ok']&&!('errorMessage'in _0x40f40e))return _0x40f40e;{const _0x128b1d=_0x2de415['ok']?_0x40f40e['errorMessage']:_0x40f40e['error']['message'],[_0x55d875,_0xbe1f22]=_0x128b1d['split']('\x20:\x20');if(_0x55d875==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x453009,'credential-already-in-use',_0x40f40e);if(_0x55d875==='EMAIL_EXISTS')throw on(_0x453009,'email-already-in-use',_0x40f40e);if(_0x55d875==='USER_DISABLED')throw on(_0x453009,'user-disabled',_0x40f40e);const _0x154b41=_0x15831b[_0x55d875]||_0x55d875['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xbe1f22)throw Ia(_0x453009,_0x154b41,_0xbe1f22);Y(_0x453009,_0x154b41);}}catch(_0x33c83c){if(_0x33c83c instanceof Re)throw _0x33c83c;Y(_0x453009,'network-request-failed',{'message':String(_0x33c83c)});}}async function en(_0x3dea3e,_0x317ae0,_0x37e562,_0x149940,_0x753ce7={}){const _0x448633=await Pe(_0x3dea3e,_0x317ae0,_0x37e562,_0x149940,_0x753ce7);return'mfaPendingCredential'in _0x448633&&Y(_0x3dea3e,'multi-factor-auth-required',{'_serverResponse':_0x448633}),_0x448633;}async function Ta(_0x21d90c,_0x588d2a,_0x5f566b,_0x41fbe7){const _0x5a5677=''+_0x588d2a+_0x5f566b+'?'+_0x41fbe7,_0x66e841=_0x21d90c,_0x59d3b0=_0x66e841['config']['emulator']?Cs(_0x21d90c['config'],_0x5a5677):_0x21d90c['config']['apiScheme']+'://'+_0x5a5677;return ff['includes'](_0x5f566b)&&(await _0x66e841['_persistenceManagerAvailable'],_0x66e841['_getPersistenceType']()==='COOKIE')?_0x66e841['_getPersistence']()['_getFinalTarget'](_0x59d3b0)['toString']():_0x59d3b0;}function _f(_0x231a87){switch(_0x231a87){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x519fa0){this['auth']=_0x519fa0,this['timer']=null,this['promise']=new Promise((_0x3aee8c,_0x5840e5)=>{this['timer']=setTimeout(()=>_0x5840e5(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x41063a,_0x4a4d48,_0x2f56ab){const _0xb84792={'appName':_0x41063a['name']};_0x2f56ab['email']&&(_0xb84792['email']=_0x2f56ab['email']),_0x2f56ab['phoneNumber']&&(_0xb84792['phoneNumber']=_0x2f56ab['phoneNumber']);const _0x5f5312=X(_0x41063a,_0x4a4d48,_0xb84792);return _0x5f5312['customData']['_tokenResponse']=_0x2f56ab,_0x5f5312;}function wr(_0x55bd1d){return _0x55bd1d!==void 0x0&&_0x55bd1d['enterprise']!==void 0x0;}class mf{constructor(_0xb88959){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0xb88959['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0xb88959['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0xb88959['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x99fcd6){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3891fa of this['recaptchaEnforcementState'])if(_0x3891fa['provider']&&_0x3891fa['provider']===_0x99fcd6)return _f(_0x3891fa['enforcementState']);return null;}['isProviderEnabled'](_0xb496ab){return this['getProviderEnforcementState'](_0xb496ab)==='ENFORCE'||this['getProviderEnforcementState'](_0xb496ab)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0xfa9c4,_0x4da3fb){return Pe(_0xfa9c4,'GET','/v2/recaptchaConfig',ke(_0xfa9c4,_0x4da3fb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3ec0e7,_0x1137ff){return Pe(_0x3ec0e7,'POST','/v1/accounts:delete',_0x1137ff);}async function Pn(_0x1bdfcb,_0x2ab346){return Pe(_0x1bdfcb,'POST','/v1/accounts:lookup',_0x2ab346);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x21e644){if(_0x21e644)try{const _0x54ba42=new Date(Number(_0x21e644));if(!isNaN(_0x54ba42['getTime']()))return _0x54ba42['toUTCString']();}catch{}}async function Ef(_0x2c36f8,_0x5c1c6a=!0x1){const _0x2e30c5=P(_0x2c36f8),_0x56669f=await _0x2e30c5['getIdToken'](_0x5c1c6a),_0x2d1d55=Ts(_0x56669f);m(_0x2d1d55&&_0x2d1d55['exp']&&_0x2d1d55['auth_time']&&_0x2d1d55['iat'],_0x2e30c5['auth'],'internal-error');const _0x280ccf=typeof _0x2d1d55['firebase']=='object'?_0x2d1d55['firebase']:void 0x0,_0x7707a1=_0x280ccf==null?void 0x0:_0x280ccf['sign_in_provider'];return{'claims':_0x2d1d55,'token':_0x56669f,'authTime':Pt(fi(_0x2d1d55['auth_time'])),'issuedAtTime':Pt(fi(_0x2d1d55['iat'])),'expirationTime':Pt(fi(_0x2d1d55['exp'])),'signInProvider':_0x7707a1||null,'signInSecondFactor':(_0x280ccf==null?void 0x0:_0x280ccf['sign_in_second_factor'])||null};}function fi(_0xf15eba){return Number(_0xf15eba)*0x3e8;}function Ts(_0x4f1ffc){const [_0x11ae42,_0x28e84f,_0x452fd1]=_0x4f1ffc['split']('.');if(_0x11ae42===void 0x0||_0x28e84f===void 0x0||_0x452fd1===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1693f2=fn(_0x28e84f);return _0x1693f2?JSON['parse'](_0x1693f2):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5b0334){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5b0334==null?void 0x0:_0x5b0334['toString']()),null;}}function Cr(_0x3c623f){const _0x14b022=Ts(_0x3c623f);return m(_0x14b022,'internal-error'),m(typeof _0x14b022['exp']<'u','internal-error'),m(typeof _0x14b022['iat']<'u','internal-error'),Number(_0x14b022['exp'])-Number(_0x14b022['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2ac0e7,_0x53f969,_0xc16b49=!0x1){if(_0xc16b49)return _0x53f969;try{return await _0x53f969;}catch(_0x25c06e){throw _0x25c06e instanceof Re&&If(_0x25c06e)&&_0x2ac0e7['auth']['currentUser']===_0x2ac0e7&&await _0x2ac0e7['auth']['signOut'](),_0x25c06e;}}function If({code:_0x5297e7}){return _0x5297e7==='auth/user-disabled'||_0x5297e7==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x162661){this['user']=_0x162661,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4d0450){if(_0x4d0450){const _0x2cda72=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2cda72;}else{this['errorBackoff']=0x7530;const _0x595cae=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x595cae);}}['schedule'](_0x464a52=!0x1){if(!this['isRunning'])return;const _0x13b98f=this['getInterval'](_0x464a52);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x13b98f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x595efe){(_0x595efe==null?void 0x0:_0x595efe['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x3683f0,_0x5a8303){this['createdAt']=_0x3683f0,this['lastLoginAt']=_0x5a8303,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x5726dc){this['createdAt']=_0x5726dc['createdAt'],this['lastLoginAt']=_0x5726dc['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2ab1dd){var _0x427be7;const _0x34c19c=_0x2ab1dd['auth'],_0x15e0e2=await _0x2ab1dd['getIdToken'](),_0x185f00=await Ht(_0x2ab1dd,Pn(_0x34c19c,{'idToken':_0x15e0e2}));m(_0x185f00==null?void 0x0:_0x185f00['users']['length'],_0x34c19c,'internal-error');const _0x560a59=_0x185f00['users'][0x0];_0x2ab1dd['_notifyReloadListener'](_0x560a59);const _0x377bf0=(_0x427be7=_0x560a59['providerUserInfo'])!=null&&_0x427be7['length']?Sa(_0x560a59['providerUserInfo']):[],_0x16e5d0=Tf(_0x2ab1dd['providerData'],_0x377bf0),_0x34898a=_0x2ab1dd['isAnonymous'],_0x30d961=!(_0x2ab1dd['email']&&_0x560a59['passwordHash'])&&!(_0x16e5d0!=null&&_0x16e5d0['length']),_0x4c2000=_0x34898a?_0x30d961:!0x1,_0x3b8c8c={'uid':_0x560a59['localId'],'displayName':_0x560a59['displayName']||null,'photoURL':_0x560a59['photoUrl']||null,'email':_0x560a59['email']||null,'emailVerified':_0x560a59['emailVerified']||!0x1,'phoneNumber':_0x560a59['phoneNumber']||null,'tenantId':_0x560a59['tenantId']||null,'providerData':_0x16e5d0,'metadata':new Li(_0x560a59['createdAt'],_0x560a59['lastLoginAt']),'isAnonymous':_0x4c2000};Object['assign'](_0x2ab1dd,_0x3b8c8c);}async function Cf(_0x1b8bff){const _0x251f89=P(_0x1b8bff);await Nn(_0x251f89),await _0x251f89['auth']['_persistUserIfCurrent'](_0x251f89),_0x251f89['auth']['_notifyListenersIfCurrent'](_0x251f89);}function Tf(_0xec6484,_0x1d1f52){return[..._0xec6484['filter'](_0x4b02ea=>!_0x1d1f52['some'](_0x1aaa64=>_0x1aaa64['providerId']===_0x4b02ea['providerId'])),..._0x1d1f52];}function Sa(_0x5cd8da){return _0x5cd8da['map'](({providerId:_0x5a2873,..._0x45c5d3})=>({'providerId':_0x5a2873,'uid':_0x45c5d3['rawId']||'','displayName':_0x45c5d3['displayName']||null,'email':_0x45c5d3['email']||null,'phoneNumber':_0x45c5d3['phoneNumber']||null,'photoURL':_0x45c5d3['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x24c08c,_0x257b7a){const _0x283bf2=await Ca(_0x24c08c,{},async()=>{const _0x4e10ad=ut({'grant_type':'refresh_token','refresh_token':_0x257b7a})['slice'](0x1),{tokenApiHost:_0x478383,apiKey:_0xd0fb39}=_0x24c08c['config'],_0x3971af=await Ta(_0x24c08c,_0x478383,'/v1/token','key='+_0xd0fb39),_0x656434=await _0x24c08c['_getAdditionalHeaders']();_0x656434['Content-Type']='application/x-www-form-urlencoded';const _0x51815f={'method':'POST','headers':_0x656434,'body':_0x4e10ad};return _0x24c08c['emulatorConfig']&&qt(_0x24c08c['emulatorConfig']['host'])&&(_0x51815f['credentials']='include'),wa['fetch']()(_0x3971af,_0x51815f);});return{'accessToken':_0x283bf2['access_token'],'expiresIn':_0x283bf2['expires_in'],'refreshToken':_0x283bf2['refresh_token']};}async function bf(_0x2d6cc1,_0x2c17a7){return Pe(_0x2d6cc1,'POST','/v2/accounts:revokeToken',ke(_0x2d6cc1,_0x2c17a7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x27d4e3){m(_0x27d4e3['idToken'],'internal-error'),m(typeof _0x27d4e3['idToken']<'u','internal-error'),m(typeof _0x27d4e3['refreshToken']<'u','internal-error');const _0x2516a1='expiresIn'in _0x27d4e3&&typeof _0x27d4e3['expiresIn']<'u'?Number(_0x27d4e3['expiresIn']):Cr(_0x27d4e3['idToken']);this['updateTokensAndExpiration'](_0x27d4e3['idToken'],_0x27d4e3['refreshToken'],_0x2516a1);}['updateFromIdToken'](_0x3ffcd3){m(_0x3ffcd3['length']!==0x0,'internal-error');const _0x36e27c=Cr(_0x3ffcd3);this['updateTokensAndExpiration'](_0x3ffcd3,null,_0x36e27c);}async['getToken'](_0x49b10e,_0x3c1809=!0x1){return!_0x3c1809&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x49b10e,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x49b10e,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1d9f0b,_0x7823b5){const {accessToken:_0x169208,refreshToken:_0x5c8cac,expiresIn:_0x355248}=await Sf(_0x1d9f0b,_0x7823b5);this['updateTokensAndExpiration'](_0x169208,_0x5c8cac,Number(_0x355248));}['updateTokensAndExpiration'](_0x1da8bd,_0x310906,_0x4b539f){this['refreshToken']=_0x310906||null,this['accessToken']=_0x1da8bd||null,this['expirationTime']=Date['now']()+_0x4b539f*0x3e8;}static['fromJSON'](_0x3fd3a2,_0x38f47f){const {refreshToken:_0x1d0af1,accessToken:_0x315783,expirationTime:_0x41f110}=_0x38f47f,_0x3221e2=new et();return _0x1d0af1&&(m(typeof _0x1d0af1=='string','internal-error',{'appName':_0x3fd3a2}),_0x3221e2['refreshToken']=_0x1d0af1),_0x315783&&(m(typeof _0x315783=='string','internal-error',{'appName':_0x3fd3a2}),_0x3221e2['accessToken']=_0x315783),_0x41f110&&(m(typeof _0x41f110=='number','internal-error',{'appName':_0x3fd3a2}),_0x3221e2['expirationTime']=_0x41f110),_0x3221e2;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xb1925){this['accessToken']=_0xb1925['accessToken'],this['refreshToken']=_0xb1925['refreshToken'],this['expirationTime']=_0xb1925['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1c801e,_0x5ed6b4){m(typeof _0x1c801e=='string'||typeof _0x1c801e>'u','internal-error',{'appName':_0x5ed6b4});}class j{constructor({uid:_0x2a4a20,auth:_0x2fefd0,stsTokenManager:_0xb5df4,..._0x33cf19}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2a4a20,this['auth']=_0x2fefd0,this['stsTokenManager']=_0xb5df4,this['accessToken']=_0xb5df4['accessToken'],this['displayName']=_0x33cf19['displayName']||null,this['email']=_0x33cf19['email']||null,this['emailVerified']=_0x33cf19['emailVerified']||!0x1,this['phoneNumber']=_0x33cf19['phoneNumber']||null,this['photoURL']=_0x33cf19['photoURL']||null,this['isAnonymous']=_0x33cf19['isAnonymous']||!0x1,this['tenantId']=_0x33cf19['tenantId']||null,this['providerData']=_0x33cf19['providerData']?[..._0x33cf19['providerData']]:[],this['metadata']=new Li(_0x33cf19['createdAt']||void 0x0,_0x33cf19['lastLoginAt']||void 0x0);}async['getIdToken'](_0x292f8d){const _0xafba2e=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x292f8d));return m(_0xafba2e,this['auth'],'internal-error'),this['accessToken']!==_0xafba2e&&(this['accessToken']=_0xafba2e,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xafba2e;}['getIdTokenResult'](_0x3cd8af){return Ef(this,_0x3cd8af);}['reload'](){return Cf(this);}['_assign'](_0x42adbb){this!==_0x42adbb&&(m(this['uid']===_0x42adbb['uid'],this['auth'],'internal-error'),this['displayName']=_0x42adbb['displayName'],this['photoURL']=_0x42adbb['photoURL'],this['email']=_0x42adbb['email'],this['emailVerified']=_0x42adbb['emailVerified'],this['phoneNumber']=_0x42adbb['phoneNumber'],this['isAnonymous']=_0x42adbb['isAnonymous'],this['tenantId']=_0x42adbb['tenantId'],this['providerData']=_0x42adbb['providerData']['map'](_0x493735=>({..._0x493735})),this['metadata']['_copy'](_0x42adbb['metadata']),this['stsTokenManager']['_assign'](_0x42adbb['stsTokenManager']));}['_clone'](_0x5d247b){const _0x17cd20=new j({...this,'auth':_0x5d247b,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x17cd20['metadata']['_copy'](this['metadata']),_0x17cd20;}['_onReload'](_0xddf9d3){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xddf9d3,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3cc78a){this['reloadListener']?this['reloadListener'](_0x3cc78a):this['reloadUserInfo']=_0x3cc78a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5dfccc,_0x618b1a=!0x1){let _0x5942f5=!0x1;_0x5dfccc['idToken']&&_0x5dfccc['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5dfccc),_0x5942f5=!0x0),_0x618b1a&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5942f5&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x59a019=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x59a019})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4e2a5f=>({..._0x4e2a5f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4b5a51,_0x48cd3b){const _0x1b3fc7=_0x48cd3b['displayName']??void 0x0,_0x13c0d3=_0x48cd3b['email']??void 0x0,_0x2e12dc=_0x48cd3b['phoneNumber']??void 0x0,_0x34519e=_0x48cd3b['photoURL']??void 0x0,_0x2c0f42=_0x48cd3b['tenantId']??void 0x0,_0x53edeb=_0x48cd3b['_redirectEventId']??void 0x0,_0x46bb7e=_0x48cd3b['createdAt']??void 0x0,_0x2ae69d=_0x48cd3b['lastLoginAt']??void 0x0,{uid:_0x542945,emailVerified:_0x246929,isAnonymous:_0x460d37,providerData:_0x3ab356,stsTokenManager:_0x17cbf3}=_0x48cd3b;m(_0x542945&&_0x17cbf3,_0x4b5a51,'internal-error');const _0x14420d=et['fromJSON'](this['name'],_0x17cbf3);m(typeof _0x542945=='string',_0x4b5a51,'internal-error'),le(_0x1b3fc7,_0x4b5a51['name']),le(_0x13c0d3,_0x4b5a51['name']),m(typeof _0x246929=='boolean',_0x4b5a51,'internal-error'),m(typeof _0x460d37=='boolean',_0x4b5a51,'internal-error'),le(_0x2e12dc,_0x4b5a51['name']),le(_0x34519e,_0x4b5a51['name']),le(_0x2c0f42,_0x4b5a51['name']),le(_0x53edeb,_0x4b5a51['name']),le(_0x46bb7e,_0x4b5a51['name']),le(_0x2ae69d,_0x4b5a51['name']);const _0x56cd49=new j({'uid':_0x542945,'auth':_0x4b5a51,'email':_0x13c0d3,'emailVerified':_0x246929,'displayName':_0x1b3fc7,'isAnonymous':_0x460d37,'photoURL':_0x34519e,'phoneNumber':_0x2e12dc,'tenantId':_0x2c0f42,'stsTokenManager':_0x14420d,'createdAt':_0x46bb7e,'lastLoginAt':_0x2ae69d});return _0x3ab356&&Array['isArray'](_0x3ab356)&&(_0x56cd49['providerData']=_0x3ab356['map'](_0x3e2815=>({..._0x3e2815}))),_0x53edeb&&(_0x56cd49['_redirectEventId']=_0x53edeb),_0x56cd49;}static async['_fromIdTokenResponse'](_0x4cad44,_0x33c7b5,_0x2bbcb6=!0x1){const _0x5ec998=new et();_0x5ec998['updateFromServerResponse'](_0x33c7b5);const _0x25d01d=new j({'uid':_0x33c7b5['localId'],'auth':_0x4cad44,'stsTokenManager':_0x5ec998,'isAnonymous':_0x2bbcb6});return await Nn(_0x25d01d),_0x25d01d;}static async['_fromGetAccountInfoResponse'](_0x3df0b0,_0xbdd18,_0x3c7d54){const _0xa0ba74=_0xbdd18['users'][0x0];m(_0xa0ba74['localId']!==void 0x0,'internal-error');const _0x42dfa7=_0xa0ba74['providerUserInfo']!==void 0x0?Sa(_0xa0ba74['providerUserInfo']):[],_0x2e92e4=!(_0xa0ba74['email']&&_0xa0ba74['passwordHash'])&&!(_0x42dfa7!=null&&_0x42dfa7['length']),_0x1bc698=new et();_0x1bc698['updateFromIdToken'](_0x3c7d54);const _0x531526=new j({'uid':_0xa0ba74['localId'],'auth':_0x3df0b0,'stsTokenManager':_0x1bc698,'isAnonymous':_0x2e92e4}),_0x56b323={'uid':_0xa0ba74['localId'],'displayName':_0xa0ba74['displayName']||null,'photoURL':_0xa0ba74['photoUrl']||null,'email':_0xa0ba74['email']||null,'emailVerified':_0xa0ba74['emailVerified']||!0x1,'phoneNumber':_0xa0ba74['phoneNumber']||null,'tenantId':_0xa0ba74['tenantId']||null,'providerData':_0x42dfa7,'metadata':new Li(_0xa0ba74['createdAt'],_0xa0ba74['lastLoginAt']),'isAnonymous':!(_0xa0ba74['email']&&_0xa0ba74['passwordHash'])&&!(_0x42dfa7!=null&&_0x42dfa7['length'])};return Object['assign'](_0x531526,_0x56b323),_0x531526;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4f98d8){ce(_0x4f98d8 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x581d2e=Tr['get'](_0x4f98d8);return _0x581d2e?(ce(_0x581d2e instanceof _0x4f98d8,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x581d2e):(_0x581d2e=new _0x4f98d8(),Tr['set'](_0x4f98d8,_0x581d2e),_0x581d2e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x433a9a,_0x4e68c3){this['storage'][_0x433a9a]=_0x4e68c3;}async['_get'](_0x19696f){const _0x96b773=this['storage'][_0x19696f];return _0x96b773===void 0x0?null:_0x96b773;}async['_remove'](_0x2aac94){delete this['storage'][_0x2aac94];}['_addListener'](_0xb0c306,_0x1905f0){}['_removeListener'](_0xc323a6,_0x393e5c){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1996d9,_0x1e0f31,_0x25cad9){return'firebase:'+_0x1996d9+':'+_0x1e0f31+':'+_0x25cad9;}class tt{constructor(_0x6bc8f,_0x2a2411,_0x430d79){this['persistence']=_0x6bc8f,this['auth']=_0x2a2411,this['userKey']=_0x430d79;const {config:_0x4c7659,name:_0x1f283a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x4c7659['apiKey'],_0x1f283a),this['fullPersistenceKey']=ln('persistence',_0x4c7659['apiKey'],_0x1f283a),this['boundEventHandler']=_0x2a2411['_onStorageEvent']['bind'](_0x2a2411),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3d99ea){return this['persistence']['_set'](this['fullUserKey'],_0x3d99ea['toJSON']());}async['getCurrentUser'](){const _0x49cee2=await this['persistence']['_get'](this['fullUserKey']);if(!_0x49cee2)return null;if(typeof _0x49cee2=='string'){const _0x388924=await Pn(this['auth'],{'idToken':_0x49cee2})['catch'](()=>{});return _0x388924?j['_fromGetAccountInfoResponse'](this['auth'],_0x388924,_0x49cee2):null;}return j['_fromJSON'](this['auth'],_0x49cee2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x8dfa1e){if(this['persistence']===_0x8dfa1e)return;const _0x1e0051=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x8dfa1e,_0x1e0051)return this['setCurrentUser'](_0x1e0051);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x529d9a,_0xbe7294,_0x124a84='authUser'){if(!_0xbe7294['length'])return new tt(ie(Sr),_0x529d9a,_0x124a84);const _0x5953ed=(await Promise['all'](_0xbe7294['map'](async _0x5342aa=>{if(await _0x5342aa['_isAvailable']())return _0x5342aa;})))['filter'](_0x64d1e6=>_0x64d1e6);let _0x857504=_0x5953ed[0x0]||ie(Sr);const _0x57f85f=ln(_0x124a84,_0x529d9a['config']['apiKey'],_0x529d9a['name']);let _0x496658=null;for(const _0x284e01 of _0xbe7294)try{const _0xf9efb6=await _0x284e01['_get'](_0x57f85f);if(_0xf9efb6){let _0x5639d8;if(typeof _0xf9efb6=='string'){const _0x4dc5de=await Pn(_0x529d9a,{'idToken':_0xf9efb6})['catch'](()=>{});if(!_0x4dc5de)break;_0x5639d8=await j['_fromGetAccountInfoResponse'](_0x529d9a,_0x4dc5de,_0xf9efb6);}else _0x5639d8=j['_fromJSON'](_0x529d9a,_0xf9efb6);_0x284e01!==_0x857504&&(_0x496658=_0x5639d8),_0x857504=_0x284e01;break;}}catch{}const _0xff33f5=_0x5953ed['filter'](_0x22f640=>_0x22f640['_shouldAllowMigration']);return!_0x857504['_shouldAllowMigration']||!_0xff33f5['length']?new tt(_0x857504,_0x529d9a,_0x124a84):(_0x857504=_0xff33f5[0x0],_0x496658&&await _0x857504['_set'](_0x57f85f,_0x496658['toJSON']()),await Promise['all'](_0xbe7294['map'](async _0x1e0c01=>{if(_0x1e0c01!==_0x857504)try{await _0x1e0c01['_remove'](_0x57f85f);}catch{}})),new tt(_0x857504,_0x529d9a,_0x124a84));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x48adde){const _0x1f3c90=_0x48adde['toLowerCase']();if(_0x1f3c90['includes']('opera/')||_0x1f3c90['includes']('opr/')||_0x1f3c90['includes']('opios/'))return'Opera';if(Pa(_0x1f3c90))return'IEMobile';if(_0x1f3c90['includes']('msie')||_0x1f3c90['includes']('trident/'))return'IE';if(_0x1f3c90['includes']('edge/'))return'Edge';if(Ra(_0x1f3c90))return'Firefox';if(_0x1f3c90['includes']('silk/'))return'Silk';if(Oa(_0x1f3c90))return'Blackberry';if(Da(_0x1f3c90))return'Webos';if(Aa(_0x1f3c90))return'Safari';if((_0x1f3c90['includes']('chrome/')||ka(_0x1f3c90))&&!_0x1f3c90['includes']('edge/'))return'Chrome';if(Na(_0x1f3c90))return'Android';{const _0x1a2379=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xc13268=_0x48adde['match'](_0x1a2379);if((_0xc13268==null?void 0x0:_0xc13268['length'])===0x2)return _0xc13268[0x1];}return'Other';}function Ra(_0x32fc80=W()){return/firefox\//i['test'](_0x32fc80);}function Aa(_0x1fa16c=W()){const _0x3c3863=_0x1fa16c['toLowerCase']();return _0x3c3863['includes']('safari/')&&!_0x3c3863['includes']('chrome/')&&!_0x3c3863['includes']('crios/')&&!_0x3c3863['includes']('android');}function ka(_0x31febc=W()){return/crios\//i['test'](_0x31febc);}function Pa(_0x223d90=W()){return/iemobile/i['test'](_0x223d90);}function Na(_0x5f4a5c=W()){return/android/i['test'](_0x5f4a5c);}function Oa(_0x51d0f5=W()){return/blackberry/i['test'](_0x51d0f5);}function Da(_0x5eb7e4=W()){return/webos/i['test'](_0x5eb7e4);}function Ss(_0x37d49e=W()){return/iphone|ipad|ipod/i['test'](_0x37d49e)||/macintosh/i['test'](_0x37d49e)&&/mobile/i['test'](_0x37d49e);}function Rf(_0x3dc3de=W()){var _0x2fd6db;return Ss(_0x3dc3de)&&!!((_0x2fd6db=window['navigator'])!=null&&_0x2fd6db['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x380028=W()){return Ss(_0x380028)||Na(_0x380028)||Da(_0x380028)||Oa(_0x380028)||/windows phone/i['test'](_0x380028)||Pa(_0x380028);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x350ca4,_0x5e1d63=[]){let _0x445796;switch(_0x350ca4){case'Browser':_0x445796=br(W());break;case'Worker':_0x445796=br(W())+'-'+_0x350ca4;break;default:_0x445796=_0x350ca4;}const _0x8bf0ad=_0x5e1d63['length']?_0x5e1d63['join'](','):'FirebaseCore-web';return _0x445796+'/JsCore/'+dt+'/'+_0x8bf0ad;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x46d618){this['auth']=_0x46d618,this['queue']=[];}['pushCallback'](_0x237914,_0x58420c){const _0xfb2097=_0x2690c8=>new Promise((_0x2aaae1,_0x2b09d0)=>{try{const _0x1b6fbd=_0x237914(_0x2690c8);_0x2aaae1(_0x1b6fbd);}catch(_0x42316a){_0x2b09d0(_0x42316a);}});_0xfb2097['onAbort']=_0x58420c,this['queue']['push'](_0xfb2097);const _0x3baca6=this['queue']['length']-0x1;return()=>{this['queue'][_0x3baca6]=()=>Promise['resolve']();};}async['runMiddleware'](_0xfe7dc0){if(this['auth']['currentUser']===_0xfe7dc0)return;const _0x1e579e=[];try{for(const _0x416215 of this['queue'])await _0x416215(_0xfe7dc0),_0x416215['onAbort']&&_0x1e579e['push'](_0x416215['onAbort']);}catch(_0x32cbad){_0x1e579e['reverse']();for(const _0x1910a0 of _0x1e579e)try{_0x1910a0();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x32cbad==null?void 0x0:_0x32cbad['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x4a076b,_0x28191d={}){return Pe(_0x4a076b,'GET','/v2/passwordPolicy',ke(_0x4a076b,_0x28191d));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x41e2bc){var _0x5da2d8;const _0x1482b7=_0x41e2bc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x1482b7['minPasswordLength']??Nf,_0x1482b7['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x1482b7['maxPasswordLength']),_0x1482b7['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x1482b7['containsLowercaseCharacter']),_0x1482b7['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x1482b7['containsUppercaseCharacter']),_0x1482b7['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x1482b7['containsNumericCharacter']),_0x1482b7['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x1482b7['containsNonAlphanumericCharacter']),this['enforcementState']=_0x41e2bc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5da2d8=_0x41e2bc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5da2d8['join'](''))??'',this['forceUpgradeOnSignin']=_0x41e2bc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x41e2bc['schemaVersion'];}['validatePassword'](_0x3ab26d){const _0x2bdd86={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x3ab26d,_0x2bdd86),this['validatePasswordCharacterOptions'](_0x3ab26d,_0x2bdd86),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['meetsMinPasswordLength']??!0x0),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['meetsMaxPasswordLength']??!0x0),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['containsLowercaseLetter']??!0x0),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['containsUppercaseLetter']??!0x0),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['containsNumericCharacter']??!0x0),_0x2bdd86['isValid']&&(_0x2bdd86['isValid']=_0x2bdd86['containsNonAlphanumericCharacter']??!0x0),_0x2bdd86;}['validatePasswordLengthOptions'](_0x306873,_0x2edbaf){const _0x314f9b=this['customStrengthOptions']['minPasswordLength'],_0xc0d575=this['customStrengthOptions']['maxPasswordLength'];_0x314f9b&&(_0x2edbaf['meetsMinPasswordLength']=_0x306873['length']>=_0x314f9b),_0xc0d575&&(_0x2edbaf['meetsMaxPasswordLength']=_0x306873['length']<=_0xc0d575);}['validatePasswordCharacterOptions'](_0x485fc6,_0x310563){this['updatePasswordCharacterOptionsStatuses'](_0x310563,!0x1,!0x1,!0x1,!0x1);let _0x42db0a;for(let _0x1b339a=0x0;_0x1b339a<_0x485fc6['length'];_0x1b339a++)_0x42db0a=_0x485fc6['charAt'](_0x1b339a),this['updatePasswordCharacterOptionsStatuses'](_0x310563,_0x42db0a>='a'&&_0x42db0a<='z',_0x42db0a>='A'&&_0x42db0a<='Z',_0x42db0a>='0'&&_0x42db0a<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x42db0a));}['updatePasswordCharacterOptionsStatuses'](_0x1e7f54,_0x17c25d,_0x241fc8,_0x1cca1b,_0x2a6b35){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1e7f54['containsLowercaseLetter']||(_0x1e7f54['containsLowercaseLetter']=_0x17c25d)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1e7f54['containsUppercaseLetter']||(_0x1e7f54['containsUppercaseLetter']=_0x241fc8)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1e7f54['containsNumericCharacter']||(_0x1e7f54['containsNumericCharacter']=_0x1cca1b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1e7f54['containsNonAlphanumericCharacter']||(_0x1e7f54['containsNonAlphanumericCharacter']=_0x2a6b35));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x59bfca,_0xa8bb2,_0x5ec193,_0x10485d){this['app']=_0x59bfca,this['heartbeatServiceProvider']=_0xa8bb2,this['appCheckServiceProvider']=_0x5ec193,this['config']=_0x10485d,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x59bfca['name'],this['clientVersion']=_0x10485d['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x34d83a=>this['_resolvePersistenceManagerAvailable']=_0x34d83a);}['_initializeWithPersistence'](_0x317521,_0xadc2e8){return _0xadc2e8&&(this['_popupRedirectResolver']=ie(_0xadc2e8)),this['_initializationPromise']=this['queue'](async()=>{var _0xf499e9,_0x37b146,_0x1eac96;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x317521),(_0xf499e9=this['_resolvePersistenceManagerAvailable'])==null||_0xf499e9['call'](this),!this['_deleted'])){if((_0x37b146=this['_popupRedirectResolver'])!=null&&_0x37b146['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0xadc2e8),this['lastNotifiedUid']=((_0x1eac96=this['currentUser'])==null?void 0x0:_0x1eac96['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x19384d=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x19384d)){if(this['currentUser']&&_0x19384d&&this['currentUser']['uid']===_0x19384d['uid']){this['_currentUser']['_assign'](_0x19384d),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x19384d,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x392be8){try{const _0x549ff2=await Pn(this,{'idToken':_0x392be8}),_0x2e39c0=await j['_fromGetAccountInfoResponse'](this,_0x549ff2,_0x392be8);await this['directlySetCurrentUser'](_0x2e39c0);}catch(_0x1eb38f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1eb38f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5380b5){var _0x3bff66;if($(this['app'])){const _0x51e184=this['app']['settings']['authIdToken'];return _0x51e184?new Promise(_0x335f7c=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x51e184)['then'](_0x335f7c,_0x335f7c));}):this['directlySetCurrentUser'](null);}const _0x46a7cd=await this['assertedPersistence']['getCurrentUser']();let _0x8e2c1b=_0x46a7cd,_0x523e55=!0x1;if(_0x5380b5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x22442e=(_0x3bff66=this['redirectUser'])==null?void 0x0:_0x3bff66['_redirectEventId'],_0x4547c8=_0x8e2c1b==null?void 0x0:_0x8e2c1b['_redirectEventId'],_0x1b9d40=await this['tryRedirectSignIn'](_0x5380b5);(!_0x22442e||_0x22442e===_0x4547c8)&&(_0x1b9d40!=null&&_0x1b9d40['user'])&&(_0x8e2c1b=_0x1b9d40['user'],_0x523e55=!0x0);}if(!_0x8e2c1b)return this['directlySetCurrentUser'](null);if(!_0x8e2c1b['_redirectEventId']){if(_0x523e55)try{await this['beforeStateQueue']['runMiddleware'](_0x8e2c1b);}catch(_0x3369ea){_0x8e2c1b=_0x46a7cd,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3369ea));}return _0x8e2c1b?this['reloadAndSetCurrentUserOrClear'](_0x8e2c1b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x8e2c1b['_redirectEventId']?this['directlySetCurrentUser'](_0x8e2c1b):this['reloadAndSetCurrentUserOrClear'](_0x8e2c1b);}async['tryRedirectSignIn'](_0x22890c){let _0x2cdc5b=null;try{_0x2cdc5b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x22890c,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2cdc5b;}async['reloadAndSetCurrentUserOrClear'](_0x4d9482){try{await Nn(_0x4d9482);}catch(_0x5c1a6a){if((_0x5c1a6a==null?void 0x0:_0x5c1a6a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4d9482);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1676a9){if($(this['app']))return Promise['reject'](re(this));const _0x5736e5=_0x1676a9?P(_0x1676a9):null;return _0x5736e5&&m(_0x5736e5['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5736e5&&_0x5736e5['_clone'](this));}async['_updateCurrentUser'](_0x33e91c,_0x2ec013=!0x1){if(!this['_deleted'])return _0x33e91c&&m(this['tenantId']===_0x33e91c['tenantId'],this,'tenant-id-mismatch'),_0x2ec013||await this['beforeStateQueue']['runMiddleware'](_0x33e91c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x33e91c),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2e4b81){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2e4b81));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4828eb){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4e8a29=this['_getPasswordPolicyInternal']();return _0x4e8a29['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4e8a29['validatePassword'](_0x4828eb);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x12d7e4=await Pf(this),_0x1d8c6e=new Of(_0x12d7e4);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1d8c6e:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1d8c6e;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x59a1d9){this['_errorFactory']=new Gt('auth','Firebase',_0x59a1d9());}['onAuthStateChanged'](_0x50cf12,_0x17cb75,_0x240cfe){return this['registerStateListener'](this['authStateSubscription'],_0x50cf12,_0x17cb75,_0x240cfe);}['beforeAuthStateChanged'](_0x51b5c6,_0x465c5b){return this['beforeStateQueue']['pushCallback'](_0x51b5c6,_0x465c5b);}['onIdTokenChanged'](_0x1429fe,_0x78c3aa,_0x3a4aa){return this['registerStateListener'](this['idTokenSubscription'],_0x1429fe,_0x78c3aa,_0x3a4aa);}['authStateReady'](){return new Promise((_0x5c9f26,_0x20c13e)=>{if(this['currentUser'])_0x5c9f26();else{const _0x52fc07=this['onAuthStateChanged'](()=>{_0x52fc07(),_0x5c9f26();},_0x20c13e);}});}async['revokeAccessToken'](_0x41be99){if(this['currentUser']){const _0x9ad688=await this['currentUser']['getIdToken'](),_0x5b46dd={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x41be99,'idToken':_0x9ad688};this['tenantId']!=null&&(_0x5b46dd['tenantId']=this['tenantId']),await bf(this,_0x5b46dd);}}['toJSON'](){var _0x111fb2;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x111fb2=this['_currentUser'])==null?void 0x0:_0x111fb2['toJSON']()};}async['_setRedirectUser'](_0x31cf30,_0x441d4d){const _0x133a56=await this['getOrInitRedirectPersistenceManager'](_0x441d4d);return _0x31cf30===null?_0x133a56['removeCurrentUser']():_0x133a56['setCurrentUser'](_0x31cf30);}async['getOrInitRedirectPersistenceManager'](_0x340e51){if(!this['redirectPersistenceManager']){const _0x6df517=_0x340e51&&ie(_0x340e51)||this['_popupRedirectResolver'];m(_0x6df517,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x6df517['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x519065){var _0x3a8abc,_0x1ad982;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3a8abc=this['_currentUser'])==null?void 0x0:_0x3a8abc['_redirectEventId'])===_0x519065?this['_currentUser']:((_0x1ad982=this['redirectUser'])==null?void 0x0:_0x1ad982['_redirectEventId'])===_0x519065?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x12353e){if(_0x12353e===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x12353e));}['_notifyListenersIfCurrent'](_0x2bd470){_0x2bd470===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2bc685;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x385072=((_0x2bc685=this['currentUser'])==null?void 0x0:_0x2bc685['uid'])??null;this['lastNotifiedUid']!==_0x385072&&(this['lastNotifiedUid']=_0x385072,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x47017c,_0x476cbb,_0x54292d,_0x233ba3){if(this['_deleted'])return()=>{};const _0x1b57f9=typeof _0x476cbb=='function'?_0x476cbb:_0x476cbb['next']['bind'](_0x476cbb);let _0x1fec51=!0x1;const _0x13859f=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x13859f,this,'internal-error'),_0x13859f['then'](()=>{_0x1fec51||_0x1b57f9(this['currentUser']);}),typeof _0x476cbb=='function'){const _0x19cd92=_0x47017c['addObserver'](_0x476cbb,_0x54292d,_0x233ba3);return()=>{_0x1fec51=!0x0,_0x19cd92();};}else{const _0x191852=_0x47017c['addObserver'](_0x476cbb);return()=>{_0x1fec51=!0x0,_0x191852();};}}async['directlySetCurrentUser'](_0x25fbe3){this['currentUser']&&this['currentUser']!==_0x25fbe3&&this['_currentUser']['_stopProactiveRefresh'](),_0x25fbe3&&this['isProactiveRefreshEnabled']&&_0x25fbe3['_startProactiveRefresh'](),this['currentUser']=_0x25fbe3,_0x25fbe3?await this['assertedPersistence']['setCurrentUser'](_0x25fbe3):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x203e16){return this['operations']=this['operations']['then'](_0x203e16,_0x203e16),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2d2798){!_0x2d2798||this['frameworks']['includes'](_0x2d2798)||(this['frameworks']['push'](_0x2d2798),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x209ea1;const _0x24b031={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x24b031['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x42d0c2=await((_0x209ea1=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x209ea1['getHeartbeatsHeader']());_0x42d0c2&&(_0x24b031['X-Firebase-Client']=_0x42d0c2);const _0x37df9e=await this['_getAppCheckToken']();return _0x37df9e&&(_0x24b031['X-Firebase-AppCheck']=_0x37df9e),_0x24b031;}async['_getAppCheckToken'](){var _0x13cfee;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x45392a=await((_0x13cfee=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x13cfee['getToken']());return _0x45392a!=null&&_0x45392a['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x45392a['error']),_0x45392a==null?void 0x0:_0x45392a['token'];}}function Ke(_0x513297){return P(_0x513297);}class Rr{constructor(_0x55c959){this['auth']=_0x55c959,this['observer']=null,this['addObserver']=Tc(_0x160d9d=>this['observer']=_0x160d9d);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x36b755){Jn=_0x36b755;}function xa(_0x441ae2){return Jn['loadJS'](_0x441ae2);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x21ce97){return'__'+_0x21ce97+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1a5cf2){_0x1a5cf2();}['execute'](_0x942bb8,_0x2f2407){return Promise['resolve']('token');}['render'](_0x25d853,_0x1d7ca2){return'';}}class Wf{['ready'](_0x18efe9){_0x18efe9();}['execute'](_0x28a890,_0x5268cd){return Promise['resolve']('token');}['render'](_0xfd8304,_0x8ce900){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x289ca2){this['type']=Bf,this['auth']=Ke(_0x289ca2);}async['verify'](_0x1857d4='verify',_0x3b2426=!0x1){async function _0xfcc029(_0x1e0fdb){if(!_0x3b2426){if(_0x1e0fdb['tenantId']==null&&_0x1e0fdb['_agentRecaptchaConfig']!=null)return _0x1e0fdb['_agentRecaptchaConfig']['siteKey'];if(_0x1e0fdb['tenantId']!=null&&_0x1e0fdb['_tenantRecaptchaConfigs'][_0x1e0fdb['tenantId']]!==void 0x0)return _0x1e0fdb['_tenantRecaptchaConfigs'][_0x1e0fdb['tenantId']]['siteKey'];}return new Promise(async(_0x1c742a,_0x4ce644)=>{yf(_0x1e0fdb,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x50f203=>{if(_0x50f203['recaptchaKey']===void 0x0)_0x4ce644(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x409fe6=new mf(_0x50f203);return _0x1e0fdb['tenantId']==null?_0x1e0fdb['_agentRecaptchaConfig']=_0x409fe6:_0x1e0fdb['_tenantRecaptchaConfigs'][_0x1e0fdb['tenantId']]=_0x409fe6,_0x1c742a(_0x409fe6['siteKey']);}})['catch'](_0x1a3ceb=>{_0x4ce644(_0x1a3ceb);});});}function _0x8de7b4(_0x196a24,_0x416547,_0x2bd524){const _0x2887af=window['grecaptcha'];wr(_0x2887af)?_0x2887af['enterprise']['ready'](()=>{_0x2887af['enterprise']['execute'](_0x196a24,{'action':_0x1857d4})['then'](_0x1427c0=>{_0x416547(_0x1427c0);})['catch'](()=>{_0x416547(Fa);});}):_0x2bd524(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4c1c93,_0x2551f5)=>{_0xfcc029(this['auth'])['then'](async _0x2076d8=>{if(!_0x3b2426&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x8de7b4(_0x2076d8,_0x4c1c93,_0x2551f5);else{if(typeof window>'u'){_0x2551f5(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x2ba5b9=Lf();_0x2ba5b9['length']!==0x0&&(_0x2ba5b9+=_0x2076d8+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x382fc8;(_0x382fc8=he['scriptInjectionDeferred'])==null||_0x382fc8['resolve']();},xa(_0x2ba5b9)['then'](()=>{var _0x1bde34;return(_0x1bde34=he['scriptInjectionDeferred'])==null?void 0x0:_0x1bde34['promise'];})['then'](()=>{_0x8de7b4(_0x2076d8,_0x4c1c93,_0x2551f5);})['catch'](_0x21376c=>{_0x2551f5(_0x21376c);});}})['catch'](_0x579e2a=>{_0x2551f5(_0x579e2a);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x484ea5,_0x3bf4d2,_0x3631a8,_0x322bef=!0x1,_0x5c60e9=!0x1){const _0x58a4d5=new he(_0x484ea5);let _0x59c68a;if(_0x5c60e9)_0x59c68a=Fa;else try{_0x59c68a=await _0x58a4d5['verify'](_0x3631a8);}catch{_0x59c68a=await _0x58a4d5['verify'](_0x3631a8,!0x0);}const _0x300fad={..._0x3bf4d2};if(_0x3631a8==='mfaSmsEnrollment'||_0x3631a8==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x300fad){const _0x16d005=_0x300fad['phoneEnrollmentInfo']['phoneNumber'],_0x51a061=_0x300fad['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x300fad,{'phoneEnrollmentInfo':{'phoneNumber':_0x16d005,'recaptchaToken':_0x51a061,'captchaResponse':_0x59c68a,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x300fad){const _0xdba71f=_0x300fad['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x300fad,{'phoneSignInInfo':{'recaptchaToken':_0xdba71f,'captchaResponse':_0x59c68a,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x300fad;}return _0x322bef?Object['assign'](_0x300fad,{'captchaResp':_0x59c68a}):Object['assign'](_0x300fad,{'captchaResponse':_0x59c68a}),Object['assign'](_0x300fad,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x300fad,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x300fad;}async function xi(_0x12817a,_0x522f6f,_0x3fd5ab,_0x141f1a,_0x21b962){var _0x21328f;if((_0x21328f=_0x12817a['_getRecaptchaConfig']())!=null&&_0x21328f['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1c2b74=await kr(_0x12817a,_0x522f6f,_0x3fd5ab,_0x3fd5ab==='getOobCode');return _0x141f1a(_0x12817a,_0x1c2b74);}else return _0x141f1a(_0x12817a,_0x522f6f)['catch'](async _0x1d5f6c=>{if(_0x1d5f6c['code']==='auth/missing-recaptcha-token'){console['log'](_0x3fd5ab+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x485ca2=await kr(_0x12817a,_0x522f6f,_0x3fd5ab,_0x3fd5ab==='getOobCode');return _0x141f1a(_0x12817a,_0x485ca2);}else return Promise['reject'](_0x1d5f6c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x3c8162,_0x53a330){const _0x3cffc3=Hi(_0x3c8162,'auth');if(_0x3cffc3['isInitialized']()){const _0x51f731=_0x3cffc3['getImmediate'](),_0x421425=_0x3cffc3['getOptions']();if(xe(_0x421425,_0x53a330??{}))return _0x51f731;Y(_0x51f731,'already-initialized');}return _0x3cffc3['initialize']({'options':_0x53a330});}function Hf(_0x3e4412,_0xa0cd1a){const _0x4535a5=(_0xa0cd1a==null?void 0x0:_0xa0cd1a['persistence'])||[],_0x48a9b9=(Array['isArray'](_0x4535a5)?_0x4535a5:[_0x4535a5])['map'](ie);_0xa0cd1a!=null&&_0xa0cd1a['errorMap']&&_0x3e4412['_updateErrorMap'](_0xa0cd1a['errorMap']),_0x3e4412['_initializeWithPersistence'](_0x48a9b9,_0xa0cd1a==null?void 0x0:_0xa0cd1a['popupRedirectResolver']);}function $f(_0x35a9b2,_0x3931da,_0x4751d4){const _0x5af734=Ke(_0x35a9b2);m(/^https?:\/\//['test'](_0x3931da),_0x5af734,'invalid-emulator-scheme');const _0x527cca=!0x1,_0x50106d=Ua(_0x3931da),{host:_0x2f5fb7,port:_0x45b7e4}=Gf(_0x3931da),_0x6e1d40=_0x45b7e4===null?'':':'+_0x45b7e4,_0x359e58={'url':_0x50106d+'//'+_0x2f5fb7+_0x6e1d40+'/'},_0x373961=Object['freeze']({'host':_0x2f5fb7,'port':_0x45b7e4,'protocol':_0x50106d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x527cca})});if(!_0x5af734['_canInitEmulator']){m(_0x5af734['config']['emulator']&&_0x5af734['emulatorConfig'],_0x5af734,'emulator-config-failed'),m(xe(_0x359e58,_0x5af734['config']['emulator'])&&xe(_0x373961,_0x5af734['emulatorConfig']),_0x5af734,'emulator-config-failed');return;}_0x5af734['config']['emulator']=_0x359e58,_0x5af734['emulatorConfig']=_0x373961,_0x5af734['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x2f5fb7)?Qr(_0x50106d+'//'+_0x2f5fb7+_0x6e1d40):qf();}function Ua(_0x22b2d3){const _0x8eb232=_0x22b2d3['indexOf'](':');return _0x8eb232<0x0?'':_0x22b2d3['substr'](0x0,_0x8eb232+0x1);}function Gf(_0x2e3549){const _0x17c883=Ua(_0x2e3549),_0x3db9ac=/(\/\/)?([^?#/]+)/['exec'](_0x2e3549['substr'](_0x17c883['length']));if(!_0x3db9ac)return{'host':'','port':null};const _0x54fd80=_0x3db9ac[0x2]['split']('@')['pop']()||'',_0x54fb67=/^(\[[^\]]+\])(:|$)/['exec'](_0x54fd80);if(_0x54fb67){const _0x171886=_0x54fb67[0x1];return{'host':_0x171886,'port':Pr(_0x54fd80['substr'](_0x171886['length']+0x1))};}else{const [_0x3b7c0f,_0x29e326]=_0x54fd80['split'](':');return{'host':_0x3b7c0f,'port':Pr(_0x29e326)};}}function Pr(_0x425e23){if(!_0x425e23)return null;const _0x985c4b=Number(_0x425e23);return isNaN(_0x985c4b)?null:_0x985c4b;}function qf(){function _0x29fe2a(){const _0x594cf0=document['createElement']('p'),_0x1752b3=_0x594cf0['style'];_0x594cf0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1752b3['position']='fixed',_0x1752b3['width']='100%',_0x1752b3['backgroundColor']='#ffffff',_0x1752b3['border']='.1em\x20solid\x20#000000',_0x1752b3['color']='#b50000',_0x1752b3['bottom']='0px',_0x1752b3['left']='0px',_0x1752b3['margin']='0px',_0x1752b3['zIndex']='10000',_0x1752b3['textAlign']='center',_0x594cf0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x594cf0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x29fe2a):_0x29fe2a());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x524659,_0x580fb7){this['providerId']=_0x524659,this['signInMethod']=_0x580fb7;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4aa0c1){return ne('not\x20implemented');}['_linkToIdToken'](_0x183878,_0x3c781d){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x673d84){return ne('not\x20implemented');}}async function zf(_0x69bffd,_0x8e6b9){return Pe(_0x69bffd,'POST','/v1/accounts:signUp',_0x8e6b9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x1f67b9,_0x5d661a){return en(_0x1f67b9,'POST','/v1/accounts:signInWithPassword',ke(_0x1f67b9,_0x5d661a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3351ad,_0x4e9c7d){return en(_0x3351ad,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3351ad,_0x4e9c7d));}async function Yf(_0x3f6427,_0x23126e){return en(_0x3f6427,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3f6427,_0x23126e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x354d47,_0x4fbcd8,_0x25674d,_0x116d56=null){super('password',_0x25674d),this['_email']=_0x354d47,this['_password']=_0x4fbcd8,this['_tenantId']=_0x116d56;}static['_fromEmailAndPassword'](_0x1384ce,_0x5c384c){return new $t(_0x1384ce,_0x5c384c,'password');}static['_fromEmailAndCode'](_0x507da3,_0x5419b1,_0x4b2786=null){return new $t(_0x507da3,_0x5419b1,'emailLink',_0x4b2786);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x9422d4){const _0x3a6a70=typeof _0x9422d4=='string'?JSON['parse'](_0x9422d4):_0x9422d4;if(_0x3a6a70!=null&&_0x3a6a70['email']&&(_0x3a6a70!=null&&_0x3a6a70['password'])){if(_0x3a6a70['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3a6a70['email'],_0x3a6a70['password']);if(_0x3a6a70['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3a6a70['email'],_0x3a6a70['password'],_0x3a6a70['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2dc8e1){switch(this['signInMethod']){case'password':const _0x36f5e6={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2dc8e1,_0x36f5e6,'signInWithPassword',jf);case'emailLink':return Kf(_0x2dc8e1,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2dc8e1,'internal-error');}}async['_linkToIdToken'](_0x243212,_0x39e10e){switch(this['signInMethod']){case'password':const _0x3d879f={'idToken':_0x39e10e,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x243212,_0x3d879f,'signUpPassword',zf);case'emailLink':return Yf(_0x243212,{'idToken':_0x39e10e,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x243212,'internal-error');}}['_getReauthenticationResolver'](_0x4a3037){return this['_getIdTokenResponse'](_0x4a3037);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x82e53d,_0xef9527){return en(_0x82e53d,'POST','/v1/accounts:signInWithIdp',ke(_0x82e53d,_0xef9527));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x54cc67){const _0x5a3984=new $e(_0x54cc67['providerId'],_0x54cc67['signInMethod']);return _0x54cc67['idToken']||_0x54cc67['accessToken']?(_0x54cc67['idToken']&&(_0x5a3984['idToken']=_0x54cc67['idToken']),_0x54cc67['accessToken']&&(_0x5a3984['accessToken']=_0x54cc67['accessToken']),_0x54cc67['nonce']&&!_0x54cc67['pendingToken']&&(_0x5a3984['nonce']=_0x54cc67['nonce']),_0x54cc67['pendingToken']&&(_0x5a3984['pendingToken']=_0x54cc67['pendingToken'])):_0x54cc67['oauthToken']&&_0x54cc67['oauthTokenSecret']?(_0x5a3984['accessToken']=_0x54cc67['oauthToken'],_0x5a3984['secret']=_0x54cc67['oauthTokenSecret']):Y('argument-error'),_0x5a3984;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x261407){const _0x42dfef=typeof _0x261407=='string'?JSON['parse'](_0x261407):_0x261407,{providerId:_0x131a14,signInMethod:_0xdbdfd1,..._0x1d6a5a}=_0x42dfef;if(!_0x131a14||!_0xdbdfd1)return null;const _0xb8746a=new $e(_0x131a14,_0xdbdfd1);return _0xb8746a['idToken']=_0x1d6a5a['idToken']||void 0x0,_0xb8746a['accessToken']=_0x1d6a5a['accessToken']||void 0x0,_0xb8746a['secret']=_0x1d6a5a['secret'],_0xb8746a['nonce']=_0x1d6a5a['nonce'],_0xb8746a['pendingToken']=_0x1d6a5a['pendingToken']||null,_0xb8746a;}['_getIdTokenResponse'](_0x2f1b03){const _0x10fa78=this['buildRequest']();return nt(_0x2f1b03,_0x10fa78);}['_linkToIdToken'](_0x47f902,_0x14f4e5){const _0x298ab5=this['buildRequest']();return _0x298ab5['idToken']=_0x14f4e5,nt(_0x47f902,_0x298ab5);}['_getReauthenticationResolver'](_0x181d4a){const _0x289978=this['buildRequest']();return _0x289978['autoCreate']=!0x1,nt(_0x181d4a,_0x289978);}['buildRequest'](){const _0x42a564={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x42a564['pendingToken']=this['pendingToken'];else{const _0x53ef8a={};this['idToken']&&(_0x53ef8a['id_token']=this['idToken']),this['accessToken']&&(_0x53ef8a['access_token']=this['accessToken']),this['secret']&&(_0x53ef8a['oauth_token_secret']=this['secret']),_0x53ef8a['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x53ef8a['nonce']=this['nonce']),_0x42a564['postBody']=ut(_0x53ef8a);}return _0x42a564;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x373daa){switch(_0x373daa){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x5e2405){const _0x506472=Ct(Tt(_0x5e2405))['link'],_0x2febd0=_0x506472?Ct(Tt(_0x506472))['deep_link_id']:null,_0x5e93b7=Ct(Tt(_0x5e2405))['deep_link_id'];return(_0x5e93b7?Ct(Tt(_0x5e93b7))['link']:null)||_0x5e93b7||_0x2febd0||_0x506472||_0x5e2405;}class Rs{constructor(_0x20fc8b){const _0x10e476=Ct(Tt(_0x20fc8b)),_0x5d9969=_0x10e476['apiKey']??null,_0x4463a4=_0x10e476['oobCode']??null,_0x367848=Jf(_0x10e476['mode']??null);m(_0x5d9969&&_0x4463a4&&_0x367848,'argument-error'),this['apiKey']=_0x5d9969,this['operation']=_0x367848,this['code']=_0x4463a4,this['continueUrl']=_0x10e476['continueUrl']??null,this['languageCode']=_0x10e476['lang']??null,this['tenantId']=_0x10e476['tenantId']??null;}static['parseLink'](_0x40af73){const _0xf30fc7=Xf(_0x40af73);try{return new Rs(_0xf30fc7);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x140700,_0x1b6804){return $t['_fromEmailAndPassword'](_0x140700,_0x1b6804);}static['credentialWithLink'](_0x57cde7,_0x1aec9f){const _0x373bbe=Rs['parseLink'](_0x1aec9f);return m(_0x373bbe,'argument-error'),$t['_fromEmailAndCode'](_0x57cde7,_0x373bbe['code'],_0x373bbe['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x24a267){this['providerId']=_0x24a267,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2066f7){this['defaultLanguageCode']=_0x2066f7;}['setCustomParameters'](_0x552f51){return this['customParameters']=_0x552f51,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x366024){return this['scopes']['includes'](_0x366024)||this['scopes']['push'](_0x366024),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x56eb5a){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x56eb5a});}static['credentialFromResult'](_0x44e601){return ue['credentialFromTaggedObject'](_0x44e601);}static['credentialFromError'](_0x32aa6e){return ue['credentialFromTaggedObject'](_0x32aa6e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x497667}){if(!_0x497667||!('oauthAccessToken'in _0x497667)||!_0x497667['oauthAccessToken'])return null;try{return ue['credential'](_0x497667['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2bd829,_0x5e89e8){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2bd829,'accessToken':_0x5e89e8});}static['credentialFromResult'](_0x399491){return de['credentialFromTaggedObject'](_0x399491);}static['credentialFromError'](_0xf2cb9){return de['credentialFromTaggedObject'](_0xf2cb9['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4363e6}){if(!_0x4363e6)return null;const {oauthIdToken:_0x37c5c2,oauthAccessToken:_0x29d0d2}=_0x4363e6;if(!_0x37c5c2&&!_0x29d0d2)return null;try{return de['credential'](_0x37c5c2,_0x29d0d2);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x59be09){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x59be09});}static['credentialFromResult'](_0x5c2572){return fe['credentialFromTaggedObject'](_0x5c2572);}static['credentialFromError'](_0x3143fb){return fe['credentialFromTaggedObject'](_0x3143fb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb5ec7b}){if(!_0xb5ec7b||!('oauthAccessToken'in _0xb5ec7b)||!_0xb5ec7b['oauthAccessToken'])return null;try{return fe['credential'](_0xb5ec7b['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x5342e5,_0x19e1d4){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5342e5,'oauthTokenSecret':_0x19e1d4});}static['credentialFromResult'](_0x28e778){return pe['credentialFromTaggedObject'](_0x28e778);}static['credentialFromError'](_0x355c2d){return pe['credentialFromTaggedObject'](_0x355c2d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x7ac53b}){if(!_0x7ac53b)return null;const {oauthAccessToken:_0x599dd2,oauthTokenSecret:_0x21f534}=_0x7ac53b;if(!_0x599dd2||!_0x21f534)return null;try{return pe['credential'](_0x599dd2,_0x21f534);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3c2952,_0x48cbb4){return en(_0x3c2952,'POST','/v1/accounts:signUp',ke(_0x3c2952,_0x48cbb4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x1abae9){this['user']=_0x1abae9['user'],this['providerId']=_0x1abae9['providerId'],this['_tokenResponse']=_0x1abae9['_tokenResponse'],this['operationType']=_0x1abae9['operationType'];}static async['_fromIdTokenResponse'](_0x4db01e,_0xe9a362,_0x4992c0,_0x15280c=!0x1){const _0x15993c=await j['_fromIdTokenResponse'](_0x4db01e,_0x4992c0,_0x15280c),_0xba7cff=Nr(_0x4992c0);return new Ge({'user':_0x15993c,'providerId':_0xba7cff,'_tokenResponse':_0x4992c0,'operationType':_0xe9a362});}static async['_forOperation'](_0x3a1eba,_0x414786,_0x1f8c35){await _0x3a1eba['_updateTokensIfNecessary'](_0x1f8c35,!0x0);const _0x3a74e5=Nr(_0x1f8c35);return new Ge({'user':_0x3a1eba,'providerId':_0x3a74e5,'_tokenResponse':_0x1f8c35,'operationType':_0x414786});}}function Nr(_0x2468ba){return _0x2468ba['providerId']?_0x2468ba['providerId']:'phoneNumber'in _0x2468ba?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x5ca3be,_0x436c20,_0x1cc69c,_0x48475f){super(_0x436c20['code'],_0x436c20['message']),this['operationType']=_0x1cc69c,this['user']=_0x48475f,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x5ca3be['name'],'tenantId':_0x5ca3be['tenantId']??void 0x0,'_serverResponse':_0x436c20['customData']['_serverResponse'],'operationType':_0x1cc69c};}static['_fromErrorAndOperation'](_0xbf305e,_0x2ca459,_0x413e5d,_0x18ff6b){return new On(_0xbf305e,_0x2ca459,_0x413e5d,_0x18ff6b);}}function Ba(_0x4740f9,_0x201d8c,_0x9cde54,_0x7f4876){return(_0x201d8c==='reauthenticate'?_0x9cde54['_getReauthenticationResolver'](_0x4740f9):_0x9cde54['_getIdTokenResponse'](_0x4740f9))['catch'](_0x155d70=>{throw _0x155d70['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4740f9,_0x155d70,_0x201d8c,_0x7f4876):_0x155d70;});}async function ep(_0x1c9b08,_0x344bcf,_0x4d8bbb=!0x1){const _0x1b9b4e=await Ht(_0x1c9b08,_0x344bcf['_linkToIdToken'](_0x1c9b08['auth'],await _0x1c9b08['getIdToken']()),_0x4d8bbb);return Ge['_forOperation'](_0x1c9b08,'link',_0x1b9b4e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x2f7fdf,_0x370791,_0x1afca2=!0x1){const {auth:_0x15b48a}=_0x2f7fdf;if($(_0x15b48a['app']))return Promise['reject'](re(_0x15b48a));const _0x20840e='reauthenticate';try{const _0x516948=await Ht(_0x2f7fdf,Ba(_0x15b48a,_0x20840e,_0x370791,_0x2f7fdf),_0x1afca2);m(_0x516948['idToken'],_0x15b48a,'internal-error');const _0x29e2db=Ts(_0x516948['idToken']);m(_0x29e2db,_0x15b48a,'internal-error');const {sub:_0x5007d2}=_0x29e2db;return m(_0x2f7fdf['uid']===_0x5007d2,_0x15b48a,'user-mismatch'),Ge['_forOperation'](_0x2f7fdf,_0x20840e,_0x516948);}catch(_0x51a809){throw(_0x51a809==null?void 0x0:_0x51a809['code'])==='auth/user-not-found'&&Y(_0x15b48a,'user-mismatch'),_0x51a809;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x466d1d,_0x46cc2d,_0x47f5f3=!0x1){if($(_0x466d1d['app']))return Promise['reject'](re(_0x466d1d));const _0x1a4af2='signIn',_0x283835=await Ba(_0x466d1d,_0x1a4af2,_0x46cc2d),_0x4b1d2d=await Ge['_fromIdTokenResponse'](_0x466d1d,_0x1a4af2,_0x283835);return _0x47f5f3||await _0x466d1d['_updateCurrentUser'](_0x4b1d2d['user']),_0x4b1d2d;}async function np(_0x1ad8f7,_0x40af94){return Va(Ke(_0x1ad8f7),_0x40af94);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x3204b3){const _0x2211e8=Ke(_0x3204b3);_0x2211e8['_getPasswordPolicyInternal']()&&await _0x2211e8['_updatePasswordPolicy']();}async function L_(_0x3a1a80,_0x47db6b,_0x346eeb){if($(_0x3a1a80['app']))return Promise['reject'](re(_0x3a1a80));const _0x2d5c6c=Ke(_0x3a1a80),_0x434290=await xi(_0x2d5c6c,{'returnSecureToken':!0x0,'email':_0x47db6b,'password':_0x346eeb,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x5d330d=>{throw _0x5d330d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3a1a80),_0x5d330d;}),_0x596104=await Ge['_fromIdTokenResponse'](_0x2d5c6c,'signIn',_0x434290);return await _0x2d5c6c['_updateCurrentUser'](_0x596104['user']),_0x596104;}function x_(_0x2b42eb,_0x24667c,_0x5a516b){return $(_0x2b42eb['app'])?Promise['reject'](re(_0x2b42eb)):np(P(_0x2b42eb),yt['credential'](_0x24667c,_0x5a516b))['catch'](async _0x11d376=>{throw _0x11d376['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2b42eb),_0x11d376;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x36419b,_0x3bc069){return P(_0x36419b)['setPersistence'](_0x3bc069);}function ip(_0x20223b,_0x43a6c9,_0x4e9011,_0xe7898f){return P(_0x20223b)['onIdTokenChanged'](_0x43a6c9,_0x4e9011,_0xe7898f);}function sp(_0x3e50bf,_0x21b530,_0x5b47a0){return P(_0x3e50bf)['beforeAuthStateChanged'](_0x21b530,_0x5b47a0);}function U_(_0x44952d,_0x77d185,_0x356bbf,_0x50b7dc){return P(_0x44952d)['onAuthStateChanged'](_0x77d185,_0x356bbf,_0x50b7dc);}function W_(_0x7aac8f){return P(_0x7aac8f)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2f4cbb,_0x3f4acc){this['storageRetriever']=_0x2f4cbb,this['type']=_0x3f4acc;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x434589,_0x2e307b){return this['storage']['setItem'](_0x434589,JSON['stringify'](_0x2e307b)),Promise['resolve']();}['_get'](_0x3f19e5){const _0x46b223=this['storage']['getItem'](_0x3f19e5);return Promise['resolve'](_0x46b223?JSON['parse'](_0x46b223):null);}['_remove'](_0x23b1a0){return this['storage']['removeItem'](_0x23b1a0),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3aee66,_0x1a8ec8)=>this['onStorageEvent'](_0x3aee66,_0x1a8ec8),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5325a8){for(const _0x482bfc of Object['keys'](this['listeners'])){const _0x22ed13=this['storage']['getItem'](_0x482bfc),_0x42aa01=this['localCache'][_0x482bfc];_0x22ed13!==_0x42aa01&&_0x5325a8(_0x482bfc,_0x42aa01,_0x22ed13);}}['onStorageEvent'](_0xf980f4,_0x5ebc7e=!0x1){if(!_0xf980f4['key']){this['forAllChangedKeys']((_0x51b66b,_0x456c68,_0x24b328)=>{this['notifyListeners'](_0x51b66b,_0x24b328);});return;}const _0x33e5bf=_0xf980f4['key'];_0x5ebc7e?this['detachListener']():this['stopPolling']();const _0x5d31ef=()=>{const _0x46203f=this['storage']['getItem'](_0x33e5bf);!_0x5ebc7e&&this['localCache'][_0x33e5bf]===_0x46203f||this['notifyListeners'](_0x33e5bf,_0x46203f);},_0x27e0d1=this['storage']['getItem'](_0x33e5bf);Af()&&_0x27e0d1!==_0xf980f4['newValue']&&_0xf980f4['newValue']!==_0xf980f4['oldValue']?setTimeout(_0x5d31ef,op):_0x5d31ef();}['notifyListeners'](_0x5e9236,_0x11a2da){this['localCache'][_0x5e9236]=_0x11a2da;const _0x6cd852=this['listeners'][_0x5e9236];if(_0x6cd852){for(const _0x298860 of Array['from'](_0x6cd852))_0x298860(_0x11a2da&&JSON['parse'](_0x11a2da));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4e7a40,_0x25defe,_0xbe702c)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4e7a40,'oldValue':_0x25defe,'newValue':_0xbe702c}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x28120e,_0x5578b3){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x28120e]||(this['listeners'][_0x28120e]=new Set(),this['localCache'][_0x28120e]=this['storage']['getItem'](_0x28120e)),this['listeners'][_0x28120e]['add'](_0x5578b3);}['_removeListener'](_0x4a39b9,_0x2f3d25){this['listeners'][_0x4a39b9]&&(this['listeners'][_0x4a39b9]['delete'](_0x2f3d25),this['listeners'][_0x4a39b9]['size']===0x0&&delete this['listeners'][_0x4a39b9]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x24f480,_0x11e5eb){await super['_set'](_0x24f480,_0x11e5eb),this['localCache'][_0x24f480]=JSON['stringify'](_0x11e5eb);}async['_get'](_0x64b7e2){const _0xd82f7f=await super['_get'](_0x64b7e2);return this['localCache'][_0x64b7e2]=JSON['stringify'](_0xd82f7f),_0xd82f7f;}async['_remove'](_0x352372){await super['_remove'](_0x352372),delete this['localCache'][_0x352372];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x48edac,_0x450c61){}['_removeListener'](_0x486630,_0x4ecc0e){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x40db4f){return Promise['all'](_0x40db4f['map'](async _0x10cbed=>{try{return{'fulfilled':!0x0,'value':await _0x10cbed};}catch(_0x3c4c2f){return{'fulfilled':!0x1,'reason':_0x3c4c2f};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x58db61){this['eventTarget']=_0x58db61,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4ea1a4){const _0x321629=this['receivers']['find'](_0x5440b3=>_0x5440b3['isListeningto'](_0x4ea1a4));if(_0x321629)return _0x321629;const _0x482e37=new Xn(_0x4ea1a4);return this['receivers']['push'](_0x482e37),_0x482e37;}['isListeningto'](_0xb534e9){return this['eventTarget']===_0xb534e9;}async['handleEvent'](_0x3fbf41){const _0x423840=_0x3fbf41,{eventId:_0x113d06,eventType:_0x27c5cc,data:_0x3c8c03}=_0x423840['data'],_0x3b11ac=this['handlersMap'][_0x27c5cc];if(!(_0x3b11ac!=null&&_0x3b11ac['size']))return;_0x423840['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x113d06,'eventType':_0x27c5cc});const _0x520ac6=Array['from'](_0x3b11ac)['map'](async _0x57f01a=>_0x57f01a(_0x423840['origin'],_0x3c8c03)),_0x52b919=await cp(_0x520ac6);_0x423840['ports'][0x0]['postMessage']({'status':'done','eventId':_0x113d06,'eventType':_0x27c5cc,'response':_0x52b919});}['_subscribe'](_0x5213b2,_0x2a68f9){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5213b2]||(this['handlersMap'][_0x5213b2]=new Set()),this['handlersMap'][_0x5213b2]['add'](_0x2a68f9);}['_unsubscribe'](_0x1ab4c6,_0x5b60f0){this['handlersMap'][_0x1ab4c6]&&_0x5b60f0&&this['handlersMap'][_0x1ab4c6]['delete'](_0x5b60f0),(!_0x5b60f0||this['handlersMap'][_0x1ab4c6]['size']===0x0)&&delete this['handlersMap'][_0x1ab4c6],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5792ed='',_0x4652c5=0xa){let _0x15cbbc='';for(let _0x3aacad=0x0;_0x3aacad<_0x4652c5;_0x3aacad++)_0x15cbbc+=Math['floor'](Math['random']()*0xa);return _0x5792ed+_0x15cbbc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x13f107){this['target']=_0x13f107,this['handlers']=new Set();}['removeMessageHandler'](_0x451944){_0x451944['messageChannel']&&(_0x451944['messageChannel']['port1']['removeEventListener']('message',_0x451944['onMessage']),_0x451944['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x451944);}async['_send'](_0x4bcfe6,_0x3f170a,_0x108c94=0x32){const _0x2a2e0a=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2a2e0a)throw new Error('connection_unavailable');let _0x1e06cd,_0x55acb1;return new Promise((_0x5f1f4b,_0xf5a9f6)=>{const _0x2d3824=As('',0x14);_0x2a2e0a['port1']['start']();const _0x27b180=setTimeout(()=>{_0xf5a9f6(new Error('unsupported_event'));},_0x108c94);_0x55acb1={'messageChannel':_0x2a2e0a,'onMessage'(_0x401849){const _0x3215cc=_0x401849;if(_0x3215cc['data']['eventId']===_0x2d3824)switch(_0x3215cc['data']['status']){case'ack':clearTimeout(_0x27b180),_0x1e06cd=setTimeout(()=>{_0xf5a9f6(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1e06cd),_0x5f1f4b(_0x3215cc['data']['response']);break;default:clearTimeout(_0x27b180),clearTimeout(_0x1e06cd),_0xf5a9f6(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x55acb1),_0x2a2e0a['port1']['addEventListener']('message',_0x55acb1['onMessage']),this['target']['postMessage']({'eventType':_0x4bcfe6,'eventId':_0x2d3824,'data':_0x3f170a},[_0x2a2e0a['port2']]);})['finally'](()=>{_0x55acb1&&this['removeMessageHandler'](_0x55acb1);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x42b43d){Z()['location']['href']=_0x42b43d;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2959df;return((_0x2959df=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2959df['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x5cbe6f){this['request']=_0x5cbe6f;}['toPromise'](){return new Promise((_0x27d221,_0x20bd46)=>{this['request']['addEventListener']('success',()=>{_0x27d221(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x20bd46(this['request']['error']);});});}}function Zn(_0x493200,_0x223073){return _0x493200['transaction']([Mn],_0x223073?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x26183c=indexedDB['deleteDatabase'](Ka);return new nn(_0x26183c)['toPromise']();}function Qa(){const _0x5e210b=indexedDB['open'](Ka,pp);return new Promise((_0x1fa4b9,_0x177633)=>{_0x5e210b['addEventListener']('error',()=>{_0x177633(_0x5e210b['error']);}),_0x5e210b['addEventListener']('upgradeneeded',()=>{const _0x110104=_0x5e210b['result'];try{_0x110104['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x5f09e6){_0x177633(_0x5f09e6);}}),_0x5e210b['addEventListener']('success',async()=>{const _0x3593c6=_0x5e210b['result'];_0x3593c6['objectStoreNames']['contains'](Mn)?_0x1fa4b9(_0x3593c6):(_0x3593c6['close'](),await _p(),_0x1fa4b9(await Qa()));});});}async function Or(_0x23edec,_0x256f7b,_0x49534c){const _0x50a2c6=Zn(_0x23edec,!0x0)['put']({[Ya]:_0x256f7b,'value':_0x49534c});return new nn(_0x50a2c6)['toPromise']();}async function gp(_0x4ffcb7,_0x3b4fb6){const _0xf43aca=Zn(_0x4ffcb7,!0x1)['get'](_0x3b4fb6),_0xac4e03=await new nn(_0xf43aca)['toPromise']();return _0xac4e03===void 0x0?null:_0xac4e03['value'];}function Dr(_0x3f4776,_0x3b82f8){const _0x2dc580=Zn(_0x3f4776,!0x0)['delete'](_0x3b82f8);return new nn(_0x2dc580)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x53395f){let _0x2ee893=0x0;for(;;)try{const _0x1b5a62=await this['_openDb']();return await _0x53395f(_0x1b5a62);}catch(_0x4df490){if(_0x2ee893++>yp)throw _0x4df490;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x14b79c,_0x11737b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x11737b['key'])})),this['receiver']['_subscribe']('ping',async(_0x2922cb,_0x37b8d8)=>['keyChanged']);}async['initializeSender'](){var _0x140d31,_0x21744d;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x338986=await this['sender']['_send']('ping',{},0x320);_0x338986&&(_0x140d31=_0x338986[0x0])!=null&&_0x140d31['fulfilled']&&(_0x21744d=_0x338986[0x0])!=null&&_0x21744d['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xcdaa61){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xcdaa61},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x38d28c=>{await Or(_0x38d28c,Dn,'1'),await Dr(_0x38d28c,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x420ee9){this['pendingWrites']++;try{await _0x420ee9();}finally{this['pendingWrites']--;}}async['_set'](_0x3cf14c,_0x3b01ef){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x117658=>Or(_0x117658,_0x3cf14c,_0x3b01ef)),this['localCache'][_0x3cf14c]=_0x3b01ef,this['notifyServiceWorker'](_0x3cf14c)));}async['_get'](_0x35e1ff){const _0x8062fc=await this['_withRetries'](_0x4aea51=>gp(_0x4aea51,_0x35e1ff));return this['localCache'][_0x35e1ff]=_0x8062fc,_0x8062fc;}async['_remove'](_0x574026){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2bdc40=>Dr(_0x2bdc40,_0x574026)),delete this['localCache'][_0x574026],this['notifyServiceWorker'](_0x574026)));}async['_poll'](){const _0x4af728=await this['_withRetries'](_0x265bdc=>{const _0xe05c37=Zn(_0x265bdc,!0x1)['getAll']();return new nn(_0xe05c37)['toPromise']();});if(!_0x4af728)return[];if(this['pendingWrites']!==0x0)return[];const _0x29a56f=[],_0x2907fb=new Set();if(_0x4af728['length']!==0x0){for(const {fbase_key:_0x12adef,value:_0xe2ec04}of _0x4af728)_0x2907fb['add'](_0x12adef),JSON['stringify'](this['localCache'][_0x12adef])!==JSON['stringify'](_0xe2ec04)&&(this['notifyListeners'](_0x12adef,_0xe2ec04),_0x29a56f['push'](_0x12adef));}for(const _0x2d543a of Object['keys'](this['localCache']))this['localCache'][_0x2d543a]&&!_0x2907fb['has'](_0x2d543a)&&(this['notifyListeners'](_0x2d543a,null),_0x29a56f['push'](_0x2d543a));return _0x29a56f;}['notifyListeners'](_0x1c78ba,_0x3b8bb7){this['localCache'][_0x1c78ba]=_0x3b8bb7;const _0x2e1804=this['listeners'][_0x1c78ba];if(_0x2e1804){for(const _0x653b13 of Array['from'](_0x2e1804))_0x653b13(_0x3b8bb7);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x212b42,_0x4db9af){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x212b42]||(this['listeners'][_0x212b42]=new Set(),this['_get'](_0x212b42)),this['listeners'][_0x212b42]['add'](_0x4db9af);}['_removeListener'](_0x572e42,_0x56763e){this['listeners'][_0x572e42]&&(this['listeners'][_0x572e42]['delete'](_0x56763e),this['listeners'][_0x572e42]['size']===0x0&&delete this['listeners'][_0x572e42]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x4478ca,_0x3b3e85){return _0x3b3e85?ie(_0x3b3e85):(m(_0x4478ca['_popupRedirectResolver'],_0x4478ca,'argument-error'),_0x4478ca['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0xc8e325){super('custom','custom'),this['params']=_0xc8e325;}['_getIdTokenResponse'](_0x4b475c){return nt(_0x4b475c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1bde98,_0x49f409){return nt(_0x1bde98,this['_buildIdpRequest'](_0x49f409));}['_getReauthenticationResolver'](_0x1e0332){return nt(_0x1e0332,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3a3447){const _0x3403c5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3a3447&&(_0x3403c5['idToken']=_0x3a3447),_0x3403c5;}}function Ip(_0x188302){return Va(_0x188302['auth'],new ks(_0x188302),_0x188302['bypassAuthState']);}function wp(_0x3b993d){const {auth:_0x1b5f54,user:_0x5a61a8}=_0x3b993d;return m(_0x5a61a8,_0x1b5f54,'internal-error'),tp(_0x5a61a8,new ks(_0x3b993d),_0x3b993d['bypassAuthState']);}async function Cp(_0x434661){const {auth:_0x229d2f,user:_0x15e93a}=_0x434661;return m(_0x15e93a,_0x229d2f,'internal-error'),ep(_0x15e93a,new ks(_0x434661),_0x434661['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x80ce83,_0x1422d6,_0x43264d,_0x11e70d,_0x38f9ab=!0x1){this['auth']=_0x80ce83,this['resolver']=_0x43264d,this['user']=_0x11e70d,this['bypassAuthState']=_0x38f9ab,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1422d6)?_0x1422d6:[_0x1422d6];}['execute'](){return new Promise(async(_0x144d8c,_0x1a4d16)=>{this['pendingPromise']={'resolve':_0x144d8c,'reject':_0x1a4d16};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2c8f76){this['reject'](_0x2c8f76);}});}async['onAuthEvent'](_0x514a7f){const {urlResponse:_0x146ea7,sessionId:_0x186d22,postBody:_0x487426,tenantId:_0x5c53ba,error:_0x57213e,type:_0x2d93e3}=_0x514a7f;if(_0x57213e){this['reject'](_0x57213e);return;}const _0x3b3bfb={'auth':this['auth'],'requestUri':_0x146ea7,'sessionId':_0x186d22,'tenantId':_0x5c53ba||void 0x0,'postBody':_0x487426||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2d93e3)(_0x3b3bfb));}catch(_0x31c4de){this['reject'](_0x31c4de);}}['onError'](_0x38d576){this['reject'](_0x38d576);}['getIdpTask'](_0x561fd7){switch(_0x561fd7){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x742676){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x742676),this['unregisterAndCleanUp']();}['reject'](_0x3eb584){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3eb584),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x8ae4ca,_0x3e5423,_0x483df3,_0x30e938,_0x52bbd0){super(_0x8ae4ca,_0x3e5423,_0x30e938,_0x52bbd0),this['provider']=_0x483df3,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x65e02c=await this['execute']();return m(_0x65e02c,this['auth'],'internal-error'),_0x65e02c;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x158e4e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x158e4e),this['authWindow']['associatedEvent']=_0x158e4e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x58d90f=>{this['reject'](_0x58d90f);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x6907d=>{_0x6907d||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x196ff3;return((_0x196ff3=this['authWindow'])==null?void 0x0:_0x196ff3['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3623d5=()=>{var _0x11cb11,_0x191dd2;if((_0x191dd2=(_0x11cb11=this['authWindow'])==null?void 0x0:_0x11cb11['window'])!=null&&_0x191dd2['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3623d5,Tp['get']());};_0x3623d5();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x5e5bc1,_0x3b4649,_0x10872b=!0x1){super(_0x5e5bc1,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3b4649,void 0x0,_0x10872b),this['eventId']=null;}async['execute'](){let _0x5ce38d=hn['get'](this['auth']['_key']());if(!_0x5ce38d){try{const _0x4dd920=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x5ce38d=()=>Promise['resolve'](_0x4dd920);}catch(_0x37fa76){_0x5ce38d=()=>Promise['reject'](_0x37fa76);}hn['set'](this['auth']['_key'](),_0x5ce38d);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5ce38d();}async['onAuthEvent'](_0x20b7d0){if(_0x20b7d0['type']==='signInViaRedirect')return super['onAuthEvent'](_0x20b7d0);if(_0x20b7d0['type']==='unknown'){this['resolve'](null);return;}if(_0x20b7d0['eventId']){const _0x24cf3a=await this['auth']['_redirectUserForId'](_0x20b7d0['eventId']);if(_0x24cf3a)return this['user']=_0x24cf3a,super['onAuthEvent'](_0x20b7d0);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4e881c,_0x37ed2e){const _0x25d3f1=Pp(_0x37ed2e),_0x8699ae=kp(_0x4e881c);if(!await _0x8699ae['_isAvailable']())return!0x1;const _0x599184=await _0x8699ae['_get'](_0x25d3f1)==='true';return await _0x8699ae['_remove'](_0x25d3f1),_0x599184;}function Ap(_0x2841e9,_0x1dc30a){hn['set'](_0x2841e9['_key'](),_0x1dc30a);}function kp(_0x2cf29e){return ie(_0x2cf29e['_redirectPersistence']);}function Pp(_0x3d6b85){return ln(Sp,_0x3d6b85['config']['apiKey'],_0x3d6b85['name']);}async function Np(_0x2d4ef5,_0x9fe345,_0x31db23=!0x1){if($(_0x2d4ef5['app']))return Promise['reject'](re(_0x2d4ef5));const _0x2738ac=Ke(_0x2d4ef5),_0x3a257f=Ep(_0x2738ac,_0x9fe345),_0x3b04f8=await new bp(_0x2738ac,_0x3a257f,_0x31db23)['execute']();return _0x3b04f8&&!_0x31db23&&(delete _0x3b04f8['user']['_redirectEventId'],await _0x2738ac['_persistUserIfCurrent'](_0x3b04f8['user']),await _0x2738ac['_setRedirectUser'](null,_0x9fe345)),_0x3b04f8;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x5717ea){this['auth']=_0x5717ea,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x368848){this['consumers']['add'](_0x368848),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x368848)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x368848),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3ef148){this['consumers']['delete'](_0x3ef148);}['onEvent'](_0x3c4136){if(this['hasEventBeenHandled'](_0x3c4136))return!0x1;let _0x22213f=!0x1;return this['consumers']['forEach'](_0x33cabc=>{this['isEventForConsumer'](_0x3c4136,_0x33cabc)&&(_0x22213f=!0x0,this['sendToConsumer'](_0x3c4136,_0x33cabc),this['saveEventToCache'](_0x3c4136));}),this['hasHandledPotentialRedirect']||!Mp(_0x3c4136)||(this['hasHandledPotentialRedirect']=!0x0,_0x22213f||(this['queuedRedirectEvent']=_0x3c4136,_0x22213f=!0x0)),_0x22213f;}['sendToConsumer'](_0x175fdf,_0x19aec4){var _0x13571b;if(_0x175fdf['error']&&!Za(_0x175fdf)){const _0x160d1f=((_0x13571b=_0x175fdf['error']['code'])==null?void 0x0:_0x13571b['split']('auth/')[0x1])||'internal-error';_0x19aec4['onError'](X(this['auth'],_0x160d1f));}else _0x19aec4['onAuthEvent'](_0x175fdf);}['isEventForConsumer'](_0x53b483,_0x33b566){const _0x96c459=_0x33b566['eventId']===null||!!_0x53b483['eventId']&&_0x53b483['eventId']===_0x33b566['eventId'];return _0x33b566['filter']['includes'](_0x53b483['type'])&&_0x96c459;}['hasEventBeenHandled'](_0x401f98){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x401f98));}['saveEventToCache'](_0x4c3495){this['cachedEventUids']['add'](Mr(_0x4c3495)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x5b17b5){return[_0x5b17b5['type'],_0x5b17b5['eventId'],_0x5b17b5['sessionId'],_0x5b17b5['tenantId']]['filter'](_0x20fe3c=>_0x20fe3c)['join']('-');}function Za({type:_0x28aef9,error:_0x2e1659}){return _0x28aef9==='unknown'&&(_0x2e1659==null?void 0x0:_0x2e1659['code'])==='auth/no-auth-event';}function Mp(_0x53c7cf){switch(_0x53c7cf['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x53c7cf);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0xd2fe0f,_0x4c2ac4={}){return Pe(_0xd2fe0f,'GET','/v1/projects',_0x4c2ac4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0xaef813){if(_0xaef813['config']['emulator'])return;const {authorizedDomains:_0xaf0db}=await Lp(_0xaef813);for(const _0x3d4ad9 of _0xaf0db)try{if(Wp(_0x3d4ad9))return;}catch{}Y(_0xaef813,'unauthorized-domain');}function Wp(_0x549b93){const _0x465468=Mi(),{protocol:_0xc5ed3,hostname:_0xb3826e}=new URL(_0x465468);if(_0x549b93['startsWith']('chrome-extension://')){const _0x2aa4f4=new URL(_0x549b93);return _0x2aa4f4['hostname']===''&&_0xb3826e===''?_0xc5ed3==='chrome-extension:'&&_0x549b93['replace']('chrome-extension://','')===_0x465468['replace']('chrome-extension://',''):_0xc5ed3==='chrome-extension:'&&_0x2aa4f4['hostname']===_0xb3826e;}if(!Fp['test'](_0xc5ed3))return!0x1;if(xp['test'](_0x549b93))return _0xb3826e===_0x549b93;const _0x497a17=_0x549b93['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x497a17+'|'+_0x497a17+')$','i')['test'](_0xb3826e);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x37ed68=Z()['___jsl'];if(_0x37ed68!=null&&_0x37ed68['H']){for(const _0x55bb89 of Object['keys'](_0x37ed68['H']))if(_0x37ed68['H'][_0x55bb89]['r']=_0x37ed68['H'][_0x55bb89]['r']||[],_0x37ed68['H'][_0x55bb89]['L']=_0x37ed68['H'][_0x55bb89]['L']||[],_0x37ed68['H'][_0x55bb89]['r']=[..._0x37ed68['H'][_0x55bb89]['L']],_0x37ed68['CP']){for(let _0x3bedbb=0x0;_0x3bedbb<_0x37ed68['CP']['length'];_0x3bedbb++)_0x37ed68['CP'][_0x3bedbb]=null;}}}function Vp(_0x5b667b){return new Promise((_0x40030a,_0xf575db)=>{var _0x22b935,_0x4b0faf,_0x38b38a;function _0x528c0c(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x40030a(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0xf575db(X(_0x5b667b,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4b0faf=(_0x22b935=Z()['gapi'])==null?void 0x0:_0x22b935['iframes'])!=null&&_0x4b0faf['Iframe'])_0x40030a(gapi['iframes']['getContext']());else{if((_0x38b38a=Z()['gapi'])!=null&&_0x38b38a['load'])_0x528c0c();else{const _0x400494=Ff('iframefcb');return Z()[_0x400494]=()=>{gapi['load']?_0x528c0c():_0xf575db(X(_0x5b667b,'network-request-failed'));},xa(xf()+'?onload='+_0x400494)['catch'](_0x230318=>_0xf575db(_0x230318));}}})['catch'](_0x5a38da=>{throw un=null,_0x5a38da;});}let un=null;function Hp(_0x3026d3){return un=un||Vp(_0x3026d3),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1623c0){const _0x38e53d=_0x1623c0['config'];m(_0x38e53d['authDomain'],_0x1623c0,'auth-domain-config-required');const _0x442e3f=_0x38e53d['emulator']?Cs(_0x38e53d,qp):'https://'+_0x1623c0['config']['authDomain']+'/'+Gp,_0x2deb12={'apiKey':_0x38e53d['apiKey'],'appName':_0x1623c0['name'],'v':dt},_0x4ac2af=jp['get'](_0x1623c0['config']['apiHost']);_0x4ac2af&&(_0x2deb12['eid']=_0x4ac2af);const _0x524374=_0x1623c0['_getFrameworks']();return _0x524374['length']&&(_0x2deb12['fw']=_0x524374['join'](',')),_0x442e3f+'?'+ut(_0x2deb12)['slice'](0x1);}async function Yp(_0x10eee3){const _0x5be71b=await Hp(_0x10eee3),_0x516cd5=Z()['gapi'];return m(_0x516cd5,_0x10eee3,'internal-error'),_0x5be71b['open']({'where':document['body'],'url':Kp(_0x10eee3),'messageHandlersFilter':_0x516cd5['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x302124=>new Promise(async(_0x1f3d7e,_0x5c66fc)=>{await _0x302124['restyle']({'setHideOnLeave':!0x1});const _0x26f16d=X(_0x10eee3,'network-request-failed'),_0x8e579b=Z()['setTimeout'](()=>{_0x5c66fc(_0x26f16d);},$p['get']());function _0x30d914(){Z()['clearTimeout'](_0x8e579b),_0x1f3d7e(_0x302124);}_0x302124['ping'](_0x30d914)['then'](_0x30d914,()=>{_0x5c66fc(_0x26f16d);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x214b84){this['window']=_0x214b84,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x52ab90,_0x23ea3f,_0x315548,_0x4588af=Jp,_0x552d9d=Xp){const _0x78b5fe=Math['max']((window['screen']['availHeight']-_0x552d9d)/0x2,0x0)['toString'](),_0x4bae1b=Math['max']((window['screen']['availWidth']-_0x4588af)/0x2,0x0)['toString']();let _0x3ef2be='';const _0x5877c2={...Qp,'width':_0x4588af['toString'](),'height':_0x552d9d['toString'](),'top':_0x78b5fe,'left':_0x4bae1b},_0x41d58c=W()['toLowerCase']();_0x315548&&(_0x3ef2be=ka(_0x41d58c)?Zp:_0x315548),Ra(_0x41d58c)&&(_0x23ea3f=_0x23ea3f||e_,_0x5877c2['scrollbars']='yes');const _0x33eec4=Object['entries'](_0x5877c2)['reduce']((_0x3a507b,[_0x5d9ab1,_0x521caf])=>''+_0x3a507b+_0x5d9ab1+'='+_0x521caf+',','');if(Rf(_0x41d58c)&&_0x3ef2be!=='_self')return n_(_0x23ea3f||'',_0x3ef2be),new xr(null);const _0x4e47a1=window['open'](_0x23ea3f||'',_0x3ef2be,_0x33eec4);m(_0x4e47a1,_0x52ab90,'popup-blocked');try{_0x4e47a1['focus']();}catch{}return new xr(_0x4e47a1);}function n_(_0x56974a,_0x392ba5){const _0x2ef6b6=document['createElement']('a');_0x2ef6b6['href']=_0x56974a,_0x2ef6b6['target']=_0x392ba5;const _0x2a4717=document['createEvent']('MouseEvent');_0x2a4717['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2ef6b6['dispatchEvent'](_0x2a4717);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x1160a8,_0x24a8eb,_0x3523f5,_0x16677b,_0x28846c,_0x223f58){m(_0x1160a8['config']['authDomain'],_0x1160a8,'auth-domain-config-required'),m(_0x1160a8['config']['apiKey'],_0x1160a8,'invalid-api-key');const _0x514582={'apiKey':_0x1160a8['config']['apiKey'],'appName':_0x1160a8['name'],'authType':_0x3523f5,'redirectUrl':_0x16677b,'v':dt,'eventId':_0x28846c};if(_0x24a8eb instanceof Wa){_0x24a8eb['setDefaultLanguage'](_0x1160a8['languageCode']),_0x514582['providerId']=_0x24a8eb['providerId']||'',pn(_0x24a8eb['getCustomParameters']())||(_0x514582['customParameters']=JSON['stringify'](_0x24a8eb['getCustomParameters']()));for(const [_0x391ac4,_0x5a556b]of Object['entries']({}))_0x514582[_0x391ac4]=_0x5a556b;}if(_0x24a8eb instanceof tn){const _0x39df09=_0x24a8eb['getScopes']()['filter'](_0x35626a=>_0x35626a!=='');_0x39df09['length']>0x0&&(_0x514582['scopes']=_0x39df09['join'](','));}_0x1160a8['tenantId']&&(_0x514582['tid']=_0x1160a8['tenantId']);const _0x11ec5f=_0x514582;for(const _0x3129ed of Object['keys'](_0x11ec5f))_0x11ec5f[_0x3129ed]===void 0x0&&delete _0x11ec5f[_0x3129ed];const _0x530833=await _0x1160a8['_getAppCheckToken'](),_0x5242bf=_0x530833?'#'+r_+'='+encodeURIComponent(_0x530833):'';return o_(_0x1160a8)+'?'+ut(_0x11ec5f)['slice'](0x1)+_0x5242bf;}function o_({config:_0x310415}){return _0x310415['emulator']?Cs(_0x310415,s_):'https://'+_0x310415['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xd75e9f,_0x461f77,_0xfdfe66,_0x3d38c5){var _0x1c95bf;ce((_0x1c95bf=this['eventManagers'][_0xd75e9f['_key']()])==null?void 0x0:_0x1c95bf['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x17f592=await Fr(_0xd75e9f,_0x461f77,_0xfdfe66,Mi(),_0x3d38c5);return t_(_0xd75e9f,_0x17f592,As());}async['_openRedirect'](_0x2812c6,_0x299365,_0x52b581,_0x100547){await this['_originValidation'](_0x2812c6);const _0x1e0ed5=await Fr(_0x2812c6,_0x299365,_0x52b581,Mi(),_0x100547);return hp(_0x1e0ed5),new Promise(()=>{});}['_initialize'](_0x3d3573){const _0x1f2426=_0x3d3573['_key']();if(this['eventManagers'][_0x1f2426]){const {manager:_0x438ccb,promise:_0x41f3f4}=this['eventManagers'][_0x1f2426];return _0x438ccb?Promise['resolve'](_0x438ccb):(ce(_0x41f3f4,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x41f3f4);}const _0x2d2dae=this['initAndGetManager'](_0x3d3573);return this['eventManagers'][_0x1f2426]={'promise':_0x2d2dae},_0x2d2dae['catch'](()=>{delete this['eventManagers'][_0x1f2426];}),_0x2d2dae;}async['initAndGetManager'](_0x275546){const _0x1ae0bd=await Yp(_0x275546),_0x32b867=new Dp(_0x275546);return _0x1ae0bd['register']('authEvent',_0xdc6d3b=>(m(_0xdc6d3b==null?void 0x0:_0xdc6d3b['authEvent'],_0x275546,'invalid-auth-event'),{'status':_0x32b867['onEvent'](_0xdc6d3b['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x275546['_key']()]={'manager':_0x32b867},this['iframes'][_0x275546['_key']()]=_0x1ae0bd,_0x32b867;}['_isIframeWebStorageSupported'](_0x2f593f,_0x1b3d29){this['iframes'][_0x2f593f['_key']()]['send'](pi,{'type':pi},_0x58d9c8=>{var _0x7acc05;const _0x5985b3=(_0x7acc05=_0x58d9c8==null?void 0x0:_0x58d9c8[0x0])==null?void 0x0:_0x7acc05[pi];_0x5985b3!==void 0x0&&_0x1b3d29(!!_0x5985b3),Y(_0x2f593f,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x17575d){const _0x1da16c=_0x17575d['_key']();return this['originValidationPromises'][_0x1da16c]||(this['originValidationPromises'][_0x1da16c]=Up(_0x17575d)),this['originValidationPromises'][_0x1da16c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x135142){this['auth']=_0x135142,this['internalListeners']=new Map();}['getUid'](){var _0x27b5ba;return this['assertAuthConfigured'](),((_0x27b5ba=this['auth']['currentUser'])==null?void 0x0:_0x27b5ba['uid'])||null;}async['getToken'](_0x44ffa8){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x44ffa8)}:null;}['addAuthTokenListener'](_0x49a6c5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x49a6c5))return;const _0x39ac0b=this['auth']['onIdTokenChanged'](_0x2d62a5=>{_0x49a6c5((_0x2d62a5==null?void 0x0:_0x2d62a5['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x49a6c5,_0x39ac0b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3c3133){this['assertAuthConfigured']();const _0x1afe8c=this['internalListeners']['get'](_0x3c3133);_0x1afe8c&&(this['internalListeners']['delete'](_0x3c3133),_0x1afe8c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x22581b){switch(_0x22581b){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5b1757){st(new Fe('auth',(_0x3394fa,{options:_0x1f4aa6})=>{const _0xd4af82=_0x3394fa['getProvider']('app')['getImmediate'](),_0x199796=_0x3394fa['getProvider']('heartbeat'),_0x109325=_0x3394fa['getProvider']('app-check-internal'),{apiKey:_0x5c74c4,authDomain:_0xa1b6ac}=_0xd4af82['options'];m(_0x5c74c4&&!_0x5c74c4['includes'](':'),'invalid-api-key',{'appName':_0xd4af82['name']});const _0x368f6e={'apiKey':_0x5c74c4,'authDomain':_0xa1b6ac,'clientPlatform':_0x5b1757,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5b1757)},_0x5f221c=new Df(_0xd4af82,_0x199796,_0x109325,_0x368f6e);return Hf(_0x5f221c,_0x1f4aa6),_0x5f221c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x2958d2,_0x259440,_0x1b2b6a)=>{_0x2958d2['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x1fb6d2=>{const _0x306ea5=Ke(_0x1fb6d2['getProvider']('auth')['getImmediate']());return(_0x38b0ee=>new l_(_0x38b0ee))(_0x306ea5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5b1757)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x13b361=>async _0x4dba82=>{const _0x441678=_0x4dba82&&await _0x4dba82['getIdTokenResult'](),_0x2b24b9=_0x441678&&(new Date()['getTime']()-Date['parse'](_0x441678['issuedAtTime']))/0x3e8;if(_0x2b24b9&&_0x2b24b9>f_)return;const _0x22318c=_0x441678==null?void 0x0:_0x441678['token'];Br!==_0x22318c&&(Br=_0x22318c,await fetch(_0x13b361,{'method':_0x22318c?'POST':'DELETE','headers':_0x22318c?{'Authorization':'Bearer\x20'+_0x22318c}:{}}));};function B_(_0x150223=Zr()){const _0x161805=Hi(_0x150223,'auth');if(_0x161805['isInitialized']())return _0x161805['getImmediate']();const _0x1a5ca8=Vf(_0x150223,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x482cdf=jr('authTokenSyncURL');if(_0x482cdf&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x43468f=new URL(_0x482cdf,location['origin']);if(location['origin']===_0x43468f['origin']){const _0x238d36=p_(_0x43468f['toString']());sp(_0x1a5ca8,_0x238d36,()=>_0x238d36(_0x1a5ca8['currentUser'])),ip(_0x1a5ca8,_0xad1106=>_0x238d36(_0xad1106));}}const _0x3758cb=qr('auth');return _0x3758cb&&$f(_0x1a5ca8,'http://'+_0x3758cb),_0x1a5ca8;}function __(){var _0x534352;return((_0x534352=document['getElementsByTagName']('head'))==null?void 0x0:_0x534352[0x0])??document;}Mf({'loadJS'(_0x392cf0){return new Promise((_0x4e05f2,_0x15ee08)=>{const _0x10b5bb=document['createElement']('script');_0x10b5bb['setAttribute']('src',_0x392cf0),_0x10b5bb['onload']=_0x4e05f2,_0x10b5bb['onerror']=_0x177735=>{const _0x228f7f=X('internal-error');_0x228f7f['customData']=_0x177735,_0x15ee08(_0x228f7f);},_0x10b5bb['type']='text/javascript',_0x10b5bb['charset']='UTF-8',__()['appendChild'](_0x10b5bb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};