const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x521970,_0x50cb44){if(!_0x521970)throw ht(_0x50cb44);},ht=function(_0x33bfc1){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x33bfc1);},Hr=function(_0x4cc6e5){const _0x294620=[];let _0x35986b=0x0;for(let _0x43cf5e=0x0;_0x43cf5e<_0x4cc6e5['length'];_0x43cf5e++){let _0x2aa3ab=_0x4cc6e5['charCodeAt'](_0x43cf5e);_0x2aa3ab<0x80?_0x294620[_0x35986b++]=_0x2aa3ab:_0x2aa3ab<0x800?(_0x294620[_0x35986b++]=_0x2aa3ab>>0x6|0xc0,_0x294620[_0x35986b++]=_0x2aa3ab&0x3f|0x80):(_0x2aa3ab&0xfc00)===0xd800&&_0x43cf5e+0x1<_0x4cc6e5['length']&&(_0x4cc6e5['charCodeAt'](_0x43cf5e+0x1)&0xfc00)===0xdc00?(_0x2aa3ab=0x10000+((_0x2aa3ab&0x3ff)<<0xa)+(_0x4cc6e5['charCodeAt'](++_0x43cf5e)&0x3ff),_0x294620[_0x35986b++]=_0x2aa3ab>>0x12|0xf0,_0x294620[_0x35986b++]=_0x2aa3ab>>0xc&0x3f|0x80,_0x294620[_0x35986b++]=_0x2aa3ab>>0x6&0x3f|0x80,_0x294620[_0x35986b++]=_0x2aa3ab&0x3f|0x80):(_0x294620[_0x35986b++]=_0x2aa3ab>>0xc|0xe0,_0x294620[_0x35986b++]=_0x2aa3ab>>0x6&0x3f|0x80,_0x294620[_0x35986b++]=_0x2aa3ab&0x3f|0x80);}return _0x294620;},nc=function(_0xb77fec){const _0x22dc03=[];let _0x28e057=0x0,_0x294124=0x0;for(;_0x28e057<_0xb77fec['length'];){const _0x198612=_0xb77fec[_0x28e057++];if(_0x198612<0x80)_0x22dc03[_0x294124++]=String['fromCharCode'](_0x198612);else{if(_0x198612>0xbf&&_0x198612<0xe0){const _0x3d1d79=_0xb77fec[_0x28e057++];_0x22dc03[_0x294124++]=String['fromCharCode']((_0x198612&0x1f)<<0x6|_0x3d1d79&0x3f);}else{if(_0x198612>0xef&&_0x198612<0x16d){const _0x24282f=_0xb77fec[_0x28e057++],_0x1ee8dd=_0xb77fec[_0x28e057++],_0x334490=_0xb77fec[_0x28e057++],_0x4de3f0=((_0x198612&0x7)<<0x12|(_0x24282f&0x3f)<<0xc|(_0x1ee8dd&0x3f)<<0x6|_0x334490&0x3f)-0x10000;_0x22dc03[_0x294124++]=String['fromCharCode'](0xd800+(_0x4de3f0>>0xa)),_0x22dc03[_0x294124++]=String['fromCharCode'](0xdc00+(_0x4de3f0&0x3ff));}else{const _0x3644ba=_0xb77fec[_0x28e057++],_0x4ab67e=_0xb77fec[_0x28e057++];_0x22dc03[_0x294124++]=String['fromCharCode']((_0x198612&0xf)<<0xc|(_0x3644ba&0x3f)<<0x6|_0x4ab67e&0x3f);}}}}return _0x22dc03['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x386b70,_0x1f0ca9){if(!Array['isArray'](_0x386b70))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2e1f58=_0x1f0ca9?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x53d0e1=[];for(let _0x6d0ac5=0x0;_0x6d0ac5<_0x386b70['length'];_0x6d0ac5+=0x3){const _0x2a8582=_0x386b70[_0x6d0ac5],_0x975a2d=_0x6d0ac5+0x1<_0x386b70['length'],_0x11a5a3=_0x975a2d?_0x386b70[_0x6d0ac5+0x1]:0x0,_0x4ae273=_0x6d0ac5+0x2<_0x386b70['length'],_0x25f505=_0x4ae273?_0x386b70[_0x6d0ac5+0x2]:0x0,_0x462807=_0x2a8582>>0x2,_0x24b930=(_0x2a8582&0x3)<<0x4|_0x11a5a3>>0x4;let _0x523218=(_0x11a5a3&0xf)<<0x2|_0x25f505>>0x6,_0x117440=_0x25f505&0x3f;_0x4ae273||(_0x117440=0x40,_0x975a2d||(_0x523218=0x40)),_0x53d0e1['push'](_0x2e1f58[_0x462807],_0x2e1f58[_0x24b930],_0x2e1f58[_0x523218],_0x2e1f58[_0x117440]);}return _0x53d0e1['join']('');},'encodeString'(_0x3668e6,_0x389469){return this['HAS_NATIVE_SUPPORT']&&!_0x389469?btoa(_0x3668e6):this['encodeByteArray'](Hr(_0x3668e6),_0x389469);},'decodeString'(_0x5be051,_0x198f2f){return this['HAS_NATIVE_SUPPORT']&&!_0x198f2f?atob(_0x5be051):nc(this['decodeStringToByteArray'](_0x5be051,_0x198f2f));},'decodeStringToByteArray'(_0xfc9a6c,_0x5cd100){this['init_']();const _0x3e9011=_0x5cd100?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2fe691=[];for(let _0x39817c=0x0;_0x39817c<_0xfc9a6c['length'];){const _0x27fc78=_0x3e9011[_0xfc9a6c['charAt'](_0x39817c++)],_0x4d002e=_0x39817c<_0xfc9a6c['length']?_0x3e9011[_0xfc9a6c['charAt'](_0x39817c)]:0x0;++_0x39817c;const _0x343c2d=_0x39817c<_0xfc9a6c['length']?_0x3e9011[_0xfc9a6c['charAt'](_0x39817c)]:0x40;++_0x39817c;const _0x414a26=_0x39817c<_0xfc9a6c['length']?_0x3e9011[_0xfc9a6c['charAt'](_0x39817c)]:0x40;if(++_0x39817c,_0x27fc78==null||_0x4d002e==null||_0x343c2d==null||_0x414a26==null)throw new ic();const _0x4c11da=_0x27fc78<<0x2|_0x4d002e>>0x4;if(_0x2fe691['push'](_0x4c11da),_0x343c2d!==0x40){const _0xd27862=_0x4d002e<<0x4&0xf0|_0x343c2d>>0x2;if(_0x2fe691['push'](_0xd27862),_0x414a26!==0x40){const _0x1930d3=_0x343c2d<<0x6&0xc0|_0x414a26;_0x2fe691['push'](_0x1930d3);}}}return _0x2fe691;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xfae670=0x0;_0xfae670<this['ENCODED_VALS']['length'];_0xfae670++)this['byteToCharMap_'][_0xfae670]=this['ENCODED_VALS']['charAt'](_0xfae670),this['charToByteMap_'][this['byteToCharMap_'][_0xfae670]]=_0xfae670,this['byteToCharMapWebSafe_'][_0xfae670]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfae670),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xfae670]]=_0xfae670,_0xfae670>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xfae670)]=_0xfae670,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xfae670)]=_0xfae670);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x421552){const _0xcc83dc=Hr(_0x421552);return Fi['encodeByteArray'](_0xcc83dc,!0x0);},dn=function(_0x5ea773){return $r(_0x5ea773)['replace'](/\./g,'');},fn=function(_0x2d2a71){try{return Fi['decodeString'](_0x2d2a71,!0x0);}catch(_0x39a7b4){console['error']('base64Decode\x20failed:\x20',_0x39a7b4);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x40b525){return Gr(void 0x0,_0x40b525);}function Gr(_0xa7c2bc,_0x47c1ab){if(!(_0x47c1ab instanceof Object))return _0x47c1ab;switch(_0x47c1ab['constructor']){case Date:const _0x44036f=_0x47c1ab;return new Date(_0x44036f['getTime']());case Object:_0xa7c2bc===void 0x0&&(_0xa7c2bc={});break;case Array:_0xa7c2bc=[];break;default:return _0x47c1ab;}for(const _0x31c2db in _0x47c1ab)!_0x47c1ab['hasOwnProperty'](_0x31c2db)||!rc(_0x31c2db)||(_0xa7c2bc[_0x31c2db]=Gr(_0xa7c2bc[_0x31c2db],_0x47c1ab[_0x31c2db]));return _0xa7c2bc;}function rc(_0xaf2734){return _0xaf2734!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x53e761=Ps['__FIREBASE_DEFAULTS__'];if(_0x53e761)return JSON['parse'](_0x53e761);},lc=()=>{if(typeof document>'u')return;let _0x295034;try{_0x295034=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x55c279=_0x295034&&fn(_0x295034[0x1]);return _0x55c279&&JSON['parse'](_0x55c279);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x1fb605){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1fb605);return;}},qr=_0x25f1d4=>{var _0x1bb819,_0xbafc65;return(_0xbafc65=(_0x1bb819=Ui())==null?void 0x0:_0x1bb819['emulatorHosts'])==null?void 0x0:_0xbafc65[_0x25f1d4];},hc=_0x513d31=>{const _0x5c254f=qr(_0x513d31);if(!_0x5c254f)return;const _0x1ba42f=_0x5c254f['lastIndexOf'](':');if(_0x1ba42f<=0x0||_0x1ba42f+0x1===_0x5c254f['length'])throw new Error('Invalid\x20host\x20'+_0x5c254f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x28cad0=parseInt(_0x5c254f['substring'](_0x1ba42f+0x1),0xa);return _0x5c254f[0x0]==='['?[_0x5c254f['substring'](0x1,_0x1ba42f-0x1),_0x28cad0]:[_0x5c254f['substring'](0x0,_0x1ba42f),_0x28cad0];},zr=()=>{var _0x1640a4;return(_0x1640a4=Ui())==null?void 0x0:_0x1640a4['config'];},jr=_0x578881=>{var _0x5e0ca9;return(_0x5e0ca9=Ui())==null?void 0x0:_0x5e0ca9['_'+_0x578881];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xb63d03,_0x4e6c43)=>{this['resolve']=_0xb63d03,this['reject']=_0x4e6c43;});}['wrapCallback'](_0x28d3d1){return(_0x13f9df,_0x4f5e5a)=>{_0x13f9df?this['reject'](_0x13f9df):this['resolve'](_0x4f5e5a),typeof _0x28d3d1=='function'&&(this['promise']['catch'](()=>{}),_0x28d3d1['length']===0x1?_0x28d3d1(_0x13f9df):_0x28d3d1(_0x13f9df,_0x4f5e5a));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x129519,_0x4601b2){if(_0x129519['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1405d7={'alg':'none','type':'JWT'},_0xd7e9d5=_0x4601b2||'demo-project',_0x2c233b=_0x129519['iat']||0x0,_0x4f5e0f=_0x129519['sub']||_0x129519['user_id'];if(!_0x4f5e0f)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x481162={'iss':'https://securetoken.google.com/'+_0xd7e9d5,'aud':_0xd7e9d5,'iat':_0x2c233b,'exp':_0x2c233b+0xe10,'auth_time':_0x2c233b,'sub':_0x4f5e0f,'user_id':_0x4f5e0f,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x129519};return[dn(JSON['stringify'](_0x1405d7)),dn(JSON['stringify'](_0x481162)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0xd93cab=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0xd93cab=='object'&&_0xd93cab['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x53dc28=W();return _0x53dc28['indexOf']('MSIE\x20')>=0x0||_0x53dc28['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3d7777,_0x5df430)=>{try{let _0x4c3f9e=!0x0;const _0x41ff35='validate-browser-context-for-indexeddb-analytics-module',_0x27f2e8=self['indexedDB']['open'](_0x41ff35);_0x27f2e8['onsuccess']=()=>{_0x27f2e8['result']['close'](),_0x4c3f9e||self['indexedDB']['deleteDatabase'](_0x41ff35),_0x3d7777(!0x0);},_0x27f2e8['onupgradeneeded']=()=>{_0x4c3f9e=!0x1;},_0x27f2e8['onerror']=()=>{var _0x5c81bc;_0x5df430(((_0x5c81bc=_0x27f2e8['error'])==null?void 0x0:_0x5c81bc['message'])||'');};}catch(_0x4cad18){_0x5df430(_0x4cad18);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x302f37,_0x1436e2,_0x4b34d3){super(_0x1436e2),this['code']=_0x302f37,this['customData']=_0x4b34d3,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x569dcf,_0x4f51a6,_0x262e88){this['service']=_0x569dcf,this['serviceName']=_0x4f51a6,this['errors']=_0x262e88;}['create'](_0x5c488d,..._0x14223e){const _0x106fb9=_0x14223e[0x0]||{},_0x391aa6=this['service']+'/'+_0x5c488d,_0x40ceec=this['errors'][_0x5c488d],_0x279c3d=_0x40ceec?vc(_0x40ceec,_0x106fb9):'Error',_0x4ea8c9=this['serviceName']+':\x20'+_0x279c3d+'\x20('+_0x391aa6+').';return new Re(_0x391aa6,_0x4ea8c9,_0x106fb9);}}function vc(_0x4bc567,_0x1b4d89){return _0x4bc567['replace'](Ec,(_0x154ac2,_0x7b5839)=>{const _0x1a05c4=_0x1b4d89[_0x7b5839];return _0x1a05c4!=null?String(_0x1a05c4):'<'+_0x7b5839+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x46f6f7){return JSON['parse'](_0x46f6f7);}function O(_0x45d3b8){return JSON['stringify'](_0x45d3b8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x254c05){let _0x1dfffc={},_0x5ec213={},_0x2a0034={},_0x17a552='';try{const _0x884083=_0x254c05['split']('.');_0x1dfffc=Nt(fn(_0x884083[0x0])||''),_0x5ec213=Nt(fn(_0x884083[0x1])||''),_0x17a552=_0x884083[0x2],_0x2a0034=_0x5ec213['d']||{},delete _0x5ec213['d'];}catch{}return{'header':_0x1dfffc,'claims':_0x5ec213,'data':_0x2a0034,'signature':_0x17a552};},Ic=function(_0x533916){const _0x4f508c=Yr(_0x533916),_0x45dccb=_0x4f508c['claims'];return!!_0x45dccb&&typeof _0x45dccb=='object'&&_0x45dccb['hasOwnProperty']('iat');},wc=function(_0x5a77db){const _0x1c0f42=Yr(_0x5a77db)['claims'];return typeof _0x1c0f42=='object'&&_0x1c0f42['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xf5bc0,_0x489fb2){return Object['prototype']['hasOwnProperty']['call'](_0xf5bc0,_0x489fb2);}function Le(_0x9a6e57,_0x12630c){if(Object['prototype']['hasOwnProperty']['call'](_0x9a6e57,_0x12630c))return _0x9a6e57[_0x12630c];}function pn(_0x5df4d1){for(const _0x334129 in _0x5df4d1)if(Object['prototype']['hasOwnProperty']['call'](_0x5df4d1,_0x334129))return!0x1;return!0x0;}function _n(_0x528583,_0x3d4662,_0x388540){const _0x2f9216={};for(const _0x5489b7 in _0x528583)Object['prototype']['hasOwnProperty']['call'](_0x528583,_0x5489b7)&&(_0x2f9216[_0x5489b7]=_0x3d4662['call'](_0x388540,_0x528583[_0x5489b7],_0x5489b7,_0x528583));return _0x2f9216;}function xe(_0x33521b,_0x4dfc24){if(_0x33521b===_0x4dfc24)return!0x0;const _0x38cbb3=Object['keys'](_0x33521b),_0x464da0=Object['keys'](_0x4dfc24);for(const _0x6dabb of _0x38cbb3){if(!_0x464da0['includes'](_0x6dabb))return!0x1;const _0x2b8409=_0x33521b[_0x6dabb],_0x139a42=_0x4dfc24[_0x6dabb];if(Ns(_0x2b8409)&&Ns(_0x139a42)){if(!xe(_0x2b8409,_0x139a42))return!0x1;}else{if(_0x2b8409!==_0x139a42)return!0x1;}}for(const _0x4c8889 of _0x464da0)if(!_0x38cbb3['includes'](_0x4c8889))return!0x1;return!0x0;}function Ns(_0x509c29){return _0x509c29!==null&&typeof _0x509c29=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4c3ef1){const _0x3c75c2=[];for(const [_0x13672b,_0x14fa0c]of Object['entries'](_0x4c3ef1))Array['isArray'](_0x14fa0c)?_0x14fa0c['forEach'](_0x100ff9=>{_0x3c75c2['push'](encodeURIComponent(_0x13672b)+'='+encodeURIComponent(_0x100ff9));}):_0x3c75c2['push'](encodeURIComponent(_0x13672b)+'='+encodeURIComponent(_0x14fa0c));return _0x3c75c2['length']?'&'+_0x3c75c2['join']('&'):'';}function Ct(_0x1b660f){const _0x416e4e={};return _0x1b660f['replace'](/^\?/,'')['split']('&')['forEach'](_0x32d75d=>{if(_0x32d75d){const [_0x3148b3,_0x38b085]=_0x32d75d['split']('=');_0x416e4e[decodeURIComponent(_0x3148b3)]=decodeURIComponent(_0x38b085);}}),_0x416e4e;}function Tt(_0x5e8dea){const _0x14aa44=_0x5e8dea['indexOf']('?');if(!_0x14aa44)return'';const _0x7bbe53=_0x5e8dea['indexOf']('#',_0x14aa44);return _0x5e8dea['substring'](_0x14aa44,_0x7bbe53>0x0?_0x7bbe53:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x1c3c79=0x1;_0x1c3c79<this['blockSize'];++_0x1c3c79)this['pad_'][_0x1c3c79]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x58d37f,_0x94cb7f){_0x94cb7f||(_0x94cb7f=0x0);const _0x3f7eb3=this['W_'];if(typeof _0x58d37f=='string'){for(let _0x3103a4=0x0;_0x3103a4<0x10;_0x3103a4++)_0x3f7eb3[_0x3103a4]=_0x58d37f['charCodeAt'](_0x94cb7f)<<0x18|_0x58d37f['charCodeAt'](_0x94cb7f+0x1)<<0x10|_0x58d37f['charCodeAt'](_0x94cb7f+0x2)<<0x8|_0x58d37f['charCodeAt'](_0x94cb7f+0x3),_0x94cb7f+=0x4;}else{for(let _0x524fde=0x0;_0x524fde<0x10;_0x524fde++)_0x3f7eb3[_0x524fde]=_0x58d37f[_0x94cb7f]<<0x18|_0x58d37f[_0x94cb7f+0x1]<<0x10|_0x58d37f[_0x94cb7f+0x2]<<0x8|_0x58d37f[_0x94cb7f+0x3],_0x94cb7f+=0x4;}for(let _0x5910f9=0x10;_0x5910f9<0x50;_0x5910f9++){const _0x31d668=_0x3f7eb3[_0x5910f9-0x3]^_0x3f7eb3[_0x5910f9-0x8]^_0x3f7eb3[_0x5910f9-0xe]^_0x3f7eb3[_0x5910f9-0x10];_0x3f7eb3[_0x5910f9]=(_0x31d668<<0x1|_0x31d668>>>0x1f)&0xffffffff;}let _0x3871fe=this['chain_'][0x0],_0x4ef67b=this['chain_'][0x1],_0x56810c=this['chain_'][0x2],_0x1cfde4=this['chain_'][0x3],_0x36b761=this['chain_'][0x4],_0x264123,_0x4c2872;for(let _0x578fae=0x0;_0x578fae<0x50;_0x578fae++){_0x578fae<0x28?_0x578fae<0x14?(_0x264123=_0x1cfde4^_0x4ef67b&(_0x56810c^_0x1cfde4),_0x4c2872=0x5a827999):(_0x264123=_0x4ef67b^_0x56810c^_0x1cfde4,_0x4c2872=0x6ed9eba1):_0x578fae<0x3c?(_0x264123=_0x4ef67b&_0x56810c|_0x1cfde4&(_0x4ef67b|_0x56810c),_0x4c2872=0x8f1bbcdc):(_0x264123=_0x4ef67b^_0x56810c^_0x1cfde4,_0x4c2872=0xca62c1d6);const _0x39d856=(_0x3871fe<<0x5|_0x3871fe>>>0x1b)+_0x264123+_0x36b761+_0x4c2872+_0x3f7eb3[_0x578fae]&0xffffffff;_0x36b761=_0x1cfde4,_0x1cfde4=_0x56810c,_0x56810c=(_0x4ef67b<<0x1e|_0x4ef67b>>>0x2)&0xffffffff,_0x4ef67b=_0x3871fe,_0x3871fe=_0x39d856;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3871fe&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4ef67b&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x56810c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1cfde4&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x36b761&0xffffffff;}['update'](_0x40d68d,_0x187698){if(_0x40d68d==null)return;_0x187698===void 0x0&&(_0x187698=_0x40d68d['length']);const _0x42e845=_0x187698-this['blockSize'];let _0xa840e7=0x0;const _0x258f9f=this['buf_'];let _0x4aa464=this['inbuf_'];for(;_0xa840e7<_0x187698;){if(_0x4aa464===0x0){for(;_0xa840e7<=_0x42e845;)this['compress_'](_0x40d68d,_0xa840e7),_0xa840e7+=this['blockSize'];}if(typeof _0x40d68d=='string'){for(;_0xa840e7<_0x187698;)if(_0x258f9f[_0x4aa464]=_0x40d68d['charCodeAt'](_0xa840e7),++_0x4aa464,++_0xa840e7,_0x4aa464===this['blockSize']){this['compress_'](_0x258f9f),_0x4aa464=0x0;break;}}else{for(;_0xa840e7<_0x187698;)if(_0x258f9f[_0x4aa464]=_0x40d68d[_0xa840e7],++_0x4aa464,++_0xa840e7,_0x4aa464===this['blockSize']){this['compress_'](_0x258f9f),_0x4aa464=0x0;break;}}}this['inbuf_']=_0x4aa464,this['total_']+=_0x187698;}['digest'](){const _0x2de8ce=[];let _0x8ea315=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x40c722=this['blockSize']-0x1;_0x40c722>=0x38;_0x40c722--)this['buf_'][_0x40c722]=_0x8ea315&0xff,_0x8ea315/=0x100;this['compress_'](this['buf_']);let _0x31f9fb=0x0;for(let _0x291e02=0x0;_0x291e02<0x5;_0x291e02++)for(let _0x54b51c=0x18;_0x54b51c>=0x0;_0x54b51c-=0x8)_0x2de8ce[_0x31f9fb]=this['chain_'][_0x291e02]>>_0x54b51c&0xff,++_0x31f9fb;return _0x2de8ce;}}function Tc(_0x301245,_0xff77a7){const _0x2e1c93=new Sc(_0x301245,_0xff77a7);return _0x2e1c93['subscribe']['bind'](_0x2e1c93);}class Sc{constructor(_0x29d9af,_0x9ec498){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x9ec498,this['task']['then'](()=>{_0x29d9af(this);})['catch'](_0x1baa1c=>{this['error'](_0x1baa1c);});}['next'](_0x48dc3a){this['forEachObserver'](_0x32ff3f=>{_0x32ff3f['next'](_0x48dc3a);});}['error'](_0x57b6af){this['forEachObserver'](_0x31df12=>{_0x31df12['error'](_0x57b6af);}),this['close'](_0x57b6af);}['complete'](){this['forEachObserver'](_0x3cc23f=>{_0x3cc23f['complete']();}),this['close']();}['subscribe'](_0x2003a7,_0x520969,_0x698b0d){let _0x2641eb;if(_0x2003a7===void 0x0&&_0x520969===void 0x0&&_0x698b0d===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2003a7,['next','error','complete'])?_0x2641eb=_0x2003a7:_0x2641eb={'next':_0x2003a7,'error':_0x520969,'complete':_0x698b0d},_0x2641eb['next']===void 0x0&&(_0x2641eb['next']=ti),_0x2641eb['error']===void 0x0&&(_0x2641eb['error']=ti),_0x2641eb['complete']===void 0x0&&(_0x2641eb['complete']=ti);const _0x47e072=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2641eb['error'](this['finalError']):_0x2641eb['complete']();}catch{}}),this['observers']['push'](_0x2641eb),_0x47e072;}['unsubscribeOne'](_0xbfc474){this['observers']===void 0x0||this['observers'][_0xbfc474]===void 0x0||(delete this['observers'][_0xbfc474],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4bd46c){if(!this['finalized']){for(let _0x464617=0x0;_0x464617<this['observers']['length'];_0x464617++)this['sendOne'](_0x464617,_0x4bd46c);}}['sendOne'](_0x1f4636,_0x9f0b6d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1f4636]!==void 0x0)try{_0x9f0b6d(this['observers'][_0x1f4636]);}catch(_0x161ae1){typeof console<'u'&&console['error']&&console['error'](_0x161ae1);}});}['close'](_0x4b1293){this['finalized']||(this['finalized']=!0x0,_0x4b1293!==void 0x0&&(this['finalError']=_0x4b1293),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x38cbd0,_0x374b7b){if(typeof _0x38cbd0!='object'||_0x38cbd0===null)return!0x1;for(const _0x4f3fa7 of _0x374b7b)if(_0x4f3fa7 in _0x38cbd0&&typeof _0x38cbd0[_0x4f3fa7]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x47a92e,_0x48ceb6){return _0x47a92e+'\x20failed:\x20'+_0x48ceb6+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x54c3c3){const _0x207ed6=[];let _0x4d0d1d=0x0;for(let _0x27d60=0x0;_0x27d60<_0x54c3c3['length'];_0x27d60++){let _0x153d06=_0x54c3c3['charCodeAt'](_0x27d60);if(_0x153d06>=0xd800&&_0x153d06<=0xdbff){const _0x2d0d5d=_0x153d06-0xd800;_0x27d60++,f(_0x27d60<_0x54c3c3['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0xaf18f3=_0x54c3c3['charCodeAt'](_0x27d60)-0xdc00;_0x153d06=0x10000+(_0x2d0d5d<<0xa)+_0xaf18f3;}_0x153d06<0x80?_0x207ed6[_0x4d0d1d++]=_0x153d06:_0x153d06<0x800?(_0x207ed6[_0x4d0d1d++]=_0x153d06>>0x6|0xc0,_0x207ed6[_0x4d0d1d++]=_0x153d06&0x3f|0x80):_0x153d06<0x10000?(_0x207ed6[_0x4d0d1d++]=_0x153d06>>0xc|0xe0,_0x207ed6[_0x4d0d1d++]=_0x153d06>>0x6&0x3f|0x80,_0x207ed6[_0x4d0d1d++]=_0x153d06&0x3f|0x80):(_0x207ed6[_0x4d0d1d++]=_0x153d06>>0x12|0xf0,_0x207ed6[_0x4d0d1d++]=_0x153d06>>0xc&0x3f|0x80,_0x207ed6[_0x4d0d1d++]=_0x153d06>>0x6&0x3f|0x80,_0x207ed6[_0x4d0d1d++]=_0x153d06&0x3f|0x80);}return _0x207ed6;},Ln=function(_0x41a406){let _0x12201f=0x0;for(let _0x3d075e=0x0;_0x3d075e<_0x41a406['length'];_0x3d075e++){const _0x5f2518=_0x41a406['charCodeAt'](_0x3d075e);_0x5f2518<0x80?_0x12201f++:_0x5f2518<0x800?_0x12201f+=0x2:_0x5f2518>=0xd800&&_0x5f2518<=0xdbff?(_0x12201f+=0x4,_0x3d075e++):_0x12201f+=0x3;}return _0x12201f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x27464e){return _0x27464e&&_0x27464e['_delegate']?_0x27464e['_delegate']:_0x27464e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x2efcf1){try{return(_0x2efcf1['startsWith']('http://')||_0x2efcf1['startsWith']('https://')?new URL(_0x2efcf1)['hostname']:_0x2efcf1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x481c24){return(await fetch(_0x481c24,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x50578a,_0x4f3c80,_0x251125){this['name']=_0x50578a,this['instanceFactory']=_0x4f3c80,this['type']=_0x251125,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2a3c8e){return this['instantiationMode']=_0x2a3c8e,this;}['setMultipleInstances'](_0x1624ca){return this['multipleInstances']=_0x1624ca,this;}['setServiceProps'](_0x2122b9){return this['serviceProps']=_0x2122b9,this;}['setInstanceCreatedCallback'](_0x42fff2){return this['onInstanceCreated']=_0x42fff2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4f94e5,_0x369abf){this['name']=_0x4f94e5,this['container']=_0x369abf,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x46d202){const _0x30fbec=this['normalizeInstanceIdentifier'](_0x46d202);if(!this['instancesDeferred']['has'](_0x30fbec)){const _0x3d1355=new H();if(this['instancesDeferred']['set'](_0x30fbec,_0x3d1355),this['isInitialized'](_0x30fbec)||this['shouldAutoInitialize']())try{const _0x411313=this['getOrInitializeService']({'instanceIdentifier':_0x30fbec});_0x411313&&_0x3d1355['resolve'](_0x411313);}catch{}}return this['instancesDeferred']['get'](_0x30fbec)['promise'];}['getImmediate'](_0x22ba3e){const _0x31be5a=this['normalizeInstanceIdentifier'](_0x22ba3e==null?void 0x0:_0x22ba3e['identifier']),_0x5310ef=(_0x22ba3e==null?void 0x0:_0x22ba3e['optional'])??!0x1;if(this['isInitialized'](_0x31be5a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x31be5a});}catch(_0x35d5ea){if(_0x5310ef)return null;throw _0x35d5ea;}else{if(_0x5310ef)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x25a726){if(_0x25a726['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x25a726['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x25a726,!!this['shouldAutoInitialize']()){if(Pc(_0x25a726))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x5c5475,_0x3825c]of this['instancesDeferred']['entries']()){const _0x55ed02=this['normalizeInstanceIdentifier'](_0x5c5475);try{const _0x196013=this['getOrInitializeService']({'instanceIdentifier':_0x55ed02});_0x3825c['resolve'](_0x196013);}catch{}}}}['clearInstance'](_0x334145=Ne){this['instancesDeferred']['delete'](_0x334145),this['instancesOptions']['delete'](_0x334145),this['instances']['delete'](_0x334145);}async['delete'](){const _0x473cd5=Array['from'](this['instances']['values']());await Promise['all']([..._0x473cd5['filter'](_0x43d62d=>'INTERNAL'in _0x43d62d)['map'](_0x128cc4=>_0x128cc4['INTERNAL']['delete']()),..._0x473cd5['filter'](_0x562cfe=>'_delete'in _0x562cfe)['map'](_0x378fec=>_0x378fec['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4759ee=Ne){return this['instances']['has'](_0x4759ee);}['getOptions'](_0x2ba309=Ne){return this['instancesOptions']['get'](_0x2ba309)||{};}['initialize'](_0x45d3fa={}){const {options:_0x28a405={}}=_0x45d3fa,_0x42a61c=this['normalizeInstanceIdentifier'](_0x45d3fa['instanceIdentifier']);if(this['isInitialized'](_0x42a61c))throw Error(this['name']+'('+_0x42a61c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x428c9f=this['getOrInitializeService']({'instanceIdentifier':_0x42a61c,'options':_0x28a405});for(const [_0x54e3a3,_0x5d9504]of this['instancesDeferred']['entries']()){const _0x580183=this['normalizeInstanceIdentifier'](_0x54e3a3);_0x42a61c===_0x580183&&_0x5d9504['resolve'](_0x428c9f);}return _0x428c9f;}['onInit'](_0x1798d5,_0x4d74f6){const _0x222189=this['normalizeInstanceIdentifier'](_0x4d74f6),_0x2cfb8a=this['onInitCallbacks']['get'](_0x222189)??new Set();_0x2cfb8a['add'](_0x1798d5),this['onInitCallbacks']['set'](_0x222189,_0x2cfb8a);const _0x3eaacf=this['instances']['get'](_0x222189);return _0x3eaacf&&_0x1798d5(_0x3eaacf,_0x222189),()=>{_0x2cfb8a['delete'](_0x1798d5);};}['invokeOnInitCallbacks'](_0x134c6f,_0x2cb5a7){const _0x3ba6b7=this['onInitCallbacks']['get'](_0x2cb5a7);if(_0x3ba6b7){for(const _0x24201e of _0x3ba6b7)try{_0x24201e(_0x134c6f,_0x2cb5a7);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xfbdbac,options:_0x35cc6a={}}){let _0x2708f1=this['instances']['get'](_0xfbdbac);if(!_0x2708f1&&this['component']&&(_0x2708f1=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0xfbdbac),'options':_0x35cc6a}),this['instances']['set'](_0xfbdbac,_0x2708f1),this['instancesOptions']['set'](_0xfbdbac,_0x35cc6a),this['invokeOnInitCallbacks'](_0x2708f1,_0xfbdbac),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xfbdbac,_0x2708f1);}catch{}return _0x2708f1||null;}['normalizeInstanceIdentifier'](_0x4f58c8=Ne){return this['component']?this['component']['multipleInstances']?_0x4f58c8:Ne:_0x4f58c8;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x1d678d){return _0x1d678d===Ne?void 0x0:_0x1d678d;}function Pc(_0x4749df){return _0x4749df['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4b8517){this['name']=_0x4b8517,this['providers']=new Map();}['addComponent'](_0x2062c9){const _0x72d24d=this['getProvider'](_0x2062c9['name']);if(_0x72d24d['isComponentSet']())throw new Error('Component\x20'+_0x2062c9['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x72d24d['setComponent'](_0x2062c9);}['addOrOverwriteComponent'](_0x5167ae){this['getProvider'](_0x5167ae['name'])['isComponentSet']()&&this['providers']['delete'](_0x5167ae['name']),this['addComponent'](_0x5167ae);}['getProvider'](_0xbbbbe){if(this['providers']['has'](_0xbbbbe))return this['providers']['get'](_0xbbbbe);const _0x85b1b=new Ac(_0xbbbbe,this);return this['providers']['set'](_0xbbbbe,_0x85b1b),_0x85b1b;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x43ab30){_0x43ab30[_0x43ab30['DEBUG']=0x0]='DEBUG',_0x43ab30[_0x43ab30['VERBOSE']=0x1]='VERBOSE',_0x43ab30[_0x43ab30['INFO']=0x2]='INFO',_0x43ab30[_0x43ab30['WARN']=0x3]='WARN',_0x43ab30[_0x43ab30['ERROR']=0x4]='ERROR',_0x43ab30[_0x43ab30['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x534731,_0xf6e8d6,..._0x5f1747)=>{if(_0xf6e8d6<_0x534731['logLevel'])return;const _0x2664e3=new Date()['toISOString'](),_0x11993d=Mc[_0xf6e8d6];if(_0x11993d)console[_0x11993d]('['+_0x2664e3+']\x20\x20'+_0x534731['name']+':',..._0x5f1747);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xf6e8d6+')');};class Bi{constructor(_0x5d4979){this['name']=_0x5d4979,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4c12d2){if(!(_0x4c12d2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4c12d2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4c12d2;}['setLogLevel'](_0x2642dc){this['_logLevel']=typeof _0x2642dc=='string'?Oc[_0x2642dc]:_0x2642dc;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x496a2b){if(typeof _0x496a2b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x496a2b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x464a59){this['_userLogHandler']=_0x464a59;}['debug'](..._0x36ae5b){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x36ae5b),this['_logHandler'](this,T['DEBUG'],..._0x36ae5b);}['log'](..._0x24f3d5){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x24f3d5),this['_logHandler'](this,T['VERBOSE'],..._0x24f3d5);}['info'](..._0x74a7b6){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x74a7b6),this['_logHandler'](this,T['INFO'],..._0x74a7b6);}['warn'](..._0x2e1bb2){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2e1bb2),this['_logHandler'](this,T['WARN'],..._0x2e1bb2);}['error'](..._0x55cc6b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x55cc6b),this['_logHandler'](this,T['ERROR'],..._0x55cc6b);}}const xc=(_0x5a0cbe,_0x4f4ab6)=>_0x4f4ab6['some'](_0x56d555=>_0x5a0cbe instanceof _0x56d555);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x347799){const _0x44ed5e=new Promise((_0x146702,_0x2c3b20)=>{const _0x5aa0bc=()=>{_0x347799['removeEventListener']('success',_0x2973af),_0x347799['removeEventListener']('error',_0xb99683);},_0x2973af=()=>{_0x146702(ge(_0x347799['result'])),_0x5aa0bc();},_0xb99683=()=>{_0x2c3b20(_0x347799['error']),_0x5aa0bc();};_0x347799['addEventListener']('success',_0x2973af),_0x347799['addEventListener']('error',_0xb99683);});return _0x44ed5e['then'](_0x1c0b70=>{_0x1c0b70 instanceof IDBCursor&&Jr['set'](_0x1c0b70,_0x347799);})['catch'](()=>{}),Vi['set'](_0x44ed5e,_0x347799),_0x44ed5e;}function Bc(_0x4865ce){if(_i['has'](_0x4865ce))return;const _0x450cf4=new Promise((_0x1ef885,_0x14af82)=>{const _0x486b64=()=>{_0x4865ce['removeEventListener']('complete',_0x1a9d08),_0x4865ce['removeEventListener']('error',_0x2deef6),_0x4865ce['removeEventListener']('abort',_0x2deef6);},_0x1a9d08=()=>{_0x1ef885(),_0x486b64();},_0x2deef6=()=>{_0x14af82(_0x4865ce['error']||new DOMException('AbortError','AbortError')),_0x486b64();};_0x4865ce['addEventListener']('complete',_0x1a9d08),_0x4865ce['addEventListener']('error',_0x2deef6),_0x4865ce['addEventListener']('abort',_0x2deef6);});_i['set'](_0x4865ce,_0x450cf4);}let gi={'get'(_0x3a06e5,_0x2e92f8,_0x15da9e){if(_0x3a06e5 instanceof IDBTransaction){if(_0x2e92f8==='done')return _i['get'](_0x3a06e5);if(_0x2e92f8==='objectStoreNames')return _0x3a06e5['objectStoreNames']||Xr['get'](_0x3a06e5);if(_0x2e92f8==='store')return _0x15da9e['objectStoreNames'][0x1]?void 0x0:_0x15da9e['objectStore'](_0x15da9e['objectStoreNames'][0x0]);}return ge(_0x3a06e5[_0x2e92f8]);},'set'(_0x4b5799,_0x1cd157,_0x9d13e0){return _0x4b5799[_0x1cd157]=_0x9d13e0,!0x0;},'has'(_0x36f587,_0x36f886){return _0x36f587 instanceof IDBTransaction&&(_0x36f886==='done'||_0x36f886==='store')?!0x0:_0x36f886 in _0x36f587;}};function Vc(_0x4ae808){gi=_0x4ae808(gi);}function Hc(_0x5e3d6f){return _0x5e3d6f===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xd9ead5,..._0xf20ebb){const _0x5da355=_0x5e3d6f['call'](ii(this),_0xd9ead5,..._0xf20ebb);return Xr['set'](_0x5da355,_0xd9ead5['sort']?_0xd9ead5['sort']():[_0xd9ead5]),ge(_0x5da355);}:Uc()['includes'](_0x5e3d6f)?function(..._0x6856a3){return _0x5e3d6f['apply'](ii(this),_0x6856a3),ge(Jr['get'](this));}:function(..._0x465546){return ge(_0x5e3d6f['apply'](ii(this),_0x465546));};}function $c(_0x853edf){return typeof _0x853edf=='function'?Hc(_0x853edf):(_0x853edf instanceof IDBTransaction&&Bc(_0x853edf),xc(_0x853edf,Fc())?new Proxy(_0x853edf,gi):_0x853edf);}function ge(_0x3b9a69){if(_0x3b9a69 instanceof IDBRequest)return Wc(_0x3b9a69);if(ni['has'](_0x3b9a69))return ni['get'](_0x3b9a69);const _0x3b0a8a=$c(_0x3b9a69);return _0x3b0a8a!==_0x3b9a69&&(ni['set'](_0x3b9a69,_0x3b0a8a),Vi['set'](_0x3b0a8a,_0x3b9a69)),_0x3b0a8a;}const ii=_0x4fe381=>Vi['get'](_0x4fe381);function Gc(_0x1f09d6,_0xf94ea2,{blocked:_0x416a15,upgrade:_0x4bc102,blocking:_0x5af4e6,terminated:_0x4fc3f5}={}){const _0x36893f=indexedDB['open'](_0x1f09d6,_0xf94ea2),_0x29b895=ge(_0x36893f);return _0x4bc102&&_0x36893f['addEventListener']('upgradeneeded',_0x353618=>{_0x4bc102(ge(_0x36893f['result']),_0x353618['oldVersion'],_0x353618['newVersion'],ge(_0x36893f['transaction']),_0x353618);}),_0x416a15&&_0x36893f['addEventListener']('blocked',_0x22c209=>_0x416a15(_0x22c209['oldVersion'],_0x22c209['newVersion'],_0x22c209)),_0x29b895['then'](_0x2e3f51=>{_0x4fc3f5&&_0x2e3f51['addEventListener']('close',()=>_0x4fc3f5()),_0x5af4e6&&_0x2e3f51['addEventListener']('versionchange',_0x682d77=>_0x5af4e6(_0x682d77['oldVersion'],_0x682d77['newVersion'],_0x682d77));})['catch'](()=>{}),_0x29b895;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x43a72e,_0x15a9f1){if(!(_0x43a72e instanceof IDBDatabase&&!(_0x15a9f1 in _0x43a72e)&&typeof _0x15a9f1=='string'))return;if(si['get'](_0x15a9f1))return si['get'](_0x15a9f1);const _0x57ccdf=_0x15a9f1['replace'](/FromIndex$/,''),_0x266262=_0x15a9f1!==_0x57ccdf,_0x303257=zc['includes'](_0x57ccdf);if(!(_0x57ccdf in(_0x266262?IDBIndex:IDBObjectStore)['prototype'])||!(_0x303257||qc['includes'](_0x57ccdf)))return;const _0x1b4bc1=async function(_0x1b6a7a,..._0xf0b4da){const _0x13a20e=this['transaction'](_0x1b6a7a,_0x303257?'readwrite':'readonly');let _0x3003a7=_0x13a20e['store'];return _0x266262&&(_0x3003a7=_0x3003a7['index'](_0xf0b4da['shift']())),(await Promise['all']([_0x3003a7[_0x57ccdf](..._0xf0b4da),_0x303257&&_0x13a20e['done']]))[0x0];};return si['set'](_0x15a9f1,_0x1b4bc1),_0x1b4bc1;}Vc(_0x280056=>({..._0x280056,'get':(_0x3c2e76,_0xd959be,_0x1f864b)=>Ms(_0x3c2e76,_0xd959be)||_0x280056['get'](_0x3c2e76,_0xd959be,_0x1f864b),'has':(_0x5a97aa,_0x25ce5e)=>!!Ms(_0x5a97aa,_0x25ce5e)||_0x280056['has'](_0x5a97aa,_0x25ce5e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x450af1){this['container']=_0x450af1;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x880357=>{if(Kc(_0x880357)){const _0x4367f3=_0x880357['getImmediate']();return _0x4367f3['library']+'/'+_0x4367f3['version'];}else return null;})['filter'](_0xf90f34=>_0xf90f34)['join']('\x20');}}function Kc(_0x4d0503){const _0x277e14=_0x4d0503['getComponent']();return(_0x277e14==null?void 0x0:_0x277e14['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x33e3df,_0x2e1d38){try{_0x33e3df['container']['addComponent'](_0x2e1d38);}catch(_0x3a88fa){oe['debug']('Component\x20'+_0x2e1d38['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x33e3df['name'],_0x3a88fa);}}function st(_0x488365){const _0x5b53ff=_0x488365['name'];if(Ei['has'](_0x5b53ff))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5b53ff+'.'),!0x1;Ei['set'](_0x5b53ff,_0x488365);for(const _0x2a6913 of Ue['values']())xs(_0x2a6913,_0x488365);for(const _0xf03e64 of vi['values']())xs(_0xf03e64,_0x488365);return!0x0;}function Hi(_0x1805e2,_0x3532f0){const _0x1dff1f=_0x1805e2['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1dff1f&&_0x1dff1f['triggerHeartbeat'](),_0x1805e2['container']['getProvider'](_0x3532f0);}function $(_0x5a9533){return _0x5a9533==null?!0x1:_0x5a9533['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0xbfeae0,_0x3da3a7,_0x32a959){this['_isDeleted']=!0x1,this['_options']={..._0xbfeae0},this['_config']={..._0x3da3a7},this['_name']=_0x3da3a7['name'],this['_automaticDataCollectionEnabled']=_0x3da3a7['automaticDataCollectionEnabled'],this['_container']=_0x32a959,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x413ab0){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x413ab0;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5eed4b){this['_isDeleted']=_0x5eed4b;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x525eca,_0x4c6bc4={}){let _0xbf8847=_0x525eca;typeof _0x4c6bc4!='object'&&(_0x4c6bc4={'name':_0x4c6bc4});const _0x3964ad={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4c6bc4},_0x470660=_0x3964ad['name'];if(typeof _0x470660!='string'||!_0x470660)throw me['create']('bad-app-name',{'appName':String(_0x470660)});if(_0xbf8847||(_0xbf8847=zr()),!_0xbf8847)throw me['create']('no-options');const _0xa2ad74=Ue['get'](_0x470660);if(_0xa2ad74){if(xe(_0xbf8847,_0xa2ad74['options'])&&xe(_0x3964ad,_0xa2ad74['config']))return _0xa2ad74;throw me['create']('duplicate-app',{'appName':_0x470660});}const _0x4947fd=new Nc(_0x470660);for(const _0x2cf0c3 of Ei['values']())_0x4947fd['addComponent'](_0x2cf0c3);const _0x5a0216=new Tl(_0xbf8847,_0x3964ad,_0x4947fd);return Ue['set'](_0x470660,_0x5a0216),_0x5a0216;}function Zr(_0x5b0386=yi){const _0xed13aa=Ue['get'](_0x5b0386);if(!_0xed13aa&&_0x5b0386===yi&&zr())return Sl();if(!_0xed13aa)throw me['create']('no-app',{'appName':_0x5b0386});return _0xed13aa;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x4046ad){let _0x2dba8d=!0x1;const _0x2d76aa=_0x4046ad['name'];Ue['has'](_0x2d76aa)?(_0x2dba8d=!0x0,Ue['delete'](_0x2d76aa)):vi['has'](_0x2d76aa)&&_0x4046ad['decRefCount']()<=0x0&&(vi['delete'](_0x2d76aa),_0x2dba8d=!0x0),_0x2dba8d&&(await Promise['all'](_0x4046ad['container']['getProviders']()['map'](_0xe31ba2=>_0xe31ba2['delete']())),_0x4046ad['isDeleted']=!0x0);}function ye(_0x4ff94a,_0x266619,_0x288519){let _0x871215=wl[_0x4ff94a]??_0x4ff94a;_0x288519&&(_0x871215+='-'+_0x288519);const _0x4e40c0=_0x871215['match'](/\s|\//),_0x5bfd1e=_0x266619['match'](/\s|\//);if(_0x4e40c0||_0x5bfd1e){const _0x130c9c=['Unable\x20to\x20register\x20library\x20\x22'+_0x871215+'\x22\x20with\x20version\x20\x22'+_0x266619+'\x22:'];_0x4e40c0&&_0x130c9c['push']('library\x20name\x20\x22'+_0x871215+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4e40c0&&_0x5bfd1e&&_0x130c9c['push']('and'),_0x5bfd1e&&_0x130c9c['push']('version\x20name\x20\x22'+_0x266619+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x130c9c['join']('\x20'));return;}st(new Fe(_0x871215+'-version',()=>({'library':_0x871215,'version':_0x266619}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x128039,_0x2b37d3)=>{switch(_0x2b37d3){case 0x0:try{_0x128039['createObjectStore'](Ot);}catch(_0x13bc8f){console['warn'](_0x13bc8f);}}}})['catch'](_0x1fb489=>{throw me['create']('idb-open',{'originalErrorMessage':_0x1fb489['message']});})),ri;}async function Al(_0x30ac22){try{const _0x48baba=(await eo())['transaction'](Ot),_0x4809b3=await _0x48baba['objectStore'](Ot)['get'](to(_0x30ac22));return await _0x48baba['done'],_0x4809b3;}catch(_0x11a950){if(_0x11a950 instanceof Re)oe['warn'](_0x11a950['message']);else{const _0xd4eb44=me['create']('idb-get',{'originalErrorMessage':_0x11a950==null?void 0x0:_0x11a950['message']});oe['warn'](_0xd4eb44['message']);}}}async function Fs(_0xed3672,_0x3002a8){try{const _0x1dbf34=(await eo())['transaction'](Ot,'readwrite');await _0x1dbf34['objectStore'](Ot)['put'](_0x3002a8,to(_0xed3672)),await _0x1dbf34['done'];}catch(_0x17b9e9){if(_0x17b9e9 instanceof Re)oe['warn'](_0x17b9e9['message']);else{const _0x5e5923=me['create']('idb-set',{'originalErrorMessage':_0x17b9e9==null?void 0x0:_0x17b9e9['message']});oe['warn'](_0x5e5923['message']);}}}function to(_0x2c94de){return _0x2c94de['name']+'!'+_0x2c94de['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0xd25551){this['container']=_0xd25551,this['_heartbeatsCache']=null;const _0xa70714=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0xa70714),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x442461=>(this['_heartbeatsCache']=_0x442461,_0x442461));}async['triggerHeartbeat'](){var _0x525ff2,_0x36ee90;try{const _0x24da84=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x20636a=Us();if(((_0x525ff2=this['_heartbeatsCache'])==null?void 0x0:_0x525ff2['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x36ee90=this['_heartbeatsCache'])==null?void 0x0:_0x36ee90['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x20636a||this['_heartbeatsCache']['heartbeats']['some'](_0x37a80d=>_0x37a80d['date']===_0x20636a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x20636a,'agent':_0x24da84}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x15d175=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x15d175,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x114ccb){oe['warn'](_0x114ccb);}}async['getHeartbeatsHeader'](){var _0x501eaf;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x501eaf=this['_heartbeatsCache'])==null?void 0x0:_0x501eaf['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1c5f2f=Us(),{heartbeatsToSend:_0x2c732e,unsentEntries:_0x4c67db}=Ol(this['_heartbeatsCache']['heartbeats']),_0x48ea40=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2c732e}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1c5f2f,_0x4c67db['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4c67db,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x48ea40;}catch(_0x38984d){return oe['warn'](_0x38984d),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x23bbce,_0x786309=kl){const _0x11c448=[];let _0x38dba1=_0x23bbce['slice']();for(const _0x10fc13 of _0x23bbce){const _0x47f05f=_0x11c448['find'](_0x129cb1=>_0x129cb1['agent']===_0x10fc13['agent']);if(_0x47f05f){if(_0x47f05f['dates']['push'](_0x10fc13['date']),Ws(_0x11c448)>_0x786309){_0x47f05f['dates']['pop']();break;}}else{if(_0x11c448['push']({'agent':_0x10fc13['agent'],'dates':[_0x10fc13['date']]}),Ws(_0x11c448)>_0x786309){_0x11c448['pop']();break;}}_0x38dba1=_0x38dba1['slice'](0x1);}return{'heartbeatsToSend':_0x11c448,'unsentEntries':_0x38dba1};}class Dl{constructor(_0x28a446){this['app']=_0x28a446,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4e7e99=await Al(this['app']);return _0x4e7e99!=null&&_0x4e7e99['heartbeats']?_0x4e7e99:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x51c5b9){if(await this['_canUseIndexedDBPromise']){const _0x3bf69a=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x51c5b9['lastSentHeartbeatDate']??_0x3bf69a['lastSentHeartbeatDate'],'heartbeats':_0x51c5b9['heartbeats']});}else return;}async['add'](_0x401d5f){if(await this['_canUseIndexedDBPromise']){const _0x500684=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x401d5f['lastSentHeartbeatDate']??_0x500684['lastSentHeartbeatDate'],'heartbeats':[..._0x500684['heartbeats'],..._0x401d5f['heartbeats']]});}else return;}}function Ws(_0x2d695f){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2d695f}))['length'];}function Ml(_0x35dacb){if(_0x35dacb['length']===0x0)return-0x1;let _0x32a6d3=0x0,_0x11b59f=_0x35dacb[0x0]['date'];for(let _0x4687a3=0x1;_0x4687a3<_0x35dacb['length'];_0x4687a3++)_0x35dacb[_0x4687a3]['date']<_0x11b59f&&(_0x11b59f=_0x35dacb[_0x4687a3]['date'],_0x32a6d3=_0x4687a3);return _0x32a6d3;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x16f16c){st(new Fe('platform-logger',_0x10ad2f=>new jc(_0x10ad2f),'PRIVATE')),st(new Fe('heartbeat',_0x89a1b4=>new Nl(_0x89a1b4),'PRIVATE')),ye(mi,Ls,_0x16f16c),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x37395b){no=_0x37395b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x162e90){this['domStorage_']=_0x162e90,this['prefix_']='firebase:';}['set'](_0x6adb1d,_0x2ea661){_0x2ea661==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x6adb1d)):this['domStorage_']['setItem'](this['prefixedName_'](_0x6adb1d),O(_0x2ea661));}['get'](_0x198481){const _0x33783e=this['domStorage_']['getItem'](this['prefixedName_'](_0x198481));return _0x33783e==null?null:Nt(_0x33783e);}['remove'](_0x6be673){this['domStorage_']['removeItem'](this['prefixedName_'](_0x6be673));}['prefixedName_'](_0x4286a7){return this['prefix_']+_0x4286a7;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5bc2b7,_0x3e0a27){_0x3e0a27==null?delete this['cache_'][_0x5bc2b7]:this['cache_'][_0x5bc2b7]=_0x3e0a27;}['get'](_0x5e2e4e){return Q(this['cache_'],_0x5e2e4e)?this['cache_'][_0x5e2e4e]:null;}['remove'](_0x57e869){delete this['cache_'][_0x57e869];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4ef9c6){try{if(typeof window<'u'&&typeof window[_0x4ef9c6]<'u'){const _0x2d0cbf=window[_0x4ef9c6];return _0x2d0cbf['setItem']('firebase:sentinel','cache'),_0x2d0cbf['removeItem']('firebase:sentinel'),new Wl(_0x2d0cbf);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x163b5e=0x1;return function(){return _0x163b5e++;};}()),ro=function(_0xe0a8ce){const _0x49a9ca=Rc(_0xe0a8ce),_0x27352a=new Cc();_0x27352a['update'](_0x49a9ca);const _0x3c65d5=_0x27352a['digest']();return Fi['encodeByteArray'](_0x3c65d5);},zt=function(..._0x2bf56f){let _0x51402c='';for(let _0x5aa948=0x0;_0x5aa948<_0x2bf56f['length'];_0x5aa948++){const _0x1835d2=_0x2bf56f[_0x5aa948];Array['isArray'](_0x1835d2)||_0x1835d2&&typeof _0x1835d2=='object'&&typeof _0x1835d2['length']=='number'?_0x51402c+=zt['apply'](null,_0x1835d2):typeof _0x1835d2=='object'?_0x51402c+=O(_0x1835d2):_0x51402c+=_0x1835d2,_0x51402c+='\x20';}return _0x51402c;};let St=null,$s=!0x0;const Hl=function(_0x3bde0a,_0x2ee5e2){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x31e328){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0xb2047d=zt['apply'](null,_0x31e328);St(_0xb2047d);}},jt=function(_0xbf65c1){return function(..._0x38d9ad){L(_0xbf65c1,..._0x38d9ad);};},Ii=function(..._0x1060fb){const _0x48bce9='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1060fb);Ze['error'](_0x48bce9);},ae=function(..._0x2fd2a9){const _0x14c24b='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x2fd2a9);throw Ze['error'](_0x14c24b),new Error(_0x14c24b);},U=function(..._0x2af418){const _0x46f0b5='FIREBASE\x20WARNING:\x20'+zt(..._0x2af418);Ze['warn'](_0x46f0b5);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2b43b7){return typeof _0x2b43b7=='number'&&(_0x2b43b7!==_0x2b43b7||_0x2b43b7===Number['POSITIVE_INFINITY']||_0x2b43b7===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3fb547){if(document['readyState']==='complete')_0x3fb547();else{let _0x4eb553=!0x1;const _0x330578=function(){if(!document['body']){setTimeout(_0x330578,Math['floor'](0xa));return;}_0x4eb553||(_0x4eb553=!0x0,_0x3fb547());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x330578,!0x1),window['addEventListener']('load',_0x330578,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x330578();}),window['attachEvent']('onload',_0x330578));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0xb08173,_0x1c5b2e){if(_0xb08173===_0x1c5b2e)return 0x0;if(_0xb08173===We||_0x1c5b2e===we)return-0x1;if(_0x1c5b2e===We||_0xb08173===we)return 0x1;{const _0x247542=Gs(_0xb08173),_0x3e551e=Gs(_0x1c5b2e);return _0x247542!==null?_0x3e551e!==null?_0x247542-_0x3e551e===0x0?_0xb08173['length']-_0x1c5b2e['length']:_0x247542-_0x3e551e:-0x1:_0x3e551e!==null?0x1:_0xb08173<_0x1c5b2e?-0x1:0x1;}},ql=function(_0x398992,_0x7bab20){return _0x398992===_0x7bab20?0x0:_0x398992<_0x7bab20?-0x1:0x1;},vt=function(_0xa4405e,_0x253f7a){if(_0x253f7a&&_0xa4405e in _0x253f7a)return _0x253f7a[_0xa4405e];throw new Error('Missing\x20required\x20key\x20('+_0xa4405e+')\x20in\x20object:\x20'+O(_0x253f7a));},$i=function(_0x1454bb){if(typeof _0x1454bb!='object'||_0x1454bb===null)return O(_0x1454bb);const _0x443aca=[];for(const _0x9240f9 in _0x1454bb)_0x443aca['push'](_0x9240f9);_0x443aca['sort']();let _0x46ba0f='{';for(let _0x3ed5da=0x0;_0x3ed5da<_0x443aca['length'];_0x3ed5da++)_0x3ed5da!==0x0&&(_0x46ba0f+=','),_0x46ba0f+=O(_0x443aca[_0x3ed5da]),_0x46ba0f+=':',_0x46ba0f+=$i(_0x1454bb[_0x443aca[_0x3ed5da]]);return _0x46ba0f+='}',_0x46ba0f;},oo=function(_0x104541,_0x21d35f){const _0x14fc51=_0x104541['length'];if(_0x14fc51<=_0x21d35f)return[_0x104541];const _0x49da58=[];for(let _0x139e4d=0x0;_0x139e4d<_0x14fc51;_0x139e4d+=_0x21d35f)_0x139e4d+_0x21d35f>_0x14fc51?_0x49da58['push'](_0x104541['substring'](_0x139e4d,_0x14fc51)):_0x49da58['push'](_0x104541['substring'](_0x139e4d,_0x139e4d+_0x21d35f));return _0x49da58;};function x(_0x5321aa,_0xd0088){for(const _0x459330 in _0x5321aa)_0x5321aa['hasOwnProperty'](_0x459330)&&_0xd0088(_0x459330,_0x5321aa[_0x459330]);}const ao=function(_0x4dacb0){f(!xn(_0x4dacb0),'Invalid\x20JSON\x20number');const _0x6b3aa0=0xb,_0x160d66=0x34,_0x5c7010=(0x1<<_0x6b3aa0-0x1)-0x1;let _0x3aa33a,_0x2e9017,_0x2705ad,_0x246d9b,_0xccc6b;_0x4dacb0===0x0?(_0x2e9017=0x0,_0x2705ad=0x0,_0x3aa33a=0x1/_0x4dacb0===-0x1/0x0?0x1:0x0):(_0x3aa33a=_0x4dacb0<0x0,_0x4dacb0=Math['abs'](_0x4dacb0),_0x4dacb0>=Math['pow'](0x2,0x1-_0x5c7010)?(_0x246d9b=Math['min'](Math['floor'](Math['log'](_0x4dacb0)/Math['LN2']),_0x5c7010),_0x2e9017=_0x246d9b+_0x5c7010,_0x2705ad=Math['round'](_0x4dacb0*Math['pow'](0x2,_0x160d66-_0x246d9b)-Math['pow'](0x2,_0x160d66))):(_0x2e9017=0x0,_0x2705ad=Math['round'](_0x4dacb0/Math['pow'](0x2,0x1-_0x5c7010-_0x160d66))));const _0x31c089=[];for(_0xccc6b=_0x160d66;_0xccc6b;_0xccc6b-=0x1)_0x31c089['push'](_0x2705ad%0x2?0x1:0x0),_0x2705ad=Math['floor'](_0x2705ad/0x2);for(_0xccc6b=_0x6b3aa0;_0xccc6b;_0xccc6b-=0x1)_0x31c089['push'](_0x2e9017%0x2?0x1:0x0),_0x2e9017=Math['floor'](_0x2e9017/0x2);_0x31c089['push'](_0x3aa33a?0x1:0x0),_0x31c089['reverse']();const _0x5ef9c0=_0x31c089['join']('');let _0xe2b7fc='';for(_0xccc6b=0x0;_0xccc6b<0x40;_0xccc6b+=0x8){let _0x1b499a=parseInt(_0x5ef9c0['substr'](_0xccc6b,0x8),0x2)['toString'](0x10);_0x1b499a['length']===0x1&&(_0x1b499a='0'+_0x1b499a),_0xe2b7fc=_0xe2b7fc+_0x1b499a;}return _0xe2b7fc['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x5541f4,_0x5297f0){let _0x306809='Unknown\x20Error';_0x5541f4==='too_big'?_0x306809='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5541f4==='permission_denied'?_0x306809='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5541f4==='unavailable'&&(_0x306809='The\x20service\x20is\x20unavailable');const _0x1169d0=new Error(_0x5541f4+'\x20at\x20'+_0x5297f0['_path']['toString']()+':\x20'+_0x306809);return _0x1169d0['code']=_0x5541f4['toUpperCase'](),_0x1169d0;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x2746b1){if(Yl['test'](_0x2746b1)){const _0x4f9ecd=Number(_0x2746b1);if(_0x4f9ecd>=Ql&&_0x4f9ecd<=Jl)return _0x4f9ecd;}return null;},ft=function(_0x5a8142){try{_0x5a8142();}catch(_0x5db52c){setTimeout(()=>{const _0x2cdb4c=_0x5db52c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x2cdb4c),_0x5db52c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x4dc312,_0x12e3b0){const _0x5e0e01=setTimeout(_0x4dc312,_0x12e3b0);return typeof _0x5e0e01=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5e0e01):typeof _0x5e0e01=='object'&&_0x5e0e01['unref']&&_0x5e0e01['unref'](),_0x5e0e01;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0xada83a,_0x3c7766){this['appCheckProvider']=_0x3c7766,this['appName']=_0xada83a['name'],$(_0xada83a)&&_0xada83a['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xada83a['settings']['appCheckToken']),this['appCheck']=_0x3c7766==null?void 0x0:_0x3c7766['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3c7766==null||_0x3c7766['get']()['then'](_0x1c735e=>this['appCheck']=_0x1c735e);}['getToken'](_0x1fdeb4){if(this['serverAppAppCheckToken']){if(_0x1fdeb4)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1fdeb4):new Promise((_0x269343,_0x3b3ab0)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1fdeb4)['then'](_0x269343,_0x3b3ab0):_0x269343(null);},0x0);});}['addTokenChangeListener'](_0x3750e1){var _0x256752;(_0x256752=this['appCheckProvider'])==null||_0x256752['get']()['then'](_0xb4e93=>_0xb4e93['addTokenListener'](_0x3750e1));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5351ab,_0x5bd605,_0x5567ec){this['appName_']=_0x5351ab,this['firebaseOptions_']=_0x5bd605,this['authProvider_']=_0x5567ec,this['auth_']=null,this['auth_']=_0x5567ec['getImmediate']({'optional':!0x0}),this['auth_']||_0x5567ec['onInit'](_0x51b67a=>this['auth_']=_0x51b67a);}['getToken'](_0x620476){return this['auth_']?this['auth_']['getToken'](_0x620476)['catch'](_0xe52aab=>_0xe52aab&&_0xe52aab['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xe52aab)):new Promise((_0x411bd5,_0x23658b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x620476)['then'](_0x411bd5,_0x23658b):_0x411bd5(null);},0x0);});}['addTokenChangeListener'](_0x4bad8f){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4bad8f):this['authProvider_']['get']()['then'](_0x2fdcc3=>_0x2fdcc3['addAuthTokenListener'](_0x4bad8f));}['removeTokenChangeListener'](_0x4a99eb){this['authProvider_']['get']()['then'](_0x2792bd=>_0x2792bd['removeAuthTokenListener'](_0x4a99eb));}['notifyForInvalidToken'](){let _0x292ebe='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x292ebe+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x292ebe+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x292ebe+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x292ebe);}}class an{constructor(_0x6dce9d){this['accessToken']=_0x6dce9d;}['getToken'](_0x3e9841){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5f194b){_0x5f194b(this['accessToken']);}['removeTokenChangeListener'](_0x29e4a9){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x3f4d07,_0x56c6e0,_0x168a64,_0xbe2217,_0x5e366b=!0x1,_0x2afebd='',_0x527bdc=!0x1,_0x591cb1=!0x1,_0x4b8ed6=null){this['secure']=_0x56c6e0,this['namespace']=_0x168a64,this['webSocketOnly']=_0xbe2217,this['nodeAdmin']=_0x5e366b,this['persistenceKey']=_0x2afebd,this['includeNamespaceInQueryParams']=_0x527bdc,this['isUsingEmulator']=_0x591cb1,this['emulatorOptions']=_0x4b8ed6,this['_host']=_0x3f4d07['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x3f4d07)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x11898f){_0x11898f!==this['internalHost']&&(this['internalHost']=_0x11898f,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1ed5a7=this['toURLString']();return this['persistenceKey']&&(_0x1ed5a7+='<'+this['persistenceKey']+'>'),_0x1ed5a7;}['toURLString'](){const _0xe6371b=this['secure']?'https://':'http://',_0x472b9a=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xe6371b+this['host']+'/'+_0x472b9a;}}function th(_0x27f538){return _0x27f538['host']!==_0x27f538['internalHost']||_0x27f538['isCustomHost']()||_0x27f538['includeNamespaceInQueryParams'];}function vo(_0x239bd1,_0x4987a0,_0xfa1ad0){f(typeof _0x4987a0=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xfa1ad0=='object','typeof\x20params\x20must\x20==\x20object');let _0x1f6c1a;if(_0x4987a0===go)_0x1f6c1a=(_0x239bd1['secure']?'wss://':'ws://')+_0x239bd1['internalHost']+'/.ws?';else{if(_0x4987a0===mo)_0x1f6c1a=(_0x239bd1['secure']?'https://':'http://')+_0x239bd1['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x4987a0);}th(_0x239bd1)&&(_0xfa1ad0['ns']=_0x239bd1['namespace']);const _0x1b8243=[];return x(_0xfa1ad0,(_0x10337f,_0xcdf134)=>{_0x1b8243['push'](_0x10337f+'='+_0xcdf134);}),_0x1f6c1a+_0x1b8243['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x576fc8,_0x5b2cf1=0x1){Q(this['counters_'],_0x576fc8)||(this['counters_'][_0x576fc8]=0x0),this['counters_'][_0x576fc8]+=_0x5b2cf1;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x5d1cb4){const _0x459277=_0x5d1cb4['toString']();return oi[_0x459277]||(oi[_0x459277]=new nh()),oi[_0x459277];}function ih(_0x4ff973,_0x3914b2){const _0x57d746=_0x4ff973['toString']();return ai[_0x57d746]||(ai[_0x57d746]=_0x3914b2()),ai[_0x57d746];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x22fed6){this['onMessage_']=_0x22fed6,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x59e342,_0x4ddf34){this['closeAfterResponse']=_0x59e342,this['onClose']=_0x4ddf34,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3849d6,_0x2b4e37){for(this['pendingResponses'][_0x3849d6]=_0x2b4e37;this['pendingResponses'][this['currentResponseNum']];){const _0x4a89b8=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x14df60=0x0;_0x14df60<_0x4a89b8['length'];++_0x14df60)_0x4a89b8[_0x14df60]&&ft(()=>{this['onMessage_'](_0x4a89b8[_0x14df60]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x1d69c3,_0x23a33d,_0x37ea22,_0x4ce75a,_0x541715,_0x1600d7,_0x1bd2cd){this['connId']=_0x1d69c3,this['repoInfo']=_0x23a33d,this['applicationId']=_0x37ea22,this['appCheckToken']=_0x4ce75a,this['authToken']=_0x541715,this['transportSessionId']=_0x1600d7,this['lastSessionId']=_0x1bd2cd,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x1d69c3),this['stats_']=qi(_0x23a33d),this['urlFn']=_0x2911ee=>(this['appCheckToken']&&(_0x2911ee[wi]=this['appCheckToken']),vo(_0x23a33d,mo,_0x2911ee));}['open'](_0xb753c9,_0x1eef24){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1eef24,this['myPacketOrderer']=new sh(_0xb753c9),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x7dddda)=>{const [_0x2c6ce2,_0x28d086,_0x4b5560,_0x2b95ec,_0x231708]=_0x7dddda;if(this['incrementIncomingBytes_'](_0x7dddda),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2c6ce2===qs)this['id']=_0x28d086,this['password']=_0x4b5560;else{if(_0x2c6ce2===rh)_0x28d086?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x28d086,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2c6ce2);}}},(..._0xf3949c)=>{const [_0x458233,_0x594083]=_0xf3949c;this['incrementIncomingBytes_'](_0xf3949c),this['myPacketOrderer']['handleResponse'](_0x458233,_0x594083);},()=>{this['onClosed_']();},this['urlFn']);const _0x221cd5={};_0x221cd5[qs]='t',_0x221cd5[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x221cd5[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x221cd5[co]=Gi,this['transportSessionId']&&(_0x221cd5[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x221cd5[po]=this['lastSessionId']),this['applicationId']&&(_0x221cd5[_o]=this['applicationId']),this['appCheckToken']&&(_0x221cd5[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x221cd5[ho]=uo);const _0x5d2db3=this['urlFn'](_0x221cd5);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5d2db3),this['scriptTagHolder']['addTag'](_0x5d2db3,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x340d3d){const _0x4c0b36=O(_0x340d3d);this['bytesSent']+=_0x4c0b36['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4c0b36['length']);const _0x525d5d=$r(_0x4c0b36),_0x223747=oo(_0x525d5d,fh);for(let _0x1d337=0x0;_0x1d337<_0x223747['length'];_0x1d337++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x223747['length'],_0x223747[_0x1d337]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x3ac8d1,_0x410130){this['myDisconnFrame']=document['createElement']('iframe');const _0x3da78b={};_0x3da78b[dh]='t',_0x3da78b[Eo]=_0x3ac8d1,_0x3da78b[Io]=_0x410130,this['myDisconnFrame']['src']=this['urlFn'](_0x3da78b),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x145edf){const _0x53ffc7=O(_0x145edf)['length'];this['bytesReceived']+=_0x53ffc7,this['stats_']['incrementCounter']('bytes_received',_0x53ffc7);}}class zi{constructor(_0x2e98c5,_0x194a48,_0x5c4955,_0x32bd0e){this['onDisconnect']=_0x5c4955,this['urlFn']=_0x32bd0e,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2e98c5,window[ah+this['uniqueCallbackIdentifier']]=_0x194a48,this['myIFrame']=zi['createIFrame_']();let _0x287954='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x287954='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1257e2='<html><body>'+_0x287954+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1257e2),this['myIFrame']['doc']['close']();}catch(_0x5dc052){L('frame\x20writing\x20exception'),_0x5dc052['stack']&&L(_0x5dc052['stack']),L(_0x5dc052);}}}static['createIFrame_'](){const _0x92e0d7=document['createElement']('iframe');if(_0x92e0d7['style']['display']='none',document['body']){document['body']['appendChild'](_0x92e0d7);try{_0x92e0d7['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x8003ce=document['domain'];_0x92e0d7['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x8003ce+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x92e0d7['contentDocument']?_0x92e0d7['doc']=_0x92e0d7['contentDocument']:_0x92e0d7['contentWindow']?_0x92e0d7['doc']=_0x92e0d7['contentWindow']['document']:_0x92e0d7['document']&&(_0x92e0d7['doc']=_0x92e0d7['document']),_0x92e0d7;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x40435f=this['onDisconnect'];_0x40435f&&(this['onDisconnect']=null,_0x40435f());}['startLongPoll'](_0x3bdd8c,_0x26856b){for(this['myID']=_0x3bdd8c,this['myPW']=_0x26856b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x434a48={};_0x434a48[Eo]=this['myID'],_0x434a48[Io]=this['myPW'],_0x434a48[wo]=this['currentSerial'];let _0xd4cfba=this['urlFn'](_0x434a48),_0x2ca132='',_0x5151f9=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2ca132['length']<=Co;){const _0x3c913b=this['pendingSegs']['shift']();_0x2ca132=_0x2ca132+'&'+lh+_0x5151f9+'='+_0x3c913b['seg']+'&'+hh+_0x5151f9+'='+_0x3c913b['ts']+'&'+uh+_0x5151f9+'='+_0x3c913b['d'],_0x5151f9++;}return _0xd4cfba=_0xd4cfba+_0x2ca132,this['addLongPollTag_'](_0xd4cfba,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x231754,_0x44e76c,_0x4d96a2){this['pendingSegs']['push']({'seg':_0x231754,'ts':_0x44e76c,'d':_0x4d96a2}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x588e16,_0x251b41){this['outstandingRequests']['add'](_0x251b41);const _0x12a3d6=()=>{this['outstandingRequests']['delete'](_0x251b41),this['newRequest_']();},_0x1a06cb=setTimeout(_0x12a3d6,Math['floor'](ph)),_0x5f75e=()=>{clearTimeout(_0x1a06cb),_0x12a3d6();};this['addTag'](_0x588e16,_0x5f75e);}['addTag'](_0x126741,_0x4cb1e6){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x127cd8=this['myIFrame']['doc']['createElement']('script');_0x127cd8['type']='text/javascript',_0x127cd8['async']=!0x0,_0x127cd8['src']=_0x126741,_0x127cd8['onload']=_0x127cd8['onreadystatechange']=function(){const _0x5bac7f=_0x127cd8['readyState'];(!_0x5bac7f||_0x5bac7f==='loaded'||_0x5bac7f==='complete')&&(_0x127cd8['onload']=_0x127cd8['onreadystatechange']=null,_0x127cd8['parentNode']&&_0x127cd8['parentNode']['removeChild'](_0x127cd8),_0x4cb1e6());},_0x127cd8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x126741),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x127cd8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x4dedfd,_0x493c1b,_0xadbfe3,_0x2436fb,_0x5e5101,_0xb0ec5b,_0x35f2d5){this['connId']=_0x4dedfd,this['applicationId']=_0xadbfe3,this['appCheckToken']=_0x2436fb,this['authToken']=_0x5e5101,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x493c1b),this['connURL']=q['connectionURL_'](_0x493c1b,_0xb0ec5b,_0x35f2d5,_0x2436fb,_0xadbfe3),this['nodeAdmin']=_0x493c1b['nodeAdmin'];}static['connectionURL_'](_0x106617,_0x45c692,_0x54eb77,_0x1a06fe,_0x1359d3){const _0x38a09a={};return _0x38a09a[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x38a09a[ho]=uo),_0x45c692&&(_0x38a09a[lo]=_0x45c692),_0x54eb77&&(_0x38a09a[po]=_0x54eb77),_0x1a06fe&&(_0x38a09a[wi]=_0x1a06fe),_0x1359d3&&(_0x38a09a[_o]=_0x1359d3),vo(_0x106617,go,_0x38a09a);}['open'](_0x42db1f,_0x4039aa){this['onDisconnect']=_0x4039aa,this['onMessage']=_0x42db1f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x57fd49;_c(),this['mySock']=new gn(this['connURL'],[],_0x57fd49);}catch(_0x4165fd){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x66a539=_0x4165fd['message']||_0x4165fd['data'];_0x66a539&&this['log_'](_0x66a539),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xb2e1bd=>{this['handleIncomingFrame'](_0xb2e1bd);},this['mySock']['onerror']=_0x4a99be=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xb8c387=_0x4a99be['message']||_0x4a99be['data'];_0xb8c387&&this['log_'](_0xb8c387),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x50a244=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x71137f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1f1d45=navigator['userAgent']['match'](_0x71137f);_0x1f1d45&&_0x1f1d45['length']>0x1&&parseFloat(_0x1f1d45[0x1])<4.4&&(_0x50a244=!0x0);}return!_0x50a244&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5b12d7){if(this['frames']['push'](_0x5b12d7),this['frames']['length']===this['totalFrames']){const _0x42ec8f=this['frames']['join']('');this['frames']=null;const _0x22939e=Nt(_0x42ec8f);this['onMessage'](_0x22939e);}}['handleNewFrameCount_'](_0x1eafe0){this['totalFrames']=_0x1eafe0,this['frames']=[];}['extractFrameCount_'](_0x583152){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x583152['length']<=0x6){const _0xcc0bd0=Number(_0x583152);if(!isNaN(_0xcc0bd0))return this['handleNewFrameCount_'](_0xcc0bd0),null;}return this['handleNewFrameCount_'](0x1),_0x583152;}['handleIncomingFrame'](_0x39777f){if(this['mySock']===null)return;const _0x24b8d8=_0x39777f['data'];if(this['bytesReceived']+=_0x24b8d8['length'],this['stats_']['incrementCounter']('bytes_received',_0x24b8d8['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x24b8d8);else{const _0x1a266c=this['extractFrameCount_'](_0x24b8d8);_0x1a266c!==null&&this['appendFrame_'](_0x1a266c);}}['send'](_0x37e5e9){this['resetKeepAlive']();const _0x2b8d30=O(_0x37e5e9);this['bytesSent']+=_0x2b8d30['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2b8d30['length']);const _0x5afb08=oo(_0x2b8d30,gh);_0x5afb08['length']>0x1&&this['sendString_'](String(_0x5afb08['length']));for(let _0x2897e7=0x0;_0x2897e7<_0x5afb08['length'];_0x2897e7++)this['sendString_'](_0x5afb08[_0x2897e7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2cdec0){try{this['mySock']['send'](_0x2cdec0);}catch(_0xd30ecd){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0xd30ecd['message']||_0xd30ecd['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xd29893){this['initTransports_'](_0xd29893);}['initTransports_'](_0x25270f){const _0x315891=q&&q['isAvailable']();let _0x1e5a99=_0x315891&&!q['previouslyFailed']();if(_0x25270f['webSocketOnly']&&(_0x315891||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1e5a99=!0x0),_0x1e5a99)this['transports_']=[q];else{const _0x31f6b6=this['transports_']=[];for(const _0x2f9b3c of Dt['ALL_TRANSPORTS'])_0x2f9b3c&&_0x2f9b3c['isAvailable']()&&_0x31f6b6['push'](_0x2f9b3c);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4cfb5e,_0xb39653,_0x1f68f7,_0x4cfd09,_0x352120,_0x1a0482,_0x3319e6,_0x5bacad,_0x3c3b54,_0x5cb195){this['id']=_0x4cfb5e,this['repoInfo_']=_0xb39653,this['applicationId_']=_0x1f68f7,this['appCheckToken_']=_0x4cfd09,this['authToken_']=_0x352120,this['onMessage_']=_0x1a0482,this['onReady_']=_0x3319e6,this['onDisconnect_']=_0x5bacad,this['onKill_']=_0x3c3b54,this['lastSessionId']=_0x5cb195,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0xb39653),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xfc1866=this['transportManager_']['initialTransport']();this['conn_']=new _0xfc1866(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xfc1866['responsesRequiredToBeHealthy']||0x0;const _0x383b81=this['connReceiver_'](this['conn_']),_0x4074d2=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x383b81,_0x4074d2);},Math['floor'](0x0));const _0x5bd41e=_0xfc1866['healthyTimeout']||0x0;_0x5bd41e>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5bd41e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2faf0a){return _0x35726=>{_0x2faf0a===this['conn_']?this['onConnectionLost_'](_0x35726):_0x2faf0a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x6a455a){return _0x422fb1=>{this['state_']!==0x2&&(_0x6a455a===this['rx_']?this['onPrimaryMessageReceived_'](_0x422fb1):_0x6a455a===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x422fb1):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1a6e1a){const _0x529902={'t':'d','d':_0x1a6e1a};this['sendData_'](_0x529902);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1f7a36){if(ci in _0x1f7a36){const _0x364b65=_0x1f7a36[ci];_0x364b65===Ys?this['upgradeIfSecondaryHealthy_']():_0x364b65===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x364b65===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x160c3c){const _0x586aa6=vt('t',_0x160c3c),_0x5a1c5d=vt('d',_0x160c3c);if(_0x586aa6==='c')this['onSecondaryControl_'](_0x5a1c5d);else{if(_0x586aa6==='d')this['pendingDataMessages']['push'](_0x5a1c5d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x586aa6);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x42d6dd){const _0x1d596e=vt('t',_0x42d6dd),_0x416cbb=vt('d',_0x42d6dd);_0x1d596e==='c'?this['onControl_'](_0x416cbb):_0x1d596e==='d'&&this['onDataMessage_'](_0x416cbb);}['onDataMessage_'](_0x475876){this['onPrimaryResponse_'](),this['onMessage_'](_0x475876);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x10ca94){const _0xd7d37=vt(ci,_0x10ca94);if(zs in _0x10ca94){const _0x46a401=_0x10ca94[zs];if(_0xd7d37===Th){const _0x1e20bc={..._0x46a401};this['repoInfo_']['isUsingEmulator']&&(_0x1e20bc['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1e20bc);}else{if(_0xd7d37===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2ac6b1=0x0;_0x2ac6b1<this['pendingDataMessages']['length'];++_0x2ac6b1)this['onDataMessage_'](this['pendingDataMessages'][_0x2ac6b1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xd7d37===wh?this['onConnectionShutdown_'](_0x46a401):_0xd7d37===js?this['onReset_'](_0x46a401):_0xd7d37===Ch?Ii('Server\x20Error:\x20'+_0x46a401):_0xd7d37===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xd7d37);}}}['onHandshake_'](_0x4ddd12){const _0x240459=_0x4ddd12['ts'],_0x55a109=_0x4ddd12['v'],_0x31ff67=_0x4ddd12['h'];this['sessionId']=_0x4ddd12['s'],this['repoInfo_']['host']=_0x31ff67,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x240459),Gi!==_0x55a109&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x61a94=this['transportManager_']['upgradeTransport']();_0x61a94&&this['startUpgrade_'](_0x61a94);}['startUpgrade_'](_0x4706fa){this['secondaryConn_']=new _0x4706fa(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4706fa['responsesRequiredToBeHealthy']||0x0;const _0x102504=this['connReceiver_'](this['secondaryConn_']),_0xc0b94a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x102504,_0xc0b94a),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0xf88411){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xf88411),this['repoInfo_']['host']=_0xf88411,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x32e337,_0x4f4b84){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x32e337,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4f4b84,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5b06da=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5b06da||this['rx_']===_0x5b06da)&&this['close']();}['onConnectionLost_'](_0x3eeaf9){this['conn_']=null,!_0x3eeaf9&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3e5db7){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3e5db7),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x14792f){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x14792f);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x478b6f,_0x544093,_0x9b2344,_0x7bf0f7){}['merge'](_0x5ebc30,_0x24cee0,_0x15db7e,_0xf54136){}['refreshAuthToken'](_0x22c2d0){}['refreshAppCheckToken'](_0x1e0390){}['onDisconnectPut'](_0x3c1801,_0x587697,_0x174855){}['onDisconnectMerge'](_0x1b80e6,_0x4ba8f8,_0x5d23e9){}['onDisconnectCancel'](_0x5f38ae,_0x27b18c){}['reportStats'](_0x11dc5b){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1c21d1){this['allowedEvents_']=_0x1c21d1,this['listeners_']={},f(Array['isArray'](_0x1c21d1)&&_0x1c21d1['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x70a69b,..._0x15ad26){if(Array['isArray'](this['listeners_'][_0x70a69b])){const _0x7e4ad4=[...this['listeners_'][_0x70a69b]];for(let _0xe0e362=0x0;_0xe0e362<_0x7e4ad4['length'];_0xe0e362++)_0x7e4ad4[_0xe0e362]['callback']['apply'](_0x7e4ad4[_0xe0e362]['context'],_0x15ad26);}}['on'](_0x4eaaed,_0x23cedb,_0x2d96ee){this['validateEventType_'](_0x4eaaed),this['listeners_'][_0x4eaaed]=this['listeners_'][_0x4eaaed]||[],this['listeners_'][_0x4eaaed]['push']({'callback':_0x23cedb,'context':_0x2d96ee});const _0x1bb0e4=this['getInitialEvent'](_0x4eaaed);_0x1bb0e4&&_0x23cedb['apply'](_0x2d96ee,_0x1bb0e4);}['off'](_0x13db0b,_0x4006d4,_0x49017b){this['validateEventType_'](_0x13db0b);const _0x32948c=this['listeners_'][_0x13db0b]||[];for(let _0x8cb5c8=0x0;_0x8cb5c8<_0x32948c['length'];_0x8cb5c8++)if(_0x32948c[_0x8cb5c8]['callback']===_0x4006d4&&(!_0x49017b||_0x49017b===_0x32948c[_0x8cb5c8]['context'])){_0x32948c['splice'](_0x8cb5c8,0x1);return;}}['validateEventType_'](_0x46f8f4){f(this['allowedEvents_']['find'](_0x3980f4=>_0x3980f4===_0x46f8f4),'Unknown\x20event:\x20'+_0x46f8f4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4bf4c1){return f(_0x4bf4c1==='online','Unknown\x20event\x20type:\x20'+_0x4bf4c1),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x3e731,_0x1059ce){if(_0x1059ce===void 0x0){this['pieces_']=_0x3e731['split']('/');let _0x139b20=0x0;for(let _0x1c4389=0x0;_0x1c4389<this['pieces_']['length'];_0x1c4389++)this['pieces_'][_0x1c4389]['length']>0x0&&(this['pieces_'][_0x139b20]=this['pieces_'][_0x1c4389],_0x139b20++);this['pieces_']['length']=_0x139b20,this['pieceNum_']=0x0;}else this['pieces_']=_0x3e731,this['pieceNum_']=_0x1059ce;}['toString'](){let _0x42f291='';for(let _0x1f5778=this['pieceNum_'];_0x1f5778<this['pieces_']['length'];_0x1f5778++)this['pieces_'][_0x1f5778]!==''&&(_0x42f291+='/'+this['pieces_'][_0x1f5778]);return _0x42f291||'/';}}function w(){return new C('');}function y(_0x120a59){return _0x120a59['pieceNum_']>=_0x120a59['pieces_']['length']?null:_0x120a59['pieces_'][_0x120a59['pieceNum_']];}function Ce(_0x26bef9){return _0x26bef9['pieces_']['length']-_0x26bef9['pieceNum_'];}function S(_0x44a2f1){let _0x2c6f57=_0x44a2f1['pieceNum_'];return _0x2c6f57<_0x44a2f1['pieces_']['length']&&_0x2c6f57++,new C(_0x44a2f1['pieces_'],_0x2c6f57);}function ji(_0x13828a){return _0x13828a['pieceNum_']<_0x13828a['pieces_']['length']?_0x13828a['pieces_'][_0x13828a['pieces_']['length']-0x1]:null;}function bh(_0x4bb8ee){let _0x2e9345='';for(let _0x37173b=_0x4bb8ee['pieceNum_'];_0x37173b<_0x4bb8ee['pieces_']['length'];_0x37173b++)_0x4bb8ee['pieces_'][_0x37173b]!==''&&(_0x2e9345+='/'+encodeURIComponent(String(_0x4bb8ee['pieces_'][_0x37173b])));return _0x2e9345||'/';}function Mt(_0x2a2136,_0x3cfdae=0x0){return _0x2a2136['pieces_']['slice'](_0x2a2136['pieceNum_']+_0x3cfdae);}function Ro(_0x5681d8){if(_0x5681d8['pieceNum_']>=_0x5681d8['pieces_']['length'])return null;const _0xdae5cd=[];for(let _0x25b6f9=_0x5681d8['pieceNum_'];_0x25b6f9<_0x5681d8['pieces_']['length']-0x1;_0x25b6f9++)_0xdae5cd['push'](_0x5681d8['pieces_'][_0x25b6f9]);return new C(_0xdae5cd,0x0);}function k(_0x344a91,_0x33f8b5){const _0x109b4a=[];for(let _0x114d29=_0x344a91['pieceNum_'];_0x114d29<_0x344a91['pieces_']['length'];_0x114d29++)_0x109b4a['push'](_0x344a91['pieces_'][_0x114d29]);if(_0x33f8b5 instanceof C){for(let _0x5e5697=_0x33f8b5['pieceNum_'];_0x5e5697<_0x33f8b5['pieces_']['length'];_0x5e5697++)_0x109b4a['push'](_0x33f8b5['pieces_'][_0x5e5697]);}else{const _0x229a4b=_0x33f8b5['split']('/');for(let _0x2f3560=0x0;_0x2f3560<_0x229a4b['length'];_0x2f3560++)_0x229a4b[_0x2f3560]['length']>0x0&&_0x109b4a['push'](_0x229a4b[_0x2f3560]);}return new C(_0x109b4a,0x0);}function v(_0x28f104){return _0x28f104['pieceNum_']>=_0x28f104['pieces_']['length'];}function F(_0x414152,_0x90ac49){const _0x5202df=y(_0x414152),_0xa29261=y(_0x90ac49);if(_0x5202df===null)return _0x90ac49;if(_0x5202df===_0xa29261)return F(S(_0x414152),S(_0x90ac49));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x90ac49+')\x20is\x20not\x20within\x20outerPath\x20('+_0x414152+')');}function Rh(_0xa5d128,_0xc6a759){const _0x41f791=Mt(_0xa5d128,0x0),_0x3f69a7=Mt(_0xc6a759,0x0);for(let _0x235a35=0x0;_0x235a35<_0x41f791['length']&&_0x235a35<_0x3f69a7['length'];_0x235a35++){const _0x2a97da=qe(_0x41f791[_0x235a35],_0x3f69a7[_0x235a35]);if(_0x2a97da!==0x0)return _0x2a97da;}return _0x41f791['length']===_0x3f69a7['length']?0x0:_0x41f791['length']<_0x3f69a7['length']?-0x1:0x1;}function Ki(_0x41b4e1,_0x587838){if(Ce(_0x41b4e1)!==Ce(_0x587838))return!0x1;for(let _0x29b505=_0x41b4e1['pieceNum_'],_0x30c808=_0x587838['pieceNum_'];_0x29b505<=_0x41b4e1['pieces_']['length'];_0x29b505++,_0x30c808++)if(_0x41b4e1['pieces_'][_0x29b505]!==_0x587838['pieces_'][_0x30c808])return!0x1;return!0x0;}function G(_0x3779c7,_0xac5340){let _0x1e2fce=_0x3779c7['pieceNum_'],_0x203b3b=_0xac5340['pieceNum_'];if(Ce(_0x3779c7)>Ce(_0xac5340))return!0x1;for(;_0x1e2fce<_0x3779c7['pieces_']['length'];){if(_0x3779c7['pieces_'][_0x1e2fce]!==_0xac5340['pieces_'][_0x203b3b])return!0x1;++_0x1e2fce,++_0x203b3b;}return!0x0;}class Ah{constructor(_0x260807,_0x1527ec){this['errorPrefix_']=_0x1527ec,this['parts_']=Mt(_0x260807,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x37da0d=0x0;_0x37da0d<this['parts_']['length'];_0x37da0d++)this['byteLength_']+=Ln(this['parts_'][_0x37da0d]);Ao(this);}}function kh(_0x4b208b,_0x41c79a){_0x4b208b['parts_']['length']>0x0&&(_0x4b208b['byteLength_']+=0x1),_0x4b208b['parts_']['push'](_0x41c79a),_0x4b208b['byteLength_']+=Ln(_0x41c79a),Ao(_0x4b208b);}function Ph(_0x23055e){const _0x43b40b=_0x23055e['parts_']['pop']();_0x23055e['byteLength_']-=Ln(_0x43b40b),_0x23055e['parts_']['length']>0x0&&(_0x23055e['byteLength_']-=0x1);}function Ao(_0x2c6139){if(_0x2c6139['byteLength_']>Zs)throw new Error(_0x2c6139['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x2c6139['byteLength_']+').');if(_0x2c6139['parts_']['length']>Xs)throw new Error(_0x2c6139['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x2c6139));}function Oe(_0x1f003d){return _0x1f003d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1f003d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x167fb6,_0x3b42df;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3b42df='visibilitychange',_0x167fb6='hidden'):typeof document['mozHidden']<'u'?(_0x3b42df='mozvisibilitychange',_0x167fb6='mozHidden'):typeof document['msHidden']<'u'?(_0x3b42df='msvisibilitychange',_0x167fb6='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3b42df='webkitvisibilitychange',_0x167fb6='webkitHidden')),this['visible_']=!0x0,_0x3b42df&&document['addEventListener'](_0x3b42df,()=>{const _0x29765c=!document[_0x167fb6];_0x29765c!==this['visible_']&&(this['visible_']=_0x29765c,this['trigger']('visible',_0x29765c));},!0x1);}['getInitialEvent'](_0x1fb356){return f(_0x1fb356==='visible','Unknown\x20event\x20type:\x20'+_0x1fb356),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x1a0186,_0x4aeba1,_0x384653,_0x28dbf5,_0x5679fa,_0x28159c,_0x3f10f2,_0x9d5814){if(super(),this['repoInfo_']=_0x1a0186,this['applicationId_']=_0x4aeba1,this['onDataUpdate_']=_0x384653,this['onConnectStatus_']=_0x28dbf5,this['onServerInfoUpdate_']=_0x5679fa,this['authTokenProvider_']=_0x28159c,this['appCheckTokenProvider_']=_0x3f10f2,this['authOverride_']=_0x9d5814,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x9d5814)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1a0186['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xb2e55b,_0x34d661,_0x39b2b5){const _0x111ae2=++this['requestNumber_'],_0x25e349={'r':_0x111ae2,'a':_0xb2e55b,'b':_0x34d661};this['log_'](O(_0x25e349)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x25e349),_0x39b2b5&&(this['requestCBHash_'][_0x111ae2]=_0x39b2b5);}['get'](_0x1d34ef){this['initConnection_']();const _0x22e99d=new H(),_0x193707={'action':'g','request':{'p':_0x1d34ef['_path']['toString'](),'q':_0x1d34ef['_queryObject']},'onComplete':_0x3559c6=>{const _0x4f4398=_0x3559c6['d'];_0x3559c6['s']==='ok'?_0x22e99d['resolve'](_0x4f4398):_0x22e99d['reject'](_0x4f4398);}};this['outstandingGets_']['push'](_0x193707),this['outstandingGetCount_']++;const _0x14065d=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x14065d),_0x22e99d['promise'];}['listen'](_0x241c8b,_0x123b74,_0x241cfa,_0x216372){this['initConnection_']();const _0x4335e4=_0x241c8b['_queryIdentifier'],_0x2504ac=_0x241c8b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2504ac+'\x20'+_0x4335e4),this['listens']['has'](_0x2504ac)||this['listens']['set'](_0x2504ac,new Map()),f(_0x241c8b['_queryParams']['isDefault']()||!_0x241c8b['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2504ac)['has'](_0x4335e4),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x25bae5={'onComplete':_0x216372,'hashFn':_0x123b74,'query':_0x241c8b,'tag':_0x241cfa};this['listens']['get'](_0x2504ac)['set'](_0x4335e4,_0x25bae5),this['connected_']&&this['sendListen_'](_0x25bae5);}['sendGet_'](_0x19e3bf){const _0x1aa5cc=this['outstandingGets_'][_0x19e3bf];this['sendRequest']('g',_0x1aa5cc['request'],_0x5a4599=>{delete this['outstandingGets_'][_0x19e3bf],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1aa5cc['onComplete']&&_0x1aa5cc['onComplete'](_0x5a4599);});}['sendListen_'](_0x28121e){const _0x1b8fb3=_0x28121e['query'],_0x579396=_0x1b8fb3['_path']['toString'](),_0x522ff0=_0x1b8fb3['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x579396+'\x20for\x20'+_0x522ff0);const _0x53669c={'p':_0x579396},_0x340518='q';_0x28121e['tag']&&(_0x53669c['q']=_0x1b8fb3['_queryObject'],_0x53669c['t']=_0x28121e['tag']),_0x53669c['h']=_0x28121e['hashFn'](),this['sendRequest'](_0x340518,_0x53669c,_0x4a98ec=>{const _0x58533d=_0x4a98ec['d'],_0x1ca9fc=_0x4a98ec['s'];se['warnOnListenWarnings_'](_0x58533d,_0x1b8fb3),(this['listens']['get'](_0x579396)&&this['listens']['get'](_0x579396)['get'](_0x522ff0))===_0x28121e&&(this['log_']('listen\x20response',_0x4a98ec),_0x1ca9fc!=='ok'&&this['removeListen_'](_0x579396,_0x522ff0),_0x28121e['onComplete']&&_0x28121e['onComplete'](_0x1ca9fc,_0x58533d));});}static['warnOnListenWarnings_'](_0x4021f0,_0x378345){if(_0x4021f0&&typeof _0x4021f0=='object'&&Q(_0x4021f0,'w')){const _0x1dd085=Le(_0x4021f0,'w');if(Array['isArray'](_0x1dd085)&&~_0x1dd085['indexOf']('no_index')){const _0x5aba71='\x22.indexOn\x22:\x20\x22'+_0x378345['_queryParams']['getIndex']()['toString']()+'\x22',_0x44be94=_0x378345['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5aba71+'\x20at\x20'+_0x44be94+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x45f1b8){this['authToken_']=_0x45f1b8,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x45f1b8);}['reduceReconnectDelayIfAdminCredential_'](_0x4860c9){(_0x4860c9&&_0x4860c9['length']===0x28||wc(_0x4860c9))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x35db2b){this['appCheckToken_']=_0x35db2b,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x10b9dd=this['authToken_'],_0x1571c2=Ic(_0x10b9dd)?'auth':'gauth',_0x363851={'cred':_0x10b9dd};this['authOverride_']===null?_0x363851['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x363851['authvar']=this['authOverride_']),this['sendRequest'](_0x1571c2,_0x363851,_0x5c5561=>{const _0x25b18b=_0x5c5561['s'],_0x2df620=_0x5c5561['d']||'error';this['authToken_']===_0x10b9dd&&(_0x25b18b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x25b18b,_0x2df620));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x572187=>{const _0x4f09aa=_0x572187['s'],_0x30abc6=_0x572187['d']||'error';_0x4f09aa==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4f09aa,_0x30abc6);});}['unlisten'](_0x428163,_0x116c84){const _0x2b713c=_0x428163['_path']['toString'](),_0x1f2d89=_0x428163['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2b713c+'\x20'+_0x1f2d89),f(_0x428163['_queryParams']['isDefault']()||!_0x428163['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2b713c,_0x1f2d89)&&this['connected_']&&this['sendUnlisten_'](_0x2b713c,_0x1f2d89,_0x428163['_queryObject'],_0x116c84);}['sendUnlisten_'](_0xdfec61,_0x40669a,_0xfba67c,_0x59991b){this['log_']('Unlisten\x20on\x20'+_0xdfec61+'\x20for\x20'+_0x40669a);const _0x4e0a48={'p':_0xdfec61},_0x28bc3a='n';_0x59991b&&(_0x4e0a48['q']=_0xfba67c,_0x4e0a48['t']=_0x59991b),this['sendRequest'](_0x28bc3a,_0x4e0a48);}['onDisconnectPut'](_0x268db3,_0x43d84b,_0x2da84f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x268db3,_0x43d84b,_0x2da84f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x268db3,'action':'o','data':_0x43d84b,'onComplete':_0x2da84f});}['onDisconnectMerge'](_0x35d1a4,_0x536045,_0x566f3a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x35d1a4,_0x536045,_0x566f3a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x35d1a4,'action':'om','data':_0x536045,'onComplete':_0x566f3a});}['onDisconnectCancel'](_0x584714,_0x20da4e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x584714,null,_0x20da4e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x584714,'action':'oc','data':null,'onComplete':_0x20da4e});}['sendOnDisconnect_'](_0x59f1ef,_0x1af1c4,_0x42faaf,_0x3b7723){const _0x5db846={'p':_0x1af1c4,'d':_0x42faaf};this['log_']('onDisconnect\x20'+_0x59f1ef,_0x5db846),this['sendRequest'](_0x59f1ef,_0x5db846,_0x23094e=>{_0x3b7723&&setTimeout(()=>{_0x3b7723(_0x23094e['s'],_0x23094e['d']);},Math['floor'](0x0));});}['put'](_0x159b29,_0x546d94,_0x1a5d03,_0x19b048){this['putInternal']('p',_0x159b29,_0x546d94,_0x1a5d03,_0x19b048);}['merge'](_0xf71e1b,_0x81f5ff,_0x3d8a02,_0x238e24){this['putInternal']('m',_0xf71e1b,_0x81f5ff,_0x3d8a02,_0x238e24);}['putInternal'](_0x4ef05d,_0x34ffba,_0x5a19f8,_0x8d11d5,_0x2dc445){this['initConnection_']();const _0x23aa11={'p':_0x34ffba,'d':_0x5a19f8};_0x2dc445!==void 0x0&&(_0x23aa11['h']=_0x2dc445),this['outstandingPuts_']['push']({'action':_0x4ef05d,'request':_0x23aa11,'onComplete':_0x8d11d5}),this['outstandingPutCount_']++;const _0x32be41=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x32be41):this['log_']('Buffering\x20put:\x20'+_0x34ffba);}['sendPut_'](_0x512ea9){const _0xaa91f7=this['outstandingPuts_'][_0x512ea9]['action'],_0x141bdc=this['outstandingPuts_'][_0x512ea9]['request'],_0xfca2a2=this['outstandingPuts_'][_0x512ea9]['onComplete'];this['outstandingPuts_'][_0x512ea9]['queued']=this['connected_'],this['sendRequest'](_0xaa91f7,_0x141bdc,_0x512bb5=>{this['log_'](_0xaa91f7+'\x20response',_0x512bb5),delete this['outstandingPuts_'][_0x512ea9],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xfca2a2&&_0xfca2a2(_0x512bb5['s'],_0x512bb5['d']);});}['reportStats'](_0x5380f8){if(this['connected_']){const _0x39b851={'c':_0x5380f8};this['log_']('reportStats',_0x39b851),this['sendRequest']('s',_0x39b851,_0x47b51c=>{if(_0x47b51c['s']!=='ok'){const _0x78573d=_0x47b51c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x78573d);}});}}['onDataMessage_'](_0x5370db){if('r'in _0x5370db){this['log_']('from\x20server:\x20'+O(_0x5370db));const _0x583c5d=_0x5370db['r'],_0x3dcdd0=this['requestCBHash_'][_0x583c5d];_0x3dcdd0&&(delete this['requestCBHash_'][_0x583c5d],_0x3dcdd0(_0x5370db['b']));}else{if('error'in _0x5370db)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5370db['error'];'a'in _0x5370db&&this['onDataPush_'](_0x5370db['a'],_0x5370db['b']);}}['onDataPush_'](_0x1c062a,_0x4d5e6b){this['log_']('handleServerMessage',_0x1c062a,_0x4d5e6b),_0x1c062a==='d'?this['onDataUpdate_'](_0x4d5e6b['p'],_0x4d5e6b['d'],!0x1,_0x4d5e6b['t']):_0x1c062a==='m'?this['onDataUpdate_'](_0x4d5e6b['p'],_0x4d5e6b['d'],!0x0,_0x4d5e6b['t']):_0x1c062a==='c'?this['onListenRevoked_'](_0x4d5e6b['p'],_0x4d5e6b['q']):_0x1c062a==='ac'?this['onAuthRevoked_'](_0x4d5e6b['s'],_0x4d5e6b['d']):_0x1c062a==='apc'?this['onAppCheckRevoked_'](_0x4d5e6b['s'],_0x4d5e6b['d']):_0x1c062a==='sd'?this['onSecurityDebugPacket_'](_0x4d5e6b):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1c062a)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x281152,_0x2c418b){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x281152),this['lastSessionId']=_0x2c418b,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x562d6b){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x562d6b));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x55bc5d){_0x55bc5d&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x55bc5d;}['onOnline_'](_0x5e4ad5){_0x5e4ad5?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5a15a5=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x245d47=Math['max'](0x0,this['reconnectDelay_']-_0x5a15a5);_0x245d47=Math['random']()*_0x245d47,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x245d47+'ms'),this['scheduleConnect_'](_0x245d47),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x584252=this['onDataMessage_']['bind'](this),_0x5619cf=this['onReady_']['bind'](this),_0x39ea1b=this['onRealtimeDisconnect_']['bind'](this),_0x22aaac=this['id']+':'+se['nextConnectionId_']++,_0x22f9d0=this['lastSessionId'];let _0x209264=!0x1,_0x1574f3=null;const _0x4d0d32=function(){_0x1574f3?_0x1574f3['close']():(_0x209264=!0x0,_0x39ea1b());},_0xa7ef3c=function(_0x55bfa3){f(_0x1574f3,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1574f3['sendRequest'](_0x55bfa3);};this['realtime_']={'close':_0x4d0d32,'sendRequest':_0xa7ef3c};const _0x1f1e86=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2d7a58,_0x44c0d0]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x1f1e86),this['appCheckTokenProvider_']['getToken'](_0x1f1e86)]);_0x209264?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2d7a58&&_0x2d7a58['accessToken'],this['appCheckToken_']=_0x44c0d0&&_0x44c0d0['token'],_0x1574f3=new Sh(_0x22aaac,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x584252,_0x5619cf,_0x39ea1b,_0x298017=>{U(_0x298017+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x22f9d0));}catch(_0x44ec7e){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x44ec7e),_0x209264||(this['repoInfo_']['nodeAdmin']&&U(_0x44ec7e),_0x4d0d32());}}}['interrupt'](_0xfb8d8){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xfb8d8),this['interruptReasons_'][_0xfb8d8]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x47aeb7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x47aeb7),delete this['interruptReasons_'][_0x47aeb7],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x3cc946){const _0x252cea=_0x3cc946-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x252cea});}['cancelSentTransactions_'](){for(let _0x218ac=0x0;_0x218ac<this['outstandingPuts_']['length'];_0x218ac++){const _0x3fd425=this['outstandingPuts_'][_0x218ac];_0x3fd425&&'h'in _0x3fd425['request']&&_0x3fd425['queued']&&(_0x3fd425['onComplete']&&_0x3fd425['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x218ac],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x41b507,_0x5f3808){let _0x5865a2;_0x5f3808?_0x5865a2=_0x5f3808['map'](_0x3a44d9=>$i(_0x3a44d9))['join']('$'):_0x5865a2='default';const _0x7628c8=this['removeListen_'](_0x41b507,_0x5865a2);_0x7628c8&&_0x7628c8['onComplete']&&_0x7628c8['onComplete']('permission_denied');}['removeListen_'](_0xebac22,_0x5d304c){const _0x83e9fc=new C(_0xebac22)['toString']();let _0x581eab;if(this['listens']['has'](_0x83e9fc)){const _0x5bea84=this['listens']['get'](_0x83e9fc);_0x581eab=_0x5bea84['get'](_0x5d304c),_0x5bea84['delete'](_0x5d304c),_0x5bea84['size']===0x0&&this['listens']['delete'](_0x83e9fc);}else _0x581eab=void 0x0;return _0x581eab;}['onAuthRevoked_'](_0x460184,_0x5b7212){L('Auth\x20token\x20revoked:\x20'+_0x460184+'/'+_0x5b7212),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x460184==='invalid_token'||_0x460184==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1408a6,_0x5ce466){L('App\x20check\x20token\x20revoked:\x20'+_0x1408a6+'/'+_0x5ce466),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1408a6==='invalid_token'||_0x1408a6==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x47e7ae){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x47e7ae):'msg'in _0x47e7ae&&console['log']('FIREBASE:\x20'+_0x47e7ae['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4ff364 of this['listens']['values']())for(const _0x569b59 of _0x4ff364['values']())this['sendListen_'](_0x569b59);for(let _0x5495a9=0x0;_0x5495a9<this['outstandingPuts_']['length'];_0x5495a9++)this['outstandingPuts_'][_0x5495a9]&&this['sendPut_'](_0x5495a9);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1b8c9d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1b8c9d['action'],_0x1b8c9d['pathString'],_0x1b8c9d['data'],_0x1b8c9d['onComplete']);}for(let _0xe935d1=0x0;_0xe935d1<this['outstandingGets_']['length'];_0xe935d1++)this['outstandingGets_'][_0xe935d1]&&this['sendGet_'](_0xe935d1);}['sendConnectStats_'](){const _0x2c9637={};let _0x2b09e3='js';_0x2c9637['sdk.'+_0x2b09e3+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x2c9637['framework.cordova']=0x1:Kr()&&(_0x2c9637['framework.reactnative']=0x1),this['reportStats'](_0x2c9637);}['shouldReconnect_'](){const _0x4a332f=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x4a332f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x47ab3c,_0x46134d){this['name']=_0x47ab3c,this['node']=_0x46134d;}static['Wrap'](_0x31b982,_0x531a45){return new E(_0x31b982,_0x531a45);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4a16ea,_0x50f1e9){const _0x12a945=new E(We,_0x4a16ea),_0xa7d963=new E(We,_0x50f1e9);return this['compare'](_0x12a945,_0xa7d963)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x37f9f3){sn=_0x37f9f3;}['compare'](_0x23e08b,_0x64a89c){return qe(_0x23e08b['name'],_0x64a89c['name']);}['isDefinedOn'](_0x4d4eaa){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x542090,_0x1b2b3c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x5dd4ff,_0x4bc8a9){return f(typeof _0x5dd4ff=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x5dd4ff,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x4c2aaa,_0x31a48c,_0x519384,_0x272bb5,_0x4b54ac=null){this['isReverse_']=_0x272bb5,this['resultGenerator_']=_0x4b54ac,this['nodeStack_']=[];let _0x49685c=0x1;for(;!_0x4c2aaa['isEmpty']();)if(_0x4c2aaa=_0x4c2aaa,_0x49685c=_0x31a48c?_0x519384(_0x4c2aaa['key'],_0x31a48c):0x1,_0x272bb5&&(_0x49685c*=-0x1),_0x49685c<0x0)this['isReverse_']?_0x4c2aaa=_0x4c2aaa['left']:_0x4c2aaa=_0x4c2aaa['right'];else{if(_0x49685c===0x0){this['nodeStack_']['push'](_0x4c2aaa);break;}else this['nodeStack_']['push'](_0x4c2aaa),this['isReverse_']?_0x4c2aaa=_0x4c2aaa['right']:_0x4c2aaa=_0x4c2aaa['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x326ba1=this['nodeStack_']['pop'](),_0x313466;if(this['resultGenerator_']?_0x313466=this['resultGenerator_'](_0x326ba1['key'],_0x326ba1['value']):_0x313466={'key':_0x326ba1['key'],'value':_0x326ba1['value']},this['isReverse_']){for(_0x326ba1=_0x326ba1['left'];!_0x326ba1['isEmpty']();)this['nodeStack_']['push'](_0x326ba1),_0x326ba1=_0x326ba1['right'];}else{for(_0x326ba1=_0x326ba1['right'];!_0x326ba1['isEmpty']();)this['nodeStack_']['push'](_0x326ba1),_0x326ba1=_0x326ba1['left'];}return _0x313466;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x2199e9=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x2199e9['key'],_0x2199e9['value']):{'key':_0x2199e9['key'],'value':_0x2199e9['value']};}}class M{constructor(_0x8c588b,_0x198415,_0x4ff23c,_0x598567,_0x14e3f6){this['key']=_0x8c588b,this['value']=_0x198415,this['color']=_0x4ff23c??M['RED'],this['left']=_0x598567??B['EMPTY_NODE'],this['right']=_0x14e3f6??B['EMPTY_NODE'];}['copy'](_0x4c571c,_0x588a26,_0x33bdbf,_0x862ace,_0x5de372){return new M(_0x4c571c??this['key'],_0x588a26??this['value'],_0x33bdbf??this['color'],_0x862ace??this['left'],_0x5de372??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4dbac7){return this['left']['inorderTraversal'](_0x4dbac7)||!!_0x4dbac7(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4dbac7);}['reverseTraversal'](_0x5eeb34){return this['right']['reverseTraversal'](_0x5eeb34)||_0x5eeb34(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5eeb34);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x47e40d,_0x3ff98d,_0x709268){let _0x5c9c7c=this;const _0x1ae018=_0x709268(_0x47e40d,_0x5c9c7c['key']);return _0x1ae018<0x0?_0x5c9c7c=_0x5c9c7c['copy'](null,null,null,_0x5c9c7c['left']['insert'](_0x47e40d,_0x3ff98d,_0x709268),null):_0x1ae018===0x0?_0x5c9c7c=_0x5c9c7c['copy'](null,_0x3ff98d,null,null,null):_0x5c9c7c=_0x5c9c7c['copy'](null,null,null,null,_0x5c9c7c['right']['insert'](_0x47e40d,_0x3ff98d,_0x709268)),_0x5c9c7c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x344345=this;return!_0x344345['left']['isRed_']()&&!_0x344345['left']['left']['isRed_']()&&(_0x344345=_0x344345['moveRedLeft_']()),_0x344345=_0x344345['copy'](null,null,null,_0x344345['left']['removeMin_'](),null),_0x344345['fixUp_']();}['remove'](_0x2759d5,_0x2a84b6){let _0x443240,_0xb81000;if(_0x443240=this,_0x2a84b6(_0x2759d5,_0x443240['key'])<0x0)!_0x443240['left']['isEmpty']()&&!_0x443240['left']['isRed_']()&&!_0x443240['left']['left']['isRed_']()&&(_0x443240=_0x443240['moveRedLeft_']()),_0x443240=_0x443240['copy'](null,null,null,_0x443240['left']['remove'](_0x2759d5,_0x2a84b6),null);else{if(_0x443240['left']['isRed_']()&&(_0x443240=_0x443240['rotateRight_']()),!_0x443240['right']['isEmpty']()&&!_0x443240['right']['isRed_']()&&!_0x443240['right']['left']['isRed_']()&&(_0x443240=_0x443240['moveRedRight_']()),_0x2a84b6(_0x2759d5,_0x443240['key'])===0x0){if(_0x443240['right']['isEmpty']())return B['EMPTY_NODE'];_0xb81000=_0x443240['right']['min_'](),_0x443240=_0x443240['copy'](_0xb81000['key'],_0xb81000['value'],null,null,_0x443240['right']['removeMin_']());}_0x443240=_0x443240['copy'](null,null,null,null,_0x443240['right']['remove'](_0x2759d5,_0x2a84b6));}return _0x443240['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5a12c5=this;return _0x5a12c5['right']['isRed_']()&&!_0x5a12c5['left']['isRed_']()&&(_0x5a12c5=_0x5a12c5['rotateLeft_']()),_0x5a12c5['left']['isRed_']()&&_0x5a12c5['left']['left']['isRed_']()&&(_0x5a12c5=_0x5a12c5['rotateRight_']()),_0x5a12c5['left']['isRed_']()&&_0x5a12c5['right']['isRed_']()&&(_0x5a12c5=_0x5a12c5['colorFlip_']()),_0x5a12c5;}['moveRedLeft_'](){let _0x379f5f=this['colorFlip_']();return _0x379f5f['right']['left']['isRed_']()&&(_0x379f5f=_0x379f5f['copy'](null,null,null,null,_0x379f5f['right']['rotateRight_']()),_0x379f5f=_0x379f5f['rotateLeft_'](),_0x379f5f=_0x379f5f['colorFlip_']()),_0x379f5f;}['moveRedRight_'](){let _0x1cf571=this['colorFlip_']();return _0x1cf571['left']['left']['isRed_']()&&(_0x1cf571=_0x1cf571['rotateRight_'](),_0x1cf571=_0x1cf571['colorFlip_']()),_0x1cf571;}['rotateLeft_'](){const _0x1739b3=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1739b3,null);}['rotateRight_'](){const _0x51af5a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x51af5a);}['colorFlip_'](){const _0x404011=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5027e2=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x404011,_0x5027e2);}['checkMaxDepth_'](){const _0x44b7d5=this['check_']();return Math['pow'](0x2,_0x44b7d5)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x54a985=this['left']['check_']();if(_0x54a985!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x54a985+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5f34d1,_0x2b35e4,_0x10aa45,_0x491558,_0x5ee934){return this;}['insert'](_0x6ccacf,_0x21f4f6,_0x3501ce){return new M(_0x6ccacf,_0x21f4f6,null);}['remove'](_0x3de796,_0x483f00){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4d1bed){return!0x1;}['reverseTraversal'](_0x24412d){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x350815,_0x1618cc=B['EMPTY_NODE']){this['comparator_']=_0x350815,this['root_']=_0x1618cc;}['insert'](_0x5b151d,_0x421718){return new B(this['comparator_'],this['root_']['insert'](_0x5b151d,_0x421718,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3b7e30){return new B(this['comparator_'],this['root_']['remove'](_0x3b7e30,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x50f01f){let _0x5c1d61,_0x2b041d=this['root_'];for(;!_0x2b041d['isEmpty']();){if(_0x5c1d61=this['comparator_'](_0x50f01f,_0x2b041d['key']),_0x5c1d61===0x0)return _0x2b041d['value'];_0x5c1d61<0x0?_0x2b041d=_0x2b041d['left']:_0x5c1d61>0x0&&(_0x2b041d=_0x2b041d['right']);}return null;}['getPredecessorKey'](_0x3b1e77){let _0x4c1a3c,_0x3c3b42=this['root_'],_0x322f61=null;for(;!_0x3c3b42['isEmpty']();)if(_0x4c1a3c=this['comparator_'](_0x3b1e77,_0x3c3b42['key']),_0x4c1a3c===0x0){if(_0x3c3b42['left']['isEmpty']())return _0x322f61?_0x322f61['key']:null;for(_0x3c3b42=_0x3c3b42['left'];!_0x3c3b42['right']['isEmpty']();)_0x3c3b42=_0x3c3b42['right'];return _0x3c3b42['key'];}else _0x4c1a3c<0x0?_0x3c3b42=_0x3c3b42['left']:_0x4c1a3c>0x0&&(_0x322f61=_0x3c3b42,_0x3c3b42=_0x3c3b42['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x5180d4){return this['root_']['inorderTraversal'](_0x5180d4);}['reverseTraversal'](_0x653f18){return this['root_']['reverseTraversal'](_0x653f18);}['getIterator'](_0x39b265){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x39b265);}['getIteratorFrom'](_0x17ce9b,_0x173c02){return new rn(this['root_'],_0x17ce9b,this['comparator_'],!0x1,_0x173c02);}['getReverseIteratorFrom'](_0x102a33,_0x11f7fb){return new rn(this['root_'],_0x102a33,this['comparator_'],!0x0,_0x11f7fb);}['getReverseIterator'](_0x5ebd0a){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5ebd0a);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x513cef,_0x3eac16){return qe(_0x513cef['name'],_0x3eac16['name']);}function Qi(_0x3ca6ee,_0x59fa73){return qe(_0x3ca6ee,_0x59fa73);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x52d91f){Ci=_0x52d91f;}const Po=function(_0x536b84){return typeof _0x536b84=='number'?'number:'+ao(_0x536b84):'string:'+_0x536b84;},No=function(_0x588889){if(_0x588889['isLeafNode']()){const _0x4215f2=_0x588889['val']();f(typeof _0x4215f2=='string'||typeof _0x4215f2=='number'||typeof _0x4215f2=='object'&&Q(_0x4215f2,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x588889===Ci||_0x588889['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x588889===Ci||_0x588889['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x18eb2a){nr=_0x18eb2a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x34eb2c,_0x4e56c5=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x34eb2c,this['priorityNode_']=_0x4e56c5,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x58a981){return new D(this['value_'],_0x58a981);}['getImmediateChild'](_0x524f7c){return _0x524f7c==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x101f0e){return v(_0x101f0e)?this:y(_0x101f0e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3fe22c,_0x505b12){return null;}['updateImmediateChild'](_0x1e2219,_0x893441){return _0x1e2219==='.priority'?this['updatePriority'](_0x893441):_0x893441['isEmpty']()&&_0x1e2219!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1e2219,_0x893441)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2368e0,_0x557ac0){const _0x2b0375=y(_0x2368e0);return _0x2b0375===null?_0x557ac0:_0x557ac0['isEmpty']()&&_0x2b0375!=='.priority'?this:(f(_0x2b0375!=='.priority'||Ce(_0x2368e0)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2b0375,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2368e0),_0x557ac0)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x54a9b0,_0x544193){return!0x1;}['val'](_0x2c6eec){return _0x2c6eec&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4bcd83='';this['priorityNode_']['isEmpty']()||(_0x4bcd83+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1e00eb=typeof this['value_'];_0x4bcd83+=_0x1e00eb+':',_0x1e00eb==='number'?_0x4bcd83+=ao(this['value_']):_0x4bcd83+=this['value_'],this['lazyHash_']=ro(_0x4bcd83);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x55980a){return _0x55980a===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x55980a instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x55980a['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x55980a));}['compareToLeafNode_'](_0x268168){const _0x58da88=typeof _0x268168['value_'],_0x5c887e=typeof this['value_'],_0x182ecb=D['VALUE_TYPE_ORDER']['indexOf'](_0x58da88),_0x4b0f26=D['VALUE_TYPE_ORDER']['indexOf'](_0x5c887e);return f(_0x182ecb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x58da88),f(_0x4b0f26>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5c887e),_0x182ecb===_0x4b0f26?_0x5c887e==='object'?0x0:this['value_']<_0x268168['value_']?-0x1:this['value_']===_0x268168['value_']?0x0:0x1:_0x4b0f26-_0x182ecb;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2d3d00){if(_0x2d3d00===this)return!0x0;if(_0x2d3d00['isLeafNode']()){const _0x6abe0c=_0x2d3d00;return this['value_']===_0x6abe0c['value_']&&this['priorityNode_']['equals'](_0x6abe0c['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3c5c94){Oo=_0x3c5c94;}function Wh(_0x15e9aa){Do=_0x15e9aa;}class Bh extends Fn{['compare'](_0x1fa580,_0x4a647e){const _0x32a9f4=_0x1fa580['node']['getPriority'](),_0x39f12a=_0x4a647e['node']['getPriority'](),_0x5b06a3=_0x32a9f4['compareTo'](_0x39f12a);return _0x5b06a3===0x0?qe(_0x1fa580['name'],_0x4a647e['name']):_0x5b06a3;}['isDefinedOn'](_0xb4631){return!_0xb4631['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1a97e2,_0x287bfc){return!_0x1a97e2['getPriority']()['equals'](_0x287bfc['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x554b2b,_0x171de2){const _0x4ef242=Oo(_0x554b2b);return new E(_0x171de2,new D('[PRIORITY-POST]',_0x4ef242));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1ca724){const _0xb27142=_0x34eb23=>parseInt(Math['log'](_0x34eb23)/Vh,0xa),_0x5c71b7=_0x21b008=>parseInt(Array(_0x21b008+0x1)['join']('1'),0x2);this['count']=_0xb27142(_0x1ca724+0x1),this['current_']=this['count']-0x1;const _0x53e62c=_0x5c71b7(this['count']);this['bits_']=_0x1ca724+0x1&_0x53e62c;}['nextBitIsOne'](){const _0xbef8f6=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xbef8f6;}}const yn=function(_0x46adf4,_0x429a76,_0x1ec2db,_0x49b0a6){_0x46adf4['sort'](_0x429a76);const _0x15d85c=function(_0x2a3b31,_0x1ec8f8){const _0x5d8bf5=_0x1ec8f8-_0x2a3b31;let _0x4e9ab3,_0xd7c7e7;if(_0x5d8bf5===0x0)return null;if(_0x5d8bf5===0x1)return _0x4e9ab3=_0x46adf4[_0x2a3b31],_0xd7c7e7=_0x1ec2db?_0x1ec2db(_0x4e9ab3):_0x4e9ab3,new M(_0xd7c7e7,_0x4e9ab3['node'],M['BLACK'],null,null);{const _0x307948=parseInt(_0x5d8bf5/0x2,0xa)+_0x2a3b31,_0x200253=_0x15d85c(_0x2a3b31,_0x307948),_0x304d00=_0x15d85c(_0x307948+0x1,_0x1ec8f8);return _0x4e9ab3=_0x46adf4[_0x307948],_0xd7c7e7=_0x1ec2db?_0x1ec2db(_0x4e9ab3):_0x4e9ab3,new M(_0xd7c7e7,_0x4e9ab3['node'],M['BLACK'],_0x200253,_0x304d00);}},_0x3a719a=function(_0x2766e9){let _0xe320dc=null,_0x106178=null,_0x2b6fc6=_0x46adf4['length'];const _0x32c7b4=function(_0x2bb757,_0x1ed5fc){const _0x35c86f=_0x2b6fc6-_0x2bb757,_0x45bbba=_0x2b6fc6;_0x2b6fc6-=_0x2bb757;const _0x154b8f=_0x15d85c(_0x35c86f+0x1,_0x45bbba),_0x513fcd=_0x46adf4[_0x35c86f],_0x4bbfaa=_0x1ec2db?_0x1ec2db(_0x513fcd):_0x513fcd;_0xc71c64(new M(_0x4bbfaa,_0x513fcd['node'],_0x1ed5fc,null,_0x154b8f));},_0xc71c64=function(_0x189a3e){_0xe320dc?(_0xe320dc['left']=_0x189a3e,_0xe320dc=_0x189a3e):(_0x106178=_0x189a3e,_0xe320dc=_0x189a3e);};for(let _0x14e5be=0x0;_0x14e5be<_0x2766e9['count'];++_0x14e5be){const _0x4fb463=_0x2766e9['nextBitIsOne'](),_0x449177=Math['pow'](0x2,_0x2766e9['count']-(_0x14e5be+0x1));_0x4fb463?_0x32c7b4(_0x449177,M['BLACK']):(_0x32c7b4(_0x449177,M['BLACK']),_0x32c7b4(_0x449177,M['RED']));}return _0x106178;},_0x50685f=new Hh(_0x46adf4['length']),_0x2ff483=_0x3a719a(_0x50685f);return new B(_0x49b0a6||_0x429a76,_0x2ff483);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4f54c5,_0x2b62f3){this['indexes_']=_0x4f54c5,this['indexSet_']=_0x2b62f3;}['get'](_0x31ee9c){const _0x3ba25f=Le(this['indexes_'],_0x31ee9c);if(!_0x3ba25f)throw new Error('No\x20index\x20defined\x20for\x20'+_0x31ee9c);return _0x3ba25f instanceof B?_0x3ba25f:null;}['hasIndex'](_0x38b549){return Q(this['indexSet_'],_0x38b549['toString']());}['addIndex'](_0x2797f4,_0x5d5e94){f(_0x2797f4!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2956d9=[];let _0xb8e680=!0x1;const _0x544131=_0x5d5e94['getIterator'](E['Wrap']);let _0x1bfc39=_0x544131['getNext']();for(;_0x1bfc39;)_0xb8e680=_0xb8e680||_0x2797f4['isDefinedOn'](_0x1bfc39['node']),_0x2956d9['push'](_0x1bfc39),_0x1bfc39=_0x544131['getNext']();let _0x5bee1d;_0xb8e680?_0x5bee1d=yn(_0x2956d9,_0x2797f4['getCompare']()):_0x5bee1d=Qe;const _0x276e85=_0x2797f4['toString'](),_0x3cfc98={...this['indexSet_']};_0x3cfc98[_0x276e85]=_0x2797f4;const _0x354cef={...this['indexes_']};return _0x354cef[_0x276e85]=_0x5bee1d,new te(_0x354cef,_0x3cfc98);}['addToIndexes'](_0xf621a2,_0x2c6aa1){const _0x93cc66=_n(this['indexes_'],(_0x57224f,_0x1471ed)=>{const _0x2d26d5=Le(this['indexSet_'],_0x1471ed);if(f(_0x2d26d5,'Missing\x20index\x20implementation\x20for\x20'+_0x1471ed),_0x57224f===Qe){if(_0x2d26d5['isDefinedOn'](_0xf621a2['node'])){const _0x480a4e=[],_0x401b05=_0x2c6aa1['getIterator'](E['Wrap']);let _0x3c061b=_0x401b05['getNext']();for(;_0x3c061b;)_0x3c061b['name']!==_0xf621a2['name']&&_0x480a4e['push'](_0x3c061b),_0x3c061b=_0x401b05['getNext']();return _0x480a4e['push'](_0xf621a2),yn(_0x480a4e,_0x2d26d5['getCompare']());}else return Qe;}else{const _0x1ed4ab=_0x2c6aa1['get'](_0xf621a2['name']);let _0x1d8625=_0x57224f;return _0x1ed4ab&&(_0x1d8625=_0x1d8625['remove'](new E(_0xf621a2['name'],_0x1ed4ab))),_0x1d8625['insert'](_0xf621a2,_0xf621a2['node']);}});return new te(_0x93cc66,this['indexSet_']);}['removeFromIndexes'](_0x2b3d3f,_0x1fe86f){const _0xb555f0=_n(this['indexes_'],_0x1514bb=>{if(_0x1514bb===Qe)return _0x1514bb;{const _0x489d78=_0x1fe86f['get'](_0x2b3d3f['name']);return _0x489d78?_0x1514bb['remove'](new E(_0x2b3d3f['name'],_0x489d78)):_0x1514bb;}});return new te(_0xb555f0,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x232f61,_0x50b136,_0x5ca294){this['children_']=_0x232f61,this['priorityNode_']=_0x50b136,this['indexMap_']=_0x5ca294,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1738a1){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1738a1,this['indexMap_']);}['getImmediateChild'](_0x64d315){if(_0x64d315==='.priority')return this['getPriority']();{const _0x5a2811=this['children_']['get'](_0x64d315);return _0x5a2811===null?It:_0x5a2811;}}['getChild'](_0x4fe746){const _0x3ed9e2=y(_0x4fe746);return _0x3ed9e2===null?this:this['getImmediateChild'](_0x3ed9e2)['getChild'](S(_0x4fe746));}['hasChild'](_0x25b2c3){return this['children_']['get'](_0x25b2c3)!==null;}['updateImmediateChild'](_0x5ac392,_0xebeba1){if(f(_0xebeba1,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5ac392==='.priority')return this['updatePriority'](_0xebeba1);{const _0x343b8f=new E(_0x5ac392,_0xebeba1);let _0x250e9c,_0x4dd283;_0xebeba1['isEmpty']()?(_0x250e9c=this['children_']['remove'](_0x5ac392),_0x4dd283=this['indexMap_']['removeFromIndexes'](_0x343b8f,this['children_'])):(_0x250e9c=this['children_']['insert'](_0x5ac392,_0xebeba1),_0x4dd283=this['indexMap_']['addToIndexes'](_0x343b8f,this['children_']));const _0x564121=_0x250e9c['isEmpty']()?It:this['priorityNode_'];return new g(_0x250e9c,_0x564121,_0x4dd283);}}['updateChild'](_0x55f058,_0x3bddce){const _0x12f512=y(_0x55f058);if(_0x12f512===null)return _0x3bddce;{f(y(_0x55f058)!=='.priority'||Ce(_0x55f058)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x446797=this['getImmediateChild'](_0x12f512)['updateChild'](S(_0x55f058),_0x3bddce);return this['updateImmediateChild'](_0x12f512,_0x446797);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5aa954){if(this['isEmpty']())return null;const _0x7cb512={};let _0xc2f327=0x0,_0x3f411d=0x0,_0x5e4312=!0x0;if(this['forEachChild'](R,(_0xb514e6,_0x3ec04d)=>{_0x7cb512[_0xb514e6]=_0x3ec04d['val'](_0x5aa954),_0xc2f327++,_0x5e4312&&g['INTEGER_REGEXP_']['test'](_0xb514e6)?_0x3f411d=Math['max'](_0x3f411d,Number(_0xb514e6)):_0x5e4312=!0x1;}),!_0x5aa954&&_0x5e4312&&_0x3f411d<0x2*_0xc2f327){const _0x2d476b=[];for(const _0x58c985 in _0x7cb512)_0x2d476b[_0x58c985]=_0x7cb512[_0x58c985];return _0x2d476b;}else return _0x5aa954&&!this['getPriority']()['isEmpty']()&&(_0x7cb512['.priority']=this['getPriority']()['val']()),_0x7cb512;}['hash'](){if(this['lazyHash_']===null){let _0x5591f9='';this['getPriority']()['isEmpty']()||(_0x5591f9+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3adeb8,_0x3cf60c)=>{const _0x5d2b66=_0x3cf60c['hash']();_0x5d2b66!==''&&(_0x5591f9+=':'+_0x3adeb8+':'+_0x5d2b66);}),this['lazyHash_']=_0x5591f9===''?'':ro(_0x5591f9);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3bf530,_0x31730d,_0x443593){const _0x2b842b=this['resolveIndex_'](_0x443593);if(_0x2b842b){const _0x3977b5=_0x2b842b['getPredecessorKey'](new E(_0x3bf530,_0x31730d));return _0x3977b5?_0x3977b5['name']:null;}else return this['children_']['getPredecessorKey'](_0x3bf530);}['getFirstChildName'](_0x3ec517){const _0x2ca12f=this['resolveIndex_'](_0x3ec517);if(_0x2ca12f){const _0x526454=_0x2ca12f['minKey']();return _0x526454&&_0x526454['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x560515){const _0x1b0807=this['getFirstChildName'](_0x560515);return _0x1b0807?new E(_0x1b0807,this['children_']['get'](_0x1b0807)):null;}['getLastChildName'](_0x110671){const _0x4cec57=this['resolveIndex_'](_0x110671);if(_0x4cec57){const _0x3aeda2=_0x4cec57['maxKey']();return _0x3aeda2&&_0x3aeda2['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x43ee19){const _0x5a3ebc=this['getLastChildName'](_0x43ee19);return _0x5a3ebc?new E(_0x5a3ebc,this['children_']['get'](_0x5a3ebc)):null;}['forEachChild'](_0x534a3f,_0x447c32){const _0x37968a=this['resolveIndex_'](_0x534a3f);return _0x37968a?_0x37968a['inorderTraversal'](_0x24379e=>_0x447c32(_0x24379e['name'],_0x24379e['node'])):this['children_']['inorderTraversal'](_0x447c32);}['getIterator'](_0x19b684){return this['getIteratorFrom'](_0x19b684['minPost'](),_0x19b684);}['getIteratorFrom'](_0x4cc66d,_0x13f3d5){const _0x10c9e0=this['resolveIndex_'](_0x13f3d5);if(_0x10c9e0)return _0x10c9e0['getIteratorFrom'](_0x4cc66d,_0x364a69=>_0x364a69);{const _0x357feb=this['children_']['getIteratorFrom'](_0x4cc66d['name'],E['Wrap']);let _0x1e6814=_0x357feb['peek']();for(;_0x1e6814!=null&&_0x13f3d5['compare'](_0x1e6814,_0x4cc66d)<0x0;)_0x357feb['getNext'](),_0x1e6814=_0x357feb['peek']();return _0x357feb;}}['getReverseIterator'](_0x3b9ed8){return this['getReverseIteratorFrom'](_0x3b9ed8['maxPost'](),_0x3b9ed8);}['getReverseIteratorFrom'](_0x5a2625,_0x116167){const _0x18c345=this['resolveIndex_'](_0x116167);if(_0x18c345)return _0x18c345['getReverseIteratorFrom'](_0x5a2625,_0x35bd38=>_0x35bd38);{const _0x2d0fc9=this['children_']['getReverseIteratorFrom'](_0x5a2625['name'],E['Wrap']);let _0x149a2e=_0x2d0fc9['peek']();for(;_0x149a2e!=null&&_0x116167['compare'](_0x149a2e,_0x5a2625)>0x0;)_0x2d0fc9['getNext'](),_0x149a2e=_0x2d0fc9['peek']();return _0x2d0fc9;}}['compareTo'](_0x2638af){return this['isEmpty']()?_0x2638af['isEmpty']()?0x0:-0x1:_0x2638af['isLeafNode']()||_0x2638af['isEmpty']()?0x1:_0x2638af===Kt?-0x1:0x0;}['withIndex'](_0x570477){if(_0x570477===ve||this['indexMap_']['hasIndex'](_0x570477))return this;{const _0x42e016=this['indexMap_']['addIndex'](_0x570477,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x42e016);}}['isIndexed'](_0xa69daa){return _0xa69daa===ve||this['indexMap_']['hasIndex'](_0xa69daa);}['equals'](_0x5a82fd){if(_0x5a82fd===this)return!0x0;if(_0x5a82fd['isLeafNode']())return!0x1;{const _0x3cb78f=_0x5a82fd;if(this['getPriority']()['equals'](_0x3cb78f['getPriority']())){if(this['children_']['count']()===_0x3cb78f['children_']['count']()){const _0x493484=this['getIterator'](R),_0x5591d0=_0x3cb78f['getIterator'](R);let _0x255ea9=_0x493484['getNext'](),_0x2a049b=_0x5591d0['getNext']();for(;_0x255ea9&&_0x2a049b;){if(_0x255ea9['name']!==_0x2a049b['name']||!_0x255ea9['node']['equals'](_0x2a049b['node']))return!0x1;_0x255ea9=_0x493484['getNext'](),_0x2a049b=_0x5591d0['getNext']();}return _0x255ea9===null&&_0x2a049b===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5571ac){return _0x5571ac===ve?null:this['indexMap_']['get'](_0x5571ac['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x55a73e){return _0x55a73e===this?0x0:0x1;}['equals'](_0x1cb017){return _0x1cb017===this;}['getPriority'](){return this;}['getImmediateChild'](_0x21e950){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x4ee76b,_0x3cf9c0=null){if(_0x4ee76b===null)return g['EMPTY_NODE'];if(typeof _0x4ee76b=='object'&&'.priority'in _0x4ee76b&&(_0x3cf9c0=_0x4ee76b['.priority']),f(_0x3cf9c0===null||typeof _0x3cf9c0=='string'||typeof _0x3cf9c0=='number'||typeof _0x3cf9c0=='object'&&'.sv'in _0x3cf9c0,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3cf9c0),typeof _0x4ee76b=='object'&&'.value'in _0x4ee76b&&_0x4ee76b['.value']!==null&&(_0x4ee76b=_0x4ee76b['.value']),typeof _0x4ee76b!='object'||'.sv'in _0x4ee76b){const _0x68b613=_0x4ee76b;return new D(_0x68b613,A(_0x3cf9c0));}if(!(_0x4ee76b instanceof Array)&&Gh){const _0x26d686=[];let _0x533b21=!0x1;if(x(_0x4ee76b,(_0xd665b3,_0x38bdf8)=>{if(_0xd665b3['substring'](0x0,0x1)!=='.'){const _0x4e0d3e=A(_0x38bdf8);_0x4e0d3e['isEmpty']()||(_0x533b21=_0x533b21||!_0x4e0d3e['getPriority']()['isEmpty'](),_0x26d686['push'](new E(_0xd665b3,_0x4e0d3e)));}}),_0x26d686['length']===0x0)return g['EMPTY_NODE'];const _0x51a688=yn(_0x26d686,xh,_0x34a522=>_0x34a522['name'],Qi);if(_0x533b21){const _0x18c189=yn(_0x26d686,R['getCompare']());return new g(_0x51a688,A(_0x3cf9c0),new te({'.priority':_0x18c189},{'.priority':R}));}else return new g(_0x51a688,A(_0x3cf9c0),te['Default']);}else{let _0x5a8049=g['EMPTY_NODE'];return x(_0x4ee76b,(_0x5f1e88,_0x23f193)=>{if(Q(_0x4ee76b,_0x5f1e88)&&_0x5f1e88['substring'](0x0,0x1)!=='.'){const _0x4cc80b=A(_0x23f193);(_0x4cc80b['isLeafNode']()||!_0x4cc80b['isEmpty']())&&(_0x5a8049=_0x5a8049['updateImmediateChild'](_0x5f1e88,_0x4cc80b));}}),_0x5a8049['updatePriority'](A(_0x3cf9c0));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x1bb546){super(),this['indexPath_']=_0x1bb546,f(!v(_0x1bb546)&&y(_0x1bb546)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x21cca4){return _0x21cca4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4ef866){return!_0x4ef866['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5072af,_0x459e72){const _0x1e5fb2=this['extractChild'](_0x5072af['node']),_0xe5bff=this['extractChild'](_0x459e72['node']),_0x25920d=_0x1e5fb2['compareTo'](_0xe5bff);return _0x25920d===0x0?qe(_0x5072af['name'],_0x459e72['name']):_0x25920d;}['makePost'](_0xdd5be3,_0x5e3d4c){const _0x1b5ec3=A(_0xdd5be3),_0x1ba7fe=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1b5ec3);return new E(_0x5e3d4c,_0x1ba7fe);}['maxPost'](){const _0x3dfdc0=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x3dfdc0);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x238d0a,_0x553302){const _0x5daa0=_0x238d0a['node']['compareTo'](_0x553302['node']);return _0x5daa0===0x0?qe(_0x238d0a['name'],_0x553302['name']):_0x5daa0;}['isDefinedOn'](_0x516c1b){return!0x0;}['indexedValueChanged'](_0x3594a6,_0x33c253){return!_0x3594a6['equals'](_0x33c253);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2d9475,_0x1905b4){const _0x36cbc3=A(_0x2d9475);return new E(_0x1905b4,_0x36cbc3);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x225b5d){return{'type':'value','snapshotNode':_0x225b5d};}function rt(_0x11b2c5,_0x5f3f3b){return{'type':'child_added','snapshotNode':_0x5f3f3b,'childName':_0x11b2c5};}function Lt(_0x50dd5b,_0x2d20e4){return{'type':'child_removed','snapshotNode':_0x2d20e4,'childName':_0x50dd5b};}function xt(_0x4752bb,_0x513766,_0x4bf6ee){return{'type':'child_changed','snapshotNode':_0x513766,'childName':_0x4752bb,'oldSnap':_0x4bf6ee};}function zh(_0x449d45,_0x2eebc3){return{'type':'child_moved','snapshotNode':_0x2eebc3,'childName':_0x449d45};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x3dc98c){this['index_']=_0x3dc98c;}['updateChild'](_0x1e56eb,_0x4494ea,_0x58ac9e,_0x178636,_0x56e049,_0x43500a){f(_0x1e56eb['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x107a52=_0x1e56eb['getImmediateChild'](_0x4494ea);return _0x107a52['getChild'](_0x178636)['equals'](_0x58ac9e['getChild'](_0x178636))&&_0x107a52['isEmpty']()===_0x58ac9e['isEmpty']()||(_0x43500a!=null&&(_0x58ac9e['isEmpty']()?_0x1e56eb['hasChild'](_0x4494ea)?_0x43500a['trackChildChange'](Lt(_0x4494ea,_0x107a52)):f(_0x1e56eb['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x107a52['isEmpty']()?_0x43500a['trackChildChange'](rt(_0x4494ea,_0x58ac9e)):_0x43500a['trackChildChange'](xt(_0x4494ea,_0x58ac9e,_0x107a52))),_0x1e56eb['isLeafNode']()&&_0x58ac9e['isEmpty']())?_0x1e56eb:_0x1e56eb['updateImmediateChild'](_0x4494ea,_0x58ac9e)['withIndex'](this['index_']);}['updateFullNode'](_0x5f5b1e,_0x148c68,_0xb28823){return _0xb28823!=null&&(_0x5f5b1e['isLeafNode']()||_0x5f5b1e['forEachChild'](R,(_0x2d143c,_0xf12336)=>{_0x148c68['hasChild'](_0x2d143c)||_0xb28823['trackChildChange'](Lt(_0x2d143c,_0xf12336));}),_0x148c68['isLeafNode']()||_0x148c68['forEachChild'](R,(_0x13e895,_0x5373fe)=>{if(_0x5f5b1e['hasChild'](_0x13e895)){const _0x514a99=_0x5f5b1e['getImmediateChild'](_0x13e895);_0x514a99['equals'](_0x5373fe)||_0xb28823['trackChildChange'](xt(_0x13e895,_0x5373fe,_0x514a99));}else _0xb28823['trackChildChange'](rt(_0x13e895,_0x5373fe));})),_0x148c68['withIndex'](this['index_']);}['updatePriority'](_0x2178b4,_0xf8c4e0){return _0x2178b4['isEmpty']()?g['EMPTY_NODE']:_0x2178b4['updatePriority'](_0xf8c4e0);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x19deff){this['indexedFilter_']=new Xi(_0x19deff['getIndex']()),this['index_']=_0x19deff['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x19deff),this['endPost_']=Ft['getEndPost_'](_0x19deff),this['startIsInclusive_']=!_0x19deff['startAfterSet_'],this['endIsInclusive_']=!_0x19deff['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4963fa){const _0x1687f7=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4963fa)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4963fa)<0x0,_0x57c9b3=this['endIsInclusive_']?this['index_']['compare'](_0x4963fa,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4963fa,this['getEndPost']())<0x0;return _0x1687f7&&_0x57c9b3;}['updateChild'](_0x1c8bee,_0x1161c1,_0x138cef,_0x17afe0,_0x19d590,_0xc69a31){return this['matches'](new E(_0x1161c1,_0x138cef))||(_0x138cef=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1c8bee,_0x1161c1,_0x138cef,_0x17afe0,_0x19d590,_0xc69a31);}['updateFullNode'](_0x54110b,_0x2c4f25,_0x57f2eb){_0x2c4f25['isLeafNode']()&&(_0x2c4f25=g['EMPTY_NODE']);let _0x2467e6=_0x2c4f25['withIndex'](this['index_']);_0x2467e6=_0x2467e6['updatePriority'](g['EMPTY_NODE']);const _0x4611da=this;return _0x2c4f25['forEachChild'](R,(_0x1456af,_0x4bbfc1)=>{_0x4611da['matches'](new E(_0x1456af,_0x4bbfc1))||(_0x2467e6=_0x2467e6['updateImmediateChild'](_0x1456af,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x54110b,_0x2467e6,_0x57f2eb);}['updatePriority'](_0xf920c2,_0x4d7383){return _0xf920c2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5201d4){if(_0x5201d4['hasStart']()){const _0x58a41d=_0x5201d4['getIndexStartName']();return _0x5201d4['getIndex']()['makePost'](_0x5201d4['getIndexStartValue'](),_0x58a41d);}else return _0x5201d4['getIndex']()['minPost']();}static['getEndPost_'](_0x4900d5){if(_0x4900d5['hasEnd']()){const _0x5a650d=_0x4900d5['getIndexEndName']();return _0x4900d5['getIndex']()['makePost'](_0x4900d5['getIndexEndValue'](),_0x5a650d);}else return _0x4900d5['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x3f1ce1){this['withinDirectionalStart']=_0x2a8111=>this['reverse_']?this['withinEndPost'](_0x2a8111):this['withinStartPost'](_0x2a8111),this['withinDirectionalEnd']=_0x2a49bc=>this['reverse_']?this['withinStartPost'](_0x2a49bc):this['withinEndPost'](_0x2a49bc),this['withinStartPost']=_0x4f630a=>{const _0x10dc10=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4f630a);return this['startIsInclusive_']?_0x10dc10<=0x0:_0x10dc10<0x0;},this['withinEndPost']=_0x1e2a29=>{const _0x347cec=this['index_']['compare'](_0x1e2a29,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x347cec<=0x0:_0x347cec<0x0;},this['rangedFilter_']=new Ft(_0x3f1ce1),this['index_']=_0x3f1ce1['getIndex'](),this['limit_']=_0x3f1ce1['getLimit'](),this['reverse_']=!_0x3f1ce1['isViewFromLeft'](),this['startIsInclusive_']=!_0x3f1ce1['startAfterSet_'],this['endIsInclusive_']=!_0x3f1ce1['endBeforeSet_'];}['updateChild'](_0x12d315,_0x4690d2,_0x48fd01,_0x1f19d7,_0x3fe760,_0x458ce3){return this['rangedFilter_']['matches'](new E(_0x4690d2,_0x48fd01))||(_0x48fd01=g['EMPTY_NODE']),_0x12d315['getImmediateChild'](_0x4690d2)['equals'](_0x48fd01)?_0x12d315:_0x12d315['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x12d315,_0x4690d2,_0x48fd01,_0x1f19d7,_0x3fe760,_0x458ce3):this['fullLimitUpdateChild_'](_0x12d315,_0x4690d2,_0x48fd01,_0x3fe760,_0x458ce3);}['updateFullNode'](_0x2491d9,_0x5ef735,_0x58fe8b){let _0x4e8e2c;if(_0x5ef735['isLeafNode']()||_0x5ef735['isEmpty']())_0x4e8e2c=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5ef735['numChildren']()&&_0x5ef735['isIndexed'](this['index_'])){_0x4e8e2c=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x16c25b;this['reverse_']?_0x16c25b=_0x5ef735['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x16c25b=_0x5ef735['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3deed7=0x0;for(;_0x16c25b['hasNext']()&&_0x3deed7<this['limit_'];){const _0x2de9e3=_0x16c25b['getNext']();if(this['withinDirectionalStart'](_0x2de9e3)){if(this['withinDirectionalEnd'](_0x2de9e3))_0x4e8e2c=_0x4e8e2c['updateImmediateChild'](_0x2de9e3['name'],_0x2de9e3['node']),_0x3deed7++;else break;}else continue;}}else{_0x4e8e2c=_0x5ef735['withIndex'](this['index_']),_0x4e8e2c=_0x4e8e2c['updatePriority'](g['EMPTY_NODE']);let _0x525d7c;this['reverse_']?_0x525d7c=_0x4e8e2c['getReverseIterator'](this['index_']):_0x525d7c=_0x4e8e2c['getIterator'](this['index_']);let _0x1de879=0x0;for(;_0x525d7c['hasNext']();){const _0x561ec7=_0x525d7c['getNext']();_0x1de879<this['limit_']&&this['withinDirectionalStart'](_0x561ec7)&&this['withinDirectionalEnd'](_0x561ec7)?_0x1de879++:_0x4e8e2c=_0x4e8e2c['updateImmediateChild'](_0x561ec7['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2491d9,_0x4e8e2c,_0x58fe8b);}['updatePriority'](_0x4748cb,_0x5419b9){return _0x4748cb;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2abbd2,_0xc15aa,_0x32e6b5,_0x3918d4,_0x25aa71){let _0x181d5f;if(this['reverse_']){const _0x17bccb=this['index_']['getCompare']();_0x181d5f=(_0x15db98,_0x7b6b67)=>_0x17bccb(_0x7b6b67,_0x15db98);}else _0x181d5f=this['index_']['getCompare']();const _0x283f63=_0x2abbd2;f(_0x283f63['numChildren']()===this['limit_'],'');const _0x4a6c97=new E(_0xc15aa,_0x32e6b5),_0x2b0127=this['reverse_']?_0x283f63['getFirstChild'](this['index_']):_0x283f63['getLastChild'](this['index_']),_0x1a1c0d=this['rangedFilter_']['matches'](_0x4a6c97);if(_0x283f63['hasChild'](_0xc15aa)){const _0x495da6=_0x283f63['getImmediateChild'](_0xc15aa);let _0x5a6cbf=_0x3918d4['getChildAfterChild'](this['index_'],_0x2b0127,this['reverse_']);for(;_0x5a6cbf!=null&&(_0x5a6cbf['name']===_0xc15aa||_0x283f63['hasChild'](_0x5a6cbf['name']));)_0x5a6cbf=_0x3918d4['getChildAfterChild'](this['index_'],_0x5a6cbf,this['reverse_']);const _0x314a0=_0x5a6cbf==null?0x1:_0x181d5f(_0x5a6cbf,_0x4a6c97);if(_0x1a1c0d&&!_0x32e6b5['isEmpty']()&&_0x314a0>=0x0)return _0x25aa71!=null&&_0x25aa71['trackChildChange'](xt(_0xc15aa,_0x32e6b5,_0x495da6)),_0x283f63['updateImmediateChild'](_0xc15aa,_0x32e6b5);{_0x25aa71!=null&&_0x25aa71['trackChildChange'](Lt(_0xc15aa,_0x495da6));const _0x2ee2e7=_0x283f63['updateImmediateChild'](_0xc15aa,g['EMPTY_NODE']);return _0x5a6cbf!=null&&this['rangedFilter_']['matches'](_0x5a6cbf)?(_0x25aa71!=null&&_0x25aa71['trackChildChange'](rt(_0x5a6cbf['name'],_0x5a6cbf['node'])),_0x2ee2e7['updateImmediateChild'](_0x5a6cbf['name'],_0x5a6cbf['node'])):_0x2ee2e7;}}else return _0x32e6b5['isEmpty']()?_0x2abbd2:_0x1a1c0d&&_0x181d5f(_0x2b0127,_0x4a6c97)>=0x0?(_0x25aa71!=null&&(_0x25aa71['trackChildChange'](Lt(_0x2b0127['name'],_0x2b0127['node'])),_0x25aa71['trackChildChange'](rt(_0xc15aa,_0x32e6b5))),_0x283f63['updateImmediateChild'](_0xc15aa,_0x32e6b5)['updateImmediateChild'](_0x2b0127['name'],g['EMPTY_NODE'])):_0x2abbd2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4f7bc8=new Zi();return _0x4f7bc8['limitSet_']=this['limitSet_'],_0x4f7bc8['limit_']=this['limit_'],_0x4f7bc8['startSet_']=this['startSet_'],_0x4f7bc8['startAfterSet_']=this['startAfterSet_'],_0x4f7bc8['indexStartValue_']=this['indexStartValue_'],_0x4f7bc8['startNameSet_']=this['startNameSet_'],_0x4f7bc8['indexStartName_']=this['indexStartName_'],_0x4f7bc8['endSet_']=this['endSet_'],_0x4f7bc8['endBeforeSet_']=this['endBeforeSet_'],_0x4f7bc8['indexEndValue_']=this['indexEndValue_'],_0x4f7bc8['endNameSet_']=this['endNameSet_'],_0x4f7bc8['indexEndName_']=this['indexEndName_'],_0x4f7bc8['index_']=this['index_'],_0x4f7bc8['viewFrom_']=this['viewFrom_'],_0x4f7bc8;}}function Kh(_0x5bc0fd){return _0x5bc0fd['loadsAllData']()?new Xi(_0x5bc0fd['getIndex']()):_0x5bc0fd['hasLimit']()?new jh(_0x5bc0fd):new Ft(_0x5bc0fd);}function Yh(_0xc19411,_0x111f80){const _0x18902c=_0xc19411['copy']();return _0x18902c['limitSet_']=!0x0,_0x18902c['limit_']=_0x111f80,_0x18902c['viewFrom_']='l',_0x18902c;}function Qh(_0x151f97,_0xe11c53,_0x5935a2){const _0x4707b6=_0x151f97['copy']();return _0x4707b6['startSet_']=!0x0,_0xe11c53===void 0x0&&(_0xe11c53=null),_0x4707b6['indexStartValue_']=_0xe11c53,_0x5935a2!=null?(_0x4707b6['startNameSet_']=!0x0,_0x4707b6['indexStartName_']=_0x5935a2):(_0x4707b6['startNameSet_']=!0x1,_0x4707b6['indexStartName_']=''),_0x4707b6;}function Jh(_0x28ec66,_0x32d659,_0x4a7b77){const _0x180102=_0x28ec66['copy']();return _0x180102['endSet_']=!0x0,_0x32d659===void 0x0&&(_0x32d659=null),_0x180102['indexEndValue_']=_0x32d659,_0x4a7b77!==void 0x0?(_0x180102['endNameSet_']=!0x0,_0x180102['indexEndName_']=_0x4a7b77):(_0x180102['endNameSet_']=!0x1,_0x180102['indexEndName_']=''),_0x180102;}function xo(_0x5ac982,_0x524926){const _0x616751=_0x5ac982['copy']();return _0x616751['index_']=_0x524926,_0x616751;}function ir(_0x12d3a3){const _0x33a59a={};if(_0x12d3a3['isDefault']())return _0x33a59a;let _0x10a766;if(_0x12d3a3['index_']===R?_0x10a766='$priority':_0x12d3a3['index_']===Mo?_0x10a766='$value':_0x12d3a3['index_']===ve?_0x10a766='$key':(f(_0x12d3a3['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x10a766=_0x12d3a3['index_']['toString']()),_0x33a59a['orderBy']=O(_0x10a766),_0x12d3a3['startSet_']){const _0x2d6644=_0x12d3a3['startAfterSet_']?'startAfter':'startAt';_0x33a59a[_0x2d6644]=O(_0x12d3a3['indexStartValue_']),_0x12d3a3['startNameSet_']&&(_0x33a59a[_0x2d6644]+=','+O(_0x12d3a3['indexStartName_']));}if(_0x12d3a3['endSet_']){const _0x3bc292=_0x12d3a3['endBeforeSet_']?'endBefore':'endAt';_0x33a59a[_0x3bc292]=O(_0x12d3a3['indexEndValue_']),_0x12d3a3['endNameSet_']&&(_0x33a59a[_0x3bc292]+=','+O(_0x12d3a3['indexEndName_']));}return _0x12d3a3['limitSet_']&&(_0x12d3a3['isViewFromLeft']()?_0x33a59a['limitToFirst']=_0x12d3a3['limit_']:_0x33a59a['limitToLast']=_0x12d3a3['limit_']),_0x33a59a;}function sr(_0x5ad38c){const _0x187ca4={};if(_0x5ad38c['startSet_']&&(_0x187ca4['sp']=_0x5ad38c['indexStartValue_'],_0x5ad38c['startNameSet_']&&(_0x187ca4['sn']=_0x5ad38c['indexStartName_']),_0x187ca4['sin']=!_0x5ad38c['startAfterSet_']),_0x5ad38c['endSet_']&&(_0x187ca4['ep']=_0x5ad38c['indexEndValue_'],_0x5ad38c['endNameSet_']&&(_0x187ca4['en']=_0x5ad38c['indexEndName_']),_0x187ca4['ein']=!_0x5ad38c['endBeforeSet_']),_0x5ad38c['limitSet_']){_0x187ca4['l']=_0x5ad38c['limit_'];let _0x33869a=_0x5ad38c['viewFrom_'];_0x33869a===''&&(_0x5ad38c['isViewFromLeft']()?_0x33869a='l':_0x33869a='r'),_0x187ca4['vf']=_0x33869a;}return _0x5ad38c['index_']!==R&&(_0x187ca4['i']=_0x5ad38c['index_']['toString']()),_0x187ca4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x3f12f8){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xb9f2d3,_0x36e79f){return _0x36e79f!==void 0x0?'tag$'+_0x36e79f:(f(_0xb9f2d3['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xb9f2d3['_path']['toString']());}constructor(_0x561bb4,_0x481997,_0x1f5a49,_0xfee16f){super(),this['repoInfo_']=_0x561bb4,this['onDataUpdate_']=_0x481997,this['authTokenProvider_']=_0x1f5a49,this['appCheckTokenProvider_']=_0xfee16f,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x36dd1e,_0x57e108,_0xb60d44,_0x2a8a9f){const _0x3786a2=_0x36dd1e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3786a2+'\x20'+_0x36dd1e['_queryIdentifier']);const _0x4cf142=vn['getListenId_'](_0x36dd1e,_0xb60d44),_0x4bc65b={};this['listens_'][_0x4cf142]=_0x4bc65b;const _0x2535ee=ir(_0x36dd1e['_queryParams']);this['restRequest_'](_0x3786a2+'.json',_0x2535ee,(_0x5d304e,_0x5883be)=>{let _0x45d3bc=_0x5883be;if(_0x5d304e===0x194&&(_0x45d3bc=null,_0x5d304e=null),_0x5d304e===null&&this['onDataUpdate_'](_0x3786a2,_0x45d3bc,!0x1,_0xb60d44),Le(this['listens_'],_0x4cf142)===_0x4bc65b){let _0x340e10;_0x5d304e?_0x5d304e===0x191?_0x340e10='permission_denied':_0x340e10='rest_error:'+_0x5d304e:_0x340e10='ok',_0x2a8a9f(_0x340e10,null);}});}['unlisten'](_0x5bd1a5,_0x142ddc){const _0x5e1a27=vn['getListenId_'](_0x5bd1a5,_0x142ddc);delete this['listens_'][_0x5e1a27];}['get'](_0x230841){const _0x1acc87=ir(_0x230841['_queryParams']),_0x360ac9=_0x230841['_path']['toString'](),_0x41def6=new H();return this['restRequest_'](_0x360ac9+'.json',_0x1acc87,(_0x3a544c,_0x2246bb)=>{let _0x73cb34=_0x2246bb;_0x3a544c===0x194&&(_0x73cb34=null,_0x3a544c=null),_0x3a544c===null?(this['onDataUpdate_'](_0x360ac9,_0x73cb34,!0x1,null),_0x41def6['resolve'](_0x73cb34)):_0x41def6['reject'](new Error(_0x73cb34));}),_0x41def6['promise'];}['refreshAuthToken'](_0x1d5ef6){}['restRequest_'](_0xd06233,_0x2612b8={},_0x17bafd){return _0x2612b8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3718f9,_0x2463d3])=>{_0x3718f9&&_0x3718f9['accessToken']&&(_0x2612b8['auth']=_0x3718f9['accessToken']),_0x2463d3&&_0x2463d3['token']&&(_0x2612b8['ac']=_0x2463d3['token']);const _0x15c1c1=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xd06233+'?ns='+this['repoInfo_']['namespace']+ut(_0x2612b8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x15c1c1);const _0x387f24=new XMLHttpRequest();_0x387f24['onreadystatechange']=()=>{if(_0x17bafd&&_0x387f24['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x15c1c1+'\x20received.\x20status:',_0x387f24['status'],'response:',_0x387f24['responseText']);let _0x3cb288=null;if(_0x387f24['status']>=0xc8&&_0x387f24['status']<0x12c){try{_0x3cb288=Nt(_0x387f24['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x15c1c1+':\x20'+_0x387f24['responseText']);}_0x17bafd(null,_0x3cb288);}else _0x387f24['status']!==0x191&&_0x387f24['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x15c1c1+'\x20Status:\x20'+_0x387f24['status']),_0x17bafd(_0x387f24['status']);_0x17bafd=null;}},_0x387f24['open']('GET',_0x15c1c1,!0x0),_0x387f24['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x32ad2c){return this['rootNode_']['getChild'](_0x32ad2c);}['updateSnapshot'](_0x35d429,_0x109b4c){this['rootNode_']=this['rootNode_']['updateChild'](_0x35d429,_0x109b4c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x156042,_0xdf42da,_0x1563df){if(v(_0xdf42da))_0x156042['value']=_0x1563df,_0x156042['children']['clear']();else{if(_0x156042['value']!==null)_0x156042['value']=_0x156042['value']['updateChild'](_0xdf42da,_0x1563df);else{const _0x441132=y(_0xdf42da);_0x156042['children']['has'](_0x441132)||_0x156042['children']['set'](_0x441132,En());const _0x2d94b7=_0x156042['children']['get'](_0x441132);_0xdf42da=S(_0xdf42da),pt(_0x2d94b7,_0xdf42da,_0x1563df);}}}function Ti(_0x3bea33,_0x3f15d8){if(v(_0x3f15d8))return _0x3bea33['value']=null,_0x3bea33['children']['clear'](),!0x0;if(_0x3bea33['value']!==null){if(_0x3bea33['value']['isLeafNode']())return!0x1;{const _0x2b4fde=_0x3bea33['value'];return _0x3bea33['value']=null,_0x2b4fde['forEachChild'](R,(_0xadcbd3,_0x5f4b37)=>{pt(_0x3bea33,new C(_0xadcbd3),_0x5f4b37);}),Ti(_0x3bea33,_0x3f15d8);}}else{if(_0x3bea33['children']['size']>0x0){const _0x57ce52=y(_0x3f15d8);return _0x3f15d8=S(_0x3f15d8),_0x3bea33['children']['has'](_0x57ce52)&&Ti(_0x3bea33['children']['get'](_0x57ce52),_0x3f15d8)&&_0x3bea33['children']['delete'](_0x57ce52),_0x3bea33['children']['size']===0x0;}else return!0x0;}}function Si(_0x5e0459,_0x57e155,_0x4b1be2){_0x5e0459['value']!==null?_0x4b1be2(_0x57e155,_0x5e0459['value']):Zh(_0x5e0459,(_0x2c373c,_0x2b688e)=>{const _0x118ea0=new C(_0x57e155['toString']()+'/'+_0x2c373c);Si(_0x2b688e,_0x118ea0,_0x4b1be2);});}function Zh(_0x30d44d,_0x38a87f){_0x30d44d['children']['forEach']((_0xa74a9e,_0x238e6a)=>{_0x38a87f(_0x238e6a,_0xa74a9e);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x44cba4){this['collection_']=_0x44cba4,this['last_']=null;}['get'](){const _0x2df992=this['collection_']['get'](),_0xebed23={..._0x2df992};return this['last_']&&x(this['last_'],(_0x3fad29,_0x220ca0)=>{_0xebed23[_0x3fad29]=_0xebed23[_0x3fad29]-_0x220ca0;}),this['last_']=_0x2df992,_0xebed23;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x36a2cf,_0x51b1af){this['server_']=_0x51b1af,this['statsToReport_']={},this['statsListener_']=new eu(_0x36a2cf);const _0x1f5c36=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1f5c36));}['reportStats_'](){const _0x73b553=this['statsListener_']['get'](),_0x4b797c={};let _0x53793d=!0x1;x(_0x73b553,(_0x232611,_0x49e0d0)=>{_0x49e0d0>0x0&&Q(this['statsToReport_'],_0x232611)&&(_0x4b797c[_0x232611]=_0x49e0d0,_0x53793d=!0x0);}),_0x53793d&&this['server_']['reportStats'](_0x4b797c),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x434346){_0x434346[_0x434346['OVERWRITE']=0x0]='OVERWRITE',_0x434346[_0x434346['MERGE']=0x1]='MERGE',_0x434346[_0x434346['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x434346[_0x434346['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4ce536){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4ce536,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5b9c48,_0x438dc1,_0x10ba3b){this['path']=_0x5b9c48,this['affectedTree']=_0x438dc1,this['revert']=_0x10ba3b,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x447552){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x994f4=this['affectedTree']['subtree'](new C(_0x447552));return new In(w(),_0x994f4,this['revert']);}}else return f(y(this['path'])===_0x447552,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3ca4a4,_0x1dd6b9){this['source']=_0x3ca4a4,this['path']=_0x1dd6b9,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1f5493){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5521b7,_0x20b291,_0x3e66c5){this['source']=_0x5521b7,this['path']=_0x20b291,this['snap']=_0x3e66c5,this['type']=z['OVERWRITE'];}['operationForChild'](_0x2973e3){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x2973e3)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4c5e6a,_0x2f07ac,_0x70d7b){this['source']=_0x4c5e6a,this['path']=_0x2f07ac,this['children']=_0x70d7b,this['type']=z['MERGE'];}['operationForChild'](_0x22a089){if(v(this['path'])){const _0x25ad56=this['children']['subtree'](new C(_0x22a089));return _0x25ad56['isEmpty']()?null:_0x25ad56['value']?new Be(this['source'],w(),_0x25ad56['value']):new ot(this['source'],w(),_0x25ad56);}else return f(y(this['path'])===_0x22a089,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x45d299,_0x3de2d4,_0x33dcc7){this['node_']=_0x45d299,this['fullyInitialized_']=_0x3de2d4,this['filtered_']=_0x33dcc7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x27c8bf){if(v(_0x27c8bf))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5642cf=y(_0x27c8bf);return this['isCompleteForChild'](_0x5642cf);}['isCompleteForChild'](_0x57cc5f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x57cc5f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x30ddd1){this['query_']=_0x30ddd1,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1b8048,_0x319615,_0x1d5c1f,_0x59b34a){const _0x5a17e9=[],_0x59050b=[];return _0x319615['forEach'](_0x1bb7f3=>{_0x1bb7f3['type']==='child_changed'&&_0x1b8048['index_']['indexedValueChanged'](_0x1bb7f3['oldSnap'],_0x1bb7f3['snapshotNode'])&&_0x59050b['push'](zh(_0x1bb7f3['childName'],_0x1bb7f3['snapshotNode']));}),wt(_0x1b8048,_0x5a17e9,'child_removed',_0x319615,_0x59b34a,_0x1d5c1f),wt(_0x1b8048,_0x5a17e9,'child_added',_0x319615,_0x59b34a,_0x1d5c1f),wt(_0x1b8048,_0x5a17e9,'child_moved',_0x59050b,_0x59b34a,_0x1d5c1f),wt(_0x1b8048,_0x5a17e9,'child_changed',_0x319615,_0x59b34a,_0x1d5c1f),wt(_0x1b8048,_0x5a17e9,'value',_0x319615,_0x59b34a,_0x1d5c1f),_0x5a17e9;}function wt(_0x242a00,_0x394012,_0x11ecb4,_0x27dc7c,_0x3142a4,_0x9dee18){const _0x942d58=_0x27dc7c['filter'](_0x1d8607=>_0x1d8607['type']===_0x11ecb4);_0x942d58['sort']((_0x3af985,_0x34f22d)=>au(_0x242a00,_0x3af985,_0x34f22d)),_0x942d58['forEach'](_0x2e84db=>{const _0x14cbde=ou(_0x242a00,_0x2e84db,_0x9dee18);_0x3142a4['forEach'](_0x1bb3a4=>{_0x1bb3a4['respondsTo'](_0x2e84db['type'])&&_0x394012['push'](_0x1bb3a4['createEvent'](_0x14cbde,_0x242a00['query_']));});});}function ou(_0x564c24,_0x1daecd,_0x4ba421){return _0x1daecd['type']==='value'||_0x1daecd['type']==='child_removed'||(_0x1daecd['prevName']=_0x4ba421['getPredecessorChildName'](_0x1daecd['childName'],_0x1daecd['snapshotNode'],_0x564c24['index_'])),_0x1daecd;}function au(_0x24c1ce,_0x5943f0,_0x1a3160){if(_0x5943f0['childName']==null||_0x1a3160['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x578a84=new E(_0x5943f0['childName'],_0x5943f0['snapshotNode']),_0x27f094=new E(_0x1a3160['childName'],_0x1a3160['snapshotNode']);return _0x24c1ce['index_']['compare'](_0x578a84,_0x27f094);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x592537,_0x5a2a4f){return{'eventCache':_0x592537,'serverCache':_0x5a2a4f};}function Rt(_0x456357,_0x35efd6,_0x50ca60,_0x51109d){return Un(new Te(_0x35efd6,_0x50ca60,_0x51109d),_0x456357['serverCache']);}function Fo(_0x3ef02a,_0x3ce184,_0xd1ad7a,_0xd84103){return Un(_0x3ef02a['eventCache'],new Te(_0x3ce184,_0xd1ad7a,_0xd84103));}function wn(_0x18f9a5){return _0x18f9a5['eventCache']['isFullyInitialized']()?_0x18f9a5['eventCache']['getNode']():null;}function Ve(_0x3e2b4a){return _0x3e2b4a['serverCache']['isFullyInitialized']()?_0x3e2b4a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x17167b){let _0x16c398=new b(null);return x(_0x17167b,(_0xafd22d,_0x15a2b0)=>{_0x16c398=_0x16c398['set'](new C(_0xafd22d),_0x15a2b0);}),_0x16c398;}constructor(_0xcabd91,_0xd4c1b=cu()){this['value']=_0xcabd91,this['children']=_0xd4c1b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3373d7,_0x44a377){if(this['value']!=null&&_0x44a377(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3373d7))return null;{const _0x7fab94=y(_0x3373d7),_0x35fbb0=this['children']['get'](_0x7fab94);if(_0x35fbb0!==null){const _0x26a976=_0x35fbb0['findRootMostMatchingPathAndValue'](S(_0x3373d7),_0x44a377);return _0x26a976!=null?{'path':k(new C(_0x7fab94),_0x26a976['path']),'value':_0x26a976['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x26795a){return this['findRootMostMatchingPathAndValue'](_0x26795a,()=>!0x0);}['subtree'](_0xdd1b30){if(v(_0xdd1b30))return this;{const _0x36351a=y(_0xdd1b30),_0x2ff0fa=this['children']['get'](_0x36351a);return _0x2ff0fa!==null?_0x2ff0fa['subtree'](S(_0xdd1b30)):new b(null);}}['set'](_0x32c2fd,_0x10fba6){if(v(_0x32c2fd))return new b(_0x10fba6,this['children']);{const _0x1639b1=y(_0x32c2fd),_0x477406=(this['children']['get'](_0x1639b1)||new b(null))['set'](S(_0x32c2fd),_0x10fba6),_0x47ebe4=this['children']['insert'](_0x1639b1,_0x477406);return new b(this['value'],_0x47ebe4);}}['remove'](_0x1961cb){if(v(_0x1961cb))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x255432=y(_0x1961cb),_0x3c453d=this['children']['get'](_0x255432);if(_0x3c453d){const _0x3ff0a3=_0x3c453d['remove'](S(_0x1961cb));let _0x5e7f26;return _0x3ff0a3['isEmpty']()?_0x5e7f26=this['children']['remove'](_0x255432):_0x5e7f26=this['children']['insert'](_0x255432,_0x3ff0a3),this['value']===null&&_0x5e7f26['isEmpty']()?new b(null):new b(this['value'],_0x5e7f26);}else return this;}}['get'](_0x1f2286){if(v(_0x1f2286))return this['value'];{const _0x384980=y(_0x1f2286),_0x22ddc4=this['children']['get'](_0x384980);return _0x22ddc4?_0x22ddc4['get'](S(_0x1f2286)):null;}}['setTree'](_0x5f4d27,_0x403837){if(v(_0x5f4d27))return _0x403837;{const _0x45aa4c=y(_0x5f4d27),_0x20ae4b=(this['children']['get'](_0x45aa4c)||new b(null))['setTree'](S(_0x5f4d27),_0x403837);let _0x1a6012;return _0x20ae4b['isEmpty']()?_0x1a6012=this['children']['remove'](_0x45aa4c):_0x1a6012=this['children']['insert'](_0x45aa4c,_0x20ae4b),new b(this['value'],_0x1a6012);}}['fold'](_0x2c1ead){return this['fold_'](w(),_0x2c1ead);}['fold_'](_0x29f6e8,_0xfd32fc){const _0x6482fd={};return this['children']['inorderTraversal']((_0xd1b39b,_0x516a95)=>{_0x6482fd[_0xd1b39b]=_0x516a95['fold_'](k(_0x29f6e8,_0xd1b39b),_0xfd32fc);}),_0xfd32fc(_0x29f6e8,this['value'],_0x6482fd);}['findOnPath'](_0x3277bd,_0x2c0cc1){return this['findOnPath_'](_0x3277bd,w(),_0x2c0cc1);}['findOnPath_'](_0xdc350f,_0x24d4a9,_0x4c2d3a){const _0x4cd346=this['value']?_0x4c2d3a(_0x24d4a9,this['value']):!0x1;if(_0x4cd346)return _0x4cd346;if(v(_0xdc350f))return null;{const _0x5d900b=y(_0xdc350f),_0x36b47c=this['children']['get'](_0x5d900b);return _0x36b47c?_0x36b47c['findOnPath_'](S(_0xdc350f),k(_0x24d4a9,_0x5d900b),_0x4c2d3a):null;}}['foreachOnPath'](_0x4ee3da,_0x4ecc61){return this['foreachOnPath_'](_0x4ee3da,w(),_0x4ecc61);}['foreachOnPath_'](_0x4a7615,_0x8fc5fb,_0x52b4ae){if(v(_0x4a7615))return this;{this['value']&&_0x52b4ae(_0x8fc5fb,this['value']);const _0x5e6ff4=y(_0x4a7615),_0x3cdced=this['children']['get'](_0x5e6ff4);return _0x3cdced?_0x3cdced['foreachOnPath_'](S(_0x4a7615),k(_0x8fc5fb,_0x5e6ff4),_0x52b4ae):new b(null);}}['foreach'](_0xe920f5){this['foreach_'](w(),_0xe920f5);}['foreach_'](_0x38112b,_0x4decf6){this['children']['inorderTraversal']((_0x416586,_0x1aa023)=>{_0x1aa023['foreach_'](k(_0x38112b,_0x416586),_0x4decf6);}),this['value']&&_0x4decf6(_0x38112b,this['value']);}['foreachChild'](_0x5aa724){this['children']['inorderTraversal']((_0x5baad9,_0x3a467c)=>{_0x3a467c['value']&&_0x5aa724(_0x5baad9,_0x3a467c['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0xe4b02c){this['writeTree_']=_0xe4b02c;}static['empty'](){return new K(new b(null));}}function At(_0x944262,_0x721aa2,_0xa35eaa){if(v(_0x721aa2))return new K(new b(_0xa35eaa));{const _0x172552=_0x944262['writeTree_']['findRootMostValueAndPath'](_0x721aa2);if(_0x172552!=null){const _0x310064=_0x172552['path'];let _0x3f4ffc=_0x172552['value'];const _0x5d59c2=F(_0x310064,_0x721aa2);return _0x3f4ffc=_0x3f4ffc['updateChild'](_0x5d59c2,_0xa35eaa),new K(_0x944262['writeTree_']['set'](_0x310064,_0x3f4ffc));}else{const _0x5b1769=new b(_0xa35eaa),_0x48a330=_0x944262['writeTree_']['setTree'](_0x721aa2,_0x5b1769);return new K(_0x48a330);}}}function bi(_0x3c77af,_0x15781c,_0x50876a){let _0x7a7741=_0x3c77af;return x(_0x50876a,(_0x75193a,_0x23986f)=>{_0x7a7741=At(_0x7a7741,k(_0x15781c,_0x75193a),_0x23986f);}),_0x7a7741;}function or(_0xdeee10,_0x392028){if(v(_0x392028))return K['empty']();{const _0x2676d6=_0xdeee10['writeTree_']['setTree'](_0x392028,new b(null));return new K(_0x2676d6);}}function Ri(_0x5daf4e,_0x20eb30){return ze(_0x5daf4e,_0x20eb30)!=null;}function ze(_0x104603,_0x4ceacf){const _0x75fe89=_0x104603['writeTree_']['findRootMostValueAndPath'](_0x4ceacf);return _0x75fe89!=null?_0x104603['writeTree_']['get'](_0x75fe89['path'])['getChild'](F(_0x75fe89['path'],_0x4ceacf)):null;}function ar(_0x54cf71){const _0x3acdfa=[],_0x38aab1=_0x54cf71['writeTree_']['value'];return _0x38aab1!=null?_0x38aab1['isLeafNode']()||_0x38aab1['forEachChild'](R,(_0x246e7d,_0x3b72d0)=>{_0x3acdfa['push'](new E(_0x246e7d,_0x3b72d0));}):_0x54cf71['writeTree_']['children']['inorderTraversal']((_0x4a5e14,_0x2af8dc)=>{_0x2af8dc['value']!=null&&_0x3acdfa['push'](new E(_0x4a5e14,_0x2af8dc['value']));}),_0x3acdfa;}function Ee(_0x2a63e3,_0x2f5e6a){if(v(_0x2f5e6a))return _0x2a63e3;{const _0x7121fc=ze(_0x2a63e3,_0x2f5e6a);return _0x7121fc!=null?new K(new b(_0x7121fc)):new K(_0x2a63e3['writeTree_']['subtree'](_0x2f5e6a));}}function Ai(_0x13874a){return _0x13874a['writeTree_']['isEmpty']();}function at(_0x44764e,_0x1eac8f){return Uo(w(),_0x44764e['writeTree_'],_0x1eac8f);}function Uo(_0x5d784d,_0x276655,_0x55f4c6){if(_0x276655['value']!=null)return _0x55f4c6['updateChild'](_0x5d784d,_0x276655['value']);{let _0x51d6a8=null;return _0x276655['children']['inorderTraversal']((_0x1359c0,_0x42e187)=>{_0x1359c0==='.priority'?(f(_0x42e187['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x51d6a8=_0x42e187['value']):_0x55f4c6=Uo(k(_0x5d784d,_0x1359c0),_0x42e187,_0x55f4c6);}),!_0x55f4c6['getChild'](_0x5d784d)['isEmpty']()&&_0x51d6a8!==null&&(_0x55f4c6=_0x55f4c6['updateChild'](k(_0x5d784d,'.priority'),_0x51d6a8)),_0x55f4c6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0xa27fad,_0x2a3f76){return Ho(_0x2a3f76,_0xa27fad);}function lu(_0x4bbbb6,_0x35e324,_0x4a19d6,_0x244c5e,_0x59139d){f(_0x244c5e>_0x4bbbb6['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x59139d===void 0x0&&(_0x59139d=!0x0),_0x4bbbb6['allWrites']['push']({'path':_0x35e324,'snap':_0x4a19d6,'writeId':_0x244c5e,'visible':_0x59139d}),_0x59139d&&(_0x4bbbb6['visibleWrites']=At(_0x4bbbb6['visibleWrites'],_0x35e324,_0x4a19d6)),_0x4bbbb6['lastWriteId']=_0x244c5e;}function hu(_0x28a1ed,_0x2bc645,_0x3e00e2,_0x580cd8){f(_0x580cd8>_0x28a1ed['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x28a1ed['allWrites']['push']({'path':_0x2bc645,'children':_0x3e00e2,'writeId':_0x580cd8,'visible':!0x0}),_0x28a1ed['visibleWrites']=bi(_0x28a1ed['visibleWrites'],_0x2bc645,_0x3e00e2),_0x28a1ed['lastWriteId']=_0x580cd8;}function uu(_0x1294be,_0x17e771){for(let _0x4d0634=0x0;_0x4d0634<_0x1294be['allWrites']['length'];_0x4d0634++){const _0x3d5a49=_0x1294be['allWrites'][_0x4d0634];if(_0x3d5a49['writeId']===_0x17e771)return _0x3d5a49;}return null;}function du(_0x48f345,_0x142540){const _0x29eb95=_0x48f345['allWrites']['findIndex'](_0x194456=>_0x194456['writeId']===_0x142540);f(_0x29eb95>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x582e89=_0x48f345['allWrites'][_0x29eb95];_0x48f345['allWrites']['splice'](_0x29eb95,0x1);let _0x32ef20=_0x582e89['visible'],_0x152dad=!0x1,_0x5b3164=_0x48f345['allWrites']['length']-0x1;for(;_0x32ef20&&_0x5b3164>=0x0;){const _0x21777a=_0x48f345['allWrites'][_0x5b3164];_0x21777a['visible']&&(_0x5b3164>=_0x29eb95&&fu(_0x21777a,_0x582e89['path'])?_0x32ef20=!0x1:G(_0x582e89['path'],_0x21777a['path'])&&(_0x152dad=!0x0)),_0x5b3164--;}if(_0x32ef20){if(_0x152dad)return pu(_0x48f345),!0x0;if(_0x582e89['snap'])_0x48f345['visibleWrites']=or(_0x48f345['visibleWrites'],_0x582e89['path']);else{const _0xad9137=_0x582e89['children'];x(_0xad9137,_0x41ff63=>{_0x48f345['visibleWrites']=or(_0x48f345['visibleWrites'],k(_0x582e89['path'],_0x41ff63));});}return!0x0;}else return!0x1;}function fu(_0x1fe95a,_0x1b390f){if(_0x1fe95a['snap'])return G(_0x1fe95a['path'],_0x1b390f);for(const _0x761c76 in _0x1fe95a['children'])if(_0x1fe95a['children']['hasOwnProperty'](_0x761c76)&&G(k(_0x1fe95a['path'],_0x761c76),_0x1b390f))return!0x0;return!0x1;}function pu(_0x2605b2){_0x2605b2['visibleWrites']=Wo(_0x2605b2['allWrites'],_u,w()),_0x2605b2['allWrites']['length']>0x0?_0x2605b2['lastWriteId']=_0x2605b2['allWrites'][_0x2605b2['allWrites']['length']-0x1]['writeId']:_0x2605b2['lastWriteId']=-0x1;}function _u(_0xab2d77){return _0xab2d77['visible'];}function Wo(_0x5884b0,_0x48c5e0,_0x849f3){let _0x3533cb=K['empty']();for(let _0x4ddbd6=0x0;_0x4ddbd6<_0x5884b0['length'];++_0x4ddbd6){const _0x403d44=_0x5884b0[_0x4ddbd6];if(_0x48c5e0(_0x403d44)){const _0x5eabb4=_0x403d44['path'];let _0x35fcbe;if(_0x403d44['snap'])G(_0x849f3,_0x5eabb4)?(_0x35fcbe=F(_0x849f3,_0x5eabb4),_0x3533cb=At(_0x3533cb,_0x35fcbe,_0x403d44['snap'])):G(_0x5eabb4,_0x849f3)&&(_0x35fcbe=F(_0x5eabb4,_0x849f3),_0x3533cb=At(_0x3533cb,w(),_0x403d44['snap']['getChild'](_0x35fcbe)));else{if(_0x403d44['children']){if(G(_0x849f3,_0x5eabb4))_0x35fcbe=F(_0x849f3,_0x5eabb4),_0x3533cb=bi(_0x3533cb,_0x35fcbe,_0x403d44['children']);else{if(G(_0x5eabb4,_0x849f3)){if(_0x35fcbe=F(_0x5eabb4,_0x849f3),v(_0x35fcbe))_0x3533cb=bi(_0x3533cb,w(),_0x403d44['children']);else{const _0x35b5fe=Le(_0x403d44['children'],y(_0x35fcbe));if(_0x35b5fe){const _0x9ed059=_0x35b5fe['getChild'](S(_0x35fcbe));_0x3533cb=At(_0x3533cb,w(),_0x9ed059);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3533cb;}function Bo(_0x11ea9c,_0x3a81ea,_0x2dc0d6,_0x5b063f,_0x168db9){if(!_0x5b063f&&!_0x168db9){const _0x13b728=ze(_0x11ea9c['visibleWrites'],_0x3a81ea);if(_0x13b728!=null)return _0x13b728;{const _0x1e4b57=Ee(_0x11ea9c['visibleWrites'],_0x3a81ea);if(Ai(_0x1e4b57))return _0x2dc0d6;if(_0x2dc0d6==null&&!Ri(_0x1e4b57,w()))return null;{const _0x527d4a=_0x2dc0d6||g['EMPTY_NODE'];return at(_0x1e4b57,_0x527d4a);}}}else{const _0x33cfdb=Ee(_0x11ea9c['visibleWrites'],_0x3a81ea);if(!_0x168db9&&Ai(_0x33cfdb))return _0x2dc0d6;if(!_0x168db9&&_0x2dc0d6==null&&!Ri(_0x33cfdb,w()))return null;{const _0x56d9fe=function(_0x5cd8b5){return(_0x5cd8b5['visible']||_0x168db9)&&(!_0x5b063f||!~_0x5b063f['indexOf'](_0x5cd8b5['writeId']))&&(G(_0x5cd8b5['path'],_0x3a81ea)||G(_0x3a81ea,_0x5cd8b5['path']));},_0x45f65e=Wo(_0x11ea9c['allWrites'],_0x56d9fe,_0x3a81ea),_0x827ead=_0x2dc0d6||g['EMPTY_NODE'];return at(_0x45f65e,_0x827ead);}}}function gu(_0x43f97a,_0x2677c8,_0x52f823){let _0x12a080=g['EMPTY_NODE'];const _0x4627c5=ze(_0x43f97a['visibleWrites'],_0x2677c8);if(_0x4627c5)return _0x4627c5['isLeafNode']()||_0x4627c5['forEachChild'](R,(_0x4cb796,_0x52f695)=>{_0x12a080=_0x12a080['updateImmediateChild'](_0x4cb796,_0x52f695);}),_0x12a080;if(_0x52f823){const _0x3ac9d7=Ee(_0x43f97a['visibleWrites'],_0x2677c8);return _0x52f823['forEachChild'](R,(_0x84b1c6,_0x4b8992)=>{const _0x23e18a=at(Ee(_0x3ac9d7,new C(_0x84b1c6)),_0x4b8992);_0x12a080=_0x12a080['updateImmediateChild'](_0x84b1c6,_0x23e18a);}),ar(_0x3ac9d7)['forEach'](_0x16d416=>{_0x12a080=_0x12a080['updateImmediateChild'](_0x16d416['name'],_0x16d416['node']);}),_0x12a080;}else{const _0xa61ac4=Ee(_0x43f97a['visibleWrites'],_0x2677c8);return ar(_0xa61ac4)['forEach'](_0x2baebf=>{_0x12a080=_0x12a080['updateImmediateChild'](_0x2baebf['name'],_0x2baebf['node']);}),_0x12a080;}}function mu(_0x245e72,_0x3083ea,_0x36ecc5,_0x4091eb,_0x1e405c){f(_0x4091eb||_0x1e405c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x39b114=k(_0x3083ea,_0x36ecc5);if(Ri(_0x245e72['visibleWrites'],_0x39b114))return null;{const _0x5b4af8=Ee(_0x245e72['visibleWrites'],_0x39b114);return Ai(_0x5b4af8)?_0x1e405c['getChild'](_0x36ecc5):at(_0x5b4af8,_0x1e405c['getChild'](_0x36ecc5));}}function yu(_0x5449c2,_0x54fc8c,_0xa8e4e5,_0x1bd800){const _0x5aec76=k(_0x54fc8c,_0xa8e4e5),_0xfa314d=ze(_0x5449c2['visibleWrites'],_0x5aec76);if(_0xfa314d!=null)return _0xfa314d;if(_0x1bd800['isCompleteForChild'](_0xa8e4e5)){const _0x1d4d9b=Ee(_0x5449c2['visibleWrites'],_0x5aec76);return at(_0x1d4d9b,_0x1bd800['getNode']()['getImmediateChild'](_0xa8e4e5));}else return null;}function vu(_0x58b7dc,_0x3760d5){return ze(_0x58b7dc['visibleWrites'],_0x3760d5);}function Eu(_0x52644e,_0x355e80,_0xea0130,_0x528c19,_0x5bc9e0,_0x4a129b,_0x2e027a){let _0xdd822f;const _0x193d40=Ee(_0x52644e['visibleWrites'],_0x355e80),_0x147dfb=ze(_0x193d40,w());if(_0x147dfb!=null)_0xdd822f=_0x147dfb;else{if(_0xea0130!=null)_0xdd822f=at(_0x193d40,_0xea0130);else return[];}if(_0xdd822f=_0xdd822f['withIndex'](_0x2e027a),!_0xdd822f['isEmpty']()&&!_0xdd822f['isLeafNode']()){const _0x323641=[],_0x104075=_0x2e027a['getCompare'](),_0xa19e5e=_0x4a129b?_0xdd822f['getReverseIteratorFrom'](_0x528c19,_0x2e027a):_0xdd822f['getIteratorFrom'](_0x528c19,_0x2e027a);let _0x37c5ba=_0xa19e5e['getNext']();for(;_0x37c5ba&&_0x323641['length']<_0x5bc9e0;)_0x104075(_0x37c5ba,_0x528c19)!==0x0&&_0x323641['push'](_0x37c5ba),_0x37c5ba=_0xa19e5e['getNext']();return _0x323641;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0xb8149b,_0x171b13,_0x241cd7,_0x40a96e){return Bo(_0xb8149b['writeTree'],_0xb8149b['treePath'],_0x171b13,_0x241cd7,_0x40a96e);}function is(_0x2ec742,_0x36d24f){return gu(_0x2ec742['writeTree'],_0x2ec742['treePath'],_0x36d24f);}function cr(_0x497973,_0x38d064,_0x452958,_0x556b7e){return mu(_0x497973['writeTree'],_0x497973['treePath'],_0x38d064,_0x452958,_0x556b7e);}function Tn(_0x561f7b,_0x5f5ccc){return vu(_0x561f7b['writeTree'],k(_0x561f7b['treePath'],_0x5f5ccc));}function wu(_0x48e581,_0x21016f,_0x1c2f22,_0xc271d9,_0x40dec2,_0x1e6568){return Eu(_0x48e581['writeTree'],_0x48e581['treePath'],_0x21016f,_0x1c2f22,_0xc271d9,_0x40dec2,_0x1e6568);}function ss(_0x4fa0d7,_0x50ff0b,_0x551ef6){return yu(_0x4fa0d7['writeTree'],_0x4fa0d7['treePath'],_0x50ff0b,_0x551ef6);}function Vo(_0x283686,_0x173096){return Ho(k(_0x283686['treePath'],_0x173096),_0x283686['writeTree']);}function Ho(_0x20f321,_0xe225de){return{'treePath':_0x20f321,'writeTree':_0xe225de};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x1b3c22){const _0x55ee06=_0x1b3c22['type'],_0x2b5ea2=_0x1b3c22['childName'];f(_0x55ee06==='child_added'||_0x55ee06==='child_changed'||_0x55ee06==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2b5ea2!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1b1221=this['changeMap']['get'](_0x2b5ea2);if(_0x1b1221){const _0x9fb74a=_0x1b1221['type'];if(_0x55ee06==='child_added'&&_0x9fb74a==='child_removed')this['changeMap']['set'](_0x2b5ea2,xt(_0x2b5ea2,_0x1b3c22['snapshotNode'],_0x1b1221['snapshotNode']));else{if(_0x55ee06==='child_removed'&&_0x9fb74a==='child_added')this['changeMap']['delete'](_0x2b5ea2);else{if(_0x55ee06==='child_removed'&&_0x9fb74a==='child_changed')this['changeMap']['set'](_0x2b5ea2,Lt(_0x2b5ea2,_0x1b1221['oldSnap']));else{if(_0x55ee06==='child_changed'&&_0x9fb74a==='child_added')this['changeMap']['set'](_0x2b5ea2,rt(_0x2b5ea2,_0x1b3c22['snapshotNode']));else{if(_0x55ee06==='child_changed'&&_0x9fb74a==='child_changed')this['changeMap']['set'](_0x2b5ea2,xt(_0x2b5ea2,_0x1b3c22['snapshotNode'],_0x1b1221['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x1b3c22+'\x20occurred\x20after\x20'+_0x1b1221);}}}}}else this['changeMap']['set'](_0x2b5ea2,_0x1b3c22);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x578f2e){return null;}['getChildAfterChild'](_0x6847ea,_0x23e461,_0x4d1b77){return null;}}const $o=new Tu();class rs{constructor(_0x51d4e2,_0x4dc246,_0x1fb6c4=null){this['writes_']=_0x51d4e2,this['viewCache_']=_0x4dc246,this['optCompleteServerCache_']=_0x1fb6c4;}['getCompleteChild'](_0x21c135){const _0x2325c1=this['viewCache_']['eventCache'];if(_0x2325c1['isCompleteForChild'](_0x21c135))return _0x2325c1['getNode']()['getImmediateChild'](_0x21c135);{const _0x3f9857=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x21c135,_0x3f9857);}}['getChildAfterChild'](_0x418cd2,_0x503aba,_0xd33163){const _0x47ee2b=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x5cae53=wu(this['writes_'],_0x47ee2b,_0x503aba,0x1,_0xd33163,_0x418cd2);return _0x5cae53['length']===0x0?null:_0x5cae53[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4b5d19){return{'filter':_0x4b5d19};}function bu(_0x128f91,_0x1e2204){f(_0x1e2204['eventCache']['getNode']()['isIndexed'](_0x128f91['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1e2204['serverCache']['getNode']()['isIndexed'](_0x128f91['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x744c5,_0x1abc12,_0x4d217b,_0x345fca,_0x85ed83){const _0x48d1a2=new Cu();let _0x533965,_0x397d92;if(_0x4d217b['type']===z['OVERWRITE']){const _0x13b9a7=_0x4d217b;_0x13b9a7['source']['fromUser']?_0x533965=ki(_0x744c5,_0x1abc12,_0x13b9a7['path'],_0x13b9a7['snap'],_0x345fca,_0x85ed83,_0x48d1a2):(f(_0x13b9a7['source']['fromServer'],'Unknown\x20source.'),_0x397d92=_0x13b9a7['source']['tagged']||_0x1abc12['serverCache']['isFiltered']()&&!v(_0x13b9a7['path']),_0x533965=Sn(_0x744c5,_0x1abc12,_0x13b9a7['path'],_0x13b9a7['snap'],_0x345fca,_0x85ed83,_0x397d92,_0x48d1a2));}else{if(_0x4d217b['type']===z['MERGE']){const _0x1bd8a5=_0x4d217b;_0x1bd8a5['source']['fromUser']?_0x533965=ku(_0x744c5,_0x1abc12,_0x1bd8a5['path'],_0x1bd8a5['children'],_0x345fca,_0x85ed83,_0x48d1a2):(f(_0x1bd8a5['source']['fromServer'],'Unknown\x20source.'),_0x397d92=_0x1bd8a5['source']['tagged']||_0x1abc12['serverCache']['isFiltered'](),_0x533965=Pi(_0x744c5,_0x1abc12,_0x1bd8a5['path'],_0x1bd8a5['children'],_0x345fca,_0x85ed83,_0x397d92,_0x48d1a2));}else{if(_0x4d217b['type']===z['ACK_USER_WRITE']){const _0x1c3b5c=_0x4d217b;_0x1c3b5c['revert']?_0x533965=Ou(_0x744c5,_0x1abc12,_0x1c3b5c['path'],_0x345fca,_0x85ed83,_0x48d1a2):_0x533965=Pu(_0x744c5,_0x1abc12,_0x1c3b5c['path'],_0x1c3b5c['affectedTree'],_0x345fca,_0x85ed83,_0x48d1a2);}else{if(_0x4d217b['type']===z['LISTEN_COMPLETE'])_0x533965=Nu(_0x744c5,_0x1abc12,_0x4d217b['path'],_0x345fca,_0x48d1a2);else throw ht('Unknown\x20operation\x20type:\x20'+_0x4d217b['type']);}}}const _0xbee7c6=_0x48d1a2['getChanges']();return Au(_0x1abc12,_0x533965,_0xbee7c6),{'viewCache':_0x533965,'changes':_0xbee7c6};}function Au(_0x5a9a07,_0x2375c5,_0x5b9919){const _0x3bc557=_0x2375c5['eventCache'];if(_0x3bc557['isFullyInitialized']()){const _0x1ae1e6=_0x3bc557['getNode']()['isLeafNode']()||_0x3bc557['getNode']()['isEmpty'](),_0x47f1ab=wn(_0x5a9a07);(_0x5b9919['length']>0x0||!_0x5a9a07['eventCache']['isFullyInitialized']()||_0x1ae1e6&&!_0x3bc557['getNode']()['equals'](_0x47f1ab)||!_0x3bc557['getNode']()['getPriority']()['equals'](_0x47f1ab['getPriority']()))&&_0x5b9919['push'](Lo(wn(_0x2375c5)));}}function Go(_0x12efa0,_0x5d48d7,_0x5756d8,_0x1619c0,_0x261ef9,_0x381f08){const _0x1e79d1=_0x5d48d7['eventCache'];if(Tn(_0x1619c0,_0x5756d8)!=null)return _0x5d48d7;{let _0x1538a6,_0x2b1729;if(v(_0x5756d8)){if(f(_0x5d48d7['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5d48d7['serverCache']['isFiltered']()){const _0x346a16=Ve(_0x5d48d7),_0x1332be=_0x346a16 instanceof g?_0x346a16:g['EMPTY_NODE'],_0x59127b=is(_0x1619c0,_0x1332be);_0x1538a6=_0x12efa0['filter']['updateFullNode'](_0x5d48d7['eventCache']['getNode'](),_0x59127b,_0x381f08);}else{const _0x49d8f0=Cn(_0x1619c0,Ve(_0x5d48d7));_0x1538a6=_0x12efa0['filter']['updateFullNode'](_0x5d48d7['eventCache']['getNode'](),_0x49d8f0,_0x381f08);}}else{const _0x1034e7=y(_0x5756d8);if(_0x1034e7==='.priority'){f(Ce(_0x5756d8)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x739071=_0x1e79d1['getNode']();_0x2b1729=_0x5d48d7['serverCache']['getNode']();const _0x5c45cf=cr(_0x1619c0,_0x5756d8,_0x739071,_0x2b1729);_0x5c45cf!=null?_0x1538a6=_0x12efa0['filter']['updatePriority'](_0x739071,_0x5c45cf):_0x1538a6=_0x1e79d1['getNode']();}else{const _0x48b8b4=S(_0x5756d8);let _0x5d578f;if(_0x1e79d1['isCompleteForChild'](_0x1034e7)){_0x2b1729=_0x5d48d7['serverCache']['getNode']();const _0x54fc55=cr(_0x1619c0,_0x5756d8,_0x1e79d1['getNode'](),_0x2b1729);_0x54fc55!=null?_0x5d578f=_0x1e79d1['getNode']()['getImmediateChild'](_0x1034e7)['updateChild'](_0x48b8b4,_0x54fc55):_0x5d578f=_0x1e79d1['getNode']()['getImmediateChild'](_0x1034e7);}else _0x5d578f=ss(_0x1619c0,_0x1034e7,_0x5d48d7['serverCache']);_0x5d578f!=null?_0x1538a6=_0x12efa0['filter']['updateChild'](_0x1e79d1['getNode'](),_0x1034e7,_0x5d578f,_0x48b8b4,_0x261ef9,_0x381f08):_0x1538a6=_0x1e79d1['getNode']();}}return Rt(_0x5d48d7,_0x1538a6,_0x1e79d1['isFullyInitialized']()||v(_0x5756d8),_0x12efa0['filter']['filtersNodes']());}}function Sn(_0x4aca00,_0x37149b,_0xf7b11a,_0x40740d,_0x2303f3,_0x13173b,_0x4debd7,_0x37f42b){const _0x9f6aaf=_0x37149b['serverCache'];let _0x5c2a3d;const _0x2c8cec=_0x4debd7?_0x4aca00['filter']:_0x4aca00['filter']['getIndexedFilter']();if(v(_0xf7b11a))_0x5c2a3d=_0x2c8cec['updateFullNode'](_0x9f6aaf['getNode'](),_0x40740d,null);else{if(_0x2c8cec['filtersNodes']()&&!_0x9f6aaf['isFiltered']()){const _0x4fbf4e=_0x9f6aaf['getNode']()['updateChild'](_0xf7b11a,_0x40740d);_0x5c2a3d=_0x2c8cec['updateFullNode'](_0x9f6aaf['getNode'](),_0x4fbf4e,null);}else{const _0x319cc8=y(_0xf7b11a);if(!_0x9f6aaf['isCompleteForPath'](_0xf7b11a)&&Ce(_0xf7b11a)>0x1)return _0x37149b;const _0xd75e57=S(_0xf7b11a),_0x73a7df=_0x9f6aaf['getNode']()['getImmediateChild'](_0x319cc8)['updateChild'](_0xd75e57,_0x40740d);_0x319cc8==='.priority'?_0x5c2a3d=_0x2c8cec['updatePriority'](_0x9f6aaf['getNode'](),_0x73a7df):_0x5c2a3d=_0x2c8cec['updateChild'](_0x9f6aaf['getNode'](),_0x319cc8,_0x73a7df,_0xd75e57,$o,null);}}const _0x7ea9a0=Fo(_0x37149b,_0x5c2a3d,_0x9f6aaf['isFullyInitialized']()||v(_0xf7b11a),_0x2c8cec['filtersNodes']()),_0x39c825=new rs(_0x2303f3,_0x7ea9a0,_0x13173b);return Go(_0x4aca00,_0x7ea9a0,_0xf7b11a,_0x2303f3,_0x39c825,_0x37f42b);}function ki(_0x58a758,_0x3a8429,_0x173773,_0x179566,_0x3cfeb4,_0x279655,_0x505f27){const _0x32bbcc=_0x3a8429['eventCache'];let _0x5f53dc,_0x3b6d2e;const _0x55c961=new rs(_0x3cfeb4,_0x3a8429,_0x279655);if(v(_0x173773))_0x3b6d2e=_0x58a758['filter']['updateFullNode'](_0x3a8429['eventCache']['getNode'](),_0x179566,_0x505f27),_0x5f53dc=Rt(_0x3a8429,_0x3b6d2e,!0x0,_0x58a758['filter']['filtersNodes']());else{const _0x241642=y(_0x173773);if(_0x241642==='.priority')_0x3b6d2e=_0x58a758['filter']['updatePriority'](_0x3a8429['eventCache']['getNode'](),_0x179566),_0x5f53dc=Rt(_0x3a8429,_0x3b6d2e,_0x32bbcc['isFullyInitialized'](),_0x32bbcc['isFiltered']());else{const _0x494c28=S(_0x173773),_0x5afa04=_0x32bbcc['getNode']()['getImmediateChild'](_0x241642);let _0x27b7fa;if(v(_0x494c28))_0x27b7fa=_0x179566;else{const _0x3dc63e=_0x55c961['getCompleteChild'](_0x241642);_0x3dc63e!=null?ji(_0x494c28)==='.priority'&&_0x3dc63e['getChild'](Ro(_0x494c28))['isEmpty']()?_0x27b7fa=_0x3dc63e:_0x27b7fa=_0x3dc63e['updateChild'](_0x494c28,_0x179566):_0x27b7fa=g['EMPTY_NODE'];}if(_0x5afa04['equals'](_0x27b7fa))_0x5f53dc=_0x3a8429;else{const _0xbefd0f=_0x58a758['filter']['updateChild'](_0x32bbcc['getNode'](),_0x241642,_0x27b7fa,_0x494c28,_0x55c961,_0x505f27);_0x5f53dc=Rt(_0x3a8429,_0xbefd0f,_0x32bbcc['isFullyInitialized'](),_0x58a758['filter']['filtersNodes']());}}}return _0x5f53dc;}function lr(_0x58f4da,_0x2f1d31){return _0x58f4da['eventCache']['isCompleteForChild'](_0x2f1d31);}function ku(_0x864e9d,_0x5f13ad,_0x1ba793,_0x18a27c,_0x4ed49f,_0x21ceac,_0x7cdc4d){let _0x36322d=_0x5f13ad;return _0x18a27c['foreach']((_0x19f345,_0x2556d5)=>{const _0x41db0f=k(_0x1ba793,_0x19f345);lr(_0x5f13ad,y(_0x41db0f))&&(_0x36322d=ki(_0x864e9d,_0x36322d,_0x41db0f,_0x2556d5,_0x4ed49f,_0x21ceac,_0x7cdc4d));}),_0x18a27c['foreach']((_0x4a4438,_0x44e82f)=>{const _0xfa50cd=k(_0x1ba793,_0x4a4438);lr(_0x5f13ad,y(_0xfa50cd))||(_0x36322d=ki(_0x864e9d,_0x36322d,_0xfa50cd,_0x44e82f,_0x4ed49f,_0x21ceac,_0x7cdc4d));}),_0x36322d;}function hr(_0x4e6890,_0x3c37aa,_0x11111f){return _0x11111f['foreach']((_0x3cb53a,_0x4e768f)=>{_0x3c37aa=_0x3c37aa['updateChild'](_0x3cb53a,_0x4e768f);}),_0x3c37aa;}function Pi(_0x1104d9,_0x511e9e,_0x4d52ec,_0x4020b9,_0x35f04c,_0x4bcd8d,_0x3adc69,_0x51fc7a){if(_0x511e9e['serverCache']['getNode']()['isEmpty']()&&!_0x511e9e['serverCache']['isFullyInitialized']())return _0x511e9e;let _0xc73a14=_0x511e9e,_0x97342f;v(_0x4d52ec)?_0x97342f=_0x4020b9:_0x97342f=new b(null)['setTree'](_0x4d52ec,_0x4020b9);const _0x469fa9=_0x511e9e['serverCache']['getNode']();return _0x97342f['children']['inorderTraversal']((_0x3bdf82,_0x2b4e05)=>{if(_0x469fa9['hasChild'](_0x3bdf82)){const _0x45f97e=_0x511e9e['serverCache']['getNode']()['getImmediateChild'](_0x3bdf82),_0x5a1204=hr(_0x1104d9,_0x45f97e,_0x2b4e05);_0xc73a14=Sn(_0x1104d9,_0xc73a14,new C(_0x3bdf82),_0x5a1204,_0x35f04c,_0x4bcd8d,_0x3adc69,_0x51fc7a);}}),_0x97342f['children']['inorderTraversal']((_0x21e464,_0x1c6c0f)=>{const _0x3201df=!_0x511e9e['serverCache']['isCompleteForChild'](_0x21e464)&&_0x1c6c0f['value']===null;if(!_0x469fa9['hasChild'](_0x21e464)&&!_0x3201df){const _0x58f5df=_0x511e9e['serverCache']['getNode']()['getImmediateChild'](_0x21e464),_0x4ebd99=hr(_0x1104d9,_0x58f5df,_0x1c6c0f);_0xc73a14=Sn(_0x1104d9,_0xc73a14,new C(_0x21e464),_0x4ebd99,_0x35f04c,_0x4bcd8d,_0x3adc69,_0x51fc7a);}}),_0xc73a14;}function Pu(_0x2f79e4,_0x30f48c,_0x5135d2,_0x3e6e9e,_0x8d39a4,_0x302d17,_0x424d3e){if(Tn(_0x8d39a4,_0x5135d2)!=null)return _0x30f48c;const _0xb63805=_0x30f48c['serverCache']['isFiltered'](),_0xb66e5=_0x30f48c['serverCache'];if(_0x3e6e9e['value']!=null){if(v(_0x5135d2)&&_0xb66e5['isFullyInitialized']()||_0xb66e5['isCompleteForPath'](_0x5135d2))return Sn(_0x2f79e4,_0x30f48c,_0x5135d2,_0xb66e5['getNode']()['getChild'](_0x5135d2),_0x8d39a4,_0x302d17,_0xb63805,_0x424d3e);if(v(_0x5135d2)){let _0x4f1e0c=new b(null);return _0xb66e5['getNode']()['forEachChild'](ve,(_0x5566e2,_0x104c63)=>{_0x4f1e0c=_0x4f1e0c['set'](new C(_0x5566e2),_0x104c63);}),Pi(_0x2f79e4,_0x30f48c,_0x5135d2,_0x4f1e0c,_0x8d39a4,_0x302d17,_0xb63805,_0x424d3e);}else return _0x30f48c;}else{let _0x450b01=new b(null);return _0x3e6e9e['foreach']((_0x1539cc,_0x2cdf81)=>{const _0x4f6ffc=k(_0x5135d2,_0x1539cc);_0xb66e5['isCompleteForPath'](_0x4f6ffc)&&(_0x450b01=_0x450b01['set'](_0x1539cc,_0xb66e5['getNode']()['getChild'](_0x4f6ffc)));}),Pi(_0x2f79e4,_0x30f48c,_0x5135d2,_0x450b01,_0x8d39a4,_0x302d17,_0xb63805,_0x424d3e);}}function Nu(_0x521617,_0xa5f5ec,_0x13d440,_0x4bcdd0,_0x40cd2f){const _0x99dccc=_0xa5f5ec['serverCache'],_0x18b409=Fo(_0xa5f5ec,_0x99dccc['getNode'](),_0x99dccc['isFullyInitialized']()||v(_0x13d440),_0x99dccc['isFiltered']());return Go(_0x521617,_0x18b409,_0x13d440,_0x4bcdd0,$o,_0x40cd2f);}function Ou(_0x280437,_0xd66c1b,_0x263f5e,_0xd836c3,_0x3e1b92,_0x530fea){let _0x4399e5;if(Tn(_0xd836c3,_0x263f5e)!=null)return _0xd66c1b;{const _0x9872d8=new rs(_0xd836c3,_0xd66c1b,_0x3e1b92),_0x3c114c=_0xd66c1b['eventCache']['getNode']();let _0x4c19c9;if(v(_0x263f5e)||y(_0x263f5e)==='.priority'){let _0x15b7a7;if(_0xd66c1b['serverCache']['isFullyInitialized']())_0x15b7a7=Cn(_0xd836c3,Ve(_0xd66c1b));else{const _0x19bbf0=_0xd66c1b['serverCache']['getNode']();f(_0x19bbf0 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x15b7a7=is(_0xd836c3,_0x19bbf0);}_0x15b7a7=_0x15b7a7,_0x4c19c9=_0x280437['filter']['updateFullNode'](_0x3c114c,_0x15b7a7,_0x530fea);}else{const _0x18aec1=y(_0x263f5e);let _0x1c1ed6=ss(_0xd836c3,_0x18aec1,_0xd66c1b['serverCache']);_0x1c1ed6==null&&_0xd66c1b['serverCache']['isCompleteForChild'](_0x18aec1)&&(_0x1c1ed6=_0x3c114c['getImmediateChild'](_0x18aec1)),_0x1c1ed6!=null?_0x4c19c9=_0x280437['filter']['updateChild'](_0x3c114c,_0x18aec1,_0x1c1ed6,S(_0x263f5e),_0x9872d8,_0x530fea):_0xd66c1b['eventCache']['getNode']()['hasChild'](_0x18aec1)?_0x4c19c9=_0x280437['filter']['updateChild'](_0x3c114c,_0x18aec1,g['EMPTY_NODE'],S(_0x263f5e),_0x9872d8,_0x530fea):_0x4c19c9=_0x3c114c,_0x4c19c9['isEmpty']()&&_0xd66c1b['serverCache']['isFullyInitialized']()&&(_0x4399e5=Cn(_0xd836c3,Ve(_0xd66c1b)),_0x4399e5['isLeafNode']()&&(_0x4c19c9=_0x280437['filter']['updateFullNode'](_0x4c19c9,_0x4399e5,_0x530fea)));}return _0x4399e5=_0xd66c1b['serverCache']['isFullyInitialized']()||Tn(_0xd836c3,w())!=null,Rt(_0xd66c1b,_0x4c19c9,_0x4399e5,_0x280437['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1a92ce,_0x1e867b){this['query_']=_0x1a92ce,this['eventRegistrations_']=[];const _0x57eee6=this['query_']['_queryParams'],_0x52720d=new Xi(_0x57eee6['getIndex']()),_0x531f5c=Kh(_0x57eee6);this['processor_']=Su(_0x531f5c);const _0x347d47=_0x1e867b['serverCache'],_0x26e7b8=_0x1e867b['eventCache'],_0x31bdbb=_0x52720d['updateFullNode'](g['EMPTY_NODE'],_0x347d47['getNode'](),null),_0x559280=_0x531f5c['updateFullNode'](g['EMPTY_NODE'],_0x26e7b8['getNode'](),null),_0x5121fc=new Te(_0x31bdbb,_0x347d47['isFullyInitialized'](),_0x52720d['filtersNodes']()),_0x464497=new Te(_0x559280,_0x26e7b8['isFullyInitialized'](),_0x531f5c['filtersNodes']());this['viewCache_']=Un(_0x464497,_0x5121fc),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x458d7f){return _0x458d7f['viewCache_']['serverCache']['getNode']();}function Lu(_0x18f963){return wn(_0x18f963['viewCache_']);}function xu(_0x2845fd,_0x35df5a){const _0x1124b1=Ve(_0x2845fd['viewCache_']);return _0x1124b1&&(_0x2845fd['query']['_queryParams']['loadsAllData']()||!v(_0x35df5a)&&!_0x1124b1['getImmediateChild'](y(_0x35df5a))['isEmpty']())?_0x1124b1['getChild'](_0x35df5a):null;}function ur(_0x2f4273){return _0x2f4273['eventRegistrations_']['length']===0x0;}function Fu(_0x315942,_0x219daa){_0x315942['eventRegistrations_']['push'](_0x219daa);}function dr(_0x1d84e3,_0x63e3b9,_0x1b2aea){const _0x217c66=[];if(_0x1b2aea){f(_0x63e3b9==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x40a127=_0x1d84e3['query']['_path'];_0x1d84e3['eventRegistrations_']['forEach'](_0x516e6d=>{const _0xc4ac0d=_0x516e6d['createCancelEvent'](_0x1b2aea,_0x40a127);_0xc4ac0d&&_0x217c66['push'](_0xc4ac0d);});}if(_0x63e3b9){let _0xd7f4eb=[];for(let _0x216a37=0x0;_0x216a37<_0x1d84e3['eventRegistrations_']['length'];++_0x216a37){const _0x54530d=_0x1d84e3['eventRegistrations_'][_0x216a37];if(!_0x54530d['matches'](_0x63e3b9))_0xd7f4eb['push'](_0x54530d);else{if(_0x63e3b9['hasAnyCallback']()){_0xd7f4eb=_0xd7f4eb['concat'](_0x1d84e3['eventRegistrations_']['slice'](_0x216a37+0x1));break;}}}_0x1d84e3['eventRegistrations_']=_0xd7f4eb;}else _0x1d84e3['eventRegistrations_']=[];return _0x217c66;}function fr(_0x9dd8b4,_0x10e8c5,_0x460579,_0x3097fb){_0x10e8c5['type']===z['MERGE']&&_0x10e8c5['source']['queryId']!==null&&(f(Ve(_0x9dd8b4['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x9dd8b4['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3c7726=_0x9dd8b4['viewCache_'],_0x3cacd8=Ru(_0x9dd8b4['processor_'],_0x3c7726,_0x10e8c5,_0x460579,_0x3097fb);return bu(_0x9dd8b4['processor_'],_0x3cacd8['viewCache']),f(_0x3cacd8['viewCache']['serverCache']['isFullyInitialized']()||!_0x3c7726['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x9dd8b4['viewCache_']=_0x3cacd8['viewCache'],qo(_0x9dd8b4,_0x3cacd8['changes'],_0x3cacd8['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2de2b6,_0x497cee){const _0x1f96c2=_0x2de2b6['viewCache_']['eventCache'],_0x4be6a0=[];return _0x1f96c2['getNode']()['isLeafNode']()||_0x1f96c2['getNode']()['forEachChild'](R,(_0x5e5bbe,_0x226f68)=>{_0x4be6a0['push'](rt(_0x5e5bbe,_0x226f68));}),_0x1f96c2['isFullyInitialized']()&&_0x4be6a0['push'](Lo(_0x1f96c2['getNode']())),qo(_0x2de2b6,_0x4be6a0,_0x1f96c2['getNode'](),_0x497cee);}function qo(_0x3672c2,_0x433aad,_0x15be1f,_0x2fb443){const _0x2f2bac=_0x2fb443?[_0x2fb443]:_0x3672c2['eventRegistrations_'];return ru(_0x3672c2['eventGenerator_'],_0x433aad,_0x15be1f,_0x2f2bac);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x588537){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x588537;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x528190){return _0x528190['views']['size']===0x0;}function os(_0x1b28e4,_0x556fc1,_0x3cbf17,_0x590173){const _0x161f12=_0x556fc1['source']['queryId'];if(_0x161f12!==null){const _0x55e8c1=_0x1b28e4['views']['get'](_0x161f12);return f(_0x55e8c1!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x55e8c1,_0x556fc1,_0x3cbf17,_0x590173);}else{let _0x3e26e1=[];for(const _0x2f15c2 of _0x1b28e4['views']['values']())_0x3e26e1=_0x3e26e1['concat'](fr(_0x2f15c2,_0x556fc1,_0x3cbf17,_0x590173));return _0x3e26e1;}}function jo(_0x17e179,_0x503d39,_0x1347a6,_0x4577bf,_0x59fb3a){const _0x16537c=_0x503d39['_queryIdentifier'],_0x2cfdd2=_0x17e179['views']['get'](_0x16537c);if(!_0x2cfdd2){let _0x1e08a5=Cn(_0x1347a6,_0x59fb3a?_0x4577bf:null),_0x24a43b=!0x1;_0x1e08a5?_0x24a43b=!0x0:_0x4577bf instanceof g?(_0x1e08a5=is(_0x1347a6,_0x4577bf),_0x24a43b=!0x1):(_0x1e08a5=g['EMPTY_NODE'],_0x24a43b=!0x1);const _0x3c7a20=Un(new Te(_0x1e08a5,_0x24a43b,!0x1),new Te(_0x4577bf,_0x59fb3a,!0x1));return new Du(_0x503d39,_0x3c7a20);}return _0x2cfdd2;}function Hu(_0x37d466,_0x16e866,_0x59c217,_0x4a0b97,_0x3bca67,_0x77b6e){const _0xeef010=jo(_0x37d466,_0x16e866,_0x4a0b97,_0x3bca67,_0x77b6e);return _0x37d466['views']['has'](_0x16e866['_queryIdentifier'])||_0x37d466['views']['set'](_0x16e866['_queryIdentifier'],_0xeef010),Fu(_0xeef010,_0x59c217),Uu(_0xeef010,_0x59c217);}function $u(_0x20b190,_0x5cf920,_0x8b3b7f,_0x17db5d){const _0x4dfd1a=_0x5cf920['_queryIdentifier'],_0x5e34f5=[];let _0x22cca1=[];const _0x26aa7d=Se(_0x20b190);if(_0x4dfd1a==='default'){for(const [_0x5a83a0,_0x2843d2]of _0x20b190['views']['entries']())_0x22cca1=_0x22cca1['concat'](dr(_0x2843d2,_0x8b3b7f,_0x17db5d)),ur(_0x2843d2)&&(_0x20b190['views']['delete'](_0x5a83a0),_0x2843d2['query']['_queryParams']['loadsAllData']()||_0x5e34f5['push'](_0x2843d2['query']));}else{const _0x4aac1a=_0x20b190['views']['get'](_0x4dfd1a);_0x4aac1a&&(_0x22cca1=_0x22cca1['concat'](dr(_0x4aac1a,_0x8b3b7f,_0x17db5d)),ur(_0x4aac1a)&&(_0x20b190['views']['delete'](_0x4dfd1a),_0x4aac1a['query']['_queryParams']['loadsAllData']()||_0x5e34f5['push'](_0x4aac1a['query'])));}return _0x26aa7d&&!Se(_0x20b190)&&_0x5e34f5['push'](new(Bu())(_0x5cf920['_repo'],_0x5cf920['_path'])),{'removed':_0x5e34f5,'events':_0x22cca1};}function Ko(_0x3cd177){const _0x34252c=[];for(const _0x3082fa of _0x3cd177['views']['values']())_0x3082fa['query']['_queryParams']['loadsAllData']()||_0x34252c['push'](_0x3082fa);return _0x34252c;}function Ie(_0x26ee15,_0x16cf17){let _0x4d1be9=null;for(const _0x179289 of _0x26ee15['views']['values']())_0x4d1be9=_0x4d1be9||xu(_0x179289,_0x16cf17);return _0x4d1be9;}function Yo(_0x1f0ab2,_0x41ae8e){if(_0x41ae8e['_queryParams']['loadsAllData']())return Bn(_0x1f0ab2);{const _0x4658ce=_0x41ae8e['_queryIdentifier'];return _0x1f0ab2['views']['get'](_0x4658ce);}}function Qo(_0x1cd923,_0x25073a){return Yo(_0x1cd923,_0x25073a)!=null;}function Se(_0x27292){return Bn(_0x27292)!=null;}function Bn(_0x5bf829){for(const _0x4f3faf of _0x5bf829['views']['values']())if(_0x4f3faf['query']['_queryParams']['loadsAllData']())return _0x4f3faf;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x248436){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x248436;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2888fe){this['listenProvider_']=_0x2888fe,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x2ce63a,_0x22e9a7,_0x5a73c1,_0x4448a6,_0x50218d){return lu(_0x2ce63a['pendingWriteTree_'],_0x22e9a7,_0x5a73c1,_0x4448a6,_0x50218d),_0x50218d?_t(_0x2ce63a,new Be(es(),_0x22e9a7,_0x5a73c1)):[];}function ju(_0x585a73,_0x25ef16,_0x47f605,_0x175c53){hu(_0x585a73['pendingWriteTree_'],_0x25ef16,_0x47f605,_0x175c53);const _0x5e5a39=b['fromObject'](_0x47f605);return _t(_0x585a73,new ot(es(),_0x25ef16,_0x5e5a39));}function _e(_0x2dd570,_0x22a056,_0x2bba30=!0x1){const _0x48b2b2=uu(_0x2dd570['pendingWriteTree_'],_0x22a056);if(du(_0x2dd570['pendingWriteTree_'],_0x22a056)){let _0x4af1ea=new b(null);return _0x48b2b2['snap']!=null?_0x4af1ea=_0x4af1ea['set'](w(),!0x0):x(_0x48b2b2['children'],_0x288c15=>{_0x4af1ea=_0x4af1ea['set'](new C(_0x288c15),!0x0);}),_t(_0x2dd570,new In(_0x48b2b2['path'],_0x4af1ea,_0x2bba30));}else return[];}function Yt(_0x18665e,_0x5b33fe,_0x135b9b){return _t(_0x18665e,new Be(ts(),_0x5b33fe,_0x135b9b));}function Ku(_0x39c920,_0xac934b,_0x1f28ce){const _0x5a4f66=b['fromObject'](_0x1f28ce);return _t(_0x39c920,new ot(ts(),_0xac934b,_0x5a4f66));}function Yu(_0x2d3b4f,_0x276ca9){return _t(_0x2d3b4f,new Ut(ts(),_0x276ca9));}function Qu(_0x36fcd5,_0x3865e9,_0x5ab96c){const _0x4ac189=cs(_0x36fcd5,_0x5ab96c);if(_0x4ac189){const _0x329996=ls(_0x4ac189),_0x28aca0=_0x329996['path'],_0x45ef79=_0x329996['queryId'],_0x379ff1=F(_0x28aca0,_0x3865e9),_0x42e628=new Ut(ns(_0x45ef79),_0x379ff1);return hs(_0x36fcd5,_0x28aca0,_0x42e628);}else return[];}function An(_0x29ac23,_0xdf9f57,_0xee51df,_0x2b68dd,_0x362a3f=!0x1){const _0x106d78=_0xdf9f57['_path'],_0x4836c3=_0x29ac23['syncPointTree_']['get'](_0x106d78);let _0x59ec53=[];if(_0x4836c3&&(_0xdf9f57['_queryIdentifier']==='default'||Qo(_0x4836c3,_0xdf9f57))){const _0xed7300=$u(_0x4836c3,_0xdf9f57,_0xee51df,_0x2b68dd);Vu(_0x4836c3)&&(_0x29ac23['syncPointTree_']=_0x29ac23['syncPointTree_']['remove'](_0x106d78));const _0x31d9a8=_0xed7300['removed'];if(_0x59ec53=_0xed7300['events'],!_0x362a3f){const _0x115224=_0x31d9a8['findIndex'](_0x25ea33=>_0x25ea33['_queryParams']['loadsAllData']())!==-0x1,_0x2eafdb=_0x29ac23['syncPointTree_']['findOnPath'](_0x106d78,(_0x3be862,_0x2dfb33)=>Se(_0x2dfb33));if(_0x115224&&!_0x2eafdb){const _0x85d673=_0x29ac23['syncPointTree_']['subtree'](_0x106d78);if(!_0x85d673['isEmpty']()){const _0x3aa0c1=Zu(_0x85d673);for(let _0x1b4623=0x0;_0x1b4623<_0x3aa0c1['length'];++_0x1b4623){const _0x19bc2e=_0x3aa0c1[_0x1b4623],_0x4f5169=_0x19bc2e['query'],_0x49dbd4=ea(_0x29ac23,_0x19bc2e);_0x29ac23['listenProvider_']['startListening'](kt(_0x4f5169),Wt(_0x29ac23,_0x4f5169),_0x49dbd4['hashFn'],_0x49dbd4['onComplete']);}}}!_0x2eafdb&&_0x31d9a8['length']>0x0&&!_0x2b68dd&&(_0x115224?_0x29ac23['listenProvider_']['stopListening'](kt(_0xdf9f57),null):_0x31d9a8['forEach'](_0x439fad=>{const _0xe548ec=_0x29ac23['queryToTagMap']['get'](Hn(_0x439fad));_0x29ac23['listenProvider_']['stopListening'](kt(_0x439fad),_0xe548ec);}));}ed(_0x29ac23,_0x31d9a8);}return _0x59ec53;}function Jo(_0x1a6d01,_0x39f6cf,_0x470759,_0x35b5dc){const _0x275d95=cs(_0x1a6d01,_0x35b5dc);if(_0x275d95!=null){const _0x173105=ls(_0x275d95),_0x161634=_0x173105['path'],_0x4876b9=_0x173105['queryId'],_0x7d2dd3=F(_0x161634,_0x39f6cf),_0x35745d=new Be(ns(_0x4876b9),_0x7d2dd3,_0x470759);return hs(_0x1a6d01,_0x161634,_0x35745d);}else return[];}function Ju(_0x33e835,_0x380ca1,_0x4a03af,_0x56aeb4){const _0x2d6140=cs(_0x33e835,_0x56aeb4);if(_0x2d6140){const _0x200ede=ls(_0x2d6140),_0x11ef80=_0x200ede['path'],_0x2593ef=_0x200ede['queryId'],_0x1097fb=F(_0x11ef80,_0x380ca1),_0x18e0cb=b['fromObject'](_0x4a03af),_0x419ce2=new ot(ns(_0x2593ef),_0x1097fb,_0x18e0cb);return hs(_0x33e835,_0x11ef80,_0x419ce2);}else return[];}function Ni(_0x21045d,_0xef4c9d,_0x3d2afc,_0x16df88=!0x1){const _0x5efbd8=_0xef4c9d['_path'];let _0x4a0673=null,_0x30bcd7=!0x1;_0x21045d['syncPointTree_']['foreachOnPath'](_0x5efbd8,(_0x1939ef,_0x42ab70)=>{const _0xbe41c7=F(_0x1939ef,_0x5efbd8);_0x4a0673=_0x4a0673||Ie(_0x42ab70,_0xbe41c7),_0x30bcd7=_0x30bcd7||Se(_0x42ab70);});let _0x50159b=_0x21045d['syncPointTree_']['get'](_0x5efbd8);_0x50159b?(_0x30bcd7=_0x30bcd7||Se(_0x50159b),_0x4a0673=_0x4a0673||Ie(_0x50159b,w())):(_0x50159b=new zo(),_0x21045d['syncPointTree_']=_0x21045d['syncPointTree_']['set'](_0x5efbd8,_0x50159b));let _0x1dcb04;_0x4a0673!=null?_0x1dcb04=!0x0:(_0x1dcb04=!0x1,_0x4a0673=g['EMPTY_NODE'],_0x21045d['syncPointTree_']['subtree'](_0x5efbd8)['foreachChild']((_0x249be4,_0xd2a157)=>{const _0xa27f6e=Ie(_0xd2a157,w());_0xa27f6e&&(_0x4a0673=_0x4a0673['updateImmediateChild'](_0x249be4,_0xa27f6e));}));const _0x377f20=Qo(_0x50159b,_0xef4c9d);if(!_0x377f20&&!_0xef4c9d['_queryParams']['loadsAllData']()){const _0x977137=Hn(_0xef4c9d);f(!_0x21045d['queryToTagMap']['has'](_0x977137),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x49977d=td();_0x21045d['queryToTagMap']['set'](_0x977137,_0x49977d),_0x21045d['tagToQueryMap']['set'](_0x49977d,_0x977137);}const _0x5a2cb3=Wn(_0x21045d['pendingWriteTree_'],_0x5efbd8);let _0x5616e1=Hu(_0x50159b,_0xef4c9d,_0x3d2afc,_0x5a2cb3,_0x4a0673,_0x1dcb04);if(!_0x377f20&&!_0x30bcd7&&!_0x16df88){const _0x10041a=Yo(_0x50159b,_0xef4c9d);_0x5616e1=_0x5616e1['concat'](nd(_0x21045d,_0xef4c9d,_0x10041a));}return _0x5616e1;}function Vn(_0x38c807,_0x975242,_0x285cd8){const _0x3e0d92=_0x38c807['pendingWriteTree_'],_0x5b775f=_0x38c807['syncPointTree_']['findOnPath'](_0x975242,(_0x2d422a,_0x1ef023)=>{const _0x1b8789=F(_0x2d422a,_0x975242),_0x426baf=Ie(_0x1ef023,_0x1b8789);if(_0x426baf)return _0x426baf;});return Bo(_0x3e0d92,_0x975242,_0x5b775f,_0x285cd8,!0x0);}function Xu(_0x28fba7,_0x862d05){const _0x38eee8=_0x862d05['_path'];let _0x25babb=null;_0x28fba7['syncPointTree_']['foreachOnPath'](_0x38eee8,(_0x115359,_0x49b36c)=>{const _0x5be27f=F(_0x115359,_0x38eee8);_0x25babb=_0x25babb||Ie(_0x49b36c,_0x5be27f);});let _0x4b6f23=_0x28fba7['syncPointTree_']['get'](_0x38eee8);_0x4b6f23?_0x25babb=_0x25babb||Ie(_0x4b6f23,w()):(_0x4b6f23=new zo(),_0x28fba7['syncPointTree_']=_0x28fba7['syncPointTree_']['set'](_0x38eee8,_0x4b6f23));const _0x3f51a5=_0x25babb!=null,_0x4d1a48=_0x3f51a5?new Te(_0x25babb,!0x0,!0x1):null,_0x1fb506=Wn(_0x28fba7['pendingWriteTree_'],_0x862d05['_path']),_0x246a66=jo(_0x4b6f23,_0x862d05,_0x1fb506,_0x3f51a5?_0x4d1a48['getNode']():g['EMPTY_NODE'],_0x3f51a5);return Lu(_0x246a66);}function _t(_0x3913db,_0x4a399f){return Xo(_0x4a399f,_0x3913db['syncPointTree_'],null,Wn(_0x3913db['pendingWriteTree_'],w()));}function Xo(_0x458e9c,_0x504f36,_0x15495e,_0x1751f9){if(v(_0x458e9c['path']))return Zo(_0x458e9c,_0x504f36,_0x15495e,_0x1751f9);{const _0x56313d=_0x504f36['get'](w());_0x15495e==null&&_0x56313d!=null&&(_0x15495e=Ie(_0x56313d,w()));let _0x5f0d8b=[];const _0x1b1a52=y(_0x458e9c['path']),_0x1bc4e4=_0x458e9c['operationForChild'](_0x1b1a52),_0x2f660e=_0x504f36['children']['get'](_0x1b1a52);if(_0x2f660e&&_0x1bc4e4){const _0x48f5f9=_0x15495e?_0x15495e['getImmediateChild'](_0x1b1a52):null,_0xe4b4e7=Vo(_0x1751f9,_0x1b1a52);_0x5f0d8b=_0x5f0d8b['concat'](Xo(_0x1bc4e4,_0x2f660e,_0x48f5f9,_0xe4b4e7));}return _0x56313d&&(_0x5f0d8b=_0x5f0d8b['concat'](os(_0x56313d,_0x458e9c,_0x1751f9,_0x15495e))),_0x5f0d8b;}}function Zo(_0x428b07,_0x17eb7a,_0xacef08,_0x97fe59){const _0x2b1da3=_0x17eb7a['get'](w());_0xacef08==null&&_0x2b1da3!=null&&(_0xacef08=Ie(_0x2b1da3,w()));let _0x2db583=[];return _0x17eb7a['children']['inorderTraversal']((_0x5dbb05,_0x46d220)=>{const _0x5dfc68=_0xacef08?_0xacef08['getImmediateChild'](_0x5dbb05):null,_0x134443=Vo(_0x97fe59,_0x5dbb05),_0x43f4af=_0x428b07['operationForChild'](_0x5dbb05);_0x43f4af&&(_0x2db583=_0x2db583['concat'](Zo(_0x43f4af,_0x46d220,_0x5dfc68,_0x134443)));}),_0x2b1da3&&(_0x2db583=_0x2db583['concat'](os(_0x2b1da3,_0x428b07,_0x97fe59,_0xacef08))),_0x2db583;}function ea(_0x44d087,_0x3479dc){const _0x3433f0=_0x3479dc['query'],_0x53f83d=Wt(_0x44d087,_0x3433f0);return{'hashFn':()=>(Mu(_0x3479dc)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x196183=>{if(_0x196183==='ok')return _0x53f83d?Qu(_0x44d087,_0x3433f0['_path'],_0x53f83d):Yu(_0x44d087,_0x3433f0['_path']);{const _0x3c1fb2=Kl(_0x196183,_0x3433f0);return An(_0x44d087,_0x3433f0,null,_0x3c1fb2);}}};}function Wt(_0x4ea725,_0x10b5e6){const _0x5b28f5=Hn(_0x10b5e6);return _0x4ea725['queryToTagMap']['get'](_0x5b28f5);}function Hn(_0x42636a){return _0x42636a['_path']['toString']()+'$'+_0x42636a['_queryIdentifier'];}function cs(_0x126fc2,_0x160433){return _0x126fc2['tagToQueryMap']['get'](_0x160433);}function ls(_0xc0abd3){const _0x2365b8=_0xc0abd3['indexOf']('$');return f(_0x2365b8!==-0x1&&_0x2365b8<_0xc0abd3['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xc0abd3['substr'](_0x2365b8+0x1),'path':new C(_0xc0abd3['substr'](0x0,_0x2365b8))};}function hs(_0x5e503e,_0x356502,_0x49c060){const _0x3fd08c=_0x5e503e['syncPointTree_']['get'](_0x356502);f(_0x3fd08c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3b5c88=Wn(_0x5e503e['pendingWriteTree_'],_0x356502);return os(_0x3fd08c,_0x49c060,_0x3b5c88,null);}function Zu(_0x3a225d){return _0x3a225d['fold']((_0x1f5825,_0x3b8b43,_0x22292d)=>{if(_0x3b8b43&&Se(_0x3b8b43))return[Bn(_0x3b8b43)];{let _0x27421c=[];return _0x3b8b43&&(_0x27421c=Ko(_0x3b8b43)),x(_0x22292d,(_0x53bf9d,_0x5a57f8)=>{_0x27421c=_0x27421c['concat'](_0x5a57f8);}),_0x27421c;}});}function kt(_0x4a9ac5){return _0x4a9ac5['_queryParams']['loadsAllData']()&&!_0x4a9ac5['_queryParams']['isDefault']()?new(qu())(_0x4a9ac5['_repo'],_0x4a9ac5['_path']):_0x4a9ac5;}function ed(_0x461bfd,_0x4955fa){for(let _0x58ddb7=0x0;_0x58ddb7<_0x4955fa['length'];++_0x58ddb7){const _0x251fdb=_0x4955fa[_0x58ddb7];if(!_0x251fdb['_queryParams']['loadsAllData']()){const _0x2991d7=Hn(_0x251fdb),_0x52c41d=_0x461bfd['queryToTagMap']['get'](_0x2991d7);_0x461bfd['queryToTagMap']['delete'](_0x2991d7),_0x461bfd['tagToQueryMap']['delete'](_0x52c41d);}}}function td(){return zu++;}function nd(_0x1388dc,_0x4bfdef,_0x14b267){const _0xa044b6=_0x4bfdef['_path'],_0x4f9a47=Wt(_0x1388dc,_0x4bfdef),_0x191ef7=ea(_0x1388dc,_0x14b267),_0x7e6408=_0x1388dc['listenProvider_']['startListening'](kt(_0x4bfdef),_0x4f9a47,_0x191ef7['hashFn'],_0x191ef7['onComplete']),_0xefcf2f=_0x1388dc['syncPointTree_']['subtree'](_0xa044b6);if(_0x4f9a47)f(!Se(_0xefcf2f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x26a611=_0xefcf2f['fold']((_0x2bf1d8,_0x3bc966,_0x300c0b)=>{if(!v(_0x2bf1d8)&&_0x3bc966&&Se(_0x3bc966))return[Bn(_0x3bc966)['query']];{let _0x4783cb=[];return _0x3bc966&&(_0x4783cb=_0x4783cb['concat'](Ko(_0x3bc966)['map'](_0x45f1f8=>_0x45f1f8['query']))),x(_0x300c0b,(_0x57fca7,_0x6ca704)=>{_0x4783cb=_0x4783cb['concat'](_0x6ca704);}),_0x4783cb;}});for(let _0x33b228=0x0;_0x33b228<_0x26a611['length'];++_0x33b228){const _0x25fbce=_0x26a611[_0x33b228];_0x1388dc['listenProvider_']['stopListening'](kt(_0x25fbce),Wt(_0x1388dc,_0x25fbce));}}return _0x7e6408;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x411552){this['node_']=_0x411552;}['getImmediateChild'](_0x496c15){const _0x98ef50=this['node_']['getImmediateChild'](_0x496c15);return new us(_0x98ef50);}['node'](){return this['node_'];}}class ds{constructor(_0x32d6c5,_0x6fecc4){this['syncTree_']=_0x32d6c5,this['path_']=_0x6fecc4;}['getImmediateChild'](_0x3d80bd){const _0x20674c=k(this['path_'],_0x3d80bd);return new ds(this['syncTree_'],_0x20674c);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x2ab78a){return _0x2ab78a=_0x2ab78a||{},_0x2ab78a['timestamp']=_0x2ab78a['timestamp']||new Date()['getTime'](),_0x2ab78a;},_r=function(_0x14839d,_0x352279,_0x2d7319){if(!_0x14839d||typeof _0x14839d!='object')return _0x14839d;if(f('.sv'in _0x14839d,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x14839d['.sv']=='string')return sd(_0x14839d['.sv'],_0x352279,_0x2d7319);if(typeof _0x14839d['.sv']=='object')return rd(_0x14839d['.sv'],_0x352279);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x14839d,null,0x2));},sd=function(_0x317aaf,_0x1b76d2,_0x2d93af){switch(_0x317aaf){case'timestamp':return _0x2d93af['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x317aaf);}},rd=function(_0x484883,_0x3836a8,_0x182665){_0x484883['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x484883,null,0x2));const _0x19e5d8=_0x484883['increment'];typeof _0x19e5d8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x19e5d8);const _0x54cfc5=_0x3836a8['node']();if(f(_0x54cfc5!==null&&typeof _0x54cfc5<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x54cfc5['isLeafNode']())return _0x19e5d8;const _0x1e4930=_0x54cfc5['getValue']();return typeof _0x1e4930!='number'?_0x19e5d8:_0x1e4930+_0x19e5d8;},ta=function(_0x5c3729,_0x330afa,_0x339516,_0x48a69a){return ps(_0x330afa,new ds(_0x339516,_0x5c3729),_0x48a69a);},fs=function(_0x4e2d0d,_0x4bc4a,_0x17171e){return ps(_0x4e2d0d,new us(_0x4bc4a),_0x17171e);};function ps(_0x3e6273,_0x3967e7,_0x14173a){const _0x47bbde=_0x3e6273['getPriority']()['val'](),_0x1e2bb3=_r(_0x47bbde,_0x3967e7['getImmediateChild']('.priority'),_0x14173a);let _0x22d1da;if(_0x3e6273['isLeafNode']()){const _0x50bdcd=_0x3e6273,_0x256243=_r(_0x50bdcd['getValue'](),_0x3967e7,_0x14173a);return _0x256243!==_0x50bdcd['getValue']()||_0x1e2bb3!==_0x50bdcd['getPriority']()['val']()?new D(_0x256243,A(_0x1e2bb3)):_0x3e6273;}else{const _0x974ac7=_0x3e6273;return _0x22d1da=_0x974ac7,_0x1e2bb3!==_0x974ac7['getPriority']()['val']()&&(_0x22d1da=_0x22d1da['updatePriority'](new D(_0x1e2bb3))),_0x974ac7['forEachChild'](R,(_0x41e1e3,_0x3ff420)=>{const _0x1751fe=ps(_0x3ff420,_0x3967e7['getImmediateChild'](_0x41e1e3),_0x14173a);_0x1751fe!==_0x3ff420&&(_0x22d1da=_0x22d1da['updateImmediateChild'](_0x41e1e3,_0x1751fe));}),_0x22d1da;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x5b76eb='',_0x34e9c8=null,_0x34b2e6={'children':{},'childCount':0x0}){this['name']=_0x5b76eb,this['parent']=_0x34e9c8,this['node']=_0x34b2e6;}}function $n(_0x1211a1,_0x4e7645){let _0x36bc25=_0x4e7645 instanceof C?_0x4e7645:new C(_0x4e7645),_0xa20517=_0x1211a1,_0x157c38=y(_0x36bc25);for(;_0x157c38!==null;){const _0x517473=Le(_0xa20517['node']['children'],_0x157c38)||{'children':{},'childCount':0x0};_0xa20517=new _s(_0x157c38,_0xa20517,_0x517473),_0x36bc25=S(_0x36bc25),_0x157c38=y(_0x36bc25);}return _0xa20517;}function je(_0x572b59){return _0x572b59['node']['value'];}function gs(_0x29674a,_0x9598e3){_0x29674a['node']['value']=_0x9598e3,Oi(_0x29674a);}function na(_0x524f93){return _0x524f93['node']['childCount']>0x0;}function od(_0xb2c4bf){return je(_0xb2c4bf)===void 0x0&&!na(_0xb2c4bf);}function Gn(_0x6f7118,_0x4dc27d){x(_0x6f7118['node']['children'],(_0x5ccb39,_0x1ab895)=>{_0x4dc27d(new _s(_0x5ccb39,_0x6f7118,_0x1ab895));});}function ia(_0x5e869c,_0x3b5ede,_0x5c6bea,_0x267f46){_0x5c6bea&&_0x3b5ede(_0x5e869c),Gn(_0x5e869c,_0x568de8=>{ia(_0x568de8,_0x3b5ede,!0x0);});}function ad(_0x1b304b,_0x430359,_0x16d3eb){let _0x3161b1=_0x1b304b['parent'];for(;_0x3161b1!==null;){if(_0x430359(_0x3161b1))return!0x0;_0x3161b1=_0x3161b1['parent'];}return!0x1;}function Qt(_0x490f17){return new C(_0x490f17['parent']===null?_0x490f17['name']:Qt(_0x490f17['parent'])+'/'+_0x490f17['name']);}function Oi(_0x306b80){_0x306b80['parent']!==null&&cd(_0x306b80['parent'],_0x306b80['name'],_0x306b80);}function cd(_0x467874,_0x54bacf,_0x453821){const _0x8aed5f=od(_0x453821),_0x227de4=Q(_0x467874['node']['children'],_0x54bacf);_0x8aed5f&&_0x227de4?(delete _0x467874['node']['children'][_0x54bacf],_0x467874['node']['childCount']--,Oi(_0x467874)):!_0x8aed5f&&!_0x227de4&&(_0x467874['node']['children'][_0x54bacf]=_0x453821['node'],_0x467874['node']['childCount']++,Oi(_0x467874));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3b8c9c){return typeof _0x3b8c9c=='string'&&_0x3b8c9c['length']!==0x0&&!ld['test'](_0x3b8c9c);},sa=function(_0x6f1797){return typeof _0x6f1797=='string'&&_0x6f1797['length']!==0x0&&!hd['test'](_0x6f1797);},ud=function(_0x5a941e){return _0x5a941e&&(_0x5a941e=_0x5a941e['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x5a941e);},Bt=function(_0x591c10){return _0x591c10===null||typeof _0x591c10=='string'||typeof _0x591c10=='number'&&!xn(_0x591c10)||_0x591c10&&typeof _0x591c10=='object'&&Q(_0x591c10,'.sv');},He=function(_0x4bc8b9,_0x35a785,_0x3b3cc1,_0x53d243){_0x53d243&&_0x35a785===void 0x0||Jt(it(_0x4bc8b9,'value'),_0x35a785,_0x3b3cc1);},Jt=function(_0x5b6376,_0x4d33d9,_0x941455){const _0x583601=_0x941455 instanceof C?new Ah(_0x941455,_0x5b6376):_0x941455;if(_0x4d33d9===void 0x0)throw new Error(_0x5b6376+'contains\x20undefined\x20'+Oe(_0x583601));if(typeof _0x4d33d9=='function')throw new Error(_0x5b6376+'contains\x20a\x20function\x20'+Oe(_0x583601)+'\x20with\x20contents\x20=\x20'+_0x4d33d9['toString']());if(xn(_0x4d33d9))throw new Error(_0x5b6376+'contains\x20'+_0x4d33d9['toString']()+'\x20'+Oe(_0x583601));if(typeof _0x4d33d9=='string'&&_0x4d33d9['length']>ui/0x3&&Ln(_0x4d33d9)>ui)throw new Error(_0x5b6376+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x583601)+'\x20(\x27'+_0x4d33d9['substring'](0x0,0x32)+'...\x27)');if(_0x4d33d9&&typeof _0x4d33d9=='object'){let _0x26ecae=!0x1,_0x52bb03=!0x1;if(x(_0x4d33d9,(_0x4ffe0d,_0xe67dc6)=>{if(_0x4ffe0d==='.value')_0x26ecae=!0x0;else{if(_0x4ffe0d!=='.priority'&&_0x4ffe0d!=='.sv'&&(_0x52bb03=!0x0,!ms(_0x4ffe0d)))throw new Error(_0x5b6376+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4ffe0d+')\x20'+Oe(_0x583601)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x583601,_0x4ffe0d),Jt(_0x5b6376,_0xe67dc6,_0x583601),Ph(_0x583601);}),_0x26ecae&&_0x52bb03)throw new Error(_0x5b6376+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x583601)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x147b1a,_0x15106d){let _0xee736,_0x585f90;for(_0xee736=0x0;_0xee736<_0x15106d['length'];_0xee736++){_0x585f90=_0x15106d[_0xee736];const _0x26576e=Mt(_0x585f90);for(let _0x15154e=0x0;_0x15154e<_0x26576e['length'];_0x15154e++)if(!(_0x26576e[_0x15154e]==='.priority'&&_0x15154e===_0x26576e['length']-0x1)){if(!ms(_0x26576e[_0x15154e]))throw new Error(_0x147b1a+'contains\x20an\x20invalid\x20key\x20('+_0x26576e[_0x15154e]+')\x20in\x20path\x20'+_0x585f90['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x15106d['sort'](Rh);let _0x8bb7e2=null;for(_0xee736=0x0;_0xee736<_0x15106d['length'];_0xee736++){if(_0x585f90=_0x15106d[_0xee736],_0x8bb7e2!==null&&G(_0x8bb7e2,_0x585f90))throw new Error(_0x147b1a+'contains\x20a\x20path\x20'+_0x8bb7e2['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x585f90['toString']());_0x8bb7e2=_0x585f90;}},ra=function(_0x3cb8e0,_0x54ff99,_0x1e9210,_0x2b5627){const _0xef8a66=it(_0x3cb8e0,'values');if(!(_0x54ff99&&typeof _0x54ff99=='object')||Array['isArray'](_0x54ff99))throw new Error(_0xef8a66+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4eceba=[];x(_0x54ff99,(_0x2b6371,_0x11d1de)=>{const _0x1ad2ee=new C(_0x2b6371);if(Jt(_0xef8a66,_0x11d1de,k(_0x1e9210,_0x1ad2ee)),ji(_0x1ad2ee)==='.priority'&&!Bt(_0x11d1de))throw new Error(_0xef8a66+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1ad2ee['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4eceba['push'](_0x1ad2ee);}),dd(_0xef8a66,_0x4eceba);},fd=function(_0x1ecf00,_0x3ceae2,_0x2a81ac){if(xn(_0x3ceae2))throw new Error(it(_0x1ecf00,'priority')+'is\x20'+_0x3ceae2['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3ceae2))throw new Error(it(_0x1ecf00,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xfef9ad,_0x45a54e,_0x23c246,_0x3ba1f3){if(!sa(_0x23c246))throw new Error(it(_0xfef9ad,_0x45a54e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x23c246+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x53a0ee,_0x357203,_0x2d7b81,_0x27c425){_0x2d7b81&&(_0x2d7b81=_0x2d7b81['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x53a0ee,_0x357203,_0x2d7b81);},Me=function(_0x35179e,_0x548ddc){if(y(_0x548ddc)==='.info')throw new Error(_0x35179e+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x164a99,_0x4b992c){const _0x30f335=_0x4b992c['path']['toString']();if(typeof _0x4b992c['repoInfo']['host']!='string'||_0x4b992c['repoInfo']['host']['length']===0x0||!ms(_0x4b992c['repoInfo']['namespace'])&&_0x4b992c['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x30f335['length']!==0x0&&!ud(_0x30f335))throw new Error(it(_0x164a99,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x23cb00,_0x3954ba){let _0x2af31c=null;for(let _0x416559=0x0;_0x416559<_0x3954ba['length'];_0x416559++){const _0x2d5806=_0x3954ba[_0x416559],_0x3c74ab=_0x2d5806['getPath']();_0x2af31c!==null&&!Ki(_0x3c74ab,_0x2af31c['path'])&&(_0x23cb00['eventLists_']['push'](_0x2af31c),_0x2af31c=null),_0x2af31c===null&&(_0x2af31c={'events':[],'path':_0x3c74ab}),_0x2af31c['events']['push'](_0x2d5806);}_0x2af31c&&_0x23cb00['eventLists_']['push'](_0x2af31c);}function oa(_0x461681,_0x5130ea,_0x5cc6c5){qn(_0x461681,_0x5cc6c5),aa(_0x461681,_0x3238b7=>Ki(_0x3238b7,_0x5130ea));}function V(_0x335862,_0x24b49e,_0x41a899){qn(_0x335862,_0x41a899),aa(_0x335862,_0x331c59=>G(_0x331c59,_0x24b49e)||G(_0x24b49e,_0x331c59));}function aa(_0x4819c3,_0x490c41){_0x4819c3['recursionDepth_']++;let _0x699c11=!0x0;for(let _0x29a39c=0x0;_0x29a39c<_0x4819c3['eventLists_']['length'];_0x29a39c++){const _0x5ebbb9=_0x4819c3['eventLists_'][_0x29a39c];if(_0x5ebbb9){const _0x3a9184=_0x5ebbb9['path'];_0x490c41(_0x3a9184)?(md(_0x4819c3['eventLists_'][_0x29a39c]),_0x4819c3['eventLists_'][_0x29a39c]=null):_0x699c11=!0x1;}}_0x699c11&&(_0x4819c3['eventLists_']=[]),_0x4819c3['recursionDepth_']--;}function md(_0x2dcff8){for(let _0xaa65d7=0x0;_0xaa65d7<_0x2dcff8['events']['length'];_0xaa65d7++){const _0x5a5a65=_0x2dcff8['events'][_0xaa65d7];if(_0x5a5a65!==null){_0x2dcff8['events'][_0xaa65d7]=null;const _0x621b06=_0x5a5a65['getEventRunner']();St&&L('event:\x20'+_0x5a5a65['toString']()),ft(_0x621b06);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x5abd87,_0x2a0924,_0x310bb1,_0x45d58d){this['repoInfo_']=_0x5abd87,this['forceRestClient_']=_0x2a0924,this['authTokenProvider_']=_0x310bb1,this['appCheckProvider_']=_0x45d58d,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x3c8d72,_0x395280,_0x582216){if(_0x3c8d72['stats_']=qi(_0x3c8d72['repoInfo_']),_0x3c8d72['forceRestClient_']||Xl())_0x3c8d72['server_']=new vn(_0x3c8d72['repoInfo_'],(_0x19ce61,_0x4fb8e3,_0x2f3904,_0x1c5a04)=>{gr(_0x3c8d72,_0x19ce61,_0x4fb8e3,_0x2f3904,_0x1c5a04);},_0x3c8d72['authTokenProvider_'],_0x3c8d72['appCheckProvider_']),setTimeout(()=>mr(_0x3c8d72,!0x0),0x0);else{if(typeof _0x582216<'u'&&_0x582216!==null){if(typeof _0x582216!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x582216);}catch(_0x39175f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x39175f);}}_0x3c8d72['persistentConnection_']=new se(_0x3c8d72['repoInfo_'],_0x395280,(_0x43c18c,_0x56f840,_0x3bf4fa,_0x53a76b)=>{gr(_0x3c8d72,_0x43c18c,_0x56f840,_0x3bf4fa,_0x53a76b);},_0x511e3f=>{mr(_0x3c8d72,_0x511e3f);},_0x1f0be4=>{Id(_0x3c8d72,_0x1f0be4);},_0x3c8d72['authTokenProvider_'],_0x3c8d72['appCheckProvider_'],_0x582216),_0x3c8d72['server_']=_0x3c8d72['persistentConnection_'];}_0x3c8d72['authTokenProvider_']['addTokenChangeListener'](_0x50e16c=>{_0x3c8d72['server_']['refreshAuthToken'](_0x50e16c);}),_0x3c8d72['appCheckProvider_']['addTokenChangeListener'](_0x2ae494=>{_0x3c8d72['server_']['refreshAppCheckToken'](_0x2ae494['token']);}),_0x3c8d72['statsReporter_']=ih(_0x3c8d72['repoInfo_'],()=>new iu(_0x3c8d72['stats_'],_0x3c8d72['server_'])),_0x3c8d72['infoData_']=new Xh(),_0x3c8d72['infoSyncTree_']=new pr({'startListening':(_0x56d1c7,_0x234585,_0xe8bbc3,_0x253dce)=>{let _0x4b4aa8=[];const _0x5f5d1e=_0x3c8d72['infoData_']['getNode'](_0x56d1c7['_path']);return _0x5f5d1e['isEmpty']()||(_0x4b4aa8=Yt(_0x3c8d72['infoSyncTree_'],_0x56d1c7['_path'],_0x5f5d1e),setTimeout(()=>{_0x253dce('ok');},0x0)),_0x4b4aa8;},'stopListening':()=>{}}),vs(_0x3c8d72,'connected',!0x1),_0x3c8d72['serverSyncTree_']=new pr({'startListening':(_0x8f83a9,_0x454d4f,_0x95073b,_0x19e147)=>(_0x3c8d72['server_']['listen'](_0x8f83a9,_0x95073b,_0x454d4f,(_0x2987c7,_0x62b992)=>{const _0x529bf8=_0x19e147(_0x2987c7,_0x62b992);V(_0x3c8d72['eventQueue_'],_0x8f83a9['_path'],_0x529bf8);}),[]),'stopListening':(_0x5dbb6f,_0x448385)=>{_0x3c8d72['server_']['unlisten'](_0x5dbb6f,_0x448385);}});}function la(_0x1ec984){const _0x567330=_0x1ec984['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x567330;}function Xt(_0x293282){return id({'timestamp':la(_0x293282)});}function gr(_0x448cde,_0x12b17d,_0x440e2a,_0x2f4d2c,_0x23e1fa){_0x448cde['dataUpdateCount']++;const _0xb262a6=new C(_0x12b17d);_0x440e2a=_0x448cde['interceptServerDataCallback_']?_0x448cde['interceptServerDataCallback_'](_0x12b17d,_0x440e2a):_0x440e2a;let _0x39d0dd=[];if(_0x23e1fa){if(_0x2f4d2c){const _0x131591=_n(_0x440e2a,_0x3328c2=>A(_0x3328c2));_0x39d0dd=Ju(_0x448cde['serverSyncTree_'],_0xb262a6,_0x131591,_0x23e1fa);}else{const _0x47dd4c=A(_0x440e2a);_0x39d0dd=Jo(_0x448cde['serverSyncTree_'],_0xb262a6,_0x47dd4c,_0x23e1fa);}}else{if(_0x2f4d2c){const _0x30ce2=_n(_0x440e2a,_0x3dd661=>A(_0x3dd661));_0x39d0dd=Ku(_0x448cde['serverSyncTree_'],_0xb262a6,_0x30ce2);}else{const _0x2961f1=A(_0x440e2a);_0x39d0dd=Yt(_0x448cde['serverSyncTree_'],_0xb262a6,_0x2961f1);}}let _0x3bd1f9=_0xb262a6;_0x39d0dd['length']>0x0&&(_0x3bd1f9=ct(_0x448cde,_0xb262a6)),V(_0x448cde['eventQueue_'],_0x3bd1f9,_0x39d0dd);}function mr(_0x300758,_0xbc5067){vs(_0x300758,'connected',_0xbc5067),_0xbc5067===!0x1&&Sd(_0x300758);}function Id(_0x5d56a3,_0x14f2be){x(_0x14f2be,(_0x23e514,_0x35325c)=>{vs(_0x5d56a3,_0x23e514,_0x35325c);});}function vs(_0x10bc50,_0x156249,_0xc8bb7c){const _0x292dcd=new C('/.info/'+_0x156249),_0x71af47=A(_0xc8bb7c);_0x10bc50['infoData_']['updateSnapshot'](_0x292dcd,_0x71af47);const _0x47d613=Yt(_0x10bc50['infoSyncTree_'],_0x292dcd,_0x71af47);V(_0x10bc50['eventQueue_'],_0x292dcd,_0x47d613);}function zn(_0x54d32d){return _0x54d32d['nextWriteId_']++;}function wd(_0x1a7175,_0x3dd3cc,_0x486638){const _0x46df7f=Xu(_0x1a7175['serverSyncTree_'],_0x3dd3cc);return _0x46df7f!=null?Promise['resolve'](_0x46df7f):_0x1a7175['server_']['get'](_0x3dd3cc)['then'](_0x1a6e4d=>{const _0x209ce3=A(_0x1a6e4d)['withIndex'](_0x3dd3cc['_queryParams']['getIndex']());Ni(_0x1a7175['serverSyncTree_'],_0x3dd3cc,_0x486638,!0x0);let _0x16a2bf;if(_0x3dd3cc['_queryParams']['loadsAllData']())_0x16a2bf=Yt(_0x1a7175['serverSyncTree_'],_0x3dd3cc['_path'],_0x209ce3);else{const _0x1490b5=Wt(_0x1a7175['serverSyncTree_'],_0x3dd3cc);_0x16a2bf=Jo(_0x1a7175['serverSyncTree_'],_0x3dd3cc['_path'],_0x209ce3,_0x1490b5);}return V(_0x1a7175['eventQueue_'],_0x3dd3cc['_path'],_0x16a2bf),An(_0x1a7175['serverSyncTree_'],_0x3dd3cc,_0x486638,null,!0x0),_0x209ce3;},_0x2d79ad=>(gt(_0x1a7175,'get\x20for\x20query\x20'+O(_0x3dd3cc)+'\x20failed:\x20'+_0x2d79ad),Promise['reject'](new Error(_0x2d79ad))));}function Cd(_0x22cbd5,_0x3549d8,_0x1cafbb,_0xed5d8b,_0x37ea7d){gt(_0x22cbd5,'set',{'path':_0x3549d8['toString'](),'value':_0x1cafbb,'priority':_0xed5d8b});const _0x538350=Xt(_0x22cbd5),_0x5ca792=A(_0x1cafbb,_0xed5d8b),_0xf8e868=Vn(_0x22cbd5['serverSyncTree_'],_0x3549d8),_0x1c68bc=fs(_0x5ca792,_0xf8e868,_0x538350),_0x1a96b8=zn(_0x22cbd5),_0xbef7bb=as(_0x22cbd5['serverSyncTree_'],_0x3549d8,_0x1c68bc,_0x1a96b8,!0x0);qn(_0x22cbd5['eventQueue_'],_0xbef7bb),_0x22cbd5['server_']['put'](_0x3549d8['toString'](),_0x5ca792['val'](!0x0),(_0x12b7dc,_0x10256b)=>{const _0x333b61=_0x12b7dc==='ok';_0x333b61||U('set\x20at\x20'+_0x3549d8+'\x20failed:\x20'+_0x12b7dc);const _0x39dae3=_e(_0x22cbd5['serverSyncTree_'],_0x1a96b8,!_0x333b61);V(_0x22cbd5['eventQueue_'],_0x3549d8,_0x39dae3),be(_0x22cbd5,_0x37ea7d,_0x12b7dc,_0x10256b);});const _0x47c11c=Is(_0x22cbd5,_0x3549d8);ct(_0x22cbd5,_0x47c11c),V(_0x22cbd5['eventQueue_'],_0x47c11c,[]);}function Td(_0x431d38,_0x17a478,_0x328604,_0x515667){gt(_0x431d38,'update',{'path':_0x17a478['toString'](),'value':_0x328604});let _0x1992ae=!0x0;const _0x1350a8=Xt(_0x431d38),_0x2b8acf={};if(x(_0x328604,(_0x3bdd31,_0x583607)=>{_0x1992ae=!0x1,_0x2b8acf[_0x3bdd31]=ta(k(_0x17a478,_0x3bdd31),A(_0x583607),_0x431d38['serverSyncTree_'],_0x1350a8);}),_0x1992ae)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x431d38,_0x515667,'ok',void 0x0);else{const _0x37a503=zn(_0x431d38),_0x220d17=ju(_0x431d38['serverSyncTree_'],_0x17a478,_0x2b8acf,_0x37a503);qn(_0x431d38['eventQueue_'],_0x220d17),_0x431d38['server_']['merge'](_0x17a478['toString'](),_0x328604,(_0x1aac7e,_0x950506)=>{const _0x43e9b8=_0x1aac7e==='ok';_0x43e9b8||U('update\x20at\x20'+_0x17a478+'\x20failed:\x20'+_0x1aac7e);const _0x3c6418=_e(_0x431d38['serverSyncTree_'],_0x37a503,!_0x43e9b8),_0x23ff83=_0x3c6418['length']>0x0?ct(_0x431d38,_0x17a478):_0x17a478;V(_0x431d38['eventQueue_'],_0x23ff83,_0x3c6418),be(_0x431d38,_0x515667,_0x1aac7e,_0x950506);}),x(_0x328604,_0x330f98=>{const _0x437d68=Is(_0x431d38,k(_0x17a478,_0x330f98));ct(_0x431d38,_0x437d68);}),V(_0x431d38['eventQueue_'],_0x17a478,[]);}}function Sd(_0x198b32){gt(_0x198b32,'onDisconnectEvents');const _0x57d28a=Xt(_0x198b32),_0x4bced0=En();Si(_0x198b32['onDisconnect_'],w(),(_0x48f9c6,_0x1475e8)=>{const _0x11eb2f=ta(_0x48f9c6,_0x1475e8,_0x198b32['serverSyncTree_'],_0x57d28a);pt(_0x4bced0,_0x48f9c6,_0x11eb2f);});let _0x58008e=[];Si(_0x4bced0,w(),(_0x5a5788,_0x414f12)=>{_0x58008e=_0x58008e['concat'](Yt(_0x198b32['serverSyncTree_'],_0x5a5788,_0x414f12));const _0xd55ef2=Is(_0x198b32,_0x5a5788);ct(_0x198b32,_0xd55ef2);}),_0x198b32['onDisconnect_']=En(),V(_0x198b32['eventQueue_'],w(),_0x58008e);}function bd(_0x29475e,_0x3c2abd,_0xc79a46){_0x29475e['server_']['onDisconnectCancel'](_0x3c2abd['toString'](),(_0x1b124f,_0xc1c675)=>{_0x1b124f==='ok'&&Ti(_0x29475e['onDisconnect_'],_0x3c2abd),be(_0x29475e,_0xc79a46,_0x1b124f,_0xc1c675);});}function yr(_0x2a5863,_0x594279,_0x1e521f,_0x3e8579){const _0x2d0a4b=A(_0x1e521f);_0x2a5863['server_']['onDisconnectPut'](_0x594279['toString'](),_0x2d0a4b['val'](!0x0),(_0x6b17e8,_0x430b4d)=>{_0x6b17e8==='ok'&&pt(_0x2a5863['onDisconnect_'],_0x594279,_0x2d0a4b),be(_0x2a5863,_0x3e8579,_0x6b17e8,_0x430b4d);});}function Rd(_0x5e1464,_0x3cfb5e,_0x5b62a6,_0x30d9e7,_0x3a9d18){const _0x579fa7=A(_0x5b62a6,_0x30d9e7);_0x5e1464['server_']['onDisconnectPut'](_0x3cfb5e['toString'](),_0x579fa7['val'](!0x0),(_0x5adc28,_0x5c2735)=>{_0x5adc28==='ok'&&pt(_0x5e1464['onDisconnect_'],_0x3cfb5e,_0x579fa7),be(_0x5e1464,_0x3a9d18,_0x5adc28,_0x5c2735);});}function Ad(_0x3f34c3,_0xe3b0db,_0x50e26b,_0x549407){if(pn(_0x50e26b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3f34c3,_0x549407,'ok',void 0x0);return;}_0x3f34c3['server_']['onDisconnectMerge'](_0xe3b0db['toString'](),_0x50e26b,(_0x49da51,_0x55d0aa)=>{_0x49da51==='ok'&&x(_0x50e26b,(_0x1f6685,_0x22f440)=>{const _0x3b8a72=A(_0x22f440);pt(_0x3f34c3['onDisconnect_'],k(_0xe3b0db,_0x1f6685),_0x3b8a72);}),be(_0x3f34c3,_0x549407,_0x49da51,_0x55d0aa);});}function kd(_0x593337,_0x3dd54d,_0x4d9982){let _0x42dd4f;y(_0x3dd54d['_path'])==='.info'?_0x42dd4f=Ni(_0x593337['infoSyncTree_'],_0x3dd54d,_0x4d9982):_0x42dd4f=Ni(_0x593337['serverSyncTree_'],_0x3dd54d,_0x4d9982),oa(_0x593337['eventQueue_'],_0x3dd54d['_path'],_0x42dd4f);}function Pd(_0x38df24,_0x20742a,_0x2ab931){let _0x402442;y(_0x20742a['_path'])==='.info'?_0x402442=An(_0x38df24['infoSyncTree_'],_0x20742a,_0x2ab931):_0x402442=An(_0x38df24['serverSyncTree_'],_0x20742a,_0x2ab931),oa(_0x38df24['eventQueue_'],_0x20742a['_path'],_0x402442);}function ha(_0x33f0b6){_0x33f0b6['persistentConnection_']&&_0x33f0b6['persistentConnection_']['interrupt'](ca);}function Nd(_0x4a19cc){_0x4a19cc['persistentConnection_']&&_0x4a19cc['persistentConnection_']['resume'](ca);}function gt(_0x250551,..._0x183b40){let _0x20f815='';_0x250551['persistentConnection_']&&(_0x20f815=_0x250551['persistentConnection_']['id']+':'),L(_0x20f815,..._0x183b40);}function be(_0x4681b5,_0xe2cf7,_0x2fcc62,_0xa37850){_0xe2cf7&&ft(()=>{if(_0x2fcc62==='ok')_0xe2cf7(null);else{const _0xdaab6d=(_0x2fcc62||'error')['toUpperCase']();let _0x4f31e1=_0xdaab6d;_0xa37850&&(_0x4f31e1+=':\x20'+_0xa37850);const _0x1267e0=new Error(_0x4f31e1);_0x1267e0['code']=_0xdaab6d,_0xe2cf7(_0x1267e0);}});}function Od(_0x514a24,_0x3a8018,_0x498e6b,_0x3c697d,_0x479c42,_0x4e929a){gt(_0x514a24,'transaction\x20on\x20'+_0x3a8018);const _0x4bba75={'path':_0x3a8018,'update':_0x498e6b,'onComplete':_0x3c697d,'status':null,'order':so(),'applyLocally':_0x4e929a,'retryCount':0x0,'unwatcher':_0x479c42,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x28b8f3=Es(_0x514a24,_0x3a8018,void 0x0);_0x4bba75['currentInputSnapshot']=_0x28b8f3;const _0x3b4b20=_0x4bba75['update'](_0x28b8f3['val']());if(_0x3b4b20===void 0x0)_0x4bba75['unwatcher'](),_0x4bba75['currentOutputSnapshotRaw']=null,_0x4bba75['currentOutputSnapshotResolved']=null,_0x4bba75['onComplete']&&_0x4bba75['onComplete'](null,!0x1,_0x4bba75['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3b4b20,_0x4bba75['path']),_0x4bba75['status']=0x0;const _0x3bf21d=$n(_0x514a24['transactionQueueTree_'],_0x3a8018),_0x1ce96f=je(_0x3bf21d)||[];_0x1ce96f['push'](_0x4bba75),gs(_0x3bf21d,_0x1ce96f);let _0x5510d9;typeof _0x3b4b20=='object'&&_0x3b4b20!==null&&Q(_0x3b4b20,'.priority')?(_0x5510d9=Le(_0x3b4b20,'.priority'),f(Bt(_0x5510d9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5510d9=(Vn(_0x514a24['serverSyncTree_'],_0x3a8018)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x59cf7b=Xt(_0x514a24),_0x48d034=A(_0x3b4b20,_0x5510d9),_0x69ff29=fs(_0x48d034,_0x28b8f3,_0x59cf7b);_0x4bba75['currentOutputSnapshotRaw']=_0x48d034,_0x4bba75['currentOutputSnapshotResolved']=_0x69ff29,_0x4bba75['currentWriteId']=zn(_0x514a24);const _0x465019=as(_0x514a24['serverSyncTree_'],_0x3a8018,_0x69ff29,_0x4bba75['currentWriteId'],_0x4bba75['applyLocally']);V(_0x514a24['eventQueue_'],_0x3a8018,_0x465019),jn(_0x514a24,_0x514a24['transactionQueueTree_']);}}function Es(_0x15f00d,_0x404d36,_0x3b5e5a){return Vn(_0x15f00d['serverSyncTree_'],_0x404d36,_0x3b5e5a)||g['EMPTY_NODE'];}function jn(_0x56ad4a,_0x3c0bbf=_0x56ad4a['transactionQueueTree_']){if(_0x3c0bbf||Kn(_0x56ad4a,_0x3c0bbf),je(_0x3c0bbf)){const _0x9da78=da(_0x56ad4a,_0x3c0bbf);f(_0x9da78['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x9da78['every'](_0x9a33af=>_0x9a33af['status']===0x0)&&Dd(_0x56ad4a,Qt(_0x3c0bbf),_0x9da78);}else na(_0x3c0bbf)&&Gn(_0x3c0bbf,_0x5de458=>{jn(_0x56ad4a,_0x5de458);});}function Dd(_0x37f932,_0x482143,_0x302719){const _0x571dd9=_0x302719['map'](_0x3ec8d5=>_0x3ec8d5['currentWriteId']),_0x94d1bd=Es(_0x37f932,_0x482143,_0x571dd9);let _0x19b867=_0x94d1bd;const _0x1c94c=_0x94d1bd['hash']();for(let _0xbe6053=0x0;_0xbe6053<_0x302719['length'];_0xbe6053++){const _0x29224b=_0x302719[_0xbe6053];f(_0x29224b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x29224b['status']=0x1,_0x29224b['retryCount']++;const _0x3b108b=F(_0x482143,_0x29224b['path']);_0x19b867=_0x19b867['updateChild'](_0x3b108b,_0x29224b['currentOutputSnapshotRaw']);}const _0x1d69cc=_0x19b867['val'](!0x0),_0x4bfa00=_0x482143;_0x37f932['server_']['put'](_0x4bfa00['toString'](),_0x1d69cc,_0x1bbbc7=>{gt(_0x37f932,'transaction\x20put\x20response',{'path':_0x4bfa00['toString'](),'status':_0x1bbbc7});let _0xea1bf4=[];if(_0x1bbbc7==='ok'){const _0x315246=[];for(let _0x5b3c9c=0x0;_0x5b3c9c<_0x302719['length'];_0x5b3c9c++)_0x302719[_0x5b3c9c]['status']=0x2,_0xea1bf4=_0xea1bf4['concat'](_e(_0x37f932['serverSyncTree_'],_0x302719[_0x5b3c9c]['currentWriteId'])),_0x302719[_0x5b3c9c]['onComplete']&&_0x315246['push'](()=>_0x302719[_0x5b3c9c]['onComplete'](null,!0x0,_0x302719[_0x5b3c9c]['currentOutputSnapshotResolved'])),_0x302719[_0x5b3c9c]['unwatcher']();Kn(_0x37f932,$n(_0x37f932['transactionQueueTree_'],_0x482143)),jn(_0x37f932,_0x37f932['transactionQueueTree_']),V(_0x37f932['eventQueue_'],_0x482143,_0xea1bf4);for(let _0x2d0169=0x0;_0x2d0169<_0x315246['length'];_0x2d0169++)ft(_0x315246[_0x2d0169]);}else{if(_0x1bbbc7==='datastale'){for(let _0x2e7619=0x0;_0x2e7619<_0x302719['length'];_0x2e7619++)_0x302719[_0x2e7619]['status']===0x3?_0x302719[_0x2e7619]['status']=0x4:_0x302719[_0x2e7619]['status']=0x0;}else{U('transaction\x20at\x20'+_0x4bfa00['toString']()+'\x20failed:\x20'+_0x1bbbc7);for(let _0x2a85a5=0x0;_0x2a85a5<_0x302719['length'];_0x2a85a5++)_0x302719[_0x2a85a5]['status']=0x4,_0x302719[_0x2a85a5]['abortReason']=_0x1bbbc7;}ct(_0x37f932,_0x482143);}},_0x1c94c);}function ct(_0x4abdb9,_0x465f06){const _0x1ebeef=ua(_0x4abdb9,_0x465f06),_0x26e0cd=Qt(_0x1ebeef),_0x43554a=da(_0x4abdb9,_0x1ebeef);return Md(_0x4abdb9,_0x43554a,_0x26e0cd),_0x26e0cd;}function Md(_0x477f2c,_0x311f3f,_0x2dc7cc){if(_0x311f3f['length']===0x0)return;const _0x14000d=[];let _0x16feb5=[];const _0x1b1d91=_0x311f3f['filter'](_0x884437=>_0x884437['status']===0x0)['map'](_0x5eab33=>_0x5eab33['currentWriteId']);for(let _0x4842ab=0x0;_0x4842ab<_0x311f3f['length'];_0x4842ab++){const _0xb5d6ae=_0x311f3f[_0x4842ab],_0x1d3f2d=F(_0x2dc7cc,_0xb5d6ae['path']);let _0xbe785a=!0x1,_0x2bc33c;if(f(_0x1d3f2d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xb5d6ae['status']===0x4)_0xbe785a=!0x0,_0x2bc33c=_0xb5d6ae['abortReason'],_0x16feb5=_0x16feb5['concat'](_e(_0x477f2c['serverSyncTree_'],_0xb5d6ae['currentWriteId'],!0x0));else{if(_0xb5d6ae['status']===0x0){if(_0xb5d6ae['retryCount']>=yd)_0xbe785a=!0x0,_0x2bc33c='maxretry',_0x16feb5=_0x16feb5['concat'](_e(_0x477f2c['serverSyncTree_'],_0xb5d6ae['currentWriteId'],!0x0));else{const _0x4c2cc4=Es(_0x477f2c,_0xb5d6ae['path'],_0x1b1d91);_0xb5d6ae['currentInputSnapshot']=_0x4c2cc4;const _0x2a4783=_0x311f3f[_0x4842ab]['update'](_0x4c2cc4['val']());if(_0x2a4783!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2a4783,_0xb5d6ae['path']);let _0x347d57=A(_0x2a4783);typeof _0x2a4783=='object'&&_0x2a4783!=null&&Q(_0x2a4783,'.priority')||(_0x347d57=_0x347d57['updatePriority'](_0x4c2cc4['getPriority']()));const _0x5a61ca=_0xb5d6ae['currentWriteId'],_0x3cb3ad=Xt(_0x477f2c),_0xe3f7c2=fs(_0x347d57,_0x4c2cc4,_0x3cb3ad);_0xb5d6ae['currentOutputSnapshotRaw']=_0x347d57,_0xb5d6ae['currentOutputSnapshotResolved']=_0xe3f7c2,_0xb5d6ae['currentWriteId']=zn(_0x477f2c),_0x1b1d91['splice'](_0x1b1d91['indexOf'](_0x5a61ca),0x1),_0x16feb5=_0x16feb5['concat'](as(_0x477f2c['serverSyncTree_'],_0xb5d6ae['path'],_0xe3f7c2,_0xb5d6ae['currentWriteId'],_0xb5d6ae['applyLocally'])),_0x16feb5=_0x16feb5['concat'](_e(_0x477f2c['serverSyncTree_'],_0x5a61ca,!0x0));}else _0xbe785a=!0x0,_0x2bc33c='nodata',_0x16feb5=_0x16feb5['concat'](_e(_0x477f2c['serverSyncTree_'],_0xb5d6ae['currentWriteId'],!0x0));}}}V(_0x477f2c['eventQueue_'],_0x2dc7cc,_0x16feb5),_0x16feb5=[],_0xbe785a&&(_0x311f3f[_0x4842ab]['status']=0x2,function(_0x35636f){setTimeout(_0x35636f,Math['floor'](0x0));}(_0x311f3f[_0x4842ab]['unwatcher']),_0x311f3f[_0x4842ab]['onComplete']&&(_0x2bc33c==='nodata'?_0x14000d['push'](()=>_0x311f3f[_0x4842ab]['onComplete'](null,!0x1,_0x311f3f[_0x4842ab]['currentInputSnapshot'])):_0x14000d['push'](()=>_0x311f3f[_0x4842ab]['onComplete'](new Error(_0x2bc33c),!0x1,null))));}Kn(_0x477f2c,_0x477f2c['transactionQueueTree_']);for(let _0x5c5091=0x0;_0x5c5091<_0x14000d['length'];_0x5c5091++)ft(_0x14000d[_0x5c5091]);jn(_0x477f2c,_0x477f2c['transactionQueueTree_']);}function ua(_0x2f59be,_0x363a49){let _0xa5212b,_0x85e0da=_0x2f59be['transactionQueueTree_'];for(_0xa5212b=y(_0x363a49);_0xa5212b!==null&&je(_0x85e0da)===void 0x0;)_0x85e0da=$n(_0x85e0da,_0xa5212b),_0x363a49=S(_0x363a49),_0xa5212b=y(_0x363a49);return _0x85e0da;}function da(_0x321234,_0x24145a){const _0xae3bef=[];return fa(_0x321234,_0x24145a,_0xae3bef),_0xae3bef['sort']((_0x5663a5,_0x153dc5)=>_0x5663a5['order']-_0x153dc5['order']),_0xae3bef;}function fa(_0x56d6e9,_0x54f46a,_0x56df29){const _0x5b1c1f=je(_0x54f46a);if(_0x5b1c1f){for(let _0x1d49e7=0x0;_0x1d49e7<_0x5b1c1f['length'];_0x1d49e7++)_0x56df29['push'](_0x5b1c1f[_0x1d49e7]);}Gn(_0x54f46a,_0x2415db=>{fa(_0x56d6e9,_0x2415db,_0x56df29);});}function Kn(_0x4022fe,_0x5810df){const _0x3dd1d5=je(_0x5810df);if(_0x3dd1d5){let _0xa981d7=0x0;for(let _0x5b6201=0x0;_0x5b6201<_0x3dd1d5['length'];_0x5b6201++)_0x3dd1d5[_0x5b6201]['status']!==0x2&&(_0x3dd1d5[_0xa981d7]=_0x3dd1d5[_0x5b6201],_0xa981d7++);_0x3dd1d5['length']=_0xa981d7,gs(_0x5810df,_0x3dd1d5['length']>0x0?_0x3dd1d5:void 0x0);}Gn(_0x5810df,_0xd835f7=>{Kn(_0x4022fe,_0xd835f7);});}function Is(_0x4c3516,_0x44c159){const _0x20cbef=Qt(ua(_0x4c3516,_0x44c159)),_0x1e9bb1=$n(_0x4c3516['transactionQueueTree_'],_0x44c159);return ad(_0x1e9bb1,_0x2c6b64=>{di(_0x4c3516,_0x2c6b64);}),di(_0x4c3516,_0x1e9bb1),ia(_0x1e9bb1,_0x2f7e1e=>{di(_0x4c3516,_0x2f7e1e);}),_0x20cbef;}function di(_0x442880,_0x22c76b){const _0x1abb7a=je(_0x22c76b);if(_0x1abb7a){const _0x4c5249=[];let _0x349805=[],_0x3f75df=-0x1;for(let _0xa08d8d=0x0;_0xa08d8d<_0x1abb7a['length'];_0xa08d8d++)_0x1abb7a[_0xa08d8d]['status']===0x3||(_0x1abb7a[_0xa08d8d]['status']===0x1?(f(_0x3f75df===_0xa08d8d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x3f75df=_0xa08d8d,_0x1abb7a[_0xa08d8d]['status']=0x3,_0x1abb7a[_0xa08d8d]['abortReason']='set'):(f(_0x1abb7a[_0xa08d8d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1abb7a[_0xa08d8d]['unwatcher'](),_0x349805=_0x349805['concat'](_e(_0x442880['serverSyncTree_'],_0x1abb7a[_0xa08d8d]['currentWriteId'],!0x0)),_0x1abb7a[_0xa08d8d]['onComplete']&&_0x4c5249['push'](_0x1abb7a[_0xa08d8d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x3f75df===-0x1?gs(_0x22c76b,void 0x0):_0x1abb7a['length']=_0x3f75df+0x1,V(_0x442880['eventQueue_'],Qt(_0x22c76b),_0x349805);for(let _0x346a00=0x0;_0x346a00<_0x4c5249['length'];_0x346a00++)ft(_0x4c5249[_0x346a00]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x47b719){let _0x4006ff='';const _0x4b8264=_0x47b719['split']('/');for(let _0x1ccb5e=0x0;_0x1ccb5e<_0x4b8264['length'];_0x1ccb5e++)if(_0x4b8264[_0x1ccb5e]['length']>0x0){let _0x4ffa5e=_0x4b8264[_0x1ccb5e];try{_0x4ffa5e=decodeURIComponent(_0x4ffa5e['replace'](/\+/g,'\x20'));}catch{}_0x4006ff+='/'+_0x4ffa5e;}return _0x4006ff;}function xd(_0x247273){const _0x45608f={};_0x247273['charAt'](0x0)==='?'&&(_0x247273=_0x247273['substring'](0x1));for(const _0x741efa of _0x247273['split']('&')){if(_0x741efa['length']===0x0)continue;const _0x450e0f=_0x741efa['split']('=');_0x450e0f['length']===0x2?_0x45608f[decodeURIComponent(_0x450e0f[0x0])]=decodeURIComponent(_0x450e0f[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x741efa+'\x27\x20in\x20query\x20\x27'+_0x247273+'\x27');}return _0x45608f;}const vr=function(_0x1aa424,_0x20bf1d){const _0x2587af=Fd(_0x1aa424),_0x437f4d=_0x2587af['namespace'];_0x2587af['domain']==='firebase.com'&&ae(_0x2587af['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x437f4d||_0x437f4d==='undefined')&&_0x2587af['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2587af['secure']||$l();const _0x5d17b3=_0x2587af['scheme']==='ws'||_0x2587af['scheme']==='wss';return{'repoInfo':new yo(_0x2587af['host'],_0x2587af['secure'],_0x437f4d,_0x5d17b3,_0x20bf1d,'',_0x437f4d!==_0x2587af['subdomain']),'path':new C(_0x2587af['pathString'])};},Fd=function(_0x683bf0){let _0x4a6812='',_0x2276cd='',_0x404ce2='',_0x28024d='',_0x5d4d7f='',_0x161cf9=!0x0,_0x5e2e6a='https',_0x1fa9e9=0x1bb;if(typeof _0x683bf0=='string'){let _0xa08ff8=_0x683bf0['indexOf']('//');_0xa08ff8>=0x0&&(_0x5e2e6a=_0x683bf0['substring'](0x0,_0xa08ff8-0x1),_0x683bf0=_0x683bf0['substring'](_0xa08ff8+0x2));let _0x4b951a=_0x683bf0['indexOf']('/');_0x4b951a===-0x1&&(_0x4b951a=_0x683bf0['length']);let _0x47c43b=_0x683bf0['indexOf']('?');_0x47c43b===-0x1&&(_0x47c43b=_0x683bf0['length']),_0x4a6812=_0x683bf0['substring'](0x0,Math['min'](_0x4b951a,_0x47c43b)),_0x4b951a<_0x47c43b&&(_0x28024d=Ld(_0x683bf0['substring'](_0x4b951a,_0x47c43b)));const _0x2cfee7=xd(_0x683bf0['substring'](Math['min'](_0x683bf0['length'],_0x47c43b)));_0xa08ff8=_0x4a6812['indexOf'](':'),_0xa08ff8>=0x0?(_0x161cf9=_0x5e2e6a==='https'||_0x5e2e6a==='wss',_0x1fa9e9=parseInt(_0x4a6812['substring'](_0xa08ff8+0x1),0xa)):_0xa08ff8=_0x4a6812['length'];const _0x2b9811=_0x4a6812['slice'](0x0,_0xa08ff8);if(_0x2b9811['toLowerCase']()==='localhost')_0x2276cd='localhost';else{if(_0x2b9811['split']('.')['length']<=0x2)_0x2276cd=_0x2b9811;else{const _0xac91ac=_0x4a6812['indexOf']('.');_0x404ce2=_0x4a6812['substring'](0x0,_0xac91ac)['toLowerCase'](),_0x2276cd=_0x4a6812['substring'](_0xac91ac+0x1),_0x5d4d7f=_0x404ce2;}}'ns'in _0x2cfee7&&(_0x5d4d7f=_0x2cfee7['ns']);}return{'host':_0x4a6812,'port':_0x1fa9e9,'domain':_0x2276cd,'subdomain':_0x404ce2,'secure':_0x161cf9,'scheme':_0x5e2e6a,'pathString':_0x28024d,'namespace':_0x5d4d7f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x1fe7eb=0x0;const _0x2d098c=[];return function(_0x481bcf){const _0x56635d=_0x481bcf===_0x1fe7eb;_0x1fe7eb=_0x481bcf;let _0x5766a2;const _0x46ead2=new Array(0x8);for(_0x5766a2=0x7;_0x5766a2>=0x0;_0x5766a2--)_0x46ead2[_0x5766a2]=Er['charAt'](_0x481bcf%0x40),_0x481bcf=Math['floor'](_0x481bcf/0x40);f(_0x481bcf===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1971d2=_0x46ead2['join']('');if(_0x56635d){for(_0x5766a2=0xb;_0x5766a2>=0x0&&_0x2d098c[_0x5766a2]===0x3f;_0x5766a2--)_0x2d098c[_0x5766a2]=0x0;_0x2d098c[_0x5766a2]++;}else{for(_0x5766a2=0x0;_0x5766a2<0xc;_0x5766a2++)_0x2d098c[_0x5766a2]=Math['floor'](Math['random']()*0x40);}for(_0x5766a2=0x0;_0x5766a2<0xc;_0x5766a2++)_0x1971d2+=Er['charAt'](_0x2d098c[_0x5766a2]);return f(_0x1971d2['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1971d2;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x2333a4,_0x324994,_0x585462,_0xf68df8){this['eventType']=_0x2333a4,this['eventRegistration']=_0x324994,this['snapshot']=_0x585462,this['prevName']=_0xf68df8;}['getPath'](){const _0x5dcc0=this['snapshot']['ref'];return this['eventType']==='value'?_0x5dcc0['_path']:_0x5dcc0['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x22ba9e,_0x3fdf44,_0x128c68){this['eventRegistration']=_0x22ba9e,this['error']=_0x3fdf44,this['path']=_0x128c68;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x65e776,_0x4471ff){this['snapshotCallback']=_0x65e776,this['cancelCallback']=_0x4471ff;}['onValue'](_0x38bc17,_0x308d7b){this['snapshotCallback']['call'](null,_0x38bc17,_0x308d7b);}['onCancel'](_0x30c5d5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x30c5d5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xcb62f8){return this['snapshotCallback']===_0xcb62f8['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xcb62f8['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xcb62f8['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x1c4073,_0x31bdd4){this['_repo']=_0x1c4073,this['_path']=_0x31bdd4;}['cancel'](){const _0x5a037a=new H();return bd(this['_repo'],this['_path'],_0x5a037a['wrapCallback'](()=>{})),_0x5a037a['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x38fab3=new H();return yr(this['_repo'],this['_path'],null,_0x38fab3['wrapCallback'](()=>{})),_0x38fab3['promise'];}['set'](_0x2a7783){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2a7783,this['_path'],!0x1);const _0x44b506=new H();return yr(this['_repo'],this['_path'],_0x2a7783,_0x44b506['wrapCallback'](()=>{})),_0x44b506['promise'];}['setWithPriority'](_0x26f3a0,_0xbf76ed){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x26f3a0,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0xbf76ed);const _0x2df7bf=new H();return Rd(this['_repo'],this['_path'],_0x26f3a0,_0xbf76ed,_0x2df7bf['wrapCallback'](()=>{})),_0x2df7bf['promise'];}['update'](_0x40da78){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x40da78,this['_path']);const _0xf1f386=new H();return Ad(this['_repo'],this['_path'],_0x40da78,_0xf1f386['wrapCallback'](()=>{})),_0xf1f386['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x234303,_0xf3785a,_0x473b13,_0x2c7a01){this['_repo']=_0x234303,this['_path']=_0xf3785a,this['_queryParams']=_0x473b13,this['_orderByCalled']=_0x2c7a01;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x28edb7=sr(this['_queryParams']),_0x564b48=$i(_0x28edb7);return _0x564b48==='{}'?'default':_0x564b48;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x19bf66){if(_0x19bf66=P(_0x19bf66),!(_0x19bf66 instanceof Ae))return!0x1;const _0x25655c=this['_repo']===_0x19bf66['_repo'],_0x2dd57c=Ki(this['_path'],_0x19bf66['_path']),_0x5db316=this['_queryIdentifier']===_0x19bf66['_queryIdentifier'];return _0x25655c&&_0x2dd57c&&_0x5db316;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x5802fb,_0x1f3d56){if(_0x5802fb['_orderByCalled']===!0x0)throw new Error(_0x1f3d56+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1a1c49){let _0x5efdd2=null,_0x2ce115=null;if(_0x1a1c49['hasStart']()&&(_0x5efdd2=_0x1a1c49['getIndexStartValue']()),_0x1a1c49['hasEnd']()&&(_0x2ce115=_0x1a1c49['getIndexEndValue']()),_0x1a1c49['getIndex']()===ve){const _0x397562='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x39c7c3='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1a1c49['hasStart']()){if(_0x1a1c49['getIndexStartName']()!==We)throw new Error(_0x397562);if(typeof _0x5efdd2!='string')throw new Error(_0x39c7c3);}if(_0x1a1c49['hasEnd']()){if(_0x1a1c49['getIndexEndName']()!==we)throw new Error(_0x397562);if(typeof _0x2ce115!='string')throw new Error(_0x39c7c3);}}else{if(_0x1a1c49['getIndex']()===R){if(_0x5efdd2!=null&&!Bt(_0x5efdd2)||_0x2ce115!=null&&!Bt(_0x2ce115))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1a1c49['getIndex']()instanceof Ji||_0x1a1c49['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x5efdd2!=null&&typeof _0x5efdd2=='object'||_0x2ce115!=null&&typeof _0x2ce115=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x9c90b3){if(_0x9c90b3['hasStart']()&&_0x9c90b3['hasEnd']()&&_0x9c90b3['hasLimit']()&&!_0x9c90b3['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x557ff5,_0x585f54){super(_0x557ff5,_0x585f54,new Zi(),!0x1);}get['parent'](){const _0x494d4a=Ro(this['_path']);return _0x494d4a===null?null:new ee(this['_repo'],_0x494d4a);}get['root'](){let _0x3314ac=this;for(;_0x3314ac['parent']!==null;)_0x3314ac=_0x3314ac['parent'];return _0x3314ac;}}class lt{constructor(_0x35ada8,_0x43a50d,_0x5036ac){this['_node']=_0x35ada8,this['ref']=_0x43a50d,this['_index']=_0x5036ac;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x567579){const _0x538192=new C(_0x567579),_0x8e3e70=Vt(this['ref'],_0x567579);return new lt(this['_node']['getChild'](_0x538192),_0x8e3e70,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x3bec01){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x30c040,_0x47f485)=>_0x3bec01(new lt(_0x47f485,Vt(this['ref'],_0x30c040),R)));}['hasChild'](_0x44b52d){const _0x13e364=new C(_0x44b52d);return!this['_node']['getChild'](_0x13e364)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x5c3582,_0x27924f){return _0x5c3582=P(_0x5c3582),_0x5c3582['_checkNotDeleted']('ref'),_0x27924f!==void 0x0?Vt(_0x5c3582['_root'],_0x27924f):_0x5c3582['_root'];}function Vt(_0x1a2d27,_0x3c3a23){return _0x1a2d27=P(_0x1a2d27),y(_0x1a2d27['_path'])===null?pd('child','path',_0x3c3a23):ys('child','path',_0x3c3a23),new ee(_0x1a2d27['_repo'],k(_0x1a2d27['_path'],_0x3c3a23));}function v_(_0x34d1c9){return _0x34d1c9=P(_0x34d1c9),new Vd(_0x34d1c9['_repo'],_0x34d1c9['_path']);}function E_(_0x1200aa,_0x3fadec){_0x1200aa=P(_0x1200aa),Me('push',_0x1200aa['_path']),He('push',_0x3fadec,_0x1200aa['_path'],!0x0);const _0xa15448=la(_0x1200aa['_repo']),_0x45fdd1=Ud(_0xa15448),_0x5663e1=Vt(_0x1200aa,_0x45fdd1),_0x59e9c5=Vt(_0x1200aa,_0x45fdd1);let _0x5c30ec;return _0x3fadec!=null?_0x5c30ec=Hd(_0x59e9c5,_0x3fadec)['then'](()=>_0x59e9c5):_0x5c30ec=Promise['resolve'](_0x59e9c5),_0x5663e1['then']=_0x5c30ec['then']['bind'](_0x5c30ec),_0x5663e1['catch']=_0x5c30ec['then']['bind'](_0x5c30ec,void 0x0),_0x5663e1;}function Hd(_0xd5fd0,_0x248c60){_0xd5fd0=P(_0xd5fd0),Me('set',_0xd5fd0['_path']),He('set',_0x248c60,_0xd5fd0['_path'],!0x1);const _0x3bfdd3=new H();return Cd(_0xd5fd0['_repo'],_0xd5fd0['_path'],_0x248c60,null,_0x3bfdd3['wrapCallback'](()=>{})),_0x3bfdd3['promise'];}function I_(_0x125d6b,_0x403c33){ra('update',_0x403c33,_0x125d6b['_path']);const _0x4526aa=new H();return Td(_0x125d6b['_repo'],_0x125d6b['_path'],_0x403c33,_0x4526aa['wrapCallback'](()=>{})),_0x4526aa['promise'];}function w_(_0x303771){_0x303771=P(_0x303771);const _0x99006b=new pa(()=>{}),_0x12044e=new Qn(_0x99006b);return wd(_0x303771['_repo'],_0x303771,_0x12044e)['then'](_0x56bd68=>new lt(_0x56bd68,new ee(_0x303771['_repo'],_0x303771['_path']),_0x303771['_queryParams']['getIndex']()));}class Qn{constructor(_0x28b208){this['callbackContext']=_0x28b208;}['respondsTo'](_0x413602){return _0x413602==='value';}['createEvent'](_0x339080,_0x1f1a56){const _0x4f4277=_0x1f1a56['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x339080['snapshotNode'],new ee(_0x1f1a56['_repo'],_0x1f1a56['_path']),_0x4f4277));}['getEventRunner'](_0xbc5267){return _0xbc5267['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xbc5267['error']):()=>this['callbackContext']['onValue'](_0xbc5267['snapshot'],null);}['createCancelEvent'](_0x3a2335,_0x517f97){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x3a2335,_0x517f97):null;}['matches'](_0x14d0ad){return _0x14d0ad instanceof Qn?!_0x14d0ad['callbackContext']||!this['callbackContext']?!0x0:_0x14d0ad['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x1bff7d,_0x587b59,_0x30c623,_0x10e475,_0x32b512){const _0x1b0498=new pa(_0x30c623,void 0x0),_0x3c4540=new Qn(_0x1b0498);return kd(_0x1bff7d['_repo'],_0x1bff7d,_0x3c4540),()=>Pd(_0x1bff7d['_repo'],_0x1bff7d,_0x3c4540);}function Gd(_0x4c2342,_0x413ae0,_0x3249ff,_0x50c9f8){return $d(_0x4c2342,'value',_0x413ae0);}class mt{}class ma extends mt{constructor(_0x5d9850,_0x117532){super(),this['_value']=_0x5d9850,this['_key']=_0x117532,this['type']='endAt';}['_apply'](_0x135994){He('endAt',this['_value'],_0x135994['_path'],!0x0);const _0x227a6a=Jh(_0x135994['_queryParams'],this['_value'],this['_key']);if(ga(_0x227a6a),Yn(_0x227a6a),_0x135994['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x135994['_repo'],_0x135994['_path'],_0x227a6a,_0x135994['_orderByCalled']);}}function C_(_0x248f5d,_0x55f349){return new ma(_0x248f5d,_0x55f349);}class ya extends mt{constructor(_0x3bb8ea,_0xabb057){super(),this['_value']=_0x3bb8ea,this['_key']=_0xabb057,this['type']='startAt';}['_apply'](_0x4f2175){He('startAt',this['_value'],_0x4f2175['_path'],!0x0);const _0x55ea84=Qh(_0x4f2175['_queryParams'],this['_value'],this['_key']);if(ga(_0x55ea84),Yn(_0x55ea84),_0x4f2175['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x4f2175['_repo'],_0x4f2175['_path'],_0x55ea84,_0x4f2175['_orderByCalled']);}}function T_(_0x514c8c=null,_0x541d8a){return new ya(_0x514c8c,_0x541d8a);}class qd extends mt{constructor(_0x309037){super(),this['_limit']=_0x309037,this['type']='limitToFirst';}['_apply'](_0x47ec32){if(_0x47ec32['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x47ec32['_repo'],_0x47ec32['_path'],Yh(_0x47ec32['_queryParams'],this['_limit']),_0x47ec32['_orderByCalled']);}}function S_(_0x5a3ca6){if(Math['floor'](_0x5a3ca6)!==_0x5a3ca6||_0x5a3ca6<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x5a3ca6);}class zd extends mt{constructor(_0x36b40f){super(),this['_path']=_0x36b40f,this['type']='orderByChild';}['_apply'](_0x6bcb23){_a(_0x6bcb23,'orderByChild');const _0x2623d1=new C(this['_path']);if(v(_0x2623d1))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xcd3435=new Ji(_0x2623d1),_0x3a7253=xo(_0x6bcb23['_queryParams'],_0xcd3435);return Yn(_0x3a7253),new Ae(_0x6bcb23['_repo'],_0x6bcb23['_path'],_0x3a7253,!0x0);}}function b_(_0x44d386){if(_0x44d386==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x44d386==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x44d386==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x44d386),new zd(_0x44d386);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3f2a80){_a(_0x3f2a80,'orderByKey');const _0x3f9d8c=xo(_0x3f2a80['_queryParams'],ve);return Yn(_0x3f9d8c),new Ae(_0x3f2a80['_repo'],_0x3f2a80['_path'],_0x3f9d8c,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x323e5a,_0x2f03eb){super(),this['_value']=_0x323e5a,this['_key']=_0x2f03eb,this['type']='equalTo';}['_apply'](_0x4c0dd7){if(He('equalTo',this['_value'],_0x4c0dd7['_path'],!0x1),_0x4c0dd7['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4c0dd7['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4c0dd7));}}function A_(_0x475a0d,_0x24ed49){return new Kd(_0x475a0d,_0x24ed49);}function k_(_0x461929,..._0x53cb05){let _0x33f652=P(_0x461929);for(const _0x1dd95a of _0x53cb05)_0x33f652=_0x1dd95a['_apply'](_0x33f652);return _0x33f652;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x368515,_0x53839f,_0x47d2c9,_0x46ee41){const _0xfc93c3=_0x53839f['lastIndexOf'](':'),_0x39e14c=_0x53839f['substring'](0x0,_0xfc93c3),_0x261adc=qt(_0x39e14c);_0x368515['repoInfo_']=new yo(_0x53839f,_0x261adc,_0x368515['repoInfo_']['namespace'],_0x368515['repoInfo_']['webSocketOnly'],_0x368515['repoInfo_']['nodeAdmin'],_0x368515['repoInfo_']['persistenceKey'],_0x368515['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x47d2c9),_0x46ee41&&(_0x368515['authTokenProvider_']=_0x46ee41);}function Xd(_0x35fe53,_0x5a31cd,_0x3f7747,_0x59b5df,_0x486a1b){let _0x40e985=_0x59b5df||_0x35fe53['options']['databaseURL'];_0x40e985===void 0x0&&(_0x35fe53['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x35fe53['options']['projectId']),_0x40e985=_0x35fe53['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x26d2b4=vr(_0x40e985,_0x486a1b),_0x199c9d=_0x26d2b4['repoInfo'],_0x2f3e37;typeof process<'u'&&Bs&&(_0x2f3e37=Bs[Yd]),_0x2f3e37?(_0x40e985='http://'+_0x2f3e37+'?ns='+_0x199c9d['namespace'],_0x26d2b4=vr(_0x40e985,_0x486a1b),_0x199c9d=_0x26d2b4['repoInfo']):_0x26d2b4['repoInfo']['secure'];const _0x263a70=new eh(_0x35fe53['name'],_0x35fe53['options'],_0x5a31cd);_d('Invalid\x20Firebase\x20Database\x20URL',_0x26d2b4),v(_0x26d2b4['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x2606f8=ef(_0x199c9d,_0x35fe53,_0x263a70,new Zl(_0x35fe53,_0x3f7747));return new tf(_0x2606f8,_0x35fe53);}function Zd(_0x2f2d74,_0x1e7c91){const _0x412561=Di[_0x1e7c91];(!_0x412561||_0x412561[_0x2f2d74['key']]!==_0x2f2d74)&&ae('Database\x20'+_0x1e7c91+'('+_0x2f2d74['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2f2d74),delete _0x412561[_0x2f2d74['key']];}function ef(_0x5f21c1,_0x65cea9,_0x4a2f9f,_0x25d0b5){let _0x542bd1=Di[_0x65cea9['name']];_0x542bd1||(_0x542bd1={},Di[_0x65cea9['name']]=_0x542bd1);let _0x554a97=_0x542bd1[_0x5f21c1['toURLString']()];return _0x554a97&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x554a97=new vd(_0x5f21c1,Qd,_0x4a2f9f,_0x25d0b5),_0x542bd1[_0x5f21c1['toURLString']()]=_0x554a97,_0x554a97;}class tf{constructor(_0x35bbd1,_0x561a52){this['_repoInternal']=_0x35bbd1,this['app']=_0x561a52,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3efed5){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3efed5+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2731fc=Zr(),_0x53c9d0){const _0x1e1bb7=Hi(_0x2731fc,'database')['getImmediate']({'identifier':_0x53c9d0});if(!_0x1e1bb7['_instanceStarted']){const _0x1e784d=hc('database');_0x1e784d&&nf(_0x1e1bb7,..._0x1e784d);}return _0x1e1bb7;}function nf(_0x2f64ee,_0x17f4ab,_0x595873,_0x30c5c8={}){_0x2f64ee=P(_0x2f64ee),_0x2f64ee['_checkNotDeleted']('useEmulator');const _0x474120=_0x17f4ab+':'+_0x595873,_0x1d6db4=_0x2f64ee['_repoInternal'];if(_0x2f64ee['_instanceStarted']){if(_0x474120===_0x2f64ee['_repoInternal']['repoInfo_']['host']&&xe(_0x30c5c8,_0x1d6db4['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xbc030d;if(_0x1d6db4['repoInfo_']['nodeAdmin'])_0x30c5c8['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xbc030d=new an(an['OWNER']);else{if(_0x30c5c8['mockUserToken']){const _0x293c03=typeof _0x30c5c8['mockUserToken']=='string'?_0x30c5c8['mockUserToken']:uc(_0x30c5c8['mockUserToken'],_0x2f64ee['app']['options']['projectId']);_0xbc030d=new an(_0x293c03);}}qt(_0x17f4ab)&&Qr(_0x17f4ab),Jd(_0x1d6db4,_0x474120,_0x30c5c8,_0xbc030d);}function N_(_0x57e854){_0x57e854=P(_0x57e854),_0x57e854['_checkNotDeleted']('goOffline'),ha(_0x57e854['_repo']);}function O_(_0x348e93){_0x348e93=P(_0x348e93),_0x348e93['_checkNotDeleted']('goOnline'),Nd(_0x348e93['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x56f2d1){Ul(dt),st(new Fe('database',(_0x545364,{instanceIdentifier:_0x136afe})=>{const _0x59621c=_0x545364['getProvider']('app')['getImmediate'](),_0x55e6f8=_0x545364['getProvider']('auth-internal'),_0xbafaa3=_0x545364['getProvider']('app-check-internal');return Xd(_0x59621c,_0x55e6f8,_0xbafaa3,_0x136afe);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x56f2d1),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x25fe15,_0x3c7874){this['committed']=_0x25fe15,this['snapshot']=_0x3c7874;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x4752e2,_0x914e30,_0x4dcd8e){if(_0x4752e2=P(_0x4752e2),Me('Reference.transaction',_0x4752e2['_path']),_0x4752e2['key']==='.length'||_0x4752e2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4752e2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5a11ef=!0x0,_0x5e27f9=new H(),_0x4ebf99=(_0x59e370,_0x7f4f7c,_0x2b5263)=>{let _0x23461a=null;_0x59e370?_0x5e27f9['reject'](_0x59e370):(_0x23461a=new lt(_0x2b5263,new ee(_0x4752e2['_repo'],_0x4752e2['_path']),R),_0x5e27f9['resolve'](new of(_0x7f4f7c,_0x23461a)));},_0x529d05=Gd(_0x4752e2,()=>{});return Od(_0x4752e2['_repo'],_0x4752e2['_path'],_0x914e30,_0x4ebf99,_0x529d05,_0x5a11ef),_0x5e27f9['promise'];}se['prototype']['simpleListen']=function(_0x130974,_0x3edef1){this['sendRequest']('q',{'p':_0x130974},_0x3edef1);},se['prototype']['echo']=function(_0x1fb88f,_0x1a117f){this['sendRequest']('echo',{'d':_0x1fb88f},_0x1a117f);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0xcbd805,..._0x4033af){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0xcbd805,..._0x4033af);}function cn(_0x16e918,..._0x215e77){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x16e918,..._0x215e77);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x596449,..._0x161817){throw ws(_0x596449,..._0x161817);}function X(_0x3e01ba,..._0x4bdab4){return ws(_0x3e01ba,..._0x4bdab4);}function Ia(_0xee4e11,_0x4038a8,_0x57a78f){const _0x492be9={...af(),[_0x4038a8]:_0x57a78f};return new Gt('auth','Firebase',_0x492be9)['create'](_0x4038a8,{'appName':_0xee4e11['name']});}function re(_0xae208b){return Ia(_0xae208b,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xefa59b,..._0x7bf628){if(typeof _0xefa59b!='string'){const _0x102a47=_0x7bf628[0x0],_0x11fdd6=[..._0x7bf628['slice'](0x1)];return _0x11fdd6[0x0]&&(_0x11fdd6[0x0]['appName']=_0xefa59b['name']),_0xefa59b['_errorFactory']['create'](_0x102a47,..._0x11fdd6);}return Ea['create'](_0xefa59b,..._0x7bf628);}function m(_0x3e5a14,_0x457946,..._0x1c6c35){if(!_0x3e5a14)throw ws(_0x457946,..._0x1c6c35);}function ne(_0x4c1a26){const _0x568145='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4c1a26;throw cn(_0x568145),new Error(_0x568145);}function ce(_0x1aba66,_0x38630c){_0x1aba66||ne(_0x38630c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x1e2bb0;return typeof self<'u'&&((_0x1e2bb0=self['location'])==null?void 0x0:_0x1e2bb0['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x91b135;return typeof self<'u'&&((_0x91b135=self['location'])==null?void 0x0:_0x91b135['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1c4c16=navigator;return _0x1c4c16['languages']&&_0x1c4c16['languages'][0x0]||_0x1c4c16['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4e9b9a,_0x26174d){this['shortDelay']=_0x4e9b9a,this['longDelay']=_0x26174d,ce(_0x26174d>_0x4e9b9a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x5ed713,_0x430a61){ce(_0x5ed713['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5f07aa}=_0x5ed713['emulator'];return _0x430a61?''+_0x5f07aa+(_0x430a61['startsWith']('/')?_0x430a61['slice'](0x1):_0x430a61):_0x5f07aa;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3fd4a9,_0x2c3c44,_0x540a28){this['fetchImpl']=_0x3fd4a9,_0x2c3c44&&(this['headersImpl']=_0x2c3c44),_0x540a28&&(this['responseImpl']=_0x540a28);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x419a39,_0x113237){return _0x419a39['tenantId']&&!_0x113237['tenantId']?{..._0x113237,'tenantId':_0x419a39['tenantId']}:_0x113237;}async function Pe(_0x155be5,_0x255adf,_0x1de8bc,_0x58654b,_0x46e97d={}){return Ca(_0x155be5,_0x46e97d,async()=>{let _0x342dfa={},_0x4d842d={};_0x58654b&&(_0x255adf==='GET'?_0x4d842d=_0x58654b:_0x342dfa={'body':JSON['stringify'](_0x58654b)});const _0x42da84=ut({..._0x4d842d,'key':_0x155be5['config']['apiKey']})['slice'](0x1),_0x2c10ce=await _0x155be5['_getAdditionalHeaders']();_0x2c10ce['Content-Type']='application/json',_0x155be5['languageCode']&&(_0x2c10ce['X-Firebase-Locale']=_0x155be5['languageCode']);const _0x52bd40={'method':_0x255adf,'headers':_0x2c10ce,..._0x342dfa};return dc()||(_0x52bd40['referrerPolicy']='strict-origin-when-cross-origin'),_0x155be5['emulatorConfig']&&qt(_0x155be5['emulatorConfig']['host'])&&(_0x52bd40['credentials']='include'),wa['fetch']()(await Ta(_0x155be5,_0x155be5['config']['apiHost'],_0x1de8bc,_0x42da84),_0x52bd40);});}async function Ca(_0x2f502a,_0x1a5687,_0x6462b4){_0x2f502a['_canInitEmulator']=!0x1;const _0x4914a9={...df,..._0x1a5687};try{const _0x3a660f=new gf(_0x2f502a),_0x41d6f4=await Promise['race']([_0x6462b4(),_0x3a660f['promise']]);_0x3a660f['clearNetworkTimeout']();const _0x5159b1=await _0x41d6f4['json']();if('needConfirmation'in _0x5159b1)throw on(_0x2f502a,'account-exists-with-different-credential',_0x5159b1);if(_0x41d6f4['ok']&&!('errorMessage'in _0x5159b1))return _0x5159b1;{const _0x2f8a95=_0x41d6f4['ok']?_0x5159b1['errorMessage']:_0x5159b1['error']['message'],[_0x7a7714,_0x24bed4]=_0x2f8a95['split']('\x20:\x20');if(_0x7a7714==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2f502a,'credential-already-in-use',_0x5159b1);if(_0x7a7714==='EMAIL_EXISTS')throw on(_0x2f502a,'email-already-in-use',_0x5159b1);if(_0x7a7714==='USER_DISABLED')throw on(_0x2f502a,'user-disabled',_0x5159b1);const _0x16a8ce=_0x4914a9[_0x7a7714]||_0x7a7714['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x24bed4)throw Ia(_0x2f502a,_0x16a8ce,_0x24bed4);Y(_0x2f502a,_0x16a8ce);}}catch(_0xcc0890){if(_0xcc0890 instanceof Re)throw _0xcc0890;Y(_0x2f502a,'network-request-failed',{'message':String(_0xcc0890)});}}async function en(_0x5a86f4,_0x5c7f7d,_0x4bb2e9,_0x281798,_0x1cc161={}){const _0x32064a=await Pe(_0x5a86f4,_0x5c7f7d,_0x4bb2e9,_0x281798,_0x1cc161);return'mfaPendingCredential'in _0x32064a&&Y(_0x5a86f4,'multi-factor-auth-required',{'_serverResponse':_0x32064a}),_0x32064a;}async function Ta(_0x30f94e,_0x9efc34,_0x140918,_0x2454e3){const _0x208959=''+_0x9efc34+_0x140918+'?'+_0x2454e3,_0x448744=_0x30f94e,_0x363b4f=_0x448744['config']['emulator']?Cs(_0x30f94e['config'],_0x208959):_0x30f94e['config']['apiScheme']+'://'+_0x208959;return ff['includes'](_0x140918)&&(await _0x448744['_persistenceManagerAvailable'],_0x448744['_getPersistenceType']()==='COOKIE')?_0x448744['_getPersistence']()['_getFinalTarget'](_0x363b4f)['toString']():_0x363b4f;}function _f(_0x2474a3){switch(_0x2474a3){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x94b07a){this['auth']=_0x94b07a,this['timer']=null,this['promise']=new Promise((_0x4b6c44,_0x318103)=>{this['timer']=setTimeout(()=>_0x318103(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x1050bf,_0x4034b0,_0x26869c){const _0x4b69f9={'appName':_0x1050bf['name']};_0x26869c['email']&&(_0x4b69f9['email']=_0x26869c['email']),_0x26869c['phoneNumber']&&(_0x4b69f9['phoneNumber']=_0x26869c['phoneNumber']);const _0x3b402f=X(_0x1050bf,_0x4034b0,_0x4b69f9);return _0x3b402f['customData']['_tokenResponse']=_0x26869c,_0x3b402f;}function wr(_0x21d427){return _0x21d427!==void 0x0&&_0x21d427['enterprise']!==void 0x0;}class mf{constructor(_0x5af8f7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5af8f7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5af8f7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5af8f7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x247622){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1045b6 of this['recaptchaEnforcementState'])if(_0x1045b6['provider']&&_0x1045b6['provider']===_0x247622)return _f(_0x1045b6['enforcementState']);return null;}['isProviderEnabled'](_0x2625ca){return this['getProviderEnforcementState'](_0x2625ca)==='ENFORCE'||this['getProviderEnforcementState'](_0x2625ca)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1801e2,_0x54b7ea){return Pe(_0x1801e2,'GET','/v2/recaptchaConfig',ke(_0x1801e2,_0x54b7ea));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x2741c,_0x26ac53){return Pe(_0x2741c,'POST','/v1/accounts:delete',_0x26ac53);}async function Pn(_0x3925dc,_0x5d39ef){return Pe(_0x3925dc,'POST','/v1/accounts:lookup',_0x5d39ef);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x8c38b6){if(_0x8c38b6)try{const _0x26cef4=new Date(Number(_0x8c38b6));if(!isNaN(_0x26cef4['getTime']()))return _0x26cef4['toUTCString']();}catch{}}async function Ef(_0x1e44dc,_0x2b283a=!0x1){const _0x340539=P(_0x1e44dc),_0x1f0b99=await _0x340539['getIdToken'](_0x2b283a),_0x201af9=Ts(_0x1f0b99);m(_0x201af9&&_0x201af9['exp']&&_0x201af9['auth_time']&&_0x201af9['iat'],_0x340539['auth'],'internal-error');const _0x45eae4=typeof _0x201af9['firebase']=='object'?_0x201af9['firebase']:void 0x0,_0x3adb7a=_0x45eae4==null?void 0x0:_0x45eae4['sign_in_provider'];return{'claims':_0x201af9,'token':_0x1f0b99,'authTime':Pt(fi(_0x201af9['auth_time'])),'issuedAtTime':Pt(fi(_0x201af9['iat'])),'expirationTime':Pt(fi(_0x201af9['exp'])),'signInProvider':_0x3adb7a||null,'signInSecondFactor':(_0x45eae4==null?void 0x0:_0x45eae4['sign_in_second_factor'])||null};}function fi(_0x222951){return Number(_0x222951)*0x3e8;}function Ts(_0x261cd7){const [_0x5a6e89,_0x3ca7bc,_0x376a02]=_0x261cd7['split']('.');if(_0x5a6e89===void 0x0||_0x3ca7bc===void 0x0||_0x376a02===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x28edba=fn(_0x3ca7bc);return _0x28edba?JSON['parse'](_0x28edba):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x35d3fa){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x35d3fa==null?void 0x0:_0x35d3fa['toString']()),null;}}function Cr(_0x28ddb8){const _0x1d654e=Ts(_0x28ddb8);return m(_0x1d654e,'internal-error'),m(typeof _0x1d654e['exp']<'u','internal-error'),m(typeof _0x1d654e['iat']<'u','internal-error'),Number(_0x1d654e['exp'])-Number(_0x1d654e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4ae0aa,_0x138c4a,_0x236034=!0x1){if(_0x236034)return _0x138c4a;try{return await _0x138c4a;}catch(_0x10f24c){throw _0x10f24c instanceof Re&&If(_0x10f24c)&&_0x4ae0aa['auth']['currentUser']===_0x4ae0aa&&await _0x4ae0aa['auth']['signOut'](),_0x10f24c;}}function If({code:_0x75e3c2}){return _0x75e3c2==='auth/user-disabled'||_0x75e3c2==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3b654d){this['user']=_0x3b654d,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4e1908){if(_0x4e1908){const _0x37bb2a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x37bb2a;}else{this['errorBackoff']=0x7530;const _0xf92af2=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xf92af2);}}['schedule'](_0x40066c=!0x1){if(!this['isRunning'])return;const _0x1da108=this['getInterval'](_0x40066c);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1da108);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x21f35d){(_0x21f35d==null?void 0x0:_0x21f35d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4d756a,_0x444453){this['createdAt']=_0x4d756a,this['lastLoginAt']=_0x444453,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x4ac5d7){this['createdAt']=_0x4ac5d7['createdAt'],this['lastLoginAt']=_0x4ac5d7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x240c76){var _0x2fb9f0;const _0x25f675=_0x240c76['auth'],_0x1f87ac=await _0x240c76['getIdToken'](),_0x201d04=await Ht(_0x240c76,Pn(_0x25f675,{'idToken':_0x1f87ac}));m(_0x201d04==null?void 0x0:_0x201d04['users']['length'],_0x25f675,'internal-error');const _0x255bf8=_0x201d04['users'][0x0];_0x240c76['_notifyReloadListener'](_0x255bf8);const _0x5f52da=(_0x2fb9f0=_0x255bf8['providerUserInfo'])!=null&&_0x2fb9f0['length']?Sa(_0x255bf8['providerUserInfo']):[],_0x3ddbe8=Tf(_0x240c76['providerData'],_0x5f52da),_0x210d34=_0x240c76['isAnonymous'],_0x4e318d=!(_0x240c76['email']&&_0x255bf8['passwordHash'])&&!(_0x3ddbe8!=null&&_0x3ddbe8['length']),_0x4b4a26=_0x210d34?_0x4e318d:!0x1,_0x57323f={'uid':_0x255bf8['localId'],'displayName':_0x255bf8['displayName']||null,'photoURL':_0x255bf8['photoUrl']||null,'email':_0x255bf8['email']||null,'emailVerified':_0x255bf8['emailVerified']||!0x1,'phoneNumber':_0x255bf8['phoneNumber']||null,'tenantId':_0x255bf8['tenantId']||null,'providerData':_0x3ddbe8,'metadata':new Li(_0x255bf8['createdAt'],_0x255bf8['lastLoginAt']),'isAnonymous':_0x4b4a26};Object['assign'](_0x240c76,_0x57323f);}async function Cf(_0xd8e583){const _0x24b2f7=P(_0xd8e583);await Nn(_0x24b2f7),await _0x24b2f7['auth']['_persistUserIfCurrent'](_0x24b2f7),_0x24b2f7['auth']['_notifyListenersIfCurrent'](_0x24b2f7);}function Tf(_0x45eb3a,_0x1dcc9d){return[..._0x45eb3a['filter'](_0x109bc2=>!_0x1dcc9d['some'](_0x3871e2=>_0x3871e2['providerId']===_0x109bc2['providerId'])),..._0x1dcc9d];}function Sa(_0xd68ffb){return _0xd68ffb['map'](({providerId:_0x4849c4,..._0xf86996})=>({'providerId':_0x4849c4,'uid':_0xf86996['rawId']||'','displayName':_0xf86996['displayName']||null,'email':_0xf86996['email']||null,'phoneNumber':_0xf86996['phoneNumber']||null,'photoURL':_0xf86996['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x1c96c9,_0xc2dc04){const _0x30536c=await Ca(_0x1c96c9,{},async()=>{const _0x313f90=ut({'grant_type':'refresh_token','refresh_token':_0xc2dc04})['slice'](0x1),{tokenApiHost:_0x1ac41a,apiKey:_0x28a183}=_0x1c96c9['config'],_0x184815=await Ta(_0x1c96c9,_0x1ac41a,'/v1/token','key='+_0x28a183),_0x179c65=await _0x1c96c9['_getAdditionalHeaders']();_0x179c65['Content-Type']='application/x-www-form-urlencoded';const _0x236dc2={'method':'POST','headers':_0x179c65,'body':_0x313f90};return _0x1c96c9['emulatorConfig']&&qt(_0x1c96c9['emulatorConfig']['host'])&&(_0x236dc2['credentials']='include'),wa['fetch']()(_0x184815,_0x236dc2);});return{'accessToken':_0x30536c['access_token'],'expiresIn':_0x30536c['expires_in'],'refreshToken':_0x30536c['refresh_token']};}async function bf(_0xfe60e4,_0x1db6ee){return Pe(_0xfe60e4,'POST','/v2/accounts:revokeToken',ke(_0xfe60e4,_0x1db6ee));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x55dc83){m(_0x55dc83['idToken'],'internal-error'),m(typeof _0x55dc83['idToken']<'u','internal-error'),m(typeof _0x55dc83['refreshToken']<'u','internal-error');const _0x4fc784='expiresIn'in _0x55dc83&&typeof _0x55dc83['expiresIn']<'u'?Number(_0x55dc83['expiresIn']):Cr(_0x55dc83['idToken']);this['updateTokensAndExpiration'](_0x55dc83['idToken'],_0x55dc83['refreshToken'],_0x4fc784);}['updateFromIdToken'](_0x424eea){m(_0x424eea['length']!==0x0,'internal-error');const _0x3c73c4=Cr(_0x424eea);this['updateTokensAndExpiration'](_0x424eea,null,_0x3c73c4);}async['getToken'](_0x4c40c7,_0x4c7744=!0x1){return!_0x4c7744&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4c40c7,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4c40c7,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xd8d832,_0x5b7844){const {accessToken:_0x3f3b67,refreshToken:_0x388edf,expiresIn:_0x45f258}=await Sf(_0xd8d832,_0x5b7844);this['updateTokensAndExpiration'](_0x3f3b67,_0x388edf,Number(_0x45f258));}['updateTokensAndExpiration'](_0x44815a,_0x165a01,_0x47ec9c){this['refreshToken']=_0x165a01||null,this['accessToken']=_0x44815a||null,this['expirationTime']=Date['now']()+_0x47ec9c*0x3e8;}static['fromJSON'](_0x5ee654,_0x425fa7){const {refreshToken:_0x35a3bf,accessToken:_0x1a32e8,expirationTime:_0x16e803}=_0x425fa7,_0x498b91=new et();return _0x35a3bf&&(m(typeof _0x35a3bf=='string','internal-error',{'appName':_0x5ee654}),_0x498b91['refreshToken']=_0x35a3bf),_0x1a32e8&&(m(typeof _0x1a32e8=='string','internal-error',{'appName':_0x5ee654}),_0x498b91['accessToken']=_0x1a32e8),_0x16e803&&(m(typeof _0x16e803=='number','internal-error',{'appName':_0x5ee654}),_0x498b91['expirationTime']=_0x16e803),_0x498b91;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x19fe8b){this['accessToken']=_0x19fe8b['accessToken'],this['refreshToken']=_0x19fe8b['refreshToken'],this['expirationTime']=_0x19fe8b['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2a6dc5,_0x228345){m(typeof _0x2a6dc5=='string'||typeof _0x2a6dc5>'u','internal-error',{'appName':_0x228345});}class j{constructor({uid:_0x11d4af,auth:_0x1d1349,stsTokenManager:_0x1a8417,..._0x5963c0}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x11d4af,this['auth']=_0x1d1349,this['stsTokenManager']=_0x1a8417,this['accessToken']=_0x1a8417['accessToken'],this['displayName']=_0x5963c0['displayName']||null,this['email']=_0x5963c0['email']||null,this['emailVerified']=_0x5963c0['emailVerified']||!0x1,this['phoneNumber']=_0x5963c0['phoneNumber']||null,this['photoURL']=_0x5963c0['photoURL']||null,this['isAnonymous']=_0x5963c0['isAnonymous']||!0x1,this['tenantId']=_0x5963c0['tenantId']||null,this['providerData']=_0x5963c0['providerData']?[..._0x5963c0['providerData']]:[],this['metadata']=new Li(_0x5963c0['createdAt']||void 0x0,_0x5963c0['lastLoginAt']||void 0x0);}async['getIdToken'](_0x154aff){const _0x14baa7=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x154aff));return m(_0x14baa7,this['auth'],'internal-error'),this['accessToken']!==_0x14baa7&&(this['accessToken']=_0x14baa7,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x14baa7;}['getIdTokenResult'](_0x37d252){return Ef(this,_0x37d252);}['reload'](){return Cf(this);}['_assign'](_0x242f11){this!==_0x242f11&&(m(this['uid']===_0x242f11['uid'],this['auth'],'internal-error'),this['displayName']=_0x242f11['displayName'],this['photoURL']=_0x242f11['photoURL'],this['email']=_0x242f11['email'],this['emailVerified']=_0x242f11['emailVerified'],this['phoneNumber']=_0x242f11['phoneNumber'],this['isAnonymous']=_0x242f11['isAnonymous'],this['tenantId']=_0x242f11['tenantId'],this['providerData']=_0x242f11['providerData']['map'](_0x21bad2=>({..._0x21bad2})),this['metadata']['_copy'](_0x242f11['metadata']),this['stsTokenManager']['_assign'](_0x242f11['stsTokenManager']));}['_clone'](_0x46f24a){const _0x3e3c2c=new j({...this,'auth':_0x46f24a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3e3c2c['metadata']['_copy'](this['metadata']),_0x3e3c2c;}['_onReload'](_0xe92736){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xe92736,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5d8981){this['reloadListener']?this['reloadListener'](_0x5d8981):this['reloadUserInfo']=_0x5d8981;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x4bc12c,_0x48bd7f=!0x1){let _0x1df176=!0x1;_0x4bc12c['idToken']&&_0x4bc12c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x4bc12c),_0x1df176=!0x0),_0x48bd7f&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1df176&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x6e8101=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x6e8101})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2c8875=>({..._0x2c8875})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2c53c8,_0x31a5d7){const _0xbc14c3=_0x31a5d7['displayName']??void 0x0,_0xf3ef27=_0x31a5d7['email']??void 0x0,_0x491a97=_0x31a5d7['phoneNumber']??void 0x0,_0x4587cb=_0x31a5d7['photoURL']??void 0x0,_0x53b2fa=_0x31a5d7['tenantId']??void 0x0,_0x118c01=_0x31a5d7['_redirectEventId']??void 0x0,_0x37cbfc=_0x31a5d7['createdAt']??void 0x0,_0x58bc32=_0x31a5d7['lastLoginAt']??void 0x0,{uid:_0x2e9c0,emailVerified:_0x2c5e47,isAnonymous:_0x51c3e3,providerData:_0x3f827e,stsTokenManager:_0x115140}=_0x31a5d7;m(_0x2e9c0&&_0x115140,_0x2c53c8,'internal-error');const _0x282d35=et['fromJSON'](this['name'],_0x115140);m(typeof _0x2e9c0=='string',_0x2c53c8,'internal-error'),le(_0xbc14c3,_0x2c53c8['name']),le(_0xf3ef27,_0x2c53c8['name']),m(typeof _0x2c5e47=='boolean',_0x2c53c8,'internal-error'),m(typeof _0x51c3e3=='boolean',_0x2c53c8,'internal-error'),le(_0x491a97,_0x2c53c8['name']),le(_0x4587cb,_0x2c53c8['name']),le(_0x53b2fa,_0x2c53c8['name']),le(_0x118c01,_0x2c53c8['name']),le(_0x37cbfc,_0x2c53c8['name']),le(_0x58bc32,_0x2c53c8['name']);const _0x23147d=new j({'uid':_0x2e9c0,'auth':_0x2c53c8,'email':_0xf3ef27,'emailVerified':_0x2c5e47,'displayName':_0xbc14c3,'isAnonymous':_0x51c3e3,'photoURL':_0x4587cb,'phoneNumber':_0x491a97,'tenantId':_0x53b2fa,'stsTokenManager':_0x282d35,'createdAt':_0x37cbfc,'lastLoginAt':_0x58bc32});return _0x3f827e&&Array['isArray'](_0x3f827e)&&(_0x23147d['providerData']=_0x3f827e['map'](_0x427df7=>({..._0x427df7}))),_0x118c01&&(_0x23147d['_redirectEventId']=_0x118c01),_0x23147d;}static async['_fromIdTokenResponse'](_0xbef3c2,_0x237c98,_0x26a02f=!0x1){const _0x260b60=new et();_0x260b60['updateFromServerResponse'](_0x237c98);const _0x34ec2e=new j({'uid':_0x237c98['localId'],'auth':_0xbef3c2,'stsTokenManager':_0x260b60,'isAnonymous':_0x26a02f});return await Nn(_0x34ec2e),_0x34ec2e;}static async['_fromGetAccountInfoResponse'](_0xa76089,_0x3e7e59,_0x9a6e0c){const _0x36f278=_0x3e7e59['users'][0x0];m(_0x36f278['localId']!==void 0x0,'internal-error');const _0x24618e=_0x36f278['providerUserInfo']!==void 0x0?Sa(_0x36f278['providerUserInfo']):[],_0x1dfae3=!(_0x36f278['email']&&_0x36f278['passwordHash'])&&!(_0x24618e!=null&&_0x24618e['length']),_0x592725=new et();_0x592725['updateFromIdToken'](_0x9a6e0c);const _0x18a240=new j({'uid':_0x36f278['localId'],'auth':_0xa76089,'stsTokenManager':_0x592725,'isAnonymous':_0x1dfae3}),_0x595a5e={'uid':_0x36f278['localId'],'displayName':_0x36f278['displayName']||null,'photoURL':_0x36f278['photoUrl']||null,'email':_0x36f278['email']||null,'emailVerified':_0x36f278['emailVerified']||!0x1,'phoneNumber':_0x36f278['phoneNumber']||null,'tenantId':_0x36f278['tenantId']||null,'providerData':_0x24618e,'metadata':new Li(_0x36f278['createdAt'],_0x36f278['lastLoginAt']),'isAnonymous':!(_0x36f278['email']&&_0x36f278['passwordHash'])&&!(_0x24618e!=null&&_0x24618e['length'])};return Object['assign'](_0x18a240,_0x595a5e),_0x18a240;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3de381){ce(_0x3de381 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x10c9c8=Tr['get'](_0x3de381);return _0x10c9c8?(ce(_0x10c9c8 instanceof _0x3de381,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x10c9c8):(_0x10c9c8=new _0x3de381(),Tr['set'](_0x3de381,_0x10c9c8),_0x10c9c8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2ad2b8,_0x8d64f2){this['storage'][_0x2ad2b8]=_0x8d64f2;}async['_get'](_0x4b1c99){const _0xa0a6ba=this['storage'][_0x4b1c99];return _0xa0a6ba===void 0x0?null:_0xa0a6ba;}async['_remove'](_0x37a6bf){delete this['storage'][_0x37a6bf];}['_addListener'](_0x3f4f62,_0x258435){}['_removeListener'](_0x4e9a25,_0xc712b5){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3790ec,_0x579d20,_0x18c1cb){return'firebase:'+_0x3790ec+':'+_0x579d20+':'+_0x18c1cb;}class tt{constructor(_0x34e78a,_0x7a4554,_0xd49712){this['persistence']=_0x34e78a,this['auth']=_0x7a4554,this['userKey']=_0xd49712;const {config:_0x55b521,name:_0x206e41}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x55b521['apiKey'],_0x206e41),this['fullPersistenceKey']=ln('persistence',_0x55b521['apiKey'],_0x206e41),this['boundEventHandler']=_0x7a4554['_onStorageEvent']['bind'](_0x7a4554),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x51cd56){return this['persistence']['_set'](this['fullUserKey'],_0x51cd56['toJSON']());}async['getCurrentUser'](){const _0x2082ad=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2082ad)return null;if(typeof _0x2082ad=='string'){const _0xe56226=await Pn(this['auth'],{'idToken':_0x2082ad})['catch'](()=>{});return _0xe56226?j['_fromGetAccountInfoResponse'](this['auth'],_0xe56226,_0x2082ad):null;}return j['_fromJSON'](this['auth'],_0x2082ad);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x360f5a){if(this['persistence']===_0x360f5a)return;const _0x2f8ffc=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x360f5a,_0x2f8ffc)return this['setCurrentUser'](_0x2f8ffc);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3bf89c,_0x339988,_0x1537d1='authUser'){if(!_0x339988['length'])return new tt(ie(Sr),_0x3bf89c,_0x1537d1);const _0x1a9b75=(await Promise['all'](_0x339988['map'](async _0x28cc09=>{if(await _0x28cc09['_isAvailable']())return _0x28cc09;})))['filter'](_0x5a2e6e=>_0x5a2e6e);let _0x11d6aa=_0x1a9b75[0x0]||ie(Sr);const _0x31235a=ln(_0x1537d1,_0x3bf89c['config']['apiKey'],_0x3bf89c['name']);let _0x3ec332=null;for(const _0x56e302 of _0x339988)try{const _0x2c2e72=await _0x56e302['_get'](_0x31235a);if(_0x2c2e72){let _0x3e9658;if(typeof _0x2c2e72=='string'){const _0x10a410=await Pn(_0x3bf89c,{'idToken':_0x2c2e72})['catch'](()=>{});if(!_0x10a410)break;_0x3e9658=await j['_fromGetAccountInfoResponse'](_0x3bf89c,_0x10a410,_0x2c2e72);}else _0x3e9658=j['_fromJSON'](_0x3bf89c,_0x2c2e72);_0x56e302!==_0x11d6aa&&(_0x3ec332=_0x3e9658),_0x11d6aa=_0x56e302;break;}}catch{}const _0x5e681e=_0x1a9b75['filter'](_0x299024=>_0x299024['_shouldAllowMigration']);return!_0x11d6aa['_shouldAllowMigration']||!_0x5e681e['length']?new tt(_0x11d6aa,_0x3bf89c,_0x1537d1):(_0x11d6aa=_0x5e681e[0x0],_0x3ec332&&await _0x11d6aa['_set'](_0x31235a,_0x3ec332['toJSON']()),await Promise['all'](_0x339988['map'](async _0x2b2dff=>{if(_0x2b2dff!==_0x11d6aa)try{await _0x2b2dff['_remove'](_0x31235a);}catch{}})),new tt(_0x11d6aa,_0x3bf89c,_0x1537d1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2d42cd){const _0x508836=_0x2d42cd['toLowerCase']();if(_0x508836['includes']('opera/')||_0x508836['includes']('opr/')||_0x508836['includes']('opios/'))return'Opera';if(Pa(_0x508836))return'IEMobile';if(_0x508836['includes']('msie')||_0x508836['includes']('trident/'))return'IE';if(_0x508836['includes']('edge/'))return'Edge';if(Ra(_0x508836))return'Firefox';if(_0x508836['includes']('silk/'))return'Silk';if(Oa(_0x508836))return'Blackberry';if(Da(_0x508836))return'Webos';if(Aa(_0x508836))return'Safari';if((_0x508836['includes']('chrome/')||ka(_0x508836))&&!_0x508836['includes']('edge/'))return'Chrome';if(Na(_0x508836))return'Android';{const _0x645ffb=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xa26a1f=_0x2d42cd['match'](_0x645ffb);if((_0xa26a1f==null?void 0x0:_0xa26a1f['length'])===0x2)return _0xa26a1f[0x1];}return'Other';}function Ra(_0x48d805=W()){return/firefox\//i['test'](_0x48d805);}function Aa(_0x45b314=W()){const _0x39dca2=_0x45b314['toLowerCase']();return _0x39dca2['includes']('safari/')&&!_0x39dca2['includes']('chrome/')&&!_0x39dca2['includes']('crios/')&&!_0x39dca2['includes']('android');}function ka(_0x9c5d8=W()){return/crios\//i['test'](_0x9c5d8);}function Pa(_0x2785e2=W()){return/iemobile/i['test'](_0x2785e2);}function Na(_0x114283=W()){return/android/i['test'](_0x114283);}function Oa(_0x46a617=W()){return/blackberry/i['test'](_0x46a617);}function Da(_0x5d6c10=W()){return/webos/i['test'](_0x5d6c10);}function Ss(_0x29d6aa=W()){return/iphone|ipad|ipod/i['test'](_0x29d6aa)||/macintosh/i['test'](_0x29d6aa)&&/mobile/i['test'](_0x29d6aa);}function Rf(_0x4cafce=W()){var _0x40beb2;return Ss(_0x4cafce)&&!!((_0x40beb2=window['navigator'])!=null&&_0x40beb2['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x4f9ca5=W()){return Ss(_0x4f9ca5)||Na(_0x4f9ca5)||Da(_0x4f9ca5)||Oa(_0x4f9ca5)||/windows phone/i['test'](_0x4f9ca5)||Pa(_0x4f9ca5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x17d6b9,_0x4d043c=[]){let _0xbb9622;switch(_0x17d6b9){case'Browser':_0xbb9622=br(W());break;case'Worker':_0xbb9622=br(W())+'-'+_0x17d6b9;break;default:_0xbb9622=_0x17d6b9;}const _0x5871bc=_0x4d043c['length']?_0x4d043c['join'](','):'FirebaseCore-web';return _0xbb9622+'/JsCore/'+dt+'/'+_0x5871bc;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x299b1f){this['auth']=_0x299b1f,this['queue']=[];}['pushCallback'](_0x3f3e61,_0x29f670){const _0x2b82ba=_0x9d3de8=>new Promise((_0x405b67,_0x248631)=>{try{const _0x5d1ffc=_0x3f3e61(_0x9d3de8);_0x405b67(_0x5d1ffc);}catch(_0x5e8dac){_0x248631(_0x5e8dac);}});_0x2b82ba['onAbort']=_0x29f670,this['queue']['push'](_0x2b82ba);const _0x21ed6c=this['queue']['length']-0x1;return()=>{this['queue'][_0x21ed6c]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5dc1e7){if(this['auth']['currentUser']===_0x5dc1e7)return;const _0x420258=[];try{for(const _0x1126c6 of this['queue'])await _0x1126c6(_0x5dc1e7),_0x1126c6['onAbort']&&_0x420258['push'](_0x1126c6['onAbort']);}catch(_0x4c23bc){_0x420258['reverse']();for(const _0x4e4c82 of _0x420258)try{_0x4e4c82();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x4c23bc==null?void 0x0:_0x4c23bc['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x9ecaa2,_0x474eb8={}){return Pe(_0x9ecaa2,'GET','/v2/passwordPolicy',ke(_0x9ecaa2,_0x474eb8));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x4f78d1){var _0x3c4f88;const _0x36f9ab=_0x4f78d1['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x36f9ab['minPasswordLength']??Nf,_0x36f9ab['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x36f9ab['maxPasswordLength']),_0x36f9ab['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x36f9ab['containsLowercaseCharacter']),_0x36f9ab['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x36f9ab['containsUppercaseCharacter']),_0x36f9ab['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x36f9ab['containsNumericCharacter']),_0x36f9ab['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x36f9ab['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4f78d1['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3c4f88=_0x4f78d1['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3c4f88['join'](''))??'',this['forceUpgradeOnSignin']=_0x4f78d1['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4f78d1['schemaVersion'];}['validatePassword'](_0x583150){const _0x4c459e={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x583150,_0x4c459e),this['validatePasswordCharacterOptions'](_0x583150,_0x4c459e),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['meetsMinPasswordLength']??!0x0),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['meetsMaxPasswordLength']??!0x0),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['containsLowercaseLetter']??!0x0),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['containsUppercaseLetter']??!0x0),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['containsNumericCharacter']??!0x0),_0x4c459e['isValid']&&(_0x4c459e['isValid']=_0x4c459e['containsNonAlphanumericCharacter']??!0x0),_0x4c459e;}['validatePasswordLengthOptions'](_0x390377,_0x14eb97){const _0x3002e8=this['customStrengthOptions']['minPasswordLength'],_0x110d37=this['customStrengthOptions']['maxPasswordLength'];_0x3002e8&&(_0x14eb97['meetsMinPasswordLength']=_0x390377['length']>=_0x3002e8),_0x110d37&&(_0x14eb97['meetsMaxPasswordLength']=_0x390377['length']<=_0x110d37);}['validatePasswordCharacterOptions'](_0x541c69,_0x45728d){this['updatePasswordCharacterOptionsStatuses'](_0x45728d,!0x1,!0x1,!0x1,!0x1);let _0x1eda1c;for(let _0x5f4837=0x0;_0x5f4837<_0x541c69['length'];_0x5f4837++)_0x1eda1c=_0x541c69['charAt'](_0x5f4837),this['updatePasswordCharacterOptionsStatuses'](_0x45728d,_0x1eda1c>='a'&&_0x1eda1c<='z',_0x1eda1c>='A'&&_0x1eda1c<='Z',_0x1eda1c>='0'&&_0x1eda1c<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1eda1c));}['updatePasswordCharacterOptionsStatuses'](_0x5591be,_0x291008,_0x1f4106,_0x103d71,_0x1e181b){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5591be['containsLowercaseLetter']||(_0x5591be['containsLowercaseLetter']=_0x291008)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5591be['containsUppercaseLetter']||(_0x5591be['containsUppercaseLetter']=_0x1f4106)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5591be['containsNumericCharacter']||(_0x5591be['containsNumericCharacter']=_0x103d71)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5591be['containsNonAlphanumericCharacter']||(_0x5591be['containsNonAlphanumericCharacter']=_0x1e181b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x183555,_0xc82224,_0x4be70e,_0x1ab6d1){this['app']=_0x183555,this['heartbeatServiceProvider']=_0xc82224,this['appCheckServiceProvider']=_0x4be70e,this['config']=_0x1ab6d1,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x183555['name'],this['clientVersion']=_0x1ab6d1['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x16623f=>this['_resolvePersistenceManagerAvailable']=_0x16623f);}['_initializeWithPersistence'](_0x352ea5,_0x463a3b){return _0x463a3b&&(this['_popupRedirectResolver']=ie(_0x463a3b)),this['_initializationPromise']=this['queue'](async()=>{var _0x3d071a,_0x3a08e9,_0x3567f9;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x352ea5),(_0x3d071a=this['_resolvePersistenceManagerAvailable'])==null||_0x3d071a['call'](this),!this['_deleted'])){if((_0x3a08e9=this['_popupRedirectResolver'])!=null&&_0x3a08e9['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x463a3b),this['lastNotifiedUid']=((_0x3567f9=this['currentUser'])==null?void 0x0:_0x3567f9['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3094ca=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3094ca)){if(this['currentUser']&&_0x3094ca&&this['currentUser']['uid']===_0x3094ca['uid']){this['_currentUser']['_assign'](_0x3094ca),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3094ca,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3e7bde){try{const _0x5df816=await Pn(this,{'idToken':_0x3e7bde}),_0x22b5d2=await j['_fromGetAccountInfoResponse'](this,_0x5df816,_0x3e7bde);await this['directlySetCurrentUser'](_0x22b5d2);}catch(_0x370b28){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x370b28),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5337f9){var _0x3cb31c;if($(this['app'])){const _0x3f8512=this['app']['settings']['authIdToken'];return _0x3f8512?new Promise(_0x1809c4=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3f8512)['then'](_0x1809c4,_0x1809c4));}):this['directlySetCurrentUser'](null);}const _0x4cab21=await this['assertedPersistence']['getCurrentUser']();let _0x4a94f5=_0x4cab21,_0x238e5a=!0x1;if(_0x5337f9&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x20e555=(_0x3cb31c=this['redirectUser'])==null?void 0x0:_0x3cb31c['_redirectEventId'],_0x3fc4ef=_0x4a94f5==null?void 0x0:_0x4a94f5['_redirectEventId'],_0x3f000f=await this['tryRedirectSignIn'](_0x5337f9);(!_0x20e555||_0x20e555===_0x3fc4ef)&&(_0x3f000f!=null&&_0x3f000f['user'])&&(_0x4a94f5=_0x3f000f['user'],_0x238e5a=!0x0);}if(!_0x4a94f5)return this['directlySetCurrentUser'](null);if(!_0x4a94f5['_redirectEventId']){if(_0x238e5a)try{await this['beforeStateQueue']['runMiddleware'](_0x4a94f5);}catch(_0x4a064a){_0x4a94f5=_0x4cab21,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4a064a));}return _0x4a94f5?this['reloadAndSetCurrentUserOrClear'](_0x4a94f5):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4a94f5['_redirectEventId']?this['directlySetCurrentUser'](_0x4a94f5):this['reloadAndSetCurrentUserOrClear'](_0x4a94f5);}async['tryRedirectSignIn'](_0x2daf98){let _0x5c72bc=null;try{_0x5c72bc=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2daf98,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5c72bc;}async['reloadAndSetCurrentUserOrClear'](_0x2e999b){try{await Nn(_0x2e999b);}catch(_0x314947){if((_0x314947==null?void 0x0:_0x314947['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2e999b);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2bfb32){if($(this['app']))return Promise['reject'](re(this));const _0xceef99=_0x2bfb32?P(_0x2bfb32):null;return _0xceef99&&m(_0xceef99['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xceef99&&_0xceef99['_clone'](this));}async['_updateCurrentUser'](_0x15b72c,_0x3c449b=!0x1){if(!this['_deleted'])return _0x15b72c&&m(this['tenantId']===_0x15b72c['tenantId'],this,'tenant-id-mismatch'),_0x3c449b||await this['beforeStateQueue']['runMiddleware'](_0x15b72c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x15b72c),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3936a4){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3936a4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x223734){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x14775c=this['_getPasswordPolicyInternal']();return _0x14775c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x14775c['validatePassword'](_0x223734);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2bfab6=await Pf(this),_0x98e139=new Of(_0x2bfab6);this['tenantId']===null?this['_projectPasswordPolicy']=_0x98e139:this['_tenantPasswordPolicies'][this['tenantId']]=_0x98e139;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2902fb){this['_errorFactory']=new Gt('auth','Firebase',_0x2902fb());}['onAuthStateChanged'](_0x2317c8,_0x235aea,_0x39105a){return this['registerStateListener'](this['authStateSubscription'],_0x2317c8,_0x235aea,_0x39105a);}['beforeAuthStateChanged'](_0x48127e,_0x13e1d5){return this['beforeStateQueue']['pushCallback'](_0x48127e,_0x13e1d5);}['onIdTokenChanged'](_0x513f5e,_0x568edb,_0x497236){return this['registerStateListener'](this['idTokenSubscription'],_0x513f5e,_0x568edb,_0x497236);}['authStateReady'](){return new Promise((_0x13496b,_0x46a833)=>{if(this['currentUser'])_0x13496b();else{const _0x302015=this['onAuthStateChanged'](()=>{_0x302015(),_0x13496b();},_0x46a833);}});}async['revokeAccessToken'](_0x27f48e){if(this['currentUser']){const _0x256354=await this['currentUser']['getIdToken'](),_0x541b1b={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x27f48e,'idToken':_0x256354};this['tenantId']!=null&&(_0x541b1b['tenantId']=this['tenantId']),await bf(this,_0x541b1b);}}['toJSON'](){var _0x60cb8f;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x60cb8f=this['_currentUser'])==null?void 0x0:_0x60cb8f['toJSON']()};}async['_setRedirectUser'](_0x522b75,_0x43530c){const _0x37b35f=await this['getOrInitRedirectPersistenceManager'](_0x43530c);return _0x522b75===null?_0x37b35f['removeCurrentUser']():_0x37b35f['setCurrentUser'](_0x522b75);}async['getOrInitRedirectPersistenceManager'](_0x202219){if(!this['redirectPersistenceManager']){const _0x574cbe=_0x202219&&ie(_0x202219)||this['_popupRedirectResolver'];m(_0x574cbe,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x574cbe['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x15a309){var _0x14734c,_0x3b4908;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x14734c=this['_currentUser'])==null?void 0x0:_0x14734c['_redirectEventId'])===_0x15a309?this['_currentUser']:((_0x3b4908=this['redirectUser'])==null?void 0x0:_0x3b4908['_redirectEventId'])===_0x15a309?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x530b33){if(_0x530b33===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x530b33));}['_notifyListenersIfCurrent'](_0x157645){_0x157645===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3d25ba;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x438480=((_0x3d25ba=this['currentUser'])==null?void 0x0:_0x3d25ba['uid'])??null;this['lastNotifiedUid']!==_0x438480&&(this['lastNotifiedUid']=_0x438480,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x82003b,_0x3fe67f,_0x376410,_0x3c8db6){if(this['_deleted'])return()=>{};const _0x572a73=typeof _0x3fe67f=='function'?_0x3fe67f:_0x3fe67f['next']['bind'](_0x3fe67f);let _0x4fc74e=!0x1;const _0x45aeec=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x45aeec,this,'internal-error'),_0x45aeec['then'](()=>{_0x4fc74e||_0x572a73(this['currentUser']);}),typeof _0x3fe67f=='function'){const _0x4a5c49=_0x82003b['addObserver'](_0x3fe67f,_0x376410,_0x3c8db6);return()=>{_0x4fc74e=!0x0,_0x4a5c49();};}else{const _0x56cafc=_0x82003b['addObserver'](_0x3fe67f);return()=>{_0x4fc74e=!0x0,_0x56cafc();};}}async['directlySetCurrentUser'](_0xa2f029){this['currentUser']&&this['currentUser']!==_0xa2f029&&this['_currentUser']['_stopProactiveRefresh'](),_0xa2f029&&this['isProactiveRefreshEnabled']&&_0xa2f029['_startProactiveRefresh'](),this['currentUser']=_0xa2f029,_0xa2f029?await this['assertedPersistence']['setCurrentUser'](_0xa2f029):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5e9d1a){return this['operations']=this['operations']['then'](_0x5e9d1a,_0x5e9d1a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x312373){!_0x312373||this['frameworks']['includes'](_0x312373)||(this['frameworks']['push'](_0x312373),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5cc92d;const _0x1d630e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1d630e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x295474=await((_0x5cc92d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5cc92d['getHeartbeatsHeader']());_0x295474&&(_0x1d630e['X-Firebase-Client']=_0x295474);const _0x1669e9=await this['_getAppCheckToken']();return _0x1669e9&&(_0x1d630e['X-Firebase-AppCheck']=_0x1669e9),_0x1d630e;}async['_getAppCheckToken'](){var _0x541a13;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2f8b6e=await((_0x541a13=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x541a13['getToken']());return _0x2f8b6e!=null&&_0x2f8b6e['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2f8b6e['error']),_0x2f8b6e==null?void 0x0:_0x2f8b6e['token'];}}function Ke(_0x313ab2){return P(_0x313ab2);}class Rr{constructor(_0x52174c){this['auth']=_0x52174c,this['observer']=null,this['addObserver']=Tc(_0x18f5af=>this['observer']=_0x18f5af);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2fe9d6){Jn=_0x2fe9d6;}function xa(_0x2dfe7f){return Jn['loadJS'](_0x2dfe7f);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x4bd973){return'__'+_0x4bd973+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x7a1216){_0x7a1216();}['execute'](_0x409b9e,_0x2b3166){return Promise['resolve']('token');}['render'](_0x234d43,_0x138d4a){return'';}}class Wf{['ready'](_0x6f9090){_0x6f9090();}['execute'](_0x552a57,_0x3f7b35){return Promise['resolve']('token');}['render'](_0x5547cc,_0x4a814f){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x341546){this['type']=Bf,this['auth']=Ke(_0x341546);}async['verify'](_0x3d674c='verify',_0x1a6398=!0x1){async function _0x1d447d(_0x463dda){if(!_0x1a6398){if(_0x463dda['tenantId']==null&&_0x463dda['_agentRecaptchaConfig']!=null)return _0x463dda['_agentRecaptchaConfig']['siteKey'];if(_0x463dda['tenantId']!=null&&_0x463dda['_tenantRecaptchaConfigs'][_0x463dda['tenantId']]!==void 0x0)return _0x463dda['_tenantRecaptchaConfigs'][_0x463dda['tenantId']]['siteKey'];}return new Promise(async(_0x3c8461,_0x27364a)=>{yf(_0x463dda,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xb48183=>{if(_0xb48183['recaptchaKey']===void 0x0)_0x27364a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2c3633=new mf(_0xb48183);return _0x463dda['tenantId']==null?_0x463dda['_agentRecaptchaConfig']=_0x2c3633:_0x463dda['_tenantRecaptchaConfigs'][_0x463dda['tenantId']]=_0x2c3633,_0x3c8461(_0x2c3633['siteKey']);}})['catch'](_0x129e52=>{_0x27364a(_0x129e52);});});}function _0x3744e3(_0x34de51,_0x2ca37b,_0x58016e){const _0x26e25a=window['grecaptcha'];wr(_0x26e25a)?_0x26e25a['enterprise']['ready'](()=>{_0x26e25a['enterprise']['execute'](_0x34de51,{'action':_0x3d674c})['then'](_0x17b224=>{_0x2ca37b(_0x17b224);})['catch'](()=>{_0x2ca37b(Fa);});}):_0x58016e(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3db79f,_0x482980)=>{_0x1d447d(this['auth'])['then'](async _0x1154e6=>{if(!_0x1a6398&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x3744e3(_0x1154e6,_0x3db79f,_0x482980);else{if(typeof window>'u'){_0x482980(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1207c2=Lf();_0x1207c2['length']!==0x0&&(_0x1207c2+=_0x1154e6+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x38b9d5;(_0x38b9d5=he['scriptInjectionDeferred'])==null||_0x38b9d5['resolve']();},xa(_0x1207c2)['then'](()=>{var _0x4a4992;return(_0x4a4992=he['scriptInjectionDeferred'])==null?void 0x0:_0x4a4992['promise'];})['then'](()=>{_0x3744e3(_0x1154e6,_0x3db79f,_0x482980);})['catch'](_0x4e955a=>{_0x482980(_0x4e955a);});}})['catch'](_0x4ced35=>{_0x482980(_0x4ced35);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x2a46f3,_0x316cf8,_0x582583,_0x3fe98d=!0x1,_0x57f32e=!0x1){const _0x4f7d5d=new he(_0x2a46f3);let _0xec586c;if(_0x57f32e)_0xec586c=Fa;else try{_0xec586c=await _0x4f7d5d['verify'](_0x582583);}catch{_0xec586c=await _0x4f7d5d['verify'](_0x582583,!0x0);}const _0x505fd1={..._0x316cf8};if(_0x582583==='mfaSmsEnrollment'||_0x582583==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x505fd1){const _0x4fd68b=_0x505fd1['phoneEnrollmentInfo']['phoneNumber'],_0x2dcad8=_0x505fd1['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x505fd1,{'phoneEnrollmentInfo':{'phoneNumber':_0x4fd68b,'recaptchaToken':_0x2dcad8,'captchaResponse':_0xec586c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x505fd1){const _0x1df60f=_0x505fd1['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x505fd1,{'phoneSignInInfo':{'recaptchaToken':_0x1df60f,'captchaResponse':_0xec586c,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x505fd1;}return _0x3fe98d?Object['assign'](_0x505fd1,{'captchaResp':_0xec586c}):Object['assign'](_0x505fd1,{'captchaResponse':_0xec586c}),Object['assign'](_0x505fd1,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x505fd1,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x505fd1;}async function xi(_0x44f95d,_0x101bdc,_0x4e8972,_0x48a401,_0x1c2db){var _0x5119d0;if((_0x5119d0=_0x44f95d['_getRecaptchaConfig']())!=null&&_0x5119d0['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3e889e=await kr(_0x44f95d,_0x101bdc,_0x4e8972,_0x4e8972==='getOobCode');return _0x48a401(_0x44f95d,_0x3e889e);}else return _0x48a401(_0x44f95d,_0x101bdc)['catch'](async _0x2e15e8=>{if(_0x2e15e8['code']==='auth/missing-recaptcha-token'){console['log'](_0x4e8972+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3f57a2=await kr(_0x44f95d,_0x101bdc,_0x4e8972,_0x4e8972==='getOobCode');return _0x48a401(_0x44f95d,_0x3f57a2);}else return Promise['reject'](_0x2e15e8);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0xf4b715,_0x546abc){const _0x1ece65=Hi(_0xf4b715,'auth');if(_0x1ece65['isInitialized']()){const _0x3a58ce=_0x1ece65['getImmediate'](),_0x3480db=_0x1ece65['getOptions']();if(xe(_0x3480db,_0x546abc??{}))return _0x3a58ce;Y(_0x3a58ce,'already-initialized');}return _0x1ece65['initialize']({'options':_0x546abc});}function Hf(_0x528b4b,_0x4cd080){const _0x5d31d0=(_0x4cd080==null?void 0x0:_0x4cd080['persistence'])||[],_0x36875d=(Array['isArray'](_0x5d31d0)?_0x5d31d0:[_0x5d31d0])['map'](ie);_0x4cd080!=null&&_0x4cd080['errorMap']&&_0x528b4b['_updateErrorMap'](_0x4cd080['errorMap']),_0x528b4b['_initializeWithPersistence'](_0x36875d,_0x4cd080==null?void 0x0:_0x4cd080['popupRedirectResolver']);}function $f(_0xab648e,_0x465654,_0x126e06){const _0x40b320=Ke(_0xab648e);m(/^https?:\/\//['test'](_0x465654),_0x40b320,'invalid-emulator-scheme');const _0x5b3eea=!0x1,_0x1813e1=Ua(_0x465654),{host:_0x3028da,port:_0x5882ed}=Gf(_0x465654),_0x51cf82=_0x5882ed===null?'':':'+_0x5882ed,_0x37c37c={'url':_0x1813e1+'//'+_0x3028da+_0x51cf82+'/'},_0x3fa13b=Object['freeze']({'host':_0x3028da,'port':_0x5882ed,'protocol':_0x1813e1['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5b3eea})});if(!_0x40b320['_canInitEmulator']){m(_0x40b320['config']['emulator']&&_0x40b320['emulatorConfig'],_0x40b320,'emulator-config-failed'),m(xe(_0x37c37c,_0x40b320['config']['emulator'])&&xe(_0x3fa13b,_0x40b320['emulatorConfig']),_0x40b320,'emulator-config-failed');return;}_0x40b320['config']['emulator']=_0x37c37c,_0x40b320['emulatorConfig']=_0x3fa13b,_0x40b320['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x3028da)?Qr(_0x1813e1+'//'+_0x3028da+_0x51cf82):qf();}function Ua(_0x1720bb){const _0x16dd79=_0x1720bb['indexOf'](':');return _0x16dd79<0x0?'':_0x1720bb['substr'](0x0,_0x16dd79+0x1);}function Gf(_0x3cfed0){const _0x7047e0=Ua(_0x3cfed0),_0x1ed3e8=/(\/\/)?([^?#/]+)/['exec'](_0x3cfed0['substr'](_0x7047e0['length']));if(!_0x1ed3e8)return{'host':'','port':null};const _0x10d97f=_0x1ed3e8[0x2]['split']('@')['pop']()||'',_0x3c4e14=/^(\[[^\]]+\])(:|$)/['exec'](_0x10d97f);if(_0x3c4e14){const _0x5cbde3=_0x3c4e14[0x1];return{'host':_0x5cbde3,'port':Pr(_0x10d97f['substr'](_0x5cbde3['length']+0x1))};}else{const [_0x199b99,_0x42004f]=_0x10d97f['split'](':');return{'host':_0x199b99,'port':Pr(_0x42004f)};}}function Pr(_0x29cd7d){if(!_0x29cd7d)return null;const _0x48df20=Number(_0x29cd7d);return isNaN(_0x48df20)?null:_0x48df20;}function qf(){function _0xb788d1(){const _0x3b9ec3=document['createElement']('p'),_0xf5d424=_0x3b9ec3['style'];_0x3b9ec3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xf5d424['position']='fixed',_0xf5d424['width']='100%',_0xf5d424['backgroundColor']='#ffffff',_0xf5d424['border']='.1em\x20solid\x20#000000',_0xf5d424['color']='#b50000',_0xf5d424['bottom']='0px',_0xf5d424['left']='0px',_0xf5d424['margin']='0px',_0xf5d424['zIndex']='10000',_0xf5d424['textAlign']='center',_0x3b9ec3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3b9ec3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xb788d1):_0xb788d1());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x34ffee,_0x5d6884){this['providerId']=_0x34ffee,this['signInMethod']=_0x5d6884;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4952cf){return ne('not\x20implemented');}['_linkToIdToken'](_0x7d88eb,_0x4a8b88){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2f3be7){return ne('not\x20implemented');}}async function zf(_0x9db686,_0x6de6f6){return Pe(_0x9db686,'POST','/v1/accounts:signUp',_0x6de6f6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0xd78d78,_0x3d6989){return en(_0xd78d78,'POST','/v1/accounts:signInWithPassword',ke(_0xd78d78,_0x3d6989));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x55c56f,_0x3f949f){return en(_0x55c56f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x55c56f,_0x3f949f));}async function Yf(_0x3dd73a,_0x4fd77d){return en(_0x3dd73a,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3dd73a,_0x4fd77d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x3113fc,_0x110174,_0x43d8c1,_0x35fbb3=null){super('password',_0x43d8c1),this['_email']=_0x3113fc,this['_password']=_0x110174,this['_tenantId']=_0x35fbb3;}static['_fromEmailAndPassword'](_0x2df450,_0x4825d3){return new $t(_0x2df450,_0x4825d3,'password');}static['_fromEmailAndCode'](_0x725a51,_0x49ad58,_0x306265=null){return new $t(_0x725a51,_0x49ad58,'emailLink',_0x306265);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x52a42d){const _0x5590c7=typeof _0x52a42d=='string'?JSON['parse'](_0x52a42d):_0x52a42d;if(_0x5590c7!=null&&_0x5590c7['email']&&(_0x5590c7!=null&&_0x5590c7['password'])){if(_0x5590c7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5590c7['email'],_0x5590c7['password']);if(_0x5590c7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5590c7['email'],_0x5590c7['password'],_0x5590c7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2ce92b){switch(this['signInMethod']){case'password':const _0x27d6e4={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2ce92b,_0x27d6e4,'signInWithPassword',jf);case'emailLink':return Kf(_0x2ce92b,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2ce92b,'internal-error');}}async['_linkToIdToken'](_0x2b8669,_0x1066a5){switch(this['signInMethod']){case'password':const _0x4bd3a6={'idToken':_0x1066a5,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2b8669,_0x4bd3a6,'signUpPassword',zf);case'emailLink':return Yf(_0x2b8669,{'idToken':_0x1066a5,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2b8669,'internal-error');}}['_getReauthenticationResolver'](_0x2992f4){return this['_getIdTokenResponse'](_0x2992f4);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x5a420f,_0x36df41){return en(_0x5a420f,'POST','/v1/accounts:signInWithIdp',ke(_0x5a420f,_0x36df41));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0xcfbd84){const _0x7bc56d=new $e(_0xcfbd84['providerId'],_0xcfbd84['signInMethod']);return _0xcfbd84['idToken']||_0xcfbd84['accessToken']?(_0xcfbd84['idToken']&&(_0x7bc56d['idToken']=_0xcfbd84['idToken']),_0xcfbd84['accessToken']&&(_0x7bc56d['accessToken']=_0xcfbd84['accessToken']),_0xcfbd84['nonce']&&!_0xcfbd84['pendingToken']&&(_0x7bc56d['nonce']=_0xcfbd84['nonce']),_0xcfbd84['pendingToken']&&(_0x7bc56d['pendingToken']=_0xcfbd84['pendingToken'])):_0xcfbd84['oauthToken']&&_0xcfbd84['oauthTokenSecret']?(_0x7bc56d['accessToken']=_0xcfbd84['oauthToken'],_0x7bc56d['secret']=_0xcfbd84['oauthTokenSecret']):Y('argument-error'),_0x7bc56d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xca8bc){const _0x4c2865=typeof _0xca8bc=='string'?JSON['parse'](_0xca8bc):_0xca8bc,{providerId:_0x5e13c5,signInMethod:_0xf28196,..._0x2c0dd6}=_0x4c2865;if(!_0x5e13c5||!_0xf28196)return null;const _0x5b38a7=new $e(_0x5e13c5,_0xf28196);return _0x5b38a7['idToken']=_0x2c0dd6['idToken']||void 0x0,_0x5b38a7['accessToken']=_0x2c0dd6['accessToken']||void 0x0,_0x5b38a7['secret']=_0x2c0dd6['secret'],_0x5b38a7['nonce']=_0x2c0dd6['nonce'],_0x5b38a7['pendingToken']=_0x2c0dd6['pendingToken']||null,_0x5b38a7;}['_getIdTokenResponse'](_0x1cce82){const _0x3d971d=this['buildRequest']();return nt(_0x1cce82,_0x3d971d);}['_linkToIdToken'](_0x298a5c,_0x2fc760){const _0xd643ca=this['buildRequest']();return _0xd643ca['idToken']=_0x2fc760,nt(_0x298a5c,_0xd643ca);}['_getReauthenticationResolver'](_0x251813){const _0x45f4de=this['buildRequest']();return _0x45f4de['autoCreate']=!0x1,nt(_0x251813,_0x45f4de);}['buildRequest'](){const _0x4d479c={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x4d479c['pendingToken']=this['pendingToken'];else{const _0x56f40d={};this['idToken']&&(_0x56f40d['id_token']=this['idToken']),this['accessToken']&&(_0x56f40d['access_token']=this['accessToken']),this['secret']&&(_0x56f40d['oauth_token_secret']=this['secret']),_0x56f40d['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x56f40d['nonce']=this['nonce']),_0x4d479c['postBody']=ut(_0x56f40d);}return _0x4d479c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x542a66){switch(_0x542a66){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x227315){const _0x1ccf88=Ct(Tt(_0x227315))['link'],_0x2a79eb=_0x1ccf88?Ct(Tt(_0x1ccf88))['deep_link_id']:null,_0x16a855=Ct(Tt(_0x227315))['deep_link_id'];return(_0x16a855?Ct(Tt(_0x16a855))['link']:null)||_0x16a855||_0x2a79eb||_0x1ccf88||_0x227315;}class Rs{constructor(_0x3d4487){const _0xf9c3e6=Ct(Tt(_0x3d4487)),_0x530853=_0xf9c3e6['apiKey']??null,_0x568636=_0xf9c3e6['oobCode']??null,_0x31bf00=Jf(_0xf9c3e6['mode']??null);m(_0x530853&&_0x568636&&_0x31bf00,'argument-error'),this['apiKey']=_0x530853,this['operation']=_0x31bf00,this['code']=_0x568636,this['continueUrl']=_0xf9c3e6['continueUrl']??null,this['languageCode']=_0xf9c3e6['lang']??null,this['tenantId']=_0xf9c3e6['tenantId']??null;}static['parseLink'](_0x49533a){const _0x55d1e2=Xf(_0x49533a);try{return new Rs(_0x55d1e2);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x389cbb,_0x7dd453){return $t['_fromEmailAndPassword'](_0x389cbb,_0x7dd453);}static['credentialWithLink'](_0x32180b,_0x2eac8f){const _0x4c8f28=Rs['parseLink'](_0x2eac8f);return m(_0x4c8f28,'argument-error'),$t['_fromEmailAndCode'](_0x32180b,_0x4c8f28['code'],_0x4c8f28['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x483e53){this['providerId']=_0x483e53,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0xae0fff){this['defaultLanguageCode']=_0xae0fff;}['setCustomParameters'](_0x3a46b4){return this['customParameters']=_0x3a46b4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x316d90){return this['scopes']['includes'](_0x316d90)||this['scopes']['push'](_0x316d90),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0xe05aef){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xe05aef});}static['credentialFromResult'](_0x333ac1){return ue['credentialFromTaggedObject'](_0x333ac1);}static['credentialFromError'](_0x180333){return ue['credentialFromTaggedObject'](_0x180333['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x168810}){if(!_0x168810||!('oauthAccessToken'in _0x168810)||!_0x168810['oauthAccessToken'])return null;try{return ue['credential'](_0x168810['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xefa97b,_0x2ebe28){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xefa97b,'accessToken':_0x2ebe28});}static['credentialFromResult'](_0x2e0f5e){return de['credentialFromTaggedObject'](_0x2e0f5e);}static['credentialFromError'](_0x4b7c99){return de['credentialFromTaggedObject'](_0x4b7c99['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x438d94}){if(!_0x438d94)return null;const {oauthIdToken:_0x112f5d,oauthAccessToken:_0x6573b9}=_0x438d94;if(!_0x112f5d&&!_0x6573b9)return null;try{return de['credential'](_0x112f5d,_0x6573b9);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5361a3){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5361a3});}static['credentialFromResult'](_0x30b8f4){return fe['credentialFromTaggedObject'](_0x30b8f4);}static['credentialFromError'](_0x221bf3){return fe['credentialFromTaggedObject'](_0x221bf3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e9390}){if(!_0x5e9390||!('oauthAccessToken'in _0x5e9390)||!_0x5e9390['oauthAccessToken'])return null;try{return fe['credential'](_0x5e9390['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x518f42,_0x3b5896){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x518f42,'oauthTokenSecret':_0x3b5896});}static['credentialFromResult'](_0x4ffa45){return pe['credentialFromTaggedObject'](_0x4ffa45);}static['credentialFromError'](_0x27c663){return pe['credentialFromTaggedObject'](_0x27c663['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22fd32}){if(!_0x22fd32)return null;const {oauthAccessToken:_0x29ad2b,oauthTokenSecret:_0xec2dd5}=_0x22fd32;if(!_0x29ad2b||!_0xec2dd5)return null;try{return pe['credential'](_0x29ad2b,_0xec2dd5);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x380982,_0x20b5ae){return en(_0x380982,'POST','/v1/accounts:signUp',ke(_0x380982,_0x20b5ae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x50c75e){this['user']=_0x50c75e['user'],this['providerId']=_0x50c75e['providerId'],this['_tokenResponse']=_0x50c75e['_tokenResponse'],this['operationType']=_0x50c75e['operationType'];}static async['_fromIdTokenResponse'](_0x44431d,_0x5c312f,_0x37654c,_0x3089d7=!0x1){const _0x3b64ac=await j['_fromIdTokenResponse'](_0x44431d,_0x37654c,_0x3089d7),_0x1cc752=Nr(_0x37654c);return new Ge({'user':_0x3b64ac,'providerId':_0x1cc752,'_tokenResponse':_0x37654c,'operationType':_0x5c312f});}static async['_forOperation'](_0x369303,_0x1ade31,_0x58f2e9){await _0x369303['_updateTokensIfNecessary'](_0x58f2e9,!0x0);const _0x561e93=Nr(_0x58f2e9);return new Ge({'user':_0x369303,'providerId':_0x561e93,'_tokenResponse':_0x58f2e9,'operationType':_0x1ade31});}}function Nr(_0x4f312e){return _0x4f312e['providerId']?_0x4f312e['providerId']:'phoneNumber'in _0x4f312e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x46b468,_0x17a2cb,_0x47812a,_0x3b32b9){super(_0x17a2cb['code'],_0x17a2cb['message']),this['operationType']=_0x47812a,this['user']=_0x3b32b9,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x46b468['name'],'tenantId':_0x46b468['tenantId']??void 0x0,'_serverResponse':_0x17a2cb['customData']['_serverResponse'],'operationType':_0x47812a};}static['_fromErrorAndOperation'](_0x28c488,_0x272005,_0x5c0671,_0x4455ce){return new On(_0x28c488,_0x272005,_0x5c0671,_0x4455ce);}}function Ba(_0x33d08f,_0x3f84ad,_0x3f2383,_0xca7538){return(_0x3f84ad==='reauthenticate'?_0x3f2383['_getReauthenticationResolver'](_0x33d08f):_0x3f2383['_getIdTokenResponse'](_0x33d08f))['catch'](_0x3531ee=>{throw _0x3531ee['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x33d08f,_0x3531ee,_0x3f84ad,_0xca7538):_0x3531ee;});}async function ep(_0x27fdfc,_0x4e8889,_0x598ea7=!0x1){const _0x53855e=await Ht(_0x27fdfc,_0x4e8889['_linkToIdToken'](_0x27fdfc['auth'],await _0x27fdfc['getIdToken']()),_0x598ea7);return Ge['_forOperation'](_0x27fdfc,'link',_0x53855e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x4a576e,_0x348865,_0x52e707=!0x1){const {auth:_0x344490}=_0x4a576e;if($(_0x344490['app']))return Promise['reject'](re(_0x344490));const _0x5584ab='reauthenticate';try{const _0x2bf091=await Ht(_0x4a576e,Ba(_0x344490,_0x5584ab,_0x348865,_0x4a576e),_0x52e707);m(_0x2bf091['idToken'],_0x344490,'internal-error');const _0x1067f6=Ts(_0x2bf091['idToken']);m(_0x1067f6,_0x344490,'internal-error');const {sub:_0x453340}=_0x1067f6;return m(_0x4a576e['uid']===_0x453340,_0x344490,'user-mismatch'),Ge['_forOperation'](_0x4a576e,_0x5584ab,_0x2bf091);}catch(_0x2d4e01){throw(_0x2d4e01==null?void 0x0:_0x2d4e01['code'])==='auth/user-not-found'&&Y(_0x344490,'user-mismatch'),_0x2d4e01;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1b8cdc,_0x592f61,_0x28020d=!0x1){if($(_0x1b8cdc['app']))return Promise['reject'](re(_0x1b8cdc));const _0x51b1bc='signIn',_0x15a6ff=await Ba(_0x1b8cdc,_0x51b1bc,_0x592f61),_0x267ff9=await Ge['_fromIdTokenResponse'](_0x1b8cdc,_0x51b1bc,_0x15a6ff);return _0x28020d||await _0x1b8cdc['_updateCurrentUser'](_0x267ff9['user']),_0x267ff9;}async function np(_0x403dee,_0x1256a7){return Va(Ke(_0x403dee),_0x1256a7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x279159){const _0x66fec7=Ke(_0x279159);_0x66fec7['_getPasswordPolicyInternal']()&&await _0x66fec7['_updatePasswordPolicy']();}async function L_(_0x297191,_0x4f87ed,_0x10d81f){if($(_0x297191['app']))return Promise['reject'](re(_0x297191));const _0x4c4855=Ke(_0x297191),_0x562eac=await xi(_0x4c4855,{'returnSecureToken':!0x0,'email':_0x4f87ed,'password':_0x10d81f,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x358029=>{throw _0x358029['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x297191),_0x358029;}),_0x44180b=await Ge['_fromIdTokenResponse'](_0x4c4855,'signIn',_0x562eac);return await _0x4c4855['_updateCurrentUser'](_0x44180b['user']),_0x44180b;}function x_(_0x18e286,_0x8d59e,_0x5b6d39){return $(_0x18e286['app'])?Promise['reject'](re(_0x18e286)):np(P(_0x18e286),yt['credential'](_0x8d59e,_0x5b6d39))['catch'](async _0x51ed49=>{throw _0x51ed49['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x18e286),_0x51ed49;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2a4399,_0x104bd4){return P(_0x2a4399)['setPersistence'](_0x104bd4);}function ip(_0x4d1003,_0x22b813,_0xa25bc9,_0x1d68de){return P(_0x4d1003)['onIdTokenChanged'](_0x22b813,_0xa25bc9,_0x1d68de);}function sp(_0x3865ec,_0x53568d,_0x4dc6cc){return P(_0x3865ec)['beforeAuthStateChanged'](_0x53568d,_0x4dc6cc);}function U_(_0x4f2764,_0x231b6a,_0x2a89b0,_0x5b49e7){return P(_0x4f2764)['onAuthStateChanged'](_0x231b6a,_0x2a89b0,_0x5b49e7);}function W_(_0x3e6928){return P(_0x3e6928)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0xc6ceb6,_0x6a0cd7){this['storageRetriever']=_0xc6ceb6,this['type']=_0x6a0cd7;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3a6483,_0x1a589b){return this['storage']['setItem'](_0x3a6483,JSON['stringify'](_0x1a589b)),Promise['resolve']();}['_get'](_0x1540d2){const _0x3e2e11=this['storage']['getItem'](_0x1540d2);return Promise['resolve'](_0x3e2e11?JSON['parse'](_0x3e2e11):null);}['_remove'](_0x36e347){return this['storage']['removeItem'](_0x36e347),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2d9b49,_0x1b765c)=>this['onStorageEvent'](_0x2d9b49,_0x1b765c),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1123f1){for(const _0x13f817 of Object['keys'](this['listeners'])){const _0x1e7b81=this['storage']['getItem'](_0x13f817),_0x34978a=this['localCache'][_0x13f817];_0x1e7b81!==_0x34978a&&_0x1123f1(_0x13f817,_0x34978a,_0x1e7b81);}}['onStorageEvent'](_0x234b69,_0x31b7ad=!0x1){if(!_0x234b69['key']){this['forAllChangedKeys']((_0x1e4c4d,_0x560f6c,_0x264a07)=>{this['notifyListeners'](_0x1e4c4d,_0x264a07);});return;}const _0x329d98=_0x234b69['key'];_0x31b7ad?this['detachListener']():this['stopPolling']();const _0x2d905a=()=>{const _0x3442da=this['storage']['getItem'](_0x329d98);!_0x31b7ad&&this['localCache'][_0x329d98]===_0x3442da||this['notifyListeners'](_0x329d98,_0x3442da);},_0x200a93=this['storage']['getItem'](_0x329d98);Af()&&_0x200a93!==_0x234b69['newValue']&&_0x234b69['newValue']!==_0x234b69['oldValue']?setTimeout(_0x2d905a,op):_0x2d905a();}['notifyListeners'](_0x551917,_0x3fd7cb){this['localCache'][_0x551917]=_0x3fd7cb;const _0x3c747d=this['listeners'][_0x551917];if(_0x3c747d){for(const _0x2307d8 of Array['from'](_0x3c747d))_0x2307d8(_0x3fd7cb&&JSON['parse'](_0x3fd7cb));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x59711f,_0x497638,_0x5a7c87)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x59711f,'oldValue':_0x497638,'newValue':_0x5a7c87}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xdadf8a,_0x324a79){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xdadf8a]||(this['listeners'][_0xdadf8a]=new Set(),this['localCache'][_0xdadf8a]=this['storage']['getItem'](_0xdadf8a)),this['listeners'][_0xdadf8a]['add'](_0x324a79);}['_removeListener'](_0x418545,_0x18cb89){this['listeners'][_0x418545]&&(this['listeners'][_0x418545]['delete'](_0x18cb89),this['listeners'][_0x418545]['size']===0x0&&delete this['listeners'][_0x418545]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x288dda,_0x51a551){await super['_set'](_0x288dda,_0x51a551),this['localCache'][_0x288dda]=JSON['stringify'](_0x51a551);}async['_get'](_0x42becd){const _0x415251=await super['_get'](_0x42becd);return this['localCache'][_0x42becd]=JSON['stringify'](_0x415251),_0x415251;}async['_remove'](_0x2716e3){await super['_remove'](_0x2716e3),delete this['localCache'][_0x2716e3];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x16cbb8,_0x49598c){}['_removeListener'](_0x1ec03c,_0x37a873){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x36a59f){return Promise['all'](_0x36a59f['map'](async _0x51a806=>{try{return{'fulfilled':!0x0,'value':await _0x51a806};}catch(_0x23510b){return{'fulfilled':!0x1,'reason':_0x23510b};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4833a1){this['eventTarget']=_0x4833a1,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3513d4){const _0x2d35b9=this['receivers']['find'](_0x5872b1=>_0x5872b1['isListeningto'](_0x3513d4));if(_0x2d35b9)return _0x2d35b9;const _0x42a5b9=new Xn(_0x3513d4);return this['receivers']['push'](_0x42a5b9),_0x42a5b9;}['isListeningto'](_0x4db9b7){return this['eventTarget']===_0x4db9b7;}async['handleEvent'](_0x2ea6af){const _0x33a714=_0x2ea6af,{eventId:_0x407539,eventType:_0x208c06,data:_0x20f40a}=_0x33a714['data'],_0x2c943a=this['handlersMap'][_0x208c06];if(!(_0x2c943a!=null&&_0x2c943a['size']))return;_0x33a714['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x407539,'eventType':_0x208c06});const _0x4c61f2=Array['from'](_0x2c943a)['map'](async _0x30ca26=>_0x30ca26(_0x33a714['origin'],_0x20f40a)),_0x4361d1=await cp(_0x4c61f2);_0x33a714['ports'][0x0]['postMessage']({'status':'done','eventId':_0x407539,'eventType':_0x208c06,'response':_0x4361d1});}['_subscribe'](_0x4b8250,_0x467623){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4b8250]||(this['handlersMap'][_0x4b8250]=new Set()),this['handlersMap'][_0x4b8250]['add'](_0x467623);}['_unsubscribe'](_0x571ce6,_0x1e79f0){this['handlersMap'][_0x571ce6]&&_0x1e79f0&&this['handlersMap'][_0x571ce6]['delete'](_0x1e79f0),(!_0x1e79f0||this['handlersMap'][_0x571ce6]['size']===0x0)&&delete this['handlersMap'][_0x571ce6],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1563e6='',_0x18ae7=0xa){let _0x3ff640='';for(let _0x3e4312=0x0;_0x3e4312<_0x18ae7;_0x3e4312++)_0x3ff640+=Math['floor'](Math['random']()*0xa);return _0x1563e6+_0x3ff640;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x346254){this['target']=_0x346254,this['handlers']=new Set();}['removeMessageHandler'](_0x56f220){_0x56f220['messageChannel']&&(_0x56f220['messageChannel']['port1']['removeEventListener']('message',_0x56f220['onMessage']),_0x56f220['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x56f220);}async['_send'](_0x1d1042,_0x386179,_0x5435b5=0x32){const _0x452ec0=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x452ec0)throw new Error('connection_unavailable');let _0x1d8300,_0x186c2d;return new Promise((_0x130ed6,_0x1dff9a)=>{const _0x1ed0f2=As('',0x14);_0x452ec0['port1']['start']();const _0x59184f=setTimeout(()=>{_0x1dff9a(new Error('unsupported_event'));},_0x5435b5);_0x186c2d={'messageChannel':_0x452ec0,'onMessage'(_0x4fad12){const _0x49d335=_0x4fad12;if(_0x49d335['data']['eventId']===_0x1ed0f2)switch(_0x49d335['data']['status']){case'ack':clearTimeout(_0x59184f),_0x1d8300=setTimeout(()=>{_0x1dff9a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1d8300),_0x130ed6(_0x49d335['data']['response']);break;default:clearTimeout(_0x59184f),clearTimeout(_0x1d8300),_0x1dff9a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x186c2d),_0x452ec0['port1']['addEventListener']('message',_0x186c2d['onMessage']),this['target']['postMessage']({'eventType':_0x1d1042,'eventId':_0x1ed0f2,'data':_0x386179},[_0x452ec0['port2']]);})['finally'](()=>{_0x186c2d&&this['removeMessageHandler'](_0x186c2d);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x2ea581){Z()['location']['href']=_0x2ea581;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x171b12;return((_0x171b12=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x171b12['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1557e3){this['request']=_0x1557e3;}['toPromise'](){return new Promise((_0xc26fb0,_0x310810)=>{this['request']['addEventListener']('success',()=>{_0xc26fb0(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x310810(this['request']['error']);});});}}function Zn(_0x52d8bc,_0x1f596f){return _0x52d8bc['transaction']([Mn],_0x1f596f?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x55f09d=indexedDB['deleteDatabase'](Ka);return new nn(_0x55f09d)['toPromise']();}function Qa(){const _0x38e3e5=indexedDB['open'](Ka,pp);return new Promise((_0x176fd3,_0x3c3b0c)=>{_0x38e3e5['addEventListener']('error',()=>{_0x3c3b0c(_0x38e3e5['error']);}),_0x38e3e5['addEventListener']('upgradeneeded',()=>{const _0x5d6423=_0x38e3e5['result'];try{_0x5d6423['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x52fbf5){_0x3c3b0c(_0x52fbf5);}}),_0x38e3e5['addEventListener']('success',async()=>{const _0x1aae1e=_0x38e3e5['result'];_0x1aae1e['objectStoreNames']['contains'](Mn)?_0x176fd3(_0x1aae1e):(_0x1aae1e['close'](),await _p(),_0x176fd3(await Qa()));});});}async function Or(_0x31e7df,_0x41aeb2,_0x3890c0){const _0x10bc7b=Zn(_0x31e7df,!0x0)['put']({[Ya]:_0x41aeb2,'value':_0x3890c0});return new nn(_0x10bc7b)['toPromise']();}async function gp(_0x2226a8,_0x2bb73c){const _0x519a2c=Zn(_0x2226a8,!0x1)['get'](_0x2bb73c),_0x47a952=await new nn(_0x519a2c)['toPromise']();return _0x47a952===void 0x0?null:_0x47a952['value'];}function Dr(_0x46278d,_0x1572ba){const _0x453a89=Zn(_0x46278d,!0x0)['delete'](_0x1572ba);return new nn(_0x453a89)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1d4a74){let _0x5865c4=0x0;for(;;)try{const _0x19ed43=await this['_openDb']();return await _0x1d4a74(_0x19ed43);}catch(_0x3c7f52){if(_0x5865c4++>yp)throw _0x3c7f52;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2c2299,_0x36bbe9)=>({'keyProcessed':(await this['_poll']())['includes'](_0x36bbe9['key'])})),this['receiver']['_subscribe']('ping',async(_0x23b776,_0x30ea0d)=>['keyChanged']);}async['initializeSender'](){var _0xb7d24,_0x567bda;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x28fa50=await this['sender']['_send']('ping',{},0x320);_0x28fa50&&(_0xb7d24=_0x28fa50[0x0])!=null&&_0xb7d24['fulfilled']&&(_0x567bda=_0x28fa50[0x0])!=null&&_0x567bda['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4a94f3){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4a94f3},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x336a29=>{await Or(_0x336a29,Dn,'1'),await Dr(_0x336a29,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0xfea94a){this['pendingWrites']++;try{await _0xfea94a();}finally{this['pendingWrites']--;}}async['_set'](_0x386cf9,_0x31e029){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5621fe=>Or(_0x5621fe,_0x386cf9,_0x31e029)),this['localCache'][_0x386cf9]=_0x31e029,this['notifyServiceWorker'](_0x386cf9)));}async['_get'](_0x21ad3a){const _0x3be403=await this['_withRetries'](_0x1222d2=>gp(_0x1222d2,_0x21ad3a));return this['localCache'][_0x21ad3a]=_0x3be403,_0x3be403;}async['_remove'](_0x19eb02){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x365824=>Dr(_0x365824,_0x19eb02)),delete this['localCache'][_0x19eb02],this['notifyServiceWorker'](_0x19eb02)));}async['_poll'](){const _0x15868f=await this['_withRetries'](_0x425dc2=>{const _0x1b2d97=Zn(_0x425dc2,!0x1)['getAll']();return new nn(_0x1b2d97)['toPromise']();});if(!_0x15868f)return[];if(this['pendingWrites']!==0x0)return[];const _0x37d4fe=[],_0x378f9a=new Set();if(_0x15868f['length']!==0x0){for(const {fbase_key:_0x5c0256,value:_0x20830d}of _0x15868f)_0x378f9a['add'](_0x5c0256),JSON['stringify'](this['localCache'][_0x5c0256])!==JSON['stringify'](_0x20830d)&&(this['notifyListeners'](_0x5c0256,_0x20830d),_0x37d4fe['push'](_0x5c0256));}for(const _0x46e881 of Object['keys'](this['localCache']))this['localCache'][_0x46e881]&&!_0x378f9a['has'](_0x46e881)&&(this['notifyListeners'](_0x46e881,null),_0x37d4fe['push'](_0x46e881));return _0x37d4fe;}['notifyListeners'](_0x10f4eb,_0x3c2ca5){this['localCache'][_0x10f4eb]=_0x3c2ca5;const _0x11c554=this['listeners'][_0x10f4eb];if(_0x11c554){for(const _0x100dde of Array['from'](_0x11c554))_0x100dde(_0x3c2ca5);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x148051,_0x2747){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x148051]||(this['listeners'][_0x148051]=new Set(),this['_get'](_0x148051)),this['listeners'][_0x148051]['add'](_0x2747);}['_removeListener'](_0x59e58a,_0x4464d8){this['listeners'][_0x59e58a]&&(this['listeners'][_0x59e58a]['delete'](_0x4464d8),this['listeners'][_0x59e58a]['size']===0x0&&delete this['listeners'][_0x59e58a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5ec609,_0x53980f){return _0x53980f?ie(_0x53980f):(m(_0x5ec609['_popupRedirectResolver'],_0x5ec609,'argument-error'),_0x5ec609['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1f4e29){super('custom','custom'),this['params']=_0x1f4e29;}['_getIdTokenResponse'](_0x5cd1fa){return nt(_0x5cd1fa,this['_buildIdpRequest']());}['_linkToIdToken'](_0x307a32,_0x55e0df){return nt(_0x307a32,this['_buildIdpRequest'](_0x55e0df));}['_getReauthenticationResolver'](_0x51c0dd){return nt(_0x51c0dd,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x55a047){const _0x3c1dcf={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x55a047&&(_0x3c1dcf['idToken']=_0x55a047),_0x3c1dcf;}}function Ip(_0x29acf2){return Va(_0x29acf2['auth'],new ks(_0x29acf2),_0x29acf2['bypassAuthState']);}function wp(_0xa42dcb){const {auth:_0x3016b6,user:_0x1d95b9}=_0xa42dcb;return m(_0x1d95b9,_0x3016b6,'internal-error'),tp(_0x1d95b9,new ks(_0xa42dcb),_0xa42dcb['bypassAuthState']);}async function Cp(_0x1d13ff){const {auth:_0x5697b6,user:_0x217656}=_0x1d13ff;return m(_0x217656,_0x5697b6,'internal-error'),ep(_0x217656,new ks(_0x1d13ff),_0x1d13ff['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x2ab1ed,_0xbc45a2,_0x17a18e,_0x42b55c,_0x2c6535=!0x1){this['auth']=_0x2ab1ed,this['resolver']=_0x17a18e,this['user']=_0x42b55c,this['bypassAuthState']=_0x2c6535,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xbc45a2)?_0xbc45a2:[_0xbc45a2];}['execute'](){return new Promise(async(_0x214570,_0x5b1958)=>{this['pendingPromise']={'resolve':_0x214570,'reject':_0x5b1958};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2e8894){this['reject'](_0x2e8894);}});}async['onAuthEvent'](_0x45fa77){const {urlResponse:_0x1d1fc1,sessionId:_0x218129,postBody:_0x4be170,tenantId:_0x3231b2,error:_0x1de1ca,type:_0x33b6bb}=_0x45fa77;if(_0x1de1ca){this['reject'](_0x1de1ca);return;}const _0x158f2a={'auth':this['auth'],'requestUri':_0x1d1fc1,'sessionId':_0x218129,'tenantId':_0x3231b2||void 0x0,'postBody':_0x4be170||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x33b6bb)(_0x158f2a));}catch(_0x57701e){this['reject'](_0x57701e);}}['onError'](_0x126055){this['reject'](_0x126055);}['getIdpTask'](_0x1d3054){switch(_0x1d3054){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0xf76687){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xf76687),this['unregisterAndCleanUp']();}['reject'](_0x3923fc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3923fc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0xa5aaa3,_0x4528f5,_0x1c3246,_0xc265a5,_0x112517){super(_0xa5aaa3,_0x4528f5,_0xc265a5,_0x112517),this['provider']=_0x1c3246,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x32b9cb=await this['execute']();return m(_0x32b9cb,this['auth'],'internal-error'),_0x32b9cb;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x118f0e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x118f0e),this['authWindow']['associatedEvent']=_0x118f0e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4da7cc=>{this['reject'](_0x4da7cc);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x468bce=>{_0x468bce||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x26b7bd;return((_0x26b7bd=this['authWindow'])==null?void 0x0:_0x26b7bd['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x11906e=()=>{var _0x4b0ca0,_0x1ff273;if((_0x1ff273=(_0x4b0ca0=this['authWindow'])==null?void 0x0:_0x4b0ca0['window'])!=null&&_0x1ff273['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x11906e,Tp['get']());};_0x11906e();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x59f180,_0x10187d,_0x34b4d7=!0x1){super(_0x59f180,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x10187d,void 0x0,_0x34b4d7),this['eventId']=null;}async['execute'](){let _0x4059ab=hn['get'](this['auth']['_key']());if(!_0x4059ab){try{const _0x194392=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4059ab=()=>Promise['resolve'](_0x194392);}catch(_0x43c79b){_0x4059ab=()=>Promise['reject'](_0x43c79b);}hn['set'](this['auth']['_key'](),_0x4059ab);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4059ab();}async['onAuthEvent'](_0x4a0733){if(_0x4a0733['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4a0733);if(_0x4a0733['type']==='unknown'){this['resolve'](null);return;}if(_0x4a0733['eventId']){const _0x55be2e=await this['auth']['_redirectUserForId'](_0x4a0733['eventId']);if(_0x55be2e)return this['user']=_0x55be2e,super['onAuthEvent'](_0x4a0733);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x18e57c,_0x26e3f6){const _0x1924e5=Pp(_0x26e3f6),_0x1e07b0=kp(_0x18e57c);if(!await _0x1e07b0['_isAvailable']())return!0x1;const _0x5b4ab4=await _0x1e07b0['_get'](_0x1924e5)==='true';return await _0x1e07b0['_remove'](_0x1924e5),_0x5b4ab4;}function Ap(_0x4bd584,_0x3f6c36){hn['set'](_0x4bd584['_key'](),_0x3f6c36);}function kp(_0x226441){return ie(_0x226441['_redirectPersistence']);}function Pp(_0x3166f6){return ln(Sp,_0x3166f6['config']['apiKey'],_0x3166f6['name']);}async function Np(_0x3f10f3,_0x3ac6a4,_0x10448d=!0x1){if($(_0x3f10f3['app']))return Promise['reject'](re(_0x3f10f3));const _0x36a9a8=Ke(_0x3f10f3),_0x4c9371=Ep(_0x36a9a8,_0x3ac6a4),_0x2950d0=await new bp(_0x36a9a8,_0x4c9371,_0x10448d)['execute']();return _0x2950d0&&!_0x10448d&&(delete _0x2950d0['user']['_redirectEventId'],await _0x36a9a8['_persistUserIfCurrent'](_0x2950d0['user']),await _0x36a9a8['_setRedirectUser'](null,_0x3ac6a4)),_0x2950d0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x146375){this['auth']=_0x146375,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3518e2){this['consumers']['add'](_0x3518e2),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3518e2)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3518e2),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xef5622){this['consumers']['delete'](_0xef5622);}['onEvent'](_0x21b831){if(this['hasEventBeenHandled'](_0x21b831))return!0x1;let _0x175614=!0x1;return this['consumers']['forEach'](_0xf332f2=>{this['isEventForConsumer'](_0x21b831,_0xf332f2)&&(_0x175614=!0x0,this['sendToConsumer'](_0x21b831,_0xf332f2),this['saveEventToCache'](_0x21b831));}),this['hasHandledPotentialRedirect']||!Mp(_0x21b831)||(this['hasHandledPotentialRedirect']=!0x0,_0x175614||(this['queuedRedirectEvent']=_0x21b831,_0x175614=!0x0)),_0x175614;}['sendToConsumer'](_0x318ca6,_0x298273){var _0x5b286d;if(_0x318ca6['error']&&!Za(_0x318ca6)){const _0x3ee2c6=((_0x5b286d=_0x318ca6['error']['code'])==null?void 0x0:_0x5b286d['split']('auth/')[0x1])||'internal-error';_0x298273['onError'](X(this['auth'],_0x3ee2c6));}else _0x298273['onAuthEvent'](_0x318ca6);}['isEventForConsumer'](_0x280b41,_0x47cd74){const _0x3882f4=_0x47cd74['eventId']===null||!!_0x280b41['eventId']&&_0x280b41['eventId']===_0x47cd74['eventId'];return _0x47cd74['filter']['includes'](_0x280b41['type'])&&_0x3882f4;}['hasEventBeenHandled'](_0x5a2224){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x5a2224));}['saveEventToCache'](_0x519fb1){this['cachedEventUids']['add'](Mr(_0x519fb1)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2f5a24){return[_0x2f5a24['type'],_0x2f5a24['eventId'],_0x2f5a24['sessionId'],_0x2f5a24['tenantId']]['filter'](_0x4a80d6=>_0x4a80d6)['join']('-');}function Za({type:_0x13ac1c,error:_0x175382}){return _0x13ac1c==='unknown'&&(_0x175382==null?void 0x0:_0x175382['code'])==='auth/no-auth-event';}function Mp(_0x4d7779){switch(_0x4d7779['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x4d7779);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x518359,_0x113ac6={}){return Pe(_0x518359,'GET','/v1/projects',_0x113ac6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3a6183){if(_0x3a6183['config']['emulator'])return;const {authorizedDomains:_0x115099}=await Lp(_0x3a6183);for(const _0x1f34e1 of _0x115099)try{if(Wp(_0x1f34e1))return;}catch{}Y(_0x3a6183,'unauthorized-domain');}function Wp(_0x165a8d){const _0xb05f89=Mi(),{protocol:_0x47b165,hostname:_0x5b6ad1}=new URL(_0xb05f89);if(_0x165a8d['startsWith']('chrome-extension://')){const _0x3c4852=new URL(_0x165a8d);return _0x3c4852['hostname']===''&&_0x5b6ad1===''?_0x47b165==='chrome-extension:'&&_0x165a8d['replace']('chrome-extension://','')===_0xb05f89['replace']('chrome-extension://',''):_0x47b165==='chrome-extension:'&&_0x3c4852['hostname']===_0x5b6ad1;}if(!Fp['test'](_0x47b165))return!0x1;if(xp['test'](_0x165a8d))return _0x5b6ad1===_0x165a8d;const _0x5aebac=_0x165a8d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x5aebac+'|'+_0x5aebac+')$','i')['test'](_0x5b6ad1);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x5a5eed=Z()['___jsl'];if(_0x5a5eed!=null&&_0x5a5eed['H']){for(const _0xa0f725 of Object['keys'](_0x5a5eed['H']))if(_0x5a5eed['H'][_0xa0f725]['r']=_0x5a5eed['H'][_0xa0f725]['r']||[],_0x5a5eed['H'][_0xa0f725]['L']=_0x5a5eed['H'][_0xa0f725]['L']||[],_0x5a5eed['H'][_0xa0f725]['r']=[..._0x5a5eed['H'][_0xa0f725]['L']],_0x5a5eed['CP']){for(let _0x5cc71f=0x0;_0x5cc71f<_0x5a5eed['CP']['length'];_0x5cc71f++)_0x5a5eed['CP'][_0x5cc71f]=null;}}}function Vp(_0x28a28a){return new Promise((_0x478d93,_0x1a5f23)=>{var _0x555577,_0x5d5db0,_0x1d6205;function _0x1dfebf(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x478d93(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1a5f23(X(_0x28a28a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5d5db0=(_0x555577=Z()['gapi'])==null?void 0x0:_0x555577['iframes'])!=null&&_0x5d5db0['Iframe'])_0x478d93(gapi['iframes']['getContext']());else{if((_0x1d6205=Z()['gapi'])!=null&&_0x1d6205['load'])_0x1dfebf();else{const _0x16dcd8=Ff('iframefcb');return Z()[_0x16dcd8]=()=>{gapi['load']?_0x1dfebf():_0x1a5f23(X(_0x28a28a,'network-request-failed'));},xa(xf()+'?onload='+_0x16dcd8)['catch'](_0x1e8140=>_0x1a5f23(_0x1e8140));}}})['catch'](_0x4602a8=>{throw un=null,_0x4602a8;});}let un=null;function Hp(_0x5be695){return un=un||Vp(_0x5be695),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x441ff8){const _0x2c4365=_0x441ff8['config'];m(_0x2c4365['authDomain'],_0x441ff8,'auth-domain-config-required');const _0x32f796=_0x2c4365['emulator']?Cs(_0x2c4365,qp):'https://'+_0x441ff8['config']['authDomain']+'/'+Gp,_0x349537={'apiKey':_0x2c4365['apiKey'],'appName':_0x441ff8['name'],'v':dt},_0x4fed7f=jp['get'](_0x441ff8['config']['apiHost']);_0x4fed7f&&(_0x349537['eid']=_0x4fed7f);const _0x187c58=_0x441ff8['_getFrameworks']();return _0x187c58['length']&&(_0x349537['fw']=_0x187c58['join'](',')),_0x32f796+'?'+ut(_0x349537)['slice'](0x1);}async function Yp(_0x18f117){const _0x531851=await Hp(_0x18f117),_0x34d4db=Z()['gapi'];return m(_0x34d4db,_0x18f117,'internal-error'),_0x531851['open']({'where':document['body'],'url':Kp(_0x18f117),'messageHandlersFilter':_0x34d4db['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x5f66e0=>new Promise(async(_0x2ef01e,_0xcde480)=>{await _0x5f66e0['restyle']({'setHideOnLeave':!0x1});const _0x2e48a6=X(_0x18f117,'network-request-failed'),_0x28aae6=Z()['setTimeout'](()=>{_0xcde480(_0x2e48a6);},$p['get']());function _0x5bda27(){Z()['clearTimeout'](_0x28aae6),_0x2ef01e(_0x5f66e0);}_0x5f66e0['ping'](_0x5bda27)['then'](_0x5bda27,()=>{_0xcde480(_0x2e48a6);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x2f0cde){this['window']=_0x2f0cde,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xfbb14,_0x4b4847,_0x1035d7,_0x217987=Jp,_0x2d82c8=Xp){const _0x18539a=Math['max']((window['screen']['availHeight']-_0x2d82c8)/0x2,0x0)['toString'](),_0x4fe179=Math['max']((window['screen']['availWidth']-_0x217987)/0x2,0x0)['toString']();let _0x2c33ce='';const _0x58b0e0={...Qp,'width':_0x217987['toString'](),'height':_0x2d82c8['toString'](),'top':_0x18539a,'left':_0x4fe179},_0x338735=W()['toLowerCase']();_0x1035d7&&(_0x2c33ce=ka(_0x338735)?Zp:_0x1035d7),Ra(_0x338735)&&(_0x4b4847=_0x4b4847||e_,_0x58b0e0['scrollbars']='yes');const _0x1203a7=Object['entries'](_0x58b0e0)['reduce']((_0x5cd3ea,[_0x3bdd91,_0x4e5750])=>''+_0x5cd3ea+_0x3bdd91+'='+_0x4e5750+',','');if(Rf(_0x338735)&&_0x2c33ce!=='_self')return n_(_0x4b4847||'',_0x2c33ce),new xr(null);const _0x4d97b9=window['open'](_0x4b4847||'',_0x2c33ce,_0x1203a7);m(_0x4d97b9,_0xfbb14,'popup-blocked');try{_0x4d97b9['focus']();}catch{}return new xr(_0x4d97b9);}function n_(_0x5dd64c,_0x458a32){const _0x53f70a=document['createElement']('a');_0x53f70a['href']=_0x5dd64c,_0x53f70a['target']=_0x458a32;const _0x180465=document['createEvent']('MouseEvent');_0x180465['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x53f70a['dispatchEvent'](_0x180465);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x1efa32,_0x31a37a,_0x27dd64,_0x353d6a,_0x3c4350,_0x595639){m(_0x1efa32['config']['authDomain'],_0x1efa32,'auth-domain-config-required'),m(_0x1efa32['config']['apiKey'],_0x1efa32,'invalid-api-key');const _0x20ec01={'apiKey':_0x1efa32['config']['apiKey'],'appName':_0x1efa32['name'],'authType':_0x27dd64,'redirectUrl':_0x353d6a,'v':dt,'eventId':_0x3c4350};if(_0x31a37a instanceof Wa){_0x31a37a['setDefaultLanguage'](_0x1efa32['languageCode']),_0x20ec01['providerId']=_0x31a37a['providerId']||'',pn(_0x31a37a['getCustomParameters']())||(_0x20ec01['customParameters']=JSON['stringify'](_0x31a37a['getCustomParameters']()));for(const [_0x4f2267,_0x42840f]of Object['entries']({}))_0x20ec01[_0x4f2267]=_0x42840f;}if(_0x31a37a instanceof tn){const _0x50922f=_0x31a37a['getScopes']()['filter'](_0x55c037=>_0x55c037!=='');_0x50922f['length']>0x0&&(_0x20ec01['scopes']=_0x50922f['join'](','));}_0x1efa32['tenantId']&&(_0x20ec01['tid']=_0x1efa32['tenantId']);const _0x144968=_0x20ec01;for(const _0x1f06e7 of Object['keys'](_0x144968))_0x144968[_0x1f06e7]===void 0x0&&delete _0x144968[_0x1f06e7];const _0x59597e=await _0x1efa32['_getAppCheckToken'](),_0xc417aa=_0x59597e?'#'+r_+'='+encodeURIComponent(_0x59597e):'';return o_(_0x1efa32)+'?'+ut(_0x144968)['slice'](0x1)+_0xc417aa;}function o_({config:_0x4f4c17}){return _0x4f4c17['emulator']?Cs(_0x4f4c17,s_):'https://'+_0x4f4c17['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x12458c,_0x38d67e,_0x495a2a,_0x5da531){var _0x1d802a;ce((_0x1d802a=this['eventManagers'][_0x12458c['_key']()])==null?void 0x0:_0x1d802a['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x33f3cc=await Fr(_0x12458c,_0x38d67e,_0x495a2a,Mi(),_0x5da531);return t_(_0x12458c,_0x33f3cc,As());}async['_openRedirect'](_0x5e9369,_0x318bdb,_0x87c2aa,_0x260fc8){await this['_originValidation'](_0x5e9369);const _0x12dc7e=await Fr(_0x5e9369,_0x318bdb,_0x87c2aa,Mi(),_0x260fc8);return hp(_0x12dc7e),new Promise(()=>{});}['_initialize'](_0x34be6c){const _0x30f931=_0x34be6c['_key']();if(this['eventManagers'][_0x30f931]){const {manager:_0x53054d,promise:_0x339bb1}=this['eventManagers'][_0x30f931];return _0x53054d?Promise['resolve'](_0x53054d):(ce(_0x339bb1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x339bb1);}const _0x56c10b=this['initAndGetManager'](_0x34be6c);return this['eventManagers'][_0x30f931]={'promise':_0x56c10b},_0x56c10b['catch'](()=>{delete this['eventManagers'][_0x30f931];}),_0x56c10b;}async['initAndGetManager'](_0x539af3){const _0x367cb5=await Yp(_0x539af3),_0x22b1bf=new Dp(_0x539af3);return _0x367cb5['register']('authEvent',_0x4d6644=>(m(_0x4d6644==null?void 0x0:_0x4d6644['authEvent'],_0x539af3,'invalid-auth-event'),{'status':_0x22b1bf['onEvent'](_0x4d6644['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x539af3['_key']()]={'manager':_0x22b1bf},this['iframes'][_0x539af3['_key']()]=_0x367cb5,_0x22b1bf;}['_isIframeWebStorageSupported'](_0x3bb8f1,_0x20ab91){this['iframes'][_0x3bb8f1['_key']()]['send'](pi,{'type':pi},_0x44ad5f=>{var _0x53353f;const _0x23c8eb=(_0x53353f=_0x44ad5f==null?void 0x0:_0x44ad5f[0x0])==null?void 0x0:_0x53353f[pi];_0x23c8eb!==void 0x0&&_0x20ab91(!!_0x23c8eb),Y(_0x3bb8f1,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2ecd4){const _0x653fc6=_0x2ecd4['_key']();return this['originValidationPromises'][_0x653fc6]||(this['originValidationPromises'][_0x653fc6]=Up(_0x2ecd4)),this['originValidationPromises'][_0x653fc6];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3e6f93){this['auth']=_0x3e6f93,this['internalListeners']=new Map();}['getUid'](){var _0x125617;return this['assertAuthConfigured'](),((_0x125617=this['auth']['currentUser'])==null?void 0x0:_0x125617['uid'])||null;}async['getToken'](_0x4b79ce){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4b79ce)}:null;}['addAuthTokenListener'](_0x240f60){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x240f60))return;const _0x1efaa9=this['auth']['onIdTokenChanged'](_0x3e54c3=>{_0x240f60((_0x3e54c3==null?void 0x0:_0x3e54c3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x240f60,_0x1efaa9),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x13d61c){this['assertAuthConfigured']();const _0xe6ff63=this['internalListeners']['get'](_0x13d61c);_0xe6ff63&&(this['internalListeners']['delete'](_0x13d61c),_0xe6ff63(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1b8f37){switch(_0x1b8f37){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x32c6ab){st(new Fe('auth',(_0xfb0069,{options:_0x192eaf})=>{const _0xd160c=_0xfb0069['getProvider']('app')['getImmediate'](),_0x34d2be=_0xfb0069['getProvider']('heartbeat'),_0x25b0fb=_0xfb0069['getProvider']('app-check-internal'),{apiKey:_0x3d8d0d,authDomain:_0x27e4cc}=_0xd160c['options'];m(_0x3d8d0d&&!_0x3d8d0d['includes'](':'),'invalid-api-key',{'appName':_0xd160c['name']});const _0x53be2e={'apiKey':_0x3d8d0d,'authDomain':_0x27e4cc,'clientPlatform':_0x32c6ab,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x32c6ab)},_0x57f546=new Df(_0xd160c,_0x34d2be,_0x25b0fb,_0x53be2e);return Hf(_0x57f546,_0x192eaf),_0x57f546;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x20d1aa,_0x370811,_0x3ca320)=>{_0x20d1aa['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x14f94c=>{const _0x44f718=Ke(_0x14f94c['getProvider']('auth')['getImmediate']());return(_0x3e8abb=>new l_(_0x3e8abb))(_0x44f718);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x32c6ab)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x7e26b8=>async _0x512113=>{const _0x235b3f=_0x512113&&await _0x512113['getIdTokenResult'](),_0x423657=_0x235b3f&&(new Date()['getTime']()-Date['parse'](_0x235b3f['issuedAtTime']))/0x3e8;if(_0x423657&&_0x423657>f_)return;const _0x1bcc3a=_0x235b3f==null?void 0x0:_0x235b3f['token'];Br!==_0x1bcc3a&&(Br=_0x1bcc3a,await fetch(_0x7e26b8,{'method':_0x1bcc3a?'POST':'DELETE','headers':_0x1bcc3a?{'Authorization':'Bearer\x20'+_0x1bcc3a}:{}}));};function B_(_0x3bc474=Zr()){const _0x4aa2af=Hi(_0x3bc474,'auth');if(_0x4aa2af['isInitialized']())return _0x4aa2af['getImmediate']();const _0x41ce35=Vf(_0x3bc474,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x4e1122=jr('authTokenSyncURL');if(_0x4e1122&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5f11fb=new URL(_0x4e1122,location['origin']);if(location['origin']===_0x5f11fb['origin']){const _0x129213=p_(_0x5f11fb['toString']());sp(_0x41ce35,_0x129213,()=>_0x129213(_0x41ce35['currentUser'])),ip(_0x41ce35,_0x5a6b93=>_0x129213(_0x5a6b93));}}const _0xd13cf3=qr('auth');return _0xd13cf3&&$f(_0x41ce35,'http://'+_0xd13cf3),_0x41ce35;}function __(){var _0x187525;return((_0x187525=document['getElementsByTagName']('head'))==null?void 0x0:_0x187525[0x0])??document;}Mf({'loadJS'(_0x399e7e){return new Promise((_0x3d0d28,_0x53ce81)=>{const _0x354e95=document['createElement']('script');_0x354e95['setAttribute']('src',_0x399e7e),_0x354e95['onload']=_0x3d0d28,_0x354e95['onerror']=_0x5e129f=>{const _0x2eb249=X('internal-error');_0x2eb249['customData']=_0x5e129f,_0x53ce81(_0x2eb249);},_0x354e95['type']='text/javascript',_0x354e95['charset']='UTF-8',__()['appendChild'](_0x354e95);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};