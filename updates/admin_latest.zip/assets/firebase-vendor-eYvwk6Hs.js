const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5ed50d,_0x48b448){if(!_0x5ed50d)throw ht(_0x48b448);},ht=function(_0x271634){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x271634);},Hr=function(_0x2ff05c){const _0x44a28d=[];let _0x5d8f85=0x0;for(let _0x77cdf1=0x0;_0x77cdf1<_0x2ff05c['length'];_0x77cdf1++){let _0x49ef1f=_0x2ff05c['charCodeAt'](_0x77cdf1);_0x49ef1f<0x80?_0x44a28d[_0x5d8f85++]=_0x49ef1f:_0x49ef1f<0x800?(_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0x6|0xc0,_0x44a28d[_0x5d8f85++]=_0x49ef1f&0x3f|0x80):(_0x49ef1f&0xfc00)===0xd800&&_0x77cdf1+0x1<_0x2ff05c['length']&&(_0x2ff05c['charCodeAt'](_0x77cdf1+0x1)&0xfc00)===0xdc00?(_0x49ef1f=0x10000+((_0x49ef1f&0x3ff)<<0xa)+(_0x2ff05c['charCodeAt'](++_0x77cdf1)&0x3ff),_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0x12|0xf0,_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0xc&0x3f|0x80,_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0x6&0x3f|0x80,_0x44a28d[_0x5d8f85++]=_0x49ef1f&0x3f|0x80):(_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0xc|0xe0,_0x44a28d[_0x5d8f85++]=_0x49ef1f>>0x6&0x3f|0x80,_0x44a28d[_0x5d8f85++]=_0x49ef1f&0x3f|0x80);}return _0x44a28d;},nc=function(_0x308916){const _0x448a1d=[];let _0x4d0cf6=0x0,_0x42cfe1=0x0;for(;_0x4d0cf6<_0x308916['length'];){const _0x3baa62=_0x308916[_0x4d0cf6++];if(_0x3baa62<0x80)_0x448a1d[_0x42cfe1++]=String['fromCharCode'](_0x3baa62);else{if(_0x3baa62>0xbf&&_0x3baa62<0xe0){const _0x5585ba=_0x308916[_0x4d0cf6++];_0x448a1d[_0x42cfe1++]=String['fromCharCode']((_0x3baa62&0x1f)<<0x6|_0x5585ba&0x3f);}else{if(_0x3baa62>0xef&&_0x3baa62<0x16d){const _0x529eda=_0x308916[_0x4d0cf6++],_0x3a373e=_0x308916[_0x4d0cf6++],_0x522f38=_0x308916[_0x4d0cf6++],_0x30ee57=((_0x3baa62&0x7)<<0x12|(_0x529eda&0x3f)<<0xc|(_0x3a373e&0x3f)<<0x6|_0x522f38&0x3f)-0x10000;_0x448a1d[_0x42cfe1++]=String['fromCharCode'](0xd800+(_0x30ee57>>0xa)),_0x448a1d[_0x42cfe1++]=String['fromCharCode'](0xdc00+(_0x30ee57&0x3ff));}else{const _0x4c3ce9=_0x308916[_0x4d0cf6++],_0x1bb22c=_0x308916[_0x4d0cf6++];_0x448a1d[_0x42cfe1++]=String['fromCharCode']((_0x3baa62&0xf)<<0xc|(_0x4c3ce9&0x3f)<<0x6|_0x1bb22c&0x3f);}}}}return _0x448a1d['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x43c747,_0xc059d3){if(!Array['isArray'](_0x43c747))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4b1db1=_0xc059d3?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x51c6b9=[];for(let _0x340e8c=0x0;_0x340e8c<_0x43c747['length'];_0x340e8c+=0x3){const _0x4b85ba=_0x43c747[_0x340e8c],_0x5a5fde=_0x340e8c+0x1<_0x43c747['length'],_0x424a6f=_0x5a5fde?_0x43c747[_0x340e8c+0x1]:0x0,_0x29c573=_0x340e8c+0x2<_0x43c747['length'],_0x1fea9c=_0x29c573?_0x43c747[_0x340e8c+0x2]:0x0,_0x1c0520=_0x4b85ba>>0x2,_0x435f5f=(_0x4b85ba&0x3)<<0x4|_0x424a6f>>0x4;let _0x41c050=(_0x424a6f&0xf)<<0x2|_0x1fea9c>>0x6,_0x47d1e7=_0x1fea9c&0x3f;_0x29c573||(_0x47d1e7=0x40,_0x5a5fde||(_0x41c050=0x40)),_0x51c6b9['push'](_0x4b1db1[_0x1c0520],_0x4b1db1[_0x435f5f],_0x4b1db1[_0x41c050],_0x4b1db1[_0x47d1e7]);}return _0x51c6b9['join']('');},'encodeString'(_0x5379d2,_0x15b05c){return this['HAS_NATIVE_SUPPORT']&&!_0x15b05c?btoa(_0x5379d2):this['encodeByteArray'](Hr(_0x5379d2),_0x15b05c);},'decodeString'(_0x1beee4,_0x50d743){return this['HAS_NATIVE_SUPPORT']&&!_0x50d743?atob(_0x1beee4):nc(this['decodeStringToByteArray'](_0x1beee4,_0x50d743));},'decodeStringToByteArray'(_0x159f61,_0x904abe){this['init_']();const _0x1682b6=_0x904abe?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x16a2b1=[];for(let _0x5355d0=0x0;_0x5355d0<_0x159f61['length'];){const _0x43ead7=_0x1682b6[_0x159f61['charAt'](_0x5355d0++)],_0x12338a=_0x5355d0<_0x159f61['length']?_0x1682b6[_0x159f61['charAt'](_0x5355d0)]:0x0;++_0x5355d0;const _0x52f1d5=_0x5355d0<_0x159f61['length']?_0x1682b6[_0x159f61['charAt'](_0x5355d0)]:0x40;++_0x5355d0;const _0x2b8ce2=_0x5355d0<_0x159f61['length']?_0x1682b6[_0x159f61['charAt'](_0x5355d0)]:0x40;if(++_0x5355d0,_0x43ead7==null||_0x12338a==null||_0x52f1d5==null||_0x2b8ce2==null)throw new ic();const _0x291f4b=_0x43ead7<<0x2|_0x12338a>>0x4;if(_0x16a2b1['push'](_0x291f4b),_0x52f1d5!==0x40){const _0x53354f=_0x12338a<<0x4&0xf0|_0x52f1d5>>0x2;if(_0x16a2b1['push'](_0x53354f),_0x2b8ce2!==0x40){const _0x1a464b=_0x52f1d5<<0x6&0xc0|_0x2b8ce2;_0x16a2b1['push'](_0x1a464b);}}}return _0x16a2b1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x31e2b8=0x0;_0x31e2b8<this['ENCODED_VALS']['length'];_0x31e2b8++)this['byteToCharMap_'][_0x31e2b8]=this['ENCODED_VALS']['charAt'](_0x31e2b8),this['charToByteMap_'][this['byteToCharMap_'][_0x31e2b8]]=_0x31e2b8,this['byteToCharMapWebSafe_'][_0x31e2b8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x31e2b8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x31e2b8]]=_0x31e2b8,_0x31e2b8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x31e2b8)]=_0x31e2b8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x31e2b8)]=_0x31e2b8);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x2b895a){const _0x5c4839=Hr(_0x2b895a);return Fi['encodeByteArray'](_0x5c4839,!0x0);},dn=function(_0x287e31){return $r(_0x287e31)['replace'](/\./g,'');},fn=function(_0x1b0c6b){try{return Fi['decodeString'](_0x1b0c6b,!0x0);}catch(_0x2f026e){console['error']('base64Decode\x20failed:\x20',_0x2f026e);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x4f5f6d){return Gr(void 0x0,_0x4f5f6d);}function Gr(_0x18a6e2,_0x57807f){if(!(_0x57807f instanceof Object))return _0x57807f;switch(_0x57807f['constructor']){case Date:const _0x5a89f6=_0x57807f;return new Date(_0x5a89f6['getTime']());case Object:_0x18a6e2===void 0x0&&(_0x18a6e2={});break;case Array:_0x18a6e2=[];break;default:return _0x57807f;}for(const _0x156624 in _0x57807f)!_0x57807f['hasOwnProperty'](_0x156624)||!rc(_0x156624)||(_0x18a6e2[_0x156624]=Gr(_0x18a6e2[_0x156624],_0x57807f[_0x156624]));return _0x18a6e2;}function rc(_0x27b979){return _0x27b979!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1a54db=Ps['__FIREBASE_DEFAULTS__'];if(_0x1a54db)return JSON['parse'](_0x1a54db);},lc=()=>{if(typeof document>'u')return;let _0x795cda;try{_0x795cda=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x8a201a=_0x795cda&&fn(_0x795cda[0x1]);return _0x8a201a&&JSON['parse'](_0x8a201a);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x4b438f){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4b438f);return;}},qr=_0x50b0c5=>{var _0x3320e5,_0x167fc3;return(_0x167fc3=(_0x3320e5=Ui())==null?void 0x0:_0x3320e5['emulatorHosts'])==null?void 0x0:_0x167fc3[_0x50b0c5];},hc=_0x47817f=>{const _0x2dea77=qr(_0x47817f);if(!_0x2dea77)return;const _0xf68559=_0x2dea77['lastIndexOf'](':');if(_0xf68559<=0x0||_0xf68559+0x1===_0x2dea77['length'])throw new Error('Invalid\x20host\x20'+_0x2dea77+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x575139=parseInt(_0x2dea77['substring'](_0xf68559+0x1),0xa);return _0x2dea77[0x0]==='['?[_0x2dea77['substring'](0x1,_0xf68559-0x1),_0x575139]:[_0x2dea77['substring'](0x0,_0xf68559),_0x575139];},zr=()=>{var _0x2a12e4;return(_0x2a12e4=Ui())==null?void 0x0:_0x2a12e4['config'];},jr=_0x25013d=>{var _0x5f03d1;return(_0x5f03d1=Ui())==null?void 0x0:_0x5f03d1['_'+_0x25013d];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x130ed0,_0x1f0f26)=>{this['resolve']=_0x130ed0,this['reject']=_0x1f0f26;});}['wrapCallback'](_0x4a7930){return(_0x3cd943,_0x582ace)=>{_0x3cd943?this['reject'](_0x3cd943):this['resolve'](_0x582ace),typeof _0x4a7930=='function'&&(this['promise']['catch'](()=>{}),_0x4a7930['length']===0x1?_0x4a7930(_0x3cd943):_0x4a7930(_0x3cd943,_0x582ace));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x1edb8a,_0x26e258){if(_0x1edb8a['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1e06cc={'alg':'none','type':'JWT'},_0x25e9e9=_0x26e258||'demo-project',_0xd87553=_0x1edb8a['iat']||0x0,_0x12e659=_0x1edb8a['sub']||_0x1edb8a['user_id'];if(!_0x12e659)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x18b60b={'iss':'https://securetoken.google.com/'+_0x25e9e9,'aud':_0x25e9e9,'iat':_0xd87553,'exp':_0xd87553+0xe10,'auth_time':_0xd87553,'sub':_0x12e659,'user_id':_0x12e659,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x1edb8a};return[dn(JSON['stringify'](_0x1e06cc)),dn(JSON['stringify'](_0x18b60b)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x152f34=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x152f34=='object'&&_0x152f34['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x272125=W();return _0x272125['indexOf']('MSIE\x20')>=0x0||_0x272125['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x16bc97,_0x3ba85e)=>{try{let _0x117fed=!0x0;const _0x4cd211='validate-browser-context-for-indexeddb-analytics-module',_0x4dd22a=self['indexedDB']['open'](_0x4cd211);_0x4dd22a['onsuccess']=()=>{_0x4dd22a['result']['close'](),_0x117fed||self['indexedDB']['deleteDatabase'](_0x4cd211),_0x16bc97(!0x0);},_0x4dd22a['onupgradeneeded']=()=>{_0x117fed=!0x1;},_0x4dd22a['onerror']=()=>{var _0x49813d;_0x3ba85e(((_0x49813d=_0x4dd22a['error'])==null?void 0x0:_0x49813d['message'])||'');};}catch(_0x5a4aa2){_0x3ba85e(_0x5a4aa2);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x4d216f,_0x2e83a4,_0x37b2dd){super(_0x2e83a4),this['code']=_0x4d216f,this['customData']=_0x37b2dd,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x2e5c57,_0x2c6965,_0x4d0de9){this['service']=_0x2e5c57,this['serviceName']=_0x2c6965,this['errors']=_0x4d0de9;}['create'](_0x43eea6,..._0xa1877d){const _0x41aa60=_0xa1877d[0x0]||{},_0xe751cf=this['service']+'/'+_0x43eea6,_0x1bd977=this['errors'][_0x43eea6],_0xd46136=_0x1bd977?vc(_0x1bd977,_0x41aa60):'Error',_0x3035f3=this['serviceName']+':\x20'+_0xd46136+'\x20('+_0xe751cf+').';return new Re(_0xe751cf,_0x3035f3,_0x41aa60);}}function vc(_0x1ec2b3,_0x536162){return _0x1ec2b3['replace'](Ec,(_0xab1c0c,_0x2e1050)=>{const _0x12a0eb=_0x536162[_0x2e1050];return _0x12a0eb!=null?String(_0x12a0eb):'<'+_0x2e1050+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x1f228f){return JSON['parse'](_0x1f228f);}function O(_0x71646a){return JSON['stringify'](_0x71646a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2a9179){let _0x3af4c5={},_0x36e19f={},_0x30cd26={},_0xf211e8='';try{const _0x59942b=_0x2a9179['split']('.');_0x3af4c5=Nt(fn(_0x59942b[0x0])||''),_0x36e19f=Nt(fn(_0x59942b[0x1])||''),_0xf211e8=_0x59942b[0x2],_0x30cd26=_0x36e19f['d']||{},delete _0x36e19f['d'];}catch{}return{'header':_0x3af4c5,'claims':_0x36e19f,'data':_0x30cd26,'signature':_0xf211e8};},Ic=function(_0x290c69){const _0x369289=Yr(_0x290c69),_0x41bd33=_0x369289['claims'];return!!_0x41bd33&&typeof _0x41bd33=='object'&&_0x41bd33['hasOwnProperty']('iat');},wc=function(_0x33105e){const _0x3ab9d7=Yr(_0x33105e)['claims'];return typeof _0x3ab9d7=='object'&&_0x3ab9d7['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x195519,_0x273257){return Object['prototype']['hasOwnProperty']['call'](_0x195519,_0x273257);}function Le(_0x399db8,_0x348d85){if(Object['prototype']['hasOwnProperty']['call'](_0x399db8,_0x348d85))return _0x399db8[_0x348d85];}function pn(_0x2cee0c){for(const _0x46bf6b in _0x2cee0c)if(Object['prototype']['hasOwnProperty']['call'](_0x2cee0c,_0x46bf6b))return!0x1;return!0x0;}function _n(_0x4c8681,_0x4e3020,_0xcd2250){const _0x4cc59c={};for(const _0x3e6a97 in _0x4c8681)Object['prototype']['hasOwnProperty']['call'](_0x4c8681,_0x3e6a97)&&(_0x4cc59c[_0x3e6a97]=_0x4e3020['call'](_0xcd2250,_0x4c8681[_0x3e6a97],_0x3e6a97,_0x4c8681));return _0x4cc59c;}function xe(_0x57100d,_0x324bcc){if(_0x57100d===_0x324bcc)return!0x0;const _0x1b24f2=Object['keys'](_0x57100d),_0x218352=Object['keys'](_0x324bcc);for(const _0xca7944 of _0x1b24f2){if(!_0x218352['includes'](_0xca7944))return!0x1;const _0x101975=_0x57100d[_0xca7944],_0xdba533=_0x324bcc[_0xca7944];if(Ns(_0x101975)&&Ns(_0xdba533)){if(!xe(_0x101975,_0xdba533))return!0x1;}else{if(_0x101975!==_0xdba533)return!0x1;}}for(const _0x4bdfe2 of _0x218352)if(!_0x1b24f2['includes'](_0x4bdfe2))return!0x1;return!0x0;}function Ns(_0x384feb){return _0x384feb!==null&&typeof _0x384feb=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x5043e4){const _0x2d89a4=[];for(const [_0x5f1a3f,_0x4e564f]of Object['entries'](_0x5043e4))Array['isArray'](_0x4e564f)?_0x4e564f['forEach'](_0x4acb66=>{_0x2d89a4['push'](encodeURIComponent(_0x5f1a3f)+'='+encodeURIComponent(_0x4acb66));}):_0x2d89a4['push'](encodeURIComponent(_0x5f1a3f)+'='+encodeURIComponent(_0x4e564f));return _0x2d89a4['length']?'&'+_0x2d89a4['join']('&'):'';}function Ct(_0x59382b){const _0x25de0c={};return _0x59382b['replace'](/^\?/,'')['split']('&')['forEach'](_0x3bafd9=>{if(_0x3bafd9){const [_0x378da9,_0x1196f5]=_0x3bafd9['split']('=');_0x25de0c[decodeURIComponent(_0x378da9)]=decodeURIComponent(_0x1196f5);}}),_0x25de0c;}function Tt(_0x18d46e){const _0x2aaa95=_0x18d46e['indexOf']('?');if(!_0x2aaa95)return'';const _0x54142d=_0x18d46e['indexOf']('#',_0x2aaa95);return _0x18d46e['substring'](_0x2aaa95,_0x54142d>0x0?_0x54142d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x55b52d=0x1;_0x55b52d<this['blockSize'];++_0x55b52d)this['pad_'][_0x55b52d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1bea8e,_0x1329fa){_0x1329fa||(_0x1329fa=0x0);const _0x573554=this['W_'];if(typeof _0x1bea8e=='string'){for(let _0x45563a=0x0;_0x45563a<0x10;_0x45563a++)_0x573554[_0x45563a]=_0x1bea8e['charCodeAt'](_0x1329fa)<<0x18|_0x1bea8e['charCodeAt'](_0x1329fa+0x1)<<0x10|_0x1bea8e['charCodeAt'](_0x1329fa+0x2)<<0x8|_0x1bea8e['charCodeAt'](_0x1329fa+0x3),_0x1329fa+=0x4;}else{for(let _0x14185d=0x0;_0x14185d<0x10;_0x14185d++)_0x573554[_0x14185d]=_0x1bea8e[_0x1329fa]<<0x18|_0x1bea8e[_0x1329fa+0x1]<<0x10|_0x1bea8e[_0x1329fa+0x2]<<0x8|_0x1bea8e[_0x1329fa+0x3],_0x1329fa+=0x4;}for(let _0x47f403=0x10;_0x47f403<0x50;_0x47f403++){const _0x3f7c03=_0x573554[_0x47f403-0x3]^_0x573554[_0x47f403-0x8]^_0x573554[_0x47f403-0xe]^_0x573554[_0x47f403-0x10];_0x573554[_0x47f403]=(_0x3f7c03<<0x1|_0x3f7c03>>>0x1f)&0xffffffff;}let _0x284ad1=this['chain_'][0x0],_0x55874e=this['chain_'][0x1],_0x3dc10e=this['chain_'][0x2],_0x3cb9d3=this['chain_'][0x3],_0x533c36=this['chain_'][0x4],_0x225cd1,_0x27c1f1;for(let _0x1399dc=0x0;_0x1399dc<0x50;_0x1399dc++){_0x1399dc<0x28?_0x1399dc<0x14?(_0x225cd1=_0x3cb9d3^_0x55874e&(_0x3dc10e^_0x3cb9d3),_0x27c1f1=0x5a827999):(_0x225cd1=_0x55874e^_0x3dc10e^_0x3cb9d3,_0x27c1f1=0x6ed9eba1):_0x1399dc<0x3c?(_0x225cd1=_0x55874e&_0x3dc10e|_0x3cb9d3&(_0x55874e|_0x3dc10e),_0x27c1f1=0x8f1bbcdc):(_0x225cd1=_0x55874e^_0x3dc10e^_0x3cb9d3,_0x27c1f1=0xca62c1d6);const _0x238950=(_0x284ad1<<0x5|_0x284ad1>>>0x1b)+_0x225cd1+_0x533c36+_0x27c1f1+_0x573554[_0x1399dc]&0xffffffff;_0x533c36=_0x3cb9d3,_0x3cb9d3=_0x3dc10e,_0x3dc10e=(_0x55874e<<0x1e|_0x55874e>>>0x2)&0xffffffff,_0x55874e=_0x284ad1,_0x284ad1=_0x238950;}this['chain_'][0x0]=this['chain_'][0x0]+_0x284ad1&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x55874e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3dc10e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3cb9d3&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x533c36&0xffffffff;}['update'](_0x120028,_0x17ae46){if(_0x120028==null)return;_0x17ae46===void 0x0&&(_0x17ae46=_0x120028['length']);const _0x54a661=_0x17ae46-this['blockSize'];let _0x223221=0x0;const _0x1b0912=this['buf_'];let _0xa314a7=this['inbuf_'];for(;_0x223221<_0x17ae46;){if(_0xa314a7===0x0){for(;_0x223221<=_0x54a661;)this['compress_'](_0x120028,_0x223221),_0x223221+=this['blockSize'];}if(typeof _0x120028=='string'){for(;_0x223221<_0x17ae46;)if(_0x1b0912[_0xa314a7]=_0x120028['charCodeAt'](_0x223221),++_0xa314a7,++_0x223221,_0xa314a7===this['blockSize']){this['compress_'](_0x1b0912),_0xa314a7=0x0;break;}}else{for(;_0x223221<_0x17ae46;)if(_0x1b0912[_0xa314a7]=_0x120028[_0x223221],++_0xa314a7,++_0x223221,_0xa314a7===this['blockSize']){this['compress_'](_0x1b0912),_0xa314a7=0x0;break;}}}this['inbuf_']=_0xa314a7,this['total_']+=_0x17ae46;}['digest'](){const _0x27a8be=[];let _0x3d62b7=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x54393b=this['blockSize']-0x1;_0x54393b>=0x38;_0x54393b--)this['buf_'][_0x54393b]=_0x3d62b7&0xff,_0x3d62b7/=0x100;this['compress_'](this['buf_']);let _0x3d5c76=0x0;for(let _0x289950=0x0;_0x289950<0x5;_0x289950++)for(let _0x9c2ea1=0x18;_0x9c2ea1>=0x0;_0x9c2ea1-=0x8)_0x27a8be[_0x3d5c76]=this['chain_'][_0x289950]>>_0x9c2ea1&0xff,++_0x3d5c76;return _0x27a8be;}}function Tc(_0x4bc2db,_0x27594d){const _0x581428=new Sc(_0x4bc2db,_0x27594d);return _0x581428['subscribe']['bind'](_0x581428);}class Sc{constructor(_0x1538c9,_0x3e39bb){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3e39bb,this['task']['then'](()=>{_0x1538c9(this);})['catch'](_0x6f75f6=>{this['error'](_0x6f75f6);});}['next'](_0x29ea18){this['forEachObserver'](_0x1a1080=>{_0x1a1080['next'](_0x29ea18);});}['error'](_0x3a6ebd){this['forEachObserver'](_0x27a4bf=>{_0x27a4bf['error'](_0x3a6ebd);}),this['close'](_0x3a6ebd);}['complete'](){this['forEachObserver'](_0x1b3dae=>{_0x1b3dae['complete']();}),this['close']();}['subscribe'](_0x59f37c,_0x33504f,_0x5a80f8){let _0x3c2deb;if(_0x59f37c===void 0x0&&_0x33504f===void 0x0&&_0x5a80f8===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x59f37c,['next','error','complete'])?_0x3c2deb=_0x59f37c:_0x3c2deb={'next':_0x59f37c,'error':_0x33504f,'complete':_0x5a80f8},_0x3c2deb['next']===void 0x0&&(_0x3c2deb['next']=ti),_0x3c2deb['error']===void 0x0&&(_0x3c2deb['error']=ti),_0x3c2deb['complete']===void 0x0&&(_0x3c2deb['complete']=ti);const _0x2fe29a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3c2deb['error'](this['finalError']):_0x3c2deb['complete']();}catch{}}),this['observers']['push'](_0x3c2deb),_0x2fe29a;}['unsubscribeOne'](_0x551ffa){this['observers']===void 0x0||this['observers'][_0x551ffa]===void 0x0||(delete this['observers'][_0x551ffa],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x39e38c){if(!this['finalized']){for(let _0x4237e7=0x0;_0x4237e7<this['observers']['length'];_0x4237e7++)this['sendOne'](_0x4237e7,_0x39e38c);}}['sendOne'](_0x3a79fb,_0x58a47d){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3a79fb]!==void 0x0)try{_0x58a47d(this['observers'][_0x3a79fb]);}catch(_0x11a227){typeof console<'u'&&console['error']&&console['error'](_0x11a227);}});}['close'](_0x1f3b9f){this['finalized']||(this['finalized']=!0x0,_0x1f3b9f!==void 0x0&&(this['finalError']=_0x1f3b9f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x22f81e,_0x5babc3){if(typeof _0x22f81e!='object'||_0x22f81e===null)return!0x1;for(const _0x5b4fcd of _0x5babc3)if(_0x5b4fcd in _0x22f81e&&typeof _0x22f81e[_0x5b4fcd]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x3a312f,_0x3e1c43){return _0x3a312f+'\x20failed:\x20'+_0x3e1c43+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0xe45999){const _0x5d3de3=[];let _0x1b05d4=0x0;for(let _0x560156=0x0;_0x560156<_0xe45999['length'];_0x560156++){let _0x1cc1b4=_0xe45999['charCodeAt'](_0x560156);if(_0x1cc1b4>=0xd800&&_0x1cc1b4<=0xdbff){const _0x1ebbe2=_0x1cc1b4-0xd800;_0x560156++,f(_0x560156<_0xe45999['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x535d88=_0xe45999['charCodeAt'](_0x560156)-0xdc00;_0x1cc1b4=0x10000+(_0x1ebbe2<<0xa)+_0x535d88;}_0x1cc1b4<0x80?_0x5d3de3[_0x1b05d4++]=_0x1cc1b4:_0x1cc1b4<0x800?(_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0x6|0xc0,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4&0x3f|0x80):_0x1cc1b4<0x10000?(_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0xc|0xe0,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0x6&0x3f|0x80,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4&0x3f|0x80):(_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0x12|0xf0,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0xc&0x3f|0x80,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4>>0x6&0x3f|0x80,_0x5d3de3[_0x1b05d4++]=_0x1cc1b4&0x3f|0x80);}return _0x5d3de3;},Ln=function(_0x499656){let _0x451469=0x0;for(let _0x38ec5d=0x0;_0x38ec5d<_0x499656['length'];_0x38ec5d++){const _0x37b248=_0x499656['charCodeAt'](_0x38ec5d);_0x37b248<0x80?_0x451469++:_0x37b248<0x800?_0x451469+=0x2:_0x37b248>=0xd800&&_0x37b248<=0xdbff?(_0x451469+=0x4,_0x38ec5d++):_0x451469+=0x3;}return _0x451469;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x54d150){return _0x54d150&&_0x54d150['_delegate']?_0x54d150['_delegate']:_0x54d150;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x1c1409){try{return(_0x1c1409['startsWith']('http://')||_0x1c1409['startsWith']('https://')?new URL(_0x1c1409)['hostname']:_0x1c1409)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3d0490){return(await fetch(_0x3d0490,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x365253,_0x5e53a4,_0xb9d552){this['name']=_0x365253,this['instanceFactory']=_0x5e53a4,this['type']=_0xb9d552,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2054fd){return this['instantiationMode']=_0x2054fd,this;}['setMultipleInstances'](_0x1a5b0a){return this['multipleInstances']=_0x1a5b0a,this;}['setServiceProps'](_0x4c9278){return this['serviceProps']=_0x4c9278,this;}['setInstanceCreatedCallback'](_0x307b59){return this['onInstanceCreated']=_0x307b59,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1c47c2,_0x12196b){this['name']=_0x1c47c2,this['container']=_0x12196b,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x40f58c){const _0x1a6b2d=this['normalizeInstanceIdentifier'](_0x40f58c);if(!this['instancesDeferred']['has'](_0x1a6b2d)){const _0x200dc2=new H();if(this['instancesDeferred']['set'](_0x1a6b2d,_0x200dc2),this['isInitialized'](_0x1a6b2d)||this['shouldAutoInitialize']())try{const _0x56b9c6=this['getOrInitializeService']({'instanceIdentifier':_0x1a6b2d});_0x56b9c6&&_0x200dc2['resolve'](_0x56b9c6);}catch{}}return this['instancesDeferred']['get'](_0x1a6b2d)['promise'];}['getImmediate'](_0x1a02f2){const _0x47a783=this['normalizeInstanceIdentifier'](_0x1a02f2==null?void 0x0:_0x1a02f2['identifier']),_0x55a082=(_0x1a02f2==null?void 0x0:_0x1a02f2['optional'])??!0x1;if(this['isInitialized'](_0x47a783)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x47a783});}catch(_0x3eedec){if(_0x55a082)return null;throw _0x3eedec;}else{if(_0x55a082)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x789b7){if(_0x789b7['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x789b7['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x789b7,!!this['shouldAutoInitialize']()){if(Pc(_0x789b7))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x2b2a8f,_0x24fe5b]of this['instancesDeferred']['entries']()){const _0x2d6306=this['normalizeInstanceIdentifier'](_0x2b2a8f);try{const _0x30bbb1=this['getOrInitializeService']({'instanceIdentifier':_0x2d6306});_0x24fe5b['resolve'](_0x30bbb1);}catch{}}}}['clearInstance'](_0x2eeabc=Ne){this['instancesDeferred']['delete'](_0x2eeabc),this['instancesOptions']['delete'](_0x2eeabc),this['instances']['delete'](_0x2eeabc);}async['delete'](){const _0x50520=Array['from'](this['instances']['values']());await Promise['all']([..._0x50520['filter'](_0x34d5ef=>'INTERNAL'in _0x34d5ef)['map'](_0x38dff5=>_0x38dff5['INTERNAL']['delete']()),..._0x50520['filter'](_0x285045=>'_delete'in _0x285045)['map'](_0x1e4dab=>_0x1e4dab['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1d380e=Ne){return this['instances']['has'](_0x1d380e);}['getOptions'](_0x577169=Ne){return this['instancesOptions']['get'](_0x577169)||{};}['initialize'](_0x319c54={}){const {options:_0x51be09={}}=_0x319c54,_0x449ffb=this['normalizeInstanceIdentifier'](_0x319c54['instanceIdentifier']);if(this['isInitialized'](_0x449ffb))throw Error(this['name']+'('+_0x449ffb+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x40377c=this['getOrInitializeService']({'instanceIdentifier':_0x449ffb,'options':_0x51be09});for(const [_0x472077,_0x9017c]of this['instancesDeferred']['entries']()){const _0x2ae2af=this['normalizeInstanceIdentifier'](_0x472077);_0x449ffb===_0x2ae2af&&_0x9017c['resolve'](_0x40377c);}return _0x40377c;}['onInit'](_0x2816fe,_0x5db331){const _0x412675=this['normalizeInstanceIdentifier'](_0x5db331),_0xbc8d81=this['onInitCallbacks']['get'](_0x412675)??new Set();_0xbc8d81['add'](_0x2816fe),this['onInitCallbacks']['set'](_0x412675,_0xbc8d81);const _0x3f5178=this['instances']['get'](_0x412675);return _0x3f5178&&_0x2816fe(_0x3f5178,_0x412675),()=>{_0xbc8d81['delete'](_0x2816fe);};}['invokeOnInitCallbacks'](_0x3133d7,_0x462469){const _0x49e9da=this['onInitCallbacks']['get'](_0x462469);if(_0x49e9da){for(const _0x566da4 of _0x49e9da)try{_0x566da4(_0x3133d7,_0x462469);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x46c141,options:_0x15cf83={}}){let _0x5c42ff=this['instances']['get'](_0x46c141);if(!_0x5c42ff&&this['component']&&(_0x5c42ff=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x46c141),'options':_0x15cf83}),this['instances']['set'](_0x46c141,_0x5c42ff),this['instancesOptions']['set'](_0x46c141,_0x15cf83),this['invokeOnInitCallbacks'](_0x5c42ff,_0x46c141),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x46c141,_0x5c42ff);}catch{}return _0x5c42ff||null;}['normalizeInstanceIdentifier'](_0x12f40e=Ne){return this['component']?this['component']['multipleInstances']?_0x12f40e:Ne:_0x12f40e;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5936a3){return _0x5936a3===Ne?void 0x0:_0x5936a3;}function Pc(_0x41e6a8){return _0x41e6a8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4aaf71){this['name']=_0x4aaf71,this['providers']=new Map();}['addComponent'](_0x463ed2){const _0x4842f6=this['getProvider'](_0x463ed2['name']);if(_0x4842f6['isComponentSet']())throw new Error('Component\x20'+_0x463ed2['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4842f6['setComponent'](_0x463ed2);}['addOrOverwriteComponent'](_0x127cdc){this['getProvider'](_0x127cdc['name'])['isComponentSet']()&&this['providers']['delete'](_0x127cdc['name']),this['addComponent'](_0x127cdc);}['getProvider'](_0x55daab){if(this['providers']['has'](_0x55daab))return this['providers']['get'](_0x55daab);const _0x2ce17f=new Ac(_0x55daab,this);return this['providers']['set'](_0x55daab,_0x2ce17f),_0x2ce17f;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x14bda9){_0x14bda9[_0x14bda9['DEBUG']=0x0]='DEBUG',_0x14bda9[_0x14bda9['VERBOSE']=0x1]='VERBOSE',_0x14bda9[_0x14bda9['INFO']=0x2]='INFO',_0x14bda9[_0x14bda9['WARN']=0x3]='WARN',_0x14bda9[_0x14bda9['ERROR']=0x4]='ERROR',_0x14bda9[_0x14bda9['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x27ddae,_0x5add2b,..._0x1b24f7)=>{if(_0x5add2b<_0x27ddae['logLevel'])return;const _0x4119ee=new Date()['toISOString'](),_0x5c5ffe=Mc[_0x5add2b];if(_0x5c5ffe)console[_0x5c5ffe]('['+_0x4119ee+']\x20\x20'+_0x27ddae['name']+':',..._0x1b24f7);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5add2b+')');};class Bi{constructor(_0xd4c87b){this['name']=_0xd4c87b,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5b05cb){if(!(_0x5b05cb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5b05cb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5b05cb;}['setLogLevel'](_0x2f53cc){this['_logLevel']=typeof _0x2f53cc=='string'?Oc[_0x2f53cc]:_0x2f53cc;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x204782){if(typeof _0x204782!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x204782;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1cf5a1){this['_userLogHandler']=_0x1cf5a1;}['debug'](..._0x2a7e37){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2a7e37),this['_logHandler'](this,T['DEBUG'],..._0x2a7e37);}['log'](..._0x276e6f){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x276e6f),this['_logHandler'](this,T['VERBOSE'],..._0x276e6f);}['info'](..._0x548725){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x548725),this['_logHandler'](this,T['INFO'],..._0x548725);}['warn'](..._0x151168){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x151168),this['_logHandler'](this,T['WARN'],..._0x151168);}['error'](..._0x2e4bce){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2e4bce),this['_logHandler'](this,T['ERROR'],..._0x2e4bce);}}const xc=(_0x314260,_0xe43968)=>_0xe43968['some'](_0x4faedc=>_0x314260 instanceof _0x4faedc);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x240843){const _0x22a634=new Promise((_0x10d646,_0x49fe00)=>{const _0x3d5cf1=()=>{_0x240843['removeEventListener']('success',_0x362738),_0x240843['removeEventListener']('error',_0x47bb8d);},_0x362738=()=>{_0x10d646(ge(_0x240843['result'])),_0x3d5cf1();},_0x47bb8d=()=>{_0x49fe00(_0x240843['error']),_0x3d5cf1();};_0x240843['addEventListener']('success',_0x362738),_0x240843['addEventListener']('error',_0x47bb8d);});return _0x22a634['then'](_0x835bbf=>{_0x835bbf instanceof IDBCursor&&Jr['set'](_0x835bbf,_0x240843);})['catch'](()=>{}),Vi['set'](_0x22a634,_0x240843),_0x22a634;}function Bc(_0x291a9a){if(_i['has'](_0x291a9a))return;const _0x464e2c=new Promise((_0x1c3e33,_0x3b347e)=>{const _0x42341f=()=>{_0x291a9a['removeEventListener']('complete',_0x3edc5a),_0x291a9a['removeEventListener']('error',_0x205f60),_0x291a9a['removeEventListener']('abort',_0x205f60);},_0x3edc5a=()=>{_0x1c3e33(),_0x42341f();},_0x205f60=()=>{_0x3b347e(_0x291a9a['error']||new DOMException('AbortError','AbortError')),_0x42341f();};_0x291a9a['addEventListener']('complete',_0x3edc5a),_0x291a9a['addEventListener']('error',_0x205f60),_0x291a9a['addEventListener']('abort',_0x205f60);});_i['set'](_0x291a9a,_0x464e2c);}let gi={'get'(_0xd1c2c6,_0x1d1232,_0x17e94c){if(_0xd1c2c6 instanceof IDBTransaction){if(_0x1d1232==='done')return _i['get'](_0xd1c2c6);if(_0x1d1232==='objectStoreNames')return _0xd1c2c6['objectStoreNames']||Xr['get'](_0xd1c2c6);if(_0x1d1232==='store')return _0x17e94c['objectStoreNames'][0x1]?void 0x0:_0x17e94c['objectStore'](_0x17e94c['objectStoreNames'][0x0]);}return ge(_0xd1c2c6[_0x1d1232]);},'set'(_0x2a3199,_0x55773e,_0x1d3e6e){return _0x2a3199[_0x55773e]=_0x1d3e6e,!0x0;},'has'(_0x217478,_0x3bd2b8){return _0x217478 instanceof IDBTransaction&&(_0x3bd2b8==='done'||_0x3bd2b8==='store')?!0x0:_0x3bd2b8 in _0x217478;}};function Vc(_0x4f1448){gi=_0x4f1448(gi);}function Hc(_0x428fb9){return _0x428fb9===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x1a30c6,..._0x459315){const _0x3e7444=_0x428fb9['call'](ii(this),_0x1a30c6,..._0x459315);return Xr['set'](_0x3e7444,_0x1a30c6['sort']?_0x1a30c6['sort']():[_0x1a30c6]),ge(_0x3e7444);}:Uc()['includes'](_0x428fb9)?function(..._0x1095bb){return _0x428fb9['apply'](ii(this),_0x1095bb),ge(Jr['get'](this));}:function(..._0x1cbf23){return ge(_0x428fb9['apply'](ii(this),_0x1cbf23));};}function $c(_0x43c006){return typeof _0x43c006=='function'?Hc(_0x43c006):(_0x43c006 instanceof IDBTransaction&&Bc(_0x43c006),xc(_0x43c006,Fc())?new Proxy(_0x43c006,gi):_0x43c006);}function ge(_0x96e38){if(_0x96e38 instanceof IDBRequest)return Wc(_0x96e38);if(ni['has'](_0x96e38))return ni['get'](_0x96e38);const _0x283d9f=$c(_0x96e38);return _0x283d9f!==_0x96e38&&(ni['set'](_0x96e38,_0x283d9f),Vi['set'](_0x283d9f,_0x96e38)),_0x283d9f;}const ii=_0x39741c=>Vi['get'](_0x39741c);function Gc(_0x3d415f,_0x1e7c7a,{blocked:_0x3f293f,upgrade:_0x1040e0,blocking:_0x354a07,terminated:_0x16d8a0}={}){const _0x36c1b8=indexedDB['open'](_0x3d415f,_0x1e7c7a),_0x53cf0d=ge(_0x36c1b8);return _0x1040e0&&_0x36c1b8['addEventListener']('upgradeneeded',_0x3c6cce=>{_0x1040e0(ge(_0x36c1b8['result']),_0x3c6cce['oldVersion'],_0x3c6cce['newVersion'],ge(_0x36c1b8['transaction']),_0x3c6cce);}),_0x3f293f&&_0x36c1b8['addEventListener']('blocked',_0x24c6dc=>_0x3f293f(_0x24c6dc['oldVersion'],_0x24c6dc['newVersion'],_0x24c6dc)),_0x53cf0d['then'](_0x291b4c=>{_0x16d8a0&&_0x291b4c['addEventListener']('close',()=>_0x16d8a0()),_0x354a07&&_0x291b4c['addEventListener']('versionchange',_0x455c41=>_0x354a07(_0x455c41['oldVersion'],_0x455c41['newVersion'],_0x455c41));})['catch'](()=>{}),_0x53cf0d;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x49fdbc,_0x33b030){if(!(_0x49fdbc instanceof IDBDatabase&&!(_0x33b030 in _0x49fdbc)&&typeof _0x33b030=='string'))return;if(si['get'](_0x33b030))return si['get'](_0x33b030);const _0x1ad510=_0x33b030['replace'](/FromIndex$/,''),_0x31cde5=_0x33b030!==_0x1ad510,_0x40ef1f=zc['includes'](_0x1ad510);if(!(_0x1ad510 in(_0x31cde5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x40ef1f||qc['includes'](_0x1ad510)))return;const _0x4c1cb5=async function(_0x1c2207,..._0xd406d){const _0x14b996=this['transaction'](_0x1c2207,_0x40ef1f?'readwrite':'readonly');let _0x5a6dc6=_0x14b996['store'];return _0x31cde5&&(_0x5a6dc6=_0x5a6dc6['index'](_0xd406d['shift']())),(await Promise['all']([_0x5a6dc6[_0x1ad510](..._0xd406d),_0x40ef1f&&_0x14b996['done']]))[0x0];};return si['set'](_0x33b030,_0x4c1cb5),_0x4c1cb5;}Vc(_0x281338=>({..._0x281338,'get':(_0x5f040d,_0x5812e5,_0x4a089b)=>Ms(_0x5f040d,_0x5812e5)||_0x281338['get'](_0x5f040d,_0x5812e5,_0x4a089b),'has':(_0x4fd72c,_0xc7e577)=>!!Ms(_0x4fd72c,_0xc7e577)||_0x281338['has'](_0x4fd72c,_0xc7e577)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x43e348){this['container']=_0x43e348;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x386b40=>{if(Kc(_0x386b40)){const _0x4c2006=_0x386b40['getImmediate']();return _0x4c2006['library']+'/'+_0x4c2006['version'];}else return null;})['filter'](_0x12dcb4=>_0x12dcb4)['join']('\x20');}}function Kc(_0xe7d76f){const _0x5336fd=_0xe7d76f['getComponent']();return(_0x5336fd==null?void 0x0:_0x5336fd['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x47e826,_0x2198c9){try{_0x47e826['container']['addComponent'](_0x2198c9);}catch(_0x33d6c3){oe['debug']('Component\x20'+_0x2198c9['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x47e826['name'],_0x33d6c3);}}function st(_0x4584e4){const _0xfd487f=_0x4584e4['name'];if(Ei['has'](_0xfd487f))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xfd487f+'.'),!0x1;Ei['set'](_0xfd487f,_0x4584e4);for(const _0x13b7af of Ue['values']())xs(_0x13b7af,_0x4584e4);for(const _0x50f71a of vi['values']())xs(_0x50f71a,_0x4584e4);return!0x0;}function Hi(_0x5d2d55,_0x1024e4){const _0x286d09=_0x5d2d55['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x286d09&&_0x286d09['triggerHeartbeat'](),_0x5d2d55['container']['getProvider'](_0x1024e4);}function $(_0x4e85de){return _0x4e85de==null?!0x1:_0x4e85de['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x20917d,_0x55b723,_0x50aa6d){this['_isDeleted']=!0x1,this['_options']={..._0x20917d},this['_config']={..._0x55b723},this['_name']=_0x55b723['name'],this['_automaticDataCollectionEnabled']=_0x55b723['automaticDataCollectionEnabled'],this['_container']=_0x50aa6d,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x433056){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x433056;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x14ab38){this['_isDeleted']=_0x14ab38;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1251d6,_0x3ecccf={}){let _0xcbd10a=_0x1251d6;typeof _0x3ecccf!='object'&&(_0x3ecccf={'name':_0x3ecccf});const _0x5f4f2e={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x3ecccf},_0x432067=_0x5f4f2e['name'];if(typeof _0x432067!='string'||!_0x432067)throw me['create']('bad-app-name',{'appName':String(_0x432067)});if(_0xcbd10a||(_0xcbd10a=zr()),!_0xcbd10a)throw me['create']('no-options');const _0x1e37d4=Ue['get'](_0x432067);if(_0x1e37d4){if(xe(_0xcbd10a,_0x1e37d4['options'])&&xe(_0x5f4f2e,_0x1e37d4['config']))return _0x1e37d4;throw me['create']('duplicate-app',{'appName':_0x432067});}const _0xcdcbef=new Nc(_0x432067);for(const _0x3b1dd2 of Ei['values']())_0xcdcbef['addComponent'](_0x3b1dd2);const _0x2c34bc=new Tl(_0xcbd10a,_0x5f4f2e,_0xcdcbef);return Ue['set'](_0x432067,_0x2c34bc),_0x2c34bc;}function Zr(_0x5bfac9=yi){const _0x5b1acb=Ue['get'](_0x5bfac9);if(!_0x5b1acb&&_0x5bfac9===yi&&zr())return Sl();if(!_0x5b1acb)throw me['create']('no-app',{'appName':_0x5bfac9});return _0x5b1acb;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x5e73c4){let _0x150693=!0x1;const _0x6f2d48=_0x5e73c4['name'];Ue['has'](_0x6f2d48)?(_0x150693=!0x0,Ue['delete'](_0x6f2d48)):vi['has'](_0x6f2d48)&&_0x5e73c4['decRefCount']()<=0x0&&(vi['delete'](_0x6f2d48),_0x150693=!0x0),_0x150693&&(await Promise['all'](_0x5e73c4['container']['getProviders']()['map'](_0x363c22=>_0x363c22['delete']())),_0x5e73c4['isDeleted']=!0x0);}function ye(_0x14ff8c,_0x503cd7,_0x491214){let _0x5f0529=wl[_0x14ff8c]??_0x14ff8c;_0x491214&&(_0x5f0529+='-'+_0x491214);const _0x2384de=_0x5f0529['match'](/\s|\//),_0x58d20c=_0x503cd7['match'](/\s|\//);if(_0x2384de||_0x58d20c){const _0x292fe7=['Unable\x20to\x20register\x20library\x20\x22'+_0x5f0529+'\x22\x20with\x20version\x20\x22'+_0x503cd7+'\x22:'];_0x2384de&&_0x292fe7['push']('library\x20name\x20\x22'+_0x5f0529+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2384de&&_0x58d20c&&_0x292fe7['push']('and'),_0x58d20c&&_0x292fe7['push']('version\x20name\x20\x22'+_0x503cd7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x292fe7['join']('\x20'));return;}st(new Fe(_0x5f0529+'-version',()=>({'library':_0x5f0529,'version':_0x503cd7}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x262098,_0x3cc36b)=>{switch(_0x3cc36b){case 0x0:try{_0x262098['createObjectStore'](Ot);}catch(_0x27f9a8){console['warn'](_0x27f9a8);}}}})['catch'](_0x409633=>{throw me['create']('idb-open',{'originalErrorMessage':_0x409633['message']});})),ri;}async function Al(_0x2801ab){try{const _0x1820be=(await eo())['transaction'](Ot),_0x212038=await _0x1820be['objectStore'](Ot)['get'](to(_0x2801ab));return await _0x1820be['done'],_0x212038;}catch(_0x59a911){if(_0x59a911 instanceof Re)oe['warn'](_0x59a911['message']);else{const _0x1d8dcb=me['create']('idb-get',{'originalErrorMessage':_0x59a911==null?void 0x0:_0x59a911['message']});oe['warn'](_0x1d8dcb['message']);}}}async function Fs(_0x94206c,_0x4af5e7){try{const _0x28e707=(await eo())['transaction'](Ot,'readwrite');await _0x28e707['objectStore'](Ot)['put'](_0x4af5e7,to(_0x94206c)),await _0x28e707['done'];}catch(_0x399bb6){if(_0x399bb6 instanceof Re)oe['warn'](_0x399bb6['message']);else{const _0x507839=me['create']('idb-set',{'originalErrorMessage':_0x399bb6==null?void 0x0:_0x399bb6['message']});oe['warn'](_0x507839['message']);}}}function to(_0x4b0c54){return _0x4b0c54['name']+'!'+_0x4b0c54['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x161fb6){this['container']=_0x161fb6,this['_heartbeatsCache']=null;const _0x1f5e40=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1f5e40),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x381c3e=>(this['_heartbeatsCache']=_0x381c3e,_0x381c3e));}async['triggerHeartbeat'](){var _0x5dd6ee,_0x9bd0bc;try{const _0xe3389d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xbf5ea2=Us();if(((_0x5dd6ee=this['_heartbeatsCache'])==null?void 0x0:_0x5dd6ee['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x9bd0bc=this['_heartbeatsCache'])==null?void 0x0:_0x9bd0bc['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xbf5ea2||this['_heartbeatsCache']['heartbeats']['some'](_0x39c0d9=>_0x39c0d9['date']===_0xbf5ea2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xbf5ea2,'agent':_0xe3389d}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x14188f=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x14188f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x20213f){oe['warn'](_0x20213f);}}async['getHeartbeatsHeader'](){var _0x21560e;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x21560e=this['_heartbeatsCache'])==null?void 0x0:_0x21560e['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1c94a1=Us(),{heartbeatsToSend:_0x9af29a,unsentEntries:_0x10d111}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4afbd=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x9af29a}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1c94a1,_0x10d111['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x10d111,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4afbd;}catch(_0x19dace){return oe['warn'](_0x19dace),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x35dd86,_0x436d17=kl){const _0xd2ef42=[];let _0x8f2e7=_0x35dd86['slice']();for(const _0x2464ce of _0x35dd86){const _0x1b1575=_0xd2ef42['find'](_0x190783=>_0x190783['agent']===_0x2464ce['agent']);if(_0x1b1575){if(_0x1b1575['dates']['push'](_0x2464ce['date']),Ws(_0xd2ef42)>_0x436d17){_0x1b1575['dates']['pop']();break;}}else{if(_0xd2ef42['push']({'agent':_0x2464ce['agent'],'dates':[_0x2464ce['date']]}),Ws(_0xd2ef42)>_0x436d17){_0xd2ef42['pop']();break;}}_0x8f2e7=_0x8f2e7['slice'](0x1);}return{'heartbeatsToSend':_0xd2ef42,'unsentEntries':_0x8f2e7};}class Dl{constructor(_0x3c7d82){this['app']=_0x3c7d82,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2c46d8=await Al(this['app']);return _0x2c46d8!=null&&_0x2c46d8['heartbeats']?_0x2c46d8:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2d98a){if(await this['_canUseIndexedDBPromise']){const _0xa3d3e8=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2d98a['lastSentHeartbeatDate']??_0xa3d3e8['lastSentHeartbeatDate'],'heartbeats':_0x2d98a['heartbeats']});}else return;}async['add'](_0xf4f261){if(await this['_canUseIndexedDBPromise']){const _0x414d22=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xf4f261['lastSentHeartbeatDate']??_0x414d22['lastSentHeartbeatDate'],'heartbeats':[..._0x414d22['heartbeats'],..._0xf4f261['heartbeats']]});}else return;}}function Ws(_0x16da5b){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x16da5b}))['length'];}function Ml(_0x24b7ff){if(_0x24b7ff['length']===0x0)return-0x1;let _0x155584=0x0,_0x5b515c=_0x24b7ff[0x0]['date'];for(let _0x52c58e=0x1;_0x52c58e<_0x24b7ff['length'];_0x52c58e++)_0x24b7ff[_0x52c58e]['date']<_0x5b515c&&(_0x5b515c=_0x24b7ff[_0x52c58e]['date'],_0x155584=_0x52c58e);return _0x155584;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x21a79b){st(new Fe('platform-logger',_0x12561e=>new jc(_0x12561e),'PRIVATE')),st(new Fe('heartbeat',_0x360cae=>new Nl(_0x360cae),'PRIVATE')),ye(mi,Ls,_0x21a79b),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x565f12){no=_0x565f12;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5c5688){this['domStorage_']=_0x5c5688,this['prefix_']='firebase:';}['set'](_0x35e1b1,_0x4a5050){_0x4a5050==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x35e1b1)):this['domStorage_']['setItem'](this['prefixedName_'](_0x35e1b1),O(_0x4a5050));}['get'](_0x1fa3b9){const _0x54faf1=this['domStorage_']['getItem'](this['prefixedName_'](_0x1fa3b9));return _0x54faf1==null?null:Nt(_0x54faf1);}['remove'](_0x15f457){this['domStorage_']['removeItem'](this['prefixedName_'](_0x15f457));}['prefixedName_'](_0x20436e){return this['prefix_']+_0x20436e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x438d59,_0x103d1b){_0x103d1b==null?delete this['cache_'][_0x438d59]:this['cache_'][_0x438d59]=_0x103d1b;}['get'](_0x38291e){return Q(this['cache_'],_0x38291e)?this['cache_'][_0x38291e]:null;}['remove'](_0xf2ec48){delete this['cache_'][_0xf2ec48];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x485c26){try{if(typeof window<'u'&&typeof window[_0x485c26]<'u'){const _0x46fe46=window[_0x485c26];return _0x46fe46['setItem']('firebase:sentinel','cache'),_0x46fe46['removeItem']('firebase:sentinel'),new Wl(_0x46fe46);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4d6f87=0x1;return function(){return _0x4d6f87++;};}()),ro=function(_0x3a5539){const _0x4ecdc1=Rc(_0x3a5539),_0x360c18=new Cc();_0x360c18['update'](_0x4ecdc1);const _0x16ff6f=_0x360c18['digest']();return Fi['encodeByteArray'](_0x16ff6f);},zt=function(..._0x399930){let _0x119bc5='';for(let _0x4fb2d1=0x0;_0x4fb2d1<_0x399930['length'];_0x4fb2d1++){const _0x180454=_0x399930[_0x4fb2d1];Array['isArray'](_0x180454)||_0x180454&&typeof _0x180454=='object'&&typeof _0x180454['length']=='number'?_0x119bc5+=zt['apply'](null,_0x180454):typeof _0x180454=='object'?_0x119bc5+=O(_0x180454):_0x119bc5+=_0x180454,_0x119bc5+='\x20';}return _0x119bc5;};let St=null,$s=!0x0;const Hl=function(_0x243ebc,_0x11dcdc){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x142e11){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x394dfc=zt['apply'](null,_0x142e11);St(_0x394dfc);}},jt=function(_0x35a596){return function(..._0x422226){L(_0x35a596,..._0x422226);};},Ii=function(..._0x387252){const _0x22a072='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x387252);Ze['error'](_0x22a072);},ae=function(..._0x44a5bb){const _0x5e07e6='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x44a5bb);throw Ze['error'](_0x5e07e6),new Error(_0x5e07e6);},U=function(..._0x252eff){const _0x2a9266='FIREBASE\x20WARNING:\x20'+zt(..._0x252eff);Ze['warn'](_0x2a9266);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5bba3a){return typeof _0x5bba3a=='number'&&(_0x5bba3a!==_0x5bba3a||_0x5bba3a===Number['POSITIVE_INFINITY']||_0x5bba3a===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4b8d5f){if(document['readyState']==='complete')_0x4b8d5f();else{let _0x4118c3=!0x1;const _0x448818=function(){if(!document['body']){setTimeout(_0x448818,Math['floor'](0xa));return;}_0x4118c3||(_0x4118c3=!0x0,_0x4b8d5f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x448818,!0x1),window['addEventListener']('load',_0x448818,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x448818();}),window['attachEvent']('onload',_0x448818));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x251c55,_0x53cd60){if(_0x251c55===_0x53cd60)return 0x0;if(_0x251c55===We||_0x53cd60===we)return-0x1;if(_0x53cd60===We||_0x251c55===we)return 0x1;{const _0x503e42=Gs(_0x251c55),_0x56ec2c=Gs(_0x53cd60);return _0x503e42!==null?_0x56ec2c!==null?_0x503e42-_0x56ec2c===0x0?_0x251c55['length']-_0x53cd60['length']:_0x503e42-_0x56ec2c:-0x1:_0x56ec2c!==null?0x1:_0x251c55<_0x53cd60?-0x1:0x1;}},ql=function(_0x529e3b,_0x1b3665){return _0x529e3b===_0x1b3665?0x0:_0x529e3b<_0x1b3665?-0x1:0x1;},vt=function(_0x4174b5,_0x71bb8a){if(_0x71bb8a&&_0x4174b5 in _0x71bb8a)return _0x71bb8a[_0x4174b5];throw new Error('Missing\x20required\x20key\x20('+_0x4174b5+')\x20in\x20object:\x20'+O(_0x71bb8a));},$i=function(_0x4be901){if(typeof _0x4be901!='object'||_0x4be901===null)return O(_0x4be901);const _0x326d03=[];for(const _0x24113f in _0x4be901)_0x326d03['push'](_0x24113f);_0x326d03['sort']();let _0x562f8f='{';for(let _0xbec586=0x0;_0xbec586<_0x326d03['length'];_0xbec586++)_0xbec586!==0x0&&(_0x562f8f+=','),_0x562f8f+=O(_0x326d03[_0xbec586]),_0x562f8f+=':',_0x562f8f+=$i(_0x4be901[_0x326d03[_0xbec586]]);return _0x562f8f+='}',_0x562f8f;},oo=function(_0xd16cc4,_0x1cffca){const _0x19a2ed=_0xd16cc4['length'];if(_0x19a2ed<=_0x1cffca)return[_0xd16cc4];const _0xe3270c=[];for(let _0x576d35=0x0;_0x576d35<_0x19a2ed;_0x576d35+=_0x1cffca)_0x576d35+_0x1cffca>_0x19a2ed?_0xe3270c['push'](_0xd16cc4['substring'](_0x576d35,_0x19a2ed)):_0xe3270c['push'](_0xd16cc4['substring'](_0x576d35,_0x576d35+_0x1cffca));return _0xe3270c;};function x(_0x577205,_0x886ef5){for(const _0x378e97 in _0x577205)_0x577205['hasOwnProperty'](_0x378e97)&&_0x886ef5(_0x378e97,_0x577205[_0x378e97]);}const ao=function(_0x269e44){f(!xn(_0x269e44),'Invalid\x20JSON\x20number');const _0x55a5b0=0xb,_0x12552a=0x34,_0x1d0968=(0x1<<_0x55a5b0-0x1)-0x1;let _0x1d2324,_0x513f26,_0x20f4ec,_0x389c89,_0x3d2fe6;_0x269e44===0x0?(_0x513f26=0x0,_0x20f4ec=0x0,_0x1d2324=0x1/_0x269e44===-0x1/0x0?0x1:0x0):(_0x1d2324=_0x269e44<0x0,_0x269e44=Math['abs'](_0x269e44),_0x269e44>=Math['pow'](0x2,0x1-_0x1d0968)?(_0x389c89=Math['min'](Math['floor'](Math['log'](_0x269e44)/Math['LN2']),_0x1d0968),_0x513f26=_0x389c89+_0x1d0968,_0x20f4ec=Math['round'](_0x269e44*Math['pow'](0x2,_0x12552a-_0x389c89)-Math['pow'](0x2,_0x12552a))):(_0x513f26=0x0,_0x20f4ec=Math['round'](_0x269e44/Math['pow'](0x2,0x1-_0x1d0968-_0x12552a))));const _0x3d4587=[];for(_0x3d2fe6=_0x12552a;_0x3d2fe6;_0x3d2fe6-=0x1)_0x3d4587['push'](_0x20f4ec%0x2?0x1:0x0),_0x20f4ec=Math['floor'](_0x20f4ec/0x2);for(_0x3d2fe6=_0x55a5b0;_0x3d2fe6;_0x3d2fe6-=0x1)_0x3d4587['push'](_0x513f26%0x2?0x1:0x0),_0x513f26=Math['floor'](_0x513f26/0x2);_0x3d4587['push'](_0x1d2324?0x1:0x0),_0x3d4587['reverse']();const _0x1a90eb=_0x3d4587['join']('');let _0x30a039='';for(_0x3d2fe6=0x0;_0x3d2fe6<0x40;_0x3d2fe6+=0x8){let _0x32e807=parseInt(_0x1a90eb['substr'](_0x3d2fe6,0x8),0x2)['toString'](0x10);_0x32e807['length']===0x1&&(_0x32e807='0'+_0x32e807),_0x30a039=_0x30a039+_0x32e807;}return _0x30a039['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x16bbb1,_0xd9fc4f){let _0x43c04a='Unknown\x20Error';_0x16bbb1==='too_big'?_0x43c04a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x16bbb1==='permission_denied'?_0x43c04a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x16bbb1==='unavailable'&&(_0x43c04a='The\x20service\x20is\x20unavailable');const _0x560cb5=new Error(_0x16bbb1+'\x20at\x20'+_0xd9fc4f['_path']['toString']()+':\x20'+_0x43c04a);return _0x560cb5['code']=_0x16bbb1['toUpperCase'](),_0x560cb5;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x1d10b4){if(Yl['test'](_0x1d10b4)){const _0x4e4c23=Number(_0x1d10b4);if(_0x4e4c23>=Ql&&_0x4e4c23<=Jl)return _0x4e4c23;}return null;},ft=function(_0x2e7c2b){try{_0x2e7c2b();}catch(_0x4a1a06){setTimeout(()=>{const _0x24672c=_0x4a1a06['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x24672c),_0x4a1a06;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x424c7d,_0x581d31){const _0x225121=setTimeout(_0x424c7d,_0x581d31);return typeof _0x225121=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x225121):typeof _0x225121=='object'&&_0x225121['unref']&&_0x225121['unref'](),_0x225121;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x19cc2d,_0x29e050){this['appCheckProvider']=_0x29e050,this['appName']=_0x19cc2d['name'],$(_0x19cc2d)&&_0x19cc2d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x19cc2d['settings']['appCheckToken']),this['appCheck']=_0x29e050==null?void 0x0:_0x29e050['getImmediate']({'optional':!0x0}),this['appCheck']||_0x29e050==null||_0x29e050['get']()['then'](_0x159790=>this['appCheck']=_0x159790);}['getToken'](_0x3153e3){if(this['serverAppAppCheckToken']){if(_0x3153e3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3153e3):new Promise((_0x563c8d,_0x565996)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3153e3)['then'](_0x563c8d,_0x565996):_0x563c8d(null);},0x0);});}['addTokenChangeListener'](_0x476093){var _0xd303e0;(_0xd303e0=this['appCheckProvider'])==null||_0xd303e0['get']()['then'](_0x4e3eef=>_0x4e3eef['addTokenListener'](_0x476093));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5aa7ec,_0x3e7d4c,_0x4fbe45){this['appName_']=_0x5aa7ec,this['firebaseOptions_']=_0x3e7d4c,this['authProvider_']=_0x4fbe45,this['auth_']=null,this['auth_']=_0x4fbe45['getImmediate']({'optional':!0x0}),this['auth_']||_0x4fbe45['onInit'](_0x32995a=>this['auth_']=_0x32995a);}['getToken'](_0x6818e5){return this['auth_']?this['auth_']['getToken'](_0x6818e5)['catch'](_0x55eaa9=>_0x55eaa9&&_0x55eaa9['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x55eaa9)):new Promise((_0x572360,_0x4ee870)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x6818e5)['then'](_0x572360,_0x4ee870):_0x572360(null);},0x0);});}['addTokenChangeListener'](_0x3a43e9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3a43e9):this['authProvider_']['get']()['then'](_0x5963fe=>_0x5963fe['addAuthTokenListener'](_0x3a43e9));}['removeTokenChangeListener'](_0x9870d9){this['authProvider_']['get']()['then'](_0x43e766=>_0x43e766['removeAuthTokenListener'](_0x9870d9));}['notifyForInvalidToken'](){let _0xd6f55d='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xd6f55d+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xd6f55d+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xd6f55d+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xd6f55d);}}class an{constructor(_0x89b9a5){this['accessToken']=_0x89b9a5;}['getToken'](_0x51b186){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3a5ba6){_0x3a5ba6(this['accessToken']);}['removeTokenChangeListener'](_0x89d0f8){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x524bbd,_0x17fec6,_0x554d3d,_0x5bf41a,_0x28f38a=!0x1,_0x24f445='',_0x18f32b=!0x1,_0x1e4785=!0x1,_0x24ac3f=null){this['secure']=_0x17fec6,this['namespace']=_0x554d3d,this['webSocketOnly']=_0x5bf41a,this['nodeAdmin']=_0x28f38a,this['persistenceKey']=_0x24f445,this['includeNamespaceInQueryParams']=_0x18f32b,this['isUsingEmulator']=_0x1e4785,this['emulatorOptions']=_0x24ac3f,this['_host']=_0x524bbd['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x524bbd)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x451613){_0x451613!==this['internalHost']&&(this['internalHost']=_0x451613,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5ad1db=this['toURLString']();return this['persistenceKey']&&(_0x5ad1db+='<'+this['persistenceKey']+'>'),_0x5ad1db;}['toURLString'](){const _0x29ead8=this['secure']?'https://':'http://',_0x1fcb29=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x29ead8+this['host']+'/'+_0x1fcb29;}}function th(_0x40ccf5){return _0x40ccf5['host']!==_0x40ccf5['internalHost']||_0x40ccf5['isCustomHost']()||_0x40ccf5['includeNamespaceInQueryParams'];}function vo(_0x850f84,_0x3fea57,_0x585a8a){f(typeof _0x3fea57=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x585a8a=='object','typeof\x20params\x20must\x20==\x20object');let _0x134208;if(_0x3fea57===go)_0x134208=(_0x850f84['secure']?'wss://':'ws://')+_0x850f84['internalHost']+'/.ws?';else{if(_0x3fea57===mo)_0x134208=(_0x850f84['secure']?'https://':'http://')+_0x850f84['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3fea57);}th(_0x850f84)&&(_0x585a8a['ns']=_0x850f84['namespace']);const _0xb37918=[];return x(_0x585a8a,(_0x5edba8,_0x25962c)=>{_0xb37918['push'](_0x5edba8+'='+_0x25962c);}),_0x134208+_0xb37918['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3d3fa2,_0x200140=0x1){Q(this['counters_'],_0x3d3fa2)||(this['counters_'][_0x3d3fa2]=0x0),this['counters_'][_0x3d3fa2]+=_0x200140;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x432554){const _0x4fb3df=_0x432554['toString']();return oi[_0x4fb3df]||(oi[_0x4fb3df]=new nh()),oi[_0x4fb3df];}function ih(_0x1b3ef0,_0x240952){const _0x1b03c4=_0x1b3ef0['toString']();return ai[_0x1b03c4]||(ai[_0x1b03c4]=_0x240952()),ai[_0x1b03c4];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x206ef4){this['onMessage_']=_0x206ef4,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x281393,_0x4e6d34){this['closeAfterResponse']=_0x281393,this['onClose']=_0x4e6d34,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xb0f89,_0x15f9ca){for(this['pendingResponses'][_0xb0f89]=_0x15f9ca;this['pendingResponses'][this['currentResponseNum']];){const _0x37093d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5dcf24=0x0;_0x5dcf24<_0x37093d['length'];++_0x5dcf24)_0x37093d[_0x5dcf24]&&ft(()=>{this['onMessage_'](_0x37093d[_0x5dcf24]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x25de94,_0x51e9ba,_0x596194,_0xb238e1,_0x28a944,_0x42793c,_0x42715b){this['connId']=_0x25de94,this['repoInfo']=_0x51e9ba,this['applicationId']=_0x596194,this['appCheckToken']=_0xb238e1,this['authToken']=_0x28a944,this['transportSessionId']=_0x42793c,this['lastSessionId']=_0x42715b,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x25de94),this['stats_']=qi(_0x51e9ba),this['urlFn']=_0x5b523a=>(this['appCheckToken']&&(_0x5b523a[wi]=this['appCheckToken']),vo(_0x51e9ba,mo,_0x5b523a));}['open'](_0x2977e7,_0x24c1ad){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x24c1ad,this['myPacketOrderer']=new sh(_0x2977e7),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4318f9)=>{const [_0x839e45,_0x40ae7e,_0xa010b2,_0x395434,_0x123bd0]=_0x4318f9;if(this['incrementIncomingBytes_'](_0x4318f9),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x839e45===qs)this['id']=_0x40ae7e,this['password']=_0xa010b2;else{if(_0x839e45===rh)_0x40ae7e?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x40ae7e,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x839e45);}}},(..._0x41439c)=>{const [_0x1781b6,_0x82d875]=_0x41439c;this['incrementIncomingBytes_'](_0x41439c),this['myPacketOrderer']['handleResponse'](_0x1781b6,_0x82d875);},()=>{this['onClosed_']();},this['urlFn']);const _0x25efec={};_0x25efec[qs]='t',_0x25efec[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x25efec[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x25efec[co]=Gi,this['transportSessionId']&&(_0x25efec[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x25efec[po]=this['lastSessionId']),this['applicationId']&&(_0x25efec[_o]=this['applicationId']),this['appCheckToken']&&(_0x25efec[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x25efec[ho]=uo);const _0x2d9f3e=this['urlFn'](_0x25efec);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2d9f3e),this['scriptTagHolder']['addTag'](_0x2d9f3e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1bc138){const _0x428b7e=O(_0x1bc138);this['bytesSent']+=_0x428b7e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x428b7e['length']);const _0xa3ee85=$r(_0x428b7e),_0x423d0a=oo(_0xa3ee85,fh);for(let _0x2897f1=0x0;_0x2897f1<_0x423d0a['length'];_0x2897f1++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x423d0a['length'],_0x423d0a[_0x2897f1]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xd44c15,_0x1dde2f){this['myDisconnFrame']=document['createElement']('iframe');const _0x9761e2={};_0x9761e2[dh]='t',_0x9761e2[Eo]=_0xd44c15,_0x9761e2[Io]=_0x1dde2f,this['myDisconnFrame']['src']=this['urlFn'](_0x9761e2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5ebe9c){const _0x32df9f=O(_0x5ebe9c)['length'];this['bytesReceived']+=_0x32df9f,this['stats_']['incrementCounter']('bytes_received',_0x32df9f);}}class zi{constructor(_0x1d26a6,_0x23bd25,_0x25ee18,_0x4e006b){this['onDisconnect']=_0x25ee18,this['urlFn']=_0x4e006b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1d26a6,window[ah+this['uniqueCallbackIdentifier']]=_0x23bd25,this['myIFrame']=zi['createIFrame_']();let _0x583753='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x583753='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1b44b4='<html><body>'+_0x583753+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1b44b4),this['myIFrame']['doc']['close']();}catch(_0x35eabe){L('frame\x20writing\x20exception'),_0x35eabe['stack']&&L(_0x35eabe['stack']),L(_0x35eabe);}}}static['createIFrame_'](){const _0x300a62=document['createElement']('iframe');if(_0x300a62['style']['display']='none',document['body']){document['body']['appendChild'](_0x300a62);try{_0x300a62['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x53a8b8=document['domain'];_0x300a62['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x53a8b8+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x300a62['contentDocument']?_0x300a62['doc']=_0x300a62['contentDocument']:_0x300a62['contentWindow']?_0x300a62['doc']=_0x300a62['contentWindow']['document']:_0x300a62['document']&&(_0x300a62['doc']=_0x300a62['document']),_0x300a62;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x566c5c=this['onDisconnect'];_0x566c5c&&(this['onDisconnect']=null,_0x566c5c());}['startLongPoll'](_0x396d42,_0x31f6ab){for(this['myID']=_0x396d42,this['myPW']=_0x31f6ab,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x21da23={};_0x21da23[Eo]=this['myID'],_0x21da23[Io]=this['myPW'],_0x21da23[wo]=this['currentSerial'];let _0x3c35a9=this['urlFn'](_0x21da23),_0xeb8fdb='',_0x498b76=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xeb8fdb['length']<=Co;){const _0x2589d2=this['pendingSegs']['shift']();_0xeb8fdb=_0xeb8fdb+'&'+lh+_0x498b76+'='+_0x2589d2['seg']+'&'+hh+_0x498b76+'='+_0x2589d2['ts']+'&'+uh+_0x498b76+'='+_0x2589d2['d'],_0x498b76++;}return _0x3c35a9=_0x3c35a9+_0xeb8fdb,this['addLongPollTag_'](_0x3c35a9,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x203ba7,_0x4619e9,_0x3e0227){this['pendingSegs']['push']({'seg':_0x203ba7,'ts':_0x4619e9,'d':_0x3e0227}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x9b60a5,_0x34444b){this['outstandingRequests']['add'](_0x34444b);const _0x3438dd=()=>{this['outstandingRequests']['delete'](_0x34444b),this['newRequest_']();},_0x57afe9=setTimeout(_0x3438dd,Math['floor'](ph)),_0x48fa2e=()=>{clearTimeout(_0x57afe9),_0x3438dd();};this['addTag'](_0x9b60a5,_0x48fa2e);}['addTag'](_0x26e599,_0x367eb4){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x181806=this['myIFrame']['doc']['createElement']('script');_0x181806['type']='text/javascript',_0x181806['async']=!0x0,_0x181806['src']=_0x26e599,_0x181806['onload']=_0x181806['onreadystatechange']=function(){const _0x3dd802=_0x181806['readyState'];(!_0x3dd802||_0x3dd802==='loaded'||_0x3dd802==='complete')&&(_0x181806['onload']=_0x181806['onreadystatechange']=null,_0x181806['parentNode']&&_0x181806['parentNode']['removeChild'](_0x181806),_0x367eb4());},_0x181806['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x26e599),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x181806);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0xafccbe,_0x2d4c04,_0x6f2032,_0x16b535,_0xa6f14f,_0x99a330,_0x1dfc6e){this['connId']=_0xafccbe,this['applicationId']=_0x6f2032,this['appCheckToken']=_0x16b535,this['authToken']=_0xa6f14f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x2d4c04),this['connURL']=q['connectionURL_'](_0x2d4c04,_0x99a330,_0x1dfc6e,_0x16b535,_0x6f2032),this['nodeAdmin']=_0x2d4c04['nodeAdmin'];}static['connectionURL_'](_0x2dd800,_0x12c515,_0x44c73c,_0xe2f192,_0x3ce281){const _0x57f75d={};return _0x57f75d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x57f75d[ho]=uo),_0x12c515&&(_0x57f75d[lo]=_0x12c515),_0x44c73c&&(_0x57f75d[po]=_0x44c73c),_0xe2f192&&(_0x57f75d[wi]=_0xe2f192),_0x3ce281&&(_0x57f75d[_o]=_0x3ce281),vo(_0x2dd800,go,_0x57f75d);}['open'](_0x1dc0a3,_0x204121){this['onDisconnect']=_0x204121,this['onMessage']=_0x1dc0a3,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5e7734;_c(),this['mySock']=new gn(this['connURL'],[],_0x5e7734);}catch(_0x488705){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5d2aad=_0x488705['message']||_0x488705['data'];_0x5d2aad&&this['log_'](_0x5d2aad),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x302fa6=>{this['handleIncomingFrame'](_0x302fa6);},this['mySock']['onerror']=_0xec5d29=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3784d3=_0xec5d29['message']||_0xec5d29['data'];_0x3784d3&&this['log_'](_0x3784d3),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x58c04f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xd58f29=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x49c3ae=navigator['userAgent']['match'](_0xd58f29);_0x49c3ae&&_0x49c3ae['length']>0x1&&parseFloat(_0x49c3ae[0x1])<4.4&&(_0x58c04f=!0x0);}return!_0x58c04f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x459d10){if(this['frames']['push'](_0x459d10),this['frames']['length']===this['totalFrames']){const _0x1cd4da=this['frames']['join']('');this['frames']=null;const _0x5bfdb0=Nt(_0x1cd4da);this['onMessage'](_0x5bfdb0);}}['handleNewFrameCount_'](_0x3ab5aa){this['totalFrames']=_0x3ab5aa,this['frames']=[];}['extractFrameCount_'](_0x576ea0){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x576ea0['length']<=0x6){const _0x1752d5=Number(_0x576ea0);if(!isNaN(_0x1752d5))return this['handleNewFrameCount_'](_0x1752d5),null;}return this['handleNewFrameCount_'](0x1),_0x576ea0;}['handleIncomingFrame'](_0x7a94e3){if(this['mySock']===null)return;const _0x388f8a=_0x7a94e3['data'];if(this['bytesReceived']+=_0x388f8a['length'],this['stats_']['incrementCounter']('bytes_received',_0x388f8a['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x388f8a);else{const _0x56056f=this['extractFrameCount_'](_0x388f8a);_0x56056f!==null&&this['appendFrame_'](_0x56056f);}}['send'](_0x10bd40){this['resetKeepAlive']();const _0x317578=O(_0x10bd40);this['bytesSent']+=_0x317578['length'],this['stats_']['incrementCounter']('bytes_sent',_0x317578['length']);const _0x56e14a=oo(_0x317578,gh);_0x56e14a['length']>0x1&&this['sendString_'](String(_0x56e14a['length']));for(let _0x5ccafe=0x0;_0x5ccafe<_0x56e14a['length'];_0x5ccafe++)this['sendString_'](_0x56e14a[_0x5ccafe]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x32d808){try{this['mySock']['send'](_0x32d808);}catch(_0x4160b3){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x4160b3['message']||_0x4160b3['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4dae43){this['initTransports_'](_0x4dae43);}['initTransports_'](_0x3cdca6){const _0x197a12=q&&q['isAvailable']();let _0x9bbc0b=_0x197a12&&!q['previouslyFailed']();if(_0x3cdca6['webSocketOnly']&&(_0x197a12||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x9bbc0b=!0x0),_0x9bbc0b)this['transports_']=[q];else{const _0x405439=this['transports_']=[];for(const _0xb5a68e of Dt['ALL_TRANSPORTS'])_0xb5a68e&&_0xb5a68e['isAvailable']()&&_0x405439['push'](_0xb5a68e);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x5131d4,_0x13c562,_0x9d46d6,_0x35c183,_0x18112e,_0x165897,_0x495ae2,_0x3c406e,_0x15b50d,_0x5315a8){this['id']=_0x5131d4,this['repoInfo_']=_0x13c562,this['applicationId_']=_0x9d46d6,this['appCheckToken_']=_0x35c183,this['authToken_']=_0x18112e,this['onMessage_']=_0x165897,this['onReady_']=_0x495ae2,this['onDisconnect_']=_0x3c406e,this['onKill_']=_0x15b50d,this['lastSessionId']=_0x5315a8,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x13c562),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2a3a6b=this['transportManager_']['initialTransport']();this['conn_']=new _0x2a3a6b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2a3a6b['responsesRequiredToBeHealthy']||0x0;const _0x17c482=this['connReceiver_'](this['conn_']),_0x2bd98b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x17c482,_0x2bd98b);},Math['floor'](0x0));const _0x64db28=_0x2a3a6b['healthyTimeout']||0x0;_0x64db28>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x64db28)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x34da6d){return _0x360ec8=>{_0x34da6d===this['conn_']?this['onConnectionLost_'](_0x360ec8):_0x34da6d===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x22e889){return _0x1eda9a=>{this['state_']!==0x2&&(_0x22e889===this['rx_']?this['onPrimaryMessageReceived_'](_0x1eda9a):_0x22e889===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x1eda9a):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x39ec31){const _0x2c8cd3={'t':'d','d':_0x39ec31};this['sendData_'](_0x2c8cd3);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xb7646e){if(ci in _0xb7646e){const _0x4aae98=_0xb7646e[ci];_0x4aae98===Ys?this['upgradeIfSecondaryHealthy_']():_0x4aae98===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4aae98===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x10e77c){const _0x30f808=vt('t',_0x10e77c),_0xf3ab4d=vt('d',_0x10e77c);if(_0x30f808==='c')this['onSecondaryControl_'](_0xf3ab4d);else{if(_0x30f808==='d')this['pendingDataMessages']['push'](_0xf3ab4d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x30f808);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x20300e){const _0x10a7d1=vt('t',_0x20300e),_0x7154c7=vt('d',_0x20300e);_0x10a7d1==='c'?this['onControl_'](_0x7154c7):_0x10a7d1==='d'&&this['onDataMessage_'](_0x7154c7);}['onDataMessage_'](_0x1c973c){this['onPrimaryResponse_'](),this['onMessage_'](_0x1c973c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x17a4f9){const _0x28b28a=vt(ci,_0x17a4f9);if(zs in _0x17a4f9){const _0x21967c=_0x17a4f9[zs];if(_0x28b28a===Th){const _0x23ab56={..._0x21967c};this['repoInfo_']['isUsingEmulator']&&(_0x23ab56['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x23ab56);}else{if(_0x28b28a===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x50dfd6=0x0;_0x50dfd6<this['pendingDataMessages']['length'];++_0x50dfd6)this['onDataMessage_'](this['pendingDataMessages'][_0x50dfd6]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x28b28a===wh?this['onConnectionShutdown_'](_0x21967c):_0x28b28a===js?this['onReset_'](_0x21967c):_0x28b28a===Ch?Ii('Server\x20Error:\x20'+_0x21967c):_0x28b28a===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x28b28a);}}}['onHandshake_'](_0x1b9f8c){const _0xcf65b2=_0x1b9f8c['ts'],_0x5ed137=_0x1b9f8c['v'],_0x137909=_0x1b9f8c['h'];this['sessionId']=_0x1b9f8c['s'],this['repoInfo_']['host']=_0x137909,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xcf65b2),Gi!==_0x5ed137&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x12c2ed=this['transportManager_']['upgradeTransport']();_0x12c2ed&&this['startUpgrade_'](_0x12c2ed);}['startUpgrade_'](_0x176e7e){this['secondaryConn_']=new _0x176e7e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x176e7e['responsesRequiredToBeHealthy']||0x0;const _0x625506=this['connReceiver_'](this['secondaryConn_']),_0x4fe3ed=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x625506,_0x4fe3ed),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3000fe){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3000fe),this['repoInfo_']['host']=_0x3000fe,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x35748d,_0x43df12){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x35748d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x43df12,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x59ecd7=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x59ecd7||this['rx_']===_0x59ecd7)&&this['close']();}['onConnectionLost_'](_0x4750dd){this['conn_']=null,!_0x4750dd&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x586eae){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x586eae),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5a526c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5a526c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x2da587,_0x5b30a2,_0x5ae366,_0x3bbb27){}['merge'](_0x41421a,_0x261724,_0xa25382,_0x4a1d5b){}['refreshAuthToken'](_0x12d78d){}['refreshAppCheckToken'](_0x458ac7){}['onDisconnectPut'](_0x892a9,_0x310940,_0x21be1d){}['onDisconnectMerge'](_0x153540,_0x3405ad,_0x501b50){}['onDisconnectCancel'](_0x3f4cc7,_0x28d953){}['reportStats'](_0x35cd74){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x4a74fe){this['allowedEvents_']=_0x4a74fe,this['listeners_']={},f(Array['isArray'](_0x4a74fe)&&_0x4a74fe['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x171f51,..._0x319042){if(Array['isArray'](this['listeners_'][_0x171f51])){const _0x2cc0b6=[...this['listeners_'][_0x171f51]];for(let _0x2d5df4=0x0;_0x2d5df4<_0x2cc0b6['length'];_0x2d5df4++)_0x2cc0b6[_0x2d5df4]['callback']['apply'](_0x2cc0b6[_0x2d5df4]['context'],_0x319042);}}['on'](_0x477eca,_0x33ed42,_0x3911c8){this['validateEventType_'](_0x477eca),this['listeners_'][_0x477eca]=this['listeners_'][_0x477eca]||[],this['listeners_'][_0x477eca]['push']({'callback':_0x33ed42,'context':_0x3911c8});const _0x299e7b=this['getInitialEvent'](_0x477eca);_0x299e7b&&_0x33ed42['apply'](_0x3911c8,_0x299e7b);}['off'](_0x435e8a,_0x133957,_0x5e9c35){this['validateEventType_'](_0x435e8a);const _0x24dd04=this['listeners_'][_0x435e8a]||[];for(let _0x1a0752=0x0;_0x1a0752<_0x24dd04['length'];_0x1a0752++)if(_0x24dd04[_0x1a0752]['callback']===_0x133957&&(!_0x5e9c35||_0x5e9c35===_0x24dd04[_0x1a0752]['context'])){_0x24dd04['splice'](_0x1a0752,0x1);return;}}['validateEventType_'](_0x457ae0){f(this['allowedEvents_']['find'](_0x4c2579=>_0x4c2579===_0x457ae0),'Unknown\x20event:\x20'+_0x457ae0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1074af){return f(_0x1074af==='online','Unknown\x20event\x20type:\x20'+_0x1074af),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2ef129,_0x1bdcee){if(_0x1bdcee===void 0x0){this['pieces_']=_0x2ef129['split']('/');let _0x507896=0x0;for(let _0x100657=0x0;_0x100657<this['pieces_']['length'];_0x100657++)this['pieces_'][_0x100657]['length']>0x0&&(this['pieces_'][_0x507896]=this['pieces_'][_0x100657],_0x507896++);this['pieces_']['length']=_0x507896,this['pieceNum_']=0x0;}else this['pieces_']=_0x2ef129,this['pieceNum_']=_0x1bdcee;}['toString'](){let _0x3d9952='';for(let _0x5a62b9=this['pieceNum_'];_0x5a62b9<this['pieces_']['length'];_0x5a62b9++)this['pieces_'][_0x5a62b9]!==''&&(_0x3d9952+='/'+this['pieces_'][_0x5a62b9]);return _0x3d9952||'/';}}function w(){return new C('');}function y(_0x17a3ca){return _0x17a3ca['pieceNum_']>=_0x17a3ca['pieces_']['length']?null:_0x17a3ca['pieces_'][_0x17a3ca['pieceNum_']];}function Ce(_0x3851e3){return _0x3851e3['pieces_']['length']-_0x3851e3['pieceNum_'];}function S(_0x3d4d32){let _0x297cf6=_0x3d4d32['pieceNum_'];return _0x297cf6<_0x3d4d32['pieces_']['length']&&_0x297cf6++,new C(_0x3d4d32['pieces_'],_0x297cf6);}function ji(_0x3e8014){return _0x3e8014['pieceNum_']<_0x3e8014['pieces_']['length']?_0x3e8014['pieces_'][_0x3e8014['pieces_']['length']-0x1]:null;}function bh(_0x19a4ec){let _0x22f344='';for(let _0x13bd16=_0x19a4ec['pieceNum_'];_0x13bd16<_0x19a4ec['pieces_']['length'];_0x13bd16++)_0x19a4ec['pieces_'][_0x13bd16]!==''&&(_0x22f344+='/'+encodeURIComponent(String(_0x19a4ec['pieces_'][_0x13bd16])));return _0x22f344||'/';}function Mt(_0x3e1db8,_0x522733=0x0){return _0x3e1db8['pieces_']['slice'](_0x3e1db8['pieceNum_']+_0x522733);}function Ro(_0x4226f4){if(_0x4226f4['pieceNum_']>=_0x4226f4['pieces_']['length'])return null;const _0x30ab7f=[];for(let _0x25f392=_0x4226f4['pieceNum_'];_0x25f392<_0x4226f4['pieces_']['length']-0x1;_0x25f392++)_0x30ab7f['push'](_0x4226f4['pieces_'][_0x25f392]);return new C(_0x30ab7f,0x0);}function k(_0x25941b,_0x2d13e3){const _0x51d0e5=[];for(let _0x36267f=_0x25941b['pieceNum_'];_0x36267f<_0x25941b['pieces_']['length'];_0x36267f++)_0x51d0e5['push'](_0x25941b['pieces_'][_0x36267f]);if(_0x2d13e3 instanceof C){for(let _0x4fadfe=_0x2d13e3['pieceNum_'];_0x4fadfe<_0x2d13e3['pieces_']['length'];_0x4fadfe++)_0x51d0e5['push'](_0x2d13e3['pieces_'][_0x4fadfe]);}else{const _0x53da9b=_0x2d13e3['split']('/');for(let _0x4542c7=0x0;_0x4542c7<_0x53da9b['length'];_0x4542c7++)_0x53da9b[_0x4542c7]['length']>0x0&&_0x51d0e5['push'](_0x53da9b[_0x4542c7]);}return new C(_0x51d0e5,0x0);}function v(_0x5ebb46){return _0x5ebb46['pieceNum_']>=_0x5ebb46['pieces_']['length'];}function F(_0x36bb24,_0x15e074){const _0x473c62=y(_0x36bb24),_0x6e6f87=y(_0x15e074);if(_0x473c62===null)return _0x15e074;if(_0x473c62===_0x6e6f87)return F(S(_0x36bb24),S(_0x15e074));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x15e074+')\x20is\x20not\x20within\x20outerPath\x20('+_0x36bb24+')');}function Rh(_0x57b15f,_0x5e5676){const _0x4f8139=Mt(_0x57b15f,0x0),_0x1354a7=Mt(_0x5e5676,0x0);for(let _0x564fcf=0x0;_0x564fcf<_0x4f8139['length']&&_0x564fcf<_0x1354a7['length'];_0x564fcf++){const _0x2d1dd1=qe(_0x4f8139[_0x564fcf],_0x1354a7[_0x564fcf]);if(_0x2d1dd1!==0x0)return _0x2d1dd1;}return _0x4f8139['length']===_0x1354a7['length']?0x0:_0x4f8139['length']<_0x1354a7['length']?-0x1:0x1;}function Ki(_0x7d16cc,_0x435887){if(Ce(_0x7d16cc)!==Ce(_0x435887))return!0x1;for(let _0x2ff632=_0x7d16cc['pieceNum_'],_0x1e2520=_0x435887['pieceNum_'];_0x2ff632<=_0x7d16cc['pieces_']['length'];_0x2ff632++,_0x1e2520++)if(_0x7d16cc['pieces_'][_0x2ff632]!==_0x435887['pieces_'][_0x1e2520])return!0x1;return!0x0;}function G(_0x2308ee,_0x24a52c){let _0x49109f=_0x2308ee['pieceNum_'],_0x5c476f=_0x24a52c['pieceNum_'];if(Ce(_0x2308ee)>Ce(_0x24a52c))return!0x1;for(;_0x49109f<_0x2308ee['pieces_']['length'];){if(_0x2308ee['pieces_'][_0x49109f]!==_0x24a52c['pieces_'][_0x5c476f])return!0x1;++_0x49109f,++_0x5c476f;}return!0x0;}class Ah{constructor(_0x254185,_0xf1f725){this['errorPrefix_']=_0xf1f725,this['parts_']=Mt(_0x254185,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3085d4=0x0;_0x3085d4<this['parts_']['length'];_0x3085d4++)this['byteLength_']+=Ln(this['parts_'][_0x3085d4]);Ao(this);}}function kh(_0x2871dc,_0x127e73){_0x2871dc['parts_']['length']>0x0&&(_0x2871dc['byteLength_']+=0x1),_0x2871dc['parts_']['push'](_0x127e73),_0x2871dc['byteLength_']+=Ln(_0x127e73),Ao(_0x2871dc);}function Ph(_0x4cb38a){const _0x1542e1=_0x4cb38a['parts_']['pop']();_0x4cb38a['byteLength_']-=Ln(_0x1542e1),_0x4cb38a['parts_']['length']>0x0&&(_0x4cb38a['byteLength_']-=0x1);}function Ao(_0x27af76){if(_0x27af76['byteLength_']>Zs)throw new Error(_0x27af76['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x27af76['byteLength_']+').');if(_0x27af76['parts_']['length']>Xs)throw new Error(_0x27af76['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x27af76));}function Oe(_0x285427){return _0x285427['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x285427['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x782943,_0x2738a7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2738a7='visibilitychange',_0x782943='hidden'):typeof document['mozHidden']<'u'?(_0x2738a7='mozvisibilitychange',_0x782943='mozHidden'):typeof document['msHidden']<'u'?(_0x2738a7='msvisibilitychange',_0x782943='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2738a7='webkitvisibilitychange',_0x782943='webkitHidden')),this['visible_']=!0x0,_0x2738a7&&document['addEventListener'](_0x2738a7,()=>{const _0x53a75c=!document[_0x782943];_0x53a75c!==this['visible_']&&(this['visible_']=_0x53a75c,this['trigger']('visible',_0x53a75c));},!0x1);}['getInitialEvent'](_0x406c2b){return f(_0x406c2b==='visible','Unknown\x20event\x20type:\x20'+_0x406c2b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x36fa75,_0x11457f,_0x17ab35,_0x40d1d9,_0x2a01bf,_0x203fa3,_0x2b3ea6,_0x52914a){if(super(),this['repoInfo_']=_0x36fa75,this['applicationId_']=_0x11457f,this['onDataUpdate_']=_0x17ab35,this['onConnectStatus_']=_0x40d1d9,this['onServerInfoUpdate_']=_0x2a01bf,this['authTokenProvider_']=_0x203fa3,this['appCheckTokenProvider_']=_0x2b3ea6,this['authOverride_']=_0x52914a,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x52914a)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x36fa75['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1891fd,_0x4a1395,_0x1644bc){const _0x3242f0=++this['requestNumber_'],_0x1dc25d={'r':_0x3242f0,'a':_0x1891fd,'b':_0x4a1395};this['log_'](O(_0x1dc25d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1dc25d),_0x1644bc&&(this['requestCBHash_'][_0x3242f0]=_0x1644bc);}['get'](_0x5df48a){this['initConnection_']();const _0x3bfbbd=new H(),_0x2e51f8={'action':'g','request':{'p':_0x5df48a['_path']['toString'](),'q':_0x5df48a['_queryObject']},'onComplete':_0x451bb6=>{const _0x3f7bff=_0x451bb6['d'];_0x451bb6['s']==='ok'?_0x3bfbbd['resolve'](_0x3f7bff):_0x3bfbbd['reject'](_0x3f7bff);}};this['outstandingGets_']['push'](_0x2e51f8),this['outstandingGetCount_']++;const _0x5395ca=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5395ca),_0x3bfbbd['promise'];}['listen'](_0x5012c9,_0x524c0c,_0x41b5b4,_0x1a58ab){this['initConnection_']();const _0x314778=_0x5012c9['_queryIdentifier'],_0xe27969=_0x5012c9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xe27969+'\x20'+_0x314778),this['listens']['has'](_0xe27969)||this['listens']['set'](_0xe27969,new Map()),f(_0x5012c9['_queryParams']['isDefault']()||!_0x5012c9['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0xe27969)['has'](_0x314778),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x34580f={'onComplete':_0x1a58ab,'hashFn':_0x524c0c,'query':_0x5012c9,'tag':_0x41b5b4};this['listens']['get'](_0xe27969)['set'](_0x314778,_0x34580f),this['connected_']&&this['sendListen_'](_0x34580f);}['sendGet_'](_0x53b213){const _0x290f2c=this['outstandingGets_'][_0x53b213];this['sendRequest']('g',_0x290f2c['request'],_0x5a4f01=>{delete this['outstandingGets_'][_0x53b213],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x290f2c['onComplete']&&_0x290f2c['onComplete'](_0x5a4f01);});}['sendListen_'](_0x57f9e5){const _0x26e0dc=_0x57f9e5['query'],_0x28696f=_0x26e0dc['_path']['toString'](),_0x5966f9=_0x26e0dc['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x28696f+'\x20for\x20'+_0x5966f9);const _0xd29b77={'p':_0x28696f},_0x3f1546='q';_0x57f9e5['tag']&&(_0xd29b77['q']=_0x26e0dc['_queryObject'],_0xd29b77['t']=_0x57f9e5['tag']),_0xd29b77['h']=_0x57f9e5['hashFn'](),this['sendRequest'](_0x3f1546,_0xd29b77,_0x53f9b0=>{const _0x2622c5=_0x53f9b0['d'],_0xa70af4=_0x53f9b0['s'];se['warnOnListenWarnings_'](_0x2622c5,_0x26e0dc),(this['listens']['get'](_0x28696f)&&this['listens']['get'](_0x28696f)['get'](_0x5966f9))===_0x57f9e5&&(this['log_']('listen\x20response',_0x53f9b0),_0xa70af4!=='ok'&&this['removeListen_'](_0x28696f,_0x5966f9),_0x57f9e5['onComplete']&&_0x57f9e5['onComplete'](_0xa70af4,_0x2622c5));});}static['warnOnListenWarnings_'](_0x5c286a,_0x3e9521){if(_0x5c286a&&typeof _0x5c286a=='object'&&Q(_0x5c286a,'w')){const _0x4a1a0b=Le(_0x5c286a,'w');if(Array['isArray'](_0x4a1a0b)&&~_0x4a1a0b['indexOf']('no_index')){const _0x6e9c8d='\x22.indexOn\x22:\x20\x22'+_0x3e9521['_queryParams']['getIndex']()['toString']()+'\x22',_0x1d7922=_0x3e9521['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x6e9c8d+'\x20at\x20'+_0x1d7922+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x113f3d){this['authToken_']=_0x113f3d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x113f3d);}['reduceReconnectDelayIfAdminCredential_'](_0x4e526c){(_0x4e526c&&_0x4e526c['length']===0x28||wc(_0x4e526c))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x1f2da8){this['appCheckToken_']=_0x1f2da8,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2f4bb7=this['authToken_'],_0x92985c=Ic(_0x2f4bb7)?'auth':'gauth',_0x24d32a={'cred':_0x2f4bb7};this['authOverride_']===null?_0x24d32a['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x24d32a['authvar']=this['authOverride_']),this['sendRequest'](_0x92985c,_0x24d32a,_0x566e45=>{const _0x41a22d=_0x566e45['s'],_0x401bac=_0x566e45['d']||'error';this['authToken_']===_0x2f4bb7&&(_0x41a22d==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x41a22d,_0x401bac));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2afefe=>{const _0x552c01=_0x2afefe['s'],_0xe43bff=_0x2afefe['d']||'error';_0x552c01==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x552c01,_0xe43bff);});}['unlisten'](_0x17fa48,_0x3479ec){const _0x5164a5=_0x17fa48['_path']['toString'](),_0x3f4378=_0x17fa48['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5164a5+'\x20'+_0x3f4378),f(_0x17fa48['_queryParams']['isDefault']()||!_0x17fa48['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5164a5,_0x3f4378)&&this['connected_']&&this['sendUnlisten_'](_0x5164a5,_0x3f4378,_0x17fa48['_queryObject'],_0x3479ec);}['sendUnlisten_'](_0x26d8cd,_0x1213fa,_0x41fb1c,_0x2a5b14){this['log_']('Unlisten\x20on\x20'+_0x26d8cd+'\x20for\x20'+_0x1213fa);const _0x56d1ad={'p':_0x26d8cd},_0x34f17e='n';_0x2a5b14&&(_0x56d1ad['q']=_0x41fb1c,_0x56d1ad['t']=_0x2a5b14),this['sendRequest'](_0x34f17e,_0x56d1ad);}['onDisconnectPut'](_0x484b96,_0x3cb26f,_0x4b9e03){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x484b96,_0x3cb26f,_0x4b9e03):this['onDisconnectRequestQueue_']['push']({'pathString':_0x484b96,'action':'o','data':_0x3cb26f,'onComplete':_0x4b9e03});}['onDisconnectMerge'](_0x44bb49,_0x324134,_0x1d905a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x44bb49,_0x324134,_0x1d905a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x44bb49,'action':'om','data':_0x324134,'onComplete':_0x1d905a});}['onDisconnectCancel'](_0x34b236,_0x57f5ef){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x34b236,null,_0x57f5ef):this['onDisconnectRequestQueue_']['push']({'pathString':_0x34b236,'action':'oc','data':null,'onComplete':_0x57f5ef});}['sendOnDisconnect_'](_0x835cbc,_0xc63cc0,_0x1904a1,_0x268d9b){const _0x5e2b03={'p':_0xc63cc0,'d':_0x1904a1};this['log_']('onDisconnect\x20'+_0x835cbc,_0x5e2b03),this['sendRequest'](_0x835cbc,_0x5e2b03,_0x3f410c=>{_0x268d9b&&setTimeout(()=>{_0x268d9b(_0x3f410c['s'],_0x3f410c['d']);},Math['floor'](0x0));});}['put'](_0x9f0fbb,_0x439eaa,_0xc61bea,_0x4a0fa6){this['putInternal']('p',_0x9f0fbb,_0x439eaa,_0xc61bea,_0x4a0fa6);}['merge'](_0x5c8845,_0x1f3f5e,_0x587eec,_0x5460d9){this['putInternal']('m',_0x5c8845,_0x1f3f5e,_0x587eec,_0x5460d9);}['putInternal'](_0x161eb8,_0x4e2a92,_0x389725,_0x1d991a,_0x5f2b3f){this['initConnection_']();const _0x3c97c0={'p':_0x4e2a92,'d':_0x389725};_0x5f2b3f!==void 0x0&&(_0x3c97c0['h']=_0x5f2b3f),this['outstandingPuts_']['push']({'action':_0x161eb8,'request':_0x3c97c0,'onComplete':_0x1d991a}),this['outstandingPutCount_']++;const _0x59b917=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x59b917):this['log_']('Buffering\x20put:\x20'+_0x4e2a92);}['sendPut_'](_0x491f98){const _0x360e56=this['outstandingPuts_'][_0x491f98]['action'],_0x527f6b=this['outstandingPuts_'][_0x491f98]['request'],_0x5b0205=this['outstandingPuts_'][_0x491f98]['onComplete'];this['outstandingPuts_'][_0x491f98]['queued']=this['connected_'],this['sendRequest'](_0x360e56,_0x527f6b,_0x33754c=>{this['log_'](_0x360e56+'\x20response',_0x33754c),delete this['outstandingPuts_'][_0x491f98],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5b0205&&_0x5b0205(_0x33754c['s'],_0x33754c['d']);});}['reportStats'](_0x23a9da){if(this['connected_']){const _0x2a81cb={'c':_0x23a9da};this['log_']('reportStats',_0x2a81cb),this['sendRequest']('s',_0x2a81cb,_0x59ee93=>{if(_0x59ee93['s']!=='ok'){const _0x5ca7d2=_0x59ee93['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5ca7d2);}});}}['onDataMessage_'](_0x2d84fa){if('r'in _0x2d84fa){this['log_']('from\x20server:\x20'+O(_0x2d84fa));const _0x4ba86d=_0x2d84fa['r'],_0x3e1390=this['requestCBHash_'][_0x4ba86d];_0x3e1390&&(delete this['requestCBHash_'][_0x4ba86d],_0x3e1390(_0x2d84fa['b']));}else{if('error'in _0x2d84fa)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2d84fa['error'];'a'in _0x2d84fa&&this['onDataPush_'](_0x2d84fa['a'],_0x2d84fa['b']);}}['onDataPush_'](_0x105d1f,_0x527478){this['log_']('handleServerMessage',_0x105d1f,_0x527478),_0x105d1f==='d'?this['onDataUpdate_'](_0x527478['p'],_0x527478['d'],!0x1,_0x527478['t']):_0x105d1f==='m'?this['onDataUpdate_'](_0x527478['p'],_0x527478['d'],!0x0,_0x527478['t']):_0x105d1f==='c'?this['onListenRevoked_'](_0x527478['p'],_0x527478['q']):_0x105d1f==='ac'?this['onAuthRevoked_'](_0x527478['s'],_0x527478['d']):_0x105d1f==='apc'?this['onAppCheckRevoked_'](_0x527478['s'],_0x527478['d']):_0x105d1f==='sd'?this['onSecurityDebugPacket_'](_0x527478):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x105d1f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x55b530,_0x450597){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x55b530),this['lastSessionId']=_0x450597,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x468914){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x468914));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1efc14){_0x1efc14&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1efc14;}['onOnline_'](_0x1827ce){_0x1827ce?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1c588f=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5b5a1d=Math['max'](0x0,this['reconnectDelay_']-_0x1c588f);_0x5b5a1d=Math['random']()*_0x5b5a1d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5b5a1d+'ms'),this['scheduleConnect_'](_0x5b5a1d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1f86e1=this['onDataMessage_']['bind'](this),_0x1cc6db=this['onReady_']['bind'](this),_0x378cff=this['onRealtimeDisconnect_']['bind'](this),_0x5dfe67=this['id']+':'+se['nextConnectionId_']++,_0x142126=this['lastSessionId'];let _0x1f7fcd=!0x1,_0x2d1159=null;const _0x3456f8=function(){_0x2d1159?_0x2d1159['close']():(_0x1f7fcd=!0x0,_0x378cff());},_0x58b378=function(_0x1062dc){f(_0x2d1159,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2d1159['sendRequest'](_0x1062dc);};this['realtime_']={'close':_0x3456f8,'sendRequest':_0x58b378};const _0x18def0=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1f780f,_0x19dde8]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x18def0),this['appCheckTokenProvider_']['getToken'](_0x18def0)]);_0x1f7fcd?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1f780f&&_0x1f780f['accessToken'],this['appCheckToken_']=_0x19dde8&&_0x19dde8['token'],_0x2d1159=new Sh(_0x5dfe67,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1f86e1,_0x1cc6db,_0x378cff,_0x2f4024=>{U(_0x2f4024+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x142126));}catch(_0x4c1303){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4c1303),_0x1f7fcd||(this['repoInfo_']['nodeAdmin']&&U(_0x4c1303),_0x3456f8());}}}['interrupt'](_0x34f72b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x34f72b),this['interruptReasons_'][_0x34f72b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3d2d9b){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3d2d9b),delete this['interruptReasons_'][_0x3d2d9b],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2b1551){const _0x4f1da5=_0x2b1551-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4f1da5});}['cancelSentTransactions_'](){for(let _0x2d5490=0x0;_0x2d5490<this['outstandingPuts_']['length'];_0x2d5490++){const _0x54d964=this['outstandingPuts_'][_0x2d5490];_0x54d964&&'h'in _0x54d964['request']&&_0x54d964['queued']&&(_0x54d964['onComplete']&&_0x54d964['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2d5490],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x32ea9f,_0x133f69){let _0x255777;_0x133f69?_0x255777=_0x133f69['map'](_0x49ccb2=>$i(_0x49ccb2))['join']('$'):_0x255777='default';const _0x104757=this['removeListen_'](_0x32ea9f,_0x255777);_0x104757&&_0x104757['onComplete']&&_0x104757['onComplete']('permission_denied');}['removeListen_'](_0x205855,_0x330260){const _0x416db7=new C(_0x205855)['toString']();let _0x7f5679;if(this['listens']['has'](_0x416db7)){const _0xcbc01b=this['listens']['get'](_0x416db7);_0x7f5679=_0xcbc01b['get'](_0x330260),_0xcbc01b['delete'](_0x330260),_0xcbc01b['size']===0x0&&this['listens']['delete'](_0x416db7);}else _0x7f5679=void 0x0;return _0x7f5679;}['onAuthRevoked_'](_0x103e9b,_0x36a2c0){L('Auth\x20token\x20revoked:\x20'+_0x103e9b+'/'+_0x36a2c0),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x103e9b==='invalid_token'||_0x103e9b==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3d4495,_0xfcd24){L('App\x20check\x20token\x20revoked:\x20'+_0x3d4495+'/'+_0xfcd24),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3d4495==='invalid_token'||_0x3d4495==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3a3161){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3a3161):'msg'in _0x3a3161&&console['log']('FIREBASE:\x20'+_0x3a3161['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5dca5c of this['listens']['values']())for(const _0x43ce25 of _0x5dca5c['values']())this['sendListen_'](_0x43ce25);for(let _0xb7bfc=0x0;_0xb7bfc<this['outstandingPuts_']['length'];_0xb7bfc++)this['outstandingPuts_'][_0xb7bfc]&&this['sendPut_'](_0xb7bfc);for(;this['onDisconnectRequestQueue_']['length'];){const _0x57efb1=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x57efb1['action'],_0x57efb1['pathString'],_0x57efb1['data'],_0x57efb1['onComplete']);}for(let _0x2998fb=0x0;_0x2998fb<this['outstandingGets_']['length'];_0x2998fb++)this['outstandingGets_'][_0x2998fb]&&this['sendGet_'](_0x2998fb);}['sendConnectStats_'](){const _0xcaf8cf={};let _0x27796b='js';_0xcaf8cf['sdk.'+_0x27796b+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xcaf8cf['framework.cordova']=0x1:Kr()&&(_0xcaf8cf['framework.reactnative']=0x1),this['reportStats'](_0xcaf8cf);}['shouldReconnect_'](){const _0x32aea1=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x32aea1;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x26010b,_0x41d22a){this['name']=_0x26010b,this['node']=_0x41d22a;}static['Wrap'](_0x2f4fdf,_0x7f2198){return new E(_0x2f4fdf,_0x7f2198);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2947ee,_0x3a0021){const _0xb78418=new E(We,_0x2947ee),_0x2fc729=new E(We,_0x3a0021);return this['compare'](_0xb78418,_0x2fc729)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x1fd675){sn=_0x1fd675;}['compare'](_0x54e680,_0x835b33){return qe(_0x54e680['name'],_0x835b33['name']);}['isDefinedOn'](_0x2e4585){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x5143a0,_0x35f472){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x73896b,_0x3abebf){return f(typeof _0x73896b=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x73896b,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x43fc93,_0x6ce085,_0x1f77cc,_0x504e09,_0x21d974=null){this['isReverse_']=_0x504e09,this['resultGenerator_']=_0x21d974,this['nodeStack_']=[];let _0xb7bbc5=0x1;for(;!_0x43fc93['isEmpty']();)if(_0x43fc93=_0x43fc93,_0xb7bbc5=_0x6ce085?_0x1f77cc(_0x43fc93['key'],_0x6ce085):0x1,_0x504e09&&(_0xb7bbc5*=-0x1),_0xb7bbc5<0x0)this['isReverse_']?_0x43fc93=_0x43fc93['left']:_0x43fc93=_0x43fc93['right'];else{if(_0xb7bbc5===0x0){this['nodeStack_']['push'](_0x43fc93);break;}else this['nodeStack_']['push'](_0x43fc93),this['isReverse_']?_0x43fc93=_0x43fc93['right']:_0x43fc93=_0x43fc93['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3c7fa9=this['nodeStack_']['pop'](),_0x298764;if(this['resultGenerator_']?_0x298764=this['resultGenerator_'](_0x3c7fa9['key'],_0x3c7fa9['value']):_0x298764={'key':_0x3c7fa9['key'],'value':_0x3c7fa9['value']},this['isReverse_']){for(_0x3c7fa9=_0x3c7fa9['left'];!_0x3c7fa9['isEmpty']();)this['nodeStack_']['push'](_0x3c7fa9),_0x3c7fa9=_0x3c7fa9['right'];}else{for(_0x3c7fa9=_0x3c7fa9['right'];!_0x3c7fa9['isEmpty']();)this['nodeStack_']['push'](_0x3c7fa9),_0x3c7fa9=_0x3c7fa9['left'];}return _0x298764;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x33506f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x33506f['key'],_0x33506f['value']):{'key':_0x33506f['key'],'value':_0x33506f['value']};}}class M{constructor(_0x719e2,_0x364953,_0x328dcd,_0x4e9714,_0x7142c0){this['key']=_0x719e2,this['value']=_0x364953,this['color']=_0x328dcd??M['RED'],this['left']=_0x4e9714??B['EMPTY_NODE'],this['right']=_0x7142c0??B['EMPTY_NODE'];}['copy'](_0x4c3dc3,_0x43c980,_0x1dcc4f,_0x2ed7de,_0x240513){return new M(_0x4c3dc3??this['key'],_0x43c980??this['value'],_0x1dcc4f??this['color'],_0x2ed7de??this['left'],_0x240513??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x44411d){return this['left']['inorderTraversal'](_0x44411d)||!!_0x44411d(this['key'],this['value'])||this['right']['inorderTraversal'](_0x44411d);}['reverseTraversal'](_0x5d03d9){return this['right']['reverseTraversal'](_0x5d03d9)||_0x5d03d9(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5d03d9);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x36a851,_0x3b30e7,_0x52a351){let _0x303f4c=this;const _0x5a1a4f=_0x52a351(_0x36a851,_0x303f4c['key']);return _0x5a1a4f<0x0?_0x303f4c=_0x303f4c['copy'](null,null,null,_0x303f4c['left']['insert'](_0x36a851,_0x3b30e7,_0x52a351),null):_0x5a1a4f===0x0?_0x303f4c=_0x303f4c['copy'](null,_0x3b30e7,null,null,null):_0x303f4c=_0x303f4c['copy'](null,null,null,null,_0x303f4c['right']['insert'](_0x36a851,_0x3b30e7,_0x52a351)),_0x303f4c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1e4bfa=this;return!_0x1e4bfa['left']['isRed_']()&&!_0x1e4bfa['left']['left']['isRed_']()&&(_0x1e4bfa=_0x1e4bfa['moveRedLeft_']()),_0x1e4bfa=_0x1e4bfa['copy'](null,null,null,_0x1e4bfa['left']['removeMin_'](),null),_0x1e4bfa['fixUp_']();}['remove'](_0x2d6e26,_0x43cdfc){let _0x587b96,_0x584b08;if(_0x587b96=this,_0x43cdfc(_0x2d6e26,_0x587b96['key'])<0x0)!_0x587b96['left']['isEmpty']()&&!_0x587b96['left']['isRed_']()&&!_0x587b96['left']['left']['isRed_']()&&(_0x587b96=_0x587b96['moveRedLeft_']()),_0x587b96=_0x587b96['copy'](null,null,null,_0x587b96['left']['remove'](_0x2d6e26,_0x43cdfc),null);else{if(_0x587b96['left']['isRed_']()&&(_0x587b96=_0x587b96['rotateRight_']()),!_0x587b96['right']['isEmpty']()&&!_0x587b96['right']['isRed_']()&&!_0x587b96['right']['left']['isRed_']()&&(_0x587b96=_0x587b96['moveRedRight_']()),_0x43cdfc(_0x2d6e26,_0x587b96['key'])===0x0){if(_0x587b96['right']['isEmpty']())return B['EMPTY_NODE'];_0x584b08=_0x587b96['right']['min_'](),_0x587b96=_0x587b96['copy'](_0x584b08['key'],_0x584b08['value'],null,null,_0x587b96['right']['removeMin_']());}_0x587b96=_0x587b96['copy'](null,null,null,null,_0x587b96['right']['remove'](_0x2d6e26,_0x43cdfc));}return _0x587b96['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x5de9cf=this;return _0x5de9cf['right']['isRed_']()&&!_0x5de9cf['left']['isRed_']()&&(_0x5de9cf=_0x5de9cf['rotateLeft_']()),_0x5de9cf['left']['isRed_']()&&_0x5de9cf['left']['left']['isRed_']()&&(_0x5de9cf=_0x5de9cf['rotateRight_']()),_0x5de9cf['left']['isRed_']()&&_0x5de9cf['right']['isRed_']()&&(_0x5de9cf=_0x5de9cf['colorFlip_']()),_0x5de9cf;}['moveRedLeft_'](){let _0x10d831=this['colorFlip_']();return _0x10d831['right']['left']['isRed_']()&&(_0x10d831=_0x10d831['copy'](null,null,null,null,_0x10d831['right']['rotateRight_']()),_0x10d831=_0x10d831['rotateLeft_'](),_0x10d831=_0x10d831['colorFlip_']()),_0x10d831;}['moveRedRight_'](){let _0x4dcef1=this['colorFlip_']();return _0x4dcef1['left']['left']['isRed_']()&&(_0x4dcef1=_0x4dcef1['rotateRight_'](),_0x4dcef1=_0x4dcef1['colorFlip_']()),_0x4dcef1;}['rotateLeft_'](){const _0x533fdc=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x533fdc,null);}['rotateRight_'](){const _0x2a7d8f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2a7d8f);}['colorFlip_'](){const _0xcd544a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x26203e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xcd544a,_0x26203e);}['checkMaxDepth_'](){const _0x5b97e8=this['check_']();return Math['pow'](0x2,_0x5b97e8)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2eba8c=this['left']['check_']();if(_0x2eba8c!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2eba8c+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x395c9f,_0x875c70,_0x310d18,_0x243796,_0x32f312){return this;}['insert'](_0x338627,_0x1e10b3,_0x144d2d){return new M(_0x338627,_0x1e10b3,null);}['remove'](_0x2da263,_0x355f49){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x57b5c1){return!0x1;}['reverseTraversal'](_0x305bd2){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1b06cc,_0x5c40ed=B['EMPTY_NODE']){this['comparator_']=_0x1b06cc,this['root_']=_0x5c40ed;}['insert'](_0x3b979b,_0x4daa7e){return new B(this['comparator_'],this['root_']['insert'](_0x3b979b,_0x4daa7e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4bb56b){return new B(this['comparator_'],this['root_']['remove'](_0x4bb56b,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x40e6a3){let _0x220462,_0x2aa016=this['root_'];for(;!_0x2aa016['isEmpty']();){if(_0x220462=this['comparator_'](_0x40e6a3,_0x2aa016['key']),_0x220462===0x0)return _0x2aa016['value'];_0x220462<0x0?_0x2aa016=_0x2aa016['left']:_0x220462>0x0&&(_0x2aa016=_0x2aa016['right']);}return null;}['getPredecessorKey'](_0x218037){let _0x28ff75,_0x20177e=this['root_'],_0x3023fb=null;for(;!_0x20177e['isEmpty']();)if(_0x28ff75=this['comparator_'](_0x218037,_0x20177e['key']),_0x28ff75===0x0){if(_0x20177e['left']['isEmpty']())return _0x3023fb?_0x3023fb['key']:null;for(_0x20177e=_0x20177e['left'];!_0x20177e['right']['isEmpty']();)_0x20177e=_0x20177e['right'];return _0x20177e['key'];}else _0x28ff75<0x0?_0x20177e=_0x20177e['left']:_0x28ff75>0x0&&(_0x3023fb=_0x20177e,_0x20177e=_0x20177e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x452943){return this['root_']['inorderTraversal'](_0x452943);}['reverseTraversal'](_0x473712){return this['root_']['reverseTraversal'](_0x473712);}['getIterator'](_0x35ac95){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x35ac95);}['getIteratorFrom'](_0xdfe444,_0x4efb6e){return new rn(this['root_'],_0xdfe444,this['comparator_'],!0x1,_0x4efb6e);}['getReverseIteratorFrom'](_0xbf2b2a,_0x4e9d4f){return new rn(this['root_'],_0xbf2b2a,this['comparator_'],!0x0,_0x4e9d4f);}['getReverseIterator'](_0xd5e814){return new rn(this['root_'],null,this['comparator_'],!0x0,_0xd5e814);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0xabd5ce,_0x4690c2){return qe(_0xabd5ce['name'],_0x4690c2['name']);}function Qi(_0x8984ce,_0x136b4e){return qe(_0x8984ce,_0x136b4e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x174026){Ci=_0x174026;}const Po=function(_0x158b30){return typeof _0x158b30=='number'?'number:'+ao(_0x158b30):'string:'+_0x158b30;},No=function(_0x597ad5){if(_0x597ad5['isLeafNode']()){const _0x3aea79=_0x597ad5['val']();f(typeof _0x3aea79=='string'||typeof _0x3aea79=='number'||typeof _0x3aea79=='object'&&Q(_0x3aea79,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x597ad5===Ci||_0x597ad5['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x597ad5===Ci||_0x597ad5['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1d96c0){nr=_0x1d96c0;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x34fa4f,_0x5d86cc=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x34fa4f,this['priorityNode_']=_0x5d86cc,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1bdccd){return new D(this['value_'],_0x1bdccd);}['getImmediateChild'](_0x53a1d2){return _0x53a1d2==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x35cd55){return v(_0x35cd55)?this:y(_0x35cd55)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3bfb67,_0x310796){return null;}['updateImmediateChild'](_0x6cee93,_0xc306ce){return _0x6cee93==='.priority'?this['updatePriority'](_0xc306ce):_0xc306ce['isEmpty']()&&_0x6cee93!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x6cee93,_0xc306ce)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3b9461,_0xe14d15){const _0x31a6f2=y(_0x3b9461);return _0x31a6f2===null?_0xe14d15:_0xe14d15['isEmpty']()&&_0x31a6f2!=='.priority'?this:(f(_0x31a6f2!=='.priority'||Ce(_0x3b9461)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x31a6f2,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x3b9461),_0xe14d15)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4f6e63,_0x8d8eec){return!0x1;}['val'](_0xd0b4e3){return _0xd0b4e3&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1befc2='';this['priorityNode_']['isEmpty']()||(_0x1befc2+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x289f6d=typeof this['value_'];_0x1befc2+=_0x289f6d+':',_0x289f6d==='number'?_0x1befc2+=ao(this['value_']):_0x1befc2+=this['value_'],this['lazyHash_']=ro(_0x1befc2);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5a793d){return _0x5a793d===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5a793d instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5a793d['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5a793d));}['compareToLeafNode_'](_0x513948){const _0x1974bc=typeof _0x513948['value_'],_0x40e8e9=typeof this['value_'],_0x18da6b=D['VALUE_TYPE_ORDER']['indexOf'](_0x1974bc),_0x242e10=D['VALUE_TYPE_ORDER']['indexOf'](_0x40e8e9);return f(_0x18da6b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1974bc),f(_0x242e10>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x40e8e9),_0x18da6b===_0x242e10?_0x40e8e9==='object'?0x0:this['value_']<_0x513948['value_']?-0x1:this['value_']===_0x513948['value_']?0x0:0x1:_0x242e10-_0x18da6b;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x309940){if(_0x309940===this)return!0x0;if(_0x309940['isLeafNode']()){const _0xb469e3=_0x309940;return this['value_']===_0xb469e3['value_']&&this['priorityNode_']['equals'](_0xb469e3['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5a3b9b){Oo=_0x5a3b9b;}function Wh(_0x3ce248){Do=_0x3ce248;}class Bh extends Fn{['compare'](_0x2da925,_0x5c5df5){const _0x56c599=_0x2da925['node']['getPriority'](),_0x57afb5=_0x5c5df5['node']['getPriority'](),_0x175057=_0x56c599['compareTo'](_0x57afb5);return _0x175057===0x0?qe(_0x2da925['name'],_0x5c5df5['name']):_0x175057;}['isDefinedOn'](_0x245212){return!_0x245212['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x456749,_0x10c97d){return!_0x456749['getPriority']()['equals'](_0x10c97d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4b4844,_0x28deb8){const _0x46df8f=Oo(_0x4b4844);return new E(_0x28deb8,new D('[PRIORITY-POST]',_0x46df8f));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x58fdf8){const _0x543891=_0x466409=>parseInt(Math['log'](_0x466409)/Vh,0xa),_0x5e30d9=_0x130925=>parseInt(Array(_0x130925+0x1)['join']('1'),0x2);this['count']=_0x543891(_0x58fdf8+0x1),this['current_']=this['count']-0x1;const _0x1b58da=_0x5e30d9(this['count']);this['bits_']=_0x58fdf8+0x1&_0x1b58da;}['nextBitIsOne'](){const _0x495583=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x495583;}}const yn=function(_0x5698b1,_0x4c9827,_0x79dae0,_0x2dd1f9){_0x5698b1['sort'](_0x4c9827);const _0x2a9ef4=function(_0x431a6d,_0x4adc28){const _0x1a078b=_0x4adc28-_0x431a6d;let _0x5f0838,_0x1a5b07;if(_0x1a078b===0x0)return null;if(_0x1a078b===0x1)return _0x5f0838=_0x5698b1[_0x431a6d],_0x1a5b07=_0x79dae0?_0x79dae0(_0x5f0838):_0x5f0838,new M(_0x1a5b07,_0x5f0838['node'],M['BLACK'],null,null);{const _0xfe2af1=parseInt(_0x1a078b/0x2,0xa)+_0x431a6d,_0x44dcbd=_0x2a9ef4(_0x431a6d,_0xfe2af1),_0x1c028a=_0x2a9ef4(_0xfe2af1+0x1,_0x4adc28);return _0x5f0838=_0x5698b1[_0xfe2af1],_0x1a5b07=_0x79dae0?_0x79dae0(_0x5f0838):_0x5f0838,new M(_0x1a5b07,_0x5f0838['node'],M['BLACK'],_0x44dcbd,_0x1c028a);}},_0x316171=function(_0x142118){let _0x410029=null,_0x318a59=null,_0x3bcf94=_0x5698b1['length'];const _0x4939e9=function(_0x585537,_0x4e35de){const _0xd5a25f=_0x3bcf94-_0x585537,_0x1a4335=_0x3bcf94;_0x3bcf94-=_0x585537;const _0x49f546=_0x2a9ef4(_0xd5a25f+0x1,_0x1a4335),_0x4b0601=_0x5698b1[_0xd5a25f],_0x9a48aa=_0x79dae0?_0x79dae0(_0x4b0601):_0x4b0601;_0x14f973(new M(_0x9a48aa,_0x4b0601['node'],_0x4e35de,null,_0x49f546));},_0x14f973=function(_0x531bce){_0x410029?(_0x410029['left']=_0x531bce,_0x410029=_0x531bce):(_0x318a59=_0x531bce,_0x410029=_0x531bce);};for(let _0x1dc3a3=0x0;_0x1dc3a3<_0x142118['count'];++_0x1dc3a3){const _0x538a19=_0x142118['nextBitIsOne'](),_0x2a8ca5=Math['pow'](0x2,_0x142118['count']-(_0x1dc3a3+0x1));_0x538a19?_0x4939e9(_0x2a8ca5,M['BLACK']):(_0x4939e9(_0x2a8ca5,M['BLACK']),_0x4939e9(_0x2a8ca5,M['RED']));}return _0x318a59;},_0x659fea=new Hh(_0x5698b1['length']),_0x5dab73=_0x316171(_0x659fea);return new B(_0x2dd1f9||_0x4c9827,_0x5dab73);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x1a3c4e,_0x163777){this['indexes_']=_0x1a3c4e,this['indexSet_']=_0x163777;}['get'](_0x55e1e1){const _0x15c550=Le(this['indexes_'],_0x55e1e1);if(!_0x15c550)throw new Error('No\x20index\x20defined\x20for\x20'+_0x55e1e1);return _0x15c550 instanceof B?_0x15c550:null;}['hasIndex'](_0x4ae41f){return Q(this['indexSet_'],_0x4ae41f['toString']());}['addIndex'](_0x2edff0,_0xb6e4b3){f(_0x2edff0!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x22eb3c=[];let _0x20b23a=!0x1;const _0x522f8f=_0xb6e4b3['getIterator'](E['Wrap']);let _0x2fe407=_0x522f8f['getNext']();for(;_0x2fe407;)_0x20b23a=_0x20b23a||_0x2edff0['isDefinedOn'](_0x2fe407['node']),_0x22eb3c['push'](_0x2fe407),_0x2fe407=_0x522f8f['getNext']();let _0x1c992d;_0x20b23a?_0x1c992d=yn(_0x22eb3c,_0x2edff0['getCompare']()):_0x1c992d=Qe;const _0xb7c6dd=_0x2edff0['toString'](),_0x780660={...this['indexSet_']};_0x780660[_0xb7c6dd]=_0x2edff0;const _0x351096={...this['indexes_']};return _0x351096[_0xb7c6dd]=_0x1c992d,new te(_0x351096,_0x780660);}['addToIndexes'](_0x15a53b,_0x316b04){const _0xf8b040=_n(this['indexes_'],(_0x524c99,_0x9bd5ba)=>{const _0x2651ea=Le(this['indexSet_'],_0x9bd5ba);if(f(_0x2651ea,'Missing\x20index\x20implementation\x20for\x20'+_0x9bd5ba),_0x524c99===Qe){if(_0x2651ea['isDefinedOn'](_0x15a53b['node'])){const _0x381b6a=[],_0xaefe4e=_0x316b04['getIterator'](E['Wrap']);let _0x2cc877=_0xaefe4e['getNext']();for(;_0x2cc877;)_0x2cc877['name']!==_0x15a53b['name']&&_0x381b6a['push'](_0x2cc877),_0x2cc877=_0xaefe4e['getNext']();return _0x381b6a['push'](_0x15a53b),yn(_0x381b6a,_0x2651ea['getCompare']());}else return Qe;}else{const _0x27928c=_0x316b04['get'](_0x15a53b['name']);let _0x2718ef=_0x524c99;return _0x27928c&&(_0x2718ef=_0x2718ef['remove'](new E(_0x15a53b['name'],_0x27928c))),_0x2718ef['insert'](_0x15a53b,_0x15a53b['node']);}});return new te(_0xf8b040,this['indexSet_']);}['removeFromIndexes'](_0x149cb2,_0x46949e){const _0x1266cc=_n(this['indexes_'],_0x401d84=>{if(_0x401d84===Qe)return _0x401d84;{const _0x2794bd=_0x46949e['get'](_0x149cb2['name']);return _0x2794bd?_0x401d84['remove'](new E(_0x149cb2['name'],_0x2794bd)):_0x401d84;}});return new te(_0x1266cc,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x920953,_0x215658,_0x5b6cb9){this['children_']=_0x920953,this['priorityNode_']=_0x215658,this['indexMap_']=_0x5b6cb9,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x147329){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x147329,this['indexMap_']);}['getImmediateChild'](_0x40dfc2){if(_0x40dfc2==='.priority')return this['getPriority']();{const _0x407c0a=this['children_']['get'](_0x40dfc2);return _0x407c0a===null?It:_0x407c0a;}}['getChild'](_0x436917){const _0x1aea49=y(_0x436917);return _0x1aea49===null?this:this['getImmediateChild'](_0x1aea49)['getChild'](S(_0x436917));}['hasChild'](_0x3bde64){return this['children_']['get'](_0x3bde64)!==null;}['updateImmediateChild'](_0x294b63,_0x1b6751){if(f(_0x1b6751,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x294b63==='.priority')return this['updatePriority'](_0x1b6751);{const _0x50b1a5=new E(_0x294b63,_0x1b6751);let _0x3b88ff,_0x3e014a;_0x1b6751['isEmpty']()?(_0x3b88ff=this['children_']['remove'](_0x294b63),_0x3e014a=this['indexMap_']['removeFromIndexes'](_0x50b1a5,this['children_'])):(_0x3b88ff=this['children_']['insert'](_0x294b63,_0x1b6751),_0x3e014a=this['indexMap_']['addToIndexes'](_0x50b1a5,this['children_']));const _0xf734fd=_0x3b88ff['isEmpty']()?It:this['priorityNode_'];return new g(_0x3b88ff,_0xf734fd,_0x3e014a);}}['updateChild'](_0x6a175f,_0x7de4aa){const _0x472ec3=y(_0x6a175f);if(_0x472ec3===null)return _0x7de4aa;{f(y(_0x6a175f)!=='.priority'||Ce(_0x6a175f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xee27e6=this['getImmediateChild'](_0x472ec3)['updateChild'](S(_0x6a175f),_0x7de4aa);return this['updateImmediateChild'](_0x472ec3,_0xee27e6);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x166c2a){if(this['isEmpty']())return null;const _0x4222fe={};let _0x3f0fcc=0x0,_0x3bd384=0x0,_0x47903d=!0x0;if(this['forEachChild'](R,(_0xc29b5e,_0x45ac75)=>{_0x4222fe[_0xc29b5e]=_0x45ac75['val'](_0x166c2a),_0x3f0fcc++,_0x47903d&&g['INTEGER_REGEXP_']['test'](_0xc29b5e)?_0x3bd384=Math['max'](_0x3bd384,Number(_0xc29b5e)):_0x47903d=!0x1;}),!_0x166c2a&&_0x47903d&&_0x3bd384<0x2*_0x3f0fcc){const _0x2e87d3=[];for(const _0x288977 in _0x4222fe)_0x2e87d3[_0x288977]=_0x4222fe[_0x288977];return _0x2e87d3;}else return _0x166c2a&&!this['getPriority']()['isEmpty']()&&(_0x4222fe['.priority']=this['getPriority']()['val']()),_0x4222fe;}['hash'](){if(this['lazyHash_']===null){let _0x3879ed='';this['getPriority']()['isEmpty']()||(_0x3879ed+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x45cdae,_0x30030d)=>{const _0x44b2e8=_0x30030d['hash']();_0x44b2e8!==''&&(_0x3879ed+=':'+_0x45cdae+':'+_0x44b2e8);}),this['lazyHash_']=_0x3879ed===''?'':ro(_0x3879ed);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5e85d7,_0x11c684,_0x36c5b7){const _0x59c74a=this['resolveIndex_'](_0x36c5b7);if(_0x59c74a){const _0x42d551=_0x59c74a['getPredecessorKey'](new E(_0x5e85d7,_0x11c684));return _0x42d551?_0x42d551['name']:null;}else return this['children_']['getPredecessorKey'](_0x5e85d7);}['getFirstChildName'](_0x17ea96){const _0x49a420=this['resolveIndex_'](_0x17ea96);if(_0x49a420){const _0x4f9060=_0x49a420['minKey']();return _0x4f9060&&_0x4f9060['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x111e13){const _0xa71c32=this['getFirstChildName'](_0x111e13);return _0xa71c32?new E(_0xa71c32,this['children_']['get'](_0xa71c32)):null;}['getLastChildName'](_0x36cce9){const _0x20a5f2=this['resolveIndex_'](_0x36cce9);if(_0x20a5f2){const _0x375cd2=_0x20a5f2['maxKey']();return _0x375cd2&&_0x375cd2['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1c03aa){const _0x4782a5=this['getLastChildName'](_0x1c03aa);return _0x4782a5?new E(_0x4782a5,this['children_']['get'](_0x4782a5)):null;}['forEachChild'](_0x5dabc5,_0x259e2c){const _0x3d8d99=this['resolveIndex_'](_0x5dabc5);return _0x3d8d99?_0x3d8d99['inorderTraversal'](_0x280477=>_0x259e2c(_0x280477['name'],_0x280477['node'])):this['children_']['inorderTraversal'](_0x259e2c);}['getIterator'](_0x14ba27){return this['getIteratorFrom'](_0x14ba27['minPost'](),_0x14ba27);}['getIteratorFrom'](_0x2ac084,_0x1814df){const _0x35a01d=this['resolveIndex_'](_0x1814df);if(_0x35a01d)return _0x35a01d['getIteratorFrom'](_0x2ac084,_0x5a87dc=>_0x5a87dc);{const _0x50d112=this['children_']['getIteratorFrom'](_0x2ac084['name'],E['Wrap']);let _0x533b72=_0x50d112['peek']();for(;_0x533b72!=null&&_0x1814df['compare'](_0x533b72,_0x2ac084)<0x0;)_0x50d112['getNext'](),_0x533b72=_0x50d112['peek']();return _0x50d112;}}['getReverseIterator'](_0x355fea){return this['getReverseIteratorFrom'](_0x355fea['maxPost'](),_0x355fea);}['getReverseIteratorFrom'](_0x475d83,_0x20d70c){const _0x47690b=this['resolveIndex_'](_0x20d70c);if(_0x47690b)return _0x47690b['getReverseIteratorFrom'](_0x475d83,_0x21596d=>_0x21596d);{const _0x5264fe=this['children_']['getReverseIteratorFrom'](_0x475d83['name'],E['Wrap']);let _0x5c1652=_0x5264fe['peek']();for(;_0x5c1652!=null&&_0x20d70c['compare'](_0x5c1652,_0x475d83)>0x0;)_0x5264fe['getNext'](),_0x5c1652=_0x5264fe['peek']();return _0x5264fe;}}['compareTo'](_0x578ed5){return this['isEmpty']()?_0x578ed5['isEmpty']()?0x0:-0x1:_0x578ed5['isLeafNode']()||_0x578ed5['isEmpty']()?0x1:_0x578ed5===Kt?-0x1:0x0;}['withIndex'](_0x36d2aa){if(_0x36d2aa===ve||this['indexMap_']['hasIndex'](_0x36d2aa))return this;{const _0x5961c7=this['indexMap_']['addIndex'](_0x36d2aa,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5961c7);}}['isIndexed'](_0x5a393f){return _0x5a393f===ve||this['indexMap_']['hasIndex'](_0x5a393f);}['equals'](_0x2af321){if(_0x2af321===this)return!0x0;if(_0x2af321['isLeafNode']())return!0x1;{const _0x150508=_0x2af321;if(this['getPriority']()['equals'](_0x150508['getPriority']())){if(this['children_']['count']()===_0x150508['children_']['count']()){const _0x4f5923=this['getIterator'](R),_0x2d1ad7=_0x150508['getIterator'](R);let _0x12d584=_0x4f5923['getNext'](),_0x3eb5be=_0x2d1ad7['getNext']();for(;_0x12d584&&_0x3eb5be;){if(_0x12d584['name']!==_0x3eb5be['name']||!_0x12d584['node']['equals'](_0x3eb5be['node']))return!0x1;_0x12d584=_0x4f5923['getNext'](),_0x3eb5be=_0x2d1ad7['getNext']();}return _0x12d584===null&&_0x3eb5be===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4f4f20){return _0x4f4f20===ve?null:this['indexMap_']['get'](_0x4f4f20['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4a69db){return _0x4a69db===this?0x0:0x1;}['equals'](_0x3810e){return _0x3810e===this;}['getPriority'](){return this;}['getImmediateChild'](_0xe3bd66){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3d57e3,_0x1ecc0d=null){if(_0x3d57e3===null)return g['EMPTY_NODE'];if(typeof _0x3d57e3=='object'&&'.priority'in _0x3d57e3&&(_0x1ecc0d=_0x3d57e3['.priority']),f(_0x1ecc0d===null||typeof _0x1ecc0d=='string'||typeof _0x1ecc0d=='number'||typeof _0x1ecc0d=='object'&&'.sv'in _0x1ecc0d,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1ecc0d),typeof _0x3d57e3=='object'&&'.value'in _0x3d57e3&&_0x3d57e3['.value']!==null&&(_0x3d57e3=_0x3d57e3['.value']),typeof _0x3d57e3!='object'||'.sv'in _0x3d57e3){const _0x4f6925=_0x3d57e3;return new D(_0x4f6925,A(_0x1ecc0d));}if(!(_0x3d57e3 instanceof Array)&&Gh){const _0x1410e9=[];let _0x193d8c=!0x1;if(x(_0x3d57e3,(_0x1685e3,_0x5cdb79)=>{if(_0x1685e3['substring'](0x0,0x1)!=='.'){const _0x1f1516=A(_0x5cdb79);_0x1f1516['isEmpty']()||(_0x193d8c=_0x193d8c||!_0x1f1516['getPriority']()['isEmpty'](),_0x1410e9['push'](new E(_0x1685e3,_0x1f1516)));}}),_0x1410e9['length']===0x0)return g['EMPTY_NODE'];const _0x109228=yn(_0x1410e9,xh,_0x5e2647=>_0x5e2647['name'],Qi);if(_0x193d8c){const _0x1ad86d=yn(_0x1410e9,R['getCompare']());return new g(_0x109228,A(_0x1ecc0d),new te({'.priority':_0x1ad86d},{'.priority':R}));}else return new g(_0x109228,A(_0x1ecc0d),te['Default']);}else{let _0x3f8ac2=g['EMPTY_NODE'];return x(_0x3d57e3,(_0x40dd6d,_0x1cf204)=>{if(Q(_0x3d57e3,_0x40dd6d)&&_0x40dd6d['substring'](0x0,0x1)!=='.'){const _0x4fa461=A(_0x1cf204);(_0x4fa461['isLeafNode']()||!_0x4fa461['isEmpty']())&&(_0x3f8ac2=_0x3f8ac2['updateImmediateChild'](_0x40dd6d,_0x4fa461));}}),_0x3f8ac2['updatePriority'](A(_0x1ecc0d));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x563919){super(),this['indexPath_']=_0x563919,f(!v(_0x563919)&&y(_0x563919)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5155b7){return _0x5155b7['getChild'](this['indexPath_']);}['isDefinedOn'](_0xf66738){return!_0xf66738['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3d9147,_0x2e12aa){const _0x205771=this['extractChild'](_0x3d9147['node']),_0x47c912=this['extractChild'](_0x2e12aa['node']),_0x37e336=_0x205771['compareTo'](_0x47c912);return _0x37e336===0x0?qe(_0x3d9147['name'],_0x2e12aa['name']):_0x37e336;}['makePost'](_0x580c75,_0x1c2d71){const _0x281c66=A(_0x580c75),_0x1f995b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x281c66);return new E(_0x1c2d71,_0x1f995b);}['maxPost'](){const _0x58cb21=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x58cb21);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x4b5b3a,_0x5741d2){const _0x18cb3c=_0x4b5b3a['node']['compareTo'](_0x5741d2['node']);return _0x18cb3c===0x0?qe(_0x4b5b3a['name'],_0x5741d2['name']):_0x18cb3c;}['isDefinedOn'](_0xcdacb8){return!0x0;}['indexedValueChanged'](_0x3776f2,_0x25888f){return!_0x3776f2['equals'](_0x25888f);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5f32dc,_0x18cda4){const _0x389892=A(_0x5f32dc);return new E(_0x18cda4,_0x389892);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x20a776){return{'type':'value','snapshotNode':_0x20a776};}function rt(_0x25ea1a,_0x15d996){return{'type':'child_added','snapshotNode':_0x15d996,'childName':_0x25ea1a};}function Lt(_0x52af47,_0x1ffac4){return{'type':'child_removed','snapshotNode':_0x1ffac4,'childName':_0x52af47};}function xt(_0x9345a7,_0x3b5dc4,_0x2adf43){return{'type':'child_changed','snapshotNode':_0x3b5dc4,'childName':_0x9345a7,'oldSnap':_0x2adf43};}function zh(_0x4f8d66,_0x54dcdc){return{'type':'child_moved','snapshotNode':_0x54dcdc,'childName':_0x4f8d66};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x17df4a){this['index_']=_0x17df4a;}['updateChild'](_0x605439,_0x574b9c,_0x1c6a85,_0x3338f7,_0x5a442f,_0x4b715c){f(_0x605439['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x13cd54=_0x605439['getImmediateChild'](_0x574b9c);return _0x13cd54['getChild'](_0x3338f7)['equals'](_0x1c6a85['getChild'](_0x3338f7))&&_0x13cd54['isEmpty']()===_0x1c6a85['isEmpty']()||(_0x4b715c!=null&&(_0x1c6a85['isEmpty']()?_0x605439['hasChild'](_0x574b9c)?_0x4b715c['trackChildChange'](Lt(_0x574b9c,_0x13cd54)):f(_0x605439['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x13cd54['isEmpty']()?_0x4b715c['trackChildChange'](rt(_0x574b9c,_0x1c6a85)):_0x4b715c['trackChildChange'](xt(_0x574b9c,_0x1c6a85,_0x13cd54))),_0x605439['isLeafNode']()&&_0x1c6a85['isEmpty']())?_0x605439:_0x605439['updateImmediateChild'](_0x574b9c,_0x1c6a85)['withIndex'](this['index_']);}['updateFullNode'](_0x56f159,_0x5aa375,_0xf5ebeb){return _0xf5ebeb!=null&&(_0x56f159['isLeafNode']()||_0x56f159['forEachChild'](R,(_0x1846ca,_0x58d255)=>{_0x5aa375['hasChild'](_0x1846ca)||_0xf5ebeb['trackChildChange'](Lt(_0x1846ca,_0x58d255));}),_0x5aa375['isLeafNode']()||_0x5aa375['forEachChild'](R,(_0xfbca1b,_0x482f7e)=>{if(_0x56f159['hasChild'](_0xfbca1b)){const _0x6cb2f5=_0x56f159['getImmediateChild'](_0xfbca1b);_0x6cb2f5['equals'](_0x482f7e)||_0xf5ebeb['trackChildChange'](xt(_0xfbca1b,_0x482f7e,_0x6cb2f5));}else _0xf5ebeb['trackChildChange'](rt(_0xfbca1b,_0x482f7e));})),_0x5aa375['withIndex'](this['index_']);}['updatePriority'](_0x446f10,_0x15be29){return _0x446f10['isEmpty']()?g['EMPTY_NODE']:_0x446f10['updatePriority'](_0x15be29);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x3b5867){this['indexedFilter_']=new Xi(_0x3b5867['getIndex']()),this['index_']=_0x3b5867['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x3b5867),this['endPost_']=Ft['getEndPost_'](_0x3b5867),this['startIsInclusive_']=!_0x3b5867['startAfterSet_'],this['endIsInclusive_']=!_0x3b5867['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x35d340){const _0x3e5b2b=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x35d340)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x35d340)<0x0,_0x1a6da7=this['endIsInclusive_']?this['index_']['compare'](_0x35d340,this['getEndPost']())<=0x0:this['index_']['compare'](_0x35d340,this['getEndPost']())<0x0;return _0x3e5b2b&&_0x1a6da7;}['updateChild'](_0x369bd3,_0xea85f4,_0x139a7c,_0x47eaae,_0x34a957,_0x4a69d2){return this['matches'](new E(_0xea85f4,_0x139a7c))||(_0x139a7c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x369bd3,_0xea85f4,_0x139a7c,_0x47eaae,_0x34a957,_0x4a69d2);}['updateFullNode'](_0x72eaf7,_0x152c02,_0x8f2d19){_0x152c02['isLeafNode']()&&(_0x152c02=g['EMPTY_NODE']);let _0x57136b=_0x152c02['withIndex'](this['index_']);_0x57136b=_0x57136b['updatePriority'](g['EMPTY_NODE']);const _0x46ae56=this;return _0x152c02['forEachChild'](R,(_0x3e87bc,_0x2ed951)=>{_0x46ae56['matches'](new E(_0x3e87bc,_0x2ed951))||(_0x57136b=_0x57136b['updateImmediateChild'](_0x3e87bc,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x72eaf7,_0x57136b,_0x8f2d19);}['updatePriority'](_0xe7e867,_0x95e395){return _0xe7e867;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5ee21a){if(_0x5ee21a['hasStart']()){const _0x2f2d5e=_0x5ee21a['getIndexStartName']();return _0x5ee21a['getIndex']()['makePost'](_0x5ee21a['getIndexStartValue'](),_0x2f2d5e);}else return _0x5ee21a['getIndex']()['minPost']();}static['getEndPost_'](_0x5655c0){if(_0x5655c0['hasEnd']()){const _0x227104=_0x5655c0['getIndexEndName']();return _0x5655c0['getIndex']()['makePost'](_0x5655c0['getIndexEndValue'](),_0x227104);}else return _0x5655c0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x3b0330){this['withinDirectionalStart']=_0x38540b=>this['reverse_']?this['withinEndPost'](_0x38540b):this['withinStartPost'](_0x38540b),this['withinDirectionalEnd']=_0x283145=>this['reverse_']?this['withinStartPost'](_0x283145):this['withinEndPost'](_0x283145),this['withinStartPost']=_0x1e7650=>{const _0x1f5275=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1e7650);return this['startIsInclusive_']?_0x1f5275<=0x0:_0x1f5275<0x0;},this['withinEndPost']=_0x7800f=>{const _0x524ff0=this['index_']['compare'](_0x7800f,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x524ff0<=0x0:_0x524ff0<0x0;},this['rangedFilter_']=new Ft(_0x3b0330),this['index_']=_0x3b0330['getIndex'](),this['limit_']=_0x3b0330['getLimit'](),this['reverse_']=!_0x3b0330['isViewFromLeft'](),this['startIsInclusive_']=!_0x3b0330['startAfterSet_'],this['endIsInclusive_']=!_0x3b0330['endBeforeSet_'];}['updateChild'](_0x3cdde0,_0x3f5299,_0x279543,_0x40c401,_0x24fc27,_0x319b58){return this['rangedFilter_']['matches'](new E(_0x3f5299,_0x279543))||(_0x279543=g['EMPTY_NODE']),_0x3cdde0['getImmediateChild'](_0x3f5299)['equals'](_0x279543)?_0x3cdde0:_0x3cdde0['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x3cdde0,_0x3f5299,_0x279543,_0x40c401,_0x24fc27,_0x319b58):this['fullLimitUpdateChild_'](_0x3cdde0,_0x3f5299,_0x279543,_0x24fc27,_0x319b58);}['updateFullNode'](_0x24d4e9,_0x484060,_0x39bfc1){let _0x5af837;if(_0x484060['isLeafNode']()||_0x484060['isEmpty']())_0x5af837=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x484060['numChildren']()&&_0x484060['isIndexed'](this['index_'])){_0x5af837=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4bdb3c;this['reverse_']?_0x4bdb3c=_0x484060['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4bdb3c=_0x484060['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x240adc=0x0;for(;_0x4bdb3c['hasNext']()&&_0x240adc<this['limit_'];){const _0x36be5=_0x4bdb3c['getNext']();if(this['withinDirectionalStart'](_0x36be5)){if(this['withinDirectionalEnd'](_0x36be5))_0x5af837=_0x5af837['updateImmediateChild'](_0x36be5['name'],_0x36be5['node']),_0x240adc++;else break;}else continue;}}else{_0x5af837=_0x484060['withIndex'](this['index_']),_0x5af837=_0x5af837['updatePriority'](g['EMPTY_NODE']);let _0x11a01c;this['reverse_']?_0x11a01c=_0x5af837['getReverseIterator'](this['index_']):_0x11a01c=_0x5af837['getIterator'](this['index_']);let _0x1ea02f=0x0;for(;_0x11a01c['hasNext']();){const _0x4301ac=_0x11a01c['getNext']();_0x1ea02f<this['limit_']&&this['withinDirectionalStart'](_0x4301ac)&&this['withinDirectionalEnd'](_0x4301ac)?_0x1ea02f++:_0x5af837=_0x5af837['updateImmediateChild'](_0x4301ac['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x24d4e9,_0x5af837,_0x39bfc1);}['updatePriority'](_0x48ed88,_0x499ac3){return _0x48ed88;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4c2224,_0x3590d9,_0x2bfc7f,_0x3730e1,_0x3b2992){let _0x51bc62;if(this['reverse_']){const _0x3b8231=this['index_']['getCompare']();_0x51bc62=(_0x365390,_0x248748)=>_0x3b8231(_0x248748,_0x365390);}else _0x51bc62=this['index_']['getCompare']();const _0x2544a1=_0x4c2224;f(_0x2544a1['numChildren']()===this['limit_'],'');const _0x2b7b0a=new E(_0x3590d9,_0x2bfc7f),_0x42ac64=this['reverse_']?_0x2544a1['getFirstChild'](this['index_']):_0x2544a1['getLastChild'](this['index_']),_0x25c134=this['rangedFilter_']['matches'](_0x2b7b0a);if(_0x2544a1['hasChild'](_0x3590d9)){const _0x4fddac=_0x2544a1['getImmediateChild'](_0x3590d9);let _0x3c8218=_0x3730e1['getChildAfterChild'](this['index_'],_0x42ac64,this['reverse_']);for(;_0x3c8218!=null&&(_0x3c8218['name']===_0x3590d9||_0x2544a1['hasChild'](_0x3c8218['name']));)_0x3c8218=_0x3730e1['getChildAfterChild'](this['index_'],_0x3c8218,this['reverse_']);const _0xd02995=_0x3c8218==null?0x1:_0x51bc62(_0x3c8218,_0x2b7b0a);if(_0x25c134&&!_0x2bfc7f['isEmpty']()&&_0xd02995>=0x0)return _0x3b2992!=null&&_0x3b2992['trackChildChange'](xt(_0x3590d9,_0x2bfc7f,_0x4fddac)),_0x2544a1['updateImmediateChild'](_0x3590d9,_0x2bfc7f);{_0x3b2992!=null&&_0x3b2992['trackChildChange'](Lt(_0x3590d9,_0x4fddac));const _0x23515b=_0x2544a1['updateImmediateChild'](_0x3590d9,g['EMPTY_NODE']);return _0x3c8218!=null&&this['rangedFilter_']['matches'](_0x3c8218)?(_0x3b2992!=null&&_0x3b2992['trackChildChange'](rt(_0x3c8218['name'],_0x3c8218['node'])),_0x23515b['updateImmediateChild'](_0x3c8218['name'],_0x3c8218['node'])):_0x23515b;}}else return _0x2bfc7f['isEmpty']()?_0x4c2224:_0x25c134&&_0x51bc62(_0x42ac64,_0x2b7b0a)>=0x0?(_0x3b2992!=null&&(_0x3b2992['trackChildChange'](Lt(_0x42ac64['name'],_0x42ac64['node'])),_0x3b2992['trackChildChange'](rt(_0x3590d9,_0x2bfc7f))),_0x2544a1['updateImmediateChild'](_0x3590d9,_0x2bfc7f)['updateImmediateChild'](_0x42ac64['name'],g['EMPTY_NODE'])):_0x4c2224;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x20c3c1=new Zi();return _0x20c3c1['limitSet_']=this['limitSet_'],_0x20c3c1['limit_']=this['limit_'],_0x20c3c1['startSet_']=this['startSet_'],_0x20c3c1['startAfterSet_']=this['startAfterSet_'],_0x20c3c1['indexStartValue_']=this['indexStartValue_'],_0x20c3c1['startNameSet_']=this['startNameSet_'],_0x20c3c1['indexStartName_']=this['indexStartName_'],_0x20c3c1['endSet_']=this['endSet_'],_0x20c3c1['endBeforeSet_']=this['endBeforeSet_'],_0x20c3c1['indexEndValue_']=this['indexEndValue_'],_0x20c3c1['endNameSet_']=this['endNameSet_'],_0x20c3c1['indexEndName_']=this['indexEndName_'],_0x20c3c1['index_']=this['index_'],_0x20c3c1['viewFrom_']=this['viewFrom_'],_0x20c3c1;}}function Kh(_0x639380){return _0x639380['loadsAllData']()?new Xi(_0x639380['getIndex']()):_0x639380['hasLimit']()?new jh(_0x639380):new Ft(_0x639380);}function Yh(_0xf7cd94,_0x562d67){const _0xe8d89b=_0xf7cd94['copy']();return _0xe8d89b['limitSet_']=!0x0,_0xe8d89b['limit_']=_0x562d67,_0xe8d89b['viewFrom_']='l',_0xe8d89b;}function Qh(_0x58657b,_0x4a1383,_0x5aadd0){const _0x42bfb6=_0x58657b['copy']();return _0x42bfb6['startSet_']=!0x0,_0x4a1383===void 0x0&&(_0x4a1383=null),_0x42bfb6['indexStartValue_']=_0x4a1383,_0x5aadd0!=null?(_0x42bfb6['startNameSet_']=!0x0,_0x42bfb6['indexStartName_']=_0x5aadd0):(_0x42bfb6['startNameSet_']=!0x1,_0x42bfb6['indexStartName_']=''),_0x42bfb6;}function Jh(_0x51b3e8,_0x451a44,_0x50d3b3){const _0x4257a1=_0x51b3e8['copy']();return _0x4257a1['endSet_']=!0x0,_0x451a44===void 0x0&&(_0x451a44=null),_0x4257a1['indexEndValue_']=_0x451a44,_0x50d3b3!==void 0x0?(_0x4257a1['endNameSet_']=!0x0,_0x4257a1['indexEndName_']=_0x50d3b3):(_0x4257a1['endNameSet_']=!0x1,_0x4257a1['indexEndName_']=''),_0x4257a1;}function xo(_0x207fdc,_0xaced39){const _0x2cb4d1=_0x207fdc['copy']();return _0x2cb4d1['index_']=_0xaced39,_0x2cb4d1;}function ir(_0x2152d8){const _0x3f1c58={};if(_0x2152d8['isDefault']())return _0x3f1c58;let _0x1a1333;if(_0x2152d8['index_']===R?_0x1a1333='$priority':_0x2152d8['index_']===Mo?_0x1a1333='$value':_0x2152d8['index_']===ve?_0x1a1333='$key':(f(_0x2152d8['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1a1333=_0x2152d8['index_']['toString']()),_0x3f1c58['orderBy']=O(_0x1a1333),_0x2152d8['startSet_']){const _0x4fed42=_0x2152d8['startAfterSet_']?'startAfter':'startAt';_0x3f1c58[_0x4fed42]=O(_0x2152d8['indexStartValue_']),_0x2152d8['startNameSet_']&&(_0x3f1c58[_0x4fed42]+=','+O(_0x2152d8['indexStartName_']));}if(_0x2152d8['endSet_']){const _0x1f232e=_0x2152d8['endBeforeSet_']?'endBefore':'endAt';_0x3f1c58[_0x1f232e]=O(_0x2152d8['indexEndValue_']),_0x2152d8['endNameSet_']&&(_0x3f1c58[_0x1f232e]+=','+O(_0x2152d8['indexEndName_']));}return _0x2152d8['limitSet_']&&(_0x2152d8['isViewFromLeft']()?_0x3f1c58['limitToFirst']=_0x2152d8['limit_']:_0x3f1c58['limitToLast']=_0x2152d8['limit_']),_0x3f1c58;}function sr(_0x16312d){const _0x202fe0={};if(_0x16312d['startSet_']&&(_0x202fe0['sp']=_0x16312d['indexStartValue_'],_0x16312d['startNameSet_']&&(_0x202fe0['sn']=_0x16312d['indexStartName_']),_0x202fe0['sin']=!_0x16312d['startAfterSet_']),_0x16312d['endSet_']&&(_0x202fe0['ep']=_0x16312d['indexEndValue_'],_0x16312d['endNameSet_']&&(_0x202fe0['en']=_0x16312d['indexEndName_']),_0x202fe0['ein']=!_0x16312d['endBeforeSet_']),_0x16312d['limitSet_']){_0x202fe0['l']=_0x16312d['limit_'];let _0x399f63=_0x16312d['viewFrom_'];_0x399f63===''&&(_0x16312d['isViewFromLeft']()?_0x399f63='l':_0x399f63='r'),_0x202fe0['vf']=_0x399f63;}return _0x16312d['index_']!==R&&(_0x202fe0['i']=_0x16312d['index_']['toString']()),_0x202fe0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x15a1a8){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x36a6d9,_0x58bfbe){return _0x58bfbe!==void 0x0?'tag$'+_0x58bfbe:(f(_0x36a6d9['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x36a6d9['_path']['toString']());}constructor(_0x4e021a,_0x49f892,_0x579a99,_0x1b06c5){super(),this['repoInfo_']=_0x4e021a,this['onDataUpdate_']=_0x49f892,this['authTokenProvider_']=_0x579a99,this['appCheckTokenProvider_']=_0x1b06c5,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4ac157,_0x735025,_0x756865,_0x2dfc75){const _0x34a4c8=_0x4ac157['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x34a4c8+'\x20'+_0x4ac157['_queryIdentifier']);const _0x1e4bc3=vn['getListenId_'](_0x4ac157,_0x756865),_0x2f844a={};this['listens_'][_0x1e4bc3]=_0x2f844a;const _0x15b626=ir(_0x4ac157['_queryParams']);this['restRequest_'](_0x34a4c8+'.json',_0x15b626,(_0x55a650,_0x1df20a)=>{let _0x46ea41=_0x1df20a;if(_0x55a650===0x194&&(_0x46ea41=null,_0x55a650=null),_0x55a650===null&&this['onDataUpdate_'](_0x34a4c8,_0x46ea41,!0x1,_0x756865),Le(this['listens_'],_0x1e4bc3)===_0x2f844a){let _0x436b36;_0x55a650?_0x55a650===0x191?_0x436b36='permission_denied':_0x436b36='rest_error:'+_0x55a650:_0x436b36='ok',_0x2dfc75(_0x436b36,null);}});}['unlisten'](_0x583689,_0x49b8d7){const _0x18b172=vn['getListenId_'](_0x583689,_0x49b8d7);delete this['listens_'][_0x18b172];}['get'](_0x335fd0){const _0x3c0d71=ir(_0x335fd0['_queryParams']),_0x26aa3a=_0x335fd0['_path']['toString'](),_0x2765f8=new H();return this['restRequest_'](_0x26aa3a+'.json',_0x3c0d71,(_0x1bb65d,_0x8a1b76)=>{let _0x36512a=_0x8a1b76;_0x1bb65d===0x194&&(_0x36512a=null,_0x1bb65d=null),_0x1bb65d===null?(this['onDataUpdate_'](_0x26aa3a,_0x36512a,!0x1,null),_0x2765f8['resolve'](_0x36512a)):_0x2765f8['reject'](new Error(_0x36512a));}),_0x2765f8['promise'];}['refreshAuthToken'](_0x503b89){}['restRequest_'](_0x556361,_0x348eee={},_0x3b637d){return _0x348eee['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x14dcc0,_0x5eb38d])=>{_0x14dcc0&&_0x14dcc0['accessToken']&&(_0x348eee['auth']=_0x14dcc0['accessToken']),_0x5eb38d&&_0x5eb38d['token']&&(_0x348eee['ac']=_0x5eb38d['token']);const _0x306230=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x556361+'?ns='+this['repoInfo_']['namespace']+ut(_0x348eee);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x306230);const _0x2772da=new XMLHttpRequest();_0x2772da['onreadystatechange']=()=>{if(_0x3b637d&&_0x2772da['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x306230+'\x20received.\x20status:',_0x2772da['status'],'response:',_0x2772da['responseText']);let _0x2d8ee1=null;if(_0x2772da['status']>=0xc8&&_0x2772da['status']<0x12c){try{_0x2d8ee1=Nt(_0x2772da['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x306230+':\x20'+_0x2772da['responseText']);}_0x3b637d(null,_0x2d8ee1);}else _0x2772da['status']!==0x191&&_0x2772da['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x306230+'\x20Status:\x20'+_0x2772da['status']),_0x3b637d(_0x2772da['status']);_0x3b637d=null;}},_0x2772da['open']('GET',_0x306230,!0x0),_0x2772da['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xa46aa6){return this['rootNode_']['getChild'](_0xa46aa6);}['updateSnapshot'](_0xa055b8,_0x27fc05){this['rootNode_']=this['rootNode_']['updateChild'](_0xa055b8,_0x27fc05);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2b8f97,_0x10c72e,_0x278c81){if(v(_0x10c72e))_0x2b8f97['value']=_0x278c81,_0x2b8f97['children']['clear']();else{if(_0x2b8f97['value']!==null)_0x2b8f97['value']=_0x2b8f97['value']['updateChild'](_0x10c72e,_0x278c81);else{const _0x4f0319=y(_0x10c72e);_0x2b8f97['children']['has'](_0x4f0319)||_0x2b8f97['children']['set'](_0x4f0319,En());const _0x2f1e4b=_0x2b8f97['children']['get'](_0x4f0319);_0x10c72e=S(_0x10c72e),pt(_0x2f1e4b,_0x10c72e,_0x278c81);}}}function Ti(_0x42b841,_0x2be653){if(v(_0x2be653))return _0x42b841['value']=null,_0x42b841['children']['clear'](),!0x0;if(_0x42b841['value']!==null){if(_0x42b841['value']['isLeafNode']())return!0x1;{const _0x18dd51=_0x42b841['value'];return _0x42b841['value']=null,_0x18dd51['forEachChild'](R,(_0x5f51f1,_0x2bf164)=>{pt(_0x42b841,new C(_0x5f51f1),_0x2bf164);}),Ti(_0x42b841,_0x2be653);}}else{if(_0x42b841['children']['size']>0x0){const _0xbd0512=y(_0x2be653);return _0x2be653=S(_0x2be653),_0x42b841['children']['has'](_0xbd0512)&&Ti(_0x42b841['children']['get'](_0xbd0512),_0x2be653)&&_0x42b841['children']['delete'](_0xbd0512),_0x42b841['children']['size']===0x0;}else return!0x0;}}function Si(_0x4a17f4,_0x2d965c,_0x117590){_0x4a17f4['value']!==null?_0x117590(_0x2d965c,_0x4a17f4['value']):Zh(_0x4a17f4,(_0x5d4b64,_0x48c11f)=>{const _0x41ed7e=new C(_0x2d965c['toString']()+'/'+_0x5d4b64);Si(_0x48c11f,_0x41ed7e,_0x117590);});}function Zh(_0x36e2f8,_0x2297ac){_0x36e2f8['children']['forEach']((_0x31afc3,_0x97a457)=>{_0x2297ac(_0x97a457,_0x31afc3);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x46a987){this['collection_']=_0x46a987,this['last_']=null;}['get'](){const _0x4b8649=this['collection_']['get'](),_0x477806={..._0x4b8649};return this['last_']&&x(this['last_'],(_0x3d5c8c,_0x3cc445)=>{_0x477806[_0x3d5c8c]=_0x477806[_0x3d5c8c]-_0x3cc445;}),this['last_']=_0x4b8649,_0x477806;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x5cae22,_0x3a1b2e){this['server_']=_0x3a1b2e,this['statsToReport_']={},this['statsListener_']=new eu(_0x5cae22);const _0x4a16de=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x4a16de));}['reportStats_'](){const _0x4fd496=this['statsListener_']['get'](),_0x14a0de={};let _0x2fa4a6=!0x1;x(_0x4fd496,(_0x470bc6,_0x23ab18)=>{_0x23ab18>0x0&&Q(this['statsToReport_'],_0x470bc6)&&(_0x14a0de[_0x470bc6]=_0x23ab18,_0x2fa4a6=!0x0);}),_0x2fa4a6&&this['server_']['reportStats'](_0x14a0de),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x51a0ec){_0x51a0ec[_0x51a0ec['OVERWRITE']=0x0]='OVERWRITE',_0x51a0ec[_0x51a0ec['MERGE']=0x1]='MERGE',_0x51a0ec[_0x51a0ec['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x51a0ec[_0x51a0ec['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x5d9552){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x5d9552,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x547993,_0x31e38b,_0x31ba40){this['path']=_0x547993,this['affectedTree']=_0x31e38b,this['revert']=_0x31ba40,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3713eb){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5228fa=this['affectedTree']['subtree'](new C(_0x3713eb));return new In(w(),_0x5228fa,this['revert']);}}else return f(y(this['path'])===_0x3713eb,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x2c7fe9,_0x56efbc){this['source']=_0x2c7fe9,this['path']=_0x56efbc,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x1bf7f2){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5a21ba,_0x44069a,_0x1618c5){this['source']=_0x5a21ba,this['path']=_0x44069a,this['snap']=_0x1618c5,this['type']=z['OVERWRITE'];}['operationForChild'](_0x34adae){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x34adae)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x1156e6,_0x4699c4,_0x463705){this['source']=_0x1156e6,this['path']=_0x4699c4,this['children']=_0x463705,this['type']=z['MERGE'];}['operationForChild'](_0x24341b){if(v(this['path'])){const _0x51cca4=this['children']['subtree'](new C(_0x24341b));return _0x51cca4['isEmpty']()?null:_0x51cca4['value']?new Be(this['source'],w(),_0x51cca4['value']):new ot(this['source'],w(),_0x51cca4);}else return f(y(this['path'])===_0x24341b,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x324007,_0x4bf6cb,_0x39ea21){this['node_']=_0x324007,this['fullyInitialized_']=_0x4bf6cb,this['filtered_']=_0x39ea21;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1e35db){if(v(_0x1e35db))return this['isFullyInitialized']()&&!this['filtered_'];const _0x34b989=y(_0x1e35db);return this['isCompleteForChild'](_0x34b989);}['isCompleteForChild'](_0x319cb3){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x319cb3);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x427153){this['query_']=_0x427153,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x211087,_0x42a1ed,_0x31344a,_0x3fdf90){const _0x3e79f8=[],_0x49fdcd=[];return _0x42a1ed['forEach'](_0x44b4c8=>{_0x44b4c8['type']==='child_changed'&&_0x211087['index_']['indexedValueChanged'](_0x44b4c8['oldSnap'],_0x44b4c8['snapshotNode'])&&_0x49fdcd['push'](zh(_0x44b4c8['childName'],_0x44b4c8['snapshotNode']));}),wt(_0x211087,_0x3e79f8,'child_removed',_0x42a1ed,_0x3fdf90,_0x31344a),wt(_0x211087,_0x3e79f8,'child_added',_0x42a1ed,_0x3fdf90,_0x31344a),wt(_0x211087,_0x3e79f8,'child_moved',_0x49fdcd,_0x3fdf90,_0x31344a),wt(_0x211087,_0x3e79f8,'child_changed',_0x42a1ed,_0x3fdf90,_0x31344a),wt(_0x211087,_0x3e79f8,'value',_0x42a1ed,_0x3fdf90,_0x31344a),_0x3e79f8;}function wt(_0x5d5887,_0x4dd137,_0x24eb21,_0x2e49fe,_0xc5a73d,_0x28f1f4){const _0x349a8b=_0x2e49fe['filter'](_0x3ae4da=>_0x3ae4da['type']===_0x24eb21);_0x349a8b['sort']((_0x2c978b,_0x2d6f58)=>au(_0x5d5887,_0x2c978b,_0x2d6f58)),_0x349a8b['forEach'](_0x35e59f=>{const _0x231abc=ou(_0x5d5887,_0x35e59f,_0x28f1f4);_0xc5a73d['forEach'](_0x1c080d=>{_0x1c080d['respondsTo'](_0x35e59f['type'])&&_0x4dd137['push'](_0x1c080d['createEvent'](_0x231abc,_0x5d5887['query_']));});});}function ou(_0x2a8eb6,_0x427b25,_0x1d592f){return _0x427b25['type']==='value'||_0x427b25['type']==='child_removed'||(_0x427b25['prevName']=_0x1d592f['getPredecessorChildName'](_0x427b25['childName'],_0x427b25['snapshotNode'],_0x2a8eb6['index_'])),_0x427b25;}function au(_0x3fb298,_0x388582,_0x4d33bd){if(_0x388582['childName']==null||_0x4d33bd['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x454534=new E(_0x388582['childName'],_0x388582['snapshotNode']),_0x186c2a=new E(_0x4d33bd['childName'],_0x4d33bd['snapshotNode']);return _0x3fb298['index_']['compare'](_0x454534,_0x186c2a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x15c427,_0x56fbb6){return{'eventCache':_0x15c427,'serverCache':_0x56fbb6};}function Rt(_0x5117d0,_0x4d46f4,_0x3eae17,_0x28fe83){return Un(new Te(_0x4d46f4,_0x3eae17,_0x28fe83),_0x5117d0['serverCache']);}function Fo(_0x2c7e73,_0x1d8ed9,_0x1edde1,_0x3fc132){return Un(_0x2c7e73['eventCache'],new Te(_0x1d8ed9,_0x1edde1,_0x3fc132));}function wn(_0x264a0d){return _0x264a0d['eventCache']['isFullyInitialized']()?_0x264a0d['eventCache']['getNode']():null;}function Ve(_0x4789af){return _0x4789af['serverCache']['isFullyInitialized']()?_0x4789af['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2611dd){let _0xa05be8=new b(null);return x(_0x2611dd,(_0x5451cb,_0x462663)=>{_0xa05be8=_0xa05be8['set'](new C(_0x5451cb),_0x462663);}),_0xa05be8;}constructor(_0x3b3f35,_0x4583e3=cu()){this['value']=_0x3b3f35,this['children']=_0x4583e3;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xb4e11c,_0x2079a0){if(this['value']!=null&&_0x2079a0(this['value']))return{'path':w(),'value':this['value']};if(v(_0xb4e11c))return null;{const _0x17a490=y(_0xb4e11c),_0x3cf6b2=this['children']['get'](_0x17a490);if(_0x3cf6b2!==null){const _0x5c7934=_0x3cf6b2['findRootMostMatchingPathAndValue'](S(_0xb4e11c),_0x2079a0);return _0x5c7934!=null?{'path':k(new C(_0x17a490),_0x5c7934['path']),'value':_0x5c7934['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5dd80f){return this['findRootMostMatchingPathAndValue'](_0x5dd80f,()=>!0x0);}['subtree'](_0x15bc07){if(v(_0x15bc07))return this;{const _0x2721c0=y(_0x15bc07),_0x40dd08=this['children']['get'](_0x2721c0);return _0x40dd08!==null?_0x40dd08['subtree'](S(_0x15bc07)):new b(null);}}['set'](_0x52f25c,_0x534af2){if(v(_0x52f25c))return new b(_0x534af2,this['children']);{const _0x42c61e=y(_0x52f25c),_0x57b6d9=(this['children']['get'](_0x42c61e)||new b(null))['set'](S(_0x52f25c),_0x534af2),_0x35a7a6=this['children']['insert'](_0x42c61e,_0x57b6d9);return new b(this['value'],_0x35a7a6);}}['remove'](_0x41c941){if(v(_0x41c941))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x46c24f=y(_0x41c941),_0x1499f7=this['children']['get'](_0x46c24f);if(_0x1499f7){const _0x342350=_0x1499f7['remove'](S(_0x41c941));let _0x45ab3f;return _0x342350['isEmpty']()?_0x45ab3f=this['children']['remove'](_0x46c24f):_0x45ab3f=this['children']['insert'](_0x46c24f,_0x342350),this['value']===null&&_0x45ab3f['isEmpty']()?new b(null):new b(this['value'],_0x45ab3f);}else return this;}}['get'](_0x1d4d98){if(v(_0x1d4d98))return this['value'];{const _0xce61d=y(_0x1d4d98),_0x41ee27=this['children']['get'](_0xce61d);return _0x41ee27?_0x41ee27['get'](S(_0x1d4d98)):null;}}['setTree'](_0x56502f,_0x2a70c5){if(v(_0x56502f))return _0x2a70c5;{const _0x289ce5=y(_0x56502f),_0x1f7239=(this['children']['get'](_0x289ce5)||new b(null))['setTree'](S(_0x56502f),_0x2a70c5);let _0x2b3736;return _0x1f7239['isEmpty']()?_0x2b3736=this['children']['remove'](_0x289ce5):_0x2b3736=this['children']['insert'](_0x289ce5,_0x1f7239),new b(this['value'],_0x2b3736);}}['fold'](_0x517d2a){return this['fold_'](w(),_0x517d2a);}['fold_'](_0x4111c2,_0x214b70){const _0x2c06cf={};return this['children']['inorderTraversal']((_0x2618e9,_0x1cd809)=>{_0x2c06cf[_0x2618e9]=_0x1cd809['fold_'](k(_0x4111c2,_0x2618e9),_0x214b70);}),_0x214b70(_0x4111c2,this['value'],_0x2c06cf);}['findOnPath'](_0x470f49,_0x36f801){return this['findOnPath_'](_0x470f49,w(),_0x36f801);}['findOnPath_'](_0x125461,_0x245735,_0x32c26c){const _0x350779=this['value']?_0x32c26c(_0x245735,this['value']):!0x1;if(_0x350779)return _0x350779;if(v(_0x125461))return null;{const _0x2a54be=y(_0x125461),_0x5523d8=this['children']['get'](_0x2a54be);return _0x5523d8?_0x5523d8['findOnPath_'](S(_0x125461),k(_0x245735,_0x2a54be),_0x32c26c):null;}}['foreachOnPath'](_0x26f1b1,_0x10c138){return this['foreachOnPath_'](_0x26f1b1,w(),_0x10c138);}['foreachOnPath_'](_0x4bdbe8,_0x2a80c5,_0x52f387){if(v(_0x4bdbe8))return this;{this['value']&&_0x52f387(_0x2a80c5,this['value']);const _0x55de6e=y(_0x4bdbe8),_0x38b7a=this['children']['get'](_0x55de6e);return _0x38b7a?_0x38b7a['foreachOnPath_'](S(_0x4bdbe8),k(_0x2a80c5,_0x55de6e),_0x52f387):new b(null);}}['foreach'](_0x31ead9){this['foreach_'](w(),_0x31ead9);}['foreach_'](_0x497b34,_0x118028){this['children']['inorderTraversal']((_0x25b7c1,_0x1c8e43)=>{_0x1c8e43['foreach_'](k(_0x497b34,_0x25b7c1),_0x118028);}),this['value']&&_0x118028(_0x497b34,this['value']);}['foreachChild'](_0x1b4243){this['children']['inorderTraversal']((_0x2f4db2,_0x516e7c)=>{_0x516e7c['value']&&_0x1b4243(_0x2f4db2,_0x516e7c['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4ee31f){this['writeTree_']=_0x4ee31f;}static['empty'](){return new K(new b(null));}}function At(_0x4b0edb,_0x542c94,_0x2bc8d3){if(v(_0x542c94))return new K(new b(_0x2bc8d3));{const _0x1a3079=_0x4b0edb['writeTree_']['findRootMostValueAndPath'](_0x542c94);if(_0x1a3079!=null){const _0x3eecb9=_0x1a3079['path'];let _0x2646a2=_0x1a3079['value'];const _0x5a47ad=F(_0x3eecb9,_0x542c94);return _0x2646a2=_0x2646a2['updateChild'](_0x5a47ad,_0x2bc8d3),new K(_0x4b0edb['writeTree_']['set'](_0x3eecb9,_0x2646a2));}else{const _0xe84fb5=new b(_0x2bc8d3),_0x17a773=_0x4b0edb['writeTree_']['setTree'](_0x542c94,_0xe84fb5);return new K(_0x17a773);}}}function bi(_0x1125e9,_0xf21255,_0x6c059c){let _0x2b9922=_0x1125e9;return x(_0x6c059c,(_0x23a0b,_0x184a70)=>{_0x2b9922=At(_0x2b9922,k(_0xf21255,_0x23a0b),_0x184a70);}),_0x2b9922;}function or(_0xb9998a,_0x540d21){if(v(_0x540d21))return K['empty']();{const _0x285481=_0xb9998a['writeTree_']['setTree'](_0x540d21,new b(null));return new K(_0x285481);}}function Ri(_0x485a60,_0x1d3791){return ze(_0x485a60,_0x1d3791)!=null;}function ze(_0x518b3b,_0x18b2a3){const _0x1acd5e=_0x518b3b['writeTree_']['findRootMostValueAndPath'](_0x18b2a3);return _0x1acd5e!=null?_0x518b3b['writeTree_']['get'](_0x1acd5e['path'])['getChild'](F(_0x1acd5e['path'],_0x18b2a3)):null;}function ar(_0x53e4a4){const _0x3bb556=[],_0x170890=_0x53e4a4['writeTree_']['value'];return _0x170890!=null?_0x170890['isLeafNode']()||_0x170890['forEachChild'](R,(_0x23fd6e,_0x30a803)=>{_0x3bb556['push'](new E(_0x23fd6e,_0x30a803));}):_0x53e4a4['writeTree_']['children']['inorderTraversal']((_0xda7980,_0x18659d)=>{_0x18659d['value']!=null&&_0x3bb556['push'](new E(_0xda7980,_0x18659d['value']));}),_0x3bb556;}function Ee(_0x41e016,_0x2de3c3){if(v(_0x2de3c3))return _0x41e016;{const _0x27788c=ze(_0x41e016,_0x2de3c3);return _0x27788c!=null?new K(new b(_0x27788c)):new K(_0x41e016['writeTree_']['subtree'](_0x2de3c3));}}function Ai(_0x3296d1){return _0x3296d1['writeTree_']['isEmpty']();}function at(_0x27a90a,_0x201aa2){return Uo(w(),_0x27a90a['writeTree_'],_0x201aa2);}function Uo(_0x5d8846,_0x1d2000,_0x313837){if(_0x1d2000['value']!=null)return _0x313837['updateChild'](_0x5d8846,_0x1d2000['value']);{let _0xa726a3=null;return _0x1d2000['children']['inorderTraversal']((_0x38bf09,_0x2a7fc0)=>{_0x38bf09==='.priority'?(f(_0x2a7fc0['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xa726a3=_0x2a7fc0['value']):_0x313837=Uo(k(_0x5d8846,_0x38bf09),_0x2a7fc0,_0x313837);}),!_0x313837['getChild'](_0x5d8846)['isEmpty']()&&_0xa726a3!==null&&(_0x313837=_0x313837['updateChild'](k(_0x5d8846,'.priority'),_0xa726a3)),_0x313837;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1dd48a,_0x50d250){return Ho(_0x50d250,_0x1dd48a);}function lu(_0x567490,_0x512979,_0x11479c,_0x345202,_0x1e47f5){f(_0x345202>_0x567490['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1e47f5===void 0x0&&(_0x1e47f5=!0x0),_0x567490['allWrites']['push']({'path':_0x512979,'snap':_0x11479c,'writeId':_0x345202,'visible':_0x1e47f5}),_0x1e47f5&&(_0x567490['visibleWrites']=At(_0x567490['visibleWrites'],_0x512979,_0x11479c)),_0x567490['lastWriteId']=_0x345202;}function hu(_0x46e7b3,_0x16fc97,_0x3ba712,_0x353b40){f(_0x353b40>_0x46e7b3['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x46e7b3['allWrites']['push']({'path':_0x16fc97,'children':_0x3ba712,'writeId':_0x353b40,'visible':!0x0}),_0x46e7b3['visibleWrites']=bi(_0x46e7b3['visibleWrites'],_0x16fc97,_0x3ba712),_0x46e7b3['lastWriteId']=_0x353b40;}function uu(_0xa6f441,_0x3b443b){for(let _0xbd7f0=0x0;_0xbd7f0<_0xa6f441['allWrites']['length'];_0xbd7f0++){const _0x37a2b7=_0xa6f441['allWrites'][_0xbd7f0];if(_0x37a2b7['writeId']===_0x3b443b)return _0x37a2b7;}return null;}function du(_0x4b2c6d,_0x95aa0c){const _0x406563=_0x4b2c6d['allWrites']['findIndex'](_0x1e049c=>_0x1e049c['writeId']===_0x95aa0c);f(_0x406563>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x2bcf9b=_0x4b2c6d['allWrites'][_0x406563];_0x4b2c6d['allWrites']['splice'](_0x406563,0x1);let _0x4907b0=_0x2bcf9b['visible'],_0x35dffc=!0x1,_0x3f5862=_0x4b2c6d['allWrites']['length']-0x1;for(;_0x4907b0&&_0x3f5862>=0x0;){const _0x1ae3a6=_0x4b2c6d['allWrites'][_0x3f5862];_0x1ae3a6['visible']&&(_0x3f5862>=_0x406563&&fu(_0x1ae3a6,_0x2bcf9b['path'])?_0x4907b0=!0x1:G(_0x2bcf9b['path'],_0x1ae3a6['path'])&&(_0x35dffc=!0x0)),_0x3f5862--;}if(_0x4907b0){if(_0x35dffc)return pu(_0x4b2c6d),!0x0;if(_0x2bcf9b['snap'])_0x4b2c6d['visibleWrites']=or(_0x4b2c6d['visibleWrites'],_0x2bcf9b['path']);else{const _0x3c65df=_0x2bcf9b['children'];x(_0x3c65df,_0x1e21f0=>{_0x4b2c6d['visibleWrites']=or(_0x4b2c6d['visibleWrites'],k(_0x2bcf9b['path'],_0x1e21f0));});}return!0x0;}else return!0x1;}function fu(_0x5f10d9,_0x11d141){if(_0x5f10d9['snap'])return G(_0x5f10d9['path'],_0x11d141);for(const _0x578b56 in _0x5f10d9['children'])if(_0x5f10d9['children']['hasOwnProperty'](_0x578b56)&&G(k(_0x5f10d9['path'],_0x578b56),_0x11d141))return!0x0;return!0x1;}function pu(_0x7b1d0e){_0x7b1d0e['visibleWrites']=Wo(_0x7b1d0e['allWrites'],_u,w()),_0x7b1d0e['allWrites']['length']>0x0?_0x7b1d0e['lastWriteId']=_0x7b1d0e['allWrites'][_0x7b1d0e['allWrites']['length']-0x1]['writeId']:_0x7b1d0e['lastWriteId']=-0x1;}function _u(_0x4b6473){return _0x4b6473['visible'];}function Wo(_0x50107f,_0xeb19d1,_0x155525){let _0x1cbb23=K['empty']();for(let _0x9bf9f8=0x0;_0x9bf9f8<_0x50107f['length'];++_0x9bf9f8){const _0x419545=_0x50107f[_0x9bf9f8];if(_0xeb19d1(_0x419545)){const _0x455ac4=_0x419545['path'];let _0x5b8041;if(_0x419545['snap'])G(_0x155525,_0x455ac4)?(_0x5b8041=F(_0x155525,_0x455ac4),_0x1cbb23=At(_0x1cbb23,_0x5b8041,_0x419545['snap'])):G(_0x455ac4,_0x155525)&&(_0x5b8041=F(_0x455ac4,_0x155525),_0x1cbb23=At(_0x1cbb23,w(),_0x419545['snap']['getChild'](_0x5b8041)));else{if(_0x419545['children']){if(G(_0x155525,_0x455ac4))_0x5b8041=F(_0x155525,_0x455ac4),_0x1cbb23=bi(_0x1cbb23,_0x5b8041,_0x419545['children']);else{if(G(_0x455ac4,_0x155525)){if(_0x5b8041=F(_0x455ac4,_0x155525),v(_0x5b8041))_0x1cbb23=bi(_0x1cbb23,w(),_0x419545['children']);else{const _0x39972a=Le(_0x419545['children'],y(_0x5b8041));if(_0x39972a){const _0x49071f=_0x39972a['getChild'](S(_0x5b8041));_0x1cbb23=At(_0x1cbb23,w(),_0x49071f);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1cbb23;}function Bo(_0x5b32b4,_0x5da454,_0x5eb2d8,_0x2b5fc5,_0x3ecd41){if(!_0x2b5fc5&&!_0x3ecd41){const _0x3389a4=ze(_0x5b32b4['visibleWrites'],_0x5da454);if(_0x3389a4!=null)return _0x3389a4;{const _0x5053fa=Ee(_0x5b32b4['visibleWrites'],_0x5da454);if(Ai(_0x5053fa))return _0x5eb2d8;if(_0x5eb2d8==null&&!Ri(_0x5053fa,w()))return null;{const _0x3c7064=_0x5eb2d8||g['EMPTY_NODE'];return at(_0x5053fa,_0x3c7064);}}}else{const _0x3a8848=Ee(_0x5b32b4['visibleWrites'],_0x5da454);if(!_0x3ecd41&&Ai(_0x3a8848))return _0x5eb2d8;if(!_0x3ecd41&&_0x5eb2d8==null&&!Ri(_0x3a8848,w()))return null;{const _0x127faf=function(_0x32ebb4){return(_0x32ebb4['visible']||_0x3ecd41)&&(!_0x2b5fc5||!~_0x2b5fc5['indexOf'](_0x32ebb4['writeId']))&&(G(_0x32ebb4['path'],_0x5da454)||G(_0x5da454,_0x32ebb4['path']));},_0x1f7a81=Wo(_0x5b32b4['allWrites'],_0x127faf,_0x5da454),_0x42cd4b=_0x5eb2d8||g['EMPTY_NODE'];return at(_0x1f7a81,_0x42cd4b);}}}function gu(_0x55af23,_0x2fa0f5,_0xe7dd41){let _0x2847e3=g['EMPTY_NODE'];const _0x1fba56=ze(_0x55af23['visibleWrites'],_0x2fa0f5);if(_0x1fba56)return _0x1fba56['isLeafNode']()||_0x1fba56['forEachChild'](R,(_0x355d83,_0x378cd7)=>{_0x2847e3=_0x2847e3['updateImmediateChild'](_0x355d83,_0x378cd7);}),_0x2847e3;if(_0xe7dd41){const _0x5a90f6=Ee(_0x55af23['visibleWrites'],_0x2fa0f5);return _0xe7dd41['forEachChild'](R,(_0x2c12ac,_0x53461f)=>{const _0x4feb0a=at(Ee(_0x5a90f6,new C(_0x2c12ac)),_0x53461f);_0x2847e3=_0x2847e3['updateImmediateChild'](_0x2c12ac,_0x4feb0a);}),ar(_0x5a90f6)['forEach'](_0x1db49e=>{_0x2847e3=_0x2847e3['updateImmediateChild'](_0x1db49e['name'],_0x1db49e['node']);}),_0x2847e3;}else{const _0x314790=Ee(_0x55af23['visibleWrites'],_0x2fa0f5);return ar(_0x314790)['forEach'](_0xc10b4e=>{_0x2847e3=_0x2847e3['updateImmediateChild'](_0xc10b4e['name'],_0xc10b4e['node']);}),_0x2847e3;}}function mu(_0x3fe52e,_0x4687b9,_0x1574af,_0x5230b2,_0x2f208c){f(_0x5230b2||_0x2f208c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x221cdc=k(_0x4687b9,_0x1574af);if(Ri(_0x3fe52e['visibleWrites'],_0x221cdc))return null;{const _0x1c2da7=Ee(_0x3fe52e['visibleWrites'],_0x221cdc);return Ai(_0x1c2da7)?_0x2f208c['getChild'](_0x1574af):at(_0x1c2da7,_0x2f208c['getChild'](_0x1574af));}}function yu(_0x459eb0,_0x436aa7,_0x89bbe6,_0x4042a0){const _0x27e300=k(_0x436aa7,_0x89bbe6),_0x1584c9=ze(_0x459eb0['visibleWrites'],_0x27e300);if(_0x1584c9!=null)return _0x1584c9;if(_0x4042a0['isCompleteForChild'](_0x89bbe6)){const _0x4c9f9b=Ee(_0x459eb0['visibleWrites'],_0x27e300);return at(_0x4c9f9b,_0x4042a0['getNode']()['getImmediateChild'](_0x89bbe6));}else return null;}function vu(_0x3d6141,_0x32df17){return ze(_0x3d6141['visibleWrites'],_0x32df17);}function Eu(_0xdd3ac8,_0x295bd3,_0x1d3fea,_0x5e234f,_0x1d05b0,_0x86d94c,_0x4c03dd){let _0x45c9ba;const _0x5734f7=Ee(_0xdd3ac8['visibleWrites'],_0x295bd3),_0x585aed=ze(_0x5734f7,w());if(_0x585aed!=null)_0x45c9ba=_0x585aed;else{if(_0x1d3fea!=null)_0x45c9ba=at(_0x5734f7,_0x1d3fea);else return[];}if(_0x45c9ba=_0x45c9ba['withIndex'](_0x4c03dd),!_0x45c9ba['isEmpty']()&&!_0x45c9ba['isLeafNode']()){const _0x3b0d3c=[],_0x1f5cc5=_0x4c03dd['getCompare'](),_0x342a85=_0x86d94c?_0x45c9ba['getReverseIteratorFrom'](_0x5e234f,_0x4c03dd):_0x45c9ba['getIteratorFrom'](_0x5e234f,_0x4c03dd);let _0x55dd9e=_0x342a85['getNext']();for(;_0x55dd9e&&_0x3b0d3c['length']<_0x1d05b0;)_0x1f5cc5(_0x55dd9e,_0x5e234f)!==0x0&&_0x3b0d3c['push'](_0x55dd9e),_0x55dd9e=_0x342a85['getNext']();return _0x3b0d3c;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0xe81b7,_0x154e4c,_0x27a5aa,_0x719531){return Bo(_0xe81b7['writeTree'],_0xe81b7['treePath'],_0x154e4c,_0x27a5aa,_0x719531);}function is(_0x582194,_0x285787){return gu(_0x582194['writeTree'],_0x582194['treePath'],_0x285787);}function cr(_0x54c7b7,_0x302b1e,_0x34ef14,_0x1a7941){return mu(_0x54c7b7['writeTree'],_0x54c7b7['treePath'],_0x302b1e,_0x34ef14,_0x1a7941);}function Tn(_0x31214c,_0x208cbc){return vu(_0x31214c['writeTree'],k(_0x31214c['treePath'],_0x208cbc));}function wu(_0x36d38f,_0x364be8,_0x582dd4,_0x596d8e,_0x2dfcdf,_0x266d8d){return Eu(_0x36d38f['writeTree'],_0x36d38f['treePath'],_0x364be8,_0x582dd4,_0x596d8e,_0x2dfcdf,_0x266d8d);}function ss(_0x4a1379,_0x1053c0,_0xc9f4a0){return yu(_0x4a1379['writeTree'],_0x4a1379['treePath'],_0x1053c0,_0xc9f4a0);}function Vo(_0x57906b,_0x2c1741){return Ho(k(_0x57906b['treePath'],_0x2c1741),_0x57906b['writeTree']);}function Ho(_0x860b3f,_0x30d502){return{'treePath':_0x860b3f,'writeTree':_0x30d502};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x431daa){const _0x4fc617=_0x431daa['type'],_0x5dc0c5=_0x431daa['childName'];f(_0x4fc617==='child_added'||_0x4fc617==='child_changed'||_0x4fc617==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5dc0c5!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1dd1a0=this['changeMap']['get'](_0x5dc0c5);if(_0x1dd1a0){const _0xb872b1=_0x1dd1a0['type'];if(_0x4fc617==='child_added'&&_0xb872b1==='child_removed')this['changeMap']['set'](_0x5dc0c5,xt(_0x5dc0c5,_0x431daa['snapshotNode'],_0x1dd1a0['snapshotNode']));else{if(_0x4fc617==='child_removed'&&_0xb872b1==='child_added')this['changeMap']['delete'](_0x5dc0c5);else{if(_0x4fc617==='child_removed'&&_0xb872b1==='child_changed')this['changeMap']['set'](_0x5dc0c5,Lt(_0x5dc0c5,_0x1dd1a0['oldSnap']));else{if(_0x4fc617==='child_changed'&&_0xb872b1==='child_added')this['changeMap']['set'](_0x5dc0c5,rt(_0x5dc0c5,_0x431daa['snapshotNode']));else{if(_0x4fc617==='child_changed'&&_0xb872b1==='child_changed')this['changeMap']['set'](_0x5dc0c5,xt(_0x5dc0c5,_0x431daa['snapshotNode'],_0x1dd1a0['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x431daa+'\x20occurred\x20after\x20'+_0x1dd1a0);}}}}}else this['changeMap']['set'](_0x5dc0c5,_0x431daa);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3c0b3e){return null;}['getChildAfterChild'](_0x5f3eb4,_0x407932,_0x359ea0){return null;}}const $o=new Tu();class rs{constructor(_0x115a63,_0x2c70ba,_0x5d88c5=null){this['writes_']=_0x115a63,this['viewCache_']=_0x2c70ba,this['optCompleteServerCache_']=_0x5d88c5;}['getCompleteChild'](_0x2ebb44){const _0x1ad2c4=this['viewCache_']['eventCache'];if(_0x1ad2c4['isCompleteForChild'](_0x2ebb44))return _0x1ad2c4['getNode']()['getImmediateChild'](_0x2ebb44);{const _0x4d7fca=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2ebb44,_0x4d7fca);}}['getChildAfterChild'](_0x18cdf9,_0x14a649,_0x4fa01b){const _0x4c0cd2=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x151608=wu(this['writes_'],_0x4c0cd2,_0x14a649,0x1,_0x4fa01b,_0x18cdf9);return _0x151608['length']===0x0?null:_0x151608[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x33820b){return{'filter':_0x33820b};}function bu(_0x2e8774,_0x20cf16){f(_0x20cf16['eventCache']['getNode']()['isIndexed'](_0x2e8774['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x20cf16['serverCache']['getNode']()['isIndexed'](_0x2e8774['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x3c20c3,_0x447d24,_0x405d20,_0x419222,_0x174654){const _0x23a367=new Cu();let _0xfdcf8,_0x3325a0;if(_0x405d20['type']===z['OVERWRITE']){const _0x581347=_0x405d20;_0x581347['source']['fromUser']?_0xfdcf8=ki(_0x3c20c3,_0x447d24,_0x581347['path'],_0x581347['snap'],_0x419222,_0x174654,_0x23a367):(f(_0x581347['source']['fromServer'],'Unknown\x20source.'),_0x3325a0=_0x581347['source']['tagged']||_0x447d24['serverCache']['isFiltered']()&&!v(_0x581347['path']),_0xfdcf8=Sn(_0x3c20c3,_0x447d24,_0x581347['path'],_0x581347['snap'],_0x419222,_0x174654,_0x3325a0,_0x23a367));}else{if(_0x405d20['type']===z['MERGE']){const _0x5ae83c=_0x405d20;_0x5ae83c['source']['fromUser']?_0xfdcf8=ku(_0x3c20c3,_0x447d24,_0x5ae83c['path'],_0x5ae83c['children'],_0x419222,_0x174654,_0x23a367):(f(_0x5ae83c['source']['fromServer'],'Unknown\x20source.'),_0x3325a0=_0x5ae83c['source']['tagged']||_0x447d24['serverCache']['isFiltered'](),_0xfdcf8=Pi(_0x3c20c3,_0x447d24,_0x5ae83c['path'],_0x5ae83c['children'],_0x419222,_0x174654,_0x3325a0,_0x23a367));}else{if(_0x405d20['type']===z['ACK_USER_WRITE']){const _0xcf37da=_0x405d20;_0xcf37da['revert']?_0xfdcf8=Ou(_0x3c20c3,_0x447d24,_0xcf37da['path'],_0x419222,_0x174654,_0x23a367):_0xfdcf8=Pu(_0x3c20c3,_0x447d24,_0xcf37da['path'],_0xcf37da['affectedTree'],_0x419222,_0x174654,_0x23a367);}else{if(_0x405d20['type']===z['LISTEN_COMPLETE'])_0xfdcf8=Nu(_0x3c20c3,_0x447d24,_0x405d20['path'],_0x419222,_0x23a367);else throw ht('Unknown\x20operation\x20type:\x20'+_0x405d20['type']);}}}const _0x430bce=_0x23a367['getChanges']();return Au(_0x447d24,_0xfdcf8,_0x430bce),{'viewCache':_0xfdcf8,'changes':_0x430bce};}function Au(_0x1f09ce,_0x1cff6f,_0x2d9e08){const _0x339b00=_0x1cff6f['eventCache'];if(_0x339b00['isFullyInitialized']()){const _0x42b0b5=_0x339b00['getNode']()['isLeafNode']()||_0x339b00['getNode']()['isEmpty'](),_0x541b25=wn(_0x1f09ce);(_0x2d9e08['length']>0x0||!_0x1f09ce['eventCache']['isFullyInitialized']()||_0x42b0b5&&!_0x339b00['getNode']()['equals'](_0x541b25)||!_0x339b00['getNode']()['getPriority']()['equals'](_0x541b25['getPriority']()))&&_0x2d9e08['push'](Lo(wn(_0x1cff6f)));}}function Go(_0x277dc6,_0x52fcc0,_0x56e4a5,_0x4469c6,_0xf137b,_0x1386de){const _0x55201e=_0x52fcc0['eventCache'];if(Tn(_0x4469c6,_0x56e4a5)!=null)return _0x52fcc0;{let _0x11bf80,_0x5855bd;if(v(_0x56e4a5)){if(f(_0x52fcc0['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x52fcc0['serverCache']['isFiltered']()){const _0x150616=Ve(_0x52fcc0),_0x4b8b0f=_0x150616 instanceof g?_0x150616:g['EMPTY_NODE'],_0x41bdd0=is(_0x4469c6,_0x4b8b0f);_0x11bf80=_0x277dc6['filter']['updateFullNode'](_0x52fcc0['eventCache']['getNode'](),_0x41bdd0,_0x1386de);}else{const _0xb66712=Cn(_0x4469c6,Ve(_0x52fcc0));_0x11bf80=_0x277dc6['filter']['updateFullNode'](_0x52fcc0['eventCache']['getNode'](),_0xb66712,_0x1386de);}}else{const _0x2cd3aa=y(_0x56e4a5);if(_0x2cd3aa==='.priority'){f(Ce(_0x56e4a5)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2ca756=_0x55201e['getNode']();_0x5855bd=_0x52fcc0['serverCache']['getNode']();const _0x5315f9=cr(_0x4469c6,_0x56e4a5,_0x2ca756,_0x5855bd);_0x5315f9!=null?_0x11bf80=_0x277dc6['filter']['updatePriority'](_0x2ca756,_0x5315f9):_0x11bf80=_0x55201e['getNode']();}else{const _0x268ada=S(_0x56e4a5);let _0x415d9d;if(_0x55201e['isCompleteForChild'](_0x2cd3aa)){_0x5855bd=_0x52fcc0['serverCache']['getNode']();const _0x1faea2=cr(_0x4469c6,_0x56e4a5,_0x55201e['getNode'](),_0x5855bd);_0x1faea2!=null?_0x415d9d=_0x55201e['getNode']()['getImmediateChild'](_0x2cd3aa)['updateChild'](_0x268ada,_0x1faea2):_0x415d9d=_0x55201e['getNode']()['getImmediateChild'](_0x2cd3aa);}else _0x415d9d=ss(_0x4469c6,_0x2cd3aa,_0x52fcc0['serverCache']);_0x415d9d!=null?_0x11bf80=_0x277dc6['filter']['updateChild'](_0x55201e['getNode'](),_0x2cd3aa,_0x415d9d,_0x268ada,_0xf137b,_0x1386de):_0x11bf80=_0x55201e['getNode']();}}return Rt(_0x52fcc0,_0x11bf80,_0x55201e['isFullyInitialized']()||v(_0x56e4a5),_0x277dc6['filter']['filtersNodes']());}}function Sn(_0x32b1f4,_0x2b73c4,_0x109423,_0x4f83f1,_0x2cbe94,_0x2568d4,_0x31fb83,_0x2471f6){const _0xafef2a=_0x2b73c4['serverCache'];let _0x403657;const _0x5d2419=_0x31fb83?_0x32b1f4['filter']:_0x32b1f4['filter']['getIndexedFilter']();if(v(_0x109423))_0x403657=_0x5d2419['updateFullNode'](_0xafef2a['getNode'](),_0x4f83f1,null);else{if(_0x5d2419['filtersNodes']()&&!_0xafef2a['isFiltered']()){const _0x5473f4=_0xafef2a['getNode']()['updateChild'](_0x109423,_0x4f83f1);_0x403657=_0x5d2419['updateFullNode'](_0xafef2a['getNode'](),_0x5473f4,null);}else{const _0x5cd10f=y(_0x109423);if(!_0xafef2a['isCompleteForPath'](_0x109423)&&Ce(_0x109423)>0x1)return _0x2b73c4;const _0x512090=S(_0x109423),_0x259723=_0xafef2a['getNode']()['getImmediateChild'](_0x5cd10f)['updateChild'](_0x512090,_0x4f83f1);_0x5cd10f==='.priority'?_0x403657=_0x5d2419['updatePriority'](_0xafef2a['getNode'](),_0x259723):_0x403657=_0x5d2419['updateChild'](_0xafef2a['getNode'](),_0x5cd10f,_0x259723,_0x512090,$o,null);}}const _0x716263=Fo(_0x2b73c4,_0x403657,_0xafef2a['isFullyInitialized']()||v(_0x109423),_0x5d2419['filtersNodes']()),_0x298063=new rs(_0x2cbe94,_0x716263,_0x2568d4);return Go(_0x32b1f4,_0x716263,_0x109423,_0x2cbe94,_0x298063,_0x2471f6);}function ki(_0x5c3c9c,_0x2abfbd,_0x171182,_0x2943cb,_0x14f140,_0x20b99f,_0x125e5a){const _0x44a75e=_0x2abfbd['eventCache'];let _0x5bd886,_0x3ed691;const _0x3b6317=new rs(_0x14f140,_0x2abfbd,_0x20b99f);if(v(_0x171182))_0x3ed691=_0x5c3c9c['filter']['updateFullNode'](_0x2abfbd['eventCache']['getNode'](),_0x2943cb,_0x125e5a),_0x5bd886=Rt(_0x2abfbd,_0x3ed691,!0x0,_0x5c3c9c['filter']['filtersNodes']());else{const _0x1be374=y(_0x171182);if(_0x1be374==='.priority')_0x3ed691=_0x5c3c9c['filter']['updatePriority'](_0x2abfbd['eventCache']['getNode'](),_0x2943cb),_0x5bd886=Rt(_0x2abfbd,_0x3ed691,_0x44a75e['isFullyInitialized'](),_0x44a75e['isFiltered']());else{const _0x45e377=S(_0x171182),_0x44a38a=_0x44a75e['getNode']()['getImmediateChild'](_0x1be374);let _0x30cabe;if(v(_0x45e377))_0x30cabe=_0x2943cb;else{const _0x6096df=_0x3b6317['getCompleteChild'](_0x1be374);_0x6096df!=null?ji(_0x45e377)==='.priority'&&_0x6096df['getChild'](Ro(_0x45e377))['isEmpty']()?_0x30cabe=_0x6096df:_0x30cabe=_0x6096df['updateChild'](_0x45e377,_0x2943cb):_0x30cabe=g['EMPTY_NODE'];}if(_0x44a38a['equals'](_0x30cabe))_0x5bd886=_0x2abfbd;else{const _0x441017=_0x5c3c9c['filter']['updateChild'](_0x44a75e['getNode'](),_0x1be374,_0x30cabe,_0x45e377,_0x3b6317,_0x125e5a);_0x5bd886=Rt(_0x2abfbd,_0x441017,_0x44a75e['isFullyInitialized'](),_0x5c3c9c['filter']['filtersNodes']());}}}return _0x5bd886;}function lr(_0x5c4d8b,_0x17c336){return _0x5c4d8b['eventCache']['isCompleteForChild'](_0x17c336);}function ku(_0x3530ce,_0x5772c6,_0x384ecc,_0x11d6b9,_0x3a4346,_0x458376,_0x7896f){let _0x53bebe=_0x5772c6;return _0x11d6b9['foreach']((_0x10d245,_0x521835)=>{const _0x4c1fef=k(_0x384ecc,_0x10d245);lr(_0x5772c6,y(_0x4c1fef))&&(_0x53bebe=ki(_0x3530ce,_0x53bebe,_0x4c1fef,_0x521835,_0x3a4346,_0x458376,_0x7896f));}),_0x11d6b9['foreach']((_0x15b555,_0x1fdeeb)=>{const _0x5441eb=k(_0x384ecc,_0x15b555);lr(_0x5772c6,y(_0x5441eb))||(_0x53bebe=ki(_0x3530ce,_0x53bebe,_0x5441eb,_0x1fdeeb,_0x3a4346,_0x458376,_0x7896f));}),_0x53bebe;}function hr(_0x25f0a0,_0x352955,_0x105b0a){return _0x105b0a['foreach']((_0x243880,_0x23957a)=>{_0x352955=_0x352955['updateChild'](_0x243880,_0x23957a);}),_0x352955;}function Pi(_0x525b20,_0x3c3c8c,_0x2a5add,_0x55d714,_0x1de1a4,_0x5c2c8a,_0x19a514,_0x4f9f26){if(_0x3c3c8c['serverCache']['getNode']()['isEmpty']()&&!_0x3c3c8c['serverCache']['isFullyInitialized']())return _0x3c3c8c;let _0x5ad0a7=_0x3c3c8c,_0x1311d8;v(_0x2a5add)?_0x1311d8=_0x55d714:_0x1311d8=new b(null)['setTree'](_0x2a5add,_0x55d714);const _0x597db4=_0x3c3c8c['serverCache']['getNode']();return _0x1311d8['children']['inorderTraversal']((_0x3fb539,_0x461f90)=>{if(_0x597db4['hasChild'](_0x3fb539)){const _0x56f689=_0x3c3c8c['serverCache']['getNode']()['getImmediateChild'](_0x3fb539),_0x1c37cf=hr(_0x525b20,_0x56f689,_0x461f90);_0x5ad0a7=Sn(_0x525b20,_0x5ad0a7,new C(_0x3fb539),_0x1c37cf,_0x1de1a4,_0x5c2c8a,_0x19a514,_0x4f9f26);}}),_0x1311d8['children']['inorderTraversal']((_0x14bec1,_0x337cda)=>{const _0xfceec1=!_0x3c3c8c['serverCache']['isCompleteForChild'](_0x14bec1)&&_0x337cda['value']===null;if(!_0x597db4['hasChild'](_0x14bec1)&&!_0xfceec1){const _0x56c6d4=_0x3c3c8c['serverCache']['getNode']()['getImmediateChild'](_0x14bec1),_0x2eb7ef=hr(_0x525b20,_0x56c6d4,_0x337cda);_0x5ad0a7=Sn(_0x525b20,_0x5ad0a7,new C(_0x14bec1),_0x2eb7ef,_0x1de1a4,_0x5c2c8a,_0x19a514,_0x4f9f26);}}),_0x5ad0a7;}function Pu(_0x3f96d5,_0x8bcfdb,_0x181254,_0x42f933,_0x272774,_0x3e7a11,_0x2dc033){if(Tn(_0x272774,_0x181254)!=null)return _0x8bcfdb;const _0x275fba=_0x8bcfdb['serverCache']['isFiltered'](),_0x5eb71b=_0x8bcfdb['serverCache'];if(_0x42f933['value']!=null){if(v(_0x181254)&&_0x5eb71b['isFullyInitialized']()||_0x5eb71b['isCompleteForPath'](_0x181254))return Sn(_0x3f96d5,_0x8bcfdb,_0x181254,_0x5eb71b['getNode']()['getChild'](_0x181254),_0x272774,_0x3e7a11,_0x275fba,_0x2dc033);if(v(_0x181254)){let _0x57edbf=new b(null);return _0x5eb71b['getNode']()['forEachChild'](ve,(_0xa98713,_0x26ca4e)=>{_0x57edbf=_0x57edbf['set'](new C(_0xa98713),_0x26ca4e);}),Pi(_0x3f96d5,_0x8bcfdb,_0x181254,_0x57edbf,_0x272774,_0x3e7a11,_0x275fba,_0x2dc033);}else return _0x8bcfdb;}else{let _0x4794f3=new b(null);return _0x42f933['foreach']((_0x376444,_0xad9a40)=>{const _0x16fc27=k(_0x181254,_0x376444);_0x5eb71b['isCompleteForPath'](_0x16fc27)&&(_0x4794f3=_0x4794f3['set'](_0x376444,_0x5eb71b['getNode']()['getChild'](_0x16fc27)));}),Pi(_0x3f96d5,_0x8bcfdb,_0x181254,_0x4794f3,_0x272774,_0x3e7a11,_0x275fba,_0x2dc033);}}function Nu(_0x309745,_0xb575f9,_0x3d043e,_0x37a892,_0x3bc94b){const _0x41f1d3=_0xb575f9['serverCache'],_0x4de5df=Fo(_0xb575f9,_0x41f1d3['getNode'](),_0x41f1d3['isFullyInitialized']()||v(_0x3d043e),_0x41f1d3['isFiltered']());return Go(_0x309745,_0x4de5df,_0x3d043e,_0x37a892,$o,_0x3bc94b);}function Ou(_0x5589b3,_0x562750,_0x460f5a,_0x202fbb,_0x181e14,_0x5c35b5){let _0x5b5b77;if(Tn(_0x202fbb,_0x460f5a)!=null)return _0x562750;{const _0x46ba71=new rs(_0x202fbb,_0x562750,_0x181e14),_0x579d77=_0x562750['eventCache']['getNode']();let _0x476485;if(v(_0x460f5a)||y(_0x460f5a)==='.priority'){let _0x21113f;if(_0x562750['serverCache']['isFullyInitialized']())_0x21113f=Cn(_0x202fbb,Ve(_0x562750));else{const _0x4888df=_0x562750['serverCache']['getNode']();f(_0x4888df instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x21113f=is(_0x202fbb,_0x4888df);}_0x21113f=_0x21113f,_0x476485=_0x5589b3['filter']['updateFullNode'](_0x579d77,_0x21113f,_0x5c35b5);}else{const _0x222546=y(_0x460f5a);let _0x59b125=ss(_0x202fbb,_0x222546,_0x562750['serverCache']);_0x59b125==null&&_0x562750['serverCache']['isCompleteForChild'](_0x222546)&&(_0x59b125=_0x579d77['getImmediateChild'](_0x222546)),_0x59b125!=null?_0x476485=_0x5589b3['filter']['updateChild'](_0x579d77,_0x222546,_0x59b125,S(_0x460f5a),_0x46ba71,_0x5c35b5):_0x562750['eventCache']['getNode']()['hasChild'](_0x222546)?_0x476485=_0x5589b3['filter']['updateChild'](_0x579d77,_0x222546,g['EMPTY_NODE'],S(_0x460f5a),_0x46ba71,_0x5c35b5):_0x476485=_0x579d77,_0x476485['isEmpty']()&&_0x562750['serverCache']['isFullyInitialized']()&&(_0x5b5b77=Cn(_0x202fbb,Ve(_0x562750)),_0x5b5b77['isLeafNode']()&&(_0x476485=_0x5589b3['filter']['updateFullNode'](_0x476485,_0x5b5b77,_0x5c35b5)));}return _0x5b5b77=_0x562750['serverCache']['isFullyInitialized']()||Tn(_0x202fbb,w())!=null,Rt(_0x562750,_0x476485,_0x5b5b77,_0x5589b3['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x43e581,_0x33716d){this['query_']=_0x43e581,this['eventRegistrations_']=[];const _0x3a8fec=this['query_']['_queryParams'],_0x4b8350=new Xi(_0x3a8fec['getIndex']()),_0x167ea4=Kh(_0x3a8fec);this['processor_']=Su(_0x167ea4);const _0x54db9f=_0x33716d['serverCache'],_0x3a33e1=_0x33716d['eventCache'],_0x41f141=_0x4b8350['updateFullNode'](g['EMPTY_NODE'],_0x54db9f['getNode'](),null),_0x264aa7=_0x167ea4['updateFullNode'](g['EMPTY_NODE'],_0x3a33e1['getNode'](),null),_0x29d06c=new Te(_0x41f141,_0x54db9f['isFullyInitialized'](),_0x4b8350['filtersNodes']()),_0x53e247=new Te(_0x264aa7,_0x3a33e1['isFullyInitialized'](),_0x167ea4['filtersNodes']());this['viewCache_']=Un(_0x53e247,_0x29d06c),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2f9f4d){return _0x2f9f4d['viewCache_']['serverCache']['getNode']();}function Lu(_0x75a962){return wn(_0x75a962['viewCache_']);}function xu(_0x844ce6,_0x7c684b){const _0x2fa443=Ve(_0x844ce6['viewCache_']);return _0x2fa443&&(_0x844ce6['query']['_queryParams']['loadsAllData']()||!v(_0x7c684b)&&!_0x2fa443['getImmediateChild'](y(_0x7c684b))['isEmpty']())?_0x2fa443['getChild'](_0x7c684b):null;}function ur(_0x473947){return _0x473947['eventRegistrations_']['length']===0x0;}function Fu(_0x22c417,_0x26c7ea){_0x22c417['eventRegistrations_']['push'](_0x26c7ea);}function dr(_0xfe46f4,_0x46bf89,_0x8ef6cf){const _0x149549=[];if(_0x8ef6cf){f(_0x46bf89==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x169922=_0xfe46f4['query']['_path'];_0xfe46f4['eventRegistrations_']['forEach'](_0x49b8b3=>{const _0x44aa9c=_0x49b8b3['createCancelEvent'](_0x8ef6cf,_0x169922);_0x44aa9c&&_0x149549['push'](_0x44aa9c);});}if(_0x46bf89){let _0x4de21f=[];for(let _0x2c7602=0x0;_0x2c7602<_0xfe46f4['eventRegistrations_']['length'];++_0x2c7602){const _0x3ba9f3=_0xfe46f4['eventRegistrations_'][_0x2c7602];if(!_0x3ba9f3['matches'](_0x46bf89))_0x4de21f['push'](_0x3ba9f3);else{if(_0x46bf89['hasAnyCallback']()){_0x4de21f=_0x4de21f['concat'](_0xfe46f4['eventRegistrations_']['slice'](_0x2c7602+0x1));break;}}}_0xfe46f4['eventRegistrations_']=_0x4de21f;}else _0xfe46f4['eventRegistrations_']=[];return _0x149549;}function fr(_0x554c55,_0x3dfa55,_0x1cdc4d,_0x43c63b){_0x3dfa55['type']===z['MERGE']&&_0x3dfa55['source']['queryId']!==null&&(f(Ve(_0x554c55['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x554c55['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xce6e83=_0x554c55['viewCache_'],_0x38ad79=Ru(_0x554c55['processor_'],_0xce6e83,_0x3dfa55,_0x1cdc4d,_0x43c63b);return bu(_0x554c55['processor_'],_0x38ad79['viewCache']),f(_0x38ad79['viewCache']['serverCache']['isFullyInitialized']()||!_0xce6e83['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x554c55['viewCache_']=_0x38ad79['viewCache'],qo(_0x554c55,_0x38ad79['changes'],_0x38ad79['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x23696c,_0x5bedd0){const _0x3649c6=_0x23696c['viewCache_']['eventCache'],_0x1cfb62=[];return _0x3649c6['getNode']()['isLeafNode']()||_0x3649c6['getNode']()['forEachChild'](R,(_0x28a640,_0x587389)=>{_0x1cfb62['push'](rt(_0x28a640,_0x587389));}),_0x3649c6['isFullyInitialized']()&&_0x1cfb62['push'](Lo(_0x3649c6['getNode']())),qo(_0x23696c,_0x1cfb62,_0x3649c6['getNode'](),_0x5bedd0);}function qo(_0x3a3648,_0x561e4e,_0x2da782,_0x4e089d){const _0x205c7f=_0x4e089d?[_0x4e089d]:_0x3a3648['eventRegistrations_'];return ru(_0x3a3648['eventGenerator_'],_0x561e4e,_0x2da782,_0x205c7f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x18c63a){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x18c63a;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x28936e){return _0x28936e['views']['size']===0x0;}function os(_0x4ba845,_0x44067f,_0x4cd562,_0x2696cf){const _0x2341f4=_0x44067f['source']['queryId'];if(_0x2341f4!==null){const _0x53cfc3=_0x4ba845['views']['get'](_0x2341f4);return f(_0x53cfc3!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x53cfc3,_0x44067f,_0x4cd562,_0x2696cf);}else{let _0x30c951=[];for(const _0x29929a of _0x4ba845['views']['values']())_0x30c951=_0x30c951['concat'](fr(_0x29929a,_0x44067f,_0x4cd562,_0x2696cf));return _0x30c951;}}function jo(_0xeddfc5,_0x34909b,_0x8a4e60,_0x126379,_0x475673){const _0x56344e=_0x34909b['_queryIdentifier'],_0x324e40=_0xeddfc5['views']['get'](_0x56344e);if(!_0x324e40){let _0x5e8b06=Cn(_0x8a4e60,_0x475673?_0x126379:null),_0x37c249=!0x1;_0x5e8b06?_0x37c249=!0x0:_0x126379 instanceof g?(_0x5e8b06=is(_0x8a4e60,_0x126379),_0x37c249=!0x1):(_0x5e8b06=g['EMPTY_NODE'],_0x37c249=!0x1);const _0x1cc682=Un(new Te(_0x5e8b06,_0x37c249,!0x1),new Te(_0x126379,_0x475673,!0x1));return new Du(_0x34909b,_0x1cc682);}return _0x324e40;}function Hu(_0x1ca282,_0x5479bf,_0x50e396,_0x5a7ae0,_0x4341e3,_0x30fa5e){const _0x3bb418=jo(_0x1ca282,_0x5479bf,_0x5a7ae0,_0x4341e3,_0x30fa5e);return _0x1ca282['views']['has'](_0x5479bf['_queryIdentifier'])||_0x1ca282['views']['set'](_0x5479bf['_queryIdentifier'],_0x3bb418),Fu(_0x3bb418,_0x50e396),Uu(_0x3bb418,_0x50e396);}function $u(_0x67a012,_0x1a5fb9,_0x205ed9,_0x2c04a7){const _0x3471f7=_0x1a5fb9['_queryIdentifier'],_0x4700a3=[];let _0x23dca2=[];const _0x339cc6=Se(_0x67a012);if(_0x3471f7==='default'){for(const [_0x45f148,_0x45dd3e]of _0x67a012['views']['entries']())_0x23dca2=_0x23dca2['concat'](dr(_0x45dd3e,_0x205ed9,_0x2c04a7)),ur(_0x45dd3e)&&(_0x67a012['views']['delete'](_0x45f148),_0x45dd3e['query']['_queryParams']['loadsAllData']()||_0x4700a3['push'](_0x45dd3e['query']));}else{const _0x2ce566=_0x67a012['views']['get'](_0x3471f7);_0x2ce566&&(_0x23dca2=_0x23dca2['concat'](dr(_0x2ce566,_0x205ed9,_0x2c04a7)),ur(_0x2ce566)&&(_0x67a012['views']['delete'](_0x3471f7),_0x2ce566['query']['_queryParams']['loadsAllData']()||_0x4700a3['push'](_0x2ce566['query'])));}return _0x339cc6&&!Se(_0x67a012)&&_0x4700a3['push'](new(Bu())(_0x1a5fb9['_repo'],_0x1a5fb9['_path'])),{'removed':_0x4700a3,'events':_0x23dca2};}function Ko(_0x56bc63){const _0x178800=[];for(const _0x4ed331 of _0x56bc63['views']['values']())_0x4ed331['query']['_queryParams']['loadsAllData']()||_0x178800['push'](_0x4ed331);return _0x178800;}function Ie(_0xf60ed0,_0x4f9f82){let _0x49dee9=null;for(const _0x3d963a of _0xf60ed0['views']['values']())_0x49dee9=_0x49dee9||xu(_0x3d963a,_0x4f9f82);return _0x49dee9;}function Yo(_0x5931d4,_0x4f9e4a){if(_0x4f9e4a['_queryParams']['loadsAllData']())return Bn(_0x5931d4);{const _0x23d91e=_0x4f9e4a['_queryIdentifier'];return _0x5931d4['views']['get'](_0x23d91e);}}function Qo(_0x219866,_0x156eec){return Yo(_0x219866,_0x156eec)!=null;}function Se(_0x34cbaa){return Bn(_0x34cbaa)!=null;}function Bn(_0x40a3dd){for(const _0x56dcf7 of _0x40a3dd['views']['values']())if(_0x56dcf7['query']['_queryParams']['loadsAllData']())return _0x56dcf7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x56b895){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x56b895;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x30866a){this['listenProvider_']=_0x30866a,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x417839,_0x5700dc,_0x50c476,_0xe4f9cf,_0x2c1020){return lu(_0x417839['pendingWriteTree_'],_0x5700dc,_0x50c476,_0xe4f9cf,_0x2c1020),_0x2c1020?_t(_0x417839,new Be(es(),_0x5700dc,_0x50c476)):[];}function ju(_0x3e6491,_0x6f1ed5,_0x448089,_0x424835){hu(_0x3e6491['pendingWriteTree_'],_0x6f1ed5,_0x448089,_0x424835);const _0x593145=b['fromObject'](_0x448089);return _t(_0x3e6491,new ot(es(),_0x6f1ed5,_0x593145));}function _e(_0x449f71,_0x258522,_0x349cbb=!0x1){const _0x4862a6=uu(_0x449f71['pendingWriteTree_'],_0x258522);if(du(_0x449f71['pendingWriteTree_'],_0x258522)){let _0x556830=new b(null);return _0x4862a6['snap']!=null?_0x556830=_0x556830['set'](w(),!0x0):x(_0x4862a6['children'],_0x2cfa7a=>{_0x556830=_0x556830['set'](new C(_0x2cfa7a),!0x0);}),_t(_0x449f71,new In(_0x4862a6['path'],_0x556830,_0x349cbb));}else return[];}function Yt(_0x4ccdf7,_0x30cd09,_0x4ca5ba){return _t(_0x4ccdf7,new Be(ts(),_0x30cd09,_0x4ca5ba));}function Ku(_0x1d4527,_0x16f1c8,_0x53289c){const _0x452ebb=b['fromObject'](_0x53289c);return _t(_0x1d4527,new ot(ts(),_0x16f1c8,_0x452ebb));}function Yu(_0x573f02,_0x5226f3){return _t(_0x573f02,new Ut(ts(),_0x5226f3));}function Qu(_0x13464c,_0x2de8e7,_0x488658){const _0x12d2bf=cs(_0x13464c,_0x488658);if(_0x12d2bf){const _0x2233c8=ls(_0x12d2bf),_0x3bf767=_0x2233c8['path'],_0x227e81=_0x2233c8['queryId'],_0x52184e=F(_0x3bf767,_0x2de8e7),_0x1e703d=new Ut(ns(_0x227e81),_0x52184e);return hs(_0x13464c,_0x3bf767,_0x1e703d);}else return[];}function An(_0x33f8b0,_0x2a8649,_0x30f7fa,_0x593ba0,_0x3ffec5=!0x1){const _0x56c983=_0x2a8649['_path'],_0x2d39cd=_0x33f8b0['syncPointTree_']['get'](_0x56c983);let _0x21ccaa=[];if(_0x2d39cd&&(_0x2a8649['_queryIdentifier']==='default'||Qo(_0x2d39cd,_0x2a8649))){const _0x52778f=$u(_0x2d39cd,_0x2a8649,_0x30f7fa,_0x593ba0);Vu(_0x2d39cd)&&(_0x33f8b0['syncPointTree_']=_0x33f8b0['syncPointTree_']['remove'](_0x56c983));const _0x36b5e8=_0x52778f['removed'];if(_0x21ccaa=_0x52778f['events'],!_0x3ffec5){const _0x21c4f2=_0x36b5e8['findIndex'](_0x2122d1=>_0x2122d1['_queryParams']['loadsAllData']())!==-0x1,_0x5a7ae8=_0x33f8b0['syncPointTree_']['findOnPath'](_0x56c983,(_0x2ae346,_0x5d05ad)=>Se(_0x5d05ad));if(_0x21c4f2&&!_0x5a7ae8){const _0x1cd55c=_0x33f8b0['syncPointTree_']['subtree'](_0x56c983);if(!_0x1cd55c['isEmpty']()){const _0x334f6e=Zu(_0x1cd55c);for(let _0x41d9fb=0x0;_0x41d9fb<_0x334f6e['length'];++_0x41d9fb){const _0x292f8d=_0x334f6e[_0x41d9fb],_0x45c54f=_0x292f8d['query'],_0x2d5b18=ea(_0x33f8b0,_0x292f8d);_0x33f8b0['listenProvider_']['startListening'](kt(_0x45c54f),Wt(_0x33f8b0,_0x45c54f),_0x2d5b18['hashFn'],_0x2d5b18['onComplete']);}}}!_0x5a7ae8&&_0x36b5e8['length']>0x0&&!_0x593ba0&&(_0x21c4f2?_0x33f8b0['listenProvider_']['stopListening'](kt(_0x2a8649),null):_0x36b5e8['forEach'](_0x26b464=>{const _0x53932a=_0x33f8b0['queryToTagMap']['get'](Hn(_0x26b464));_0x33f8b0['listenProvider_']['stopListening'](kt(_0x26b464),_0x53932a);}));}ed(_0x33f8b0,_0x36b5e8);}return _0x21ccaa;}function Jo(_0x46e819,_0x246afa,_0x299a46,_0x6a5a38){const _0x23b6a6=cs(_0x46e819,_0x6a5a38);if(_0x23b6a6!=null){const _0x1092c2=ls(_0x23b6a6),_0x595d81=_0x1092c2['path'],_0x86cb0e=_0x1092c2['queryId'],_0x259fa4=F(_0x595d81,_0x246afa),_0x1777cd=new Be(ns(_0x86cb0e),_0x259fa4,_0x299a46);return hs(_0x46e819,_0x595d81,_0x1777cd);}else return[];}function Ju(_0x4f2c92,_0x1123eb,_0x59cf1b,_0xfc94ea){const _0x2556f6=cs(_0x4f2c92,_0xfc94ea);if(_0x2556f6){const _0x23d41f=ls(_0x2556f6),_0x448d4c=_0x23d41f['path'],_0x498750=_0x23d41f['queryId'],_0x5bbd03=F(_0x448d4c,_0x1123eb),_0x4cda56=b['fromObject'](_0x59cf1b),_0x432b59=new ot(ns(_0x498750),_0x5bbd03,_0x4cda56);return hs(_0x4f2c92,_0x448d4c,_0x432b59);}else return[];}function Ni(_0x364d9d,_0xb48d38,_0x555518,_0x7133cc=!0x1){const _0x465a1f=_0xb48d38['_path'];let _0x2435ae=null,_0xd07f26=!0x1;_0x364d9d['syncPointTree_']['foreachOnPath'](_0x465a1f,(_0x15084c,_0x363098)=>{const _0x1b3854=F(_0x15084c,_0x465a1f);_0x2435ae=_0x2435ae||Ie(_0x363098,_0x1b3854),_0xd07f26=_0xd07f26||Se(_0x363098);});let _0x2fcf0a=_0x364d9d['syncPointTree_']['get'](_0x465a1f);_0x2fcf0a?(_0xd07f26=_0xd07f26||Se(_0x2fcf0a),_0x2435ae=_0x2435ae||Ie(_0x2fcf0a,w())):(_0x2fcf0a=new zo(),_0x364d9d['syncPointTree_']=_0x364d9d['syncPointTree_']['set'](_0x465a1f,_0x2fcf0a));let _0xd69659;_0x2435ae!=null?_0xd69659=!0x0:(_0xd69659=!0x1,_0x2435ae=g['EMPTY_NODE'],_0x364d9d['syncPointTree_']['subtree'](_0x465a1f)['foreachChild']((_0x3d78e3,_0xf74064)=>{const _0x5f0b56=Ie(_0xf74064,w());_0x5f0b56&&(_0x2435ae=_0x2435ae['updateImmediateChild'](_0x3d78e3,_0x5f0b56));}));const _0x26482c=Qo(_0x2fcf0a,_0xb48d38);if(!_0x26482c&&!_0xb48d38['_queryParams']['loadsAllData']()){const _0x42402e=Hn(_0xb48d38);f(!_0x364d9d['queryToTagMap']['has'](_0x42402e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x946acb=td();_0x364d9d['queryToTagMap']['set'](_0x42402e,_0x946acb),_0x364d9d['tagToQueryMap']['set'](_0x946acb,_0x42402e);}const _0x2dc70a=Wn(_0x364d9d['pendingWriteTree_'],_0x465a1f);let _0x472b06=Hu(_0x2fcf0a,_0xb48d38,_0x555518,_0x2dc70a,_0x2435ae,_0xd69659);if(!_0x26482c&&!_0xd07f26&&!_0x7133cc){const _0x44c83c=Yo(_0x2fcf0a,_0xb48d38);_0x472b06=_0x472b06['concat'](nd(_0x364d9d,_0xb48d38,_0x44c83c));}return _0x472b06;}function Vn(_0x25f0a8,_0x5a1f71,_0x4945b3){const _0x1ecb19=_0x25f0a8['pendingWriteTree_'],_0x4771c9=_0x25f0a8['syncPointTree_']['findOnPath'](_0x5a1f71,(_0x28d702,_0xc6b7a0)=>{const _0x111416=F(_0x28d702,_0x5a1f71),_0x27850c=Ie(_0xc6b7a0,_0x111416);if(_0x27850c)return _0x27850c;});return Bo(_0x1ecb19,_0x5a1f71,_0x4771c9,_0x4945b3,!0x0);}function Xu(_0x5740d7,_0x1b85d8){const _0x39ba3a=_0x1b85d8['_path'];let _0x4fb158=null;_0x5740d7['syncPointTree_']['foreachOnPath'](_0x39ba3a,(_0x129b92,_0x20726c)=>{const _0x18d362=F(_0x129b92,_0x39ba3a);_0x4fb158=_0x4fb158||Ie(_0x20726c,_0x18d362);});let _0x598b0d=_0x5740d7['syncPointTree_']['get'](_0x39ba3a);_0x598b0d?_0x4fb158=_0x4fb158||Ie(_0x598b0d,w()):(_0x598b0d=new zo(),_0x5740d7['syncPointTree_']=_0x5740d7['syncPointTree_']['set'](_0x39ba3a,_0x598b0d));const _0x2cccfe=_0x4fb158!=null,_0x48a2ed=_0x2cccfe?new Te(_0x4fb158,!0x0,!0x1):null,_0x282b11=Wn(_0x5740d7['pendingWriteTree_'],_0x1b85d8['_path']),_0x176f5c=jo(_0x598b0d,_0x1b85d8,_0x282b11,_0x2cccfe?_0x48a2ed['getNode']():g['EMPTY_NODE'],_0x2cccfe);return Lu(_0x176f5c);}function _t(_0x276c1b,_0x4c4043){return Xo(_0x4c4043,_0x276c1b['syncPointTree_'],null,Wn(_0x276c1b['pendingWriteTree_'],w()));}function Xo(_0x3f6b12,_0x45519f,_0x1cd51c,_0x3e7e3d){if(v(_0x3f6b12['path']))return Zo(_0x3f6b12,_0x45519f,_0x1cd51c,_0x3e7e3d);{const _0xcef033=_0x45519f['get'](w());_0x1cd51c==null&&_0xcef033!=null&&(_0x1cd51c=Ie(_0xcef033,w()));let _0x1cf024=[];const _0x3e232c=y(_0x3f6b12['path']),_0x144a7c=_0x3f6b12['operationForChild'](_0x3e232c),_0xc758e8=_0x45519f['children']['get'](_0x3e232c);if(_0xc758e8&&_0x144a7c){const _0x1092ab=_0x1cd51c?_0x1cd51c['getImmediateChild'](_0x3e232c):null,_0x473c43=Vo(_0x3e7e3d,_0x3e232c);_0x1cf024=_0x1cf024['concat'](Xo(_0x144a7c,_0xc758e8,_0x1092ab,_0x473c43));}return _0xcef033&&(_0x1cf024=_0x1cf024['concat'](os(_0xcef033,_0x3f6b12,_0x3e7e3d,_0x1cd51c))),_0x1cf024;}}function Zo(_0x3e26f1,_0x3aa3dc,_0x4e6934,_0x397573){const _0x599aca=_0x3aa3dc['get'](w());_0x4e6934==null&&_0x599aca!=null&&(_0x4e6934=Ie(_0x599aca,w()));let _0x487048=[];return _0x3aa3dc['children']['inorderTraversal']((_0x331e38,_0x3ca0aa)=>{const _0x13e1be=_0x4e6934?_0x4e6934['getImmediateChild'](_0x331e38):null,_0x1f6f55=Vo(_0x397573,_0x331e38),_0x5cbab5=_0x3e26f1['operationForChild'](_0x331e38);_0x5cbab5&&(_0x487048=_0x487048['concat'](Zo(_0x5cbab5,_0x3ca0aa,_0x13e1be,_0x1f6f55)));}),_0x599aca&&(_0x487048=_0x487048['concat'](os(_0x599aca,_0x3e26f1,_0x397573,_0x4e6934))),_0x487048;}function ea(_0x52193f,_0x74829){const _0x1ba1d3=_0x74829['query'],_0x49037d=Wt(_0x52193f,_0x1ba1d3);return{'hashFn':()=>(Mu(_0x74829)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5d8f5b=>{if(_0x5d8f5b==='ok')return _0x49037d?Qu(_0x52193f,_0x1ba1d3['_path'],_0x49037d):Yu(_0x52193f,_0x1ba1d3['_path']);{const _0xdb164c=Kl(_0x5d8f5b,_0x1ba1d3);return An(_0x52193f,_0x1ba1d3,null,_0xdb164c);}}};}function Wt(_0x1f2917,_0x33d0d2){const _0x5a47be=Hn(_0x33d0d2);return _0x1f2917['queryToTagMap']['get'](_0x5a47be);}function Hn(_0x340c0b){return _0x340c0b['_path']['toString']()+'$'+_0x340c0b['_queryIdentifier'];}function cs(_0x16562d,_0x42088b){return _0x16562d['tagToQueryMap']['get'](_0x42088b);}function ls(_0xd611f1){const _0x28de76=_0xd611f1['indexOf']('$');return f(_0x28de76!==-0x1&&_0x28de76<_0xd611f1['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xd611f1['substr'](_0x28de76+0x1),'path':new C(_0xd611f1['substr'](0x0,_0x28de76))};}function hs(_0x3b8b7a,_0x53bb90,_0x3d06bb){const _0xebb9aa=_0x3b8b7a['syncPointTree_']['get'](_0x53bb90);f(_0xebb9aa,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x54dc07=Wn(_0x3b8b7a['pendingWriteTree_'],_0x53bb90);return os(_0xebb9aa,_0x3d06bb,_0x54dc07,null);}function Zu(_0xb0c1a0){return _0xb0c1a0['fold']((_0x36ba5b,_0x117cdb,_0x40aa7b)=>{if(_0x117cdb&&Se(_0x117cdb))return[Bn(_0x117cdb)];{let _0x591209=[];return _0x117cdb&&(_0x591209=Ko(_0x117cdb)),x(_0x40aa7b,(_0x44ab48,_0x2083a0)=>{_0x591209=_0x591209['concat'](_0x2083a0);}),_0x591209;}});}function kt(_0x164cd7){return _0x164cd7['_queryParams']['loadsAllData']()&&!_0x164cd7['_queryParams']['isDefault']()?new(qu())(_0x164cd7['_repo'],_0x164cd7['_path']):_0x164cd7;}function ed(_0x61e97b,_0xa7ed6f){for(let _0x3899d6=0x0;_0x3899d6<_0xa7ed6f['length'];++_0x3899d6){const _0x13aad8=_0xa7ed6f[_0x3899d6];if(!_0x13aad8['_queryParams']['loadsAllData']()){const _0x305d91=Hn(_0x13aad8),_0x13c47c=_0x61e97b['queryToTagMap']['get'](_0x305d91);_0x61e97b['queryToTagMap']['delete'](_0x305d91),_0x61e97b['tagToQueryMap']['delete'](_0x13c47c);}}}function td(){return zu++;}function nd(_0x5bf260,_0x74d5b5,_0x7413b4){const _0x3d1466=_0x74d5b5['_path'],_0x18572c=Wt(_0x5bf260,_0x74d5b5),_0x4555cb=ea(_0x5bf260,_0x7413b4),_0x3ab1d6=_0x5bf260['listenProvider_']['startListening'](kt(_0x74d5b5),_0x18572c,_0x4555cb['hashFn'],_0x4555cb['onComplete']),_0x198d8a=_0x5bf260['syncPointTree_']['subtree'](_0x3d1466);if(_0x18572c)f(!Se(_0x198d8a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x465e3d=_0x198d8a['fold']((_0x461d0b,_0x593eda,_0x5673ee)=>{if(!v(_0x461d0b)&&_0x593eda&&Se(_0x593eda))return[Bn(_0x593eda)['query']];{let _0x25b65e=[];return _0x593eda&&(_0x25b65e=_0x25b65e['concat'](Ko(_0x593eda)['map'](_0x32d383=>_0x32d383['query']))),x(_0x5673ee,(_0x33aee6,_0x2b0d3c)=>{_0x25b65e=_0x25b65e['concat'](_0x2b0d3c);}),_0x25b65e;}});for(let _0x595da1=0x0;_0x595da1<_0x465e3d['length'];++_0x595da1){const _0x5a8c69=_0x465e3d[_0x595da1];_0x5bf260['listenProvider_']['stopListening'](kt(_0x5a8c69),Wt(_0x5bf260,_0x5a8c69));}}return _0x3ab1d6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x307127){this['node_']=_0x307127;}['getImmediateChild'](_0x307b17){const _0x3a27cc=this['node_']['getImmediateChild'](_0x307b17);return new us(_0x3a27cc);}['node'](){return this['node_'];}}class ds{constructor(_0x557e0a,_0x1b5173){this['syncTree_']=_0x557e0a,this['path_']=_0x1b5173;}['getImmediateChild'](_0x54b724){const _0x54f0e2=k(this['path_'],_0x54b724);return new ds(this['syncTree_'],_0x54f0e2);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x272268){return _0x272268=_0x272268||{},_0x272268['timestamp']=_0x272268['timestamp']||new Date()['getTime'](),_0x272268;},_r=function(_0x3325a5,_0x43d0d0,_0x35af25){if(!_0x3325a5||typeof _0x3325a5!='object')return _0x3325a5;if(f('.sv'in _0x3325a5,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x3325a5['.sv']=='string')return sd(_0x3325a5['.sv'],_0x43d0d0,_0x35af25);if(typeof _0x3325a5['.sv']=='object')return rd(_0x3325a5['.sv'],_0x43d0d0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3325a5,null,0x2));},sd=function(_0x12faec,_0x3538e8,_0x21e062){switch(_0x12faec){case'timestamp':return _0x21e062['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x12faec);}},rd=function(_0xdf1ce1,_0x2d7f8f,_0x672e98){_0xdf1ce1['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xdf1ce1,null,0x2));const _0x3a7123=_0xdf1ce1['increment'];typeof _0x3a7123!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3a7123);const _0x43c37d=_0x2d7f8f['node']();if(f(_0x43c37d!==null&&typeof _0x43c37d<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x43c37d['isLeafNode']())return _0x3a7123;const _0x369a3d=_0x43c37d['getValue']();return typeof _0x369a3d!='number'?_0x3a7123:_0x369a3d+_0x3a7123;},ta=function(_0x562f5e,_0x59afd6,_0x37d25c,_0x930fd3){return ps(_0x59afd6,new ds(_0x37d25c,_0x562f5e),_0x930fd3);},fs=function(_0x207a5d,_0xb6f40b,_0x4f1fd4){return ps(_0x207a5d,new us(_0xb6f40b),_0x4f1fd4);};function ps(_0x5c362f,_0x49009f,_0x2c7663){const _0x420c33=_0x5c362f['getPriority']()['val'](),_0x5462db=_r(_0x420c33,_0x49009f['getImmediateChild']('.priority'),_0x2c7663);let _0x3cbb71;if(_0x5c362f['isLeafNode']()){const _0x4c3b50=_0x5c362f,_0x34a1a7=_r(_0x4c3b50['getValue'](),_0x49009f,_0x2c7663);return _0x34a1a7!==_0x4c3b50['getValue']()||_0x5462db!==_0x4c3b50['getPriority']()['val']()?new D(_0x34a1a7,A(_0x5462db)):_0x5c362f;}else{const _0x38f3ab=_0x5c362f;return _0x3cbb71=_0x38f3ab,_0x5462db!==_0x38f3ab['getPriority']()['val']()&&(_0x3cbb71=_0x3cbb71['updatePriority'](new D(_0x5462db))),_0x38f3ab['forEachChild'](R,(_0x51d8f7,_0x51b0cd)=>{const _0x226ce2=ps(_0x51b0cd,_0x49009f['getImmediateChild'](_0x51d8f7),_0x2c7663);_0x226ce2!==_0x51b0cd&&(_0x3cbb71=_0x3cbb71['updateImmediateChild'](_0x51d8f7,_0x226ce2));}),_0x3cbb71;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x407caa='',_0x3e4776=null,_0x30186c={'children':{},'childCount':0x0}){this['name']=_0x407caa,this['parent']=_0x3e4776,this['node']=_0x30186c;}}function $n(_0x619990,_0x4b5396){let _0x1a91da=_0x4b5396 instanceof C?_0x4b5396:new C(_0x4b5396),_0x4139ea=_0x619990,_0x323867=y(_0x1a91da);for(;_0x323867!==null;){const _0x5e255e=Le(_0x4139ea['node']['children'],_0x323867)||{'children':{},'childCount':0x0};_0x4139ea=new _s(_0x323867,_0x4139ea,_0x5e255e),_0x1a91da=S(_0x1a91da),_0x323867=y(_0x1a91da);}return _0x4139ea;}function je(_0x531e8d){return _0x531e8d['node']['value'];}function gs(_0x250cf1,_0x251ac0){_0x250cf1['node']['value']=_0x251ac0,Oi(_0x250cf1);}function na(_0x43bd73){return _0x43bd73['node']['childCount']>0x0;}function od(_0x59b521){return je(_0x59b521)===void 0x0&&!na(_0x59b521);}function Gn(_0x16e7a9,_0x2cad3e){x(_0x16e7a9['node']['children'],(_0x3d5cd9,_0x57f9a5)=>{_0x2cad3e(new _s(_0x3d5cd9,_0x16e7a9,_0x57f9a5));});}function ia(_0x5c625a,_0x4ca87a,_0x1992ec,_0x31df59){_0x1992ec&&_0x4ca87a(_0x5c625a),Gn(_0x5c625a,_0x5f581c=>{ia(_0x5f581c,_0x4ca87a,!0x0);});}function ad(_0x5a2537,_0x27514a,_0x2dc2da){let _0x187084=_0x5a2537['parent'];for(;_0x187084!==null;){if(_0x27514a(_0x187084))return!0x0;_0x187084=_0x187084['parent'];}return!0x1;}function Qt(_0x58daa3){return new C(_0x58daa3['parent']===null?_0x58daa3['name']:Qt(_0x58daa3['parent'])+'/'+_0x58daa3['name']);}function Oi(_0xd9130a){_0xd9130a['parent']!==null&&cd(_0xd9130a['parent'],_0xd9130a['name'],_0xd9130a);}function cd(_0x34e447,_0x2bc103,_0x14bf40){const _0x3b2472=od(_0x14bf40),_0x18a5ae=Q(_0x34e447['node']['children'],_0x2bc103);_0x3b2472&&_0x18a5ae?(delete _0x34e447['node']['children'][_0x2bc103],_0x34e447['node']['childCount']--,Oi(_0x34e447)):!_0x3b2472&&!_0x18a5ae&&(_0x34e447['node']['children'][_0x2bc103]=_0x14bf40['node'],_0x34e447['node']['childCount']++,Oi(_0x34e447));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x9fd647){return typeof _0x9fd647=='string'&&_0x9fd647['length']!==0x0&&!ld['test'](_0x9fd647);},sa=function(_0x2a2a49){return typeof _0x2a2a49=='string'&&_0x2a2a49['length']!==0x0&&!hd['test'](_0x2a2a49);},ud=function(_0xee3375){return _0xee3375&&(_0xee3375=_0xee3375['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xee3375);},Bt=function(_0x3606b8){return _0x3606b8===null||typeof _0x3606b8=='string'||typeof _0x3606b8=='number'&&!xn(_0x3606b8)||_0x3606b8&&typeof _0x3606b8=='object'&&Q(_0x3606b8,'.sv');},He=function(_0x1e0f5c,_0x2ba8c8,_0x1968d6,_0x282f9f){_0x282f9f&&_0x2ba8c8===void 0x0||Jt(it(_0x1e0f5c,'value'),_0x2ba8c8,_0x1968d6);},Jt=function(_0x568384,_0x2e8c28,_0x595d5f){const _0x2ffd2a=_0x595d5f instanceof C?new Ah(_0x595d5f,_0x568384):_0x595d5f;if(_0x2e8c28===void 0x0)throw new Error(_0x568384+'contains\x20undefined\x20'+Oe(_0x2ffd2a));if(typeof _0x2e8c28=='function')throw new Error(_0x568384+'contains\x20a\x20function\x20'+Oe(_0x2ffd2a)+'\x20with\x20contents\x20=\x20'+_0x2e8c28['toString']());if(xn(_0x2e8c28))throw new Error(_0x568384+'contains\x20'+_0x2e8c28['toString']()+'\x20'+Oe(_0x2ffd2a));if(typeof _0x2e8c28=='string'&&_0x2e8c28['length']>ui/0x3&&Ln(_0x2e8c28)>ui)throw new Error(_0x568384+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2ffd2a)+'\x20(\x27'+_0x2e8c28['substring'](0x0,0x32)+'...\x27)');if(_0x2e8c28&&typeof _0x2e8c28=='object'){let _0x24da86=!0x1,_0x5c9705=!0x1;if(x(_0x2e8c28,(_0x192f35,_0x33b4fc)=>{if(_0x192f35==='.value')_0x24da86=!0x0;else{if(_0x192f35!=='.priority'&&_0x192f35!=='.sv'&&(_0x5c9705=!0x0,!ms(_0x192f35)))throw new Error(_0x568384+'\x20contains\x20an\x20invalid\x20key\x20('+_0x192f35+')\x20'+Oe(_0x2ffd2a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2ffd2a,_0x192f35),Jt(_0x568384,_0x33b4fc,_0x2ffd2a),Ph(_0x2ffd2a);}),_0x24da86&&_0x5c9705)throw new Error(_0x568384+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2ffd2a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x162641,_0x515de8){let _0x242894,_0x2dc14e;for(_0x242894=0x0;_0x242894<_0x515de8['length'];_0x242894++){_0x2dc14e=_0x515de8[_0x242894];const _0x23456c=Mt(_0x2dc14e);for(let _0x2eb761=0x0;_0x2eb761<_0x23456c['length'];_0x2eb761++)if(!(_0x23456c[_0x2eb761]==='.priority'&&_0x2eb761===_0x23456c['length']-0x1)){if(!ms(_0x23456c[_0x2eb761]))throw new Error(_0x162641+'contains\x20an\x20invalid\x20key\x20('+_0x23456c[_0x2eb761]+')\x20in\x20path\x20'+_0x2dc14e['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x515de8['sort'](Rh);let _0x23a7ba=null;for(_0x242894=0x0;_0x242894<_0x515de8['length'];_0x242894++){if(_0x2dc14e=_0x515de8[_0x242894],_0x23a7ba!==null&&G(_0x23a7ba,_0x2dc14e))throw new Error(_0x162641+'contains\x20a\x20path\x20'+_0x23a7ba['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2dc14e['toString']());_0x23a7ba=_0x2dc14e;}},ra=function(_0x30b006,_0x10d33c,_0x1a0a9c,_0x3b66c9){const _0x368c69=it(_0x30b006,'values');if(!(_0x10d33c&&typeof _0x10d33c=='object')||Array['isArray'](_0x10d33c))throw new Error(_0x368c69+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5679b0=[];x(_0x10d33c,(_0xb8bcd3,_0x2a3074)=>{const _0x585f15=new C(_0xb8bcd3);if(Jt(_0x368c69,_0x2a3074,k(_0x1a0a9c,_0x585f15)),ji(_0x585f15)==='.priority'&&!Bt(_0x2a3074))throw new Error(_0x368c69+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x585f15['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5679b0['push'](_0x585f15);}),dd(_0x368c69,_0x5679b0);},fd=function(_0x3eb5b9,_0x58139e,_0x267c35){if(xn(_0x58139e))throw new Error(it(_0x3eb5b9,'priority')+'is\x20'+_0x58139e['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x58139e))throw new Error(it(_0x3eb5b9,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x71500a,_0x4e7ef5,_0x1299b2,_0x508e49){if(!sa(_0x1299b2))throw new Error(it(_0x71500a,_0x4e7ef5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1299b2+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x16535f,_0x4b3daf,_0x5e0615,_0xce5f66){_0x5e0615&&(_0x5e0615=_0x5e0615['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x16535f,_0x4b3daf,_0x5e0615);},Me=function(_0x4bb8db,_0x399547){if(y(_0x399547)==='.info')throw new Error(_0x4bb8db+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x35ee81,_0x3eff95){const _0x16a26e=_0x3eff95['path']['toString']();if(typeof _0x3eff95['repoInfo']['host']!='string'||_0x3eff95['repoInfo']['host']['length']===0x0||!ms(_0x3eff95['repoInfo']['namespace'])&&_0x3eff95['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x16a26e['length']!==0x0&&!ud(_0x16a26e))throw new Error(it(_0x35ee81,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x1f7709,_0x165b78){let _0x2dc392=null;for(let _0x531a49=0x0;_0x531a49<_0x165b78['length'];_0x531a49++){const _0x2ccce3=_0x165b78[_0x531a49],_0x4cc913=_0x2ccce3['getPath']();_0x2dc392!==null&&!Ki(_0x4cc913,_0x2dc392['path'])&&(_0x1f7709['eventLists_']['push'](_0x2dc392),_0x2dc392=null),_0x2dc392===null&&(_0x2dc392={'events':[],'path':_0x4cc913}),_0x2dc392['events']['push'](_0x2ccce3);}_0x2dc392&&_0x1f7709['eventLists_']['push'](_0x2dc392);}function oa(_0xbda367,_0x1c8aee,_0x43e31d){qn(_0xbda367,_0x43e31d),aa(_0xbda367,_0x2293b8=>Ki(_0x2293b8,_0x1c8aee));}function V(_0x2b5228,_0x3e3a40,_0x3e7d9f){qn(_0x2b5228,_0x3e7d9f),aa(_0x2b5228,_0x1a0b7e=>G(_0x1a0b7e,_0x3e3a40)||G(_0x3e3a40,_0x1a0b7e));}function aa(_0x41c35f,_0x2385f8){_0x41c35f['recursionDepth_']++;let _0x3f792e=!0x0;for(let _0x2cb5be=0x0;_0x2cb5be<_0x41c35f['eventLists_']['length'];_0x2cb5be++){const _0x1efc15=_0x41c35f['eventLists_'][_0x2cb5be];if(_0x1efc15){const _0x4d3176=_0x1efc15['path'];_0x2385f8(_0x4d3176)?(md(_0x41c35f['eventLists_'][_0x2cb5be]),_0x41c35f['eventLists_'][_0x2cb5be]=null):_0x3f792e=!0x1;}}_0x3f792e&&(_0x41c35f['eventLists_']=[]),_0x41c35f['recursionDepth_']--;}function md(_0xf60f25){for(let _0x321c77=0x0;_0x321c77<_0xf60f25['events']['length'];_0x321c77++){const _0x2b78d6=_0xf60f25['events'][_0x321c77];if(_0x2b78d6!==null){_0xf60f25['events'][_0x321c77]=null;const _0x312ee9=_0x2b78d6['getEventRunner']();St&&L('event:\x20'+_0x2b78d6['toString']()),ft(_0x312ee9);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x25a648,_0xe21a50,_0x391afa,_0x4f805b){this['repoInfo_']=_0x25a648,this['forceRestClient_']=_0xe21a50,this['authTokenProvider_']=_0x391afa,this['appCheckProvider_']=_0x4f805b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x50562f,_0x5a7eb5,_0xe720ef){if(_0x50562f['stats_']=qi(_0x50562f['repoInfo_']),_0x50562f['forceRestClient_']||Xl())_0x50562f['server_']=new vn(_0x50562f['repoInfo_'],(_0x42842b,_0x382810,_0x5b3022,_0x514497)=>{gr(_0x50562f,_0x42842b,_0x382810,_0x5b3022,_0x514497);},_0x50562f['authTokenProvider_'],_0x50562f['appCheckProvider_']),setTimeout(()=>mr(_0x50562f,!0x0),0x0);else{if(typeof _0xe720ef<'u'&&_0xe720ef!==null){if(typeof _0xe720ef!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0xe720ef);}catch(_0x32ff37){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x32ff37);}}_0x50562f['persistentConnection_']=new se(_0x50562f['repoInfo_'],_0x5a7eb5,(_0x282ded,_0x5822b8,_0x3915d2,_0x280481)=>{gr(_0x50562f,_0x282ded,_0x5822b8,_0x3915d2,_0x280481);},_0x3ce26b=>{mr(_0x50562f,_0x3ce26b);},_0x4d681a=>{Id(_0x50562f,_0x4d681a);},_0x50562f['authTokenProvider_'],_0x50562f['appCheckProvider_'],_0xe720ef),_0x50562f['server_']=_0x50562f['persistentConnection_'];}_0x50562f['authTokenProvider_']['addTokenChangeListener'](_0x5a6320=>{_0x50562f['server_']['refreshAuthToken'](_0x5a6320);}),_0x50562f['appCheckProvider_']['addTokenChangeListener'](_0x558154=>{_0x50562f['server_']['refreshAppCheckToken'](_0x558154['token']);}),_0x50562f['statsReporter_']=ih(_0x50562f['repoInfo_'],()=>new iu(_0x50562f['stats_'],_0x50562f['server_'])),_0x50562f['infoData_']=new Xh(),_0x50562f['infoSyncTree_']=new pr({'startListening':(_0x49e917,_0x2c7105,_0x4679a7,_0x6184ac)=>{let _0x51eca5=[];const _0x19d3e1=_0x50562f['infoData_']['getNode'](_0x49e917['_path']);return _0x19d3e1['isEmpty']()||(_0x51eca5=Yt(_0x50562f['infoSyncTree_'],_0x49e917['_path'],_0x19d3e1),setTimeout(()=>{_0x6184ac('ok');},0x0)),_0x51eca5;},'stopListening':()=>{}}),vs(_0x50562f,'connected',!0x1),_0x50562f['serverSyncTree_']=new pr({'startListening':(_0x4999ad,_0x1e83f6,_0x4dcc76,_0x422319)=>(_0x50562f['server_']['listen'](_0x4999ad,_0x4dcc76,_0x1e83f6,(_0x527472,_0x477627)=>{const _0x15b9d1=_0x422319(_0x527472,_0x477627);V(_0x50562f['eventQueue_'],_0x4999ad['_path'],_0x15b9d1);}),[]),'stopListening':(_0x109f7d,_0x122cd6)=>{_0x50562f['server_']['unlisten'](_0x109f7d,_0x122cd6);}});}function la(_0x5daeb1){const _0x57056c=_0x5daeb1['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x57056c;}function Xt(_0x18877b){return id({'timestamp':la(_0x18877b)});}function gr(_0xe3aef8,_0x1f19fd,_0x378c81,_0x1e52d0,_0x3051a8){_0xe3aef8['dataUpdateCount']++;const _0xa2cf92=new C(_0x1f19fd);_0x378c81=_0xe3aef8['interceptServerDataCallback_']?_0xe3aef8['interceptServerDataCallback_'](_0x1f19fd,_0x378c81):_0x378c81;let _0x49daed=[];if(_0x3051a8){if(_0x1e52d0){const _0x709c72=_n(_0x378c81,_0x315b45=>A(_0x315b45));_0x49daed=Ju(_0xe3aef8['serverSyncTree_'],_0xa2cf92,_0x709c72,_0x3051a8);}else{const _0x14755d=A(_0x378c81);_0x49daed=Jo(_0xe3aef8['serverSyncTree_'],_0xa2cf92,_0x14755d,_0x3051a8);}}else{if(_0x1e52d0){const _0x27bf87=_n(_0x378c81,_0x591118=>A(_0x591118));_0x49daed=Ku(_0xe3aef8['serverSyncTree_'],_0xa2cf92,_0x27bf87);}else{const _0x3152a5=A(_0x378c81);_0x49daed=Yt(_0xe3aef8['serverSyncTree_'],_0xa2cf92,_0x3152a5);}}let _0x321702=_0xa2cf92;_0x49daed['length']>0x0&&(_0x321702=ct(_0xe3aef8,_0xa2cf92)),V(_0xe3aef8['eventQueue_'],_0x321702,_0x49daed);}function mr(_0x451426,_0x4c6a3c){vs(_0x451426,'connected',_0x4c6a3c),_0x4c6a3c===!0x1&&Sd(_0x451426);}function Id(_0x32e8a5,_0x505bf2){x(_0x505bf2,(_0x2f3628,_0x2f6d25)=>{vs(_0x32e8a5,_0x2f3628,_0x2f6d25);});}function vs(_0x13c3bc,_0x4af31f,_0x3cbc1f){const _0x234112=new C('/.info/'+_0x4af31f),_0x4a539b=A(_0x3cbc1f);_0x13c3bc['infoData_']['updateSnapshot'](_0x234112,_0x4a539b);const _0x5cf3df=Yt(_0x13c3bc['infoSyncTree_'],_0x234112,_0x4a539b);V(_0x13c3bc['eventQueue_'],_0x234112,_0x5cf3df);}function zn(_0x5ddf48){return _0x5ddf48['nextWriteId_']++;}function wd(_0x2150d5,_0x3fa644,_0x935d57){const _0x55cd89=Xu(_0x2150d5['serverSyncTree_'],_0x3fa644);return _0x55cd89!=null?Promise['resolve'](_0x55cd89):_0x2150d5['server_']['get'](_0x3fa644)['then'](_0x42211b=>{const _0x194cf5=A(_0x42211b)['withIndex'](_0x3fa644['_queryParams']['getIndex']());Ni(_0x2150d5['serverSyncTree_'],_0x3fa644,_0x935d57,!0x0);let _0xb04ebd;if(_0x3fa644['_queryParams']['loadsAllData']())_0xb04ebd=Yt(_0x2150d5['serverSyncTree_'],_0x3fa644['_path'],_0x194cf5);else{const _0x440860=Wt(_0x2150d5['serverSyncTree_'],_0x3fa644);_0xb04ebd=Jo(_0x2150d5['serverSyncTree_'],_0x3fa644['_path'],_0x194cf5,_0x440860);}return V(_0x2150d5['eventQueue_'],_0x3fa644['_path'],_0xb04ebd),An(_0x2150d5['serverSyncTree_'],_0x3fa644,_0x935d57,null,!0x0),_0x194cf5;},_0x473a9f=>(gt(_0x2150d5,'get\x20for\x20query\x20'+O(_0x3fa644)+'\x20failed:\x20'+_0x473a9f),Promise['reject'](new Error(_0x473a9f))));}function Cd(_0x5ea90e,_0x75923d,_0x99e884,_0x18ad9b,_0x24f68e){gt(_0x5ea90e,'set',{'path':_0x75923d['toString'](),'value':_0x99e884,'priority':_0x18ad9b});const _0x3918fb=Xt(_0x5ea90e),_0x208c8a=A(_0x99e884,_0x18ad9b),_0x189871=Vn(_0x5ea90e['serverSyncTree_'],_0x75923d),_0x437734=fs(_0x208c8a,_0x189871,_0x3918fb),_0x38642c=zn(_0x5ea90e),_0x58c346=as(_0x5ea90e['serverSyncTree_'],_0x75923d,_0x437734,_0x38642c,!0x0);qn(_0x5ea90e['eventQueue_'],_0x58c346),_0x5ea90e['server_']['put'](_0x75923d['toString'](),_0x208c8a['val'](!0x0),(_0x580c8f,_0x418a2)=>{const _0x233439=_0x580c8f==='ok';_0x233439||U('set\x20at\x20'+_0x75923d+'\x20failed:\x20'+_0x580c8f);const _0x16f34f=_e(_0x5ea90e['serverSyncTree_'],_0x38642c,!_0x233439);V(_0x5ea90e['eventQueue_'],_0x75923d,_0x16f34f),be(_0x5ea90e,_0x24f68e,_0x580c8f,_0x418a2);});const _0x1e0d69=Is(_0x5ea90e,_0x75923d);ct(_0x5ea90e,_0x1e0d69),V(_0x5ea90e['eventQueue_'],_0x1e0d69,[]);}function Td(_0x2846eb,_0x5223de,_0x1efe13,_0x4538b4){gt(_0x2846eb,'update',{'path':_0x5223de['toString'](),'value':_0x1efe13});let _0x52f895=!0x0;const _0x46ff89=Xt(_0x2846eb),_0x50bbc7={};if(x(_0x1efe13,(_0x5dd2c8,_0x41823e)=>{_0x52f895=!0x1,_0x50bbc7[_0x5dd2c8]=ta(k(_0x5223de,_0x5dd2c8),A(_0x41823e),_0x2846eb['serverSyncTree_'],_0x46ff89);}),_0x52f895)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2846eb,_0x4538b4,'ok',void 0x0);else{const _0x59cd1b=zn(_0x2846eb),_0x2318cd=ju(_0x2846eb['serverSyncTree_'],_0x5223de,_0x50bbc7,_0x59cd1b);qn(_0x2846eb['eventQueue_'],_0x2318cd),_0x2846eb['server_']['merge'](_0x5223de['toString'](),_0x1efe13,(_0xd3f60f,_0x358dd8)=>{const _0x445bb5=_0xd3f60f==='ok';_0x445bb5||U('update\x20at\x20'+_0x5223de+'\x20failed:\x20'+_0xd3f60f);const _0x3b5382=_e(_0x2846eb['serverSyncTree_'],_0x59cd1b,!_0x445bb5),_0x1d86e1=_0x3b5382['length']>0x0?ct(_0x2846eb,_0x5223de):_0x5223de;V(_0x2846eb['eventQueue_'],_0x1d86e1,_0x3b5382),be(_0x2846eb,_0x4538b4,_0xd3f60f,_0x358dd8);}),x(_0x1efe13,_0x2a13fd=>{const _0x1b58f4=Is(_0x2846eb,k(_0x5223de,_0x2a13fd));ct(_0x2846eb,_0x1b58f4);}),V(_0x2846eb['eventQueue_'],_0x5223de,[]);}}function Sd(_0x5e0769){gt(_0x5e0769,'onDisconnectEvents');const _0x23d986=Xt(_0x5e0769),_0x30c829=En();Si(_0x5e0769['onDisconnect_'],w(),(_0x272066,_0x154494)=>{const _0x57db95=ta(_0x272066,_0x154494,_0x5e0769['serverSyncTree_'],_0x23d986);pt(_0x30c829,_0x272066,_0x57db95);});let _0x8a8840=[];Si(_0x30c829,w(),(_0xb47531,_0xacfcbb)=>{_0x8a8840=_0x8a8840['concat'](Yt(_0x5e0769['serverSyncTree_'],_0xb47531,_0xacfcbb));const _0x5a236d=Is(_0x5e0769,_0xb47531);ct(_0x5e0769,_0x5a236d);}),_0x5e0769['onDisconnect_']=En(),V(_0x5e0769['eventQueue_'],w(),_0x8a8840);}function bd(_0x284f30,_0x1f5535,_0x559371){_0x284f30['server_']['onDisconnectCancel'](_0x1f5535['toString'](),(_0x32c36f,_0x2587fa)=>{_0x32c36f==='ok'&&Ti(_0x284f30['onDisconnect_'],_0x1f5535),be(_0x284f30,_0x559371,_0x32c36f,_0x2587fa);});}function yr(_0x1cedc5,_0x142e14,_0x107861,_0x42b531){const _0x4cc2a4=A(_0x107861);_0x1cedc5['server_']['onDisconnectPut'](_0x142e14['toString'](),_0x4cc2a4['val'](!0x0),(_0x30ef71,_0x4eb950)=>{_0x30ef71==='ok'&&pt(_0x1cedc5['onDisconnect_'],_0x142e14,_0x4cc2a4),be(_0x1cedc5,_0x42b531,_0x30ef71,_0x4eb950);});}function Rd(_0x539502,_0x44d413,_0x1a925d,_0x5c4cfb,_0x24d7f9){const _0x22ab90=A(_0x1a925d,_0x5c4cfb);_0x539502['server_']['onDisconnectPut'](_0x44d413['toString'](),_0x22ab90['val'](!0x0),(_0x18990f,_0x4f1930)=>{_0x18990f==='ok'&&pt(_0x539502['onDisconnect_'],_0x44d413,_0x22ab90),be(_0x539502,_0x24d7f9,_0x18990f,_0x4f1930);});}function Ad(_0x2cfd8e,_0x4eccf5,_0x151536,_0x147e61){if(pn(_0x151536)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2cfd8e,_0x147e61,'ok',void 0x0);return;}_0x2cfd8e['server_']['onDisconnectMerge'](_0x4eccf5['toString'](),_0x151536,(_0x12b258,_0x404acb)=>{_0x12b258==='ok'&&x(_0x151536,(_0x42829e,_0x2f3772)=>{const _0x35a445=A(_0x2f3772);pt(_0x2cfd8e['onDisconnect_'],k(_0x4eccf5,_0x42829e),_0x35a445);}),be(_0x2cfd8e,_0x147e61,_0x12b258,_0x404acb);});}function kd(_0x59e586,_0x5cc6dc,_0x180360){let _0x26e223;y(_0x5cc6dc['_path'])==='.info'?_0x26e223=Ni(_0x59e586['infoSyncTree_'],_0x5cc6dc,_0x180360):_0x26e223=Ni(_0x59e586['serverSyncTree_'],_0x5cc6dc,_0x180360),oa(_0x59e586['eventQueue_'],_0x5cc6dc['_path'],_0x26e223);}function Pd(_0x3aa629,_0x97a7,_0xefd9ea){let _0x33e9d4;y(_0x97a7['_path'])==='.info'?_0x33e9d4=An(_0x3aa629['infoSyncTree_'],_0x97a7,_0xefd9ea):_0x33e9d4=An(_0x3aa629['serverSyncTree_'],_0x97a7,_0xefd9ea),oa(_0x3aa629['eventQueue_'],_0x97a7['_path'],_0x33e9d4);}function ha(_0x23a000){_0x23a000['persistentConnection_']&&_0x23a000['persistentConnection_']['interrupt'](ca);}function Nd(_0x1ec475){_0x1ec475['persistentConnection_']&&_0x1ec475['persistentConnection_']['resume'](ca);}function gt(_0x5b57e6,..._0x4ae1ce){let _0x2f16f7='';_0x5b57e6['persistentConnection_']&&(_0x2f16f7=_0x5b57e6['persistentConnection_']['id']+':'),L(_0x2f16f7,..._0x4ae1ce);}function be(_0xc5f757,_0x2a686d,_0x4ba628,_0x36fbee){_0x2a686d&&ft(()=>{if(_0x4ba628==='ok')_0x2a686d(null);else{const _0x34f575=(_0x4ba628||'error')['toUpperCase']();let _0x58f665=_0x34f575;_0x36fbee&&(_0x58f665+=':\x20'+_0x36fbee);const _0x33a406=new Error(_0x58f665);_0x33a406['code']=_0x34f575,_0x2a686d(_0x33a406);}});}function Od(_0x2a36f2,_0x52f5c3,_0x49d873,_0x366708,_0x37863f,_0xc0057f){gt(_0x2a36f2,'transaction\x20on\x20'+_0x52f5c3);const _0x4f42a4={'path':_0x52f5c3,'update':_0x49d873,'onComplete':_0x366708,'status':null,'order':so(),'applyLocally':_0xc0057f,'retryCount':0x0,'unwatcher':_0x37863f,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5cf41a=Es(_0x2a36f2,_0x52f5c3,void 0x0);_0x4f42a4['currentInputSnapshot']=_0x5cf41a;const _0x4c1533=_0x4f42a4['update'](_0x5cf41a['val']());if(_0x4c1533===void 0x0)_0x4f42a4['unwatcher'](),_0x4f42a4['currentOutputSnapshotRaw']=null,_0x4f42a4['currentOutputSnapshotResolved']=null,_0x4f42a4['onComplete']&&_0x4f42a4['onComplete'](null,!0x1,_0x4f42a4['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c1533,_0x4f42a4['path']),_0x4f42a4['status']=0x0;const _0x56be21=$n(_0x2a36f2['transactionQueueTree_'],_0x52f5c3),_0x5bbc74=je(_0x56be21)||[];_0x5bbc74['push'](_0x4f42a4),gs(_0x56be21,_0x5bbc74);let _0x5685ba;typeof _0x4c1533=='object'&&_0x4c1533!==null&&Q(_0x4c1533,'.priority')?(_0x5685ba=Le(_0x4c1533,'.priority'),f(Bt(_0x5685ba),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5685ba=(Vn(_0x2a36f2['serverSyncTree_'],_0x52f5c3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x145ac0=Xt(_0x2a36f2),_0x8e5b0e=A(_0x4c1533,_0x5685ba),_0x3a64bd=fs(_0x8e5b0e,_0x5cf41a,_0x145ac0);_0x4f42a4['currentOutputSnapshotRaw']=_0x8e5b0e,_0x4f42a4['currentOutputSnapshotResolved']=_0x3a64bd,_0x4f42a4['currentWriteId']=zn(_0x2a36f2);const _0x500986=as(_0x2a36f2['serverSyncTree_'],_0x52f5c3,_0x3a64bd,_0x4f42a4['currentWriteId'],_0x4f42a4['applyLocally']);V(_0x2a36f2['eventQueue_'],_0x52f5c3,_0x500986),jn(_0x2a36f2,_0x2a36f2['transactionQueueTree_']);}}function Es(_0x40de6e,_0x555a47,_0x3381ae){return Vn(_0x40de6e['serverSyncTree_'],_0x555a47,_0x3381ae)||g['EMPTY_NODE'];}function jn(_0x45d1d1,_0x50bb5b=_0x45d1d1['transactionQueueTree_']){if(_0x50bb5b||Kn(_0x45d1d1,_0x50bb5b),je(_0x50bb5b)){const _0x21456e=da(_0x45d1d1,_0x50bb5b);f(_0x21456e['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x21456e['every'](_0x4071a1=>_0x4071a1['status']===0x0)&&Dd(_0x45d1d1,Qt(_0x50bb5b),_0x21456e);}else na(_0x50bb5b)&&Gn(_0x50bb5b,_0x2cb334=>{jn(_0x45d1d1,_0x2cb334);});}function Dd(_0x238e9b,_0x4fd008,_0x899025){const _0x222bc1=_0x899025['map'](_0x459e80=>_0x459e80['currentWriteId']),_0x39ceaa=Es(_0x238e9b,_0x4fd008,_0x222bc1);let _0x399955=_0x39ceaa;const _0x15f32f=_0x39ceaa['hash']();for(let _0x152112=0x0;_0x152112<_0x899025['length'];_0x152112++){const _0x3f06cb=_0x899025[_0x152112];f(_0x3f06cb['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3f06cb['status']=0x1,_0x3f06cb['retryCount']++;const _0xb2ddba=F(_0x4fd008,_0x3f06cb['path']);_0x399955=_0x399955['updateChild'](_0xb2ddba,_0x3f06cb['currentOutputSnapshotRaw']);}const _0x17f7c4=_0x399955['val'](!0x0),_0x140c6f=_0x4fd008;_0x238e9b['server_']['put'](_0x140c6f['toString'](),_0x17f7c4,_0x1cf35b=>{gt(_0x238e9b,'transaction\x20put\x20response',{'path':_0x140c6f['toString'](),'status':_0x1cf35b});let _0x1ff659=[];if(_0x1cf35b==='ok'){const _0x4744dd=[];for(let _0x2ab002=0x0;_0x2ab002<_0x899025['length'];_0x2ab002++)_0x899025[_0x2ab002]['status']=0x2,_0x1ff659=_0x1ff659['concat'](_e(_0x238e9b['serverSyncTree_'],_0x899025[_0x2ab002]['currentWriteId'])),_0x899025[_0x2ab002]['onComplete']&&_0x4744dd['push'](()=>_0x899025[_0x2ab002]['onComplete'](null,!0x0,_0x899025[_0x2ab002]['currentOutputSnapshotResolved'])),_0x899025[_0x2ab002]['unwatcher']();Kn(_0x238e9b,$n(_0x238e9b['transactionQueueTree_'],_0x4fd008)),jn(_0x238e9b,_0x238e9b['transactionQueueTree_']),V(_0x238e9b['eventQueue_'],_0x4fd008,_0x1ff659);for(let _0x590474=0x0;_0x590474<_0x4744dd['length'];_0x590474++)ft(_0x4744dd[_0x590474]);}else{if(_0x1cf35b==='datastale'){for(let _0x4aaa38=0x0;_0x4aaa38<_0x899025['length'];_0x4aaa38++)_0x899025[_0x4aaa38]['status']===0x3?_0x899025[_0x4aaa38]['status']=0x4:_0x899025[_0x4aaa38]['status']=0x0;}else{U('transaction\x20at\x20'+_0x140c6f['toString']()+'\x20failed:\x20'+_0x1cf35b);for(let _0x162936=0x0;_0x162936<_0x899025['length'];_0x162936++)_0x899025[_0x162936]['status']=0x4,_0x899025[_0x162936]['abortReason']=_0x1cf35b;}ct(_0x238e9b,_0x4fd008);}},_0x15f32f);}function ct(_0x5e67a5,_0x37091a){const _0x5891d1=ua(_0x5e67a5,_0x37091a),_0x4e8333=Qt(_0x5891d1),_0x4bdd5d=da(_0x5e67a5,_0x5891d1);return Md(_0x5e67a5,_0x4bdd5d,_0x4e8333),_0x4e8333;}function Md(_0x2f6c49,_0x17e26c,_0x4a83de){if(_0x17e26c['length']===0x0)return;const _0x188e5d=[];let _0x5128a8=[];const _0x37cd54=_0x17e26c['filter'](_0x717523=>_0x717523['status']===0x0)['map'](_0xad7643=>_0xad7643['currentWriteId']);for(let _0x5a3206=0x0;_0x5a3206<_0x17e26c['length'];_0x5a3206++){const _0x97a5de=_0x17e26c[_0x5a3206],_0x1b6977=F(_0x4a83de,_0x97a5de['path']);let _0x46867b=!0x1,_0x395e98;if(f(_0x1b6977!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x97a5de['status']===0x4)_0x46867b=!0x0,_0x395e98=_0x97a5de['abortReason'],_0x5128a8=_0x5128a8['concat'](_e(_0x2f6c49['serverSyncTree_'],_0x97a5de['currentWriteId'],!0x0));else{if(_0x97a5de['status']===0x0){if(_0x97a5de['retryCount']>=yd)_0x46867b=!0x0,_0x395e98='maxretry',_0x5128a8=_0x5128a8['concat'](_e(_0x2f6c49['serverSyncTree_'],_0x97a5de['currentWriteId'],!0x0));else{const _0x2988d8=Es(_0x2f6c49,_0x97a5de['path'],_0x37cd54);_0x97a5de['currentInputSnapshot']=_0x2988d8;const _0x48a277=_0x17e26c[_0x5a3206]['update'](_0x2988d8['val']());if(_0x48a277!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x48a277,_0x97a5de['path']);let _0x55fa98=A(_0x48a277);typeof _0x48a277=='object'&&_0x48a277!=null&&Q(_0x48a277,'.priority')||(_0x55fa98=_0x55fa98['updatePriority'](_0x2988d8['getPriority']()));const _0xa11cfd=_0x97a5de['currentWriteId'],_0x3edfc4=Xt(_0x2f6c49),_0x4dd126=fs(_0x55fa98,_0x2988d8,_0x3edfc4);_0x97a5de['currentOutputSnapshotRaw']=_0x55fa98,_0x97a5de['currentOutputSnapshotResolved']=_0x4dd126,_0x97a5de['currentWriteId']=zn(_0x2f6c49),_0x37cd54['splice'](_0x37cd54['indexOf'](_0xa11cfd),0x1),_0x5128a8=_0x5128a8['concat'](as(_0x2f6c49['serverSyncTree_'],_0x97a5de['path'],_0x4dd126,_0x97a5de['currentWriteId'],_0x97a5de['applyLocally'])),_0x5128a8=_0x5128a8['concat'](_e(_0x2f6c49['serverSyncTree_'],_0xa11cfd,!0x0));}else _0x46867b=!0x0,_0x395e98='nodata',_0x5128a8=_0x5128a8['concat'](_e(_0x2f6c49['serverSyncTree_'],_0x97a5de['currentWriteId'],!0x0));}}}V(_0x2f6c49['eventQueue_'],_0x4a83de,_0x5128a8),_0x5128a8=[],_0x46867b&&(_0x17e26c[_0x5a3206]['status']=0x2,function(_0xafb3ad){setTimeout(_0xafb3ad,Math['floor'](0x0));}(_0x17e26c[_0x5a3206]['unwatcher']),_0x17e26c[_0x5a3206]['onComplete']&&(_0x395e98==='nodata'?_0x188e5d['push'](()=>_0x17e26c[_0x5a3206]['onComplete'](null,!0x1,_0x17e26c[_0x5a3206]['currentInputSnapshot'])):_0x188e5d['push'](()=>_0x17e26c[_0x5a3206]['onComplete'](new Error(_0x395e98),!0x1,null))));}Kn(_0x2f6c49,_0x2f6c49['transactionQueueTree_']);for(let _0x45366d=0x0;_0x45366d<_0x188e5d['length'];_0x45366d++)ft(_0x188e5d[_0x45366d]);jn(_0x2f6c49,_0x2f6c49['transactionQueueTree_']);}function ua(_0x2794f4,_0x45e17e){let _0x19a951,_0x465e07=_0x2794f4['transactionQueueTree_'];for(_0x19a951=y(_0x45e17e);_0x19a951!==null&&je(_0x465e07)===void 0x0;)_0x465e07=$n(_0x465e07,_0x19a951),_0x45e17e=S(_0x45e17e),_0x19a951=y(_0x45e17e);return _0x465e07;}function da(_0x575fcc,_0x3a3f88){const _0x2a17fb=[];return fa(_0x575fcc,_0x3a3f88,_0x2a17fb),_0x2a17fb['sort']((_0x140fcf,_0x51c43e)=>_0x140fcf['order']-_0x51c43e['order']),_0x2a17fb;}function fa(_0x3169e7,_0x4683c1,_0x212c3c){const _0xf19ebb=je(_0x4683c1);if(_0xf19ebb){for(let _0xe1fcc5=0x0;_0xe1fcc5<_0xf19ebb['length'];_0xe1fcc5++)_0x212c3c['push'](_0xf19ebb[_0xe1fcc5]);}Gn(_0x4683c1,_0x20ea3b=>{fa(_0x3169e7,_0x20ea3b,_0x212c3c);});}function Kn(_0x1c0111,_0x5d86c8){const _0xdeebf=je(_0x5d86c8);if(_0xdeebf){let _0x2eb896=0x0;for(let _0x1f82e8=0x0;_0x1f82e8<_0xdeebf['length'];_0x1f82e8++)_0xdeebf[_0x1f82e8]['status']!==0x2&&(_0xdeebf[_0x2eb896]=_0xdeebf[_0x1f82e8],_0x2eb896++);_0xdeebf['length']=_0x2eb896,gs(_0x5d86c8,_0xdeebf['length']>0x0?_0xdeebf:void 0x0);}Gn(_0x5d86c8,_0x289db5=>{Kn(_0x1c0111,_0x289db5);});}function Is(_0x2e1202,_0x538506){const _0x1f5e18=Qt(ua(_0x2e1202,_0x538506)),_0x21f79c=$n(_0x2e1202['transactionQueueTree_'],_0x538506);return ad(_0x21f79c,_0x15f623=>{di(_0x2e1202,_0x15f623);}),di(_0x2e1202,_0x21f79c),ia(_0x21f79c,_0xf618eb=>{di(_0x2e1202,_0xf618eb);}),_0x1f5e18;}function di(_0x4a03f6,_0x583128){const _0x49074c=je(_0x583128);if(_0x49074c){const _0x310db2=[];let _0x1a90ae=[],_0x294173=-0x1;for(let _0x1db5c6=0x0;_0x1db5c6<_0x49074c['length'];_0x1db5c6++)_0x49074c[_0x1db5c6]['status']===0x3||(_0x49074c[_0x1db5c6]['status']===0x1?(f(_0x294173===_0x1db5c6-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x294173=_0x1db5c6,_0x49074c[_0x1db5c6]['status']=0x3,_0x49074c[_0x1db5c6]['abortReason']='set'):(f(_0x49074c[_0x1db5c6]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x49074c[_0x1db5c6]['unwatcher'](),_0x1a90ae=_0x1a90ae['concat'](_e(_0x4a03f6['serverSyncTree_'],_0x49074c[_0x1db5c6]['currentWriteId'],!0x0)),_0x49074c[_0x1db5c6]['onComplete']&&_0x310db2['push'](_0x49074c[_0x1db5c6]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x294173===-0x1?gs(_0x583128,void 0x0):_0x49074c['length']=_0x294173+0x1,V(_0x4a03f6['eventQueue_'],Qt(_0x583128),_0x1a90ae);for(let _0x13ea15=0x0;_0x13ea15<_0x310db2['length'];_0x13ea15++)ft(_0x310db2[_0x13ea15]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x1be62d){let _0x47b5c5='';const _0x45fb50=_0x1be62d['split']('/');for(let _0xcca447=0x0;_0xcca447<_0x45fb50['length'];_0xcca447++)if(_0x45fb50[_0xcca447]['length']>0x0){let _0x3b08c9=_0x45fb50[_0xcca447];try{_0x3b08c9=decodeURIComponent(_0x3b08c9['replace'](/\+/g,'\x20'));}catch{}_0x47b5c5+='/'+_0x3b08c9;}return _0x47b5c5;}function xd(_0x3d23f7){const _0x3c0a35={};_0x3d23f7['charAt'](0x0)==='?'&&(_0x3d23f7=_0x3d23f7['substring'](0x1));for(const _0x20a032 of _0x3d23f7['split']('&')){if(_0x20a032['length']===0x0)continue;const _0x451f68=_0x20a032['split']('=');_0x451f68['length']===0x2?_0x3c0a35[decodeURIComponent(_0x451f68[0x0])]=decodeURIComponent(_0x451f68[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x20a032+'\x27\x20in\x20query\x20\x27'+_0x3d23f7+'\x27');}return _0x3c0a35;}const vr=function(_0x12da2a,_0x51cb71){const _0x12e148=Fd(_0x12da2a),_0x367db0=_0x12e148['namespace'];_0x12e148['domain']==='firebase.com'&&ae(_0x12e148['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x367db0||_0x367db0==='undefined')&&_0x12e148['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x12e148['secure']||$l();const _0x203542=_0x12e148['scheme']==='ws'||_0x12e148['scheme']==='wss';return{'repoInfo':new yo(_0x12e148['host'],_0x12e148['secure'],_0x367db0,_0x203542,_0x51cb71,'',_0x367db0!==_0x12e148['subdomain']),'path':new C(_0x12e148['pathString'])};},Fd=function(_0x254d6b){let _0x3f8950='',_0x123823='',_0x529771='',_0x16df11='',_0x2edb94='',_0x3679c0=!0x0,_0x1df85a='https',_0x10bb8c=0x1bb;if(typeof _0x254d6b=='string'){let _0x500d47=_0x254d6b['indexOf']('//');_0x500d47>=0x0&&(_0x1df85a=_0x254d6b['substring'](0x0,_0x500d47-0x1),_0x254d6b=_0x254d6b['substring'](_0x500d47+0x2));let _0x33677a=_0x254d6b['indexOf']('/');_0x33677a===-0x1&&(_0x33677a=_0x254d6b['length']);let _0x2138da=_0x254d6b['indexOf']('?');_0x2138da===-0x1&&(_0x2138da=_0x254d6b['length']),_0x3f8950=_0x254d6b['substring'](0x0,Math['min'](_0x33677a,_0x2138da)),_0x33677a<_0x2138da&&(_0x16df11=Ld(_0x254d6b['substring'](_0x33677a,_0x2138da)));const _0x58678b=xd(_0x254d6b['substring'](Math['min'](_0x254d6b['length'],_0x2138da)));_0x500d47=_0x3f8950['indexOf'](':'),_0x500d47>=0x0?(_0x3679c0=_0x1df85a==='https'||_0x1df85a==='wss',_0x10bb8c=parseInt(_0x3f8950['substring'](_0x500d47+0x1),0xa)):_0x500d47=_0x3f8950['length'];const _0x52575c=_0x3f8950['slice'](0x0,_0x500d47);if(_0x52575c['toLowerCase']()==='localhost')_0x123823='localhost';else{if(_0x52575c['split']('.')['length']<=0x2)_0x123823=_0x52575c;else{const _0xfc561a=_0x3f8950['indexOf']('.');_0x529771=_0x3f8950['substring'](0x0,_0xfc561a)['toLowerCase'](),_0x123823=_0x3f8950['substring'](_0xfc561a+0x1),_0x2edb94=_0x529771;}}'ns'in _0x58678b&&(_0x2edb94=_0x58678b['ns']);}return{'host':_0x3f8950,'port':_0x10bb8c,'domain':_0x123823,'subdomain':_0x529771,'secure':_0x3679c0,'scheme':_0x1df85a,'pathString':_0x16df11,'namespace':_0x2edb94};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x5b6db4=0x0;const _0x1608b3=[];return function(_0x4628fd){const _0x3200f9=_0x4628fd===_0x5b6db4;_0x5b6db4=_0x4628fd;let _0x19d868;const _0x54ab1b=new Array(0x8);for(_0x19d868=0x7;_0x19d868>=0x0;_0x19d868--)_0x54ab1b[_0x19d868]=Er['charAt'](_0x4628fd%0x40),_0x4628fd=Math['floor'](_0x4628fd/0x40);f(_0x4628fd===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5a617c=_0x54ab1b['join']('');if(_0x3200f9){for(_0x19d868=0xb;_0x19d868>=0x0&&_0x1608b3[_0x19d868]===0x3f;_0x19d868--)_0x1608b3[_0x19d868]=0x0;_0x1608b3[_0x19d868]++;}else{for(_0x19d868=0x0;_0x19d868<0xc;_0x19d868++)_0x1608b3[_0x19d868]=Math['floor'](Math['random']()*0x40);}for(_0x19d868=0x0;_0x19d868<0xc;_0x19d868++)_0x5a617c+=Er['charAt'](_0x1608b3[_0x19d868]);return f(_0x5a617c['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5a617c;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1fb4f5,_0x452c1f,_0x93a89a,_0x34cb07){this['eventType']=_0x1fb4f5,this['eventRegistration']=_0x452c1f,this['snapshot']=_0x93a89a,this['prevName']=_0x34cb07;}['getPath'](){const _0x3077c1=this['snapshot']['ref'];return this['eventType']==='value'?_0x3077c1['_path']:_0x3077c1['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x5f0afd,_0x2bc9e4,_0x2500c6){this['eventRegistration']=_0x5f0afd,this['error']=_0x2bc9e4,this['path']=_0x2500c6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x460667,_0x20385e){this['snapshotCallback']=_0x460667,this['cancelCallback']=_0x20385e;}['onValue'](_0x10e475,_0x4556e1){this['snapshotCallback']['call'](null,_0x10e475,_0x4556e1);}['onCancel'](_0x80f5c4){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x80f5c4);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x11885f){return this['snapshotCallback']===_0x11885f['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x11885f['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x11885f['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5bc15c,_0x2f5220){this['_repo']=_0x5bc15c,this['_path']=_0x2f5220;}['cancel'](){const _0x325a8f=new H();return bd(this['_repo'],this['_path'],_0x325a8f['wrapCallback'](()=>{})),_0x325a8f['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2270ce=new H();return yr(this['_repo'],this['_path'],null,_0x2270ce['wrapCallback'](()=>{})),_0x2270ce['promise'];}['set'](_0x2f2ab1){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2f2ab1,this['_path'],!0x1);const _0x474a3e=new H();return yr(this['_repo'],this['_path'],_0x2f2ab1,_0x474a3e['wrapCallback'](()=>{})),_0x474a3e['promise'];}['setWithPriority'](_0x120b3d,_0x1afe0a){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x120b3d,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1afe0a);const _0xa82aa3=new H();return Rd(this['_repo'],this['_path'],_0x120b3d,_0x1afe0a,_0xa82aa3['wrapCallback'](()=>{})),_0xa82aa3['promise'];}['update'](_0x3cc571){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x3cc571,this['_path']);const _0x4ded4d=new H();return Ad(this['_repo'],this['_path'],_0x3cc571,_0x4ded4d['wrapCallback'](()=>{})),_0x4ded4d['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x141daf,_0x22174e,_0x100807,_0x160228){this['_repo']=_0x141daf,this['_path']=_0x22174e,this['_queryParams']=_0x100807,this['_orderByCalled']=_0x160228;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4257d1=sr(this['_queryParams']),_0x5ee6a9=$i(_0x4257d1);return _0x5ee6a9==='{}'?'default':_0x5ee6a9;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x884adc){if(_0x884adc=P(_0x884adc),!(_0x884adc instanceof Ae))return!0x1;const _0x42638e=this['_repo']===_0x884adc['_repo'],_0x473651=Ki(this['_path'],_0x884adc['_path']),_0x337991=this['_queryIdentifier']===_0x884adc['_queryIdentifier'];return _0x42638e&&_0x473651&&_0x337991;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1dd3e4,_0x461f4b){if(_0x1dd3e4['_orderByCalled']===!0x0)throw new Error(_0x461f4b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4dea90){let _0x4091fd=null,_0x39243f=null;if(_0x4dea90['hasStart']()&&(_0x4091fd=_0x4dea90['getIndexStartValue']()),_0x4dea90['hasEnd']()&&(_0x39243f=_0x4dea90['getIndexEndValue']()),_0x4dea90['getIndex']()===ve){const _0x4d357d='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2c9661='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4dea90['hasStart']()){if(_0x4dea90['getIndexStartName']()!==We)throw new Error(_0x4d357d);if(typeof _0x4091fd!='string')throw new Error(_0x2c9661);}if(_0x4dea90['hasEnd']()){if(_0x4dea90['getIndexEndName']()!==we)throw new Error(_0x4d357d);if(typeof _0x39243f!='string')throw new Error(_0x2c9661);}}else{if(_0x4dea90['getIndex']()===R){if(_0x4091fd!=null&&!Bt(_0x4091fd)||_0x39243f!=null&&!Bt(_0x39243f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4dea90['getIndex']()instanceof Ji||_0x4dea90['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4091fd!=null&&typeof _0x4091fd=='object'||_0x39243f!=null&&typeof _0x39243f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0xb4dbf7){if(_0xb4dbf7['hasStart']()&&_0xb4dbf7['hasEnd']()&&_0xb4dbf7['hasLimit']()&&!_0xb4dbf7['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x4b3fd6,_0x4f9d43){super(_0x4b3fd6,_0x4f9d43,new Zi(),!0x1);}get['parent'](){const _0x31ffd6=Ro(this['_path']);return _0x31ffd6===null?null:new ee(this['_repo'],_0x31ffd6);}get['root'](){let _0x30a950=this;for(;_0x30a950['parent']!==null;)_0x30a950=_0x30a950['parent'];return _0x30a950;}}class lt{constructor(_0x1a325c,_0x58540e,_0x245f53){this['_node']=_0x1a325c,this['ref']=_0x58540e,this['_index']=_0x245f53;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x51a408){const _0x3fd02e=new C(_0x51a408),_0x1184d1=Vt(this['ref'],_0x51a408);return new lt(this['_node']['getChild'](_0x3fd02e),_0x1184d1,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2e9195){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2eb24d,_0x5905bc)=>_0x2e9195(new lt(_0x5905bc,Vt(this['ref'],_0x2eb24d),R)));}['hasChild'](_0x48ab44){const _0x5645df=new C(_0x48ab44);return!this['_node']['getChild'](_0x5645df)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4aedef,_0x1b97d2){return _0x4aedef=P(_0x4aedef),_0x4aedef['_checkNotDeleted']('ref'),_0x1b97d2!==void 0x0?Vt(_0x4aedef['_root'],_0x1b97d2):_0x4aedef['_root'];}function Vt(_0x41a988,_0x34da41){return _0x41a988=P(_0x41a988),y(_0x41a988['_path'])===null?pd('child','path',_0x34da41):ys('child','path',_0x34da41),new ee(_0x41a988['_repo'],k(_0x41a988['_path'],_0x34da41));}function v_(_0x4793e6){return _0x4793e6=P(_0x4793e6),new Vd(_0x4793e6['_repo'],_0x4793e6['_path']);}function E_(_0x27c366,_0x1dcc9e){_0x27c366=P(_0x27c366),Me('push',_0x27c366['_path']),He('push',_0x1dcc9e,_0x27c366['_path'],!0x0);const _0x4c5e9c=la(_0x27c366['_repo']),_0x344693=Ud(_0x4c5e9c),_0x444ea9=Vt(_0x27c366,_0x344693),_0x1e6722=Vt(_0x27c366,_0x344693);let _0x503eb4;return _0x1dcc9e!=null?_0x503eb4=Hd(_0x1e6722,_0x1dcc9e)['then'](()=>_0x1e6722):_0x503eb4=Promise['resolve'](_0x1e6722),_0x444ea9['then']=_0x503eb4['then']['bind'](_0x503eb4),_0x444ea9['catch']=_0x503eb4['then']['bind'](_0x503eb4,void 0x0),_0x444ea9;}function Hd(_0x2daaef,_0x532057){_0x2daaef=P(_0x2daaef),Me('set',_0x2daaef['_path']),He('set',_0x532057,_0x2daaef['_path'],!0x1);const _0x1aaaff=new H();return Cd(_0x2daaef['_repo'],_0x2daaef['_path'],_0x532057,null,_0x1aaaff['wrapCallback'](()=>{})),_0x1aaaff['promise'];}function I_(_0x56eb15,_0x118cbf){ra('update',_0x118cbf,_0x56eb15['_path']);const _0x27080e=new H();return Td(_0x56eb15['_repo'],_0x56eb15['_path'],_0x118cbf,_0x27080e['wrapCallback'](()=>{})),_0x27080e['promise'];}function w_(_0x55e62d){_0x55e62d=P(_0x55e62d);const _0x4d5a92=new pa(()=>{}),_0x28aad4=new Qn(_0x4d5a92);return wd(_0x55e62d['_repo'],_0x55e62d,_0x28aad4)['then'](_0x4cb8d3=>new lt(_0x4cb8d3,new ee(_0x55e62d['_repo'],_0x55e62d['_path']),_0x55e62d['_queryParams']['getIndex']()));}class Qn{constructor(_0x3946e8){this['callbackContext']=_0x3946e8;}['respondsTo'](_0xdf30dc){return _0xdf30dc==='value';}['createEvent'](_0x1070ec,_0x10c775){const _0x587508=_0x10c775['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x1070ec['snapshotNode'],new ee(_0x10c775['_repo'],_0x10c775['_path']),_0x587508));}['getEventRunner'](_0x45b9f4){return _0x45b9f4['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x45b9f4['error']):()=>this['callbackContext']['onValue'](_0x45b9f4['snapshot'],null);}['createCancelEvent'](_0x14920c,_0x441ef1){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x14920c,_0x441ef1):null;}['matches'](_0x3f74c8){return _0x3f74c8 instanceof Qn?!_0x3f74c8['callbackContext']||!this['callbackContext']?!0x0:_0x3f74c8['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x10fd18,_0x598e85,_0x1f21cc,_0x3b7cd8,_0x48be9b){const _0x19930e=new pa(_0x1f21cc,void 0x0),_0x3d4681=new Qn(_0x19930e);return kd(_0x10fd18['_repo'],_0x10fd18,_0x3d4681),()=>Pd(_0x10fd18['_repo'],_0x10fd18,_0x3d4681);}function Gd(_0x3a5e67,_0x4f63da,_0x2ffd9b,_0xc3ba08){return $d(_0x3a5e67,'value',_0x4f63da);}class mt{}class ma extends mt{constructor(_0x2a4b61,_0x1e1abb){super(),this['_value']=_0x2a4b61,this['_key']=_0x1e1abb,this['type']='endAt';}['_apply'](_0xa4842a){He('endAt',this['_value'],_0xa4842a['_path'],!0x0);const _0x2450c8=Jh(_0xa4842a['_queryParams'],this['_value'],this['_key']);if(ga(_0x2450c8),Yn(_0x2450c8),_0xa4842a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0xa4842a['_repo'],_0xa4842a['_path'],_0x2450c8,_0xa4842a['_orderByCalled']);}}function C_(_0x2c0e0e,_0x7dfaa2){return new ma(_0x2c0e0e,_0x7dfaa2);}class ya extends mt{constructor(_0x413b03,_0x3c48b2){super(),this['_value']=_0x413b03,this['_key']=_0x3c48b2,this['type']='startAt';}['_apply'](_0x4524a2){He('startAt',this['_value'],_0x4524a2['_path'],!0x0);const _0x3479f6=Qh(_0x4524a2['_queryParams'],this['_value'],this['_key']);if(ga(_0x3479f6),Yn(_0x3479f6),_0x4524a2['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x4524a2['_repo'],_0x4524a2['_path'],_0x3479f6,_0x4524a2['_orderByCalled']);}}function T_(_0x476751=null,_0x462d18){return new ya(_0x476751,_0x462d18);}class qd extends mt{constructor(_0x4d6771){super(),this['_limit']=_0x4d6771,this['type']='limitToFirst';}['_apply'](_0x1afc63){if(_0x1afc63['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x1afc63['_repo'],_0x1afc63['_path'],Yh(_0x1afc63['_queryParams'],this['_limit']),_0x1afc63['_orderByCalled']);}}function S_(_0x2539fe){if(Math['floor'](_0x2539fe)!==_0x2539fe||_0x2539fe<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x2539fe);}class zd extends mt{constructor(_0x1ef596){super(),this['_path']=_0x1ef596,this['type']='orderByChild';}['_apply'](_0x4624be){_a(_0x4624be,'orderByChild');const _0x29b3c6=new C(this['_path']);if(v(_0x29b3c6))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x271d8a=new Ji(_0x29b3c6),_0x814d2f=xo(_0x4624be['_queryParams'],_0x271d8a);return Yn(_0x814d2f),new Ae(_0x4624be['_repo'],_0x4624be['_path'],_0x814d2f,!0x0);}}function b_(_0x1e7fd2){if(_0x1e7fd2==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1e7fd2==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1e7fd2==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x1e7fd2),new zd(_0x1e7fd2);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x31150a){_a(_0x31150a,'orderByKey');const _0x1c9fac=xo(_0x31150a['_queryParams'],ve);return Yn(_0x1c9fac),new Ae(_0x31150a['_repo'],_0x31150a['_path'],_0x1c9fac,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x39540d,_0x63d919){super(),this['_value']=_0x39540d,this['_key']=_0x63d919,this['type']='equalTo';}['_apply'](_0x480f14){if(He('equalTo',this['_value'],_0x480f14['_path'],!0x1),_0x480f14['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x480f14['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x480f14));}}function A_(_0x220e58,_0x29a5d8){return new Kd(_0x220e58,_0x29a5d8);}function k_(_0x3fad1e,..._0x416381){let _0x1823ff=P(_0x3fad1e);for(const _0x26ef4d of _0x416381)_0x1823ff=_0x26ef4d['_apply'](_0x1823ff);return _0x1823ff;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x2676ae,_0x2be020,_0x4a4292,_0x190161){const _0x13f1e0=_0x2be020['lastIndexOf'](':'),_0x25540c=_0x2be020['substring'](0x0,_0x13f1e0),_0xe2e81a=qt(_0x25540c);_0x2676ae['repoInfo_']=new yo(_0x2be020,_0xe2e81a,_0x2676ae['repoInfo_']['namespace'],_0x2676ae['repoInfo_']['webSocketOnly'],_0x2676ae['repoInfo_']['nodeAdmin'],_0x2676ae['repoInfo_']['persistenceKey'],_0x2676ae['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4a4292),_0x190161&&(_0x2676ae['authTokenProvider_']=_0x190161);}function Xd(_0x5e84b9,_0x5d1c87,_0xe67d9b,_0xd5140,_0x587afc){let _0x260a98=_0xd5140||_0x5e84b9['options']['databaseURL'];_0x260a98===void 0x0&&(_0x5e84b9['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5e84b9['options']['projectId']),_0x260a98=_0x5e84b9['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x92d69a=vr(_0x260a98,_0x587afc),_0x1d4595=_0x92d69a['repoInfo'],_0x744043;typeof process<'u'&&Bs&&(_0x744043=Bs[Yd]),_0x744043?(_0x260a98='http://'+_0x744043+'?ns='+_0x1d4595['namespace'],_0x92d69a=vr(_0x260a98,_0x587afc),_0x1d4595=_0x92d69a['repoInfo']):_0x92d69a['repoInfo']['secure'];const _0x50a119=new eh(_0x5e84b9['name'],_0x5e84b9['options'],_0x5d1c87);_d('Invalid\x20Firebase\x20Database\x20URL',_0x92d69a),v(_0x92d69a['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x20b43c=ef(_0x1d4595,_0x5e84b9,_0x50a119,new Zl(_0x5e84b9,_0xe67d9b));return new tf(_0x20b43c,_0x5e84b9);}function Zd(_0x4964be,_0x398cb8){const _0x8e01d=Di[_0x398cb8];(!_0x8e01d||_0x8e01d[_0x4964be['key']]!==_0x4964be)&&ae('Database\x20'+_0x398cb8+'('+_0x4964be['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4964be),delete _0x8e01d[_0x4964be['key']];}function ef(_0x1957e9,_0x304dac,_0x32821d,_0xaa74ac){let _0x1868c3=Di[_0x304dac['name']];_0x1868c3||(_0x1868c3={},Di[_0x304dac['name']]=_0x1868c3);let _0x3912e6=_0x1868c3[_0x1957e9['toURLString']()];return _0x3912e6&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3912e6=new vd(_0x1957e9,Qd,_0x32821d,_0xaa74ac),_0x1868c3[_0x1957e9['toURLString']()]=_0x3912e6,_0x3912e6;}class tf{constructor(_0xc82673,_0x11e7d9){this['_repoInternal']=_0xc82673,this['app']=_0x11e7d9,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x104687){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x104687+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x7221d2=Zr(),_0x25b6e7){const _0x2f31c4=Hi(_0x7221d2,'database')['getImmediate']({'identifier':_0x25b6e7});if(!_0x2f31c4['_instanceStarted']){const _0xb8ada7=hc('database');_0xb8ada7&&nf(_0x2f31c4,..._0xb8ada7);}return _0x2f31c4;}function nf(_0x2bd20c,_0x3e4526,_0x422e54,_0x196f9f={}){_0x2bd20c=P(_0x2bd20c),_0x2bd20c['_checkNotDeleted']('useEmulator');const _0x58cc85=_0x3e4526+':'+_0x422e54,_0x3851a2=_0x2bd20c['_repoInternal'];if(_0x2bd20c['_instanceStarted']){if(_0x58cc85===_0x2bd20c['_repoInternal']['repoInfo_']['host']&&xe(_0x196f9f,_0x3851a2['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xe83425;if(_0x3851a2['repoInfo_']['nodeAdmin'])_0x196f9f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xe83425=new an(an['OWNER']);else{if(_0x196f9f['mockUserToken']){const _0x26f487=typeof _0x196f9f['mockUserToken']=='string'?_0x196f9f['mockUserToken']:uc(_0x196f9f['mockUserToken'],_0x2bd20c['app']['options']['projectId']);_0xe83425=new an(_0x26f487);}}qt(_0x3e4526)&&Qr(_0x3e4526),Jd(_0x3851a2,_0x58cc85,_0x196f9f,_0xe83425);}function N_(_0x445ea4){_0x445ea4=P(_0x445ea4),_0x445ea4['_checkNotDeleted']('goOffline'),ha(_0x445ea4['_repo']);}function O_(_0x441312){_0x441312=P(_0x441312),_0x441312['_checkNotDeleted']('goOnline'),Nd(_0x441312['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x1eb85c){Ul(dt),st(new Fe('database',(_0x9852a0,{instanceIdentifier:_0x4d7086})=>{const _0x21a86f=_0x9852a0['getProvider']('app')['getImmediate'](),_0x200d1b=_0x9852a0['getProvider']('auth-internal'),_0x3814a0=_0x9852a0['getProvider']('app-check-internal');return Xd(_0x21a86f,_0x200d1b,_0x3814a0,_0x4d7086);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x1eb85c),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x3f1437,_0x433de7){this['committed']=_0x3f1437,this['snapshot']=_0x433de7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x227348,_0x40b7e3,_0x24d867){if(_0x227348=P(_0x227348),Me('Reference.transaction',_0x227348['_path']),_0x227348['key']==='.length'||_0x227348['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x227348['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3915f2=!0x0,_0x11a80c=new H(),_0x1a6016=(_0x313637,_0x9633a0,_0x1923b8)=>{let _0x541927=null;_0x313637?_0x11a80c['reject'](_0x313637):(_0x541927=new lt(_0x1923b8,new ee(_0x227348['_repo'],_0x227348['_path']),R),_0x11a80c['resolve'](new of(_0x9633a0,_0x541927)));},_0x1cf541=Gd(_0x227348,()=>{});return Od(_0x227348['_repo'],_0x227348['_path'],_0x40b7e3,_0x1a6016,_0x1cf541,_0x3915f2),_0x11a80c['promise'];}se['prototype']['simpleListen']=function(_0xeed22,_0x55f727){this['sendRequest']('q',{'p':_0xeed22},_0x55f727);},se['prototype']['echo']=function(_0x44923c,_0x2c58d0){this['sendRequest']('echo',{'d':_0x44923c},_0x2c58d0);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x14e05e,..._0x41f43d){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x14e05e,..._0x41f43d);}function cn(_0x5b47f8,..._0xd132a7){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5b47f8,..._0xd132a7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xd14548,..._0x15c630){throw ws(_0xd14548,..._0x15c630);}function X(_0x26b0a5,..._0x15fc4f){return ws(_0x26b0a5,..._0x15fc4f);}function Ia(_0x572a47,_0xdb5d1f,_0x2de3d1){const _0x3a2689={...af(),[_0xdb5d1f]:_0x2de3d1};return new Gt('auth','Firebase',_0x3a2689)['create'](_0xdb5d1f,{'appName':_0x572a47['name']});}function re(_0xa6e246){return Ia(_0xa6e246,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x19f68e,..._0x5860df){if(typeof _0x19f68e!='string'){const _0x4eb489=_0x5860df[0x0],_0x57103b=[..._0x5860df['slice'](0x1)];return _0x57103b[0x0]&&(_0x57103b[0x0]['appName']=_0x19f68e['name']),_0x19f68e['_errorFactory']['create'](_0x4eb489,..._0x57103b);}return Ea['create'](_0x19f68e,..._0x5860df);}function m(_0x512459,_0x3c49c5,..._0x4a9035){if(!_0x512459)throw ws(_0x3c49c5,..._0x4a9035);}function ne(_0x41d707){const _0x22fdcd='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x41d707;throw cn(_0x22fdcd),new Error(_0x22fdcd);}function ce(_0x326c9c,_0x44c309){_0x326c9c||ne(_0x44c309);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x51c6e9;return typeof self<'u'&&((_0x51c6e9=self['location'])==null?void 0x0:_0x51c6e9['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1fb467;return typeof self<'u'&&((_0x1fb467=self['location'])==null?void 0x0:_0x1fb467['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x49e7b5=navigator;return _0x49e7b5['languages']&&_0x49e7b5['languages'][0x0]||_0x49e7b5['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x175315,_0x5e0ee6){this['shortDelay']=_0x175315,this['longDelay']=_0x5e0ee6,ce(_0x5e0ee6>_0x175315,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3f99c2,_0x1add67){ce(_0x3f99c2['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1ebf49}=_0x3f99c2['emulator'];return _0x1add67?''+_0x1ebf49+(_0x1add67['startsWith']('/')?_0x1add67['slice'](0x1):_0x1add67):_0x1ebf49;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xda0c94,_0x366850,_0x1d9929){this['fetchImpl']=_0xda0c94,_0x366850&&(this['headersImpl']=_0x366850),_0x1d9929&&(this['responseImpl']=_0x1d9929);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x2dd3f4,_0x17a810){return _0x2dd3f4['tenantId']&&!_0x17a810['tenantId']?{..._0x17a810,'tenantId':_0x2dd3f4['tenantId']}:_0x17a810;}async function Pe(_0x53ed63,_0x3d5ddc,_0x15ece0,_0x4cfebe,_0x4795c4={}){return Ca(_0x53ed63,_0x4795c4,async()=>{let _0xdc1174={},_0x26370e={};_0x4cfebe&&(_0x3d5ddc==='GET'?_0x26370e=_0x4cfebe:_0xdc1174={'body':JSON['stringify'](_0x4cfebe)});const _0xda4834=ut({..._0x26370e,'key':_0x53ed63['config']['apiKey']})['slice'](0x1),_0x234f11=await _0x53ed63['_getAdditionalHeaders']();_0x234f11['Content-Type']='application/json',_0x53ed63['languageCode']&&(_0x234f11['X-Firebase-Locale']=_0x53ed63['languageCode']);const _0x2985ca={'method':_0x3d5ddc,'headers':_0x234f11,..._0xdc1174};return dc()||(_0x2985ca['referrerPolicy']='strict-origin-when-cross-origin'),_0x53ed63['emulatorConfig']&&qt(_0x53ed63['emulatorConfig']['host'])&&(_0x2985ca['credentials']='include'),wa['fetch']()(await Ta(_0x53ed63,_0x53ed63['config']['apiHost'],_0x15ece0,_0xda4834),_0x2985ca);});}async function Ca(_0x1a6697,_0x1c066b,_0x15a9fd){_0x1a6697['_canInitEmulator']=!0x1;const _0x3fd98e={...df,..._0x1c066b};try{const _0x31ee13=new gf(_0x1a6697),_0x1b37a3=await Promise['race']([_0x15a9fd(),_0x31ee13['promise']]);_0x31ee13['clearNetworkTimeout']();const _0x1b58a5=await _0x1b37a3['json']();if('needConfirmation'in _0x1b58a5)throw on(_0x1a6697,'account-exists-with-different-credential',_0x1b58a5);if(_0x1b37a3['ok']&&!('errorMessage'in _0x1b58a5))return _0x1b58a5;{const _0x4e794e=_0x1b37a3['ok']?_0x1b58a5['errorMessage']:_0x1b58a5['error']['message'],[_0x1edf7f,_0x2e4119]=_0x4e794e['split']('\x20:\x20');if(_0x1edf7f==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1a6697,'credential-already-in-use',_0x1b58a5);if(_0x1edf7f==='EMAIL_EXISTS')throw on(_0x1a6697,'email-already-in-use',_0x1b58a5);if(_0x1edf7f==='USER_DISABLED')throw on(_0x1a6697,'user-disabled',_0x1b58a5);const _0x2a6285=_0x3fd98e[_0x1edf7f]||_0x1edf7f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2e4119)throw Ia(_0x1a6697,_0x2a6285,_0x2e4119);Y(_0x1a6697,_0x2a6285);}}catch(_0x28d665){if(_0x28d665 instanceof Re)throw _0x28d665;Y(_0x1a6697,'network-request-failed',{'message':String(_0x28d665)});}}async function en(_0x8f36f,_0x14ca5f,_0x5a6ad7,_0x358dac,_0x3087de={}){const _0x1e5133=await Pe(_0x8f36f,_0x14ca5f,_0x5a6ad7,_0x358dac,_0x3087de);return'mfaPendingCredential'in _0x1e5133&&Y(_0x8f36f,'multi-factor-auth-required',{'_serverResponse':_0x1e5133}),_0x1e5133;}async function Ta(_0x180f80,_0x40679d,_0x184147,_0x45c281){const _0x556807=''+_0x40679d+_0x184147+'?'+_0x45c281,_0x1f3293=_0x180f80,_0x5c48ba=_0x1f3293['config']['emulator']?Cs(_0x180f80['config'],_0x556807):_0x180f80['config']['apiScheme']+'://'+_0x556807;return ff['includes'](_0x184147)&&(await _0x1f3293['_persistenceManagerAvailable'],_0x1f3293['_getPersistenceType']()==='COOKIE')?_0x1f3293['_getPersistence']()['_getFinalTarget'](_0x5c48ba)['toString']():_0x5c48ba;}function _f(_0x527d5d){switch(_0x527d5d){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5a51dd){this['auth']=_0x5a51dd,this['timer']=null,this['promise']=new Promise((_0xc446a1,_0x1c7a9d)=>{this['timer']=setTimeout(()=>_0x1c7a9d(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x273719,_0x1d7a94,_0x42346d){const _0x2b6820={'appName':_0x273719['name']};_0x42346d['email']&&(_0x2b6820['email']=_0x42346d['email']),_0x42346d['phoneNumber']&&(_0x2b6820['phoneNumber']=_0x42346d['phoneNumber']);const _0x4e6882=X(_0x273719,_0x1d7a94,_0x2b6820);return _0x4e6882['customData']['_tokenResponse']=_0x42346d,_0x4e6882;}function wr(_0x3d712c){return _0x3d712c!==void 0x0&&_0x3d712c['enterprise']!==void 0x0;}class mf{constructor(_0x46bfe0){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x46bfe0['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x46bfe0['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x46bfe0['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2b4bde){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xbc936f of this['recaptchaEnforcementState'])if(_0xbc936f['provider']&&_0xbc936f['provider']===_0x2b4bde)return _f(_0xbc936f['enforcementState']);return null;}['isProviderEnabled'](_0x1277a7){return this['getProviderEnforcementState'](_0x1277a7)==='ENFORCE'||this['getProviderEnforcementState'](_0x1277a7)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x42051e,_0x319d19){return Pe(_0x42051e,'GET','/v2/recaptchaConfig',ke(_0x42051e,_0x319d19));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x442fce,_0x464913){return Pe(_0x442fce,'POST','/v1/accounts:delete',_0x464913);}async function Pn(_0x56e4a9,_0x4c398a){return Pe(_0x56e4a9,'POST','/v1/accounts:lookup',_0x4c398a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x64f66f){if(_0x64f66f)try{const _0x31e16d=new Date(Number(_0x64f66f));if(!isNaN(_0x31e16d['getTime']()))return _0x31e16d['toUTCString']();}catch{}}async function Ef(_0x1f8054,_0x178c98=!0x1){const _0x3b960f=P(_0x1f8054),_0x46b198=await _0x3b960f['getIdToken'](_0x178c98),_0x44054a=Ts(_0x46b198);m(_0x44054a&&_0x44054a['exp']&&_0x44054a['auth_time']&&_0x44054a['iat'],_0x3b960f['auth'],'internal-error');const _0x300078=typeof _0x44054a['firebase']=='object'?_0x44054a['firebase']:void 0x0,_0x365ac3=_0x300078==null?void 0x0:_0x300078['sign_in_provider'];return{'claims':_0x44054a,'token':_0x46b198,'authTime':Pt(fi(_0x44054a['auth_time'])),'issuedAtTime':Pt(fi(_0x44054a['iat'])),'expirationTime':Pt(fi(_0x44054a['exp'])),'signInProvider':_0x365ac3||null,'signInSecondFactor':(_0x300078==null?void 0x0:_0x300078['sign_in_second_factor'])||null};}function fi(_0x1f9b8f){return Number(_0x1f9b8f)*0x3e8;}function Ts(_0x28e269){const [_0x600352,_0x89ca41,_0x5d119d]=_0x28e269['split']('.');if(_0x600352===void 0x0||_0x89ca41===void 0x0||_0x5d119d===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4a7a0f=fn(_0x89ca41);return _0x4a7a0f?JSON['parse'](_0x4a7a0f):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x20d9a6){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x20d9a6==null?void 0x0:_0x20d9a6['toString']()),null;}}function Cr(_0x118e71){const _0x4b213e=Ts(_0x118e71);return m(_0x4b213e,'internal-error'),m(typeof _0x4b213e['exp']<'u','internal-error'),m(typeof _0x4b213e['iat']<'u','internal-error'),Number(_0x4b213e['exp'])-Number(_0x4b213e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x3948eb,_0x361749,_0x43c612=!0x1){if(_0x43c612)return _0x361749;try{return await _0x361749;}catch(_0x469638){throw _0x469638 instanceof Re&&If(_0x469638)&&_0x3948eb['auth']['currentUser']===_0x3948eb&&await _0x3948eb['auth']['signOut'](),_0x469638;}}function If({code:_0x258566}){return _0x258566==='auth/user-disabled'||_0x258566==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x528f45){this['user']=_0x528f45,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x14c0d4){if(_0x14c0d4){const _0x53a155=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x53a155;}else{this['errorBackoff']=0x7530;const _0x14ee28=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x14ee28);}}['schedule'](_0x954f74=!0x1){if(!this['isRunning'])return;const _0x302a58=this['getInterval'](_0x954f74);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x302a58);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x18e94b){(_0x18e94b==null?void 0x0:_0x18e94b['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x3ec74a,_0x5eca69){this['createdAt']=_0x3ec74a,this['lastLoginAt']=_0x5eca69,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x4a8541){this['createdAt']=_0x4a8541['createdAt'],this['lastLoginAt']=_0x4a8541['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x35ab82){var _0x28e583;const _0x167be3=_0x35ab82['auth'],_0x193f5e=await _0x35ab82['getIdToken'](),_0x579f66=await Ht(_0x35ab82,Pn(_0x167be3,{'idToken':_0x193f5e}));m(_0x579f66==null?void 0x0:_0x579f66['users']['length'],_0x167be3,'internal-error');const _0x221174=_0x579f66['users'][0x0];_0x35ab82['_notifyReloadListener'](_0x221174);const _0x464fdd=(_0x28e583=_0x221174['providerUserInfo'])!=null&&_0x28e583['length']?Sa(_0x221174['providerUserInfo']):[],_0x41f2b9=Tf(_0x35ab82['providerData'],_0x464fdd),_0x4ab683=_0x35ab82['isAnonymous'],_0x5a68f5=!(_0x35ab82['email']&&_0x221174['passwordHash'])&&!(_0x41f2b9!=null&&_0x41f2b9['length']),_0x3b8269=_0x4ab683?_0x5a68f5:!0x1,_0x337728={'uid':_0x221174['localId'],'displayName':_0x221174['displayName']||null,'photoURL':_0x221174['photoUrl']||null,'email':_0x221174['email']||null,'emailVerified':_0x221174['emailVerified']||!0x1,'phoneNumber':_0x221174['phoneNumber']||null,'tenantId':_0x221174['tenantId']||null,'providerData':_0x41f2b9,'metadata':new Li(_0x221174['createdAt'],_0x221174['lastLoginAt']),'isAnonymous':_0x3b8269};Object['assign'](_0x35ab82,_0x337728);}async function Cf(_0x270283){const _0x116267=P(_0x270283);await Nn(_0x116267),await _0x116267['auth']['_persistUserIfCurrent'](_0x116267),_0x116267['auth']['_notifyListenersIfCurrent'](_0x116267);}function Tf(_0x5e6fc0,_0x3f49ae){return[..._0x5e6fc0['filter'](_0xcb66a2=>!_0x3f49ae['some'](_0x1f0277=>_0x1f0277['providerId']===_0xcb66a2['providerId'])),..._0x3f49ae];}function Sa(_0x5af4d7){return _0x5af4d7['map'](({providerId:_0x30b792,..._0x27e0e1})=>({'providerId':_0x30b792,'uid':_0x27e0e1['rawId']||'','displayName':_0x27e0e1['displayName']||null,'email':_0x27e0e1['email']||null,'phoneNumber':_0x27e0e1['phoneNumber']||null,'photoURL':_0x27e0e1['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x5a796c,_0x24a1a9){const _0x475d08=await Ca(_0x5a796c,{},async()=>{const _0x1167d5=ut({'grant_type':'refresh_token','refresh_token':_0x24a1a9})['slice'](0x1),{tokenApiHost:_0x3918bb,apiKey:_0x6a7cca}=_0x5a796c['config'],_0x4cfd57=await Ta(_0x5a796c,_0x3918bb,'/v1/token','key='+_0x6a7cca),_0x40f799=await _0x5a796c['_getAdditionalHeaders']();_0x40f799['Content-Type']='application/x-www-form-urlencoded';const _0x1354bf={'method':'POST','headers':_0x40f799,'body':_0x1167d5};return _0x5a796c['emulatorConfig']&&qt(_0x5a796c['emulatorConfig']['host'])&&(_0x1354bf['credentials']='include'),wa['fetch']()(_0x4cfd57,_0x1354bf);});return{'accessToken':_0x475d08['access_token'],'expiresIn':_0x475d08['expires_in'],'refreshToken':_0x475d08['refresh_token']};}async function bf(_0xeb2aa2,_0xfc74e1){return Pe(_0xeb2aa2,'POST','/v2/accounts:revokeToken',ke(_0xeb2aa2,_0xfc74e1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2b931e){m(_0x2b931e['idToken'],'internal-error'),m(typeof _0x2b931e['idToken']<'u','internal-error'),m(typeof _0x2b931e['refreshToken']<'u','internal-error');const _0x129811='expiresIn'in _0x2b931e&&typeof _0x2b931e['expiresIn']<'u'?Number(_0x2b931e['expiresIn']):Cr(_0x2b931e['idToken']);this['updateTokensAndExpiration'](_0x2b931e['idToken'],_0x2b931e['refreshToken'],_0x129811);}['updateFromIdToken'](_0x4a2eef){m(_0x4a2eef['length']!==0x0,'internal-error');const _0x5e7d21=Cr(_0x4a2eef);this['updateTokensAndExpiration'](_0x4a2eef,null,_0x5e7d21);}async['getToken'](_0x2b5e61,_0x5bb619=!0x1){return!_0x5bb619&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2b5e61,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2b5e61,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x39fd18,_0x55a5fb){const {accessToken:_0x1b5fb8,refreshToken:_0x134845,expiresIn:_0xb4676a}=await Sf(_0x39fd18,_0x55a5fb);this['updateTokensAndExpiration'](_0x1b5fb8,_0x134845,Number(_0xb4676a));}['updateTokensAndExpiration'](_0x533ad4,_0xecdba0,_0x4798c1){this['refreshToken']=_0xecdba0||null,this['accessToken']=_0x533ad4||null,this['expirationTime']=Date['now']()+_0x4798c1*0x3e8;}static['fromJSON'](_0x523056,_0x5e79e6){const {refreshToken:_0x1c929f,accessToken:_0x277d4e,expirationTime:_0x4cc05f}=_0x5e79e6,_0x53fa8d=new et();return _0x1c929f&&(m(typeof _0x1c929f=='string','internal-error',{'appName':_0x523056}),_0x53fa8d['refreshToken']=_0x1c929f),_0x277d4e&&(m(typeof _0x277d4e=='string','internal-error',{'appName':_0x523056}),_0x53fa8d['accessToken']=_0x277d4e),_0x4cc05f&&(m(typeof _0x4cc05f=='number','internal-error',{'appName':_0x523056}),_0x53fa8d['expirationTime']=_0x4cc05f),_0x53fa8d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x150223){this['accessToken']=_0x150223['accessToken'],this['refreshToken']=_0x150223['refreshToken'],this['expirationTime']=_0x150223['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3dfc2d,_0x13d1fb){m(typeof _0x3dfc2d=='string'||typeof _0x3dfc2d>'u','internal-error',{'appName':_0x13d1fb});}class j{constructor({uid:_0x294adc,auth:_0x183ca2,stsTokenManager:_0x14eba7,..._0x1a7745}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x294adc,this['auth']=_0x183ca2,this['stsTokenManager']=_0x14eba7,this['accessToken']=_0x14eba7['accessToken'],this['displayName']=_0x1a7745['displayName']||null,this['email']=_0x1a7745['email']||null,this['emailVerified']=_0x1a7745['emailVerified']||!0x1,this['phoneNumber']=_0x1a7745['phoneNumber']||null,this['photoURL']=_0x1a7745['photoURL']||null,this['isAnonymous']=_0x1a7745['isAnonymous']||!0x1,this['tenantId']=_0x1a7745['tenantId']||null,this['providerData']=_0x1a7745['providerData']?[..._0x1a7745['providerData']]:[],this['metadata']=new Li(_0x1a7745['createdAt']||void 0x0,_0x1a7745['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2f34a0){const _0x16c898=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x2f34a0));return m(_0x16c898,this['auth'],'internal-error'),this['accessToken']!==_0x16c898&&(this['accessToken']=_0x16c898,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x16c898;}['getIdTokenResult'](_0x2b3c1a){return Ef(this,_0x2b3c1a);}['reload'](){return Cf(this);}['_assign'](_0x331341){this!==_0x331341&&(m(this['uid']===_0x331341['uid'],this['auth'],'internal-error'),this['displayName']=_0x331341['displayName'],this['photoURL']=_0x331341['photoURL'],this['email']=_0x331341['email'],this['emailVerified']=_0x331341['emailVerified'],this['phoneNumber']=_0x331341['phoneNumber'],this['isAnonymous']=_0x331341['isAnonymous'],this['tenantId']=_0x331341['tenantId'],this['providerData']=_0x331341['providerData']['map'](_0xec41e5=>({..._0xec41e5})),this['metadata']['_copy'](_0x331341['metadata']),this['stsTokenManager']['_assign'](_0x331341['stsTokenManager']));}['_clone'](_0x32a7a4){const _0xb21a0e=new j({...this,'auth':_0x32a7a4,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xb21a0e['metadata']['_copy'](this['metadata']),_0xb21a0e;}['_onReload'](_0x17ba11){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x17ba11,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x569274){this['reloadListener']?this['reloadListener'](_0x569274):this['reloadUserInfo']=_0x569274;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2512ea,_0x58c089=!0x1){let _0xe99a3a=!0x1;_0x2512ea['idToken']&&_0x2512ea['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2512ea),_0xe99a3a=!0x0),_0x58c089&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0xe99a3a&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x52aa1d=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x52aa1d})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x512172=>({..._0x512172})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x2e96d6,_0x145dd1){const _0x554e33=_0x145dd1['displayName']??void 0x0,_0x12c9ae=_0x145dd1['email']??void 0x0,_0x2a7a77=_0x145dd1['phoneNumber']??void 0x0,_0x762e61=_0x145dd1['photoURL']??void 0x0,_0x39f957=_0x145dd1['tenantId']??void 0x0,_0x434f9a=_0x145dd1['_redirectEventId']??void 0x0,_0x302b6b=_0x145dd1['createdAt']??void 0x0,_0x5d647f=_0x145dd1['lastLoginAt']??void 0x0,{uid:_0x41c2cd,emailVerified:_0x5f4250,isAnonymous:_0x1f97d5,providerData:_0xfc52f5,stsTokenManager:_0x1296dc}=_0x145dd1;m(_0x41c2cd&&_0x1296dc,_0x2e96d6,'internal-error');const _0x29f6ac=et['fromJSON'](this['name'],_0x1296dc);m(typeof _0x41c2cd=='string',_0x2e96d6,'internal-error'),le(_0x554e33,_0x2e96d6['name']),le(_0x12c9ae,_0x2e96d6['name']),m(typeof _0x5f4250=='boolean',_0x2e96d6,'internal-error'),m(typeof _0x1f97d5=='boolean',_0x2e96d6,'internal-error'),le(_0x2a7a77,_0x2e96d6['name']),le(_0x762e61,_0x2e96d6['name']),le(_0x39f957,_0x2e96d6['name']),le(_0x434f9a,_0x2e96d6['name']),le(_0x302b6b,_0x2e96d6['name']),le(_0x5d647f,_0x2e96d6['name']);const _0x1d28f4=new j({'uid':_0x41c2cd,'auth':_0x2e96d6,'email':_0x12c9ae,'emailVerified':_0x5f4250,'displayName':_0x554e33,'isAnonymous':_0x1f97d5,'photoURL':_0x762e61,'phoneNumber':_0x2a7a77,'tenantId':_0x39f957,'stsTokenManager':_0x29f6ac,'createdAt':_0x302b6b,'lastLoginAt':_0x5d647f});return _0xfc52f5&&Array['isArray'](_0xfc52f5)&&(_0x1d28f4['providerData']=_0xfc52f5['map'](_0x4d23b9=>({..._0x4d23b9}))),_0x434f9a&&(_0x1d28f4['_redirectEventId']=_0x434f9a),_0x1d28f4;}static async['_fromIdTokenResponse'](_0x463613,_0x34befe,_0x4acb2d=!0x1){const _0x14e1d9=new et();_0x14e1d9['updateFromServerResponse'](_0x34befe);const _0x51da23=new j({'uid':_0x34befe['localId'],'auth':_0x463613,'stsTokenManager':_0x14e1d9,'isAnonymous':_0x4acb2d});return await Nn(_0x51da23),_0x51da23;}static async['_fromGetAccountInfoResponse'](_0x289824,_0x1270e5,_0x4be4bc){const _0x64495d=_0x1270e5['users'][0x0];m(_0x64495d['localId']!==void 0x0,'internal-error');const _0x1c87a7=_0x64495d['providerUserInfo']!==void 0x0?Sa(_0x64495d['providerUserInfo']):[],_0x223e0e=!(_0x64495d['email']&&_0x64495d['passwordHash'])&&!(_0x1c87a7!=null&&_0x1c87a7['length']),_0x377ff8=new et();_0x377ff8['updateFromIdToken'](_0x4be4bc);const _0x3ba050=new j({'uid':_0x64495d['localId'],'auth':_0x289824,'stsTokenManager':_0x377ff8,'isAnonymous':_0x223e0e}),_0xc08ef9={'uid':_0x64495d['localId'],'displayName':_0x64495d['displayName']||null,'photoURL':_0x64495d['photoUrl']||null,'email':_0x64495d['email']||null,'emailVerified':_0x64495d['emailVerified']||!0x1,'phoneNumber':_0x64495d['phoneNumber']||null,'tenantId':_0x64495d['tenantId']||null,'providerData':_0x1c87a7,'metadata':new Li(_0x64495d['createdAt'],_0x64495d['lastLoginAt']),'isAnonymous':!(_0x64495d['email']&&_0x64495d['passwordHash'])&&!(_0x1c87a7!=null&&_0x1c87a7['length'])};return Object['assign'](_0x3ba050,_0xc08ef9),_0x3ba050;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5ed6aa){ce(_0x5ed6aa instanceof Function,'Expected\x20a\x20class\x20definition');let _0xa2f142=Tr['get'](_0x5ed6aa);return _0xa2f142?(ce(_0xa2f142 instanceof _0x5ed6aa,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xa2f142):(_0xa2f142=new _0x5ed6aa(),Tr['set'](_0x5ed6aa,_0xa2f142),_0xa2f142);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x32055f,_0x304a71){this['storage'][_0x32055f]=_0x304a71;}async['_get'](_0x236009){const _0x3b6c95=this['storage'][_0x236009];return _0x3b6c95===void 0x0?null:_0x3b6c95;}async['_remove'](_0x2e4aa8){delete this['storage'][_0x2e4aa8];}['_addListener'](_0x4e1d93,_0x6f2a3f){}['_removeListener'](_0x434491,_0xf80b78){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x5e47de,_0xbac408,_0x146dc0){return'firebase:'+_0x5e47de+':'+_0xbac408+':'+_0x146dc0;}class tt{constructor(_0x4266cf,_0x2f96fb,_0x20cd71){this['persistence']=_0x4266cf,this['auth']=_0x2f96fb,this['userKey']=_0x20cd71;const {config:_0x3f2fab,name:_0x28a0db}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x3f2fab['apiKey'],_0x28a0db),this['fullPersistenceKey']=ln('persistence',_0x3f2fab['apiKey'],_0x28a0db),this['boundEventHandler']=_0x2f96fb['_onStorageEvent']['bind'](_0x2f96fb),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xbb0a0d){return this['persistence']['_set'](this['fullUserKey'],_0xbb0a0d['toJSON']());}async['getCurrentUser'](){const _0x113b2a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x113b2a)return null;if(typeof _0x113b2a=='string'){const _0x3305bf=await Pn(this['auth'],{'idToken':_0x113b2a})['catch'](()=>{});return _0x3305bf?j['_fromGetAccountInfoResponse'](this['auth'],_0x3305bf,_0x113b2a):null;}return j['_fromJSON'](this['auth'],_0x113b2a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3eda96){if(this['persistence']===_0x3eda96)return;const _0x1489bc=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3eda96,_0x1489bc)return this['setCurrentUser'](_0x1489bc);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x169189,_0x490a12,_0x521bc5='authUser'){if(!_0x490a12['length'])return new tt(ie(Sr),_0x169189,_0x521bc5);const _0x24c9bd=(await Promise['all'](_0x490a12['map'](async _0x10d398=>{if(await _0x10d398['_isAvailable']())return _0x10d398;})))['filter'](_0x48376d=>_0x48376d);let _0x580324=_0x24c9bd[0x0]||ie(Sr);const _0x1142c1=ln(_0x521bc5,_0x169189['config']['apiKey'],_0x169189['name']);let _0x211241=null;for(const _0x3f51a2 of _0x490a12)try{const _0x52dc9b=await _0x3f51a2['_get'](_0x1142c1);if(_0x52dc9b){let _0x424af1;if(typeof _0x52dc9b=='string'){const _0x1055c5=await Pn(_0x169189,{'idToken':_0x52dc9b})['catch'](()=>{});if(!_0x1055c5)break;_0x424af1=await j['_fromGetAccountInfoResponse'](_0x169189,_0x1055c5,_0x52dc9b);}else _0x424af1=j['_fromJSON'](_0x169189,_0x52dc9b);_0x3f51a2!==_0x580324&&(_0x211241=_0x424af1),_0x580324=_0x3f51a2;break;}}catch{}const _0x2bc031=_0x24c9bd['filter'](_0x35cb9e=>_0x35cb9e['_shouldAllowMigration']);return!_0x580324['_shouldAllowMigration']||!_0x2bc031['length']?new tt(_0x580324,_0x169189,_0x521bc5):(_0x580324=_0x2bc031[0x0],_0x211241&&await _0x580324['_set'](_0x1142c1,_0x211241['toJSON']()),await Promise['all'](_0x490a12['map'](async _0x48de16=>{if(_0x48de16!==_0x580324)try{await _0x48de16['_remove'](_0x1142c1);}catch{}})),new tt(_0x580324,_0x169189,_0x521bc5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x338c15){const _0x51a565=_0x338c15['toLowerCase']();if(_0x51a565['includes']('opera/')||_0x51a565['includes']('opr/')||_0x51a565['includes']('opios/'))return'Opera';if(Pa(_0x51a565))return'IEMobile';if(_0x51a565['includes']('msie')||_0x51a565['includes']('trident/'))return'IE';if(_0x51a565['includes']('edge/'))return'Edge';if(Ra(_0x51a565))return'Firefox';if(_0x51a565['includes']('silk/'))return'Silk';if(Oa(_0x51a565))return'Blackberry';if(Da(_0x51a565))return'Webos';if(Aa(_0x51a565))return'Safari';if((_0x51a565['includes']('chrome/')||ka(_0x51a565))&&!_0x51a565['includes']('edge/'))return'Chrome';if(Na(_0x51a565))return'Android';{const _0x12b870=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xb20438=_0x338c15['match'](_0x12b870);if((_0xb20438==null?void 0x0:_0xb20438['length'])===0x2)return _0xb20438[0x1];}return'Other';}function Ra(_0x1c2491=W()){return/firefox\//i['test'](_0x1c2491);}function Aa(_0x298f52=W()){const _0xa28d9b=_0x298f52['toLowerCase']();return _0xa28d9b['includes']('safari/')&&!_0xa28d9b['includes']('chrome/')&&!_0xa28d9b['includes']('crios/')&&!_0xa28d9b['includes']('android');}function ka(_0x32bc17=W()){return/crios\//i['test'](_0x32bc17);}function Pa(_0x37350f=W()){return/iemobile/i['test'](_0x37350f);}function Na(_0x538368=W()){return/android/i['test'](_0x538368);}function Oa(_0x2184e6=W()){return/blackberry/i['test'](_0x2184e6);}function Da(_0x47f932=W()){return/webos/i['test'](_0x47f932);}function Ss(_0x1932a6=W()){return/iphone|ipad|ipod/i['test'](_0x1932a6)||/macintosh/i['test'](_0x1932a6)&&/mobile/i['test'](_0x1932a6);}function Rf(_0x28a0b2=W()){var _0x478a77;return Ss(_0x28a0b2)&&!!((_0x478a77=window['navigator'])!=null&&_0x478a77['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5e1310=W()){return Ss(_0x5e1310)||Na(_0x5e1310)||Da(_0x5e1310)||Oa(_0x5e1310)||/windows phone/i['test'](_0x5e1310)||Pa(_0x5e1310);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x15bae0,_0x584b29=[]){let _0x1bd4a5;switch(_0x15bae0){case'Browser':_0x1bd4a5=br(W());break;case'Worker':_0x1bd4a5=br(W())+'-'+_0x15bae0;break;default:_0x1bd4a5=_0x15bae0;}const _0x2f3ddd=_0x584b29['length']?_0x584b29['join'](','):'FirebaseCore-web';return _0x1bd4a5+'/JsCore/'+dt+'/'+_0x2f3ddd;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x2cc179){this['auth']=_0x2cc179,this['queue']=[];}['pushCallback'](_0x2e8c0b,_0x49d7b1){const _0x39c927=_0x396338=>new Promise((_0xc0cbc1,_0xe6397b)=>{try{const _0x51b3bc=_0x2e8c0b(_0x396338);_0xc0cbc1(_0x51b3bc);}catch(_0x4aeeb1){_0xe6397b(_0x4aeeb1);}});_0x39c927['onAbort']=_0x49d7b1,this['queue']['push'](_0x39c927);const _0x4743b8=this['queue']['length']-0x1;return()=>{this['queue'][_0x4743b8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3302bf){if(this['auth']['currentUser']===_0x3302bf)return;const _0x273dda=[];try{for(const _0x562414 of this['queue'])await _0x562414(_0x3302bf),_0x562414['onAbort']&&_0x273dda['push'](_0x562414['onAbort']);}catch(_0x404173){_0x273dda['reverse']();for(const _0x334388 of _0x273dda)try{_0x334388();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x404173==null?void 0x0:_0x404173['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x42190e,_0x3a9d97={}){return Pe(_0x42190e,'GET','/v2/passwordPolicy',ke(_0x42190e,_0x3a9d97));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x1e9927){var _0x3b6025;const _0x32b4bb=_0x1e9927['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x32b4bb['minPasswordLength']??Nf,_0x32b4bb['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x32b4bb['maxPasswordLength']),_0x32b4bb['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x32b4bb['containsLowercaseCharacter']),_0x32b4bb['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x32b4bb['containsUppercaseCharacter']),_0x32b4bb['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x32b4bb['containsNumericCharacter']),_0x32b4bb['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x32b4bb['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1e9927['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3b6025=_0x1e9927['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3b6025['join'](''))??'',this['forceUpgradeOnSignin']=_0x1e9927['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1e9927['schemaVersion'];}['validatePassword'](_0x4dd0e3){const _0x3b1999={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4dd0e3,_0x3b1999),this['validatePasswordCharacterOptions'](_0x4dd0e3,_0x3b1999),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['meetsMinPasswordLength']??!0x0),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['meetsMaxPasswordLength']??!0x0),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['containsLowercaseLetter']??!0x0),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['containsUppercaseLetter']??!0x0),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['containsNumericCharacter']??!0x0),_0x3b1999['isValid']&&(_0x3b1999['isValid']=_0x3b1999['containsNonAlphanumericCharacter']??!0x0),_0x3b1999;}['validatePasswordLengthOptions'](_0x11138a,_0x32cdcb){const _0x352408=this['customStrengthOptions']['minPasswordLength'],_0x857cc5=this['customStrengthOptions']['maxPasswordLength'];_0x352408&&(_0x32cdcb['meetsMinPasswordLength']=_0x11138a['length']>=_0x352408),_0x857cc5&&(_0x32cdcb['meetsMaxPasswordLength']=_0x11138a['length']<=_0x857cc5);}['validatePasswordCharacterOptions'](_0x24eba3,_0x44eb6e){this['updatePasswordCharacterOptionsStatuses'](_0x44eb6e,!0x1,!0x1,!0x1,!0x1);let _0x56b367;for(let _0x3885e4=0x0;_0x3885e4<_0x24eba3['length'];_0x3885e4++)_0x56b367=_0x24eba3['charAt'](_0x3885e4),this['updatePasswordCharacterOptionsStatuses'](_0x44eb6e,_0x56b367>='a'&&_0x56b367<='z',_0x56b367>='A'&&_0x56b367<='Z',_0x56b367>='0'&&_0x56b367<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x56b367));}['updatePasswordCharacterOptionsStatuses'](_0x5af81b,_0x1183d3,_0x50df25,_0x389ee0,_0x358876){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5af81b['containsLowercaseLetter']||(_0x5af81b['containsLowercaseLetter']=_0x1183d3)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5af81b['containsUppercaseLetter']||(_0x5af81b['containsUppercaseLetter']=_0x50df25)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5af81b['containsNumericCharacter']||(_0x5af81b['containsNumericCharacter']=_0x389ee0)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5af81b['containsNonAlphanumericCharacter']||(_0x5af81b['containsNonAlphanumericCharacter']=_0x358876));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x31669e,_0x56d640,_0x485560,_0x428a02){this['app']=_0x31669e,this['heartbeatServiceProvider']=_0x56d640,this['appCheckServiceProvider']=_0x485560,this['config']=_0x428a02,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x31669e['name'],this['clientVersion']=_0x428a02['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1b8bfb=>this['_resolvePersistenceManagerAvailable']=_0x1b8bfb);}['_initializeWithPersistence'](_0x1c8949,_0x3b7cf1){return _0x3b7cf1&&(this['_popupRedirectResolver']=ie(_0x3b7cf1)),this['_initializationPromise']=this['queue'](async()=>{var _0x171fbe,_0x51f66d,_0x21c41f;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x1c8949),(_0x171fbe=this['_resolvePersistenceManagerAvailable'])==null||_0x171fbe['call'](this),!this['_deleted'])){if((_0x51f66d=this['_popupRedirectResolver'])!=null&&_0x51f66d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3b7cf1),this['lastNotifiedUid']=((_0x21c41f=this['currentUser'])==null?void 0x0:_0x21c41f['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2ea21e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2ea21e)){if(this['currentUser']&&_0x2ea21e&&this['currentUser']['uid']===_0x2ea21e['uid']){this['_currentUser']['_assign'](_0x2ea21e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2ea21e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4e125f){try{const _0x5d03ae=await Pn(this,{'idToken':_0x4e125f}),_0x52c346=await j['_fromGetAccountInfoResponse'](this,_0x5d03ae,_0x4e125f);await this['directlySetCurrentUser'](_0x52c346);}catch(_0x7d4a46){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x7d4a46),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x330548){var _0x352f06;if($(this['app'])){const _0x3f13ce=this['app']['settings']['authIdToken'];return _0x3f13ce?new Promise(_0x3faa39=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3f13ce)['then'](_0x3faa39,_0x3faa39));}):this['directlySetCurrentUser'](null);}const _0x2a7545=await this['assertedPersistence']['getCurrentUser']();let _0x522fbc=_0x2a7545,_0xe40255=!0x1;if(_0x330548&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x157621=(_0x352f06=this['redirectUser'])==null?void 0x0:_0x352f06['_redirectEventId'],_0x2b2080=_0x522fbc==null?void 0x0:_0x522fbc['_redirectEventId'],_0x43651f=await this['tryRedirectSignIn'](_0x330548);(!_0x157621||_0x157621===_0x2b2080)&&(_0x43651f!=null&&_0x43651f['user'])&&(_0x522fbc=_0x43651f['user'],_0xe40255=!0x0);}if(!_0x522fbc)return this['directlySetCurrentUser'](null);if(!_0x522fbc['_redirectEventId']){if(_0xe40255)try{await this['beforeStateQueue']['runMiddleware'](_0x522fbc);}catch(_0x13fe37){_0x522fbc=_0x2a7545,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x13fe37));}return _0x522fbc?this['reloadAndSetCurrentUserOrClear'](_0x522fbc):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x522fbc['_redirectEventId']?this['directlySetCurrentUser'](_0x522fbc):this['reloadAndSetCurrentUserOrClear'](_0x522fbc);}async['tryRedirectSignIn'](_0x59962c){let _0x110b86=null;try{_0x110b86=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x59962c,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x110b86;}async['reloadAndSetCurrentUserOrClear'](_0x3217f0){try{await Nn(_0x3217f0);}catch(_0x46d7b6){if((_0x46d7b6==null?void 0x0:_0x46d7b6['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3217f0);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xbbcc66){if($(this['app']))return Promise['reject'](re(this));const _0x2d784c=_0xbbcc66?P(_0xbbcc66):null;return _0x2d784c&&m(_0x2d784c['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2d784c&&_0x2d784c['_clone'](this));}async['_updateCurrentUser'](_0x5dd703,_0x725331=!0x1){if(!this['_deleted'])return _0x5dd703&&m(this['tenantId']===_0x5dd703['tenantId'],this,'tenant-id-mismatch'),_0x725331||await this['beforeStateQueue']['runMiddleware'](_0x5dd703),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x5dd703),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x22a703){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x22a703));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3ec2ea){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1c449e=this['_getPasswordPolicyInternal']();return _0x1c449e['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1c449e['validatePassword'](_0x3ec2ea);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x48c502=await Pf(this),_0x569a54=new Of(_0x48c502);this['tenantId']===null?this['_projectPasswordPolicy']=_0x569a54:this['_tenantPasswordPolicies'][this['tenantId']]=_0x569a54;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5df05f){this['_errorFactory']=new Gt('auth','Firebase',_0x5df05f());}['onAuthStateChanged'](_0x63188b,_0x1fb3af,_0x2bd53d){return this['registerStateListener'](this['authStateSubscription'],_0x63188b,_0x1fb3af,_0x2bd53d);}['beforeAuthStateChanged'](_0x371f63,_0x393c5c){return this['beforeStateQueue']['pushCallback'](_0x371f63,_0x393c5c);}['onIdTokenChanged'](_0x4fdc98,_0x3c9626,_0x134402){return this['registerStateListener'](this['idTokenSubscription'],_0x4fdc98,_0x3c9626,_0x134402);}['authStateReady'](){return new Promise((_0x570bba,_0x4723fe)=>{if(this['currentUser'])_0x570bba();else{const _0x49b7c7=this['onAuthStateChanged'](()=>{_0x49b7c7(),_0x570bba();},_0x4723fe);}});}async['revokeAccessToken'](_0x4c2bd6){if(this['currentUser']){const _0x8de49c=await this['currentUser']['getIdToken'](),_0x285f3f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4c2bd6,'idToken':_0x8de49c};this['tenantId']!=null&&(_0x285f3f['tenantId']=this['tenantId']),await bf(this,_0x285f3f);}}['toJSON'](){var _0x2493dc;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2493dc=this['_currentUser'])==null?void 0x0:_0x2493dc['toJSON']()};}async['_setRedirectUser'](_0x54b208,_0x2b5f8e){const _0xf732b5=await this['getOrInitRedirectPersistenceManager'](_0x2b5f8e);return _0x54b208===null?_0xf732b5['removeCurrentUser']():_0xf732b5['setCurrentUser'](_0x54b208);}async['getOrInitRedirectPersistenceManager'](_0x2951c3){if(!this['redirectPersistenceManager']){const _0x3013ce=_0x2951c3&&ie(_0x2951c3)||this['_popupRedirectResolver'];m(_0x3013ce,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3013ce['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x9bd00b){var _0x1ada98,_0x30ae22;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x1ada98=this['_currentUser'])==null?void 0x0:_0x1ada98['_redirectEventId'])===_0x9bd00b?this['_currentUser']:((_0x30ae22=this['redirectUser'])==null?void 0x0:_0x30ae22['_redirectEventId'])===_0x9bd00b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x447e08){if(_0x447e08===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x447e08));}['_notifyListenersIfCurrent'](_0x132016){_0x132016===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x405b0a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xb8910c=((_0x405b0a=this['currentUser'])==null?void 0x0:_0x405b0a['uid'])??null;this['lastNotifiedUid']!==_0xb8910c&&(this['lastNotifiedUid']=_0xb8910c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1d6e2b,_0x3e2d22,_0x5e583d,_0x3e3681){if(this['_deleted'])return()=>{};const _0x49f2f2=typeof _0x3e2d22=='function'?_0x3e2d22:_0x3e2d22['next']['bind'](_0x3e2d22);let _0x4d2377=!0x1;const _0xc23bf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xc23bf,this,'internal-error'),_0xc23bf['then'](()=>{_0x4d2377||_0x49f2f2(this['currentUser']);}),typeof _0x3e2d22=='function'){const _0x50eb05=_0x1d6e2b['addObserver'](_0x3e2d22,_0x5e583d,_0x3e3681);return()=>{_0x4d2377=!0x0,_0x50eb05();};}else{const _0x31189d=_0x1d6e2b['addObserver'](_0x3e2d22);return()=>{_0x4d2377=!0x0,_0x31189d();};}}async['directlySetCurrentUser'](_0x1768df){this['currentUser']&&this['currentUser']!==_0x1768df&&this['_currentUser']['_stopProactiveRefresh'](),_0x1768df&&this['isProactiveRefreshEnabled']&&_0x1768df['_startProactiveRefresh'](),this['currentUser']=_0x1768df,_0x1768df?await this['assertedPersistence']['setCurrentUser'](_0x1768df):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x47a25f){return this['operations']=this['operations']['then'](_0x47a25f,_0x47a25f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2114e6){!_0x2114e6||this['frameworks']['includes'](_0x2114e6)||(this['frameworks']['push'](_0x2114e6),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x2933a2;const _0x3fb74e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3fb74e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x25fe66=await((_0x2933a2=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2933a2['getHeartbeatsHeader']());_0x25fe66&&(_0x3fb74e['X-Firebase-Client']=_0x25fe66);const _0x4422fb=await this['_getAppCheckToken']();return _0x4422fb&&(_0x3fb74e['X-Firebase-AppCheck']=_0x4422fb),_0x3fb74e;}async['_getAppCheckToken'](){var _0x1205b6;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x25336e=await((_0x1205b6=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1205b6['getToken']());return _0x25336e!=null&&_0x25336e['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x25336e['error']),_0x25336e==null?void 0x0:_0x25336e['token'];}}function Ke(_0x4acdbb){return P(_0x4acdbb);}class Rr{constructor(_0x236454){this['auth']=_0x236454,this['observer']=null,this['addObserver']=Tc(_0x2bf29f=>this['observer']=_0x2bf29f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2176ae){Jn=_0x2176ae;}function xa(_0x3e8e79){return Jn['loadJS'](_0x3e8e79);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x152e9f){return'__'+_0x152e9f+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x25fc09){_0x25fc09();}['execute'](_0x229490,_0x4bfacf){return Promise['resolve']('token');}['render'](_0x58383d,_0x2e588b){return'';}}class Wf{['ready'](_0x56052b){_0x56052b();}['execute'](_0x392e4f,_0x18d6df){return Promise['resolve']('token');}['render'](_0x4d8c16,_0x444922){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x556e1d){this['type']=Bf,this['auth']=Ke(_0x556e1d);}async['verify'](_0x2c724b='verify',_0x42f7dd=!0x1){async function _0xe52f02(_0x5d02bd){if(!_0x42f7dd){if(_0x5d02bd['tenantId']==null&&_0x5d02bd['_agentRecaptchaConfig']!=null)return _0x5d02bd['_agentRecaptchaConfig']['siteKey'];if(_0x5d02bd['tenantId']!=null&&_0x5d02bd['_tenantRecaptchaConfigs'][_0x5d02bd['tenantId']]!==void 0x0)return _0x5d02bd['_tenantRecaptchaConfigs'][_0x5d02bd['tenantId']]['siteKey'];}return new Promise(async(_0x3cfb78,_0x4a9f94)=>{yf(_0x5d02bd,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2dc40f=>{if(_0x2dc40f['recaptchaKey']===void 0x0)_0x4a9f94(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xe0e18a=new mf(_0x2dc40f);return _0x5d02bd['tenantId']==null?_0x5d02bd['_agentRecaptchaConfig']=_0xe0e18a:_0x5d02bd['_tenantRecaptchaConfigs'][_0x5d02bd['tenantId']]=_0xe0e18a,_0x3cfb78(_0xe0e18a['siteKey']);}})['catch'](_0x19d908=>{_0x4a9f94(_0x19d908);});});}function _0x1c0129(_0x2805de,_0x5bee2e,_0xa906be){const _0x483ec8=window['grecaptcha'];wr(_0x483ec8)?_0x483ec8['enterprise']['ready'](()=>{_0x483ec8['enterprise']['execute'](_0x2805de,{'action':_0x2c724b})['then'](_0x5e559e=>{_0x5bee2e(_0x5e559e);})['catch'](()=>{_0x5bee2e(Fa);});}):_0xa906be(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x311a26,_0xfbb878)=>{_0xe52f02(this['auth'])['then'](async _0x1a52c1=>{if(!_0x42f7dd&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x1c0129(_0x1a52c1,_0x311a26,_0xfbb878);else{if(typeof window>'u'){_0xfbb878(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xb9c2cc=Lf();_0xb9c2cc['length']!==0x0&&(_0xb9c2cc+=_0x1a52c1+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x17d172;(_0x17d172=he['scriptInjectionDeferred'])==null||_0x17d172['resolve']();},xa(_0xb9c2cc)['then'](()=>{var _0x544da;return(_0x544da=he['scriptInjectionDeferred'])==null?void 0x0:_0x544da['promise'];})['then'](()=>{_0x1c0129(_0x1a52c1,_0x311a26,_0xfbb878);})['catch'](_0x2ead5b=>{_0xfbb878(_0x2ead5b);});}})['catch'](_0x5979fe=>{_0xfbb878(_0x5979fe);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5dd341,_0x60304d,_0x20100a,_0x2a17b6=!0x1,_0x301332=!0x1){const _0x39e86e=new he(_0x5dd341);let _0x43ecbd;if(_0x301332)_0x43ecbd=Fa;else try{_0x43ecbd=await _0x39e86e['verify'](_0x20100a);}catch{_0x43ecbd=await _0x39e86e['verify'](_0x20100a,!0x0);}const _0x5883f8={..._0x60304d};if(_0x20100a==='mfaSmsEnrollment'||_0x20100a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5883f8){const _0x5a625d=_0x5883f8['phoneEnrollmentInfo']['phoneNumber'],_0xe33796=_0x5883f8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5883f8,{'phoneEnrollmentInfo':{'phoneNumber':_0x5a625d,'recaptchaToken':_0xe33796,'captchaResponse':_0x43ecbd,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5883f8){const _0x9063eb=_0x5883f8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5883f8,{'phoneSignInInfo':{'recaptchaToken':_0x9063eb,'captchaResponse':_0x43ecbd,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5883f8;}return _0x2a17b6?Object['assign'](_0x5883f8,{'captchaResp':_0x43ecbd}):Object['assign'](_0x5883f8,{'captchaResponse':_0x43ecbd}),Object['assign'](_0x5883f8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5883f8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5883f8;}async function xi(_0x803c3d,_0x3337ed,_0x2ef663,_0x5f2e20,_0x564d19){var _0x4cf36e;if((_0x4cf36e=_0x803c3d['_getRecaptchaConfig']())!=null&&_0x4cf36e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x2bfcc0=await kr(_0x803c3d,_0x3337ed,_0x2ef663,_0x2ef663==='getOobCode');return _0x5f2e20(_0x803c3d,_0x2bfcc0);}else return _0x5f2e20(_0x803c3d,_0x3337ed)['catch'](async _0x2fe73c=>{if(_0x2fe73c['code']==='auth/missing-recaptcha-token'){console['log'](_0x2ef663+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2263ac=await kr(_0x803c3d,_0x3337ed,_0x2ef663,_0x2ef663==='getOobCode');return _0x5f2e20(_0x803c3d,_0x2263ac);}else return Promise['reject'](_0x2fe73c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x5945db,_0x19a00a){const _0x2f3038=Hi(_0x5945db,'auth');if(_0x2f3038['isInitialized']()){const _0x16450b=_0x2f3038['getImmediate'](),_0x1c7832=_0x2f3038['getOptions']();if(xe(_0x1c7832,_0x19a00a??{}))return _0x16450b;Y(_0x16450b,'already-initialized');}return _0x2f3038['initialize']({'options':_0x19a00a});}function Hf(_0x494117,_0x526dac){const _0x1e3cc2=(_0x526dac==null?void 0x0:_0x526dac['persistence'])||[],_0x51757d=(Array['isArray'](_0x1e3cc2)?_0x1e3cc2:[_0x1e3cc2])['map'](ie);_0x526dac!=null&&_0x526dac['errorMap']&&_0x494117['_updateErrorMap'](_0x526dac['errorMap']),_0x494117['_initializeWithPersistence'](_0x51757d,_0x526dac==null?void 0x0:_0x526dac['popupRedirectResolver']);}function $f(_0x3a72b6,_0x8caf76,_0x562446){const _0x1f846c=Ke(_0x3a72b6);m(/^https?:\/\//['test'](_0x8caf76),_0x1f846c,'invalid-emulator-scheme');const _0x528eff=!0x1,_0x2fd21d=Ua(_0x8caf76),{host:_0x42b9fa,port:_0x38f449}=Gf(_0x8caf76),_0x574704=_0x38f449===null?'':':'+_0x38f449,_0x3e9064={'url':_0x2fd21d+'//'+_0x42b9fa+_0x574704+'/'},_0xd8079c=Object['freeze']({'host':_0x42b9fa,'port':_0x38f449,'protocol':_0x2fd21d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x528eff})});if(!_0x1f846c['_canInitEmulator']){m(_0x1f846c['config']['emulator']&&_0x1f846c['emulatorConfig'],_0x1f846c,'emulator-config-failed'),m(xe(_0x3e9064,_0x1f846c['config']['emulator'])&&xe(_0xd8079c,_0x1f846c['emulatorConfig']),_0x1f846c,'emulator-config-failed');return;}_0x1f846c['config']['emulator']=_0x3e9064,_0x1f846c['emulatorConfig']=_0xd8079c,_0x1f846c['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x42b9fa)?Qr(_0x2fd21d+'//'+_0x42b9fa+_0x574704):qf();}function Ua(_0x21c27e){const _0x3992f8=_0x21c27e['indexOf'](':');return _0x3992f8<0x0?'':_0x21c27e['substr'](0x0,_0x3992f8+0x1);}function Gf(_0x4607a5){const _0x251c3f=Ua(_0x4607a5),_0x55210d=/(\/\/)?([^?#/]+)/['exec'](_0x4607a5['substr'](_0x251c3f['length']));if(!_0x55210d)return{'host':'','port':null};const _0x17490f=_0x55210d[0x2]['split']('@')['pop']()||'',_0x738449=/^(\[[^\]]+\])(:|$)/['exec'](_0x17490f);if(_0x738449){const _0x5706ea=_0x738449[0x1];return{'host':_0x5706ea,'port':Pr(_0x17490f['substr'](_0x5706ea['length']+0x1))};}else{const [_0x389aeb,_0x1d30e7]=_0x17490f['split'](':');return{'host':_0x389aeb,'port':Pr(_0x1d30e7)};}}function Pr(_0x3c8db1){if(!_0x3c8db1)return null;const _0x55385d=Number(_0x3c8db1);return isNaN(_0x55385d)?null:_0x55385d;}function qf(){function _0x33c306(){const _0x24fda3=document['createElement']('p'),_0x4d908a=_0x24fda3['style'];_0x24fda3['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4d908a['position']='fixed',_0x4d908a['width']='100%',_0x4d908a['backgroundColor']='#ffffff',_0x4d908a['border']='.1em\x20solid\x20#000000',_0x4d908a['color']='#b50000',_0x4d908a['bottom']='0px',_0x4d908a['left']='0px',_0x4d908a['margin']='0px',_0x4d908a['zIndex']='10000',_0x4d908a['textAlign']='center',_0x24fda3['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x24fda3);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x33c306):_0x33c306());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x15d99f,_0x2de103){this['providerId']=_0x15d99f,this['signInMethod']=_0x2de103;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2dc8e9){return ne('not\x20implemented');}['_linkToIdToken'](_0x239f67,_0x5b9e9c){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2adadb){return ne('not\x20implemented');}}async function zf(_0x235b4f,_0x3daa90){return Pe(_0x235b4f,'POST','/v1/accounts:signUp',_0x3daa90);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x529b7b,_0x1aae9b){return en(_0x529b7b,'POST','/v1/accounts:signInWithPassword',ke(_0x529b7b,_0x1aae9b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xa829ef,_0x258ad3){return en(_0xa829ef,'POST','/v1/accounts:signInWithEmailLink',ke(_0xa829ef,_0x258ad3));}async function Yf(_0x492c44,_0x43648a){return en(_0x492c44,'POST','/v1/accounts:signInWithEmailLink',ke(_0x492c44,_0x43648a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x2e5a53,_0x6bfa07,_0x338bd3,_0x2ef58f=null){super('password',_0x338bd3),this['_email']=_0x2e5a53,this['_password']=_0x6bfa07,this['_tenantId']=_0x2ef58f;}static['_fromEmailAndPassword'](_0x122d00,_0x3a1b66){return new $t(_0x122d00,_0x3a1b66,'password');}static['_fromEmailAndCode'](_0x44669c,_0x59d4da,_0x5d1f29=null){return new $t(_0x44669c,_0x59d4da,'emailLink',_0x5d1f29);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x46fc2d){const _0x6f870c=typeof _0x46fc2d=='string'?JSON['parse'](_0x46fc2d):_0x46fc2d;if(_0x6f870c!=null&&_0x6f870c['email']&&(_0x6f870c!=null&&_0x6f870c['password'])){if(_0x6f870c['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x6f870c['email'],_0x6f870c['password']);if(_0x6f870c['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x6f870c['email'],_0x6f870c['password'],_0x6f870c['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4e3031){switch(this['signInMethod']){case'password':const _0x4f491c={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4e3031,_0x4f491c,'signInWithPassword',jf);case'emailLink':return Kf(_0x4e3031,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4e3031,'internal-error');}}async['_linkToIdToken'](_0x19015e,_0x5403da){switch(this['signInMethod']){case'password':const _0x53c3e2={'idToken':_0x5403da,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x19015e,_0x53c3e2,'signUpPassword',zf);case'emailLink':return Yf(_0x19015e,{'idToken':_0x5403da,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x19015e,'internal-error');}}['_getReauthenticationResolver'](_0x29d0be){return this['_getIdTokenResponse'](_0x29d0be);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2cb464,_0x4ac250){return en(_0x2cb464,'POST','/v1/accounts:signInWithIdp',ke(_0x2cb464,_0x4ac250));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x167749){const _0x46d6e8=new $e(_0x167749['providerId'],_0x167749['signInMethod']);return _0x167749['idToken']||_0x167749['accessToken']?(_0x167749['idToken']&&(_0x46d6e8['idToken']=_0x167749['idToken']),_0x167749['accessToken']&&(_0x46d6e8['accessToken']=_0x167749['accessToken']),_0x167749['nonce']&&!_0x167749['pendingToken']&&(_0x46d6e8['nonce']=_0x167749['nonce']),_0x167749['pendingToken']&&(_0x46d6e8['pendingToken']=_0x167749['pendingToken'])):_0x167749['oauthToken']&&_0x167749['oauthTokenSecret']?(_0x46d6e8['accessToken']=_0x167749['oauthToken'],_0x46d6e8['secret']=_0x167749['oauthTokenSecret']):Y('argument-error'),_0x46d6e8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x158425){const _0x45da30=typeof _0x158425=='string'?JSON['parse'](_0x158425):_0x158425,{providerId:_0xdaa3e5,signInMethod:_0x431595,..._0x3a953f}=_0x45da30;if(!_0xdaa3e5||!_0x431595)return null;const _0x13dafb=new $e(_0xdaa3e5,_0x431595);return _0x13dafb['idToken']=_0x3a953f['idToken']||void 0x0,_0x13dafb['accessToken']=_0x3a953f['accessToken']||void 0x0,_0x13dafb['secret']=_0x3a953f['secret'],_0x13dafb['nonce']=_0x3a953f['nonce'],_0x13dafb['pendingToken']=_0x3a953f['pendingToken']||null,_0x13dafb;}['_getIdTokenResponse'](_0x220ea9){const _0x15fc9c=this['buildRequest']();return nt(_0x220ea9,_0x15fc9c);}['_linkToIdToken'](_0x221e0c,_0x1f3901){const _0x35aef9=this['buildRequest']();return _0x35aef9['idToken']=_0x1f3901,nt(_0x221e0c,_0x35aef9);}['_getReauthenticationResolver'](_0x1a0757){const _0x3ca780=this['buildRequest']();return _0x3ca780['autoCreate']=!0x1,nt(_0x1a0757,_0x3ca780);}['buildRequest'](){const _0x37d9b6={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x37d9b6['pendingToken']=this['pendingToken'];else{const _0x72aa58={};this['idToken']&&(_0x72aa58['id_token']=this['idToken']),this['accessToken']&&(_0x72aa58['access_token']=this['accessToken']),this['secret']&&(_0x72aa58['oauth_token_secret']=this['secret']),_0x72aa58['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x72aa58['nonce']=this['nonce']),_0x37d9b6['postBody']=ut(_0x72aa58);}return _0x37d9b6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2cee90){switch(_0x2cee90){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x2a656a){const _0x40b3b6=Ct(Tt(_0x2a656a))['link'],_0x29f74d=_0x40b3b6?Ct(Tt(_0x40b3b6))['deep_link_id']:null,_0x36b6bd=Ct(Tt(_0x2a656a))['deep_link_id'];return(_0x36b6bd?Ct(Tt(_0x36b6bd))['link']:null)||_0x36b6bd||_0x29f74d||_0x40b3b6||_0x2a656a;}class Rs{constructor(_0x217daf){const _0x51ca94=Ct(Tt(_0x217daf)),_0x2910bc=_0x51ca94['apiKey']??null,_0x2a5b44=_0x51ca94['oobCode']??null,_0x53c836=Jf(_0x51ca94['mode']??null);m(_0x2910bc&&_0x2a5b44&&_0x53c836,'argument-error'),this['apiKey']=_0x2910bc,this['operation']=_0x53c836,this['code']=_0x2a5b44,this['continueUrl']=_0x51ca94['continueUrl']??null,this['languageCode']=_0x51ca94['lang']??null,this['tenantId']=_0x51ca94['tenantId']??null;}static['parseLink'](_0x1963ac){const _0x17af3b=Xf(_0x1963ac);try{return new Rs(_0x17af3b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x2c4f71,_0x24a088){return $t['_fromEmailAndPassword'](_0x2c4f71,_0x24a088);}static['credentialWithLink'](_0x18f01c,_0x56b5bb){const _0x1c1744=Rs['parseLink'](_0x56b5bb);return m(_0x1c1744,'argument-error'),$t['_fromEmailAndCode'](_0x18f01c,_0x1c1744['code'],_0x1c1744['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x46ae87){this['providerId']=_0x46ae87,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x32abce){this['defaultLanguageCode']=_0x32abce;}['setCustomParameters'](_0x833f34){return this['customParameters']=_0x833f34,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x57e7c9){return this['scopes']['includes'](_0x57e7c9)||this['scopes']['push'](_0x57e7c9),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4f2414){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4f2414});}static['credentialFromResult'](_0x3b2c43){return ue['credentialFromTaggedObject'](_0x3b2c43);}static['credentialFromError'](_0x226acc){return ue['credentialFromTaggedObject'](_0x226acc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x113732}){if(!_0x113732||!('oauthAccessToken'in _0x113732)||!_0x113732['oauthAccessToken'])return null;try{return ue['credential'](_0x113732['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3ff99e,_0x35aa26){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3ff99e,'accessToken':_0x35aa26});}static['credentialFromResult'](_0x125269){return de['credentialFromTaggedObject'](_0x125269);}static['credentialFromError'](_0x4cf5a0){return de['credentialFromTaggedObject'](_0x4cf5a0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4cc88a}){if(!_0x4cc88a)return null;const {oauthIdToken:_0x2df131,oauthAccessToken:_0x3f7930}=_0x4cc88a;if(!_0x2df131&&!_0x3f7930)return null;try{return de['credential'](_0x2df131,_0x3f7930);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x3239b6){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3239b6});}static['credentialFromResult'](_0x7dcb94){return fe['credentialFromTaggedObject'](_0x7dcb94);}static['credentialFromError'](_0x5b9b8c){return fe['credentialFromTaggedObject'](_0x5b9b8c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1445a1}){if(!_0x1445a1||!('oauthAccessToken'in _0x1445a1)||!_0x1445a1['oauthAccessToken'])return null;try{return fe['credential'](_0x1445a1['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3fdac3,_0x1708de){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3fdac3,'oauthTokenSecret':_0x1708de});}static['credentialFromResult'](_0x109960){return pe['credentialFromTaggedObject'](_0x109960);}static['credentialFromError'](_0x3c7fba){return pe['credentialFromTaggedObject'](_0x3c7fba['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x160ba2}){if(!_0x160ba2)return null;const {oauthAccessToken:_0x887551,oauthTokenSecret:_0x31837f}=_0x160ba2;if(!_0x887551||!_0x31837f)return null;try{return pe['credential'](_0x887551,_0x31837f);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x26f506,_0x3f5bb7){return en(_0x26f506,'POST','/v1/accounts:signUp',ke(_0x26f506,_0x3f5bb7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x1fd10b){this['user']=_0x1fd10b['user'],this['providerId']=_0x1fd10b['providerId'],this['_tokenResponse']=_0x1fd10b['_tokenResponse'],this['operationType']=_0x1fd10b['operationType'];}static async['_fromIdTokenResponse'](_0x3f7de0,_0x20f406,_0x5cd98b,_0x4bc1ad=!0x1){const _0x443fe4=await j['_fromIdTokenResponse'](_0x3f7de0,_0x5cd98b,_0x4bc1ad),_0x2b88e6=Nr(_0x5cd98b);return new Ge({'user':_0x443fe4,'providerId':_0x2b88e6,'_tokenResponse':_0x5cd98b,'operationType':_0x20f406});}static async['_forOperation'](_0x70bc83,_0xef2000,_0x5df598){await _0x70bc83['_updateTokensIfNecessary'](_0x5df598,!0x0);const _0x3fc1=Nr(_0x5df598);return new Ge({'user':_0x70bc83,'providerId':_0x3fc1,'_tokenResponse':_0x5df598,'operationType':_0xef2000});}}function Nr(_0x4e9bda){return _0x4e9bda['providerId']?_0x4e9bda['providerId']:'phoneNumber'in _0x4e9bda?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xeab57,_0x4dd93e,_0x1dddf1,_0x4e48cc){super(_0x4dd93e['code'],_0x4dd93e['message']),this['operationType']=_0x1dddf1,this['user']=_0x4e48cc,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xeab57['name'],'tenantId':_0xeab57['tenantId']??void 0x0,'_serverResponse':_0x4dd93e['customData']['_serverResponse'],'operationType':_0x1dddf1};}static['_fromErrorAndOperation'](_0x324d8b,_0x37f5a5,_0x4e293c,_0x118d2b){return new On(_0x324d8b,_0x37f5a5,_0x4e293c,_0x118d2b);}}function Ba(_0x96e02,_0x3786e9,_0x2baf57,_0x4c69c6){return(_0x3786e9==='reauthenticate'?_0x2baf57['_getReauthenticationResolver'](_0x96e02):_0x2baf57['_getIdTokenResponse'](_0x96e02))['catch'](_0x4143cd=>{throw _0x4143cd['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x96e02,_0x4143cd,_0x3786e9,_0x4c69c6):_0x4143cd;});}async function ep(_0xc47f01,_0x22808b,_0x4b4e70=!0x1){const _0xaf9b7f=await Ht(_0xc47f01,_0x22808b['_linkToIdToken'](_0xc47f01['auth'],await _0xc47f01['getIdToken']()),_0x4b4e70);return Ge['_forOperation'](_0xc47f01,'link',_0xaf9b7f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x31945e,_0x30438f,_0x26b881=!0x1){const {auth:_0x1a2e83}=_0x31945e;if($(_0x1a2e83['app']))return Promise['reject'](re(_0x1a2e83));const _0x53183d='reauthenticate';try{const _0x43583a=await Ht(_0x31945e,Ba(_0x1a2e83,_0x53183d,_0x30438f,_0x31945e),_0x26b881);m(_0x43583a['idToken'],_0x1a2e83,'internal-error');const _0x41b5de=Ts(_0x43583a['idToken']);m(_0x41b5de,_0x1a2e83,'internal-error');const {sub:_0x5379c8}=_0x41b5de;return m(_0x31945e['uid']===_0x5379c8,_0x1a2e83,'user-mismatch'),Ge['_forOperation'](_0x31945e,_0x53183d,_0x43583a);}catch(_0x53d329){throw(_0x53d329==null?void 0x0:_0x53d329['code'])==='auth/user-not-found'&&Y(_0x1a2e83,'user-mismatch'),_0x53d329;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x5d6bd7,_0x2634ea,_0x37410e=!0x1){if($(_0x5d6bd7['app']))return Promise['reject'](re(_0x5d6bd7));const _0xe68377='signIn',_0x5ac66e=await Ba(_0x5d6bd7,_0xe68377,_0x2634ea),_0x429db6=await Ge['_fromIdTokenResponse'](_0x5d6bd7,_0xe68377,_0x5ac66e);return _0x37410e||await _0x5d6bd7['_updateCurrentUser'](_0x429db6['user']),_0x429db6;}async function np(_0x37a47f,_0x5ae9d8){return Va(Ke(_0x37a47f),_0x5ae9d8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2bb104){const _0x5caada=Ke(_0x2bb104);_0x5caada['_getPasswordPolicyInternal']()&&await _0x5caada['_updatePasswordPolicy']();}async function L_(_0x40b4e3,_0x2141ad,_0x3ffdd6){if($(_0x40b4e3['app']))return Promise['reject'](re(_0x40b4e3));const _0x499ed9=Ke(_0x40b4e3),_0x1ed492=await xi(_0x499ed9,{'returnSecureToken':!0x0,'email':_0x2141ad,'password':_0x3ffdd6,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x3a02bd=>{throw _0x3a02bd['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x40b4e3),_0x3a02bd;}),_0x1fabf1=await Ge['_fromIdTokenResponse'](_0x499ed9,'signIn',_0x1ed492);return await _0x499ed9['_updateCurrentUser'](_0x1fabf1['user']),_0x1fabf1;}function x_(_0x370a90,_0x2700bd,_0x767aa3){return $(_0x370a90['app'])?Promise['reject'](re(_0x370a90)):np(P(_0x370a90),yt['credential'](_0x2700bd,_0x767aa3))['catch'](async _0x18793e=>{throw _0x18793e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x370a90),_0x18793e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2ff4e2,_0x4e5afc){return P(_0x2ff4e2)['setPersistence'](_0x4e5afc);}function ip(_0x1c5057,_0x33b183,_0x2dd505,_0x241973){return P(_0x1c5057)['onIdTokenChanged'](_0x33b183,_0x2dd505,_0x241973);}function sp(_0x5787a4,_0xfe06e4,_0xc48305){return P(_0x5787a4)['beforeAuthStateChanged'](_0xfe06e4,_0xc48305);}function U_(_0xf41be,_0x1ce7ba,_0x2e5d60,_0x4980fb){return P(_0xf41be)['onAuthStateChanged'](_0x1ce7ba,_0x2e5d60,_0x4980fb);}function W_(_0xc9f224){return P(_0xc9f224)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5a4f9e,_0x70a3ec){this['storageRetriever']=_0x5a4f9e,this['type']=_0x70a3ec;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3f25be,_0x288ff5){return this['storage']['setItem'](_0x3f25be,JSON['stringify'](_0x288ff5)),Promise['resolve']();}['_get'](_0x286c73){const _0x1dba29=this['storage']['getItem'](_0x286c73);return Promise['resolve'](_0x1dba29?JSON['parse'](_0x1dba29):null);}['_remove'](_0xcc5f1){return this['storage']['removeItem'](_0xcc5f1),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x646427,_0x6e4616)=>this['onStorageEvent'](_0x646427,_0x6e4616),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xfcdf89){for(const _0xac1d38 of Object['keys'](this['listeners'])){const _0x319755=this['storage']['getItem'](_0xac1d38),_0x542e76=this['localCache'][_0xac1d38];_0x319755!==_0x542e76&&_0xfcdf89(_0xac1d38,_0x542e76,_0x319755);}}['onStorageEvent'](_0x23d561,_0x1c6685=!0x1){if(!_0x23d561['key']){this['forAllChangedKeys']((_0x44f43e,_0x18b049,_0x5f32c6)=>{this['notifyListeners'](_0x44f43e,_0x5f32c6);});return;}const _0xfccc3b=_0x23d561['key'];_0x1c6685?this['detachListener']():this['stopPolling']();const _0x21c4d6=()=>{const _0x35c93f=this['storage']['getItem'](_0xfccc3b);!_0x1c6685&&this['localCache'][_0xfccc3b]===_0x35c93f||this['notifyListeners'](_0xfccc3b,_0x35c93f);},_0x26ccfd=this['storage']['getItem'](_0xfccc3b);Af()&&_0x26ccfd!==_0x23d561['newValue']&&_0x23d561['newValue']!==_0x23d561['oldValue']?setTimeout(_0x21c4d6,op):_0x21c4d6();}['notifyListeners'](_0x49757d,_0x1ceab3){this['localCache'][_0x49757d]=_0x1ceab3;const _0x4d2006=this['listeners'][_0x49757d];if(_0x4d2006){for(const _0x552459 of Array['from'](_0x4d2006))_0x552459(_0x1ceab3&&JSON['parse'](_0x1ceab3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x281e83,_0x10a0f9,_0xe46f07)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x281e83,'oldValue':_0x10a0f9,'newValue':_0xe46f07}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4c646b,_0x46f057){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4c646b]||(this['listeners'][_0x4c646b]=new Set(),this['localCache'][_0x4c646b]=this['storage']['getItem'](_0x4c646b)),this['listeners'][_0x4c646b]['add'](_0x46f057);}['_removeListener'](_0x272509,_0xf3b408){this['listeners'][_0x272509]&&(this['listeners'][_0x272509]['delete'](_0xf3b408),this['listeners'][_0x272509]['size']===0x0&&delete this['listeners'][_0x272509]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x577d79,_0x596584){await super['_set'](_0x577d79,_0x596584),this['localCache'][_0x577d79]=JSON['stringify'](_0x596584);}async['_get'](_0xc4fff0){const _0x4aec2d=await super['_get'](_0xc4fff0);return this['localCache'][_0xc4fff0]=JSON['stringify'](_0x4aec2d),_0x4aec2d;}async['_remove'](_0x35dc7d){await super['_remove'](_0x35dc7d),delete this['localCache'][_0x35dc7d];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0xa1d533,_0x27cc9f){}['_removeListener'](_0x50e48e,_0x2afa95){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x3fa19e){return Promise['all'](_0x3fa19e['map'](async _0x2a03f9=>{try{return{'fulfilled':!0x0,'value':await _0x2a03f9};}catch(_0x1eea38){return{'fulfilled':!0x1,'reason':_0x1eea38};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x356637){this['eventTarget']=_0x356637,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x380d6e){const _0x339bc6=this['receivers']['find'](_0x16488c=>_0x16488c['isListeningto'](_0x380d6e));if(_0x339bc6)return _0x339bc6;const _0x153bb7=new Xn(_0x380d6e);return this['receivers']['push'](_0x153bb7),_0x153bb7;}['isListeningto'](_0x2189ec){return this['eventTarget']===_0x2189ec;}async['handleEvent'](_0x8f29a2){const _0x40e86=_0x8f29a2,{eventId:_0x5e75f5,eventType:_0x19ac99,data:_0x2f12d6}=_0x40e86['data'],_0x2d2d25=this['handlersMap'][_0x19ac99];if(!(_0x2d2d25!=null&&_0x2d2d25['size']))return;_0x40e86['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5e75f5,'eventType':_0x19ac99});const _0xa65437=Array['from'](_0x2d2d25)['map'](async _0x53af52=>_0x53af52(_0x40e86['origin'],_0x2f12d6)),_0x57d0b9=await cp(_0xa65437);_0x40e86['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5e75f5,'eventType':_0x19ac99,'response':_0x57d0b9});}['_subscribe'](_0x5a56e1,_0x441b84){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5a56e1]||(this['handlersMap'][_0x5a56e1]=new Set()),this['handlersMap'][_0x5a56e1]['add'](_0x441b84);}['_unsubscribe'](_0x518ca9,_0x358022){this['handlersMap'][_0x518ca9]&&_0x358022&&this['handlersMap'][_0x518ca9]['delete'](_0x358022),(!_0x358022||this['handlersMap'][_0x518ca9]['size']===0x0)&&delete this['handlersMap'][_0x518ca9],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5ac8a4='',_0x35e01a=0xa){let _0x23776a='';for(let _0x31ffd9=0x0;_0x31ffd9<_0x35e01a;_0x31ffd9++)_0x23776a+=Math['floor'](Math['random']()*0xa);return _0x5ac8a4+_0x23776a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x3624a4){this['target']=_0x3624a4,this['handlers']=new Set();}['removeMessageHandler'](_0x511220){_0x511220['messageChannel']&&(_0x511220['messageChannel']['port1']['removeEventListener']('message',_0x511220['onMessage']),_0x511220['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x511220);}async['_send'](_0x3658e8,_0x5c751e,_0x4514a1=0x32){const _0x44c8d5=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x44c8d5)throw new Error('connection_unavailable');let _0x11021f,_0x47bd95;return new Promise((_0xa069e6,_0x4b0bef)=>{const _0x382be9=As('',0x14);_0x44c8d5['port1']['start']();const _0x4e522c=setTimeout(()=>{_0x4b0bef(new Error('unsupported_event'));},_0x4514a1);_0x47bd95={'messageChannel':_0x44c8d5,'onMessage'(_0x3f6fd3){const _0x45c9b0=_0x3f6fd3;if(_0x45c9b0['data']['eventId']===_0x382be9)switch(_0x45c9b0['data']['status']){case'ack':clearTimeout(_0x4e522c),_0x11021f=setTimeout(()=>{_0x4b0bef(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x11021f),_0xa069e6(_0x45c9b0['data']['response']);break;default:clearTimeout(_0x4e522c),clearTimeout(_0x11021f),_0x4b0bef(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x47bd95),_0x44c8d5['port1']['addEventListener']('message',_0x47bd95['onMessage']),this['target']['postMessage']({'eventType':_0x3658e8,'eventId':_0x382be9,'data':_0x5c751e},[_0x44c8d5['port2']]);})['finally'](()=>{_0x47bd95&&this['removeMessageHandler'](_0x47bd95);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x2edff4){Z()['location']['href']=_0x2edff4;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1faef3;return((_0x1faef3=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1faef3['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4c9c01){this['request']=_0x4c9c01;}['toPromise'](){return new Promise((_0x10db79,_0x1865c5)=>{this['request']['addEventListener']('success',()=>{_0x10db79(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1865c5(this['request']['error']);});});}}function Zn(_0x23dd2d,_0x45f404){return _0x23dd2d['transaction']([Mn],_0x45f404?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x446579=indexedDB['deleteDatabase'](Ka);return new nn(_0x446579)['toPromise']();}function Qa(){const _0x40dc4d=indexedDB['open'](Ka,pp);return new Promise((_0x4f7452,_0x38c693)=>{_0x40dc4d['addEventListener']('error',()=>{_0x38c693(_0x40dc4d['error']);}),_0x40dc4d['addEventListener']('upgradeneeded',()=>{const _0x39adef=_0x40dc4d['result'];try{_0x39adef['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x157095){_0x38c693(_0x157095);}}),_0x40dc4d['addEventListener']('success',async()=>{const _0x5d5f9a=_0x40dc4d['result'];_0x5d5f9a['objectStoreNames']['contains'](Mn)?_0x4f7452(_0x5d5f9a):(_0x5d5f9a['close'](),await _p(),_0x4f7452(await Qa()));});});}async function Or(_0x2687fa,_0x54879a,_0x5174e7){const _0x158ca0=Zn(_0x2687fa,!0x0)['put']({[Ya]:_0x54879a,'value':_0x5174e7});return new nn(_0x158ca0)['toPromise']();}async function gp(_0x525315,_0x2ee031){const _0x2cd64d=Zn(_0x525315,!0x1)['get'](_0x2ee031),_0xc0f3a4=await new nn(_0x2cd64d)['toPromise']();return _0xc0f3a4===void 0x0?null:_0xc0f3a4['value'];}function Dr(_0x346597,_0x61d68f){const _0x59ea4e=Zn(_0x346597,!0x0)['delete'](_0x61d68f);return new nn(_0x59ea4e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x565841){let _0x3be558=0x0;for(;;)try{const _0x2a75da=await this['_openDb']();return await _0x565841(_0x2a75da);}catch(_0x590012){if(_0x3be558++>yp)throw _0x590012;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x139f17,_0x578be2)=>({'keyProcessed':(await this['_poll']())['includes'](_0x578be2['key'])})),this['receiver']['_subscribe']('ping',async(_0x49c7a8,_0x20ffdf)=>['keyChanged']);}async['initializeSender'](){var _0x57979b,_0x4bfdf0;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0xf7581e=await this['sender']['_send']('ping',{},0x320);_0xf7581e&&(_0x57979b=_0xf7581e[0x0])!=null&&_0x57979b['fulfilled']&&(_0x4bfdf0=_0xf7581e[0x0])!=null&&_0x4bfdf0['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x30273f){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x30273f},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xef9502=>{await Or(_0xef9502,Dn,'1'),await Dr(_0xef9502,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4b12d5){this['pendingWrites']++;try{await _0x4b12d5();}finally{this['pendingWrites']--;}}async['_set'](_0x556ec9,_0x44cf2d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x48e5e0=>Or(_0x48e5e0,_0x556ec9,_0x44cf2d)),this['localCache'][_0x556ec9]=_0x44cf2d,this['notifyServiceWorker'](_0x556ec9)));}async['_get'](_0x2e1a83){const _0x48b59a=await this['_withRetries'](_0x2dcdcc=>gp(_0x2dcdcc,_0x2e1a83));return this['localCache'][_0x2e1a83]=_0x48b59a,_0x48b59a;}async['_remove'](_0x45e7ed){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x696c42=>Dr(_0x696c42,_0x45e7ed)),delete this['localCache'][_0x45e7ed],this['notifyServiceWorker'](_0x45e7ed)));}async['_poll'](){const _0x54fd47=await this['_withRetries'](_0x43a4e5=>{const _0x580bd7=Zn(_0x43a4e5,!0x1)['getAll']();return new nn(_0x580bd7)['toPromise']();});if(!_0x54fd47)return[];if(this['pendingWrites']!==0x0)return[];const _0xdd76d0=[],_0x32d258=new Set();if(_0x54fd47['length']!==0x0){for(const {fbase_key:_0x4387d6,value:_0x325615}of _0x54fd47)_0x32d258['add'](_0x4387d6),JSON['stringify'](this['localCache'][_0x4387d6])!==JSON['stringify'](_0x325615)&&(this['notifyListeners'](_0x4387d6,_0x325615),_0xdd76d0['push'](_0x4387d6));}for(const _0x40cf9e of Object['keys'](this['localCache']))this['localCache'][_0x40cf9e]&&!_0x32d258['has'](_0x40cf9e)&&(this['notifyListeners'](_0x40cf9e,null),_0xdd76d0['push'](_0x40cf9e));return _0xdd76d0;}['notifyListeners'](_0x44bb2a,_0x53dfad){this['localCache'][_0x44bb2a]=_0x53dfad;const _0x18334b=this['listeners'][_0x44bb2a];if(_0x18334b){for(const _0x2111fd of Array['from'](_0x18334b))_0x2111fd(_0x53dfad);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x46eb63,_0x3010f0){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x46eb63]||(this['listeners'][_0x46eb63]=new Set(),this['_get'](_0x46eb63)),this['listeners'][_0x46eb63]['add'](_0x3010f0);}['_removeListener'](_0xa76893,_0x59f9d4){this['listeners'][_0xa76893]&&(this['listeners'][_0xa76893]['delete'](_0x59f9d4),this['listeners'][_0xa76893]['size']===0x0&&delete this['listeners'][_0xa76893]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0xc7c70c,_0x2f00bb){return _0x2f00bb?ie(_0x2f00bb):(m(_0xc7c70c['_popupRedirectResolver'],_0xc7c70c,'argument-error'),_0xc7c70c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3b13a6){super('custom','custom'),this['params']=_0x3b13a6;}['_getIdTokenResponse'](_0x2ec7e3){return nt(_0x2ec7e3,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3c0aee,_0x1557f6){return nt(_0x3c0aee,this['_buildIdpRequest'](_0x1557f6));}['_getReauthenticationResolver'](_0x572814){return nt(_0x572814,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2ccba2){const _0x2cce09={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2ccba2&&(_0x2cce09['idToken']=_0x2ccba2),_0x2cce09;}}function Ip(_0x2af275){return Va(_0x2af275['auth'],new ks(_0x2af275),_0x2af275['bypassAuthState']);}function wp(_0xb9eb46){const {auth:_0x2d33a6,user:_0x1e17a6}=_0xb9eb46;return m(_0x1e17a6,_0x2d33a6,'internal-error'),tp(_0x1e17a6,new ks(_0xb9eb46),_0xb9eb46['bypassAuthState']);}async function Cp(_0x4f4c2e){const {auth:_0x51951e,user:_0x2cd2c3}=_0x4f4c2e;return m(_0x2cd2c3,_0x51951e,'internal-error'),ep(_0x2cd2c3,new ks(_0x4f4c2e),_0x4f4c2e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x4ea4b9,_0x58a9f2,_0x5b5c16,_0x14d3ba,_0x31fd1b=!0x1){this['auth']=_0x4ea4b9,this['resolver']=_0x5b5c16,this['user']=_0x14d3ba,this['bypassAuthState']=_0x31fd1b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x58a9f2)?_0x58a9f2:[_0x58a9f2];}['execute'](){return new Promise(async(_0x25237e,_0x49f83a)=>{this['pendingPromise']={'resolve':_0x25237e,'reject':_0x49f83a};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1b04a9){this['reject'](_0x1b04a9);}});}async['onAuthEvent'](_0x4b2e7a){const {urlResponse:_0x11cf1a,sessionId:_0x342cb7,postBody:_0x324cc2,tenantId:_0x4bd1e9,error:_0x4376cb,type:_0x9a77d5}=_0x4b2e7a;if(_0x4376cb){this['reject'](_0x4376cb);return;}const _0x1c9ad6={'auth':this['auth'],'requestUri':_0x11cf1a,'sessionId':_0x342cb7,'tenantId':_0x4bd1e9||void 0x0,'postBody':_0x324cc2||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x9a77d5)(_0x1c9ad6));}catch(_0x22c6ed){this['reject'](_0x22c6ed);}}['onError'](_0x8f9ac1){this['reject'](_0x8f9ac1);}['getIdpTask'](_0x156fab){switch(_0x156fab){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x386648){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x386648),this['unregisterAndCleanUp']();}['reject'](_0x58d4dc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x58d4dc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4a4cee,_0x1792cb,_0x5ec876,_0x11c0e2,_0x281b7a){super(_0x4a4cee,_0x1792cb,_0x11c0e2,_0x281b7a),this['provider']=_0x5ec876,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x32f24b=await this['execute']();return m(_0x32f24b,this['auth'],'internal-error'),_0x32f24b;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x224ee1=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x224ee1),this['authWindow']['associatedEvent']=_0x224ee1,this['resolver']['_originValidation'](this['auth'])['catch'](_0x815cb0=>{this['reject'](_0x815cb0);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x58c0ed=>{_0x58c0ed||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xfa70e2;return((_0xfa70e2=this['authWindow'])==null?void 0x0:_0xfa70e2['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x24e82d=()=>{var _0x3bd38e,_0xee62bc;if((_0xee62bc=(_0x3bd38e=this['authWindow'])==null?void 0x0:_0x3bd38e['window'])!=null&&_0xee62bc['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x24e82d,Tp['get']());};_0x24e82d();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x242ed6,_0x3347bd,_0x382025=!0x1){super(_0x242ed6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3347bd,void 0x0,_0x382025),this['eventId']=null;}async['execute'](){let _0x5e54f6=hn['get'](this['auth']['_key']());if(!_0x5e54f6){try{const _0x246a61=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x5e54f6=()=>Promise['resolve'](_0x246a61);}catch(_0x25d08a){_0x5e54f6=()=>Promise['reject'](_0x25d08a);}hn['set'](this['auth']['_key'](),_0x5e54f6);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x5e54f6();}async['onAuthEvent'](_0x5ddecf){if(_0x5ddecf['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5ddecf);if(_0x5ddecf['type']==='unknown'){this['resolve'](null);return;}if(_0x5ddecf['eventId']){const _0x488b54=await this['auth']['_redirectUserForId'](_0x5ddecf['eventId']);if(_0x488b54)return this['user']=_0x488b54,super['onAuthEvent'](_0x5ddecf);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x5010d6,_0x2cf4a8){const _0x5e5be3=Pp(_0x2cf4a8),_0x76da42=kp(_0x5010d6);if(!await _0x76da42['_isAvailable']())return!0x1;const _0x49aa49=await _0x76da42['_get'](_0x5e5be3)==='true';return await _0x76da42['_remove'](_0x5e5be3),_0x49aa49;}function Ap(_0x41c94e,_0x2636c0){hn['set'](_0x41c94e['_key'](),_0x2636c0);}function kp(_0x438f7b){return ie(_0x438f7b['_redirectPersistence']);}function Pp(_0x790adc){return ln(Sp,_0x790adc['config']['apiKey'],_0x790adc['name']);}async function Np(_0xa68df3,_0x4d5eb0,_0x419ce1=!0x1){if($(_0xa68df3['app']))return Promise['reject'](re(_0xa68df3));const _0x5def6e=Ke(_0xa68df3),_0x2713f7=Ep(_0x5def6e,_0x4d5eb0),_0x5c9180=await new bp(_0x5def6e,_0x2713f7,_0x419ce1)['execute']();return _0x5c9180&&!_0x419ce1&&(delete _0x5c9180['user']['_redirectEventId'],await _0x5def6e['_persistUserIfCurrent'](_0x5c9180['user']),await _0x5def6e['_setRedirectUser'](null,_0x4d5eb0)),_0x5c9180;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x504971){this['auth']=_0x504971,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xaa8a02){this['consumers']['add'](_0xaa8a02),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xaa8a02)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xaa8a02),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3f46dd){this['consumers']['delete'](_0x3f46dd);}['onEvent'](_0x515c35){if(this['hasEventBeenHandled'](_0x515c35))return!0x1;let _0x3a798e=!0x1;return this['consumers']['forEach'](_0x5394ab=>{this['isEventForConsumer'](_0x515c35,_0x5394ab)&&(_0x3a798e=!0x0,this['sendToConsumer'](_0x515c35,_0x5394ab),this['saveEventToCache'](_0x515c35));}),this['hasHandledPotentialRedirect']||!Mp(_0x515c35)||(this['hasHandledPotentialRedirect']=!0x0,_0x3a798e||(this['queuedRedirectEvent']=_0x515c35,_0x3a798e=!0x0)),_0x3a798e;}['sendToConsumer'](_0x147307,_0x42c37b){var _0x518d6d;if(_0x147307['error']&&!Za(_0x147307)){const _0x53ced9=((_0x518d6d=_0x147307['error']['code'])==null?void 0x0:_0x518d6d['split']('auth/')[0x1])||'internal-error';_0x42c37b['onError'](X(this['auth'],_0x53ced9));}else _0x42c37b['onAuthEvent'](_0x147307);}['isEventForConsumer'](_0x28d84f,_0x5b587d){const _0x164292=_0x5b587d['eventId']===null||!!_0x28d84f['eventId']&&_0x28d84f['eventId']===_0x5b587d['eventId'];return _0x5b587d['filter']['includes'](_0x28d84f['type'])&&_0x164292;}['hasEventBeenHandled'](_0x3dfd0d){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x3dfd0d));}['saveEventToCache'](_0x26df89){this['cachedEventUids']['add'](Mr(_0x26df89)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1162af){return[_0x1162af['type'],_0x1162af['eventId'],_0x1162af['sessionId'],_0x1162af['tenantId']]['filter'](_0x5ddc80=>_0x5ddc80)['join']('-');}function Za({type:_0x2c0b2c,error:_0x29dea1}){return _0x2c0b2c==='unknown'&&(_0x29dea1==null?void 0x0:_0x29dea1['code'])==='auth/no-auth-event';}function Mp(_0x3b232e){switch(_0x3b232e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3b232e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x5d4192,_0x136b67={}){return Pe(_0x5d4192,'GET','/v1/projects',_0x136b67);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x59d376){if(_0x59d376['config']['emulator'])return;const {authorizedDomains:_0x9202c}=await Lp(_0x59d376);for(const _0x100733 of _0x9202c)try{if(Wp(_0x100733))return;}catch{}Y(_0x59d376,'unauthorized-domain');}function Wp(_0x164c4b){const _0x3411d=Mi(),{protocol:_0xe09abd,hostname:_0x2541ee}=new URL(_0x3411d);if(_0x164c4b['startsWith']('chrome-extension://')){const _0x3cfab4=new URL(_0x164c4b);return _0x3cfab4['hostname']===''&&_0x2541ee===''?_0xe09abd==='chrome-extension:'&&_0x164c4b['replace']('chrome-extension://','')===_0x3411d['replace']('chrome-extension://',''):_0xe09abd==='chrome-extension:'&&_0x3cfab4['hostname']===_0x2541ee;}if(!Fp['test'](_0xe09abd))return!0x1;if(xp['test'](_0x164c4b))return _0x2541ee===_0x164c4b;const _0x2849c5=_0x164c4b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2849c5+'|'+_0x2849c5+')$','i')['test'](_0x2541ee);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x486c5f=Z()['___jsl'];if(_0x486c5f!=null&&_0x486c5f['H']){for(const _0x1e723e of Object['keys'](_0x486c5f['H']))if(_0x486c5f['H'][_0x1e723e]['r']=_0x486c5f['H'][_0x1e723e]['r']||[],_0x486c5f['H'][_0x1e723e]['L']=_0x486c5f['H'][_0x1e723e]['L']||[],_0x486c5f['H'][_0x1e723e]['r']=[..._0x486c5f['H'][_0x1e723e]['L']],_0x486c5f['CP']){for(let _0x205b4f=0x0;_0x205b4f<_0x486c5f['CP']['length'];_0x205b4f++)_0x486c5f['CP'][_0x205b4f]=null;}}}function Vp(_0x19623b){return new Promise((_0x1bf318,_0x5af222)=>{var _0xc9eac1,_0x576b24,_0x43139c;function _0x2886aa(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1bf318(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x5af222(X(_0x19623b,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x576b24=(_0xc9eac1=Z()['gapi'])==null?void 0x0:_0xc9eac1['iframes'])!=null&&_0x576b24['Iframe'])_0x1bf318(gapi['iframes']['getContext']());else{if((_0x43139c=Z()['gapi'])!=null&&_0x43139c['load'])_0x2886aa();else{const _0x19faa9=Ff('iframefcb');return Z()[_0x19faa9]=()=>{gapi['load']?_0x2886aa():_0x5af222(X(_0x19623b,'network-request-failed'));},xa(xf()+'?onload='+_0x19faa9)['catch'](_0x12ac0a=>_0x5af222(_0x12ac0a));}}})['catch'](_0x1a8c52=>{throw un=null,_0x1a8c52;});}let un=null;function Hp(_0x235686){return un=un||Vp(_0x235686),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x442de8){const _0xc8b19e=_0x442de8['config'];m(_0xc8b19e['authDomain'],_0x442de8,'auth-domain-config-required');const _0x41e929=_0xc8b19e['emulator']?Cs(_0xc8b19e,qp):'https://'+_0x442de8['config']['authDomain']+'/'+Gp,_0x47834e={'apiKey':_0xc8b19e['apiKey'],'appName':_0x442de8['name'],'v':dt},_0x1333d9=jp['get'](_0x442de8['config']['apiHost']);_0x1333d9&&(_0x47834e['eid']=_0x1333d9);const _0xcc8c10=_0x442de8['_getFrameworks']();return _0xcc8c10['length']&&(_0x47834e['fw']=_0xcc8c10['join'](',')),_0x41e929+'?'+ut(_0x47834e)['slice'](0x1);}async function Yp(_0x13ca38){const _0x58e218=await Hp(_0x13ca38),_0x3bbcd7=Z()['gapi'];return m(_0x3bbcd7,_0x13ca38,'internal-error'),_0x58e218['open']({'where':document['body'],'url':Kp(_0x13ca38),'messageHandlersFilter':_0x3bbcd7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x282a68=>new Promise(async(_0x1f8160,_0x21e22b)=>{await _0x282a68['restyle']({'setHideOnLeave':!0x1});const _0x1405d0=X(_0x13ca38,'network-request-failed'),_0x43de39=Z()['setTimeout'](()=>{_0x21e22b(_0x1405d0);},$p['get']());function _0x2dea30(){Z()['clearTimeout'](_0x43de39),_0x1f8160(_0x282a68);}_0x282a68['ping'](_0x2dea30)['then'](_0x2dea30,()=>{_0x21e22b(_0x1405d0);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x74ac20){this['window']=_0x74ac20,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x9c9e72,_0x16f568,_0x426eea,_0x41659d=Jp,_0x15e31e=Xp){const _0x1b6f33=Math['max']((window['screen']['availHeight']-_0x15e31e)/0x2,0x0)['toString'](),_0x542d77=Math['max']((window['screen']['availWidth']-_0x41659d)/0x2,0x0)['toString']();let _0x251d33='';const _0x94be7d={...Qp,'width':_0x41659d['toString'](),'height':_0x15e31e['toString'](),'top':_0x1b6f33,'left':_0x542d77},_0xe21e48=W()['toLowerCase']();_0x426eea&&(_0x251d33=ka(_0xe21e48)?Zp:_0x426eea),Ra(_0xe21e48)&&(_0x16f568=_0x16f568||e_,_0x94be7d['scrollbars']='yes');const _0x2340e3=Object['entries'](_0x94be7d)['reduce']((_0x31c50c,[_0x1e68f8,_0x48fca6])=>''+_0x31c50c+_0x1e68f8+'='+_0x48fca6+',','');if(Rf(_0xe21e48)&&_0x251d33!=='_self')return n_(_0x16f568||'',_0x251d33),new xr(null);const _0x3f13ca=window['open'](_0x16f568||'',_0x251d33,_0x2340e3);m(_0x3f13ca,_0x9c9e72,'popup-blocked');try{_0x3f13ca['focus']();}catch{}return new xr(_0x3f13ca);}function n_(_0x480e37,_0x45b627){const _0x5da818=document['createElement']('a');_0x5da818['href']=_0x480e37,_0x5da818['target']=_0x45b627;const _0x47ddd5=document['createEvent']('MouseEvent');_0x47ddd5['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5da818['dispatchEvent'](_0x47ddd5);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x475b72,_0x274342,_0x44fd56,_0x646ae5,_0x1544b6,_0xe930bf){m(_0x475b72['config']['authDomain'],_0x475b72,'auth-domain-config-required'),m(_0x475b72['config']['apiKey'],_0x475b72,'invalid-api-key');const _0x43d0b8={'apiKey':_0x475b72['config']['apiKey'],'appName':_0x475b72['name'],'authType':_0x44fd56,'redirectUrl':_0x646ae5,'v':dt,'eventId':_0x1544b6};if(_0x274342 instanceof Wa){_0x274342['setDefaultLanguage'](_0x475b72['languageCode']),_0x43d0b8['providerId']=_0x274342['providerId']||'',pn(_0x274342['getCustomParameters']())||(_0x43d0b8['customParameters']=JSON['stringify'](_0x274342['getCustomParameters']()));for(const [_0x262983,_0x57bc33]of Object['entries']({}))_0x43d0b8[_0x262983]=_0x57bc33;}if(_0x274342 instanceof tn){const _0x207b49=_0x274342['getScopes']()['filter'](_0x481c53=>_0x481c53!=='');_0x207b49['length']>0x0&&(_0x43d0b8['scopes']=_0x207b49['join'](','));}_0x475b72['tenantId']&&(_0x43d0b8['tid']=_0x475b72['tenantId']);const _0x11be15=_0x43d0b8;for(const _0x5520a0 of Object['keys'](_0x11be15))_0x11be15[_0x5520a0]===void 0x0&&delete _0x11be15[_0x5520a0];const _0x3df6bc=await _0x475b72['_getAppCheckToken'](),_0x50a63f=_0x3df6bc?'#'+r_+'='+encodeURIComponent(_0x3df6bc):'';return o_(_0x475b72)+'?'+ut(_0x11be15)['slice'](0x1)+_0x50a63f;}function o_({config:_0x4f5b00}){return _0x4f5b00['emulator']?Cs(_0x4f5b00,s_):'https://'+_0x4f5b00['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x43ac15,_0x459204,_0x2d54fc,_0x221b0f){var _0x21fc80;ce((_0x21fc80=this['eventManagers'][_0x43ac15['_key']()])==null?void 0x0:_0x21fc80['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x412ac9=await Fr(_0x43ac15,_0x459204,_0x2d54fc,Mi(),_0x221b0f);return t_(_0x43ac15,_0x412ac9,As());}async['_openRedirect'](_0x1df44d,_0x1882ce,_0x932ae9,_0x1d8588){await this['_originValidation'](_0x1df44d);const _0x430211=await Fr(_0x1df44d,_0x1882ce,_0x932ae9,Mi(),_0x1d8588);return hp(_0x430211),new Promise(()=>{});}['_initialize'](_0x23e9c8){const _0x3bc880=_0x23e9c8['_key']();if(this['eventManagers'][_0x3bc880]){const {manager:_0x3b9243,promise:_0x5c57fc}=this['eventManagers'][_0x3bc880];return _0x3b9243?Promise['resolve'](_0x3b9243):(ce(_0x5c57fc,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5c57fc);}const _0x40ac24=this['initAndGetManager'](_0x23e9c8);return this['eventManagers'][_0x3bc880]={'promise':_0x40ac24},_0x40ac24['catch'](()=>{delete this['eventManagers'][_0x3bc880];}),_0x40ac24;}async['initAndGetManager'](_0x10fcd9){const _0x4f9226=await Yp(_0x10fcd9),_0x5c7bec=new Dp(_0x10fcd9);return _0x4f9226['register']('authEvent',_0x5d4c09=>(m(_0x5d4c09==null?void 0x0:_0x5d4c09['authEvent'],_0x10fcd9,'invalid-auth-event'),{'status':_0x5c7bec['onEvent'](_0x5d4c09['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x10fcd9['_key']()]={'manager':_0x5c7bec},this['iframes'][_0x10fcd9['_key']()]=_0x4f9226,_0x5c7bec;}['_isIframeWebStorageSupported'](_0x13f200,_0x1d48c9){this['iframes'][_0x13f200['_key']()]['send'](pi,{'type':pi},_0x5b07cc=>{var _0x1f70a3;const _0x8fa690=(_0x1f70a3=_0x5b07cc==null?void 0x0:_0x5b07cc[0x0])==null?void 0x0:_0x1f70a3[pi];_0x8fa690!==void 0x0&&_0x1d48c9(!!_0x8fa690),Y(_0x13f200,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3fcaa1){const _0x35c0bd=_0x3fcaa1['_key']();return this['originValidationPromises'][_0x35c0bd]||(this['originValidationPromises'][_0x35c0bd]=Up(_0x3fcaa1)),this['originValidationPromises'][_0x35c0bd];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3f4f45){this['auth']=_0x3f4f45,this['internalListeners']=new Map();}['getUid'](){var _0x554068;return this['assertAuthConfigured'](),((_0x554068=this['auth']['currentUser'])==null?void 0x0:_0x554068['uid'])||null;}async['getToken'](_0x333aa3){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x333aa3)}:null;}['addAuthTokenListener'](_0x4f17c0){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4f17c0))return;const _0x2fb4e4=this['auth']['onIdTokenChanged'](_0x357f08=>{_0x4f17c0((_0x357f08==null?void 0x0:_0x357f08['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4f17c0,_0x2fb4e4),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x83a425){this['assertAuthConfigured']();const _0x23f31c=this['internalListeners']['get'](_0x83a425);_0x23f31c&&(this['internalListeners']['delete'](_0x83a425),_0x23f31c(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x52bb2e){switch(_0x52bb2e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2db022){st(new Fe('auth',(_0x35355f,{options:_0x3cda08})=>{const _0x3edc90=_0x35355f['getProvider']('app')['getImmediate'](),_0x43a55b=_0x35355f['getProvider']('heartbeat'),_0x163d79=_0x35355f['getProvider']('app-check-internal'),{apiKey:_0x131ad8,authDomain:_0x125082}=_0x3edc90['options'];m(_0x131ad8&&!_0x131ad8['includes'](':'),'invalid-api-key',{'appName':_0x3edc90['name']});const _0x2c92d2={'apiKey':_0x131ad8,'authDomain':_0x125082,'clientPlatform':_0x2db022,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2db022)},_0x2421c6=new Df(_0x3edc90,_0x43a55b,_0x163d79,_0x2c92d2);return Hf(_0x2421c6,_0x3cda08),_0x2421c6;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x39e18e,_0x3791f6,_0x51e66b)=>{_0x39e18e['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x422866=>{const _0x420b35=Ke(_0x422866['getProvider']('auth')['getImmediate']());return(_0x16b972=>new l_(_0x16b972))(_0x420b35);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2db022)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1e3205=>async _0x57e3c8=>{const _0x4c74a4=_0x57e3c8&&await _0x57e3c8['getIdTokenResult'](),_0xb94c46=_0x4c74a4&&(new Date()['getTime']()-Date['parse'](_0x4c74a4['issuedAtTime']))/0x3e8;if(_0xb94c46&&_0xb94c46>f_)return;const _0x2785e0=_0x4c74a4==null?void 0x0:_0x4c74a4['token'];Br!==_0x2785e0&&(Br=_0x2785e0,await fetch(_0x1e3205,{'method':_0x2785e0?'POST':'DELETE','headers':_0x2785e0?{'Authorization':'Bearer\x20'+_0x2785e0}:{}}));};function B_(_0x42da23=Zr()){const _0x21e8fd=Hi(_0x42da23,'auth');if(_0x21e8fd['isInitialized']())return _0x21e8fd['getImmediate']();const _0x26a5ec=Vf(_0x42da23,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x43fbee=jr('authTokenSyncURL');if(_0x43fbee&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x6222f1=new URL(_0x43fbee,location['origin']);if(location['origin']===_0x6222f1['origin']){const _0x5a5944=p_(_0x6222f1['toString']());sp(_0x26a5ec,_0x5a5944,()=>_0x5a5944(_0x26a5ec['currentUser'])),ip(_0x26a5ec,_0x49e771=>_0x5a5944(_0x49e771));}}const _0xc626bc=qr('auth');return _0xc626bc&&$f(_0x26a5ec,'http://'+_0xc626bc),_0x26a5ec;}function __(){var _0x10ece3;return((_0x10ece3=document['getElementsByTagName']('head'))==null?void 0x0:_0x10ece3[0x0])??document;}Mf({'loadJS'(_0x588b21){return new Promise((_0x14d7cd,_0x55605d)=>{const _0x3a16ec=document['createElement']('script');_0x3a16ec['setAttribute']('src',_0x588b21),_0x3a16ec['onload']=_0x14d7cd,_0x3a16ec['onerror']=_0x48a4e1=>{const _0x19e550=X('internal-error');_0x19e550['customData']=_0x48a4e1,_0x55605d(_0x19e550);},_0x3a16ec['type']='text/javascript',_0x3a16ec['charset']='UTF-8',__()['appendChild'](_0x3a16ec);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};