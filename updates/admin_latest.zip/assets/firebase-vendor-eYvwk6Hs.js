const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x199516,_0xf6947f){if(!_0x199516)throw ht(_0xf6947f);},ht=function(_0x3bff3d){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3bff3d);},Hr=function(_0x23cbe8){const _0x2b36c9=[];let _0x1c10b4=0x0;for(let _0x40ef04=0x0;_0x40ef04<_0x23cbe8['length'];_0x40ef04++){let _0x23828d=_0x23cbe8['charCodeAt'](_0x40ef04);_0x23828d<0x80?_0x2b36c9[_0x1c10b4++]=_0x23828d:_0x23828d<0x800?(_0x2b36c9[_0x1c10b4++]=_0x23828d>>0x6|0xc0,_0x2b36c9[_0x1c10b4++]=_0x23828d&0x3f|0x80):(_0x23828d&0xfc00)===0xd800&&_0x40ef04+0x1<_0x23cbe8['length']&&(_0x23cbe8['charCodeAt'](_0x40ef04+0x1)&0xfc00)===0xdc00?(_0x23828d=0x10000+((_0x23828d&0x3ff)<<0xa)+(_0x23cbe8['charCodeAt'](++_0x40ef04)&0x3ff),_0x2b36c9[_0x1c10b4++]=_0x23828d>>0x12|0xf0,_0x2b36c9[_0x1c10b4++]=_0x23828d>>0xc&0x3f|0x80,_0x2b36c9[_0x1c10b4++]=_0x23828d>>0x6&0x3f|0x80,_0x2b36c9[_0x1c10b4++]=_0x23828d&0x3f|0x80):(_0x2b36c9[_0x1c10b4++]=_0x23828d>>0xc|0xe0,_0x2b36c9[_0x1c10b4++]=_0x23828d>>0x6&0x3f|0x80,_0x2b36c9[_0x1c10b4++]=_0x23828d&0x3f|0x80);}return _0x2b36c9;},nc=function(_0x334546){const _0x3bb679=[];let _0x478e61=0x0,_0x5d248e=0x0;for(;_0x478e61<_0x334546['length'];){const _0x32ffd5=_0x334546[_0x478e61++];if(_0x32ffd5<0x80)_0x3bb679[_0x5d248e++]=String['fromCharCode'](_0x32ffd5);else{if(_0x32ffd5>0xbf&&_0x32ffd5<0xe0){const _0x533d8b=_0x334546[_0x478e61++];_0x3bb679[_0x5d248e++]=String['fromCharCode']((_0x32ffd5&0x1f)<<0x6|_0x533d8b&0x3f);}else{if(_0x32ffd5>0xef&&_0x32ffd5<0x16d){const _0x21993b=_0x334546[_0x478e61++],_0x2a20bc=_0x334546[_0x478e61++],_0x4b800a=_0x334546[_0x478e61++],_0x2e4ae7=((_0x32ffd5&0x7)<<0x12|(_0x21993b&0x3f)<<0xc|(_0x2a20bc&0x3f)<<0x6|_0x4b800a&0x3f)-0x10000;_0x3bb679[_0x5d248e++]=String['fromCharCode'](0xd800+(_0x2e4ae7>>0xa)),_0x3bb679[_0x5d248e++]=String['fromCharCode'](0xdc00+(_0x2e4ae7&0x3ff));}else{const _0x530e4e=_0x334546[_0x478e61++],_0x4b53e6=_0x334546[_0x478e61++];_0x3bb679[_0x5d248e++]=String['fromCharCode']((_0x32ffd5&0xf)<<0xc|(_0x530e4e&0x3f)<<0x6|_0x4b53e6&0x3f);}}}}return _0x3bb679['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x40f25f,_0x61f5c9){if(!Array['isArray'](_0x40f25f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0xc09839=_0x61f5c9?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x121ab0=[];for(let _0x4ecdc0=0x0;_0x4ecdc0<_0x40f25f['length'];_0x4ecdc0+=0x3){const _0x3798d8=_0x40f25f[_0x4ecdc0],_0x1eada6=_0x4ecdc0+0x1<_0x40f25f['length'],_0x359dbf=_0x1eada6?_0x40f25f[_0x4ecdc0+0x1]:0x0,_0x59b657=_0x4ecdc0+0x2<_0x40f25f['length'],_0x21a8d8=_0x59b657?_0x40f25f[_0x4ecdc0+0x2]:0x0,_0x5c4fb1=_0x3798d8>>0x2,_0x557f10=(_0x3798d8&0x3)<<0x4|_0x359dbf>>0x4;let _0x3258cc=(_0x359dbf&0xf)<<0x2|_0x21a8d8>>0x6,_0x12aa34=_0x21a8d8&0x3f;_0x59b657||(_0x12aa34=0x40,_0x1eada6||(_0x3258cc=0x40)),_0x121ab0['push'](_0xc09839[_0x5c4fb1],_0xc09839[_0x557f10],_0xc09839[_0x3258cc],_0xc09839[_0x12aa34]);}return _0x121ab0['join']('');},'encodeString'(_0x4e98ec,_0x1445df){return this['HAS_NATIVE_SUPPORT']&&!_0x1445df?btoa(_0x4e98ec):this['encodeByteArray'](Hr(_0x4e98ec),_0x1445df);},'decodeString'(_0x36236b,_0x3e840){return this['HAS_NATIVE_SUPPORT']&&!_0x3e840?atob(_0x36236b):nc(this['decodeStringToByteArray'](_0x36236b,_0x3e840));},'decodeStringToByteArray'(_0x4492df,_0x89370c){this['init_']();const _0x485a96=_0x89370c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xdec8f1=[];for(let _0x50cfa0=0x0;_0x50cfa0<_0x4492df['length'];){const _0x3fe34c=_0x485a96[_0x4492df['charAt'](_0x50cfa0++)],_0x2f2f28=_0x50cfa0<_0x4492df['length']?_0x485a96[_0x4492df['charAt'](_0x50cfa0)]:0x0;++_0x50cfa0;const _0x138253=_0x50cfa0<_0x4492df['length']?_0x485a96[_0x4492df['charAt'](_0x50cfa0)]:0x40;++_0x50cfa0;const _0x332ddf=_0x50cfa0<_0x4492df['length']?_0x485a96[_0x4492df['charAt'](_0x50cfa0)]:0x40;if(++_0x50cfa0,_0x3fe34c==null||_0x2f2f28==null||_0x138253==null||_0x332ddf==null)throw new ic();const _0x3a1938=_0x3fe34c<<0x2|_0x2f2f28>>0x4;if(_0xdec8f1['push'](_0x3a1938),_0x138253!==0x40){const _0x57db7a=_0x2f2f28<<0x4&0xf0|_0x138253>>0x2;if(_0xdec8f1['push'](_0x57db7a),_0x332ddf!==0x40){const _0x14da2e=_0x138253<<0x6&0xc0|_0x332ddf;_0xdec8f1['push'](_0x14da2e);}}}return _0xdec8f1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3b9400=0x0;_0x3b9400<this['ENCODED_VALS']['length'];_0x3b9400++)this['byteToCharMap_'][_0x3b9400]=this['ENCODED_VALS']['charAt'](_0x3b9400),this['charToByteMap_'][this['byteToCharMap_'][_0x3b9400]]=_0x3b9400,this['byteToCharMapWebSafe_'][_0x3b9400]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3b9400),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3b9400]]=_0x3b9400,_0x3b9400>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3b9400)]=_0x3b9400,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3b9400)]=_0x3b9400);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3f67f1){const _0x396c0c=Hr(_0x3f67f1);return Fi['encodeByteArray'](_0x396c0c,!0x0);},dn=function(_0x26b932){return $r(_0x26b932)['replace'](/\./g,'');},fn=function(_0x4968fb){try{return Fi['decodeString'](_0x4968fb,!0x0);}catch(_0x14a41b){console['error']('base64Decode\x20failed:\x20',_0x14a41b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x335b80){return Gr(void 0x0,_0x335b80);}function Gr(_0x2c4fb1,_0x54dab2){if(!(_0x54dab2 instanceof Object))return _0x54dab2;switch(_0x54dab2['constructor']){case Date:const _0x253de4=_0x54dab2;return new Date(_0x253de4['getTime']());case Object:_0x2c4fb1===void 0x0&&(_0x2c4fb1={});break;case Array:_0x2c4fb1=[];break;default:return _0x54dab2;}for(const _0x31f767 in _0x54dab2)!_0x54dab2['hasOwnProperty'](_0x31f767)||!rc(_0x31f767)||(_0x2c4fb1[_0x31f767]=Gr(_0x2c4fb1[_0x31f767],_0x54dab2[_0x31f767]));return _0x2c4fb1;}function rc(_0x4031c7){return _0x4031c7!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x5d8a90=Ps['__FIREBASE_DEFAULTS__'];if(_0x5d8a90)return JSON['parse'](_0x5d8a90);},lc=()=>{if(typeof document>'u')return;let _0x39105b;try{_0x39105b=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x41312f=_0x39105b&&fn(_0x39105b[0x1]);return _0x41312f&&JSON['parse'](_0x41312f);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xa9aae4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xa9aae4);return;}},qr=_0x35fac4=>{var _0xa1975,_0x5ce0c7;return(_0x5ce0c7=(_0xa1975=Ui())==null?void 0x0:_0xa1975['emulatorHosts'])==null?void 0x0:_0x5ce0c7[_0x35fac4];},hc=_0x12b995=>{const _0x479f31=qr(_0x12b995);if(!_0x479f31)return;const _0x4830ff=_0x479f31['lastIndexOf'](':');if(_0x4830ff<=0x0||_0x4830ff+0x1===_0x479f31['length'])throw new Error('Invalid\x20host\x20'+_0x479f31+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x18ba95=parseInt(_0x479f31['substring'](_0x4830ff+0x1),0xa);return _0x479f31[0x0]==='['?[_0x479f31['substring'](0x1,_0x4830ff-0x1),_0x18ba95]:[_0x479f31['substring'](0x0,_0x4830ff),_0x18ba95];},zr=()=>{var _0x2de0e8;return(_0x2de0e8=Ui())==null?void 0x0:_0x2de0e8['config'];},jr=_0x72a5dd=>{var _0x88100b;return(_0x88100b=Ui())==null?void 0x0:_0x88100b['_'+_0x72a5dd];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5acc41,_0x4d379d)=>{this['resolve']=_0x5acc41,this['reject']=_0x4d379d;});}['wrapCallback'](_0x4a39ca){return(_0x1067f7,_0xd2bd53)=>{_0x1067f7?this['reject'](_0x1067f7):this['resolve'](_0xd2bd53),typeof _0x4a39ca=='function'&&(this['promise']['catch'](()=>{}),_0x4a39ca['length']===0x1?_0x4a39ca(_0x1067f7):_0x4a39ca(_0x1067f7,_0xd2bd53));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x5b7967,_0x1c4b53){if(_0x5b7967['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x3eb8ea={'alg':'none','type':'JWT'},_0x2e3302=_0x1c4b53||'demo-project',_0x45c913=_0x5b7967['iat']||0x0,_0x1b90c5=_0x5b7967['sub']||_0x5b7967['user_id'];if(!_0x1b90c5)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x11463c={'iss':'https://securetoken.google.com/'+_0x2e3302,'aud':_0x2e3302,'iat':_0x45c913,'exp':_0x45c913+0xe10,'auth_time':_0x45c913,'sub':_0x1b90c5,'user_id':_0x1b90c5,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x5b7967};return[dn(JSON['stringify'](_0x3eb8ea)),dn(JSON['stringify'](_0x11463c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x57ad5c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x57ad5c=='object'&&_0x57ad5c['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1a5ffa=W();return _0x1a5ffa['indexOf']('MSIE\x20')>=0x0||_0x1a5ffa['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x24dc6d,_0x43f05f)=>{try{let _0x46626a=!0x0;const _0x13840a='validate-browser-context-for-indexeddb-analytics-module',_0x3cc1e8=self['indexedDB']['open'](_0x13840a);_0x3cc1e8['onsuccess']=()=>{_0x3cc1e8['result']['close'](),_0x46626a||self['indexedDB']['deleteDatabase'](_0x13840a),_0x24dc6d(!0x0);},_0x3cc1e8['onupgradeneeded']=()=>{_0x46626a=!0x1;},_0x3cc1e8['onerror']=()=>{var _0x1b0e7a;_0x43f05f(((_0x1b0e7a=_0x3cc1e8['error'])==null?void 0x0:_0x1b0e7a['message'])||'');};}catch(_0x50f976){_0x43f05f(_0x50f976);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x29f349,_0x103be0,_0x1a4cb8){super(_0x103be0),this['code']=_0x29f349,this['customData']=_0x1a4cb8,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x548ed2,_0x554423,_0x20429b){this['service']=_0x548ed2,this['serviceName']=_0x554423,this['errors']=_0x20429b;}['create'](_0x6bea95,..._0x4300bf){const _0x286158=_0x4300bf[0x0]||{},_0x5274d5=this['service']+'/'+_0x6bea95,_0x5306f1=this['errors'][_0x6bea95],_0x1ccb6d=_0x5306f1?vc(_0x5306f1,_0x286158):'Error',_0x9b7216=this['serviceName']+':\x20'+_0x1ccb6d+'\x20('+_0x5274d5+').';return new Re(_0x5274d5,_0x9b7216,_0x286158);}}function vc(_0x55186a,_0x24ac2d){return _0x55186a['replace'](Ec,(_0x2c7a6e,_0x1d4441)=>{const _0x236da2=_0x24ac2d[_0x1d4441];return _0x236da2!=null?String(_0x236da2):'<'+_0x1d4441+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2b88b1){return JSON['parse'](_0x2b88b1);}function O(_0x3b7e0d){return JSON['stringify'](_0x3b7e0d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x4362ec){let _0xe3dc7e={},_0x294648={},_0x214f69={},_0x491d61='';try{const _0x7ead78=_0x4362ec['split']('.');_0xe3dc7e=Nt(fn(_0x7ead78[0x0])||''),_0x294648=Nt(fn(_0x7ead78[0x1])||''),_0x491d61=_0x7ead78[0x2],_0x214f69=_0x294648['d']||{},delete _0x294648['d'];}catch{}return{'header':_0xe3dc7e,'claims':_0x294648,'data':_0x214f69,'signature':_0x491d61};},Ic=function(_0x303d8e){const _0x499fcd=Yr(_0x303d8e),_0x3b2a09=_0x499fcd['claims'];return!!_0x3b2a09&&typeof _0x3b2a09=='object'&&_0x3b2a09['hasOwnProperty']('iat');},wc=function(_0x2b60eb){const _0x1b8956=Yr(_0x2b60eb)['claims'];return typeof _0x1b8956=='object'&&_0x1b8956['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5e8a78,_0x2b65fa){return Object['prototype']['hasOwnProperty']['call'](_0x5e8a78,_0x2b65fa);}function Le(_0x4af326,_0x1e801f){if(Object['prototype']['hasOwnProperty']['call'](_0x4af326,_0x1e801f))return _0x4af326[_0x1e801f];}function pn(_0x21826d){for(const _0x47f4b2 in _0x21826d)if(Object['prototype']['hasOwnProperty']['call'](_0x21826d,_0x47f4b2))return!0x1;return!0x0;}function _n(_0x2c9b1f,_0x55a5af,_0x2881e8){const _0x27a158={};for(const _0x459a50 in _0x2c9b1f)Object['prototype']['hasOwnProperty']['call'](_0x2c9b1f,_0x459a50)&&(_0x27a158[_0x459a50]=_0x55a5af['call'](_0x2881e8,_0x2c9b1f[_0x459a50],_0x459a50,_0x2c9b1f));return _0x27a158;}function xe(_0x2f0c53,_0x47770b){if(_0x2f0c53===_0x47770b)return!0x0;const _0x26fe9d=Object['keys'](_0x2f0c53),_0x5a29ec=Object['keys'](_0x47770b);for(const _0x45abc4 of _0x26fe9d){if(!_0x5a29ec['includes'](_0x45abc4))return!0x1;const _0x608f13=_0x2f0c53[_0x45abc4],_0x3a1648=_0x47770b[_0x45abc4];if(Ns(_0x608f13)&&Ns(_0x3a1648)){if(!xe(_0x608f13,_0x3a1648))return!0x1;}else{if(_0x608f13!==_0x3a1648)return!0x1;}}for(const _0x3ef8a3 of _0x5a29ec)if(!_0x26fe9d['includes'](_0x3ef8a3))return!0x1;return!0x0;}function Ns(_0x30c2a6){return _0x30c2a6!==null&&typeof _0x30c2a6=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x53fe66){const _0x582fd6=[];for(const [_0x2740a5,_0x2777e6]of Object['entries'](_0x53fe66))Array['isArray'](_0x2777e6)?_0x2777e6['forEach'](_0xf89085=>{_0x582fd6['push'](encodeURIComponent(_0x2740a5)+'='+encodeURIComponent(_0xf89085));}):_0x582fd6['push'](encodeURIComponent(_0x2740a5)+'='+encodeURIComponent(_0x2777e6));return _0x582fd6['length']?'&'+_0x582fd6['join']('&'):'';}function Ct(_0x231f20){const _0x4ad11a={};return _0x231f20['replace'](/^\?/,'')['split']('&')['forEach'](_0xbc78c3=>{if(_0xbc78c3){const [_0x137bad,_0x34e124]=_0xbc78c3['split']('=');_0x4ad11a[decodeURIComponent(_0x137bad)]=decodeURIComponent(_0x34e124);}}),_0x4ad11a;}function Tt(_0x30596f){const _0x2acee4=_0x30596f['indexOf']('?');if(!_0x2acee4)return'';const _0x25069d=_0x30596f['indexOf']('#',_0x2acee4);return _0x30596f['substring'](_0x2acee4,_0x25069d>0x0?_0x25069d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3799cb=0x1;_0x3799cb<this['blockSize'];++_0x3799cb)this['pad_'][_0x3799cb]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x31481c,_0x145815){_0x145815||(_0x145815=0x0);const _0x853764=this['W_'];if(typeof _0x31481c=='string'){for(let _0x45406c=0x0;_0x45406c<0x10;_0x45406c++)_0x853764[_0x45406c]=_0x31481c['charCodeAt'](_0x145815)<<0x18|_0x31481c['charCodeAt'](_0x145815+0x1)<<0x10|_0x31481c['charCodeAt'](_0x145815+0x2)<<0x8|_0x31481c['charCodeAt'](_0x145815+0x3),_0x145815+=0x4;}else{for(let _0x71e0de=0x0;_0x71e0de<0x10;_0x71e0de++)_0x853764[_0x71e0de]=_0x31481c[_0x145815]<<0x18|_0x31481c[_0x145815+0x1]<<0x10|_0x31481c[_0x145815+0x2]<<0x8|_0x31481c[_0x145815+0x3],_0x145815+=0x4;}for(let _0x36d7ef=0x10;_0x36d7ef<0x50;_0x36d7ef++){const _0x1fc304=_0x853764[_0x36d7ef-0x3]^_0x853764[_0x36d7ef-0x8]^_0x853764[_0x36d7ef-0xe]^_0x853764[_0x36d7ef-0x10];_0x853764[_0x36d7ef]=(_0x1fc304<<0x1|_0x1fc304>>>0x1f)&0xffffffff;}let _0x318a5d=this['chain_'][0x0],_0xad75f=this['chain_'][0x1],_0x3baca7=this['chain_'][0x2],_0x142bb7=this['chain_'][0x3],_0x3ba52b=this['chain_'][0x4],_0x26471b,_0x354d45;for(let _0x1f5eb0=0x0;_0x1f5eb0<0x50;_0x1f5eb0++){_0x1f5eb0<0x28?_0x1f5eb0<0x14?(_0x26471b=_0x142bb7^_0xad75f&(_0x3baca7^_0x142bb7),_0x354d45=0x5a827999):(_0x26471b=_0xad75f^_0x3baca7^_0x142bb7,_0x354d45=0x6ed9eba1):_0x1f5eb0<0x3c?(_0x26471b=_0xad75f&_0x3baca7|_0x142bb7&(_0xad75f|_0x3baca7),_0x354d45=0x8f1bbcdc):(_0x26471b=_0xad75f^_0x3baca7^_0x142bb7,_0x354d45=0xca62c1d6);const _0x381caf=(_0x318a5d<<0x5|_0x318a5d>>>0x1b)+_0x26471b+_0x3ba52b+_0x354d45+_0x853764[_0x1f5eb0]&0xffffffff;_0x3ba52b=_0x142bb7,_0x142bb7=_0x3baca7,_0x3baca7=(_0xad75f<<0x1e|_0xad75f>>>0x2)&0xffffffff,_0xad75f=_0x318a5d,_0x318a5d=_0x381caf;}this['chain_'][0x0]=this['chain_'][0x0]+_0x318a5d&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xad75f&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3baca7&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x142bb7&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3ba52b&0xffffffff;}['update'](_0x2d3e85,_0x14f990){if(_0x2d3e85==null)return;_0x14f990===void 0x0&&(_0x14f990=_0x2d3e85['length']);const _0x1e1289=_0x14f990-this['blockSize'];let _0x43da95=0x0;const _0x169fd8=this['buf_'];let _0x126a74=this['inbuf_'];for(;_0x43da95<_0x14f990;){if(_0x126a74===0x0){for(;_0x43da95<=_0x1e1289;)this['compress_'](_0x2d3e85,_0x43da95),_0x43da95+=this['blockSize'];}if(typeof _0x2d3e85=='string'){for(;_0x43da95<_0x14f990;)if(_0x169fd8[_0x126a74]=_0x2d3e85['charCodeAt'](_0x43da95),++_0x126a74,++_0x43da95,_0x126a74===this['blockSize']){this['compress_'](_0x169fd8),_0x126a74=0x0;break;}}else{for(;_0x43da95<_0x14f990;)if(_0x169fd8[_0x126a74]=_0x2d3e85[_0x43da95],++_0x126a74,++_0x43da95,_0x126a74===this['blockSize']){this['compress_'](_0x169fd8),_0x126a74=0x0;break;}}}this['inbuf_']=_0x126a74,this['total_']+=_0x14f990;}['digest'](){const _0x2ddd3e=[];let _0x179bab=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4e470a=this['blockSize']-0x1;_0x4e470a>=0x38;_0x4e470a--)this['buf_'][_0x4e470a]=_0x179bab&0xff,_0x179bab/=0x100;this['compress_'](this['buf_']);let _0x594d1d=0x0;for(let _0x48cf1d=0x0;_0x48cf1d<0x5;_0x48cf1d++)for(let _0x1a97d2=0x18;_0x1a97d2>=0x0;_0x1a97d2-=0x8)_0x2ddd3e[_0x594d1d]=this['chain_'][_0x48cf1d]>>_0x1a97d2&0xff,++_0x594d1d;return _0x2ddd3e;}}function Tc(_0x5f3dec,_0xda9ff6){const _0x44c249=new Sc(_0x5f3dec,_0xda9ff6);return _0x44c249['subscribe']['bind'](_0x44c249);}class Sc{constructor(_0x4e567a,_0x11e923){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x11e923,this['task']['then'](()=>{_0x4e567a(this);})['catch'](_0x1e13f5=>{this['error'](_0x1e13f5);});}['next'](_0x10c7c0){this['forEachObserver'](_0x149aa9=>{_0x149aa9['next'](_0x10c7c0);});}['error'](_0x4f3a93){this['forEachObserver'](_0x50e4b6=>{_0x50e4b6['error'](_0x4f3a93);}),this['close'](_0x4f3a93);}['complete'](){this['forEachObserver'](_0xa3307f=>{_0xa3307f['complete']();}),this['close']();}['subscribe'](_0x44af72,_0xf0b706,_0x17923e){let _0x2c9ddd;if(_0x44af72===void 0x0&&_0xf0b706===void 0x0&&_0x17923e===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x44af72,['next','error','complete'])?_0x2c9ddd=_0x44af72:_0x2c9ddd={'next':_0x44af72,'error':_0xf0b706,'complete':_0x17923e},_0x2c9ddd['next']===void 0x0&&(_0x2c9ddd['next']=ti),_0x2c9ddd['error']===void 0x0&&(_0x2c9ddd['error']=ti),_0x2c9ddd['complete']===void 0x0&&(_0x2c9ddd['complete']=ti);const _0x21354b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2c9ddd['error'](this['finalError']):_0x2c9ddd['complete']();}catch{}}),this['observers']['push'](_0x2c9ddd),_0x21354b;}['unsubscribeOne'](_0x4c6630){this['observers']===void 0x0||this['observers'][_0x4c6630]===void 0x0||(delete this['observers'][_0x4c6630],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x24fa4a){if(!this['finalized']){for(let _0x5ebbd3=0x0;_0x5ebbd3<this['observers']['length'];_0x5ebbd3++)this['sendOne'](_0x5ebbd3,_0x24fa4a);}}['sendOne'](_0x102846,_0x5e0fdb){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x102846]!==void 0x0)try{_0x5e0fdb(this['observers'][_0x102846]);}catch(_0x126546){typeof console<'u'&&console['error']&&console['error'](_0x126546);}});}['close'](_0x47f10e){this['finalized']||(this['finalized']=!0x0,_0x47f10e!==void 0x0&&(this['finalError']=_0x47f10e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x572a9d,_0x51a535){if(typeof _0x572a9d!='object'||_0x572a9d===null)return!0x1;for(const _0x15a404 of _0x51a535)if(_0x15a404 in _0x572a9d&&typeof _0x572a9d[_0x15a404]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x583f68,_0x172b87){return _0x583f68+'\x20failed:\x20'+_0x172b87+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x7b7dd1){const _0x16c5ec=[];let _0x4ffae5=0x0;for(let _0x1ecb33=0x0;_0x1ecb33<_0x7b7dd1['length'];_0x1ecb33++){let _0x176d24=_0x7b7dd1['charCodeAt'](_0x1ecb33);if(_0x176d24>=0xd800&&_0x176d24<=0xdbff){const _0x1ed0a5=_0x176d24-0xd800;_0x1ecb33++,f(_0x1ecb33<_0x7b7dd1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x8efff5=_0x7b7dd1['charCodeAt'](_0x1ecb33)-0xdc00;_0x176d24=0x10000+(_0x1ed0a5<<0xa)+_0x8efff5;}_0x176d24<0x80?_0x16c5ec[_0x4ffae5++]=_0x176d24:_0x176d24<0x800?(_0x16c5ec[_0x4ffae5++]=_0x176d24>>0x6|0xc0,_0x16c5ec[_0x4ffae5++]=_0x176d24&0x3f|0x80):_0x176d24<0x10000?(_0x16c5ec[_0x4ffae5++]=_0x176d24>>0xc|0xe0,_0x16c5ec[_0x4ffae5++]=_0x176d24>>0x6&0x3f|0x80,_0x16c5ec[_0x4ffae5++]=_0x176d24&0x3f|0x80):(_0x16c5ec[_0x4ffae5++]=_0x176d24>>0x12|0xf0,_0x16c5ec[_0x4ffae5++]=_0x176d24>>0xc&0x3f|0x80,_0x16c5ec[_0x4ffae5++]=_0x176d24>>0x6&0x3f|0x80,_0x16c5ec[_0x4ffae5++]=_0x176d24&0x3f|0x80);}return _0x16c5ec;},Ln=function(_0xe2e751){let _0x19033e=0x0;for(let _0x127ce0=0x0;_0x127ce0<_0xe2e751['length'];_0x127ce0++){const _0x5e7aa5=_0xe2e751['charCodeAt'](_0x127ce0);_0x5e7aa5<0x80?_0x19033e++:_0x5e7aa5<0x800?_0x19033e+=0x2:_0x5e7aa5>=0xd800&&_0x5e7aa5<=0xdbff?(_0x19033e+=0x4,_0x127ce0++):_0x19033e+=0x3;}return _0x19033e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x2c924e){return _0x2c924e&&_0x2c924e['_delegate']?_0x2c924e['_delegate']:_0x2c924e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x2c7b64){try{return(_0x2c7b64['startsWith']('http://')||_0x2c7b64['startsWith']('https://')?new URL(_0x2c7b64)['hostname']:_0x2c7b64)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x40aa85){return(await fetch(_0x40aa85,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x3e1558,_0x1bf001,_0x4bb5da){this['name']=_0x3e1558,this['instanceFactory']=_0x1bf001,this['type']=_0x4bb5da,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x55c21f){return this['instantiationMode']=_0x55c21f,this;}['setMultipleInstances'](_0x4a59e1){return this['multipleInstances']=_0x4a59e1,this;}['setServiceProps'](_0x192202){return this['serviceProps']=_0x192202,this;}['setInstanceCreatedCallback'](_0x509ed4){return this['onInstanceCreated']=_0x509ed4,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x35f4a0,_0x2d21c8){this['name']=_0x35f4a0,this['container']=_0x2d21c8,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x20c2e3){const _0xfe97c1=this['normalizeInstanceIdentifier'](_0x20c2e3);if(!this['instancesDeferred']['has'](_0xfe97c1)){const _0x143f00=new H();if(this['instancesDeferred']['set'](_0xfe97c1,_0x143f00),this['isInitialized'](_0xfe97c1)||this['shouldAutoInitialize']())try{const _0x1b49da=this['getOrInitializeService']({'instanceIdentifier':_0xfe97c1});_0x1b49da&&_0x143f00['resolve'](_0x1b49da);}catch{}}return this['instancesDeferred']['get'](_0xfe97c1)['promise'];}['getImmediate'](_0x9e530b){const _0x49d266=this['normalizeInstanceIdentifier'](_0x9e530b==null?void 0x0:_0x9e530b['identifier']),_0x55ace4=(_0x9e530b==null?void 0x0:_0x9e530b['optional'])??!0x1;if(this['isInitialized'](_0x49d266)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x49d266});}catch(_0x35b158){if(_0x55ace4)return null;throw _0x35b158;}else{if(_0x55ace4)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x26488d){if(_0x26488d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x26488d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x26488d,!!this['shouldAutoInitialize']()){if(Pc(_0x26488d))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x38ba0b,_0x15c0a6]of this['instancesDeferred']['entries']()){const _0x4074af=this['normalizeInstanceIdentifier'](_0x38ba0b);try{const _0x434185=this['getOrInitializeService']({'instanceIdentifier':_0x4074af});_0x15c0a6['resolve'](_0x434185);}catch{}}}}['clearInstance'](_0x28c054=Ne){this['instancesDeferred']['delete'](_0x28c054),this['instancesOptions']['delete'](_0x28c054),this['instances']['delete'](_0x28c054);}async['delete'](){const _0x40d129=Array['from'](this['instances']['values']());await Promise['all']([..._0x40d129['filter'](_0x5aa01d=>'INTERNAL'in _0x5aa01d)['map'](_0x26d4d1=>_0x26d4d1['INTERNAL']['delete']()),..._0x40d129['filter'](_0x5431fc=>'_delete'in _0x5431fc)['map'](_0x338a7a=>_0x338a7a['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1883db=Ne){return this['instances']['has'](_0x1883db);}['getOptions'](_0x3627f1=Ne){return this['instancesOptions']['get'](_0x3627f1)||{};}['initialize'](_0x117af2={}){const {options:_0x7022db={}}=_0x117af2,_0x18688e=this['normalizeInstanceIdentifier'](_0x117af2['instanceIdentifier']);if(this['isInitialized'](_0x18688e))throw Error(this['name']+'('+_0x18688e+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x334a22=this['getOrInitializeService']({'instanceIdentifier':_0x18688e,'options':_0x7022db});for(const [_0x375018,_0x4ff25c]of this['instancesDeferred']['entries']()){const _0x564ccd=this['normalizeInstanceIdentifier'](_0x375018);_0x18688e===_0x564ccd&&_0x4ff25c['resolve'](_0x334a22);}return _0x334a22;}['onInit'](_0x134861,_0x20888d){const _0x284d0d=this['normalizeInstanceIdentifier'](_0x20888d),_0x861d43=this['onInitCallbacks']['get'](_0x284d0d)??new Set();_0x861d43['add'](_0x134861),this['onInitCallbacks']['set'](_0x284d0d,_0x861d43);const _0x299272=this['instances']['get'](_0x284d0d);return _0x299272&&_0x134861(_0x299272,_0x284d0d),()=>{_0x861d43['delete'](_0x134861);};}['invokeOnInitCallbacks'](_0x5cd617,_0x315443){const _0x5ebcad=this['onInitCallbacks']['get'](_0x315443);if(_0x5ebcad){for(const _0x12e2f5 of _0x5ebcad)try{_0x12e2f5(_0x5cd617,_0x315443);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x510805,options:_0x151166={}}){let _0x327796=this['instances']['get'](_0x510805);if(!_0x327796&&this['component']&&(_0x327796=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x510805),'options':_0x151166}),this['instances']['set'](_0x510805,_0x327796),this['instancesOptions']['set'](_0x510805,_0x151166),this['invokeOnInitCallbacks'](_0x327796,_0x510805),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x510805,_0x327796);}catch{}return _0x327796||null;}['normalizeInstanceIdentifier'](_0x4ca743=Ne){return this['component']?this['component']['multipleInstances']?_0x4ca743:Ne:_0x4ca743;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0xd7fe61){return _0xd7fe61===Ne?void 0x0:_0xd7fe61;}function Pc(_0x469048){return _0x469048['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0xacae80){this['name']=_0xacae80,this['providers']=new Map();}['addComponent'](_0x47c5cb){const _0x2cfcbf=this['getProvider'](_0x47c5cb['name']);if(_0x2cfcbf['isComponentSet']())throw new Error('Component\x20'+_0x47c5cb['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x2cfcbf['setComponent'](_0x47c5cb);}['addOrOverwriteComponent'](_0x2cdf30){this['getProvider'](_0x2cdf30['name'])['isComponentSet']()&&this['providers']['delete'](_0x2cdf30['name']),this['addComponent'](_0x2cdf30);}['getProvider'](_0x3d92ac){if(this['providers']['has'](_0x3d92ac))return this['providers']['get'](_0x3d92ac);const _0x51894a=new Ac(_0x3d92ac,this);return this['providers']['set'](_0x3d92ac,_0x51894a),_0x51894a;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x31443f){_0x31443f[_0x31443f['DEBUG']=0x0]='DEBUG',_0x31443f[_0x31443f['VERBOSE']=0x1]='VERBOSE',_0x31443f[_0x31443f['INFO']=0x2]='INFO',_0x31443f[_0x31443f['WARN']=0x3]='WARN',_0x31443f[_0x31443f['ERROR']=0x4]='ERROR',_0x31443f[_0x31443f['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x153087,_0x11a3c6,..._0x16d949)=>{if(_0x11a3c6<_0x153087['logLevel'])return;const _0x3137d1=new Date()['toISOString'](),_0x2ff168=Mc[_0x11a3c6];if(_0x2ff168)console[_0x2ff168]('['+_0x3137d1+']\x20\x20'+_0x153087['name']+':',..._0x16d949);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x11a3c6+')');};class Bi{constructor(_0x32816d){this['name']=_0x32816d,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3f5a84){if(!(_0x3f5a84 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3f5a84+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3f5a84;}['setLogLevel'](_0x44ad07){this['_logLevel']=typeof _0x44ad07=='string'?Oc[_0x44ad07]:_0x44ad07;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2c9fd1){if(typeof _0x2c9fd1!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2c9fd1;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x421bab){this['_userLogHandler']=_0x421bab;}['debug'](..._0x263c70){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x263c70),this['_logHandler'](this,T['DEBUG'],..._0x263c70);}['log'](..._0x218c82){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x218c82),this['_logHandler'](this,T['VERBOSE'],..._0x218c82);}['info'](..._0x26fcf4){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x26fcf4),this['_logHandler'](this,T['INFO'],..._0x26fcf4);}['warn'](..._0x32b720){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x32b720),this['_logHandler'](this,T['WARN'],..._0x32b720);}['error'](..._0x5abafe){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5abafe),this['_logHandler'](this,T['ERROR'],..._0x5abafe);}}const xc=(_0x39c5b8,_0xfb7e78)=>_0xfb7e78['some'](_0x5959b3=>_0x39c5b8 instanceof _0x5959b3);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x8ded28){const _0x2a23ec=new Promise((_0x1e4c7a,_0x4a4962)=>{const _0x19dfc7=()=>{_0x8ded28['removeEventListener']('success',_0x22009e),_0x8ded28['removeEventListener']('error',_0x26d8ca);},_0x22009e=()=>{_0x1e4c7a(ge(_0x8ded28['result'])),_0x19dfc7();},_0x26d8ca=()=>{_0x4a4962(_0x8ded28['error']),_0x19dfc7();};_0x8ded28['addEventListener']('success',_0x22009e),_0x8ded28['addEventListener']('error',_0x26d8ca);});return _0x2a23ec['then'](_0x1af295=>{_0x1af295 instanceof IDBCursor&&Jr['set'](_0x1af295,_0x8ded28);})['catch'](()=>{}),Vi['set'](_0x2a23ec,_0x8ded28),_0x2a23ec;}function Bc(_0x2a789b){if(_i['has'](_0x2a789b))return;const _0x558c2c=new Promise((_0x1a62e1,_0x15b5b6)=>{const _0x315610=()=>{_0x2a789b['removeEventListener']('complete',_0x21f194),_0x2a789b['removeEventListener']('error',_0x3b5ea5),_0x2a789b['removeEventListener']('abort',_0x3b5ea5);},_0x21f194=()=>{_0x1a62e1(),_0x315610();},_0x3b5ea5=()=>{_0x15b5b6(_0x2a789b['error']||new DOMException('AbortError','AbortError')),_0x315610();};_0x2a789b['addEventListener']('complete',_0x21f194),_0x2a789b['addEventListener']('error',_0x3b5ea5),_0x2a789b['addEventListener']('abort',_0x3b5ea5);});_i['set'](_0x2a789b,_0x558c2c);}let gi={'get'(_0x275c14,_0x26f77c,_0x37a967){if(_0x275c14 instanceof IDBTransaction){if(_0x26f77c==='done')return _i['get'](_0x275c14);if(_0x26f77c==='objectStoreNames')return _0x275c14['objectStoreNames']||Xr['get'](_0x275c14);if(_0x26f77c==='store')return _0x37a967['objectStoreNames'][0x1]?void 0x0:_0x37a967['objectStore'](_0x37a967['objectStoreNames'][0x0]);}return ge(_0x275c14[_0x26f77c]);},'set'(_0xc9d6b9,_0x32de97,_0x2ceffb){return _0xc9d6b9[_0x32de97]=_0x2ceffb,!0x0;},'has'(_0x3b08fa,_0x1779c6){return _0x3b08fa instanceof IDBTransaction&&(_0x1779c6==='done'||_0x1779c6==='store')?!0x0:_0x1779c6 in _0x3b08fa;}};function Vc(_0x2a48e7){gi=_0x2a48e7(gi);}function Hc(_0x19b3e4){return _0x19b3e4===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x24ed4e,..._0x45f58c){const _0x524655=_0x19b3e4['call'](ii(this),_0x24ed4e,..._0x45f58c);return Xr['set'](_0x524655,_0x24ed4e['sort']?_0x24ed4e['sort']():[_0x24ed4e]),ge(_0x524655);}:Uc()['includes'](_0x19b3e4)?function(..._0x2f66ac){return _0x19b3e4['apply'](ii(this),_0x2f66ac),ge(Jr['get'](this));}:function(..._0x33ea78){return ge(_0x19b3e4['apply'](ii(this),_0x33ea78));};}function $c(_0x13443e){return typeof _0x13443e=='function'?Hc(_0x13443e):(_0x13443e instanceof IDBTransaction&&Bc(_0x13443e),xc(_0x13443e,Fc())?new Proxy(_0x13443e,gi):_0x13443e);}function ge(_0x1ad112){if(_0x1ad112 instanceof IDBRequest)return Wc(_0x1ad112);if(ni['has'](_0x1ad112))return ni['get'](_0x1ad112);const _0x375bf9=$c(_0x1ad112);return _0x375bf9!==_0x1ad112&&(ni['set'](_0x1ad112,_0x375bf9),Vi['set'](_0x375bf9,_0x1ad112)),_0x375bf9;}const ii=_0x20cd43=>Vi['get'](_0x20cd43);function Gc(_0x23b1cc,_0x3d4c5c,{blocked:_0x77bcad,upgrade:_0x393c70,blocking:_0x581d01,terminated:_0x5a7077}={}){const _0x7f71e2=indexedDB['open'](_0x23b1cc,_0x3d4c5c),_0x4d958d=ge(_0x7f71e2);return _0x393c70&&_0x7f71e2['addEventListener']('upgradeneeded',_0x579412=>{_0x393c70(ge(_0x7f71e2['result']),_0x579412['oldVersion'],_0x579412['newVersion'],ge(_0x7f71e2['transaction']),_0x579412);}),_0x77bcad&&_0x7f71e2['addEventListener']('blocked',_0x14d318=>_0x77bcad(_0x14d318['oldVersion'],_0x14d318['newVersion'],_0x14d318)),_0x4d958d['then'](_0x1970a7=>{_0x5a7077&&_0x1970a7['addEventListener']('close',()=>_0x5a7077()),_0x581d01&&_0x1970a7['addEventListener']('versionchange',_0x10790a=>_0x581d01(_0x10790a['oldVersion'],_0x10790a['newVersion'],_0x10790a));})['catch'](()=>{}),_0x4d958d;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0xd7152b,_0x216f04){if(!(_0xd7152b instanceof IDBDatabase&&!(_0x216f04 in _0xd7152b)&&typeof _0x216f04=='string'))return;if(si['get'](_0x216f04))return si['get'](_0x216f04);const _0x2be1ec=_0x216f04['replace'](/FromIndex$/,''),_0x1d7c8f=_0x216f04!==_0x2be1ec,_0x212a7b=zc['includes'](_0x2be1ec);if(!(_0x2be1ec in(_0x1d7c8f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x212a7b||qc['includes'](_0x2be1ec)))return;const _0x508a1e=async function(_0x5dd1ee,..._0x1b1498){const _0x3402ea=this['transaction'](_0x5dd1ee,_0x212a7b?'readwrite':'readonly');let _0x1dc30e=_0x3402ea['store'];return _0x1d7c8f&&(_0x1dc30e=_0x1dc30e['index'](_0x1b1498['shift']())),(await Promise['all']([_0x1dc30e[_0x2be1ec](..._0x1b1498),_0x212a7b&&_0x3402ea['done']]))[0x0];};return si['set'](_0x216f04,_0x508a1e),_0x508a1e;}Vc(_0x350fd7=>({..._0x350fd7,'get':(_0x4fb585,_0xeefd52,_0x5cb381)=>Ms(_0x4fb585,_0xeefd52)||_0x350fd7['get'](_0x4fb585,_0xeefd52,_0x5cb381),'has':(_0x27d6e7,_0x1f96a3)=>!!Ms(_0x27d6e7,_0x1f96a3)||_0x350fd7['has'](_0x27d6e7,_0x1f96a3)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0xb97824){this['container']=_0xb97824;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x38d547=>{if(Kc(_0x38d547)){const _0x1cb8c0=_0x38d547['getImmediate']();return _0x1cb8c0['library']+'/'+_0x1cb8c0['version'];}else return null;})['filter'](_0x6ca260=>_0x6ca260)['join']('\x20');}}function Kc(_0x1b1691){const _0x21f6f9=_0x1b1691['getComponent']();return(_0x21f6f9==null?void 0x0:_0x21f6f9['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x160a15,_0x46e0a9){try{_0x160a15['container']['addComponent'](_0x46e0a9);}catch(_0x5c324){oe['debug']('Component\x20'+_0x46e0a9['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x160a15['name'],_0x5c324);}}function st(_0x37626f){const _0x156b66=_0x37626f['name'];if(Ei['has'](_0x156b66))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x156b66+'.'),!0x1;Ei['set'](_0x156b66,_0x37626f);for(const _0x824bf3 of Ue['values']())xs(_0x824bf3,_0x37626f);for(const _0x5bad68 of vi['values']())xs(_0x5bad68,_0x37626f);return!0x0;}function Hi(_0x43e6a2,_0x16a569){const _0x1852e0=_0x43e6a2['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1852e0&&_0x1852e0['triggerHeartbeat'](),_0x43e6a2['container']['getProvider'](_0x16a569);}function $(_0x5ad9a6){return _0x5ad9a6==null?!0x1:_0x5ad9a6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1c5965,_0x5259d1,_0x2b0953){this['_isDeleted']=!0x1,this['_options']={..._0x1c5965},this['_config']={..._0x5259d1},this['_name']=_0x5259d1['name'],this['_automaticDataCollectionEnabled']=_0x5259d1['automaticDataCollectionEnabled'],this['_container']=_0x2b0953,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x443ed2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x443ed2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x464d7e){this['_isDeleted']=_0x464d7e;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3e4e36,_0x4602c3={}){let _0x46e1e8=_0x3e4e36;typeof _0x4602c3!='object'&&(_0x4602c3={'name':_0x4602c3});const _0x3cdc25={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4602c3},_0x52e3ae=_0x3cdc25['name'];if(typeof _0x52e3ae!='string'||!_0x52e3ae)throw me['create']('bad-app-name',{'appName':String(_0x52e3ae)});if(_0x46e1e8||(_0x46e1e8=zr()),!_0x46e1e8)throw me['create']('no-options');const _0x4f5d2f=Ue['get'](_0x52e3ae);if(_0x4f5d2f){if(xe(_0x46e1e8,_0x4f5d2f['options'])&&xe(_0x3cdc25,_0x4f5d2f['config']))return _0x4f5d2f;throw me['create']('duplicate-app',{'appName':_0x52e3ae});}const _0x14231c=new Nc(_0x52e3ae);for(const _0x1565e7 of Ei['values']())_0x14231c['addComponent'](_0x1565e7);const _0xc728d4=new Tl(_0x46e1e8,_0x3cdc25,_0x14231c);return Ue['set'](_0x52e3ae,_0xc728d4),_0xc728d4;}function Zr(_0x157ddf=yi){const _0x31b043=Ue['get'](_0x157ddf);if(!_0x31b043&&_0x157ddf===yi&&zr())return Sl();if(!_0x31b043)throw me['create']('no-app',{'appName':_0x157ddf});return _0x31b043;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x99b1f6){let _0x2fd5be=!0x1;const _0x23bc1b=_0x99b1f6['name'];Ue['has'](_0x23bc1b)?(_0x2fd5be=!0x0,Ue['delete'](_0x23bc1b)):vi['has'](_0x23bc1b)&&_0x99b1f6['decRefCount']()<=0x0&&(vi['delete'](_0x23bc1b),_0x2fd5be=!0x0),_0x2fd5be&&(await Promise['all'](_0x99b1f6['container']['getProviders']()['map'](_0x485972=>_0x485972['delete']())),_0x99b1f6['isDeleted']=!0x0);}function ye(_0x383ea5,_0x30deb0,_0x4a6a70){let _0x2dd23c=wl[_0x383ea5]??_0x383ea5;_0x4a6a70&&(_0x2dd23c+='-'+_0x4a6a70);const _0x2a53f9=_0x2dd23c['match'](/\s|\//),_0x334fb1=_0x30deb0['match'](/\s|\//);if(_0x2a53f9||_0x334fb1){const _0x305bba=['Unable\x20to\x20register\x20library\x20\x22'+_0x2dd23c+'\x22\x20with\x20version\x20\x22'+_0x30deb0+'\x22:'];_0x2a53f9&&_0x305bba['push']('library\x20name\x20\x22'+_0x2dd23c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2a53f9&&_0x334fb1&&_0x305bba['push']('and'),_0x334fb1&&_0x305bba['push']('version\x20name\x20\x22'+_0x30deb0+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x305bba['join']('\x20'));return;}st(new Fe(_0x2dd23c+'-version',()=>({'library':_0x2dd23c,'version':_0x30deb0}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3aee04,_0x1e860b)=>{switch(_0x1e860b){case 0x0:try{_0x3aee04['createObjectStore'](Ot);}catch(_0x52a8b2){console['warn'](_0x52a8b2);}}}})['catch'](_0x301c58=>{throw me['create']('idb-open',{'originalErrorMessage':_0x301c58['message']});})),ri;}async function Al(_0x31d960){try{const _0x3c18b9=(await eo())['transaction'](Ot),_0x2384dd=await _0x3c18b9['objectStore'](Ot)['get'](to(_0x31d960));return await _0x3c18b9['done'],_0x2384dd;}catch(_0x1734cd){if(_0x1734cd instanceof Re)oe['warn'](_0x1734cd['message']);else{const _0x56c0f9=me['create']('idb-get',{'originalErrorMessage':_0x1734cd==null?void 0x0:_0x1734cd['message']});oe['warn'](_0x56c0f9['message']);}}}async function Fs(_0x5c0f66,_0x1649fd){try{const _0x1dfb0a=(await eo())['transaction'](Ot,'readwrite');await _0x1dfb0a['objectStore'](Ot)['put'](_0x1649fd,to(_0x5c0f66)),await _0x1dfb0a['done'];}catch(_0x2c9c50){if(_0x2c9c50 instanceof Re)oe['warn'](_0x2c9c50['message']);else{const _0x13679c=me['create']('idb-set',{'originalErrorMessage':_0x2c9c50==null?void 0x0:_0x2c9c50['message']});oe['warn'](_0x13679c['message']);}}}function to(_0x475388){return _0x475388['name']+'!'+_0x475388['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x28d540){this['container']=_0x28d540,this['_heartbeatsCache']=null;const _0x31055b=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x31055b),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5972ed=>(this['_heartbeatsCache']=_0x5972ed,_0x5972ed));}async['triggerHeartbeat'](){var _0x38608e,_0x565b89;try{const _0x1ccb01=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x415118=Us();if(((_0x38608e=this['_heartbeatsCache'])==null?void 0x0:_0x38608e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x565b89=this['_heartbeatsCache'])==null?void 0x0:_0x565b89['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x415118||this['_heartbeatsCache']['heartbeats']['some'](_0x2b85fb=>_0x2b85fb['date']===_0x415118))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x415118,'agent':_0x1ccb01}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x2fa343=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2fa343,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1474b3){oe['warn'](_0x1474b3);}}async['getHeartbeatsHeader'](){var _0x5d1dfc;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5d1dfc=this['_heartbeatsCache'])==null?void 0x0:_0x5d1dfc['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x234832=Us(),{heartbeatsToSend:_0x26e8b6,unsentEntries:_0x4bff3d}=Ol(this['_heartbeatsCache']['heartbeats']),_0x449bb7=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x26e8b6}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x234832,_0x4bff3d['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4bff3d,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x449bb7;}catch(_0x5ec373){return oe['warn'](_0x5ec373),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5c129f,_0x13a865=kl){const _0x5a1963=[];let _0x15f843=_0x5c129f['slice']();for(const _0x49043c of _0x5c129f){const _0x21a442=_0x5a1963['find'](_0x181cba=>_0x181cba['agent']===_0x49043c['agent']);if(_0x21a442){if(_0x21a442['dates']['push'](_0x49043c['date']),Ws(_0x5a1963)>_0x13a865){_0x21a442['dates']['pop']();break;}}else{if(_0x5a1963['push']({'agent':_0x49043c['agent'],'dates':[_0x49043c['date']]}),Ws(_0x5a1963)>_0x13a865){_0x5a1963['pop']();break;}}_0x15f843=_0x15f843['slice'](0x1);}return{'heartbeatsToSend':_0x5a1963,'unsentEntries':_0x15f843};}class Dl{constructor(_0x3ded98){this['app']=_0x3ded98,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xabb874=await Al(this['app']);return _0xabb874!=null&&_0xabb874['heartbeats']?_0xabb874:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x294623){if(await this['_canUseIndexedDBPromise']){const _0x3658b4=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x294623['lastSentHeartbeatDate']??_0x3658b4['lastSentHeartbeatDate'],'heartbeats':_0x294623['heartbeats']});}else return;}async['add'](_0x403d9e){if(await this['_canUseIndexedDBPromise']){const _0x2826f3=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x403d9e['lastSentHeartbeatDate']??_0x2826f3['lastSentHeartbeatDate'],'heartbeats':[..._0x2826f3['heartbeats'],..._0x403d9e['heartbeats']]});}else return;}}function Ws(_0x5c7f95){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x5c7f95}))['length'];}function Ml(_0x3a7cf0){if(_0x3a7cf0['length']===0x0)return-0x1;let _0x4c8909=0x0,_0x168d28=_0x3a7cf0[0x0]['date'];for(let _0x505204=0x1;_0x505204<_0x3a7cf0['length'];_0x505204++)_0x3a7cf0[_0x505204]['date']<_0x168d28&&(_0x168d28=_0x3a7cf0[_0x505204]['date'],_0x4c8909=_0x505204);return _0x4c8909;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x309533){st(new Fe('platform-logger',_0x33ddee=>new jc(_0x33ddee),'PRIVATE')),st(new Fe('heartbeat',_0x45b18f=>new Nl(_0x45b18f),'PRIVATE')),ye(mi,Ls,_0x309533),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2bf445){no=_0x2bf445;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x36ac70){this['domStorage_']=_0x36ac70,this['prefix_']='firebase:';}['set'](_0x367898,_0x30a5fa){_0x30a5fa==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x367898)):this['domStorage_']['setItem'](this['prefixedName_'](_0x367898),O(_0x30a5fa));}['get'](_0x59ab86){const _0x2d0376=this['domStorage_']['getItem'](this['prefixedName_'](_0x59ab86));return _0x2d0376==null?null:Nt(_0x2d0376);}['remove'](_0x1d6bf6){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1d6bf6));}['prefixedName_'](_0xb9e487){return this['prefix_']+_0xb9e487;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x9c8050,_0x2e4e94){_0x2e4e94==null?delete this['cache_'][_0x9c8050]:this['cache_'][_0x9c8050]=_0x2e4e94;}['get'](_0x50c6b1){return Q(this['cache_'],_0x50c6b1)?this['cache_'][_0x50c6b1]:null;}['remove'](_0x4ce42e){delete this['cache_'][_0x4ce42e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1f003e){try{if(typeof window<'u'&&typeof window[_0x1f003e]<'u'){const _0x46f49e=window[_0x1f003e];return _0x46f49e['setItem']('firebase:sentinel','cache'),_0x46f49e['removeItem']('firebase:sentinel'),new Wl(_0x46f49e);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3315c6=0x1;return function(){return _0x3315c6++;};}()),ro=function(_0x52e696){const _0x1fc32a=Rc(_0x52e696),_0x52f611=new Cc();_0x52f611['update'](_0x1fc32a);const _0x233957=_0x52f611['digest']();return Fi['encodeByteArray'](_0x233957);},zt=function(..._0x4ad364){let _0x4a7990='';for(let _0x232ef8=0x0;_0x232ef8<_0x4ad364['length'];_0x232ef8++){const _0x1520a9=_0x4ad364[_0x232ef8];Array['isArray'](_0x1520a9)||_0x1520a9&&typeof _0x1520a9=='object'&&typeof _0x1520a9['length']=='number'?_0x4a7990+=zt['apply'](null,_0x1520a9):typeof _0x1520a9=='object'?_0x4a7990+=O(_0x1520a9):_0x4a7990+=_0x1520a9,_0x4a7990+='\x20';}return _0x4a7990;};let St=null,$s=!0x0;const Hl=function(_0x3c8fbe,_0x2f7110){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x476fd3){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x5d1d8e=zt['apply'](null,_0x476fd3);St(_0x5d1d8e);}},jt=function(_0x17d8c6){return function(..._0x119381){L(_0x17d8c6,..._0x119381);};},Ii=function(..._0x10e00a){const _0x12ce62='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x10e00a);Ze['error'](_0x12ce62);},ae=function(..._0x10837c){const _0x17ca12='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x10837c);throw Ze['error'](_0x17ca12),new Error(_0x17ca12);},U=function(..._0x315373){const _0x3460d2='FIREBASE\x20WARNING:\x20'+zt(..._0x315373);Ze['warn'](_0x3460d2);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2e6047){return typeof _0x2e6047=='number'&&(_0x2e6047!==_0x2e6047||_0x2e6047===Number['POSITIVE_INFINITY']||_0x2e6047===Number['NEGATIVE_INFINITY']);},Gl=function(_0x37639b){if(document['readyState']==='complete')_0x37639b();else{let _0xe3e30b=!0x1;const _0x39bb84=function(){if(!document['body']){setTimeout(_0x39bb84,Math['floor'](0xa));return;}_0xe3e30b||(_0xe3e30b=!0x0,_0x37639b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x39bb84,!0x1),window['addEventListener']('load',_0x39bb84,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x39bb84();}),window['attachEvent']('onload',_0x39bb84));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x3c2792,_0x27b5df){if(_0x3c2792===_0x27b5df)return 0x0;if(_0x3c2792===We||_0x27b5df===we)return-0x1;if(_0x27b5df===We||_0x3c2792===we)return 0x1;{const _0x1495fd=Gs(_0x3c2792),_0x55b8b1=Gs(_0x27b5df);return _0x1495fd!==null?_0x55b8b1!==null?_0x1495fd-_0x55b8b1===0x0?_0x3c2792['length']-_0x27b5df['length']:_0x1495fd-_0x55b8b1:-0x1:_0x55b8b1!==null?0x1:_0x3c2792<_0x27b5df?-0x1:0x1;}},ql=function(_0x231965,_0xf7698c){return _0x231965===_0xf7698c?0x0:_0x231965<_0xf7698c?-0x1:0x1;},vt=function(_0x5ca729,_0x3e4219){if(_0x3e4219&&_0x5ca729 in _0x3e4219)return _0x3e4219[_0x5ca729];throw new Error('Missing\x20required\x20key\x20('+_0x5ca729+')\x20in\x20object:\x20'+O(_0x3e4219));},$i=function(_0x2a0a83){if(typeof _0x2a0a83!='object'||_0x2a0a83===null)return O(_0x2a0a83);const _0xbf0c35=[];for(const _0x5bfe4f in _0x2a0a83)_0xbf0c35['push'](_0x5bfe4f);_0xbf0c35['sort']();let _0x5cafcd='{';for(let _0x9ff535=0x0;_0x9ff535<_0xbf0c35['length'];_0x9ff535++)_0x9ff535!==0x0&&(_0x5cafcd+=','),_0x5cafcd+=O(_0xbf0c35[_0x9ff535]),_0x5cafcd+=':',_0x5cafcd+=$i(_0x2a0a83[_0xbf0c35[_0x9ff535]]);return _0x5cafcd+='}',_0x5cafcd;},oo=function(_0x1320cc,_0x4b423e){const _0x9a06ee=_0x1320cc['length'];if(_0x9a06ee<=_0x4b423e)return[_0x1320cc];const _0x51e501=[];for(let _0x334c4d=0x0;_0x334c4d<_0x9a06ee;_0x334c4d+=_0x4b423e)_0x334c4d+_0x4b423e>_0x9a06ee?_0x51e501['push'](_0x1320cc['substring'](_0x334c4d,_0x9a06ee)):_0x51e501['push'](_0x1320cc['substring'](_0x334c4d,_0x334c4d+_0x4b423e));return _0x51e501;};function x(_0x5b95a1,_0x5c53d7){for(const _0x1c991f in _0x5b95a1)_0x5b95a1['hasOwnProperty'](_0x1c991f)&&_0x5c53d7(_0x1c991f,_0x5b95a1[_0x1c991f]);}const ao=function(_0x5f339c){f(!xn(_0x5f339c),'Invalid\x20JSON\x20number');const _0x51ce13=0xb,_0x500cce=0x34,_0x518642=(0x1<<_0x51ce13-0x1)-0x1;let _0x49968d,_0x3e7d6f,_0x31d1cb,_0x3fcafa,_0x18969b;_0x5f339c===0x0?(_0x3e7d6f=0x0,_0x31d1cb=0x0,_0x49968d=0x1/_0x5f339c===-0x1/0x0?0x1:0x0):(_0x49968d=_0x5f339c<0x0,_0x5f339c=Math['abs'](_0x5f339c),_0x5f339c>=Math['pow'](0x2,0x1-_0x518642)?(_0x3fcafa=Math['min'](Math['floor'](Math['log'](_0x5f339c)/Math['LN2']),_0x518642),_0x3e7d6f=_0x3fcafa+_0x518642,_0x31d1cb=Math['round'](_0x5f339c*Math['pow'](0x2,_0x500cce-_0x3fcafa)-Math['pow'](0x2,_0x500cce))):(_0x3e7d6f=0x0,_0x31d1cb=Math['round'](_0x5f339c/Math['pow'](0x2,0x1-_0x518642-_0x500cce))));const _0x18ad18=[];for(_0x18969b=_0x500cce;_0x18969b;_0x18969b-=0x1)_0x18ad18['push'](_0x31d1cb%0x2?0x1:0x0),_0x31d1cb=Math['floor'](_0x31d1cb/0x2);for(_0x18969b=_0x51ce13;_0x18969b;_0x18969b-=0x1)_0x18ad18['push'](_0x3e7d6f%0x2?0x1:0x0),_0x3e7d6f=Math['floor'](_0x3e7d6f/0x2);_0x18ad18['push'](_0x49968d?0x1:0x0),_0x18ad18['reverse']();const _0x5406c1=_0x18ad18['join']('');let _0x212d24='';for(_0x18969b=0x0;_0x18969b<0x40;_0x18969b+=0x8){let _0x388dd1=parseInt(_0x5406c1['substr'](_0x18969b,0x8),0x2)['toString'](0x10);_0x388dd1['length']===0x1&&(_0x388dd1='0'+_0x388dd1),_0x212d24=_0x212d24+_0x388dd1;}return _0x212d24['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x561e32,_0x43c34f){let _0x1e2485='Unknown\x20Error';_0x561e32==='too_big'?_0x1e2485='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x561e32==='permission_denied'?_0x1e2485='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x561e32==='unavailable'&&(_0x1e2485='The\x20service\x20is\x20unavailable');const _0x67f772=new Error(_0x561e32+'\x20at\x20'+_0x43c34f['_path']['toString']()+':\x20'+_0x1e2485);return _0x67f772['code']=_0x561e32['toUpperCase'](),_0x67f772;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x37687d){if(Yl['test'](_0x37687d)){const _0x253e68=Number(_0x37687d);if(_0x253e68>=Ql&&_0x253e68<=Jl)return _0x253e68;}return null;},ft=function(_0x2fa761){try{_0x2fa761();}catch(_0x3797b4){setTimeout(()=>{const _0x44a59b=_0x3797b4['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x44a59b),_0x3797b4;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x24e259,_0x5bbba4){const _0x543198=setTimeout(_0x24e259,_0x5bbba4);return typeof _0x543198=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x543198):typeof _0x543198=='object'&&_0x543198['unref']&&_0x543198['unref'](),_0x543198;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x2f6f61,_0x2d19ab){this['appCheckProvider']=_0x2d19ab,this['appName']=_0x2f6f61['name'],$(_0x2f6f61)&&_0x2f6f61['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x2f6f61['settings']['appCheckToken']),this['appCheck']=_0x2d19ab==null?void 0x0:_0x2d19ab['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2d19ab==null||_0x2d19ab['get']()['then'](_0x291c91=>this['appCheck']=_0x291c91);}['getToken'](_0xa6b8c){if(this['serverAppAppCheckToken']){if(_0xa6b8c)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xa6b8c):new Promise((_0x5882b4,_0x37815e)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xa6b8c)['then'](_0x5882b4,_0x37815e):_0x5882b4(null);},0x0);});}['addTokenChangeListener'](_0x11e0d2){var _0x1dd57a;(_0x1dd57a=this['appCheckProvider'])==null||_0x1dd57a['get']()['then'](_0x371f1c=>_0x371f1c['addTokenListener'](_0x11e0d2));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x26187d,_0x18800b,_0x418f3e){this['appName_']=_0x26187d,this['firebaseOptions_']=_0x18800b,this['authProvider_']=_0x418f3e,this['auth_']=null,this['auth_']=_0x418f3e['getImmediate']({'optional':!0x0}),this['auth_']||_0x418f3e['onInit'](_0x4a1411=>this['auth_']=_0x4a1411);}['getToken'](_0x22dac8){return this['auth_']?this['auth_']['getToken'](_0x22dac8)['catch'](_0x199807=>_0x199807&&_0x199807['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x199807)):new Promise((_0x11f098,_0x479f50)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x22dac8)['then'](_0x11f098,_0x479f50):_0x11f098(null);},0x0);});}['addTokenChangeListener'](_0x2e408c){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2e408c):this['authProvider_']['get']()['then'](_0x261f0d=>_0x261f0d['addAuthTokenListener'](_0x2e408c));}['removeTokenChangeListener'](_0x527126){this['authProvider_']['get']()['then'](_0x97220=>_0x97220['removeAuthTokenListener'](_0x527126));}['notifyForInvalidToken'](){let _0x321b64='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x321b64+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x321b64+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x321b64+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x321b64);}}class an{constructor(_0x34f174){this['accessToken']=_0x34f174;}['getToken'](_0x31b685){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xfe9f32){_0xfe9f32(this['accessToken']);}['removeTokenChangeListener'](_0x21837f){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x2ac406,_0x914f80,_0x9829b2,_0x1a9439,_0x933661=!0x1,_0x1d5f3b='',_0x271ae8=!0x1,_0x101b23=!0x1,_0x1bf674=null){this['secure']=_0x914f80,this['namespace']=_0x9829b2,this['webSocketOnly']=_0x1a9439,this['nodeAdmin']=_0x933661,this['persistenceKey']=_0x1d5f3b,this['includeNamespaceInQueryParams']=_0x271ae8,this['isUsingEmulator']=_0x101b23,this['emulatorOptions']=_0x1bf674,this['_host']=_0x2ac406['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x2ac406)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x450184){_0x450184!==this['internalHost']&&(this['internalHost']=_0x450184,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4b11e6=this['toURLString']();return this['persistenceKey']&&(_0x4b11e6+='<'+this['persistenceKey']+'>'),_0x4b11e6;}['toURLString'](){const _0x600f76=this['secure']?'https://':'http://',_0x3a8f02=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x600f76+this['host']+'/'+_0x3a8f02;}}function th(_0x56e28a){return _0x56e28a['host']!==_0x56e28a['internalHost']||_0x56e28a['isCustomHost']()||_0x56e28a['includeNamespaceInQueryParams'];}function vo(_0x2c57c7,_0x1dc942,_0x3db30d){f(typeof _0x1dc942=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3db30d=='object','typeof\x20params\x20must\x20==\x20object');let _0x396c43;if(_0x1dc942===go)_0x396c43=(_0x2c57c7['secure']?'wss://':'ws://')+_0x2c57c7['internalHost']+'/.ws?';else{if(_0x1dc942===mo)_0x396c43=(_0x2c57c7['secure']?'https://':'http://')+_0x2c57c7['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1dc942);}th(_0x2c57c7)&&(_0x3db30d['ns']=_0x2c57c7['namespace']);const _0x258fcf=[];return x(_0x3db30d,(_0x536afb,_0x173fd8)=>{_0x258fcf['push'](_0x536afb+'='+_0x173fd8);}),_0x396c43+_0x258fcf['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3de077,_0x15eb73=0x1){Q(this['counters_'],_0x3de077)||(this['counters_'][_0x3de077]=0x0),this['counters_'][_0x3de077]+=_0x15eb73;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x1274e9){const _0x4f592d=_0x1274e9['toString']();return oi[_0x4f592d]||(oi[_0x4f592d]=new nh()),oi[_0x4f592d];}function ih(_0x5d758a,_0x1754c5){const _0x452d04=_0x5d758a['toString']();return ai[_0x452d04]||(ai[_0x452d04]=_0x1754c5()),ai[_0x452d04];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x54a6ad){this['onMessage_']=_0x54a6ad,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1092b4,_0xf359c1){this['closeAfterResponse']=_0x1092b4,this['onClose']=_0xf359c1,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3d3249,_0x97b7a8){for(this['pendingResponses'][_0x3d3249]=_0x97b7a8;this['pendingResponses'][this['currentResponseNum']];){const _0x4f96b1=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3c1c44=0x0;_0x3c1c44<_0x4f96b1['length'];++_0x3c1c44)_0x4f96b1[_0x3c1c44]&&ft(()=>{this['onMessage_'](_0x4f96b1[_0x3c1c44]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x15a06e,_0xacc607,_0x19907b,_0xc36539,_0x5121d1,_0x4a9ab2,_0x519837){this['connId']=_0x15a06e,this['repoInfo']=_0xacc607,this['applicationId']=_0x19907b,this['appCheckToken']=_0xc36539,this['authToken']=_0x5121d1,this['transportSessionId']=_0x4a9ab2,this['lastSessionId']=_0x519837,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x15a06e),this['stats_']=qi(_0xacc607),this['urlFn']=_0x14a61a=>(this['appCheckToken']&&(_0x14a61a[wi]=this['appCheckToken']),vo(_0xacc607,mo,_0x14a61a));}['open'](_0xf1a8b7,_0x30a483){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x30a483,this['myPacketOrderer']=new sh(_0xf1a8b7),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x2a6232)=>{const [_0x389bcc,_0x426e36,_0x48e570,_0x251115,_0x128fcd]=_0x2a6232;if(this['incrementIncomingBytes_'](_0x2a6232),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x389bcc===qs)this['id']=_0x426e36,this['password']=_0x48e570;else{if(_0x389bcc===rh)_0x426e36?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x426e36,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x389bcc);}}},(..._0x48cbd5)=>{const [_0x5c1690,_0x38a8d9]=_0x48cbd5;this['incrementIncomingBytes_'](_0x48cbd5),this['myPacketOrderer']['handleResponse'](_0x5c1690,_0x38a8d9);},()=>{this['onClosed_']();},this['urlFn']);const _0x526864={};_0x526864[qs]='t',_0x526864[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x526864[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x526864[co]=Gi,this['transportSessionId']&&(_0x526864[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x526864[po]=this['lastSessionId']),this['applicationId']&&(_0x526864[_o]=this['applicationId']),this['appCheckToken']&&(_0x526864[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x526864[ho]=uo);const _0x500a5e=this['urlFn'](_0x526864);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x500a5e),this['scriptTagHolder']['addTag'](_0x500a5e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x153456){const _0x2af580=O(_0x153456);this['bytesSent']+=_0x2af580['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2af580['length']);const _0x4c9500=$r(_0x2af580),_0x2d8688=oo(_0x4c9500,fh);for(let _0x5f082d=0x0;_0x5f082d<_0x2d8688['length'];_0x5f082d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2d8688['length'],_0x2d8688[_0x5f082d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x847efa,_0x47fe0f){this['myDisconnFrame']=document['createElement']('iframe');const _0x35742f={};_0x35742f[dh]='t',_0x35742f[Eo]=_0x847efa,_0x35742f[Io]=_0x47fe0f,this['myDisconnFrame']['src']=this['urlFn'](_0x35742f),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x175fa4){const _0x478843=O(_0x175fa4)['length'];this['bytesReceived']+=_0x478843,this['stats_']['incrementCounter']('bytes_received',_0x478843);}}class zi{constructor(_0x3c6f79,_0x1dba40,_0x78e954,_0x4b3694){this['onDisconnect']=_0x78e954,this['urlFn']=_0x4b3694,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3c6f79,window[ah+this['uniqueCallbackIdentifier']]=_0x1dba40,this['myIFrame']=zi['createIFrame_']();let _0x100620='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x100620='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xd01aea='<html><body>'+_0x100620+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xd01aea),this['myIFrame']['doc']['close']();}catch(_0x422fe3){L('frame\x20writing\x20exception'),_0x422fe3['stack']&&L(_0x422fe3['stack']),L(_0x422fe3);}}}static['createIFrame_'](){const _0x251904=document['createElement']('iframe');if(_0x251904['style']['display']='none',document['body']){document['body']['appendChild'](_0x251904);try{_0x251904['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x566c61=document['domain'];_0x251904['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x566c61+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x251904['contentDocument']?_0x251904['doc']=_0x251904['contentDocument']:_0x251904['contentWindow']?_0x251904['doc']=_0x251904['contentWindow']['document']:_0x251904['document']&&(_0x251904['doc']=_0x251904['document']),_0x251904;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0xef0870=this['onDisconnect'];_0xef0870&&(this['onDisconnect']=null,_0xef0870());}['startLongPoll'](_0x1518fc,_0x16b089){for(this['myID']=_0x1518fc,this['myPW']=_0x16b089,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x27cf5f={};_0x27cf5f[Eo]=this['myID'],_0x27cf5f[Io]=this['myPW'],_0x27cf5f[wo]=this['currentSerial'];let _0x41abf9=this['urlFn'](_0x27cf5f),_0x5d0ccb='',_0x1613e5=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5d0ccb['length']<=Co;){const _0x225c33=this['pendingSegs']['shift']();_0x5d0ccb=_0x5d0ccb+'&'+lh+_0x1613e5+'='+_0x225c33['seg']+'&'+hh+_0x1613e5+'='+_0x225c33['ts']+'&'+uh+_0x1613e5+'='+_0x225c33['d'],_0x1613e5++;}return _0x41abf9=_0x41abf9+_0x5d0ccb,this['addLongPollTag_'](_0x41abf9,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1aab99,_0x29f2cb,_0x593ca8){this['pendingSegs']['push']({'seg':_0x1aab99,'ts':_0x29f2cb,'d':_0x593ca8}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1dec1e,_0x571d50){this['outstandingRequests']['add'](_0x571d50);const _0x21ae9f=()=>{this['outstandingRequests']['delete'](_0x571d50),this['newRequest_']();},_0x5bc25e=setTimeout(_0x21ae9f,Math['floor'](ph)),_0x16d50f=()=>{clearTimeout(_0x5bc25e),_0x21ae9f();};this['addTag'](_0x1dec1e,_0x16d50f);}['addTag'](_0x3b3f3c,_0x5c6ea6){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x293a03=this['myIFrame']['doc']['createElement']('script');_0x293a03['type']='text/javascript',_0x293a03['async']=!0x0,_0x293a03['src']=_0x3b3f3c,_0x293a03['onload']=_0x293a03['onreadystatechange']=function(){const _0x5c1e13=_0x293a03['readyState'];(!_0x5c1e13||_0x5c1e13==='loaded'||_0x5c1e13==='complete')&&(_0x293a03['onload']=_0x293a03['onreadystatechange']=null,_0x293a03['parentNode']&&_0x293a03['parentNode']['removeChild'](_0x293a03),_0x5c6ea6());},_0x293a03['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3b3f3c),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x293a03);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x37c678,_0x10d270,_0x4f9bf3,_0x55380c,_0x8aaa8f,_0x14180b,_0x312cd6){this['connId']=_0x37c678,this['applicationId']=_0x4f9bf3,this['appCheckToken']=_0x55380c,this['authToken']=_0x8aaa8f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x10d270),this['connURL']=q['connectionURL_'](_0x10d270,_0x14180b,_0x312cd6,_0x55380c,_0x4f9bf3),this['nodeAdmin']=_0x10d270['nodeAdmin'];}static['connectionURL_'](_0x4f7464,_0x31cac5,_0x325257,_0xef9e16,_0x472ffe){const _0x53bc00={};return _0x53bc00[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x53bc00[ho]=uo),_0x31cac5&&(_0x53bc00[lo]=_0x31cac5),_0x325257&&(_0x53bc00[po]=_0x325257),_0xef9e16&&(_0x53bc00[wi]=_0xef9e16),_0x472ffe&&(_0x53bc00[_o]=_0x472ffe),vo(_0x4f7464,go,_0x53bc00);}['open'](_0x54d3c5,_0xa3496a){this['onDisconnect']=_0xa3496a,this['onMessage']=_0x54d3c5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x5f3408;_c(),this['mySock']=new gn(this['connURL'],[],_0x5f3408);}catch(_0x50fb20){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4aabfd=_0x50fb20['message']||_0x50fb20['data'];_0x4aabfd&&this['log_'](_0x4aabfd),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2cb669=>{this['handleIncomingFrame'](_0x2cb669);},this['mySock']['onerror']=_0x4775f7=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2418f0=_0x4775f7['message']||_0x4775f7['data'];_0x2418f0&&this['log_'](_0x2418f0),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x308189=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1cc28b=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xcaff59=navigator['userAgent']['match'](_0x1cc28b);_0xcaff59&&_0xcaff59['length']>0x1&&parseFloat(_0xcaff59[0x1])<4.4&&(_0x308189=!0x0);}return!_0x308189&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x464725){if(this['frames']['push'](_0x464725),this['frames']['length']===this['totalFrames']){const _0x204fb6=this['frames']['join']('');this['frames']=null;const _0x502aa1=Nt(_0x204fb6);this['onMessage'](_0x502aa1);}}['handleNewFrameCount_'](_0x469594){this['totalFrames']=_0x469594,this['frames']=[];}['extractFrameCount_'](_0x115187){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x115187['length']<=0x6){const _0x2fe948=Number(_0x115187);if(!isNaN(_0x2fe948))return this['handleNewFrameCount_'](_0x2fe948),null;}return this['handleNewFrameCount_'](0x1),_0x115187;}['handleIncomingFrame'](_0x3d3afd){if(this['mySock']===null)return;const _0x59c800=_0x3d3afd['data'];if(this['bytesReceived']+=_0x59c800['length'],this['stats_']['incrementCounter']('bytes_received',_0x59c800['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x59c800);else{const _0x1866e2=this['extractFrameCount_'](_0x59c800);_0x1866e2!==null&&this['appendFrame_'](_0x1866e2);}}['send'](_0x1598f9){this['resetKeepAlive']();const _0x4a36a1=O(_0x1598f9);this['bytesSent']+=_0x4a36a1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4a36a1['length']);const _0x2a2928=oo(_0x4a36a1,gh);_0x2a2928['length']>0x1&&this['sendString_'](String(_0x2a2928['length']));for(let _0x39e8f9=0x0;_0x39e8f9<_0x2a2928['length'];_0x39e8f9++)this['sendString_'](_0x2a2928[_0x39e8f9]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x250301){try{this['mySock']['send'](_0x250301);}catch(_0xc07567){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0xc07567['message']||_0xc07567['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4bd17c){this['initTransports_'](_0x4bd17c);}['initTransports_'](_0x282f7e){const _0xe7ff4f=q&&q['isAvailable']();let _0x4da343=_0xe7ff4f&&!q['previouslyFailed']();if(_0x282f7e['webSocketOnly']&&(_0xe7ff4f||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4da343=!0x0),_0x4da343)this['transports_']=[q];else{const _0x2d64fd=this['transports_']=[];for(const _0x2ef70a of Dt['ALL_TRANSPORTS'])_0x2ef70a&&_0x2ef70a['isAvailable']()&&_0x2d64fd['push'](_0x2ef70a);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x610b2,_0x545873,_0x21744d,_0x4a75c2,_0x55a8d1,_0x4d2850,_0x99993f,_0x3f64c7,_0x26c4f2,_0x15150d){this['id']=_0x610b2,this['repoInfo_']=_0x545873,this['applicationId_']=_0x21744d,this['appCheckToken_']=_0x4a75c2,this['authToken_']=_0x55a8d1,this['onMessage_']=_0x4d2850,this['onReady_']=_0x99993f,this['onDisconnect_']=_0x3f64c7,this['onKill_']=_0x26c4f2,this['lastSessionId']=_0x15150d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x545873),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xf36762=this['transportManager_']['initialTransport']();this['conn_']=new _0xf36762(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xf36762['responsesRequiredToBeHealthy']||0x0;const _0x444829=this['connReceiver_'](this['conn_']),_0x2b24ce=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x444829,_0x2b24ce);},Math['floor'](0x0));const _0x46b06a=_0xf36762['healthyTimeout']||0x0;_0x46b06a>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x46b06a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x226405){return _0x10b6d8=>{_0x226405===this['conn_']?this['onConnectionLost_'](_0x10b6d8):_0x226405===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x14568d){return _0x57087f=>{this['state_']!==0x2&&(_0x14568d===this['rx_']?this['onPrimaryMessageReceived_'](_0x57087f):_0x14568d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x57087f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x56ef44){const _0x27125f={'t':'d','d':_0x56ef44};this['sendData_'](_0x27125f);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4fe1cb){if(ci in _0x4fe1cb){const _0x1ecf8f=_0x4fe1cb[ci];_0x1ecf8f===Ys?this['upgradeIfSecondaryHealthy_']():_0x1ecf8f===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1ecf8f===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x104c3f){const _0x1b0d05=vt('t',_0x104c3f),_0x521d06=vt('d',_0x104c3f);if(_0x1b0d05==='c')this['onSecondaryControl_'](_0x521d06);else{if(_0x1b0d05==='d')this['pendingDataMessages']['push'](_0x521d06);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1b0d05);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x38e542){const _0xce5dff=vt('t',_0x38e542),_0x1857d6=vt('d',_0x38e542);_0xce5dff==='c'?this['onControl_'](_0x1857d6):_0xce5dff==='d'&&this['onDataMessage_'](_0x1857d6);}['onDataMessage_'](_0x38b16f){this['onPrimaryResponse_'](),this['onMessage_'](_0x38b16f);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x9335ec){const _0x75788b=vt(ci,_0x9335ec);if(zs in _0x9335ec){const _0x54dfd2=_0x9335ec[zs];if(_0x75788b===Th){const _0x561b8e={..._0x54dfd2};this['repoInfo_']['isUsingEmulator']&&(_0x561b8e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x561b8e);}else{if(_0x75788b===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4589ce=0x0;_0x4589ce<this['pendingDataMessages']['length'];++_0x4589ce)this['onDataMessage_'](this['pendingDataMessages'][_0x4589ce]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x75788b===wh?this['onConnectionShutdown_'](_0x54dfd2):_0x75788b===js?this['onReset_'](_0x54dfd2):_0x75788b===Ch?Ii('Server\x20Error:\x20'+_0x54dfd2):_0x75788b===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x75788b);}}}['onHandshake_'](_0x438e65){const _0x21df35=_0x438e65['ts'],_0x43d296=_0x438e65['v'],_0x3dfbe=_0x438e65['h'];this['sessionId']=_0x438e65['s'],this['repoInfo_']['host']=_0x3dfbe,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x21df35),Gi!==_0x43d296&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x19e0b1=this['transportManager_']['upgradeTransport']();_0x19e0b1&&this['startUpgrade_'](_0x19e0b1);}['startUpgrade_'](_0x51f13a){this['secondaryConn_']=new _0x51f13a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x51f13a['responsesRequiredToBeHealthy']||0x0;const _0x4c2df7=this['connReceiver_'](this['secondaryConn_']),_0x37a7c9=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4c2df7,_0x37a7c9),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x32bb52){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x32bb52),this['repoInfo_']['host']=_0x32bb52,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x11a1f1,_0x2562ee){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x11a1f1,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2562ee,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x566f44=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x566f44||this['rx_']===_0x566f44)&&this['close']();}['onConnectionLost_'](_0x223351){this['conn_']=null,!_0x223351&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3dd4ef){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3dd4ef),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2e92e9){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2e92e9);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xa072ec,_0x170c7a,_0x54a590,_0x1a4c28){}['merge'](_0x231e01,_0x5932a7,_0xce6746,_0x1cf444){}['refreshAuthToken'](_0xec4071){}['refreshAppCheckToken'](_0x32bd6d){}['onDisconnectPut'](_0x6f2b6c,_0x5d26f6,_0x5b592f){}['onDisconnectMerge'](_0x55cc25,_0x597495,_0x366ff0){}['onDisconnectCancel'](_0x489d96,_0x5bb92e){}['reportStats'](_0x2b4336){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x204f44){this['allowedEvents_']=_0x204f44,this['listeners_']={},f(Array['isArray'](_0x204f44)&&_0x204f44['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x22c918,..._0x190604){if(Array['isArray'](this['listeners_'][_0x22c918])){const _0x4fbdd7=[...this['listeners_'][_0x22c918]];for(let _0x56eed1=0x0;_0x56eed1<_0x4fbdd7['length'];_0x56eed1++)_0x4fbdd7[_0x56eed1]['callback']['apply'](_0x4fbdd7[_0x56eed1]['context'],_0x190604);}}['on'](_0x529566,_0x33c891,_0xf3f2fc){this['validateEventType_'](_0x529566),this['listeners_'][_0x529566]=this['listeners_'][_0x529566]||[],this['listeners_'][_0x529566]['push']({'callback':_0x33c891,'context':_0xf3f2fc});const _0x558399=this['getInitialEvent'](_0x529566);_0x558399&&_0x33c891['apply'](_0xf3f2fc,_0x558399);}['off'](_0x13b0b7,_0x4625af,_0x186c24){this['validateEventType_'](_0x13b0b7);const _0x4bed2b=this['listeners_'][_0x13b0b7]||[];for(let _0x13793f=0x0;_0x13793f<_0x4bed2b['length'];_0x13793f++)if(_0x4bed2b[_0x13793f]['callback']===_0x4625af&&(!_0x186c24||_0x186c24===_0x4bed2b[_0x13793f]['context'])){_0x4bed2b['splice'](_0x13793f,0x1);return;}}['validateEventType_'](_0x2128a2){f(this['allowedEvents_']['find'](_0x20eea7=>_0x20eea7===_0x2128a2),'Unknown\x20event:\x20'+_0x2128a2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2a36bb){return f(_0x2a36bb==='online','Unknown\x20event\x20type:\x20'+_0x2a36bb),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x217c4e,_0x34f97c){if(_0x34f97c===void 0x0){this['pieces_']=_0x217c4e['split']('/');let _0xf6cf8c=0x0;for(let _0x3f404d=0x0;_0x3f404d<this['pieces_']['length'];_0x3f404d++)this['pieces_'][_0x3f404d]['length']>0x0&&(this['pieces_'][_0xf6cf8c]=this['pieces_'][_0x3f404d],_0xf6cf8c++);this['pieces_']['length']=_0xf6cf8c,this['pieceNum_']=0x0;}else this['pieces_']=_0x217c4e,this['pieceNum_']=_0x34f97c;}['toString'](){let _0x1430d9='';for(let _0x40f397=this['pieceNum_'];_0x40f397<this['pieces_']['length'];_0x40f397++)this['pieces_'][_0x40f397]!==''&&(_0x1430d9+='/'+this['pieces_'][_0x40f397]);return _0x1430d9||'/';}}function w(){return new C('');}function y(_0xbef39d){return _0xbef39d['pieceNum_']>=_0xbef39d['pieces_']['length']?null:_0xbef39d['pieces_'][_0xbef39d['pieceNum_']];}function Ce(_0x2807c8){return _0x2807c8['pieces_']['length']-_0x2807c8['pieceNum_'];}function S(_0x361d97){let _0x2deb34=_0x361d97['pieceNum_'];return _0x2deb34<_0x361d97['pieces_']['length']&&_0x2deb34++,new C(_0x361d97['pieces_'],_0x2deb34);}function ji(_0x2dd9e3){return _0x2dd9e3['pieceNum_']<_0x2dd9e3['pieces_']['length']?_0x2dd9e3['pieces_'][_0x2dd9e3['pieces_']['length']-0x1]:null;}function bh(_0x4e495d){let _0x160cdc='';for(let _0x2b1b58=_0x4e495d['pieceNum_'];_0x2b1b58<_0x4e495d['pieces_']['length'];_0x2b1b58++)_0x4e495d['pieces_'][_0x2b1b58]!==''&&(_0x160cdc+='/'+encodeURIComponent(String(_0x4e495d['pieces_'][_0x2b1b58])));return _0x160cdc||'/';}function Mt(_0x34c67b,_0x14637d=0x0){return _0x34c67b['pieces_']['slice'](_0x34c67b['pieceNum_']+_0x14637d);}function Ro(_0x41b1d8){if(_0x41b1d8['pieceNum_']>=_0x41b1d8['pieces_']['length'])return null;const _0x528afe=[];for(let _0x49b9c8=_0x41b1d8['pieceNum_'];_0x49b9c8<_0x41b1d8['pieces_']['length']-0x1;_0x49b9c8++)_0x528afe['push'](_0x41b1d8['pieces_'][_0x49b9c8]);return new C(_0x528afe,0x0);}function k(_0x32aea9,_0x372438){const _0x168df0=[];for(let _0x5c0361=_0x32aea9['pieceNum_'];_0x5c0361<_0x32aea9['pieces_']['length'];_0x5c0361++)_0x168df0['push'](_0x32aea9['pieces_'][_0x5c0361]);if(_0x372438 instanceof C){for(let _0x5b0e0c=_0x372438['pieceNum_'];_0x5b0e0c<_0x372438['pieces_']['length'];_0x5b0e0c++)_0x168df0['push'](_0x372438['pieces_'][_0x5b0e0c]);}else{const _0x42dd68=_0x372438['split']('/');for(let _0x323ef1=0x0;_0x323ef1<_0x42dd68['length'];_0x323ef1++)_0x42dd68[_0x323ef1]['length']>0x0&&_0x168df0['push'](_0x42dd68[_0x323ef1]);}return new C(_0x168df0,0x0);}function v(_0x408295){return _0x408295['pieceNum_']>=_0x408295['pieces_']['length'];}function F(_0x4afad1,_0x44790f){const _0xd53ecd=y(_0x4afad1),_0x42d0d8=y(_0x44790f);if(_0xd53ecd===null)return _0x44790f;if(_0xd53ecd===_0x42d0d8)return F(S(_0x4afad1),S(_0x44790f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x44790f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x4afad1+')');}function Rh(_0x1774fc,_0x5eb97d){const _0x26e6c8=Mt(_0x1774fc,0x0),_0x28550a=Mt(_0x5eb97d,0x0);for(let _0x9672d3=0x0;_0x9672d3<_0x26e6c8['length']&&_0x9672d3<_0x28550a['length'];_0x9672d3++){const _0x491d7c=qe(_0x26e6c8[_0x9672d3],_0x28550a[_0x9672d3]);if(_0x491d7c!==0x0)return _0x491d7c;}return _0x26e6c8['length']===_0x28550a['length']?0x0:_0x26e6c8['length']<_0x28550a['length']?-0x1:0x1;}function Ki(_0x52b7c5,_0x4b7781){if(Ce(_0x52b7c5)!==Ce(_0x4b7781))return!0x1;for(let _0x2093c4=_0x52b7c5['pieceNum_'],_0x307e72=_0x4b7781['pieceNum_'];_0x2093c4<=_0x52b7c5['pieces_']['length'];_0x2093c4++,_0x307e72++)if(_0x52b7c5['pieces_'][_0x2093c4]!==_0x4b7781['pieces_'][_0x307e72])return!0x1;return!0x0;}function G(_0x31ad82,_0x53d5f9){let _0x1c2999=_0x31ad82['pieceNum_'],_0x3c5df3=_0x53d5f9['pieceNum_'];if(Ce(_0x31ad82)>Ce(_0x53d5f9))return!0x1;for(;_0x1c2999<_0x31ad82['pieces_']['length'];){if(_0x31ad82['pieces_'][_0x1c2999]!==_0x53d5f9['pieces_'][_0x3c5df3])return!0x1;++_0x1c2999,++_0x3c5df3;}return!0x0;}class Ah{constructor(_0x1538f8,_0x3c01be){this['errorPrefix_']=_0x3c01be,this['parts_']=Mt(_0x1538f8,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5974e1=0x0;_0x5974e1<this['parts_']['length'];_0x5974e1++)this['byteLength_']+=Ln(this['parts_'][_0x5974e1]);Ao(this);}}function kh(_0x4ce290,_0x38ef9c){_0x4ce290['parts_']['length']>0x0&&(_0x4ce290['byteLength_']+=0x1),_0x4ce290['parts_']['push'](_0x38ef9c),_0x4ce290['byteLength_']+=Ln(_0x38ef9c),Ao(_0x4ce290);}function Ph(_0x364fa9){const _0x51319d=_0x364fa9['parts_']['pop']();_0x364fa9['byteLength_']-=Ln(_0x51319d),_0x364fa9['parts_']['length']>0x0&&(_0x364fa9['byteLength_']-=0x1);}function Ao(_0x518bb4){if(_0x518bb4['byteLength_']>Zs)throw new Error(_0x518bb4['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x518bb4['byteLength_']+').');if(_0x518bb4['parts_']['length']>Xs)throw new Error(_0x518bb4['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x518bb4));}function Oe(_0x56dc01){return _0x56dc01['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x56dc01['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x48f731,_0xaae5ab;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xaae5ab='visibilitychange',_0x48f731='hidden'):typeof document['mozHidden']<'u'?(_0xaae5ab='mozvisibilitychange',_0x48f731='mozHidden'):typeof document['msHidden']<'u'?(_0xaae5ab='msvisibilitychange',_0x48f731='msHidden'):typeof document['webkitHidden']<'u'&&(_0xaae5ab='webkitvisibilitychange',_0x48f731='webkitHidden')),this['visible_']=!0x0,_0xaae5ab&&document['addEventListener'](_0xaae5ab,()=>{const _0x22b942=!document[_0x48f731];_0x22b942!==this['visible_']&&(this['visible_']=_0x22b942,this['trigger']('visible',_0x22b942));},!0x1);}['getInitialEvent'](_0x2428bf){return f(_0x2428bf==='visible','Unknown\x20event\x20type:\x20'+_0x2428bf),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x31522e,_0x51d498,_0x4ac58b,_0x1e716a,_0x225a3c,_0x10d0e8,_0x282b54,_0x47ff64){if(super(),this['repoInfo_']=_0x31522e,this['applicationId_']=_0x51d498,this['onDataUpdate_']=_0x4ac58b,this['onConnectStatus_']=_0x1e716a,this['onServerInfoUpdate_']=_0x225a3c,this['authTokenProvider_']=_0x10d0e8,this['appCheckTokenProvider_']=_0x282b54,this['authOverride_']=_0x47ff64,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x47ff64)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x31522e['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x45537b,_0x447061,_0x1eea07){const _0x221dd2=++this['requestNumber_'],_0x48d89f={'r':_0x221dd2,'a':_0x45537b,'b':_0x447061};this['log_'](O(_0x48d89f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x48d89f),_0x1eea07&&(this['requestCBHash_'][_0x221dd2]=_0x1eea07);}['get'](_0x480574){this['initConnection_']();const _0x41c345=new H(),_0x1e11bf={'action':'g','request':{'p':_0x480574['_path']['toString'](),'q':_0x480574['_queryObject']},'onComplete':_0x5ef29e=>{const _0x3cdb3f=_0x5ef29e['d'];_0x5ef29e['s']==='ok'?_0x41c345['resolve'](_0x3cdb3f):_0x41c345['reject'](_0x3cdb3f);}};this['outstandingGets_']['push'](_0x1e11bf),this['outstandingGetCount_']++;const _0x5b30d0=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5b30d0),_0x41c345['promise'];}['listen'](_0xc3f91f,_0x24b222,_0x15fbe0,_0xa8771a){this['initConnection_']();const _0x34dd4f=_0xc3f91f['_queryIdentifier'],_0x3de12b=_0xc3f91f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3de12b+'\x20'+_0x34dd4f),this['listens']['has'](_0x3de12b)||this['listens']['set'](_0x3de12b,new Map()),f(_0xc3f91f['_queryParams']['isDefault']()||!_0xc3f91f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3de12b)['has'](_0x34dd4f),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1ce335={'onComplete':_0xa8771a,'hashFn':_0x24b222,'query':_0xc3f91f,'tag':_0x15fbe0};this['listens']['get'](_0x3de12b)['set'](_0x34dd4f,_0x1ce335),this['connected_']&&this['sendListen_'](_0x1ce335);}['sendGet_'](_0x273b78){const _0x1faf9e=this['outstandingGets_'][_0x273b78];this['sendRequest']('g',_0x1faf9e['request'],_0x3ea2d1=>{delete this['outstandingGets_'][_0x273b78],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1faf9e['onComplete']&&_0x1faf9e['onComplete'](_0x3ea2d1);});}['sendListen_'](_0x5b5b6b){const _0x10be69=_0x5b5b6b['query'],_0x493578=_0x10be69['_path']['toString'](),_0x4e145d=_0x10be69['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x493578+'\x20for\x20'+_0x4e145d);const _0x247218={'p':_0x493578},_0x52807b='q';_0x5b5b6b['tag']&&(_0x247218['q']=_0x10be69['_queryObject'],_0x247218['t']=_0x5b5b6b['tag']),_0x247218['h']=_0x5b5b6b['hashFn'](),this['sendRequest'](_0x52807b,_0x247218,_0x2e02ef=>{const _0x700d61=_0x2e02ef['d'],_0x45f7a9=_0x2e02ef['s'];se['warnOnListenWarnings_'](_0x700d61,_0x10be69),(this['listens']['get'](_0x493578)&&this['listens']['get'](_0x493578)['get'](_0x4e145d))===_0x5b5b6b&&(this['log_']('listen\x20response',_0x2e02ef),_0x45f7a9!=='ok'&&this['removeListen_'](_0x493578,_0x4e145d),_0x5b5b6b['onComplete']&&_0x5b5b6b['onComplete'](_0x45f7a9,_0x700d61));});}static['warnOnListenWarnings_'](_0x1c71de,_0x13a65c){if(_0x1c71de&&typeof _0x1c71de=='object'&&Q(_0x1c71de,'w')){const _0x3de02c=Le(_0x1c71de,'w');if(Array['isArray'](_0x3de02c)&&~_0x3de02c['indexOf']('no_index')){const _0x14e1f6='\x22.indexOn\x22:\x20\x22'+_0x13a65c['_queryParams']['getIndex']()['toString']()+'\x22',_0x1b8244=_0x13a65c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x14e1f6+'\x20at\x20'+_0x1b8244+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5c7b63){this['authToken_']=_0x5c7b63,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5c7b63);}['reduceReconnectDelayIfAdminCredential_'](_0x1196d3){(_0x1196d3&&_0x1196d3['length']===0x28||wc(_0x1196d3))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x13550d){this['appCheckToken_']=_0x13550d,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x56651c=this['authToken_'],_0x485fb7=Ic(_0x56651c)?'auth':'gauth',_0x379fc9={'cred':_0x56651c};this['authOverride_']===null?_0x379fc9['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x379fc9['authvar']=this['authOverride_']),this['sendRequest'](_0x485fb7,_0x379fc9,_0x1e3c20=>{const _0x4e915b=_0x1e3c20['s'],_0xb3a013=_0x1e3c20['d']||'error';this['authToken_']===_0x56651c&&(_0x4e915b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4e915b,_0xb3a013));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x547b34=>{const _0x55e38e=_0x547b34['s'],_0x1a4df7=_0x547b34['d']||'error';_0x55e38e==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x55e38e,_0x1a4df7);});}['unlisten'](_0x82c696,_0x66a63c){const _0x368e80=_0x82c696['_path']['toString'](),_0x61ab0a=_0x82c696['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x368e80+'\x20'+_0x61ab0a),f(_0x82c696['_queryParams']['isDefault']()||!_0x82c696['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x368e80,_0x61ab0a)&&this['connected_']&&this['sendUnlisten_'](_0x368e80,_0x61ab0a,_0x82c696['_queryObject'],_0x66a63c);}['sendUnlisten_'](_0x33d392,_0x17386d,_0x5a4eff,_0x52cda9){this['log_']('Unlisten\x20on\x20'+_0x33d392+'\x20for\x20'+_0x17386d);const _0x240c3c={'p':_0x33d392},_0x13c022='n';_0x52cda9&&(_0x240c3c['q']=_0x5a4eff,_0x240c3c['t']=_0x52cda9),this['sendRequest'](_0x13c022,_0x240c3c);}['onDisconnectPut'](_0x4abf97,_0x340bc3,_0x3105f8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4abf97,_0x340bc3,_0x3105f8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4abf97,'action':'o','data':_0x340bc3,'onComplete':_0x3105f8});}['onDisconnectMerge'](_0x36d563,_0x5ae919,_0x4b5b9d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x36d563,_0x5ae919,_0x4b5b9d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x36d563,'action':'om','data':_0x5ae919,'onComplete':_0x4b5b9d});}['onDisconnectCancel'](_0x47d502,_0x32c918){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x47d502,null,_0x32c918):this['onDisconnectRequestQueue_']['push']({'pathString':_0x47d502,'action':'oc','data':null,'onComplete':_0x32c918});}['sendOnDisconnect_'](_0x15a825,_0x1413a3,_0x25e594,_0x10cad9){const _0x138234={'p':_0x1413a3,'d':_0x25e594};this['log_']('onDisconnect\x20'+_0x15a825,_0x138234),this['sendRequest'](_0x15a825,_0x138234,_0x1eb39c=>{_0x10cad9&&setTimeout(()=>{_0x10cad9(_0x1eb39c['s'],_0x1eb39c['d']);},Math['floor'](0x0));});}['put'](_0x26708c,_0x83a7bb,_0x5d0c32,_0x593ff5){this['putInternal']('p',_0x26708c,_0x83a7bb,_0x5d0c32,_0x593ff5);}['merge'](_0x4e1722,_0x1ab7d8,_0x3328f4,_0x5ec0a){this['putInternal']('m',_0x4e1722,_0x1ab7d8,_0x3328f4,_0x5ec0a);}['putInternal'](_0x39927d,_0x454f4b,_0x575da2,_0x57f4be,_0x3ddf13){this['initConnection_']();const _0x4366d6={'p':_0x454f4b,'d':_0x575da2};_0x3ddf13!==void 0x0&&(_0x4366d6['h']=_0x3ddf13),this['outstandingPuts_']['push']({'action':_0x39927d,'request':_0x4366d6,'onComplete':_0x57f4be}),this['outstandingPutCount_']++;const _0x8f800a=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x8f800a):this['log_']('Buffering\x20put:\x20'+_0x454f4b);}['sendPut_'](_0x3d15ba){const _0x14b657=this['outstandingPuts_'][_0x3d15ba]['action'],_0x1cbc09=this['outstandingPuts_'][_0x3d15ba]['request'],_0x402194=this['outstandingPuts_'][_0x3d15ba]['onComplete'];this['outstandingPuts_'][_0x3d15ba]['queued']=this['connected_'],this['sendRequest'](_0x14b657,_0x1cbc09,_0xab556b=>{this['log_'](_0x14b657+'\x20response',_0xab556b),delete this['outstandingPuts_'][_0x3d15ba],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x402194&&_0x402194(_0xab556b['s'],_0xab556b['d']);});}['reportStats'](_0x1c8902){if(this['connected_']){const _0xb79b5={'c':_0x1c8902};this['log_']('reportStats',_0xb79b5),this['sendRequest']('s',_0xb79b5,_0x9c4fd9=>{if(_0x9c4fd9['s']!=='ok'){const _0x5ae4cb=_0x9c4fd9['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5ae4cb);}});}}['onDataMessage_'](_0x4580be){if('r'in _0x4580be){this['log_']('from\x20server:\x20'+O(_0x4580be));const _0x137cfd=_0x4580be['r'],_0x47875a=this['requestCBHash_'][_0x137cfd];_0x47875a&&(delete this['requestCBHash_'][_0x137cfd],_0x47875a(_0x4580be['b']));}else{if('error'in _0x4580be)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4580be['error'];'a'in _0x4580be&&this['onDataPush_'](_0x4580be['a'],_0x4580be['b']);}}['onDataPush_'](_0x2f60eb,_0x27c203){this['log_']('handleServerMessage',_0x2f60eb,_0x27c203),_0x2f60eb==='d'?this['onDataUpdate_'](_0x27c203['p'],_0x27c203['d'],!0x1,_0x27c203['t']):_0x2f60eb==='m'?this['onDataUpdate_'](_0x27c203['p'],_0x27c203['d'],!0x0,_0x27c203['t']):_0x2f60eb==='c'?this['onListenRevoked_'](_0x27c203['p'],_0x27c203['q']):_0x2f60eb==='ac'?this['onAuthRevoked_'](_0x27c203['s'],_0x27c203['d']):_0x2f60eb==='apc'?this['onAppCheckRevoked_'](_0x27c203['s'],_0x27c203['d']):_0x2f60eb==='sd'?this['onSecurityDebugPacket_'](_0x27c203):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2f60eb)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x43936e,_0x107f1a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x43936e),this['lastSessionId']=_0x107f1a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4cc9f7){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4cc9f7));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x6d1819){_0x6d1819&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x6d1819;}['onOnline_'](_0x755e8d){_0x755e8d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4b4487=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3d844d=Math['max'](0x0,this['reconnectDelay_']-_0x4b4487);_0x3d844d=Math['random']()*_0x3d844d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3d844d+'ms'),this['scheduleConnect_'](_0x3d844d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x52e112=this['onDataMessage_']['bind'](this),_0xd754e2=this['onReady_']['bind'](this),_0x1b95a6=this['onRealtimeDisconnect_']['bind'](this),_0x563f24=this['id']+':'+se['nextConnectionId_']++,_0x3a8b6c=this['lastSessionId'];let _0x26a21a=!0x1,_0x14ef0a=null;const _0x1169ef=function(){_0x14ef0a?_0x14ef0a['close']():(_0x26a21a=!0x0,_0x1b95a6());},_0x17c56d=function(_0x27d345){f(_0x14ef0a,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x14ef0a['sendRequest'](_0x27d345);};this['realtime_']={'close':_0x1169ef,'sendRequest':_0x17c56d};const _0x53a48f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x919132,_0x488a19]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x53a48f),this['appCheckTokenProvider_']['getToken'](_0x53a48f)]);_0x26a21a?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x919132&&_0x919132['accessToken'],this['appCheckToken_']=_0x488a19&&_0x488a19['token'],_0x14ef0a=new Sh(_0x563f24,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x52e112,_0xd754e2,_0x1b95a6,_0x368311=>{U(_0x368311+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3a8b6c));}catch(_0x470032){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x470032),_0x26a21a||(this['repoInfo_']['nodeAdmin']&&U(_0x470032),_0x1169ef());}}}['interrupt'](_0x55c3f1){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x55c3f1),this['interruptReasons_'][_0x55c3f1]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4b9c24){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4b9c24),delete this['interruptReasons_'][_0x4b9c24],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x50c919){const _0x199373=_0x50c919-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x199373});}['cancelSentTransactions_'](){for(let _0x9daf1c=0x0;_0x9daf1c<this['outstandingPuts_']['length'];_0x9daf1c++){const _0x3eb311=this['outstandingPuts_'][_0x9daf1c];_0x3eb311&&'h'in _0x3eb311['request']&&_0x3eb311['queued']&&(_0x3eb311['onComplete']&&_0x3eb311['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x9daf1c],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xf23ed7,_0x52ee21){let _0x2de205;_0x52ee21?_0x2de205=_0x52ee21['map'](_0x37a3c0=>$i(_0x37a3c0))['join']('$'):_0x2de205='default';const _0x480813=this['removeListen_'](_0xf23ed7,_0x2de205);_0x480813&&_0x480813['onComplete']&&_0x480813['onComplete']('permission_denied');}['removeListen_'](_0x167635,_0x1037cc){const _0x2f6c30=new C(_0x167635)['toString']();let _0x4e5ad8;if(this['listens']['has'](_0x2f6c30)){const _0x1edd2f=this['listens']['get'](_0x2f6c30);_0x4e5ad8=_0x1edd2f['get'](_0x1037cc),_0x1edd2f['delete'](_0x1037cc),_0x1edd2f['size']===0x0&&this['listens']['delete'](_0x2f6c30);}else _0x4e5ad8=void 0x0;return _0x4e5ad8;}['onAuthRevoked_'](_0x2df6c7,_0x59752d){L('Auth\x20token\x20revoked:\x20'+_0x2df6c7+'/'+_0x59752d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x2df6c7==='invalid_token'||_0x2df6c7==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5149ff,_0x3fc0c){L('App\x20check\x20token\x20revoked:\x20'+_0x5149ff+'/'+_0x3fc0c),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5149ff==='invalid_token'||_0x5149ff==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x56e9c1){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x56e9c1):'msg'in _0x56e9c1&&console['log']('FIREBASE:\x20'+_0x56e9c1['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x596998 of this['listens']['values']())for(const _0x9e4429 of _0x596998['values']())this['sendListen_'](_0x9e4429);for(let _0x546024=0x0;_0x546024<this['outstandingPuts_']['length'];_0x546024++)this['outstandingPuts_'][_0x546024]&&this['sendPut_'](_0x546024);for(;this['onDisconnectRequestQueue_']['length'];){const _0x59d6d4=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x59d6d4['action'],_0x59d6d4['pathString'],_0x59d6d4['data'],_0x59d6d4['onComplete']);}for(let _0x9a8f3b=0x0;_0x9a8f3b<this['outstandingGets_']['length'];_0x9a8f3b++)this['outstandingGets_'][_0x9a8f3b]&&this['sendGet_'](_0x9a8f3b);}['sendConnectStats_'](){const _0x268540={};let _0x43299d='js';_0x268540['sdk.'+_0x43299d+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x268540['framework.cordova']=0x1:Kr()&&(_0x268540['framework.reactnative']=0x1),this['reportStats'](_0x268540);}['shouldReconnect_'](){const _0x5893d6=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5893d6;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x38a16d,_0x39fd84){this['name']=_0x38a16d,this['node']=_0x39fd84;}static['Wrap'](_0x3ea7c8,_0x25312e){return new E(_0x3ea7c8,_0x25312e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x58949b,_0x2d3967){const _0x41fcf0=new E(We,_0x58949b),_0x1c72cb=new E(We,_0x2d3967);return this['compare'](_0x41fcf0,_0x1c72cb)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x1cd876){sn=_0x1cd876;}['compare'](_0x4b6ab6,_0x515a9e){return qe(_0x4b6ab6['name'],_0x515a9e['name']);}['isDefinedOn'](_0x3e9abd){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2d9371,_0x5b2763){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x36937f,_0x491be9){return f(typeof _0x36937f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x36937f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x42b4b3,_0x3e6918,_0x5bbf7c,_0x373795,_0x10be64=null){this['isReverse_']=_0x373795,this['resultGenerator_']=_0x10be64,this['nodeStack_']=[];let _0xc7c97=0x1;for(;!_0x42b4b3['isEmpty']();)if(_0x42b4b3=_0x42b4b3,_0xc7c97=_0x3e6918?_0x5bbf7c(_0x42b4b3['key'],_0x3e6918):0x1,_0x373795&&(_0xc7c97*=-0x1),_0xc7c97<0x0)this['isReverse_']?_0x42b4b3=_0x42b4b3['left']:_0x42b4b3=_0x42b4b3['right'];else{if(_0xc7c97===0x0){this['nodeStack_']['push'](_0x42b4b3);break;}else this['nodeStack_']['push'](_0x42b4b3),this['isReverse_']?_0x42b4b3=_0x42b4b3['right']:_0x42b4b3=_0x42b4b3['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x29ab25=this['nodeStack_']['pop'](),_0x4b6d81;if(this['resultGenerator_']?_0x4b6d81=this['resultGenerator_'](_0x29ab25['key'],_0x29ab25['value']):_0x4b6d81={'key':_0x29ab25['key'],'value':_0x29ab25['value']},this['isReverse_']){for(_0x29ab25=_0x29ab25['left'];!_0x29ab25['isEmpty']();)this['nodeStack_']['push'](_0x29ab25),_0x29ab25=_0x29ab25['right'];}else{for(_0x29ab25=_0x29ab25['right'];!_0x29ab25['isEmpty']();)this['nodeStack_']['push'](_0x29ab25),_0x29ab25=_0x29ab25['left'];}return _0x4b6d81;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5afd28=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5afd28['key'],_0x5afd28['value']):{'key':_0x5afd28['key'],'value':_0x5afd28['value']};}}class M{constructor(_0x41bf27,_0x4a0577,_0x35332e,_0x29aa21,_0x186826){this['key']=_0x41bf27,this['value']=_0x4a0577,this['color']=_0x35332e??M['RED'],this['left']=_0x29aa21??B['EMPTY_NODE'],this['right']=_0x186826??B['EMPTY_NODE'];}['copy'](_0x450368,_0x19f2cb,_0x2e5d63,_0x33431b,_0x292dd9){return new M(_0x450368??this['key'],_0x19f2cb??this['value'],_0x2e5d63??this['color'],_0x33431b??this['left'],_0x292dd9??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x552a60){return this['left']['inorderTraversal'](_0x552a60)||!!_0x552a60(this['key'],this['value'])||this['right']['inorderTraversal'](_0x552a60);}['reverseTraversal'](_0x1cd2f4){return this['right']['reverseTraversal'](_0x1cd2f4)||_0x1cd2f4(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1cd2f4);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x56db8e,_0x27ee1f,_0x50b582){let _0x2e4b87=this;const _0x425bdc=_0x50b582(_0x56db8e,_0x2e4b87['key']);return _0x425bdc<0x0?_0x2e4b87=_0x2e4b87['copy'](null,null,null,_0x2e4b87['left']['insert'](_0x56db8e,_0x27ee1f,_0x50b582),null):_0x425bdc===0x0?_0x2e4b87=_0x2e4b87['copy'](null,_0x27ee1f,null,null,null):_0x2e4b87=_0x2e4b87['copy'](null,null,null,null,_0x2e4b87['right']['insert'](_0x56db8e,_0x27ee1f,_0x50b582)),_0x2e4b87['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4d4119=this;return!_0x4d4119['left']['isRed_']()&&!_0x4d4119['left']['left']['isRed_']()&&(_0x4d4119=_0x4d4119['moveRedLeft_']()),_0x4d4119=_0x4d4119['copy'](null,null,null,_0x4d4119['left']['removeMin_'](),null),_0x4d4119['fixUp_']();}['remove'](_0x2b6eeb,_0x1dd7ed){let _0x3f0e3f,_0x5773ff;if(_0x3f0e3f=this,_0x1dd7ed(_0x2b6eeb,_0x3f0e3f['key'])<0x0)!_0x3f0e3f['left']['isEmpty']()&&!_0x3f0e3f['left']['isRed_']()&&!_0x3f0e3f['left']['left']['isRed_']()&&(_0x3f0e3f=_0x3f0e3f['moveRedLeft_']()),_0x3f0e3f=_0x3f0e3f['copy'](null,null,null,_0x3f0e3f['left']['remove'](_0x2b6eeb,_0x1dd7ed),null);else{if(_0x3f0e3f['left']['isRed_']()&&(_0x3f0e3f=_0x3f0e3f['rotateRight_']()),!_0x3f0e3f['right']['isEmpty']()&&!_0x3f0e3f['right']['isRed_']()&&!_0x3f0e3f['right']['left']['isRed_']()&&(_0x3f0e3f=_0x3f0e3f['moveRedRight_']()),_0x1dd7ed(_0x2b6eeb,_0x3f0e3f['key'])===0x0){if(_0x3f0e3f['right']['isEmpty']())return B['EMPTY_NODE'];_0x5773ff=_0x3f0e3f['right']['min_'](),_0x3f0e3f=_0x3f0e3f['copy'](_0x5773ff['key'],_0x5773ff['value'],null,null,_0x3f0e3f['right']['removeMin_']());}_0x3f0e3f=_0x3f0e3f['copy'](null,null,null,null,_0x3f0e3f['right']['remove'](_0x2b6eeb,_0x1dd7ed));}return _0x3f0e3f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1a8651=this;return _0x1a8651['right']['isRed_']()&&!_0x1a8651['left']['isRed_']()&&(_0x1a8651=_0x1a8651['rotateLeft_']()),_0x1a8651['left']['isRed_']()&&_0x1a8651['left']['left']['isRed_']()&&(_0x1a8651=_0x1a8651['rotateRight_']()),_0x1a8651['left']['isRed_']()&&_0x1a8651['right']['isRed_']()&&(_0x1a8651=_0x1a8651['colorFlip_']()),_0x1a8651;}['moveRedLeft_'](){let _0x29ca16=this['colorFlip_']();return _0x29ca16['right']['left']['isRed_']()&&(_0x29ca16=_0x29ca16['copy'](null,null,null,null,_0x29ca16['right']['rotateRight_']()),_0x29ca16=_0x29ca16['rotateLeft_'](),_0x29ca16=_0x29ca16['colorFlip_']()),_0x29ca16;}['moveRedRight_'](){let _0x517189=this['colorFlip_']();return _0x517189['left']['left']['isRed_']()&&(_0x517189=_0x517189['rotateRight_'](),_0x517189=_0x517189['colorFlip_']()),_0x517189;}['rotateLeft_'](){const _0x126940=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x126940,null);}['rotateRight_'](){const _0x4597cf=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x4597cf);}['colorFlip_'](){const _0x5e7803=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2c0f84=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5e7803,_0x2c0f84);}['checkMaxDepth_'](){const _0xebbb13=this['check_']();return Math['pow'](0x2,_0xebbb13)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2d6ff0=this['left']['check_']();if(_0x2d6ff0!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2d6ff0+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x2931cd,_0x42f6fb,_0x323038,_0xa943b6,_0x208705){return this;}['insert'](_0x41b568,_0x4a237b,_0x554f78){return new M(_0x41b568,_0x4a237b,null);}['remove'](_0x42f2f6,_0x56ec68){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x9b7fe6){return!0x1;}['reverseTraversal'](_0x41b6ec){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x181a59,_0x451d19=B['EMPTY_NODE']){this['comparator_']=_0x181a59,this['root_']=_0x451d19;}['insert'](_0x37ca0c,_0x17fb4c){return new B(this['comparator_'],this['root_']['insert'](_0x37ca0c,_0x17fb4c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x48540c){return new B(this['comparator_'],this['root_']['remove'](_0x48540c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x41c530){let _0x32bc69,_0x57ac02=this['root_'];for(;!_0x57ac02['isEmpty']();){if(_0x32bc69=this['comparator_'](_0x41c530,_0x57ac02['key']),_0x32bc69===0x0)return _0x57ac02['value'];_0x32bc69<0x0?_0x57ac02=_0x57ac02['left']:_0x32bc69>0x0&&(_0x57ac02=_0x57ac02['right']);}return null;}['getPredecessorKey'](_0xfdf312){let _0x2562e4,_0x1c931f=this['root_'],_0xeda0b4=null;for(;!_0x1c931f['isEmpty']();)if(_0x2562e4=this['comparator_'](_0xfdf312,_0x1c931f['key']),_0x2562e4===0x0){if(_0x1c931f['left']['isEmpty']())return _0xeda0b4?_0xeda0b4['key']:null;for(_0x1c931f=_0x1c931f['left'];!_0x1c931f['right']['isEmpty']();)_0x1c931f=_0x1c931f['right'];return _0x1c931f['key'];}else _0x2562e4<0x0?_0x1c931f=_0x1c931f['left']:_0x2562e4>0x0&&(_0xeda0b4=_0x1c931f,_0x1c931f=_0x1c931f['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x52043f){return this['root_']['inorderTraversal'](_0x52043f);}['reverseTraversal'](_0x33edad){return this['root_']['reverseTraversal'](_0x33edad);}['getIterator'](_0x3531e8){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x3531e8);}['getIteratorFrom'](_0x265bb1,_0x2d9822){return new rn(this['root_'],_0x265bb1,this['comparator_'],!0x1,_0x2d9822);}['getReverseIteratorFrom'](_0x599a38,_0x43ed93){return new rn(this['root_'],_0x599a38,this['comparator_'],!0x0,_0x43ed93);}['getReverseIterator'](_0x18d910){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x18d910);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1d741b,_0x255502){return qe(_0x1d741b['name'],_0x255502['name']);}function Qi(_0x358d90,_0x49042b){return qe(_0x358d90,_0x49042b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x1c8e62){Ci=_0x1c8e62;}const Po=function(_0x55e804){return typeof _0x55e804=='number'?'number:'+ao(_0x55e804):'string:'+_0x55e804;},No=function(_0x5540d4){if(_0x5540d4['isLeafNode']()){const _0x2da6b1=_0x5540d4['val']();f(typeof _0x2da6b1=='string'||typeof _0x2da6b1=='number'||typeof _0x2da6b1=='object'&&Q(_0x2da6b1,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5540d4===Ci||_0x5540d4['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5540d4===Ci||_0x5540d4['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x44b906){nr=_0x44b906;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x3bd896,_0x1bf59b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3bd896,this['priorityNode_']=_0x1bf59b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4eabc0){return new D(this['value_'],_0x4eabc0);}['getImmediateChild'](_0x464b76){return _0x464b76==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1e9b69){return v(_0x1e9b69)?this:y(_0x1e9b69)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x589957,_0x464b0e){return null;}['updateImmediateChild'](_0x536c78,_0x24da7a){return _0x536c78==='.priority'?this['updatePriority'](_0x24da7a):_0x24da7a['isEmpty']()&&_0x536c78!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x536c78,_0x24da7a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xf56eec,_0x3d8b88){const _0x4c2cc4=y(_0xf56eec);return _0x4c2cc4===null?_0x3d8b88:_0x3d8b88['isEmpty']()&&_0x4c2cc4!=='.priority'?this:(f(_0x4c2cc4!=='.priority'||Ce(_0xf56eec)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4c2cc4,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0xf56eec),_0x3d8b88)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4f3dc3,_0x5025c9){return!0x1;}['val'](_0x4035d9){return _0x4035d9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2f0925='';this['priorityNode_']['isEmpty']()||(_0x2f0925+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x129ade=typeof this['value_'];_0x2f0925+=_0x129ade+':',_0x129ade==='number'?_0x2f0925+=ao(this['value_']):_0x2f0925+=this['value_'],this['lazyHash_']=ro(_0x2f0925);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x398f0f){return _0x398f0f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x398f0f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x398f0f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x398f0f));}['compareToLeafNode_'](_0x576552){const _0x252cab=typeof _0x576552['value_'],_0x4f599c=typeof this['value_'],_0x29ea1c=D['VALUE_TYPE_ORDER']['indexOf'](_0x252cab),_0x1196cb=D['VALUE_TYPE_ORDER']['indexOf'](_0x4f599c);return f(_0x29ea1c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x252cab),f(_0x1196cb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4f599c),_0x29ea1c===_0x1196cb?_0x4f599c==='object'?0x0:this['value_']<_0x576552['value_']?-0x1:this['value_']===_0x576552['value_']?0x0:0x1:_0x1196cb-_0x29ea1c;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3edbae){if(_0x3edbae===this)return!0x0;if(_0x3edbae['isLeafNode']()){const _0x5226b5=_0x3edbae;return this['value_']===_0x5226b5['value_']&&this['priorityNode_']['equals'](_0x5226b5['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1a2566){Oo=_0x1a2566;}function Wh(_0x4804ff){Do=_0x4804ff;}class Bh extends Fn{['compare'](_0x509f2b,_0xb3e4e3){const _0x25572c=_0x509f2b['node']['getPriority'](),_0x3750dc=_0xb3e4e3['node']['getPriority'](),_0x1550c1=_0x25572c['compareTo'](_0x3750dc);return _0x1550c1===0x0?qe(_0x509f2b['name'],_0xb3e4e3['name']):_0x1550c1;}['isDefinedOn'](_0x5dbd0f){return!_0x5dbd0f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x544f22,_0x8a821a){return!_0x544f22['getPriority']()['equals'](_0x8a821a['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x9a8106,_0x7329fa){const _0x30c989=Oo(_0x9a8106);return new E(_0x7329fa,new D('[PRIORITY-POST]',_0x30c989));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x398e29){const _0x398af0=_0x28802b=>parseInt(Math['log'](_0x28802b)/Vh,0xa),_0x1c96e6=_0x1d405d=>parseInt(Array(_0x1d405d+0x1)['join']('1'),0x2);this['count']=_0x398af0(_0x398e29+0x1),this['current_']=this['count']-0x1;const _0x9af437=_0x1c96e6(this['count']);this['bits_']=_0x398e29+0x1&_0x9af437;}['nextBitIsOne'](){const _0xc459f9=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xc459f9;}}const yn=function(_0x28c34b,_0x3259c2,_0x2b3508,_0x2fcd90){_0x28c34b['sort'](_0x3259c2);const _0x5067f3=function(_0x361429,_0x1e78b8){const _0x44ac2c=_0x1e78b8-_0x361429;let _0x1fd2fe,_0x2e08e8;if(_0x44ac2c===0x0)return null;if(_0x44ac2c===0x1)return _0x1fd2fe=_0x28c34b[_0x361429],_0x2e08e8=_0x2b3508?_0x2b3508(_0x1fd2fe):_0x1fd2fe,new M(_0x2e08e8,_0x1fd2fe['node'],M['BLACK'],null,null);{const _0x500b9b=parseInt(_0x44ac2c/0x2,0xa)+_0x361429,_0x43791a=_0x5067f3(_0x361429,_0x500b9b),_0x58002b=_0x5067f3(_0x500b9b+0x1,_0x1e78b8);return _0x1fd2fe=_0x28c34b[_0x500b9b],_0x2e08e8=_0x2b3508?_0x2b3508(_0x1fd2fe):_0x1fd2fe,new M(_0x2e08e8,_0x1fd2fe['node'],M['BLACK'],_0x43791a,_0x58002b);}},_0x34e086=function(_0x254fce){let _0x503e9b=null,_0x3ee41c=null,_0x11e10e=_0x28c34b['length'];const _0x44ffa9=function(_0x17c7dd,_0x3de3bd){const _0xbee4fa=_0x11e10e-_0x17c7dd,_0x28e2bb=_0x11e10e;_0x11e10e-=_0x17c7dd;const _0x4c21dc=_0x5067f3(_0xbee4fa+0x1,_0x28e2bb),_0x1b0f2f=_0x28c34b[_0xbee4fa],_0x2d19fa=_0x2b3508?_0x2b3508(_0x1b0f2f):_0x1b0f2f;_0x315ea5(new M(_0x2d19fa,_0x1b0f2f['node'],_0x3de3bd,null,_0x4c21dc));},_0x315ea5=function(_0x7bfc33){_0x503e9b?(_0x503e9b['left']=_0x7bfc33,_0x503e9b=_0x7bfc33):(_0x3ee41c=_0x7bfc33,_0x503e9b=_0x7bfc33);};for(let _0x51bb51=0x0;_0x51bb51<_0x254fce['count'];++_0x51bb51){const _0x290ec0=_0x254fce['nextBitIsOne'](),_0x5c5a95=Math['pow'](0x2,_0x254fce['count']-(_0x51bb51+0x1));_0x290ec0?_0x44ffa9(_0x5c5a95,M['BLACK']):(_0x44ffa9(_0x5c5a95,M['BLACK']),_0x44ffa9(_0x5c5a95,M['RED']));}return _0x3ee41c;},_0x30ecbe=new Hh(_0x28c34b['length']),_0x238b50=_0x34e086(_0x30ecbe);return new B(_0x2fcd90||_0x3259c2,_0x238b50);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0xe68b68,_0x498f33){this['indexes_']=_0xe68b68,this['indexSet_']=_0x498f33;}['get'](_0x318480){const _0xf5e446=Le(this['indexes_'],_0x318480);if(!_0xf5e446)throw new Error('No\x20index\x20defined\x20for\x20'+_0x318480);return _0xf5e446 instanceof B?_0xf5e446:null;}['hasIndex'](_0x6e2072){return Q(this['indexSet_'],_0x6e2072['toString']());}['addIndex'](_0x1ce8c5,_0x3adb5d){f(_0x1ce8c5!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x565c42=[];let _0x1a8f71=!0x1;const _0x54bd6d=_0x3adb5d['getIterator'](E['Wrap']);let _0x291dd7=_0x54bd6d['getNext']();for(;_0x291dd7;)_0x1a8f71=_0x1a8f71||_0x1ce8c5['isDefinedOn'](_0x291dd7['node']),_0x565c42['push'](_0x291dd7),_0x291dd7=_0x54bd6d['getNext']();let _0x4ab774;_0x1a8f71?_0x4ab774=yn(_0x565c42,_0x1ce8c5['getCompare']()):_0x4ab774=Qe;const _0x1d7d86=_0x1ce8c5['toString'](),_0x305649={...this['indexSet_']};_0x305649[_0x1d7d86]=_0x1ce8c5;const _0x4edf1a={...this['indexes_']};return _0x4edf1a[_0x1d7d86]=_0x4ab774,new te(_0x4edf1a,_0x305649);}['addToIndexes'](_0x55f5eb,_0xf9ab9){const _0x2c9c93=_n(this['indexes_'],(_0x154260,_0x50e74d)=>{const _0x391430=Le(this['indexSet_'],_0x50e74d);if(f(_0x391430,'Missing\x20index\x20implementation\x20for\x20'+_0x50e74d),_0x154260===Qe){if(_0x391430['isDefinedOn'](_0x55f5eb['node'])){const _0xc74be2=[],_0xfe4653=_0xf9ab9['getIterator'](E['Wrap']);let _0x184031=_0xfe4653['getNext']();for(;_0x184031;)_0x184031['name']!==_0x55f5eb['name']&&_0xc74be2['push'](_0x184031),_0x184031=_0xfe4653['getNext']();return _0xc74be2['push'](_0x55f5eb),yn(_0xc74be2,_0x391430['getCompare']());}else return Qe;}else{const _0xc8b9c4=_0xf9ab9['get'](_0x55f5eb['name']);let _0x14db05=_0x154260;return _0xc8b9c4&&(_0x14db05=_0x14db05['remove'](new E(_0x55f5eb['name'],_0xc8b9c4))),_0x14db05['insert'](_0x55f5eb,_0x55f5eb['node']);}});return new te(_0x2c9c93,this['indexSet_']);}['removeFromIndexes'](_0x544b80,_0x516cdb){const _0x31c9aa=_n(this['indexes_'],_0x41e41f=>{if(_0x41e41f===Qe)return _0x41e41f;{const _0x3c4fdc=_0x516cdb['get'](_0x544b80['name']);return _0x3c4fdc?_0x41e41f['remove'](new E(_0x544b80['name'],_0x3c4fdc)):_0x41e41f;}});return new te(_0x31c9aa,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4d3e73,_0x1deaa5,_0x35ad23){this['children_']=_0x4d3e73,this['priorityNode_']=_0x1deaa5,this['indexMap_']=_0x35ad23,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x104a3b){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x104a3b,this['indexMap_']);}['getImmediateChild'](_0x36f9d6){if(_0x36f9d6==='.priority')return this['getPriority']();{const _0x573634=this['children_']['get'](_0x36f9d6);return _0x573634===null?It:_0x573634;}}['getChild'](_0xd75bfc){const _0x5156b1=y(_0xd75bfc);return _0x5156b1===null?this:this['getImmediateChild'](_0x5156b1)['getChild'](S(_0xd75bfc));}['hasChild'](_0x29dc91){return this['children_']['get'](_0x29dc91)!==null;}['updateImmediateChild'](_0x4054ca,_0x5bd33a){if(f(_0x5bd33a,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4054ca==='.priority')return this['updatePriority'](_0x5bd33a);{const _0x2e2d4a=new E(_0x4054ca,_0x5bd33a);let _0x3f8954,_0x3e7d5c;_0x5bd33a['isEmpty']()?(_0x3f8954=this['children_']['remove'](_0x4054ca),_0x3e7d5c=this['indexMap_']['removeFromIndexes'](_0x2e2d4a,this['children_'])):(_0x3f8954=this['children_']['insert'](_0x4054ca,_0x5bd33a),_0x3e7d5c=this['indexMap_']['addToIndexes'](_0x2e2d4a,this['children_']));const _0x3832aa=_0x3f8954['isEmpty']()?It:this['priorityNode_'];return new g(_0x3f8954,_0x3832aa,_0x3e7d5c);}}['updateChild'](_0x323efc,_0xf7fbeb){const _0x191a84=y(_0x323efc);if(_0x191a84===null)return _0xf7fbeb;{f(y(_0x323efc)!=='.priority'||Ce(_0x323efc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x3add38=this['getImmediateChild'](_0x191a84)['updateChild'](S(_0x323efc),_0xf7fbeb);return this['updateImmediateChild'](_0x191a84,_0x3add38);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2bb6d7){if(this['isEmpty']())return null;const _0x27340c={};let _0x3feb45=0x0,_0x566f9c=0x0,_0x463918=!0x0;if(this['forEachChild'](R,(_0x225026,_0x381e82)=>{_0x27340c[_0x225026]=_0x381e82['val'](_0x2bb6d7),_0x3feb45++,_0x463918&&g['INTEGER_REGEXP_']['test'](_0x225026)?_0x566f9c=Math['max'](_0x566f9c,Number(_0x225026)):_0x463918=!0x1;}),!_0x2bb6d7&&_0x463918&&_0x566f9c<0x2*_0x3feb45){const _0xbb1bb5=[];for(const _0x26f736 in _0x27340c)_0xbb1bb5[_0x26f736]=_0x27340c[_0x26f736];return _0xbb1bb5;}else return _0x2bb6d7&&!this['getPriority']()['isEmpty']()&&(_0x27340c['.priority']=this['getPriority']()['val']()),_0x27340c;}['hash'](){if(this['lazyHash_']===null){let _0x9349e7='';this['getPriority']()['isEmpty']()||(_0x9349e7+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xcc5bed,_0x5ed782)=>{const _0x21a603=_0x5ed782['hash']();_0x21a603!==''&&(_0x9349e7+=':'+_0xcc5bed+':'+_0x21a603);}),this['lazyHash_']=_0x9349e7===''?'':ro(_0x9349e7);}return this['lazyHash_'];}['getPredecessorChildName'](_0x19055c,_0x26176d,_0x3d2bd){const _0x53145b=this['resolveIndex_'](_0x3d2bd);if(_0x53145b){const _0x3ea25c=_0x53145b['getPredecessorKey'](new E(_0x19055c,_0x26176d));return _0x3ea25c?_0x3ea25c['name']:null;}else return this['children_']['getPredecessorKey'](_0x19055c);}['getFirstChildName'](_0x4bede0){const _0x1dce28=this['resolveIndex_'](_0x4bede0);if(_0x1dce28){const _0x38cfcc=_0x1dce28['minKey']();return _0x38cfcc&&_0x38cfcc['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x36c122){const _0x1a6b7=this['getFirstChildName'](_0x36c122);return _0x1a6b7?new E(_0x1a6b7,this['children_']['get'](_0x1a6b7)):null;}['getLastChildName'](_0x1348c0){const _0xd03a37=this['resolveIndex_'](_0x1348c0);if(_0xd03a37){const _0x454d90=_0xd03a37['maxKey']();return _0x454d90&&_0x454d90['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2fc6b4){const _0xbbdb26=this['getLastChildName'](_0x2fc6b4);return _0xbbdb26?new E(_0xbbdb26,this['children_']['get'](_0xbbdb26)):null;}['forEachChild'](_0x582a5a,_0x43e52f){const _0x4a6f5a=this['resolveIndex_'](_0x582a5a);return _0x4a6f5a?_0x4a6f5a['inorderTraversal'](_0x2a031c=>_0x43e52f(_0x2a031c['name'],_0x2a031c['node'])):this['children_']['inorderTraversal'](_0x43e52f);}['getIterator'](_0x11ee31){return this['getIteratorFrom'](_0x11ee31['minPost'](),_0x11ee31);}['getIteratorFrom'](_0x215c45,_0x22371f){const _0x3d5a6e=this['resolveIndex_'](_0x22371f);if(_0x3d5a6e)return _0x3d5a6e['getIteratorFrom'](_0x215c45,_0x246be2=>_0x246be2);{const _0x46ca13=this['children_']['getIteratorFrom'](_0x215c45['name'],E['Wrap']);let _0x34f7b8=_0x46ca13['peek']();for(;_0x34f7b8!=null&&_0x22371f['compare'](_0x34f7b8,_0x215c45)<0x0;)_0x46ca13['getNext'](),_0x34f7b8=_0x46ca13['peek']();return _0x46ca13;}}['getReverseIterator'](_0x51ee9d){return this['getReverseIteratorFrom'](_0x51ee9d['maxPost'](),_0x51ee9d);}['getReverseIteratorFrom'](_0x57b752,_0x555f08){const _0x2dba99=this['resolveIndex_'](_0x555f08);if(_0x2dba99)return _0x2dba99['getReverseIteratorFrom'](_0x57b752,_0x218fb5=>_0x218fb5);{const _0x394ddb=this['children_']['getReverseIteratorFrom'](_0x57b752['name'],E['Wrap']);let _0x339fd5=_0x394ddb['peek']();for(;_0x339fd5!=null&&_0x555f08['compare'](_0x339fd5,_0x57b752)>0x0;)_0x394ddb['getNext'](),_0x339fd5=_0x394ddb['peek']();return _0x394ddb;}}['compareTo'](_0x59e562){return this['isEmpty']()?_0x59e562['isEmpty']()?0x0:-0x1:_0x59e562['isLeafNode']()||_0x59e562['isEmpty']()?0x1:_0x59e562===Kt?-0x1:0x0;}['withIndex'](_0x5eb592){if(_0x5eb592===ve||this['indexMap_']['hasIndex'](_0x5eb592))return this;{const _0x55ca9a=this['indexMap_']['addIndex'](_0x5eb592,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x55ca9a);}}['isIndexed'](_0x41f1f0){return _0x41f1f0===ve||this['indexMap_']['hasIndex'](_0x41f1f0);}['equals'](_0x10bb31){if(_0x10bb31===this)return!0x0;if(_0x10bb31['isLeafNode']())return!0x1;{const _0x5f0991=_0x10bb31;if(this['getPriority']()['equals'](_0x5f0991['getPriority']())){if(this['children_']['count']()===_0x5f0991['children_']['count']()){const _0x4f874d=this['getIterator'](R),_0x3e886d=_0x5f0991['getIterator'](R);let _0x47bfa7=_0x4f874d['getNext'](),_0x3aa935=_0x3e886d['getNext']();for(;_0x47bfa7&&_0x3aa935;){if(_0x47bfa7['name']!==_0x3aa935['name']||!_0x47bfa7['node']['equals'](_0x3aa935['node']))return!0x1;_0x47bfa7=_0x4f874d['getNext'](),_0x3aa935=_0x3e886d['getNext']();}return _0x47bfa7===null&&_0x3aa935===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3902f5){return _0x3902f5===ve?null:this['indexMap_']['get'](_0x3902f5['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x303683){return _0x303683===this?0x0:0x1;}['equals'](_0x3481fb){return _0x3481fb===this;}['getPriority'](){return this;}['getImmediateChild'](_0x192686){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x19bb43,_0x4d961e=null){if(_0x19bb43===null)return g['EMPTY_NODE'];if(typeof _0x19bb43=='object'&&'.priority'in _0x19bb43&&(_0x4d961e=_0x19bb43['.priority']),f(_0x4d961e===null||typeof _0x4d961e=='string'||typeof _0x4d961e=='number'||typeof _0x4d961e=='object'&&'.sv'in _0x4d961e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4d961e),typeof _0x19bb43=='object'&&'.value'in _0x19bb43&&_0x19bb43['.value']!==null&&(_0x19bb43=_0x19bb43['.value']),typeof _0x19bb43!='object'||'.sv'in _0x19bb43){const _0x303c62=_0x19bb43;return new D(_0x303c62,A(_0x4d961e));}if(!(_0x19bb43 instanceof Array)&&Gh){const _0x5c8004=[];let _0xdd1a02=!0x1;if(x(_0x19bb43,(_0x5b9824,_0x42e6ff)=>{if(_0x5b9824['substring'](0x0,0x1)!=='.'){const _0x2b6000=A(_0x42e6ff);_0x2b6000['isEmpty']()||(_0xdd1a02=_0xdd1a02||!_0x2b6000['getPriority']()['isEmpty'](),_0x5c8004['push'](new E(_0x5b9824,_0x2b6000)));}}),_0x5c8004['length']===0x0)return g['EMPTY_NODE'];const _0x1e86dc=yn(_0x5c8004,xh,_0x5ef48c=>_0x5ef48c['name'],Qi);if(_0xdd1a02){const _0x3441ac=yn(_0x5c8004,R['getCompare']());return new g(_0x1e86dc,A(_0x4d961e),new te({'.priority':_0x3441ac},{'.priority':R}));}else return new g(_0x1e86dc,A(_0x4d961e),te['Default']);}else{let _0x2c56a1=g['EMPTY_NODE'];return x(_0x19bb43,(_0x1a9433,_0x5ad6e2)=>{if(Q(_0x19bb43,_0x1a9433)&&_0x1a9433['substring'](0x0,0x1)!=='.'){const _0xc90f17=A(_0x5ad6e2);(_0xc90f17['isLeafNode']()||!_0xc90f17['isEmpty']())&&(_0x2c56a1=_0x2c56a1['updateImmediateChild'](_0x1a9433,_0xc90f17));}}),_0x2c56a1['updatePriority'](A(_0x4d961e));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x26d576){super(),this['indexPath_']=_0x26d576,f(!v(_0x26d576)&&y(_0x26d576)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x28e04a){return _0x28e04a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3fa035){return!_0x3fa035['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2d36dd,_0x46300c){const _0x510366=this['extractChild'](_0x2d36dd['node']),_0xb2648d=this['extractChild'](_0x46300c['node']),_0x5946df=_0x510366['compareTo'](_0xb2648d);return _0x5946df===0x0?qe(_0x2d36dd['name'],_0x46300c['name']):_0x5946df;}['makePost'](_0x1cda1d,_0x2cda09){const _0x3134db=A(_0x1cda1d),_0x3b3c2a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3134db);return new E(_0x2cda09,_0x3b3c2a);}['maxPost'](){const _0x4e9c62=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4e9c62);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x1f055a,_0x3c761c){const _0x3d2101=_0x1f055a['node']['compareTo'](_0x3c761c['node']);return _0x3d2101===0x0?qe(_0x1f055a['name'],_0x3c761c['name']):_0x3d2101;}['isDefinedOn'](_0x4abb2f){return!0x0;}['indexedValueChanged'](_0x3ad5c2,_0x1d1a03){return!_0x3ad5c2['equals'](_0x1d1a03);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x32898b,_0xa53ec0){const _0x27befb=A(_0x32898b);return new E(_0xa53ec0,_0x27befb);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x24a77b){return{'type':'value','snapshotNode':_0x24a77b};}function rt(_0x1fad1a,_0x583184){return{'type':'child_added','snapshotNode':_0x583184,'childName':_0x1fad1a};}function Lt(_0x418a56,_0x48cf88){return{'type':'child_removed','snapshotNode':_0x48cf88,'childName':_0x418a56};}function xt(_0x5878e5,_0x9864c6,_0x5c59ba){return{'type':'child_changed','snapshotNode':_0x9864c6,'childName':_0x5878e5,'oldSnap':_0x5c59ba};}function zh(_0x42d93a,_0x5a69fd){return{'type':'child_moved','snapshotNode':_0x5a69fd,'childName':_0x42d93a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x625780){this['index_']=_0x625780;}['updateChild'](_0x858242,_0x186ecc,_0x443854,_0x8e8b43,_0x53d8e7,_0x4bf7ed){f(_0x858242['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1eede0=_0x858242['getImmediateChild'](_0x186ecc);return _0x1eede0['getChild'](_0x8e8b43)['equals'](_0x443854['getChild'](_0x8e8b43))&&_0x1eede0['isEmpty']()===_0x443854['isEmpty']()||(_0x4bf7ed!=null&&(_0x443854['isEmpty']()?_0x858242['hasChild'](_0x186ecc)?_0x4bf7ed['trackChildChange'](Lt(_0x186ecc,_0x1eede0)):f(_0x858242['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1eede0['isEmpty']()?_0x4bf7ed['trackChildChange'](rt(_0x186ecc,_0x443854)):_0x4bf7ed['trackChildChange'](xt(_0x186ecc,_0x443854,_0x1eede0))),_0x858242['isLeafNode']()&&_0x443854['isEmpty']())?_0x858242:_0x858242['updateImmediateChild'](_0x186ecc,_0x443854)['withIndex'](this['index_']);}['updateFullNode'](_0x14dad4,_0x4f4db8,_0x5bd7aa){return _0x5bd7aa!=null&&(_0x14dad4['isLeafNode']()||_0x14dad4['forEachChild'](R,(_0x40a847,_0x133a2d)=>{_0x4f4db8['hasChild'](_0x40a847)||_0x5bd7aa['trackChildChange'](Lt(_0x40a847,_0x133a2d));}),_0x4f4db8['isLeafNode']()||_0x4f4db8['forEachChild'](R,(_0x4858fb,_0x3982ed)=>{if(_0x14dad4['hasChild'](_0x4858fb)){const _0x97e8ba=_0x14dad4['getImmediateChild'](_0x4858fb);_0x97e8ba['equals'](_0x3982ed)||_0x5bd7aa['trackChildChange'](xt(_0x4858fb,_0x3982ed,_0x97e8ba));}else _0x5bd7aa['trackChildChange'](rt(_0x4858fb,_0x3982ed));})),_0x4f4db8['withIndex'](this['index_']);}['updatePriority'](_0x4c3a12,_0x39cc49){return _0x4c3a12['isEmpty']()?g['EMPTY_NODE']:_0x4c3a12['updatePriority'](_0x39cc49);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x5dc533){this['indexedFilter_']=new Xi(_0x5dc533['getIndex']()),this['index_']=_0x5dc533['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x5dc533),this['endPost_']=Ft['getEndPost_'](_0x5dc533),this['startIsInclusive_']=!_0x5dc533['startAfterSet_'],this['endIsInclusive_']=!_0x5dc533['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1a50a9){const _0x34b832=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1a50a9)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1a50a9)<0x0,_0x30e184=this['endIsInclusive_']?this['index_']['compare'](_0x1a50a9,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1a50a9,this['getEndPost']())<0x0;return _0x34b832&&_0x30e184;}['updateChild'](_0x241f2f,_0x50021e,_0x357502,_0x4a7cfa,_0x737353,_0x30cca4){return this['matches'](new E(_0x50021e,_0x357502))||(_0x357502=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x241f2f,_0x50021e,_0x357502,_0x4a7cfa,_0x737353,_0x30cca4);}['updateFullNode'](_0x58e030,_0x566ee2,_0x3c7ffc){_0x566ee2['isLeafNode']()&&(_0x566ee2=g['EMPTY_NODE']);let _0x58402a=_0x566ee2['withIndex'](this['index_']);_0x58402a=_0x58402a['updatePriority'](g['EMPTY_NODE']);const _0x16c968=this;return _0x566ee2['forEachChild'](R,(_0x23aa7f,_0x4c3722)=>{_0x16c968['matches'](new E(_0x23aa7f,_0x4c3722))||(_0x58402a=_0x58402a['updateImmediateChild'](_0x23aa7f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x58e030,_0x58402a,_0x3c7ffc);}['updatePriority'](_0x2cb5e2,_0x155ff2){return _0x2cb5e2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x432a30){if(_0x432a30['hasStart']()){const _0x2ddfd9=_0x432a30['getIndexStartName']();return _0x432a30['getIndex']()['makePost'](_0x432a30['getIndexStartValue'](),_0x2ddfd9);}else return _0x432a30['getIndex']()['minPost']();}static['getEndPost_'](_0x439b28){if(_0x439b28['hasEnd']()){const _0x223b64=_0x439b28['getIndexEndName']();return _0x439b28['getIndex']()['makePost'](_0x439b28['getIndexEndValue'](),_0x223b64);}else return _0x439b28['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x49f53f){this['withinDirectionalStart']=_0x340924=>this['reverse_']?this['withinEndPost'](_0x340924):this['withinStartPost'](_0x340924),this['withinDirectionalEnd']=_0x234a73=>this['reverse_']?this['withinStartPost'](_0x234a73):this['withinEndPost'](_0x234a73),this['withinStartPost']=_0x22a3c3=>{const _0x22f244=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x22a3c3);return this['startIsInclusive_']?_0x22f244<=0x0:_0x22f244<0x0;},this['withinEndPost']=_0x186261=>{const _0x2a3b73=this['index_']['compare'](_0x186261,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2a3b73<=0x0:_0x2a3b73<0x0;},this['rangedFilter_']=new Ft(_0x49f53f),this['index_']=_0x49f53f['getIndex'](),this['limit_']=_0x49f53f['getLimit'](),this['reverse_']=!_0x49f53f['isViewFromLeft'](),this['startIsInclusive_']=!_0x49f53f['startAfterSet_'],this['endIsInclusive_']=!_0x49f53f['endBeforeSet_'];}['updateChild'](_0x54563e,_0x11881d,_0x1d527e,_0x4cf154,_0x28da1e,_0x283397){return this['rangedFilter_']['matches'](new E(_0x11881d,_0x1d527e))||(_0x1d527e=g['EMPTY_NODE']),_0x54563e['getImmediateChild'](_0x11881d)['equals'](_0x1d527e)?_0x54563e:_0x54563e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x54563e,_0x11881d,_0x1d527e,_0x4cf154,_0x28da1e,_0x283397):this['fullLimitUpdateChild_'](_0x54563e,_0x11881d,_0x1d527e,_0x28da1e,_0x283397);}['updateFullNode'](_0x12ca13,_0x52df65,_0x32af99){let _0x417551;if(_0x52df65['isLeafNode']()||_0x52df65['isEmpty']())_0x417551=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x52df65['numChildren']()&&_0x52df65['isIndexed'](this['index_'])){_0x417551=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x356c54;this['reverse_']?_0x356c54=_0x52df65['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x356c54=_0x52df65['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x8c7478=0x0;for(;_0x356c54['hasNext']()&&_0x8c7478<this['limit_'];){const _0x55040d=_0x356c54['getNext']();if(this['withinDirectionalStart'](_0x55040d)){if(this['withinDirectionalEnd'](_0x55040d))_0x417551=_0x417551['updateImmediateChild'](_0x55040d['name'],_0x55040d['node']),_0x8c7478++;else break;}else continue;}}else{_0x417551=_0x52df65['withIndex'](this['index_']),_0x417551=_0x417551['updatePriority'](g['EMPTY_NODE']);let _0x208d15;this['reverse_']?_0x208d15=_0x417551['getReverseIterator'](this['index_']):_0x208d15=_0x417551['getIterator'](this['index_']);let _0x492d55=0x0;for(;_0x208d15['hasNext']();){const _0x469996=_0x208d15['getNext']();_0x492d55<this['limit_']&&this['withinDirectionalStart'](_0x469996)&&this['withinDirectionalEnd'](_0x469996)?_0x492d55++:_0x417551=_0x417551['updateImmediateChild'](_0x469996['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x12ca13,_0x417551,_0x32af99);}['updatePriority'](_0x5b6937,_0x4a5deb){return _0x5b6937;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2d53e4,_0x134b94,_0x4cac6d,_0x16e2f6,_0x1bc15a){let _0x5c2d6e;if(this['reverse_']){const _0x45c066=this['index_']['getCompare']();_0x5c2d6e=(_0x227ba2,_0x21c807)=>_0x45c066(_0x21c807,_0x227ba2);}else _0x5c2d6e=this['index_']['getCompare']();const _0x1a69f2=_0x2d53e4;f(_0x1a69f2['numChildren']()===this['limit_'],'');const _0x237304=new E(_0x134b94,_0x4cac6d),_0x54ae52=this['reverse_']?_0x1a69f2['getFirstChild'](this['index_']):_0x1a69f2['getLastChild'](this['index_']),_0x17b7a7=this['rangedFilter_']['matches'](_0x237304);if(_0x1a69f2['hasChild'](_0x134b94)){const _0x3e5c25=_0x1a69f2['getImmediateChild'](_0x134b94);let _0x5813f6=_0x16e2f6['getChildAfterChild'](this['index_'],_0x54ae52,this['reverse_']);for(;_0x5813f6!=null&&(_0x5813f6['name']===_0x134b94||_0x1a69f2['hasChild'](_0x5813f6['name']));)_0x5813f6=_0x16e2f6['getChildAfterChild'](this['index_'],_0x5813f6,this['reverse_']);const _0x19a284=_0x5813f6==null?0x1:_0x5c2d6e(_0x5813f6,_0x237304);if(_0x17b7a7&&!_0x4cac6d['isEmpty']()&&_0x19a284>=0x0)return _0x1bc15a!=null&&_0x1bc15a['trackChildChange'](xt(_0x134b94,_0x4cac6d,_0x3e5c25)),_0x1a69f2['updateImmediateChild'](_0x134b94,_0x4cac6d);{_0x1bc15a!=null&&_0x1bc15a['trackChildChange'](Lt(_0x134b94,_0x3e5c25));const _0x154f07=_0x1a69f2['updateImmediateChild'](_0x134b94,g['EMPTY_NODE']);return _0x5813f6!=null&&this['rangedFilter_']['matches'](_0x5813f6)?(_0x1bc15a!=null&&_0x1bc15a['trackChildChange'](rt(_0x5813f6['name'],_0x5813f6['node'])),_0x154f07['updateImmediateChild'](_0x5813f6['name'],_0x5813f6['node'])):_0x154f07;}}else return _0x4cac6d['isEmpty']()?_0x2d53e4:_0x17b7a7&&_0x5c2d6e(_0x54ae52,_0x237304)>=0x0?(_0x1bc15a!=null&&(_0x1bc15a['trackChildChange'](Lt(_0x54ae52['name'],_0x54ae52['node'])),_0x1bc15a['trackChildChange'](rt(_0x134b94,_0x4cac6d))),_0x1a69f2['updateImmediateChild'](_0x134b94,_0x4cac6d)['updateImmediateChild'](_0x54ae52['name'],g['EMPTY_NODE'])):_0x2d53e4;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3f33ec=new Zi();return _0x3f33ec['limitSet_']=this['limitSet_'],_0x3f33ec['limit_']=this['limit_'],_0x3f33ec['startSet_']=this['startSet_'],_0x3f33ec['startAfterSet_']=this['startAfterSet_'],_0x3f33ec['indexStartValue_']=this['indexStartValue_'],_0x3f33ec['startNameSet_']=this['startNameSet_'],_0x3f33ec['indexStartName_']=this['indexStartName_'],_0x3f33ec['endSet_']=this['endSet_'],_0x3f33ec['endBeforeSet_']=this['endBeforeSet_'],_0x3f33ec['indexEndValue_']=this['indexEndValue_'],_0x3f33ec['endNameSet_']=this['endNameSet_'],_0x3f33ec['indexEndName_']=this['indexEndName_'],_0x3f33ec['index_']=this['index_'],_0x3f33ec['viewFrom_']=this['viewFrom_'],_0x3f33ec;}}function Kh(_0xba3c88){return _0xba3c88['loadsAllData']()?new Xi(_0xba3c88['getIndex']()):_0xba3c88['hasLimit']()?new jh(_0xba3c88):new Ft(_0xba3c88);}function Yh(_0x48e9f1,_0x4ecf99){const _0x306cd3=_0x48e9f1['copy']();return _0x306cd3['limitSet_']=!0x0,_0x306cd3['limit_']=_0x4ecf99,_0x306cd3['viewFrom_']='l',_0x306cd3;}function Qh(_0x2e193f,_0x3a2286,_0x461e85){const _0xbff254=_0x2e193f['copy']();return _0xbff254['startSet_']=!0x0,_0x3a2286===void 0x0&&(_0x3a2286=null),_0xbff254['indexStartValue_']=_0x3a2286,_0x461e85!=null?(_0xbff254['startNameSet_']=!0x0,_0xbff254['indexStartName_']=_0x461e85):(_0xbff254['startNameSet_']=!0x1,_0xbff254['indexStartName_']=''),_0xbff254;}function Jh(_0x3e6ebf,_0xda3a14,_0x101c29){const _0x2e3ef1=_0x3e6ebf['copy']();return _0x2e3ef1['endSet_']=!0x0,_0xda3a14===void 0x0&&(_0xda3a14=null),_0x2e3ef1['indexEndValue_']=_0xda3a14,_0x101c29!==void 0x0?(_0x2e3ef1['endNameSet_']=!0x0,_0x2e3ef1['indexEndName_']=_0x101c29):(_0x2e3ef1['endNameSet_']=!0x1,_0x2e3ef1['indexEndName_']=''),_0x2e3ef1;}function xo(_0xe4b2ce,_0x2c6e71){const _0x3c44e3=_0xe4b2ce['copy']();return _0x3c44e3['index_']=_0x2c6e71,_0x3c44e3;}function ir(_0x4b7807){const _0x50a212={};if(_0x4b7807['isDefault']())return _0x50a212;let _0x234359;if(_0x4b7807['index_']===R?_0x234359='$priority':_0x4b7807['index_']===Mo?_0x234359='$value':_0x4b7807['index_']===ve?_0x234359='$key':(f(_0x4b7807['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x234359=_0x4b7807['index_']['toString']()),_0x50a212['orderBy']=O(_0x234359),_0x4b7807['startSet_']){const _0x1fd101=_0x4b7807['startAfterSet_']?'startAfter':'startAt';_0x50a212[_0x1fd101]=O(_0x4b7807['indexStartValue_']),_0x4b7807['startNameSet_']&&(_0x50a212[_0x1fd101]+=','+O(_0x4b7807['indexStartName_']));}if(_0x4b7807['endSet_']){const _0x48b48f=_0x4b7807['endBeforeSet_']?'endBefore':'endAt';_0x50a212[_0x48b48f]=O(_0x4b7807['indexEndValue_']),_0x4b7807['endNameSet_']&&(_0x50a212[_0x48b48f]+=','+O(_0x4b7807['indexEndName_']));}return _0x4b7807['limitSet_']&&(_0x4b7807['isViewFromLeft']()?_0x50a212['limitToFirst']=_0x4b7807['limit_']:_0x50a212['limitToLast']=_0x4b7807['limit_']),_0x50a212;}function sr(_0x564102){const _0xc82202={};if(_0x564102['startSet_']&&(_0xc82202['sp']=_0x564102['indexStartValue_'],_0x564102['startNameSet_']&&(_0xc82202['sn']=_0x564102['indexStartName_']),_0xc82202['sin']=!_0x564102['startAfterSet_']),_0x564102['endSet_']&&(_0xc82202['ep']=_0x564102['indexEndValue_'],_0x564102['endNameSet_']&&(_0xc82202['en']=_0x564102['indexEndName_']),_0xc82202['ein']=!_0x564102['endBeforeSet_']),_0x564102['limitSet_']){_0xc82202['l']=_0x564102['limit_'];let _0x50896b=_0x564102['viewFrom_'];_0x50896b===''&&(_0x564102['isViewFromLeft']()?_0x50896b='l':_0x50896b='r'),_0xc82202['vf']=_0x50896b;}return _0x564102['index_']!==R&&(_0xc82202['i']=_0x564102['index_']['toString']()),_0xc82202;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xc5db7c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xe40459,_0x4c489b){return _0x4c489b!==void 0x0?'tag$'+_0x4c489b:(f(_0xe40459['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xe40459['_path']['toString']());}constructor(_0x1b80b9,_0x2ff495,_0x18ee8e,_0x2b6c59){super(),this['repoInfo_']=_0x1b80b9,this['onDataUpdate_']=_0x2ff495,this['authTokenProvider_']=_0x18ee8e,this['appCheckTokenProvider_']=_0x2b6c59,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4c8ba3,_0xd2c8db,_0x1c6f82,_0x16c39a){const _0x5ec432=_0x4c8ba3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5ec432+'\x20'+_0x4c8ba3['_queryIdentifier']);const _0x596f1b=vn['getListenId_'](_0x4c8ba3,_0x1c6f82),_0x1d2571={};this['listens_'][_0x596f1b]=_0x1d2571;const _0xd1b36f=ir(_0x4c8ba3['_queryParams']);this['restRequest_'](_0x5ec432+'.json',_0xd1b36f,(_0x1c947c,_0x3e256)=>{let _0x38ac47=_0x3e256;if(_0x1c947c===0x194&&(_0x38ac47=null,_0x1c947c=null),_0x1c947c===null&&this['onDataUpdate_'](_0x5ec432,_0x38ac47,!0x1,_0x1c6f82),Le(this['listens_'],_0x596f1b)===_0x1d2571){let _0x51fe53;_0x1c947c?_0x1c947c===0x191?_0x51fe53='permission_denied':_0x51fe53='rest_error:'+_0x1c947c:_0x51fe53='ok',_0x16c39a(_0x51fe53,null);}});}['unlisten'](_0x1dea87,_0x45cc01){const _0x233453=vn['getListenId_'](_0x1dea87,_0x45cc01);delete this['listens_'][_0x233453];}['get'](_0x475826){const _0x16bcee=ir(_0x475826['_queryParams']),_0x525037=_0x475826['_path']['toString'](),_0x13b70b=new H();return this['restRequest_'](_0x525037+'.json',_0x16bcee,(_0x524b07,_0x187dbd)=>{let _0x4dd94f=_0x187dbd;_0x524b07===0x194&&(_0x4dd94f=null,_0x524b07=null),_0x524b07===null?(this['onDataUpdate_'](_0x525037,_0x4dd94f,!0x1,null),_0x13b70b['resolve'](_0x4dd94f)):_0x13b70b['reject'](new Error(_0x4dd94f));}),_0x13b70b['promise'];}['refreshAuthToken'](_0x5ba5ac){}['restRequest_'](_0x21dd6c,_0x214047={},_0x367524){return _0x214047['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x55b30f,_0x55810c])=>{_0x55b30f&&_0x55b30f['accessToken']&&(_0x214047['auth']=_0x55b30f['accessToken']),_0x55810c&&_0x55810c['token']&&(_0x214047['ac']=_0x55810c['token']);const _0x5e119e=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x21dd6c+'?ns='+this['repoInfo_']['namespace']+ut(_0x214047);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5e119e);const _0x2455b6=new XMLHttpRequest();_0x2455b6['onreadystatechange']=()=>{if(_0x367524&&_0x2455b6['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5e119e+'\x20received.\x20status:',_0x2455b6['status'],'response:',_0x2455b6['responseText']);let _0x4e31e8=null;if(_0x2455b6['status']>=0xc8&&_0x2455b6['status']<0x12c){try{_0x4e31e8=Nt(_0x2455b6['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5e119e+':\x20'+_0x2455b6['responseText']);}_0x367524(null,_0x4e31e8);}else _0x2455b6['status']!==0x191&&_0x2455b6['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5e119e+'\x20Status:\x20'+_0x2455b6['status']),_0x367524(_0x2455b6['status']);_0x367524=null;}},_0x2455b6['open']('GET',_0x5e119e,!0x0),_0x2455b6['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4f042b){return this['rootNode_']['getChild'](_0x4f042b);}['updateSnapshot'](_0x2b9ae3,_0x2ad92d){this['rootNode_']=this['rootNode_']['updateChild'](_0x2b9ae3,_0x2ad92d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x784f4f,_0x2b9a06,_0x4ceed0){if(v(_0x2b9a06))_0x784f4f['value']=_0x4ceed0,_0x784f4f['children']['clear']();else{if(_0x784f4f['value']!==null)_0x784f4f['value']=_0x784f4f['value']['updateChild'](_0x2b9a06,_0x4ceed0);else{const _0x2f58de=y(_0x2b9a06);_0x784f4f['children']['has'](_0x2f58de)||_0x784f4f['children']['set'](_0x2f58de,En());const _0x5d548c=_0x784f4f['children']['get'](_0x2f58de);_0x2b9a06=S(_0x2b9a06),pt(_0x5d548c,_0x2b9a06,_0x4ceed0);}}}function Ti(_0x247af9,_0x2c36b6){if(v(_0x2c36b6))return _0x247af9['value']=null,_0x247af9['children']['clear'](),!0x0;if(_0x247af9['value']!==null){if(_0x247af9['value']['isLeafNode']())return!0x1;{const _0x1df845=_0x247af9['value'];return _0x247af9['value']=null,_0x1df845['forEachChild'](R,(_0x1b19a2,_0x1ce689)=>{pt(_0x247af9,new C(_0x1b19a2),_0x1ce689);}),Ti(_0x247af9,_0x2c36b6);}}else{if(_0x247af9['children']['size']>0x0){const _0x4d7a06=y(_0x2c36b6);return _0x2c36b6=S(_0x2c36b6),_0x247af9['children']['has'](_0x4d7a06)&&Ti(_0x247af9['children']['get'](_0x4d7a06),_0x2c36b6)&&_0x247af9['children']['delete'](_0x4d7a06),_0x247af9['children']['size']===0x0;}else return!0x0;}}function Si(_0x1b1ce3,_0x512385,_0x1b28fa){_0x1b1ce3['value']!==null?_0x1b28fa(_0x512385,_0x1b1ce3['value']):Zh(_0x1b1ce3,(_0x3cb028,_0x1fb8c4)=>{const _0x53993a=new C(_0x512385['toString']()+'/'+_0x3cb028);Si(_0x1fb8c4,_0x53993a,_0x1b28fa);});}function Zh(_0x42c383,_0x2d839a){_0x42c383['children']['forEach']((_0x5c7acd,_0x4280c2)=>{_0x2d839a(_0x4280c2,_0x5c7acd);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x108ada){this['collection_']=_0x108ada,this['last_']=null;}['get'](){const _0x3c9c2d=this['collection_']['get'](),_0x501642={..._0x3c9c2d};return this['last_']&&x(this['last_'],(_0x1f4d4f,_0x1dc0e6)=>{_0x501642[_0x1f4d4f]=_0x501642[_0x1f4d4f]-_0x1dc0e6;}),this['last_']=_0x3c9c2d,_0x501642;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x30b6e0,_0x495daf){this['server_']=_0x495daf,this['statsToReport_']={},this['statsListener_']=new eu(_0x30b6e0);const _0x204ff1=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x204ff1));}['reportStats_'](){const _0x2f62b3=this['statsListener_']['get'](),_0x3ae338={};let _0x553285=!0x1;x(_0x2f62b3,(_0x518db0,_0x3bd966)=>{_0x3bd966>0x0&&Q(this['statsToReport_'],_0x518db0)&&(_0x3ae338[_0x518db0]=_0x3bd966,_0x553285=!0x0);}),_0x553285&&this['server_']['reportStats'](_0x3ae338),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x289562){_0x289562[_0x289562['OVERWRITE']=0x0]='OVERWRITE',_0x289562[_0x289562['MERGE']=0x1]='MERGE',_0x289562[_0x289562['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x289562[_0x289562['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4f75d3){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4f75d3,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x59cb2a,_0x5077eb,_0x1a3118){this['path']=_0x59cb2a,this['affectedTree']=_0x5077eb,this['revert']=_0x1a3118,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x55b9a2){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3ea98d=this['affectedTree']['subtree'](new C(_0x55b9a2));return new In(w(),_0x3ea98d,this['revert']);}}else return f(y(this['path'])===_0x55b9a2,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x446c24,_0x249048){this['source']=_0x446c24,this['path']=_0x249048,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4e4376){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x5be3b3,_0x32ef4f,_0x5654a6){this['source']=_0x5be3b3,this['path']=_0x32ef4f,this['snap']=_0x5654a6,this['type']=z['OVERWRITE'];}['operationForChild'](_0x230049){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x230049)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4bcc69,_0xc96eb,_0x5343ce){this['source']=_0x4bcc69,this['path']=_0xc96eb,this['children']=_0x5343ce,this['type']=z['MERGE'];}['operationForChild'](_0x222231){if(v(this['path'])){const _0x43b469=this['children']['subtree'](new C(_0x222231));return _0x43b469['isEmpty']()?null:_0x43b469['value']?new Be(this['source'],w(),_0x43b469['value']):new ot(this['source'],w(),_0x43b469);}else return f(y(this['path'])===_0x222231,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x382d75,_0xcc882f,_0x69c200){this['node_']=_0x382d75,this['fullyInitialized_']=_0xcc882f,this['filtered_']=_0x69c200;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x576638){if(v(_0x576638))return this['isFullyInitialized']()&&!this['filtered_'];const _0x124edc=y(_0x576638);return this['isCompleteForChild'](_0x124edc);}['isCompleteForChild'](_0x327811){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x327811);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x274d73){this['query_']=_0x274d73,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xfe6768,_0x46c24b,_0x57d5b6,_0x2c47f0){const _0x23e2a5=[],_0xd7e2c9=[];return _0x46c24b['forEach'](_0xdcd891=>{_0xdcd891['type']==='child_changed'&&_0xfe6768['index_']['indexedValueChanged'](_0xdcd891['oldSnap'],_0xdcd891['snapshotNode'])&&_0xd7e2c9['push'](zh(_0xdcd891['childName'],_0xdcd891['snapshotNode']));}),wt(_0xfe6768,_0x23e2a5,'child_removed',_0x46c24b,_0x2c47f0,_0x57d5b6),wt(_0xfe6768,_0x23e2a5,'child_added',_0x46c24b,_0x2c47f0,_0x57d5b6),wt(_0xfe6768,_0x23e2a5,'child_moved',_0xd7e2c9,_0x2c47f0,_0x57d5b6),wt(_0xfe6768,_0x23e2a5,'child_changed',_0x46c24b,_0x2c47f0,_0x57d5b6),wt(_0xfe6768,_0x23e2a5,'value',_0x46c24b,_0x2c47f0,_0x57d5b6),_0x23e2a5;}function wt(_0x151c74,_0x18a104,_0x271694,_0x709647,_0x17925d,_0x59acd9){const _0x208963=_0x709647['filter'](_0x12c9ad=>_0x12c9ad['type']===_0x271694);_0x208963['sort']((_0x5eba67,_0x255fb5)=>au(_0x151c74,_0x5eba67,_0x255fb5)),_0x208963['forEach'](_0x34196a=>{const _0xd0d399=ou(_0x151c74,_0x34196a,_0x59acd9);_0x17925d['forEach'](_0x4aec33=>{_0x4aec33['respondsTo'](_0x34196a['type'])&&_0x18a104['push'](_0x4aec33['createEvent'](_0xd0d399,_0x151c74['query_']));});});}function ou(_0x143042,_0x55bc27,_0x170f96){return _0x55bc27['type']==='value'||_0x55bc27['type']==='child_removed'||(_0x55bc27['prevName']=_0x170f96['getPredecessorChildName'](_0x55bc27['childName'],_0x55bc27['snapshotNode'],_0x143042['index_'])),_0x55bc27;}function au(_0x503e55,_0xa5443e,_0x3f7220){if(_0xa5443e['childName']==null||_0x3f7220['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x14b1eb=new E(_0xa5443e['childName'],_0xa5443e['snapshotNode']),_0x1d9bf6=new E(_0x3f7220['childName'],_0x3f7220['snapshotNode']);return _0x503e55['index_']['compare'](_0x14b1eb,_0x1d9bf6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x22d2df,_0x851ff8){return{'eventCache':_0x22d2df,'serverCache':_0x851ff8};}function Rt(_0x1b35e0,_0x5a5f60,_0x23e2e7,_0x57d656){return Un(new Te(_0x5a5f60,_0x23e2e7,_0x57d656),_0x1b35e0['serverCache']);}function Fo(_0x1daf1c,_0x2ee966,_0x46a411,_0x43d991){return Un(_0x1daf1c['eventCache'],new Te(_0x2ee966,_0x46a411,_0x43d991));}function wn(_0x25184f){return _0x25184f['eventCache']['isFullyInitialized']()?_0x25184f['eventCache']['getNode']():null;}function Ve(_0x4e8e5b){return _0x4e8e5b['serverCache']['isFullyInitialized']()?_0x4e8e5b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x5be472){let _0x284573=new b(null);return x(_0x5be472,(_0x443e2b,_0x210c7c)=>{_0x284573=_0x284573['set'](new C(_0x443e2b),_0x210c7c);}),_0x284573;}constructor(_0x4872b4,_0x20b216=cu()){this['value']=_0x4872b4,this['children']=_0x20b216;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3aaf20,_0x4812e6){if(this['value']!=null&&_0x4812e6(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3aaf20))return null;{const _0x3a0720=y(_0x3aaf20),_0x505645=this['children']['get'](_0x3a0720);if(_0x505645!==null){const _0x42cbc0=_0x505645['findRootMostMatchingPathAndValue'](S(_0x3aaf20),_0x4812e6);return _0x42cbc0!=null?{'path':k(new C(_0x3a0720),_0x42cbc0['path']),'value':_0x42cbc0['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3bcbd3){return this['findRootMostMatchingPathAndValue'](_0x3bcbd3,()=>!0x0);}['subtree'](_0x3939c3){if(v(_0x3939c3))return this;{const _0x262b37=y(_0x3939c3),_0xef10d3=this['children']['get'](_0x262b37);return _0xef10d3!==null?_0xef10d3['subtree'](S(_0x3939c3)):new b(null);}}['set'](_0x17651d,_0x57f9ab){if(v(_0x17651d))return new b(_0x57f9ab,this['children']);{const _0x1ecb57=y(_0x17651d),_0x1c47d0=(this['children']['get'](_0x1ecb57)||new b(null))['set'](S(_0x17651d),_0x57f9ab),_0x15b115=this['children']['insert'](_0x1ecb57,_0x1c47d0);return new b(this['value'],_0x15b115);}}['remove'](_0x5bc25a){if(v(_0x5bc25a))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x3c8970=y(_0x5bc25a),_0x41a6eb=this['children']['get'](_0x3c8970);if(_0x41a6eb){const _0x1a9eef=_0x41a6eb['remove'](S(_0x5bc25a));let _0x22d8b9;return _0x1a9eef['isEmpty']()?_0x22d8b9=this['children']['remove'](_0x3c8970):_0x22d8b9=this['children']['insert'](_0x3c8970,_0x1a9eef),this['value']===null&&_0x22d8b9['isEmpty']()?new b(null):new b(this['value'],_0x22d8b9);}else return this;}}['get'](_0x57cdcf){if(v(_0x57cdcf))return this['value'];{const _0x17765a=y(_0x57cdcf),_0x1f9d85=this['children']['get'](_0x17765a);return _0x1f9d85?_0x1f9d85['get'](S(_0x57cdcf)):null;}}['setTree'](_0x3a9759,_0x2f54a5){if(v(_0x3a9759))return _0x2f54a5;{const _0x2a8a3c=y(_0x3a9759),_0x1b3fc2=(this['children']['get'](_0x2a8a3c)||new b(null))['setTree'](S(_0x3a9759),_0x2f54a5);let _0x42694c;return _0x1b3fc2['isEmpty']()?_0x42694c=this['children']['remove'](_0x2a8a3c):_0x42694c=this['children']['insert'](_0x2a8a3c,_0x1b3fc2),new b(this['value'],_0x42694c);}}['fold'](_0x3f3df0){return this['fold_'](w(),_0x3f3df0);}['fold_'](_0x4546f2,_0x850b90){const _0x34079e={};return this['children']['inorderTraversal']((_0x452c45,_0x5a55b4)=>{_0x34079e[_0x452c45]=_0x5a55b4['fold_'](k(_0x4546f2,_0x452c45),_0x850b90);}),_0x850b90(_0x4546f2,this['value'],_0x34079e);}['findOnPath'](_0x24a874,_0x52a0e1){return this['findOnPath_'](_0x24a874,w(),_0x52a0e1);}['findOnPath_'](_0x23ac14,_0x592f97,_0x5c57a5){const _0x1d6406=this['value']?_0x5c57a5(_0x592f97,this['value']):!0x1;if(_0x1d6406)return _0x1d6406;if(v(_0x23ac14))return null;{const _0x38a483=y(_0x23ac14),_0x34b1f3=this['children']['get'](_0x38a483);return _0x34b1f3?_0x34b1f3['findOnPath_'](S(_0x23ac14),k(_0x592f97,_0x38a483),_0x5c57a5):null;}}['foreachOnPath'](_0x5beb16,_0x4c0a21){return this['foreachOnPath_'](_0x5beb16,w(),_0x4c0a21);}['foreachOnPath_'](_0x4f20d6,_0x2b6411,_0x93946b){if(v(_0x4f20d6))return this;{this['value']&&_0x93946b(_0x2b6411,this['value']);const _0x136177=y(_0x4f20d6),_0xeeb28c=this['children']['get'](_0x136177);return _0xeeb28c?_0xeeb28c['foreachOnPath_'](S(_0x4f20d6),k(_0x2b6411,_0x136177),_0x93946b):new b(null);}}['foreach'](_0x9d547a){this['foreach_'](w(),_0x9d547a);}['foreach_'](_0x57061e,_0x2331cb){this['children']['inorderTraversal']((_0x28911f,_0x2af002)=>{_0x2af002['foreach_'](k(_0x57061e,_0x28911f),_0x2331cb);}),this['value']&&_0x2331cb(_0x57061e,this['value']);}['foreachChild'](_0x4e3bfe){this['children']['inorderTraversal']((_0x43544a,_0x52db62)=>{_0x52db62['value']&&_0x4e3bfe(_0x43544a,_0x52db62['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4704c2){this['writeTree_']=_0x4704c2;}static['empty'](){return new K(new b(null));}}function At(_0x4bd30f,_0x59d9b4,_0xade497){if(v(_0x59d9b4))return new K(new b(_0xade497));{const _0xe694b7=_0x4bd30f['writeTree_']['findRootMostValueAndPath'](_0x59d9b4);if(_0xe694b7!=null){const _0x2bfd2e=_0xe694b7['path'];let _0x385d48=_0xe694b7['value'];const _0x35add9=F(_0x2bfd2e,_0x59d9b4);return _0x385d48=_0x385d48['updateChild'](_0x35add9,_0xade497),new K(_0x4bd30f['writeTree_']['set'](_0x2bfd2e,_0x385d48));}else{const _0x418681=new b(_0xade497),_0x112dcd=_0x4bd30f['writeTree_']['setTree'](_0x59d9b4,_0x418681);return new K(_0x112dcd);}}}function bi(_0x3be1b2,_0x40d47b,_0x3d127b){let _0x5e3444=_0x3be1b2;return x(_0x3d127b,(_0x306b8c,_0x2c054b)=>{_0x5e3444=At(_0x5e3444,k(_0x40d47b,_0x306b8c),_0x2c054b);}),_0x5e3444;}function or(_0x103d99,_0x5749c){if(v(_0x5749c))return K['empty']();{const _0x371753=_0x103d99['writeTree_']['setTree'](_0x5749c,new b(null));return new K(_0x371753);}}function Ri(_0x3ca536,_0x21a6a4){return ze(_0x3ca536,_0x21a6a4)!=null;}function ze(_0x113f58,_0x4882de){const _0x2eb769=_0x113f58['writeTree_']['findRootMostValueAndPath'](_0x4882de);return _0x2eb769!=null?_0x113f58['writeTree_']['get'](_0x2eb769['path'])['getChild'](F(_0x2eb769['path'],_0x4882de)):null;}function ar(_0x4d0e05){const _0x3b9cab=[],_0x2c407f=_0x4d0e05['writeTree_']['value'];return _0x2c407f!=null?_0x2c407f['isLeafNode']()||_0x2c407f['forEachChild'](R,(_0x32a830,_0x574fda)=>{_0x3b9cab['push'](new E(_0x32a830,_0x574fda));}):_0x4d0e05['writeTree_']['children']['inorderTraversal']((_0x551d41,_0x46bc2e)=>{_0x46bc2e['value']!=null&&_0x3b9cab['push'](new E(_0x551d41,_0x46bc2e['value']));}),_0x3b9cab;}function Ee(_0x2d961c,_0x5c4d67){if(v(_0x5c4d67))return _0x2d961c;{const _0x37abe1=ze(_0x2d961c,_0x5c4d67);return _0x37abe1!=null?new K(new b(_0x37abe1)):new K(_0x2d961c['writeTree_']['subtree'](_0x5c4d67));}}function Ai(_0x223701){return _0x223701['writeTree_']['isEmpty']();}function at(_0x303b93,_0x360efa){return Uo(w(),_0x303b93['writeTree_'],_0x360efa);}function Uo(_0x163556,_0xf3019f,_0x34b09c){if(_0xf3019f['value']!=null)return _0x34b09c['updateChild'](_0x163556,_0xf3019f['value']);{let _0xa426aa=null;return _0xf3019f['children']['inorderTraversal']((_0x339f60,_0x2920f5)=>{_0x339f60==='.priority'?(f(_0x2920f5['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xa426aa=_0x2920f5['value']):_0x34b09c=Uo(k(_0x163556,_0x339f60),_0x2920f5,_0x34b09c);}),!_0x34b09c['getChild'](_0x163556)['isEmpty']()&&_0xa426aa!==null&&(_0x34b09c=_0x34b09c['updateChild'](k(_0x163556,'.priority'),_0xa426aa)),_0x34b09c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x52b48e,_0x3f535f){return Ho(_0x3f535f,_0x52b48e);}function lu(_0x1876c8,_0x66e772,_0x52d654,_0x3bd008,_0x2cb4c9){f(_0x3bd008>_0x1876c8['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2cb4c9===void 0x0&&(_0x2cb4c9=!0x0),_0x1876c8['allWrites']['push']({'path':_0x66e772,'snap':_0x52d654,'writeId':_0x3bd008,'visible':_0x2cb4c9}),_0x2cb4c9&&(_0x1876c8['visibleWrites']=At(_0x1876c8['visibleWrites'],_0x66e772,_0x52d654)),_0x1876c8['lastWriteId']=_0x3bd008;}function hu(_0x1b8b56,_0x4d9593,_0x33a6b3,_0x3a2ad4){f(_0x3a2ad4>_0x1b8b56['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1b8b56['allWrites']['push']({'path':_0x4d9593,'children':_0x33a6b3,'writeId':_0x3a2ad4,'visible':!0x0}),_0x1b8b56['visibleWrites']=bi(_0x1b8b56['visibleWrites'],_0x4d9593,_0x33a6b3),_0x1b8b56['lastWriteId']=_0x3a2ad4;}function uu(_0x529b71,_0x3a448e){for(let _0x2f2fcc=0x0;_0x2f2fcc<_0x529b71['allWrites']['length'];_0x2f2fcc++){const _0x4f2832=_0x529b71['allWrites'][_0x2f2fcc];if(_0x4f2832['writeId']===_0x3a448e)return _0x4f2832;}return null;}function du(_0x43e50a,_0x56f750){const _0x540e3c=_0x43e50a['allWrites']['findIndex'](_0x53f3bc=>_0x53f3bc['writeId']===_0x56f750);f(_0x540e3c>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xc36e8=_0x43e50a['allWrites'][_0x540e3c];_0x43e50a['allWrites']['splice'](_0x540e3c,0x1);let _0x2de460=_0xc36e8['visible'],_0x2799c3=!0x1,_0x350024=_0x43e50a['allWrites']['length']-0x1;for(;_0x2de460&&_0x350024>=0x0;){const _0x47c98a=_0x43e50a['allWrites'][_0x350024];_0x47c98a['visible']&&(_0x350024>=_0x540e3c&&fu(_0x47c98a,_0xc36e8['path'])?_0x2de460=!0x1:G(_0xc36e8['path'],_0x47c98a['path'])&&(_0x2799c3=!0x0)),_0x350024--;}if(_0x2de460){if(_0x2799c3)return pu(_0x43e50a),!0x0;if(_0xc36e8['snap'])_0x43e50a['visibleWrites']=or(_0x43e50a['visibleWrites'],_0xc36e8['path']);else{const _0xe66127=_0xc36e8['children'];x(_0xe66127,_0x3d4d07=>{_0x43e50a['visibleWrites']=or(_0x43e50a['visibleWrites'],k(_0xc36e8['path'],_0x3d4d07));});}return!0x0;}else return!0x1;}function fu(_0x215c9f,_0x4b1686){if(_0x215c9f['snap'])return G(_0x215c9f['path'],_0x4b1686);for(const _0x1e57d6 in _0x215c9f['children'])if(_0x215c9f['children']['hasOwnProperty'](_0x1e57d6)&&G(k(_0x215c9f['path'],_0x1e57d6),_0x4b1686))return!0x0;return!0x1;}function pu(_0x3d6d19){_0x3d6d19['visibleWrites']=Wo(_0x3d6d19['allWrites'],_u,w()),_0x3d6d19['allWrites']['length']>0x0?_0x3d6d19['lastWriteId']=_0x3d6d19['allWrites'][_0x3d6d19['allWrites']['length']-0x1]['writeId']:_0x3d6d19['lastWriteId']=-0x1;}function _u(_0x1b5bac){return _0x1b5bac['visible'];}function Wo(_0x5e3eae,_0x89fe85,_0x362126){let _0x190e04=K['empty']();for(let _0x2c7746=0x0;_0x2c7746<_0x5e3eae['length'];++_0x2c7746){const _0x1dbcc6=_0x5e3eae[_0x2c7746];if(_0x89fe85(_0x1dbcc6)){const _0x12fda9=_0x1dbcc6['path'];let _0x21de0c;if(_0x1dbcc6['snap'])G(_0x362126,_0x12fda9)?(_0x21de0c=F(_0x362126,_0x12fda9),_0x190e04=At(_0x190e04,_0x21de0c,_0x1dbcc6['snap'])):G(_0x12fda9,_0x362126)&&(_0x21de0c=F(_0x12fda9,_0x362126),_0x190e04=At(_0x190e04,w(),_0x1dbcc6['snap']['getChild'](_0x21de0c)));else{if(_0x1dbcc6['children']){if(G(_0x362126,_0x12fda9))_0x21de0c=F(_0x362126,_0x12fda9),_0x190e04=bi(_0x190e04,_0x21de0c,_0x1dbcc6['children']);else{if(G(_0x12fda9,_0x362126)){if(_0x21de0c=F(_0x12fda9,_0x362126),v(_0x21de0c))_0x190e04=bi(_0x190e04,w(),_0x1dbcc6['children']);else{const _0xfa0f20=Le(_0x1dbcc6['children'],y(_0x21de0c));if(_0xfa0f20){const _0x44a912=_0xfa0f20['getChild'](S(_0x21de0c));_0x190e04=At(_0x190e04,w(),_0x44a912);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x190e04;}function Bo(_0x5b49c4,_0x12445b,_0xb6be10,_0x2341ba,_0x57459b){if(!_0x2341ba&&!_0x57459b){const _0xf24d71=ze(_0x5b49c4['visibleWrites'],_0x12445b);if(_0xf24d71!=null)return _0xf24d71;{const _0x315ffd=Ee(_0x5b49c4['visibleWrites'],_0x12445b);if(Ai(_0x315ffd))return _0xb6be10;if(_0xb6be10==null&&!Ri(_0x315ffd,w()))return null;{const _0xfe12d3=_0xb6be10||g['EMPTY_NODE'];return at(_0x315ffd,_0xfe12d3);}}}else{const _0x3f333c=Ee(_0x5b49c4['visibleWrites'],_0x12445b);if(!_0x57459b&&Ai(_0x3f333c))return _0xb6be10;if(!_0x57459b&&_0xb6be10==null&&!Ri(_0x3f333c,w()))return null;{const _0x3bdb9b=function(_0x1d308a){return(_0x1d308a['visible']||_0x57459b)&&(!_0x2341ba||!~_0x2341ba['indexOf'](_0x1d308a['writeId']))&&(G(_0x1d308a['path'],_0x12445b)||G(_0x12445b,_0x1d308a['path']));},_0x186116=Wo(_0x5b49c4['allWrites'],_0x3bdb9b,_0x12445b),_0x1b05e2=_0xb6be10||g['EMPTY_NODE'];return at(_0x186116,_0x1b05e2);}}}function gu(_0x242e72,_0x6bf351,_0x5560b9){let _0x916bb4=g['EMPTY_NODE'];const _0x40a044=ze(_0x242e72['visibleWrites'],_0x6bf351);if(_0x40a044)return _0x40a044['isLeafNode']()||_0x40a044['forEachChild'](R,(_0x8161ab,_0x2b048a)=>{_0x916bb4=_0x916bb4['updateImmediateChild'](_0x8161ab,_0x2b048a);}),_0x916bb4;if(_0x5560b9){const _0x2a7859=Ee(_0x242e72['visibleWrites'],_0x6bf351);return _0x5560b9['forEachChild'](R,(_0x5bfb33,_0x30b3b8)=>{const _0x38794e=at(Ee(_0x2a7859,new C(_0x5bfb33)),_0x30b3b8);_0x916bb4=_0x916bb4['updateImmediateChild'](_0x5bfb33,_0x38794e);}),ar(_0x2a7859)['forEach'](_0x4f9436=>{_0x916bb4=_0x916bb4['updateImmediateChild'](_0x4f9436['name'],_0x4f9436['node']);}),_0x916bb4;}else{const _0x2b6351=Ee(_0x242e72['visibleWrites'],_0x6bf351);return ar(_0x2b6351)['forEach'](_0x184a9a=>{_0x916bb4=_0x916bb4['updateImmediateChild'](_0x184a9a['name'],_0x184a9a['node']);}),_0x916bb4;}}function mu(_0x27b4d0,_0x49d333,_0x33ba17,_0x3317e1,_0x4b6ec7){f(_0x3317e1||_0x4b6ec7,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x369907=k(_0x49d333,_0x33ba17);if(Ri(_0x27b4d0['visibleWrites'],_0x369907))return null;{const _0x2663a2=Ee(_0x27b4d0['visibleWrites'],_0x369907);return Ai(_0x2663a2)?_0x4b6ec7['getChild'](_0x33ba17):at(_0x2663a2,_0x4b6ec7['getChild'](_0x33ba17));}}function yu(_0x5ecd4d,_0x597aef,_0x36d759,_0x2cef12){const _0xa5a48f=k(_0x597aef,_0x36d759),_0x5db0be=ze(_0x5ecd4d['visibleWrites'],_0xa5a48f);if(_0x5db0be!=null)return _0x5db0be;if(_0x2cef12['isCompleteForChild'](_0x36d759)){const _0x5f3d02=Ee(_0x5ecd4d['visibleWrites'],_0xa5a48f);return at(_0x5f3d02,_0x2cef12['getNode']()['getImmediateChild'](_0x36d759));}else return null;}function vu(_0x163d6a,_0x4670f2){return ze(_0x163d6a['visibleWrites'],_0x4670f2);}function Eu(_0x3ad499,_0x25e310,_0x11a703,_0x32d3a7,_0x153119,_0x30ee2b,_0x1b9c29){let _0x5b090b;const _0x13f5c1=Ee(_0x3ad499['visibleWrites'],_0x25e310),_0x3ed7e7=ze(_0x13f5c1,w());if(_0x3ed7e7!=null)_0x5b090b=_0x3ed7e7;else{if(_0x11a703!=null)_0x5b090b=at(_0x13f5c1,_0x11a703);else return[];}if(_0x5b090b=_0x5b090b['withIndex'](_0x1b9c29),!_0x5b090b['isEmpty']()&&!_0x5b090b['isLeafNode']()){const _0x5ab1a1=[],_0x51aad7=_0x1b9c29['getCompare'](),_0x21c3f5=_0x30ee2b?_0x5b090b['getReverseIteratorFrom'](_0x32d3a7,_0x1b9c29):_0x5b090b['getIteratorFrom'](_0x32d3a7,_0x1b9c29);let _0x239c5d=_0x21c3f5['getNext']();for(;_0x239c5d&&_0x5ab1a1['length']<_0x153119;)_0x51aad7(_0x239c5d,_0x32d3a7)!==0x0&&_0x5ab1a1['push'](_0x239c5d),_0x239c5d=_0x21c3f5['getNext']();return _0x5ab1a1;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x1b2685,_0x56852a,_0x235af5,_0x1d6879){return Bo(_0x1b2685['writeTree'],_0x1b2685['treePath'],_0x56852a,_0x235af5,_0x1d6879);}function is(_0x4c770b,_0xd8ecc){return gu(_0x4c770b['writeTree'],_0x4c770b['treePath'],_0xd8ecc);}function cr(_0x4a242e,_0x46afcc,_0x209606,_0x5a624b){return mu(_0x4a242e['writeTree'],_0x4a242e['treePath'],_0x46afcc,_0x209606,_0x5a624b);}function Tn(_0x11cfeb,_0x1c2aad){return vu(_0x11cfeb['writeTree'],k(_0x11cfeb['treePath'],_0x1c2aad));}function wu(_0x3145ee,_0x22a9cc,_0x1f029b,_0x22aa0a,_0x533068,_0xcdcc39){return Eu(_0x3145ee['writeTree'],_0x3145ee['treePath'],_0x22a9cc,_0x1f029b,_0x22aa0a,_0x533068,_0xcdcc39);}function ss(_0x316f21,_0x8a6915,_0x508626){return yu(_0x316f21['writeTree'],_0x316f21['treePath'],_0x8a6915,_0x508626);}function Vo(_0x211e23,_0x6a7e85){return Ho(k(_0x211e23['treePath'],_0x6a7e85),_0x211e23['writeTree']);}function Ho(_0x95c377,_0x2cd14b){return{'treePath':_0x95c377,'writeTree':_0x2cd14b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x256dd5){const _0x1604a8=_0x256dd5['type'],_0x1b2a8c=_0x256dd5['childName'];f(_0x1604a8==='child_added'||_0x1604a8==='child_changed'||_0x1604a8==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1b2a8c!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2cd713=this['changeMap']['get'](_0x1b2a8c);if(_0x2cd713){const _0x316826=_0x2cd713['type'];if(_0x1604a8==='child_added'&&_0x316826==='child_removed')this['changeMap']['set'](_0x1b2a8c,xt(_0x1b2a8c,_0x256dd5['snapshotNode'],_0x2cd713['snapshotNode']));else{if(_0x1604a8==='child_removed'&&_0x316826==='child_added')this['changeMap']['delete'](_0x1b2a8c);else{if(_0x1604a8==='child_removed'&&_0x316826==='child_changed')this['changeMap']['set'](_0x1b2a8c,Lt(_0x1b2a8c,_0x2cd713['oldSnap']));else{if(_0x1604a8==='child_changed'&&_0x316826==='child_added')this['changeMap']['set'](_0x1b2a8c,rt(_0x1b2a8c,_0x256dd5['snapshotNode']));else{if(_0x1604a8==='child_changed'&&_0x316826==='child_changed')this['changeMap']['set'](_0x1b2a8c,xt(_0x1b2a8c,_0x256dd5['snapshotNode'],_0x2cd713['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x256dd5+'\x20occurred\x20after\x20'+_0x2cd713);}}}}}else this['changeMap']['set'](_0x1b2a8c,_0x256dd5);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x405a50){return null;}['getChildAfterChild'](_0x331f10,_0x2a14f4,_0x3c2073){return null;}}const $o=new Tu();class rs{constructor(_0x39af9f,_0x3332e9,_0x1a4865=null){this['writes_']=_0x39af9f,this['viewCache_']=_0x3332e9,this['optCompleteServerCache_']=_0x1a4865;}['getCompleteChild'](_0x3fd04a){const _0x4aef86=this['viewCache_']['eventCache'];if(_0x4aef86['isCompleteForChild'](_0x3fd04a))return _0x4aef86['getNode']()['getImmediateChild'](_0x3fd04a);{const _0xf3cb19=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x3fd04a,_0xf3cb19);}}['getChildAfterChild'](_0x5cc99f,_0x17b596,_0x4b31ff){const _0x2fd2b4=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x258450=wu(this['writes_'],_0x2fd2b4,_0x17b596,0x1,_0x4b31ff,_0x5cc99f);return _0x258450['length']===0x0?null:_0x258450[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4c499f){return{'filter':_0x4c499f};}function bu(_0x53f09d,_0x3b2999){f(_0x3b2999['eventCache']['getNode']()['isIndexed'](_0x53f09d['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3b2999['serverCache']['getNode']()['isIndexed'](_0x53f09d['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x5e0040,_0x33a2f7,_0x2576fc,_0x133a7a,_0x5ea7f0){const _0x52668f=new Cu();let _0x18ae99,_0x215ffd;if(_0x2576fc['type']===z['OVERWRITE']){const _0x2fbce9=_0x2576fc;_0x2fbce9['source']['fromUser']?_0x18ae99=ki(_0x5e0040,_0x33a2f7,_0x2fbce9['path'],_0x2fbce9['snap'],_0x133a7a,_0x5ea7f0,_0x52668f):(f(_0x2fbce9['source']['fromServer'],'Unknown\x20source.'),_0x215ffd=_0x2fbce9['source']['tagged']||_0x33a2f7['serverCache']['isFiltered']()&&!v(_0x2fbce9['path']),_0x18ae99=Sn(_0x5e0040,_0x33a2f7,_0x2fbce9['path'],_0x2fbce9['snap'],_0x133a7a,_0x5ea7f0,_0x215ffd,_0x52668f));}else{if(_0x2576fc['type']===z['MERGE']){const _0x4bfd45=_0x2576fc;_0x4bfd45['source']['fromUser']?_0x18ae99=ku(_0x5e0040,_0x33a2f7,_0x4bfd45['path'],_0x4bfd45['children'],_0x133a7a,_0x5ea7f0,_0x52668f):(f(_0x4bfd45['source']['fromServer'],'Unknown\x20source.'),_0x215ffd=_0x4bfd45['source']['tagged']||_0x33a2f7['serverCache']['isFiltered'](),_0x18ae99=Pi(_0x5e0040,_0x33a2f7,_0x4bfd45['path'],_0x4bfd45['children'],_0x133a7a,_0x5ea7f0,_0x215ffd,_0x52668f));}else{if(_0x2576fc['type']===z['ACK_USER_WRITE']){const _0x5e6f7f=_0x2576fc;_0x5e6f7f['revert']?_0x18ae99=Ou(_0x5e0040,_0x33a2f7,_0x5e6f7f['path'],_0x133a7a,_0x5ea7f0,_0x52668f):_0x18ae99=Pu(_0x5e0040,_0x33a2f7,_0x5e6f7f['path'],_0x5e6f7f['affectedTree'],_0x133a7a,_0x5ea7f0,_0x52668f);}else{if(_0x2576fc['type']===z['LISTEN_COMPLETE'])_0x18ae99=Nu(_0x5e0040,_0x33a2f7,_0x2576fc['path'],_0x133a7a,_0x52668f);else throw ht('Unknown\x20operation\x20type:\x20'+_0x2576fc['type']);}}}const _0xf1fcdd=_0x52668f['getChanges']();return Au(_0x33a2f7,_0x18ae99,_0xf1fcdd),{'viewCache':_0x18ae99,'changes':_0xf1fcdd};}function Au(_0x340bbd,_0x5b7247,_0x4ac762){const _0x4a490d=_0x5b7247['eventCache'];if(_0x4a490d['isFullyInitialized']()){const _0x3f0cd2=_0x4a490d['getNode']()['isLeafNode']()||_0x4a490d['getNode']()['isEmpty'](),_0xae4ed4=wn(_0x340bbd);(_0x4ac762['length']>0x0||!_0x340bbd['eventCache']['isFullyInitialized']()||_0x3f0cd2&&!_0x4a490d['getNode']()['equals'](_0xae4ed4)||!_0x4a490d['getNode']()['getPriority']()['equals'](_0xae4ed4['getPriority']()))&&_0x4ac762['push'](Lo(wn(_0x5b7247)));}}function Go(_0x363b35,_0x4c7069,_0x845575,_0x575fac,_0x2554be,_0x11ddc0){const _0x7529e8=_0x4c7069['eventCache'];if(Tn(_0x575fac,_0x845575)!=null)return _0x4c7069;{let _0x4f1c66,_0x5aafe1;if(v(_0x845575)){if(f(_0x4c7069['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4c7069['serverCache']['isFiltered']()){const _0x4b483f=Ve(_0x4c7069),_0x26cf8c=_0x4b483f instanceof g?_0x4b483f:g['EMPTY_NODE'],_0x500cdd=is(_0x575fac,_0x26cf8c);_0x4f1c66=_0x363b35['filter']['updateFullNode'](_0x4c7069['eventCache']['getNode'](),_0x500cdd,_0x11ddc0);}else{const _0x3d0258=Cn(_0x575fac,Ve(_0x4c7069));_0x4f1c66=_0x363b35['filter']['updateFullNode'](_0x4c7069['eventCache']['getNode'](),_0x3d0258,_0x11ddc0);}}else{const _0x34db36=y(_0x845575);if(_0x34db36==='.priority'){f(Ce(_0x845575)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4ccbce=_0x7529e8['getNode']();_0x5aafe1=_0x4c7069['serverCache']['getNode']();const _0x358bda=cr(_0x575fac,_0x845575,_0x4ccbce,_0x5aafe1);_0x358bda!=null?_0x4f1c66=_0x363b35['filter']['updatePriority'](_0x4ccbce,_0x358bda):_0x4f1c66=_0x7529e8['getNode']();}else{const _0x3b9d7e=S(_0x845575);let _0x5541fc;if(_0x7529e8['isCompleteForChild'](_0x34db36)){_0x5aafe1=_0x4c7069['serverCache']['getNode']();const _0x5441b3=cr(_0x575fac,_0x845575,_0x7529e8['getNode'](),_0x5aafe1);_0x5441b3!=null?_0x5541fc=_0x7529e8['getNode']()['getImmediateChild'](_0x34db36)['updateChild'](_0x3b9d7e,_0x5441b3):_0x5541fc=_0x7529e8['getNode']()['getImmediateChild'](_0x34db36);}else _0x5541fc=ss(_0x575fac,_0x34db36,_0x4c7069['serverCache']);_0x5541fc!=null?_0x4f1c66=_0x363b35['filter']['updateChild'](_0x7529e8['getNode'](),_0x34db36,_0x5541fc,_0x3b9d7e,_0x2554be,_0x11ddc0):_0x4f1c66=_0x7529e8['getNode']();}}return Rt(_0x4c7069,_0x4f1c66,_0x7529e8['isFullyInitialized']()||v(_0x845575),_0x363b35['filter']['filtersNodes']());}}function Sn(_0x3cc0df,_0x5fe31e,_0x301614,_0x1c83de,_0x5f810f,_0x596572,_0x32d443,_0x4d2612){const _0x5c72dd=_0x5fe31e['serverCache'];let _0x268b2b;const _0x43b4bd=_0x32d443?_0x3cc0df['filter']:_0x3cc0df['filter']['getIndexedFilter']();if(v(_0x301614))_0x268b2b=_0x43b4bd['updateFullNode'](_0x5c72dd['getNode'](),_0x1c83de,null);else{if(_0x43b4bd['filtersNodes']()&&!_0x5c72dd['isFiltered']()){const _0xc5dad8=_0x5c72dd['getNode']()['updateChild'](_0x301614,_0x1c83de);_0x268b2b=_0x43b4bd['updateFullNode'](_0x5c72dd['getNode'](),_0xc5dad8,null);}else{const _0x2c1173=y(_0x301614);if(!_0x5c72dd['isCompleteForPath'](_0x301614)&&Ce(_0x301614)>0x1)return _0x5fe31e;const _0x1e98b0=S(_0x301614),_0x2f309d=_0x5c72dd['getNode']()['getImmediateChild'](_0x2c1173)['updateChild'](_0x1e98b0,_0x1c83de);_0x2c1173==='.priority'?_0x268b2b=_0x43b4bd['updatePriority'](_0x5c72dd['getNode'](),_0x2f309d):_0x268b2b=_0x43b4bd['updateChild'](_0x5c72dd['getNode'](),_0x2c1173,_0x2f309d,_0x1e98b0,$o,null);}}const _0x4519d1=Fo(_0x5fe31e,_0x268b2b,_0x5c72dd['isFullyInitialized']()||v(_0x301614),_0x43b4bd['filtersNodes']()),_0x9d5cde=new rs(_0x5f810f,_0x4519d1,_0x596572);return Go(_0x3cc0df,_0x4519d1,_0x301614,_0x5f810f,_0x9d5cde,_0x4d2612);}function ki(_0x7f66fb,_0x30ad17,_0x4d9a73,_0x17fc0f,_0x47f5a0,_0x4d01f2,_0x562166){const _0x3f1d8c=_0x30ad17['eventCache'];let _0x19a5cb,_0x445174;const _0x497bb5=new rs(_0x47f5a0,_0x30ad17,_0x4d01f2);if(v(_0x4d9a73))_0x445174=_0x7f66fb['filter']['updateFullNode'](_0x30ad17['eventCache']['getNode'](),_0x17fc0f,_0x562166),_0x19a5cb=Rt(_0x30ad17,_0x445174,!0x0,_0x7f66fb['filter']['filtersNodes']());else{const _0xd04d1b=y(_0x4d9a73);if(_0xd04d1b==='.priority')_0x445174=_0x7f66fb['filter']['updatePriority'](_0x30ad17['eventCache']['getNode'](),_0x17fc0f),_0x19a5cb=Rt(_0x30ad17,_0x445174,_0x3f1d8c['isFullyInitialized'](),_0x3f1d8c['isFiltered']());else{const _0x61320c=S(_0x4d9a73),_0x517ef3=_0x3f1d8c['getNode']()['getImmediateChild'](_0xd04d1b);let _0x57d160;if(v(_0x61320c))_0x57d160=_0x17fc0f;else{const _0x363d1d=_0x497bb5['getCompleteChild'](_0xd04d1b);_0x363d1d!=null?ji(_0x61320c)==='.priority'&&_0x363d1d['getChild'](Ro(_0x61320c))['isEmpty']()?_0x57d160=_0x363d1d:_0x57d160=_0x363d1d['updateChild'](_0x61320c,_0x17fc0f):_0x57d160=g['EMPTY_NODE'];}if(_0x517ef3['equals'](_0x57d160))_0x19a5cb=_0x30ad17;else{const _0x54a821=_0x7f66fb['filter']['updateChild'](_0x3f1d8c['getNode'](),_0xd04d1b,_0x57d160,_0x61320c,_0x497bb5,_0x562166);_0x19a5cb=Rt(_0x30ad17,_0x54a821,_0x3f1d8c['isFullyInitialized'](),_0x7f66fb['filter']['filtersNodes']());}}}return _0x19a5cb;}function lr(_0x1f863a,_0x5881e2){return _0x1f863a['eventCache']['isCompleteForChild'](_0x5881e2);}function ku(_0xaaa956,_0x40f91f,_0x37cfea,_0x1b1a13,_0xbc711b,_0x5f1b36,_0x1be9e4){let _0x586f9f=_0x40f91f;return _0x1b1a13['foreach']((_0x122554,_0x5e4bf4)=>{const _0x4c4907=k(_0x37cfea,_0x122554);lr(_0x40f91f,y(_0x4c4907))&&(_0x586f9f=ki(_0xaaa956,_0x586f9f,_0x4c4907,_0x5e4bf4,_0xbc711b,_0x5f1b36,_0x1be9e4));}),_0x1b1a13['foreach']((_0x533a21,_0x1d58ae)=>{const _0x3c8531=k(_0x37cfea,_0x533a21);lr(_0x40f91f,y(_0x3c8531))||(_0x586f9f=ki(_0xaaa956,_0x586f9f,_0x3c8531,_0x1d58ae,_0xbc711b,_0x5f1b36,_0x1be9e4));}),_0x586f9f;}function hr(_0x206fda,_0x4f93b1,_0x205be7){return _0x205be7['foreach']((_0x1aa1ea,_0xc33735)=>{_0x4f93b1=_0x4f93b1['updateChild'](_0x1aa1ea,_0xc33735);}),_0x4f93b1;}function Pi(_0x18a54c,_0x2ac2e2,_0x21af44,_0x85fa25,_0xb41d9,_0x53e841,_0x3768ff,_0x1f53c3){if(_0x2ac2e2['serverCache']['getNode']()['isEmpty']()&&!_0x2ac2e2['serverCache']['isFullyInitialized']())return _0x2ac2e2;let _0x589336=_0x2ac2e2,_0x2f41a6;v(_0x21af44)?_0x2f41a6=_0x85fa25:_0x2f41a6=new b(null)['setTree'](_0x21af44,_0x85fa25);const _0xca8aaf=_0x2ac2e2['serverCache']['getNode']();return _0x2f41a6['children']['inorderTraversal']((_0x24d808,_0x1c2a25)=>{if(_0xca8aaf['hasChild'](_0x24d808)){const _0x2ff49d=_0x2ac2e2['serverCache']['getNode']()['getImmediateChild'](_0x24d808),_0x19a947=hr(_0x18a54c,_0x2ff49d,_0x1c2a25);_0x589336=Sn(_0x18a54c,_0x589336,new C(_0x24d808),_0x19a947,_0xb41d9,_0x53e841,_0x3768ff,_0x1f53c3);}}),_0x2f41a6['children']['inorderTraversal']((_0x4da8d5,_0x510b67)=>{const _0x56d3b=!_0x2ac2e2['serverCache']['isCompleteForChild'](_0x4da8d5)&&_0x510b67['value']===null;if(!_0xca8aaf['hasChild'](_0x4da8d5)&&!_0x56d3b){const _0x11a016=_0x2ac2e2['serverCache']['getNode']()['getImmediateChild'](_0x4da8d5),_0x10d139=hr(_0x18a54c,_0x11a016,_0x510b67);_0x589336=Sn(_0x18a54c,_0x589336,new C(_0x4da8d5),_0x10d139,_0xb41d9,_0x53e841,_0x3768ff,_0x1f53c3);}}),_0x589336;}function Pu(_0x108774,_0x3e092b,_0x34426d,_0xc84218,_0x513c4e,_0x2266f5,_0x44758a){if(Tn(_0x513c4e,_0x34426d)!=null)return _0x3e092b;const _0x42c843=_0x3e092b['serverCache']['isFiltered'](),_0xf804db=_0x3e092b['serverCache'];if(_0xc84218['value']!=null){if(v(_0x34426d)&&_0xf804db['isFullyInitialized']()||_0xf804db['isCompleteForPath'](_0x34426d))return Sn(_0x108774,_0x3e092b,_0x34426d,_0xf804db['getNode']()['getChild'](_0x34426d),_0x513c4e,_0x2266f5,_0x42c843,_0x44758a);if(v(_0x34426d)){let _0xed99fe=new b(null);return _0xf804db['getNode']()['forEachChild'](ve,(_0x22d683,_0x195daf)=>{_0xed99fe=_0xed99fe['set'](new C(_0x22d683),_0x195daf);}),Pi(_0x108774,_0x3e092b,_0x34426d,_0xed99fe,_0x513c4e,_0x2266f5,_0x42c843,_0x44758a);}else return _0x3e092b;}else{let _0x449412=new b(null);return _0xc84218['foreach']((_0x15a81d,_0x1c1597)=>{const _0x819567=k(_0x34426d,_0x15a81d);_0xf804db['isCompleteForPath'](_0x819567)&&(_0x449412=_0x449412['set'](_0x15a81d,_0xf804db['getNode']()['getChild'](_0x819567)));}),Pi(_0x108774,_0x3e092b,_0x34426d,_0x449412,_0x513c4e,_0x2266f5,_0x42c843,_0x44758a);}}function Nu(_0x1013a7,_0x16a792,_0xf1810d,_0x40ce21,_0x1cd09d){const _0x432587=_0x16a792['serverCache'],_0x192917=Fo(_0x16a792,_0x432587['getNode'](),_0x432587['isFullyInitialized']()||v(_0xf1810d),_0x432587['isFiltered']());return Go(_0x1013a7,_0x192917,_0xf1810d,_0x40ce21,$o,_0x1cd09d);}function Ou(_0x12440d,_0x4ef5d8,_0xfedca2,_0x40c80f,_0x15126f,_0x46a189){let _0x1ce5e5;if(Tn(_0x40c80f,_0xfedca2)!=null)return _0x4ef5d8;{const _0x231ac9=new rs(_0x40c80f,_0x4ef5d8,_0x15126f),_0x253f4f=_0x4ef5d8['eventCache']['getNode']();let _0x4143ea;if(v(_0xfedca2)||y(_0xfedca2)==='.priority'){let _0x1c28e4;if(_0x4ef5d8['serverCache']['isFullyInitialized']())_0x1c28e4=Cn(_0x40c80f,Ve(_0x4ef5d8));else{const _0x4b5979=_0x4ef5d8['serverCache']['getNode']();f(_0x4b5979 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1c28e4=is(_0x40c80f,_0x4b5979);}_0x1c28e4=_0x1c28e4,_0x4143ea=_0x12440d['filter']['updateFullNode'](_0x253f4f,_0x1c28e4,_0x46a189);}else{const _0x4151ec=y(_0xfedca2);let _0x193851=ss(_0x40c80f,_0x4151ec,_0x4ef5d8['serverCache']);_0x193851==null&&_0x4ef5d8['serverCache']['isCompleteForChild'](_0x4151ec)&&(_0x193851=_0x253f4f['getImmediateChild'](_0x4151ec)),_0x193851!=null?_0x4143ea=_0x12440d['filter']['updateChild'](_0x253f4f,_0x4151ec,_0x193851,S(_0xfedca2),_0x231ac9,_0x46a189):_0x4ef5d8['eventCache']['getNode']()['hasChild'](_0x4151ec)?_0x4143ea=_0x12440d['filter']['updateChild'](_0x253f4f,_0x4151ec,g['EMPTY_NODE'],S(_0xfedca2),_0x231ac9,_0x46a189):_0x4143ea=_0x253f4f,_0x4143ea['isEmpty']()&&_0x4ef5d8['serverCache']['isFullyInitialized']()&&(_0x1ce5e5=Cn(_0x40c80f,Ve(_0x4ef5d8)),_0x1ce5e5['isLeafNode']()&&(_0x4143ea=_0x12440d['filter']['updateFullNode'](_0x4143ea,_0x1ce5e5,_0x46a189)));}return _0x1ce5e5=_0x4ef5d8['serverCache']['isFullyInitialized']()||Tn(_0x40c80f,w())!=null,Rt(_0x4ef5d8,_0x4143ea,_0x1ce5e5,_0x12440d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x10356f,_0x1cffb5){this['query_']=_0x10356f,this['eventRegistrations_']=[];const _0x326d48=this['query_']['_queryParams'],_0x2509f0=new Xi(_0x326d48['getIndex']()),_0x1bce1d=Kh(_0x326d48);this['processor_']=Su(_0x1bce1d);const _0x399bed=_0x1cffb5['serverCache'],_0x5f324b=_0x1cffb5['eventCache'],_0x25c238=_0x2509f0['updateFullNode'](g['EMPTY_NODE'],_0x399bed['getNode'](),null),_0x3a1892=_0x1bce1d['updateFullNode'](g['EMPTY_NODE'],_0x5f324b['getNode'](),null),_0x561f72=new Te(_0x25c238,_0x399bed['isFullyInitialized'](),_0x2509f0['filtersNodes']()),_0x4c3c03=new Te(_0x3a1892,_0x5f324b['isFullyInitialized'](),_0x1bce1d['filtersNodes']());this['viewCache_']=Un(_0x4c3c03,_0x561f72),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x359c24){return _0x359c24['viewCache_']['serverCache']['getNode']();}function Lu(_0x3f781d){return wn(_0x3f781d['viewCache_']);}function xu(_0x28931c,_0x43ea85){const _0x4cbf5a=Ve(_0x28931c['viewCache_']);return _0x4cbf5a&&(_0x28931c['query']['_queryParams']['loadsAllData']()||!v(_0x43ea85)&&!_0x4cbf5a['getImmediateChild'](y(_0x43ea85))['isEmpty']())?_0x4cbf5a['getChild'](_0x43ea85):null;}function ur(_0x3b5f47){return _0x3b5f47['eventRegistrations_']['length']===0x0;}function Fu(_0x116732,_0x39bd7b){_0x116732['eventRegistrations_']['push'](_0x39bd7b);}function dr(_0x19b983,_0x1df3de,_0x22fc6f){const _0x1fa89a=[];if(_0x22fc6f){f(_0x1df3de==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1e03bd=_0x19b983['query']['_path'];_0x19b983['eventRegistrations_']['forEach'](_0x1e30ad=>{const _0x1c36f7=_0x1e30ad['createCancelEvent'](_0x22fc6f,_0x1e03bd);_0x1c36f7&&_0x1fa89a['push'](_0x1c36f7);});}if(_0x1df3de){let _0x1ee6c2=[];for(let _0x1e5397=0x0;_0x1e5397<_0x19b983['eventRegistrations_']['length'];++_0x1e5397){const _0x1203c3=_0x19b983['eventRegistrations_'][_0x1e5397];if(!_0x1203c3['matches'](_0x1df3de))_0x1ee6c2['push'](_0x1203c3);else{if(_0x1df3de['hasAnyCallback']()){_0x1ee6c2=_0x1ee6c2['concat'](_0x19b983['eventRegistrations_']['slice'](_0x1e5397+0x1));break;}}}_0x19b983['eventRegistrations_']=_0x1ee6c2;}else _0x19b983['eventRegistrations_']=[];return _0x1fa89a;}function fr(_0x4f58e8,_0x2cb659,_0x146ac7,_0x15fb0c){_0x2cb659['type']===z['MERGE']&&_0x2cb659['source']['queryId']!==null&&(f(Ve(_0x4f58e8['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x4f58e8['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xa78c6e=_0x4f58e8['viewCache_'],_0x1ee42f=Ru(_0x4f58e8['processor_'],_0xa78c6e,_0x2cb659,_0x146ac7,_0x15fb0c);return bu(_0x4f58e8['processor_'],_0x1ee42f['viewCache']),f(_0x1ee42f['viewCache']['serverCache']['isFullyInitialized']()||!_0xa78c6e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x4f58e8['viewCache_']=_0x1ee42f['viewCache'],qo(_0x4f58e8,_0x1ee42f['changes'],_0x1ee42f['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x45f8c0,_0x3e76eb){const _0x319bce=_0x45f8c0['viewCache_']['eventCache'],_0x246128=[];return _0x319bce['getNode']()['isLeafNode']()||_0x319bce['getNode']()['forEachChild'](R,(_0x45e7d1,_0x1e4e74)=>{_0x246128['push'](rt(_0x45e7d1,_0x1e4e74));}),_0x319bce['isFullyInitialized']()&&_0x246128['push'](Lo(_0x319bce['getNode']())),qo(_0x45f8c0,_0x246128,_0x319bce['getNode'](),_0x3e76eb);}function qo(_0x29b061,_0x5ae62c,_0x3b0680,_0x18d3d8){const _0x33d6f2=_0x18d3d8?[_0x18d3d8]:_0x29b061['eventRegistrations_'];return ru(_0x29b061['eventGenerator_'],_0x5ae62c,_0x3b0680,_0x33d6f2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x53e81c){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x53e81c;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5492c4){return _0x5492c4['views']['size']===0x0;}function os(_0x4ed253,_0xf21624,_0x5eeba3,_0xa8a30a){const _0x31cc5d=_0xf21624['source']['queryId'];if(_0x31cc5d!==null){const _0x300c80=_0x4ed253['views']['get'](_0x31cc5d);return f(_0x300c80!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x300c80,_0xf21624,_0x5eeba3,_0xa8a30a);}else{let _0x2098af=[];for(const _0x148a95 of _0x4ed253['views']['values']())_0x2098af=_0x2098af['concat'](fr(_0x148a95,_0xf21624,_0x5eeba3,_0xa8a30a));return _0x2098af;}}function jo(_0x24f227,_0x565ad6,_0x4560a6,_0x3504f8,_0x5ba8b6){const _0x32b4ff=_0x565ad6['_queryIdentifier'],_0xbd03fb=_0x24f227['views']['get'](_0x32b4ff);if(!_0xbd03fb){let _0x2824c6=Cn(_0x4560a6,_0x5ba8b6?_0x3504f8:null),_0x35b17c=!0x1;_0x2824c6?_0x35b17c=!0x0:_0x3504f8 instanceof g?(_0x2824c6=is(_0x4560a6,_0x3504f8),_0x35b17c=!0x1):(_0x2824c6=g['EMPTY_NODE'],_0x35b17c=!0x1);const _0x4affc7=Un(new Te(_0x2824c6,_0x35b17c,!0x1),new Te(_0x3504f8,_0x5ba8b6,!0x1));return new Du(_0x565ad6,_0x4affc7);}return _0xbd03fb;}function Hu(_0x5023b3,_0x1d0202,_0xc3e7fe,_0x1e8ec4,_0x11b8a0,_0x252118){const _0x88f326=jo(_0x5023b3,_0x1d0202,_0x1e8ec4,_0x11b8a0,_0x252118);return _0x5023b3['views']['has'](_0x1d0202['_queryIdentifier'])||_0x5023b3['views']['set'](_0x1d0202['_queryIdentifier'],_0x88f326),Fu(_0x88f326,_0xc3e7fe),Uu(_0x88f326,_0xc3e7fe);}function $u(_0x3ea30f,_0xbee6c4,_0x483884,_0x45691f){const _0x48c11c=_0xbee6c4['_queryIdentifier'],_0x4ec886=[];let _0x51760e=[];const _0x3e9f06=Se(_0x3ea30f);if(_0x48c11c==='default'){for(const [_0x39c6a8,_0x42cf94]of _0x3ea30f['views']['entries']())_0x51760e=_0x51760e['concat'](dr(_0x42cf94,_0x483884,_0x45691f)),ur(_0x42cf94)&&(_0x3ea30f['views']['delete'](_0x39c6a8),_0x42cf94['query']['_queryParams']['loadsAllData']()||_0x4ec886['push'](_0x42cf94['query']));}else{const _0x41751f=_0x3ea30f['views']['get'](_0x48c11c);_0x41751f&&(_0x51760e=_0x51760e['concat'](dr(_0x41751f,_0x483884,_0x45691f)),ur(_0x41751f)&&(_0x3ea30f['views']['delete'](_0x48c11c),_0x41751f['query']['_queryParams']['loadsAllData']()||_0x4ec886['push'](_0x41751f['query'])));}return _0x3e9f06&&!Se(_0x3ea30f)&&_0x4ec886['push'](new(Bu())(_0xbee6c4['_repo'],_0xbee6c4['_path'])),{'removed':_0x4ec886,'events':_0x51760e};}function Ko(_0x14efe8){const _0x173d6b=[];for(const _0x5254c4 of _0x14efe8['views']['values']())_0x5254c4['query']['_queryParams']['loadsAllData']()||_0x173d6b['push'](_0x5254c4);return _0x173d6b;}function Ie(_0x3bb3ea,_0x3dc22c){let _0x1f0479=null;for(const _0x560e9f of _0x3bb3ea['views']['values']())_0x1f0479=_0x1f0479||xu(_0x560e9f,_0x3dc22c);return _0x1f0479;}function Yo(_0x2ea27a,_0x2ad56c){if(_0x2ad56c['_queryParams']['loadsAllData']())return Bn(_0x2ea27a);{const _0x5e5f22=_0x2ad56c['_queryIdentifier'];return _0x2ea27a['views']['get'](_0x5e5f22);}}function Qo(_0x2fdcd8,_0xbba780){return Yo(_0x2fdcd8,_0xbba780)!=null;}function Se(_0x778a11){return Bn(_0x778a11)!=null;}function Bn(_0x3cef95){for(const _0x1ae37c of _0x3cef95['views']['values']())if(_0x1ae37c['query']['_queryParams']['loadsAllData']())return _0x1ae37c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x53c90b){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x53c90b;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2dc7c6){this['listenProvider_']=_0x2dc7c6,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x1f038d,_0x45c871,_0x1e43cd,_0x58bfe7,_0x1e8124){return lu(_0x1f038d['pendingWriteTree_'],_0x45c871,_0x1e43cd,_0x58bfe7,_0x1e8124),_0x1e8124?_t(_0x1f038d,new Be(es(),_0x45c871,_0x1e43cd)):[];}function ju(_0x1566fb,_0x4fb098,_0x3a3eb6,_0x16a6be){hu(_0x1566fb['pendingWriteTree_'],_0x4fb098,_0x3a3eb6,_0x16a6be);const _0x281e29=b['fromObject'](_0x3a3eb6);return _t(_0x1566fb,new ot(es(),_0x4fb098,_0x281e29));}function _e(_0x198cae,_0x266a55,_0x2cbaf6=!0x1){const _0xb4e959=uu(_0x198cae['pendingWriteTree_'],_0x266a55);if(du(_0x198cae['pendingWriteTree_'],_0x266a55)){let _0x4285a9=new b(null);return _0xb4e959['snap']!=null?_0x4285a9=_0x4285a9['set'](w(),!0x0):x(_0xb4e959['children'],_0x3414cb=>{_0x4285a9=_0x4285a9['set'](new C(_0x3414cb),!0x0);}),_t(_0x198cae,new In(_0xb4e959['path'],_0x4285a9,_0x2cbaf6));}else return[];}function Yt(_0x157a86,_0x5a24bb,_0x2be1be){return _t(_0x157a86,new Be(ts(),_0x5a24bb,_0x2be1be));}function Ku(_0x5f1169,_0x279509,_0x336d82){const _0x40c569=b['fromObject'](_0x336d82);return _t(_0x5f1169,new ot(ts(),_0x279509,_0x40c569));}function Yu(_0x343842,_0x47ade1){return _t(_0x343842,new Ut(ts(),_0x47ade1));}function Qu(_0x3150d5,_0x87b515,_0x216603){const _0x38be96=cs(_0x3150d5,_0x216603);if(_0x38be96){const _0x3b19aa=ls(_0x38be96),_0x18166e=_0x3b19aa['path'],_0x434981=_0x3b19aa['queryId'],_0x5ec871=F(_0x18166e,_0x87b515),_0x15333c=new Ut(ns(_0x434981),_0x5ec871);return hs(_0x3150d5,_0x18166e,_0x15333c);}else return[];}function An(_0x34356d,_0x32ecd1,_0x13f1b0,_0x5d4b5f,_0x527e17=!0x1){const _0x5d72d5=_0x32ecd1['_path'],_0x195dbe=_0x34356d['syncPointTree_']['get'](_0x5d72d5);let _0x2bb915=[];if(_0x195dbe&&(_0x32ecd1['_queryIdentifier']==='default'||Qo(_0x195dbe,_0x32ecd1))){const _0x20c9eb=$u(_0x195dbe,_0x32ecd1,_0x13f1b0,_0x5d4b5f);Vu(_0x195dbe)&&(_0x34356d['syncPointTree_']=_0x34356d['syncPointTree_']['remove'](_0x5d72d5));const _0x500967=_0x20c9eb['removed'];if(_0x2bb915=_0x20c9eb['events'],!_0x527e17){const _0x46fb4f=_0x500967['findIndex'](_0x6f1bdb=>_0x6f1bdb['_queryParams']['loadsAllData']())!==-0x1,_0x4caaf1=_0x34356d['syncPointTree_']['findOnPath'](_0x5d72d5,(_0x1bfc45,_0x300e9d)=>Se(_0x300e9d));if(_0x46fb4f&&!_0x4caaf1){const _0x32982d=_0x34356d['syncPointTree_']['subtree'](_0x5d72d5);if(!_0x32982d['isEmpty']()){const _0x564d75=Zu(_0x32982d);for(let _0x389ce6=0x0;_0x389ce6<_0x564d75['length'];++_0x389ce6){const _0x209e77=_0x564d75[_0x389ce6],_0x3a365f=_0x209e77['query'],_0x46e4ee=ea(_0x34356d,_0x209e77);_0x34356d['listenProvider_']['startListening'](kt(_0x3a365f),Wt(_0x34356d,_0x3a365f),_0x46e4ee['hashFn'],_0x46e4ee['onComplete']);}}}!_0x4caaf1&&_0x500967['length']>0x0&&!_0x5d4b5f&&(_0x46fb4f?_0x34356d['listenProvider_']['stopListening'](kt(_0x32ecd1),null):_0x500967['forEach'](_0x129e3a=>{const _0x3dd2c6=_0x34356d['queryToTagMap']['get'](Hn(_0x129e3a));_0x34356d['listenProvider_']['stopListening'](kt(_0x129e3a),_0x3dd2c6);}));}ed(_0x34356d,_0x500967);}return _0x2bb915;}function Jo(_0x5809ad,_0x1368f7,_0x2464a0,_0x36ca36){const _0xb82560=cs(_0x5809ad,_0x36ca36);if(_0xb82560!=null){const _0x210ded=ls(_0xb82560),_0x53c280=_0x210ded['path'],_0x185079=_0x210ded['queryId'],_0x10df1b=F(_0x53c280,_0x1368f7),_0x6141ae=new Be(ns(_0x185079),_0x10df1b,_0x2464a0);return hs(_0x5809ad,_0x53c280,_0x6141ae);}else return[];}function Ju(_0x3c425d,_0x60a3fe,_0x6d4339,_0x333247){const _0x353f31=cs(_0x3c425d,_0x333247);if(_0x353f31){const _0x323b12=ls(_0x353f31),_0x4db1f1=_0x323b12['path'],_0x266bf5=_0x323b12['queryId'],_0x55bc81=F(_0x4db1f1,_0x60a3fe),_0x55b60a=b['fromObject'](_0x6d4339),_0x4fc148=new ot(ns(_0x266bf5),_0x55bc81,_0x55b60a);return hs(_0x3c425d,_0x4db1f1,_0x4fc148);}else return[];}function Ni(_0x5b2ce6,_0x105e72,_0x52bc4e,_0xb5f010=!0x1){const _0x2772a0=_0x105e72['_path'];let _0x29602a=null,_0x21a993=!0x1;_0x5b2ce6['syncPointTree_']['foreachOnPath'](_0x2772a0,(_0x506d41,_0x875eb5)=>{const _0xbb7651=F(_0x506d41,_0x2772a0);_0x29602a=_0x29602a||Ie(_0x875eb5,_0xbb7651),_0x21a993=_0x21a993||Se(_0x875eb5);});let _0x4f20f5=_0x5b2ce6['syncPointTree_']['get'](_0x2772a0);_0x4f20f5?(_0x21a993=_0x21a993||Se(_0x4f20f5),_0x29602a=_0x29602a||Ie(_0x4f20f5,w())):(_0x4f20f5=new zo(),_0x5b2ce6['syncPointTree_']=_0x5b2ce6['syncPointTree_']['set'](_0x2772a0,_0x4f20f5));let _0x436a20;_0x29602a!=null?_0x436a20=!0x0:(_0x436a20=!0x1,_0x29602a=g['EMPTY_NODE'],_0x5b2ce6['syncPointTree_']['subtree'](_0x2772a0)['foreachChild']((_0x5b21d5,_0x24c33a)=>{const _0x138686=Ie(_0x24c33a,w());_0x138686&&(_0x29602a=_0x29602a['updateImmediateChild'](_0x5b21d5,_0x138686));}));const _0x3bd8bf=Qo(_0x4f20f5,_0x105e72);if(!_0x3bd8bf&&!_0x105e72['_queryParams']['loadsAllData']()){const _0x1ecedd=Hn(_0x105e72);f(!_0x5b2ce6['queryToTagMap']['has'](_0x1ecedd),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5e22c2=td();_0x5b2ce6['queryToTagMap']['set'](_0x1ecedd,_0x5e22c2),_0x5b2ce6['tagToQueryMap']['set'](_0x5e22c2,_0x1ecedd);}const _0x21a949=Wn(_0x5b2ce6['pendingWriteTree_'],_0x2772a0);let _0x2ba704=Hu(_0x4f20f5,_0x105e72,_0x52bc4e,_0x21a949,_0x29602a,_0x436a20);if(!_0x3bd8bf&&!_0x21a993&&!_0xb5f010){const _0x5f4e68=Yo(_0x4f20f5,_0x105e72);_0x2ba704=_0x2ba704['concat'](nd(_0x5b2ce6,_0x105e72,_0x5f4e68));}return _0x2ba704;}function Vn(_0x4bf61d,_0x3237c2,_0x2d3159){const _0x2b2eed=_0x4bf61d['pendingWriteTree_'],_0x528456=_0x4bf61d['syncPointTree_']['findOnPath'](_0x3237c2,(_0xb21ff9,_0x335bb6)=>{const _0x4c3b62=F(_0xb21ff9,_0x3237c2),_0x299792=Ie(_0x335bb6,_0x4c3b62);if(_0x299792)return _0x299792;});return Bo(_0x2b2eed,_0x3237c2,_0x528456,_0x2d3159,!0x0);}function Xu(_0x2fbc91,_0x33bc3f){const _0x1f3766=_0x33bc3f['_path'];let _0x5b9c74=null;_0x2fbc91['syncPointTree_']['foreachOnPath'](_0x1f3766,(_0x335fc5,_0x447c9e)=>{const _0x138ee7=F(_0x335fc5,_0x1f3766);_0x5b9c74=_0x5b9c74||Ie(_0x447c9e,_0x138ee7);});let _0x30fe57=_0x2fbc91['syncPointTree_']['get'](_0x1f3766);_0x30fe57?_0x5b9c74=_0x5b9c74||Ie(_0x30fe57,w()):(_0x30fe57=new zo(),_0x2fbc91['syncPointTree_']=_0x2fbc91['syncPointTree_']['set'](_0x1f3766,_0x30fe57));const _0x32e902=_0x5b9c74!=null,_0x242271=_0x32e902?new Te(_0x5b9c74,!0x0,!0x1):null,_0x4b9e09=Wn(_0x2fbc91['pendingWriteTree_'],_0x33bc3f['_path']),_0xcd39e0=jo(_0x30fe57,_0x33bc3f,_0x4b9e09,_0x32e902?_0x242271['getNode']():g['EMPTY_NODE'],_0x32e902);return Lu(_0xcd39e0);}function _t(_0x192317,_0x437cb3){return Xo(_0x437cb3,_0x192317['syncPointTree_'],null,Wn(_0x192317['pendingWriteTree_'],w()));}function Xo(_0x2fbaad,_0x50ebc2,_0x2c2f21,_0x3f3f05){if(v(_0x2fbaad['path']))return Zo(_0x2fbaad,_0x50ebc2,_0x2c2f21,_0x3f3f05);{const _0x1221e8=_0x50ebc2['get'](w());_0x2c2f21==null&&_0x1221e8!=null&&(_0x2c2f21=Ie(_0x1221e8,w()));let _0x51c9de=[];const _0x1578c6=y(_0x2fbaad['path']),_0x3c79e8=_0x2fbaad['operationForChild'](_0x1578c6),_0x5d24af=_0x50ebc2['children']['get'](_0x1578c6);if(_0x5d24af&&_0x3c79e8){const _0x34490c=_0x2c2f21?_0x2c2f21['getImmediateChild'](_0x1578c6):null,_0x49acb4=Vo(_0x3f3f05,_0x1578c6);_0x51c9de=_0x51c9de['concat'](Xo(_0x3c79e8,_0x5d24af,_0x34490c,_0x49acb4));}return _0x1221e8&&(_0x51c9de=_0x51c9de['concat'](os(_0x1221e8,_0x2fbaad,_0x3f3f05,_0x2c2f21))),_0x51c9de;}}function Zo(_0x5df926,_0x2453e1,_0x58fe63,_0x19b385){const _0x4c8aa1=_0x2453e1['get'](w());_0x58fe63==null&&_0x4c8aa1!=null&&(_0x58fe63=Ie(_0x4c8aa1,w()));let _0x3e3d53=[];return _0x2453e1['children']['inorderTraversal']((_0x1322aa,_0x30815d)=>{const _0x14d50e=_0x58fe63?_0x58fe63['getImmediateChild'](_0x1322aa):null,_0x27d02a=Vo(_0x19b385,_0x1322aa),_0x494a65=_0x5df926['operationForChild'](_0x1322aa);_0x494a65&&(_0x3e3d53=_0x3e3d53['concat'](Zo(_0x494a65,_0x30815d,_0x14d50e,_0x27d02a)));}),_0x4c8aa1&&(_0x3e3d53=_0x3e3d53['concat'](os(_0x4c8aa1,_0x5df926,_0x19b385,_0x58fe63))),_0x3e3d53;}function ea(_0x3db068,_0x3efdc2){const _0x17a928=_0x3efdc2['query'],_0x1cfcd0=Wt(_0x3db068,_0x17a928);return{'hashFn':()=>(Mu(_0x3efdc2)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3e1669=>{if(_0x3e1669==='ok')return _0x1cfcd0?Qu(_0x3db068,_0x17a928['_path'],_0x1cfcd0):Yu(_0x3db068,_0x17a928['_path']);{const _0x377ab7=Kl(_0x3e1669,_0x17a928);return An(_0x3db068,_0x17a928,null,_0x377ab7);}}};}function Wt(_0x3b275b,_0x4cb4c9){const _0x466154=Hn(_0x4cb4c9);return _0x3b275b['queryToTagMap']['get'](_0x466154);}function Hn(_0x2c2b30){return _0x2c2b30['_path']['toString']()+'$'+_0x2c2b30['_queryIdentifier'];}function cs(_0x37a755,_0x424a73){return _0x37a755['tagToQueryMap']['get'](_0x424a73);}function ls(_0x33a9aa){const _0x3ef02d=_0x33a9aa['indexOf']('$');return f(_0x3ef02d!==-0x1&&_0x3ef02d<_0x33a9aa['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x33a9aa['substr'](_0x3ef02d+0x1),'path':new C(_0x33a9aa['substr'](0x0,_0x3ef02d))};}function hs(_0x158f63,_0x3e8001,_0x5eb873){const _0x182834=_0x158f63['syncPointTree_']['get'](_0x3e8001);f(_0x182834,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4405ea=Wn(_0x158f63['pendingWriteTree_'],_0x3e8001);return os(_0x182834,_0x5eb873,_0x4405ea,null);}function Zu(_0x1abdb8){return _0x1abdb8['fold']((_0x303160,_0x3c5a04,_0x10fbda)=>{if(_0x3c5a04&&Se(_0x3c5a04))return[Bn(_0x3c5a04)];{let _0x3706d7=[];return _0x3c5a04&&(_0x3706d7=Ko(_0x3c5a04)),x(_0x10fbda,(_0x269094,_0x247533)=>{_0x3706d7=_0x3706d7['concat'](_0x247533);}),_0x3706d7;}});}function kt(_0x549105){return _0x549105['_queryParams']['loadsAllData']()&&!_0x549105['_queryParams']['isDefault']()?new(qu())(_0x549105['_repo'],_0x549105['_path']):_0x549105;}function ed(_0x3d7e8f,_0x5ad3b6){for(let _0x303854=0x0;_0x303854<_0x5ad3b6['length'];++_0x303854){const _0x319f2d=_0x5ad3b6[_0x303854];if(!_0x319f2d['_queryParams']['loadsAllData']()){const _0x27f26a=Hn(_0x319f2d),_0x1af20d=_0x3d7e8f['queryToTagMap']['get'](_0x27f26a);_0x3d7e8f['queryToTagMap']['delete'](_0x27f26a),_0x3d7e8f['tagToQueryMap']['delete'](_0x1af20d);}}}function td(){return zu++;}function nd(_0x748a71,_0x1c74a7,_0x450452){const _0x22a6b3=_0x1c74a7['_path'],_0x4ac25d=Wt(_0x748a71,_0x1c74a7),_0x4218fa=ea(_0x748a71,_0x450452),_0x29ea9f=_0x748a71['listenProvider_']['startListening'](kt(_0x1c74a7),_0x4ac25d,_0x4218fa['hashFn'],_0x4218fa['onComplete']),_0x256ab7=_0x748a71['syncPointTree_']['subtree'](_0x22a6b3);if(_0x4ac25d)f(!Se(_0x256ab7['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5a6541=_0x256ab7['fold']((_0x1d20dd,_0x1923d7,_0x532c36)=>{if(!v(_0x1d20dd)&&_0x1923d7&&Se(_0x1923d7))return[Bn(_0x1923d7)['query']];{let _0x212c52=[];return _0x1923d7&&(_0x212c52=_0x212c52['concat'](Ko(_0x1923d7)['map'](_0x1ae2eb=>_0x1ae2eb['query']))),x(_0x532c36,(_0x4aec2b,_0x1b6eac)=>{_0x212c52=_0x212c52['concat'](_0x1b6eac);}),_0x212c52;}});for(let _0x19262e=0x0;_0x19262e<_0x5a6541['length'];++_0x19262e){const _0x353a72=_0x5a6541[_0x19262e];_0x748a71['listenProvider_']['stopListening'](kt(_0x353a72),Wt(_0x748a71,_0x353a72));}}return _0x29ea9f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x17cc7c){this['node_']=_0x17cc7c;}['getImmediateChild'](_0xc02d60){const _0x2e25eb=this['node_']['getImmediateChild'](_0xc02d60);return new us(_0x2e25eb);}['node'](){return this['node_'];}}class ds{constructor(_0x5abae9,_0x370caf){this['syncTree_']=_0x5abae9,this['path_']=_0x370caf;}['getImmediateChild'](_0x507959){const _0x223746=k(this['path_'],_0x507959);return new ds(this['syncTree_'],_0x223746);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x47521a){return _0x47521a=_0x47521a||{},_0x47521a['timestamp']=_0x47521a['timestamp']||new Date()['getTime'](),_0x47521a;},_r=function(_0x517a01,_0x411464,_0x20ca62){if(!_0x517a01||typeof _0x517a01!='object')return _0x517a01;if(f('.sv'in _0x517a01,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x517a01['.sv']=='string')return sd(_0x517a01['.sv'],_0x411464,_0x20ca62);if(typeof _0x517a01['.sv']=='object')return rd(_0x517a01['.sv'],_0x411464);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x517a01,null,0x2));},sd=function(_0x29c2cf,_0x36e123,_0x5f2e35){switch(_0x29c2cf){case'timestamp':return _0x5f2e35['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x29c2cf);}},rd=function(_0xf43977,_0x405f86,_0x486234){_0xf43977['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xf43977,null,0x2));const _0x29a4d3=_0xf43977['increment'];typeof _0x29a4d3!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x29a4d3);const _0x204832=_0x405f86['node']();if(f(_0x204832!==null&&typeof _0x204832<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x204832['isLeafNode']())return _0x29a4d3;const _0x4dfeab=_0x204832['getValue']();return typeof _0x4dfeab!='number'?_0x29a4d3:_0x4dfeab+_0x29a4d3;},ta=function(_0x372ad5,_0x17c0ae,_0x44732e,_0x1da093){return ps(_0x17c0ae,new ds(_0x44732e,_0x372ad5),_0x1da093);},fs=function(_0x1cb19c,_0x3f5573,_0x151610){return ps(_0x1cb19c,new us(_0x3f5573),_0x151610);};function ps(_0x48201a,_0x260fa8,_0x29d0e7){const _0x5a421f=_0x48201a['getPriority']()['val'](),_0x115c7f=_r(_0x5a421f,_0x260fa8['getImmediateChild']('.priority'),_0x29d0e7);let _0x222689;if(_0x48201a['isLeafNode']()){const _0xfb2887=_0x48201a,_0x2316d9=_r(_0xfb2887['getValue'](),_0x260fa8,_0x29d0e7);return _0x2316d9!==_0xfb2887['getValue']()||_0x115c7f!==_0xfb2887['getPriority']()['val']()?new D(_0x2316d9,A(_0x115c7f)):_0x48201a;}else{const _0x449ec1=_0x48201a;return _0x222689=_0x449ec1,_0x115c7f!==_0x449ec1['getPriority']()['val']()&&(_0x222689=_0x222689['updatePriority'](new D(_0x115c7f))),_0x449ec1['forEachChild'](R,(_0x54f29c,_0x4d4ce9)=>{const _0x5900a8=ps(_0x4d4ce9,_0x260fa8['getImmediateChild'](_0x54f29c),_0x29d0e7);_0x5900a8!==_0x4d4ce9&&(_0x222689=_0x222689['updateImmediateChild'](_0x54f29c,_0x5900a8));}),_0x222689;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x28699d='',_0x3ce828=null,_0x998985={'children':{},'childCount':0x0}){this['name']=_0x28699d,this['parent']=_0x3ce828,this['node']=_0x998985;}}function $n(_0x302cd3,_0x3f2aa9){let _0x3efeab=_0x3f2aa9 instanceof C?_0x3f2aa9:new C(_0x3f2aa9),_0x3c3c9e=_0x302cd3,_0x423ab9=y(_0x3efeab);for(;_0x423ab9!==null;){const _0x3aa650=Le(_0x3c3c9e['node']['children'],_0x423ab9)||{'children':{},'childCount':0x0};_0x3c3c9e=new _s(_0x423ab9,_0x3c3c9e,_0x3aa650),_0x3efeab=S(_0x3efeab),_0x423ab9=y(_0x3efeab);}return _0x3c3c9e;}function je(_0x506d82){return _0x506d82['node']['value'];}function gs(_0x13f5dc,_0x321347){_0x13f5dc['node']['value']=_0x321347,Oi(_0x13f5dc);}function na(_0x20eef){return _0x20eef['node']['childCount']>0x0;}function od(_0x4b9838){return je(_0x4b9838)===void 0x0&&!na(_0x4b9838);}function Gn(_0x375a58,_0x2b456e){x(_0x375a58['node']['children'],(_0x174560,_0x4d7941)=>{_0x2b456e(new _s(_0x174560,_0x375a58,_0x4d7941));});}function ia(_0x380e61,_0x45110f,_0x525afc,_0xe3fb4b){_0x525afc&&_0x45110f(_0x380e61),Gn(_0x380e61,_0x14d000=>{ia(_0x14d000,_0x45110f,!0x0);});}function ad(_0x1d7b4b,_0x3daa40,_0x567ddf){let _0x12457b=_0x1d7b4b['parent'];for(;_0x12457b!==null;){if(_0x3daa40(_0x12457b))return!0x0;_0x12457b=_0x12457b['parent'];}return!0x1;}function Qt(_0xdd681f){return new C(_0xdd681f['parent']===null?_0xdd681f['name']:Qt(_0xdd681f['parent'])+'/'+_0xdd681f['name']);}function Oi(_0x2d403b){_0x2d403b['parent']!==null&&cd(_0x2d403b['parent'],_0x2d403b['name'],_0x2d403b);}function cd(_0x40a591,_0x1bbd04,_0x2c2533){const _0x4c9c30=od(_0x2c2533),_0x159cb3=Q(_0x40a591['node']['children'],_0x1bbd04);_0x4c9c30&&_0x159cb3?(delete _0x40a591['node']['children'][_0x1bbd04],_0x40a591['node']['childCount']--,Oi(_0x40a591)):!_0x4c9c30&&!_0x159cb3&&(_0x40a591['node']['children'][_0x1bbd04]=_0x2c2533['node'],_0x40a591['node']['childCount']++,Oi(_0x40a591));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x18e50e){return typeof _0x18e50e=='string'&&_0x18e50e['length']!==0x0&&!ld['test'](_0x18e50e);},sa=function(_0x542ed1){return typeof _0x542ed1=='string'&&_0x542ed1['length']!==0x0&&!hd['test'](_0x542ed1);},ud=function(_0x3ddcd6){return _0x3ddcd6&&(_0x3ddcd6=_0x3ddcd6['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3ddcd6);},Bt=function(_0x77270c){return _0x77270c===null||typeof _0x77270c=='string'||typeof _0x77270c=='number'&&!xn(_0x77270c)||_0x77270c&&typeof _0x77270c=='object'&&Q(_0x77270c,'.sv');},He=function(_0xfd07ac,_0x4bd2cf,_0x95eb6c,_0x563977){_0x563977&&_0x4bd2cf===void 0x0||Jt(it(_0xfd07ac,'value'),_0x4bd2cf,_0x95eb6c);},Jt=function(_0x41be5f,_0x556822,_0x1cf43c){const _0x572dd9=_0x1cf43c instanceof C?new Ah(_0x1cf43c,_0x41be5f):_0x1cf43c;if(_0x556822===void 0x0)throw new Error(_0x41be5f+'contains\x20undefined\x20'+Oe(_0x572dd9));if(typeof _0x556822=='function')throw new Error(_0x41be5f+'contains\x20a\x20function\x20'+Oe(_0x572dd9)+'\x20with\x20contents\x20=\x20'+_0x556822['toString']());if(xn(_0x556822))throw new Error(_0x41be5f+'contains\x20'+_0x556822['toString']()+'\x20'+Oe(_0x572dd9));if(typeof _0x556822=='string'&&_0x556822['length']>ui/0x3&&Ln(_0x556822)>ui)throw new Error(_0x41be5f+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x572dd9)+'\x20(\x27'+_0x556822['substring'](0x0,0x32)+'...\x27)');if(_0x556822&&typeof _0x556822=='object'){let _0x42a504=!0x1,_0x570126=!0x1;if(x(_0x556822,(_0x157fb2,_0x28d7af)=>{if(_0x157fb2==='.value')_0x42a504=!0x0;else{if(_0x157fb2!=='.priority'&&_0x157fb2!=='.sv'&&(_0x570126=!0x0,!ms(_0x157fb2)))throw new Error(_0x41be5f+'\x20contains\x20an\x20invalid\x20key\x20('+_0x157fb2+')\x20'+Oe(_0x572dd9)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x572dd9,_0x157fb2),Jt(_0x41be5f,_0x28d7af,_0x572dd9),Ph(_0x572dd9);}),_0x42a504&&_0x570126)throw new Error(_0x41be5f+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x572dd9)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2686c4,_0x817348){let _0x2ec2a4,_0x2aead0;for(_0x2ec2a4=0x0;_0x2ec2a4<_0x817348['length'];_0x2ec2a4++){_0x2aead0=_0x817348[_0x2ec2a4];const _0x51dfe8=Mt(_0x2aead0);for(let _0x3c0714=0x0;_0x3c0714<_0x51dfe8['length'];_0x3c0714++)if(!(_0x51dfe8[_0x3c0714]==='.priority'&&_0x3c0714===_0x51dfe8['length']-0x1)){if(!ms(_0x51dfe8[_0x3c0714]))throw new Error(_0x2686c4+'contains\x20an\x20invalid\x20key\x20('+_0x51dfe8[_0x3c0714]+')\x20in\x20path\x20'+_0x2aead0['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x817348['sort'](Rh);let _0x34720a=null;for(_0x2ec2a4=0x0;_0x2ec2a4<_0x817348['length'];_0x2ec2a4++){if(_0x2aead0=_0x817348[_0x2ec2a4],_0x34720a!==null&&G(_0x34720a,_0x2aead0))throw new Error(_0x2686c4+'contains\x20a\x20path\x20'+_0x34720a['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2aead0['toString']());_0x34720a=_0x2aead0;}},ra=function(_0x4224b2,_0x290330,_0x2a6479,_0x70eb){const _0x2bc129=it(_0x4224b2,'values');if(!(_0x290330&&typeof _0x290330=='object')||Array['isArray'](_0x290330))throw new Error(_0x2bc129+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1b0afe=[];x(_0x290330,(_0x27598f,_0x2c0ca1)=>{const _0x14cf9b=new C(_0x27598f);if(Jt(_0x2bc129,_0x2c0ca1,k(_0x2a6479,_0x14cf9b)),ji(_0x14cf9b)==='.priority'&&!Bt(_0x2c0ca1))throw new Error(_0x2bc129+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x14cf9b['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1b0afe['push'](_0x14cf9b);}),dd(_0x2bc129,_0x1b0afe);},fd=function(_0xab9154,_0x3b95bc,_0x16cc34){if(xn(_0x3b95bc))throw new Error(it(_0xab9154,'priority')+'is\x20'+_0x3b95bc['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3b95bc))throw new Error(it(_0xab9154,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xea1c33,_0x1b2b80,_0x1e73c7,_0x7fda64){if(!sa(_0x1e73c7))throw new Error(it(_0xea1c33,_0x1b2b80)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1e73c7+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x31d662,_0x594a78,_0x3407d9,_0x926a2a){_0x3407d9&&(_0x3407d9=_0x3407d9['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x31d662,_0x594a78,_0x3407d9);},Me=function(_0x112589,_0x160106){if(y(_0x160106)==='.info')throw new Error(_0x112589+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x4939e4,_0x16fa39){const _0x65999f=_0x16fa39['path']['toString']();if(typeof _0x16fa39['repoInfo']['host']!='string'||_0x16fa39['repoInfo']['host']['length']===0x0||!ms(_0x16fa39['repoInfo']['namespace'])&&_0x16fa39['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x65999f['length']!==0x0&&!ud(_0x65999f))throw new Error(it(_0x4939e4,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x509d81,_0x43a2cf){let _0x3e387b=null;for(let _0x26cc4c=0x0;_0x26cc4c<_0x43a2cf['length'];_0x26cc4c++){const _0x3c157d=_0x43a2cf[_0x26cc4c],_0x3df929=_0x3c157d['getPath']();_0x3e387b!==null&&!Ki(_0x3df929,_0x3e387b['path'])&&(_0x509d81['eventLists_']['push'](_0x3e387b),_0x3e387b=null),_0x3e387b===null&&(_0x3e387b={'events':[],'path':_0x3df929}),_0x3e387b['events']['push'](_0x3c157d);}_0x3e387b&&_0x509d81['eventLists_']['push'](_0x3e387b);}function oa(_0x589726,_0x3505b8,_0x1c3d14){qn(_0x589726,_0x1c3d14),aa(_0x589726,_0x1905f3=>Ki(_0x1905f3,_0x3505b8));}function V(_0x2a369f,_0x54aeb8,_0x12b6a7){qn(_0x2a369f,_0x12b6a7),aa(_0x2a369f,_0x36fb7f=>G(_0x36fb7f,_0x54aeb8)||G(_0x54aeb8,_0x36fb7f));}function aa(_0x352f65,_0x5ed358){_0x352f65['recursionDepth_']++;let _0x304ab0=!0x0;for(let _0x56e5f7=0x0;_0x56e5f7<_0x352f65['eventLists_']['length'];_0x56e5f7++){const _0x565ff4=_0x352f65['eventLists_'][_0x56e5f7];if(_0x565ff4){const _0x50e9e2=_0x565ff4['path'];_0x5ed358(_0x50e9e2)?(md(_0x352f65['eventLists_'][_0x56e5f7]),_0x352f65['eventLists_'][_0x56e5f7]=null):_0x304ab0=!0x1;}}_0x304ab0&&(_0x352f65['eventLists_']=[]),_0x352f65['recursionDepth_']--;}function md(_0x33988d){for(let _0x4d1121=0x0;_0x4d1121<_0x33988d['events']['length'];_0x4d1121++){const _0x52b5fb=_0x33988d['events'][_0x4d1121];if(_0x52b5fb!==null){_0x33988d['events'][_0x4d1121]=null;const _0xf03469=_0x52b5fb['getEventRunner']();St&&L('event:\x20'+_0x52b5fb['toString']()),ft(_0xf03469);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4d2ad8,_0x9df923,_0x53ee9d,_0x566eef){this['repoInfo_']=_0x4d2ad8,this['forceRestClient_']=_0x9df923,this['authTokenProvider_']=_0x53ee9d,this['appCheckProvider_']=_0x566eef,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2053f6,_0x32bb76,_0x324e8f){if(_0x2053f6['stats_']=qi(_0x2053f6['repoInfo_']),_0x2053f6['forceRestClient_']||Xl())_0x2053f6['server_']=new vn(_0x2053f6['repoInfo_'],(_0x28daa5,_0x4e711b,_0x25f07c,_0x3ccf7d)=>{gr(_0x2053f6,_0x28daa5,_0x4e711b,_0x25f07c,_0x3ccf7d);},_0x2053f6['authTokenProvider_'],_0x2053f6['appCheckProvider_']),setTimeout(()=>mr(_0x2053f6,!0x0),0x0);else{if(typeof _0x324e8f<'u'&&_0x324e8f!==null){if(typeof _0x324e8f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x324e8f);}catch(_0x972f76){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x972f76);}}_0x2053f6['persistentConnection_']=new se(_0x2053f6['repoInfo_'],_0x32bb76,(_0xd8824b,_0x3f240a,_0x31defc,_0x16ea57)=>{gr(_0x2053f6,_0xd8824b,_0x3f240a,_0x31defc,_0x16ea57);},_0x1fda93=>{mr(_0x2053f6,_0x1fda93);},_0x57e1b5=>{Id(_0x2053f6,_0x57e1b5);},_0x2053f6['authTokenProvider_'],_0x2053f6['appCheckProvider_'],_0x324e8f),_0x2053f6['server_']=_0x2053f6['persistentConnection_'];}_0x2053f6['authTokenProvider_']['addTokenChangeListener'](_0x3c94ff=>{_0x2053f6['server_']['refreshAuthToken'](_0x3c94ff);}),_0x2053f6['appCheckProvider_']['addTokenChangeListener'](_0x2fea9c=>{_0x2053f6['server_']['refreshAppCheckToken'](_0x2fea9c['token']);}),_0x2053f6['statsReporter_']=ih(_0x2053f6['repoInfo_'],()=>new iu(_0x2053f6['stats_'],_0x2053f6['server_'])),_0x2053f6['infoData_']=new Xh(),_0x2053f6['infoSyncTree_']=new pr({'startListening':(_0x369a08,_0x187f49,_0x273334,_0x469303)=>{let _0x18b84c=[];const _0xe51cac=_0x2053f6['infoData_']['getNode'](_0x369a08['_path']);return _0xe51cac['isEmpty']()||(_0x18b84c=Yt(_0x2053f6['infoSyncTree_'],_0x369a08['_path'],_0xe51cac),setTimeout(()=>{_0x469303('ok');},0x0)),_0x18b84c;},'stopListening':()=>{}}),vs(_0x2053f6,'connected',!0x1),_0x2053f6['serverSyncTree_']=new pr({'startListening':(_0x1fadc4,_0x2b94a3,_0x66fa0e,_0x745381)=>(_0x2053f6['server_']['listen'](_0x1fadc4,_0x66fa0e,_0x2b94a3,(_0x4c08fd,_0x57f164)=>{const _0x2add1b=_0x745381(_0x4c08fd,_0x57f164);V(_0x2053f6['eventQueue_'],_0x1fadc4['_path'],_0x2add1b);}),[]),'stopListening':(_0x5afb32,_0x503aea)=>{_0x2053f6['server_']['unlisten'](_0x5afb32,_0x503aea);}});}function la(_0x2434de){const _0xce2c25=_0x2434de['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xce2c25;}function Xt(_0x4eac65){return id({'timestamp':la(_0x4eac65)});}function gr(_0x3bee40,_0x1eeb0e,_0x440948,_0x3f5d5f,_0x4abade){_0x3bee40['dataUpdateCount']++;const _0x375375=new C(_0x1eeb0e);_0x440948=_0x3bee40['interceptServerDataCallback_']?_0x3bee40['interceptServerDataCallback_'](_0x1eeb0e,_0x440948):_0x440948;let _0x3db6b2=[];if(_0x4abade){if(_0x3f5d5f){const _0x52e8ee=_n(_0x440948,_0x15e054=>A(_0x15e054));_0x3db6b2=Ju(_0x3bee40['serverSyncTree_'],_0x375375,_0x52e8ee,_0x4abade);}else{const _0x37f0a9=A(_0x440948);_0x3db6b2=Jo(_0x3bee40['serverSyncTree_'],_0x375375,_0x37f0a9,_0x4abade);}}else{if(_0x3f5d5f){const _0x68e7b0=_n(_0x440948,_0x5a8c13=>A(_0x5a8c13));_0x3db6b2=Ku(_0x3bee40['serverSyncTree_'],_0x375375,_0x68e7b0);}else{const _0x16559=A(_0x440948);_0x3db6b2=Yt(_0x3bee40['serverSyncTree_'],_0x375375,_0x16559);}}let _0x5340d7=_0x375375;_0x3db6b2['length']>0x0&&(_0x5340d7=ct(_0x3bee40,_0x375375)),V(_0x3bee40['eventQueue_'],_0x5340d7,_0x3db6b2);}function mr(_0x18bfe3,_0x38428d){vs(_0x18bfe3,'connected',_0x38428d),_0x38428d===!0x1&&Sd(_0x18bfe3);}function Id(_0x12a91a,_0x2bb442){x(_0x2bb442,(_0x3abb6b,_0x133bf6)=>{vs(_0x12a91a,_0x3abb6b,_0x133bf6);});}function vs(_0xc6fbd0,_0x163697,_0x9fa79c){const _0x5e3aad=new C('/.info/'+_0x163697),_0x3cf6a8=A(_0x9fa79c);_0xc6fbd0['infoData_']['updateSnapshot'](_0x5e3aad,_0x3cf6a8);const _0xa30ed1=Yt(_0xc6fbd0['infoSyncTree_'],_0x5e3aad,_0x3cf6a8);V(_0xc6fbd0['eventQueue_'],_0x5e3aad,_0xa30ed1);}function zn(_0x40a3c8){return _0x40a3c8['nextWriteId_']++;}function wd(_0x5b3cd3,_0x50eadc,_0xcc25dd){const _0x49aa2e=Xu(_0x5b3cd3['serverSyncTree_'],_0x50eadc);return _0x49aa2e!=null?Promise['resolve'](_0x49aa2e):_0x5b3cd3['server_']['get'](_0x50eadc)['then'](_0x31c045=>{const _0x2e6c91=A(_0x31c045)['withIndex'](_0x50eadc['_queryParams']['getIndex']());Ni(_0x5b3cd3['serverSyncTree_'],_0x50eadc,_0xcc25dd,!0x0);let _0x59bc90;if(_0x50eadc['_queryParams']['loadsAllData']())_0x59bc90=Yt(_0x5b3cd3['serverSyncTree_'],_0x50eadc['_path'],_0x2e6c91);else{const _0x54f41e=Wt(_0x5b3cd3['serverSyncTree_'],_0x50eadc);_0x59bc90=Jo(_0x5b3cd3['serverSyncTree_'],_0x50eadc['_path'],_0x2e6c91,_0x54f41e);}return V(_0x5b3cd3['eventQueue_'],_0x50eadc['_path'],_0x59bc90),An(_0x5b3cd3['serverSyncTree_'],_0x50eadc,_0xcc25dd,null,!0x0),_0x2e6c91;},_0x2681c2=>(gt(_0x5b3cd3,'get\x20for\x20query\x20'+O(_0x50eadc)+'\x20failed:\x20'+_0x2681c2),Promise['reject'](new Error(_0x2681c2))));}function Cd(_0x4d9aef,_0x49f42e,_0x4c2cf6,_0xa8dc68,_0x511648){gt(_0x4d9aef,'set',{'path':_0x49f42e['toString'](),'value':_0x4c2cf6,'priority':_0xa8dc68});const _0x3b3a7e=Xt(_0x4d9aef),_0x56e7b3=A(_0x4c2cf6,_0xa8dc68),_0x1c7fb6=Vn(_0x4d9aef['serverSyncTree_'],_0x49f42e),_0x1398a1=fs(_0x56e7b3,_0x1c7fb6,_0x3b3a7e),_0xf1d209=zn(_0x4d9aef),_0x1b5c48=as(_0x4d9aef['serverSyncTree_'],_0x49f42e,_0x1398a1,_0xf1d209,!0x0);qn(_0x4d9aef['eventQueue_'],_0x1b5c48),_0x4d9aef['server_']['put'](_0x49f42e['toString'](),_0x56e7b3['val'](!0x0),(_0x3e6908,_0x326546)=>{const _0x26099c=_0x3e6908==='ok';_0x26099c||U('set\x20at\x20'+_0x49f42e+'\x20failed:\x20'+_0x3e6908);const _0x45d0e9=_e(_0x4d9aef['serverSyncTree_'],_0xf1d209,!_0x26099c);V(_0x4d9aef['eventQueue_'],_0x49f42e,_0x45d0e9),be(_0x4d9aef,_0x511648,_0x3e6908,_0x326546);});const _0x8a1073=Is(_0x4d9aef,_0x49f42e);ct(_0x4d9aef,_0x8a1073),V(_0x4d9aef['eventQueue_'],_0x8a1073,[]);}function Td(_0x280fe0,_0xa85c92,_0x43e084,_0x3d60e3){gt(_0x280fe0,'update',{'path':_0xa85c92['toString'](),'value':_0x43e084});let _0x585c38=!0x0;const _0x4ab1b0=Xt(_0x280fe0),_0xb1b7ae={};if(x(_0x43e084,(_0x51f599,_0x22c01c)=>{_0x585c38=!0x1,_0xb1b7ae[_0x51f599]=ta(k(_0xa85c92,_0x51f599),A(_0x22c01c),_0x280fe0['serverSyncTree_'],_0x4ab1b0);}),_0x585c38)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x280fe0,_0x3d60e3,'ok',void 0x0);else{const _0x5b030a=zn(_0x280fe0),_0x41676a=ju(_0x280fe0['serverSyncTree_'],_0xa85c92,_0xb1b7ae,_0x5b030a);qn(_0x280fe0['eventQueue_'],_0x41676a),_0x280fe0['server_']['merge'](_0xa85c92['toString'](),_0x43e084,(_0x4f5a7e,_0x4e0d87)=>{const _0x2c65ab=_0x4f5a7e==='ok';_0x2c65ab||U('update\x20at\x20'+_0xa85c92+'\x20failed:\x20'+_0x4f5a7e);const _0x2c900e=_e(_0x280fe0['serverSyncTree_'],_0x5b030a,!_0x2c65ab),_0x2015e6=_0x2c900e['length']>0x0?ct(_0x280fe0,_0xa85c92):_0xa85c92;V(_0x280fe0['eventQueue_'],_0x2015e6,_0x2c900e),be(_0x280fe0,_0x3d60e3,_0x4f5a7e,_0x4e0d87);}),x(_0x43e084,_0x6640ff=>{const _0x52c014=Is(_0x280fe0,k(_0xa85c92,_0x6640ff));ct(_0x280fe0,_0x52c014);}),V(_0x280fe0['eventQueue_'],_0xa85c92,[]);}}function Sd(_0xc2cb6a){gt(_0xc2cb6a,'onDisconnectEvents');const _0x1ca7ce=Xt(_0xc2cb6a),_0x1fc096=En();Si(_0xc2cb6a['onDisconnect_'],w(),(_0x60b9f5,_0x220865)=>{const _0x3e29e8=ta(_0x60b9f5,_0x220865,_0xc2cb6a['serverSyncTree_'],_0x1ca7ce);pt(_0x1fc096,_0x60b9f5,_0x3e29e8);});let _0x5a809d=[];Si(_0x1fc096,w(),(_0x11cc0c,_0x50b08a)=>{_0x5a809d=_0x5a809d['concat'](Yt(_0xc2cb6a['serverSyncTree_'],_0x11cc0c,_0x50b08a));const _0xb9e790=Is(_0xc2cb6a,_0x11cc0c);ct(_0xc2cb6a,_0xb9e790);}),_0xc2cb6a['onDisconnect_']=En(),V(_0xc2cb6a['eventQueue_'],w(),_0x5a809d);}function bd(_0x4a4923,_0xc6079e,_0x504645){_0x4a4923['server_']['onDisconnectCancel'](_0xc6079e['toString'](),(_0x228c3c,_0x5392d7)=>{_0x228c3c==='ok'&&Ti(_0x4a4923['onDisconnect_'],_0xc6079e),be(_0x4a4923,_0x504645,_0x228c3c,_0x5392d7);});}function yr(_0x5cd837,_0x29342e,_0x96a9c,_0x13c375){const _0x2b6fd4=A(_0x96a9c);_0x5cd837['server_']['onDisconnectPut'](_0x29342e['toString'](),_0x2b6fd4['val'](!0x0),(_0x2e1053,_0x316665)=>{_0x2e1053==='ok'&&pt(_0x5cd837['onDisconnect_'],_0x29342e,_0x2b6fd4),be(_0x5cd837,_0x13c375,_0x2e1053,_0x316665);});}function Rd(_0x37d163,_0x5ac417,_0x4d7ed1,_0x1fb6c7,_0x18ef10){const _0x28278f=A(_0x4d7ed1,_0x1fb6c7);_0x37d163['server_']['onDisconnectPut'](_0x5ac417['toString'](),_0x28278f['val'](!0x0),(_0x3db843,_0x54bdaa)=>{_0x3db843==='ok'&&pt(_0x37d163['onDisconnect_'],_0x5ac417,_0x28278f),be(_0x37d163,_0x18ef10,_0x3db843,_0x54bdaa);});}function Ad(_0x2486b,_0x14dfba,_0x5f4a1b,_0x5eff5d){if(pn(_0x5f4a1b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2486b,_0x5eff5d,'ok',void 0x0);return;}_0x2486b['server_']['onDisconnectMerge'](_0x14dfba['toString'](),_0x5f4a1b,(_0x3f65ac,_0x3c062d)=>{_0x3f65ac==='ok'&&x(_0x5f4a1b,(_0x12b079,_0x149cc5)=>{const _0x424539=A(_0x149cc5);pt(_0x2486b['onDisconnect_'],k(_0x14dfba,_0x12b079),_0x424539);}),be(_0x2486b,_0x5eff5d,_0x3f65ac,_0x3c062d);});}function kd(_0x68697f,_0x38dc67,_0x34e851){let _0x349e4c;y(_0x38dc67['_path'])==='.info'?_0x349e4c=Ni(_0x68697f['infoSyncTree_'],_0x38dc67,_0x34e851):_0x349e4c=Ni(_0x68697f['serverSyncTree_'],_0x38dc67,_0x34e851),oa(_0x68697f['eventQueue_'],_0x38dc67['_path'],_0x349e4c);}function Pd(_0x1e087a,_0x2aef4e,_0x1265c6){let _0x57623a;y(_0x2aef4e['_path'])==='.info'?_0x57623a=An(_0x1e087a['infoSyncTree_'],_0x2aef4e,_0x1265c6):_0x57623a=An(_0x1e087a['serverSyncTree_'],_0x2aef4e,_0x1265c6),oa(_0x1e087a['eventQueue_'],_0x2aef4e['_path'],_0x57623a);}function ha(_0x151705){_0x151705['persistentConnection_']&&_0x151705['persistentConnection_']['interrupt'](ca);}function Nd(_0x350048){_0x350048['persistentConnection_']&&_0x350048['persistentConnection_']['resume'](ca);}function gt(_0x15f202,..._0x464749){let _0x403fff='';_0x15f202['persistentConnection_']&&(_0x403fff=_0x15f202['persistentConnection_']['id']+':'),L(_0x403fff,..._0x464749);}function be(_0x23e299,_0x220dad,_0x52124a,_0x23caaa){_0x220dad&&ft(()=>{if(_0x52124a==='ok')_0x220dad(null);else{const _0x25271b=(_0x52124a||'error')['toUpperCase']();let _0x48de44=_0x25271b;_0x23caaa&&(_0x48de44+=':\x20'+_0x23caaa);const _0x40a823=new Error(_0x48de44);_0x40a823['code']=_0x25271b,_0x220dad(_0x40a823);}});}function Od(_0xd3db5d,_0x384e12,_0x326df2,_0x46fa88,_0x3be8fb,_0xb1cdb6){gt(_0xd3db5d,'transaction\x20on\x20'+_0x384e12);const _0x4a3ba6={'path':_0x384e12,'update':_0x326df2,'onComplete':_0x46fa88,'status':null,'order':so(),'applyLocally':_0xb1cdb6,'retryCount':0x0,'unwatcher':_0x3be8fb,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x56b1dc=Es(_0xd3db5d,_0x384e12,void 0x0);_0x4a3ba6['currentInputSnapshot']=_0x56b1dc;const _0xa584a1=_0x4a3ba6['update'](_0x56b1dc['val']());if(_0xa584a1===void 0x0)_0x4a3ba6['unwatcher'](),_0x4a3ba6['currentOutputSnapshotRaw']=null,_0x4a3ba6['currentOutputSnapshotResolved']=null,_0x4a3ba6['onComplete']&&_0x4a3ba6['onComplete'](null,!0x1,_0x4a3ba6['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0xa584a1,_0x4a3ba6['path']),_0x4a3ba6['status']=0x0;const _0x4905eb=$n(_0xd3db5d['transactionQueueTree_'],_0x384e12),_0x55d141=je(_0x4905eb)||[];_0x55d141['push'](_0x4a3ba6),gs(_0x4905eb,_0x55d141);let _0x109457;typeof _0xa584a1=='object'&&_0xa584a1!==null&&Q(_0xa584a1,'.priority')?(_0x109457=Le(_0xa584a1,'.priority'),f(Bt(_0x109457),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x109457=(Vn(_0xd3db5d['serverSyncTree_'],_0x384e12)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x16258d=Xt(_0xd3db5d),_0x19c2b4=A(_0xa584a1,_0x109457),_0x4339e0=fs(_0x19c2b4,_0x56b1dc,_0x16258d);_0x4a3ba6['currentOutputSnapshotRaw']=_0x19c2b4,_0x4a3ba6['currentOutputSnapshotResolved']=_0x4339e0,_0x4a3ba6['currentWriteId']=zn(_0xd3db5d);const _0x121a5a=as(_0xd3db5d['serverSyncTree_'],_0x384e12,_0x4339e0,_0x4a3ba6['currentWriteId'],_0x4a3ba6['applyLocally']);V(_0xd3db5d['eventQueue_'],_0x384e12,_0x121a5a),jn(_0xd3db5d,_0xd3db5d['transactionQueueTree_']);}}function Es(_0x5b30d4,_0x44824c,_0x5c9c28){return Vn(_0x5b30d4['serverSyncTree_'],_0x44824c,_0x5c9c28)||g['EMPTY_NODE'];}function jn(_0x202579,_0x3d8d32=_0x202579['transactionQueueTree_']){if(_0x3d8d32||Kn(_0x202579,_0x3d8d32),je(_0x3d8d32)){const _0x2cfbad=da(_0x202579,_0x3d8d32);f(_0x2cfbad['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2cfbad['every'](_0x1d91ce=>_0x1d91ce['status']===0x0)&&Dd(_0x202579,Qt(_0x3d8d32),_0x2cfbad);}else na(_0x3d8d32)&&Gn(_0x3d8d32,_0xaf8055=>{jn(_0x202579,_0xaf8055);});}function Dd(_0x3425ba,_0x5a413c,_0x54714d){const _0xa8acc3=_0x54714d['map'](_0x292586=>_0x292586['currentWriteId']),_0x29ac4f=Es(_0x3425ba,_0x5a413c,_0xa8acc3);let _0x233aec=_0x29ac4f;const _0x5a305e=_0x29ac4f['hash']();for(let _0x37ce0b=0x0;_0x37ce0b<_0x54714d['length'];_0x37ce0b++){const _0x376dba=_0x54714d[_0x37ce0b];f(_0x376dba['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x376dba['status']=0x1,_0x376dba['retryCount']++;const _0x54b313=F(_0x5a413c,_0x376dba['path']);_0x233aec=_0x233aec['updateChild'](_0x54b313,_0x376dba['currentOutputSnapshotRaw']);}const _0x3259cf=_0x233aec['val'](!0x0),_0x43586f=_0x5a413c;_0x3425ba['server_']['put'](_0x43586f['toString'](),_0x3259cf,_0x1aaccf=>{gt(_0x3425ba,'transaction\x20put\x20response',{'path':_0x43586f['toString'](),'status':_0x1aaccf});let _0x4c9128=[];if(_0x1aaccf==='ok'){const _0x3bafb5=[];for(let _0x5004f0=0x0;_0x5004f0<_0x54714d['length'];_0x5004f0++)_0x54714d[_0x5004f0]['status']=0x2,_0x4c9128=_0x4c9128['concat'](_e(_0x3425ba['serverSyncTree_'],_0x54714d[_0x5004f0]['currentWriteId'])),_0x54714d[_0x5004f0]['onComplete']&&_0x3bafb5['push'](()=>_0x54714d[_0x5004f0]['onComplete'](null,!0x0,_0x54714d[_0x5004f0]['currentOutputSnapshotResolved'])),_0x54714d[_0x5004f0]['unwatcher']();Kn(_0x3425ba,$n(_0x3425ba['transactionQueueTree_'],_0x5a413c)),jn(_0x3425ba,_0x3425ba['transactionQueueTree_']),V(_0x3425ba['eventQueue_'],_0x5a413c,_0x4c9128);for(let _0x1d1e4e=0x0;_0x1d1e4e<_0x3bafb5['length'];_0x1d1e4e++)ft(_0x3bafb5[_0x1d1e4e]);}else{if(_0x1aaccf==='datastale'){for(let _0x42f586=0x0;_0x42f586<_0x54714d['length'];_0x42f586++)_0x54714d[_0x42f586]['status']===0x3?_0x54714d[_0x42f586]['status']=0x4:_0x54714d[_0x42f586]['status']=0x0;}else{U('transaction\x20at\x20'+_0x43586f['toString']()+'\x20failed:\x20'+_0x1aaccf);for(let _0x4fdb7b=0x0;_0x4fdb7b<_0x54714d['length'];_0x4fdb7b++)_0x54714d[_0x4fdb7b]['status']=0x4,_0x54714d[_0x4fdb7b]['abortReason']=_0x1aaccf;}ct(_0x3425ba,_0x5a413c);}},_0x5a305e);}function ct(_0x34d943,_0x591003){const _0x26119a=ua(_0x34d943,_0x591003),_0x2f4343=Qt(_0x26119a),_0x58d981=da(_0x34d943,_0x26119a);return Md(_0x34d943,_0x58d981,_0x2f4343),_0x2f4343;}function Md(_0x114cd8,_0x4c4a34,_0x46293f){if(_0x4c4a34['length']===0x0)return;const _0x354408=[];let _0xe1aeff=[];const _0x419990=_0x4c4a34['filter'](_0x501a68=>_0x501a68['status']===0x0)['map'](_0x3c4d68=>_0x3c4d68['currentWriteId']);for(let _0xd868f5=0x0;_0xd868f5<_0x4c4a34['length'];_0xd868f5++){const _0x3f8daa=_0x4c4a34[_0xd868f5],_0x57050a=F(_0x46293f,_0x3f8daa['path']);let _0x1180e3=!0x1,_0x45ce60;if(f(_0x57050a!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3f8daa['status']===0x4)_0x1180e3=!0x0,_0x45ce60=_0x3f8daa['abortReason'],_0xe1aeff=_0xe1aeff['concat'](_e(_0x114cd8['serverSyncTree_'],_0x3f8daa['currentWriteId'],!0x0));else{if(_0x3f8daa['status']===0x0){if(_0x3f8daa['retryCount']>=yd)_0x1180e3=!0x0,_0x45ce60='maxretry',_0xe1aeff=_0xe1aeff['concat'](_e(_0x114cd8['serverSyncTree_'],_0x3f8daa['currentWriteId'],!0x0));else{const _0x2a57d4=Es(_0x114cd8,_0x3f8daa['path'],_0x419990);_0x3f8daa['currentInputSnapshot']=_0x2a57d4;const _0x41131f=_0x4c4a34[_0xd868f5]['update'](_0x2a57d4['val']());if(_0x41131f!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x41131f,_0x3f8daa['path']);let _0x10fcb9=A(_0x41131f);typeof _0x41131f=='object'&&_0x41131f!=null&&Q(_0x41131f,'.priority')||(_0x10fcb9=_0x10fcb9['updatePriority'](_0x2a57d4['getPriority']()));const _0x5e7a87=_0x3f8daa['currentWriteId'],_0x5c3d80=Xt(_0x114cd8),_0x548da1=fs(_0x10fcb9,_0x2a57d4,_0x5c3d80);_0x3f8daa['currentOutputSnapshotRaw']=_0x10fcb9,_0x3f8daa['currentOutputSnapshotResolved']=_0x548da1,_0x3f8daa['currentWriteId']=zn(_0x114cd8),_0x419990['splice'](_0x419990['indexOf'](_0x5e7a87),0x1),_0xe1aeff=_0xe1aeff['concat'](as(_0x114cd8['serverSyncTree_'],_0x3f8daa['path'],_0x548da1,_0x3f8daa['currentWriteId'],_0x3f8daa['applyLocally'])),_0xe1aeff=_0xe1aeff['concat'](_e(_0x114cd8['serverSyncTree_'],_0x5e7a87,!0x0));}else _0x1180e3=!0x0,_0x45ce60='nodata',_0xe1aeff=_0xe1aeff['concat'](_e(_0x114cd8['serverSyncTree_'],_0x3f8daa['currentWriteId'],!0x0));}}}V(_0x114cd8['eventQueue_'],_0x46293f,_0xe1aeff),_0xe1aeff=[],_0x1180e3&&(_0x4c4a34[_0xd868f5]['status']=0x2,function(_0x45cd92){setTimeout(_0x45cd92,Math['floor'](0x0));}(_0x4c4a34[_0xd868f5]['unwatcher']),_0x4c4a34[_0xd868f5]['onComplete']&&(_0x45ce60==='nodata'?_0x354408['push'](()=>_0x4c4a34[_0xd868f5]['onComplete'](null,!0x1,_0x4c4a34[_0xd868f5]['currentInputSnapshot'])):_0x354408['push'](()=>_0x4c4a34[_0xd868f5]['onComplete'](new Error(_0x45ce60),!0x1,null))));}Kn(_0x114cd8,_0x114cd8['transactionQueueTree_']);for(let _0x4d56e0=0x0;_0x4d56e0<_0x354408['length'];_0x4d56e0++)ft(_0x354408[_0x4d56e0]);jn(_0x114cd8,_0x114cd8['transactionQueueTree_']);}function ua(_0x52a6d8,_0x15388f){let _0x292ffb,_0x56f767=_0x52a6d8['transactionQueueTree_'];for(_0x292ffb=y(_0x15388f);_0x292ffb!==null&&je(_0x56f767)===void 0x0;)_0x56f767=$n(_0x56f767,_0x292ffb),_0x15388f=S(_0x15388f),_0x292ffb=y(_0x15388f);return _0x56f767;}function da(_0x41a4f7,_0xc68a09){const _0x1c0f3b=[];return fa(_0x41a4f7,_0xc68a09,_0x1c0f3b),_0x1c0f3b['sort']((_0x2e8157,_0x914d35)=>_0x2e8157['order']-_0x914d35['order']),_0x1c0f3b;}function fa(_0x35135b,_0x59f9b5,_0x45556a){const _0x18bf9a=je(_0x59f9b5);if(_0x18bf9a){for(let _0x14097c=0x0;_0x14097c<_0x18bf9a['length'];_0x14097c++)_0x45556a['push'](_0x18bf9a[_0x14097c]);}Gn(_0x59f9b5,_0x353ae9=>{fa(_0x35135b,_0x353ae9,_0x45556a);});}function Kn(_0x3565ec,_0x29b918){const _0x327f6e=je(_0x29b918);if(_0x327f6e){let _0x34b512=0x0;for(let _0x13298b=0x0;_0x13298b<_0x327f6e['length'];_0x13298b++)_0x327f6e[_0x13298b]['status']!==0x2&&(_0x327f6e[_0x34b512]=_0x327f6e[_0x13298b],_0x34b512++);_0x327f6e['length']=_0x34b512,gs(_0x29b918,_0x327f6e['length']>0x0?_0x327f6e:void 0x0);}Gn(_0x29b918,_0x518df9=>{Kn(_0x3565ec,_0x518df9);});}function Is(_0x2ed15a,_0x4c8adf){const _0x17ea5e=Qt(ua(_0x2ed15a,_0x4c8adf)),_0x2faebf=$n(_0x2ed15a['transactionQueueTree_'],_0x4c8adf);return ad(_0x2faebf,_0x15b1b8=>{di(_0x2ed15a,_0x15b1b8);}),di(_0x2ed15a,_0x2faebf),ia(_0x2faebf,_0xea795b=>{di(_0x2ed15a,_0xea795b);}),_0x17ea5e;}function di(_0x54cc7e,_0x259557){const _0x92ed9e=je(_0x259557);if(_0x92ed9e){const _0x40ff0b=[];let _0x37f30e=[],_0x158b8e=-0x1;for(let _0xcc4575=0x0;_0xcc4575<_0x92ed9e['length'];_0xcc4575++)_0x92ed9e[_0xcc4575]['status']===0x3||(_0x92ed9e[_0xcc4575]['status']===0x1?(f(_0x158b8e===_0xcc4575-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x158b8e=_0xcc4575,_0x92ed9e[_0xcc4575]['status']=0x3,_0x92ed9e[_0xcc4575]['abortReason']='set'):(f(_0x92ed9e[_0xcc4575]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x92ed9e[_0xcc4575]['unwatcher'](),_0x37f30e=_0x37f30e['concat'](_e(_0x54cc7e['serverSyncTree_'],_0x92ed9e[_0xcc4575]['currentWriteId'],!0x0)),_0x92ed9e[_0xcc4575]['onComplete']&&_0x40ff0b['push'](_0x92ed9e[_0xcc4575]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x158b8e===-0x1?gs(_0x259557,void 0x0):_0x92ed9e['length']=_0x158b8e+0x1,V(_0x54cc7e['eventQueue_'],Qt(_0x259557),_0x37f30e);for(let _0x5c3b99=0x0;_0x5c3b99<_0x40ff0b['length'];_0x5c3b99++)ft(_0x40ff0b[_0x5c3b99]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4dd2c9){let _0x26af78='';const _0x1911be=_0x4dd2c9['split']('/');for(let _0x3f4fcb=0x0;_0x3f4fcb<_0x1911be['length'];_0x3f4fcb++)if(_0x1911be[_0x3f4fcb]['length']>0x0){let _0x105aea=_0x1911be[_0x3f4fcb];try{_0x105aea=decodeURIComponent(_0x105aea['replace'](/\+/g,'\x20'));}catch{}_0x26af78+='/'+_0x105aea;}return _0x26af78;}function xd(_0x55731a){const _0x370892={};_0x55731a['charAt'](0x0)==='?'&&(_0x55731a=_0x55731a['substring'](0x1));for(const _0x3a2f90 of _0x55731a['split']('&')){if(_0x3a2f90['length']===0x0)continue;const _0x4a89b7=_0x3a2f90['split']('=');_0x4a89b7['length']===0x2?_0x370892[decodeURIComponent(_0x4a89b7[0x0])]=decodeURIComponent(_0x4a89b7[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3a2f90+'\x27\x20in\x20query\x20\x27'+_0x55731a+'\x27');}return _0x370892;}const vr=function(_0x3d978e,_0x552551){const _0x982dbd=Fd(_0x3d978e),_0x503062=_0x982dbd['namespace'];_0x982dbd['domain']==='firebase.com'&&ae(_0x982dbd['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x503062||_0x503062==='undefined')&&_0x982dbd['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x982dbd['secure']||$l();const _0x2d3fdf=_0x982dbd['scheme']==='ws'||_0x982dbd['scheme']==='wss';return{'repoInfo':new yo(_0x982dbd['host'],_0x982dbd['secure'],_0x503062,_0x2d3fdf,_0x552551,'',_0x503062!==_0x982dbd['subdomain']),'path':new C(_0x982dbd['pathString'])};},Fd=function(_0x40097a){let _0x3e53cd='',_0x465812='',_0x4dc54a='',_0x246293='',_0x3a5829='',_0x196a77=!0x0,_0xce3a94='https',_0x19a552=0x1bb;if(typeof _0x40097a=='string'){let _0x2423e8=_0x40097a['indexOf']('//');_0x2423e8>=0x0&&(_0xce3a94=_0x40097a['substring'](0x0,_0x2423e8-0x1),_0x40097a=_0x40097a['substring'](_0x2423e8+0x2));let _0x457f12=_0x40097a['indexOf']('/');_0x457f12===-0x1&&(_0x457f12=_0x40097a['length']);let _0x3225cc=_0x40097a['indexOf']('?');_0x3225cc===-0x1&&(_0x3225cc=_0x40097a['length']),_0x3e53cd=_0x40097a['substring'](0x0,Math['min'](_0x457f12,_0x3225cc)),_0x457f12<_0x3225cc&&(_0x246293=Ld(_0x40097a['substring'](_0x457f12,_0x3225cc)));const _0xec39f6=xd(_0x40097a['substring'](Math['min'](_0x40097a['length'],_0x3225cc)));_0x2423e8=_0x3e53cd['indexOf'](':'),_0x2423e8>=0x0?(_0x196a77=_0xce3a94==='https'||_0xce3a94==='wss',_0x19a552=parseInt(_0x3e53cd['substring'](_0x2423e8+0x1),0xa)):_0x2423e8=_0x3e53cd['length'];const _0x46bcf3=_0x3e53cd['slice'](0x0,_0x2423e8);if(_0x46bcf3['toLowerCase']()==='localhost')_0x465812='localhost';else{if(_0x46bcf3['split']('.')['length']<=0x2)_0x465812=_0x46bcf3;else{const _0x2fcfe6=_0x3e53cd['indexOf']('.');_0x4dc54a=_0x3e53cd['substring'](0x0,_0x2fcfe6)['toLowerCase'](),_0x465812=_0x3e53cd['substring'](_0x2fcfe6+0x1),_0x3a5829=_0x4dc54a;}}'ns'in _0xec39f6&&(_0x3a5829=_0xec39f6['ns']);}return{'host':_0x3e53cd,'port':_0x19a552,'domain':_0x465812,'subdomain':_0x4dc54a,'secure':_0x196a77,'scheme':_0xce3a94,'pathString':_0x246293,'namespace':_0x3a5829};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x20ff09=0x0;const _0x352d14=[];return function(_0xf65ac7){const _0x1a2d18=_0xf65ac7===_0x20ff09;_0x20ff09=_0xf65ac7;let _0x469c44;const _0x2b2da3=new Array(0x8);for(_0x469c44=0x7;_0x469c44>=0x0;_0x469c44--)_0x2b2da3[_0x469c44]=Er['charAt'](_0xf65ac7%0x40),_0xf65ac7=Math['floor'](_0xf65ac7/0x40);f(_0xf65ac7===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1c2d6f=_0x2b2da3['join']('');if(_0x1a2d18){for(_0x469c44=0xb;_0x469c44>=0x0&&_0x352d14[_0x469c44]===0x3f;_0x469c44--)_0x352d14[_0x469c44]=0x0;_0x352d14[_0x469c44]++;}else{for(_0x469c44=0x0;_0x469c44<0xc;_0x469c44++)_0x352d14[_0x469c44]=Math['floor'](Math['random']()*0x40);}for(_0x469c44=0x0;_0x469c44<0xc;_0x469c44++)_0x1c2d6f+=Er['charAt'](_0x352d14[_0x469c44]);return f(_0x1c2d6f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1c2d6f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x44b9ef,_0x566f8f,_0x452d5a,_0x3ef21d){this['eventType']=_0x44b9ef,this['eventRegistration']=_0x566f8f,this['snapshot']=_0x452d5a,this['prevName']=_0x3ef21d;}['getPath'](){const _0x545a18=this['snapshot']['ref'];return this['eventType']==='value'?_0x545a18['_path']:_0x545a18['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x17919f,_0x53b472,_0xa1bd7d){this['eventRegistration']=_0x17919f,this['error']=_0x53b472,this['path']=_0xa1bd7d;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x101c7e,_0x172618){this['snapshotCallback']=_0x101c7e,this['cancelCallback']=_0x172618;}['onValue'](_0x3d084a,_0x5e1c92){this['snapshotCallback']['call'](null,_0x3d084a,_0x5e1c92);}['onCancel'](_0x33e9a8){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x33e9a8);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x150dad){return this['snapshotCallback']===_0x150dad['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x150dad['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x150dad['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x293991,_0xa7d883){this['_repo']=_0x293991,this['_path']=_0xa7d883;}['cancel'](){const _0x188c72=new H();return bd(this['_repo'],this['_path'],_0x188c72['wrapCallback'](()=>{})),_0x188c72['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x43316a=new H();return yr(this['_repo'],this['_path'],null,_0x43316a['wrapCallback'](()=>{})),_0x43316a['promise'];}['set'](_0x425ef0){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x425ef0,this['_path'],!0x1);const _0xacce56=new H();return yr(this['_repo'],this['_path'],_0x425ef0,_0xacce56['wrapCallback'](()=>{})),_0xacce56['promise'];}['setWithPriority'](_0x9eef82,_0x397b37){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x9eef82,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x397b37);const _0x19f699=new H();return Rd(this['_repo'],this['_path'],_0x9eef82,_0x397b37,_0x19f699['wrapCallback'](()=>{})),_0x19f699['promise'];}['update'](_0x1c03ad){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1c03ad,this['_path']);const _0x25c246=new H();return Ad(this['_repo'],this['_path'],_0x1c03ad,_0x25c246['wrapCallback'](()=>{})),_0x25c246['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x3f8eb8,_0x221b19,_0x3907ee,_0x4eecf2){this['_repo']=_0x3f8eb8,this['_path']=_0x221b19,this['_queryParams']=_0x3907ee,this['_orderByCalled']=_0x4eecf2;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x1a5c4c=sr(this['_queryParams']),_0x25c796=$i(_0x1a5c4c);return _0x25c796==='{}'?'default':_0x25c796;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x31918b){if(_0x31918b=P(_0x31918b),!(_0x31918b instanceof Ae))return!0x1;const _0x1c0f26=this['_repo']===_0x31918b['_repo'],_0x137fb8=Ki(this['_path'],_0x31918b['_path']),_0x3c8f9b=this['_queryIdentifier']===_0x31918b['_queryIdentifier'];return _0x1c0f26&&_0x137fb8&&_0x3c8f9b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1a51ad,_0x21826b){if(_0x1a51ad['_orderByCalled']===!0x0)throw new Error(_0x21826b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x252d07){let _0x573df4=null,_0x181d27=null;if(_0x252d07['hasStart']()&&(_0x573df4=_0x252d07['getIndexStartValue']()),_0x252d07['hasEnd']()&&(_0x181d27=_0x252d07['getIndexEndValue']()),_0x252d07['getIndex']()===ve){const _0x469bdc='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4c6e5e='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x252d07['hasStart']()){if(_0x252d07['getIndexStartName']()!==We)throw new Error(_0x469bdc);if(typeof _0x573df4!='string')throw new Error(_0x4c6e5e);}if(_0x252d07['hasEnd']()){if(_0x252d07['getIndexEndName']()!==we)throw new Error(_0x469bdc);if(typeof _0x181d27!='string')throw new Error(_0x4c6e5e);}}else{if(_0x252d07['getIndex']()===R){if(_0x573df4!=null&&!Bt(_0x573df4)||_0x181d27!=null&&!Bt(_0x181d27))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x252d07['getIndex']()instanceof Ji||_0x252d07['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x573df4!=null&&typeof _0x573df4=='object'||_0x181d27!=null&&typeof _0x181d27=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x201dd2){if(_0x201dd2['hasStart']()&&_0x201dd2['hasEnd']()&&_0x201dd2['hasLimit']()&&!_0x201dd2['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5eb413,_0x3deb34){super(_0x5eb413,_0x3deb34,new Zi(),!0x1);}get['parent'](){const _0x3fddc1=Ro(this['_path']);return _0x3fddc1===null?null:new ee(this['_repo'],_0x3fddc1);}get['root'](){let _0x3b1405=this;for(;_0x3b1405['parent']!==null;)_0x3b1405=_0x3b1405['parent'];return _0x3b1405;}}class lt{constructor(_0x4fc369,_0x42b24c,_0x23e0c9){this['_node']=_0x4fc369,this['ref']=_0x42b24c,this['_index']=_0x23e0c9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x104541){const _0x437cd8=new C(_0x104541),_0x290518=Vt(this['ref'],_0x104541);return new lt(this['_node']['getChild'](_0x437cd8),_0x290518,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x128d9c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4dce01,_0x50a020)=>_0x128d9c(new lt(_0x50a020,Vt(this['ref'],_0x4dce01),R)));}['hasChild'](_0x397097){const _0xc3efa4=new C(_0x397097);return!this['_node']['getChild'](_0xc3efa4)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x32ed5c,_0x1db998){return _0x32ed5c=P(_0x32ed5c),_0x32ed5c['_checkNotDeleted']('ref'),_0x1db998!==void 0x0?Vt(_0x32ed5c['_root'],_0x1db998):_0x32ed5c['_root'];}function Vt(_0x355e55,_0x4cdfc6){return _0x355e55=P(_0x355e55),y(_0x355e55['_path'])===null?pd('child','path',_0x4cdfc6):ys('child','path',_0x4cdfc6),new ee(_0x355e55['_repo'],k(_0x355e55['_path'],_0x4cdfc6));}function v_(_0x182dae){return _0x182dae=P(_0x182dae),new Vd(_0x182dae['_repo'],_0x182dae['_path']);}function E_(_0x27e33d,_0x33c69e){_0x27e33d=P(_0x27e33d),Me('push',_0x27e33d['_path']),He('push',_0x33c69e,_0x27e33d['_path'],!0x0);const _0x3f7f94=la(_0x27e33d['_repo']),_0x158ca8=Ud(_0x3f7f94),_0x409324=Vt(_0x27e33d,_0x158ca8),_0x265fdc=Vt(_0x27e33d,_0x158ca8);let _0x5315a1;return _0x33c69e!=null?_0x5315a1=Hd(_0x265fdc,_0x33c69e)['then'](()=>_0x265fdc):_0x5315a1=Promise['resolve'](_0x265fdc),_0x409324['then']=_0x5315a1['then']['bind'](_0x5315a1),_0x409324['catch']=_0x5315a1['then']['bind'](_0x5315a1,void 0x0),_0x409324;}function Hd(_0xe1de5,_0x4ebec5){_0xe1de5=P(_0xe1de5),Me('set',_0xe1de5['_path']),He('set',_0x4ebec5,_0xe1de5['_path'],!0x1);const _0x3c8358=new H();return Cd(_0xe1de5['_repo'],_0xe1de5['_path'],_0x4ebec5,null,_0x3c8358['wrapCallback'](()=>{})),_0x3c8358['promise'];}function I_(_0x585ef4,_0x393fa3){ra('update',_0x393fa3,_0x585ef4['_path']);const _0x455a34=new H();return Td(_0x585ef4['_repo'],_0x585ef4['_path'],_0x393fa3,_0x455a34['wrapCallback'](()=>{})),_0x455a34['promise'];}function w_(_0x339c4b){_0x339c4b=P(_0x339c4b);const _0x1f7410=new pa(()=>{}),_0x315e8d=new Qn(_0x1f7410);return wd(_0x339c4b['_repo'],_0x339c4b,_0x315e8d)['then'](_0x41cc06=>new lt(_0x41cc06,new ee(_0x339c4b['_repo'],_0x339c4b['_path']),_0x339c4b['_queryParams']['getIndex']()));}class Qn{constructor(_0x5ee540){this['callbackContext']=_0x5ee540;}['respondsTo'](_0x434b2a){return _0x434b2a==='value';}['createEvent'](_0x28ee7f,_0x284751){const _0x2f2b9b=_0x284751['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x28ee7f['snapshotNode'],new ee(_0x284751['_repo'],_0x284751['_path']),_0x2f2b9b));}['getEventRunner'](_0x4cdab0){return _0x4cdab0['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4cdab0['error']):()=>this['callbackContext']['onValue'](_0x4cdab0['snapshot'],null);}['createCancelEvent'](_0x3f64b7,_0x3b8eec){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x3f64b7,_0x3b8eec):null;}['matches'](_0x124bfa){return _0x124bfa instanceof Qn?!_0x124bfa['callbackContext']||!this['callbackContext']?!0x0:_0x124bfa['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x39c297,_0x25ea6c,_0x5c1467,_0xebeacb,_0x356771){const _0x2d7caa=new pa(_0x5c1467,void 0x0),_0x24f677=new Qn(_0x2d7caa);return kd(_0x39c297['_repo'],_0x39c297,_0x24f677),()=>Pd(_0x39c297['_repo'],_0x39c297,_0x24f677);}function Gd(_0x40006a,_0x4a1d2e,_0x11b9a9,_0x2178ac){return $d(_0x40006a,'value',_0x4a1d2e);}class mt{}class ma extends mt{constructor(_0xbc6de9,_0x1d74a2){super(),this['_value']=_0xbc6de9,this['_key']=_0x1d74a2,this['type']='endAt';}['_apply'](_0x4c8c2e){He('endAt',this['_value'],_0x4c8c2e['_path'],!0x0);const _0x1df804=Jh(_0x4c8c2e['_queryParams'],this['_value'],this['_key']);if(ga(_0x1df804),Yn(_0x1df804),_0x4c8c2e['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x4c8c2e['_repo'],_0x4c8c2e['_path'],_0x1df804,_0x4c8c2e['_orderByCalled']);}}function C_(_0x23894e,_0x509ef2){return new ma(_0x23894e,_0x509ef2);}class ya extends mt{constructor(_0x58d7b5,_0x585152){super(),this['_value']=_0x58d7b5,this['_key']=_0x585152,this['type']='startAt';}['_apply'](_0x57d905){He('startAt',this['_value'],_0x57d905['_path'],!0x0);const _0x4d176c=Qh(_0x57d905['_queryParams'],this['_value'],this['_key']);if(ga(_0x4d176c),Yn(_0x4d176c),_0x57d905['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x57d905['_repo'],_0x57d905['_path'],_0x4d176c,_0x57d905['_orderByCalled']);}}function T_(_0x3c0b56=null,_0x5441dd){return new ya(_0x3c0b56,_0x5441dd);}class qd extends mt{constructor(_0x22b60a){super(),this['_limit']=_0x22b60a,this['type']='limitToFirst';}['_apply'](_0xfed6f7){if(_0xfed6f7['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0xfed6f7['_repo'],_0xfed6f7['_path'],Yh(_0xfed6f7['_queryParams'],this['_limit']),_0xfed6f7['_orderByCalled']);}}function S_(_0x1fd883){if(Math['floor'](_0x1fd883)!==_0x1fd883||_0x1fd883<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x1fd883);}class zd extends mt{constructor(_0x491314){super(),this['_path']=_0x491314,this['type']='orderByChild';}['_apply'](_0xc3aebe){_a(_0xc3aebe,'orderByChild');const _0x1ddb9c=new C(this['_path']);if(v(_0x1ddb9c))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3a5607=new Ji(_0x1ddb9c),_0x251f52=xo(_0xc3aebe['_queryParams'],_0x3a5607);return Yn(_0x251f52),new Ae(_0xc3aebe['_repo'],_0xc3aebe['_path'],_0x251f52,!0x0);}}function b_(_0x17c733){if(_0x17c733==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x17c733==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x17c733==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x17c733),new zd(_0x17c733);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x64b3b4){_a(_0x64b3b4,'orderByKey');const _0x22502f=xo(_0x64b3b4['_queryParams'],ve);return Yn(_0x22502f),new Ae(_0x64b3b4['_repo'],_0x64b3b4['_path'],_0x22502f,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x124573,_0x3cc85f){super(),this['_value']=_0x124573,this['_key']=_0x3cc85f,this['type']='equalTo';}['_apply'](_0x43d4f3){if(He('equalTo',this['_value'],_0x43d4f3['_path'],!0x1),_0x43d4f3['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x43d4f3['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x43d4f3));}}function A_(_0x4e2a62,_0x5cdb70){return new Kd(_0x4e2a62,_0x5cdb70);}function k_(_0x148dbc,..._0x5e7f2b){let _0x5bcce2=P(_0x148dbc);for(const _0x37ced1 of _0x5e7f2b)_0x5bcce2=_0x37ced1['_apply'](_0x5bcce2);return _0x5bcce2;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x280abc,_0x21ab9b,_0x358e9b,_0x166eb2){const _0x47b14b=_0x21ab9b['lastIndexOf'](':'),_0x4fb8d3=_0x21ab9b['substring'](0x0,_0x47b14b),_0x672d6a=qt(_0x4fb8d3);_0x280abc['repoInfo_']=new yo(_0x21ab9b,_0x672d6a,_0x280abc['repoInfo_']['namespace'],_0x280abc['repoInfo_']['webSocketOnly'],_0x280abc['repoInfo_']['nodeAdmin'],_0x280abc['repoInfo_']['persistenceKey'],_0x280abc['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x358e9b),_0x166eb2&&(_0x280abc['authTokenProvider_']=_0x166eb2);}function Xd(_0x1df32a,_0x1c6c15,_0x16fea5,_0x441a82,_0x5ebcce){let _0x2bd0d0=_0x441a82||_0x1df32a['options']['databaseURL'];_0x2bd0d0===void 0x0&&(_0x1df32a['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1df32a['options']['projectId']),_0x2bd0d0=_0x1df32a['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x356bb9=vr(_0x2bd0d0,_0x5ebcce),_0x370480=_0x356bb9['repoInfo'],_0x376f53;typeof process<'u'&&Bs&&(_0x376f53=Bs[Yd]),_0x376f53?(_0x2bd0d0='http://'+_0x376f53+'?ns='+_0x370480['namespace'],_0x356bb9=vr(_0x2bd0d0,_0x5ebcce),_0x370480=_0x356bb9['repoInfo']):_0x356bb9['repoInfo']['secure'];const _0x617aad=new eh(_0x1df32a['name'],_0x1df32a['options'],_0x1c6c15);_d('Invalid\x20Firebase\x20Database\x20URL',_0x356bb9),v(_0x356bb9['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x296333=ef(_0x370480,_0x1df32a,_0x617aad,new Zl(_0x1df32a,_0x16fea5));return new tf(_0x296333,_0x1df32a);}function Zd(_0x3b20bd,_0x168957){const _0x12a7e0=Di[_0x168957];(!_0x12a7e0||_0x12a7e0[_0x3b20bd['key']]!==_0x3b20bd)&&ae('Database\x20'+_0x168957+'('+_0x3b20bd['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x3b20bd),delete _0x12a7e0[_0x3b20bd['key']];}function ef(_0x130367,_0x334426,_0x1f9b07,_0x17c044){let _0x106464=Di[_0x334426['name']];_0x106464||(_0x106464={},Di[_0x334426['name']]=_0x106464);let _0x26535c=_0x106464[_0x130367['toURLString']()];return _0x26535c&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x26535c=new vd(_0x130367,Qd,_0x1f9b07,_0x17c044),_0x106464[_0x130367['toURLString']()]=_0x26535c,_0x26535c;}class tf{constructor(_0x8d2d08,_0x1cd1f7){this['_repoInternal']=_0x8d2d08,this['app']=_0x1cd1f7,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x16533a){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x16533a+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x464d61=Zr(),_0x1a537d){const _0x1f1756=Hi(_0x464d61,'database')['getImmediate']({'identifier':_0x1a537d});if(!_0x1f1756['_instanceStarted']){const _0x13a3c1=hc('database');_0x13a3c1&&nf(_0x1f1756,..._0x13a3c1);}return _0x1f1756;}function nf(_0x113396,_0x5b1a12,_0x48bba4,_0x23959b={}){_0x113396=P(_0x113396),_0x113396['_checkNotDeleted']('useEmulator');const _0x553ae2=_0x5b1a12+':'+_0x48bba4,_0x5cbab7=_0x113396['_repoInternal'];if(_0x113396['_instanceStarted']){if(_0x553ae2===_0x113396['_repoInternal']['repoInfo_']['host']&&xe(_0x23959b,_0x5cbab7['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x56f79c;if(_0x5cbab7['repoInfo_']['nodeAdmin'])_0x23959b['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x56f79c=new an(an['OWNER']);else{if(_0x23959b['mockUserToken']){const _0x16f8e6=typeof _0x23959b['mockUserToken']=='string'?_0x23959b['mockUserToken']:uc(_0x23959b['mockUserToken'],_0x113396['app']['options']['projectId']);_0x56f79c=new an(_0x16f8e6);}}qt(_0x5b1a12)&&Qr(_0x5b1a12),Jd(_0x5cbab7,_0x553ae2,_0x23959b,_0x56f79c);}function N_(_0x51ec70){_0x51ec70=P(_0x51ec70),_0x51ec70['_checkNotDeleted']('goOffline'),ha(_0x51ec70['_repo']);}function O_(_0x46ccc4){_0x46ccc4=P(_0x46ccc4),_0x46ccc4['_checkNotDeleted']('goOnline'),Nd(_0x46ccc4['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x2ee189){Ul(dt),st(new Fe('database',(_0xca75a8,{instanceIdentifier:_0x4ae0ad})=>{const _0x2754c3=_0xca75a8['getProvider']('app')['getImmediate'](),_0x14c35a=_0xca75a8['getProvider']('auth-internal'),_0xac14ed=_0xca75a8['getProvider']('app-check-internal');return Xd(_0x2754c3,_0x14c35a,_0xac14ed,_0x4ae0ad);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x2ee189),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x16efa1,_0x3cc120){this['committed']=_0x16efa1,this['snapshot']=_0x3cc120;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x1e90a2,_0x1ef8ae,_0x5d291f){if(_0x1e90a2=P(_0x1e90a2),Me('Reference.transaction',_0x1e90a2['_path']),_0x1e90a2['key']==='.length'||_0x1e90a2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x1e90a2['key']+'\x20is\x20a\x20read-only\x20object.';const _0xdf5eea=!0x0,_0x5dee6b=new H(),_0x28d204=(_0x24f7c8,_0x422755,_0x2e266d)=>{let _0x3f51b3=null;_0x24f7c8?_0x5dee6b['reject'](_0x24f7c8):(_0x3f51b3=new lt(_0x2e266d,new ee(_0x1e90a2['_repo'],_0x1e90a2['_path']),R),_0x5dee6b['resolve'](new of(_0x422755,_0x3f51b3)));},_0x1eae9c=Gd(_0x1e90a2,()=>{});return Od(_0x1e90a2['_repo'],_0x1e90a2['_path'],_0x1ef8ae,_0x28d204,_0x1eae9c,_0xdf5eea),_0x5dee6b['promise'];}se['prototype']['simpleListen']=function(_0x3d7be6,_0x193882){this['sendRequest']('q',{'p':_0x3d7be6},_0x193882);},se['prototype']['echo']=function(_0x50c46e,_0x26ab85){this['sendRequest']('echo',{'d':_0x50c46e},_0x26ab85);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5cee90,..._0x3872ee){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5cee90,..._0x3872ee);}function cn(_0xe8d28d,..._0x4a8c7a){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0xe8d28d,..._0x4a8c7a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1991a6,..._0x416e9e){throw ws(_0x1991a6,..._0x416e9e);}function X(_0xe06acb,..._0x30e757){return ws(_0xe06acb,..._0x30e757);}function Ia(_0x3eb821,_0x3e2e1d,_0x197c61){const _0x2d53ad={...af(),[_0x3e2e1d]:_0x197c61};return new Gt('auth','Firebase',_0x2d53ad)['create'](_0x3e2e1d,{'appName':_0x3eb821['name']});}function re(_0x3d9d0a){return Ia(_0x3d9d0a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x20f7d0,..._0x545e7a){if(typeof _0x20f7d0!='string'){const _0x2a3ec0=_0x545e7a[0x0],_0xdf14f1=[..._0x545e7a['slice'](0x1)];return _0xdf14f1[0x0]&&(_0xdf14f1[0x0]['appName']=_0x20f7d0['name']),_0x20f7d0['_errorFactory']['create'](_0x2a3ec0,..._0xdf14f1);}return Ea['create'](_0x20f7d0,..._0x545e7a);}function m(_0x19a631,_0x47702d,..._0x5d9cd9){if(!_0x19a631)throw ws(_0x47702d,..._0x5d9cd9);}function ne(_0x9f9d7f){const _0x262597='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x9f9d7f;throw cn(_0x262597),new Error(_0x262597);}function ce(_0x52e23c,_0x24ce91){_0x52e23c||ne(_0x24ce91);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x476cf4;return typeof self<'u'&&((_0x476cf4=self['location'])==null?void 0x0:_0x476cf4['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2b4a3a;return typeof self<'u'&&((_0x2b4a3a=self['location'])==null?void 0x0:_0x2b4a3a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1c929a=navigator;return _0x1c929a['languages']&&_0x1c929a['languages'][0x0]||_0x1c929a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x8082f8,_0x589c2a){this['shortDelay']=_0x8082f8,this['longDelay']=_0x589c2a,ce(_0x589c2a>_0x8082f8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x4c1650,_0x105399){ce(_0x4c1650['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x36f909}=_0x4c1650['emulator'];return _0x105399?''+_0x36f909+(_0x105399['startsWith']('/')?_0x105399['slice'](0x1):_0x105399):_0x36f909;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x115fbb,_0xcc49d,_0x11e524){this['fetchImpl']=_0x115fbb,_0xcc49d&&(this['headersImpl']=_0xcc49d),_0x11e524&&(this['responseImpl']=_0x11e524);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x3b8742,_0x42d061){return _0x3b8742['tenantId']&&!_0x42d061['tenantId']?{..._0x42d061,'tenantId':_0x3b8742['tenantId']}:_0x42d061;}async function Pe(_0x48e96d,_0x37b09b,_0x270294,_0x16f4ec,_0xd7706={}){return Ca(_0x48e96d,_0xd7706,async()=>{let _0x15dbea={},_0x4fed26={};_0x16f4ec&&(_0x37b09b==='GET'?_0x4fed26=_0x16f4ec:_0x15dbea={'body':JSON['stringify'](_0x16f4ec)});const _0x18f494=ut({..._0x4fed26,'key':_0x48e96d['config']['apiKey']})['slice'](0x1),_0x765546=await _0x48e96d['_getAdditionalHeaders']();_0x765546['Content-Type']='application/json',_0x48e96d['languageCode']&&(_0x765546['X-Firebase-Locale']=_0x48e96d['languageCode']);const _0x3d106a={'method':_0x37b09b,'headers':_0x765546,..._0x15dbea};return dc()||(_0x3d106a['referrerPolicy']='strict-origin-when-cross-origin'),_0x48e96d['emulatorConfig']&&qt(_0x48e96d['emulatorConfig']['host'])&&(_0x3d106a['credentials']='include'),wa['fetch']()(await Ta(_0x48e96d,_0x48e96d['config']['apiHost'],_0x270294,_0x18f494),_0x3d106a);});}async function Ca(_0x152ec8,_0x1a8b54,_0x4225d0){_0x152ec8['_canInitEmulator']=!0x1;const _0x35c587={...df,..._0x1a8b54};try{const _0x5553e3=new gf(_0x152ec8),_0x4f1e6d=await Promise['race']([_0x4225d0(),_0x5553e3['promise']]);_0x5553e3['clearNetworkTimeout']();const _0x18e2a3=await _0x4f1e6d['json']();if('needConfirmation'in _0x18e2a3)throw on(_0x152ec8,'account-exists-with-different-credential',_0x18e2a3);if(_0x4f1e6d['ok']&&!('errorMessage'in _0x18e2a3))return _0x18e2a3;{const _0x2ac769=_0x4f1e6d['ok']?_0x18e2a3['errorMessage']:_0x18e2a3['error']['message'],[_0x5b3cf3,_0x245ea3]=_0x2ac769['split']('\x20:\x20');if(_0x5b3cf3==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x152ec8,'credential-already-in-use',_0x18e2a3);if(_0x5b3cf3==='EMAIL_EXISTS')throw on(_0x152ec8,'email-already-in-use',_0x18e2a3);if(_0x5b3cf3==='USER_DISABLED')throw on(_0x152ec8,'user-disabled',_0x18e2a3);const _0x1f30eb=_0x35c587[_0x5b3cf3]||_0x5b3cf3['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x245ea3)throw Ia(_0x152ec8,_0x1f30eb,_0x245ea3);Y(_0x152ec8,_0x1f30eb);}}catch(_0x269560){if(_0x269560 instanceof Re)throw _0x269560;Y(_0x152ec8,'network-request-failed',{'message':String(_0x269560)});}}async function en(_0x5b0431,_0x402c8e,_0x16ee87,_0xc05c3d,_0x3714e7={}){const _0x1a0e66=await Pe(_0x5b0431,_0x402c8e,_0x16ee87,_0xc05c3d,_0x3714e7);return'mfaPendingCredential'in _0x1a0e66&&Y(_0x5b0431,'multi-factor-auth-required',{'_serverResponse':_0x1a0e66}),_0x1a0e66;}async function Ta(_0x53bf09,_0x24e9a3,_0x1669d0,_0x26da12){const _0x42722a=''+_0x24e9a3+_0x1669d0+'?'+_0x26da12,_0xaed2df=_0x53bf09,_0x5ba910=_0xaed2df['config']['emulator']?Cs(_0x53bf09['config'],_0x42722a):_0x53bf09['config']['apiScheme']+'://'+_0x42722a;return ff['includes'](_0x1669d0)&&(await _0xaed2df['_persistenceManagerAvailable'],_0xaed2df['_getPersistenceType']()==='COOKIE')?_0xaed2df['_getPersistence']()['_getFinalTarget'](_0x5ba910)['toString']():_0x5ba910;}function _f(_0x574a92){switch(_0x574a92){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x362282){this['auth']=_0x362282,this['timer']=null,this['promise']=new Promise((_0x16681f,_0x2e56b5)=>{this['timer']=setTimeout(()=>_0x2e56b5(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0xca5eb9,_0x483b7b,_0x31baa6){const _0x377ac7={'appName':_0xca5eb9['name']};_0x31baa6['email']&&(_0x377ac7['email']=_0x31baa6['email']),_0x31baa6['phoneNumber']&&(_0x377ac7['phoneNumber']=_0x31baa6['phoneNumber']);const _0x557213=X(_0xca5eb9,_0x483b7b,_0x377ac7);return _0x557213['customData']['_tokenResponse']=_0x31baa6,_0x557213;}function wr(_0x7e1292){return _0x7e1292!==void 0x0&&_0x7e1292['enterprise']!==void 0x0;}class mf{constructor(_0xd19701){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0xd19701['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0xd19701['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0xd19701['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x27cb37){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x23f37b of this['recaptchaEnforcementState'])if(_0x23f37b['provider']&&_0x23f37b['provider']===_0x27cb37)return _f(_0x23f37b['enforcementState']);return null;}['isProviderEnabled'](_0x28a35d){return this['getProviderEnforcementState'](_0x28a35d)==='ENFORCE'||this['getProviderEnforcementState'](_0x28a35d)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x45b761,_0x3595c8){return Pe(_0x45b761,'GET','/v2/recaptchaConfig',ke(_0x45b761,_0x3595c8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0xc08688,_0x1b67b4){return Pe(_0xc08688,'POST','/v1/accounts:delete',_0x1b67b4);}async function Pn(_0x3d1c5b,_0x2fcaa3){return Pe(_0x3d1c5b,'POST','/v1/accounts:lookup',_0x2fcaa3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x45b172){if(_0x45b172)try{const _0x114a09=new Date(Number(_0x45b172));if(!isNaN(_0x114a09['getTime']()))return _0x114a09['toUTCString']();}catch{}}async function Ef(_0xde4349,_0x26167b=!0x1){const _0x2e6fce=P(_0xde4349),_0xc35d4e=await _0x2e6fce['getIdToken'](_0x26167b),_0x1494ad=Ts(_0xc35d4e);m(_0x1494ad&&_0x1494ad['exp']&&_0x1494ad['auth_time']&&_0x1494ad['iat'],_0x2e6fce['auth'],'internal-error');const _0x39f26e=typeof _0x1494ad['firebase']=='object'?_0x1494ad['firebase']:void 0x0,_0x46767=_0x39f26e==null?void 0x0:_0x39f26e['sign_in_provider'];return{'claims':_0x1494ad,'token':_0xc35d4e,'authTime':Pt(fi(_0x1494ad['auth_time'])),'issuedAtTime':Pt(fi(_0x1494ad['iat'])),'expirationTime':Pt(fi(_0x1494ad['exp'])),'signInProvider':_0x46767||null,'signInSecondFactor':(_0x39f26e==null?void 0x0:_0x39f26e['sign_in_second_factor'])||null};}function fi(_0x394145){return Number(_0x394145)*0x3e8;}function Ts(_0x4f1794){const [_0x518e37,_0x541968,_0x3fda84]=_0x4f1794['split']('.');if(_0x518e37===void 0x0||_0x541968===void 0x0||_0x3fda84===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3ad0fa=fn(_0x541968);return _0x3ad0fa?JSON['parse'](_0x3ad0fa):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5ec0cf){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5ec0cf==null?void 0x0:_0x5ec0cf['toString']()),null;}}function Cr(_0x43755c){const _0x3daa19=Ts(_0x43755c);return m(_0x3daa19,'internal-error'),m(typeof _0x3daa19['exp']<'u','internal-error'),m(typeof _0x3daa19['iat']<'u','internal-error'),Number(_0x3daa19['exp'])-Number(_0x3daa19['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x6bfe08,_0x29229d,_0xc04f31=!0x1){if(_0xc04f31)return _0x29229d;try{return await _0x29229d;}catch(_0x39cd82){throw _0x39cd82 instanceof Re&&If(_0x39cd82)&&_0x6bfe08['auth']['currentUser']===_0x6bfe08&&await _0x6bfe08['auth']['signOut'](),_0x39cd82;}}function If({code:_0x5f125e}){return _0x5f125e==='auth/user-disabled'||_0x5f125e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5d4c25){this['user']=_0x5d4c25,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x360039){if(_0x360039){const _0x546ff5=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x546ff5;}else{this['errorBackoff']=0x7530;const _0x5b9dc8=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5b9dc8);}}['schedule'](_0x645e46=!0x1){if(!this['isRunning'])return;const _0x5ee4cc=this['getInterval'](_0x645e46);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5ee4cc);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x22adf3){(_0x22adf3==null?void 0x0:_0x22adf3['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x49bad8,_0x5d9478){this['createdAt']=_0x49bad8,this['lastLoginAt']=_0x5d9478,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x442ec1){this['createdAt']=_0x442ec1['createdAt'],this['lastLoginAt']=_0x442ec1['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0xed901d){var _0x4dd178;const _0x45ed08=_0xed901d['auth'],_0x461e62=await _0xed901d['getIdToken'](),_0x5b8959=await Ht(_0xed901d,Pn(_0x45ed08,{'idToken':_0x461e62}));m(_0x5b8959==null?void 0x0:_0x5b8959['users']['length'],_0x45ed08,'internal-error');const _0x575550=_0x5b8959['users'][0x0];_0xed901d['_notifyReloadListener'](_0x575550);const _0x545983=(_0x4dd178=_0x575550['providerUserInfo'])!=null&&_0x4dd178['length']?Sa(_0x575550['providerUserInfo']):[],_0x2713d5=Tf(_0xed901d['providerData'],_0x545983),_0x57eb1f=_0xed901d['isAnonymous'],_0x1a8973=!(_0xed901d['email']&&_0x575550['passwordHash'])&&!(_0x2713d5!=null&&_0x2713d5['length']),_0x440abc=_0x57eb1f?_0x1a8973:!0x1,_0x3242a1={'uid':_0x575550['localId'],'displayName':_0x575550['displayName']||null,'photoURL':_0x575550['photoUrl']||null,'email':_0x575550['email']||null,'emailVerified':_0x575550['emailVerified']||!0x1,'phoneNumber':_0x575550['phoneNumber']||null,'tenantId':_0x575550['tenantId']||null,'providerData':_0x2713d5,'metadata':new Li(_0x575550['createdAt'],_0x575550['lastLoginAt']),'isAnonymous':_0x440abc};Object['assign'](_0xed901d,_0x3242a1);}async function Cf(_0x33e955){const _0x4da1f6=P(_0x33e955);await Nn(_0x4da1f6),await _0x4da1f6['auth']['_persistUserIfCurrent'](_0x4da1f6),_0x4da1f6['auth']['_notifyListenersIfCurrent'](_0x4da1f6);}function Tf(_0x43fad6,_0x2da565){return[..._0x43fad6['filter'](_0x430f1a=>!_0x2da565['some'](_0x186180=>_0x186180['providerId']===_0x430f1a['providerId'])),..._0x2da565];}function Sa(_0x1da0a6){return _0x1da0a6['map'](({providerId:_0x39686c,..._0x11244b})=>({'providerId':_0x39686c,'uid':_0x11244b['rawId']||'','displayName':_0x11244b['displayName']||null,'email':_0x11244b['email']||null,'phoneNumber':_0x11244b['phoneNumber']||null,'photoURL':_0x11244b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x5e1eee,_0x1fbf56){const _0x219689=await Ca(_0x5e1eee,{},async()=>{const _0x10d0fd=ut({'grant_type':'refresh_token','refresh_token':_0x1fbf56})['slice'](0x1),{tokenApiHost:_0x1ecb75,apiKey:_0xe3b9b9}=_0x5e1eee['config'],_0x370624=await Ta(_0x5e1eee,_0x1ecb75,'/v1/token','key='+_0xe3b9b9),_0x502074=await _0x5e1eee['_getAdditionalHeaders']();_0x502074['Content-Type']='application/x-www-form-urlencoded';const _0x805ccc={'method':'POST','headers':_0x502074,'body':_0x10d0fd};return _0x5e1eee['emulatorConfig']&&qt(_0x5e1eee['emulatorConfig']['host'])&&(_0x805ccc['credentials']='include'),wa['fetch']()(_0x370624,_0x805ccc);});return{'accessToken':_0x219689['access_token'],'expiresIn':_0x219689['expires_in'],'refreshToken':_0x219689['refresh_token']};}async function bf(_0x26d472,_0x54e7f3){return Pe(_0x26d472,'POST','/v2/accounts:revokeToken',ke(_0x26d472,_0x54e7f3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5a90bf){m(_0x5a90bf['idToken'],'internal-error'),m(typeof _0x5a90bf['idToken']<'u','internal-error'),m(typeof _0x5a90bf['refreshToken']<'u','internal-error');const _0x517a22='expiresIn'in _0x5a90bf&&typeof _0x5a90bf['expiresIn']<'u'?Number(_0x5a90bf['expiresIn']):Cr(_0x5a90bf['idToken']);this['updateTokensAndExpiration'](_0x5a90bf['idToken'],_0x5a90bf['refreshToken'],_0x517a22);}['updateFromIdToken'](_0x1b38c3){m(_0x1b38c3['length']!==0x0,'internal-error');const _0xfa366a=Cr(_0x1b38c3);this['updateTokensAndExpiration'](_0x1b38c3,null,_0xfa366a);}async['getToken'](_0x1b10fc,_0x389feb=!0x1){return!_0x389feb&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1b10fc,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1b10fc,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2ad4dd,_0x201a82){const {accessToken:_0x31cbd9,refreshToken:_0x5b0473,expiresIn:_0x4b8d08}=await Sf(_0x2ad4dd,_0x201a82);this['updateTokensAndExpiration'](_0x31cbd9,_0x5b0473,Number(_0x4b8d08));}['updateTokensAndExpiration'](_0x333ef7,_0xe589b8,_0x2fed86){this['refreshToken']=_0xe589b8||null,this['accessToken']=_0x333ef7||null,this['expirationTime']=Date['now']()+_0x2fed86*0x3e8;}static['fromJSON'](_0x5df113,_0x2d37a8){const {refreshToken:_0x106d6d,accessToken:_0x5c721d,expirationTime:_0x49545a}=_0x2d37a8,_0x124cff=new et();return _0x106d6d&&(m(typeof _0x106d6d=='string','internal-error',{'appName':_0x5df113}),_0x124cff['refreshToken']=_0x106d6d),_0x5c721d&&(m(typeof _0x5c721d=='string','internal-error',{'appName':_0x5df113}),_0x124cff['accessToken']=_0x5c721d),_0x49545a&&(m(typeof _0x49545a=='number','internal-error',{'appName':_0x5df113}),_0x124cff['expirationTime']=_0x49545a),_0x124cff;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x328326){this['accessToken']=_0x328326['accessToken'],this['refreshToken']=_0x328326['refreshToken'],this['expirationTime']=_0x328326['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x309d26,_0x538bd9){m(typeof _0x309d26=='string'||typeof _0x309d26>'u','internal-error',{'appName':_0x538bd9});}class j{constructor({uid:_0x1417fb,auth:_0x1b80f9,stsTokenManager:_0x1530c2,..._0x220bba}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1417fb,this['auth']=_0x1b80f9,this['stsTokenManager']=_0x1530c2,this['accessToken']=_0x1530c2['accessToken'],this['displayName']=_0x220bba['displayName']||null,this['email']=_0x220bba['email']||null,this['emailVerified']=_0x220bba['emailVerified']||!0x1,this['phoneNumber']=_0x220bba['phoneNumber']||null,this['photoURL']=_0x220bba['photoURL']||null,this['isAnonymous']=_0x220bba['isAnonymous']||!0x1,this['tenantId']=_0x220bba['tenantId']||null,this['providerData']=_0x220bba['providerData']?[..._0x220bba['providerData']]:[],this['metadata']=new Li(_0x220bba['createdAt']||void 0x0,_0x220bba['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3ca8ae){const _0x219826=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x3ca8ae));return m(_0x219826,this['auth'],'internal-error'),this['accessToken']!==_0x219826&&(this['accessToken']=_0x219826,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x219826;}['getIdTokenResult'](_0x539bee){return Ef(this,_0x539bee);}['reload'](){return Cf(this);}['_assign'](_0x11e441){this!==_0x11e441&&(m(this['uid']===_0x11e441['uid'],this['auth'],'internal-error'),this['displayName']=_0x11e441['displayName'],this['photoURL']=_0x11e441['photoURL'],this['email']=_0x11e441['email'],this['emailVerified']=_0x11e441['emailVerified'],this['phoneNumber']=_0x11e441['phoneNumber'],this['isAnonymous']=_0x11e441['isAnonymous'],this['tenantId']=_0x11e441['tenantId'],this['providerData']=_0x11e441['providerData']['map'](_0x12b5d8=>({..._0x12b5d8})),this['metadata']['_copy'](_0x11e441['metadata']),this['stsTokenManager']['_assign'](_0x11e441['stsTokenManager']));}['_clone'](_0x5b3c0d){const _0xfc55a4=new j({...this,'auth':_0x5b3c0d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xfc55a4['metadata']['_copy'](this['metadata']),_0xfc55a4;}['_onReload'](_0x19fda7){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x19fda7,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5c43af){this['reloadListener']?this['reloadListener'](_0x5c43af):this['reloadUserInfo']=_0x5c43af;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x49afd2,_0x153f23=!0x1){let _0x1901c2=!0x1;_0x49afd2['idToken']&&_0x49afd2['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x49afd2),_0x1901c2=!0x0),_0x153f23&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1901c2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x13c015=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x13c015})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x429cf0=>({..._0x429cf0})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4e3d47,_0x57161b){const _0x46e9c9=_0x57161b['displayName']??void 0x0,_0x433138=_0x57161b['email']??void 0x0,_0x12f6b9=_0x57161b['phoneNumber']??void 0x0,_0x1c44cc=_0x57161b['photoURL']??void 0x0,_0x13c6a9=_0x57161b['tenantId']??void 0x0,_0x2de487=_0x57161b['_redirectEventId']??void 0x0,_0x150db3=_0x57161b['createdAt']??void 0x0,_0x58777f=_0x57161b['lastLoginAt']??void 0x0,{uid:_0x4f1d61,emailVerified:_0x3d77d3,isAnonymous:_0x1d0952,providerData:_0x3180e0,stsTokenManager:_0xaaee36}=_0x57161b;m(_0x4f1d61&&_0xaaee36,_0x4e3d47,'internal-error');const _0x483cf9=et['fromJSON'](this['name'],_0xaaee36);m(typeof _0x4f1d61=='string',_0x4e3d47,'internal-error'),le(_0x46e9c9,_0x4e3d47['name']),le(_0x433138,_0x4e3d47['name']),m(typeof _0x3d77d3=='boolean',_0x4e3d47,'internal-error'),m(typeof _0x1d0952=='boolean',_0x4e3d47,'internal-error'),le(_0x12f6b9,_0x4e3d47['name']),le(_0x1c44cc,_0x4e3d47['name']),le(_0x13c6a9,_0x4e3d47['name']),le(_0x2de487,_0x4e3d47['name']),le(_0x150db3,_0x4e3d47['name']),le(_0x58777f,_0x4e3d47['name']);const _0x4e016c=new j({'uid':_0x4f1d61,'auth':_0x4e3d47,'email':_0x433138,'emailVerified':_0x3d77d3,'displayName':_0x46e9c9,'isAnonymous':_0x1d0952,'photoURL':_0x1c44cc,'phoneNumber':_0x12f6b9,'tenantId':_0x13c6a9,'stsTokenManager':_0x483cf9,'createdAt':_0x150db3,'lastLoginAt':_0x58777f});return _0x3180e0&&Array['isArray'](_0x3180e0)&&(_0x4e016c['providerData']=_0x3180e0['map'](_0x5224c8=>({..._0x5224c8}))),_0x2de487&&(_0x4e016c['_redirectEventId']=_0x2de487),_0x4e016c;}static async['_fromIdTokenResponse'](_0x56495d,_0x46c080,_0x376f77=!0x1){const _0x1860b0=new et();_0x1860b0['updateFromServerResponse'](_0x46c080);const _0x23005a=new j({'uid':_0x46c080['localId'],'auth':_0x56495d,'stsTokenManager':_0x1860b0,'isAnonymous':_0x376f77});return await Nn(_0x23005a),_0x23005a;}static async['_fromGetAccountInfoResponse'](_0x4854e4,_0xd8adbc,_0x269a47){const _0x27bd87=_0xd8adbc['users'][0x0];m(_0x27bd87['localId']!==void 0x0,'internal-error');const _0x471c75=_0x27bd87['providerUserInfo']!==void 0x0?Sa(_0x27bd87['providerUserInfo']):[],_0x118292=!(_0x27bd87['email']&&_0x27bd87['passwordHash'])&&!(_0x471c75!=null&&_0x471c75['length']),_0x1d3314=new et();_0x1d3314['updateFromIdToken'](_0x269a47);const _0x2662aa=new j({'uid':_0x27bd87['localId'],'auth':_0x4854e4,'stsTokenManager':_0x1d3314,'isAnonymous':_0x118292}),_0x5d6f35={'uid':_0x27bd87['localId'],'displayName':_0x27bd87['displayName']||null,'photoURL':_0x27bd87['photoUrl']||null,'email':_0x27bd87['email']||null,'emailVerified':_0x27bd87['emailVerified']||!0x1,'phoneNumber':_0x27bd87['phoneNumber']||null,'tenantId':_0x27bd87['tenantId']||null,'providerData':_0x471c75,'metadata':new Li(_0x27bd87['createdAt'],_0x27bd87['lastLoginAt']),'isAnonymous':!(_0x27bd87['email']&&_0x27bd87['passwordHash'])&&!(_0x471c75!=null&&_0x471c75['length'])};return Object['assign'](_0x2662aa,_0x5d6f35),_0x2662aa;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xb6506b){ce(_0xb6506b instanceof Function,'Expected\x20a\x20class\x20definition');let _0x28e1fe=Tr['get'](_0xb6506b);return _0x28e1fe?(ce(_0x28e1fe instanceof _0xb6506b,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x28e1fe):(_0x28e1fe=new _0xb6506b(),Tr['set'](_0xb6506b,_0x28e1fe),_0x28e1fe);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2a91f6,_0x4fa7f5){this['storage'][_0x2a91f6]=_0x4fa7f5;}async['_get'](_0x31fdd3){const _0x1dc32b=this['storage'][_0x31fdd3];return _0x1dc32b===void 0x0?null:_0x1dc32b;}async['_remove'](_0x4b4c27){delete this['storage'][_0x4b4c27];}['_addListener'](_0x2695a2,_0x54f34e){}['_removeListener'](_0x28371a,_0x46d515){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4637ab,_0x15b1d6,_0xcb76a2){return'firebase:'+_0x4637ab+':'+_0x15b1d6+':'+_0xcb76a2;}class tt{constructor(_0x40614f,_0x184fac,_0x171933){this['persistence']=_0x40614f,this['auth']=_0x184fac,this['userKey']=_0x171933;const {config:_0x44a45e,name:_0x580440}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x44a45e['apiKey'],_0x580440),this['fullPersistenceKey']=ln('persistence',_0x44a45e['apiKey'],_0x580440),this['boundEventHandler']=_0x184fac['_onStorageEvent']['bind'](_0x184fac),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x552f58){return this['persistence']['_set'](this['fullUserKey'],_0x552f58['toJSON']());}async['getCurrentUser'](){const _0x2eccf9=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2eccf9)return null;if(typeof _0x2eccf9=='string'){const _0x3a70ea=await Pn(this['auth'],{'idToken':_0x2eccf9})['catch'](()=>{});return _0x3a70ea?j['_fromGetAccountInfoResponse'](this['auth'],_0x3a70ea,_0x2eccf9):null;}return j['_fromJSON'](this['auth'],_0x2eccf9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3607db){if(this['persistence']===_0x3607db)return;const _0x26e0e1=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3607db,_0x26e0e1)return this['setCurrentUser'](_0x26e0e1);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5c1512,_0x124de6,_0x374012='authUser'){if(!_0x124de6['length'])return new tt(ie(Sr),_0x5c1512,_0x374012);const _0x3754be=(await Promise['all'](_0x124de6['map'](async _0x3fef2a=>{if(await _0x3fef2a['_isAvailable']())return _0x3fef2a;})))['filter'](_0x2d9cd1=>_0x2d9cd1);let _0x30237c=_0x3754be[0x0]||ie(Sr);const _0x2801a8=ln(_0x374012,_0x5c1512['config']['apiKey'],_0x5c1512['name']);let _0x321cd5=null;for(const _0x356e41 of _0x124de6)try{const _0x1f31dd=await _0x356e41['_get'](_0x2801a8);if(_0x1f31dd){let _0x40249e;if(typeof _0x1f31dd=='string'){const _0x40e087=await Pn(_0x5c1512,{'idToken':_0x1f31dd})['catch'](()=>{});if(!_0x40e087)break;_0x40249e=await j['_fromGetAccountInfoResponse'](_0x5c1512,_0x40e087,_0x1f31dd);}else _0x40249e=j['_fromJSON'](_0x5c1512,_0x1f31dd);_0x356e41!==_0x30237c&&(_0x321cd5=_0x40249e),_0x30237c=_0x356e41;break;}}catch{}const _0xf8535f=_0x3754be['filter'](_0x3e150f=>_0x3e150f['_shouldAllowMigration']);return!_0x30237c['_shouldAllowMigration']||!_0xf8535f['length']?new tt(_0x30237c,_0x5c1512,_0x374012):(_0x30237c=_0xf8535f[0x0],_0x321cd5&&await _0x30237c['_set'](_0x2801a8,_0x321cd5['toJSON']()),await Promise['all'](_0x124de6['map'](async _0x3d3ae7=>{if(_0x3d3ae7!==_0x30237c)try{await _0x3d3ae7['_remove'](_0x2801a8);}catch{}})),new tt(_0x30237c,_0x5c1512,_0x374012));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2c28fc){const _0x57ff49=_0x2c28fc['toLowerCase']();if(_0x57ff49['includes']('opera/')||_0x57ff49['includes']('opr/')||_0x57ff49['includes']('opios/'))return'Opera';if(Pa(_0x57ff49))return'IEMobile';if(_0x57ff49['includes']('msie')||_0x57ff49['includes']('trident/'))return'IE';if(_0x57ff49['includes']('edge/'))return'Edge';if(Ra(_0x57ff49))return'Firefox';if(_0x57ff49['includes']('silk/'))return'Silk';if(Oa(_0x57ff49))return'Blackberry';if(Da(_0x57ff49))return'Webos';if(Aa(_0x57ff49))return'Safari';if((_0x57ff49['includes']('chrome/')||ka(_0x57ff49))&&!_0x57ff49['includes']('edge/'))return'Chrome';if(Na(_0x57ff49))return'Android';{const _0xbcca24=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x39e353=_0x2c28fc['match'](_0xbcca24);if((_0x39e353==null?void 0x0:_0x39e353['length'])===0x2)return _0x39e353[0x1];}return'Other';}function Ra(_0x16f45e=W()){return/firefox\//i['test'](_0x16f45e);}function Aa(_0x463a37=W()){const _0x79ffcc=_0x463a37['toLowerCase']();return _0x79ffcc['includes']('safari/')&&!_0x79ffcc['includes']('chrome/')&&!_0x79ffcc['includes']('crios/')&&!_0x79ffcc['includes']('android');}function ka(_0x3cece8=W()){return/crios\//i['test'](_0x3cece8);}function Pa(_0x2a5645=W()){return/iemobile/i['test'](_0x2a5645);}function Na(_0x440784=W()){return/android/i['test'](_0x440784);}function Oa(_0x51d341=W()){return/blackberry/i['test'](_0x51d341);}function Da(_0x5bae4f=W()){return/webos/i['test'](_0x5bae4f);}function Ss(_0x3bba41=W()){return/iphone|ipad|ipod/i['test'](_0x3bba41)||/macintosh/i['test'](_0x3bba41)&&/mobile/i['test'](_0x3bba41);}function Rf(_0x53d749=W()){var _0x1c406b;return Ss(_0x53d749)&&!!((_0x1c406b=window['navigator'])!=null&&_0x1c406b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x456f3b=W()){return Ss(_0x456f3b)||Na(_0x456f3b)||Da(_0x456f3b)||Oa(_0x456f3b)||/windows phone/i['test'](_0x456f3b)||Pa(_0x456f3b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1b0a4c,_0x369a3a=[]){let _0x328fff;switch(_0x1b0a4c){case'Browser':_0x328fff=br(W());break;case'Worker':_0x328fff=br(W())+'-'+_0x1b0a4c;break;default:_0x328fff=_0x1b0a4c;}const _0x368259=_0x369a3a['length']?_0x369a3a['join'](','):'FirebaseCore-web';return _0x328fff+'/JsCore/'+dt+'/'+_0x368259;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1668d1){this['auth']=_0x1668d1,this['queue']=[];}['pushCallback'](_0x50efad,_0x5a1204){const _0x29e6f1=_0x9f55fc=>new Promise((_0x108772,_0x3061b6)=>{try{const _0xee4da9=_0x50efad(_0x9f55fc);_0x108772(_0xee4da9);}catch(_0x51d638){_0x3061b6(_0x51d638);}});_0x29e6f1['onAbort']=_0x5a1204,this['queue']['push'](_0x29e6f1);const _0x5e34f1=this['queue']['length']-0x1;return()=>{this['queue'][_0x5e34f1]=()=>Promise['resolve']();};}async['runMiddleware'](_0x30fb38){if(this['auth']['currentUser']===_0x30fb38)return;const _0x59655e=[];try{for(const _0x3df2cf of this['queue'])await _0x3df2cf(_0x30fb38),_0x3df2cf['onAbort']&&_0x59655e['push'](_0x3df2cf['onAbort']);}catch(_0x1ca815){_0x59655e['reverse']();for(const _0x7b20c of _0x59655e)try{_0x7b20c();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1ca815==null?void 0x0:_0x1ca815['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1299d0,_0x47e4d6={}){return Pe(_0x1299d0,'GET','/v2/passwordPolicy',ke(_0x1299d0,_0x47e4d6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3e5b77){var _0x19a739;const _0x155d8c=_0x3e5b77['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x155d8c['minPasswordLength']??Nf,_0x155d8c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x155d8c['maxPasswordLength']),_0x155d8c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x155d8c['containsLowercaseCharacter']),_0x155d8c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x155d8c['containsUppercaseCharacter']),_0x155d8c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x155d8c['containsNumericCharacter']),_0x155d8c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x155d8c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3e5b77['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x19a739=_0x3e5b77['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x19a739['join'](''))??'',this['forceUpgradeOnSignin']=_0x3e5b77['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3e5b77['schemaVersion'];}['validatePassword'](_0x153e56){const _0x526c2c={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x153e56,_0x526c2c),this['validatePasswordCharacterOptions'](_0x153e56,_0x526c2c),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['meetsMinPasswordLength']??!0x0),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['meetsMaxPasswordLength']??!0x0),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['containsLowercaseLetter']??!0x0),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['containsUppercaseLetter']??!0x0),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['containsNumericCharacter']??!0x0),_0x526c2c['isValid']&&(_0x526c2c['isValid']=_0x526c2c['containsNonAlphanumericCharacter']??!0x0),_0x526c2c;}['validatePasswordLengthOptions'](_0x220774,_0xc248b9){const _0x2f60e4=this['customStrengthOptions']['minPasswordLength'],_0x2770d3=this['customStrengthOptions']['maxPasswordLength'];_0x2f60e4&&(_0xc248b9['meetsMinPasswordLength']=_0x220774['length']>=_0x2f60e4),_0x2770d3&&(_0xc248b9['meetsMaxPasswordLength']=_0x220774['length']<=_0x2770d3);}['validatePasswordCharacterOptions'](_0x286000,_0x72c790){this['updatePasswordCharacterOptionsStatuses'](_0x72c790,!0x1,!0x1,!0x1,!0x1);let _0x25bb3f;for(let _0x2d5aef=0x0;_0x2d5aef<_0x286000['length'];_0x2d5aef++)_0x25bb3f=_0x286000['charAt'](_0x2d5aef),this['updatePasswordCharacterOptionsStatuses'](_0x72c790,_0x25bb3f>='a'&&_0x25bb3f<='z',_0x25bb3f>='A'&&_0x25bb3f<='Z',_0x25bb3f>='0'&&_0x25bb3f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x25bb3f));}['updatePasswordCharacterOptionsStatuses'](_0x4842f1,_0x5801a0,_0x3c79c2,_0xd3ac6a,_0x208be5){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x4842f1['containsLowercaseLetter']||(_0x4842f1['containsLowercaseLetter']=_0x5801a0)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x4842f1['containsUppercaseLetter']||(_0x4842f1['containsUppercaseLetter']=_0x3c79c2)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x4842f1['containsNumericCharacter']||(_0x4842f1['containsNumericCharacter']=_0xd3ac6a)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x4842f1['containsNonAlphanumericCharacter']||(_0x4842f1['containsNonAlphanumericCharacter']=_0x208be5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x1ed19f,_0x84fe8c,_0x584088,_0x2caa03){this['app']=_0x1ed19f,this['heartbeatServiceProvider']=_0x84fe8c,this['appCheckServiceProvider']=_0x584088,this['config']=_0x2caa03,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1ed19f['name'],this['clientVersion']=_0x2caa03['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5dab0c=>this['_resolvePersistenceManagerAvailable']=_0x5dab0c);}['_initializeWithPersistence'](_0x232a88,_0x3d856c){return _0x3d856c&&(this['_popupRedirectResolver']=ie(_0x3d856c)),this['_initializationPromise']=this['queue'](async()=>{var _0x25333b,_0x22aee1,_0x49826c;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x232a88),(_0x25333b=this['_resolvePersistenceManagerAvailable'])==null||_0x25333b['call'](this),!this['_deleted'])){if((_0x22aee1=this['_popupRedirectResolver'])!=null&&_0x22aee1['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3d856c),this['lastNotifiedUid']=((_0x49826c=this['currentUser'])==null?void 0x0:_0x49826c['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xe1b650=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xe1b650)){if(this['currentUser']&&_0xe1b650&&this['currentUser']['uid']===_0xe1b650['uid']){this['_currentUser']['_assign'](_0xe1b650),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xe1b650,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x597dc1){try{const _0x59cd6c=await Pn(this,{'idToken':_0x597dc1}),_0x914fc=await j['_fromGetAccountInfoResponse'](this,_0x59cd6c,_0x597dc1);await this['directlySetCurrentUser'](_0x914fc);}catch(_0xd59f0b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0xd59f0b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x464640){var _0x5d88e0;if($(this['app'])){const _0x4cd323=this['app']['settings']['authIdToken'];return _0x4cd323?new Promise(_0x4d69ca=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4cd323)['then'](_0x4d69ca,_0x4d69ca));}):this['directlySetCurrentUser'](null);}const _0x479d34=await this['assertedPersistence']['getCurrentUser']();let _0x23d260=_0x479d34,_0x5cc514=!0x1;if(_0x464640&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x315b96=(_0x5d88e0=this['redirectUser'])==null?void 0x0:_0x5d88e0['_redirectEventId'],_0x3e2348=_0x23d260==null?void 0x0:_0x23d260['_redirectEventId'],_0x4db28c=await this['tryRedirectSignIn'](_0x464640);(!_0x315b96||_0x315b96===_0x3e2348)&&(_0x4db28c!=null&&_0x4db28c['user'])&&(_0x23d260=_0x4db28c['user'],_0x5cc514=!0x0);}if(!_0x23d260)return this['directlySetCurrentUser'](null);if(!_0x23d260['_redirectEventId']){if(_0x5cc514)try{await this['beforeStateQueue']['runMiddleware'](_0x23d260);}catch(_0x391949){_0x23d260=_0x479d34,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x391949));}return _0x23d260?this['reloadAndSetCurrentUserOrClear'](_0x23d260):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x23d260['_redirectEventId']?this['directlySetCurrentUser'](_0x23d260):this['reloadAndSetCurrentUserOrClear'](_0x23d260);}async['tryRedirectSignIn'](_0x44f7a2){let _0x3fb075=null;try{_0x3fb075=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x44f7a2,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3fb075;}async['reloadAndSetCurrentUserOrClear'](_0x1f0011){try{await Nn(_0x1f0011);}catch(_0x38d113){if((_0x38d113==null?void 0x0:_0x38d113['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1f0011);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1439d6){if($(this['app']))return Promise['reject'](re(this));const _0x4cd2bc=_0x1439d6?P(_0x1439d6):null;return _0x4cd2bc&&m(_0x4cd2bc['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4cd2bc&&_0x4cd2bc['_clone'](this));}async['_updateCurrentUser'](_0x4a9d0c,_0x3d72d7=!0x1){if(!this['_deleted'])return _0x4a9d0c&&m(this['tenantId']===_0x4a9d0c['tenantId'],this,'tenant-id-mismatch'),_0x3d72d7||await this['beforeStateQueue']['runMiddleware'](_0x4a9d0c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x4a9d0c),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3d817e){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3d817e));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x61b6b2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x297d26=this['_getPasswordPolicyInternal']();return _0x297d26['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x297d26['validatePassword'](_0x61b6b2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1119fa=await Pf(this),_0x53210d=new Of(_0x1119fa);this['tenantId']===null?this['_projectPasswordPolicy']=_0x53210d:this['_tenantPasswordPolicies'][this['tenantId']]=_0x53210d;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x59bd21){this['_errorFactory']=new Gt('auth','Firebase',_0x59bd21());}['onAuthStateChanged'](_0x233852,_0x40452b,_0x533cb2){return this['registerStateListener'](this['authStateSubscription'],_0x233852,_0x40452b,_0x533cb2);}['beforeAuthStateChanged'](_0x53f62b,_0x57e6ed){return this['beforeStateQueue']['pushCallback'](_0x53f62b,_0x57e6ed);}['onIdTokenChanged'](_0x23429c,_0x585845,_0x98837a){return this['registerStateListener'](this['idTokenSubscription'],_0x23429c,_0x585845,_0x98837a);}['authStateReady'](){return new Promise((_0x27ead6,_0x2307a2)=>{if(this['currentUser'])_0x27ead6();else{const _0x2248ff=this['onAuthStateChanged'](()=>{_0x2248ff(),_0x27ead6();},_0x2307a2);}});}async['revokeAccessToken'](_0x5b0eba){if(this['currentUser']){const _0x359115=await this['currentUser']['getIdToken'](),_0x3036a3={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x5b0eba,'idToken':_0x359115};this['tenantId']!=null&&(_0x3036a3['tenantId']=this['tenantId']),await bf(this,_0x3036a3);}}['toJSON'](){var _0x12370d;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x12370d=this['_currentUser'])==null?void 0x0:_0x12370d['toJSON']()};}async['_setRedirectUser'](_0x55ea5c,_0x459936){const _0x78b7ba=await this['getOrInitRedirectPersistenceManager'](_0x459936);return _0x55ea5c===null?_0x78b7ba['removeCurrentUser']():_0x78b7ba['setCurrentUser'](_0x55ea5c);}async['getOrInitRedirectPersistenceManager'](_0x626bac){if(!this['redirectPersistenceManager']){const _0x12f1bf=_0x626bac&&ie(_0x626bac)||this['_popupRedirectResolver'];m(_0x12f1bf,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x12f1bf['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x440c55){var _0x1dc9d2,_0x6ee9de;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x1dc9d2=this['_currentUser'])==null?void 0x0:_0x1dc9d2['_redirectEventId'])===_0x440c55?this['_currentUser']:((_0x6ee9de=this['redirectUser'])==null?void 0x0:_0x6ee9de['_redirectEventId'])===_0x440c55?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0xf8f072){if(_0xf8f072===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0xf8f072));}['_notifyListenersIfCurrent'](_0x53b950){_0x53b950===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x596a57;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x52ac63=((_0x596a57=this['currentUser'])==null?void 0x0:_0x596a57['uid'])??null;this['lastNotifiedUid']!==_0x52ac63&&(this['lastNotifiedUid']=_0x52ac63,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x51e88a,_0xd9267f,_0x22ee03,_0x289839){if(this['_deleted'])return()=>{};const _0x37b978=typeof _0xd9267f=='function'?_0xd9267f:_0xd9267f['next']['bind'](_0xd9267f);let _0x26dfce=!0x1;const _0x4bb012=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4bb012,this,'internal-error'),_0x4bb012['then'](()=>{_0x26dfce||_0x37b978(this['currentUser']);}),typeof _0xd9267f=='function'){const _0x1216a9=_0x51e88a['addObserver'](_0xd9267f,_0x22ee03,_0x289839);return()=>{_0x26dfce=!0x0,_0x1216a9();};}else{const _0x1b45cd=_0x51e88a['addObserver'](_0xd9267f);return()=>{_0x26dfce=!0x0,_0x1b45cd();};}}async['directlySetCurrentUser'](_0xe44f0){this['currentUser']&&this['currentUser']!==_0xe44f0&&this['_currentUser']['_stopProactiveRefresh'](),_0xe44f0&&this['isProactiveRefreshEnabled']&&_0xe44f0['_startProactiveRefresh'](),this['currentUser']=_0xe44f0,_0xe44f0?await this['assertedPersistence']['setCurrentUser'](_0xe44f0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2e8c08){return this['operations']=this['operations']['then'](_0x2e8c08,_0x2e8c08),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x7f16e){!_0x7f16e||this['frameworks']['includes'](_0x7f16e)||(this['frameworks']['push'](_0x7f16e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5237b9;const _0x54278f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x54278f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x308579=await((_0x5237b9=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5237b9['getHeartbeatsHeader']());_0x308579&&(_0x54278f['X-Firebase-Client']=_0x308579);const _0x19cd06=await this['_getAppCheckToken']();return _0x19cd06&&(_0x54278f['X-Firebase-AppCheck']=_0x19cd06),_0x54278f;}async['_getAppCheckToken'](){var _0x2a292d;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2fa404=await((_0x2a292d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2a292d['getToken']());return _0x2fa404!=null&&_0x2fa404['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2fa404['error']),_0x2fa404==null?void 0x0:_0x2fa404['token'];}}function Ke(_0x3692c6){return P(_0x3692c6);}class Rr{constructor(_0xd836ab){this['auth']=_0xd836ab,this['observer']=null,this['addObserver']=Tc(_0xd4bf99=>this['observer']=_0xd4bf99);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x415162){Jn=_0x415162;}function xa(_0x5721b5){return Jn['loadJS'](_0x5721b5);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0xa585d5){return'__'+_0xa585d5+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x316399){_0x316399();}['execute'](_0x3e86ad,_0x19c5d6){return Promise['resolve']('token');}['render'](_0x4a71f3,_0x15c713){return'';}}class Wf{['ready'](_0x1f45a6){_0x1f45a6();}['execute'](_0x29c412,_0x5c80c1){return Promise['resolve']('token');}['render'](_0x4df94f,_0x30da37){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3a498c){this['type']=Bf,this['auth']=Ke(_0x3a498c);}async['verify'](_0x75b8ca='verify',_0x49b5aa=!0x1){async function _0x502754(_0x428bee){if(!_0x49b5aa){if(_0x428bee['tenantId']==null&&_0x428bee['_agentRecaptchaConfig']!=null)return _0x428bee['_agentRecaptchaConfig']['siteKey'];if(_0x428bee['tenantId']!=null&&_0x428bee['_tenantRecaptchaConfigs'][_0x428bee['tenantId']]!==void 0x0)return _0x428bee['_tenantRecaptchaConfigs'][_0x428bee['tenantId']]['siteKey'];}return new Promise(async(_0x58a921,_0x297dd7)=>{yf(_0x428bee,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4ce190=>{if(_0x4ce190['recaptchaKey']===void 0x0)_0x297dd7(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x55f32b=new mf(_0x4ce190);return _0x428bee['tenantId']==null?_0x428bee['_agentRecaptchaConfig']=_0x55f32b:_0x428bee['_tenantRecaptchaConfigs'][_0x428bee['tenantId']]=_0x55f32b,_0x58a921(_0x55f32b['siteKey']);}})['catch'](_0x323b49=>{_0x297dd7(_0x323b49);});});}function _0x4da904(_0x3b1358,_0x2f66fe,_0x23accb){const _0x93a078=window['grecaptcha'];wr(_0x93a078)?_0x93a078['enterprise']['ready'](()=>{_0x93a078['enterprise']['execute'](_0x3b1358,{'action':_0x75b8ca})['then'](_0x4fc0ac=>{_0x2f66fe(_0x4fc0ac);})['catch'](()=>{_0x2f66fe(Fa);});}):_0x23accb(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xb2d0c3,_0x2c4998)=>{_0x502754(this['auth'])['then'](async _0x1cf209=>{if(!_0x49b5aa&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x4da904(_0x1cf209,_0xb2d0c3,_0x2c4998);else{if(typeof window>'u'){_0x2c4998(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1748a0=Lf();_0x1748a0['length']!==0x0&&(_0x1748a0+=_0x1cf209+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x470208;(_0x470208=he['scriptInjectionDeferred'])==null||_0x470208['resolve']();},xa(_0x1748a0)['then'](()=>{var _0x1dca64;return(_0x1dca64=he['scriptInjectionDeferred'])==null?void 0x0:_0x1dca64['promise'];})['then'](()=>{_0x4da904(_0x1cf209,_0xb2d0c3,_0x2c4998);})['catch'](_0x99cd4c=>{_0x2c4998(_0x99cd4c);});}})['catch'](_0x478bb6=>{_0x2c4998(_0x478bb6);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x59d7eb,_0x38ec8b,_0x44eea9,_0xb2fb22=!0x1,_0x5ef769=!0x1){const _0x48a2d5=new he(_0x59d7eb);let _0x284a18;if(_0x5ef769)_0x284a18=Fa;else try{_0x284a18=await _0x48a2d5['verify'](_0x44eea9);}catch{_0x284a18=await _0x48a2d5['verify'](_0x44eea9,!0x0);}const _0x2c1e13={..._0x38ec8b};if(_0x44eea9==='mfaSmsEnrollment'||_0x44eea9==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2c1e13){const _0x2c6dd0=_0x2c1e13['phoneEnrollmentInfo']['phoneNumber'],_0x35fcbe=_0x2c1e13['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2c1e13,{'phoneEnrollmentInfo':{'phoneNumber':_0x2c6dd0,'recaptchaToken':_0x35fcbe,'captchaResponse':_0x284a18,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2c1e13){const _0x8bd151=_0x2c1e13['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2c1e13,{'phoneSignInInfo':{'recaptchaToken':_0x8bd151,'captchaResponse':_0x284a18,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2c1e13;}return _0xb2fb22?Object['assign'](_0x2c1e13,{'captchaResp':_0x284a18}):Object['assign'](_0x2c1e13,{'captchaResponse':_0x284a18}),Object['assign'](_0x2c1e13,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2c1e13,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2c1e13;}async function xi(_0x492d0b,_0xf12e50,_0x1631a9,_0x356d2d,_0x3d4789){var _0x2f1c09;if((_0x2f1c09=_0x492d0b['_getRecaptchaConfig']())!=null&&_0x2f1c09['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5cac67=await kr(_0x492d0b,_0xf12e50,_0x1631a9,_0x1631a9==='getOobCode');return _0x356d2d(_0x492d0b,_0x5cac67);}else return _0x356d2d(_0x492d0b,_0xf12e50)['catch'](async _0x39163d=>{if(_0x39163d['code']==='auth/missing-recaptcha-token'){console['log'](_0x1631a9+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xd05a18=await kr(_0x492d0b,_0xf12e50,_0x1631a9,_0x1631a9==='getOobCode');return _0x356d2d(_0x492d0b,_0xd05a18);}else return Promise['reject'](_0x39163d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1dc4b8,_0x51d37a){const _0x5aea60=Hi(_0x1dc4b8,'auth');if(_0x5aea60['isInitialized']()){const _0x5933a2=_0x5aea60['getImmediate'](),_0x2edff0=_0x5aea60['getOptions']();if(xe(_0x2edff0,_0x51d37a??{}))return _0x5933a2;Y(_0x5933a2,'already-initialized');}return _0x5aea60['initialize']({'options':_0x51d37a});}function Hf(_0x1e75f1,_0x1ae3b6){const _0x1bf6f1=(_0x1ae3b6==null?void 0x0:_0x1ae3b6['persistence'])||[],_0x12a00b=(Array['isArray'](_0x1bf6f1)?_0x1bf6f1:[_0x1bf6f1])['map'](ie);_0x1ae3b6!=null&&_0x1ae3b6['errorMap']&&_0x1e75f1['_updateErrorMap'](_0x1ae3b6['errorMap']),_0x1e75f1['_initializeWithPersistence'](_0x12a00b,_0x1ae3b6==null?void 0x0:_0x1ae3b6['popupRedirectResolver']);}function $f(_0x55b122,_0x2267ec,_0x30b084){const _0x3b607f=Ke(_0x55b122);m(/^https?:\/\//['test'](_0x2267ec),_0x3b607f,'invalid-emulator-scheme');const _0x4b6a29=!0x1,_0xf6d48e=Ua(_0x2267ec),{host:_0x38ee32,port:_0x1fca72}=Gf(_0x2267ec),_0x2e5c48=_0x1fca72===null?'':':'+_0x1fca72,_0x20a539={'url':_0xf6d48e+'//'+_0x38ee32+_0x2e5c48+'/'},_0xacb9cb=Object['freeze']({'host':_0x38ee32,'port':_0x1fca72,'protocol':_0xf6d48e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4b6a29})});if(!_0x3b607f['_canInitEmulator']){m(_0x3b607f['config']['emulator']&&_0x3b607f['emulatorConfig'],_0x3b607f,'emulator-config-failed'),m(xe(_0x20a539,_0x3b607f['config']['emulator'])&&xe(_0xacb9cb,_0x3b607f['emulatorConfig']),_0x3b607f,'emulator-config-failed');return;}_0x3b607f['config']['emulator']=_0x20a539,_0x3b607f['emulatorConfig']=_0xacb9cb,_0x3b607f['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x38ee32)?Qr(_0xf6d48e+'//'+_0x38ee32+_0x2e5c48):qf();}function Ua(_0x1ac747){const _0x10c7bf=_0x1ac747['indexOf'](':');return _0x10c7bf<0x0?'':_0x1ac747['substr'](0x0,_0x10c7bf+0x1);}function Gf(_0x3acac3){const _0x290045=Ua(_0x3acac3),_0x3f2f7b=/(\/\/)?([^?#/]+)/['exec'](_0x3acac3['substr'](_0x290045['length']));if(!_0x3f2f7b)return{'host':'','port':null};const _0x5d7b3f=_0x3f2f7b[0x2]['split']('@')['pop']()||'',_0x300c92=/^(\[[^\]]+\])(:|$)/['exec'](_0x5d7b3f);if(_0x300c92){const _0x127a95=_0x300c92[0x1];return{'host':_0x127a95,'port':Pr(_0x5d7b3f['substr'](_0x127a95['length']+0x1))};}else{const [_0x216575,_0x96b6d4]=_0x5d7b3f['split'](':');return{'host':_0x216575,'port':Pr(_0x96b6d4)};}}function Pr(_0x8c9c7d){if(!_0x8c9c7d)return null;const _0x425921=Number(_0x8c9c7d);return isNaN(_0x425921)?null:_0x425921;}function qf(){function _0x2a2f6e(){const _0xafca08=document['createElement']('p'),_0x306abd=_0xafca08['style'];_0xafca08['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x306abd['position']='fixed',_0x306abd['width']='100%',_0x306abd['backgroundColor']='#ffffff',_0x306abd['border']='.1em\x20solid\x20#000000',_0x306abd['color']='#b50000',_0x306abd['bottom']='0px',_0x306abd['left']='0px',_0x306abd['margin']='0px',_0x306abd['zIndex']='10000',_0x306abd['textAlign']='center',_0xafca08['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xafca08);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2a2f6e):_0x2a2f6e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x1daac2,_0x28c573){this['providerId']=_0x1daac2,this['signInMethod']=_0x28c573;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3bc49c){return ne('not\x20implemented');}['_linkToIdToken'](_0x235890,_0x428786){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x5ebaa0){return ne('not\x20implemented');}}async function zf(_0x33762,_0x405ed4){return Pe(_0x33762,'POST','/v1/accounts:signUp',_0x405ed4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x459113,_0x3c2c2b){return en(_0x459113,'POST','/v1/accounts:signInWithPassword',ke(_0x459113,_0x3c2c2b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x132ace,_0x1314c2){return en(_0x132ace,'POST','/v1/accounts:signInWithEmailLink',ke(_0x132ace,_0x1314c2));}async function Yf(_0x35a297,_0x18f7b6){return en(_0x35a297,'POST','/v1/accounts:signInWithEmailLink',ke(_0x35a297,_0x18f7b6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x5acc31,_0x433261,_0x2cdf1e,_0x322d90=null){super('password',_0x2cdf1e),this['_email']=_0x5acc31,this['_password']=_0x433261,this['_tenantId']=_0x322d90;}static['_fromEmailAndPassword'](_0x542b7c,_0x1ce6eb){return new $t(_0x542b7c,_0x1ce6eb,'password');}static['_fromEmailAndCode'](_0x581a9f,_0x38ab61,_0x125260=null){return new $t(_0x581a9f,_0x38ab61,'emailLink',_0x125260);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1e4888){const _0x501d70=typeof _0x1e4888=='string'?JSON['parse'](_0x1e4888):_0x1e4888;if(_0x501d70!=null&&_0x501d70['email']&&(_0x501d70!=null&&_0x501d70['password'])){if(_0x501d70['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x501d70['email'],_0x501d70['password']);if(_0x501d70['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x501d70['email'],_0x501d70['password'],_0x501d70['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1f0581){switch(this['signInMethod']){case'password':const _0x388568={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1f0581,_0x388568,'signInWithPassword',jf);case'emailLink':return Kf(_0x1f0581,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1f0581,'internal-error');}}async['_linkToIdToken'](_0x57f220,_0x4c75a9){switch(this['signInMethod']){case'password':const _0x3dd2e7={'idToken':_0x4c75a9,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x57f220,_0x3dd2e7,'signUpPassword',zf);case'emailLink':return Yf(_0x57f220,{'idToken':_0x4c75a9,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x57f220,'internal-error');}}['_getReauthenticationResolver'](_0x1a3c3f){return this['_getIdTokenResponse'](_0x1a3c3f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x11e8d2,_0x274e8a){return en(_0x11e8d2,'POST','/v1/accounts:signInWithIdp',ke(_0x11e8d2,_0x274e8a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5cf45e){const _0x3dd4eb=new $e(_0x5cf45e['providerId'],_0x5cf45e['signInMethod']);return _0x5cf45e['idToken']||_0x5cf45e['accessToken']?(_0x5cf45e['idToken']&&(_0x3dd4eb['idToken']=_0x5cf45e['idToken']),_0x5cf45e['accessToken']&&(_0x3dd4eb['accessToken']=_0x5cf45e['accessToken']),_0x5cf45e['nonce']&&!_0x5cf45e['pendingToken']&&(_0x3dd4eb['nonce']=_0x5cf45e['nonce']),_0x5cf45e['pendingToken']&&(_0x3dd4eb['pendingToken']=_0x5cf45e['pendingToken'])):_0x5cf45e['oauthToken']&&_0x5cf45e['oauthTokenSecret']?(_0x3dd4eb['accessToken']=_0x5cf45e['oauthToken'],_0x3dd4eb['secret']=_0x5cf45e['oauthTokenSecret']):Y('argument-error'),_0x3dd4eb;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4fd27f){const _0x16ff67=typeof _0x4fd27f=='string'?JSON['parse'](_0x4fd27f):_0x4fd27f,{providerId:_0x4ed274,signInMethod:_0x4b895c,..._0x17b19c}=_0x16ff67;if(!_0x4ed274||!_0x4b895c)return null;const _0x1883ae=new $e(_0x4ed274,_0x4b895c);return _0x1883ae['idToken']=_0x17b19c['idToken']||void 0x0,_0x1883ae['accessToken']=_0x17b19c['accessToken']||void 0x0,_0x1883ae['secret']=_0x17b19c['secret'],_0x1883ae['nonce']=_0x17b19c['nonce'],_0x1883ae['pendingToken']=_0x17b19c['pendingToken']||null,_0x1883ae;}['_getIdTokenResponse'](_0x37e7af){const _0x54926f=this['buildRequest']();return nt(_0x37e7af,_0x54926f);}['_linkToIdToken'](_0x56f109,_0x59f673){const _0x16232d=this['buildRequest']();return _0x16232d['idToken']=_0x59f673,nt(_0x56f109,_0x16232d);}['_getReauthenticationResolver'](_0x4c9dca){const _0x31b325=this['buildRequest']();return _0x31b325['autoCreate']=!0x1,nt(_0x4c9dca,_0x31b325);}['buildRequest'](){const _0xb909b7={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0xb909b7['pendingToken']=this['pendingToken'];else{const _0x5d7f5e={};this['idToken']&&(_0x5d7f5e['id_token']=this['idToken']),this['accessToken']&&(_0x5d7f5e['access_token']=this['accessToken']),this['secret']&&(_0x5d7f5e['oauth_token_secret']=this['secret']),_0x5d7f5e['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5d7f5e['nonce']=this['nonce']),_0xb909b7['postBody']=ut(_0x5d7f5e);}return _0xb909b7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x21a00f){switch(_0x21a00f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x16cb27){const _0x35b6e6=Ct(Tt(_0x16cb27))['link'],_0x2431d9=_0x35b6e6?Ct(Tt(_0x35b6e6))['deep_link_id']:null,_0x44fd41=Ct(Tt(_0x16cb27))['deep_link_id'];return(_0x44fd41?Ct(Tt(_0x44fd41))['link']:null)||_0x44fd41||_0x2431d9||_0x35b6e6||_0x16cb27;}class Rs{constructor(_0x3d740d){const _0x42eeaa=Ct(Tt(_0x3d740d)),_0x31c00d=_0x42eeaa['apiKey']??null,_0x1b86ba=_0x42eeaa['oobCode']??null,_0x405149=Jf(_0x42eeaa['mode']??null);m(_0x31c00d&&_0x1b86ba&&_0x405149,'argument-error'),this['apiKey']=_0x31c00d,this['operation']=_0x405149,this['code']=_0x1b86ba,this['continueUrl']=_0x42eeaa['continueUrl']??null,this['languageCode']=_0x42eeaa['lang']??null,this['tenantId']=_0x42eeaa['tenantId']??null;}static['parseLink'](_0x400345){const _0x148a25=Xf(_0x400345);try{return new Rs(_0x148a25);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x336166,_0x7c542){return $t['_fromEmailAndPassword'](_0x336166,_0x7c542);}static['credentialWithLink'](_0x1254ee,_0x346e4d){const _0x1705fb=Rs['parseLink'](_0x346e4d);return m(_0x1705fb,'argument-error'),$t['_fromEmailAndCode'](_0x1254ee,_0x1705fb['code'],_0x1705fb['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x26f201){this['providerId']=_0x26f201,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3971c0){this['defaultLanguageCode']=_0x3971c0;}['setCustomParameters'](_0x42b20e){return this['customParameters']=_0x42b20e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3aff82){return this['scopes']['includes'](_0x3aff82)||this['scopes']['push'](_0x3aff82),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4d83ad){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4d83ad});}static['credentialFromResult'](_0x5f3f32){return ue['credentialFromTaggedObject'](_0x5f3f32);}static['credentialFromError'](_0xed2cad){return ue['credentialFromTaggedObject'](_0xed2cad['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1df23d}){if(!_0x1df23d||!('oauthAccessToken'in _0x1df23d)||!_0x1df23d['oauthAccessToken'])return null;try{return ue['credential'](_0x1df23d['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x14bbac,_0x23c3d5){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x14bbac,'accessToken':_0x23c3d5});}static['credentialFromResult'](_0x311b77){return de['credentialFromTaggedObject'](_0x311b77);}static['credentialFromError'](_0xf5975){return de['credentialFromTaggedObject'](_0xf5975['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xe327b9}){if(!_0xe327b9)return null;const {oauthIdToken:_0x12cfc0,oauthAccessToken:_0x165c7b}=_0xe327b9;if(!_0x12cfc0&&!_0x165c7b)return null;try{return de['credential'](_0x12cfc0,_0x165c7b);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x46feb5){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x46feb5});}static['credentialFromResult'](_0x5c1bbf){return fe['credentialFromTaggedObject'](_0x5c1bbf);}static['credentialFromError'](_0x3f1603){return fe['credentialFromTaggedObject'](_0x3f1603['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x24025f}){if(!_0x24025f||!('oauthAccessToken'in _0x24025f)||!_0x24025f['oauthAccessToken'])return null;try{return fe['credential'](_0x24025f['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x510938,_0x4da515){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x510938,'oauthTokenSecret':_0x4da515});}static['credentialFromResult'](_0x3ed413){return pe['credentialFromTaggedObject'](_0x3ed413);}static['credentialFromError'](_0x4a2aa1){return pe['credentialFromTaggedObject'](_0x4a2aa1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd1a195}){if(!_0xd1a195)return null;const {oauthAccessToken:_0x228cf1,oauthTokenSecret:_0xd0d603}=_0xd1a195;if(!_0x228cf1||!_0xd0d603)return null;try{return pe['credential'](_0x228cf1,_0xd0d603);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3931b9,_0x41aa1e){return en(_0x3931b9,'POST','/v1/accounts:signUp',ke(_0x3931b9,_0x41aa1e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x23cd98){this['user']=_0x23cd98['user'],this['providerId']=_0x23cd98['providerId'],this['_tokenResponse']=_0x23cd98['_tokenResponse'],this['operationType']=_0x23cd98['operationType'];}static async['_fromIdTokenResponse'](_0x191934,_0x27f37a,_0x4bb187,_0x3a8b1c=!0x1){const _0x5db98d=await j['_fromIdTokenResponse'](_0x191934,_0x4bb187,_0x3a8b1c),_0xb9b916=Nr(_0x4bb187);return new Ge({'user':_0x5db98d,'providerId':_0xb9b916,'_tokenResponse':_0x4bb187,'operationType':_0x27f37a});}static async['_forOperation'](_0x2ca1fa,_0x674293,_0x2787f9){await _0x2ca1fa['_updateTokensIfNecessary'](_0x2787f9,!0x0);const _0x23268c=Nr(_0x2787f9);return new Ge({'user':_0x2ca1fa,'providerId':_0x23268c,'_tokenResponse':_0x2787f9,'operationType':_0x674293});}}function Nr(_0x265fe8){return _0x265fe8['providerId']?_0x265fe8['providerId']:'phoneNumber'in _0x265fe8?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x11d350,_0x870528,_0x312fcf,_0x2375e6){super(_0x870528['code'],_0x870528['message']),this['operationType']=_0x312fcf,this['user']=_0x2375e6,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x11d350['name'],'tenantId':_0x11d350['tenantId']??void 0x0,'_serverResponse':_0x870528['customData']['_serverResponse'],'operationType':_0x312fcf};}static['_fromErrorAndOperation'](_0x3c66d5,_0x4edf0a,_0x12fff5,_0x2c5c18){return new On(_0x3c66d5,_0x4edf0a,_0x12fff5,_0x2c5c18);}}function Ba(_0x52ae14,_0x31f986,_0x33bf29,_0x339461){return(_0x31f986==='reauthenticate'?_0x33bf29['_getReauthenticationResolver'](_0x52ae14):_0x33bf29['_getIdTokenResponse'](_0x52ae14))['catch'](_0x307f9c=>{throw _0x307f9c['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x52ae14,_0x307f9c,_0x31f986,_0x339461):_0x307f9c;});}async function ep(_0x12e9c6,_0x5754b8,_0x41b6b4=!0x1){const _0x48318f=await Ht(_0x12e9c6,_0x5754b8['_linkToIdToken'](_0x12e9c6['auth'],await _0x12e9c6['getIdToken']()),_0x41b6b4);return Ge['_forOperation'](_0x12e9c6,'link',_0x48318f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x2b289e,_0x19383a,_0x4d61e7=!0x1){const {auth:_0x2659f3}=_0x2b289e;if($(_0x2659f3['app']))return Promise['reject'](re(_0x2659f3));const _0x19007f='reauthenticate';try{const _0x42ed3d=await Ht(_0x2b289e,Ba(_0x2659f3,_0x19007f,_0x19383a,_0x2b289e),_0x4d61e7);m(_0x42ed3d['idToken'],_0x2659f3,'internal-error');const _0x296851=Ts(_0x42ed3d['idToken']);m(_0x296851,_0x2659f3,'internal-error');const {sub:_0x1bc601}=_0x296851;return m(_0x2b289e['uid']===_0x1bc601,_0x2659f3,'user-mismatch'),Ge['_forOperation'](_0x2b289e,_0x19007f,_0x42ed3d);}catch(_0x16874d){throw(_0x16874d==null?void 0x0:_0x16874d['code'])==='auth/user-not-found'&&Y(_0x2659f3,'user-mismatch'),_0x16874d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2bd2c7,_0x5cf122,_0x4aee31=!0x1){if($(_0x2bd2c7['app']))return Promise['reject'](re(_0x2bd2c7));const _0x25e4f5='signIn',_0x5d205b=await Ba(_0x2bd2c7,_0x25e4f5,_0x5cf122),_0x3a1dfe=await Ge['_fromIdTokenResponse'](_0x2bd2c7,_0x25e4f5,_0x5d205b);return _0x4aee31||await _0x2bd2c7['_updateCurrentUser'](_0x3a1dfe['user']),_0x3a1dfe;}async function np(_0xe97d43,_0x3aab81){return Va(Ke(_0xe97d43),_0x3aab81);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xed5d9d){const _0x255312=Ke(_0xed5d9d);_0x255312['_getPasswordPolicyInternal']()&&await _0x255312['_updatePasswordPolicy']();}async function L_(_0x315cde,_0x3b7499,_0x33c297){if($(_0x315cde['app']))return Promise['reject'](re(_0x315cde));const _0x57bf04=Ke(_0x315cde),_0x166c7a=await xi(_0x57bf04,{'returnSecureToken':!0x0,'email':_0x3b7499,'password':_0x33c297,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x2b392f=>{throw _0x2b392f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x315cde),_0x2b392f;}),_0x55b16e=await Ge['_fromIdTokenResponse'](_0x57bf04,'signIn',_0x166c7a);return await _0x57bf04['_updateCurrentUser'](_0x55b16e['user']),_0x55b16e;}function x_(_0x269a5f,_0x82de3f,_0x5cee9f){return $(_0x269a5f['app'])?Promise['reject'](re(_0x269a5f)):np(P(_0x269a5f),yt['credential'](_0x82de3f,_0x5cee9f))['catch'](async _0x3ebde8=>{throw _0x3ebde8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x269a5f),_0x3ebde8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x5ab03d,_0x28cbe6){return P(_0x5ab03d)['setPersistence'](_0x28cbe6);}function ip(_0x3e4bca,_0x4b86f4,_0xd8a42d,_0xbad865){return P(_0x3e4bca)['onIdTokenChanged'](_0x4b86f4,_0xd8a42d,_0xbad865);}function sp(_0x150958,_0x548004,_0x2e08ff){return P(_0x150958)['beforeAuthStateChanged'](_0x548004,_0x2e08ff);}function U_(_0x5afd38,_0x43f26b,_0x2babec,_0x2a339a){return P(_0x5afd38)['onAuthStateChanged'](_0x43f26b,_0x2babec,_0x2a339a);}function W_(_0x2f0226){return P(_0x2f0226)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4a9f0d,_0x3ab5bc){this['storageRetriever']=_0x4a9f0d,this['type']=_0x3ab5bc;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1d3631,_0xd029ad){return this['storage']['setItem'](_0x1d3631,JSON['stringify'](_0xd029ad)),Promise['resolve']();}['_get'](_0x549b3a){const _0x5f2282=this['storage']['getItem'](_0x549b3a);return Promise['resolve'](_0x5f2282?JSON['parse'](_0x5f2282):null);}['_remove'](_0x3def80){return this['storage']['removeItem'](_0x3def80),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4d83a6,_0x464ccc)=>this['onStorageEvent'](_0x4d83a6,_0x464ccc),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x2a4f33){for(const _0x171355 of Object['keys'](this['listeners'])){const _0x1698c9=this['storage']['getItem'](_0x171355),_0x502eba=this['localCache'][_0x171355];_0x1698c9!==_0x502eba&&_0x2a4f33(_0x171355,_0x502eba,_0x1698c9);}}['onStorageEvent'](_0x1c7ba9,_0x554924=!0x1){if(!_0x1c7ba9['key']){this['forAllChangedKeys']((_0x3a8c7a,_0x5e0480,_0x2a02dd)=>{this['notifyListeners'](_0x3a8c7a,_0x2a02dd);});return;}const _0xf55bae=_0x1c7ba9['key'];_0x554924?this['detachListener']():this['stopPolling']();const _0x74c58c=()=>{const _0x141e3d=this['storage']['getItem'](_0xf55bae);!_0x554924&&this['localCache'][_0xf55bae]===_0x141e3d||this['notifyListeners'](_0xf55bae,_0x141e3d);},_0x5b745e=this['storage']['getItem'](_0xf55bae);Af()&&_0x5b745e!==_0x1c7ba9['newValue']&&_0x1c7ba9['newValue']!==_0x1c7ba9['oldValue']?setTimeout(_0x74c58c,op):_0x74c58c();}['notifyListeners'](_0x4cd09f,_0x518884){this['localCache'][_0x4cd09f]=_0x518884;const _0x93b838=this['listeners'][_0x4cd09f];if(_0x93b838){for(const _0x3145b4 of Array['from'](_0x93b838))_0x3145b4(_0x518884&&JSON['parse'](_0x518884));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2b8160,_0x19a08b,_0x351c63)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2b8160,'oldValue':_0x19a08b,'newValue':_0x351c63}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x556ce6,_0x17562d){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x556ce6]||(this['listeners'][_0x556ce6]=new Set(),this['localCache'][_0x556ce6]=this['storage']['getItem'](_0x556ce6)),this['listeners'][_0x556ce6]['add'](_0x17562d);}['_removeListener'](_0x5ab9dd,_0x2d5f45){this['listeners'][_0x5ab9dd]&&(this['listeners'][_0x5ab9dd]['delete'](_0x2d5f45),this['listeners'][_0x5ab9dd]['size']===0x0&&delete this['listeners'][_0x5ab9dd]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x55a535,_0x32d876){await super['_set'](_0x55a535,_0x32d876),this['localCache'][_0x55a535]=JSON['stringify'](_0x32d876);}async['_get'](_0x5c78c0){const _0x242f1a=await super['_get'](_0x5c78c0);return this['localCache'][_0x5c78c0]=JSON['stringify'](_0x242f1a),_0x242f1a;}async['_remove'](_0x539890){await super['_remove'](_0x539890),delete this['localCache'][_0x539890];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2d35ca,_0x3693c8){}['_removeListener'](_0x37eea2,_0xbeb322){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x43d6ff){return Promise['all'](_0x43d6ff['map'](async _0x3c53d0=>{try{return{'fulfilled':!0x0,'value':await _0x3c53d0};}catch(_0x3bf4bc){return{'fulfilled':!0x1,'reason':_0x3bf4bc};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x55d659){this['eventTarget']=_0x55d659,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x37ca67){const _0x3fe719=this['receivers']['find'](_0x2786f2=>_0x2786f2['isListeningto'](_0x37ca67));if(_0x3fe719)return _0x3fe719;const _0x44f609=new Xn(_0x37ca67);return this['receivers']['push'](_0x44f609),_0x44f609;}['isListeningto'](_0x4679bd){return this['eventTarget']===_0x4679bd;}async['handleEvent'](_0x29ce3d){const _0xc52609=_0x29ce3d,{eventId:_0x1beb7e,eventType:_0x135335,data:_0x243052}=_0xc52609['data'],_0x429440=this['handlersMap'][_0x135335];if(!(_0x429440!=null&&_0x429440['size']))return;_0xc52609['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1beb7e,'eventType':_0x135335});const _0x4923fc=Array['from'](_0x429440)['map'](async _0x18207a=>_0x18207a(_0xc52609['origin'],_0x243052)),_0x5a537a=await cp(_0x4923fc);_0xc52609['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1beb7e,'eventType':_0x135335,'response':_0x5a537a});}['_subscribe'](_0x48b0a4,_0x25d43b){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x48b0a4]||(this['handlersMap'][_0x48b0a4]=new Set()),this['handlersMap'][_0x48b0a4]['add'](_0x25d43b);}['_unsubscribe'](_0x23cee0,_0x204504){this['handlersMap'][_0x23cee0]&&_0x204504&&this['handlersMap'][_0x23cee0]['delete'](_0x204504),(!_0x204504||this['handlersMap'][_0x23cee0]['size']===0x0)&&delete this['handlersMap'][_0x23cee0],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5e279c='',_0x5262da=0xa){let _0x3bdefd='';for(let _0x31110c=0x0;_0x31110c<_0x5262da;_0x31110c++)_0x3bdefd+=Math['floor'](Math['random']()*0xa);return _0x5e279c+_0x3bdefd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x37d303){this['target']=_0x37d303,this['handlers']=new Set();}['removeMessageHandler'](_0x170158){_0x170158['messageChannel']&&(_0x170158['messageChannel']['port1']['removeEventListener']('message',_0x170158['onMessage']),_0x170158['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x170158);}async['_send'](_0xfcfbef,_0x480326,_0x54ce7f=0x32){const _0x1bd496=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1bd496)throw new Error('connection_unavailable');let _0x2788dc,_0x190476;return new Promise((_0x5e26dc,_0x20d5aa)=>{const _0x44d868=As('',0x14);_0x1bd496['port1']['start']();const _0x116fd2=setTimeout(()=>{_0x20d5aa(new Error('unsupported_event'));},_0x54ce7f);_0x190476={'messageChannel':_0x1bd496,'onMessage'(_0x43c093){const _0x2c80a3=_0x43c093;if(_0x2c80a3['data']['eventId']===_0x44d868)switch(_0x2c80a3['data']['status']){case'ack':clearTimeout(_0x116fd2),_0x2788dc=setTimeout(()=>{_0x20d5aa(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2788dc),_0x5e26dc(_0x2c80a3['data']['response']);break;default:clearTimeout(_0x116fd2),clearTimeout(_0x2788dc),_0x20d5aa(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x190476),_0x1bd496['port1']['addEventListener']('message',_0x190476['onMessage']),this['target']['postMessage']({'eventType':_0xfcfbef,'eventId':_0x44d868,'data':_0x480326},[_0x1bd496['port2']]);})['finally'](()=>{_0x190476&&this['removeMessageHandler'](_0x190476);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4fe8b1){Z()['location']['href']=_0x4fe8b1;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x235165;return((_0x235165=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x235165['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x321508){this['request']=_0x321508;}['toPromise'](){return new Promise((_0x1f983a,_0xfd56e)=>{this['request']['addEventListener']('success',()=>{_0x1f983a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xfd56e(this['request']['error']);});});}}function Zn(_0x395713,_0x549b90){return _0x395713['transaction']([Mn],_0x549b90?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x19f08d=indexedDB['deleteDatabase'](Ka);return new nn(_0x19f08d)['toPromise']();}function Qa(){const _0x10ae8f=indexedDB['open'](Ka,pp);return new Promise((_0x3f5ce1,_0x1d0c63)=>{_0x10ae8f['addEventListener']('error',()=>{_0x1d0c63(_0x10ae8f['error']);}),_0x10ae8f['addEventListener']('upgradeneeded',()=>{const _0x38b00c=_0x10ae8f['result'];try{_0x38b00c['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x53d932){_0x1d0c63(_0x53d932);}}),_0x10ae8f['addEventListener']('success',async()=>{const _0xbe6f22=_0x10ae8f['result'];_0xbe6f22['objectStoreNames']['contains'](Mn)?_0x3f5ce1(_0xbe6f22):(_0xbe6f22['close'](),await _p(),_0x3f5ce1(await Qa()));});});}async function Or(_0x192f5b,_0xc7d9d8,_0x2734c0){const _0x11ec07=Zn(_0x192f5b,!0x0)['put']({[Ya]:_0xc7d9d8,'value':_0x2734c0});return new nn(_0x11ec07)['toPromise']();}async function gp(_0x5ac867,_0x2364e2){const _0x5da1e3=Zn(_0x5ac867,!0x1)['get'](_0x2364e2),_0x2d1710=await new nn(_0x5da1e3)['toPromise']();return _0x2d1710===void 0x0?null:_0x2d1710['value'];}function Dr(_0x2cde4d,_0x53a6b4){const _0x245fd1=Zn(_0x2cde4d,!0x0)['delete'](_0x53a6b4);return new nn(_0x245fd1)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x4f9487){let _0xae8cf6=0x0;for(;;)try{const _0x5de814=await this['_openDb']();return await _0x4f9487(_0x5de814);}catch(_0x4bf80f){if(_0xae8cf6++>yp)throw _0x4bf80f;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x4fd849,_0x10f6f0)=>({'keyProcessed':(await this['_poll']())['includes'](_0x10f6f0['key'])})),this['receiver']['_subscribe']('ping',async(_0x2c29b9,_0x415a1b)=>['keyChanged']);}async['initializeSender'](){var _0x39b5e1,_0x330e10;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x55b224=await this['sender']['_send']('ping',{},0x320);_0x55b224&&(_0x39b5e1=_0x55b224[0x0])!=null&&_0x39b5e1['fulfilled']&&(_0x330e10=_0x55b224[0x0])!=null&&_0x330e10['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x155c65){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x155c65},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x11a55e=>{await Or(_0x11a55e,Dn,'1'),await Dr(_0x11a55e,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x4ac054){this['pendingWrites']++;try{await _0x4ac054();}finally{this['pendingWrites']--;}}async['_set'](_0x43ed1f,_0x449369){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x21c508=>Or(_0x21c508,_0x43ed1f,_0x449369)),this['localCache'][_0x43ed1f]=_0x449369,this['notifyServiceWorker'](_0x43ed1f)));}async['_get'](_0x639c6b){const _0x4f079d=await this['_withRetries'](_0x1a1734=>gp(_0x1a1734,_0x639c6b));return this['localCache'][_0x639c6b]=_0x4f079d,_0x4f079d;}async['_remove'](_0x20fc53){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x286d6a=>Dr(_0x286d6a,_0x20fc53)),delete this['localCache'][_0x20fc53],this['notifyServiceWorker'](_0x20fc53)));}async['_poll'](){const _0x149a4f=await this['_withRetries'](_0xb16eb4=>{const _0x1ffd3d=Zn(_0xb16eb4,!0x1)['getAll']();return new nn(_0x1ffd3d)['toPromise']();});if(!_0x149a4f)return[];if(this['pendingWrites']!==0x0)return[];const _0x520259=[],_0x135794=new Set();if(_0x149a4f['length']!==0x0){for(const {fbase_key:_0x42a47a,value:_0x4aa92d}of _0x149a4f)_0x135794['add'](_0x42a47a),JSON['stringify'](this['localCache'][_0x42a47a])!==JSON['stringify'](_0x4aa92d)&&(this['notifyListeners'](_0x42a47a,_0x4aa92d),_0x520259['push'](_0x42a47a));}for(const _0x5c4820 of Object['keys'](this['localCache']))this['localCache'][_0x5c4820]&&!_0x135794['has'](_0x5c4820)&&(this['notifyListeners'](_0x5c4820,null),_0x520259['push'](_0x5c4820));return _0x520259;}['notifyListeners'](_0x5928b7,_0x3e7280){this['localCache'][_0x5928b7]=_0x3e7280;const _0x153286=this['listeners'][_0x5928b7];if(_0x153286){for(const _0x19a77f of Array['from'](_0x153286))_0x19a77f(_0x3e7280);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0xd33a79,_0x3db0cf){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0xd33a79]||(this['listeners'][_0xd33a79]=new Set(),this['_get'](_0xd33a79)),this['listeners'][_0xd33a79]['add'](_0x3db0cf);}['_removeListener'](_0x3b6c8d,_0x400840){this['listeners'][_0x3b6c8d]&&(this['listeners'][_0x3b6c8d]['delete'](_0x400840),this['listeners'][_0x3b6c8d]['size']===0x0&&delete this['listeners'][_0x3b6c8d]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5e69a4,_0x28e7be){return _0x28e7be?ie(_0x28e7be):(m(_0x5e69a4['_popupRedirectResolver'],_0x5e69a4,'argument-error'),_0x5e69a4['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4d6d37){super('custom','custom'),this['params']=_0x4d6d37;}['_getIdTokenResponse'](_0x15ccd0){return nt(_0x15ccd0,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4b5f8b,_0xbdf63b){return nt(_0x4b5f8b,this['_buildIdpRequest'](_0xbdf63b));}['_getReauthenticationResolver'](_0x202d2f){return nt(_0x202d2f,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4eeb18){const _0x33bcbb={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4eeb18&&(_0x33bcbb['idToken']=_0x4eeb18),_0x33bcbb;}}function Ip(_0x921386){return Va(_0x921386['auth'],new ks(_0x921386),_0x921386['bypassAuthState']);}function wp(_0x539dac){const {auth:_0x221cab,user:_0x393662}=_0x539dac;return m(_0x393662,_0x221cab,'internal-error'),tp(_0x393662,new ks(_0x539dac),_0x539dac['bypassAuthState']);}async function Cp(_0x539ef3){const {auth:_0x12044e,user:_0x56c8de}=_0x539ef3;return m(_0x56c8de,_0x12044e,'internal-error'),ep(_0x56c8de,new ks(_0x539ef3),_0x539ef3['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x519df2,_0x245147,_0x5d639c,_0x2b6c32,_0xb65dd9=!0x1){this['auth']=_0x519df2,this['resolver']=_0x5d639c,this['user']=_0x2b6c32,this['bypassAuthState']=_0xb65dd9,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x245147)?_0x245147:[_0x245147];}['execute'](){return new Promise(async(_0x35a18a,_0x3f1657)=>{this['pendingPromise']={'resolve':_0x35a18a,'reject':_0x3f1657};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4ec692){this['reject'](_0x4ec692);}});}async['onAuthEvent'](_0x4eaf66){const {urlResponse:_0x3d3e6e,sessionId:_0x3471b2,postBody:_0x57bfad,tenantId:_0x34b667,error:_0x4d1935,type:_0x5aef47}=_0x4eaf66;if(_0x4d1935){this['reject'](_0x4d1935);return;}const _0x275da8={'auth':this['auth'],'requestUri':_0x3d3e6e,'sessionId':_0x3471b2,'tenantId':_0x34b667||void 0x0,'postBody':_0x57bfad||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5aef47)(_0x275da8));}catch(_0x39ed1b){this['reject'](_0x39ed1b);}}['onError'](_0x5ed6ef){this['reject'](_0x5ed6ef);}['getIdpTask'](_0x1cdf8d){switch(_0x1cdf8d){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x415e4){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x415e4),this['unregisterAndCleanUp']();}['reject'](_0x2f1aa8){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2f1aa8),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x623c24,_0x39bf46,_0x5bd5b9,_0x160377,_0x4022b1){super(_0x623c24,_0x39bf46,_0x160377,_0x4022b1),this['provider']=_0x5bd5b9,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1aa515=await this['execute']();return m(_0x1aa515,this['auth'],'internal-error'),_0x1aa515;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x513907=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x513907),this['authWindow']['associatedEvent']=_0x513907,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3a59bf=>{this['reject'](_0x3a59bf);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x35a130=>{_0x35a130||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1c1b18;return((_0x1c1b18=this['authWindow'])==null?void 0x0:_0x1c1b18['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0xf6ce98=()=>{var _0x540531,_0x5d0308;if((_0x5d0308=(_0x540531=this['authWindow'])==null?void 0x0:_0x540531['window'])!=null&&_0x5d0308['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xf6ce98,Tp['get']());};_0xf6ce98();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x1165af,_0x3d684f,_0x5c8803=!0x1){super(_0x1165af,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3d684f,void 0x0,_0x5c8803),this['eventId']=null;}async['execute'](){let _0x15d3ca=hn['get'](this['auth']['_key']());if(!_0x15d3ca){try{const _0x53f7c5=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x15d3ca=()=>Promise['resolve'](_0x53f7c5);}catch(_0xd99497){_0x15d3ca=()=>Promise['reject'](_0xd99497);}hn['set'](this['auth']['_key'](),_0x15d3ca);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x15d3ca();}async['onAuthEvent'](_0x3bb0d){if(_0x3bb0d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x3bb0d);if(_0x3bb0d['type']==='unknown'){this['resolve'](null);return;}if(_0x3bb0d['eventId']){const _0x2e064e=await this['auth']['_redirectUserForId'](_0x3bb0d['eventId']);if(_0x2e064e)return this['user']=_0x2e064e,super['onAuthEvent'](_0x3bb0d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x24650f,_0x331ad0){const _0x3bc3e1=Pp(_0x331ad0),_0x4838a7=kp(_0x24650f);if(!await _0x4838a7['_isAvailable']())return!0x1;const _0x2ce10c=await _0x4838a7['_get'](_0x3bc3e1)==='true';return await _0x4838a7['_remove'](_0x3bc3e1),_0x2ce10c;}function Ap(_0x2aa8fa,_0x48a24c){hn['set'](_0x2aa8fa['_key'](),_0x48a24c);}function kp(_0x7788ad){return ie(_0x7788ad['_redirectPersistence']);}function Pp(_0x5e78d7){return ln(Sp,_0x5e78d7['config']['apiKey'],_0x5e78d7['name']);}async function Np(_0x51550c,_0x5822b5,_0x35fc83=!0x1){if($(_0x51550c['app']))return Promise['reject'](re(_0x51550c));const _0x464952=Ke(_0x51550c),_0x576671=Ep(_0x464952,_0x5822b5),_0x46f1dc=await new bp(_0x464952,_0x576671,_0x35fc83)['execute']();return _0x46f1dc&&!_0x35fc83&&(delete _0x46f1dc['user']['_redirectEventId'],await _0x464952['_persistUserIfCurrent'](_0x46f1dc['user']),await _0x464952['_setRedirectUser'](null,_0x5822b5)),_0x46f1dc;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0xb31eb0){this['auth']=_0xb31eb0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x460645){this['consumers']['add'](_0x460645),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x460645)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x460645),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1ab2e4){this['consumers']['delete'](_0x1ab2e4);}['onEvent'](_0x33df3d){if(this['hasEventBeenHandled'](_0x33df3d))return!0x1;let _0x4becfe=!0x1;return this['consumers']['forEach'](_0xf22cc2=>{this['isEventForConsumer'](_0x33df3d,_0xf22cc2)&&(_0x4becfe=!0x0,this['sendToConsumer'](_0x33df3d,_0xf22cc2),this['saveEventToCache'](_0x33df3d));}),this['hasHandledPotentialRedirect']||!Mp(_0x33df3d)||(this['hasHandledPotentialRedirect']=!0x0,_0x4becfe||(this['queuedRedirectEvent']=_0x33df3d,_0x4becfe=!0x0)),_0x4becfe;}['sendToConsumer'](_0x1a3568,_0x557499){var _0x3312df;if(_0x1a3568['error']&&!Za(_0x1a3568)){const _0x432ede=((_0x3312df=_0x1a3568['error']['code'])==null?void 0x0:_0x3312df['split']('auth/')[0x1])||'internal-error';_0x557499['onError'](X(this['auth'],_0x432ede));}else _0x557499['onAuthEvent'](_0x1a3568);}['isEventForConsumer'](_0xf9aa45,_0x3b1641){const _0x65e2c3=_0x3b1641['eventId']===null||!!_0xf9aa45['eventId']&&_0xf9aa45['eventId']===_0x3b1641['eventId'];return _0x3b1641['filter']['includes'](_0xf9aa45['type'])&&_0x65e2c3;}['hasEventBeenHandled'](_0x98c378){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x98c378));}['saveEventToCache'](_0x31f32e){this['cachedEventUids']['add'](Mr(_0x31f32e)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1e6681){return[_0x1e6681['type'],_0x1e6681['eventId'],_0x1e6681['sessionId'],_0x1e6681['tenantId']]['filter'](_0x2d654c=>_0x2d654c)['join']('-');}function Za({type:_0x35962e,error:_0x2b03be}){return _0x35962e==='unknown'&&(_0x2b03be==null?void 0x0:_0x2b03be['code'])==='auth/no-auth-event';}function Mp(_0x456d6e){switch(_0x456d6e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x456d6e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1423b9,_0x2d7af2={}){return Pe(_0x1423b9,'GET','/v1/projects',_0x2d7af2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x23b30a){if(_0x23b30a['config']['emulator'])return;const {authorizedDomains:_0x528a2c}=await Lp(_0x23b30a);for(const _0x1b1e04 of _0x528a2c)try{if(Wp(_0x1b1e04))return;}catch{}Y(_0x23b30a,'unauthorized-domain');}function Wp(_0x385e3e){const _0x65fd95=Mi(),{protocol:_0x53cd29,hostname:_0x427ae5}=new URL(_0x65fd95);if(_0x385e3e['startsWith']('chrome-extension://')){const _0x144ea3=new URL(_0x385e3e);return _0x144ea3['hostname']===''&&_0x427ae5===''?_0x53cd29==='chrome-extension:'&&_0x385e3e['replace']('chrome-extension://','')===_0x65fd95['replace']('chrome-extension://',''):_0x53cd29==='chrome-extension:'&&_0x144ea3['hostname']===_0x427ae5;}if(!Fp['test'](_0x53cd29))return!0x1;if(xp['test'](_0x385e3e))return _0x427ae5===_0x385e3e;const _0x3b97ae=_0x385e3e['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3b97ae+'|'+_0x3b97ae+')$','i')['test'](_0x427ae5);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x3862e0=Z()['___jsl'];if(_0x3862e0!=null&&_0x3862e0['H']){for(const _0x35f644 of Object['keys'](_0x3862e0['H']))if(_0x3862e0['H'][_0x35f644]['r']=_0x3862e0['H'][_0x35f644]['r']||[],_0x3862e0['H'][_0x35f644]['L']=_0x3862e0['H'][_0x35f644]['L']||[],_0x3862e0['H'][_0x35f644]['r']=[..._0x3862e0['H'][_0x35f644]['L']],_0x3862e0['CP']){for(let _0x33eac9=0x0;_0x33eac9<_0x3862e0['CP']['length'];_0x33eac9++)_0x3862e0['CP'][_0x33eac9]=null;}}}function Vp(_0x281dbd){return new Promise((_0x47538d,_0x589547)=>{var _0x5d174e,_0x3bc39b,_0x5a4439;function _0x1bd1a9(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x47538d(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x589547(X(_0x281dbd,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x3bc39b=(_0x5d174e=Z()['gapi'])==null?void 0x0:_0x5d174e['iframes'])!=null&&_0x3bc39b['Iframe'])_0x47538d(gapi['iframes']['getContext']());else{if((_0x5a4439=Z()['gapi'])!=null&&_0x5a4439['load'])_0x1bd1a9();else{const _0x53672a=Ff('iframefcb');return Z()[_0x53672a]=()=>{gapi['load']?_0x1bd1a9():_0x589547(X(_0x281dbd,'network-request-failed'));},xa(xf()+'?onload='+_0x53672a)['catch'](_0x3ea7b4=>_0x589547(_0x3ea7b4));}}})['catch'](_0x14845e=>{throw un=null,_0x14845e;});}let un=null;function Hp(_0x25666c){return un=un||Vp(_0x25666c),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x42ee6e){const _0x22659c=_0x42ee6e['config'];m(_0x22659c['authDomain'],_0x42ee6e,'auth-domain-config-required');const _0x48976a=_0x22659c['emulator']?Cs(_0x22659c,qp):'https://'+_0x42ee6e['config']['authDomain']+'/'+Gp,_0x4a87a0={'apiKey':_0x22659c['apiKey'],'appName':_0x42ee6e['name'],'v':dt},_0x1dcc53=jp['get'](_0x42ee6e['config']['apiHost']);_0x1dcc53&&(_0x4a87a0['eid']=_0x1dcc53);const _0x3bf59e=_0x42ee6e['_getFrameworks']();return _0x3bf59e['length']&&(_0x4a87a0['fw']=_0x3bf59e['join'](',')),_0x48976a+'?'+ut(_0x4a87a0)['slice'](0x1);}async function Yp(_0x250225){const _0x4be8b0=await Hp(_0x250225),_0x2109c7=Z()['gapi'];return m(_0x2109c7,_0x250225,'internal-error'),_0x4be8b0['open']({'where':document['body'],'url':Kp(_0x250225),'messageHandlersFilter':_0x2109c7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x2e4110=>new Promise(async(_0x4a02b3,_0x1789b1)=>{await _0x2e4110['restyle']({'setHideOnLeave':!0x1});const _0x5a369=X(_0x250225,'network-request-failed'),_0x23bf52=Z()['setTimeout'](()=>{_0x1789b1(_0x5a369);},$p['get']());function _0x3cc968(){Z()['clearTimeout'](_0x23bf52),_0x4a02b3(_0x2e4110);}_0x2e4110['ping'](_0x3cc968)['then'](_0x3cc968,()=>{_0x1789b1(_0x5a369);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x48c1b8){this['window']=_0x48c1b8,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xf4ddd2,_0x30abe0,_0x47efd7,_0x3796cf=Jp,_0x20416e=Xp){const _0x3ad5f5=Math['max']((window['screen']['availHeight']-_0x20416e)/0x2,0x0)['toString'](),_0x57cf6f=Math['max']((window['screen']['availWidth']-_0x3796cf)/0x2,0x0)['toString']();let _0x58538d='';const _0x142089={...Qp,'width':_0x3796cf['toString'](),'height':_0x20416e['toString'](),'top':_0x3ad5f5,'left':_0x57cf6f},_0x25fc1a=W()['toLowerCase']();_0x47efd7&&(_0x58538d=ka(_0x25fc1a)?Zp:_0x47efd7),Ra(_0x25fc1a)&&(_0x30abe0=_0x30abe0||e_,_0x142089['scrollbars']='yes');const _0x2ecb16=Object['entries'](_0x142089)['reduce']((_0x1bcf15,[_0x447f32,_0x33398e])=>''+_0x1bcf15+_0x447f32+'='+_0x33398e+',','');if(Rf(_0x25fc1a)&&_0x58538d!=='_self')return n_(_0x30abe0||'',_0x58538d),new xr(null);const _0x31bdc1=window['open'](_0x30abe0||'',_0x58538d,_0x2ecb16);m(_0x31bdc1,_0xf4ddd2,'popup-blocked');try{_0x31bdc1['focus']();}catch{}return new xr(_0x31bdc1);}function n_(_0x9b7a20,_0x4e2d63){const _0x4dd055=document['createElement']('a');_0x4dd055['href']=_0x9b7a20,_0x4dd055['target']=_0x4e2d63;const _0x1ff8fe=document['createEvent']('MouseEvent');_0x1ff8fe['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4dd055['dispatchEvent'](_0x1ff8fe);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x5d8e9a,_0x22e97e,_0x284079,_0x3e65e9,_0x55fd4c,_0x346f6a){m(_0x5d8e9a['config']['authDomain'],_0x5d8e9a,'auth-domain-config-required'),m(_0x5d8e9a['config']['apiKey'],_0x5d8e9a,'invalid-api-key');const _0x3fbfbf={'apiKey':_0x5d8e9a['config']['apiKey'],'appName':_0x5d8e9a['name'],'authType':_0x284079,'redirectUrl':_0x3e65e9,'v':dt,'eventId':_0x55fd4c};if(_0x22e97e instanceof Wa){_0x22e97e['setDefaultLanguage'](_0x5d8e9a['languageCode']),_0x3fbfbf['providerId']=_0x22e97e['providerId']||'',pn(_0x22e97e['getCustomParameters']())||(_0x3fbfbf['customParameters']=JSON['stringify'](_0x22e97e['getCustomParameters']()));for(const [_0x58c432,_0x4f2d29]of Object['entries']({}))_0x3fbfbf[_0x58c432]=_0x4f2d29;}if(_0x22e97e instanceof tn){const _0x2cd819=_0x22e97e['getScopes']()['filter'](_0x235f1a=>_0x235f1a!=='');_0x2cd819['length']>0x0&&(_0x3fbfbf['scopes']=_0x2cd819['join'](','));}_0x5d8e9a['tenantId']&&(_0x3fbfbf['tid']=_0x5d8e9a['tenantId']);const _0x5c5d52=_0x3fbfbf;for(const _0x3175a0 of Object['keys'](_0x5c5d52))_0x5c5d52[_0x3175a0]===void 0x0&&delete _0x5c5d52[_0x3175a0];const _0xf4f71a=await _0x5d8e9a['_getAppCheckToken'](),_0x58812e=_0xf4f71a?'#'+r_+'='+encodeURIComponent(_0xf4f71a):'';return o_(_0x5d8e9a)+'?'+ut(_0x5c5d52)['slice'](0x1)+_0x58812e;}function o_({config:_0x467176}){return _0x467176['emulator']?Cs(_0x467176,s_):'https://'+_0x467176['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x110595,_0x204a1a,_0x4f471c,_0x2748a1){var _0xab25c2;ce((_0xab25c2=this['eventManagers'][_0x110595['_key']()])==null?void 0x0:_0xab25c2['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x18d6ea=await Fr(_0x110595,_0x204a1a,_0x4f471c,Mi(),_0x2748a1);return t_(_0x110595,_0x18d6ea,As());}async['_openRedirect'](_0x39bbb2,_0x3f992a,_0x53b606,_0x2db1f4){await this['_originValidation'](_0x39bbb2);const _0x4a81f3=await Fr(_0x39bbb2,_0x3f992a,_0x53b606,Mi(),_0x2db1f4);return hp(_0x4a81f3),new Promise(()=>{});}['_initialize'](_0x244785){const _0x42121b=_0x244785['_key']();if(this['eventManagers'][_0x42121b]){const {manager:_0x9cfa6c,promise:_0xba280a}=this['eventManagers'][_0x42121b];return _0x9cfa6c?Promise['resolve'](_0x9cfa6c):(ce(_0xba280a,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xba280a);}const _0x166c5e=this['initAndGetManager'](_0x244785);return this['eventManagers'][_0x42121b]={'promise':_0x166c5e},_0x166c5e['catch'](()=>{delete this['eventManagers'][_0x42121b];}),_0x166c5e;}async['initAndGetManager'](_0x6e3c5b){const _0x24d9d2=await Yp(_0x6e3c5b),_0x34f59c=new Dp(_0x6e3c5b);return _0x24d9d2['register']('authEvent',_0x4081f5=>(m(_0x4081f5==null?void 0x0:_0x4081f5['authEvent'],_0x6e3c5b,'invalid-auth-event'),{'status':_0x34f59c['onEvent'](_0x4081f5['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x6e3c5b['_key']()]={'manager':_0x34f59c},this['iframes'][_0x6e3c5b['_key']()]=_0x24d9d2,_0x34f59c;}['_isIframeWebStorageSupported'](_0x4bbf92,_0x293ec6){this['iframes'][_0x4bbf92['_key']()]['send'](pi,{'type':pi},_0x378f87=>{var _0x490539;const _0x441730=(_0x490539=_0x378f87==null?void 0x0:_0x378f87[0x0])==null?void 0x0:_0x490539[pi];_0x441730!==void 0x0&&_0x293ec6(!!_0x441730),Y(_0x4bbf92,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3fa16b){const _0x1fbc61=_0x3fa16b['_key']();return this['originValidationPromises'][_0x1fbc61]||(this['originValidationPromises'][_0x1fbc61]=Up(_0x3fa16b)),this['originValidationPromises'][_0x1fbc61];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x33448d){this['auth']=_0x33448d,this['internalListeners']=new Map();}['getUid'](){var _0x55a3d6;return this['assertAuthConfigured'](),((_0x55a3d6=this['auth']['currentUser'])==null?void 0x0:_0x55a3d6['uid'])||null;}async['getToken'](_0x541cbb){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x541cbb)}:null;}['addAuthTokenListener'](_0x1b7985){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1b7985))return;const _0x11755a=this['auth']['onIdTokenChanged'](_0x4e370b=>{_0x1b7985((_0x4e370b==null?void 0x0:_0x4e370b['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1b7985,_0x11755a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x463a98){this['assertAuthConfigured']();const _0x401936=this['internalListeners']['get'](_0x463a98);_0x401936&&(this['internalListeners']['delete'](_0x463a98),_0x401936(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x31d3f9){switch(_0x31d3f9){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5d2128){st(new Fe('auth',(_0x4bde03,{options:_0x5d80f5})=>{const _0x24a3b3=_0x4bde03['getProvider']('app')['getImmediate'](),_0x30f0ee=_0x4bde03['getProvider']('heartbeat'),_0x36aff9=_0x4bde03['getProvider']('app-check-internal'),{apiKey:_0x35ff2f,authDomain:_0x23b862}=_0x24a3b3['options'];m(_0x35ff2f&&!_0x35ff2f['includes'](':'),'invalid-api-key',{'appName':_0x24a3b3['name']});const _0x1d5011={'apiKey':_0x35ff2f,'authDomain':_0x23b862,'clientPlatform':_0x5d2128,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5d2128)},_0x198ff5=new Df(_0x24a3b3,_0x30f0ee,_0x36aff9,_0x1d5011);return Hf(_0x198ff5,_0x5d80f5),_0x198ff5;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x25e166,_0x35e06d,_0x796a3a)=>{_0x25e166['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x394bac=>{const _0x3d3d21=Ke(_0x394bac['getProvider']('auth')['getImmediate']());return(_0x5c16a2=>new l_(_0x5c16a2))(_0x3d3d21);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5d2128)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x2a8e7a=>async _0x42b349=>{const _0x3328d1=_0x42b349&&await _0x42b349['getIdTokenResult'](),_0x46898e=_0x3328d1&&(new Date()['getTime']()-Date['parse'](_0x3328d1['issuedAtTime']))/0x3e8;if(_0x46898e&&_0x46898e>f_)return;const _0xe3032b=_0x3328d1==null?void 0x0:_0x3328d1['token'];Br!==_0xe3032b&&(Br=_0xe3032b,await fetch(_0x2a8e7a,{'method':_0xe3032b?'POST':'DELETE','headers':_0xe3032b?{'Authorization':'Bearer\x20'+_0xe3032b}:{}}));};function B_(_0x117f61=Zr()){const _0x12bcfd=Hi(_0x117f61,'auth');if(_0x12bcfd['isInitialized']())return _0x12bcfd['getImmediate']();const _0x94c1bc=Vf(_0x117f61,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x9f64cc=jr('authTokenSyncURL');if(_0x9f64cc&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2ec55c=new URL(_0x9f64cc,location['origin']);if(location['origin']===_0x2ec55c['origin']){const _0x87b09a=p_(_0x2ec55c['toString']());sp(_0x94c1bc,_0x87b09a,()=>_0x87b09a(_0x94c1bc['currentUser'])),ip(_0x94c1bc,_0xcff328=>_0x87b09a(_0xcff328));}}const _0x55480d=qr('auth');return _0x55480d&&$f(_0x94c1bc,'http://'+_0x55480d),_0x94c1bc;}function __(){var _0x5eb12a;return((_0x5eb12a=document['getElementsByTagName']('head'))==null?void 0x0:_0x5eb12a[0x0])??document;}Mf({'loadJS'(_0x2c1620){return new Promise((_0x4cc95e,_0x580077)=>{const _0x2ad330=document['createElement']('script');_0x2ad330['setAttribute']('src',_0x2c1620),_0x2ad330['onload']=_0x4cc95e,_0x2ad330['onerror']=_0x100bc0=>{const _0x3793f1=X('internal-error');_0x3793f1['customData']=_0x100bc0,_0x580077(_0x3793f1);},_0x2ad330['type']='text/javascript',_0x2ad330['charset']='UTF-8',__()['appendChild'](_0x2ad330);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};