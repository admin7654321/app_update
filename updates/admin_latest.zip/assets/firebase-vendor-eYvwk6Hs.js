const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1a2941,_0x2247ac){if(!_0x1a2941)throw ht(_0x2247ac);},ht=function(_0x2c1867){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2c1867);},Hr=function(_0x53d6d8){const _0x47895f=[];let _0x596e2a=0x0;for(let _0x5ad887=0x0;_0x5ad887<_0x53d6d8['length'];_0x5ad887++){let _0x5f4721=_0x53d6d8['charCodeAt'](_0x5ad887);_0x5f4721<0x80?_0x47895f[_0x596e2a++]=_0x5f4721:_0x5f4721<0x800?(_0x47895f[_0x596e2a++]=_0x5f4721>>0x6|0xc0,_0x47895f[_0x596e2a++]=_0x5f4721&0x3f|0x80):(_0x5f4721&0xfc00)===0xd800&&_0x5ad887+0x1<_0x53d6d8['length']&&(_0x53d6d8['charCodeAt'](_0x5ad887+0x1)&0xfc00)===0xdc00?(_0x5f4721=0x10000+((_0x5f4721&0x3ff)<<0xa)+(_0x53d6d8['charCodeAt'](++_0x5ad887)&0x3ff),_0x47895f[_0x596e2a++]=_0x5f4721>>0x12|0xf0,_0x47895f[_0x596e2a++]=_0x5f4721>>0xc&0x3f|0x80,_0x47895f[_0x596e2a++]=_0x5f4721>>0x6&0x3f|0x80,_0x47895f[_0x596e2a++]=_0x5f4721&0x3f|0x80):(_0x47895f[_0x596e2a++]=_0x5f4721>>0xc|0xe0,_0x47895f[_0x596e2a++]=_0x5f4721>>0x6&0x3f|0x80,_0x47895f[_0x596e2a++]=_0x5f4721&0x3f|0x80);}return _0x47895f;},nc=function(_0x1bb65b){const _0x51aca5=[];let _0x68aaaf=0x0,_0x171d9a=0x0;for(;_0x68aaaf<_0x1bb65b['length'];){const _0x2fe33b=_0x1bb65b[_0x68aaaf++];if(_0x2fe33b<0x80)_0x51aca5[_0x171d9a++]=String['fromCharCode'](_0x2fe33b);else{if(_0x2fe33b>0xbf&&_0x2fe33b<0xe0){const _0x443445=_0x1bb65b[_0x68aaaf++];_0x51aca5[_0x171d9a++]=String['fromCharCode']((_0x2fe33b&0x1f)<<0x6|_0x443445&0x3f);}else{if(_0x2fe33b>0xef&&_0x2fe33b<0x16d){const _0x46b458=_0x1bb65b[_0x68aaaf++],_0x147f8d=_0x1bb65b[_0x68aaaf++],_0x2ed0d0=_0x1bb65b[_0x68aaaf++],_0x57359c=((_0x2fe33b&0x7)<<0x12|(_0x46b458&0x3f)<<0xc|(_0x147f8d&0x3f)<<0x6|_0x2ed0d0&0x3f)-0x10000;_0x51aca5[_0x171d9a++]=String['fromCharCode'](0xd800+(_0x57359c>>0xa)),_0x51aca5[_0x171d9a++]=String['fromCharCode'](0xdc00+(_0x57359c&0x3ff));}else{const _0x4de34f=_0x1bb65b[_0x68aaaf++],_0x3ab68c=_0x1bb65b[_0x68aaaf++];_0x51aca5[_0x171d9a++]=String['fromCharCode']((_0x2fe33b&0xf)<<0xc|(_0x4de34f&0x3f)<<0x6|_0x3ab68c&0x3f);}}}}return _0x51aca5['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2693b6,_0x4cfbe8){if(!Array['isArray'](_0x2693b6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x304aee=_0x4cfbe8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x45edfa=[];for(let _0x19ae97=0x0;_0x19ae97<_0x2693b6['length'];_0x19ae97+=0x3){const _0x518c1e=_0x2693b6[_0x19ae97],_0x312a72=_0x19ae97+0x1<_0x2693b6['length'],_0x329687=_0x312a72?_0x2693b6[_0x19ae97+0x1]:0x0,_0x19ae6c=_0x19ae97+0x2<_0x2693b6['length'],_0x434f78=_0x19ae6c?_0x2693b6[_0x19ae97+0x2]:0x0,_0x46e0d2=_0x518c1e>>0x2,_0xde7774=(_0x518c1e&0x3)<<0x4|_0x329687>>0x4;let _0xc9f7ff=(_0x329687&0xf)<<0x2|_0x434f78>>0x6,_0x316f2d=_0x434f78&0x3f;_0x19ae6c||(_0x316f2d=0x40,_0x312a72||(_0xc9f7ff=0x40)),_0x45edfa['push'](_0x304aee[_0x46e0d2],_0x304aee[_0xde7774],_0x304aee[_0xc9f7ff],_0x304aee[_0x316f2d]);}return _0x45edfa['join']('');},'encodeString'(_0x1b3148,_0x475b88){return this['HAS_NATIVE_SUPPORT']&&!_0x475b88?btoa(_0x1b3148):this['encodeByteArray'](Hr(_0x1b3148),_0x475b88);},'decodeString'(_0x4cfbee,_0xbc4e70){return this['HAS_NATIVE_SUPPORT']&&!_0xbc4e70?atob(_0x4cfbee):nc(this['decodeStringToByteArray'](_0x4cfbee,_0xbc4e70));},'decodeStringToByteArray'(_0x56ce78,_0x227292){this['init_']();const _0x21594c=_0x227292?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3bf3cd=[];for(let _0x64d3f5=0x0;_0x64d3f5<_0x56ce78['length'];){const _0x43fc42=_0x21594c[_0x56ce78['charAt'](_0x64d3f5++)],_0x3f0337=_0x64d3f5<_0x56ce78['length']?_0x21594c[_0x56ce78['charAt'](_0x64d3f5)]:0x0;++_0x64d3f5;const _0x57ee49=_0x64d3f5<_0x56ce78['length']?_0x21594c[_0x56ce78['charAt'](_0x64d3f5)]:0x40;++_0x64d3f5;const _0x810fbb=_0x64d3f5<_0x56ce78['length']?_0x21594c[_0x56ce78['charAt'](_0x64d3f5)]:0x40;if(++_0x64d3f5,_0x43fc42==null||_0x3f0337==null||_0x57ee49==null||_0x810fbb==null)throw new ic();const _0x1440ad=_0x43fc42<<0x2|_0x3f0337>>0x4;if(_0x3bf3cd['push'](_0x1440ad),_0x57ee49!==0x40){const _0x207eaa=_0x3f0337<<0x4&0xf0|_0x57ee49>>0x2;if(_0x3bf3cd['push'](_0x207eaa),_0x810fbb!==0x40){const _0x3708e1=_0x57ee49<<0x6&0xc0|_0x810fbb;_0x3bf3cd['push'](_0x3708e1);}}}return _0x3bf3cd;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x437496=0x0;_0x437496<this['ENCODED_VALS']['length'];_0x437496++)this['byteToCharMap_'][_0x437496]=this['ENCODED_VALS']['charAt'](_0x437496),this['charToByteMap_'][this['byteToCharMap_'][_0x437496]]=_0x437496,this['byteToCharMapWebSafe_'][_0x437496]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x437496),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x437496]]=_0x437496,_0x437496>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x437496)]=_0x437496,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x437496)]=_0x437496);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x567422){const _0x61ddbb=Hr(_0x567422);return Fi['encodeByteArray'](_0x61ddbb,!0x0);},dn=function(_0x304766){return $r(_0x304766)['replace'](/\./g,'');},fn=function(_0x517ea4){try{return Fi['decodeString'](_0x517ea4,!0x0);}catch(_0x3e4268){console['error']('base64Decode\x20failed:\x20',_0x3e4268);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x31ef14){return Gr(void 0x0,_0x31ef14);}function Gr(_0x48c7ec,_0x1c5f6c){if(!(_0x1c5f6c instanceof Object))return _0x1c5f6c;switch(_0x1c5f6c['constructor']){case Date:const _0x5a635f=_0x1c5f6c;return new Date(_0x5a635f['getTime']());case Object:_0x48c7ec===void 0x0&&(_0x48c7ec={});break;case Array:_0x48c7ec=[];break;default:return _0x1c5f6c;}for(const _0x3e536e in _0x1c5f6c)!_0x1c5f6c['hasOwnProperty'](_0x3e536e)||!rc(_0x3e536e)||(_0x48c7ec[_0x3e536e]=Gr(_0x48c7ec[_0x3e536e],_0x1c5f6c[_0x3e536e]));return _0x48c7ec;}function rc(_0x4fbfc9){return _0x4fbfc9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x12325a=Ps['__FIREBASE_DEFAULTS__'];if(_0x12325a)return JSON['parse'](_0x12325a);},lc=()=>{if(typeof document>'u')return;let _0xfeea60;try{_0xfeea60=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x30c105=_0xfeea60&&fn(_0xfeea60[0x1]);return _0x30c105&&JSON['parse'](_0x30c105);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x390a20){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x390a20);return;}},qr=_0x1679ca=>{var _0x2a301e,_0x585e82;return(_0x585e82=(_0x2a301e=Ui())==null?void 0x0:_0x2a301e['emulatorHosts'])==null?void 0x0:_0x585e82[_0x1679ca];},hc=_0x3b9700=>{const _0x47d6f9=qr(_0x3b9700);if(!_0x47d6f9)return;const _0x2f2a08=_0x47d6f9['lastIndexOf'](':');if(_0x2f2a08<=0x0||_0x2f2a08+0x1===_0x47d6f9['length'])throw new Error('Invalid\x20host\x20'+_0x47d6f9+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x287932=parseInt(_0x47d6f9['substring'](_0x2f2a08+0x1),0xa);return _0x47d6f9[0x0]==='['?[_0x47d6f9['substring'](0x1,_0x2f2a08-0x1),_0x287932]:[_0x47d6f9['substring'](0x0,_0x2f2a08),_0x287932];},zr=()=>{var _0x22d52c;return(_0x22d52c=Ui())==null?void 0x0:_0x22d52c['config'];},jr=_0xd57791=>{var _0x421925;return(_0x421925=Ui())==null?void 0x0:_0x421925['_'+_0xd57791];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x395f84,_0xab4b39)=>{this['resolve']=_0x395f84,this['reject']=_0xab4b39;});}['wrapCallback'](_0x5c9b09){return(_0x25c182,_0x3e1bca)=>{_0x25c182?this['reject'](_0x25c182):this['resolve'](_0x3e1bca),typeof _0x5c9b09=='function'&&(this['promise']['catch'](()=>{}),_0x5c9b09['length']===0x1?_0x5c9b09(_0x25c182):_0x5c9b09(_0x25c182,_0x3e1bca));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x54d220,_0xa0aec5){if(_0x54d220['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5a93a1={'alg':'none','type':'JWT'},_0x14ea34=_0xa0aec5||'demo-project',_0x1cc9fb=_0x54d220['iat']||0x0,_0x45ed7d=_0x54d220['sub']||_0x54d220['user_id'];if(!_0x45ed7d)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2010bb={'iss':'https://securetoken.google.com/'+_0x14ea34,'aud':_0x14ea34,'iat':_0x1cc9fb,'exp':_0x1cc9fb+0xe10,'auth_time':_0x1cc9fb,'sub':_0x45ed7d,'user_id':_0x45ed7d,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x54d220};return[dn(JSON['stringify'](_0x5a93a1)),dn(JSON['stringify'](_0x2010bb)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x49aac2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x49aac2=='object'&&_0x49aac2['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x42fc1c=W();return _0x42fc1c['indexOf']('MSIE\x20')>=0x0||_0x42fc1c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2d7f22,_0x4566c3)=>{try{let _0x33d4c0=!0x0;const _0x34e62c='validate-browser-context-for-indexeddb-analytics-module',_0xcea919=self['indexedDB']['open'](_0x34e62c);_0xcea919['onsuccess']=()=>{_0xcea919['result']['close'](),_0x33d4c0||self['indexedDB']['deleteDatabase'](_0x34e62c),_0x2d7f22(!0x0);},_0xcea919['onupgradeneeded']=()=>{_0x33d4c0=!0x1;},_0xcea919['onerror']=()=>{var _0x594664;_0x4566c3(((_0x594664=_0xcea919['error'])==null?void 0x0:_0x594664['message'])||'');};}catch(_0x56467e){_0x4566c3(_0x56467e);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2ab25c,_0x2a146e,_0x1c5b45){super(_0x2a146e),this['code']=_0x2ab25c,this['customData']=_0x1c5b45,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0xd8d849,_0x455beb,_0x622def){this['service']=_0xd8d849,this['serviceName']=_0x455beb,this['errors']=_0x622def;}['create'](_0x19542c,..._0x7d715c){const _0x610f97=_0x7d715c[0x0]||{},_0x50d71b=this['service']+'/'+_0x19542c,_0x470645=this['errors'][_0x19542c],_0x47ea2a=_0x470645?vc(_0x470645,_0x610f97):'Error',_0x4db500=this['serviceName']+':\x20'+_0x47ea2a+'\x20('+_0x50d71b+').';return new Re(_0x50d71b,_0x4db500,_0x610f97);}}function vc(_0xb5d4ba,_0x3d3ff9){return _0xb5d4ba['replace'](Ec,(_0x442420,_0x532814)=>{const _0x489433=_0x3d3ff9[_0x532814];return _0x489433!=null?String(_0x489433):'<'+_0x532814+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2dea99){return JSON['parse'](_0x2dea99);}function O(_0x2ef4a4){return JSON['stringify'](_0x2ef4a4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x25b433){let _0x164d0e={},_0x57676f={},_0x3f5eb3={},_0x3dd62c='';try{const _0x4d204d=_0x25b433['split']('.');_0x164d0e=Nt(fn(_0x4d204d[0x0])||''),_0x57676f=Nt(fn(_0x4d204d[0x1])||''),_0x3dd62c=_0x4d204d[0x2],_0x3f5eb3=_0x57676f['d']||{},delete _0x57676f['d'];}catch{}return{'header':_0x164d0e,'claims':_0x57676f,'data':_0x3f5eb3,'signature':_0x3dd62c};},Ic=function(_0x1ca560){const _0x355ec2=Yr(_0x1ca560),_0x3ea2c0=_0x355ec2['claims'];return!!_0x3ea2c0&&typeof _0x3ea2c0=='object'&&_0x3ea2c0['hasOwnProperty']('iat');},wc=function(_0x2ca992){const _0xb958ba=Yr(_0x2ca992)['claims'];return typeof _0xb958ba=='object'&&_0xb958ba['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x3a54d5,_0x688618){return Object['prototype']['hasOwnProperty']['call'](_0x3a54d5,_0x688618);}function Le(_0x64b318,_0x49d477){if(Object['prototype']['hasOwnProperty']['call'](_0x64b318,_0x49d477))return _0x64b318[_0x49d477];}function pn(_0x315e30){for(const _0xd7cdce in _0x315e30)if(Object['prototype']['hasOwnProperty']['call'](_0x315e30,_0xd7cdce))return!0x1;return!0x0;}function _n(_0x4d1059,_0x5c61c5,_0x5cddf6){const _0x1c7861={};for(const _0x41afa1 in _0x4d1059)Object['prototype']['hasOwnProperty']['call'](_0x4d1059,_0x41afa1)&&(_0x1c7861[_0x41afa1]=_0x5c61c5['call'](_0x5cddf6,_0x4d1059[_0x41afa1],_0x41afa1,_0x4d1059));return _0x1c7861;}function xe(_0xdcb56c,_0x30cacb){if(_0xdcb56c===_0x30cacb)return!0x0;const _0xed145=Object['keys'](_0xdcb56c),_0x323dd5=Object['keys'](_0x30cacb);for(const _0x45a541 of _0xed145){if(!_0x323dd5['includes'](_0x45a541))return!0x1;const _0x4a1612=_0xdcb56c[_0x45a541],_0x2794da=_0x30cacb[_0x45a541];if(Ns(_0x4a1612)&&Ns(_0x2794da)){if(!xe(_0x4a1612,_0x2794da))return!0x1;}else{if(_0x4a1612!==_0x2794da)return!0x1;}}for(const _0x49a90c of _0x323dd5)if(!_0xed145['includes'](_0x49a90c))return!0x1;return!0x0;}function Ns(_0x2950ce){return _0x2950ce!==null&&typeof _0x2950ce=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x315929){const _0x367d85=[];for(const [_0x358dc3,_0x33091b]of Object['entries'](_0x315929))Array['isArray'](_0x33091b)?_0x33091b['forEach'](_0x3301f3=>{_0x367d85['push'](encodeURIComponent(_0x358dc3)+'='+encodeURIComponent(_0x3301f3));}):_0x367d85['push'](encodeURIComponent(_0x358dc3)+'='+encodeURIComponent(_0x33091b));return _0x367d85['length']?'&'+_0x367d85['join']('&'):'';}function Ct(_0xab682b){const _0x1adec8={};return _0xab682b['replace'](/^\?/,'')['split']('&')['forEach'](_0x241464=>{if(_0x241464){const [_0x446ca8,_0x258429]=_0x241464['split']('=');_0x1adec8[decodeURIComponent(_0x446ca8)]=decodeURIComponent(_0x258429);}}),_0x1adec8;}function Tt(_0x425ebb){const _0x438ab5=_0x425ebb['indexOf']('?');if(!_0x438ab5)return'';const _0x367e3c=_0x425ebb['indexOf']('#',_0x438ab5);return _0x425ebb['substring'](_0x438ab5,_0x367e3c>0x0?_0x367e3c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3c5def=0x1;_0x3c5def<this['blockSize'];++_0x3c5def)this['pad_'][_0x3c5def]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4f7d84,_0x102599){_0x102599||(_0x102599=0x0);const _0x17de41=this['W_'];if(typeof _0x4f7d84=='string'){for(let _0x4cfba2=0x0;_0x4cfba2<0x10;_0x4cfba2++)_0x17de41[_0x4cfba2]=_0x4f7d84['charCodeAt'](_0x102599)<<0x18|_0x4f7d84['charCodeAt'](_0x102599+0x1)<<0x10|_0x4f7d84['charCodeAt'](_0x102599+0x2)<<0x8|_0x4f7d84['charCodeAt'](_0x102599+0x3),_0x102599+=0x4;}else{for(let _0x36222d=0x0;_0x36222d<0x10;_0x36222d++)_0x17de41[_0x36222d]=_0x4f7d84[_0x102599]<<0x18|_0x4f7d84[_0x102599+0x1]<<0x10|_0x4f7d84[_0x102599+0x2]<<0x8|_0x4f7d84[_0x102599+0x3],_0x102599+=0x4;}for(let _0x19edf2=0x10;_0x19edf2<0x50;_0x19edf2++){const _0x34ebb7=_0x17de41[_0x19edf2-0x3]^_0x17de41[_0x19edf2-0x8]^_0x17de41[_0x19edf2-0xe]^_0x17de41[_0x19edf2-0x10];_0x17de41[_0x19edf2]=(_0x34ebb7<<0x1|_0x34ebb7>>>0x1f)&0xffffffff;}let _0x235c26=this['chain_'][0x0],_0x2b6e3e=this['chain_'][0x1],_0xa2ea75=this['chain_'][0x2],_0x1eedb4=this['chain_'][0x3],_0x2e32bf=this['chain_'][0x4],_0x595852,_0x4839f5;for(let _0x4d9dde=0x0;_0x4d9dde<0x50;_0x4d9dde++){_0x4d9dde<0x28?_0x4d9dde<0x14?(_0x595852=_0x1eedb4^_0x2b6e3e&(_0xa2ea75^_0x1eedb4),_0x4839f5=0x5a827999):(_0x595852=_0x2b6e3e^_0xa2ea75^_0x1eedb4,_0x4839f5=0x6ed9eba1):_0x4d9dde<0x3c?(_0x595852=_0x2b6e3e&_0xa2ea75|_0x1eedb4&(_0x2b6e3e|_0xa2ea75),_0x4839f5=0x8f1bbcdc):(_0x595852=_0x2b6e3e^_0xa2ea75^_0x1eedb4,_0x4839f5=0xca62c1d6);const _0x5b3c8c=(_0x235c26<<0x5|_0x235c26>>>0x1b)+_0x595852+_0x2e32bf+_0x4839f5+_0x17de41[_0x4d9dde]&0xffffffff;_0x2e32bf=_0x1eedb4,_0x1eedb4=_0xa2ea75,_0xa2ea75=(_0x2b6e3e<<0x1e|_0x2b6e3e>>>0x2)&0xffffffff,_0x2b6e3e=_0x235c26,_0x235c26=_0x5b3c8c;}this['chain_'][0x0]=this['chain_'][0x0]+_0x235c26&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2b6e3e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xa2ea75&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1eedb4&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2e32bf&0xffffffff;}['update'](_0x47077b,_0x34c005){if(_0x47077b==null)return;_0x34c005===void 0x0&&(_0x34c005=_0x47077b['length']);const _0xc8969a=_0x34c005-this['blockSize'];let _0x6675fb=0x0;const _0x4c36e0=this['buf_'];let _0x2f52ae=this['inbuf_'];for(;_0x6675fb<_0x34c005;){if(_0x2f52ae===0x0){for(;_0x6675fb<=_0xc8969a;)this['compress_'](_0x47077b,_0x6675fb),_0x6675fb+=this['blockSize'];}if(typeof _0x47077b=='string'){for(;_0x6675fb<_0x34c005;)if(_0x4c36e0[_0x2f52ae]=_0x47077b['charCodeAt'](_0x6675fb),++_0x2f52ae,++_0x6675fb,_0x2f52ae===this['blockSize']){this['compress_'](_0x4c36e0),_0x2f52ae=0x0;break;}}else{for(;_0x6675fb<_0x34c005;)if(_0x4c36e0[_0x2f52ae]=_0x47077b[_0x6675fb],++_0x2f52ae,++_0x6675fb,_0x2f52ae===this['blockSize']){this['compress_'](_0x4c36e0),_0x2f52ae=0x0;break;}}}this['inbuf_']=_0x2f52ae,this['total_']+=_0x34c005;}['digest'](){const _0x4c2d32=[];let _0xf5afa9=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5d6589=this['blockSize']-0x1;_0x5d6589>=0x38;_0x5d6589--)this['buf_'][_0x5d6589]=_0xf5afa9&0xff,_0xf5afa9/=0x100;this['compress_'](this['buf_']);let _0x599e8a=0x0;for(let _0x4aac61=0x0;_0x4aac61<0x5;_0x4aac61++)for(let _0x44059f=0x18;_0x44059f>=0x0;_0x44059f-=0x8)_0x4c2d32[_0x599e8a]=this['chain_'][_0x4aac61]>>_0x44059f&0xff,++_0x599e8a;return _0x4c2d32;}}function Tc(_0x2afbef,_0x46a139){const _0x4d51a7=new Sc(_0x2afbef,_0x46a139);return _0x4d51a7['subscribe']['bind'](_0x4d51a7);}class Sc{constructor(_0x1efa87,_0x472c2c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x472c2c,this['task']['then'](()=>{_0x1efa87(this);})['catch'](_0x2763ff=>{this['error'](_0x2763ff);});}['next'](_0xd78d54){this['forEachObserver'](_0xc0c945=>{_0xc0c945['next'](_0xd78d54);});}['error'](_0x42c495){this['forEachObserver'](_0x26a9cc=>{_0x26a9cc['error'](_0x42c495);}),this['close'](_0x42c495);}['complete'](){this['forEachObserver'](_0x3a6ce6=>{_0x3a6ce6['complete']();}),this['close']();}['subscribe'](_0x12e490,_0x34bdcb,_0x554e01){let _0x2edab1;if(_0x12e490===void 0x0&&_0x34bdcb===void 0x0&&_0x554e01===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x12e490,['next','error','complete'])?_0x2edab1=_0x12e490:_0x2edab1={'next':_0x12e490,'error':_0x34bdcb,'complete':_0x554e01},_0x2edab1['next']===void 0x0&&(_0x2edab1['next']=ti),_0x2edab1['error']===void 0x0&&(_0x2edab1['error']=ti),_0x2edab1['complete']===void 0x0&&(_0x2edab1['complete']=ti);const _0x33e954=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2edab1['error'](this['finalError']):_0x2edab1['complete']();}catch{}}),this['observers']['push'](_0x2edab1),_0x33e954;}['unsubscribeOne'](_0x38b14a){this['observers']===void 0x0||this['observers'][_0x38b14a]===void 0x0||(delete this['observers'][_0x38b14a],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4efec2){if(!this['finalized']){for(let _0x4d7d3d=0x0;_0x4d7d3d<this['observers']['length'];_0x4d7d3d++)this['sendOne'](_0x4d7d3d,_0x4efec2);}}['sendOne'](_0x4aadb2,_0x409ac5){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4aadb2]!==void 0x0)try{_0x409ac5(this['observers'][_0x4aadb2]);}catch(_0x517b11){typeof console<'u'&&console['error']&&console['error'](_0x517b11);}});}['close'](_0x305766){this['finalized']||(this['finalized']=!0x0,_0x305766!==void 0x0&&(this['finalError']=_0x305766),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5bc75a,_0x40fb27){if(typeof _0x5bc75a!='object'||_0x5bc75a===null)return!0x1;for(const _0x296dd5 of _0x40fb27)if(_0x296dd5 in _0x5bc75a&&typeof _0x5bc75a[_0x296dd5]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x403a34,_0x14d5db){return _0x403a34+'\x20failed:\x20'+_0x14d5db+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4f4117){const _0x1a80c3=[];let _0x2a6434=0x0;for(let _0x295ab3=0x0;_0x295ab3<_0x4f4117['length'];_0x295ab3++){let _0x136a79=_0x4f4117['charCodeAt'](_0x295ab3);if(_0x136a79>=0xd800&&_0x136a79<=0xdbff){const _0x43a607=_0x136a79-0xd800;_0x295ab3++,f(_0x295ab3<_0x4f4117['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3a49f4=_0x4f4117['charCodeAt'](_0x295ab3)-0xdc00;_0x136a79=0x10000+(_0x43a607<<0xa)+_0x3a49f4;}_0x136a79<0x80?_0x1a80c3[_0x2a6434++]=_0x136a79:_0x136a79<0x800?(_0x1a80c3[_0x2a6434++]=_0x136a79>>0x6|0xc0,_0x1a80c3[_0x2a6434++]=_0x136a79&0x3f|0x80):_0x136a79<0x10000?(_0x1a80c3[_0x2a6434++]=_0x136a79>>0xc|0xe0,_0x1a80c3[_0x2a6434++]=_0x136a79>>0x6&0x3f|0x80,_0x1a80c3[_0x2a6434++]=_0x136a79&0x3f|0x80):(_0x1a80c3[_0x2a6434++]=_0x136a79>>0x12|0xf0,_0x1a80c3[_0x2a6434++]=_0x136a79>>0xc&0x3f|0x80,_0x1a80c3[_0x2a6434++]=_0x136a79>>0x6&0x3f|0x80,_0x1a80c3[_0x2a6434++]=_0x136a79&0x3f|0x80);}return _0x1a80c3;},Ln=function(_0x3c8811){let _0x4db14a=0x0;for(let _0x3be518=0x0;_0x3be518<_0x3c8811['length'];_0x3be518++){const _0x3c4c81=_0x3c8811['charCodeAt'](_0x3be518);_0x3c4c81<0x80?_0x4db14a++:_0x3c4c81<0x800?_0x4db14a+=0x2:_0x3c4c81>=0xd800&&_0x3c4c81<=0xdbff?(_0x4db14a+=0x4,_0x3be518++):_0x4db14a+=0x3;}return _0x4db14a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3277cb){return _0x3277cb&&_0x3277cb['_delegate']?_0x3277cb['_delegate']:_0x3277cb;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x508384){try{return(_0x508384['startsWith']('http://')||_0x508384['startsWith']('https://')?new URL(_0x508384)['hostname']:_0x508384)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x6c80ce){return(await fetch(_0x6c80ce,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x42ec8b,_0x37c72a,_0x4e2987){this['name']=_0x42ec8b,this['instanceFactory']=_0x37c72a,this['type']=_0x4e2987,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4754b3){return this['instantiationMode']=_0x4754b3,this;}['setMultipleInstances'](_0x2081e8){return this['multipleInstances']=_0x2081e8,this;}['setServiceProps'](_0x522b98){return this['serviceProps']=_0x522b98,this;}['setInstanceCreatedCallback'](_0x59e8a7){return this['onInstanceCreated']=_0x59e8a7,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x414f12,_0x5b67b8){this['name']=_0x414f12,this['container']=_0x5b67b8,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5f1341){const _0x4c57d3=this['normalizeInstanceIdentifier'](_0x5f1341);if(!this['instancesDeferred']['has'](_0x4c57d3)){const _0x356c58=new H();if(this['instancesDeferred']['set'](_0x4c57d3,_0x356c58),this['isInitialized'](_0x4c57d3)||this['shouldAutoInitialize']())try{const _0x557f18=this['getOrInitializeService']({'instanceIdentifier':_0x4c57d3});_0x557f18&&_0x356c58['resolve'](_0x557f18);}catch{}}return this['instancesDeferred']['get'](_0x4c57d3)['promise'];}['getImmediate'](_0x36d9cc){const _0x188c1d=this['normalizeInstanceIdentifier'](_0x36d9cc==null?void 0x0:_0x36d9cc['identifier']),_0x4d7521=(_0x36d9cc==null?void 0x0:_0x36d9cc['optional'])??!0x1;if(this['isInitialized'](_0x188c1d)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x188c1d});}catch(_0x5d025d){if(_0x4d7521)return null;throw _0x5d025d;}else{if(_0x4d7521)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x9abd6b){if(_0x9abd6b['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x9abd6b['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x9abd6b,!!this['shouldAutoInitialize']()){if(Pc(_0x9abd6b))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x185ea,_0x52421a]of this['instancesDeferred']['entries']()){const _0x2697f9=this['normalizeInstanceIdentifier'](_0x185ea);try{const _0x3be7ca=this['getOrInitializeService']({'instanceIdentifier':_0x2697f9});_0x52421a['resolve'](_0x3be7ca);}catch{}}}}['clearInstance'](_0x3cbf0d=Ne){this['instancesDeferred']['delete'](_0x3cbf0d),this['instancesOptions']['delete'](_0x3cbf0d),this['instances']['delete'](_0x3cbf0d);}async['delete'](){const _0x1332a5=Array['from'](this['instances']['values']());await Promise['all']([..._0x1332a5['filter'](_0x4f90fc=>'INTERNAL'in _0x4f90fc)['map'](_0x5cb84f=>_0x5cb84f['INTERNAL']['delete']()),..._0x1332a5['filter'](_0xc95ffc=>'_delete'in _0xc95ffc)['map'](_0x63d737=>_0x63d737['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0xe65085=Ne){return this['instances']['has'](_0xe65085);}['getOptions'](_0x4da814=Ne){return this['instancesOptions']['get'](_0x4da814)||{};}['initialize'](_0x880f9f={}){const {options:_0x5b074d={}}=_0x880f9f,_0x35cf4a=this['normalizeInstanceIdentifier'](_0x880f9f['instanceIdentifier']);if(this['isInitialized'](_0x35cf4a))throw Error(this['name']+'('+_0x35cf4a+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x43b854=this['getOrInitializeService']({'instanceIdentifier':_0x35cf4a,'options':_0x5b074d});for(const [_0x56add1,_0x23ec54]of this['instancesDeferred']['entries']()){const _0x271bdc=this['normalizeInstanceIdentifier'](_0x56add1);_0x35cf4a===_0x271bdc&&_0x23ec54['resolve'](_0x43b854);}return _0x43b854;}['onInit'](_0x1b19bf,_0x57e4e0){const _0x59a295=this['normalizeInstanceIdentifier'](_0x57e4e0),_0x39f672=this['onInitCallbacks']['get'](_0x59a295)??new Set();_0x39f672['add'](_0x1b19bf),this['onInitCallbacks']['set'](_0x59a295,_0x39f672);const _0x5ec4dd=this['instances']['get'](_0x59a295);return _0x5ec4dd&&_0x1b19bf(_0x5ec4dd,_0x59a295),()=>{_0x39f672['delete'](_0x1b19bf);};}['invokeOnInitCallbacks'](_0x5a7ed7,_0x13fa71){const _0x1f7ef0=this['onInitCallbacks']['get'](_0x13fa71);if(_0x1f7ef0){for(const _0x3f9ea5 of _0x1f7ef0)try{_0x3f9ea5(_0x5a7ed7,_0x13fa71);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x110382,options:_0x26285d={}}){let _0x534c5b=this['instances']['get'](_0x110382);if(!_0x534c5b&&this['component']&&(_0x534c5b=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x110382),'options':_0x26285d}),this['instances']['set'](_0x110382,_0x534c5b),this['instancesOptions']['set'](_0x110382,_0x26285d),this['invokeOnInitCallbacks'](_0x534c5b,_0x110382),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x110382,_0x534c5b);}catch{}return _0x534c5b||null;}['normalizeInstanceIdentifier'](_0x508902=Ne){return this['component']?this['component']['multipleInstances']?_0x508902:Ne:_0x508902;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x25da93){return _0x25da93===Ne?void 0x0:_0x25da93;}function Pc(_0x8c340b){return _0x8c340b['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x5155bc){this['name']=_0x5155bc,this['providers']=new Map();}['addComponent'](_0x33fc8d){const _0x5ba45e=this['getProvider'](_0x33fc8d['name']);if(_0x5ba45e['isComponentSet']())throw new Error('Component\x20'+_0x33fc8d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5ba45e['setComponent'](_0x33fc8d);}['addOrOverwriteComponent'](_0x148af7){this['getProvider'](_0x148af7['name'])['isComponentSet']()&&this['providers']['delete'](_0x148af7['name']),this['addComponent'](_0x148af7);}['getProvider'](_0x46d67f){if(this['providers']['has'](_0x46d67f))return this['providers']['get'](_0x46d67f);const _0x1510be=new Ac(_0x46d67f,this);return this['providers']['set'](_0x46d67f,_0x1510be),_0x1510be;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x459546){_0x459546[_0x459546['DEBUG']=0x0]='DEBUG',_0x459546[_0x459546['VERBOSE']=0x1]='VERBOSE',_0x459546[_0x459546['INFO']=0x2]='INFO',_0x459546[_0x459546['WARN']=0x3]='WARN',_0x459546[_0x459546['ERROR']=0x4]='ERROR',_0x459546[_0x459546['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x26bf94,_0x44072f,..._0x170483)=>{if(_0x44072f<_0x26bf94['logLevel'])return;const _0x5d7e49=new Date()['toISOString'](),_0x4ee95c=Mc[_0x44072f];if(_0x4ee95c)console[_0x4ee95c]('['+_0x5d7e49+']\x20\x20'+_0x26bf94['name']+':',..._0x170483);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x44072f+')');};class Bi{constructor(_0x242181){this['name']=_0x242181,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1d9f1b){if(!(_0x1d9f1b in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1d9f1b+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1d9f1b;}['setLogLevel'](_0x4a99d2){this['_logLevel']=typeof _0x4a99d2=='string'?Oc[_0x4a99d2]:_0x4a99d2;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x14cf89){if(typeof _0x14cf89!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x14cf89;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x49652c){this['_userLogHandler']=_0x49652c;}['debug'](..._0x89b86e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x89b86e),this['_logHandler'](this,T['DEBUG'],..._0x89b86e);}['log'](..._0x350c9){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x350c9),this['_logHandler'](this,T['VERBOSE'],..._0x350c9);}['info'](..._0x88b75){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x88b75),this['_logHandler'](this,T['INFO'],..._0x88b75);}['warn'](..._0x2a9ca8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2a9ca8),this['_logHandler'](this,T['WARN'],..._0x2a9ca8);}['error'](..._0x5c83d3){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5c83d3),this['_logHandler'](this,T['ERROR'],..._0x5c83d3);}}const xc=(_0x15e022,_0x34a022)=>_0x34a022['some'](_0x44b4d4=>_0x15e022 instanceof _0x44b4d4);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x30e1be){const _0x27bdec=new Promise((_0x2d64fd,_0x50479c)=>{const _0x2bf724=()=>{_0x30e1be['removeEventListener']('success',_0x251593),_0x30e1be['removeEventListener']('error',_0x1e0236);},_0x251593=()=>{_0x2d64fd(ge(_0x30e1be['result'])),_0x2bf724();},_0x1e0236=()=>{_0x50479c(_0x30e1be['error']),_0x2bf724();};_0x30e1be['addEventListener']('success',_0x251593),_0x30e1be['addEventListener']('error',_0x1e0236);});return _0x27bdec['then'](_0x2c780f=>{_0x2c780f instanceof IDBCursor&&Jr['set'](_0x2c780f,_0x30e1be);})['catch'](()=>{}),Vi['set'](_0x27bdec,_0x30e1be),_0x27bdec;}function Bc(_0x3520c1){if(_i['has'](_0x3520c1))return;const _0x472749=new Promise((_0x572d18,_0x569a36)=>{const _0x52c900=()=>{_0x3520c1['removeEventListener']('complete',_0x1871fd),_0x3520c1['removeEventListener']('error',_0xdd7173),_0x3520c1['removeEventListener']('abort',_0xdd7173);},_0x1871fd=()=>{_0x572d18(),_0x52c900();},_0xdd7173=()=>{_0x569a36(_0x3520c1['error']||new DOMException('AbortError','AbortError')),_0x52c900();};_0x3520c1['addEventListener']('complete',_0x1871fd),_0x3520c1['addEventListener']('error',_0xdd7173),_0x3520c1['addEventListener']('abort',_0xdd7173);});_i['set'](_0x3520c1,_0x472749);}let gi={'get'(_0x4d94ca,_0x48a768,_0xfe9cbe){if(_0x4d94ca instanceof IDBTransaction){if(_0x48a768==='done')return _i['get'](_0x4d94ca);if(_0x48a768==='objectStoreNames')return _0x4d94ca['objectStoreNames']||Xr['get'](_0x4d94ca);if(_0x48a768==='store')return _0xfe9cbe['objectStoreNames'][0x1]?void 0x0:_0xfe9cbe['objectStore'](_0xfe9cbe['objectStoreNames'][0x0]);}return ge(_0x4d94ca[_0x48a768]);},'set'(_0x3b9c7f,_0x3e1aed,_0x50d1df){return _0x3b9c7f[_0x3e1aed]=_0x50d1df,!0x0;},'has'(_0x90128c,_0x3671b1){return _0x90128c instanceof IDBTransaction&&(_0x3671b1==='done'||_0x3671b1==='store')?!0x0:_0x3671b1 in _0x90128c;}};function Vc(_0x3ec76f){gi=_0x3ec76f(gi);}function Hc(_0x502a11){return _0x502a11===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x288f03,..._0x488871){const _0x4ac000=_0x502a11['call'](ii(this),_0x288f03,..._0x488871);return Xr['set'](_0x4ac000,_0x288f03['sort']?_0x288f03['sort']():[_0x288f03]),ge(_0x4ac000);}:Uc()['includes'](_0x502a11)?function(..._0x270e78){return _0x502a11['apply'](ii(this),_0x270e78),ge(Jr['get'](this));}:function(..._0xd75847){return ge(_0x502a11['apply'](ii(this),_0xd75847));};}function $c(_0x2987e5){return typeof _0x2987e5=='function'?Hc(_0x2987e5):(_0x2987e5 instanceof IDBTransaction&&Bc(_0x2987e5),xc(_0x2987e5,Fc())?new Proxy(_0x2987e5,gi):_0x2987e5);}function ge(_0xea76a4){if(_0xea76a4 instanceof IDBRequest)return Wc(_0xea76a4);if(ni['has'](_0xea76a4))return ni['get'](_0xea76a4);const _0x443882=$c(_0xea76a4);return _0x443882!==_0xea76a4&&(ni['set'](_0xea76a4,_0x443882),Vi['set'](_0x443882,_0xea76a4)),_0x443882;}const ii=_0x157631=>Vi['get'](_0x157631);function Gc(_0x37c91f,_0x399af6,{blocked:_0x2f06c2,upgrade:_0x19e177,blocking:_0x50d355,terminated:_0x2218d7}={}){const _0x311827=indexedDB['open'](_0x37c91f,_0x399af6),_0x3ada2b=ge(_0x311827);return _0x19e177&&_0x311827['addEventListener']('upgradeneeded',_0x54f776=>{_0x19e177(ge(_0x311827['result']),_0x54f776['oldVersion'],_0x54f776['newVersion'],ge(_0x311827['transaction']),_0x54f776);}),_0x2f06c2&&_0x311827['addEventListener']('blocked',_0x588a9f=>_0x2f06c2(_0x588a9f['oldVersion'],_0x588a9f['newVersion'],_0x588a9f)),_0x3ada2b['then'](_0x362243=>{_0x2218d7&&_0x362243['addEventListener']('close',()=>_0x2218d7()),_0x50d355&&_0x362243['addEventListener']('versionchange',_0x155244=>_0x50d355(_0x155244['oldVersion'],_0x155244['newVersion'],_0x155244));})['catch'](()=>{}),_0x3ada2b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x2acff4,_0x4eb2ed){if(!(_0x2acff4 instanceof IDBDatabase&&!(_0x4eb2ed in _0x2acff4)&&typeof _0x4eb2ed=='string'))return;if(si['get'](_0x4eb2ed))return si['get'](_0x4eb2ed);const _0x4f9dd3=_0x4eb2ed['replace'](/FromIndex$/,''),_0x2e5469=_0x4eb2ed!==_0x4f9dd3,_0x2e1c2e=zc['includes'](_0x4f9dd3);if(!(_0x4f9dd3 in(_0x2e5469?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2e1c2e||qc['includes'](_0x4f9dd3)))return;const _0x104f6d=async function(_0x365268,..._0x152dba){const _0x33f1ec=this['transaction'](_0x365268,_0x2e1c2e?'readwrite':'readonly');let _0x28c187=_0x33f1ec['store'];return _0x2e5469&&(_0x28c187=_0x28c187['index'](_0x152dba['shift']())),(await Promise['all']([_0x28c187[_0x4f9dd3](..._0x152dba),_0x2e1c2e&&_0x33f1ec['done']]))[0x0];};return si['set'](_0x4eb2ed,_0x104f6d),_0x104f6d;}Vc(_0x30ecbe=>({..._0x30ecbe,'get':(_0x19d7f1,_0x3cf643,_0x3ea653)=>Ms(_0x19d7f1,_0x3cf643)||_0x30ecbe['get'](_0x19d7f1,_0x3cf643,_0x3ea653),'has':(_0x151b50,_0x113d74)=>!!Ms(_0x151b50,_0x113d74)||_0x30ecbe['has'](_0x151b50,_0x113d74)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x6b08bd){this['container']=_0x6b08bd;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5178a1=>{if(Kc(_0x5178a1)){const _0x798a9d=_0x5178a1['getImmediate']();return _0x798a9d['library']+'/'+_0x798a9d['version'];}else return null;})['filter'](_0x298775=>_0x298775)['join']('\x20');}}function Kc(_0x1375c4){const _0x59e17b=_0x1375c4['getComponent']();return(_0x59e17b==null?void 0x0:_0x59e17b['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x153956,_0x49fccd){try{_0x153956['container']['addComponent'](_0x49fccd);}catch(_0x299497){oe['debug']('Component\x20'+_0x49fccd['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x153956['name'],_0x299497);}}function st(_0x3abbcd){const _0x38bd68=_0x3abbcd['name'];if(Ei['has'](_0x38bd68))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x38bd68+'.'),!0x1;Ei['set'](_0x38bd68,_0x3abbcd);for(const _0x27429c of Ue['values']())xs(_0x27429c,_0x3abbcd);for(const _0x3aab4d of vi['values']())xs(_0x3aab4d,_0x3abbcd);return!0x0;}function Hi(_0x2b58c6,_0xe6eb20){const _0x257cdd=_0x2b58c6['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x257cdd&&_0x257cdd['triggerHeartbeat'](),_0x2b58c6['container']['getProvider'](_0xe6eb20);}function $(_0x3ed938){return _0x3ed938==null?!0x1:_0x3ed938['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x4047f4,_0x56640a,_0x3ee09c){this['_isDeleted']=!0x1,this['_options']={..._0x4047f4},this['_config']={..._0x56640a},this['_name']=_0x56640a['name'],this['_automaticDataCollectionEnabled']=_0x56640a['automaticDataCollectionEnabled'],this['_container']=_0x3ee09c,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x5ee7a5){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x5ee7a5;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x42dc03){this['_isDeleted']=_0x42dc03;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x11485c,_0x836c70={}){let _0x5751de=_0x11485c;typeof _0x836c70!='object'&&(_0x836c70={'name':_0x836c70});const _0x1df713={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x836c70},_0x4c5895=_0x1df713['name'];if(typeof _0x4c5895!='string'||!_0x4c5895)throw me['create']('bad-app-name',{'appName':String(_0x4c5895)});if(_0x5751de||(_0x5751de=zr()),!_0x5751de)throw me['create']('no-options');const _0x24fb1a=Ue['get'](_0x4c5895);if(_0x24fb1a){if(xe(_0x5751de,_0x24fb1a['options'])&&xe(_0x1df713,_0x24fb1a['config']))return _0x24fb1a;throw me['create']('duplicate-app',{'appName':_0x4c5895});}const _0x48e921=new Nc(_0x4c5895);for(const _0xbe0118 of Ei['values']())_0x48e921['addComponent'](_0xbe0118);const _0x94265=new Tl(_0x5751de,_0x1df713,_0x48e921);return Ue['set'](_0x4c5895,_0x94265),_0x94265;}function Zr(_0x24770d=yi){const _0x842603=Ue['get'](_0x24770d);if(!_0x842603&&_0x24770d===yi&&zr())return Sl();if(!_0x842603)throw me['create']('no-app',{'appName':_0x24770d});return _0x842603;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x178e0d){let _0xfb824f=!0x1;const _0x154563=_0x178e0d['name'];Ue['has'](_0x154563)?(_0xfb824f=!0x0,Ue['delete'](_0x154563)):vi['has'](_0x154563)&&_0x178e0d['decRefCount']()<=0x0&&(vi['delete'](_0x154563),_0xfb824f=!0x0),_0xfb824f&&(await Promise['all'](_0x178e0d['container']['getProviders']()['map'](_0x2f448b=>_0x2f448b['delete']())),_0x178e0d['isDeleted']=!0x0);}function ye(_0x2375ff,_0x5b3438,_0x514103){let _0xd447d9=wl[_0x2375ff]??_0x2375ff;_0x514103&&(_0xd447d9+='-'+_0x514103);const _0x358252=_0xd447d9['match'](/\s|\//),_0x30c3b5=_0x5b3438['match'](/\s|\//);if(_0x358252||_0x30c3b5){const _0x38f660=['Unable\x20to\x20register\x20library\x20\x22'+_0xd447d9+'\x22\x20with\x20version\x20\x22'+_0x5b3438+'\x22:'];_0x358252&&_0x38f660['push']('library\x20name\x20\x22'+_0xd447d9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x358252&&_0x30c3b5&&_0x38f660['push']('and'),_0x30c3b5&&_0x38f660['push']('version\x20name\x20\x22'+_0x5b3438+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x38f660['join']('\x20'));return;}st(new Fe(_0xd447d9+'-version',()=>({'library':_0xd447d9,'version':_0x5b3438}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0xce712,_0x43ff71)=>{switch(_0x43ff71){case 0x0:try{_0xce712['createObjectStore'](Ot);}catch(_0x17edc9){console['warn'](_0x17edc9);}}}})['catch'](_0x220e10=>{throw me['create']('idb-open',{'originalErrorMessage':_0x220e10['message']});})),ri;}async function Al(_0x12e50b){try{const _0x59617e=(await eo())['transaction'](Ot),_0x25ea41=await _0x59617e['objectStore'](Ot)['get'](to(_0x12e50b));return await _0x59617e['done'],_0x25ea41;}catch(_0x41067e){if(_0x41067e instanceof Re)oe['warn'](_0x41067e['message']);else{const _0x52630c=me['create']('idb-get',{'originalErrorMessage':_0x41067e==null?void 0x0:_0x41067e['message']});oe['warn'](_0x52630c['message']);}}}async function Fs(_0x2f9fe8,_0x395845){try{const _0x34d26c=(await eo())['transaction'](Ot,'readwrite');await _0x34d26c['objectStore'](Ot)['put'](_0x395845,to(_0x2f9fe8)),await _0x34d26c['done'];}catch(_0x428b13){if(_0x428b13 instanceof Re)oe['warn'](_0x428b13['message']);else{const _0x31ee9c=me['create']('idb-set',{'originalErrorMessage':_0x428b13==null?void 0x0:_0x428b13['message']});oe['warn'](_0x31ee9c['message']);}}}function to(_0x8e4d98){return _0x8e4d98['name']+'!'+_0x8e4d98['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x3bf5b9){this['container']=_0x3bf5b9,this['_heartbeatsCache']=null;const _0x2c8221=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2c8221),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x433b58=>(this['_heartbeatsCache']=_0x433b58,_0x433b58));}async['triggerHeartbeat'](){var _0x4fff41,_0x58651f;try{const _0x5f1e39=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x539102=Us();if(((_0x4fff41=this['_heartbeatsCache'])==null?void 0x0:_0x4fff41['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x58651f=this['_heartbeatsCache'])==null?void 0x0:_0x58651f['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x539102||this['_heartbeatsCache']['heartbeats']['some'](_0x5a7e39=>_0x5a7e39['date']===_0x539102))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x539102,'agent':_0x5f1e39}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x32050c=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x32050c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3a98fe){oe['warn'](_0x3a98fe);}}async['getHeartbeatsHeader'](){var _0xa72a6;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0xa72a6=this['_heartbeatsCache'])==null?void 0x0:_0xa72a6['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x598371=Us(),{heartbeatsToSend:_0xbe4b10,unsentEntries:_0x2bb7b2}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2d16f3=dn(JSON['stringify']({'version':0x2,'heartbeats':_0xbe4b10}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x598371,_0x2bb7b2['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2bb7b2,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2d16f3;}catch(_0x28e7c0){return oe['warn'](_0x28e7c0),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0xf68bba,_0xec64f5=kl){const _0x397a9f=[];let _0x3862a8=_0xf68bba['slice']();for(const _0x571135 of _0xf68bba){const _0x4a5246=_0x397a9f['find'](_0x507552=>_0x507552['agent']===_0x571135['agent']);if(_0x4a5246){if(_0x4a5246['dates']['push'](_0x571135['date']),Ws(_0x397a9f)>_0xec64f5){_0x4a5246['dates']['pop']();break;}}else{if(_0x397a9f['push']({'agent':_0x571135['agent'],'dates':[_0x571135['date']]}),Ws(_0x397a9f)>_0xec64f5){_0x397a9f['pop']();break;}}_0x3862a8=_0x3862a8['slice'](0x1);}return{'heartbeatsToSend':_0x397a9f,'unsentEntries':_0x3862a8};}class Dl{constructor(_0x58cae){this['app']=_0x58cae,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x71acce=await Al(this['app']);return _0x71acce!=null&&_0x71acce['heartbeats']?_0x71acce:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x41dcb1){if(await this['_canUseIndexedDBPromise']){const _0x1de00e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x41dcb1['lastSentHeartbeatDate']??_0x1de00e['lastSentHeartbeatDate'],'heartbeats':_0x41dcb1['heartbeats']});}else return;}async['add'](_0x52870c){if(await this['_canUseIndexedDBPromise']){const _0x21daab=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x52870c['lastSentHeartbeatDate']??_0x21daab['lastSentHeartbeatDate'],'heartbeats':[..._0x21daab['heartbeats'],..._0x52870c['heartbeats']]});}else return;}}function Ws(_0x440c6f){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x440c6f}))['length'];}function Ml(_0x213a82){if(_0x213a82['length']===0x0)return-0x1;let _0x53c075=0x0,_0x3ccf0a=_0x213a82[0x0]['date'];for(let _0x54a764=0x1;_0x54a764<_0x213a82['length'];_0x54a764++)_0x213a82[_0x54a764]['date']<_0x3ccf0a&&(_0x3ccf0a=_0x213a82[_0x54a764]['date'],_0x53c075=_0x54a764);return _0x53c075;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4681d6){st(new Fe('platform-logger',_0xfc55c8=>new jc(_0xfc55c8),'PRIVATE')),st(new Fe('heartbeat',_0x52129d=>new Nl(_0x52129d),'PRIVATE')),ye(mi,Ls,_0x4681d6),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x32eddc){no=_0x32eddc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1b4d22){this['domStorage_']=_0x1b4d22,this['prefix_']='firebase:';}['set'](_0x25c60f,_0x458981){_0x458981==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x25c60f)):this['domStorage_']['setItem'](this['prefixedName_'](_0x25c60f),O(_0x458981));}['get'](_0x2d1c17){const _0x318865=this['domStorage_']['getItem'](this['prefixedName_'](_0x2d1c17));return _0x318865==null?null:Nt(_0x318865);}['remove'](_0xda23c9){this['domStorage_']['removeItem'](this['prefixedName_'](_0xda23c9));}['prefixedName_'](_0x19082e){return this['prefix_']+_0x19082e;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x21ede0,_0x271611){_0x271611==null?delete this['cache_'][_0x21ede0]:this['cache_'][_0x21ede0]=_0x271611;}['get'](_0x3eaae5){return Q(this['cache_'],_0x3eaae5)?this['cache_'][_0x3eaae5]:null;}['remove'](_0x52f6af){delete this['cache_'][_0x52f6af];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xabe2f3){try{if(typeof window<'u'&&typeof window[_0xabe2f3]<'u'){const _0x11f7e1=window[_0xabe2f3];return _0x11f7e1['setItem']('firebase:sentinel','cache'),_0x11f7e1['removeItem']('firebase:sentinel'),new Wl(_0x11f7e1);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x2a48df=0x1;return function(){return _0x2a48df++;};}()),ro=function(_0x5dc522){const _0x4afe60=Rc(_0x5dc522),_0x30468e=new Cc();_0x30468e['update'](_0x4afe60);const _0xb3df1b=_0x30468e['digest']();return Fi['encodeByteArray'](_0xb3df1b);},zt=function(..._0x2a44d2){let _0x4615c2='';for(let _0x382e7c=0x0;_0x382e7c<_0x2a44d2['length'];_0x382e7c++){const _0xf90e16=_0x2a44d2[_0x382e7c];Array['isArray'](_0xf90e16)||_0xf90e16&&typeof _0xf90e16=='object'&&typeof _0xf90e16['length']=='number'?_0x4615c2+=zt['apply'](null,_0xf90e16):typeof _0xf90e16=='object'?_0x4615c2+=O(_0xf90e16):_0x4615c2+=_0xf90e16,_0x4615c2+='\x20';}return _0x4615c2;};let St=null,$s=!0x0;const Hl=function(_0x33eea3,_0x585c80){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x4c4297){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x3305e1=zt['apply'](null,_0x4c4297);St(_0x3305e1);}},jt=function(_0x20acd5){return function(..._0x1f7000){L(_0x20acd5,..._0x1f7000);};},Ii=function(..._0x4164af){const _0x24ad0e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x4164af);Ze['error'](_0x24ad0e);},ae=function(..._0x197337){const _0x265b08='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x197337);throw Ze['error'](_0x265b08),new Error(_0x265b08);},U=function(..._0x29b19c){const _0x52ad7c='FIREBASE\x20WARNING:\x20'+zt(..._0x29b19c);Ze['warn'](_0x52ad7c);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3d0c92){return typeof _0x3d0c92=='number'&&(_0x3d0c92!==_0x3d0c92||_0x3d0c92===Number['POSITIVE_INFINITY']||_0x3d0c92===Number['NEGATIVE_INFINITY']);},Gl=function(_0x37ec08){if(document['readyState']==='complete')_0x37ec08();else{let _0x5e8017=!0x1;const _0x207f90=function(){if(!document['body']){setTimeout(_0x207f90,Math['floor'](0xa));return;}_0x5e8017||(_0x5e8017=!0x0,_0x37ec08());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x207f90,!0x1),window['addEventListener']('load',_0x207f90,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x207f90();}),window['attachEvent']('onload',_0x207f90));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4b7292,_0x4ce248){if(_0x4b7292===_0x4ce248)return 0x0;if(_0x4b7292===We||_0x4ce248===we)return-0x1;if(_0x4ce248===We||_0x4b7292===we)return 0x1;{const _0x482646=Gs(_0x4b7292),_0x2d7edc=Gs(_0x4ce248);return _0x482646!==null?_0x2d7edc!==null?_0x482646-_0x2d7edc===0x0?_0x4b7292['length']-_0x4ce248['length']:_0x482646-_0x2d7edc:-0x1:_0x2d7edc!==null?0x1:_0x4b7292<_0x4ce248?-0x1:0x1;}},ql=function(_0x2489d6,_0x140941){return _0x2489d6===_0x140941?0x0:_0x2489d6<_0x140941?-0x1:0x1;},vt=function(_0x546e70,_0x5ceb3d){if(_0x5ceb3d&&_0x546e70 in _0x5ceb3d)return _0x5ceb3d[_0x546e70];throw new Error('Missing\x20required\x20key\x20('+_0x546e70+')\x20in\x20object:\x20'+O(_0x5ceb3d));},$i=function(_0x299f1e){if(typeof _0x299f1e!='object'||_0x299f1e===null)return O(_0x299f1e);const _0x22c617=[];for(const _0x5efc0f in _0x299f1e)_0x22c617['push'](_0x5efc0f);_0x22c617['sort']();let _0x378869='{';for(let _0x4a850a=0x0;_0x4a850a<_0x22c617['length'];_0x4a850a++)_0x4a850a!==0x0&&(_0x378869+=','),_0x378869+=O(_0x22c617[_0x4a850a]),_0x378869+=':',_0x378869+=$i(_0x299f1e[_0x22c617[_0x4a850a]]);return _0x378869+='}',_0x378869;},oo=function(_0x14e3f6,_0x2c8b43){const _0x4d882c=_0x14e3f6['length'];if(_0x4d882c<=_0x2c8b43)return[_0x14e3f6];const _0x28920b=[];for(let _0x523867=0x0;_0x523867<_0x4d882c;_0x523867+=_0x2c8b43)_0x523867+_0x2c8b43>_0x4d882c?_0x28920b['push'](_0x14e3f6['substring'](_0x523867,_0x4d882c)):_0x28920b['push'](_0x14e3f6['substring'](_0x523867,_0x523867+_0x2c8b43));return _0x28920b;};function x(_0x29aa95,_0x33d2d6){for(const _0x30c193 in _0x29aa95)_0x29aa95['hasOwnProperty'](_0x30c193)&&_0x33d2d6(_0x30c193,_0x29aa95[_0x30c193]);}const ao=function(_0x3b9764){f(!xn(_0x3b9764),'Invalid\x20JSON\x20number');const _0x618618=0xb,_0x54651b=0x34,_0x322af8=(0x1<<_0x618618-0x1)-0x1;let _0xc07ae3,_0x1b2c8f,_0x86f9e,_0x3ffeb6,_0x2aac01;_0x3b9764===0x0?(_0x1b2c8f=0x0,_0x86f9e=0x0,_0xc07ae3=0x1/_0x3b9764===-0x1/0x0?0x1:0x0):(_0xc07ae3=_0x3b9764<0x0,_0x3b9764=Math['abs'](_0x3b9764),_0x3b9764>=Math['pow'](0x2,0x1-_0x322af8)?(_0x3ffeb6=Math['min'](Math['floor'](Math['log'](_0x3b9764)/Math['LN2']),_0x322af8),_0x1b2c8f=_0x3ffeb6+_0x322af8,_0x86f9e=Math['round'](_0x3b9764*Math['pow'](0x2,_0x54651b-_0x3ffeb6)-Math['pow'](0x2,_0x54651b))):(_0x1b2c8f=0x0,_0x86f9e=Math['round'](_0x3b9764/Math['pow'](0x2,0x1-_0x322af8-_0x54651b))));const _0x47f523=[];for(_0x2aac01=_0x54651b;_0x2aac01;_0x2aac01-=0x1)_0x47f523['push'](_0x86f9e%0x2?0x1:0x0),_0x86f9e=Math['floor'](_0x86f9e/0x2);for(_0x2aac01=_0x618618;_0x2aac01;_0x2aac01-=0x1)_0x47f523['push'](_0x1b2c8f%0x2?0x1:0x0),_0x1b2c8f=Math['floor'](_0x1b2c8f/0x2);_0x47f523['push'](_0xc07ae3?0x1:0x0),_0x47f523['reverse']();const _0x1c58f4=_0x47f523['join']('');let _0xbffb59='';for(_0x2aac01=0x0;_0x2aac01<0x40;_0x2aac01+=0x8){let _0x1ad85f=parseInt(_0x1c58f4['substr'](_0x2aac01,0x8),0x2)['toString'](0x10);_0x1ad85f['length']===0x1&&(_0x1ad85f='0'+_0x1ad85f),_0xbffb59=_0xbffb59+_0x1ad85f;}return _0xbffb59['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3074d4,_0x4b6cad){let _0x16e7bd='Unknown\x20Error';_0x3074d4==='too_big'?_0x16e7bd='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3074d4==='permission_denied'?_0x16e7bd='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3074d4==='unavailable'&&(_0x16e7bd='The\x20service\x20is\x20unavailable');const _0xf3a71b=new Error(_0x3074d4+'\x20at\x20'+_0x4b6cad['_path']['toString']()+':\x20'+_0x16e7bd);return _0xf3a71b['code']=_0x3074d4['toUpperCase'](),_0xf3a71b;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x17352d){if(Yl['test'](_0x17352d)){const _0x34a8fc=Number(_0x17352d);if(_0x34a8fc>=Ql&&_0x34a8fc<=Jl)return _0x34a8fc;}return null;},ft=function(_0x5c5b99){try{_0x5c5b99();}catch(_0x79fb4c){setTimeout(()=>{const _0x1d4ae0=_0x79fb4c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1d4ae0),_0x79fb4c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x4ee265,_0x3dbf4b){const _0x273eb9=setTimeout(_0x4ee265,_0x3dbf4b);return typeof _0x273eb9=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x273eb9):typeof _0x273eb9=='object'&&_0x273eb9['unref']&&_0x273eb9['unref'](),_0x273eb9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1311f1,_0x52ccef){this['appCheckProvider']=_0x52ccef,this['appName']=_0x1311f1['name'],$(_0x1311f1)&&_0x1311f1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1311f1['settings']['appCheckToken']),this['appCheck']=_0x52ccef==null?void 0x0:_0x52ccef['getImmediate']({'optional':!0x0}),this['appCheck']||_0x52ccef==null||_0x52ccef['get']()['then'](_0x4706bb=>this['appCheck']=_0x4706bb);}['getToken'](_0x3239f3){if(this['serverAppAppCheckToken']){if(_0x3239f3)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3239f3):new Promise((_0x3caac2,_0x6763ab)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3239f3)['then'](_0x3caac2,_0x6763ab):_0x3caac2(null);},0x0);});}['addTokenChangeListener'](_0x52bb1c){var _0xbc7843;(_0xbc7843=this['appCheckProvider'])==null||_0xbc7843['get']()['then'](_0x2e54f8=>_0x2e54f8['addTokenListener'](_0x52bb1c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x27ad81,_0x570244,_0x3f429){this['appName_']=_0x27ad81,this['firebaseOptions_']=_0x570244,this['authProvider_']=_0x3f429,this['auth_']=null,this['auth_']=_0x3f429['getImmediate']({'optional':!0x0}),this['auth_']||_0x3f429['onInit'](_0x11888f=>this['auth_']=_0x11888f);}['getToken'](_0x5e2fa3){return this['auth_']?this['auth_']['getToken'](_0x5e2fa3)['catch'](_0x5ab247=>_0x5ab247&&_0x5ab247['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5ab247)):new Promise((_0x3c9e32,_0xcfddb0)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x5e2fa3)['then'](_0x3c9e32,_0xcfddb0):_0x3c9e32(null);},0x0);});}['addTokenChangeListener'](_0x3aa3a3){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3aa3a3):this['authProvider_']['get']()['then'](_0x70c61=>_0x70c61['addAuthTokenListener'](_0x3aa3a3));}['removeTokenChangeListener'](_0x586e71){this['authProvider_']['get']()['then'](_0x2b414e=>_0x2b414e['removeAuthTokenListener'](_0x586e71));}['notifyForInvalidToken'](){let _0x11340e='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x11340e+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x11340e+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x11340e+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x11340e);}}class an{constructor(_0x357263){this['accessToken']=_0x357263;}['getToken'](_0x5b9c3e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3b9adb){_0x3b9adb(this['accessToken']);}['removeTokenChangeListener'](_0x592201){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5a0a48,_0x799b64,_0x21ec95,_0x1a46ec,_0x5b61a1=!0x1,_0x964815='',_0x220bd7=!0x1,_0x476bb8=!0x1,_0x25e837=null){this['secure']=_0x799b64,this['namespace']=_0x21ec95,this['webSocketOnly']=_0x1a46ec,this['nodeAdmin']=_0x5b61a1,this['persistenceKey']=_0x964815,this['includeNamespaceInQueryParams']=_0x220bd7,this['isUsingEmulator']=_0x476bb8,this['emulatorOptions']=_0x25e837,this['_host']=_0x5a0a48['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x5a0a48)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x565ccd){_0x565ccd!==this['internalHost']&&(this['internalHost']=_0x565ccd,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5d84d5=this['toURLString']();return this['persistenceKey']&&(_0x5d84d5+='<'+this['persistenceKey']+'>'),_0x5d84d5;}['toURLString'](){const _0x1f3bd1=this['secure']?'https://':'http://',_0x48fb24=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1f3bd1+this['host']+'/'+_0x48fb24;}}function th(_0x3728bf){return _0x3728bf['host']!==_0x3728bf['internalHost']||_0x3728bf['isCustomHost']()||_0x3728bf['includeNamespaceInQueryParams'];}function vo(_0x1024d5,_0x533cf5,_0x630091){f(typeof _0x533cf5=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x630091=='object','typeof\x20params\x20must\x20==\x20object');let _0x15f110;if(_0x533cf5===go)_0x15f110=(_0x1024d5['secure']?'wss://':'ws://')+_0x1024d5['internalHost']+'/.ws?';else{if(_0x533cf5===mo)_0x15f110=(_0x1024d5['secure']?'https://':'http://')+_0x1024d5['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x533cf5);}th(_0x1024d5)&&(_0x630091['ns']=_0x1024d5['namespace']);const _0x56af5a=[];return x(_0x630091,(_0xb6a547,_0x2db0ba)=>{_0x56af5a['push'](_0xb6a547+'='+_0x2db0ba);}),_0x15f110+_0x56af5a['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x217727,_0x10dc87=0x1){Q(this['counters_'],_0x217727)||(this['counters_'][_0x217727]=0x0),this['counters_'][_0x217727]+=_0x10dc87;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x496d5e){const _0x2adcef=_0x496d5e['toString']();return oi[_0x2adcef]||(oi[_0x2adcef]=new nh()),oi[_0x2adcef];}function ih(_0x45b7b8,_0x37655d){const _0x423bb2=_0x45b7b8['toString']();return ai[_0x423bb2]||(ai[_0x423bb2]=_0x37655d()),ai[_0x423bb2];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4e6ce7){this['onMessage_']=_0x4e6ce7,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x46a221,_0x4930a9){this['closeAfterResponse']=_0x46a221,this['onClose']=_0x4930a9,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4ca45c,_0x24d007){for(this['pendingResponses'][_0x4ca45c]=_0x24d007;this['pendingResponses'][this['currentResponseNum']];){const _0x15306a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1d9a0a=0x0;_0x1d9a0a<_0x15306a['length'];++_0x1d9a0a)_0x15306a[_0x1d9a0a]&&ft(()=>{this['onMessage_'](_0x15306a[_0x1d9a0a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3140ff,_0x40722c,_0x77003,_0x14a13c,_0x56033c,_0x36128d,_0x8fc5f4){this['connId']=_0x3140ff,this['repoInfo']=_0x40722c,this['applicationId']=_0x77003,this['appCheckToken']=_0x14a13c,this['authToken']=_0x56033c,this['transportSessionId']=_0x36128d,this['lastSessionId']=_0x8fc5f4,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x3140ff),this['stats_']=qi(_0x40722c),this['urlFn']=_0x39fbd2=>(this['appCheckToken']&&(_0x39fbd2[wi]=this['appCheckToken']),vo(_0x40722c,mo,_0x39fbd2));}['open'](_0x5efe88,_0x435f44){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x435f44,this['myPacketOrderer']=new sh(_0x5efe88),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x31c4a7)=>{const [_0x5b4918,_0x245d79,_0x2cf2bb,_0xe08407,_0x5a1365]=_0x31c4a7;if(this['incrementIncomingBytes_'](_0x31c4a7),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5b4918===qs)this['id']=_0x245d79,this['password']=_0x2cf2bb;else{if(_0x5b4918===rh)_0x245d79?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x245d79,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5b4918);}}},(..._0x232556)=>{const [_0x307e32,_0x71f3e2]=_0x232556;this['incrementIncomingBytes_'](_0x232556),this['myPacketOrderer']['handleResponse'](_0x307e32,_0x71f3e2);},()=>{this['onClosed_']();},this['urlFn']);const _0x13b300={};_0x13b300[qs]='t',_0x13b300[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x13b300[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x13b300[co]=Gi,this['transportSessionId']&&(_0x13b300[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x13b300[po]=this['lastSessionId']),this['applicationId']&&(_0x13b300[_o]=this['applicationId']),this['appCheckToken']&&(_0x13b300[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x13b300[ho]=uo);const _0x4d19fa=this['urlFn'](_0x13b300);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4d19fa),this['scriptTagHolder']['addTag'](_0x4d19fa,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4d39ee){const _0xe8b1cf=O(_0x4d39ee);this['bytesSent']+=_0xe8b1cf['length'],this['stats_']['incrementCounter']('bytes_sent',_0xe8b1cf['length']);const _0x255fff=$r(_0xe8b1cf),_0xe23f4b=oo(_0x255fff,fh);for(let _0x298ed3=0x0;_0x298ed3<_0xe23f4b['length'];_0x298ed3++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xe23f4b['length'],_0xe23f4b[_0x298ed3]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5341d0,_0x580bdc){this['myDisconnFrame']=document['createElement']('iframe');const _0x2f6c3e={};_0x2f6c3e[dh]='t',_0x2f6c3e[Eo]=_0x5341d0,_0x2f6c3e[Io]=_0x580bdc,this['myDisconnFrame']['src']=this['urlFn'](_0x2f6c3e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xa11da){const _0x181362=O(_0xa11da)['length'];this['bytesReceived']+=_0x181362,this['stats_']['incrementCounter']('bytes_received',_0x181362);}}class zi{constructor(_0x3c0534,_0x416a70,_0x1de0ae,_0x403fa9){this['onDisconnect']=_0x1de0ae,this['urlFn']=_0x403fa9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3c0534,window[ah+this['uniqueCallbackIdentifier']]=_0x416a70,this['myIFrame']=zi['createIFrame_']();let _0x33f83a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x33f83a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xd26dcf='<html><body>'+_0x33f83a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xd26dcf),this['myIFrame']['doc']['close']();}catch(_0x2d020f){L('frame\x20writing\x20exception'),_0x2d020f['stack']&&L(_0x2d020f['stack']),L(_0x2d020f);}}}static['createIFrame_'](){const _0x940e4d=document['createElement']('iframe');if(_0x940e4d['style']['display']='none',document['body']){document['body']['appendChild'](_0x940e4d);try{_0x940e4d['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1ae882=document['domain'];_0x940e4d['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1ae882+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x940e4d['contentDocument']?_0x940e4d['doc']=_0x940e4d['contentDocument']:_0x940e4d['contentWindow']?_0x940e4d['doc']=_0x940e4d['contentWindow']['document']:_0x940e4d['document']&&(_0x940e4d['doc']=_0x940e4d['document']),_0x940e4d;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x78965=this['onDisconnect'];_0x78965&&(this['onDisconnect']=null,_0x78965());}['startLongPoll'](_0x592e11,_0x56af0a){for(this['myID']=_0x592e11,this['myPW']=_0x56af0a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1369bb={};_0x1369bb[Eo]=this['myID'],_0x1369bb[Io]=this['myPW'],_0x1369bb[wo]=this['currentSerial'];let _0x5571ee=this['urlFn'](_0x1369bb),_0x360d46='',_0x4ca424=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x360d46['length']<=Co;){const _0x4774c0=this['pendingSegs']['shift']();_0x360d46=_0x360d46+'&'+lh+_0x4ca424+'='+_0x4774c0['seg']+'&'+hh+_0x4ca424+'='+_0x4774c0['ts']+'&'+uh+_0x4ca424+'='+_0x4774c0['d'],_0x4ca424++;}return _0x5571ee=_0x5571ee+_0x360d46,this['addLongPollTag_'](_0x5571ee,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x16500f,_0x2161a3,_0x3c4b5d){this['pendingSegs']['push']({'seg':_0x16500f,'ts':_0x2161a3,'d':_0x3c4b5d}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x11144b,_0x1536ac){this['outstandingRequests']['add'](_0x1536ac);const _0x5e949f=()=>{this['outstandingRequests']['delete'](_0x1536ac),this['newRequest_']();},_0x7ba0b=setTimeout(_0x5e949f,Math['floor'](ph)),_0x185758=()=>{clearTimeout(_0x7ba0b),_0x5e949f();};this['addTag'](_0x11144b,_0x185758);}['addTag'](_0x5f345a,_0x9bed0){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4a8bf2=this['myIFrame']['doc']['createElement']('script');_0x4a8bf2['type']='text/javascript',_0x4a8bf2['async']=!0x0,_0x4a8bf2['src']=_0x5f345a,_0x4a8bf2['onload']=_0x4a8bf2['onreadystatechange']=function(){const _0x2a3064=_0x4a8bf2['readyState'];(!_0x2a3064||_0x2a3064==='loaded'||_0x2a3064==='complete')&&(_0x4a8bf2['onload']=_0x4a8bf2['onreadystatechange']=null,_0x4a8bf2['parentNode']&&_0x4a8bf2['parentNode']['removeChild'](_0x4a8bf2),_0x9bed0());},_0x4a8bf2['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5f345a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4a8bf2);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2c879f,_0x2f2f03,_0x3d4779,_0x53e77f,_0x49be7,_0x3f9b06,_0x2e0b03){this['connId']=_0x2c879f,this['applicationId']=_0x3d4779,this['appCheckToken']=_0x53e77f,this['authToken']=_0x49be7,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x2f2f03),this['connURL']=q['connectionURL_'](_0x2f2f03,_0x3f9b06,_0x2e0b03,_0x53e77f,_0x3d4779),this['nodeAdmin']=_0x2f2f03['nodeAdmin'];}static['connectionURL_'](_0x257a68,_0x12fbc2,_0x43091d,_0x2e2d11,_0x31bebb){const _0x40d429={};return _0x40d429[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x40d429[ho]=uo),_0x12fbc2&&(_0x40d429[lo]=_0x12fbc2),_0x43091d&&(_0x40d429[po]=_0x43091d),_0x2e2d11&&(_0x40d429[wi]=_0x2e2d11),_0x31bebb&&(_0x40d429[_o]=_0x31bebb),vo(_0x257a68,go,_0x40d429);}['open'](_0x5f1696,_0x19849d){this['onDisconnect']=_0x19849d,this['onMessage']=_0x5f1696,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x3f607a;_c(),this['mySock']=new gn(this['connURL'],[],_0x3f607a);}catch(_0x44b84a){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xd80cf3=_0x44b84a['message']||_0x44b84a['data'];_0xd80cf3&&this['log_'](_0xd80cf3),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x21e88a=>{this['handleIncomingFrame'](_0x21e88a);},this['mySock']['onerror']=_0x192c68=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xa66963=_0x192c68['message']||_0x192c68['data'];_0xa66963&&this['log_'](_0xa66963),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x27330b=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1a6e7f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x327fc7=navigator['userAgent']['match'](_0x1a6e7f);_0x327fc7&&_0x327fc7['length']>0x1&&parseFloat(_0x327fc7[0x1])<4.4&&(_0x27330b=!0x0);}return!_0x27330b&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x1facb7){if(this['frames']['push'](_0x1facb7),this['frames']['length']===this['totalFrames']){const _0x37d2d4=this['frames']['join']('');this['frames']=null;const _0xfc339d=Nt(_0x37d2d4);this['onMessage'](_0xfc339d);}}['handleNewFrameCount_'](_0x41c3e4){this['totalFrames']=_0x41c3e4,this['frames']=[];}['extractFrameCount_'](_0x16813b){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x16813b['length']<=0x6){const _0x2d987b=Number(_0x16813b);if(!isNaN(_0x2d987b))return this['handleNewFrameCount_'](_0x2d987b),null;}return this['handleNewFrameCount_'](0x1),_0x16813b;}['handleIncomingFrame'](_0x5c02e1){if(this['mySock']===null)return;const _0x4acc1d=_0x5c02e1['data'];if(this['bytesReceived']+=_0x4acc1d['length'],this['stats_']['incrementCounter']('bytes_received',_0x4acc1d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4acc1d);else{const _0x2d19db=this['extractFrameCount_'](_0x4acc1d);_0x2d19db!==null&&this['appendFrame_'](_0x2d19db);}}['send'](_0x300b4c){this['resetKeepAlive']();const _0x56f71b=O(_0x300b4c);this['bytesSent']+=_0x56f71b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x56f71b['length']);const _0x5cec46=oo(_0x56f71b,gh);_0x5cec46['length']>0x1&&this['sendString_'](String(_0x5cec46['length']));for(let _0x3d2bcc=0x0;_0x3d2bcc<_0x5cec46['length'];_0x3d2bcc++)this['sendString_'](_0x5cec46[_0x3d2bcc]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x269515){try{this['mySock']['send'](_0x269515);}catch(_0x33d003){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x33d003['message']||_0x33d003['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0xced9d){this['initTransports_'](_0xced9d);}['initTransports_'](_0x49be82){const _0x53512f=q&&q['isAvailable']();let _0x1ab81e=_0x53512f&&!q['previouslyFailed']();if(_0x49be82['webSocketOnly']&&(_0x53512f||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1ab81e=!0x0),_0x1ab81e)this['transports_']=[q];else{const _0x1cccb5=this['transports_']=[];for(const _0x24ed0a of Dt['ALL_TRANSPORTS'])_0x24ed0a&&_0x24ed0a['isAvailable']()&&_0x1cccb5['push'](_0x24ed0a);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x2ade05,_0x54333f,_0x38b1f5,_0x284d79,_0xb521cd,_0x1940c3,_0x4ad1a6,_0x23ca50,_0x878686,_0x32c457){this['id']=_0x2ade05,this['repoInfo_']=_0x54333f,this['applicationId_']=_0x38b1f5,this['appCheckToken_']=_0x284d79,this['authToken_']=_0xb521cd,this['onMessage_']=_0x1940c3,this['onReady_']=_0x4ad1a6,this['onDisconnect_']=_0x23ca50,this['onKill_']=_0x878686,this['lastSessionId']=_0x32c457,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x54333f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xdb3b80=this['transportManager_']['initialTransport']();this['conn_']=new _0xdb3b80(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xdb3b80['responsesRequiredToBeHealthy']||0x0;const _0x43c0cf=this['connReceiver_'](this['conn_']),_0x2a9d1c=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x43c0cf,_0x2a9d1c);},Math['floor'](0x0));const _0x2b9e1b=_0xdb3b80['healthyTimeout']||0x0;_0x2b9e1b>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2b9e1b)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x762c90){return _0x3c5fcf=>{_0x762c90===this['conn_']?this['onConnectionLost_'](_0x3c5fcf):_0x762c90===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3edf9f){return _0x5ab54b=>{this['state_']!==0x2&&(_0x3edf9f===this['rx_']?this['onPrimaryMessageReceived_'](_0x5ab54b):_0x3edf9f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5ab54b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x18e200){const _0x2f2288={'t':'d','d':_0x18e200};this['sendData_'](_0x2f2288);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x57b97c){if(ci in _0x57b97c){const _0x3dda14=_0x57b97c[ci];_0x3dda14===Ys?this['upgradeIfSecondaryHealthy_']():_0x3dda14===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3dda14===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x163834){const _0x402e37=vt('t',_0x163834),_0x442cc6=vt('d',_0x163834);if(_0x402e37==='c')this['onSecondaryControl_'](_0x442cc6);else{if(_0x402e37==='d')this['pendingDataMessages']['push'](_0x442cc6);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x402e37);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4dd473){const _0x281081=vt('t',_0x4dd473),_0x4cf44f=vt('d',_0x4dd473);_0x281081==='c'?this['onControl_'](_0x4cf44f):_0x281081==='d'&&this['onDataMessage_'](_0x4cf44f);}['onDataMessage_'](_0x220081){this['onPrimaryResponse_'](),this['onMessage_'](_0x220081);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x55522f){const _0x1e2c6f=vt(ci,_0x55522f);if(zs in _0x55522f){const _0x3fc463=_0x55522f[zs];if(_0x1e2c6f===Th){const _0x32e0ec={..._0x3fc463};this['repoInfo_']['isUsingEmulator']&&(_0x32e0ec['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x32e0ec);}else{if(_0x1e2c6f===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3007d=0x0;_0x3007d<this['pendingDataMessages']['length'];++_0x3007d)this['onDataMessage_'](this['pendingDataMessages'][_0x3007d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1e2c6f===wh?this['onConnectionShutdown_'](_0x3fc463):_0x1e2c6f===js?this['onReset_'](_0x3fc463):_0x1e2c6f===Ch?Ii('Server\x20Error:\x20'+_0x3fc463):_0x1e2c6f===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1e2c6f);}}}['onHandshake_'](_0x6202ab){const _0x570ef2=_0x6202ab['ts'],_0x4051bf=_0x6202ab['v'],_0x2f5dd3=_0x6202ab['h'];this['sessionId']=_0x6202ab['s'],this['repoInfo_']['host']=_0x2f5dd3,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x570ef2),Gi!==_0x4051bf&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x6f296=this['transportManager_']['upgradeTransport']();_0x6f296&&this['startUpgrade_'](_0x6f296);}['startUpgrade_'](_0x4611f7){this['secondaryConn_']=new _0x4611f7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4611f7['responsesRequiredToBeHealthy']||0x0;const _0x17dcf5=this['connReceiver_'](this['secondaryConn_']),_0xeae3f9=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x17dcf5,_0xeae3f9),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5b2488){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5b2488),this['repoInfo_']['host']=_0x5b2488,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2152dd,_0x6c3ded){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2152dd,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x6c3ded,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4e3fe3=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4e3fe3||this['rx_']===_0x4e3fe3)&&this['close']();}['onConnectionLost_'](_0x66d39b){this['conn_']=null,!_0x66d39b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x4f393b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x4f393b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2ffcb0){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2ffcb0);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x14fd0c,_0x472883,_0x2be1c9,_0xee4bb8){}['merge'](_0x5a2e6b,_0x300148,_0x563861,_0xd3d77f){}['refreshAuthToken'](_0x5c1192){}['refreshAppCheckToken'](_0x12c4aa){}['onDisconnectPut'](_0x18ead5,_0x5c964f,_0x5c5849){}['onDisconnectMerge'](_0x8812e0,_0x385d5d,_0x7ea8fe){}['onDisconnectCancel'](_0x2893e0,_0x2e1923){}['reportStats'](_0xc1495d){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x519b81){this['allowedEvents_']=_0x519b81,this['listeners_']={},f(Array['isArray'](_0x519b81)&&_0x519b81['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x16f0a8,..._0x3ab115){if(Array['isArray'](this['listeners_'][_0x16f0a8])){const _0x1de700=[...this['listeners_'][_0x16f0a8]];for(let _0x650652=0x0;_0x650652<_0x1de700['length'];_0x650652++)_0x1de700[_0x650652]['callback']['apply'](_0x1de700[_0x650652]['context'],_0x3ab115);}}['on'](_0x52e477,_0x23cea2,_0x277a5b){this['validateEventType_'](_0x52e477),this['listeners_'][_0x52e477]=this['listeners_'][_0x52e477]||[],this['listeners_'][_0x52e477]['push']({'callback':_0x23cea2,'context':_0x277a5b});const _0x5275a2=this['getInitialEvent'](_0x52e477);_0x5275a2&&_0x23cea2['apply'](_0x277a5b,_0x5275a2);}['off'](_0x267078,_0x4e12e3,_0x14f0e2){this['validateEventType_'](_0x267078);const _0x608ee=this['listeners_'][_0x267078]||[];for(let _0x1ab720=0x0;_0x1ab720<_0x608ee['length'];_0x1ab720++)if(_0x608ee[_0x1ab720]['callback']===_0x4e12e3&&(!_0x14f0e2||_0x14f0e2===_0x608ee[_0x1ab720]['context'])){_0x608ee['splice'](_0x1ab720,0x1);return;}}['validateEventType_'](_0x210249){f(this['allowedEvents_']['find'](_0x4a786e=>_0x4a786e===_0x210249),'Unknown\x20event:\x20'+_0x210249);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x242499){return f(_0x242499==='online','Unknown\x20event\x20type:\x20'+_0x242499),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x331623,_0x36662f){if(_0x36662f===void 0x0){this['pieces_']=_0x331623['split']('/');let _0x4c73bd=0x0;for(let _0x422768=0x0;_0x422768<this['pieces_']['length'];_0x422768++)this['pieces_'][_0x422768]['length']>0x0&&(this['pieces_'][_0x4c73bd]=this['pieces_'][_0x422768],_0x4c73bd++);this['pieces_']['length']=_0x4c73bd,this['pieceNum_']=0x0;}else this['pieces_']=_0x331623,this['pieceNum_']=_0x36662f;}['toString'](){let _0x239e29='';for(let _0x3ce206=this['pieceNum_'];_0x3ce206<this['pieces_']['length'];_0x3ce206++)this['pieces_'][_0x3ce206]!==''&&(_0x239e29+='/'+this['pieces_'][_0x3ce206]);return _0x239e29||'/';}}function w(){return new C('');}function y(_0x32850a){return _0x32850a['pieceNum_']>=_0x32850a['pieces_']['length']?null:_0x32850a['pieces_'][_0x32850a['pieceNum_']];}function Ce(_0x356412){return _0x356412['pieces_']['length']-_0x356412['pieceNum_'];}function S(_0x25da4d){let _0x254109=_0x25da4d['pieceNum_'];return _0x254109<_0x25da4d['pieces_']['length']&&_0x254109++,new C(_0x25da4d['pieces_'],_0x254109);}function ji(_0xa7b0ac){return _0xa7b0ac['pieceNum_']<_0xa7b0ac['pieces_']['length']?_0xa7b0ac['pieces_'][_0xa7b0ac['pieces_']['length']-0x1]:null;}function bh(_0x2a987c){let _0x2a7627='';for(let _0x2c9406=_0x2a987c['pieceNum_'];_0x2c9406<_0x2a987c['pieces_']['length'];_0x2c9406++)_0x2a987c['pieces_'][_0x2c9406]!==''&&(_0x2a7627+='/'+encodeURIComponent(String(_0x2a987c['pieces_'][_0x2c9406])));return _0x2a7627||'/';}function Mt(_0x5bcd4d,_0x1afdf9=0x0){return _0x5bcd4d['pieces_']['slice'](_0x5bcd4d['pieceNum_']+_0x1afdf9);}function Ro(_0x1e0124){if(_0x1e0124['pieceNum_']>=_0x1e0124['pieces_']['length'])return null;const _0x22a29f=[];for(let _0x10f67b=_0x1e0124['pieceNum_'];_0x10f67b<_0x1e0124['pieces_']['length']-0x1;_0x10f67b++)_0x22a29f['push'](_0x1e0124['pieces_'][_0x10f67b]);return new C(_0x22a29f,0x0);}function k(_0x3560e7,_0x4f5e38){const _0x309acb=[];for(let _0x31dfe1=_0x3560e7['pieceNum_'];_0x31dfe1<_0x3560e7['pieces_']['length'];_0x31dfe1++)_0x309acb['push'](_0x3560e7['pieces_'][_0x31dfe1]);if(_0x4f5e38 instanceof C){for(let _0x38b54f=_0x4f5e38['pieceNum_'];_0x38b54f<_0x4f5e38['pieces_']['length'];_0x38b54f++)_0x309acb['push'](_0x4f5e38['pieces_'][_0x38b54f]);}else{const _0x5e1e82=_0x4f5e38['split']('/');for(let _0x51f9d1=0x0;_0x51f9d1<_0x5e1e82['length'];_0x51f9d1++)_0x5e1e82[_0x51f9d1]['length']>0x0&&_0x309acb['push'](_0x5e1e82[_0x51f9d1]);}return new C(_0x309acb,0x0);}function v(_0x3bcbc6){return _0x3bcbc6['pieceNum_']>=_0x3bcbc6['pieces_']['length'];}function F(_0x411c33,_0x34509a){const _0x1b4438=y(_0x411c33),_0x3c3623=y(_0x34509a);if(_0x1b4438===null)return _0x34509a;if(_0x1b4438===_0x3c3623)return F(S(_0x411c33),S(_0x34509a));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x34509a+')\x20is\x20not\x20within\x20outerPath\x20('+_0x411c33+')');}function Rh(_0x221ed2,_0xa0fb24){const _0x404fbc=Mt(_0x221ed2,0x0),_0x1d7f56=Mt(_0xa0fb24,0x0);for(let _0x16b238=0x0;_0x16b238<_0x404fbc['length']&&_0x16b238<_0x1d7f56['length'];_0x16b238++){const _0x27bc15=qe(_0x404fbc[_0x16b238],_0x1d7f56[_0x16b238]);if(_0x27bc15!==0x0)return _0x27bc15;}return _0x404fbc['length']===_0x1d7f56['length']?0x0:_0x404fbc['length']<_0x1d7f56['length']?-0x1:0x1;}function Ki(_0x5d76c0,_0x44a130){if(Ce(_0x5d76c0)!==Ce(_0x44a130))return!0x1;for(let _0xf8093f=_0x5d76c0['pieceNum_'],_0x33be88=_0x44a130['pieceNum_'];_0xf8093f<=_0x5d76c0['pieces_']['length'];_0xf8093f++,_0x33be88++)if(_0x5d76c0['pieces_'][_0xf8093f]!==_0x44a130['pieces_'][_0x33be88])return!0x1;return!0x0;}function G(_0x2fd8bf,_0x202309){let _0x588505=_0x2fd8bf['pieceNum_'],_0x200f24=_0x202309['pieceNum_'];if(Ce(_0x2fd8bf)>Ce(_0x202309))return!0x1;for(;_0x588505<_0x2fd8bf['pieces_']['length'];){if(_0x2fd8bf['pieces_'][_0x588505]!==_0x202309['pieces_'][_0x200f24])return!0x1;++_0x588505,++_0x200f24;}return!0x0;}class Ah{constructor(_0x12ce96,_0x141d7d){this['errorPrefix_']=_0x141d7d,this['parts_']=Mt(_0x12ce96,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5775e1=0x0;_0x5775e1<this['parts_']['length'];_0x5775e1++)this['byteLength_']+=Ln(this['parts_'][_0x5775e1]);Ao(this);}}function kh(_0x5e3027,_0x1d59e4){_0x5e3027['parts_']['length']>0x0&&(_0x5e3027['byteLength_']+=0x1),_0x5e3027['parts_']['push'](_0x1d59e4),_0x5e3027['byteLength_']+=Ln(_0x1d59e4),Ao(_0x5e3027);}function Ph(_0x1ffd85){const _0x29e3c8=_0x1ffd85['parts_']['pop']();_0x1ffd85['byteLength_']-=Ln(_0x29e3c8),_0x1ffd85['parts_']['length']>0x0&&(_0x1ffd85['byteLength_']-=0x1);}function Ao(_0x598d1f){if(_0x598d1f['byteLength_']>Zs)throw new Error(_0x598d1f['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x598d1f['byteLength_']+').');if(_0x598d1f['parts_']['length']>Xs)throw new Error(_0x598d1f['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x598d1f));}function Oe(_0xff2946){return _0xff2946['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xff2946['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x24987a,_0x3a4803;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3a4803='visibilitychange',_0x24987a='hidden'):typeof document['mozHidden']<'u'?(_0x3a4803='mozvisibilitychange',_0x24987a='mozHidden'):typeof document['msHidden']<'u'?(_0x3a4803='msvisibilitychange',_0x24987a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3a4803='webkitvisibilitychange',_0x24987a='webkitHidden')),this['visible_']=!0x0,_0x3a4803&&document['addEventListener'](_0x3a4803,()=>{const _0x41a870=!document[_0x24987a];_0x41a870!==this['visible_']&&(this['visible_']=_0x41a870,this['trigger']('visible',_0x41a870));},!0x1);}['getInitialEvent'](_0x923f18){return f(_0x923f18==='visible','Unknown\x20event\x20type:\x20'+_0x923f18),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x35fc6c,_0xa209e8,_0x57e7e5,_0x487b88,_0x5df6f4,_0x5b16df,_0x213c4a,_0x4335c6){if(super(),this['repoInfo_']=_0x35fc6c,this['applicationId_']=_0xa209e8,this['onDataUpdate_']=_0x57e7e5,this['onConnectStatus_']=_0x487b88,this['onServerInfoUpdate_']=_0x5df6f4,this['authTokenProvider_']=_0x5b16df,this['appCheckTokenProvider_']=_0x213c4a,this['authOverride_']=_0x4335c6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4335c6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x35fc6c['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x9e1061,_0x110f06,_0x439c55){const _0x2a0a36=++this['requestNumber_'],_0xefeb2d={'r':_0x2a0a36,'a':_0x9e1061,'b':_0x110f06};this['log_'](O(_0xefeb2d)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xefeb2d),_0x439c55&&(this['requestCBHash_'][_0x2a0a36]=_0x439c55);}['get'](_0xfcbcf7){this['initConnection_']();const _0x1f9cd5=new H(),_0x2ff757={'action':'g','request':{'p':_0xfcbcf7['_path']['toString'](),'q':_0xfcbcf7['_queryObject']},'onComplete':_0x334825=>{const _0x56467a=_0x334825['d'];_0x334825['s']==='ok'?_0x1f9cd5['resolve'](_0x56467a):_0x1f9cd5['reject'](_0x56467a);}};this['outstandingGets_']['push'](_0x2ff757),this['outstandingGetCount_']++;const _0x1aa57a=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1aa57a),_0x1f9cd5['promise'];}['listen'](_0x5e40c7,_0x167669,_0x2df935,_0x2a4389){this['initConnection_']();const _0x2a2306=_0x5e40c7['_queryIdentifier'],_0x49f6b7=_0x5e40c7['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x49f6b7+'\x20'+_0x2a2306),this['listens']['has'](_0x49f6b7)||this['listens']['set'](_0x49f6b7,new Map()),f(_0x5e40c7['_queryParams']['isDefault']()||!_0x5e40c7['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x49f6b7)['has'](_0x2a2306),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x3482fb={'onComplete':_0x2a4389,'hashFn':_0x167669,'query':_0x5e40c7,'tag':_0x2df935};this['listens']['get'](_0x49f6b7)['set'](_0x2a2306,_0x3482fb),this['connected_']&&this['sendListen_'](_0x3482fb);}['sendGet_'](_0xf1a13f){const _0x528111=this['outstandingGets_'][_0xf1a13f];this['sendRequest']('g',_0x528111['request'],_0x34a5a2=>{delete this['outstandingGets_'][_0xf1a13f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x528111['onComplete']&&_0x528111['onComplete'](_0x34a5a2);});}['sendListen_'](_0x448623){const _0x392544=_0x448623['query'],_0x2287d8=_0x392544['_path']['toString'](),_0x2a8707=_0x392544['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2287d8+'\x20for\x20'+_0x2a8707);const _0x1a96d3={'p':_0x2287d8},_0x5b7d0e='q';_0x448623['tag']&&(_0x1a96d3['q']=_0x392544['_queryObject'],_0x1a96d3['t']=_0x448623['tag']),_0x1a96d3['h']=_0x448623['hashFn'](),this['sendRequest'](_0x5b7d0e,_0x1a96d3,_0xbba749=>{const _0x4b0260=_0xbba749['d'],_0x48f00e=_0xbba749['s'];se['warnOnListenWarnings_'](_0x4b0260,_0x392544),(this['listens']['get'](_0x2287d8)&&this['listens']['get'](_0x2287d8)['get'](_0x2a8707))===_0x448623&&(this['log_']('listen\x20response',_0xbba749),_0x48f00e!=='ok'&&this['removeListen_'](_0x2287d8,_0x2a8707),_0x448623['onComplete']&&_0x448623['onComplete'](_0x48f00e,_0x4b0260));});}static['warnOnListenWarnings_'](_0x666d1,_0x1fed6f){if(_0x666d1&&typeof _0x666d1=='object'&&Q(_0x666d1,'w')){const _0x16c057=Le(_0x666d1,'w');if(Array['isArray'](_0x16c057)&&~_0x16c057['indexOf']('no_index')){const _0x6cb3f0='\x22.indexOn\x22:\x20\x22'+_0x1fed6f['_queryParams']['getIndex']()['toString']()+'\x22',_0x36298e=_0x1fed6f['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x6cb3f0+'\x20at\x20'+_0x36298e+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3e932a){this['authToken_']=_0x3e932a,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3e932a);}['reduceReconnectDelayIfAdminCredential_'](_0x4ae3b8){(_0x4ae3b8&&_0x4ae3b8['length']===0x28||wc(_0x4ae3b8))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2025aa){this['appCheckToken_']=_0x2025aa,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x57d1dc=this['authToken_'],_0x17d9f4=Ic(_0x57d1dc)?'auth':'gauth',_0x4683cf={'cred':_0x57d1dc};this['authOverride_']===null?_0x4683cf['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4683cf['authvar']=this['authOverride_']),this['sendRequest'](_0x17d9f4,_0x4683cf,_0x48f9ce=>{const _0x4c4dee=_0x48f9ce['s'],_0x4503e1=_0x48f9ce['d']||'error';this['authToken_']===_0x57d1dc&&(_0x4c4dee==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4c4dee,_0x4503e1));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3dcd3c=>{const _0x4c7bc4=_0x3dcd3c['s'],_0x4df56d=_0x3dcd3c['d']||'error';_0x4c7bc4==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4c7bc4,_0x4df56d);});}['unlisten'](_0x714192,_0x583631){const _0x142158=_0x714192['_path']['toString'](),_0x4c1d3e=_0x714192['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x142158+'\x20'+_0x4c1d3e),f(_0x714192['_queryParams']['isDefault']()||!_0x714192['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x142158,_0x4c1d3e)&&this['connected_']&&this['sendUnlisten_'](_0x142158,_0x4c1d3e,_0x714192['_queryObject'],_0x583631);}['sendUnlisten_'](_0x4aae68,_0x3e58b1,_0x380084,_0x489b58){this['log_']('Unlisten\x20on\x20'+_0x4aae68+'\x20for\x20'+_0x3e58b1);const _0x297728={'p':_0x4aae68},_0x3bee4f='n';_0x489b58&&(_0x297728['q']=_0x380084,_0x297728['t']=_0x489b58),this['sendRequest'](_0x3bee4f,_0x297728);}['onDisconnectPut'](_0x37ac4a,_0x27812e,_0xc80263){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x37ac4a,_0x27812e,_0xc80263):this['onDisconnectRequestQueue_']['push']({'pathString':_0x37ac4a,'action':'o','data':_0x27812e,'onComplete':_0xc80263});}['onDisconnectMerge'](_0x2924c5,_0x5dac1a,_0x51ba08){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x2924c5,_0x5dac1a,_0x51ba08):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2924c5,'action':'om','data':_0x5dac1a,'onComplete':_0x51ba08});}['onDisconnectCancel'](_0xa856b0,_0x42a9c9){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xa856b0,null,_0x42a9c9):this['onDisconnectRequestQueue_']['push']({'pathString':_0xa856b0,'action':'oc','data':null,'onComplete':_0x42a9c9});}['sendOnDisconnect_'](_0x334397,_0x502a8a,_0x2fdba6,_0x4a0e9e){const _0x193824={'p':_0x502a8a,'d':_0x2fdba6};this['log_']('onDisconnect\x20'+_0x334397,_0x193824),this['sendRequest'](_0x334397,_0x193824,_0x12bd4a=>{_0x4a0e9e&&setTimeout(()=>{_0x4a0e9e(_0x12bd4a['s'],_0x12bd4a['d']);},Math['floor'](0x0));});}['put'](_0x1a7bde,_0x41ba36,_0x2d2fd2,_0x4ace35){this['putInternal']('p',_0x1a7bde,_0x41ba36,_0x2d2fd2,_0x4ace35);}['merge'](_0xfbb665,_0x5a6efe,_0x593bd9,_0x3d4cd5){this['putInternal']('m',_0xfbb665,_0x5a6efe,_0x593bd9,_0x3d4cd5);}['putInternal'](_0xf00e56,_0x541e35,_0x36ab38,_0x4c1742,_0x8c29f8){this['initConnection_']();const _0x492a67={'p':_0x541e35,'d':_0x36ab38};_0x8c29f8!==void 0x0&&(_0x492a67['h']=_0x8c29f8),this['outstandingPuts_']['push']({'action':_0xf00e56,'request':_0x492a67,'onComplete':_0x4c1742}),this['outstandingPutCount_']++;const _0x165458=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x165458):this['log_']('Buffering\x20put:\x20'+_0x541e35);}['sendPut_'](_0x1ff125){const _0x2b3643=this['outstandingPuts_'][_0x1ff125]['action'],_0x191070=this['outstandingPuts_'][_0x1ff125]['request'],_0x19d3b9=this['outstandingPuts_'][_0x1ff125]['onComplete'];this['outstandingPuts_'][_0x1ff125]['queued']=this['connected_'],this['sendRequest'](_0x2b3643,_0x191070,_0x2f7702=>{this['log_'](_0x2b3643+'\x20response',_0x2f7702),delete this['outstandingPuts_'][_0x1ff125],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x19d3b9&&_0x19d3b9(_0x2f7702['s'],_0x2f7702['d']);});}['reportStats'](_0x2ed2ed){if(this['connected_']){const _0x5d1436={'c':_0x2ed2ed};this['log_']('reportStats',_0x5d1436),this['sendRequest']('s',_0x5d1436,_0x1a1899=>{if(_0x1a1899['s']!=='ok'){const _0x584f61=_0x1a1899['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x584f61);}});}}['onDataMessage_'](_0x2372ab){if('r'in _0x2372ab){this['log_']('from\x20server:\x20'+O(_0x2372ab));const _0x2b3e3=_0x2372ab['r'],_0x20a925=this['requestCBHash_'][_0x2b3e3];_0x20a925&&(delete this['requestCBHash_'][_0x2b3e3],_0x20a925(_0x2372ab['b']));}else{if('error'in _0x2372ab)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2372ab['error'];'a'in _0x2372ab&&this['onDataPush_'](_0x2372ab['a'],_0x2372ab['b']);}}['onDataPush_'](_0x10a865,_0x49cffe){this['log_']('handleServerMessage',_0x10a865,_0x49cffe),_0x10a865==='d'?this['onDataUpdate_'](_0x49cffe['p'],_0x49cffe['d'],!0x1,_0x49cffe['t']):_0x10a865==='m'?this['onDataUpdate_'](_0x49cffe['p'],_0x49cffe['d'],!0x0,_0x49cffe['t']):_0x10a865==='c'?this['onListenRevoked_'](_0x49cffe['p'],_0x49cffe['q']):_0x10a865==='ac'?this['onAuthRevoked_'](_0x49cffe['s'],_0x49cffe['d']):_0x10a865==='apc'?this['onAppCheckRevoked_'](_0x49cffe['s'],_0x49cffe['d']):_0x10a865==='sd'?this['onSecurityDebugPacket_'](_0x49cffe):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x10a865)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5b00e3,_0x3a6186){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5b00e3),this['lastSessionId']=_0x3a6186,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4ddd18){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4ddd18));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x23eda4){_0x23eda4&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x23eda4;}['onOnline_'](_0x4ab2bf){_0x4ab2bf?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x43f770=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x15804a=Math['max'](0x0,this['reconnectDelay_']-_0x43f770);_0x15804a=Math['random']()*_0x15804a,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x15804a+'ms'),this['scheduleConnect_'](_0x15804a),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0xb4a204=this['onDataMessage_']['bind'](this),_0xe80f42=this['onReady_']['bind'](this),_0x113dea=this['onRealtimeDisconnect_']['bind'](this),_0x3df9af=this['id']+':'+se['nextConnectionId_']++,_0x26bf15=this['lastSessionId'];let _0x4e0600=!0x1,_0x28ea44=null;const _0x191755=function(){_0x28ea44?_0x28ea44['close']():(_0x4e0600=!0x0,_0x113dea());},_0x1986aa=function(_0x2e8b95){f(_0x28ea44,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x28ea44['sendRequest'](_0x2e8b95);};this['realtime_']={'close':_0x191755,'sendRequest':_0x1986aa};const _0x52247a=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x44cb2e,_0x36f447]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x52247a),this['appCheckTokenProvider_']['getToken'](_0x52247a)]);_0x4e0600?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x44cb2e&&_0x44cb2e['accessToken'],this['appCheckToken_']=_0x36f447&&_0x36f447['token'],_0x28ea44=new Sh(_0x3df9af,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0xb4a204,_0xe80f42,_0x113dea,_0x28d821=>{U(_0x28d821+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x26bf15));}catch(_0x5d1fd9){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5d1fd9),_0x4e0600||(this['repoInfo_']['nodeAdmin']&&U(_0x5d1fd9),_0x191755());}}}['interrupt'](_0x2db6d5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2db6d5),this['interruptReasons_'][_0x2db6d5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1aee0e){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1aee0e),delete this['interruptReasons_'][_0x1aee0e],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xcb0c70){const _0x39a638=_0xcb0c70-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x39a638});}['cancelSentTransactions_'](){for(let _0x2e82e0=0x0;_0x2e82e0<this['outstandingPuts_']['length'];_0x2e82e0++){const _0x41ec0f=this['outstandingPuts_'][_0x2e82e0];_0x41ec0f&&'h'in _0x41ec0f['request']&&_0x41ec0f['queued']&&(_0x41ec0f['onComplete']&&_0x41ec0f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2e82e0],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x53e7c6,_0x4e6ec2){let _0x18cb6c;_0x4e6ec2?_0x18cb6c=_0x4e6ec2['map'](_0x217cd5=>$i(_0x217cd5))['join']('$'):_0x18cb6c='default';const _0x19a36e=this['removeListen_'](_0x53e7c6,_0x18cb6c);_0x19a36e&&_0x19a36e['onComplete']&&_0x19a36e['onComplete']('permission_denied');}['removeListen_'](_0x542666,_0x371f89){const _0x9c56da=new C(_0x542666)['toString']();let _0xd8324d;if(this['listens']['has'](_0x9c56da)){const _0x5e924d=this['listens']['get'](_0x9c56da);_0xd8324d=_0x5e924d['get'](_0x371f89),_0x5e924d['delete'](_0x371f89),_0x5e924d['size']===0x0&&this['listens']['delete'](_0x9c56da);}else _0xd8324d=void 0x0;return _0xd8324d;}['onAuthRevoked_'](_0x1ab026,_0x428b21){L('Auth\x20token\x20revoked:\x20'+_0x1ab026+'/'+_0x428b21),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1ab026==='invalid_token'||_0x1ab026==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x17ad6f,_0x13f5c0){L('App\x20check\x20token\x20revoked:\x20'+_0x17ad6f+'/'+_0x13f5c0),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x17ad6f==='invalid_token'||_0x17ad6f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1d134b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1d134b):'msg'in _0x1d134b&&console['log']('FIREBASE:\x20'+_0x1d134b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1aa5a9 of this['listens']['values']())for(const _0x1e2c98 of _0x1aa5a9['values']())this['sendListen_'](_0x1e2c98);for(let _0x54d9c3=0x0;_0x54d9c3<this['outstandingPuts_']['length'];_0x54d9c3++)this['outstandingPuts_'][_0x54d9c3]&&this['sendPut_'](_0x54d9c3);for(;this['onDisconnectRequestQueue_']['length'];){const _0xc2fc0b=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xc2fc0b['action'],_0xc2fc0b['pathString'],_0xc2fc0b['data'],_0xc2fc0b['onComplete']);}for(let _0x420988=0x0;_0x420988<this['outstandingGets_']['length'];_0x420988++)this['outstandingGets_'][_0x420988]&&this['sendGet_'](_0x420988);}['sendConnectStats_'](){const _0x551b91={};let _0x1d7de3='js';_0x551b91['sdk.'+_0x1d7de3+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x551b91['framework.cordova']=0x1:Kr()&&(_0x551b91['framework.reactnative']=0x1),this['reportStats'](_0x551b91);}['shouldReconnect_'](){const _0xa1775=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0xa1775;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4fcca5,_0xe5bb3d){this['name']=_0x4fcca5,this['node']=_0xe5bb3d;}static['Wrap'](_0x16896d,_0x35c9f9){return new E(_0x16896d,_0x35c9f9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2d4d2f,_0x38e9bd){const _0x268f98=new E(We,_0x2d4d2f),_0x21d9e2=new E(We,_0x38e9bd);return this['compare'](_0x268f98,_0x21d9e2)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x54e0e0){sn=_0x54e0e0;}['compare'](_0x252dd1,_0x174cef){return qe(_0x252dd1['name'],_0x174cef['name']);}['isDefinedOn'](_0x5034ff){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x95fa7a,_0x343841){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x539269,_0x16c121){return f(typeof _0x539269=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x539269,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x341bd0,_0x12e21a,_0x450be5,_0x2d3022,_0x18f3cc=null){this['isReverse_']=_0x2d3022,this['resultGenerator_']=_0x18f3cc,this['nodeStack_']=[];let _0x40baf5=0x1;for(;!_0x341bd0['isEmpty']();)if(_0x341bd0=_0x341bd0,_0x40baf5=_0x12e21a?_0x450be5(_0x341bd0['key'],_0x12e21a):0x1,_0x2d3022&&(_0x40baf5*=-0x1),_0x40baf5<0x0)this['isReverse_']?_0x341bd0=_0x341bd0['left']:_0x341bd0=_0x341bd0['right'];else{if(_0x40baf5===0x0){this['nodeStack_']['push'](_0x341bd0);break;}else this['nodeStack_']['push'](_0x341bd0),this['isReverse_']?_0x341bd0=_0x341bd0['right']:_0x341bd0=_0x341bd0['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x24ee77=this['nodeStack_']['pop'](),_0x4a066a;if(this['resultGenerator_']?_0x4a066a=this['resultGenerator_'](_0x24ee77['key'],_0x24ee77['value']):_0x4a066a={'key':_0x24ee77['key'],'value':_0x24ee77['value']},this['isReverse_']){for(_0x24ee77=_0x24ee77['left'];!_0x24ee77['isEmpty']();)this['nodeStack_']['push'](_0x24ee77),_0x24ee77=_0x24ee77['right'];}else{for(_0x24ee77=_0x24ee77['right'];!_0x24ee77['isEmpty']();)this['nodeStack_']['push'](_0x24ee77),_0x24ee77=_0x24ee77['left'];}return _0x4a066a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x125f13=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x125f13['key'],_0x125f13['value']):{'key':_0x125f13['key'],'value':_0x125f13['value']};}}class M{constructor(_0x1c0017,_0x226db0,_0x188524,_0x297025,_0x278fa6){this['key']=_0x1c0017,this['value']=_0x226db0,this['color']=_0x188524??M['RED'],this['left']=_0x297025??B['EMPTY_NODE'],this['right']=_0x278fa6??B['EMPTY_NODE'];}['copy'](_0x495215,_0x20f6b2,_0x30d1e6,_0x34f27b,_0x21445b){return new M(_0x495215??this['key'],_0x20f6b2??this['value'],_0x30d1e6??this['color'],_0x34f27b??this['left'],_0x21445b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x462752){return this['left']['inorderTraversal'](_0x462752)||!!_0x462752(this['key'],this['value'])||this['right']['inorderTraversal'](_0x462752);}['reverseTraversal'](_0x29ba3b){return this['right']['reverseTraversal'](_0x29ba3b)||_0x29ba3b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x29ba3b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4100f6,_0x25497c,_0x8d81bb){let _0x26abae=this;const _0xe3c717=_0x8d81bb(_0x4100f6,_0x26abae['key']);return _0xe3c717<0x0?_0x26abae=_0x26abae['copy'](null,null,null,_0x26abae['left']['insert'](_0x4100f6,_0x25497c,_0x8d81bb),null):_0xe3c717===0x0?_0x26abae=_0x26abae['copy'](null,_0x25497c,null,null,null):_0x26abae=_0x26abae['copy'](null,null,null,null,_0x26abae['right']['insert'](_0x4100f6,_0x25497c,_0x8d81bb)),_0x26abae['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4316ff=this;return!_0x4316ff['left']['isRed_']()&&!_0x4316ff['left']['left']['isRed_']()&&(_0x4316ff=_0x4316ff['moveRedLeft_']()),_0x4316ff=_0x4316ff['copy'](null,null,null,_0x4316ff['left']['removeMin_'](),null),_0x4316ff['fixUp_']();}['remove'](_0x1ccdee,_0x1bee58){let _0x238b6f,_0x532e3c;if(_0x238b6f=this,_0x1bee58(_0x1ccdee,_0x238b6f['key'])<0x0)!_0x238b6f['left']['isEmpty']()&&!_0x238b6f['left']['isRed_']()&&!_0x238b6f['left']['left']['isRed_']()&&(_0x238b6f=_0x238b6f['moveRedLeft_']()),_0x238b6f=_0x238b6f['copy'](null,null,null,_0x238b6f['left']['remove'](_0x1ccdee,_0x1bee58),null);else{if(_0x238b6f['left']['isRed_']()&&(_0x238b6f=_0x238b6f['rotateRight_']()),!_0x238b6f['right']['isEmpty']()&&!_0x238b6f['right']['isRed_']()&&!_0x238b6f['right']['left']['isRed_']()&&(_0x238b6f=_0x238b6f['moveRedRight_']()),_0x1bee58(_0x1ccdee,_0x238b6f['key'])===0x0){if(_0x238b6f['right']['isEmpty']())return B['EMPTY_NODE'];_0x532e3c=_0x238b6f['right']['min_'](),_0x238b6f=_0x238b6f['copy'](_0x532e3c['key'],_0x532e3c['value'],null,null,_0x238b6f['right']['removeMin_']());}_0x238b6f=_0x238b6f['copy'](null,null,null,null,_0x238b6f['right']['remove'](_0x1ccdee,_0x1bee58));}return _0x238b6f['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x26b05c=this;return _0x26b05c['right']['isRed_']()&&!_0x26b05c['left']['isRed_']()&&(_0x26b05c=_0x26b05c['rotateLeft_']()),_0x26b05c['left']['isRed_']()&&_0x26b05c['left']['left']['isRed_']()&&(_0x26b05c=_0x26b05c['rotateRight_']()),_0x26b05c['left']['isRed_']()&&_0x26b05c['right']['isRed_']()&&(_0x26b05c=_0x26b05c['colorFlip_']()),_0x26b05c;}['moveRedLeft_'](){let _0x4a97ff=this['colorFlip_']();return _0x4a97ff['right']['left']['isRed_']()&&(_0x4a97ff=_0x4a97ff['copy'](null,null,null,null,_0x4a97ff['right']['rotateRight_']()),_0x4a97ff=_0x4a97ff['rotateLeft_'](),_0x4a97ff=_0x4a97ff['colorFlip_']()),_0x4a97ff;}['moveRedRight_'](){let _0x44abe4=this['colorFlip_']();return _0x44abe4['left']['left']['isRed_']()&&(_0x44abe4=_0x44abe4['rotateRight_'](),_0x44abe4=_0x44abe4['colorFlip_']()),_0x44abe4;}['rotateLeft_'](){const _0x57454f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x57454f,null);}['rotateRight_'](){const _0x3dceee=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3dceee);}['colorFlip_'](){const _0x52969b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x46adff=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x52969b,_0x46adff);}['checkMaxDepth_'](){const _0x2cc348=this['check_']();return Math['pow'](0x2,_0x2cc348)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2f7d71=this['left']['check_']();if(_0x2f7d71!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2f7d71+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x470ff3,_0x78b096,_0x12c641,_0x232f3d,_0x3c81a6){return this;}['insert'](_0x3dbcb4,_0x2f28ae,_0x5acbff){return new M(_0x3dbcb4,_0x2f28ae,null);}['remove'](_0x26e0f3,_0x532884){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x293c13){return!0x1;}['reverseTraversal'](_0x5bbbda){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x56ca07,_0x3db06a=B['EMPTY_NODE']){this['comparator_']=_0x56ca07,this['root_']=_0x3db06a;}['insert'](_0x50f963,_0x1f45ab){return new B(this['comparator_'],this['root_']['insert'](_0x50f963,_0x1f45ab,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3088e0){return new B(this['comparator_'],this['root_']['remove'](_0x3088e0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2aeba7){let _0x44b9c4,_0x1ad513=this['root_'];for(;!_0x1ad513['isEmpty']();){if(_0x44b9c4=this['comparator_'](_0x2aeba7,_0x1ad513['key']),_0x44b9c4===0x0)return _0x1ad513['value'];_0x44b9c4<0x0?_0x1ad513=_0x1ad513['left']:_0x44b9c4>0x0&&(_0x1ad513=_0x1ad513['right']);}return null;}['getPredecessorKey'](_0x2d5596){let _0x3565f5,_0x391105=this['root_'],_0x1b941e=null;for(;!_0x391105['isEmpty']();)if(_0x3565f5=this['comparator_'](_0x2d5596,_0x391105['key']),_0x3565f5===0x0){if(_0x391105['left']['isEmpty']())return _0x1b941e?_0x1b941e['key']:null;for(_0x391105=_0x391105['left'];!_0x391105['right']['isEmpty']();)_0x391105=_0x391105['right'];return _0x391105['key'];}else _0x3565f5<0x0?_0x391105=_0x391105['left']:_0x3565f5>0x0&&(_0x1b941e=_0x391105,_0x391105=_0x391105['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x3e7cc3){return this['root_']['inorderTraversal'](_0x3e7cc3);}['reverseTraversal'](_0x4dbfa3){return this['root_']['reverseTraversal'](_0x4dbfa3);}['getIterator'](_0x4e7b47){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x4e7b47);}['getIteratorFrom'](_0x58ce4f,_0x1e681b){return new rn(this['root_'],_0x58ce4f,this['comparator_'],!0x1,_0x1e681b);}['getReverseIteratorFrom'](_0x380199,_0x247c3d){return new rn(this['root_'],_0x380199,this['comparator_'],!0x0,_0x247c3d);}['getReverseIterator'](_0x3a08f3){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3a08f3);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2a20b7,_0x408f22){return qe(_0x2a20b7['name'],_0x408f22['name']);}function Qi(_0x3a07fb,_0x5d7774){return qe(_0x3a07fb,_0x5d7774);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x479799){Ci=_0x479799;}const Po=function(_0x386814){return typeof _0x386814=='number'?'number:'+ao(_0x386814):'string:'+_0x386814;},No=function(_0x23abf7){if(_0x23abf7['isLeafNode']()){const _0x42deac=_0x23abf7['val']();f(typeof _0x42deac=='string'||typeof _0x42deac=='number'||typeof _0x42deac=='object'&&Q(_0x42deac,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x23abf7===Ci||_0x23abf7['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x23abf7===Ci||_0x23abf7['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x19d841){nr=_0x19d841;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x459dd4,_0x45fd23=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x459dd4,this['priorityNode_']=_0x45fd23,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3b0673){return new D(this['value_'],_0x3b0673);}['getImmediateChild'](_0x25f41d){return _0x25f41d==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x770aed){return v(_0x770aed)?this:y(_0x770aed)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x313e91,_0xf4caf7){return null;}['updateImmediateChild'](_0x459ad9,_0x222bcb){return _0x459ad9==='.priority'?this['updatePriority'](_0x222bcb):_0x222bcb['isEmpty']()&&_0x459ad9!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x459ad9,_0x222bcb)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x130f0e,_0x3e7130){const _0x191d6a=y(_0x130f0e);return _0x191d6a===null?_0x3e7130:_0x3e7130['isEmpty']()&&_0x191d6a!=='.priority'?this:(f(_0x191d6a!=='.priority'||Ce(_0x130f0e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x191d6a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x130f0e),_0x3e7130)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xbe115a,_0x47e4d7){return!0x1;}['val'](_0x4f0d3a){return _0x4f0d3a&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x27c7fc='';this['priorityNode_']['isEmpty']()||(_0x27c7fc+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x21d7d5=typeof this['value_'];_0x27c7fc+=_0x21d7d5+':',_0x21d7d5==='number'?_0x27c7fc+=ao(this['value_']):_0x27c7fc+=this['value_'],this['lazyHash_']=ro(_0x27c7fc);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5c4fe4){return _0x5c4fe4===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5c4fe4 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5c4fe4['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5c4fe4));}['compareToLeafNode_'](_0x21c6a8){const _0x4156ea=typeof _0x21c6a8['value_'],_0x1ed861=typeof this['value_'],_0x2c2bf7=D['VALUE_TYPE_ORDER']['indexOf'](_0x4156ea),_0x3d6a57=D['VALUE_TYPE_ORDER']['indexOf'](_0x1ed861);return f(_0x2c2bf7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4156ea),f(_0x3d6a57>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1ed861),_0x2c2bf7===_0x3d6a57?_0x1ed861==='object'?0x0:this['value_']<_0x21c6a8['value_']?-0x1:this['value_']===_0x21c6a8['value_']?0x0:0x1:_0x3d6a57-_0x2c2bf7;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4389d3){if(_0x4389d3===this)return!0x0;if(_0x4389d3['isLeafNode']()){const _0xa9fbd1=_0x4389d3;return this['value_']===_0xa9fbd1['value_']&&this['priorityNode_']['equals'](_0xa9fbd1['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x21794f){Oo=_0x21794f;}function Wh(_0x51d90c){Do=_0x51d90c;}class Bh extends Fn{['compare'](_0x10ef0e,_0x31de9d){const _0x583bc4=_0x10ef0e['node']['getPriority'](),_0x14c37b=_0x31de9d['node']['getPriority'](),_0x3afb1c=_0x583bc4['compareTo'](_0x14c37b);return _0x3afb1c===0x0?qe(_0x10ef0e['name'],_0x31de9d['name']):_0x3afb1c;}['isDefinedOn'](_0x3f2f29){return!_0x3f2f29['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4ac32f,_0x146e05){return!_0x4ac32f['getPriority']()['equals'](_0x146e05['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x519891,_0x314114){const _0x25cd42=Oo(_0x519891);return new E(_0x314114,new D('[PRIORITY-POST]',_0x25cd42));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x235bc6){const _0x1f8871=_0x5a47c1=>parseInt(Math['log'](_0x5a47c1)/Vh,0xa),_0x327533=_0x31db8f=>parseInt(Array(_0x31db8f+0x1)['join']('1'),0x2);this['count']=_0x1f8871(_0x235bc6+0x1),this['current_']=this['count']-0x1;const _0x475d75=_0x327533(this['count']);this['bits_']=_0x235bc6+0x1&_0x475d75;}['nextBitIsOne'](){const _0x5e43a2=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5e43a2;}}const yn=function(_0x46aa4b,_0x3788a4,_0x549e17,_0x4b55a9){_0x46aa4b['sort'](_0x3788a4);const _0x11d85f=function(_0xb4eab5,_0x245923){const _0xc6ed7b=_0x245923-_0xb4eab5;let _0x57c76a,_0x55cd8e;if(_0xc6ed7b===0x0)return null;if(_0xc6ed7b===0x1)return _0x57c76a=_0x46aa4b[_0xb4eab5],_0x55cd8e=_0x549e17?_0x549e17(_0x57c76a):_0x57c76a,new M(_0x55cd8e,_0x57c76a['node'],M['BLACK'],null,null);{const _0x2c0a74=parseInt(_0xc6ed7b/0x2,0xa)+_0xb4eab5,_0x564d01=_0x11d85f(_0xb4eab5,_0x2c0a74),_0x569705=_0x11d85f(_0x2c0a74+0x1,_0x245923);return _0x57c76a=_0x46aa4b[_0x2c0a74],_0x55cd8e=_0x549e17?_0x549e17(_0x57c76a):_0x57c76a,new M(_0x55cd8e,_0x57c76a['node'],M['BLACK'],_0x564d01,_0x569705);}},_0xd1cf5d=function(_0x5d92d5){let _0x5ba5b0=null,_0x46366c=null,_0x59a865=_0x46aa4b['length'];const _0x41be8d=function(_0x4fffcf,_0x39879f){const _0x3d6da0=_0x59a865-_0x4fffcf,_0x327ef5=_0x59a865;_0x59a865-=_0x4fffcf;const _0x5bd18e=_0x11d85f(_0x3d6da0+0x1,_0x327ef5),_0xe086be=_0x46aa4b[_0x3d6da0],_0x458f17=_0x549e17?_0x549e17(_0xe086be):_0xe086be;_0x5c1253(new M(_0x458f17,_0xe086be['node'],_0x39879f,null,_0x5bd18e));},_0x5c1253=function(_0x3d1732){_0x5ba5b0?(_0x5ba5b0['left']=_0x3d1732,_0x5ba5b0=_0x3d1732):(_0x46366c=_0x3d1732,_0x5ba5b0=_0x3d1732);};for(let _0x39a538=0x0;_0x39a538<_0x5d92d5['count'];++_0x39a538){const _0x5c52b=_0x5d92d5['nextBitIsOne'](),_0x4678da=Math['pow'](0x2,_0x5d92d5['count']-(_0x39a538+0x1));_0x5c52b?_0x41be8d(_0x4678da,M['BLACK']):(_0x41be8d(_0x4678da,M['BLACK']),_0x41be8d(_0x4678da,M['RED']));}return _0x46366c;},_0x467994=new Hh(_0x46aa4b['length']),_0x464822=_0xd1cf5d(_0x467994);return new B(_0x4b55a9||_0x3788a4,_0x464822);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x46794c,_0x513cba){this['indexes_']=_0x46794c,this['indexSet_']=_0x513cba;}['get'](_0x46c7fe){const _0x14600a=Le(this['indexes_'],_0x46c7fe);if(!_0x14600a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x46c7fe);return _0x14600a instanceof B?_0x14600a:null;}['hasIndex'](_0x2f976f){return Q(this['indexSet_'],_0x2f976f['toString']());}['addIndex'](_0x3e3041,_0x38f4d8){f(_0x3e3041!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x495174=[];let _0x360b90=!0x1;const _0x16b032=_0x38f4d8['getIterator'](E['Wrap']);let _0x2e4e32=_0x16b032['getNext']();for(;_0x2e4e32;)_0x360b90=_0x360b90||_0x3e3041['isDefinedOn'](_0x2e4e32['node']),_0x495174['push'](_0x2e4e32),_0x2e4e32=_0x16b032['getNext']();let _0x1c6e10;_0x360b90?_0x1c6e10=yn(_0x495174,_0x3e3041['getCompare']()):_0x1c6e10=Qe;const _0x442a8d=_0x3e3041['toString'](),_0x80a66f={...this['indexSet_']};_0x80a66f[_0x442a8d]=_0x3e3041;const _0x15aa68={...this['indexes_']};return _0x15aa68[_0x442a8d]=_0x1c6e10,new te(_0x15aa68,_0x80a66f);}['addToIndexes'](_0x526f86,_0x42e03b){const _0x15537e=_n(this['indexes_'],(_0x68743b,_0x23628b)=>{const _0x1345cf=Le(this['indexSet_'],_0x23628b);if(f(_0x1345cf,'Missing\x20index\x20implementation\x20for\x20'+_0x23628b),_0x68743b===Qe){if(_0x1345cf['isDefinedOn'](_0x526f86['node'])){const _0x51d1f5=[],_0x569a8d=_0x42e03b['getIterator'](E['Wrap']);let _0x2918e6=_0x569a8d['getNext']();for(;_0x2918e6;)_0x2918e6['name']!==_0x526f86['name']&&_0x51d1f5['push'](_0x2918e6),_0x2918e6=_0x569a8d['getNext']();return _0x51d1f5['push'](_0x526f86),yn(_0x51d1f5,_0x1345cf['getCompare']());}else return Qe;}else{const _0x586ff1=_0x42e03b['get'](_0x526f86['name']);let _0x27ecee=_0x68743b;return _0x586ff1&&(_0x27ecee=_0x27ecee['remove'](new E(_0x526f86['name'],_0x586ff1))),_0x27ecee['insert'](_0x526f86,_0x526f86['node']);}});return new te(_0x15537e,this['indexSet_']);}['removeFromIndexes'](_0x4a32ee,_0x2a91d7){const _0x4f2585=_n(this['indexes_'],_0x51b61f=>{if(_0x51b61f===Qe)return _0x51b61f;{const _0x1f8627=_0x2a91d7['get'](_0x4a32ee['name']);return _0x1f8627?_0x51b61f['remove'](new E(_0x4a32ee['name'],_0x1f8627)):_0x51b61f;}});return new te(_0x4f2585,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0xb17c1b,_0x26e6f6,_0x4cfd47){this['children_']=_0xb17c1b,this['priorityNode_']=_0x26e6f6,this['indexMap_']=_0x4cfd47,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x55d109){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x55d109,this['indexMap_']);}['getImmediateChild'](_0x33dac5){if(_0x33dac5==='.priority')return this['getPriority']();{const _0x6f5b=this['children_']['get'](_0x33dac5);return _0x6f5b===null?It:_0x6f5b;}}['getChild'](_0x4f4d03){const _0x4ca61f=y(_0x4f4d03);return _0x4ca61f===null?this:this['getImmediateChild'](_0x4ca61f)['getChild'](S(_0x4f4d03));}['hasChild'](_0x6b90e2){return this['children_']['get'](_0x6b90e2)!==null;}['updateImmediateChild'](_0x53e17d,_0x2a83fe){if(f(_0x2a83fe,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x53e17d==='.priority')return this['updatePriority'](_0x2a83fe);{const _0x2addc5=new E(_0x53e17d,_0x2a83fe);let _0x1f5375,_0x3846ce;_0x2a83fe['isEmpty']()?(_0x1f5375=this['children_']['remove'](_0x53e17d),_0x3846ce=this['indexMap_']['removeFromIndexes'](_0x2addc5,this['children_'])):(_0x1f5375=this['children_']['insert'](_0x53e17d,_0x2a83fe),_0x3846ce=this['indexMap_']['addToIndexes'](_0x2addc5,this['children_']));const _0x36e00a=_0x1f5375['isEmpty']()?It:this['priorityNode_'];return new g(_0x1f5375,_0x36e00a,_0x3846ce);}}['updateChild'](_0x533d77,_0xf675fb){const _0x482a0d=y(_0x533d77);if(_0x482a0d===null)return _0xf675fb;{f(y(_0x533d77)!=='.priority'||Ce(_0x533d77)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0xa005d4=this['getImmediateChild'](_0x482a0d)['updateChild'](S(_0x533d77),_0xf675fb);return this['updateImmediateChild'](_0x482a0d,_0xa005d4);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5aa07f){if(this['isEmpty']())return null;const _0x575e32={};let _0x26c7e1=0x0,_0x5151ee=0x0,_0xb27f7f=!0x0;if(this['forEachChild'](R,(_0x3e1b62,_0x5d535b)=>{_0x575e32[_0x3e1b62]=_0x5d535b['val'](_0x5aa07f),_0x26c7e1++,_0xb27f7f&&g['INTEGER_REGEXP_']['test'](_0x3e1b62)?_0x5151ee=Math['max'](_0x5151ee,Number(_0x3e1b62)):_0xb27f7f=!0x1;}),!_0x5aa07f&&_0xb27f7f&&_0x5151ee<0x2*_0x26c7e1){const _0x14452f=[];for(const _0x37cf11 in _0x575e32)_0x14452f[_0x37cf11]=_0x575e32[_0x37cf11];return _0x14452f;}else return _0x5aa07f&&!this['getPriority']()['isEmpty']()&&(_0x575e32['.priority']=this['getPriority']()['val']()),_0x575e32;}['hash'](){if(this['lazyHash_']===null){let _0x7b4ec7='';this['getPriority']()['isEmpty']()||(_0x7b4ec7+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x2e98c9,_0x1dccd4)=>{const _0x4cc01e=_0x1dccd4['hash']();_0x4cc01e!==''&&(_0x7b4ec7+=':'+_0x2e98c9+':'+_0x4cc01e);}),this['lazyHash_']=_0x7b4ec7===''?'':ro(_0x7b4ec7);}return this['lazyHash_'];}['getPredecessorChildName'](_0x18d622,_0x590a02,_0x3e6ab0){const _0x2526fb=this['resolveIndex_'](_0x3e6ab0);if(_0x2526fb){const _0x3a4774=_0x2526fb['getPredecessorKey'](new E(_0x18d622,_0x590a02));return _0x3a4774?_0x3a4774['name']:null;}else return this['children_']['getPredecessorKey'](_0x18d622);}['getFirstChildName'](_0x16b8a6){const _0x2e62f8=this['resolveIndex_'](_0x16b8a6);if(_0x2e62f8){const _0x3b203a=_0x2e62f8['minKey']();return _0x3b203a&&_0x3b203a['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1395f5){const _0x1d5ee3=this['getFirstChildName'](_0x1395f5);return _0x1d5ee3?new E(_0x1d5ee3,this['children_']['get'](_0x1d5ee3)):null;}['getLastChildName'](_0x4fec7d){const _0x2de694=this['resolveIndex_'](_0x4fec7d);if(_0x2de694){const _0x19e600=_0x2de694['maxKey']();return _0x19e600&&_0x19e600['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x41fdfc){const _0x37792c=this['getLastChildName'](_0x41fdfc);return _0x37792c?new E(_0x37792c,this['children_']['get'](_0x37792c)):null;}['forEachChild'](_0x396b41,_0x4edad7){const _0x25d321=this['resolveIndex_'](_0x396b41);return _0x25d321?_0x25d321['inorderTraversal'](_0x1938d8=>_0x4edad7(_0x1938d8['name'],_0x1938d8['node'])):this['children_']['inorderTraversal'](_0x4edad7);}['getIterator'](_0x11326e){return this['getIteratorFrom'](_0x11326e['minPost'](),_0x11326e);}['getIteratorFrom'](_0x158009,_0x262c83){const _0x1b26f7=this['resolveIndex_'](_0x262c83);if(_0x1b26f7)return _0x1b26f7['getIteratorFrom'](_0x158009,_0x49d50b=>_0x49d50b);{const _0x1c6b07=this['children_']['getIteratorFrom'](_0x158009['name'],E['Wrap']);let _0x45d94b=_0x1c6b07['peek']();for(;_0x45d94b!=null&&_0x262c83['compare'](_0x45d94b,_0x158009)<0x0;)_0x1c6b07['getNext'](),_0x45d94b=_0x1c6b07['peek']();return _0x1c6b07;}}['getReverseIterator'](_0x1fa910){return this['getReverseIteratorFrom'](_0x1fa910['maxPost'](),_0x1fa910);}['getReverseIteratorFrom'](_0xa12e08,_0x55dc15){const _0x12f6cc=this['resolveIndex_'](_0x55dc15);if(_0x12f6cc)return _0x12f6cc['getReverseIteratorFrom'](_0xa12e08,_0x4643aa=>_0x4643aa);{const _0x226f02=this['children_']['getReverseIteratorFrom'](_0xa12e08['name'],E['Wrap']);let _0x3cba7c=_0x226f02['peek']();for(;_0x3cba7c!=null&&_0x55dc15['compare'](_0x3cba7c,_0xa12e08)>0x0;)_0x226f02['getNext'](),_0x3cba7c=_0x226f02['peek']();return _0x226f02;}}['compareTo'](_0x1c29d9){return this['isEmpty']()?_0x1c29d9['isEmpty']()?0x0:-0x1:_0x1c29d9['isLeafNode']()||_0x1c29d9['isEmpty']()?0x1:_0x1c29d9===Kt?-0x1:0x0;}['withIndex'](_0x2564ab){if(_0x2564ab===ve||this['indexMap_']['hasIndex'](_0x2564ab))return this;{const _0x234060=this['indexMap_']['addIndex'](_0x2564ab,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x234060);}}['isIndexed'](_0x3da4c2){return _0x3da4c2===ve||this['indexMap_']['hasIndex'](_0x3da4c2);}['equals'](_0x5ef1c1){if(_0x5ef1c1===this)return!0x0;if(_0x5ef1c1['isLeafNode']())return!0x1;{const _0x524a46=_0x5ef1c1;if(this['getPriority']()['equals'](_0x524a46['getPriority']())){if(this['children_']['count']()===_0x524a46['children_']['count']()){const _0xa6b6b0=this['getIterator'](R),_0x4a76a4=_0x524a46['getIterator'](R);let _0x4b3944=_0xa6b6b0['getNext'](),_0x36c63c=_0x4a76a4['getNext']();for(;_0x4b3944&&_0x36c63c;){if(_0x4b3944['name']!==_0x36c63c['name']||!_0x4b3944['node']['equals'](_0x36c63c['node']))return!0x1;_0x4b3944=_0xa6b6b0['getNext'](),_0x36c63c=_0x4a76a4['getNext']();}return _0x4b3944===null&&_0x36c63c===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3f9a8e){return _0x3f9a8e===ve?null:this['indexMap_']['get'](_0x3f9a8e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x52dc5e){return _0x52dc5e===this?0x0:0x1;}['equals'](_0x25610d){return _0x25610d===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5d757b){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x436ae8,_0x19fee9=null){if(_0x436ae8===null)return g['EMPTY_NODE'];if(typeof _0x436ae8=='object'&&'.priority'in _0x436ae8&&(_0x19fee9=_0x436ae8['.priority']),f(_0x19fee9===null||typeof _0x19fee9=='string'||typeof _0x19fee9=='number'||typeof _0x19fee9=='object'&&'.sv'in _0x19fee9,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x19fee9),typeof _0x436ae8=='object'&&'.value'in _0x436ae8&&_0x436ae8['.value']!==null&&(_0x436ae8=_0x436ae8['.value']),typeof _0x436ae8!='object'||'.sv'in _0x436ae8){const _0xe544ee=_0x436ae8;return new D(_0xe544ee,A(_0x19fee9));}if(!(_0x436ae8 instanceof Array)&&Gh){const _0x498dd6=[];let _0x2df940=!0x1;if(x(_0x436ae8,(_0x41be74,_0x41a871)=>{if(_0x41be74['substring'](0x0,0x1)!=='.'){const _0xe93a7b=A(_0x41a871);_0xe93a7b['isEmpty']()||(_0x2df940=_0x2df940||!_0xe93a7b['getPriority']()['isEmpty'](),_0x498dd6['push'](new E(_0x41be74,_0xe93a7b)));}}),_0x498dd6['length']===0x0)return g['EMPTY_NODE'];const _0x52060a=yn(_0x498dd6,xh,_0x239c98=>_0x239c98['name'],Qi);if(_0x2df940){const _0x3d4b72=yn(_0x498dd6,R['getCompare']());return new g(_0x52060a,A(_0x19fee9),new te({'.priority':_0x3d4b72},{'.priority':R}));}else return new g(_0x52060a,A(_0x19fee9),te['Default']);}else{let _0x243883=g['EMPTY_NODE'];return x(_0x436ae8,(_0x223c10,_0x3b5284)=>{if(Q(_0x436ae8,_0x223c10)&&_0x223c10['substring'](0x0,0x1)!=='.'){const _0x1a3c6a=A(_0x3b5284);(_0x1a3c6a['isLeafNode']()||!_0x1a3c6a['isEmpty']())&&(_0x243883=_0x243883['updateImmediateChild'](_0x223c10,_0x1a3c6a));}}),_0x243883['updatePriority'](A(_0x19fee9));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x55e5de){super(),this['indexPath_']=_0x55e5de,f(!v(_0x55e5de)&&y(_0x55e5de)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xa42e32){return _0xa42e32['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1e47a0){return!_0x1e47a0['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2f1ed8,_0x527612){const _0x1fdf4d=this['extractChild'](_0x2f1ed8['node']),_0x17a458=this['extractChild'](_0x527612['node']),_0x16535c=_0x1fdf4d['compareTo'](_0x17a458);return _0x16535c===0x0?qe(_0x2f1ed8['name'],_0x527612['name']):_0x16535c;}['makePost'](_0x15e4d1,_0x2a4d8b){const _0x2d0839=A(_0x15e4d1),_0x180d9a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2d0839);return new E(_0x2a4d8b,_0x180d9a);}['maxPost'](){const _0x137d42=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x137d42);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x13c884,_0x2ba1cb){const _0x276f4f=_0x13c884['node']['compareTo'](_0x2ba1cb['node']);return _0x276f4f===0x0?qe(_0x13c884['name'],_0x2ba1cb['name']):_0x276f4f;}['isDefinedOn'](_0x338c7f){return!0x0;}['indexedValueChanged'](_0x57151c,_0x485c37){return!_0x57151c['equals'](_0x485c37);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x4f8090,_0x26a27b){const _0x224243=A(_0x4f8090);return new E(_0x26a27b,_0x224243);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xfce015){return{'type':'value','snapshotNode':_0xfce015};}function rt(_0x15679b,_0x36f1bf){return{'type':'child_added','snapshotNode':_0x36f1bf,'childName':_0x15679b};}function Lt(_0x39e733,_0x59c0a3){return{'type':'child_removed','snapshotNode':_0x59c0a3,'childName':_0x39e733};}function xt(_0x42350a,_0x4542e5,_0x54993f){return{'type':'child_changed','snapshotNode':_0x4542e5,'childName':_0x42350a,'oldSnap':_0x54993f};}function zh(_0x495c75,_0x52534d){return{'type':'child_moved','snapshotNode':_0x52534d,'childName':_0x495c75};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x5b6a2e){this['index_']=_0x5b6a2e;}['updateChild'](_0x5dd339,_0x4beb28,_0x3d6aa3,_0x5ef7c5,_0x797ea0,_0x318199){f(_0x5dd339['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x123d0e=_0x5dd339['getImmediateChild'](_0x4beb28);return _0x123d0e['getChild'](_0x5ef7c5)['equals'](_0x3d6aa3['getChild'](_0x5ef7c5))&&_0x123d0e['isEmpty']()===_0x3d6aa3['isEmpty']()||(_0x318199!=null&&(_0x3d6aa3['isEmpty']()?_0x5dd339['hasChild'](_0x4beb28)?_0x318199['trackChildChange'](Lt(_0x4beb28,_0x123d0e)):f(_0x5dd339['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x123d0e['isEmpty']()?_0x318199['trackChildChange'](rt(_0x4beb28,_0x3d6aa3)):_0x318199['trackChildChange'](xt(_0x4beb28,_0x3d6aa3,_0x123d0e))),_0x5dd339['isLeafNode']()&&_0x3d6aa3['isEmpty']())?_0x5dd339:_0x5dd339['updateImmediateChild'](_0x4beb28,_0x3d6aa3)['withIndex'](this['index_']);}['updateFullNode'](_0x4555f9,_0x5ee96b,_0x1ebd29){return _0x1ebd29!=null&&(_0x4555f9['isLeafNode']()||_0x4555f9['forEachChild'](R,(_0x2f9553,_0x4fbf79)=>{_0x5ee96b['hasChild'](_0x2f9553)||_0x1ebd29['trackChildChange'](Lt(_0x2f9553,_0x4fbf79));}),_0x5ee96b['isLeafNode']()||_0x5ee96b['forEachChild'](R,(_0x2071dc,_0x34e2cc)=>{if(_0x4555f9['hasChild'](_0x2071dc)){const _0x5a9892=_0x4555f9['getImmediateChild'](_0x2071dc);_0x5a9892['equals'](_0x34e2cc)||_0x1ebd29['trackChildChange'](xt(_0x2071dc,_0x34e2cc,_0x5a9892));}else _0x1ebd29['trackChildChange'](rt(_0x2071dc,_0x34e2cc));})),_0x5ee96b['withIndex'](this['index_']);}['updatePriority'](_0x53c5a4,_0x591d25){return _0x53c5a4['isEmpty']()?g['EMPTY_NODE']:_0x53c5a4['updatePriority'](_0x591d25);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x9ccf3a){this['indexedFilter_']=new Xi(_0x9ccf3a['getIndex']()),this['index_']=_0x9ccf3a['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x9ccf3a),this['endPost_']=Ft['getEndPost_'](_0x9ccf3a),this['startIsInclusive_']=!_0x9ccf3a['startAfterSet_'],this['endIsInclusive_']=!_0x9ccf3a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x16c2b3){const _0xdfdef7=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x16c2b3)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x16c2b3)<0x0,_0x4cdb89=this['endIsInclusive_']?this['index_']['compare'](_0x16c2b3,this['getEndPost']())<=0x0:this['index_']['compare'](_0x16c2b3,this['getEndPost']())<0x0;return _0xdfdef7&&_0x4cdb89;}['updateChild'](_0x313ab2,_0xb940a2,_0x7c5e79,_0x3a6101,_0x1ccaa9,_0x40db05){return this['matches'](new E(_0xb940a2,_0x7c5e79))||(_0x7c5e79=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x313ab2,_0xb940a2,_0x7c5e79,_0x3a6101,_0x1ccaa9,_0x40db05);}['updateFullNode'](_0x4f5dfc,_0x4d77d1,_0x3e7b6f){_0x4d77d1['isLeafNode']()&&(_0x4d77d1=g['EMPTY_NODE']);let _0x34359b=_0x4d77d1['withIndex'](this['index_']);_0x34359b=_0x34359b['updatePriority'](g['EMPTY_NODE']);const _0x2ea2f5=this;return _0x4d77d1['forEachChild'](R,(_0x874180,_0x3fed06)=>{_0x2ea2f5['matches'](new E(_0x874180,_0x3fed06))||(_0x34359b=_0x34359b['updateImmediateChild'](_0x874180,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4f5dfc,_0x34359b,_0x3e7b6f);}['updatePriority'](_0xa0e2,_0xf39b04){return _0xa0e2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1d4b1e){if(_0x1d4b1e['hasStart']()){const _0x1ef4c1=_0x1d4b1e['getIndexStartName']();return _0x1d4b1e['getIndex']()['makePost'](_0x1d4b1e['getIndexStartValue'](),_0x1ef4c1);}else return _0x1d4b1e['getIndex']()['minPost']();}static['getEndPost_'](_0x12c565){if(_0x12c565['hasEnd']()){const _0x309240=_0x12c565['getIndexEndName']();return _0x12c565['getIndex']()['makePost'](_0x12c565['getIndexEndValue'](),_0x309240);}else return _0x12c565['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0xd8abd8){this['withinDirectionalStart']=_0x5386fc=>this['reverse_']?this['withinEndPost'](_0x5386fc):this['withinStartPost'](_0x5386fc),this['withinDirectionalEnd']=_0x48ce81=>this['reverse_']?this['withinStartPost'](_0x48ce81):this['withinEndPost'](_0x48ce81),this['withinStartPost']=_0x5d90b7=>{const _0x29c443=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5d90b7);return this['startIsInclusive_']?_0x29c443<=0x0:_0x29c443<0x0;},this['withinEndPost']=_0x533f4d=>{const _0x136118=this['index_']['compare'](_0x533f4d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x136118<=0x0:_0x136118<0x0;},this['rangedFilter_']=new Ft(_0xd8abd8),this['index_']=_0xd8abd8['getIndex'](),this['limit_']=_0xd8abd8['getLimit'](),this['reverse_']=!_0xd8abd8['isViewFromLeft'](),this['startIsInclusive_']=!_0xd8abd8['startAfterSet_'],this['endIsInclusive_']=!_0xd8abd8['endBeforeSet_'];}['updateChild'](_0x1d2848,_0x2c51d7,_0x19a119,_0x361a77,_0x2303eb,_0x203926){return this['rangedFilter_']['matches'](new E(_0x2c51d7,_0x19a119))||(_0x19a119=g['EMPTY_NODE']),_0x1d2848['getImmediateChild'](_0x2c51d7)['equals'](_0x19a119)?_0x1d2848:_0x1d2848['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1d2848,_0x2c51d7,_0x19a119,_0x361a77,_0x2303eb,_0x203926):this['fullLimitUpdateChild_'](_0x1d2848,_0x2c51d7,_0x19a119,_0x2303eb,_0x203926);}['updateFullNode'](_0x55f561,_0x5dbe93,_0x30827a){let _0x223b7b;if(_0x5dbe93['isLeafNode']()||_0x5dbe93['isEmpty']())_0x223b7b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5dbe93['numChildren']()&&_0x5dbe93['isIndexed'](this['index_'])){_0x223b7b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x289eca;this['reverse_']?_0x289eca=_0x5dbe93['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x289eca=_0x5dbe93['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3f44a6=0x0;for(;_0x289eca['hasNext']()&&_0x3f44a6<this['limit_'];){const _0x215e4d=_0x289eca['getNext']();if(this['withinDirectionalStart'](_0x215e4d)){if(this['withinDirectionalEnd'](_0x215e4d))_0x223b7b=_0x223b7b['updateImmediateChild'](_0x215e4d['name'],_0x215e4d['node']),_0x3f44a6++;else break;}else continue;}}else{_0x223b7b=_0x5dbe93['withIndex'](this['index_']),_0x223b7b=_0x223b7b['updatePriority'](g['EMPTY_NODE']);let _0x52a07d;this['reverse_']?_0x52a07d=_0x223b7b['getReverseIterator'](this['index_']):_0x52a07d=_0x223b7b['getIterator'](this['index_']);let _0x124ded=0x0;for(;_0x52a07d['hasNext']();){const _0x19478d=_0x52a07d['getNext']();_0x124ded<this['limit_']&&this['withinDirectionalStart'](_0x19478d)&&this['withinDirectionalEnd'](_0x19478d)?_0x124ded++:_0x223b7b=_0x223b7b['updateImmediateChild'](_0x19478d['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x55f561,_0x223b7b,_0x30827a);}['updatePriority'](_0x247e96,_0x52c06f){return _0x247e96;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x291972,_0x4a8899,_0x48828b,_0x5e9e1a,_0x3fc7e2){let _0x137d14;if(this['reverse_']){const _0x19d448=this['index_']['getCompare']();_0x137d14=(_0x1eea2f,_0x5e957e)=>_0x19d448(_0x5e957e,_0x1eea2f);}else _0x137d14=this['index_']['getCompare']();const _0x4ad624=_0x291972;f(_0x4ad624['numChildren']()===this['limit_'],'');const _0xd928d2=new E(_0x4a8899,_0x48828b),_0x4baa93=this['reverse_']?_0x4ad624['getFirstChild'](this['index_']):_0x4ad624['getLastChild'](this['index_']),_0x2d834d=this['rangedFilter_']['matches'](_0xd928d2);if(_0x4ad624['hasChild'](_0x4a8899)){const _0x396171=_0x4ad624['getImmediateChild'](_0x4a8899);let _0x5c37c8=_0x5e9e1a['getChildAfterChild'](this['index_'],_0x4baa93,this['reverse_']);for(;_0x5c37c8!=null&&(_0x5c37c8['name']===_0x4a8899||_0x4ad624['hasChild'](_0x5c37c8['name']));)_0x5c37c8=_0x5e9e1a['getChildAfterChild'](this['index_'],_0x5c37c8,this['reverse_']);const _0x104bc9=_0x5c37c8==null?0x1:_0x137d14(_0x5c37c8,_0xd928d2);if(_0x2d834d&&!_0x48828b['isEmpty']()&&_0x104bc9>=0x0)return _0x3fc7e2!=null&&_0x3fc7e2['trackChildChange'](xt(_0x4a8899,_0x48828b,_0x396171)),_0x4ad624['updateImmediateChild'](_0x4a8899,_0x48828b);{_0x3fc7e2!=null&&_0x3fc7e2['trackChildChange'](Lt(_0x4a8899,_0x396171));const _0x5067c9=_0x4ad624['updateImmediateChild'](_0x4a8899,g['EMPTY_NODE']);return _0x5c37c8!=null&&this['rangedFilter_']['matches'](_0x5c37c8)?(_0x3fc7e2!=null&&_0x3fc7e2['trackChildChange'](rt(_0x5c37c8['name'],_0x5c37c8['node'])),_0x5067c9['updateImmediateChild'](_0x5c37c8['name'],_0x5c37c8['node'])):_0x5067c9;}}else return _0x48828b['isEmpty']()?_0x291972:_0x2d834d&&_0x137d14(_0x4baa93,_0xd928d2)>=0x0?(_0x3fc7e2!=null&&(_0x3fc7e2['trackChildChange'](Lt(_0x4baa93['name'],_0x4baa93['node'])),_0x3fc7e2['trackChildChange'](rt(_0x4a8899,_0x48828b))),_0x4ad624['updateImmediateChild'](_0x4a8899,_0x48828b)['updateImmediateChild'](_0x4baa93['name'],g['EMPTY_NODE'])):_0x291972;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4a0a68=new Zi();return _0x4a0a68['limitSet_']=this['limitSet_'],_0x4a0a68['limit_']=this['limit_'],_0x4a0a68['startSet_']=this['startSet_'],_0x4a0a68['startAfterSet_']=this['startAfterSet_'],_0x4a0a68['indexStartValue_']=this['indexStartValue_'],_0x4a0a68['startNameSet_']=this['startNameSet_'],_0x4a0a68['indexStartName_']=this['indexStartName_'],_0x4a0a68['endSet_']=this['endSet_'],_0x4a0a68['endBeforeSet_']=this['endBeforeSet_'],_0x4a0a68['indexEndValue_']=this['indexEndValue_'],_0x4a0a68['endNameSet_']=this['endNameSet_'],_0x4a0a68['indexEndName_']=this['indexEndName_'],_0x4a0a68['index_']=this['index_'],_0x4a0a68['viewFrom_']=this['viewFrom_'],_0x4a0a68;}}function Kh(_0x202c60){return _0x202c60['loadsAllData']()?new Xi(_0x202c60['getIndex']()):_0x202c60['hasLimit']()?new jh(_0x202c60):new Ft(_0x202c60);}function Yh(_0x57ffd5,_0x28fb96){const _0xb81064=_0x57ffd5['copy']();return _0xb81064['limitSet_']=!0x0,_0xb81064['limit_']=_0x28fb96,_0xb81064['viewFrom_']='l',_0xb81064;}function Qh(_0x2955f0,_0x3237c6,_0x3c0def){const _0x980b93=_0x2955f0['copy']();return _0x980b93['startSet_']=!0x0,_0x3237c6===void 0x0&&(_0x3237c6=null),_0x980b93['indexStartValue_']=_0x3237c6,_0x3c0def!=null?(_0x980b93['startNameSet_']=!0x0,_0x980b93['indexStartName_']=_0x3c0def):(_0x980b93['startNameSet_']=!0x1,_0x980b93['indexStartName_']=''),_0x980b93;}function Jh(_0x280e96,_0x52f48f,_0x3b0153){const _0x308ce9=_0x280e96['copy']();return _0x308ce9['endSet_']=!0x0,_0x52f48f===void 0x0&&(_0x52f48f=null),_0x308ce9['indexEndValue_']=_0x52f48f,_0x3b0153!==void 0x0?(_0x308ce9['endNameSet_']=!0x0,_0x308ce9['indexEndName_']=_0x3b0153):(_0x308ce9['endNameSet_']=!0x1,_0x308ce9['indexEndName_']=''),_0x308ce9;}function xo(_0x3bf001,_0x5342ef){const _0x3e8fdc=_0x3bf001['copy']();return _0x3e8fdc['index_']=_0x5342ef,_0x3e8fdc;}function ir(_0x17272e){const _0x45b206={};if(_0x17272e['isDefault']())return _0x45b206;let _0x74857c;if(_0x17272e['index_']===R?_0x74857c='$priority':_0x17272e['index_']===Mo?_0x74857c='$value':_0x17272e['index_']===ve?_0x74857c='$key':(f(_0x17272e['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x74857c=_0x17272e['index_']['toString']()),_0x45b206['orderBy']=O(_0x74857c),_0x17272e['startSet_']){const _0x4aaee9=_0x17272e['startAfterSet_']?'startAfter':'startAt';_0x45b206[_0x4aaee9]=O(_0x17272e['indexStartValue_']),_0x17272e['startNameSet_']&&(_0x45b206[_0x4aaee9]+=','+O(_0x17272e['indexStartName_']));}if(_0x17272e['endSet_']){const _0x363171=_0x17272e['endBeforeSet_']?'endBefore':'endAt';_0x45b206[_0x363171]=O(_0x17272e['indexEndValue_']),_0x17272e['endNameSet_']&&(_0x45b206[_0x363171]+=','+O(_0x17272e['indexEndName_']));}return _0x17272e['limitSet_']&&(_0x17272e['isViewFromLeft']()?_0x45b206['limitToFirst']=_0x17272e['limit_']:_0x45b206['limitToLast']=_0x17272e['limit_']),_0x45b206;}function sr(_0x60e3b1){const _0x1b20c0={};if(_0x60e3b1['startSet_']&&(_0x1b20c0['sp']=_0x60e3b1['indexStartValue_'],_0x60e3b1['startNameSet_']&&(_0x1b20c0['sn']=_0x60e3b1['indexStartName_']),_0x1b20c0['sin']=!_0x60e3b1['startAfterSet_']),_0x60e3b1['endSet_']&&(_0x1b20c0['ep']=_0x60e3b1['indexEndValue_'],_0x60e3b1['endNameSet_']&&(_0x1b20c0['en']=_0x60e3b1['indexEndName_']),_0x1b20c0['ein']=!_0x60e3b1['endBeforeSet_']),_0x60e3b1['limitSet_']){_0x1b20c0['l']=_0x60e3b1['limit_'];let _0x4c1f23=_0x60e3b1['viewFrom_'];_0x4c1f23===''&&(_0x60e3b1['isViewFromLeft']()?_0x4c1f23='l':_0x4c1f23='r'),_0x1b20c0['vf']=_0x4c1f23;}return _0x60e3b1['index_']!==R&&(_0x1b20c0['i']=_0x60e3b1['index_']['toString']()),_0x1b20c0;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x210353){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x24b017,_0x5e6f96){return _0x5e6f96!==void 0x0?'tag$'+_0x5e6f96:(f(_0x24b017['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x24b017['_path']['toString']());}constructor(_0x40ada8,_0x341948,_0x4f82e7,_0x4527b5){super(),this['repoInfo_']=_0x40ada8,this['onDataUpdate_']=_0x341948,this['authTokenProvider_']=_0x4f82e7,this['appCheckTokenProvider_']=_0x4527b5,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x32d97a,_0x5f5138,_0x71151d,_0x1c9f35){const _0x872ec1=_0x32d97a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x872ec1+'\x20'+_0x32d97a['_queryIdentifier']);const _0x5024dd=vn['getListenId_'](_0x32d97a,_0x71151d),_0x4baea3={};this['listens_'][_0x5024dd]=_0x4baea3;const _0x24edd8=ir(_0x32d97a['_queryParams']);this['restRequest_'](_0x872ec1+'.json',_0x24edd8,(_0x1b78ea,_0x51e8e2)=>{let _0x55600b=_0x51e8e2;if(_0x1b78ea===0x194&&(_0x55600b=null,_0x1b78ea=null),_0x1b78ea===null&&this['onDataUpdate_'](_0x872ec1,_0x55600b,!0x1,_0x71151d),Le(this['listens_'],_0x5024dd)===_0x4baea3){let _0x5df5ab;_0x1b78ea?_0x1b78ea===0x191?_0x5df5ab='permission_denied':_0x5df5ab='rest_error:'+_0x1b78ea:_0x5df5ab='ok',_0x1c9f35(_0x5df5ab,null);}});}['unlisten'](_0x568b18,_0x52b66c){const _0x2b8b5e=vn['getListenId_'](_0x568b18,_0x52b66c);delete this['listens_'][_0x2b8b5e];}['get'](_0x202cfc){const _0x52fc69=ir(_0x202cfc['_queryParams']),_0xeefecd=_0x202cfc['_path']['toString'](),_0x5603af=new H();return this['restRequest_'](_0xeefecd+'.json',_0x52fc69,(_0x2c47b9,_0x468bd9)=>{let _0x5c6bbe=_0x468bd9;_0x2c47b9===0x194&&(_0x5c6bbe=null,_0x2c47b9=null),_0x2c47b9===null?(this['onDataUpdate_'](_0xeefecd,_0x5c6bbe,!0x1,null),_0x5603af['resolve'](_0x5c6bbe)):_0x5603af['reject'](new Error(_0x5c6bbe));}),_0x5603af['promise'];}['refreshAuthToken'](_0x1de637){}['restRequest_'](_0x394abe,_0x3b1cdf={},_0x4a6200){return _0x3b1cdf['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5631f6,_0x181396])=>{_0x5631f6&&_0x5631f6['accessToken']&&(_0x3b1cdf['auth']=_0x5631f6['accessToken']),_0x181396&&_0x181396['token']&&(_0x3b1cdf['ac']=_0x181396['token']);const _0x4e0fb7=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x394abe+'?ns='+this['repoInfo_']['namespace']+ut(_0x3b1cdf);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4e0fb7);const _0x51b004=new XMLHttpRequest();_0x51b004['onreadystatechange']=()=>{if(_0x4a6200&&_0x51b004['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4e0fb7+'\x20received.\x20status:',_0x51b004['status'],'response:',_0x51b004['responseText']);let _0x2ebb6a=null;if(_0x51b004['status']>=0xc8&&_0x51b004['status']<0x12c){try{_0x2ebb6a=Nt(_0x51b004['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4e0fb7+':\x20'+_0x51b004['responseText']);}_0x4a6200(null,_0x2ebb6a);}else _0x51b004['status']!==0x191&&_0x51b004['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4e0fb7+'\x20Status:\x20'+_0x51b004['status']),_0x4a6200(_0x51b004['status']);_0x4a6200=null;}},_0x51b004['open']('GET',_0x4e0fb7,!0x0),_0x51b004['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x452c18){return this['rootNode_']['getChild'](_0x452c18);}['updateSnapshot'](_0x5218fa,_0x237a0d){this['rootNode_']=this['rootNode_']['updateChild'](_0x5218fa,_0x237a0d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x47a214,_0x5971a7,_0x2fe38d){if(v(_0x5971a7))_0x47a214['value']=_0x2fe38d,_0x47a214['children']['clear']();else{if(_0x47a214['value']!==null)_0x47a214['value']=_0x47a214['value']['updateChild'](_0x5971a7,_0x2fe38d);else{const _0x1f057b=y(_0x5971a7);_0x47a214['children']['has'](_0x1f057b)||_0x47a214['children']['set'](_0x1f057b,En());const _0x1fad10=_0x47a214['children']['get'](_0x1f057b);_0x5971a7=S(_0x5971a7),pt(_0x1fad10,_0x5971a7,_0x2fe38d);}}}function Ti(_0x5df30b,_0x55937e){if(v(_0x55937e))return _0x5df30b['value']=null,_0x5df30b['children']['clear'](),!0x0;if(_0x5df30b['value']!==null){if(_0x5df30b['value']['isLeafNode']())return!0x1;{const _0x39f944=_0x5df30b['value'];return _0x5df30b['value']=null,_0x39f944['forEachChild'](R,(_0xb6162c,_0x33fba4)=>{pt(_0x5df30b,new C(_0xb6162c),_0x33fba4);}),Ti(_0x5df30b,_0x55937e);}}else{if(_0x5df30b['children']['size']>0x0){const _0x3244bb=y(_0x55937e);return _0x55937e=S(_0x55937e),_0x5df30b['children']['has'](_0x3244bb)&&Ti(_0x5df30b['children']['get'](_0x3244bb),_0x55937e)&&_0x5df30b['children']['delete'](_0x3244bb),_0x5df30b['children']['size']===0x0;}else return!0x0;}}function Si(_0x353cd8,_0x13040d,_0x2630e1){_0x353cd8['value']!==null?_0x2630e1(_0x13040d,_0x353cd8['value']):Zh(_0x353cd8,(_0x45f71e,_0x141215)=>{const _0x262738=new C(_0x13040d['toString']()+'/'+_0x45f71e);Si(_0x141215,_0x262738,_0x2630e1);});}function Zh(_0x28bbcf,_0xc53194){_0x28bbcf['children']['forEach']((_0xa52f1e,_0x542ad4)=>{_0xc53194(_0x542ad4,_0xa52f1e);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x41388e){this['collection_']=_0x41388e,this['last_']=null;}['get'](){const _0x57cfef=this['collection_']['get'](),_0x2d492e={..._0x57cfef};return this['last_']&&x(this['last_'],(_0x1b7941,_0x17c587)=>{_0x2d492e[_0x1b7941]=_0x2d492e[_0x1b7941]-_0x17c587;}),this['last_']=_0x57cfef,_0x2d492e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x33b8bd,_0x45791c){this['server_']=_0x45791c,this['statsToReport_']={},this['statsListener_']=new eu(_0x33b8bd);const _0x3a87d1=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3a87d1));}['reportStats_'](){const _0xa56ebf=this['statsListener_']['get'](),_0x1c4b44={};let _0x2ec294=!0x1;x(_0xa56ebf,(_0x5896f4,_0x2e8ce1)=>{_0x2e8ce1>0x0&&Q(this['statsToReport_'],_0x5896f4)&&(_0x1c4b44[_0x5896f4]=_0x2e8ce1,_0x2ec294=!0x0);}),_0x2ec294&&this['server_']['reportStats'](_0x1c4b44),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x3f851b){_0x3f851b[_0x3f851b['OVERWRITE']=0x0]='OVERWRITE',_0x3f851b[_0x3f851b['MERGE']=0x1]='MERGE',_0x3f851b[_0x3f851b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3f851b[_0x3f851b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x506d9a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x506d9a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5a7494,_0xe43017,_0x1e3a11){this['path']=_0x5a7494,this['affectedTree']=_0xe43017,this['revert']=_0x1e3a11,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0xf6c57f){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x57312f=this['affectedTree']['subtree'](new C(_0xf6c57f));return new In(w(),_0x57312f,this['revert']);}}else return f(y(this['path'])===_0xf6c57f,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x2ff5fb,_0x482a08){this['source']=_0x2ff5fb,this['path']=_0x482a08,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4336d1){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3aa130,_0x28c157,_0x2789e4){this['source']=_0x3aa130,this['path']=_0x28c157,this['snap']=_0x2789e4,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3736b4){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3736b4)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4b7867,_0x46d5a9,_0x12de4e){this['source']=_0x4b7867,this['path']=_0x46d5a9,this['children']=_0x12de4e,this['type']=z['MERGE'];}['operationForChild'](_0x4a9ae7){if(v(this['path'])){const _0x2c34db=this['children']['subtree'](new C(_0x4a9ae7));return _0x2c34db['isEmpty']()?null:_0x2c34db['value']?new Be(this['source'],w(),_0x2c34db['value']):new ot(this['source'],w(),_0x2c34db);}else return f(y(this['path'])===_0x4a9ae7,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x4a92bb,_0x58a543,_0x5f0146){this['node_']=_0x4a92bb,this['fullyInitialized_']=_0x58a543,this['filtered_']=_0x5f0146;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4347cb){if(v(_0x4347cb))return this['isFullyInitialized']()&&!this['filtered_'];const _0x55303a=y(_0x4347cb);return this['isCompleteForChild'](_0x55303a);}['isCompleteForChild'](_0x230bd3){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x230bd3);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x5b0b5a){this['query_']=_0x5b0b5a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x394b65,_0x469229,_0x94d775,_0x1d7138){const _0x57c5e1=[],_0x445124=[];return _0x469229['forEach'](_0x5de0b8=>{_0x5de0b8['type']==='child_changed'&&_0x394b65['index_']['indexedValueChanged'](_0x5de0b8['oldSnap'],_0x5de0b8['snapshotNode'])&&_0x445124['push'](zh(_0x5de0b8['childName'],_0x5de0b8['snapshotNode']));}),wt(_0x394b65,_0x57c5e1,'child_removed',_0x469229,_0x1d7138,_0x94d775),wt(_0x394b65,_0x57c5e1,'child_added',_0x469229,_0x1d7138,_0x94d775),wt(_0x394b65,_0x57c5e1,'child_moved',_0x445124,_0x1d7138,_0x94d775),wt(_0x394b65,_0x57c5e1,'child_changed',_0x469229,_0x1d7138,_0x94d775),wt(_0x394b65,_0x57c5e1,'value',_0x469229,_0x1d7138,_0x94d775),_0x57c5e1;}function wt(_0x38ef39,_0x4babab,_0x5dcf44,_0x32ea22,_0x2f1341,_0x148861){const _0x35b676=_0x32ea22['filter'](_0x14773e=>_0x14773e['type']===_0x5dcf44);_0x35b676['sort']((_0x2ccdf1,_0x294a54)=>au(_0x38ef39,_0x2ccdf1,_0x294a54)),_0x35b676['forEach'](_0x4b2236=>{const _0x323725=ou(_0x38ef39,_0x4b2236,_0x148861);_0x2f1341['forEach'](_0x12c65a=>{_0x12c65a['respondsTo'](_0x4b2236['type'])&&_0x4babab['push'](_0x12c65a['createEvent'](_0x323725,_0x38ef39['query_']));});});}function ou(_0xca9399,_0x55d1ff,_0x28d48e){return _0x55d1ff['type']==='value'||_0x55d1ff['type']==='child_removed'||(_0x55d1ff['prevName']=_0x28d48e['getPredecessorChildName'](_0x55d1ff['childName'],_0x55d1ff['snapshotNode'],_0xca9399['index_'])),_0x55d1ff;}function au(_0x505db0,_0x45e361,_0x1198bc){if(_0x45e361['childName']==null||_0x1198bc['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1d0f68=new E(_0x45e361['childName'],_0x45e361['snapshotNode']),_0x14b2b3=new E(_0x1198bc['childName'],_0x1198bc['snapshotNode']);return _0x505db0['index_']['compare'](_0x1d0f68,_0x14b2b3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x5384bc,_0x2893fd){return{'eventCache':_0x5384bc,'serverCache':_0x2893fd};}function Rt(_0x397804,_0xbdaf56,_0x166f38,_0x446eec){return Un(new Te(_0xbdaf56,_0x166f38,_0x446eec),_0x397804['serverCache']);}function Fo(_0x5e4bba,_0x184659,_0x386593,_0x1d94a4){return Un(_0x5e4bba['eventCache'],new Te(_0x184659,_0x386593,_0x1d94a4));}function wn(_0x59421e){return _0x59421e['eventCache']['isFullyInitialized']()?_0x59421e['eventCache']['getNode']():null;}function Ve(_0x4f3100){return _0x4f3100['serverCache']['isFullyInitialized']()?_0x4f3100['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x9d8974){let _0x137eb6=new b(null);return x(_0x9d8974,(_0x34b689,_0x2ecd4b)=>{_0x137eb6=_0x137eb6['set'](new C(_0x34b689),_0x2ecd4b);}),_0x137eb6;}constructor(_0x156aea,_0x27c140=cu()){this['value']=_0x156aea,this['children']=_0x27c140;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1d3e6b,_0x3eea8b){if(this['value']!=null&&_0x3eea8b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1d3e6b))return null;{const _0x56a836=y(_0x1d3e6b),_0x20ce6f=this['children']['get'](_0x56a836);if(_0x20ce6f!==null){const _0x1ad245=_0x20ce6f['findRootMostMatchingPathAndValue'](S(_0x1d3e6b),_0x3eea8b);return _0x1ad245!=null?{'path':k(new C(_0x56a836),_0x1ad245['path']),'value':_0x1ad245['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x554f66){return this['findRootMostMatchingPathAndValue'](_0x554f66,()=>!0x0);}['subtree'](_0x128115){if(v(_0x128115))return this;{const _0x44ace3=y(_0x128115),_0xb41828=this['children']['get'](_0x44ace3);return _0xb41828!==null?_0xb41828['subtree'](S(_0x128115)):new b(null);}}['set'](_0xfc5b61,_0x2bd799){if(v(_0xfc5b61))return new b(_0x2bd799,this['children']);{const _0x68badd=y(_0xfc5b61),_0x3863aa=(this['children']['get'](_0x68badd)||new b(null))['set'](S(_0xfc5b61),_0x2bd799),_0x43aab4=this['children']['insert'](_0x68badd,_0x3863aa);return new b(this['value'],_0x43aab4);}}['remove'](_0x2a627d){if(v(_0x2a627d))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x181f3d=y(_0x2a627d),_0x23c3ad=this['children']['get'](_0x181f3d);if(_0x23c3ad){const _0x3b74a7=_0x23c3ad['remove'](S(_0x2a627d));let _0x85c43;return _0x3b74a7['isEmpty']()?_0x85c43=this['children']['remove'](_0x181f3d):_0x85c43=this['children']['insert'](_0x181f3d,_0x3b74a7),this['value']===null&&_0x85c43['isEmpty']()?new b(null):new b(this['value'],_0x85c43);}else return this;}}['get'](_0x265c7b){if(v(_0x265c7b))return this['value'];{const _0xcfd5b0=y(_0x265c7b),_0x117d74=this['children']['get'](_0xcfd5b0);return _0x117d74?_0x117d74['get'](S(_0x265c7b)):null;}}['setTree'](_0x1ac48c,_0x39297d){if(v(_0x1ac48c))return _0x39297d;{const _0x2ca6ba=y(_0x1ac48c),_0x45527a=(this['children']['get'](_0x2ca6ba)||new b(null))['setTree'](S(_0x1ac48c),_0x39297d);let _0x28b211;return _0x45527a['isEmpty']()?_0x28b211=this['children']['remove'](_0x2ca6ba):_0x28b211=this['children']['insert'](_0x2ca6ba,_0x45527a),new b(this['value'],_0x28b211);}}['fold'](_0x1c1903){return this['fold_'](w(),_0x1c1903);}['fold_'](_0x3d9a79,_0x20e2c6){const _0xde4a24={};return this['children']['inorderTraversal']((_0x2c0633,_0x21b60c)=>{_0xde4a24[_0x2c0633]=_0x21b60c['fold_'](k(_0x3d9a79,_0x2c0633),_0x20e2c6);}),_0x20e2c6(_0x3d9a79,this['value'],_0xde4a24);}['findOnPath'](_0x1446c3,_0x589cd1){return this['findOnPath_'](_0x1446c3,w(),_0x589cd1);}['findOnPath_'](_0x4314e0,_0x4000a4,_0x46c85f){const _0xb00e50=this['value']?_0x46c85f(_0x4000a4,this['value']):!0x1;if(_0xb00e50)return _0xb00e50;if(v(_0x4314e0))return null;{const _0x105d1d=y(_0x4314e0),_0x4ab086=this['children']['get'](_0x105d1d);return _0x4ab086?_0x4ab086['findOnPath_'](S(_0x4314e0),k(_0x4000a4,_0x105d1d),_0x46c85f):null;}}['foreachOnPath'](_0x4f932a,_0x42edb0){return this['foreachOnPath_'](_0x4f932a,w(),_0x42edb0);}['foreachOnPath_'](_0x55a93b,_0x5d2f66,_0x4c02b1){if(v(_0x55a93b))return this;{this['value']&&_0x4c02b1(_0x5d2f66,this['value']);const _0xa0ab5c=y(_0x55a93b),_0x4ba388=this['children']['get'](_0xa0ab5c);return _0x4ba388?_0x4ba388['foreachOnPath_'](S(_0x55a93b),k(_0x5d2f66,_0xa0ab5c),_0x4c02b1):new b(null);}}['foreach'](_0x27b4bf){this['foreach_'](w(),_0x27b4bf);}['foreach_'](_0x1199fe,_0x332967){this['children']['inorderTraversal']((_0x12e22f,_0x276868)=>{_0x276868['foreach_'](k(_0x1199fe,_0x12e22f),_0x332967);}),this['value']&&_0x332967(_0x1199fe,this['value']);}['foreachChild'](_0x155942){this['children']['inorderTraversal']((_0x1e5e12,_0x1d8ad5)=>{_0x1d8ad5['value']&&_0x155942(_0x1e5e12,_0x1d8ad5['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x42d054){this['writeTree_']=_0x42d054;}static['empty'](){return new K(new b(null));}}function At(_0x83b551,_0x11a95e,_0x2faae5){if(v(_0x11a95e))return new K(new b(_0x2faae5));{const _0x1a1215=_0x83b551['writeTree_']['findRootMostValueAndPath'](_0x11a95e);if(_0x1a1215!=null){const _0x1a1477=_0x1a1215['path'];let _0x4207d1=_0x1a1215['value'];const _0x113f08=F(_0x1a1477,_0x11a95e);return _0x4207d1=_0x4207d1['updateChild'](_0x113f08,_0x2faae5),new K(_0x83b551['writeTree_']['set'](_0x1a1477,_0x4207d1));}else{const _0x4022ff=new b(_0x2faae5),_0x10e67e=_0x83b551['writeTree_']['setTree'](_0x11a95e,_0x4022ff);return new K(_0x10e67e);}}}function bi(_0x34ebb1,_0x14ca08,_0x474fcf){let _0x27038c=_0x34ebb1;return x(_0x474fcf,(_0xe7d731,_0x32f258)=>{_0x27038c=At(_0x27038c,k(_0x14ca08,_0xe7d731),_0x32f258);}),_0x27038c;}function or(_0x44b302,_0xf48a23){if(v(_0xf48a23))return K['empty']();{const _0x51f093=_0x44b302['writeTree_']['setTree'](_0xf48a23,new b(null));return new K(_0x51f093);}}function Ri(_0x1e3ed0,_0x4c2a25){return ze(_0x1e3ed0,_0x4c2a25)!=null;}function ze(_0x338b77,_0x2011a5){const _0x2efc36=_0x338b77['writeTree_']['findRootMostValueAndPath'](_0x2011a5);return _0x2efc36!=null?_0x338b77['writeTree_']['get'](_0x2efc36['path'])['getChild'](F(_0x2efc36['path'],_0x2011a5)):null;}function ar(_0x4f49aa){const _0x504fb6=[],_0x17d499=_0x4f49aa['writeTree_']['value'];return _0x17d499!=null?_0x17d499['isLeafNode']()||_0x17d499['forEachChild'](R,(_0x3c0eb9,_0x5e773f)=>{_0x504fb6['push'](new E(_0x3c0eb9,_0x5e773f));}):_0x4f49aa['writeTree_']['children']['inorderTraversal']((_0x3e494b,_0xa49c82)=>{_0xa49c82['value']!=null&&_0x504fb6['push'](new E(_0x3e494b,_0xa49c82['value']));}),_0x504fb6;}function Ee(_0x21af65,_0x572879){if(v(_0x572879))return _0x21af65;{const _0x1a4aa3=ze(_0x21af65,_0x572879);return _0x1a4aa3!=null?new K(new b(_0x1a4aa3)):new K(_0x21af65['writeTree_']['subtree'](_0x572879));}}function Ai(_0x19789f){return _0x19789f['writeTree_']['isEmpty']();}function at(_0x2cb9e0,_0x5e0f19){return Uo(w(),_0x2cb9e0['writeTree_'],_0x5e0f19);}function Uo(_0x47dbb6,_0x892b8a,_0x38c654){if(_0x892b8a['value']!=null)return _0x38c654['updateChild'](_0x47dbb6,_0x892b8a['value']);{let _0x47edcf=null;return _0x892b8a['children']['inorderTraversal']((_0x21c607,_0x30fb3e)=>{_0x21c607==='.priority'?(f(_0x30fb3e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x47edcf=_0x30fb3e['value']):_0x38c654=Uo(k(_0x47dbb6,_0x21c607),_0x30fb3e,_0x38c654);}),!_0x38c654['getChild'](_0x47dbb6)['isEmpty']()&&_0x47edcf!==null&&(_0x38c654=_0x38c654['updateChild'](k(_0x47dbb6,'.priority'),_0x47edcf)),_0x38c654;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x12e341,_0x108499){return Ho(_0x108499,_0x12e341);}function lu(_0x3c0624,_0x27dfcc,_0x2d74df,_0x3a8cce,_0x56b4de){f(_0x3a8cce>_0x3c0624['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x56b4de===void 0x0&&(_0x56b4de=!0x0),_0x3c0624['allWrites']['push']({'path':_0x27dfcc,'snap':_0x2d74df,'writeId':_0x3a8cce,'visible':_0x56b4de}),_0x56b4de&&(_0x3c0624['visibleWrites']=At(_0x3c0624['visibleWrites'],_0x27dfcc,_0x2d74df)),_0x3c0624['lastWriteId']=_0x3a8cce;}function hu(_0x26a9f1,_0x3e939e,_0x470d78,_0x39de1c){f(_0x39de1c>_0x26a9f1['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x26a9f1['allWrites']['push']({'path':_0x3e939e,'children':_0x470d78,'writeId':_0x39de1c,'visible':!0x0}),_0x26a9f1['visibleWrites']=bi(_0x26a9f1['visibleWrites'],_0x3e939e,_0x470d78),_0x26a9f1['lastWriteId']=_0x39de1c;}function uu(_0x4aa249,_0x24bd04){for(let _0xe11598=0x0;_0xe11598<_0x4aa249['allWrites']['length'];_0xe11598++){const _0x249ff6=_0x4aa249['allWrites'][_0xe11598];if(_0x249ff6['writeId']===_0x24bd04)return _0x249ff6;}return null;}function du(_0x324e19,_0x479463){const _0x5519ba=_0x324e19['allWrites']['findIndex'](_0x275d77=>_0x275d77['writeId']===_0x479463);f(_0x5519ba>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x66f3fd=_0x324e19['allWrites'][_0x5519ba];_0x324e19['allWrites']['splice'](_0x5519ba,0x1);let _0x15d6af=_0x66f3fd['visible'],_0x5e366f=!0x1,_0x126d17=_0x324e19['allWrites']['length']-0x1;for(;_0x15d6af&&_0x126d17>=0x0;){const _0x38d9f1=_0x324e19['allWrites'][_0x126d17];_0x38d9f1['visible']&&(_0x126d17>=_0x5519ba&&fu(_0x38d9f1,_0x66f3fd['path'])?_0x15d6af=!0x1:G(_0x66f3fd['path'],_0x38d9f1['path'])&&(_0x5e366f=!0x0)),_0x126d17--;}if(_0x15d6af){if(_0x5e366f)return pu(_0x324e19),!0x0;if(_0x66f3fd['snap'])_0x324e19['visibleWrites']=or(_0x324e19['visibleWrites'],_0x66f3fd['path']);else{const _0x8708da=_0x66f3fd['children'];x(_0x8708da,_0x397a7a=>{_0x324e19['visibleWrites']=or(_0x324e19['visibleWrites'],k(_0x66f3fd['path'],_0x397a7a));});}return!0x0;}else return!0x1;}function fu(_0x199a2a,_0x5d8cbc){if(_0x199a2a['snap'])return G(_0x199a2a['path'],_0x5d8cbc);for(const _0x25a48e in _0x199a2a['children'])if(_0x199a2a['children']['hasOwnProperty'](_0x25a48e)&&G(k(_0x199a2a['path'],_0x25a48e),_0x5d8cbc))return!0x0;return!0x1;}function pu(_0xbb6db){_0xbb6db['visibleWrites']=Wo(_0xbb6db['allWrites'],_u,w()),_0xbb6db['allWrites']['length']>0x0?_0xbb6db['lastWriteId']=_0xbb6db['allWrites'][_0xbb6db['allWrites']['length']-0x1]['writeId']:_0xbb6db['lastWriteId']=-0x1;}function _u(_0x5c53e1){return _0x5c53e1['visible'];}function Wo(_0x36d582,_0x13f7e0,_0x227c5a){let _0x5b97d2=K['empty']();for(let _0x5c0774=0x0;_0x5c0774<_0x36d582['length'];++_0x5c0774){const _0x2a6bef=_0x36d582[_0x5c0774];if(_0x13f7e0(_0x2a6bef)){const _0x2f7f05=_0x2a6bef['path'];let _0x51c05b;if(_0x2a6bef['snap'])G(_0x227c5a,_0x2f7f05)?(_0x51c05b=F(_0x227c5a,_0x2f7f05),_0x5b97d2=At(_0x5b97d2,_0x51c05b,_0x2a6bef['snap'])):G(_0x2f7f05,_0x227c5a)&&(_0x51c05b=F(_0x2f7f05,_0x227c5a),_0x5b97d2=At(_0x5b97d2,w(),_0x2a6bef['snap']['getChild'](_0x51c05b)));else{if(_0x2a6bef['children']){if(G(_0x227c5a,_0x2f7f05))_0x51c05b=F(_0x227c5a,_0x2f7f05),_0x5b97d2=bi(_0x5b97d2,_0x51c05b,_0x2a6bef['children']);else{if(G(_0x2f7f05,_0x227c5a)){if(_0x51c05b=F(_0x2f7f05,_0x227c5a),v(_0x51c05b))_0x5b97d2=bi(_0x5b97d2,w(),_0x2a6bef['children']);else{const _0x15b56e=Le(_0x2a6bef['children'],y(_0x51c05b));if(_0x15b56e){const _0x4d9dd3=_0x15b56e['getChild'](S(_0x51c05b));_0x5b97d2=At(_0x5b97d2,w(),_0x4d9dd3);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x5b97d2;}function Bo(_0x4d4d2b,_0x444a78,_0x4ef96c,_0x4b5f3e,_0x4d776e){if(!_0x4b5f3e&&!_0x4d776e){const _0x5b7803=ze(_0x4d4d2b['visibleWrites'],_0x444a78);if(_0x5b7803!=null)return _0x5b7803;{const _0x28f64e=Ee(_0x4d4d2b['visibleWrites'],_0x444a78);if(Ai(_0x28f64e))return _0x4ef96c;if(_0x4ef96c==null&&!Ri(_0x28f64e,w()))return null;{const _0x971c25=_0x4ef96c||g['EMPTY_NODE'];return at(_0x28f64e,_0x971c25);}}}else{const _0x477c04=Ee(_0x4d4d2b['visibleWrites'],_0x444a78);if(!_0x4d776e&&Ai(_0x477c04))return _0x4ef96c;if(!_0x4d776e&&_0x4ef96c==null&&!Ri(_0x477c04,w()))return null;{const _0xcadf6d=function(_0x20f4ed){return(_0x20f4ed['visible']||_0x4d776e)&&(!_0x4b5f3e||!~_0x4b5f3e['indexOf'](_0x20f4ed['writeId']))&&(G(_0x20f4ed['path'],_0x444a78)||G(_0x444a78,_0x20f4ed['path']));},_0x10d046=Wo(_0x4d4d2b['allWrites'],_0xcadf6d,_0x444a78),_0x482713=_0x4ef96c||g['EMPTY_NODE'];return at(_0x10d046,_0x482713);}}}function gu(_0x2b8781,_0x55d8b3,_0x105332){let _0x1904c3=g['EMPTY_NODE'];const _0x3f3ea9=ze(_0x2b8781['visibleWrites'],_0x55d8b3);if(_0x3f3ea9)return _0x3f3ea9['isLeafNode']()||_0x3f3ea9['forEachChild'](R,(_0x3a65ac,_0x1fa784)=>{_0x1904c3=_0x1904c3['updateImmediateChild'](_0x3a65ac,_0x1fa784);}),_0x1904c3;if(_0x105332){const _0x28f3b7=Ee(_0x2b8781['visibleWrites'],_0x55d8b3);return _0x105332['forEachChild'](R,(_0x3f5abd,_0x38fe27)=>{const _0x42744c=at(Ee(_0x28f3b7,new C(_0x3f5abd)),_0x38fe27);_0x1904c3=_0x1904c3['updateImmediateChild'](_0x3f5abd,_0x42744c);}),ar(_0x28f3b7)['forEach'](_0x2e87b2=>{_0x1904c3=_0x1904c3['updateImmediateChild'](_0x2e87b2['name'],_0x2e87b2['node']);}),_0x1904c3;}else{const _0x3f5e09=Ee(_0x2b8781['visibleWrites'],_0x55d8b3);return ar(_0x3f5e09)['forEach'](_0x450daf=>{_0x1904c3=_0x1904c3['updateImmediateChild'](_0x450daf['name'],_0x450daf['node']);}),_0x1904c3;}}function mu(_0x539432,_0x38131f,_0xef34f5,_0xb48052,_0x11141c){f(_0xb48052||_0x11141c,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x109e04=k(_0x38131f,_0xef34f5);if(Ri(_0x539432['visibleWrites'],_0x109e04))return null;{const _0x585aa6=Ee(_0x539432['visibleWrites'],_0x109e04);return Ai(_0x585aa6)?_0x11141c['getChild'](_0xef34f5):at(_0x585aa6,_0x11141c['getChild'](_0xef34f5));}}function yu(_0x342b9b,_0x5e9579,_0x4945be,_0x54b3a8){const _0x1448f6=k(_0x5e9579,_0x4945be),_0x104d73=ze(_0x342b9b['visibleWrites'],_0x1448f6);if(_0x104d73!=null)return _0x104d73;if(_0x54b3a8['isCompleteForChild'](_0x4945be)){const _0x34e9a0=Ee(_0x342b9b['visibleWrites'],_0x1448f6);return at(_0x34e9a0,_0x54b3a8['getNode']()['getImmediateChild'](_0x4945be));}else return null;}function vu(_0x26b816,_0x8f3c7f){return ze(_0x26b816['visibleWrites'],_0x8f3c7f);}function Eu(_0x12acd1,_0x375dfc,_0x2f5b78,_0x25b48a,_0x37a4e4,_0x19a069,_0x321e81){let _0x41f740;const _0x2be2e3=Ee(_0x12acd1['visibleWrites'],_0x375dfc),_0x5ddaa6=ze(_0x2be2e3,w());if(_0x5ddaa6!=null)_0x41f740=_0x5ddaa6;else{if(_0x2f5b78!=null)_0x41f740=at(_0x2be2e3,_0x2f5b78);else return[];}if(_0x41f740=_0x41f740['withIndex'](_0x321e81),!_0x41f740['isEmpty']()&&!_0x41f740['isLeafNode']()){const _0x45c539=[],_0x225571=_0x321e81['getCompare'](),_0x1b0b66=_0x19a069?_0x41f740['getReverseIteratorFrom'](_0x25b48a,_0x321e81):_0x41f740['getIteratorFrom'](_0x25b48a,_0x321e81);let _0x4bc762=_0x1b0b66['getNext']();for(;_0x4bc762&&_0x45c539['length']<_0x37a4e4;)_0x225571(_0x4bc762,_0x25b48a)!==0x0&&_0x45c539['push'](_0x4bc762),_0x4bc762=_0x1b0b66['getNext']();return _0x45c539;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x1fd388,_0xb59a0b,_0x3d2b93,_0x5e7e44){return Bo(_0x1fd388['writeTree'],_0x1fd388['treePath'],_0xb59a0b,_0x3d2b93,_0x5e7e44);}function is(_0x328c39,_0x7f3637){return gu(_0x328c39['writeTree'],_0x328c39['treePath'],_0x7f3637);}function cr(_0x5b83cd,_0x3b3fbf,_0x101fff,_0x137018){return mu(_0x5b83cd['writeTree'],_0x5b83cd['treePath'],_0x3b3fbf,_0x101fff,_0x137018);}function Tn(_0x37a26d,_0x57ef35){return vu(_0x37a26d['writeTree'],k(_0x37a26d['treePath'],_0x57ef35));}function wu(_0x2e73f8,_0x1e10b7,_0x3588de,_0x4ded92,_0x2a89f7,_0x5b3a17){return Eu(_0x2e73f8['writeTree'],_0x2e73f8['treePath'],_0x1e10b7,_0x3588de,_0x4ded92,_0x2a89f7,_0x5b3a17);}function ss(_0x4287aa,_0x469ba0,_0x294125){return yu(_0x4287aa['writeTree'],_0x4287aa['treePath'],_0x469ba0,_0x294125);}function Vo(_0x1a9bc3,_0x1cae6d){return Ho(k(_0x1a9bc3['treePath'],_0x1cae6d),_0x1a9bc3['writeTree']);}function Ho(_0x153f8d,_0x2d8d81){return{'treePath':_0x153f8d,'writeTree':_0x2d8d81};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xa98161){const _0x17aa8c=_0xa98161['type'],_0x35aca3=_0xa98161['childName'];f(_0x17aa8c==='child_added'||_0x17aa8c==='child_changed'||_0x17aa8c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x35aca3!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x48caff=this['changeMap']['get'](_0x35aca3);if(_0x48caff){const _0x59c5a6=_0x48caff['type'];if(_0x17aa8c==='child_added'&&_0x59c5a6==='child_removed')this['changeMap']['set'](_0x35aca3,xt(_0x35aca3,_0xa98161['snapshotNode'],_0x48caff['snapshotNode']));else{if(_0x17aa8c==='child_removed'&&_0x59c5a6==='child_added')this['changeMap']['delete'](_0x35aca3);else{if(_0x17aa8c==='child_removed'&&_0x59c5a6==='child_changed')this['changeMap']['set'](_0x35aca3,Lt(_0x35aca3,_0x48caff['oldSnap']));else{if(_0x17aa8c==='child_changed'&&_0x59c5a6==='child_added')this['changeMap']['set'](_0x35aca3,rt(_0x35aca3,_0xa98161['snapshotNode']));else{if(_0x17aa8c==='child_changed'&&_0x59c5a6==='child_changed')this['changeMap']['set'](_0x35aca3,xt(_0x35aca3,_0xa98161['snapshotNode'],_0x48caff['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0xa98161+'\x20occurred\x20after\x20'+_0x48caff);}}}}}else this['changeMap']['set'](_0x35aca3,_0xa98161);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x38fa03){return null;}['getChildAfterChild'](_0x155022,_0x14717f,_0x10689b){return null;}}const $o=new Tu();class rs{constructor(_0x53a2f7,_0x4879b6,_0x2a62d1=null){this['writes_']=_0x53a2f7,this['viewCache_']=_0x4879b6,this['optCompleteServerCache_']=_0x2a62d1;}['getCompleteChild'](_0x2b79a8){const _0x4da996=this['viewCache_']['eventCache'];if(_0x4da996['isCompleteForChild'](_0x2b79a8))return _0x4da996['getNode']()['getImmediateChild'](_0x2b79a8);{const _0x256b18=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2b79a8,_0x256b18);}}['getChildAfterChild'](_0x11e534,_0x51188e,_0x3dd9a9){const _0x33d591=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x4f9a24=wu(this['writes_'],_0x33d591,_0x51188e,0x1,_0x3dd9a9,_0x11e534);return _0x4f9a24['length']===0x0?null:_0x4f9a24[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2a4fc1){return{'filter':_0x2a4fc1};}function bu(_0x4759ab,_0x1e050f){f(_0x1e050f['eventCache']['getNode']()['isIndexed'](_0x4759ab['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1e050f['serverCache']['getNode']()['isIndexed'](_0x4759ab['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x17bf44,_0x288871,_0x359e19,_0x30eba8,_0x519a5c){const _0x607ae2=new Cu();let _0x47880b,_0x3444f5;if(_0x359e19['type']===z['OVERWRITE']){const _0x451064=_0x359e19;_0x451064['source']['fromUser']?_0x47880b=ki(_0x17bf44,_0x288871,_0x451064['path'],_0x451064['snap'],_0x30eba8,_0x519a5c,_0x607ae2):(f(_0x451064['source']['fromServer'],'Unknown\x20source.'),_0x3444f5=_0x451064['source']['tagged']||_0x288871['serverCache']['isFiltered']()&&!v(_0x451064['path']),_0x47880b=Sn(_0x17bf44,_0x288871,_0x451064['path'],_0x451064['snap'],_0x30eba8,_0x519a5c,_0x3444f5,_0x607ae2));}else{if(_0x359e19['type']===z['MERGE']){const _0x674ad=_0x359e19;_0x674ad['source']['fromUser']?_0x47880b=ku(_0x17bf44,_0x288871,_0x674ad['path'],_0x674ad['children'],_0x30eba8,_0x519a5c,_0x607ae2):(f(_0x674ad['source']['fromServer'],'Unknown\x20source.'),_0x3444f5=_0x674ad['source']['tagged']||_0x288871['serverCache']['isFiltered'](),_0x47880b=Pi(_0x17bf44,_0x288871,_0x674ad['path'],_0x674ad['children'],_0x30eba8,_0x519a5c,_0x3444f5,_0x607ae2));}else{if(_0x359e19['type']===z['ACK_USER_WRITE']){const _0x1cac85=_0x359e19;_0x1cac85['revert']?_0x47880b=Ou(_0x17bf44,_0x288871,_0x1cac85['path'],_0x30eba8,_0x519a5c,_0x607ae2):_0x47880b=Pu(_0x17bf44,_0x288871,_0x1cac85['path'],_0x1cac85['affectedTree'],_0x30eba8,_0x519a5c,_0x607ae2);}else{if(_0x359e19['type']===z['LISTEN_COMPLETE'])_0x47880b=Nu(_0x17bf44,_0x288871,_0x359e19['path'],_0x30eba8,_0x607ae2);else throw ht('Unknown\x20operation\x20type:\x20'+_0x359e19['type']);}}}const _0x4e3bf3=_0x607ae2['getChanges']();return Au(_0x288871,_0x47880b,_0x4e3bf3),{'viewCache':_0x47880b,'changes':_0x4e3bf3};}function Au(_0x2fbc0e,_0x58be97,_0xc3477d){const _0x17555b=_0x58be97['eventCache'];if(_0x17555b['isFullyInitialized']()){const _0x1995ed=_0x17555b['getNode']()['isLeafNode']()||_0x17555b['getNode']()['isEmpty'](),_0x20fd8e=wn(_0x2fbc0e);(_0xc3477d['length']>0x0||!_0x2fbc0e['eventCache']['isFullyInitialized']()||_0x1995ed&&!_0x17555b['getNode']()['equals'](_0x20fd8e)||!_0x17555b['getNode']()['getPriority']()['equals'](_0x20fd8e['getPriority']()))&&_0xc3477d['push'](Lo(wn(_0x58be97)));}}function Go(_0x20e5c7,_0x46277e,_0x45b28e,_0x3bd608,_0x3bf87c,_0x347de6){const _0x539d9e=_0x46277e['eventCache'];if(Tn(_0x3bd608,_0x45b28e)!=null)return _0x46277e;{let _0x2613d4,_0x518b74;if(v(_0x45b28e)){if(f(_0x46277e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x46277e['serverCache']['isFiltered']()){const _0x43a063=Ve(_0x46277e),_0x300c6d=_0x43a063 instanceof g?_0x43a063:g['EMPTY_NODE'],_0x250c2f=is(_0x3bd608,_0x300c6d);_0x2613d4=_0x20e5c7['filter']['updateFullNode'](_0x46277e['eventCache']['getNode'](),_0x250c2f,_0x347de6);}else{const _0x391408=Cn(_0x3bd608,Ve(_0x46277e));_0x2613d4=_0x20e5c7['filter']['updateFullNode'](_0x46277e['eventCache']['getNode'](),_0x391408,_0x347de6);}}else{const _0x493a0f=y(_0x45b28e);if(_0x493a0f==='.priority'){f(Ce(_0x45b28e)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1acb4c=_0x539d9e['getNode']();_0x518b74=_0x46277e['serverCache']['getNode']();const _0x382624=cr(_0x3bd608,_0x45b28e,_0x1acb4c,_0x518b74);_0x382624!=null?_0x2613d4=_0x20e5c7['filter']['updatePriority'](_0x1acb4c,_0x382624):_0x2613d4=_0x539d9e['getNode']();}else{const _0xab85f2=S(_0x45b28e);let _0x566d19;if(_0x539d9e['isCompleteForChild'](_0x493a0f)){_0x518b74=_0x46277e['serverCache']['getNode']();const _0x15343b=cr(_0x3bd608,_0x45b28e,_0x539d9e['getNode'](),_0x518b74);_0x15343b!=null?_0x566d19=_0x539d9e['getNode']()['getImmediateChild'](_0x493a0f)['updateChild'](_0xab85f2,_0x15343b):_0x566d19=_0x539d9e['getNode']()['getImmediateChild'](_0x493a0f);}else _0x566d19=ss(_0x3bd608,_0x493a0f,_0x46277e['serverCache']);_0x566d19!=null?_0x2613d4=_0x20e5c7['filter']['updateChild'](_0x539d9e['getNode'](),_0x493a0f,_0x566d19,_0xab85f2,_0x3bf87c,_0x347de6):_0x2613d4=_0x539d9e['getNode']();}}return Rt(_0x46277e,_0x2613d4,_0x539d9e['isFullyInitialized']()||v(_0x45b28e),_0x20e5c7['filter']['filtersNodes']());}}function Sn(_0x2a9a46,_0x3f9c4e,_0x2174a2,_0x43c584,_0x3d7762,_0xae5dac,_0x1c3d05,_0x41dbc1){const _0x21b5f5=_0x3f9c4e['serverCache'];let _0x20f191;const _0x505b59=_0x1c3d05?_0x2a9a46['filter']:_0x2a9a46['filter']['getIndexedFilter']();if(v(_0x2174a2))_0x20f191=_0x505b59['updateFullNode'](_0x21b5f5['getNode'](),_0x43c584,null);else{if(_0x505b59['filtersNodes']()&&!_0x21b5f5['isFiltered']()){const _0xd7dc9=_0x21b5f5['getNode']()['updateChild'](_0x2174a2,_0x43c584);_0x20f191=_0x505b59['updateFullNode'](_0x21b5f5['getNode'](),_0xd7dc9,null);}else{const _0xfa489c=y(_0x2174a2);if(!_0x21b5f5['isCompleteForPath'](_0x2174a2)&&Ce(_0x2174a2)>0x1)return _0x3f9c4e;const _0x308a05=S(_0x2174a2),_0x1eb83c=_0x21b5f5['getNode']()['getImmediateChild'](_0xfa489c)['updateChild'](_0x308a05,_0x43c584);_0xfa489c==='.priority'?_0x20f191=_0x505b59['updatePriority'](_0x21b5f5['getNode'](),_0x1eb83c):_0x20f191=_0x505b59['updateChild'](_0x21b5f5['getNode'](),_0xfa489c,_0x1eb83c,_0x308a05,$o,null);}}const _0x799e=Fo(_0x3f9c4e,_0x20f191,_0x21b5f5['isFullyInitialized']()||v(_0x2174a2),_0x505b59['filtersNodes']()),_0x54fea8=new rs(_0x3d7762,_0x799e,_0xae5dac);return Go(_0x2a9a46,_0x799e,_0x2174a2,_0x3d7762,_0x54fea8,_0x41dbc1);}function ki(_0x743697,_0xccb2e4,_0x10f503,_0x26f785,_0xbbb1ff,_0x336480,_0x120316){const _0x51281e=_0xccb2e4['eventCache'];let _0x345c3b,_0x4c79ce;const _0x5dab94=new rs(_0xbbb1ff,_0xccb2e4,_0x336480);if(v(_0x10f503))_0x4c79ce=_0x743697['filter']['updateFullNode'](_0xccb2e4['eventCache']['getNode'](),_0x26f785,_0x120316),_0x345c3b=Rt(_0xccb2e4,_0x4c79ce,!0x0,_0x743697['filter']['filtersNodes']());else{const _0x45a656=y(_0x10f503);if(_0x45a656==='.priority')_0x4c79ce=_0x743697['filter']['updatePriority'](_0xccb2e4['eventCache']['getNode'](),_0x26f785),_0x345c3b=Rt(_0xccb2e4,_0x4c79ce,_0x51281e['isFullyInitialized'](),_0x51281e['isFiltered']());else{const _0x390ec9=S(_0x10f503),_0x1a3b6e=_0x51281e['getNode']()['getImmediateChild'](_0x45a656);let _0x3c0d1c;if(v(_0x390ec9))_0x3c0d1c=_0x26f785;else{const _0x47393d=_0x5dab94['getCompleteChild'](_0x45a656);_0x47393d!=null?ji(_0x390ec9)==='.priority'&&_0x47393d['getChild'](Ro(_0x390ec9))['isEmpty']()?_0x3c0d1c=_0x47393d:_0x3c0d1c=_0x47393d['updateChild'](_0x390ec9,_0x26f785):_0x3c0d1c=g['EMPTY_NODE'];}if(_0x1a3b6e['equals'](_0x3c0d1c))_0x345c3b=_0xccb2e4;else{const _0x7957b6=_0x743697['filter']['updateChild'](_0x51281e['getNode'](),_0x45a656,_0x3c0d1c,_0x390ec9,_0x5dab94,_0x120316);_0x345c3b=Rt(_0xccb2e4,_0x7957b6,_0x51281e['isFullyInitialized'](),_0x743697['filter']['filtersNodes']());}}}return _0x345c3b;}function lr(_0x463701,_0x576312){return _0x463701['eventCache']['isCompleteForChild'](_0x576312);}function ku(_0x3552e8,_0x40058d,_0x48ee45,_0x1d1563,_0x1b1d2f,_0x45a778,_0x264b39){let _0x2bc090=_0x40058d;return _0x1d1563['foreach']((_0x5ae317,_0x3c3070)=>{const _0x55775d=k(_0x48ee45,_0x5ae317);lr(_0x40058d,y(_0x55775d))&&(_0x2bc090=ki(_0x3552e8,_0x2bc090,_0x55775d,_0x3c3070,_0x1b1d2f,_0x45a778,_0x264b39));}),_0x1d1563['foreach']((_0x5580af,_0x4fe0ee)=>{const _0x53c6b3=k(_0x48ee45,_0x5580af);lr(_0x40058d,y(_0x53c6b3))||(_0x2bc090=ki(_0x3552e8,_0x2bc090,_0x53c6b3,_0x4fe0ee,_0x1b1d2f,_0x45a778,_0x264b39));}),_0x2bc090;}function hr(_0x286e78,_0x45929b,_0x2bcc16){return _0x2bcc16['foreach']((_0x361ad3,_0x195a6d)=>{_0x45929b=_0x45929b['updateChild'](_0x361ad3,_0x195a6d);}),_0x45929b;}function Pi(_0x485995,_0x3b3214,_0x2ff4d8,_0x434005,_0x15b60f,_0x4d63b3,_0xecf2b4,_0x3dd8f4){if(_0x3b3214['serverCache']['getNode']()['isEmpty']()&&!_0x3b3214['serverCache']['isFullyInitialized']())return _0x3b3214;let _0x712f99=_0x3b3214,_0x3bfaa9;v(_0x2ff4d8)?_0x3bfaa9=_0x434005:_0x3bfaa9=new b(null)['setTree'](_0x2ff4d8,_0x434005);const _0x2bfea0=_0x3b3214['serverCache']['getNode']();return _0x3bfaa9['children']['inorderTraversal']((_0xb8a51d,_0x4fccfb)=>{if(_0x2bfea0['hasChild'](_0xb8a51d)){const _0xf5a386=_0x3b3214['serverCache']['getNode']()['getImmediateChild'](_0xb8a51d),_0x509881=hr(_0x485995,_0xf5a386,_0x4fccfb);_0x712f99=Sn(_0x485995,_0x712f99,new C(_0xb8a51d),_0x509881,_0x15b60f,_0x4d63b3,_0xecf2b4,_0x3dd8f4);}}),_0x3bfaa9['children']['inorderTraversal']((_0xc2aa6a,_0x394ad4)=>{const _0x23c060=!_0x3b3214['serverCache']['isCompleteForChild'](_0xc2aa6a)&&_0x394ad4['value']===null;if(!_0x2bfea0['hasChild'](_0xc2aa6a)&&!_0x23c060){const _0x45100f=_0x3b3214['serverCache']['getNode']()['getImmediateChild'](_0xc2aa6a),_0x3c2199=hr(_0x485995,_0x45100f,_0x394ad4);_0x712f99=Sn(_0x485995,_0x712f99,new C(_0xc2aa6a),_0x3c2199,_0x15b60f,_0x4d63b3,_0xecf2b4,_0x3dd8f4);}}),_0x712f99;}function Pu(_0x4acc27,_0x44ceea,_0x3dd419,_0x56dd30,_0x356197,_0x370880,_0x24cda3){if(Tn(_0x356197,_0x3dd419)!=null)return _0x44ceea;const _0x110556=_0x44ceea['serverCache']['isFiltered'](),_0x2e855d=_0x44ceea['serverCache'];if(_0x56dd30['value']!=null){if(v(_0x3dd419)&&_0x2e855d['isFullyInitialized']()||_0x2e855d['isCompleteForPath'](_0x3dd419))return Sn(_0x4acc27,_0x44ceea,_0x3dd419,_0x2e855d['getNode']()['getChild'](_0x3dd419),_0x356197,_0x370880,_0x110556,_0x24cda3);if(v(_0x3dd419)){let _0x24acbe=new b(null);return _0x2e855d['getNode']()['forEachChild'](ve,(_0x590075,_0x3c8992)=>{_0x24acbe=_0x24acbe['set'](new C(_0x590075),_0x3c8992);}),Pi(_0x4acc27,_0x44ceea,_0x3dd419,_0x24acbe,_0x356197,_0x370880,_0x110556,_0x24cda3);}else return _0x44ceea;}else{let _0x53c4be=new b(null);return _0x56dd30['foreach']((_0x29aeaa,_0x3b8f48)=>{const _0x47dda2=k(_0x3dd419,_0x29aeaa);_0x2e855d['isCompleteForPath'](_0x47dda2)&&(_0x53c4be=_0x53c4be['set'](_0x29aeaa,_0x2e855d['getNode']()['getChild'](_0x47dda2)));}),Pi(_0x4acc27,_0x44ceea,_0x3dd419,_0x53c4be,_0x356197,_0x370880,_0x110556,_0x24cda3);}}function Nu(_0x4ee027,_0x40cab3,_0x7023ee,_0x330063,_0x44a028){const _0x16b808=_0x40cab3['serverCache'],_0x4e8e03=Fo(_0x40cab3,_0x16b808['getNode'](),_0x16b808['isFullyInitialized']()||v(_0x7023ee),_0x16b808['isFiltered']());return Go(_0x4ee027,_0x4e8e03,_0x7023ee,_0x330063,$o,_0x44a028);}function Ou(_0x4ee0b4,_0x564ec2,_0x126aeb,_0x1c2b95,_0xc98cd7,_0x132cee){let _0x5d1ed6;if(Tn(_0x1c2b95,_0x126aeb)!=null)return _0x564ec2;{const _0xa808fc=new rs(_0x1c2b95,_0x564ec2,_0xc98cd7),_0x236c5f=_0x564ec2['eventCache']['getNode']();let _0x58ff0a;if(v(_0x126aeb)||y(_0x126aeb)==='.priority'){let _0x4a364a;if(_0x564ec2['serverCache']['isFullyInitialized']())_0x4a364a=Cn(_0x1c2b95,Ve(_0x564ec2));else{const _0x409fc4=_0x564ec2['serverCache']['getNode']();f(_0x409fc4 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4a364a=is(_0x1c2b95,_0x409fc4);}_0x4a364a=_0x4a364a,_0x58ff0a=_0x4ee0b4['filter']['updateFullNode'](_0x236c5f,_0x4a364a,_0x132cee);}else{const _0x419e8b=y(_0x126aeb);let _0x1aef11=ss(_0x1c2b95,_0x419e8b,_0x564ec2['serverCache']);_0x1aef11==null&&_0x564ec2['serverCache']['isCompleteForChild'](_0x419e8b)&&(_0x1aef11=_0x236c5f['getImmediateChild'](_0x419e8b)),_0x1aef11!=null?_0x58ff0a=_0x4ee0b4['filter']['updateChild'](_0x236c5f,_0x419e8b,_0x1aef11,S(_0x126aeb),_0xa808fc,_0x132cee):_0x564ec2['eventCache']['getNode']()['hasChild'](_0x419e8b)?_0x58ff0a=_0x4ee0b4['filter']['updateChild'](_0x236c5f,_0x419e8b,g['EMPTY_NODE'],S(_0x126aeb),_0xa808fc,_0x132cee):_0x58ff0a=_0x236c5f,_0x58ff0a['isEmpty']()&&_0x564ec2['serverCache']['isFullyInitialized']()&&(_0x5d1ed6=Cn(_0x1c2b95,Ve(_0x564ec2)),_0x5d1ed6['isLeafNode']()&&(_0x58ff0a=_0x4ee0b4['filter']['updateFullNode'](_0x58ff0a,_0x5d1ed6,_0x132cee)));}return _0x5d1ed6=_0x564ec2['serverCache']['isFullyInitialized']()||Tn(_0x1c2b95,w())!=null,Rt(_0x564ec2,_0x58ff0a,_0x5d1ed6,_0x4ee0b4['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x50d4ac,_0x3e5b71){this['query_']=_0x50d4ac,this['eventRegistrations_']=[];const _0x41019a=this['query_']['_queryParams'],_0x3ddea4=new Xi(_0x41019a['getIndex']()),_0x8b8c51=Kh(_0x41019a);this['processor_']=Su(_0x8b8c51);const _0x9d8e7c=_0x3e5b71['serverCache'],_0x546be2=_0x3e5b71['eventCache'],_0x23aada=_0x3ddea4['updateFullNode'](g['EMPTY_NODE'],_0x9d8e7c['getNode'](),null),_0xfac96=_0x8b8c51['updateFullNode'](g['EMPTY_NODE'],_0x546be2['getNode'](),null),_0x30be3e=new Te(_0x23aada,_0x9d8e7c['isFullyInitialized'](),_0x3ddea4['filtersNodes']()),_0x24c2c3=new Te(_0xfac96,_0x546be2['isFullyInitialized'](),_0x8b8c51['filtersNodes']());this['viewCache_']=Un(_0x24c2c3,_0x30be3e),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x42c2e7){return _0x42c2e7['viewCache_']['serverCache']['getNode']();}function Lu(_0x2c08d9){return wn(_0x2c08d9['viewCache_']);}function xu(_0x169192,_0x1e5e20){const _0x6569f7=Ve(_0x169192['viewCache_']);return _0x6569f7&&(_0x169192['query']['_queryParams']['loadsAllData']()||!v(_0x1e5e20)&&!_0x6569f7['getImmediateChild'](y(_0x1e5e20))['isEmpty']())?_0x6569f7['getChild'](_0x1e5e20):null;}function ur(_0x10e4ba){return _0x10e4ba['eventRegistrations_']['length']===0x0;}function Fu(_0x58ed19,_0x16ca8c){_0x58ed19['eventRegistrations_']['push'](_0x16ca8c);}function dr(_0x21792d,_0x546f9d,_0x3b115b){const _0x4f228=[];if(_0x3b115b){f(_0x546f9d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1dcdd0=_0x21792d['query']['_path'];_0x21792d['eventRegistrations_']['forEach'](_0x2eb7c7=>{const _0x587db6=_0x2eb7c7['createCancelEvent'](_0x3b115b,_0x1dcdd0);_0x587db6&&_0x4f228['push'](_0x587db6);});}if(_0x546f9d){let _0x1483b9=[];for(let _0x49678c=0x0;_0x49678c<_0x21792d['eventRegistrations_']['length'];++_0x49678c){const _0x2626b0=_0x21792d['eventRegistrations_'][_0x49678c];if(!_0x2626b0['matches'](_0x546f9d))_0x1483b9['push'](_0x2626b0);else{if(_0x546f9d['hasAnyCallback']()){_0x1483b9=_0x1483b9['concat'](_0x21792d['eventRegistrations_']['slice'](_0x49678c+0x1));break;}}}_0x21792d['eventRegistrations_']=_0x1483b9;}else _0x21792d['eventRegistrations_']=[];return _0x4f228;}function fr(_0x15640d,_0x12f9fd,_0x7f5102,_0x538943){_0x12f9fd['type']===z['MERGE']&&_0x12f9fd['source']['queryId']!==null&&(f(Ve(_0x15640d['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x15640d['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x35ffad=_0x15640d['viewCache_'],_0xbcec66=Ru(_0x15640d['processor_'],_0x35ffad,_0x12f9fd,_0x7f5102,_0x538943);return bu(_0x15640d['processor_'],_0xbcec66['viewCache']),f(_0xbcec66['viewCache']['serverCache']['isFullyInitialized']()||!_0x35ffad['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x15640d['viewCache_']=_0xbcec66['viewCache'],qo(_0x15640d,_0xbcec66['changes'],_0xbcec66['viewCache']['eventCache']['getNode'](),null);}function Uu(_0xcf478f,_0x4136d8){const _0x1ef787=_0xcf478f['viewCache_']['eventCache'],_0x1660a6=[];return _0x1ef787['getNode']()['isLeafNode']()||_0x1ef787['getNode']()['forEachChild'](R,(_0x47adc6,_0x463a27)=>{_0x1660a6['push'](rt(_0x47adc6,_0x463a27));}),_0x1ef787['isFullyInitialized']()&&_0x1660a6['push'](Lo(_0x1ef787['getNode']())),qo(_0xcf478f,_0x1660a6,_0x1ef787['getNode'](),_0x4136d8);}function qo(_0x36c27c,_0x23cab1,_0x318bc7,_0x455b01){const _0x1fb1bc=_0x455b01?[_0x455b01]:_0x36c27c['eventRegistrations_'];return ru(_0x36c27c['eventGenerator_'],_0x23cab1,_0x318bc7,_0x1fb1bc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x8caa3f){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x8caa3f;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x419ae1){return _0x419ae1['views']['size']===0x0;}function os(_0x34241d,_0x1a22ff,_0x253216,_0x23f2c3){const _0x562110=_0x1a22ff['source']['queryId'];if(_0x562110!==null){const _0x294aa2=_0x34241d['views']['get'](_0x562110);return f(_0x294aa2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x294aa2,_0x1a22ff,_0x253216,_0x23f2c3);}else{let _0x198975=[];for(const _0x453bed of _0x34241d['views']['values']())_0x198975=_0x198975['concat'](fr(_0x453bed,_0x1a22ff,_0x253216,_0x23f2c3));return _0x198975;}}function jo(_0x338f5e,_0x3e352c,_0x26fa9f,_0x338515,_0x2e8542){const _0x26a4c0=_0x3e352c['_queryIdentifier'],_0xfd574c=_0x338f5e['views']['get'](_0x26a4c0);if(!_0xfd574c){let _0x6a6e0e=Cn(_0x26fa9f,_0x2e8542?_0x338515:null),_0x33a026=!0x1;_0x6a6e0e?_0x33a026=!0x0:_0x338515 instanceof g?(_0x6a6e0e=is(_0x26fa9f,_0x338515),_0x33a026=!0x1):(_0x6a6e0e=g['EMPTY_NODE'],_0x33a026=!0x1);const _0x4b0e81=Un(new Te(_0x6a6e0e,_0x33a026,!0x1),new Te(_0x338515,_0x2e8542,!0x1));return new Du(_0x3e352c,_0x4b0e81);}return _0xfd574c;}function Hu(_0x3c33b9,_0x2adb98,_0x7d907b,_0x36d340,_0x24e629,_0x2f7a12){const _0x47f146=jo(_0x3c33b9,_0x2adb98,_0x36d340,_0x24e629,_0x2f7a12);return _0x3c33b9['views']['has'](_0x2adb98['_queryIdentifier'])||_0x3c33b9['views']['set'](_0x2adb98['_queryIdentifier'],_0x47f146),Fu(_0x47f146,_0x7d907b),Uu(_0x47f146,_0x7d907b);}function $u(_0x29bd03,_0x30d22c,_0x497633,_0x246efd){const _0x161d06=_0x30d22c['_queryIdentifier'],_0x38cbbf=[];let _0x4f10d7=[];const _0x25abff=Se(_0x29bd03);if(_0x161d06==='default'){for(const [_0xeb1ad7,_0x1b356e]of _0x29bd03['views']['entries']())_0x4f10d7=_0x4f10d7['concat'](dr(_0x1b356e,_0x497633,_0x246efd)),ur(_0x1b356e)&&(_0x29bd03['views']['delete'](_0xeb1ad7),_0x1b356e['query']['_queryParams']['loadsAllData']()||_0x38cbbf['push'](_0x1b356e['query']));}else{const _0x22a0fd=_0x29bd03['views']['get'](_0x161d06);_0x22a0fd&&(_0x4f10d7=_0x4f10d7['concat'](dr(_0x22a0fd,_0x497633,_0x246efd)),ur(_0x22a0fd)&&(_0x29bd03['views']['delete'](_0x161d06),_0x22a0fd['query']['_queryParams']['loadsAllData']()||_0x38cbbf['push'](_0x22a0fd['query'])));}return _0x25abff&&!Se(_0x29bd03)&&_0x38cbbf['push'](new(Bu())(_0x30d22c['_repo'],_0x30d22c['_path'])),{'removed':_0x38cbbf,'events':_0x4f10d7};}function Ko(_0x8d39c){const _0x23da4b=[];for(const _0x195ad5 of _0x8d39c['views']['values']())_0x195ad5['query']['_queryParams']['loadsAllData']()||_0x23da4b['push'](_0x195ad5);return _0x23da4b;}function Ie(_0x21ff13,_0x8543d9){let _0x21847a=null;for(const _0x4ab179 of _0x21ff13['views']['values']())_0x21847a=_0x21847a||xu(_0x4ab179,_0x8543d9);return _0x21847a;}function Yo(_0x4f576c,_0x36ed47){if(_0x36ed47['_queryParams']['loadsAllData']())return Bn(_0x4f576c);{const _0x4f2c49=_0x36ed47['_queryIdentifier'];return _0x4f576c['views']['get'](_0x4f2c49);}}function Qo(_0x3bda50,_0x266e7b){return Yo(_0x3bda50,_0x266e7b)!=null;}function Se(_0x1cd55f){return Bn(_0x1cd55f)!=null;}function Bn(_0x1866ca){for(const _0x5e7edb of _0x1866ca['views']['values']())if(_0x5e7edb['query']['_queryParams']['loadsAllData']())return _0x5e7edb;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xe63556){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xe63556;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2e2e03){this['listenProvider_']=_0x2e2e03,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0xb0c6c9,_0x3b239f,_0x46a8a5,_0x31d820,_0x113d88){return lu(_0xb0c6c9['pendingWriteTree_'],_0x3b239f,_0x46a8a5,_0x31d820,_0x113d88),_0x113d88?_t(_0xb0c6c9,new Be(es(),_0x3b239f,_0x46a8a5)):[];}function ju(_0x407634,_0x3c8ca9,_0x339d0f,_0x29d554){hu(_0x407634['pendingWriteTree_'],_0x3c8ca9,_0x339d0f,_0x29d554);const _0x5a30cd=b['fromObject'](_0x339d0f);return _t(_0x407634,new ot(es(),_0x3c8ca9,_0x5a30cd));}function _e(_0x17a472,_0x2a6a0c,_0x5db77d=!0x1){const _0x21669f=uu(_0x17a472['pendingWriteTree_'],_0x2a6a0c);if(du(_0x17a472['pendingWriteTree_'],_0x2a6a0c)){let _0x32f250=new b(null);return _0x21669f['snap']!=null?_0x32f250=_0x32f250['set'](w(),!0x0):x(_0x21669f['children'],_0x174484=>{_0x32f250=_0x32f250['set'](new C(_0x174484),!0x0);}),_t(_0x17a472,new In(_0x21669f['path'],_0x32f250,_0x5db77d));}else return[];}function Yt(_0x547943,_0x743fd,_0x27c2a2){return _t(_0x547943,new Be(ts(),_0x743fd,_0x27c2a2));}function Ku(_0x411428,_0x4597cf,_0x38b8c3){const _0x3978a8=b['fromObject'](_0x38b8c3);return _t(_0x411428,new ot(ts(),_0x4597cf,_0x3978a8));}function Yu(_0xd46fbf,_0x4667f5){return _t(_0xd46fbf,new Ut(ts(),_0x4667f5));}function Qu(_0x4228a0,_0x3fcb55,_0x745de3){const _0x39d19b=cs(_0x4228a0,_0x745de3);if(_0x39d19b){const _0x35f9c5=ls(_0x39d19b),_0x33fc87=_0x35f9c5['path'],_0x56d536=_0x35f9c5['queryId'],_0x1acaf7=F(_0x33fc87,_0x3fcb55),_0x53703c=new Ut(ns(_0x56d536),_0x1acaf7);return hs(_0x4228a0,_0x33fc87,_0x53703c);}else return[];}function An(_0x32594b,_0x1311f9,_0x172a34,_0x190c25,_0x28b711=!0x1){const _0x26eb9a=_0x1311f9['_path'],_0x21c8ea=_0x32594b['syncPointTree_']['get'](_0x26eb9a);let _0x43399a=[];if(_0x21c8ea&&(_0x1311f9['_queryIdentifier']==='default'||Qo(_0x21c8ea,_0x1311f9))){const _0x2728ea=$u(_0x21c8ea,_0x1311f9,_0x172a34,_0x190c25);Vu(_0x21c8ea)&&(_0x32594b['syncPointTree_']=_0x32594b['syncPointTree_']['remove'](_0x26eb9a));const _0xc4b919=_0x2728ea['removed'];if(_0x43399a=_0x2728ea['events'],!_0x28b711){const _0x539b99=_0xc4b919['findIndex'](_0x304154=>_0x304154['_queryParams']['loadsAllData']())!==-0x1,_0xe73e03=_0x32594b['syncPointTree_']['findOnPath'](_0x26eb9a,(_0x47e048,_0x52e2a4)=>Se(_0x52e2a4));if(_0x539b99&&!_0xe73e03){const _0x32f639=_0x32594b['syncPointTree_']['subtree'](_0x26eb9a);if(!_0x32f639['isEmpty']()){const _0x225a1c=Zu(_0x32f639);for(let _0x5de3d2=0x0;_0x5de3d2<_0x225a1c['length'];++_0x5de3d2){const _0x3a5d49=_0x225a1c[_0x5de3d2],_0x5cf9cc=_0x3a5d49['query'],_0x1ccec9=ea(_0x32594b,_0x3a5d49);_0x32594b['listenProvider_']['startListening'](kt(_0x5cf9cc),Wt(_0x32594b,_0x5cf9cc),_0x1ccec9['hashFn'],_0x1ccec9['onComplete']);}}}!_0xe73e03&&_0xc4b919['length']>0x0&&!_0x190c25&&(_0x539b99?_0x32594b['listenProvider_']['stopListening'](kt(_0x1311f9),null):_0xc4b919['forEach'](_0x498fd6=>{const _0x3ea078=_0x32594b['queryToTagMap']['get'](Hn(_0x498fd6));_0x32594b['listenProvider_']['stopListening'](kt(_0x498fd6),_0x3ea078);}));}ed(_0x32594b,_0xc4b919);}return _0x43399a;}function Jo(_0x23a64a,_0x51da99,_0xd7d491,_0x275deb){const _0x594475=cs(_0x23a64a,_0x275deb);if(_0x594475!=null){const _0x2ede60=ls(_0x594475),_0x185267=_0x2ede60['path'],_0x5b3b34=_0x2ede60['queryId'],_0x321ead=F(_0x185267,_0x51da99),_0x43acfb=new Be(ns(_0x5b3b34),_0x321ead,_0xd7d491);return hs(_0x23a64a,_0x185267,_0x43acfb);}else return[];}function Ju(_0x429d32,_0x3f598e,_0x3010c6,_0x9767e6){const _0x29dd43=cs(_0x429d32,_0x9767e6);if(_0x29dd43){const _0x42aa76=ls(_0x29dd43),_0x2b9ec6=_0x42aa76['path'],_0x2f7722=_0x42aa76['queryId'],_0x9313c4=F(_0x2b9ec6,_0x3f598e),_0x437426=b['fromObject'](_0x3010c6),_0x74160b=new ot(ns(_0x2f7722),_0x9313c4,_0x437426);return hs(_0x429d32,_0x2b9ec6,_0x74160b);}else return[];}function Ni(_0x5e1449,_0x2b586c,_0x1835ef,_0x4a323a=!0x1){const _0x72240=_0x2b586c['_path'];let _0x4d02e6=null,_0x540850=!0x1;_0x5e1449['syncPointTree_']['foreachOnPath'](_0x72240,(_0xc0920b,_0x861f6f)=>{const _0x30664c=F(_0xc0920b,_0x72240);_0x4d02e6=_0x4d02e6||Ie(_0x861f6f,_0x30664c),_0x540850=_0x540850||Se(_0x861f6f);});let _0x3317a4=_0x5e1449['syncPointTree_']['get'](_0x72240);_0x3317a4?(_0x540850=_0x540850||Se(_0x3317a4),_0x4d02e6=_0x4d02e6||Ie(_0x3317a4,w())):(_0x3317a4=new zo(),_0x5e1449['syncPointTree_']=_0x5e1449['syncPointTree_']['set'](_0x72240,_0x3317a4));let _0xf3060a;_0x4d02e6!=null?_0xf3060a=!0x0:(_0xf3060a=!0x1,_0x4d02e6=g['EMPTY_NODE'],_0x5e1449['syncPointTree_']['subtree'](_0x72240)['foreachChild']((_0x2f77fa,_0x4a0830)=>{const _0x5a67de=Ie(_0x4a0830,w());_0x5a67de&&(_0x4d02e6=_0x4d02e6['updateImmediateChild'](_0x2f77fa,_0x5a67de));}));const _0x4c785c=Qo(_0x3317a4,_0x2b586c);if(!_0x4c785c&&!_0x2b586c['_queryParams']['loadsAllData']()){const _0x465cad=Hn(_0x2b586c);f(!_0x5e1449['queryToTagMap']['has'](_0x465cad),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5a7726=td();_0x5e1449['queryToTagMap']['set'](_0x465cad,_0x5a7726),_0x5e1449['tagToQueryMap']['set'](_0x5a7726,_0x465cad);}const _0x525ed4=Wn(_0x5e1449['pendingWriteTree_'],_0x72240);let _0xf35643=Hu(_0x3317a4,_0x2b586c,_0x1835ef,_0x525ed4,_0x4d02e6,_0xf3060a);if(!_0x4c785c&&!_0x540850&&!_0x4a323a){const _0xfcf9d0=Yo(_0x3317a4,_0x2b586c);_0xf35643=_0xf35643['concat'](nd(_0x5e1449,_0x2b586c,_0xfcf9d0));}return _0xf35643;}function Vn(_0x4b234b,_0xf10396,_0x30687c){const _0x11b0a0=_0x4b234b['pendingWriteTree_'],_0x3d812f=_0x4b234b['syncPointTree_']['findOnPath'](_0xf10396,(_0x57ed02,_0x53bc36)=>{const _0xa7a25a=F(_0x57ed02,_0xf10396),_0x32cda2=Ie(_0x53bc36,_0xa7a25a);if(_0x32cda2)return _0x32cda2;});return Bo(_0x11b0a0,_0xf10396,_0x3d812f,_0x30687c,!0x0);}function Xu(_0x4fea2f,_0x8a2a38){const _0x4ef3f0=_0x8a2a38['_path'];let _0x35c5b5=null;_0x4fea2f['syncPointTree_']['foreachOnPath'](_0x4ef3f0,(_0x5c04e6,_0x1b5de0)=>{const _0x555c27=F(_0x5c04e6,_0x4ef3f0);_0x35c5b5=_0x35c5b5||Ie(_0x1b5de0,_0x555c27);});let _0x433a0e=_0x4fea2f['syncPointTree_']['get'](_0x4ef3f0);_0x433a0e?_0x35c5b5=_0x35c5b5||Ie(_0x433a0e,w()):(_0x433a0e=new zo(),_0x4fea2f['syncPointTree_']=_0x4fea2f['syncPointTree_']['set'](_0x4ef3f0,_0x433a0e));const _0x29575c=_0x35c5b5!=null,_0x10c7df=_0x29575c?new Te(_0x35c5b5,!0x0,!0x1):null,_0x1f4f0f=Wn(_0x4fea2f['pendingWriteTree_'],_0x8a2a38['_path']),_0x1bc157=jo(_0x433a0e,_0x8a2a38,_0x1f4f0f,_0x29575c?_0x10c7df['getNode']():g['EMPTY_NODE'],_0x29575c);return Lu(_0x1bc157);}function _t(_0x521bfc,_0x33304e){return Xo(_0x33304e,_0x521bfc['syncPointTree_'],null,Wn(_0x521bfc['pendingWriteTree_'],w()));}function Xo(_0x4f0f17,_0x1db6ed,_0x494b5b,_0x2941c2){if(v(_0x4f0f17['path']))return Zo(_0x4f0f17,_0x1db6ed,_0x494b5b,_0x2941c2);{const _0x3a4c63=_0x1db6ed['get'](w());_0x494b5b==null&&_0x3a4c63!=null&&(_0x494b5b=Ie(_0x3a4c63,w()));let _0x232442=[];const _0x373cfd=y(_0x4f0f17['path']),_0x599b12=_0x4f0f17['operationForChild'](_0x373cfd),_0x416ed5=_0x1db6ed['children']['get'](_0x373cfd);if(_0x416ed5&&_0x599b12){const _0x533b31=_0x494b5b?_0x494b5b['getImmediateChild'](_0x373cfd):null,_0x15d91a=Vo(_0x2941c2,_0x373cfd);_0x232442=_0x232442['concat'](Xo(_0x599b12,_0x416ed5,_0x533b31,_0x15d91a));}return _0x3a4c63&&(_0x232442=_0x232442['concat'](os(_0x3a4c63,_0x4f0f17,_0x2941c2,_0x494b5b))),_0x232442;}}function Zo(_0x1c862d,_0x4b8421,_0x3b5a24,_0x420fb0){const _0x14c291=_0x4b8421['get'](w());_0x3b5a24==null&&_0x14c291!=null&&(_0x3b5a24=Ie(_0x14c291,w()));let _0x402a7c=[];return _0x4b8421['children']['inorderTraversal']((_0x10042a,_0x2fd2b9)=>{const _0x174842=_0x3b5a24?_0x3b5a24['getImmediateChild'](_0x10042a):null,_0x2cfe14=Vo(_0x420fb0,_0x10042a),_0x370832=_0x1c862d['operationForChild'](_0x10042a);_0x370832&&(_0x402a7c=_0x402a7c['concat'](Zo(_0x370832,_0x2fd2b9,_0x174842,_0x2cfe14)));}),_0x14c291&&(_0x402a7c=_0x402a7c['concat'](os(_0x14c291,_0x1c862d,_0x420fb0,_0x3b5a24))),_0x402a7c;}function ea(_0x9ea1d6,_0x3c9a1a){const _0x421a34=_0x3c9a1a['query'],_0x3f8bf0=Wt(_0x9ea1d6,_0x421a34);return{'hashFn':()=>(Mu(_0x3c9a1a)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1f4458=>{if(_0x1f4458==='ok')return _0x3f8bf0?Qu(_0x9ea1d6,_0x421a34['_path'],_0x3f8bf0):Yu(_0x9ea1d6,_0x421a34['_path']);{const _0x27917e=Kl(_0x1f4458,_0x421a34);return An(_0x9ea1d6,_0x421a34,null,_0x27917e);}}};}function Wt(_0x56d00e,_0x23717f){const _0x1c573f=Hn(_0x23717f);return _0x56d00e['queryToTagMap']['get'](_0x1c573f);}function Hn(_0x204a48){return _0x204a48['_path']['toString']()+'$'+_0x204a48['_queryIdentifier'];}function cs(_0x40f8a4,_0x325ed9){return _0x40f8a4['tagToQueryMap']['get'](_0x325ed9);}function ls(_0x42b420){const _0x4d8cff=_0x42b420['indexOf']('$');return f(_0x4d8cff!==-0x1&&_0x4d8cff<_0x42b420['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x42b420['substr'](_0x4d8cff+0x1),'path':new C(_0x42b420['substr'](0x0,_0x4d8cff))};}function hs(_0x163ed3,_0x133f37,_0x55fef0){const _0x5c4cd4=_0x163ed3['syncPointTree_']['get'](_0x133f37);f(_0x5c4cd4,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2756b1=Wn(_0x163ed3['pendingWriteTree_'],_0x133f37);return os(_0x5c4cd4,_0x55fef0,_0x2756b1,null);}function Zu(_0x165cb7){return _0x165cb7['fold']((_0x104858,_0x4384f6,_0x11a22c)=>{if(_0x4384f6&&Se(_0x4384f6))return[Bn(_0x4384f6)];{let _0x1556d5=[];return _0x4384f6&&(_0x1556d5=Ko(_0x4384f6)),x(_0x11a22c,(_0x5983c3,_0x290a59)=>{_0x1556d5=_0x1556d5['concat'](_0x290a59);}),_0x1556d5;}});}function kt(_0x4b4290){return _0x4b4290['_queryParams']['loadsAllData']()&&!_0x4b4290['_queryParams']['isDefault']()?new(qu())(_0x4b4290['_repo'],_0x4b4290['_path']):_0x4b4290;}function ed(_0x3b9d1a,_0x29c21e){for(let _0x2e5a21=0x0;_0x2e5a21<_0x29c21e['length'];++_0x2e5a21){const _0x210e98=_0x29c21e[_0x2e5a21];if(!_0x210e98['_queryParams']['loadsAllData']()){const _0x28d822=Hn(_0x210e98),_0x52fa49=_0x3b9d1a['queryToTagMap']['get'](_0x28d822);_0x3b9d1a['queryToTagMap']['delete'](_0x28d822),_0x3b9d1a['tagToQueryMap']['delete'](_0x52fa49);}}}function td(){return zu++;}function nd(_0x10d9a3,_0x4903e9,_0x469180){const _0x42ead2=_0x4903e9['_path'],_0x376ce7=Wt(_0x10d9a3,_0x4903e9),_0x4634f2=ea(_0x10d9a3,_0x469180),_0x5d4ed7=_0x10d9a3['listenProvider_']['startListening'](kt(_0x4903e9),_0x376ce7,_0x4634f2['hashFn'],_0x4634f2['onComplete']),_0xc8de7f=_0x10d9a3['syncPointTree_']['subtree'](_0x42ead2);if(_0x376ce7)f(!Se(_0xc8de7f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3c14ff=_0xc8de7f['fold']((_0xf2d3e7,_0x48fdbf,_0x4db0fb)=>{if(!v(_0xf2d3e7)&&_0x48fdbf&&Se(_0x48fdbf))return[Bn(_0x48fdbf)['query']];{let _0x3f35a2=[];return _0x48fdbf&&(_0x3f35a2=_0x3f35a2['concat'](Ko(_0x48fdbf)['map'](_0xab75f0=>_0xab75f0['query']))),x(_0x4db0fb,(_0x367f35,_0x22ccd8)=>{_0x3f35a2=_0x3f35a2['concat'](_0x22ccd8);}),_0x3f35a2;}});for(let _0x3dd58f=0x0;_0x3dd58f<_0x3c14ff['length'];++_0x3dd58f){const _0x421229=_0x3c14ff[_0x3dd58f];_0x10d9a3['listenProvider_']['stopListening'](kt(_0x421229),Wt(_0x10d9a3,_0x421229));}}return _0x5d4ed7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x50ed94){this['node_']=_0x50ed94;}['getImmediateChild'](_0x3a499d){const _0x5cac5c=this['node_']['getImmediateChild'](_0x3a499d);return new us(_0x5cac5c);}['node'](){return this['node_'];}}class ds{constructor(_0x5ce5d8,_0x96ae0e){this['syncTree_']=_0x5ce5d8,this['path_']=_0x96ae0e;}['getImmediateChild'](_0x32d529){const _0x4ce0ae=k(this['path_'],_0x32d529);return new ds(this['syncTree_'],_0x4ce0ae);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x173a3b){return _0x173a3b=_0x173a3b||{},_0x173a3b['timestamp']=_0x173a3b['timestamp']||new Date()['getTime'](),_0x173a3b;},_r=function(_0xb498d8,_0x5947b0,_0x4e8fd6){if(!_0xb498d8||typeof _0xb498d8!='object')return _0xb498d8;if(f('.sv'in _0xb498d8,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0xb498d8['.sv']=='string')return sd(_0xb498d8['.sv'],_0x5947b0,_0x4e8fd6);if(typeof _0xb498d8['.sv']=='object')return rd(_0xb498d8['.sv'],_0x5947b0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xb498d8,null,0x2));},sd=function(_0x32ed79,_0x583d58,_0x17081b){switch(_0x32ed79){case'timestamp':return _0x17081b['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x32ed79);}},rd=function(_0x2928cb,_0x58d3cc,_0xdf3c20){_0x2928cb['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2928cb,null,0x2));const _0x313a9d=_0x2928cb['increment'];typeof _0x313a9d!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x313a9d);const _0x4372bb=_0x58d3cc['node']();if(f(_0x4372bb!==null&&typeof _0x4372bb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4372bb['isLeafNode']())return _0x313a9d;const _0x257c0d=_0x4372bb['getValue']();return typeof _0x257c0d!='number'?_0x313a9d:_0x257c0d+_0x313a9d;},ta=function(_0x4c198a,_0x286409,_0x3d8dd2,_0x3e67ab){return ps(_0x286409,new ds(_0x3d8dd2,_0x4c198a),_0x3e67ab);},fs=function(_0x46d95a,_0x1e6a5f,_0x35dcd7){return ps(_0x46d95a,new us(_0x1e6a5f),_0x35dcd7);};function ps(_0x1fb7a9,_0x5594a9,_0xe379ee){const _0x2989f9=_0x1fb7a9['getPriority']()['val'](),_0x39ca1a=_r(_0x2989f9,_0x5594a9['getImmediateChild']('.priority'),_0xe379ee);let _0x2ffb3a;if(_0x1fb7a9['isLeafNode']()){const _0x21543f=_0x1fb7a9,_0x16ebef=_r(_0x21543f['getValue'](),_0x5594a9,_0xe379ee);return _0x16ebef!==_0x21543f['getValue']()||_0x39ca1a!==_0x21543f['getPriority']()['val']()?new D(_0x16ebef,A(_0x39ca1a)):_0x1fb7a9;}else{const _0x1cd6f7=_0x1fb7a9;return _0x2ffb3a=_0x1cd6f7,_0x39ca1a!==_0x1cd6f7['getPriority']()['val']()&&(_0x2ffb3a=_0x2ffb3a['updatePriority'](new D(_0x39ca1a))),_0x1cd6f7['forEachChild'](R,(_0x1aeefd,_0x153b40)=>{const _0x510a55=ps(_0x153b40,_0x5594a9['getImmediateChild'](_0x1aeefd),_0xe379ee);_0x510a55!==_0x153b40&&(_0x2ffb3a=_0x2ffb3a['updateImmediateChild'](_0x1aeefd,_0x510a55));}),_0x2ffb3a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x11bb7f='',_0x21cb89=null,_0x1c8ab1={'children':{},'childCount':0x0}){this['name']=_0x11bb7f,this['parent']=_0x21cb89,this['node']=_0x1c8ab1;}}function $n(_0x49a52b,_0x266d76){let _0x17ed21=_0x266d76 instanceof C?_0x266d76:new C(_0x266d76),_0x1ba791=_0x49a52b,_0x5a9124=y(_0x17ed21);for(;_0x5a9124!==null;){const _0x19b749=Le(_0x1ba791['node']['children'],_0x5a9124)||{'children':{},'childCount':0x0};_0x1ba791=new _s(_0x5a9124,_0x1ba791,_0x19b749),_0x17ed21=S(_0x17ed21),_0x5a9124=y(_0x17ed21);}return _0x1ba791;}function je(_0x5a0e2b){return _0x5a0e2b['node']['value'];}function gs(_0x9787b9,_0x13c66f){_0x9787b9['node']['value']=_0x13c66f,Oi(_0x9787b9);}function na(_0x5a7f62){return _0x5a7f62['node']['childCount']>0x0;}function od(_0x4dec6b){return je(_0x4dec6b)===void 0x0&&!na(_0x4dec6b);}function Gn(_0x5632c7,_0x5517b7){x(_0x5632c7['node']['children'],(_0x594f54,_0x5f4b26)=>{_0x5517b7(new _s(_0x594f54,_0x5632c7,_0x5f4b26));});}function ia(_0x2b7a2b,_0x1ce35d,_0x28c36d,_0x36474e){_0x28c36d&&_0x1ce35d(_0x2b7a2b),Gn(_0x2b7a2b,_0x58d94c=>{ia(_0x58d94c,_0x1ce35d,!0x0);});}function ad(_0x55ade0,_0x158577,_0x73e40c){let _0x4460c9=_0x55ade0['parent'];for(;_0x4460c9!==null;){if(_0x158577(_0x4460c9))return!0x0;_0x4460c9=_0x4460c9['parent'];}return!0x1;}function Qt(_0x2d836d){return new C(_0x2d836d['parent']===null?_0x2d836d['name']:Qt(_0x2d836d['parent'])+'/'+_0x2d836d['name']);}function Oi(_0x38948f){_0x38948f['parent']!==null&&cd(_0x38948f['parent'],_0x38948f['name'],_0x38948f);}function cd(_0x1721c0,_0x5cefc5,_0x1f8163){const _0x3f3472=od(_0x1f8163),_0x3eba13=Q(_0x1721c0['node']['children'],_0x5cefc5);_0x3f3472&&_0x3eba13?(delete _0x1721c0['node']['children'][_0x5cefc5],_0x1721c0['node']['childCount']--,Oi(_0x1721c0)):!_0x3f3472&&!_0x3eba13&&(_0x1721c0['node']['children'][_0x5cefc5]=_0x1f8163['node'],_0x1721c0['node']['childCount']++,Oi(_0x1721c0));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x2c6bb4){return typeof _0x2c6bb4=='string'&&_0x2c6bb4['length']!==0x0&&!ld['test'](_0x2c6bb4);},sa=function(_0x22e06b){return typeof _0x22e06b=='string'&&_0x22e06b['length']!==0x0&&!hd['test'](_0x22e06b);},ud=function(_0x8592b2){return _0x8592b2&&(_0x8592b2=_0x8592b2['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x8592b2);},Bt=function(_0xbaaccf){return _0xbaaccf===null||typeof _0xbaaccf=='string'||typeof _0xbaaccf=='number'&&!xn(_0xbaaccf)||_0xbaaccf&&typeof _0xbaaccf=='object'&&Q(_0xbaaccf,'.sv');},He=function(_0x1614ae,_0x527d47,_0x4def6e,_0x2b7795){_0x2b7795&&_0x527d47===void 0x0||Jt(it(_0x1614ae,'value'),_0x527d47,_0x4def6e);},Jt=function(_0x3bf2c7,_0x1da47f,_0x37c5b1){const _0x32148f=_0x37c5b1 instanceof C?new Ah(_0x37c5b1,_0x3bf2c7):_0x37c5b1;if(_0x1da47f===void 0x0)throw new Error(_0x3bf2c7+'contains\x20undefined\x20'+Oe(_0x32148f));if(typeof _0x1da47f=='function')throw new Error(_0x3bf2c7+'contains\x20a\x20function\x20'+Oe(_0x32148f)+'\x20with\x20contents\x20=\x20'+_0x1da47f['toString']());if(xn(_0x1da47f))throw new Error(_0x3bf2c7+'contains\x20'+_0x1da47f['toString']()+'\x20'+Oe(_0x32148f));if(typeof _0x1da47f=='string'&&_0x1da47f['length']>ui/0x3&&Ln(_0x1da47f)>ui)throw new Error(_0x3bf2c7+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x32148f)+'\x20(\x27'+_0x1da47f['substring'](0x0,0x32)+'...\x27)');if(_0x1da47f&&typeof _0x1da47f=='object'){let _0x5907e4=!0x1,_0x35f77a=!0x1;if(x(_0x1da47f,(_0x598964,_0x597c5a)=>{if(_0x598964==='.value')_0x5907e4=!0x0;else{if(_0x598964!=='.priority'&&_0x598964!=='.sv'&&(_0x35f77a=!0x0,!ms(_0x598964)))throw new Error(_0x3bf2c7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x598964+')\x20'+Oe(_0x32148f)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x32148f,_0x598964),Jt(_0x3bf2c7,_0x597c5a,_0x32148f),Ph(_0x32148f);}),_0x5907e4&&_0x35f77a)throw new Error(_0x3bf2c7+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x32148f)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5e1adc,_0x356dff){let _0x282e7b,_0x15be0f;for(_0x282e7b=0x0;_0x282e7b<_0x356dff['length'];_0x282e7b++){_0x15be0f=_0x356dff[_0x282e7b];const _0x1e533d=Mt(_0x15be0f);for(let _0x5cf786=0x0;_0x5cf786<_0x1e533d['length'];_0x5cf786++)if(!(_0x1e533d[_0x5cf786]==='.priority'&&_0x5cf786===_0x1e533d['length']-0x1)){if(!ms(_0x1e533d[_0x5cf786]))throw new Error(_0x5e1adc+'contains\x20an\x20invalid\x20key\x20('+_0x1e533d[_0x5cf786]+')\x20in\x20path\x20'+_0x15be0f['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x356dff['sort'](Rh);let _0x36aaec=null;for(_0x282e7b=0x0;_0x282e7b<_0x356dff['length'];_0x282e7b++){if(_0x15be0f=_0x356dff[_0x282e7b],_0x36aaec!==null&&G(_0x36aaec,_0x15be0f))throw new Error(_0x5e1adc+'contains\x20a\x20path\x20'+_0x36aaec['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x15be0f['toString']());_0x36aaec=_0x15be0f;}},ra=function(_0x36d3b9,_0x4f5586,_0x5c5177,_0x5f0701){const _0x1b8e3e=it(_0x36d3b9,'values');if(!(_0x4f5586&&typeof _0x4f5586=='object')||Array['isArray'](_0x4f5586))throw new Error(_0x1b8e3e+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3c598b=[];x(_0x4f5586,(_0x116619,_0x5c0655)=>{const _0x589120=new C(_0x116619);if(Jt(_0x1b8e3e,_0x5c0655,k(_0x5c5177,_0x589120)),ji(_0x589120)==='.priority'&&!Bt(_0x5c0655))throw new Error(_0x1b8e3e+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x589120['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3c598b['push'](_0x589120);}),dd(_0x1b8e3e,_0x3c598b);},fd=function(_0x3d8228,_0xe722f2,_0x47b130){if(xn(_0xe722f2))throw new Error(it(_0x3d8228,'priority')+'is\x20'+_0xe722f2['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xe722f2))throw new Error(it(_0x3d8228,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0xe18cb,_0x517323,_0x21b6a0,_0x4b8557){if(!sa(_0x21b6a0))throw new Error(it(_0xe18cb,_0x517323)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x21b6a0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x32fb91,_0x244ded,_0x48ed76,_0x148572){_0x48ed76&&(_0x48ed76=_0x48ed76['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x32fb91,_0x244ded,_0x48ed76);},Me=function(_0x4d7602,_0x1b92bb){if(y(_0x1b92bb)==='.info')throw new Error(_0x4d7602+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x47354c,_0x1da53e){const _0x369016=_0x1da53e['path']['toString']();if(typeof _0x1da53e['repoInfo']['host']!='string'||_0x1da53e['repoInfo']['host']['length']===0x0||!ms(_0x1da53e['repoInfo']['namespace'])&&_0x1da53e['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x369016['length']!==0x0&&!ud(_0x369016))throw new Error(it(_0x47354c,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x42e40a,_0x475a3c){let _0x45c28a=null;for(let _0xefca07=0x0;_0xefca07<_0x475a3c['length'];_0xefca07++){const _0x3e23c8=_0x475a3c[_0xefca07],_0x4ed004=_0x3e23c8['getPath']();_0x45c28a!==null&&!Ki(_0x4ed004,_0x45c28a['path'])&&(_0x42e40a['eventLists_']['push'](_0x45c28a),_0x45c28a=null),_0x45c28a===null&&(_0x45c28a={'events':[],'path':_0x4ed004}),_0x45c28a['events']['push'](_0x3e23c8);}_0x45c28a&&_0x42e40a['eventLists_']['push'](_0x45c28a);}function oa(_0x383cef,_0x3cbce8,_0x42274f){qn(_0x383cef,_0x42274f),aa(_0x383cef,_0x38ea4c=>Ki(_0x38ea4c,_0x3cbce8));}function V(_0x17da5d,_0x2083ac,_0x51f5d9){qn(_0x17da5d,_0x51f5d9),aa(_0x17da5d,_0x1b1019=>G(_0x1b1019,_0x2083ac)||G(_0x2083ac,_0x1b1019));}function aa(_0x578b8f,_0x115eee){_0x578b8f['recursionDepth_']++;let _0x18fc0a=!0x0;for(let _0x1c1fc9=0x0;_0x1c1fc9<_0x578b8f['eventLists_']['length'];_0x1c1fc9++){const _0x5cf5b1=_0x578b8f['eventLists_'][_0x1c1fc9];if(_0x5cf5b1){const _0x54f4f5=_0x5cf5b1['path'];_0x115eee(_0x54f4f5)?(md(_0x578b8f['eventLists_'][_0x1c1fc9]),_0x578b8f['eventLists_'][_0x1c1fc9]=null):_0x18fc0a=!0x1;}}_0x18fc0a&&(_0x578b8f['eventLists_']=[]),_0x578b8f['recursionDepth_']--;}function md(_0x82904a){for(let _0x42eade=0x0;_0x42eade<_0x82904a['events']['length'];_0x42eade++){const _0x2f1207=_0x82904a['events'][_0x42eade];if(_0x2f1207!==null){_0x82904a['events'][_0x42eade]=null;const _0x28a7e6=_0x2f1207['getEventRunner']();St&&L('event:\x20'+_0x2f1207['toString']()),ft(_0x28a7e6);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4dd44a,_0x241458,_0x4d1c5d,_0x31b01d){this['repoInfo_']=_0x4dd44a,this['forceRestClient_']=_0x241458,this['authTokenProvider_']=_0x4d1c5d,this['appCheckProvider_']=_0x31b01d,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x38ab0e,_0x50a2fb,_0x13810e){if(_0x38ab0e['stats_']=qi(_0x38ab0e['repoInfo_']),_0x38ab0e['forceRestClient_']||Xl())_0x38ab0e['server_']=new vn(_0x38ab0e['repoInfo_'],(_0x266211,_0x489a57,_0x33f737,_0x209a75)=>{gr(_0x38ab0e,_0x266211,_0x489a57,_0x33f737,_0x209a75);},_0x38ab0e['authTokenProvider_'],_0x38ab0e['appCheckProvider_']),setTimeout(()=>mr(_0x38ab0e,!0x0),0x0);else{if(typeof _0x13810e<'u'&&_0x13810e!==null){if(typeof _0x13810e!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x13810e);}catch(_0x68dde8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x68dde8);}}_0x38ab0e['persistentConnection_']=new se(_0x38ab0e['repoInfo_'],_0x50a2fb,(_0x1729bc,_0x16e18f,_0x59ec1b,_0xbcd5f4)=>{gr(_0x38ab0e,_0x1729bc,_0x16e18f,_0x59ec1b,_0xbcd5f4);},_0x195ec1=>{mr(_0x38ab0e,_0x195ec1);},_0x36bbab=>{Id(_0x38ab0e,_0x36bbab);},_0x38ab0e['authTokenProvider_'],_0x38ab0e['appCheckProvider_'],_0x13810e),_0x38ab0e['server_']=_0x38ab0e['persistentConnection_'];}_0x38ab0e['authTokenProvider_']['addTokenChangeListener'](_0x3d0764=>{_0x38ab0e['server_']['refreshAuthToken'](_0x3d0764);}),_0x38ab0e['appCheckProvider_']['addTokenChangeListener'](_0x1dde3c=>{_0x38ab0e['server_']['refreshAppCheckToken'](_0x1dde3c['token']);}),_0x38ab0e['statsReporter_']=ih(_0x38ab0e['repoInfo_'],()=>new iu(_0x38ab0e['stats_'],_0x38ab0e['server_'])),_0x38ab0e['infoData_']=new Xh(),_0x38ab0e['infoSyncTree_']=new pr({'startListening':(_0x5914ba,_0x46cf5a,_0x13d211,_0x19eee4)=>{let _0x1afda2=[];const _0x61908a=_0x38ab0e['infoData_']['getNode'](_0x5914ba['_path']);return _0x61908a['isEmpty']()||(_0x1afda2=Yt(_0x38ab0e['infoSyncTree_'],_0x5914ba['_path'],_0x61908a),setTimeout(()=>{_0x19eee4('ok');},0x0)),_0x1afda2;},'stopListening':()=>{}}),vs(_0x38ab0e,'connected',!0x1),_0x38ab0e['serverSyncTree_']=new pr({'startListening':(_0x5295cc,_0x2694e5,_0x1984ae,_0x32fc5f)=>(_0x38ab0e['server_']['listen'](_0x5295cc,_0x1984ae,_0x2694e5,(_0x1bb69a,_0x2daec1)=>{const _0x5377cb=_0x32fc5f(_0x1bb69a,_0x2daec1);V(_0x38ab0e['eventQueue_'],_0x5295cc['_path'],_0x5377cb);}),[]),'stopListening':(_0xf4d0e7,_0x48feac)=>{_0x38ab0e['server_']['unlisten'](_0xf4d0e7,_0x48feac);}});}function la(_0x5b245f){const _0x467ec0=_0x5b245f['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x467ec0;}function Xt(_0x25dc08){return id({'timestamp':la(_0x25dc08)});}function gr(_0x1ac79e,_0x254070,_0x41341f,_0x4dd76a,_0x1b7c6f){_0x1ac79e['dataUpdateCount']++;const _0x28e1ef=new C(_0x254070);_0x41341f=_0x1ac79e['interceptServerDataCallback_']?_0x1ac79e['interceptServerDataCallback_'](_0x254070,_0x41341f):_0x41341f;let _0x44ecc6=[];if(_0x1b7c6f){if(_0x4dd76a){const _0x35fc74=_n(_0x41341f,_0x4ab2ac=>A(_0x4ab2ac));_0x44ecc6=Ju(_0x1ac79e['serverSyncTree_'],_0x28e1ef,_0x35fc74,_0x1b7c6f);}else{const _0x3df284=A(_0x41341f);_0x44ecc6=Jo(_0x1ac79e['serverSyncTree_'],_0x28e1ef,_0x3df284,_0x1b7c6f);}}else{if(_0x4dd76a){const _0x33d0a7=_n(_0x41341f,_0x4ff5dd=>A(_0x4ff5dd));_0x44ecc6=Ku(_0x1ac79e['serverSyncTree_'],_0x28e1ef,_0x33d0a7);}else{const _0x2084ec=A(_0x41341f);_0x44ecc6=Yt(_0x1ac79e['serverSyncTree_'],_0x28e1ef,_0x2084ec);}}let _0x1eb154=_0x28e1ef;_0x44ecc6['length']>0x0&&(_0x1eb154=ct(_0x1ac79e,_0x28e1ef)),V(_0x1ac79e['eventQueue_'],_0x1eb154,_0x44ecc6);}function mr(_0x5303d1,_0x1f3c82){vs(_0x5303d1,'connected',_0x1f3c82),_0x1f3c82===!0x1&&Sd(_0x5303d1);}function Id(_0xbb025c,_0x3d72bf){x(_0x3d72bf,(_0x17343a,_0xf32b1f)=>{vs(_0xbb025c,_0x17343a,_0xf32b1f);});}function vs(_0x59a5c7,_0x438a8a,_0x1bac19){const _0x10348c=new C('/.info/'+_0x438a8a),_0x9ae8d8=A(_0x1bac19);_0x59a5c7['infoData_']['updateSnapshot'](_0x10348c,_0x9ae8d8);const _0x5dd139=Yt(_0x59a5c7['infoSyncTree_'],_0x10348c,_0x9ae8d8);V(_0x59a5c7['eventQueue_'],_0x10348c,_0x5dd139);}function zn(_0x384749){return _0x384749['nextWriteId_']++;}function wd(_0x11bbf7,_0x3a640c,_0xbf9228){const _0xce6097=Xu(_0x11bbf7['serverSyncTree_'],_0x3a640c);return _0xce6097!=null?Promise['resolve'](_0xce6097):_0x11bbf7['server_']['get'](_0x3a640c)['then'](_0x3b6da6=>{const _0x5b3169=A(_0x3b6da6)['withIndex'](_0x3a640c['_queryParams']['getIndex']());Ni(_0x11bbf7['serverSyncTree_'],_0x3a640c,_0xbf9228,!0x0);let _0xab2738;if(_0x3a640c['_queryParams']['loadsAllData']())_0xab2738=Yt(_0x11bbf7['serverSyncTree_'],_0x3a640c['_path'],_0x5b3169);else{const _0x460095=Wt(_0x11bbf7['serverSyncTree_'],_0x3a640c);_0xab2738=Jo(_0x11bbf7['serverSyncTree_'],_0x3a640c['_path'],_0x5b3169,_0x460095);}return V(_0x11bbf7['eventQueue_'],_0x3a640c['_path'],_0xab2738),An(_0x11bbf7['serverSyncTree_'],_0x3a640c,_0xbf9228,null,!0x0),_0x5b3169;},_0x355ff3=>(gt(_0x11bbf7,'get\x20for\x20query\x20'+O(_0x3a640c)+'\x20failed:\x20'+_0x355ff3),Promise['reject'](new Error(_0x355ff3))));}function Cd(_0x4d8546,_0x1f2826,_0x266704,_0x67bea8,_0x61cf29){gt(_0x4d8546,'set',{'path':_0x1f2826['toString'](),'value':_0x266704,'priority':_0x67bea8});const _0x58cc8d=Xt(_0x4d8546),_0x52244d=A(_0x266704,_0x67bea8),_0xddfb97=Vn(_0x4d8546['serverSyncTree_'],_0x1f2826),_0x44b50a=fs(_0x52244d,_0xddfb97,_0x58cc8d),_0x632862=zn(_0x4d8546),_0x3f347f=as(_0x4d8546['serverSyncTree_'],_0x1f2826,_0x44b50a,_0x632862,!0x0);qn(_0x4d8546['eventQueue_'],_0x3f347f),_0x4d8546['server_']['put'](_0x1f2826['toString'](),_0x52244d['val'](!0x0),(_0x4492bb,_0x24139d)=>{const _0xde8a44=_0x4492bb==='ok';_0xde8a44||U('set\x20at\x20'+_0x1f2826+'\x20failed:\x20'+_0x4492bb);const _0x254f66=_e(_0x4d8546['serverSyncTree_'],_0x632862,!_0xde8a44);V(_0x4d8546['eventQueue_'],_0x1f2826,_0x254f66),be(_0x4d8546,_0x61cf29,_0x4492bb,_0x24139d);});const _0xfc360a=Is(_0x4d8546,_0x1f2826);ct(_0x4d8546,_0xfc360a),V(_0x4d8546['eventQueue_'],_0xfc360a,[]);}function Td(_0x5144ca,_0x5f0095,_0x55bb9f,_0x207d79){gt(_0x5144ca,'update',{'path':_0x5f0095['toString'](),'value':_0x55bb9f});let _0x165ce2=!0x0;const _0x5c017c=Xt(_0x5144ca),_0x69e7e6={};if(x(_0x55bb9f,(_0x1162f2,_0x1d5f61)=>{_0x165ce2=!0x1,_0x69e7e6[_0x1162f2]=ta(k(_0x5f0095,_0x1162f2),A(_0x1d5f61),_0x5144ca['serverSyncTree_'],_0x5c017c);}),_0x165ce2)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x5144ca,_0x207d79,'ok',void 0x0);else{const _0x5c24f0=zn(_0x5144ca),_0x37d772=ju(_0x5144ca['serverSyncTree_'],_0x5f0095,_0x69e7e6,_0x5c24f0);qn(_0x5144ca['eventQueue_'],_0x37d772),_0x5144ca['server_']['merge'](_0x5f0095['toString'](),_0x55bb9f,(_0x47c675,_0x26f8df)=>{const _0x58694d=_0x47c675==='ok';_0x58694d||U('update\x20at\x20'+_0x5f0095+'\x20failed:\x20'+_0x47c675);const _0x20ae84=_e(_0x5144ca['serverSyncTree_'],_0x5c24f0,!_0x58694d),_0x47f0da=_0x20ae84['length']>0x0?ct(_0x5144ca,_0x5f0095):_0x5f0095;V(_0x5144ca['eventQueue_'],_0x47f0da,_0x20ae84),be(_0x5144ca,_0x207d79,_0x47c675,_0x26f8df);}),x(_0x55bb9f,_0x1a654f=>{const _0x2fa903=Is(_0x5144ca,k(_0x5f0095,_0x1a654f));ct(_0x5144ca,_0x2fa903);}),V(_0x5144ca['eventQueue_'],_0x5f0095,[]);}}function Sd(_0x4157db){gt(_0x4157db,'onDisconnectEvents');const _0x4dbe59=Xt(_0x4157db),_0x2d7500=En();Si(_0x4157db['onDisconnect_'],w(),(_0x1bb6ca,_0x7db4ad)=>{const _0x52aa24=ta(_0x1bb6ca,_0x7db4ad,_0x4157db['serverSyncTree_'],_0x4dbe59);pt(_0x2d7500,_0x1bb6ca,_0x52aa24);});let _0x328ba6=[];Si(_0x2d7500,w(),(_0x5cd1b0,_0x3ab760)=>{_0x328ba6=_0x328ba6['concat'](Yt(_0x4157db['serverSyncTree_'],_0x5cd1b0,_0x3ab760));const _0x20d9f7=Is(_0x4157db,_0x5cd1b0);ct(_0x4157db,_0x20d9f7);}),_0x4157db['onDisconnect_']=En(),V(_0x4157db['eventQueue_'],w(),_0x328ba6);}function bd(_0x144319,_0x531a81,_0x4cfab3){_0x144319['server_']['onDisconnectCancel'](_0x531a81['toString'](),(_0x1a7188,_0x2de6f0)=>{_0x1a7188==='ok'&&Ti(_0x144319['onDisconnect_'],_0x531a81),be(_0x144319,_0x4cfab3,_0x1a7188,_0x2de6f0);});}function yr(_0x5edda1,_0x1cb221,_0x255afc,_0x42bdd3){const _0x180dce=A(_0x255afc);_0x5edda1['server_']['onDisconnectPut'](_0x1cb221['toString'](),_0x180dce['val'](!0x0),(_0x1f28dc,_0x4ad537)=>{_0x1f28dc==='ok'&&pt(_0x5edda1['onDisconnect_'],_0x1cb221,_0x180dce),be(_0x5edda1,_0x42bdd3,_0x1f28dc,_0x4ad537);});}function Rd(_0x3120e4,_0x4e28c1,_0x493b64,_0x10c069,_0x4d17a5){const _0x19a9f8=A(_0x493b64,_0x10c069);_0x3120e4['server_']['onDisconnectPut'](_0x4e28c1['toString'](),_0x19a9f8['val'](!0x0),(_0x4b497d,_0xeadd3c)=>{_0x4b497d==='ok'&&pt(_0x3120e4['onDisconnect_'],_0x4e28c1,_0x19a9f8),be(_0x3120e4,_0x4d17a5,_0x4b497d,_0xeadd3c);});}function Ad(_0x49f06f,_0x57b460,_0x23c3b8,_0x2a7ed7){if(pn(_0x23c3b8)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x49f06f,_0x2a7ed7,'ok',void 0x0);return;}_0x49f06f['server_']['onDisconnectMerge'](_0x57b460['toString'](),_0x23c3b8,(_0x465949,_0x4579d8)=>{_0x465949==='ok'&&x(_0x23c3b8,(_0x9c50bb,_0x51a14f)=>{const _0x2796f2=A(_0x51a14f);pt(_0x49f06f['onDisconnect_'],k(_0x57b460,_0x9c50bb),_0x2796f2);}),be(_0x49f06f,_0x2a7ed7,_0x465949,_0x4579d8);});}function kd(_0x3480cb,_0x4ce245,_0x2fb4c9){let _0xa701a2;y(_0x4ce245['_path'])==='.info'?_0xa701a2=Ni(_0x3480cb['infoSyncTree_'],_0x4ce245,_0x2fb4c9):_0xa701a2=Ni(_0x3480cb['serverSyncTree_'],_0x4ce245,_0x2fb4c9),oa(_0x3480cb['eventQueue_'],_0x4ce245['_path'],_0xa701a2);}function Pd(_0x219f41,_0x5a039c,_0x5a01f6){let _0x9abd0c;y(_0x5a039c['_path'])==='.info'?_0x9abd0c=An(_0x219f41['infoSyncTree_'],_0x5a039c,_0x5a01f6):_0x9abd0c=An(_0x219f41['serverSyncTree_'],_0x5a039c,_0x5a01f6),oa(_0x219f41['eventQueue_'],_0x5a039c['_path'],_0x9abd0c);}function ha(_0x388776){_0x388776['persistentConnection_']&&_0x388776['persistentConnection_']['interrupt'](ca);}function Nd(_0x4ab69a){_0x4ab69a['persistentConnection_']&&_0x4ab69a['persistentConnection_']['resume'](ca);}function gt(_0x538ebd,..._0x8eb0fd){let _0x50e3bc='';_0x538ebd['persistentConnection_']&&(_0x50e3bc=_0x538ebd['persistentConnection_']['id']+':'),L(_0x50e3bc,..._0x8eb0fd);}function be(_0x54996c,_0x113b9d,_0xa902e1,_0x435c26){_0x113b9d&&ft(()=>{if(_0xa902e1==='ok')_0x113b9d(null);else{const _0x948428=(_0xa902e1||'error')['toUpperCase']();let _0x252b9d=_0x948428;_0x435c26&&(_0x252b9d+=':\x20'+_0x435c26);const _0x3d8447=new Error(_0x252b9d);_0x3d8447['code']=_0x948428,_0x113b9d(_0x3d8447);}});}function Od(_0x20a71d,_0x36ef1a,_0x4712ec,_0x566aa7,_0x3a0c95,_0x2c25de){gt(_0x20a71d,'transaction\x20on\x20'+_0x36ef1a);const _0x2c9404={'path':_0x36ef1a,'update':_0x4712ec,'onComplete':_0x566aa7,'status':null,'order':so(),'applyLocally':_0x2c25de,'retryCount':0x0,'unwatcher':_0x3a0c95,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x315a5d=Es(_0x20a71d,_0x36ef1a,void 0x0);_0x2c9404['currentInputSnapshot']=_0x315a5d;const _0x173056=_0x2c9404['update'](_0x315a5d['val']());if(_0x173056===void 0x0)_0x2c9404['unwatcher'](),_0x2c9404['currentOutputSnapshotRaw']=null,_0x2c9404['currentOutputSnapshotResolved']=null,_0x2c9404['onComplete']&&_0x2c9404['onComplete'](null,!0x1,_0x2c9404['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x173056,_0x2c9404['path']),_0x2c9404['status']=0x0;const _0x16a194=$n(_0x20a71d['transactionQueueTree_'],_0x36ef1a),_0x53ea53=je(_0x16a194)||[];_0x53ea53['push'](_0x2c9404),gs(_0x16a194,_0x53ea53);let _0x567664;typeof _0x173056=='object'&&_0x173056!==null&&Q(_0x173056,'.priority')?(_0x567664=Le(_0x173056,'.priority'),f(Bt(_0x567664),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x567664=(Vn(_0x20a71d['serverSyncTree_'],_0x36ef1a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1cd3f8=Xt(_0x20a71d),_0x39148b=A(_0x173056,_0x567664),_0x310d04=fs(_0x39148b,_0x315a5d,_0x1cd3f8);_0x2c9404['currentOutputSnapshotRaw']=_0x39148b,_0x2c9404['currentOutputSnapshotResolved']=_0x310d04,_0x2c9404['currentWriteId']=zn(_0x20a71d);const _0x2072d7=as(_0x20a71d['serverSyncTree_'],_0x36ef1a,_0x310d04,_0x2c9404['currentWriteId'],_0x2c9404['applyLocally']);V(_0x20a71d['eventQueue_'],_0x36ef1a,_0x2072d7),jn(_0x20a71d,_0x20a71d['transactionQueueTree_']);}}function Es(_0x402885,_0x1b575b,_0x47ed4e){return Vn(_0x402885['serverSyncTree_'],_0x1b575b,_0x47ed4e)||g['EMPTY_NODE'];}function jn(_0x3b5f0f,_0x4e14c0=_0x3b5f0f['transactionQueueTree_']){if(_0x4e14c0||Kn(_0x3b5f0f,_0x4e14c0),je(_0x4e14c0)){const _0x20e1a4=da(_0x3b5f0f,_0x4e14c0);f(_0x20e1a4['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x20e1a4['every'](_0x9034bc=>_0x9034bc['status']===0x0)&&Dd(_0x3b5f0f,Qt(_0x4e14c0),_0x20e1a4);}else na(_0x4e14c0)&&Gn(_0x4e14c0,_0x4322c6=>{jn(_0x3b5f0f,_0x4322c6);});}function Dd(_0x46bebe,_0x2252d7,_0x1a744d){const _0x142eb5=_0x1a744d['map'](_0x2fcd1a=>_0x2fcd1a['currentWriteId']),_0xe92c26=Es(_0x46bebe,_0x2252d7,_0x142eb5);let _0x108814=_0xe92c26;const _0x3e32ef=_0xe92c26['hash']();for(let _0x15cd3e=0x0;_0x15cd3e<_0x1a744d['length'];_0x15cd3e++){const _0x1ff5cf=_0x1a744d[_0x15cd3e];f(_0x1ff5cf['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x1ff5cf['status']=0x1,_0x1ff5cf['retryCount']++;const _0x2f57f8=F(_0x2252d7,_0x1ff5cf['path']);_0x108814=_0x108814['updateChild'](_0x2f57f8,_0x1ff5cf['currentOutputSnapshotRaw']);}const _0x265715=_0x108814['val'](!0x0),_0x88f0be=_0x2252d7;_0x46bebe['server_']['put'](_0x88f0be['toString'](),_0x265715,_0x564e6d=>{gt(_0x46bebe,'transaction\x20put\x20response',{'path':_0x88f0be['toString'](),'status':_0x564e6d});let _0x37dde9=[];if(_0x564e6d==='ok'){const _0x38a4fb=[];for(let _0x26b9e4=0x0;_0x26b9e4<_0x1a744d['length'];_0x26b9e4++)_0x1a744d[_0x26b9e4]['status']=0x2,_0x37dde9=_0x37dde9['concat'](_e(_0x46bebe['serverSyncTree_'],_0x1a744d[_0x26b9e4]['currentWriteId'])),_0x1a744d[_0x26b9e4]['onComplete']&&_0x38a4fb['push'](()=>_0x1a744d[_0x26b9e4]['onComplete'](null,!0x0,_0x1a744d[_0x26b9e4]['currentOutputSnapshotResolved'])),_0x1a744d[_0x26b9e4]['unwatcher']();Kn(_0x46bebe,$n(_0x46bebe['transactionQueueTree_'],_0x2252d7)),jn(_0x46bebe,_0x46bebe['transactionQueueTree_']),V(_0x46bebe['eventQueue_'],_0x2252d7,_0x37dde9);for(let _0x372186=0x0;_0x372186<_0x38a4fb['length'];_0x372186++)ft(_0x38a4fb[_0x372186]);}else{if(_0x564e6d==='datastale'){for(let _0x133e49=0x0;_0x133e49<_0x1a744d['length'];_0x133e49++)_0x1a744d[_0x133e49]['status']===0x3?_0x1a744d[_0x133e49]['status']=0x4:_0x1a744d[_0x133e49]['status']=0x0;}else{U('transaction\x20at\x20'+_0x88f0be['toString']()+'\x20failed:\x20'+_0x564e6d);for(let _0x26c340=0x0;_0x26c340<_0x1a744d['length'];_0x26c340++)_0x1a744d[_0x26c340]['status']=0x4,_0x1a744d[_0x26c340]['abortReason']=_0x564e6d;}ct(_0x46bebe,_0x2252d7);}},_0x3e32ef);}function ct(_0x2bbbab,_0x109a72){const _0x3a31e4=ua(_0x2bbbab,_0x109a72),_0x5cb25a=Qt(_0x3a31e4),_0x3685b0=da(_0x2bbbab,_0x3a31e4);return Md(_0x2bbbab,_0x3685b0,_0x5cb25a),_0x5cb25a;}function Md(_0x32417e,_0x1c2345,_0x339978){if(_0x1c2345['length']===0x0)return;const _0x32ef6a=[];let _0x236651=[];const _0x449e7a=_0x1c2345['filter'](_0x4281e2=>_0x4281e2['status']===0x0)['map'](_0x325006=>_0x325006['currentWriteId']);for(let _0x3f0c80=0x0;_0x3f0c80<_0x1c2345['length'];_0x3f0c80++){const _0x1e486a=_0x1c2345[_0x3f0c80],_0x482430=F(_0x339978,_0x1e486a['path']);let _0x513202=!0x1,_0x13b1ff;if(f(_0x482430!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1e486a['status']===0x4)_0x513202=!0x0,_0x13b1ff=_0x1e486a['abortReason'],_0x236651=_0x236651['concat'](_e(_0x32417e['serverSyncTree_'],_0x1e486a['currentWriteId'],!0x0));else{if(_0x1e486a['status']===0x0){if(_0x1e486a['retryCount']>=yd)_0x513202=!0x0,_0x13b1ff='maxretry',_0x236651=_0x236651['concat'](_e(_0x32417e['serverSyncTree_'],_0x1e486a['currentWriteId'],!0x0));else{const _0x242031=Es(_0x32417e,_0x1e486a['path'],_0x449e7a);_0x1e486a['currentInputSnapshot']=_0x242031;const _0x36683c=_0x1c2345[_0x3f0c80]['update'](_0x242031['val']());if(_0x36683c!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x36683c,_0x1e486a['path']);let _0x36b4ab=A(_0x36683c);typeof _0x36683c=='object'&&_0x36683c!=null&&Q(_0x36683c,'.priority')||(_0x36b4ab=_0x36b4ab['updatePriority'](_0x242031['getPriority']()));const _0x1a85d3=_0x1e486a['currentWriteId'],_0x44dc76=Xt(_0x32417e),_0x2a6fa5=fs(_0x36b4ab,_0x242031,_0x44dc76);_0x1e486a['currentOutputSnapshotRaw']=_0x36b4ab,_0x1e486a['currentOutputSnapshotResolved']=_0x2a6fa5,_0x1e486a['currentWriteId']=zn(_0x32417e),_0x449e7a['splice'](_0x449e7a['indexOf'](_0x1a85d3),0x1),_0x236651=_0x236651['concat'](as(_0x32417e['serverSyncTree_'],_0x1e486a['path'],_0x2a6fa5,_0x1e486a['currentWriteId'],_0x1e486a['applyLocally'])),_0x236651=_0x236651['concat'](_e(_0x32417e['serverSyncTree_'],_0x1a85d3,!0x0));}else _0x513202=!0x0,_0x13b1ff='nodata',_0x236651=_0x236651['concat'](_e(_0x32417e['serverSyncTree_'],_0x1e486a['currentWriteId'],!0x0));}}}V(_0x32417e['eventQueue_'],_0x339978,_0x236651),_0x236651=[],_0x513202&&(_0x1c2345[_0x3f0c80]['status']=0x2,function(_0xda19d6){setTimeout(_0xda19d6,Math['floor'](0x0));}(_0x1c2345[_0x3f0c80]['unwatcher']),_0x1c2345[_0x3f0c80]['onComplete']&&(_0x13b1ff==='nodata'?_0x32ef6a['push'](()=>_0x1c2345[_0x3f0c80]['onComplete'](null,!0x1,_0x1c2345[_0x3f0c80]['currentInputSnapshot'])):_0x32ef6a['push'](()=>_0x1c2345[_0x3f0c80]['onComplete'](new Error(_0x13b1ff),!0x1,null))));}Kn(_0x32417e,_0x32417e['transactionQueueTree_']);for(let _0x34b787=0x0;_0x34b787<_0x32ef6a['length'];_0x34b787++)ft(_0x32ef6a[_0x34b787]);jn(_0x32417e,_0x32417e['transactionQueueTree_']);}function ua(_0x27e211,_0x3444f1){let _0x18e1ad,_0x404ead=_0x27e211['transactionQueueTree_'];for(_0x18e1ad=y(_0x3444f1);_0x18e1ad!==null&&je(_0x404ead)===void 0x0;)_0x404ead=$n(_0x404ead,_0x18e1ad),_0x3444f1=S(_0x3444f1),_0x18e1ad=y(_0x3444f1);return _0x404ead;}function da(_0x5167e8,_0x326cd6){const _0x20cbc6=[];return fa(_0x5167e8,_0x326cd6,_0x20cbc6),_0x20cbc6['sort']((_0x12d6e5,_0xa59a0)=>_0x12d6e5['order']-_0xa59a0['order']),_0x20cbc6;}function fa(_0x44df33,_0x559dcd,_0x372b67){const _0x21d2f2=je(_0x559dcd);if(_0x21d2f2){for(let _0xcdb29c=0x0;_0xcdb29c<_0x21d2f2['length'];_0xcdb29c++)_0x372b67['push'](_0x21d2f2[_0xcdb29c]);}Gn(_0x559dcd,_0x2562ee=>{fa(_0x44df33,_0x2562ee,_0x372b67);});}function Kn(_0xc854d5,_0x5a9f5a){const _0x52c6ab=je(_0x5a9f5a);if(_0x52c6ab){let _0x35bbd9=0x0;for(let _0x3c1344=0x0;_0x3c1344<_0x52c6ab['length'];_0x3c1344++)_0x52c6ab[_0x3c1344]['status']!==0x2&&(_0x52c6ab[_0x35bbd9]=_0x52c6ab[_0x3c1344],_0x35bbd9++);_0x52c6ab['length']=_0x35bbd9,gs(_0x5a9f5a,_0x52c6ab['length']>0x0?_0x52c6ab:void 0x0);}Gn(_0x5a9f5a,_0xf54c2f=>{Kn(_0xc854d5,_0xf54c2f);});}function Is(_0x30c47d,_0x25d15d){const _0x9523ed=Qt(ua(_0x30c47d,_0x25d15d)),_0x372660=$n(_0x30c47d['transactionQueueTree_'],_0x25d15d);return ad(_0x372660,_0x312f53=>{di(_0x30c47d,_0x312f53);}),di(_0x30c47d,_0x372660),ia(_0x372660,_0x133524=>{di(_0x30c47d,_0x133524);}),_0x9523ed;}function di(_0x2800d7,_0x3db436){const _0x283834=je(_0x3db436);if(_0x283834){const _0x5eb17e=[];let _0x2ff8ef=[],_0x2cee56=-0x1;for(let _0x850786=0x0;_0x850786<_0x283834['length'];_0x850786++)_0x283834[_0x850786]['status']===0x3||(_0x283834[_0x850786]['status']===0x1?(f(_0x2cee56===_0x850786-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2cee56=_0x850786,_0x283834[_0x850786]['status']=0x3,_0x283834[_0x850786]['abortReason']='set'):(f(_0x283834[_0x850786]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x283834[_0x850786]['unwatcher'](),_0x2ff8ef=_0x2ff8ef['concat'](_e(_0x2800d7['serverSyncTree_'],_0x283834[_0x850786]['currentWriteId'],!0x0)),_0x283834[_0x850786]['onComplete']&&_0x5eb17e['push'](_0x283834[_0x850786]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2cee56===-0x1?gs(_0x3db436,void 0x0):_0x283834['length']=_0x2cee56+0x1,V(_0x2800d7['eventQueue_'],Qt(_0x3db436),_0x2ff8ef);for(let _0x2f84b0=0x0;_0x2f84b0<_0x5eb17e['length'];_0x2f84b0++)ft(_0x5eb17e[_0x2f84b0]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x895f37){let _0x226958='';const _0x2c2d54=_0x895f37['split']('/');for(let _0x1ac984=0x0;_0x1ac984<_0x2c2d54['length'];_0x1ac984++)if(_0x2c2d54[_0x1ac984]['length']>0x0){let _0x17bedf=_0x2c2d54[_0x1ac984];try{_0x17bedf=decodeURIComponent(_0x17bedf['replace'](/\+/g,'\x20'));}catch{}_0x226958+='/'+_0x17bedf;}return _0x226958;}function xd(_0x100289){const _0xef5699={};_0x100289['charAt'](0x0)==='?'&&(_0x100289=_0x100289['substring'](0x1));for(const _0x533090 of _0x100289['split']('&')){if(_0x533090['length']===0x0)continue;const _0x2f9c17=_0x533090['split']('=');_0x2f9c17['length']===0x2?_0xef5699[decodeURIComponent(_0x2f9c17[0x0])]=decodeURIComponent(_0x2f9c17[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x533090+'\x27\x20in\x20query\x20\x27'+_0x100289+'\x27');}return _0xef5699;}const vr=function(_0x41a034,_0x2c79c6){const _0x47a822=Fd(_0x41a034),_0xb08c3e=_0x47a822['namespace'];_0x47a822['domain']==='firebase.com'&&ae(_0x47a822['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xb08c3e||_0xb08c3e==='undefined')&&_0x47a822['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x47a822['secure']||$l();const _0x196449=_0x47a822['scheme']==='ws'||_0x47a822['scheme']==='wss';return{'repoInfo':new yo(_0x47a822['host'],_0x47a822['secure'],_0xb08c3e,_0x196449,_0x2c79c6,'',_0xb08c3e!==_0x47a822['subdomain']),'path':new C(_0x47a822['pathString'])};},Fd=function(_0x28ca10){let _0x27fc08='',_0xa74982='',_0x5116d9='',_0x49b3bd='',_0x20ae67='',_0x269fd8=!0x0,_0x385bca='https',_0x55c20d=0x1bb;if(typeof _0x28ca10=='string'){let _0x409399=_0x28ca10['indexOf']('//');_0x409399>=0x0&&(_0x385bca=_0x28ca10['substring'](0x0,_0x409399-0x1),_0x28ca10=_0x28ca10['substring'](_0x409399+0x2));let _0x13d675=_0x28ca10['indexOf']('/');_0x13d675===-0x1&&(_0x13d675=_0x28ca10['length']);let _0x4552ac=_0x28ca10['indexOf']('?');_0x4552ac===-0x1&&(_0x4552ac=_0x28ca10['length']),_0x27fc08=_0x28ca10['substring'](0x0,Math['min'](_0x13d675,_0x4552ac)),_0x13d675<_0x4552ac&&(_0x49b3bd=Ld(_0x28ca10['substring'](_0x13d675,_0x4552ac)));const _0xbe913e=xd(_0x28ca10['substring'](Math['min'](_0x28ca10['length'],_0x4552ac)));_0x409399=_0x27fc08['indexOf'](':'),_0x409399>=0x0?(_0x269fd8=_0x385bca==='https'||_0x385bca==='wss',_0x55c20d=parseInt(_0x27fc08['substring'](_0x409399+0x1),0xa)):_0x409399=_0x27fc08['length'];const _0x5d12d9=_0x27fc08['slice'](0x0,_0x409399);if(_0x5d12d9['toLowerCase']()==='localhost')_0xa74982='localhost';else{if(_0x5d12d9['split']('.')['length']<=0x2)_0xa74982=_0x5d12d9;else{const _0x5d3257=_0x27fc08['indexOf']('.');_0x5116d9=_0x27fc08['substring'](0x0,_0x5d3257)['toLowerCase'](),_0xa74982=_0x27fc08['substring'](_0x5d3257+0x1),_0x20ae67=_0x5116d9;}}'ns'in _0xbe913e&&(_0x20ae67=_0xbe913e['ns']);}return{'host':_0x27fc08,'port':_0x55c20d,'domain':_0xa74982,'subdomain':_0x5116d9,'secure':_0x269fd8,'scheme':_0x385bca,'pathString':_0x49b3bd,'namespace':_0x20ae67};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x343a03=0x0;const _0x56a637=[];return function(_0x217450){const _0xe808e3=_0x217450===_0x343a03;_0x343a03=_0x217450;let _0x1021f7;const _0x2ed9d6=new Array(0x8);for(_0x1021f7=0x7;_0x1021f7>=0x0;_0x1021f7--)_0x2ed9d6[_0x1021f7]=Er['charAt'](_0x217450%0x40),_0x217450=Math['floor'](_0x217450/0x40);f(_0x217450===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x514efd=_0x2ed9d6['join']('');if(_0xe808e3){for(_0x1021f7=0xb;_0x1021f7>=0x0&&_0x56a637[_0x1021f7]===0x3f;_0x1021f7--)_0x56a637[_0x1021f7]=0x0;_0x56a637[_0x1021f7]++;}else{for(_0x1021f7=0x0;_0x1021f7<0xc;_0x1021f7++)_0x56a637[_0x1021f7]=Math['floor'](Math['random']()*0x40);}for(_0x1021f7=0x0;_0x1021f7<0xc;_0x1021f7++)_0x514efd+=Er['charAt'](_0x56a637[_0x1021f7]);return f(_0x514efd['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x514efd;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x33775c,_0x354004,_0x31e996,_0x39eeca){this['eventType']=_0x33775c,this['eventRegistration']=_0x354004,this['snapshot']=_0x31e996,this['prevName']=_0x39eeca;}['getPath'](){const _0x2f1f9b=this['snapshot']['ref'];return this['eventType']==='value'?_0x2f1f9b['_path']:_0x2f1f9b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x289f25,_0x5dd722,_0x2c02df){this['eventRegistration']=_0x289f25,this['error']=_0x5dd722,this['path']=_0x2c02df;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x36d6d8,_0x385202){this['snapshotCallback']=_0x36d6d8,this['cancelCallback']=_0x385202;}['onValue'](_0x115b75,_0x1c53e3){this['snapshotCallback']['call'](null,_0x115b75,_0x1c53e3);}['onCancel'](_0x4bc3df){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4bc3df);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1369c6){return this['snapshotCallback']===_0x1369c6['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1369c6['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1369c6['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3b8e69,_0x23f84a){this['_repo']=_0x3b8e69,this['_path']=_0x23f84a;}['cancel'](){const _0x298006=new H();return bd(this['_repo'],this['_path'],_0x298006['wrapCallback'](()=>{})),_0x298006['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x5572bf=new H();return yr(this['_repo'],this['_path'],null,_0x5572bf['wrapCallback'](()=>{})),_0x5572bf['promise'];}['set'](_0x52f78b){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x52f78b,this['_path'],!0x1);const _0x1ae1a8=new H();return yr(this['_repo'],this['_path'],_0x52f78b,_0x1ae1a8['wrapCallback'](()=>{})),_0x1ae1a8['promise'];}['setWithPriority'](_0x330208,_0x915c52){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x330208,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x915c52);const _0x4cee44=new H();return Rd(this['_repo'],this['_path'],_0x330208,_0x915c52,_0x4cee44['wrapCallback'](()=>{})),_0x4cee44['promise'];}['update'](_0x1c35a1){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1c35a1,this['_path']);const _0x37db46=new H();return Ad(this['_repo'],this['_path'],_0x1c35a1,_0x37db46['wrapCallback'](()=>{})),_0x37db46['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4e3768,_0x1e0f77,_0x4dbd04,_0x135013){this['_repo']=_0x4e3768,this['_path']=_0x1e0f77,this['_queryParams']=_0x4dbd04,this['_orderByCalled']=_0x135013;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5d002a=sr(this['_queryParams']),_0x4a50e0=$i(_0x5d002a);return _0x4a50e0==='{}'?'default':_0x4a50e0;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x101072){if(_0x101072=P(_0x101072),!(_0x101072 instanceof Ae))return!0x1;const _0x47f9fb=this['_repo']===_0x101072['_repo'],_0x36e222=Ki(this['_path'],_0x101072['_path']),_0x563639=this['_queryIdentifier']===_0x101072['_queryIdentifier'];return _0x47f9fb&&_0x36e222&&_0x563639;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x28e039,_0x3228c1){if(_0x28e039['_orderByCalled']===!0x0)throw new Error(_0x3228c1+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x284236){let _0x503e5b=null,_0x496f78=null;if(_0x284236['hasStart']()&&(_0x503e5b=_0x284236['getIndexStartValue']()),_0x284236['hasEnd']()&&(_0x496f78=_0x284236['getIndexEndValue']()),_0x284236['getIndex']()===ve){const _0x2f1312='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2616d9='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x284236['hasStart']()){if(_0x284236['getIndexStartName']()!==We)throw new Error(_0x2f1312);if(typeof _0x503e5b!='string')throw new Error(_0x2616d9);}if(_0x284236['hasEnd']()){if(_0x284236['getIndexEndName']()!==we)throw new Error(_0x2f1312);if(typeof _0x496f78!='string')throw new Error(_0x2616d9);}}else{if(_0x284236['getIndex']()===R){if(_0x503e5b!=null&&!Bt(_0x503e5b)||_0x496f78!=null&&!Bt(_0x496f78))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x284236['getIndex']()instanceof Ji||_0x284236['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x503e5b!=null&&typeof _0x503e5b=='object'||_0x496f78!=null&&typeof _0x496f78=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2320e9){if(_0x2320e9['hasStart']()&&_0x2320e9['hasEnd']()&&_0x2320e9['hasLimit']()&&!_0x2320e9['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5697b5,_0x317a7b){super(_0x5697b5,_0x317a7b,new Zi(),!0x1);}get['parent'](){const _0x419564=Ro(this['_path']);return _0x419564===null?null:new ee(this['_repo'],_0x419564);}get['root'](){let _0x542407=this;for(;_0x542407['parent']!==null;)_0x542407=_0x542407['parent'];return _0x542407;}}class lt{constructor(_0x4185c2,_0x593952,_0x5b2d34){this['_node']=_0x4185c2,this['ref']=_0x593952,this['_index']=_0x5b2d34;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5332f8){const _0x3e778d=new C(_0x5332f8),_0x185aa9=Vt(this['ref'],_0x5332f8);return new lt(this['_node']['getChild'](_0x3e778d),_0x185aa9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x17ad0){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2bed1a,_0x138459)=>_0x17ad0(new lt(_0x138459,Vt(this['ref'],_0x2bed1a),R)));}['hasChild'](_0x342840){const _0x18625a=new C(_0x342840);return!this['_node']['getChild'](_0x18625a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x29a5ff,_0x2c51b5){return _0x29a5ff=P(_0x29a5ff),_0x29a5ff['_checkNotDeleted']('ref'),_0x2c51b5!==void 0x0?Vt(_0x29a5ff['_root'],_0x2c51b5):_0x29a5ff['_root'];}function Vt(_0x11a719,_0x37a99c){return _0x11a719=P(_0x11a719),y(_0x11a719['_path'])===null?pd('child','path',_0x37a99c):ys('child','path',_0x37a99c),new ee(_0x11a719['_repo'],k(_0x11a719['_path'],_0x37a99c));}function v_(_0x284964){return _0x284964=P(_0x284964),new Vd(_0x284964['_repo'],_0x284964['_path']);}function E_(_0x4870e1,_0x26d08c){_0x4870e1=P(_0x4870e1),Me('push',_0x4870e1['_path']),He('push',_0x26d08c,_0x4870e1['_path'],!0x0);const _0x1ac64c=la(_0x4870e1['_repo']),_0x4c1e9f=Ud(_0x1ac64c),_0x4725ec=Vt(_0x4870e1,_0x4c1e9f),_0x3350ec=Vt(_0x4870e1,_0x4c1e9f);let _0x258bb6;return _0x26d08c!=null?_0x258bb6=Hd(_0x3350ec,_0x26d08c)['then'](()=>_0x3350ec):_0x258bb6=Promise['resolve'](_0x3350ec),_0x4725ec['then']=_0x258bb6['then']['bind'](_0x258bb6),_0x4725ec['catch']=_0x258bb6['then']['bind'](_0x258bb6,void 0x0),_0x4725ec;}function Hd(_0x556fd2,_0x2a05c4){_0x556fd2=P(_0x556fd2),Me('set',_0x556fd2['_path']),He('set',_0x2a05c4,_0x556fd2['_path'],!0x1);const _0x3c9910=new H();return Cd(_0x556fd2['_repo'],_0x556fd2['_path'],_0x2a05c4,null,_0x3c9910['wrapCallback'](()=>{})),_0x3c9910['promise'];}function I_(_0x15c0dd,_0x48282b){ra('update',_0x48282b,_0x15c0dd['_path']);const _0x26dc58=new H();return Td(_0x15c0dd['_repo'],_0x15c0dd['_path'],_0x48282b,_0x26dc58['wrapCallback'](()=>{})),_0x26dc58['promise'];}function w_(_0x2c3ccd){_0x2c3ccd=P(_0x2c3ccd);const _0x143196=new pa(()=>{}),_0x318225=new Qn(_0x143196);return wd(_0x2c3ccd['_repo'],_0x2c3ccd,_0x318225)['then'](_0x465466=>new lt(_0x465466,new ee(_0x2c3ccd['_repo'],_0x2c3ccd['_path']),_0x2c3ccd['_queryParams']['getIndex']()));}class Qn{constructor(_0xe15879){this['callbackContext']=_0xe15879;}['respondsTo'](_0x36cf83){return _0x36cf83==='value';}['createEvent'](_0x1e339c,_0x46ded2){const _0x2c1d95=_0x46ded2['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x1e339c['snapshotNode'],new ee(_0x46ded2['_repo'],_0x46ded2['_path']),_0x2c1d95));}['getEventRunner'](_0x287986){return _0x287986['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x287986['error']):()=>this['callbackContext']['onValue'](_0x287986['snapshot'],null);}['createCancelEvent'](_0xb50268,_0x2c0b0f){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xb50268,_0x2c0b0f):null;}['matches'](_0x2001e6){return _0x2001e6 instanceof Qn?!_0x2001e6['callbackContext']||!this['callbackContext']?!0x0:_0x2001e6['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x4be161,_0x40f1ec,_0x1d21d4,_0x6891f1,_0x50bea5){const _0x59a5a0=new pa(_0x1d21d4,void 0x0),_0x3e011f=new Qn(_0x59a5a0);return kd(_0x4be161['_repo'],_0x4be161,_0x3e011f),()=>Pd(_0x4be161['_repo'],_0x4be161,_0x3e011f);}function Gd(_0x455a58,_0x8b268a,_0x4866bd,_0x367639){return $d(_0x455a58,'value',_0x8b268a);}class mt{}class ma extends mt{constructor(_0x241c08,_0x447e01){super(),this['_value']=_0x241c08,this['_key']=_0x447e01,this['type']='endAt';}['_apply'](_0x57d390){He('endAt',this['_value'],_0x57d390['_path'],!0x0);const _0x2f138d=Jh(_0x57d390['_queryParams'],this['_value'],this['_key']);if(ga(_0x2f138d),Yn(_0x2f138d),_0x57d390['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x57d390['_repo'],_0x57d390['_path'],_0x2f138d,_0x57d390['_orderByCalled']);}}function C_(_0x204e2a,_0x784b41){return new ma(_0x204e2a,_0x784b41);}class ya extends mt{constructor(_0x4bbc5a,_0x4a0b1a){super(),this['_value']=_0x4bbc5a,this['_key']=_0x4a0b1a,this['type']='startAt';}['_apply'](_0x28bce3){He('startAt',this['_value'],_0x28bce3['_path'],!0x0);const _0x1fcfa2=Qh(_0x28bce3['_queryParams'],this['_value'],this['_key']);if(ga(_0x1fcfa2),Yn(_0x1fcfa2),_0x28bce3['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x28bce3['_repo'],_0x28bce3['_path'],_0x1fcfa2,_0x28bce3['_orderByCalled']);}}function T_(_0x36243d=null,_0x277eba){return new ya(_0x36243d,_0x277eba);}class qd extends mt{constructor(_0x576d4a){super(),this['_limit']=_0x576d4a,this['type']='limitToFirst';}['_apply'](_0x346a70){if(_0x346a70['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x346a70['_repo'],_0x346a70['_path'],Yh(_0x346a70['_queryParams'],this['_limit']),_0x346a70['_orderByCalled']);}}function S_(_0x1b672b){if(Math['floor'](_0x1b672b)!==_0x1b672b||_0x1b672b<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x1b672b);}class zd extends mt{constructor(_0x128788){super(),this['_path']=_0x128788,this['type']='orderByChild';}['_apply'](_0x36a60d){_a(_0x36a60d,'orderByChild');const _0x21d5c9=new C(this['_path']);if(v(_0x21d5c9))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2385f4=new Ji(_0x21d5c9),_0x4a457b=xo(_0x36a60d['_queryParams'],_0x2385f4);return Yn(_0x4a457b),new Ae(_0x36a60d['_repo'],_0x36a60d['_path'],_0x4a457b,!0x0);}}function b_(_0x3986f0){if(_0x3986f0==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3986f0==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3986f0==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x3986f0),new zd(_0x3986f0);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x5419fa){_a(_0x5419fa,'orderByKey');const _0x5556e9=xo(_0x5419fa['_queryParams'],ve);return Yn(_0x5556e9),new Ae(_0x5419fa['_repo'],_0x5419fa['_path'],_0x5556e9,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x40f3a0,_0x3a0717){super(),this['_value']=_0x40f3a0,this['_key']=_0x3a0717,this['type']='equalTo';}['_apply'](_0x398ca2){if(He('equalTo',this['_value'],_0x398ca2['_path'],!0x1),_0x398ca2['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x398ca2['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x398ca2));}}function A_(_0x4619b9,_0x105d89){return new Kd(_0x4619b9,_0x105d89);}function k_(_0x50b064,..._0xed6789){let _0x37255f=P(_0x50b064);for(const _0x438151 of _0xed6789)_0x37255f=_0x438151['_apply'](_0x37255f);return _0x37255f;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1ea11c,_0x4e7230,_0x40f6d6,_0x5ec0d1){const _0x39d1c8=_0x4e7230['lastIndexOf'](':'),_0x37d292=_0x4e7230['substring'](0x0,_0x39d1c8),_0x50aa56=qt(_0x37d292);_0x1ea11c['repoInfo_']=new yo(_0x4e7230,_0x50aa56,_0x1ea11c['repoInfo_']['namespace'],_0x1ea11c['repoInfo_']['webSocketOnly'],_0x1ea11c['repoInfo_']['nodeAdmin'],_0x1ea11c['repoInfo_']['persistenceKey'],_0x1ea11c['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x40f6d6),_0x5ec0d1&&(_0x1ea11c['authTokenProvider_']=_0x5ec0d1);}function Xd(_0x5c331e,_0x20ee49,_0x44b244,_0x45a5fa,_0x5e3da5){let _0x4927c4=_0x45a5fa||_0x5c331e['options']['databaseURL'];_0x4927c4===void 0x0&&(_0x5c331e['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5c331e['options']['projectId']),_0x4927c4=_0x5c331e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x164944=vr(_0x4927c4,_0x5e3da5),_0x2bf595=_0x164944['repoInfo'],_0x25aa04;typeof process<'u'&&Bs&&(_0x25aa04=Bs[Yd]),_0x25aa04?(_0x4927c4='http://'+_0x25aa04+'?ns='+_0x2bf595['namespace'],_0x164944=vr(_0x4927c4,_0x5e3da5),_0x2bf595=_0x164944['repoInfo']):_0x164944['repoInfo']['secure'];const _0x83593=new eh(_0x5c331e['name'],_0x5c331e['options'],_0x20ee49);_d('Invalid\x20Firebase\x20Database\x20URL',_0x164944),v(_0x164944['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x55404b=ef(_0x2bf595,_0x5c331e,_0x83593,new Zl(_0x5c331e,_0x44b244));return new tf(_0x55404b,_0x5c331e);}function Zd(_0x5106ea,_0x5a2f31){const _0x420471=Di[_0x5a2f31];(!_0x420471||_0x420471[_0x5106ea['key']]!==_0x5106ea)&&ae('Database\x20'+_0x5a2f31+'('+_0x5106ea['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x5106ea),delete _0x420471[_0x5106ea['key']];}function ef(_0x128868,_0x15344e,_0x4a7d25,_0x94ea05){let _0x3ffe5c=Di[_0x15344e['name']];_0x3ffe5c||(_0x3ffe5c={},Di[_0x15344e['name']]=_0x3ffe5c);let _0x4fadbf=_0x3ffe5c[_0x128868['toURLString']()];return _0x4fadbf&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4fadbf=new vd(_0x128868,Qd,_0x4a7d25,_0x94ea05),_0x3ffe5c[_0x128868['toURLString']()]=_0x4fadbf,_0x4fadbf;}class tf{constructor(_0x1c2742,_0x388545){this['_repoInternal']=_0x1c2742,this['app']=_0x388545,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1b2e5c){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x1b2e5c+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0xa6742c=Zr(),_0x485462){const _0x269408=Hi(_0xa6742c,'database')['getImmediate']({'identifier':_0x485462});if(!_0x269408['_instanceStarted']){const _0xa9728b=hc('database');_0xa9728b&&nf(_0x269408,..._0xa9728b);}return _0x269408;}function nf(_0x5a6024,_0x105aa0,_0x9a33c8,_0x1ab56a={}){_0x5a6024=P(_0x5a6024),_0x5a6024['_checkNotDeleted']('useEmulator');const _0x362ff6=_0x105aa0+':'+_0x9a33c8,_0x5daba7=_0x5a6024['_repoInternal'];if(_0x5a6024['_instanceStarted']){if(_0x362ff6===_0x5a6024['_repoInternal']['repoInfo_']['host']&&xe(_0x1ab56a,_0x5daba7['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x387e55;if(_0x5daba7['repoInfo_']['nodeAdmin'])_0x1ab56a['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x387e55=new an(an['OWNER']);else{if(_0x1ab56a['mockUserToken']){const _0x4fc50b=typeof _0x1ab56a['mockUserToken']=='string'?_0x1ab56a['mockUserToken']:uc(_0x1ab56a['mockUserToken'],_0x5a6024['app']['options']['projectId']);_0x387e55=new an(_0x4fc50b);}}qt(_0x105aa0)&&Qr(_0x105aa0),Jd(_0x5daba7,_0x362ff6,_0x1ab56a,_0x387e55);}function N_(_0x3f3c0b){_0x3f3c0b=P(_0x3f3c0b),_0x3f3c0b['_checkNotDeleted']('goOffline'),ha(_0x3f3c0b['_repo']);}function O_(_0x3a2cc6){_0x3a2cc6=P(_0x3a2cc6),_0x3a2cc6['_checkNotDeleted']('goOnline'),Nd(_0x3a2cc6['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x11dfb2){Ul(dt),st(new Fe('database',(_0x3477e2,{instanceIdentifier:_0x27c43a})=>{const _0x265a62=_0x3477e2['getProvider']('app')['getImmediate'](),_0x105bc0=_0x3477e2['getProvider']('auth-internal'),_0x14792b=_0x3477e2['getProvider']('app-check-internal');return Xd(_0x265a62,_0x105bc0,_0x14792b,_0x27c43a);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x11dfb2),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x580940,_0x5143a5){this['committed']=_0x580940,this['snapshot']=_0x5143a5;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x3d273a,_0x353a23,_0x225e11){if(_0x3d273a=P(_0x3d273a),Me('Reference.transaction',_0x3d273a['_path']),_0x3d273a['key']==='.length'||_0x3d273a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3d273a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x231b5a=!0x0,_0x5b383b=new H(),_0x2a5b14=(_0x51d212,_0x3bf26c,_0x29344d)=>{let _0x354909=null;_0x51d212?_0x5b383b['reject'](_0x51d212):(_0x354909=new lt(_0x29344d,new ee(_0x3d273a['_repo'],_0x3d273a['_path']),R),_0x5b383b['resolve'](new of(_0x3bf26c,_0x354909)));},_0x3e7f04=Gd(_0x3d273a,()=>{});return Od(_0x3d273a['_repo'],_0x3d273a['_path'],_0x353a23,_0x2a5b14,_0x3e7f04,_0x231b5a),_0x5b383b['promise'];}se['prototype']['simpleListen']=function(_0xd4aa89,_0x4b0023){this['sendRequest']('q',{'p':_0xd4aa89},_0x4b0023);},se['prototype']['echo']=function(_0x227ca9,_0x3b1e9a){this['sendRequest']('echo',{'d':_0x227ca9},_0x3b1e9a);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x205955,..._0x1cea75){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x205955,..._0x1cea75);}function cn(_0x4743b4,..._0x1905f3){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x4743b4,..._0x1905f3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x491184,..._0x1aac1d){throw ws(_0x491184,..._0x1aac1d);}function X(_0x5bceb1,..._0x5481c0){return ws(_0x5bceb1,..._0x5481c0);}function Ia(_0x99ce3a,_0x30f87c,_0x176334){const _0xaaf17b={...af(),[_0x30f87c]:_0x176334};return new Gt('auth','Firebase',_0xaaf17b)['create'](_0x30f87c,{'appName':_0x99ce3a['name']});}function re(_0x36c83f){return Ia(_0x36c83f,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x3881dd,..._0x12a743){if(typeof _0x3881dd!='string'){const _0x3aa887=_0x12a743[0x0],_0x5487a8=[..._0x12a743['slice'](0x1)];return _0x5487a8[0x0]&&(_0x5487a8[0x0]['appName']=_0x3881dd['name']),_0x3881dd['_errorFactory']['create'](_0x3aa887,..._0x5487a8);}return Ea['create'](_0x3881dd,..._0x12a743);}function m(_0x30f413,_0x4062df,..._0x3ef1bf){if(!_0x30f413)throw ws(_0x4062df,..._0x3ef1bf);}function ne(_0x366090){const _0x31518b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x366090;throw cn(_0x31518b),new Error(_0x31518b);}function ce(_0x4bbd4e,_0x2a7fac){_0x4bbd4e||ne(_0x2a7fac);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x38593e;return typeof self<'u'&&((_0x38593e=self['location'])==null?void 0x0:_0x38593e['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5b40a7;return typeof self<'u'&&((_0x5b40a7=self['location'])==null?void 0x0:_0x5b40a7['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5064f6=navigator;return _0x5064f6['languages']&&_0x5064f6['languages'][0x0]||_0x5064f6['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x16fdb3,_0x4df284){this['shortDelay']=_0x16fdb3,this['longDelay']=_0x4df284,ce(_0x4df284>_0x16fdb3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2396e1,_0xab2827){ce(_0x2396e1['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5be3c0}=_0x2396e1['emulator'];return _0xab2827?''+_0x5be3c0+(_0xab2827['startsWith']('/')?_0xab2827['slice'](0x1):_0xab2827):_0x5be3c0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x27fb5c,_0x3e01a5,_0x5671c8){this['fetchImpl']=_0x27fb5c,_0x3e01a5&&(this['headersImpl']=_0x3e01a5),_0x5671c8&&(this['responseImpl']=_0x5671c8);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x24f403,_0x5ed6a2){return _0x24f403['tenantId']&&!_0x5ed6a2['tenantId']?{..._0x5ed6a2,'tenantId':_0x24f403['tenantId']}:_0x5ed6a2;}async function Pe(_0x5b4ab5,_0x525c70,_0x474d26,_0x382b1f,_0x26517f={}){return Ca(_0x5b4ab5,_0x26517f,async()=>{let _0x4e561b={},_0x562fe7={};_0x382b1f&&(_0x525c70==='GET'?_0x562fe7=_0x382b1f:_0x4e561b={'body':JSON['stringify'](_0x382b1f)});const _0x38115a=ut({..._0x562fe7,'key':_0x5b4ab5['config']['apiKey']})['slice'](0x1),_0x34649b=await _0x5b4ab5['_getAdditionalHeaders']();_0x34649b['Content-Type']='application/json',_0x5b4ab5['languageCode']&&(_0x34649b['X-Firebase-Locale']=_0x5b4ab5['languageCode']);const _0xb52f6={'method':_0x525c70,'headers':_0x34649b,..._0x4e561b};return dc()||(_0xb52f6['referrerPolicy']='strict-origin-when-cross-origin'),_0x5b4ab5['emulatorConfig']&&qt(_0x5b4ab5['emulatorConfig']['host'])&&(_0xb52f6['credentials']='include'),wa['fetch']()(await Ta(_0x5b4ab5,_0x5b4ab5['config']['apiHost'],_0x474d26,_0x38115a),_0xb52f6);});}async function Ca(_0x4efc87,_0x560bce,_0xb4b90a){_0x4efc87['_canInitEmulator']=!0x1;const _0x10913d={...df,..._0x560bce};try{const _0x248cb2=new gf(_0x4efc87),_0x18b03f=await Promise['race']([_0xb4b90a(),_0x248cb2['promise']]);_0x248cb2['clearNetworkTimeout']();const _0x45ec40=await _0x18b03f['json']();if('needConfirmation'in _0x45ec40)throw on(_0x4efc87,'account-exists-with-different-credential',_0x45ec40);if(_0x18b03f['ok']&&!('errorMessage'in _0x45ec40))return _0x45ec40;{const _0x8e0dc6=_0x18b03f['ok']?_0x45ec40['errorMessage']:_0x45ec40['error']['message'],[_0x254cdd,_0x2c4c9d]=_0x8e0dc6['split']('\x20:\x20');if(_0x254cdd==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x4efc87,'credential-already-in-use',_0x45ec40);if(_0x254cdd==='EMAIL_EXISTS')throw on(_0x4efc87,'email-already-in-use',_0x45ec40);if(_0x254cdd==='USER_DISABLED')throw on(_0x4efc87,'user-disabled',_0x45ec40);const _0x1447a6=_0x10913d[_0x254cdd]||_0x254cdd['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2c4c9d)throw Ia(_0x4efc87,_0x1447a6,_0x2c4c9d);Y(_0x4efc87,_0x1447a6);}}catch(_0x502b7b){if(_0x502b7b instanceof Re)throw _0x502b7b;Y(_0x4efc87,'network-request-failed',{'message':String(_0x502b7b)});}}async function en(_0x2c1d26,_0x52e636,_0x28c7a1,_0x1a8a8e,_0x12a399={}){const _0xc23316=await Pe(_0x2c1d26,_0x52e636,_0x28c7a1,_0x1a8a8e,_0x12a399);return'mfaPendingCredential'in _0xc23316&&Y(_0x2c1d26,'multi-factor-auth-required',{'_serverResponse':_0xc23316}),_0xc23316;}async function Ta(_0x4036df,_0x14e9a8,_0xee1bda,_0x16db5b){const _0x4135de=''+_0x14e9a8+_0xee1bda+'?'+_0x16db5b,_0x1baa36=_0x4036df,_0x52eb2d=_0x1baa36['config']['emulator']?Cs(_0x4036df['config'],_0x4135de):_0x4036df['config']['apiScheme']+'://'+_0x4135de;return ff['includes'](_0xee1bda)&&(await _0x1baa36['_persistenceManagerAvailable'],_0x1baa36['_getPersistenceType']()==='COOKIE')?_0x1baa36['_getPersistence']()['_getFinalTarget'](_0x52eb2d)['toString']():_0x52eb2d;}function _f(_0x381b3b){switch(_0x381b3b){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5d9adb){this['auth']=_0x5d9adb,this['timer']=null,this['promise']=new Promise((_0x361e1c,_0x42d0c7)=>{this['timer']=setTimeout(()=>_0x42d0c7(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x40474c,_0x84c810,_0x207d90){const _0x49969b={'appName':_0x40474c['name']};_0x207d90['email']&&(_0x49969b['email']=_0x207d90['email']),_0x207d90['phoneNumber']&&(_0x49969b['phoneNumber']=_0x207d90['phoneNumber']);const _0x2349e4=X(_0x40474c,_0x84c810,_0x49969b);return _0x2349e4['customData']['_tokenResponse']=_0x207d90,_0x2349e4;}function wr(_0x3dc74f){return _0x3dc74f!==void 0x0&&_0x3dc74f['enterprise']!==void 0x0;}class mf{constructor(_0x5c414f){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5c414f['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5c414f['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5c414f['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4c0443){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3d1c8e of this['recaptchaEnforcementState'])if(_0x3d1c8e['provider']&&_0x3d1c8e['provider']===_0x4c0443)return _f(_0x3d1c8e['enforcementState']);return null;}['isProviderEnabled'](_0x3b1615){return this['getProviderEnforcementState'](_0x3b1615)==='ENFORCE'||this['getProviderEnforcementState'](_0x3b1615)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0xfe0e56,_0x5895af){return Pe(_0xfe0e56,'GET','/v2/recaptchaConfig',ke(_0xfe0e56,_0x5895af));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x5d43df,_0xecec4d){return Pe(_0x5d43df,'POST','/v1/accounts:delete',_0xecec4d);}async function Pn(_0x3131bc,_0x4ae9b2){return Pe(_0x3131bc,'POST','/v1/accounts:lookup',_0x4ae9b2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x2c36ac){if(_0x2c36ac)try{const _0x262b5b=new Date(Number(_0x2c36ac));if(!isNaN(_0x262b5b['getTime']()))return _0x262b5b['toUTCString']();}catch{}}async function Ef(_0x1ddf34,_0x438b30=!0x1){const _0x49a953=P(_0x1ddf34),_0x728c9a=await _0x49a953['getIdToken'](_0x438b30),_0x35385d=Ts(_0x728c9a);m(_0x35385d&&_0x35385d['exp']&&_0x35385d['auth_time']&&_0x35385d['iat'],_0x49a953['auth'],'internal-error');const _0x2b760b=typeof _0x35385d['firebase']=='object'?_0x35385d['firebase']:void 0x0,_0x266c0a=_0x2b760b==null?void 0x0:_0x2b760b['sign_in_provider'];return{'claims':_0x35385d,'token':_0x728c9a,'authTime':Pt(fi(_0x35385d['auth_time'])),'issuedAtTime':Pt(fi(_0x35385d['iat'])),'expirationTime':Pt(fi(_0x35385d['exp'])),'signInProvider':_0x266c0a||null,'signInSecondFactor':(_0x2b760b==null?void 0x0:_0x2b760b['sign_in_second_factor'])||null};}function fi(_0x381ec8){return Number(_0x381ec8)*0x3e8;}function Ts(_0x4019a2){const [_0x5e4bda,_0x3e038b,_0x1af711]=_0x4019a2['split']('.');if(_0x5e4bda===void 0x0||_0x3e038b===void 0x0||_0x1af711===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4c61a0=fn(_0x3e038b);return _0x4c61a0?JSON['parse'](_0x4c61a0):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x471721){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x471721==null?void 0x0:_0x471721['toString']()),null;}}function Cr(_0x210e9f){const _0x1a420a=Ts(_0x210e9f);return m(_0x1a420a,'internal-error'),m(typeof _0x1a420a['exp']<'u','internal-error'),m(typeof _0x1a420a['iat']<'u','internal-error'),Number(_0x1a420a['exp'])-Number(_0x1a420a['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x22b4b3,_0x2bc63c,_0x13f76c=!0x1){if(_0x13f76c)return _0x2bc63c;try{return await _0x2bc63c;}catch(_0x1a2f3e){throw _0x1a2f3e instanceof Re&&If(_0x1a2f3e)&&_0x22b4b3['auth']['currentUser']===_0x22b4b3&&await _0x22b4b3['auth']['signOut'](),_0x1a2f3e;}}function If({code:_0x5cdf7a}){return _0x5cdf7a==='auth/user-disabled'||_0x5cdf7a==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2c318f){this['user']=_0x2c318f,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x54bf14){if(_0x54bf14){const _0x590abe=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x590abe;}else{this['errorBackoff']=0x7530;const _0x3fb56d=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3fb56d);}}['schedule'](_0x15fc45=!0x1){if(!this['isRunning'])return;const _0x2335c9=this['getInterval'](_0x15fc45);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2335c9);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x59ad6a){(_0x59ad6a==null?void 0x0:_0x59ad6a['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x549168,_0x2a29a6){this['createdAt']=_0x549168,this['lastLoginAt']=_0x2a29a6,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x854b8a){this['createdAt']=_0x854b8a['createdAt'],this['lastLoginAt']=_0x854b8a['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x252507){var _0x43fe23;const _0x44aa77=_0x252507['auth'],_0x1cd25e=await _0x252507['getIdToken'](),_0x3435f6=await Ht(_0x252507,Pn(_0x44aa77,{'idToken':_0x1cd25e}));m(_0x3435f6==null?void 0x0:_0x3435f6['users']['length'],_0x44aa77,'internal-error');const _0x3a7ea3=_0x3435f6['users'][0x0];_0x252507['_notifyReloadListener'](_0x3a7ea3);const _0x3a1345=(_0x43fe23=_0x3a7ea3['providerUserInfo'])!=null&&_0x43fe23['length']?Sa(_0x3a7ea3['providerUserInfo']):[],_0x3a34f9=Tf(_0x252507['providerData'],_0x3a1345),_0x17ce19=_0x252507['isAnonymous'],_0x54587d=!(_0x252507['email']&&_0x3a7ea3['passwordHash'])&&!(_0x3a34f9!=null&&_0x3a34f9['length']),_0x106e99=_0x17ce19?_0x54587d:!0x1,_0xd4fd66={'uid':_0x3a7ea3['localId'],'displayName':_0x3a7ea3['displayName']||null,'photoURL':_0x3a7ea3['photoUrl']||null,'email':_0x3a7ea3['email']||null,'emailVerified':_0x3a7ea3['emailVerified']||!0x1,'phoneNumber':_0x3a7ea3['phoneNumber']||null,'tenantId':_0x3a7ea3['tenantId']||null,'providerData':_0x3a34f9,'metadata':new Li(_0x3a7ea3['createdAt'],_0x3a7ea3['lastLoginAt']),'isAnonymous':_0x106e99};Object['assign'](_0x252507,_0xd4fd66);}async function Cf(_0x1a9a15){const _0x2871dd=P(_0x1a9a15);await Nn(_0x2871dd),await _0x2871dd['auth']['_persistUserIfCurrent'](_0x2871dd),_0x2871dd['auth']['_notifyListenersIfCurrent'](_0x2871dd);}function Tf(_0x55526d,_0x68c04b){return[..._0x55526d['filter'](_0x56ccb1=>!_0x68c04b['some'](_0x3e6eca=>_0x3e6eca['providerId']===_0x56ccb1['providerId'])),..._0x68c04b];}function Sa(_0x2d560b){return _0x2d560b['map'](({providerId:_0x3bf777,..._0x345363})=>({'providerId':_0x3bf777,'uid':_0x345363['rawId']||'','displayName':_0x345363['displayName']||null,'email':_0x345363['email']||null,'phoneNumber':_0x345363['phoneNumber']||null,'photoURL':_0x345363['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4638b4,_0xed0b58){const _0x22b22f=await Ca(_0x4638b4,{},async()=>{const _0x584f08=ut({'grant_type':'refresh_token','refresh_token':_0xed0b58})['slice'](0x1),{tokenApiHost:_0x331994,apiKey:_0x1717e7}=_0x4638b4['config'],_0x42ab9b=await Ta(_0x4638b4,_0x331994,'/v1/token','key='+_0x1717e7),_0x5a3116=await _0x4638b4['_getAdditionalHeaders']();_0x5a3116['Content-Type']='application/x-www-form-urlencoded';const _0x562f7a={'method':'POST','headers':_0x5a3116,'body':_0x584f08};return _0x4638b4['emulatorConfig']&&qt(_0x4638b4['emulatorConfig']['host'])&&(_0x562f7a['credentials']='include'),wa['fetch']()(_0x42ab9b,_0x562f7a);});return{'accessToken':_0x22b22f['access_token'],'expiresIn':_0x22b22f['expires_in'],'refreshToken':_0x22b22f['refresh_token']};}async function bf(_0x41eba9,_0x546223){return Pe(_0x41eba9,'POST','/v2/accounts:revokeToken',ke(_0x41eba9,_0x546223));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x68e981){m(_0x68e981['idToken'],'internal-error'),m(typeof _0x68e981['idToken']<'u','internal-error'),m(typeof _0x68e981['refreshToken']<'u','internal-error');const _0x3b4ad1='expiresIn'in _0x68e981&&typeof _0x68e981['expiresIn']<'u'?Number(_0x68e981['expiresIn']):Cr(_0x68e981['idToken']);this['updateTokensAndExpiration'](_0x68e981['idToken'],_0x68e981['refreshToken'],_0x3b4ad1);}['updateFromIdToken'](_0x4c186a){m(_0x4c186a['length']!==0x0,'internal-error');const _0x3cc619=Cr(_0x4c186a);this['updateTokensAndExpiration'](_0x4c186a,null,_0x3cc619);}async['getToken'](_0x47a465,_0x1da6ef=!0x1){return!_0x1da6ef&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x47a465,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x47a465,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4ab5b3,_0x513cbc){const {accessToken:_0x31fc15,refreshToken:_0x19d33c,expiresIn:_0x265075}=await Sf(_0x4ab5b3,_0x513cbc);this['updateTokensAndExpiration'](_0x31fc15,_0x19d33c,Number(_0x265075));}['updateTokensAndExpiration'](_0x2036d6,_0x5e43ef,_0x795a20){this['refreshToken']=_0x5e43ef||null,this['accessToken']=_0x2036d6||null,this['expirationTime']=Date['now']()+_0x795a20*0x3e8;}static['fromJSON'](_0x29219b,_0x15ee04){const {refreshToken:_0x5d85ac,accessToken:_0x5109ef,expirationTime:_0x3c78a8}=_0x15ee04,_0x15e9db=new et();return _0x5d85ac&&(m(typeof _0x5d85ac=='string','internal-error',{'appName':_0x29219b}),_0x15e9db['refreshToken']=_0x5d85ac),_0x5109ef&&(m(typeof _0x5109ef=='string','internal-error',{'appName':_0x29219b}),_0x15e9db['accessToken']=_0x5109ef),_0x3c78a8&&(m(typeof _0x3c78a8=='number','internal-error',{'appName':_0x29219b}),_0x15e9db['expirationTime']=_0x3c78a8),_0x15e9db;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5131b8){this['accessToken']=_0x5131b8['accessToken'],this['refreshToken']=_0x5131b8['refreshToken'],this['expirationTime']=_0x5131b8['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2c142b,_0x32beaf){m(typeof _0x2c142b=='string'||typeof _0x2c142b>'u','internal-error',{'appName':_0x32beaf});}class j{constructor({uid:_0x5c8642,auth:_0x5869bd,stsTokenManager:_0x28c31e,..._0x352b85}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5c8642,this['auth']=_0x5869bd,this['stsTokenManager']=_0x28c31e,this['accessToken']=_0x28c31e['accessToken'],this['displayName']=_0x352b85['displayName']||null,this['email']=_0x352b85['email']||null,this['emailVerified']=_0x352b85['emailVerified']||!0x1,this['phoneNumber']=_0x352b85['phoneNumber']||null,this['photoURL']=_0x352b85['photoURL']||null,this['isAnonymous']=_0x352b85['isAnonymous']||!0x1,this['tenantId']=_0x352b85['tenantId']||null,this['providerData']=_0x352b85['providerData']?[..._0x352b85['providerData']]:[],this['metadata']=new Li(_0x352b85['createdAt']||void 0x0,_0x352b85['lastLoginAt']||void 0x0);}async['getIdToken'](_0x228cca){const _0x59808a=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x228cca));return m(_0x59808a,this['auth'],'internal-error'),this['accessToken']!==_0x59808a&&(this['accessToken']=_0x59808a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x59808a;}['getIdTokenResult'](_0x36b4b3){return Ef(this,_0x36b4b3);}['reload'](){return Cf(this);}['_assign'](_0x26c469){this!==_0x26c469&&(m(this['uid']===_0x26c469['uid'],this['auth'],'internal-error'),this['displayName']=_0x26c469['displayName'],this['photoURL']=_0x26c469['photoURL'],this['email']=_0x26c469['email'],this['emailVerified']=_0x26c469['emailVerified'],this['phoneNumber']=_0x26c469['phoneNumber'],this['isAnonymous']=_0x26c469['isAnonymous'],this['tenantId']=_0x26c469['tenantId'],this['providerData']=_0x26c469['providerData']['map'](_0x67b31b=>({..._0x67b31b})),this['metadata']['_copy'](_0x26c469['metadata']),this['stsTokenManager']['_assign'](_0x26c469['stsTokenManager']));}['_clone'](_0x36e061){const _0xdb5b36=new j({...this,'auth':_0x36e061,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xdb5b36['metadata']['_copy'](this['metadata']),_0xdb5b36;}['_onReload'](_0x4b289b){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x4b289b,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x55f0e6){this['reloadListener']?this['reloadListener'](_0x55f0e6):this['reloadUserInfo']=_0x55f0e6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5cf7fa,_0x1bf629=!0x1){let _0xb3bfe=!0x1;_0x5cf7fa['idToken']&&_0x5cf7fa['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5cf7fa),_0xb3bfe=!0x0),_0x1bf629&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0xb3bfe&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2b85c2=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x2b85c2})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4b13fe=>({..._0x4b13fe})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x110a75,_0x165c7e){const _0x32ff29=_0x165c7e['displayName']??void 0x0,_0xceb5d4=_0x165c7e['email']??void 0x0,_0x254a1c=_0x165c7e['phoneNumber']??void 0x0,_0x264b72=_0x165c7e['photoURL']??void 0x0,_0x44973c=_0x165c7e['tenantId']??void 0x0,_0x13ebc2=_0x165c7e['_redirectEventId']??void 0x0,_0x57088f=_0x165c7e['createdAt']??void 0x0,_0x5cb2a9=_0x165c7e['lastLoginAt']??void 0x0,{uid:_0x56989b,emailVerified:_0x53792c,isAnonymous:_0x22ea3e,providerData:_0x24c3f8,stsTokenManager:_0x908fd3}=_0x165c7e;m(_0x56989b&&_0x908fd3,_0x110a75,'internal-error');const _0x19b360=et['fromJSON'](this['name'],_0x908fd3);m(typeof _0x56989b=='string',_0x110a75,'internal-error'),le(_0x32ff29,_0x110a75['name']),le(_0xceb5d4,_0x110a75['name']),m(typeof _0x53792c=='boolean',_0x110a75,'internal-error'),m(typeof _0x22ea3e=='boolean',_0x110a75,'internal-error'),le(_0x254a1c,_0x110a75['name']),le(_0x264b72,_0x110a75['name']),le(_0x44973c,_0x110a75['name']),le(_0x13ebc2,_0x110a75['name']),le(_0x57088f,_0x110a75['name']),le(_0x5cb2a9,_0x110a75['name']);const _0x5dfc77=new j({'uid':_0x56989b,'auth':_0x110a75,'email':_0xceb5d4,'emailVerified':_0x53792c,'displayName':_0x32ff29,'isAnonymous':_0x22ea3e,'photoURL':_0x264b72,'phoneNumber':_0x254a1c,'tenantId':_0x44973c,'stsTokenManager':_0x19b360,'createdAt':_0x57088f,'lastLoginAt':_0x5cb2a9});return _0x24c3f8&&Array['isArray'](_0x24c3f8)&&(_0x5dfc77['providerData']=_0x24c3f8['map'](_0x2b280f=>({..._0x2b280f}))),_0x13ebc2&&(_0x5dfc77['_redirectEventId']=_0x13ebc2),_0x5dfc77;}static async['_fromIdTokenResponse'](_0x5bf8a9,_0x3b5ca0,_0x343b04=!0x1){const _0x2dd2cc=new et();_0x2dd2cc['updateFromServerResponse'](_0x3b5ca0);const _0x50ad2f=new j({'uid':_0x3b5ca0['localId'],'auth':_0x5bf8a9,'stsTokenManager':_0x2dd2cc,'isAnonymous':_0x343b04});return await Nn(_0x50ad2f),_0x50ad2f;}static async['_fromGetAccountInfoResponse'](_0x356c2d,_0x51880d,_0xedaf64){const _0x4672ad=_0x51880d['users'][0x0];m(_0x4672ad['localId']!==void 0x0,'internal-error');const _0x3ff2b6=_0x4672ad['providerUserInfo']!==void 0x0?Sa(_0x4672ad['providerUserInfo']):[],_0x2e9e86=!(_0x4672ad['email']&&_0x4672ad['passwordHash'])&&!(_0x3ff2b6!=null&&_0x3ff2b6['length']),_0x30ff97=new et();_0x30ff97['updateFromIdToken'](_0xedaf64);const _0x1bb20c=new j({'uid':_0x4672ad['localId'],'auth':_0x356c2d,'stsTokenManager':_0x30ff97,'isAnonymous':_0x2e9e86}),_0x548a87={'uid':_0x4672ad['localId'],'displayName':_0x4672ad['displayName']||null,'photoURL':_0x4672ad['photoUrl']||null,'email':_0x4672ad['email']||null,'emailVerified':_0x4672ad['emailVerified']||!0x1,'phoneNumber':_0x4672ad['phoneNumber']||null,'tenantId':_0x4672ad['tenantId']||null,'providerData':_0x3ff2b6,'metadata':new Li(_0x4672ad['createdAt'],_0x4672ad['lastLoginAt']),'isAnonymous':!(_0x4672ad['email']&&_0x4672ad['passwordHash'])&&!(_0x3ff2b6!=null&&_0x3ff2b6['length'])};return Object['assign'](_0x1bb20c,_0x548a87),_0x1bb20c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5d5844){ce(_0x5d5844 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x432259=Tr['get'](_0x5d5844);return _0x432259?(ce(_0x432259 instanceof _0x5d5844,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x432259):(_0x432259=new _0x5d5844(),Tr['set'](_0x5d5844,_0x432259),_0x432259);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1a4ffd,_0x3f48c1){this['storage'][_0x1a4ffd]=_0x3f48c1;}async['_get'](_0x591cf6){const _0x4d805f=this['storage'][_0x591cf6];return _0x4d805f===void 0x0?null:_0x4d805f;}async['_remove'](_0x5210f1){delete this['storage'][_0x5210f1];}['_addListener'](_0xd3c985,_0x3228ab){}['_removeListener'](_0x58b8a5,_0x5214ad){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x2b057f,_0x4343ad,_0xc0e7a2){return'firebase:'+_0x2b057f+':'+_0x4343ad+':'+_0xc0e7a2;}class tt{constructor(_0x4648d7,_0x403a7c,_0x179064){this['persistence']=_0x4648d7,this['auth']=_0x403a7c,this['userKey']=_0x179064;const {config:_0x307e46,name:_0x37c070}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x307e46['apiKey'],_0x37c070),this['fullPersistenceKey']=ln('persistence',_0x307e46['apiKey'],_0x37c070),this['boundEventHandler']=_0x403a7c['_onStorageEvent']['bind'](_0x403a7c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1025a1){return this['persistence']['_set'](this['fullUserKey'],_0x1025a1['toJSON']());}async['getCurrentUser'](){const _0x52f988=await this['persistence']['_get'](this['fullUserKey']);if(!_0x52f988)return null;if(typeof _0x52f988=='string'){const _0xb6419a=await Pn(this['auth'],{'idToken':_0x52f988})['catch'](()=>{});return _0xb6419a?j['_fromGetAccountInfoResponse'](this['auth'],_0xb6419a,_0x52f988):null;}return j['_fromJSON'](this['auth'],_0x52f988);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x540d22){if(this['persistence']===_0x540d22)return;const _0x446806=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x540d22,_0x446806)return this['setCurrentUser'](_0x446806);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x387d6d,_0x34654c,_0x4b6dea='authUser'){if(!_0x34654c['length'])return new tt(ie(Sr),_0x387d6d,_0x4b6dea);const _0x5e94b2=(await Promise['all'](_0x34654c['map'](async _0x3be2ef=>{if(await _0x3be2ef['_isAvailable']())return _0x3be2ef;})))['filter'](_0x682a88=>_0x682a88);let _0x22fd50=_0x5e94b2[0x0]||ie(Sr);const _0x463ef3=ln(_0x4b6dea,_0x387d6d['config']['apiKey'],_0x387d6d['name']);let _0x3bb581=null;for(const _0x3f863f of _0x34654c)try{const _0x6b8d65=await _0x3f863f['_get'](_0x463ef3);if(_0x6b8d65){let _0x421dc4;if(typeof _0x6b8d65=='string'){const _0x431362=await Pn(_0x387d6d,{'idToken':_0x6b8d65})['catch'](()=>{});if(!_0x431362)break;_0x421dc4=await j['_fromGetAccountInfoResponse'](_0x387d6d,_0x431362,_0x6b8d65);}else _0x421dc4=j['_fromJSON'](_0x387d6d,_0x6b8d65);_0x3f863f!==_0x22fd50&&(_0x3bb581=_0x421dc4),_0x22fd50=_0x3f863f;break;}}catch{}const _0x1a7329=_0x5e94b2['filter'](_0xd5f55f=>_0xd5f55f['_shouldAllowMigration']);return!_0x22fd50['_shouldAllowMigration']||!_0x1a7329['length']?new tt(_0x22fd50,_0x387d6d,_0x4b6dea):(_0x22fd50=_0x1a7329[0x0],_0x3bb581&&await _0x22fd50['_set'](_0x463ef3,_0x3bb581['toJSON']()),await Promise['all'](_0x34654c['map'](async _0x1f0490=>{if(_0x1f0490!==_0x22fd50)try{await _0x1f0490['_remove'](_0x463ef3);}catch{}})),new tt(_0x22fd50,_0x387d6d,_0x4b6dea));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5a4545){const _0x962d68=_0x5a4545['toLowerCase']();if(_0x962d68['includes']('opera/')||_0x962d68['includes']('opr/')||_0x962d68['includes']('opios/'))return'Opera';if(Pa(_0x962d68))return'IEMobile';if(_0x962d68['includes']('msie')||_0x962d68['includes']('trident/'))return'IE';if(_0x962d68['includes']('edge/'))return'Edge';if(Ra(_0x962d68))return'Firefox';if(_0x962d68['includes']('silk/'))return'Silk';if(Oa(_0x962d68))return'Blackberry';if(Da(_0x962d68))return'Webos';if(Aa(_0x962d68))return'Safari';if((_0x962d68['includes']('chrome/')||ka(_0x962d68))&&!_0x962d68['includes']('edge/'))return'Chrome';if(Na(_0x962d68))return'Android';{const _0x98b5eb=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x26ca1f=_0x5a4545['match'](_0x98b5eb);if((_0x26ca1f==null?void 0x0:_0x26ca1f['length'])===0x2)return _0x26ca1f[0x1];}return'Other';}function Ra(_0x3b540c=W()){return/firefox\//i['test'](_0x3b540c);}function Aa(_0x524bd9=W()){const _0x365a0a=_0x524bd9['toLowerCase']();return _0x365a0a['includes']('safari/')&&!_0x365a0a['includes']('chrome/')&&!_0x365a0a['includes']('crios/')&&!_0x365a0a['includes']('android');}function ka(_0x265e30=W()){return/crios\//i['test'](_0x265e30);}function Pa(_0x5203da=W()){return/iemobile/i['test'](_0x5203da);}function Na(_0x168eb5=W()){return/android/i['test'](_0x168eb5);}function Oa(_0x20734d=W()){return/blackberry/i['test'](_0x20734d);}function Da(_0x3ae96e=W()){return/webos/i['test'](_0x3ae96e);}function Ss(_0x15cfc6=W()){return/iphone|ipad|ipod/i['test'](_0x15cfc6)||/macintosh/i['test'](_0x15cfc6)&&/mobile/i['test'](_0x15cfc6);}function Rf(_0x21bc33=W()){var _0xd7a2ed;return Ss(_0x21bc33)&&!!((_0xd7a2ed=window['navigator'])!=null&&_0xd7a2ed['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x53b41f=W()){return Ss(_0x53b41f)||Na(_0x53b41f)||Da(_0x53b41f)||Oa(_0x53b41f)||/windows phone/i['test'](_0x53b41f)||Pa(_0x53b41f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x42cec9,_0x55b5e9=[]){let _0x326705;switch(_0x42cec9){case'Browser':_0x326705=br(W());break;case'Worker':_0x326705=br(W())+'-'+_0x42cec9;break;default:_0x326705=_0x42cec9;}const _0x4dc153=_0x55b5e9['length']?_0x55b5e9['join'](','):'FirebaseCore-web';return _0x326705+'/JsCore/'+dt+'/'+_0x4dc153;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1f5fa2){this['auth']=_0x1f5fa2,this['queue']=[];}['pushCallback'](_0x57d167,_0x127ddb){const _0x5e70d6=_0x439c1c=>new Promise((_0x446d5f,_0xb0e9e9)=>{try{const _0xd6f5f6=_0x57d167(_0x439c1c);_0x446d5f(_0xd6f5f6);}catch(_0x1cf12b){_0xb0e9e9(_0x1cf12b);}});_0x5e70d6['onAbort']=_0x127ddb,this['queue']['push'](_0x5e70d6);const _0x40768f=this['queue']['length']-0x1;return()=>{this['queue'][_0x40768f]=()=>Promise['resolve']();};}async['runMiddleware'](_0x477122){if(this['auth']['currentUser']===_0x477122)return;const _0x268c1d=[];try{for(const _0x17400c of this['queue'])await _0x17400c(_0x477122),_0x17400c['onAbort']&&_0x268c1d['push'](_0x17400c['onAbort']);}catch(_0x3ef67f){_0x268c1d['reverse']();for(const _0x2e76ac of _0x268c1d)try{_0x2e76ac();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3ef67f==null?void 0x0:_0x3ef67f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x420915,_0x1777be={}){return Pe(_0x420915,'GET','/v2/passwordPolicy',ke(_0x420915,_0x1777be));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x2d7630){var _0x1af494;const _0x290cfc=_0x2d7630['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x290cfc['minPasswordLength']??Nf,_0x290cfc['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x290cfc['maxPasswordLength']),_0x290cfc['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x290cfc['containsLowercaseCharacter']),_0x290cfc['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x290cfc['containsUppercaseCharacter']),_0x290cfc['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x290cfc['containsNumericCharacter']),_0x290cfc['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x290cfc['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2d7630['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x1af494=_0x2d7630['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x1af494['join'](''))??'',this['forceUpgradeOnSignin']=_0x2d7630['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2d7630['schemaVersion'];}['validatePassword'](_0x4b2634){const _0x54f793={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4b2634,_0x54f793),this['validatePasswordCharacterOptions'](_0x4b2634,_0x54f793),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['meetsMinPasswordLength']??!0x0),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['meetsMaxPasswordLength']??!0x0),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['containsLowercaseLetter']??!0x0),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['containsUppercaseLetter']??!0x0),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['containsNumericCharacter']??!0x0),_0x54f793['isValid']&&(_0x54f793['isValid']=_0x54f793['containsNonAlphanumericCharacter']??!0x0),_0x54f793;}['validatePasswordLengthOptions'](_0x2e26d5,_0x214159){const _0x8d37ce=this['customStrengthOptions']['minPasswordLength'],_0x389b99=this['customStrengthOptions']['maxPasswordLength'];_0x8d37ce&&(_0x214159['meetsMinPasswordLength']=_0x2e26d5['length']>=_0x8d37ce),_0x389b99&&(_0x214159['meetsMaxPasswordLength']=_0x2e26d5['length']<=_0x389b99);}['validatePasswordCharacterOptions'](_0x1f4862,_0x366222){this['updatePasswordCharacterOptionsStatuses'](_0x366222,!0x1,!0x1,!0x1,!0x1);let _0x1eaa97;for(let _0x371759=0x0;_0x371759<_0x1f4862['length'];_0x371759++)_0x1eaa97=_0x1f4862['charAt'](_0x371759),this['updatePasswordCharacterOptionsStatuses'](_0x366222,_0x1eaa97>='a'&&_0x1eaa97<='z',_0x1eaa97>='A'&&_0x1eaa97<='Z',_0x1eaa97>='0'&&_0x1eaa97<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1eaa97));}['updatePasswordCharacterOptionsStatuses'](_0x49cb92,_0x3cf8d2,_0x12cd68,_0xbcb2a1,_0x4133e9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x49cb92['containsLowercaseLetter']||(_0x49cb92['containsLowercaseLetter']=_0x3cf8d2)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x49cb92['containsUppercaseLetter']||(_0x49cb92['containsUppercaseLetter']=_0x12cd68)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x49cb92['containsNumericCharacter']||(_0x49cb92['containsNumericCharacter']=_0xbcb2a1)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x49cb92['containsNonAlphanumericCharacter']||(_0x49cb92['containsNonAlphanumericCharacter']=_0x4133e9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5d1b18,_0x3108fc,_0x6f957a,_0xd2382b){this['app']=_0x5d1b18,this['heartbeatServiceProvider']=_0x3108fc,this['appCheckServiceProvider']=_0x6f957a,this['config']=_0xd2382b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5d1b18['name'],this['clientVersion']=_0xd2382b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5c1e00=>this['_resolvePersistenceManagerAvailable']=_0x5c1e00);}['_initializeWithPersistence'](_0xb3804e,_0x5caeab){return _0x5caeab&&(this['_popupRedirectResolver']=ie(_0x5caeab)),this['_initializationPromise']=this['queue'](async()=>{var _0x438904,_0x21c948,_0x5056a3;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0xb3804e),(_0x438904=this['_resolvePersistenceManagerAvailable'])==null||_0x438904['call'](this),!this['_deleted'])){if((_0x21c948=this['_popupRedirectResolver'])!=null&&_0x21c948['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5caeab),this['lastNotifiedUid']=((_0x5056a3=this['currentUser'])==null?void 0x0:_0x5056a3['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4a1093=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4a1093)){if(this['currentUser']&&_0x4a1093&&this['currentUser']['uid']===_0x4a1093['uid']){this['_currentUser']['_assign'](_0x4a1093),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4a1093,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4c6524){try{const _0x533287=await Pn(this,{'idToken':_0x4c6524}),_0x4ba3a6=await j['_fromGetAccountInfoResponse'](this,_0x533287,_0x4c6524);await this['directlySetCurrentUser'](_0x4ba3a6);}catch(_0x6af2f6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x6af2f6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4629a0){var _0x1b310a;if($(this['app'])){const _0x649c37=this['app']['settings']['authIdToken'];return _0x649c37?new Promise(_0x5b7d49=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x649c37)['then'](_0x5b7d49,_0x5b7d49));}):this['directlySetCurrentUser'](null);}const _0x267b5b=await this['assertedPersistence']['getCurrentUser']();let _0x840fe9=_0x267b5b,_0x1178b6=!0x1;if(_0x4629a0&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x51c1e2=(_0x1b310a=this['redirectUser'])==null?void 0x0:_0x1b310a['_redirectEventId'],_0x2b6246=_0x840fe9==null?void 0x0:_0x840fe9['_redirectEventId'],_0x25e5e7=await this['tryRedirectSignIn'](_0x4629a0);(!_0x51c1e2||_0x51c1e2===_0x2b6246)&&(_0x25e5e7!=null&&_0x25e5e7['user'])&&(_0x840fe9=_0x25e5e7['user'],_0x1178b6=!0x0);}if(!_0x840fe9)return this['directlySetCurrentUser'](null);if(!_0x840fe9['_redirectEventId']){if(_0x1178b6)try{await this['beforeStateQueue']['runMiddleware'](_0x840fe9);}catch(_0x38eddc){_0x840fe9=_0x267b5b,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x38eddc));}return _0x840fe9?this['reloadAndSetCurrentUserOrClear'](_0x840fe9):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x840fe9['_redirectEventId']?this['directlySetCurrentUser'](_0x840fe9):this['reloadAndSetCurrentUserOrClear'](_0x840fe9);}async['tryRedirectSignIn'](_0x4b0d5f){let _0x486927=null;try{_0x486927=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4b0d5f,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x486927;}async['reloadAndSetCurrentUserOrClear'](_0x2e606f){try{await Nn(_0x2e606f);}catch(_0x454a81){if((_0x454a81==null?void 0x0:_0x454a81['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2e606f);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x51d686){if($(this['app']))return Promise['reject'](re(this));const _0x49f61d=_0x51d686?P(_0x51d686):null;return _0x49f61d&&m(_0x49f61d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x49f61d&&_0x49f61d['_clone'](this));}async['_updateCurrentUser'](_0x68c50,_0x59f39b=!0x1){if(!this['_deleted'])return _0x68c50&&m(this['tenantId']===_0x68c50['tenantId'],this,'tenant-id-mismatch'),_0x59f39b||await this['beforeStateQueue']['runMiddleware'](_0x68c50),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x68c50),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2a4992){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2a4992));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1d4e93){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x35e7d8=this['_getPasswordPolicyInternal']();return _0x35e7d8['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x35e7d8['validatePassword'](_0x1d4e93);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x737cad=await Pf(this),_0x56ecda=new Of(_0x737cad);this['tenantId']===null?this['_projectPasswordPolicy']=_0x56ecda:this['_tenantPasswordPolicies'][this['tenantId']]=_0x56ecda;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5b6eea){this['_errorFactory']=new Gt('auth','Firebase',_0x5b6eea());}['onAuthStateChanged'](_0x47bb8b,_0x3da380,_0x1512dd){return this['registerStateListener'](this['authStateSubscription'],_0x47bb8b,_0x3da380,_0x1512dd);}['beforeAuthStateChanged'](_0x4ce88b,_0x43ff7f){return this['beforeStateQueue']['pushCallback'](_0x4ce88b,_0x43ff7f);}['onIdTokenChanged'](_0x1b4066,_0x1edf58,_0x497686){return this['registerStateListener'](this['idTokenSubscription'],_0x1b4066,_0x1edf58,_0x497686);}['authStateReady'](){return new Promise((_0x13cd8b,_0x4db9e6)=>{if(this['currentUser'])_0x13cd8b();else{const _0x293f28=this['onAuthStateChanged'](()=>{_0x293f28(),_0x13cd8b();},_0x4db9e6);}});}async['revokeAccessToken'](_0x52a522){if(this['currentUser']){const _0x19b5e5=await this['currentUser']['getIdToken'](),_0x4f6e4f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x52a522,'idToken':_0x19b5e5};this['tenantId']!=null&&(_0x4f6e4f['tenantId']=this['tenantId']),await bf(this,_0x4f6e4f);}}['toJSON'](){var _0x51cbc7;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x51cbc7=this['_currentUser'])==null?void 0x0:_0x51cbc7['toJSON']()};}async['_setRedirectUser'](_0x49d3fa,_0xf1972d){const _0x484061=await this['getOrInitRedirectPersistenceManager'](_0xf1972d);return _0x49d3fa===null?_0x484061['removeCurrentUser']():_0x484061['setCurrentUser'](_0x49d3fa);}async['getOrInitRedirectPersistenceManager'](_0x5a8bda){if(!this['redirectPersistenceManager']){const _0x145b63=_0x5a8bda&&ie(_0x5a8bda)||this['_popupRedirectResolver'];m(_0x145b63,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x145b63['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x42ef4a){var _0x3cb94c,_0x15c32c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3cb94c=this['_currentUser'])==null?void 0x0:_0x3cb94c['_redirectEventId'])===_0x42ef4a?this['_currentUser']:((_0x15c32c=this['redirectUser'])==null?void 0x0:_0x15c32c['_redirectEventId'])===_0x42ef4a?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x142364){if(_0x142364===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x142364));}['_notifyListenersIfCurrent'](_0x463c0b){_0x463c0b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3852dc;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1c113d=((_0x3852dc=this['currentUser'])==null?void 0x0:_0x3852dc['uid'])??null;this['lastNotifiedUid']!==_0x1c113d&&(this['lastNotifiedUid']=_0x1c113d,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x55981d,_0x15d5ce,_0x3c1b1e,_0x4c6b81){if(this['_deleted'])return()=>{};const _0x5f0718=typeof _0x15d5ce=='function'?_0x15d5ce:_0x15d5ce['next']['bind'](_0x15d5ce);let _0x51c99c=!0x1;const _0x4a411a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4a411a,this,'internal-error'),_0x4a411a['then'](()=>{_0x51c99c||_0x5f0718(this['currentUser']);}),typeof _0x15d5ce=='function'){const _0x396350=_0x55981d['addObserver'](_0x15d5ce,_0x3c1b1e,_0x4c6b81);return()=>{_0x51c99c=!0x0,_0x396350();};}else{const _0x2996df=_0x55981d['addObserver'](_0x15d5ce);return()=>{_0x51c99c=!0x0,_0x2996df();};}}async['directlySetCurrentUser'](_0x4ed74f){this['currentUser']&&this['currentUser']!==_0x4ed74f&&this['_currentUser']['_stopProactiveRefresh'](),_0x4ed74f&&this['isProactiveRefreshEnabled']&&_0x4ed74f['_startProactiveRefresh'](),this['currentUser']=_0x4ed74f,_0x4ed74f?await this['assertedPersistence']['setCurrentUser'](_0x4ed74f):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2e729f){return this['operations']=this['operations']['then'](_0x2e729f,_0x2e729f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3f8269){!_0x3f8269||this['frameworks']['includes'](_0x3f8269)||(this['frameworks']['push'](_0x3f8269),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1c15a9;const _0x5f5ade={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5f5ade['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xf57f4e=await((_0x1c15a9=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1c15a9['getHeartbeatsHeader']());_0xf57f4e&&(_0x5f5ade['X-Firebase-Client']=_0xf57f4e);const _0x448353=await this['_getAppCheckToken']();return _0x448353&&(_0x5f5ade['X-Firebase-AppCheck']=_0x448353),_0x5f5ade;}async['_getAppCheckToken'](){var _0x153b66;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x23e091=await((_0x153b66=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x153b66['getToken']());return _0x23e091!=null&&_0x23e091['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x23e091['error']),_0x23e091==null?void 0x0:_0x23e091['token'];}}function Ke(_0x4b6003){return P(_0x4b6003);}class Rr{constructor(_0x1540ba){this['auth']=_0x1540ba,this['observer']=null,this['addObserver']=Tc(_0x50a11f=>this['observer']=_0x50a11f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5dc626){Jn=_0x5dc626;}function xa(_0x5a95c9){return Jn['loadJS'](_0x5a95c9);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x30ff19){return'__'+_0x30ff19+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x5d3908){_0x5d3908();}['execute'](_0x3d9228,_0x1e8295){return Promise['resolve']('token');}['render'](_0x12f25f,_0x21b8c4){return'';}}class Wf{['ready'](_0x38d14a){_0x38d14a();}['execute'](_0x7f694,_0x1d4fc5){return Promise['resolve']('token');}['render'](_0x4714a5,_0x13aab2){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x1cea4f){this['type']=Bf,this['auth']=Ke(_0x1cea4f);}async['verify'](_0x13965d='verify',_0x426ccd=!0x1){async function _0x56fa99(_0x6ba517){if(!_0x426ccd){if(_0x6ba517['tenantId']==null&&_0x6ba517['_agentRecaptchaConfig']!=null)return _0x6ba517['_agentRecaptchaConfig']['siteKey'];if(_0x6ba517['tenantId']!=null&&_0x6ba517['_tenantRecaptchaConfigs'][_0x6ba517['tenantId']]!==void 0x0)return _0x6ba517['_tenantRecaptchaConfigs'][_0x6ba517['tenantId']]['siteKey'];}return new Promise(async(_0x974cd,_0xf8f35b)=>{yf(_0x6ba517,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x53a206=>{if(_0x53a206['recaptchaKey']===void 0x0)_0xf8f35b(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xdc42fa=new mf(_0x53a206);return _0x6ba517['tenantId']==null?_0x6ba517['_agentRecaptchaConfig']=_0xdc42fa:_0x6ba517['_tenantRecaptchaConfigs'][_0x6ba517['tenantId']]=_0xdc42fa,_0x974cd(_0xdc42fa['siteKey']);}})['catch'](_0x3ea76f=>{_0xf8f35b(_0x3ea76f);});});}function _0x21f384(_0x2e7bda,_0x56edfd,_0x52e0a8){const _0x11419e=window['grecaptcha'];wr(_0x11419e)?_0x11419e['enterprise']['ready'](()=>{_0x11419e['enterprise']['execute'](_0x2e7bda,{'action':_0x13965d})['then'](_0x223e81=>{_0x56edfd(_0x223e81);})['catch'](()=>{_0x56edfd(Fa);});}):_0x52e0a8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xcfeab8,_0x55bbe1)=>{_0x56fa99(this['auth'])['then'](async _0x2def70=>{if(!_0x426ccd&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x21f384(_0x2def70,_0xcfeab8,_0x55bbe1);else{if(typeof window>'u'){_0x55bbe1(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x20de81=Lf();_0x20de81['length']!==0x0&&(_0x20de81+=_0x2def70+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5beada;(_0x5beada=he['scriptInjectionDeferred'])==null||_0x5beada['resolve']();},xa(_0x20de81)['then'](()=>{var _0x38cc07;return(_0x38cc07=he['scriptInjectionDeferred'])==null?void 0x0:_0x38cc07['promise'];})['then'](()=>{_0x21f384(_0x2def70,_0xcfeab8,_0x55bbe1);})['catch'](_0x51fc28=>{_0x55bbe1(_0x51fc28);});}})['catch'](_0x3ed2e0=>{_0x55bbe1(_0x3ed2e0);});});}}he['scriptInjectionDeferred']=null;async function kr(_0xa4db7d,_0xbd57ec,_0x4d178a,_0x25ecea=!0x1,_0x4c1878=!0x1){const _0x12114f=new he(_0xa4db7d);let _0x21d5ac;if(_0x4c1878)_0x21d5ac=Fa;else try{_0x21d5ac=await _0x12114f['verify'](_0x4d178a);}catch{_0x21d5ac=await _0x12114f['verify'](_0x4d178a,!0x0);}const _0x511e5f={..._0xbd57ec};if(_0x4d178a==='mfaSmsEnrollment'||_0x4d178a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x511e5f){const _0x2bc4ab=_0x511e5f['phoneEnrollmentInfo']['phoneNumber'],_0x29bfa6=_0x511e5f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x511e5f,{'phoneEnrollmentInfo':{'phoneNumber':_0x2bc4ab,'recaptchaToken':_0x29bfa6,'captchaResponse':_0x21d5ac,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x511e5f){const _0x16ae9f=_0x511e5f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x511e5f,{'phoneSignInInfo':{'recaptchaToken':_0x16ae9f,'captchaResponse':_0x21d5ac,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x511e5f;}return _0x25ecea?Object['assign'](_0x511e5f,{'captchaResp':_0x21d5ac}):Object['assign'](_0x511e5f,{'captchaResponse':_0x21d5ac}),Object['assign'](_0x511e5f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x511e5f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x511e5f;}async function xi(_0x8f0c39,_0x5d6e2e,_0x56562c,_0x2b4376,_0x128b4b){var _0x59e5f1;if((_0x59e5f1=_0x8f0c39['_getRecaptchaConfig']())!=null&&_0x59e5f1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3768a2=await kr(_0x8f0c39,_0x5d6e2e,_0x56562c,_0x56562c==='getOobCode');return _0x2b4376(_0x8f0c39,_0x3768a2);}else return _0x2b4376(_0x8f0c39,_0x5d6e2e)['catch'](async _0x57582d=>{if(_0x57582d['code']==='auth/missing-recaptcha-token'){console['log'](_0x56562c+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2db799=await kr(_0x8f0c39,_0x5d6e2e,_0x56562c,_0x56562c==='getOobCode');return _0x2b4376(_0x8f0c39,_0x2db799);}else return Promise['reject'](_0x57582d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x566072,_0x16e278){const _0x1a50f1=Hi(_0x566072,'auth');if(_0x1a50f1['isInitialized']()){const _0x44fa41=_0x1a50f1['getImmediate'](),_0x19d8f2=_0x1a50f1['getOptions']();if(xe(_0x19d8f2,_0x16e278??{}))return _0x44fa41;Y(_0x44fa41,'already-initialized');}return _0x1a50f1['initialize']({'options':_0x16e278});}function Hf(_0x4b05d8,_0x250259){const _0x1dea9b=(_0x250259==null?void 0x0:_0x250259['persistence'])||[],_0xfcabad=(Array['isArray'](_0x1dea9b)?_0x1dea9b:[_0x1dea9b])['map'](ie);_0x250259!=null&&_0x250259['errorMap']&&_0x4b05d8['_updateErrorMap'](_0x250259['errorMap']),_0x4b05d8['_initializeWithPersistence'](_0xfcabad,_0x250259==null?void 0x0:_0x250259['popupRedirectResolver']);}function $f(_0x57bba3,_0x514aeb,_0x3dc4dd){const _0x19edd5=Ke(_0x57bba3);m(/^https?:\/\//['test'](_0x514aeb),_0x19edd5,'invalid-emulator-scheme');const _0x3a8522=!0x1,_0x3bb4e9=Ua(_0x514aeb),{host:_0x31ba3a,port:_0x323945}=Gf(_0x514aeb),_0x2ff6f4=_0x323945===null?'':':'+_0x323945,_0x8ba6a8={'url':_0x3bb4e9+'//'+_0x31ba3a+_0x2ff6f4+'/'},_0x2b94b9=Object['freeze']({'host':_0x31ba3a,'port':_0x323945,'protocol':_0x3bb4e9['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3a8522})});if(!_0x19edd5['_canInitEmulator']){m(_0x19edd5['config']['emulator']&&_0x19edd5['emulatorConfig'],_0x19edd5,'emulator-config-failed'),m(xe(_0x8ba6a8,_0x19edd5['config']['emulator'])&&xe(_0x2b94b9,_0x19edd5['emulatorConfig']),_0x19edd5,'emulator-config-failed');return;}_0x19edd5['config']['emulator']=_0x8ba6a8,_0x19edd5['emulatorConfig']=_0x2b94b9,_0x19edd5['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x31ba3a)?Qr(_0x3bb4e9+'//'+_0x31ba3a+_0x2ff6f4):qf();}function Ua(_0x4c7e02){const _0x12baa3=_0x4c7e02['indexOf'](':');return _0x12baa3<0x0?'':_0x4c7e02['substr'](0x0,_0x12baa3+0x1);}function Gf(_0x2e55ee){const _0x4f68a1=Ua(_0x2e55ee),_0x4a68c5=/(\/\/)?([^?#/]+)/['exec'](_0x2e55ee['substr'](_0x4f68a1['length']));if(!_0x4a68c5)return{'host':'','port':null};const _0x177653=_0x4a68c5[0x2]['split']('@')['pop']()||'',_0x57b523=/^(\[[^\]]+\])(:|$)/['exec'](_0x177653);if(_0x57b523){const _0x8c7b39=_0x57b523[0x1];return{'host':_0x8c7b39,'port':Pr(_0x177653['substr'](_0x8c7b39['length']+0x1))};}else{const [_0x4d13a3,_0x2f9416]=_0x177653['split'](':');return{'host':_0x4d13a3,'port':Pr(_0x2f9416)};}}function Pr(_0x29b486){if(!_0x29b486)return null;const _0x5c93ad=Number(_0x29b486);return isNaN(_0x5c93ad)?null:_0x5c93ad;}function qf(){function _0x22f578(){const _0x26333c=document['createElement']('p'),_0x2be866=_0x26333c['style'];_0x26333c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2be866['position']='fixed',_0x2be866['width']='100%',_0x2be866['backgroundColor']='#ffffff',_0x2be866['border']='.1em\x20solid\x20#000000',_0x2be866['color']='#b50000',_0x2be866['bottom']='0px',_0x2be866['left']='0px',_0x2be866['margin']='0px',_0x2be866['zIndex']='10000',_0x2be866['textAlign']='center',_0x26333c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x26333c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x22f578):_0x22f578());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3bf7b5,_0x221209){this['providerId']=_0x3bf7b5,this['signInMethod']=_0x221209;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x16718f){return ne('not\x20implemented');}['_linkToIdToken'](_0x302832,_0x41c778){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xaf134f){return ne('not\x20implemented');}}async function zf(_0x181d00,_0x881ab6){return Pe(_0x181d00,'POST','/v1/accounts:signUp',_0x881ab6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x3ebb51,_0xf11c2b){return en(_0x3ebb51,'POST','/v1/accounts:signInWithPassword',ke(_0x3ebb51,_0xf11c2b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x2f4cee,_0x352d1f){return en(_0x2f4cee,'POST','/v1/accounts:signInWithEmailLink',ke(_0x2f4cee,_0x352d1f));}async function Yf(_0x1b9eb2,_0x44b259){return en(_0x1b9eb2,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1b9eb2,_0x44b259));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x5411f3,_0x5d7faf,_0x1548ef,_0x10c229=null){super('password',_0x1548ef),this['_email']=_0x5411f3,this['_password']=_0x5d7faf,this['_tenantId']=_0x10c229;}static['_fromEmailAndPassword'](_0x16207b,_0x13a426){return new $t(_0x16207b,_0x13a426,'password');}static['_fromEmailAndCode'](_0x2af174,_0x4f0614,_0x18c47f=null){return new $t(_0x2af174,_0x4f0614,'emailLink',_0x18c47f);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1be330){const _0x3c4627=typeof _0x1be330=='string'?JSON['parse'](_0x1be330):_0x1be330;if(_0x3c4627!=null&&_0x3c4627['email']&&(_0x3c4627!=null&&_0x3c4627['password'])){if(_0x3c4627['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3c4627['email'],_0x3c4627['password']);if(_0x3c4627['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3c4627['email'],_0x3c4627['password'],_0x3c4627['tenantId']);}return null;}async['_getIdTokenResponse'](_0x19d648){switch(this['signInMethod']){case'password':const _0x338fe7={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x19d648,_0x338fe7,'signInWithPassword',jf);case'emailLink':return Kf(_0x19d648,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x19d648,'internal-error');}}async['_linkToIdToken'](_0x4da43f,_0x3a4851){switch(this['signInMethod']){case'password':const _0x20a8dc={'idToken':_0x3a4851,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4da43f,_0x20a8dc,'signUpPassword',zf);case'emailLink':return Yf(_0x4da43f,{'idToken':_0x3a4851,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4da43f,'internal-error');}}['_getReauthenticationResolver'](_0x44d328){return this['_getIdTokenResponse'](_0x44d328);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x856ef7,_0xb08aa5){return en(_0x856ef7,'POST','/v1/accounts:signInWithIdp',ke(_0x856ef7,_0xb08aa5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x30617a){const _0x122f3f=new $e(_0x30617a['providerId'],_0x30617a['signInMethod']);return _0x30617a['idToken']||_0x30617a['accessToken']?(_0x30617a['idToken']&&(_0x122f3f['idToken']=_0x30617a['idToken']),_0x30617a['accessToken']&&(_0x122f3f['accessToken']=_0x30617a['accessToken']),_0x30617a['nonce']&&!_0x30617a['pendingToken']&&(_0x122f3f['nonce']=_0x30617a['nonce']),_0x30617a['pendingToken']&&(_0x122f3f['pendingToken']=_0x30617a['pendingToken'])):_0x30617a['oauthToken']&&_0x30617a['oauthTokenSecret']?(_0x122f3f['accessToken']=_0x30617a['oauthToken'],_0x122f3f['secret']=_0x30617a['oauthTokenSecret']):Y('argument-error'),_0x122f3f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x212187){const _0x3a0d97=typeof _0x212187=='string'?JSON['parse'](_0x212187):_0x212187,{providerId:_0x3cb158,signInMethod:_0x393e3d,..._0x3b4d35}=_0x3a0d97;if(!_0x3cb158||!_0x393e3d)return null;const _0x43a7e0=new $e(_0x3cb158,_0x393e3d);return _0x43a7e0['idToken']=_0x3b4d35['idToken']||void 0x0,_0x43a7e0['accessToken']=_0x3b4d35['accessToken']||void 0x0,_0x43a7e0['secret']=_0x3b4d35['secret'],_0x43a7e0['nonce']=_0x3b4d35['nonce'],_0x43a7e0['pendingToken']=_0x3b4d35['pendingToken']||null,_0x43a7e0;}['_getIdTokenResponse'](_0x1a7ffb){const _0x4d8ff8=this['buildRequest']();return nt(_0x1a7ffb,_0x4d8ff8);}['_linkToIdToken'](_0x165539,_0x427c8e){const _0x323f18=this['buildRequest']();return _0x323f18['idToken']=_0x427c8e,nt(_0x165539,_0x323f18);}['_getReauthenticationResolver'](_0x1d71b3){const _0x264c20=this['buildRequest']();return _0x264c20['autoCreate']=!0x1,nt(_0x1d71b3,_0x264c20);}['buildRequest'](){const _0x12f588={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x12f588['pendingToken']=this['pendingToken'];else{const _0x3aca53={};this['idToken']&&(_0x3aca53['id_token']=this['idToken']),this['accessToken']&&(_0x3aca53['access_token']=this['accessToken']),this['secret']&&(_0x3aca53['oauth_token_secret']=this['secret']),_0x3aca53['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3aca53['nonce']=this['nonce']),_0x12f588['postBody']=ut(_0x3aca53);}return _0x12f588;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x488e23){switch(_0x488e23){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0xccd220){const _0x38f95a=Ct(Tt(_0xccd220))['link'],_0x109e67=_0x38f95a?Ct(Tt(_0x38f95a))['deep_link_id']:null,_0x572e90=Ct(Tt(_0xccd220))['deep_link_id'];return(_0x572e90?Ct(Tt(_0x572e90))['link']:null)||_0x572e90||_0x109e67||_0x38f95a||_0xccd220;}class Rs{constructor(_0x11eff3){const _0x114bec=Ct(Tt(_0x11eff3)),_0x43834e=_0x114bec['apiKey']??null,_0x546166=_0x114bec['oobCode']??null,_0x57137c=Jf(_0x114bec['mode']??null);m(_0x43834e&&_0x546166&&_0x57137c,'argument-error'),this['apiKey']=_0x43834e,this['operation']=_0x57137c,this['code']=_0x546166,this['continueUrl']=_0x114bec['continueUrl']??null,this['languageCode']=_0x114bec['lang']??null,this['tenantId']=_0x114bec['tenantId']??null;}static['parseLink'](_0x2e86d9){const _0x26c8db=Xf(_0x2e86d9);try{return new Rs(_0x26c8db);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x8f6e53,_0x5c8482){return $t['_fromEmailAndPassword'](_0x8f6e53,_0x5c8482);}static['credentialWithLink'](_0x41c78f,_0x1b7aa5){const _0x11841e=Rs['parseLink'](_0x1b7aa5);return m(_0x11841e,'argument-error'),$t['_fromEmailAndCode'](_0x41c78f,_0x11841e['code'],_0x11841e['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x35c9fb){this['providerId']=_0x35c9fb,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3d4907){this['defaultLanguageCode']=_0x3d4907;}['setCustomParameters'](_0x40f4f3){return this['customParameters']=_0x40f4f3,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x17369f){return this['scopes']['includes'](_0x17369f)||this['scopes']['push'](_0x17369f),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0xb407c4){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0xb407c4});}static['credentialFromResult'](_0x46c2be){return ue['credentialFromTaggedObject'](_0x46c2be);}static['credentialFromError'](_0x54eafd){return ue['credentialFromTaggedObject'](_0x54eafd['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b2719}){if(!_0x4b2719||!('oauthAccessToken'in _0x4b2719)||!_0x4b2719['oauthAccessToken'])return null;try{return ue['credential'](_0x4b2719['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x431fd3,_0x4baccb){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x431fd3,'accessToken':_0x4baccb});}static['credentialFromResult'](_0x1d9802){return de['credentialFromTaggedObject'](_0x1d9802);}static['credentialFromError'](_0x4937e0){return de['credentialFromTaggedObject'](_0x4937e0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x43af0d}){if(!_0x43af0d)return null;const {oauthIdToken:_0x3877ac,oauthAccessToken:_0xd3c460}=_0x43af0d;if(!_0x3877ac&&!_0xd3c460)return null;try{return de['credential'](_0x3877ac,_0xd3c460);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x2909bc){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2909bc});}static['credentialFromResult'](_0x457af1){return fe['credentialFromTaggedObject'](_0x457af1);}static['credentialFromError'](_0x295150){return fe['credentialFromTaggedObject'](_0x295150['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x506809}){if(!_0x506809||!('oauthAccessToken'in _0x506809)||!_0x506809['oauthAccessToken'])return null;try{return fe['credential'](_0x506809['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x1d0d17,_0x244159){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1d0d17,'oauthTokenSecret':_0x244159});}static['credentialFromResult'](_0x546908){return pe['credentialFromTaggedObject'](_0x546908);}static['credentialFromError'](_0x3e69b6){return pe['credentialFromTaggedObject'](_0x3e69b6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4f0b9a}){if(!_0x4f0b9a)return null;const {oauthAccessToken:_0x57baf2,oauthTokenSecret:_0x2052ff}=_0x4f0b9a;if(!_0x57baf2||!_0x2052ff)return null;try{return pe['credential'](_0x57baf2,_0x2052ff);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x104511,_0x49b808){return en(_0x104511,'POST','/v1/accounts:signUp',ke(_0x104511,_0x49b808));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x4bf12c){this['user']=_0x4bf12c['user'],this['providerId']=_0x4bf12c['providerId'],this['_tokenResponse']=_0x4bf12c['_tokenResponse'],this['operationType']=_0x4bf12c['operationType'];}static async['_fromIdTokenResponse'](_0x3b3761,_0x39817f,_0x32c148,_0x171e26=!0x1){const _0x7ca1d8=await j['_fromIdTokenResponse'](_0x3b3761,_0x32c148,_0x171e26),_0x2f27ba=Nr(_0x32c148);return new Ge({'user':_0x7ca1d8,'providerId':_0x2f27ba,'_tokenResponse':_0x32c148,'operationType':_0x39817f});}static async['_forOperation'](_0x109779,_0x2cc7f0,_0x197035){await _0x109779['_updateTokensIfNecessary'](_0x197035,!0x0);const _0x51ed7b=Nr(_0x197035);return new Ge({'user':_0x109779,'providerId':_0x51ed7b,'_tokenResponse':_0x197035,'operationType':_0x2cc7f0});}}function Nr(_0x50f3d6){return _0x50f3d6['providerId']?_0x50f3d6['providerId']:'phoneNumber'in _0x50f3d6?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x38e4db,_0x4184e3,_0x3da5fc,_0x4207e6){super(_0x4184e3['code'],_0x4184e3['message']),this['operationType']=_0x3da5fc,this['user']=_0x4207e6,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x38e4db['name'],'tenantId':_0x38e4db['tenantId']??void 0x0,'_serverResponse':_0x4184e3['customData']['_serverResponse'],'operationType':_0x3da5fc};}static['_fromErrorAndOperation'](_0x22a7b4,_0x3763e8,_0x1f4ba2,_0xdc1ee4){return new On(_0x22a7b4,_0x3763e8,_0x1f4ba2,_0xdc1ee4);}}function Ba(_0x5b3a52,_0x1aec0f,_0x9592d9,_0x24021e){return(_0x1aec0f==='reauthenticate'?_0x9592d9['_getReauthenticationResolver'](_0x5b3a52):_0x9592d9['_getIdTokenResponse'](_0x5b3a52))['catch'](_0x51363b=>{throw _0x51363b['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x5b3a52,_0x51363b,_0x1aec0f,_0x24021e):_0x51363b;});}async function ep(_0x59c457,_0x14e7b0,_0x99a0ff=!0x1){const _0x9f59c=await Ht(_0x59c457,_0x14e7b0['_linkToIdToken'](_0x59c457['auth'],await _0x59c457['getIdToken']()),_0x99a0ff);return Ge['_forOperation'](_0x59c457,'link',_0x9f59c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x51d634,_0xab4ee5,_0x4b513d=!0x1){const {auth:_0x4da147}=_0x51d634;if($(_0x4da147['app']))return Promise['reject'](re(_0x4da147));const _0x6522dd='reauthenticate';try{const _0x5f5daa=await Ht(_0x51d634,Ba(_0x4da147,_0x6522dd,_0xab4ee5,_0x51d634),_0x4b513d);m(_0x5f5daa['idToken'],_0x4da147,'internal-error');const _0x4f0bd2=Ts(_0x5f5daa['idToken']);m(_0x4f0bd2,_0x4da147,'internal-error');const {sub:_0x177e39}=_0x4f0bd2;return m(_0x51d634['uid']===_0x177e39,_0x4da147,'user-mismatch'),Ge['_forOperation'](_0x51d634,_0x6522dd,_0x5f5daa);}catch(_0x377fb2){throw(_0x377fb2==null?void 0x0:_0x377fb2['code'])==='auth/user-not-found'&&Y(_0x4da147,'user-mismatch'),_0x377fb2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x50f557,_0x2be2d8,_0x4027e0=!0x1){if($(_0x50f557['app']))return Promise['reject'](re(_0x50f557));const _0x141be3='signIn',_0x3304c3=await Ba(_0x50f557,_0x141be3,_0x2be2d8),_0x355c12=await Ge['_fromIdTokenResponse'](_0x50f557,_0x141be3,_0x3304c3);return _0x4027e0||await _0x50f557['_updateCurrentUser'](_0x355c12['user']),_0x355c12;}async function np(_0x3168ea,_0x4d2f4a){return Va(Ke(_0x3168ea),_0x4d2f4a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xeaa0ef){const _0x101263=Ke(_0xeaa0ef);_0x101263['_getPasswordPolicyInternal']()&&await _0x101263['_updatePasswordPolicy']();}async function L_(_0x40d160,_0x9dcc04,_0x32cec4){if($(_0x40d160['app']))return Promise['reject'](re(_0x40d160));const _0x35a3d8=Ke(_0x40d160),_0x1c7491=await xi(_0x35a3d8,{'returnSecureToken':!0x0,'email':_0x9dcc04,'password':_0x32cec4,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x34759b=>{throw _0x34759b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x40d160),_0x34759b;}),_0x1c46f2=await Ge['_fromIdTokenResponse'](_0x35a3d8,'signIn',_0x1c7491);return await _0x35a3d8['_updateCurrentUser'](_0x1c46f2['user']),_0x1c46f2;}function x_(_0x128949,_0x3db500,_0x46ef3f){return $(_0x128949['app'])?Promise['reject'](re(_0x128949)):np(P(_0x128949),yt['credential'](_0x3db500,_0x46ef3f))['catch'](async _0x4a17ca=>{throw _0x4a17ca['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x128949),_0x4a17ca;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x3f2241,_0x23f64c){return P(_0x3f2241)['setPersistence'](_0x23f64c);}function ip(_0x47524b,_0x3f1f16,_0x475ed2,_0x2dc2e2){return P(_0x47524b)['onIdTokenChanged'](_0x3f1f16,_0x475ed2,_0x2dc2e2);}function sp(_0x4dc379,_0x1e64b7,_0x2f63bc){return P(_0x4dc379)['beforeAuthStateChanged'](_0x1e64b7,_0x2f63bc);}function U_(_0x25421c,_0x56b6ad,_0x173c04,_0x17b308){return P(_0x25421c)['onAuthStateChanged'](_0x56b6ad,_0x173c04,_0x17b308);}function W_(_0x53afa3){return P(_0x53afa3)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3131f6,_0x4f06e9){this['storageRetriever']=_0x3131f6,this['type']=_0x4f06e9;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5ac5e2,_0x689eb8){return this['storage']['setItem'](_0x5ac5e2,JSON['stringify'](_0x689eb8)),Promise['resolve']();}['_get'](_0x21a531){const _0x390742=this['storage']['getItem'](_0x21a531);return Promise['resolve'](_0x390742?JSON['parse'](_0x390742):null);}['_remove'](_0x53a672){return this['storage']['removeItem'](_0x53a672),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5a23c3,_0x4f54b8)=>this['onStorageEvent'](_0x5a23c3,_0x4f54b8),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x341590){for(const _0x37dba3 of Object['keys'](this['listeners'])){const _0x6e7ac2=this['storage']['getItem'](_0x37dba3),_0x1dab11=this['localCache'][_0x37dba3];_0x6e7ac2!==_0x1dab11&&_0x341590(_0x37dba3,_0x1dab11,_0x6e7ac2);}}['onStorageEvent'](_0x6e7524,_0x249e33=!0x1){if(!_0x6e7524['key']){this['forAllChangedKeys']((_0x28a3db,_0x3c25b9,_0x2804ba)=>{this['notifyListeners'](_0x28a3db,_0x2804ba);});return;}const _0x5aa365=_0x6e7524['key'];_0x249e33?this['detachListener']():this['stopPolling']();const _0x50758d=()=>{const _0x2fa32e=this['storage']['getItem'](_0x5aa365);!_0x249e33&&this['localCache'][_0x5aa365]===_0x2fa32e||this['notifyListeners'](_0x5aa365,_0x2fa32e);},_0x280470=this['storage']['getItem'](_0x5aa365);Af()&&_0x280470!==_0x6e7524['newValue']&&_0x6e7524['newValue']!==_0x6e7524['oldValue']?setTimeout(_0x50758d,op):_0x50758d();}['notifyListeners'](_0x162b02,_0x2e07d9){this['localCache'][_0x162b02]=_0x2e07d9;const _0x29edae=this['listeners'][_0x162b02];if(_0x29edae){for(const _0x38e674 of Array['from'](_0x29edae))_0x38e674(_0x2e07d9&&JSON['parse'](_0x2e07d9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x27b9a0,_0x4afa6d,_0x1dd34b)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x27b9a0,'oldValue':_0x4afa6d,'newValue':_0x1dd34b}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x47dcb8,_0x3330e9){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x47dcb8]||(this['listeners'][_0x47dcb8]=new Set(),this['localCache'][_0x47dcb8]=this['storage']['getItem'](_0x47dcb8)),this['listeners'][_0x47dcb8]['add'](_0x3330e9);}['_removeListener'](_0x1545c3,_0x423f29){this['listeners'][_0x1545c3]&&(this['listeners'][_0x1545c3]['delete'](_0x423f29),this['listeners'][_0x1545c3]['size']===0x0&&delete this['listeners'][_0x1545c3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4af1bf,_0x15c040){await super['_set'](_0x4af1bf,_0x15c040),this['localCache'][_0x4af1bf]=JSON['stringify'](_0x15c040);}async['_get'](_0x87e6e9){const _0x3fecfb=await super['_get'](_0x87e6e9);return this['localCache'][_0x87e6e9]=JSON['stringify'](_0x3fecfb),_0x3fecfb;}async['_remove'](_0x95cedc){await super['_remove'](_0x95cedc),delete this['localCache'][_0x95cedc];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4e7f4a,_0x243949){}['_removeListener'](_0x7af3a7,_0x3609d1){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2f068f){return Promise['all'](_0x2f068f['map'](async _0x5c383b=>{try{return{'fulfilled':!0x0,'value':await _0x5c383b};}catch(_0x21de1d){return{'fulfilled':!0x1,'reason':_0x21de1d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xbea02d){this['eventTarget']=_0xbea02d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xd5dc35){const _0x1486c1=this['receivers']['find'](_0x36f9a8=>_0x36f9a8['isListeningto'](_0xd5dc35));if(_0x1486c1)return _0x1486c1;const _0x1ba96b=new Xn(_0xd5dc35);return this['receivers']['push'](_0x1ba96b),_0x1ba96b;}['isListeningto'](_0x3f2597){return this['eventTarget']===_0x3f2597;}async['handleEvent'](_0x8d972c){const _0x1a6fbc=_0x8d972c,{eventId:_0x249ed9,eventType:_0x5e9209,data:_0x4b1c23}=_0x1a6fbc['data'],_0x49b166=this['handlersMap'][_0x5e9209];if(!(_0x49b166!=null&&_0x49b166['size']))return;_0x1a6fbc['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x249ed9,'eventType':_0x5e9209});const _0x53e6ab=Array['from'](_0x49b166)['map'](async _0x2bcfd7=>_0x2bcfd7(_0x1a6fbc['origin'],_0x4b1c23)),_0x4e1e0c=await cp(_0x53e6ab);_0x1a6fbc['ports'][0x0]['postMessage']({'status':'done','eventId':_0x249ed9,'eventType':_0x5e9209,'response':_0x4e1e0c});}['_subscribe'](_0x2eff33,_0x302df6){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2eff33]||(this['handlersMap'][_0x2eff33]=new Set()),this['handlersMap'][_0x2eff33]['add'](_0x302df6);}['_unsubscribe'](_0x49a6bd,_0x1bf5b8){this['handlersMap'][_0x49a6bd]&&_0x1bf5b8&&this['handlersMap'][_0x49a6bd]['delete'](_0x1bf5b8),(!_0x1bf5b8||this['handlersMap'][_0x49a6bd]['size']===0x0)&&delete this['handlersMap'][_0x49a6bd],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x356c89='',_0x1c6e3f=0xa){let _0x564320='';for(let _0x562832=0x0;_0x562832<_0x1c6e3f;_0x562832++)_0x564320+=Math['floor'](Math['random']()*0xa);return _0x356c89+_0x564320;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x28f1fe){this['target']=_0x28f1fe,this['handlers']=new Set();}['removeMessageHandler'](_0x2faac2){_0x2faac2['messageChannel']&&(_0x2faac2['messageChannel']['port1']['removeEventListener']('message',_0x2faac2['onMessage']),_0x2faac2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2faac2);}async['_send'](_0x539555,_0xbb26a1,_0x23b03e=0x32){const _0x5f40f6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x5f40f6)throw new Error('connection_unavailable');let _0x2e5984,_0xaa49d1;return new Promise((_0x581c2b,_0x137d5c)=>{const _0x2eb356=As('',0x14);_0x5f40f6['port1']['start']();const _0x53898b=setTimeout(()=>{_0x137d5c(new Error('unsupported_event'));},_0x23b03e);_0xaa49d1={'messageChannel':_0x5f40f6,'onMessage'(_0x272a74){const _0x1cccac=_0x272a74;if(_0x1cccac['data']['eventId']===_0x2eb356)switch(_0x1cccac['data']['status']){case'ack':clearTimeout(_0x53898b),_0x2e5984=setTimeout(()=>{_0x137d5c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2e5984),_0x581c2b(_0x1cccac['data']['response']);break;default:clearTimeout(_0x53898b),clearTimeout(_0x2e5984),_0x137d5c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xaa49d1),_0x5f40f6['port1']['addEventListener']('message',_0xaa49d1['onMessage']),this['target']['postMessage']({'eventType':_0x539555,'eventId':_0x2eb356,'data':_0xbb26a1},[_0x5f40f6['port2']]);})['finally'](()=>{_0xaa49d1&&this['removeMessageHandler'](_0xaa49d1);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x699184){Z()['location']['href']=_0x699184;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4de3b7;return((_0x4de3b7=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4de3b7['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x31d8af){this['request']=_0x31d8af;}['toPromise'](){return new Promise((_0x11e419,_0x391d12)=>{this['request']['addEventListener']('success',()=>{_0x11e419(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x391d12(this['request']['error']);});});}}function Zn(_0x45b6b8,_0x5c0522){return _0x45b6b8['transaction']([Mn],_0x5c0522?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x1dd400=indexedDB['deleteDatabase'](Ka);return new nn(_0x1dd400)['toPromise']();}function Qa(){const _0x19f7f4=indexedDB['open'](Ka,pp);return new Promise((_0x49afca,_0x5258c6)=>{_0x19f7f4['addEventListener']('error',()=>{_0x5258c6(_0x19f7f4['error']);}),_0x19f7f4['addEventListener']('upgradeneeded',()=>{const _0x1b2bb0=_0x19f7f4['result'];try{_0x1b2bb0['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3dbb23){_0x5258c6(_0x3dbb23);}}),_0x19f7f4['addEventListener']('success',async()=>{const _0x4bd7a7=_0x19f7f4['result'];_0x4bd7a7['objectStoreNames']['contains'](Mn)?_0x49afca(_0x4bd7a7):(_0x4bd7a7['close'](),await _p(),_0x49afca(await Qa()));});});}async function Or(_0x38d11c,_0x5cc0d0,_0x648f91){const _0x38c9b4=Zn(_0x38d11c,!0x0)['put']({[Ya]:_0x5cc0d0,'value':_0x648f91});return new nn(_0x38c9b4)['toPromise']();}async function gp(_0x1e9fba,_0x5de73b){const _0x347523=Zn(_0x1e9fba,!0x1)['get'](_0x5de73b),_0x5a6506=await new nn(_0x347523)['toPromise']();return _0x5a6506===void 0x0?null:_0x5a6506['value'];}function Dr(_0x224894,_0x6216f8){const _0x1e2818=Zn(_0x224894,!0x0)['delete'](_0x6216f8);return new nn(_0x1e2818)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1bae39){let _0x375e22=0x0;for(;;)try{const _0xa601da=await this['_openDb']();return await _0x1bae39(_0xa601da);}catch(_0x57d066){if(_0x375e22++>yp)throw _0x57d066;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x3a2601,_0x4592e8)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4592e8['key'])})),this['receiver']['_subscribe']('ping',async(_0x358b90,_0x3313e8)=>['keyChanged']);}async['initializeSender'](){var _0x47e001,_0x276173;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x343b95=await this['sender']['_send']('ping',{},0x320);_0x343b95&&(_0x47e001=_0x343b95[0x0])!=null&&_0x47e001['fulfilled']&&(_0x276173=_0x343b95[0x0])!=null&&_0x276173['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x30ebf7){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x30ebf7},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3b1a01=>{await Or(_0x3b1a01,Dn,'1'),await Dr(_0x3b1a01,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x24fad1){this['pendingWrites']++;try{await _0x24fad1();}finally{this['pendingWrites']--;}}async['_set'](_0x6543ba,_0x5a395c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x465d85=>Or(_0x465d85,_0x6543ba,_0x5a395c)),this['localCache'][_0x6543ba]=_0x5a395c,this['notifyServiceWorker'](_0x6543ba)));}async['_get'](_0x27fb1f){const _0x2e2813=await this['_withRetries'](_0x4a71c3=>gp(_0x4a71c3,_0x27fb1f));return this['localCache'][_0x27fb1f]=_0x2e2813,_0x2e2813;}async['_remove'](_0x5cf1d4){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xfc882a=>Dr(_0xfc882a,_0x5cf1d4)),delete this['localCache'][_0x5cf1d4],this['notifyServiceWorker'](_0x5cf1d4)));}async['_poll'](){const _0x703830=await this['_withRetries'](_0x267021=>{const _0x464343=Zn(_0x267021,!0x1)['getAll']();return new nn(_0x464343)['toPromise']();});if(!_0x703830)return[];if(this['pendingWrites']!==0x0)return[];const _0x4fa793=[],_0x536311=new Set();if(_0x703830['length']!==0x0){for(const {fbase_key:_0x2c2d64,value:_0x5a0ff4}of _0x703830)_0x536311['add'](_0x2c2d64),JSON['stringify'](this['localCache'][_0x2c2d64])!==JSON['stringify'](_0x5a0ff4)&&(this['notifyListeners'](_0x2c2d64,_0x5a0ff4),_0x4fa793['push'](_0x2c2d64));}for(const _0x248968 of Object['keys'](this['localCache']))this['localCache'][_0x248968]&&!_0x536311['has'](_0x248968)&&(this['notifyListeners'](_0x248968,null),_0x4fa793['push'](_0x248968));return _0x4fa793;}['notifyListeners'](_0x3e454,_0x1940ac){this['localCache'][_0x3e454]=_0x1940ac;const _0x45fd43=this['listeners'][_0x3e454];if(_0x45fd43){for(const _0xb0798f of Array['from'](_0x45fd43))_0xb0798f(_0x1940ac);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x56dbf9,_0x8c8bc7){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x56dbf9]||(this['listeners'][_0x56dbf9]=new Set(),this['_get'](_0x56dbf9)),this['listeners'][_0x56dbf9]['add'](_0x8c8bc7);}['_removeListener'](_0x42e662,_0x23acd2){this['listeners'][_0x42e662]&&(this['listeners'][_0x42e662]['delete'](_0x23acd2),this['listeners'][_0x42e662]['size']===0x0&&delete this['listeners'][_0x42e662]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x3234e2,_0x4a0ce1){return _0x4a0ce1?ie(_0x4a0ce1):(m(_0x3234e2['_popupRedirectResolver'],_0x3234e2,'argument-error'),_0x3234e2['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2c9262){super('custom','custom'),this['params']=_0x2c9262;}['_getIdTokenResponse'](_0x42cac5){return nt(_0x42cac5,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1c0fea,_0x3775d0){return nt(_0x1c0fea,this['_buildIdpRequest'](_0x3775d0));}['_getReauthenticationResolver'](_0x35d5e8){return nt(_0x35d5e8,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x30801c){const _0x49139c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x30801c&&(_0x49139c['idToken']=_0x30801c),_0x49139c;}}function Ip(_0x4c23d9){return Va(_0x4c23d9['auth'],new ks(_0x4c23d9),_0x4c23d9['bypassAuthState']);}function wp(_0x15079a){const {auth:_0x38f416,user:_0x57d342}=_0x15079a;return m(_0x57d342,_0x38f416,'internal-error'),tp(_0x57d342,new ks(_0x15079a),_0x15079a['bypassAuthState']);}async function Cp(_0x1c4477){const {auth:_0x37edf5,user:_0x42087f}=_0x1c4477;return m(_0x42087f,_0x37edf5,'internal-error'),ep(_0x42087f,new ks(_0x1c4477),_0x1c4477['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x541607,_0x12a910,_0x31da24,_0x5de16b,_0x3e942e=!0x1){this['auth']=_0x541607,this['resolver']=_0x31da24,this['user']=_0x5de16b,this['bypassAuthState']=_0x3e942e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x12a910)?_0x12a910:[_0x12a910];}['execute'](){return new Promise(async(_0x2bbb5d,_0x57a7a5)=>{this['pendingPromise']={'resolve':_0x2bbb5d,'reject':_0x57a7a5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4ed7be){this['reject'](_0x4ed7be);}});}async['onAuthEvent'](_0x25f5ea){const {urlResponse:_0x389e53,sessionId:_0x3b17c8,postBody:_0x2ecb5d,tenantId:_0xe04639,error:_0x280fea,type:_0x164688}=_0x25f5ea;if(_0x280fea){this['reject'](_0x280fea);return;}const _0x40a2ab={'auth':this['auth'],'requestUri':_0x389e53,'sessionId':_0x3b17c8,'tenantId':_0xe04639||void 0x0,'postBody':_0x2ecb5d||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x164688)(_0x40a2ab));}catch(_0x1c5c03){this['reject'](_0x1c5c03);}}['onError'](_0x507306){this['reject'](_0x507306);}['getIdpTask'](_0x4cb60d){switch(_0x4cb60d){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3eaed3){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3eaed3),this['unregisterAndCleanUp']();}['reject'](_0x1bd7fd){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1bd7fd),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x3b0ae8,_0x31f687,_0x138ef2,_0x538ff7,_0x6c3414){super(_0x3b0ae8,_0x31f687,_0x538ff7,_0x6c3414),this['provider']=_0x138ef2,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x601f39=await this['execute']();return m(_0x601f39,this['auth'],'internal-error'),_0x601f39;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5e0d0b=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5e0d0b),this['authWindow']['associatedEvent']=_0x5e0d0b,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4f6f01=>{this['reject'](_0x4f6f01);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0xbc5200=>{_0xbc5200||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3fbd72;return((_0x3fbd72=this['authWindow'])==null?void 0x0:_0x3fbd72['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x294042=()=>{var _0x4fdde8,_0x19a1a6;if((_0x19a1a6=(_0x4fdde8=this['authWindow'])==null?void 0x0:_0x4fdde8['window'])!=null&&_0x19a1a6['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x294042,Tp['get']());};_0x294042();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x29660c,_0x31b5d7,_0x57434a=!0x1){super(_0x29660c,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x31b5d7,void 0x0,_0x57434a),this['eventId']=null;}async['execute'](){let _0x1fd00a=hn['get'](this['auth']['_key']());if(!_0x1fd00a){try{const _0xd3cd61=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x1fd00a=()=>Promise['resolve'](_0xd3cd61);}catch(_0x5a0a9a){_0x1fd00a=()=>Promise['reject'](_0x5a0a9a);}hn['set'](this['auth']['_key'](),_0x1fd00a);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1fd00a();}async['onAuthEvent'](_0x4933d7){if(_0x4933d7['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4933d7);if(_0x4933d7['type']==='unknown'){this['resolve'](null);return;}if(_0x4933d7['eventId']){const _0x16e05c=await this['auth']['_redirectUserForId'](_0x4933d7['eventId']);if(_0x16e05c)return this['user']=_0x16e05c,super['onAuthEvent'](_0x4933d7);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4b5ddc,_0x8f8c78){const _0x137325=Pp(_0x8f8c78),_0x34b2c6=kp(_0x4b5ddc);if(!await _0x34b2c6['_isAvailable']())return!0x1;const _0xb3f32a=await _0x34b2c6['_get'](_0x137325)==='true';return await _0x34b2c6['_remove'](_0x137325),_0xb3f32a;}function Ap(_0x303a4f,_0x2c9a3f){hn['set'](_0x303a4f['_key'](),_0x2c9a3f);}function kp(_0x26c8ba){return ie(_0x26c8ba['_redirectPersistence']);}function Pp(_0x114305){return ln(Sp,_0x114305['config']['apiKey'],_0x114305['name']);}async function Np(_0x41e167,_0x509a43,_0xea580c=!0x1){if($(_0x41e167['app']))return Promise['reject'](re(_0x41e167));const _0x2dfa18=Ke(_0x41e167),_0x41cdbd=Ep(_0x2dfa18,_0x509a43),_0x1148ad=await new bp(_0x2dfa18,_0x41cdbd,_0xea580c)['execute']();return _0x1148ad&&!_0xea580c&&(delete _0x1148ad['user']['_redirectEventId'],await _0x2dfa18['_persistUserIfCurrent'](_0x1148ad['user']),await _0x2dfa18['_setRedirectUser'](null,_0x509a43)),_0x1148ad;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x4b2f2d){this['auth']=_0x4b2f2d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x27c69c){this['consumers']['add'](_0x27c69c),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x27c69c)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x27c69c),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5ec065){this['consumers']['delete'](_0x5ec065);}['onEvent'](_0x6c1c77){if(this['hasEventBeenHandled'](_0x6c1c77))return!0x1;let _0xc40b10=!0x1;return this['consumers']['forEach'](_0x15551a=>{this['isEventForConsumer'](_0x6c1c77,_0x15551a)&&(_0xc40b10=!0x0,this['sendToConsumer'](_0x6c1c77,_0x15551a),this['saveEventToCache'](_0x6c1c77));}),this['hasHandledPotentialRedirect']||!Mp(_0x6c1c77)||(this['hasHandledPotentialRedirect']=!0x0,_0xc40b10||(this['queuedRedirectEvent']=_0x6c1c77,_0xc40b10=!0x0)),_0xc40b10;}['sendToConsumer'](_0x18b412,_0x223e37){var _0x364c84;if(_0x18b412['error']&&!Za(_0x18b412)){const _0x5010f2=((_0x364c84=_0x18b412['error']['code'])==null?void 0x0:_0x364c84['split']('auth/')[0x1])||'internal-error';_0x223e37['onError'](X(this['auth'],_0x5010f2));}else _0x223e37['onAuthEvent'](_0x18b412);}['isEventForConsumer'](_0x3d5900,_0x174ca6){const _0x29838f=_0x174ca6['eventId']===null||!!_0x3d5900['eventId']&&_0x3d5900['eventId']===_0x174ca6['eventId'];return _0x174ca6['filter']['includes'](_0x3d5900['type'])&&_0x29838f;}['hasEventBeenHandled'](_0x2fcb13){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2fcb13));}['saveEventToCache'](_0x153f42){this['cachedEventUids']['add'](Mr(_0x153f42)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x3bd4ab){return[_0x3bd4ab['type'],_0x3bd4ab['eventId'],_0x3bd4ab['sessionId'],_0x3bd4ab['tenantId']]['filter'](_0x19681d=>_0x19681d)['join']('-');}function Za({type:_0x52b929,error:_0x2d5f7b}){return _0x52b929==='unknown'&&(_0x2d5f7b==null?void 0x0:_0x2d5f7b['code'])==='auth/no-auth-event';}function Mp(_0x19317f){switch(_0x19317f['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x19317f);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x190a84,_0x5d207b={}){return Pe(_0x190a84,'GET','/v1/projects',_0x5d207b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x5cfdd2){if(_0x5cfdd2['config']['emulator'])return;const {authorizedDomains:_0x768829}=await Lp(_0x5cfdd2);for(const _0x358d69 of _0x768829)try{if(Wp(_0x358d69))return;}catch{}Y(_0x5cfdd2,'unauthorized-domain');}function Wp(_0x1f2075){const _0xb6056f=Mi(),{protocol:_0x1da357,hostname:_0xfdee25}=new URL(_0xb6056f);if(_0x1f2075['startsWith']('chrome-extension://')){const _0x4ad94c=new URL(_0x1f2075);return _0x4ad94c['hostname']===''&&_0xfdee25===''?_0x1da357==='chrome-extension:'&&_0x1f2075['replace']('chrome-extension://','')===_0xb6056f['replace']('chrome-extension://',''):_0x1da357==='chrome-extension:'&&_0x4ad94c['hostname']===_0xfdee25;}if(!Fp['test'](_0x1da357))return!0x1;if(xp['test'](_0x1f2075))return _0xfdee25===_0x1f2075;const _0x3022ae=_0x1f2075['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3022ae+'|'+_0x3022ae+')$','i')['test'](_0xfdee25);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x186412=Z()['___jsl'];if(_0x186412!=null&&_0x186412['H']){for(const _0x544a30 of Object['keys'](_0x186412['H']))if(_0x186412['H'][_0x544a30]['r']=_0x186412['H'][_0x544a30]['r']||[],_0x186412['H'][_0x544a30]['L']=_0x186412['H'][_0x544a30]['L']||[],_0x186412['H'][_0x544a30]['r']=[..._0x186412['H'][_0x544a30]['L']],_0x186412['CP']){for(let _0x1679b1=0x0;_0x1679b1<_0x186412['CP']['length'];_0x1679b1++)_0x186412['CP'][_0x1679b1]=null;}}}function Vp(_0x53c406){return new Promise((_0x48a0ca,_0x3cc22d)=>{var _0x2c7555,_0x21cbd2,_0x16bac1;function _0xb0ab20(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x48a0ca(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x3cc22d(X(_0x53c406,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x21cbd2=(_0x2c7555=Z()['gapi'])==null?void 0x0:_0x2c7555['iframes'])!=null&&_0x21cbd2['Iframe'])_0x48a0ca(gapi['iframes']['getContext']());else{if((_0x16bac1=Z()['gapi'])!=null&&_0x16bac1['load'])_0xb0ab20();else{const _0x478756=Ff('iframefcb');return Z()[_0x478756]=()=>{gapi['load']?_0xb0ab20():_0x3cc22d(X(_0x53c406,'network-request-failed'));},xa(xf()+'?onload='+_0x478756)['catch'](_0x3b8662=>_0x3cc22d(_0x3b8662));}}})['catch'](_0x1e5345=>{throw un=null,_0x1e5345;});}let un=null;function Hp(_0x4f5504){return un=un||Vp(_0x4f5504),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x321c45){const _0x5a75bb=_0x321c45['config'];m(_0x5a75bb['authDomain'],_0x321c45,'auth-domain-config-required');const _0x403409=_0x5a75bb['emulator']?Cs(_0x5a75bb,qp):'https://'+_0x321c45['config']['authDomain']+'/'+Gp,_0x11a901={'apiKey':_0x5a75bb['apiKey'],'appName':_0x321c45['name'],'v':dt},_0x12ff69=jp['get'](_0x321c45['config']['apiHost']);_0x12ff69&&(_0x11a901['eid']=_0x12ff69);const _0x588a66=_0x321c45['_getFrameworks']();return _0x588a66['length']&&(_0x11a901['fw']=_0x588a66['join'](',')),_0x403409+'?'+ut(_0x11a901)['slice'](0x1);}async function Yp(_0x243b22){const _0x193f01=await Hp(_0x243b22),_0x1b0a3f=Z()['gapi'];return m(_0x1b0a3f,_0x243b22,'internal-error'),_0x193f01['open']({'where':document['body'],'url':Kp(_0x243b22),'messageHandlersFilter':_0x1b0a3f['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x3c5fb8=>new Promise(async(_0x4b6a83,_0x3b5953)=>{await _0x3c5fb8['restyle']({'setHideOnLeave':!0x1});const _0x569cd=X(_0x243b22,'network-request-failed'),_0x35490a=Z()['setTimeout'](()=>{_0x3b5953(_0x569cd);},$p['get']());function _0x3e7ec2(){Z()['clearTimeout'](_0x35490a),_0x4b6a83(_0x3c5fb8);}_0x3c5fb8['ping'](_0x3e7ec2)['then'](_0x3e7ec2,()=>{_0x3b5953(_0x569cd);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x36b633){this['window']=_0x36b633,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x1d7190,_0x68ef0e,_0x408442,_0x469a65=Jp,_0x299e3f=Xp){const _0x2874f6=Math['max']((window['screen']['availHeight']-_0x299e3f)/0x2,0x0)['toString'](),_0x30a847=Math['max']((window['screen']['availWidth']-_0x469a65)/0x2,0x0)['toString']();let _0x4f1d33='';const _0xa97baf={...Qp,'width':_0x469a65['toString'](),'height':_0x299e3f['toString'](),'top':_0x2874f6,'left':_0x30a847},_0x30e835=W()['toLowerCase']();_0x408442&&(_0x4f1d33=ka(_0x30e835)?Zp:_0x408442),Ra(_0x30e835)&&(_0x68ef0e=_0x68ef0e||e_,_0xa97baf['scrollbars']='yes');const _0x269100=Object['entries'](_0xa97baf)['reduce']((_0x2e7754,[_0x5038f9,_0xec677b])=>''+_0x2e7754+_0x5038f9+'='+_0xec677b+',','');if(Rf(_0x30e835)&&_0x4f1d33!=='_self')return n_(_0x68ef0e||'',_0x4f1d33),new xr(null);const _0xe21db5=window['open'](_0x68ef0e||'',_0x4f1d33,_0x269100);m(_0xe21db5,_0x1d7190,'popup-blocked');try{_0xe21db5['focus']();}catch{}return new xr(_0xe21db5);}function n_(_0x552427,_0x440deb){const _0x1bfe1b=document['createElement']('a');_0x1bfe1b['href']=_0x552427,_0x1bfe1b['target']=_0x440deb;const _0xf82225=document['createEvent']('MouseEvent');_0xf82225['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1bfe1b['dispatchEvent'](_0xf82225);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x1a15d7,_0x4b3dd4,_0x5533d7,_0x421cef,_0x57f39a,_0x963ff8){m(_0x1a15d7['config']['authDomain'],_0x1a15d7,'auth-domain-config-required'),m(_0x1a15d7['config']['apiKey'],_0x1a15d7,'invalid-api-key');const _0x3d2ef1={'apiKey':_0x1a15d7['config']['apiKey'],'appName':_0x1a15d7['name'],'authType':_0x5533d7,'redirectUrl':_0x421cef,'v':dt,'eventId':_0x57f39a};if(_0x4b3dd4 instanceof Wa){_0x4b3dd4['setDefaultLanguage'](_0x1a15d7['languageCode']),_0x3d2ef1['providerId']=_0x4b3dd4['providerId']||'',pn(_0x4b3dd4['getCustomParameters']())||(_0x3d2ef1['customParameters']=JSON['stringify'](_0x4b3dd4['getCustomParameters']()));for(const [_0x377d19,_0xed1233]of Object['entries']({}))_0x3d2ef1[_0x377d19]=_0xed1233;}if(_0x4b3dd4 instanceof tn){const _0x8bfc62=_0x4b3dd4['getScopes']()['filter'](_0x571822=>_0x571822!=='');_0x8bfc62['length']>0x0&&(_0x3d2ef1['scopes']=_0x8bfc62['join'](','));}_0x1a15d7['tenantId']&&(_0x3d2ef1['tid']=_0x1a15d7['tenantId']);const _0x19ef9b=_0x3d2ef1;for(const _0x5ccd1a of Object['keys'](_0x19ef9b))_0x19ef9b[_0x5ccd1a]===void 0x0&&delete _0x19ef9b[_0x5ccd1a];const _0x4f4c57=await _0x1a15d7['_getAppCheckToken'](),_0x180f5d=_0x4f4c57?'#'+r_+'='+encodeURIComponent(_0x4f4c57):'';return o_(_0x1a15d7)+'?'+ut(_0x19ef9b)['slice'](0x1)+_0x180f5d;}function o_({config:_0x372081}){return _0x372081['emulator']?Cs(_0x372081,s_):'https://'+_0x372081['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x59d813,_0x23584e,_0x2ee8be,_0x5dae6b){var _0x43d518;ce((_0x43d518=this['eventManagers'][_0x59d813['_key']()])==null?void 0x0:_0x43d518['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x33f7b8=await Fr(_0x59d813,_0x23584e,_0x2ee8be,Mi(),_0x5dae6b);return t_(_0x59d813,_0x33f7b8,As());}async['_openRedirect'](_0x208746,_0x120457,_0xc56848,_0x303282){await this['_originValidation'](_0x208746);const _0x3b0ddd=await Fr(_0x208746,_0x120457,_0xc56848,Mi(),_0x303282);return hp(_0x3b0ddd),new Promise(()=>{});}['_initialize'](_0xb519d4){const _0x502c45=_0xb519d4['_key']();if(this['eventManagers'][_0x502c45]){const {manager:_0x647551,promise:_0x49b7d0}=this['eventManagers'][_0x502c45];return _0x647551?Promise['resolve'](_0x647551):(ce(_0x49b7d0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x49b7d0);}const _0x55ade3=this['initAndGetManager'](_0xb519d4);return this['eventManagers'][_0x502c45]={'promise':_0x55ade3},_0x55ade3['catch'](()=>{delete this['eventManagers'][_0x502c45];}),_0x55ade3;}async['initAndGetManager'](_0x5bbdc4){const _0x3d9c41=await Yp(_0x5bbdc4),_0x39d461=new Dp(_0x5bbdc4);return _0x3d9c41['register']('authEvent',_0x2e6f12=>(m(_0x2e6f12==null?void 0x0:_0x2e6f12['authEvent'],_0x5bbdc4,'invalid-auth-event'),{'status':_0x39d461['onEvent'](_0x2e6f12['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5bbdc4['_key']()]={'manager':_0x39d461},this['iframes'][_0x5bbdc4['_key']()]=_0x3d9c41,_0x39d461;}['_isIframeWebStorageSupported'](_0xaacba8,_0x1a839d){this['iframes'][_0xaacba8['_key']()]['send'](pi,{'type':pi},_0x500f88=>{var _0x16fd3b;const _0x5476ad=(_0x16fd3b=_0x500f88==null?void 0x0:_0x500f88[0x0])==null?void 0x0:_0x16fd3b[pi];_0x5476ad!==void 0x0&&_0x1a839d(!!_0x5476ad),Y(_0xaacba8,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1cad6a){const _0x316134=_0x1cad6a['_key']();return this['originValidationPromises'][_0x316134]||(this['originValidationPromises'][_0x316134]=Up(_0x1cad6a)),this['originValidationPromises'][_0x316134];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0xbc8ac0){this['auth']=_0xbc8ac0,this['internalListeners']=new Map();}['getUid'](){var _0x2c4baa;return this['assertAuthConfigured'](),((_0x2c4baa=this['auth']['currentUser'])==null?void 0x0:_0x2c4baa['uid'])||null;}async['getToken'](_0x14a322){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x14a322)}:null;}['addAuthTokenListener'](_0x46eddd){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x46eddd))return;const _0x401c65=this['auth']['onIdTokenChanged'](_0x13a3f5=>{_0x46eddd((_0x13a3f5==null?void 0x0:_0x13a3f5['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x46eddd,_0x401c65),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x26a4e1){this['assertAuthConfigured']();const _0x371a7b=this['internalListeners']['get'](_0x26a4e1);_0x371a7b&&(this['internalListeners']['delete'](_0x26a4e1),_0x371a7b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x156002){switch(_0x156002){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x9fe6ae){st(new Fe('auth',(_0xb654a1,{options:_0x194f64})=>{const _0x408e41=_0xb654a1['getProvider']('app')['getImmediate'](),_0x37a7da=_0xb654a1['getProvider']('heartbeat'),_0x2a2b8b=_0xb654a1['getProvider']('app-check-internal'),{apiKey:_0xa81033,authDomain:_0x413f84}=_0x408e41['options'];m(_0xa81033&&!_0xa81033['includes'](':'),'invalid-api-key',{'appName':_0x408e41['name']});const _0x45bee0={'apiKey':_0xa81033,'authDomain':_0x413f84,'clientPlatform':_0x9fe6ae,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x9fe6ae)},_0x50454c=new Df(_0x408e41,_0x37a7da,_0x2a2b8b,_0x45bee0);return Hf(_0x50454c,_0x194f64),_0x50454c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x505b78,_0x37ece3,_0x307d9d)=>{_0x505b78['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x23c83f=>{const _0xf6595=Ke(_0x23c83f['getProvider']('auth')['getImmediate']());return(_0x257ce9=>new l_(_0x257ce9))(_0xf6595);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x9fe6ae)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0xc494df=>async _0x326746=>{const _0x81368a=_0x326746&&await _0x326746['getIdTokenResult'](),_0x4b81c9=_0x81368a&&(new Date()['getTime']()-Date['parse'](_0x81368a['issuedAtTime']))/0x3e8;if(_0x4b81c9&&_0x4b81c9>f_)return;const _0x176199=_0x81368a==null?void 0x0:_0x81368a['token'];Br!==_0x176199&&(Br=_0x176199,await fetch(_0xc494df,{'method':_0x176199?'POST':'DELETE','headers':_0x176199?{'Authorization':'Bearer\x20'+_0x176199}:{}}));};function B_(_0x15d470=Zr()){const _0x380dec=Hi(_0x15d470,'auth');if(_0x380dec['isInitialized']())return _0x380dec['getImmediate']();const _0x48fd9f=Vf(_0x15d470,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x5754b4=jr('authTokenSyncURL');if(_0x5754b4&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x36bb8d=new URL(_0x5754b4,location['origin']);if(location['origin']===_0x36bb8d['origin']){const _0x37f138=p_(_0x36bb8d['toString']());sp(_0x48fd9f,_0x37f138,()=>_0x37f138(_0x48fd9f['currentUser'])),ip(_0x48fd9f,_0x3fff01=>_0x37f138(_0x3fff01));}}const _0x4ffa42=qr('auth');return _0x4ffa42&&$f(_0x48fd9f,'http://'+_0x4ffa42),_0x48fd9f;}function __(){var _0x28de4f;return((_0x28de4f=document['getElementsByTagName']('head'))==null?void 0x0:_0x28de4f[0x0])??document;}Mf({'loadJS'(_0x1a4e73){return new Promise((_0x4dfe2a,_0x546526)=>{const _0x4517a7=document['createElement']('script');_0x4517a7['setAttribute']('src',_0x1a4e73),_0x4517a7['onload']=_0x4dfe2a,_0x4517a7['onerror']=_0xe909f3=>{const _0x30ccf2=X('internal-error');_0x30ccf2['customData']=_0xe909f3,_0x546526(_0x30ccf2);},_0x4517a7['type']='text/javascript',_0x4517a7['charset']='UTF-8',__()['appendChild'](_0x4517a7);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,x_ as e,m_ as f,g_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};