const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x21e246,_0x4f90c5){if(!_0x21e246)throw ht(_0x4f90c5);},ht=function(_0x248175){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x248175);},Hr=function(_0x3e8404){const _0x473e37=[];let _0xd03de8=0x0;for(let _0x111cea=0x0;_0x111cea<_0x3e8404['length'];_0x111cea++){let _0x395398=_0x3e8404['charCodeAt'](_0x111cea);_0x395398<0x80?_0x473e37[_0xd03de8++]=_0x395398:_0x395398<0x800?(_0x473e37[_0xd03de8++]=_0x395398>>0x6|0xc0,_0x473e37[_0xd03de8++]=_0x395398&0x3f|0x80):(_0x395398&0xfc00)===0xd800&&_0x111cea+0x1<_0x3e8404['length']&&(_0x3e8404['charCodeAt'](_0x111cea+0x1)&0xfc00)===0xdc00?(_0x395398=0x10000+((_0x395398&0x3ff)<<0xa)+(_0x3e8404['charCodeAt'](++_0x111cea)&0x3ff),_0x473e37[_0xd03de8++]=_0x395398>>0x12|0xf0,_0x473e37[_0xd03de8++]=_0x395398>>0xc&0x3f|0x80,_0x473e37[_0xd03de8++]=_0x395398>>0x6&0x3f|0x80,_0x473e37[_0xd03de8++]=_0x395398&0x3f|0x80):(_0x473e37[_0xd03de8++]=_0x395398>>0xc|0xe0,_0x473e37[_0xd03de8++]=_0x395398>>0x6&0x3f|0x80,_0x473e37[_0xd03de8++]=_0x395398&0x3f|0x80);}return _0x473e37;},nc=function(_0x1ad1bc){const _0x2c2327=[];let _0x533abc=0x0,_0x4ec1e7=0x0;for(;_0x533abc<_0x1ad1bc['length'];){const _0x57a2be=_0x1ad1bc[_0x533abc++];if(_0x57a2be<0x80)_0x2c2327[_0x4ec1e7++]=String['fromCharCode'](_0x57a2be);else{if(_0x57a2be>0xbf&&_0x57a2be<0xe0){const _0x1ae880=_0x1ad1bc[_0x533abc++];_0x2c2327[_0x4ec1e7++]=String['fromCharCode']((_0x57a2be&0x1f)<<0x6|_0x1ae880&0x3f);}else{if(_0x57a2be>0xef&&_0x57a2be<0x16d){const _0x4efbbe=_0x1ad1bc[_0x533abc++],_0x3cd356=_0x1ad1bc[_0x533abc++],_0x221900=_0x1ad1bc[_0x533abc++],_0x35757a=((_0x57a2be&0x7)<<0x12|(_0x4efbbe&0x3f)<<0xc|(_0x3cd356&0x3f)<<0x6|_0x221900&0x3f)-0x10000;_0x2c2327[_0x4ec1e7++]=String['fromCharCode'](0xd800+(_0x35757a>>0xa)),_0x2c2327[_0x4ec1e7++]=String['fromCharCode'](0xdc00+(_0x35757a&0x3ff));}else{const _0x2508a7=_0x1ad1bc[_0x533abc++],_0x4630d6=_0x1ad1bc[_0x533abc++];_0x2c2327[_0x4ec1e7++]=String['fromCharCode']((_0x57a2be&0xf)<<0xc|(_0x2508a7&0x3f)<<0x6|_0x4630d6&0x3f);}}}}return _0x2c2327['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1aba52,_0x59b4ec){if(!Array['isArray'](_0x1aba52))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x585ca4=_0x59b4ec?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5b53b2=[];for(let _0x287385=0x0;_0x287385<_0x1aba52['length'];_0x287385+=0x3){const _0x1a1e98=_0x1aba52[_0x287385],_0x4e2678=_0x287385+0x1<_0x1aba52['length'],_0x28d82c=_0x4e2678?_0x1aba52[_0x287385+0x1]:0x0,_0x31f526=_0x287385+0x2<_0x1aba52['length'],_0x1bfe34=_0x31f526?_0x1aba52[_0x287385+0x2]:0x0,_0x124960=_0x1a1e98>>0x2,_0x125adc=(_0x1a1e98&0x3)<<0x4|_0x28d82c>>0x4;let _0x7fa834=(_0x28d82c&0xf)<<0x2|_0x1bfe34>>0x6,_0x26ad38=_0x1bfe34&0x3f;_0x31f526||(_0x26ad38=0x40,_0x4e2678||(_0x7fa834=0x40)),_0x5b53b2['push'](_0x585ca4[_0x124960],_0x585ca4[_0x125adc],_0x585ca4[_0x7fa834],_0x585ca4[_0x26ad38]);}return _0x5b53b2['join']('');},'encodeString'(_0x135fc9,_0x2b6869){return this['HAS_NATIVE_SUPPORT']&&!_0x2b6869?btoa(_0x135fc9):this['encodeByteArray'](Hr(_0x135fc9),_0x2b6869);},'decodeString'(_0x4597e0,_0x37b2a5){return this['HAS_NATIVE_SUPPORT']&&!_0x37b2a5?atob(_0x4597e0):nc(this['decodeStringToByteArray'](_0x4597e0,_0x37b2a5));},'decodeStringToByteArray'(_0xc575d6,_0x219194){this['init_']();const _0x15f555=_0x219194?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4b9b3e=[];for(let _0x670467=0x0;_0x670467<_0xc575d6['length'];){const _0x495282=_0x15f555[_0xc575d6['charAt'](_0x670467++)],_0x402b1c=_0x670467<_0xc575d6['length']?_0x15f555[_0xc575d6['charAt'](_0x670467)]:0x0;++_0x670467;const _0x5eb7e9=_0x670467<_0xc575d6['length']?_0x15f555[_0xc575d6['charAt'](_0x670467)]:0x40;++_0x670467;const _0x50da00=_0x670467<_0xc575d6['length']?_0x15f555[_0xc575d6['charAt'](_0x670467)]:0x40;if(++_0x670467,_0x495282==null||_0x402b1c==null||_0x5eb7e9==null||_0x50da00==null)throw new ic();const _0x205ae7=_0x495282<<0x2|_0x402b1c>>0x4;if(_0x4b9b3e['push'](_0x205ae7),_0x5eb7e9!==0x40){const _0x4ddf1e=_0x402b1c<<0x4&0xf0|_0x5eb7e9>>0x2;if(_0x4b9b3e['push'](_0x4ddf1e),_0x50da00!==0x40){const _0x4deac7=_0x5eb7e9<<0x6&0xc0|_0x50da00;_0x4b9b3e['push'](_0x4deac7);}}}return _0x4b9b3e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x26f03c=0x0;_0x26f03c<this['ENCODED_VALS']['length'];_0x26f03c++)this['byteToCharMap_'][_0x26f03c]=this['ENCODED_VALS']['charAt'](_0x26f03c),this['charToByteMap_'][this['byteToCharMap_'][_0x26f03c]]=_0x26f03c,this['byteToCharMapWebSafe_'][_0x26f03c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26f03c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x26f03c]]=_0x26f03c,_0x26f03c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x26f03c)]=_0x26f03c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x26f03c)]=_0x26f03c);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x2e2d50){const _0xbc1987=Hr(_0x2e2d50);return Fi['encodeByteArray'](_0xbc1987,!0x0);},dn=function(_0x1860f4){return $r(_0x1860f4)['replace'](/\./g,'');},fn=function(_0x1ce4c6){try{return Fi['decodeString'](_0x1ce4c6,!0x0);}catch(_0x3d8d5c){console['error']('base64Decode\x20failed:\x20',_0x3d8d5c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3af7f2){return Gr(void 0x0,_0x3af7f2);}function Gr(_0x8ef55c,_0x38c03c){if(!(_0x38c03c instanceof Object))return _0x38c03c;switch(_0x38c03c['constructor']){case Date:const _0xa0686e=_0x38c03c;return new Date(_0xa0686e['getTime']());case Object:_0x8ef55c===void 0x0&&(_0x8ef55c={});break;case Array:_0x8ef55c=[];break;default:return _0x38c03c;}for(const _0x5c7632 in _0x38c03c)!_0x38c03c['hasOwnProperty'](_0x5c7632)||!rc(_0x5c7632)||(_0x8ef55c[_0x5c7632]=Gr(_0x8ef55c[_0x5c7632],_0x38c03c[_0x5c7632]));return _0x8ef55c;}function rc(_0x32bab2){return _0x32bab2!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xf4d3a3=Ps['__FIREBASE_DEFAULTS__'];if(_0xf4d3a3)return JSON['parse'](_0xf4d3a3);},lc=()=>{if(typeof document>'u')return;let _0x3cf2f7;try{_0x3cf2f7=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x31a1a0=_0x3cf2f7&&fn(_0x3cf2f7[0x1]);return _0x31a1a0&&JSON['parse'](_0x31a1a0);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x2f00a6){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x2f00a6);return;}},qr=_0x26ee32=>{var _0x547eed,_0x17cc55;return(_0x17cc55=(_0x547eed=Ui())==null?void 0x0:_0x547eed['emulatorHosts'])==null?void 0x0:_0x17cc55[_0x26ee32];},hc=_0x5a9470=>{const _0x8c2557=qr(_0x5a9470);if(!_0x8c2557)return;const _0x3c300d=_0x8c2557['lastIndexOf'](':');if(_0x3c300d<=0x0||_0x3c300d+0x1===_0x8c2557['length'])throw new Error('Invalid\x20host\x20'+_0x8c2557+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2c1b93=parseInt(_0x8c2557['substring'](_0x3c300d+0x1),0xa);return _0x8c2557[0x0]==='['?[_0x8c2557['substring'](0x1,_0x3c300d-0x1),_0x2c1b93]:[_0x8c2557['substring'](0x0,_0x3c300d),_0x2c1b93];},zr=()=>{var _0x504b55;return(_0x504b55=Ui())==null?void 0x0:_0x504b55['config'];},jr=_0x82fe89=>{var _0x50c234;return(_0x50c234=Ui())==null?void 0x0:_0x50c234['_'+_0x82fe89];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xf5d46e,_0x412c25)=>{this['resolve']=_0xf5d46e,this['reject']=_0x412c25;});}['wrapCallback'](_0x14159f){return(_0x4d37d0,_0x59a95d)=>{_0x4d37d0?this['reject'](_0x4d37d0):this['resolve'](_0x59a95d),typeof _0x14159f=='function'&&(this['promise']['catch'](()=>{}),_0x14159f['length']===0x1?_0x14159f(_0x4d37d0):_0x14159f(_0x4d37d0,_0x59a95d));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x56b2db,_0x62672){if(_0x56b2db['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x40be2d={'alg':'none','type':'JWT'},_0x46987d=_0x62672||'demo-project',_0x2c32d1=_0x56b2db['iat']||0x0,_0x1c6872=_0x56b2db['sub']||_0x56b2db['user_id'];if(!_0x1c6872)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x560e29={'iss':'https://securetoken.google.com/'+_0x46987d,'aud':_0x46987d,'iat':_0x2c32d1,'exp':_0x2c32d1+0xe10,'auth_time':_0x2c32d1,'sub':_0x1c6872,'user_id':_0x1c6872,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x56b2db};return[dn(JSON['stringify'](_0x40be2d)),dn(JSON['stringify'](_0x560e29)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x32c0da=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x32c0da=='object'&&_0x32c0da['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x546026=W();return _0x546026['indexOf']('MSIE\x20')>=0x0||_0x546026['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0xd145dd,_0x5347aa)=>{try{let _0xce23af=!0x0;const _0x1aade4='validate-browser-context-for-indexeddb-analytics-module',_0xebac75=self['indexedDB']['open'](_0x1aade4);_0xebac75['onsuccess']=()=>{_0xebac75['result']['close'](),_0xce23af||self['indexedDB']['deleteDatabase'](_0x1aade4),_0xd145dd(!0x0);},_0xebac75['onupgradeneeded']=()=>{_0xce23af=!0x1;},_0xebac75['onerror']=()=>{var _0x19c19f;_0x5347aa(((_0x19c19f=_0xebac75['error'])==null?void 0x0:_0x19c19f['message'])||'');};}catch(_0x4efde6){_0x5347aa(_0x4efde6);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x31a527,_0x5171f1,_0xd36521){super(_0x5171f1),this['code']=_0x31a527,this['customData']=_0xd36521,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x42c0aa,_0x60edd5,_0x398d51){this['service']=_0x42c0aa,this['serviceName']=_0x60edd5,this['errors']=_0x398d51;}['create'](_0x3b19ef,..._0x50ac6a){const _0x2f3740=_0x50ac6a[0x0]||{},_0x1021f9=this['service']+'/'+_0x3b19ef,_0x59b1f1=this['errors'][_0x3b19ef],_0x506fc2=_0x59b1f1?vc(_0x59b1f1,_0x2f3740):'Error',_0x549709=this['serviceName']+':\x20'+_0x506fc2+'\x20('+_0x1021f9+').';return new Re(_0x1021f9,_0x549709,_0x2f3740);}}function vc(_0x61aefe,_0x529071){return _0x61aefe['replace'](Ec,(_0x34b784,_0x7a44f7)=>{const _0x51d413=_0x529071[_0x7a44f7];return _0x51d413!=null?String(_0x51d413):'<'+_0x7a44f7+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x15ba44){return JSON['parse'](_0x15ba44);}function O(_0x412125){return JSON['stringify'](_0x412125);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5687cd){let _0x1ef333={},_0x19076e={},_0x1c7147={},_0x7779d5='';try{const _0x2428c8=_0x5687cd['split']('.');_0x1ef333=Nt(fn(_0x2428c8[0x0])||''),_0x19076e=Nt(fn(_0x2428c8[0x1])||''),_0x7779d5=_0x2428c8[0x2],_0x1c7147=_0x19076e['d']||{},delete _0x19076e['d'];}catch{}return{'header':_0x1ef333,'claims':_0x19076e,'data':_0x1c7147,'signature':_0x7779d5};},Ic=function(_0x729208){const _0x1d2dec=Yr(_0x729208),_0x199707=_0x1d2dec['claims'];return!!_0x199707&&typeof _0x199707=='object'&&_0x199707['hasOwnProperty']('iat');},wc=function(_0x3ab458){const _0x5a1717=Yr(_0x3ab458)['claims'];return typeof _0x5a1717=='object'&&_0x5a1717['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5f9b11,_0x5b7dfa){return Object['prototype']['hasOwnProperty']['call'](_0x5f9b11,_0x5b7dfa);}function Le(_0x5a984d,_0x238026){if(Object['prototype']['hasOwnProperty']['call'](_0x5a984d,_0x238026))return _0x5a984d[_0x238026];}function pn(_0x57c455){for(const _0x1cfd31 in _0x57c455)if(Object['prototype']['hasOwnProperty']['call'](_0x57c455,_0x1cfd31))return!0x1;return!0x0;}function _n(_0xfeba20,_0x478886,_0x557858){const _0x6bc976={};for(const _0x16f115 in _0xfeba20)Object['prototype']['hasOwnProperty']['call'](_0xfeba20,_0x16f115)&&(_0x6bc976[_0x16f115]=_0x478886['call'](_0x557858,_0xfeba20[_0x16f115],_0x16f115,_0xfeba20));return _0x6bc976;}function xe(_0x3497e5,_0x1f92b3){if(_0x3497e5===_0x1f92b3)return!0x0;const _0x4be7d5=Object['keys'](_0x3497e5),_0x49e6ef=Object['keys'](_0x1f92b3);for(const _0x20b7c7 of _0x4be7d5){if(!_0x49e6ef['includes'](_0x20b7c7))return!0x1;const _0x11927b=_0x3497e5[_0x20b7c7],_0x5c6093=_0x1f92b3[_0x20b7c7];if(Ns(_0x11927b)&&Ns(_0x5c6093)){if(!xe(_0x11927b,_0x5c6093))return!0x1;}else{if(_0x11927b!==_0x5c6093)return!0x1;}}for(const _0x26bb39 of _0x49e6ef)if(!_0x4be7d5['includes'](_0x26bb39))return!0x1;return!0x0;}function Ns(_0x3f948e){return _0x3f948e!==null&&typeof _0x3f948e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x484f6b){const _0x5359d3=[];for(const [_0x4b6d8c,_0x2950c7]of Object['entries'](_0x484f6b))Array['isArray'](_0x2950c7)?_0x2950c7['forEach'](_0x441796=>{_0x5359d3['push'](encodeURIComponent(_0x4b6d8c)+'='+encodeURIComponent(_0x441796));}):_0x5359d3['push'](encodeURIComponent(_0x4b6d8c)+'='+encodeURIComponent(_0x2950c7));return _0x5359d3['length']?'&'+_0x5359d3['join']('&'):'';}function Ct(_0x4bd1a3){const _0x49b020={};return _0x4bd1a3['replace'](/^\?/,'')['split']('&')['forEach'](_0x194842=>{if(_0x194842){const [_0x41f8b0,_0x4949ca]=_0x194842['split']('=');_0x49b020[decodeURIComponent(_0x41f8b0)]=decodeURIComponent(_0x4949ca);}}),_0x49b020;}function Tt(_0x545843){const _0x552772=_0x545843['indexOf']('?');if(!_0x552772)return'';const _0x309738=_0x545843['indexOf']('#',_0x552772);return _0x545843['substring'](_0x552772,_0x309738>0x0?_0x309738:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3d50dc=0x1;_0x3d50dc<this['blockSize'];++_0x3d50dc)this['pad_'][_0x3d50dc]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x291031,_0x4370ab){_0x4370ab||(_0x4370ab=0x0);const _0x4c6959=this['W_'];if(typeof _0x291031=='string'){for(let _0x16cb12=0x0;_0x16cb12<0x10;_0x16cb12++)_0x4c6959[_0x16cb12]=_0x291031['charCodeAt'](_0x4370ab)<<0x18|_0x291031['charCodeAt'](_0x4370ab+0x1)<<0x10|_0x291031['charCodeAt'](_0x4370ab+0x2)<<0x8|_0x291031['charCodeAt'](_0x4370ab+0x3),_0x4370ab+=0x4;}else{for(let _0x465214=0x0;_0x465214<0x10;_0x465214++)_0x4c6959[_0x465214]=_0x291031[_0x4370ab]<<0x18|_0x291031[_0x4370ab+0x1]<<0x10|_0x291031[_0x4370ab+0x2]<<0x8|_0x291031[_0x4370ab+0x3],_0x4370ab+=0x4;}for(let _0xdea19e=0x10;_0xdea19e<0x50;_0xdea19e++){const _0x473032=_0x4c6959[_0xdea19e-0x3]^_0x4c6959[_0xdea19e-0x8]^_0x4c6959[_0xdea19e-0xe]^_0x4c6959[_0xdea19e-0x10];_0x4c6959[_0xdea19e]=(_0x473032<<0x1|_0x473032>>>0x1f)&0xffffffff;}let _0x7a91c2=this['chain_'][0x0],_0x4f1e5e=this['chain_'][0x1],_0x3a5521=this['chain_'][0x2],_0x3b0688=this['chain_'][0x3],_0x2396ce=this['chain_'][0x4],_0x53856d,_0x8c1d90;for(let _0x143751=0x0;_0x143751<0x50;_0x143751++){_0x143751<0x28?_0x143751<0x14?(_0x53856d=_0x3b0688^_0x4f1e5e&(_0x3a5521^_0x3b0688),_0x8c1d90=0x5a827999):(_0x53856d=_0x4f1e5e^_0x3a5521^_0x3b0688,_0x8c1d90=0x6ed9eba1):_0x143751<0x3c?(_0x53856d=_0x4f1e5e&_0x3a5521|_0x3b0688&(_0x4f1e5e|_0x3a5521),_0x8c1d90=0x8f1bbcdc):(_0x53856d=_0x4f1e5e^_0x3a5521^_0x3b0688,_0x8c1d90=0xca62c1d6);const _0x17e34f=(_0x7a91c2<<0x5|_0x7a91c2>>>0x1b)+_0x53856d+_0x2396ce+_0x8c1d90+_0x4c6959[_0x143751]&0xffffffff;_0x2396ce=_0x3b0688,_0x3b0688=_0x3a5521,_0x3a5521=(_0x4f1e5e<<0x1e|_0x4f1e5e>>>0x2)&0xffffffff,_0x4f1e5e=_0x7a91c2,_0x7a91c2=_0x17e34f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x7a91c2&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4f1e5e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3a5521&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3b0688&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2396ce&0xffffffff;}['update'](_0x5ba4bb,_0x22b3e7){if(_0x5ba4bb==null)return;_0x22b3e7===void 0x0&&(_0x22b3e7=_0x5ba4bb['length']);const _0x6aab28=_0x22b3e7-this['blockSize'];let _0x3a5fb3=0x0;const _0x3f1940=this['buf_'];let _0x141bb9=this['inbuf_'];for(;_0x3a5fb3<_0x22b3e7;){if(_0x141bb9===0x0){for(;_0x3a5fb3<=_0x6aab28;)this['compress_'](_0x5ba4bb,_0x3a5fb3),_0x3a5fb3+=this['blockSize'];}if(typeof _0x5ba4bb=='string'){for(;_0x3a5fb3<_0x22b3e7;)if(_0x3f1940[_0x141bb9]=_0x5ba4bb['charCodeAt'](_0x3a5fb3),++_0x141bb9,++_0x3a5fb3,_0x141bb9===this['blockSize']){this['compress_'](_0x3f1940),_0x141bb9=0x0;break;}}else{for(;_0x3a5fb3<_0x22b3e7;)if(_0x3f1940[_0x141bb9]=_0x5ba4bb[_0x3a5fb3],++_0x141bb9,++_0x3a5fb3,_0x141bb9===this['blockSize']){this['compress_'](_0x3f1940),_0x141bb9=0x0;break;}}}this['inbuf_']=_0x141bb9,this['total_']+=_0x22b3e7;}['digest'](){const _0x5593fe=[];let _0x34ca1b=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x19758e=this['blockSize']-0x1;_0x19758e>=0x38;_0x19758e--)this['buf_'][_0x19758e]=_0x34ca1b&0xff,_0x34ca1b/=0x100;this['compress_'](this['buf_']);let _0x288f0b=0x0;for(let _0x249e58=0x0;_0x249e58<0x5;_0x249e58++)for(let _0x49d89c=0x18;_0x49d89c>=0x0;_0x49d89c-=0x8)_0x5593fe[_0x288f0b]=this['chain_'][_0x249e58]>>_0x49d89c&0xff,++_0x288f0b;return _0x5593fe;}}function Tc(_0x4286d3,_0x338501){const _0x51970a=new Sc(_0x4286d3,_0x338501);return _0x51970a['subscribe']['bind'](_0x51970a);}class Sc{constructor(_0xa7fb3,_0x21cfdd){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x21cfdd,this['task']['then'](()=>{_0xa7fb3(this);})['catch'](_0x3ae30c=>{this['error'](_0x3ae30c);});}['next'](_0x1c770f){this['forEachObserver'](_0x9b85a7=>{_0x9b85a7['next'](_0x1c770f);});}['error'](_0x541dc9){this['forEachObserver'](_0x5cc116=>{_0x5cc116['error'](_0x541dc9);}),this['close'](_0x541dc9);}['complete'](){this['forEachObserver'](_0x2e822c=>{_0x2e822c['complete']();}),this['close']();}['subscribe'](_0x4b1aaa,_0x58d06e,_0x553522){let _0x4e9792;if(_0x4b1aaa===void 0x0&&_0x58d06e===void 0x0&&_0x553522===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4b1aaa,['next','error','complete'])?_0x4e9792=_0x4b1aaa:_0x4e9792={'next':_0x4b1aaa,'error':_0x58d06e,'complete':_0x553522},_0x4e9792['next']===void 0x0&&(_0x4e9792['next']=ti),_0x4e9792['error']===void 0x0&&(_0x4e9792['error']=ti),_0x4e9792['complete']===void 0x0&&(_0x4e9792['complete']=ti);const _0x3b56e5=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4e9792['error'](this['finalError']):_0x4e9792['complete']();}catch{}}),this['observers']['push'](_0x4e9792),_0x3b56e5;}['unsubscribeOne'](_0x4e50b4){this['observers']===void 0x0||this['observers'][_0x4e50b4]===void 0x0||(delete this['observers'][_0x4e50b4],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x538c2f){if(!this['finalized']){for(let _0xdceff8=0x0;_0xdceff8<this['observers']['length'];_0xdceff8++)this['sendOne'](_0xdceff8,_0x538c2f);}}['sendOne'](_0x2a58a6,_0x13d8f0){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2a58a6]!==void 0x0)try{_0x13d8f0(this['observers'][_0x2a58a6]);}catch(_0x2cba42){typeof console<'u'&&console['error']&&console['error'](_0x2cba42);}});}['close'](_0x317424){this['finalized']||(this['finalized']=!0x0,_0x317424!==void 0x0&&(this['finalError']=_0x317424),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4b7b1e,_0x3e77df){if(typeof _0x4b7b1e!='object'||_0x4b7b1e===null)return!0x1;for(const _0x10032a of _0x3e77df)if(_0x10032a in _0x4b7b1e&&typeof _0x4b7b1e[_0x10032a]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x4316d6,_0x5a6c35){return _0x4316d6+'\x20failed:\x20'+_0x5a6c35+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x238f89){const _0x42ce6e=[];let _0x56f54b=0x0;for(let _0x180545=0x0;_0x180545<_0x238f89['length'];_0x180545++){let _0x1f4c31=_0x238f89['charCodeAt'](_0x180545);if(_0x1f4c31>=0xd800&&_0x1f4c31<=0xdbff){const _0x23f6f9=_0x1f4c31-0xd800;_0x180545++,f(_0x180545<_0x238f89['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2b96c4=_0x238f89['charCodeAt'](_0x180545)-0xdc00;_0x1f4c31=0x10000+(_0x23f6f9<<0xa)+_0x2b96c4;}_0x1f4c31<0x80?_0x42ce6e[_0x56f54b++]=_0x1f4c31:_0x1f4c31<0x800?(_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0x6|0xc0,_0x42ce6e[_0x56f54b++]=_0x1f4c31&0x3f|0x80):_0x1f4c31<0x10000?(_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0xc|0xe0,_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0x6&0x3f|0x80,_0x42ce6e[_0x56f54b++]=_0x1f4c31&0x3f|0x80):(_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0x12|0xf0,_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0xc&0x3f|0x80,_0x42ce6e[_0x56f54b++]=_0x1f4c31>>0x6&0x3f|0x80,_0x42ce6e[_0x56f54b++]=_0x1f4c31&0x3f|0x80);}return _0x42ce6e;},Ln=function(_0x58671c){let _0x217b7f=0x0;for(let _0x5d17da=0x0;_0x5d17da<_0x58671c['length'];_0x5d17da++){const _0x5bbc97=_0x58671c['charCodeAt'](_0x5d17da);_0x5bbc97<0x80?_0x217b7f++:_0x5bbc97<0x800?_0x217b7f+=0x2:_0x5bbc97>=0xd800&&_0x5bbc97<=0xdbff?(_0x217b7f+=0x4,_0x5d17da++):_0x217b7f+=0x3;}return _0x217b7f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3fa3af){return _0x3fa3af&&_0x3fa3af['_delegate']?_0x3fa3af['_delegate']:_0x3fa3af;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x4acaed){try{return(_0x4acaed['startsWith']('http://')||_0x4acaed['startsWith']('https://')?new URL(_0x4acaed)['hostname']:_0x4acaed)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3f4231){return(await fetch(_0x3f4231,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x2ad87f,_0x5b131b,_0x51e8a9){this['name']=_0x2ad87f,this['instanceFactory']=_0x5b131b,this['type']=_0x51e8a9,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x294758){return this['instantiationMode']=_0x294758,this;}['setMultipleInstances'](_0x5b5373){return this['multipleInstances']=_0x5b5373,this;}['setServiceProps'](_0x3c9995){return this['serviceProps']=_0x3c9995,this;}['setInstanceCreatedCallback'](_0x479e11){return this['onInstanceCreated']=_0x479e11,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5969cf,_0x2faded){this['name']=_0x5969cf,this['container']=_0x2faded,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x17f342){const _0x670f60=this['normalizeInstanceIdentifier'](_0x17f342);if(!this['instancesDeferred']['has'](_0x670f60)){const _0x5c04d9=new H();if(this['instancesDeferred']['set'](_0x670f60,_0x5c04d9),this['isInitialized'](_0x670f60)||this['shouldAutoInitialize']())try{const _0x20e2d0=this['getOrInitializeService']({'instanceIdentifier':_0x670f60});_0x20e2d0&&_0x5c04d9['resolve'](_0x20e2d0);}catch{}}return this['instancesDeferred']['get'](_0x670f60)['promise'];}['getImmediate'](_0x889d5f){const _0x3942fe=this['normalizeInstanceIdentifier'](_0x889d5f==null?void 0x0:_0x889d5f['identifier']),_0x1ba667=(_0x889d5f==null?void 0x0:_0x889d5f['optional'])??!0x1;if(this['isInitialized'](_0x3942fe)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3942fe});}catch(_0x3a23ba){if(_0x1ba667)return null;throw _0x3a23ba;}else{if(_0x1ba667)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x368315){if(_0x368315['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x368315['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x368315,!!this['shouldAutoInitialize']()){if(Pc(_0x368315))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x22e7cc,_0xbb84ca]of this['instancesDeferred']['entries']()){const _0x561e52=this['normalizeInstanceIdentifier'](_0x22e7cc);try{const _0x5dae54=this['getOrInitializeService']({'instanceIdentifier':_0x561e52});_0xbb84ca['resolve'](_0x5dae54);}catch{}}}}['clearInstance'](_0x571259=Ne){this['instancesDeferred']['delete'](_0x571259),this['instancesOptions']['delete'](_0x571259),this['instances']['delete'](_0x571259);}async['delete'](){const _0x57f581=Array['from'](this['instances']['values']());await Promise['all']([..._0x57f581['filter'](_0x2af20b=>'INTERNAL'in _0x2af20b)['map'](_0x3c90a7=>_0x3c90a7['INTERNAL']['delete']()),..._0x57f581['filter'](_0x1c0031=>'_delete'in _0x1c0031)['map'](_0xd6a7d4=>_0xd6a7d4['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2a5cdc=Ne){return this['instances']['has'](_0x2a5cdc);}['getOptions'](_0x1202bb=Ne){return this['instancesOptions']['get'](_0x1202bb)||{};}['initialize'](_0x7e7eea={}){const {options:_0x5a03c0={}}=_0x7e7eea,_0x51a958=this['normalizeInstanceIdentifier'](_0x7e7eea['instanceIdentifier']);if(this['isInitialized'](_0x51a958))throw Error(this['name']+'('+_0x51a958+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x36c498=this['getOrInitializeService']({'instanceIdentifier':_0x51a958,'options':_0x5a03c0});for(const [_0x274074,_0x56efef]of this['instancesDeferred']['entries']()){const _0x1b503c=this['normalizeInstanceIdentifier'](_0x274074);_0x51a958===_0x1b503c&&_0x56efef['resolve'](_0x36c498);}return _0x36c498;}['onInit'](_0x430b6a,_0x36de1){const _0x4acfac=this['normalizeInstanceIdentifier'](_0x36de1),_0xf6c199=this['onInitCallbacks']['get'](_0x4acfac)??new Set();_0xf6c199['add'](_0x430b6a),this['onInitCallbacks']['set'](_0x4acfac,_0xf6c199);const _0x3654ae=this['instances']['get'](_0x4acfac);return _0x3654ae&&_0x430b6a(_0x3654ae,_0x4acfac),()=>{_0xf6c199['delete'](_0x430b6a);};}['invokeOnInitCallbacks'](_0x10b26d,_0x546d2a){const _0x80b856=this['onInitCallbacks']['get'](_0x546d2a);if(_0x80b856){for(const _0x3135e7 of _0x80b856)try{_0x3135e7(_0x10b26d,_0x546d2a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x460aea,options:_0x1cbe1f={}}){let _0x151503=this['instances']['get'](_0x460aea);if(!_0x151503&&this['component']&&(_0x151503=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x460aea),'options':_0x1cbe1f}),this['instances']['set'](_0x460aea,_0x151503),this['instancesOptions']['set'](_0x460aea,_0x1cbe1f),this['invokeOnInitCallbacks'](_0x151503,_0x460aea),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x460aea,_0x151503);}catch{}return _0x151503||null;}['normalizeInstanceIdentifier'](_0x359f3a=Ne){return this['component']?this['component']['multipleInstances']?_0x359f3a:Ne:_0x359f3a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2e224d){return _0x2e224d===Ne?void 0x0:_0x2e224d;}function Pc(_0x1eaf86){return _0x1eaf86['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x27a4b4){this['name']=_0x27a4b4,this['providers']=new Map();}['addComponent'](_0x2d8d28){const _0xeb2b7=this['getProvider'](_0x2d8d28['name']);if(_0xeb2b7['isComponentSet']())throw new Error('Component\x20'+_0x2d8d28['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xeb2b7['setComponent'](_0x2d8d28);}['addOrOverwriteComponent'](_0x8afd99){this['getProvider'](_0x8afd99['name'])['isComponentSet']()&&this['providers']['delete'](_0x8afd99['name']),this['addComponent'](_0x8afd99);}['getProvider'](_0x32ccb5){if(this['providers']['has'](_0x32ccb5))return this['providers']['get'](_0x32ccb5);const _0x468b03=new Ac(_0x32ccb5,this);return this['providers']['set'](_0x32ccb5,_0x468b03),_0x468b03;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4e27b7){_0x4e27b7[_0x4e27b7['DEBUG']=0x0]='DEBUG',_0x4e27b7[_0x4e27b7['VERBOSE']=0x1]='VERBOSE',_0x4e27b7[_0x4e27b7['INFO']=0x2]='INFO',_0x4e27b7[_0x4e27b7['WARN']=0x3]='WARN',_0x4e27b7[_0x4e27b7['ERROR']=0x4]='ERROR',_0x4e27b7[_0x4e27b7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x40924a,_0x432d2b,..._0x23efac)=>{if(_0x432d2b<_0x40924a['logLevel'])return;const _0x51bf76=new Date()['toISOString'](),_0x16b7f8=Mc[_0x432d2b];if(_0x16b7f8)console[_0x16b7f8]('['+_0x51bf76+']\x20\x20'+_0x40924a['name']+':',..._0x23efac);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x432d2b+')');};class Bi{constructor(_0x2b04a3){this['name']=_0x2b04a3,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x477799){if(!(_0x477799 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x477799+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x477799;}['setLogLevel'](_0x497d47){this['_logLevel']=typeof _0x497d47=='string'?Oc[_0x497d47]:_0x497d47;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xbfcf2d){if(typeof _0xbfcf2d!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xbfcf2d;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1ec4c6){this['_userLogHandler']=_0x1ec4c6;}['debug'](..._0x452f52){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x452f52),this['_logHandler'](this,T['DEBUG'],..._0x452f52);}['log'](..._0x465c80){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x465c80),this['_logHandler'](this,T['VERBOSE'],..._0x465c80);}['info'](..._0x1ee20e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1ee20e),this['_logHandler'](this,T['INFO'],..._0x1ee20e);}['warn'](..._0x43adc0){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x43adc0),this['_logHandler'](this,T['WARN'],..._0x43adc0);}['error'](..._0x5cbdb6){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5cbdb6),this['_logHandler'](this,T['ERROR'],..._0x5cbdb6);}}const xc=(_0x25efc0,_0x2a4f3f)=>_0x2a4f3f['some'](_0x3baf03=>_0x25efc0 instanceof _0x3baf03);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x3f614f){const _0x24132a=new Promise((_0x218049,_0x30f402)=>{const _0x468c58=()=>{_0x3f614f['removeEventListener']('success',_0x52e5ad),_0x3f614f['removeEventListener']('error',_0x595afd);},_0x52e5ad=()=>{_0x218049(ge(_0x3f614f['result'])),_0x468c58();},_0x595afd=()=>{_0x30f402(_0x3f614f['error']),_0x468c58();};_0x3f614f['addEventListener']('success',_0x52e5ad),_0x3f614f['addEventListener']('error',_0x595afd);});return _0x24132a['then'](_0x4d39f3=>{_0x4d39f3 instanceof IDBCursor&&Jr['set'](_0x4d39f3,_0x3f614f);})['catch'](()=>{}),Vi['set'](_0x24132a,_0x3f614f),_0x24132a;}function Bc(_0x32d61a){if(_i['has'](_0x32d61a))return;const _0x110144=new Promise((_0x33f286,_0x483f0d)=>{const _0x3993f0=()=>{_0x32d61a['removeEventListener']('complete',_0x335612),_0x32d61a['removeEventListener']('error',_0x12e461),_0x32d61a['removeEventListener']('abort',_0x12e461);},_0x335612=()=>{_0x33f286(),_0x3993f0();},_0x12e461=()=>{_0x483f0d(_0x32d61a['error']||new DOMException('AbortError','AbortError')),_0x3993f0();};_0x32d61a['addEventListener']('complete',_0x335612),_0x32d61a['addEventListener']('error',_0x12e461),_0x32d61a['addEventListener']('abort',_0x12e461);});_i['set'](_0x32d61a,_0x110144);}let gi={'get'(_0x546acb,_0x58beb0,_0x1cd043){if(_0x546acb instanceof IDBTransaction){if(_0x58beb0==='done')return _i['get'](_0x546acb);if(_0x58beb0==='objectStoreNames')return _0x546acb['objectStoreNames']||Xr['get'](_0x546acb);if(_0x58beb0==='store')return _0x1cd043['objectStoreNames'][0x1]?void 0x0:_0x1cd043['objectStore'](_0x1cd043['objectStoreNames'][0x0]);}return ge(_0x546acb[_0x58beb0]);},'set'(_0x1a2140,_0x5abae3,_0x2061cc){return _0x1a2140[_0x5abae3]=_0x2061cc,!0x0;},'has'(_0xe83f04,_0x242190){return _0xe83f04 instanceof IDBTransaction&&(_0x242190==='done'||_0x242190==='store')?!0x0:_0x242190 in _0xe83f04;}};function Vc(_0x1e7d0a){gi=_0x1e7d0a(gi);}function Hc(_0x21da09){return _0x21da09===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x309035,..._0x2bf188){const _0x4b97c5=_0x21da09['call'](ii(this),_0x309035,..._0x2bf188);return Xr['set'](_0x4b97c5,_0x309035['sort']?_0x309035['sort']():[_0x309035]),ge(_0x4b97c5);}:Uc()['includes'](_0x21da09)?function(..._0x4fcabf){return _0x21da09['apply'](ii(this),_0x4fcabf),ge(Jr['get'](this));}:function(..._0xb372a){return ge(_0x21da09['apply'](ii(this),_0xb372a));};}function $c(_0x37423c){return typeof _0x37423c=='function'?Hc(_0x37423c):(_0x37423c instanceof IDBTransaction&&Bc(_0x37423c),xc(_0x37423c,Fc())?new Proxy(_0x37423c,gi):_0x37423c);}function ge(_0x200a61){if(_0x200a61 instanceof IDBRequest)return Wc(_0x200a61);if(ni['has'](_0x200a61))return ni['get'](_0x200a61);const _0x246c41=$c(_0x200a61);return _0x246c41!==_0x200a61&&(ni['set'](_0x200a61,_0x246c41),Vi['set'](_0x246c41,_0x200a61)),_0x246c41;}const ii=_0x7a6eaa=>Vi['get'](_0x7a6eaa);function Gc(_0x2042c8,_0x37aee9,{blocked:_0x46ea09,upgrade:_0x2c1729,blocking:_0x52778d,terminated:_0x1437ad}={}){const _0x4e20ac=indexedDB['open'](_0x2042c8,_0x37aee9),_0x20e107=ge(_0x4e20ac);return _0x2c1729&&_0x4e20ac['addEventListener']('upgradeneeded',_0x13ae57=>{_0x2c1729(ge(_0x4e20ac['result']),_0x13ae57['oldVersion'],_0x13ae57['newVersion'],ge(_0x4e20ac['transaction']),_0x13ae57);}),_0x46ea09&&_0x4e20ac['addEventListener']('blocked',_0x3b3b4c=>_0x46ea09(_0x3b3b4c['oldVersion'],_0x3b3b4c['newVersion'],_0x3b3b4c)),_0x20e107['then'](_0x211f1c=>{_0x1437ad&&_0x211f1c['addEventListener']('close',()=>_0x1437ad()),_0x52778d&&_0x211f1c['addEventListener']('versionchange',_0x337e05=>_0x52778d(_0x337e05['oldVersion'],_0x337e05['newVersion'],_0x337e05));})['catch'](()=>{}),_0x20e107;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x372173,_0x322d9d){if(!(_0x372173 instanceof IDBDatabase&&!(_0x322d9d in _0x372173)&&typeof _0x322d9d=='string'))return;if(si['get'](_0x322d9d))return si['get'](_0x322d9d);const _0x410dd7=_0x322d9d['replace'](/FromIndex$/,''),_0x2e89ae=_0x322d9d!==_0x410dd7,_0x4dd742=zc['includes'](_0x410dd7);if(!(_0x410dd7 in(_0x2e89ae?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4dd742||qc['includes'](_0x410dd7)))return;const _0x464ec6=async function(_0x1aa5e2,..._0x3c246e){const _0x58488e=this['transaction'](_0x1aa5e2,_0x4dd742?'readwrite':'readonly');let _0x256791=_0x58488e['store'];return _0x2e89ae&&(_0x256791=_0x256791['index'](_0x3c246e['shift']())),(await Promise['all']([_0x256791[_0x410dd7](..._0x3c246e),_0x4dd742&&_0x58488e['done']]))[0x0];};return si['set'](_0x322d9d,_0x464ec6),_0x464ec6;}Vc(_0x36863f=>({..._0x36863f,'get':(_0x51a0fd,_0x4257bb,_0xb374c3)=>Ms(_0x51a0fd,_0x4257bb)||_0x36863f['get'](_0x51a0fd,_0x4257bb,_0xb374c3),'has':(_0x2f962d,_0x4ac56c)=>!!Ms(_0x2f962d,_0x4ac56c)||_0x36863f['has'](_0x2f962d,_0x4ac56c)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4df87d){this['container']=_0x4df87d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x341ab5=>{if(Kc(_0x341ab5)){const _0x579be0=_0x341ab5['getImmediate']();return _0x579be0['library']+'/'+_0x579be0['version'];}else return null;})['filter'](_0x352c6b=>_0x352c6b)['join']('\x20');}}function Kc(_0x2e904c){const _0x4deeec=_0x2e904c['getComponent']();return(_0x4deeec==null?void 0x0:_0x4deeec['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x4ca7da,_0x27dc3d){try{_0x4ca7da['container']['addComponent'](_0x27dc3d);}catch(_0xa1f0e2){oe['debug']('Component\x20'+_0x27dc3d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4ca7da['name'],_0xa1f0e2);}}function st(_0x5c554e){const _0x26de78=_0x5c554e['name'];if(Ei['has'](_0x26de78))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x26de78+'.'),!0x1;Ei['set'](_0x26de78,_0x5c554e);for(const _0x52ba38 of Ue['values']())xs(_0x52ba38,_0x5c554e);for(const _0x16fd0f of vi['values']())xs(_0x16fd0f,_0x5c554e);return!0x0;}function Hi(_0x2a693b,_0x34ecb5){const _0x537665=_0x2a693b['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x537665&&_0x537665['triggerHeartbeat'](),_0x2a693b['container']['getProvider'](_0x34ecb5);}function $(_0x24ad48){return _0x24ad48==null?!0x1:_0x24ad48['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x36095d,_0x1a0c97,_0x53a688){this['_isDeleted']=!0x1,this['_options']={..._0x36095d},this['_config']={..._0x1a0c97},this['_name']=_0x1a0c97['name'],this['_automaticDataCollectionEnabled']=_0x1a0c97['automaticDataCollectionEnabled'],this['_container']=_0x53a688,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3f2610){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3f2610;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x178dab){this['_isDeleted']=_0x178dab;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x5c4a9a,_0x4fd1a7={}){let _0x93d29a=_0x5c4a9a;typeof _0x4fd1a7!='object'&&(_0x4fd1a7={'name':_0x4fd1a7});const _0x3a9363={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4fd1a7},_0x33c4f4=_0x3a9363['name'];if(typeof _0x33c4f4!='string'||!_0x33c4f4)throw me['create']('bad-app-name',{'appName':String(_0x33c4f4)});if(_0x93d29a||(_0x93d29a=zr()),!_0x93d29a)throw me['create']('no-options');const _0x4773b1=Ue['get'](_0x33c4f4);if(_0x4773b1){if(xe(_0x93d29a,_0x4773b1['options'])&&xe(_0x3a9363,_0x4773b1['config']))return _0x4773b1;throw me['create']('duplicate-app',{'appName':_0x33c4f4});}const _0x20ee5b=new Nc(_0x33c4f4);for(const _0x280b07 of Ei['values']())_0x20ee5b['addComponent'](_0x280b07);const _0x362aac=new Tl(_0x93d29a,_0x3a9363,_0x20ee5b);return Ue['set'](_0x33c4f4,_0x362aac),_0x362aac;}function Zr(_0x4d87da=yi){const _0x222446=Ue['get'](_0x4d87da);if(!_0x222446&&_0x4d87da===yi&&zr())return Sl();if(!_0x222446)throw me['create']('no-app',{'appName':_0x4d87da});return _0x222446;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x5c7358){let _0x3da063=!0x1;const _0x2d6253=_0x5c7358['name'];Ue['has'](_0x2d6253)?(_0x3da063=!0x0,Ue['delete'](_0x2d6253)):vi['has'](_0x2d6253)&&_0x5c7358['decRefCount']()<=0x0&&(vi['delete'](_0x2d6253),_0x3da063=!0x0),_0x3da063&&(await Promise['all'](_0x5c7358['container']['getProviders']()['map'](_0x4d04bc=>_0x4d04bc['delete']())),_0x5c7358['isDeleted']=!0x0);}function ye(_0x5849d9,_0x36d47a,_0x430977){let _0x2c4ffb=wl[_0x5849d9]??_0x5849d9;_0x430977&&(_0x2c4ffb+='-'+_0x430977);const _0x50e309=_0x2c4ffb['match'](/\s|\//),_0x12c666=_0x36d47a['match'](/\s|\//);if(_0x50e309||_0x12c666){const _0x24b78c=['Unable\x20to\x20register\x20library\x20\x22'+_0x2c4ffb+'\x22\x20with\x20version\x20\x22'+_0x36d47a+'\x22:'];_0x50e309&&_0x24b78c['push']('library\x20name\x20\x22'+_0x2c4ffb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x50e309&&_0x12c666&&_0x24b78c['push']('and'),_0x12c666&&_0x24b78c['push']('version\x20name\x20\x22'+_0x36d47a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x24b78c['join']('\x20'));return;}st(new Fe(_0x2c4ffb+'-version',()=>({'library':_0x2c4ffb,'version':_0x36d47a}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x26474a,_0x26f644)=>{switch(_0x26f644){case 0x0:try{_0x26474a['createObjectStore'](Ot);}catch(_0x1017b0){console['warn'](_0x1017b0);}}}})['catch'](_0x27b5c4=>{throw me['create']('idb-open',{'originalErrorMessage':_0x27b5c4['message']});})),ri;}async function Al(_0x3c4513){try{const _0x52bb4c=(await eo())['transaction'](Ot),_0x56b372=await _0x52bb4c['objectStore'](Ot)['get'](to(_0x3c4513));return await _0x52bb4c['done'],_0x56b372;}catch(_0x4a906e){if(_0x4a906e instanceof Re)oe['warn'](_0x4a906e['message']);else{const _0x26772a=me['create']('idb-get',{'originalErrorMessage':_0x4a906e==null?void 0x0:_0x4a906e['message']});oe['warn'](_0x26772a['message']);}}}async function Fs(_0x3a6b79,_0x23d61e){try{const _0x233ed5=(await eo())['transaction'](Ot,'readwrite');await _0x233ed5['objectStore'](Ot)['put'](_0x23d61e,to(_0x3a6b79)),await _0x233ed5['done'];}catch(_0xde9a01){if(_0xde9a01 instanceof Re)oe['warn'](_0xde9a01['message']);else{const _0x4007d2=me['create']('idb-set',{'originalErrorMessage':_0xde9a01==null?void 0x0:_0xde9a01['message']});oe['warn'](_0x4007d2['message']);}}}function to(_0x6984f1){return _0x6984f1['name']+'!'+_0x6984f1['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x549bfa){this['container']=_0x549bfa,this['_heartbeatsCache']=null;const _0x3de07c=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3de07c),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1e8a68=>(this['_heartbeatsCache']=_0x1e8a68,_0x1e8a68));}async['triggerHeartbeat'](){var _0x3fc76d,_0x6181a;try{const _0x495f84=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4ffe29=Us();if(((_0x3fc76d=this['_heartbeatsCache'])==null?void 0x0:_0x3fc76d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x6181a=this['_heartbeatsCache'])==null?void 0x0:_0x6181a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4ffe29||this['_heartbeatsCache']['heartbeats']['some'](_0x3ef1ad=>_0x3ef1ad['date']===_0x4ffe29))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4ffe29,'agent':_0x495f84}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x37b7ac=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x37b7ac,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x405662){oe['warn'](_0x405662);}}async['getHeartbeatsHeader'](){var _0x5acc4d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5acc4d=this['_heartbeatsCache'])==null?void 0x0:_0x5acc4d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3c6de3=Us(),{heartbeatsToSend:_0xc1dea0,unsentEntries:_0x390853}=Ol(this['_heartbeatsCache']['heartbeats']),_0x488ab9=dn(JSON['stringify']({'version':0x2,'heartbeats':_0xc1dea0}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3c6de3,_0x390853['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x390853,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x488ab9;}catch(_0x17408b){return oe['warn'](_0x17408b),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1cfcad,_0xad3ea9=kl){const _0x5901bd=[];let _0x1ee59a=_0x1cfcad['slice']();for(const _0x3c9300 of _0x1cfcad){const _0x1190a5=_0x5901bd['find'](_0x367f8e=>_0x367f8e['agent']===_0x3c9300['agent']);if(_0x1190a5){if(_0x1190a5['dates']['push'](_0x3c9300['date']),Ws(_0x5901bd)>_0xad3ea9){_0x1190a5['dates']['pop']();break;}}else{if(_0x5901bd['push']({'agent':_0x3c9300['agent'],'dates':[_0x3c9300['date']]}),Ws(_0x5901bd)>_0xad3ea9){_0x5901bd['pop']();break;}}_0x1ee59a=_0x1ee59a['slice'](0x1);}return{'heartbeatsToSend':_0x5901bd,'unsentEntries':_0x1ee59a};}class Dl{constructor(_0x56d9a3){this['app']=_0x56d9a3,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4bfdfc=await Al(this['app']);return _0x4bfdfc!=null&&_0x4bfdfc['heartbeats']?_0x4bfdfc:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1f95af){if(await this['_canUseIndexedDBPromise']){const _0x7904e6=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1f95af['lastSentHeartbeatDate']??_0x7904e6['lastSentHeartbeatDate'],'heartbeats':_0x1f95af['heartbeats']});}else return;}async['add'](_0x1df117){if(await this['_canUseIndexedDBPromise']){const _0x3668e3=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1df117['lastSentHeartbeatDate']??_0x3668e3['lastSentHeartbeatDate'],'heartbeats':[..._0x3668e3['heartbeats'],..._0x1df117['heartbeats']]});}else return;}}function Ws(_0x45e754){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x45e754}))['length'];}function Ml(_0x18571e){if(_0x18571e['length']===0x0)return-0x1;let _0x50cedc=0x0,_0x278b33=_0x18571e[0x0]['date'];for(let _0x345576=0x1;_0x345576<_0x18571e['length'];_0x345576++)_0x18571e[_0x345576]['date']<_0x278b33&&(_0x278b33=_0x18571e[_0x345576]['date'],_0x50cedc=_0x345576);return _0x50cedc;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4311fd){st(new Fe('platform-logger',_0x4e55be=>new jc(_0x4e55be),'PRIVATE')),st(new Fe('heartbeat',_0x3bbe61=>new Nl(_0x3bbe61),'PRIVATE')),ye(mi,Ls,_0x4311fd),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x437f56){no=_0x437f56;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x196d33){this['domStorage_']=_0x196d33,this['prefix_']='firebase:';}['set'](_0x4dfac3,_0x96199f){_0x96199f==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4dfac3)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4dfac3),O(_0x96199f));}['get'](_0x12005a){const _0x2438bf=this['domStorage_']['getItem'](this['prefixedName_'](_0x12005a));return _0x2438bf==null?null:Nt(_0x2438bf);}['remove'](_0x2e8431){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2e8431));}['prefixedName_'](_0x5c397c){return this['prefix_']+_0x5c397c;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x130960,_0x4f2bb6){_0x4f2bb6==null?delete this['cache_'][_0x130960]:this['cache_'][_0x130960]=_0x4f2bb6;}['get'](_0x110f04){return Q(this['cache_'],_0x110f04)?this['cache_'][_0x110f04]:null;}['remove'](_0x4a4e4d){delete this['cache_'][_0x4a4e4d];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x13cf23){try{if(typeof window<'u'&&typeof window[_0x13cf23]<'u'){const _0x3d031f=window[_0x13cf23];return _0x3d031f['setItem']('firebase:sentinel','cache'),_0x3d031f['removeItem']('firebase:sentinel'),new Wl(_0x3d031f);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1e53bf=0x1;return function(){return _0x1e53bf++;};}()),ro=function(_0x140710){const _0x5b15ac=Rc(_0x140710),_0xd1709c=new Cc();_0xd1709c['update'](_0x5b15ac);const _0x59aba2=_0xd1709c['digest']();return Fi['encodeByteArray'](_0x59aba2);},zt=function(..._0x447bc5){let _0x3f5677='';for(let _0x27d526=0x0;_0x27d526<_0x447bc5['length'];_0x27d526++){const _0x11394b=_0x447bc5[_0x27d526];Array['isArray'](_0x11394b)||_0x11394b&&typeof _0x11394b=='object'&&typeof _0x11394b['length']=='number'?_0x3f5677+=zt['apply'](null,_0x11394b):typeof _0x11394b=='object'?_0x3f5677+=O(_0x11394b):_0x3f5677+=_0x11394b,_0x3f5677+='\x20';}return _0x3f5677;};let St=null,$s=!0x0;const Hl=function(_0x39cc41,_0x4e8665){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x3ea0f7){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x99c164=zt['apply'](null,_0x3ea0f7);St(_0x99c164);}},jt=function(_0x29ab89){return function(..._0x2f76d7){L(_0x29ab89,..._0x2f76d7);};},Ii=function(..._0x12cdba){const _0x6f6c28='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x12cdba);Ze['error'](_0x6f6c28);},ae=function(..._0x194e9c){const _0x26c981='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x194e9c);throw Ze['error'](_0x26c981),new Error(_0x26c981);},U=function(..._0x302249){const _0xe9c2c7='FIREBASE\x20WARNING:\x20'+zt(..._0x302249);Ze['warn'](_0xe9c2c7);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5da7ae){return typeof _0x5da7ae=='number'&&(_0x5da7ae!==_0x5da7ae||_0x5da7ae===Number['POSITIVE_INFINITY']||_0x5da7ae===Number['NEGATIVE_INFINITY']);},Gl=function(_0x29b1f9){if(document['readyState']==='complete')_0x29b1f9();else{let _0xc912ab=!0x1;const _0x46abda=function(){if(!document['body']){setTimeout(_0x46abda,Math['floor'](0xa));return;}_0xc912ab||(_0xc912ab=!0x0,_0x29b1f9());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x46abda,!0x1),window['addEventListener']('load',_0x46abda,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x46abda();}),window['attachEvent']('onload',_0x46abda));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x37c570,_0x3c5c76){if(_0x37c570===_0x3c5c76)return 0x0;if(_0x37c570===We||_0x3c5c76===we)return-0x1;if(_0x3c5c76===We||_0x37c570===we)return 0x1;{const _0x5c3f68=Gs(_0x37c570),_0x5b675d=Gs(_0x3c5c76);return _0x5c3f68!==null?_0x5b675d!==null?_0x5c3f68-_0x5b675d===0x0?_0x37c570['length']-_0x3c5c76['length']:_0x5c3f68-_0x5b675d:-0x1:_0x5b675d!==null?0x1:_0x37c570<_0x3c5c76?-0x1:0x1;}},ql=function(_0x228666,_0x4cfd9a){return _0x228666===_0x4cfd9a?0x0:_0x228666<_0x4cfd9a?-0x1:0x1;},vt=function(_0x5bde10,_0x1795cc){if(_0x1795cc&&_0x5bde10 in _0x1795cc)return _0x1795cc[_0x5bde10];throw new Error('Missing\x20required\x20key\x20('+_0x5bde10+')\x20in\x20object:\x20'+O(_0x1795cc));},$i=function(_0xb48ce1){if(typeof _0xb48ce1!='object'||_0xb48ce1===null)return O(_0xb48ce1);const _0x3d57a2=[];for(const _0xfed7aa in _0xb48ce1)_0x3d57a2['push'](_0xfed7aa);_0x3d57a2['sort']();let _0x33fc2a='{';for(let _0x391e76=0x0;_0x391e76<_0x3d57a2['length'];_0x391e76++)_0x391e76!==0x0&&(_0x33fc2a+=','),_0x33fc2a+=O(_0x3d57a2[_0x391e76]),_0x33fc2a+=':',_0x33fc2a+=$i(_0xb48ce1[_0x3d57a2[_0x391e76]]);return _0x33fc2a+='}',_0x33fc2a;},oo=function(_0x47fd91,_0x403a74){const _0x10bf60=_0x47fd91['length'];if(_0x10bf60<=_0x403a74)return[_0x47fd91];const _0x2cb9ba=[];for(let _0x289b6b=0x0;_0x289b6b<_0x10bf60;_0x289b6b+=_0x403a74)_0x289b6b+_0x403a74>_0x10bf60?_0x2cb9ba['push'](_0x47fd91['substring'](_0x289b6b,_0x10bf60)):_0x2cb9ba['push'](_0x47fd91['substring'](_0x289b6b,_0x289b6b+_0x403a74));return _0x2cb9ba;};function x(_0x2bbf91,_0x3425a6){for(const _0x26a14a in _0x2bbf91)_0x2bbf91['hasOwnProperty'](_0x26a14a)&&_0x3425a6(_0x26a14a,_0x2bbf91[_0x26a14a]);}const ao=function(_0x402e4f){f(!xn(_0x402e4f),'Invalid\x20JSON\x20number');const _0x1d66fe=0xb,_0x59f9cf=0x34,_0x128ee5=(0x1<<_0x1d66fe-0x1)-0x1;let _0x2aba33,_0x1e5c0d,_0x1ba2d2,_0xa42caf,_0x4434fd;_0x402e4f===0x0?(_0x1e5c0d=0x0,_0x1ba2d2=0x0,_0x2aba33=0x1/_0x402e4f===-0x1/0x0?0x1:0x0):(_0x2aba33=_0x402e4f<0x0,_0x402e4f=Math['abs'](_0x402e4f),_0x402e4f>=Math['pow'](0x2,0x1-_0x128ee5)?(_0xa42caf=Math['min'](Math['floor'](Math['log'](_0x402e4f)/Math['LN2']),_0x128ee5),_0x1e5c0d=_0xa42caf+_0x128ee5,_0x1ba2d2=Math['round'](_0x402e4f*Math['pow'](0x2,_0x59f9cf-_0xa42caf)-Math['pow'](0x2,_0x59f9cf))):(_0x1e5c0d=0x0,_0x1ba2d2=Math['round'](_0x402e4f/Math['pow'](0x2,0x1-_0x128ee5-_0x59f9cf))));const _0x54cfab=[];for(_0x4434fd=_0x59f9cf;_0x4434fd;_0x4434fd-=0x1)_0x54cfab['push'](_0x1ba2d2%0x2?0x1:0x0),_0x1ba2d2=Math['floor'](_0x1ba2d2/0x2);for(_0x4434fd=_0x1d66fe;_0x4434fd;_0x4434fd-=0x1)_0x54cfab['push'](_0x1e5c0d%0x2?0x1:0x0),_0x1e5c0d=Math['floor'](_0x1e5c0d/0x2);_0x54cfab['push'](_0x2aba33?0x1:0x0),_0x54cfab['reverse']();const _0x5d38c2=_0x54cfab['join']('');let _0x3f03ee='';for(_0x4434fd=0x0;_0x4434fd<0x40;_0x4434fd+=0x8){let _0x1ec400=parseInt(_0x5d38c2['substr'](_0x4434fd,0x8),0x2)['toString'](0x10);_0x1ec400['length']===0x1&&(_0x1ec400='0'+_0x1ec400),_0x3f03ee=_0x3f03ee+_0x1ec400;}return _0x3f03ee['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2abdb4,_0x112ea5){let _0xb03666='Unknown\x20Error';_0x2abdb4==='too_big'?_0xb03666='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2abdb4==='permission_denied'?_0xb03666='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2abdb4==='unavailable'&&(_0xb03666='The\x20service\x20is\x20unavailable');const _0x137e20=new Error(_0x2abdb4+'\x20at\x20'+_0x112ea5['_path']['toString']()+':\x20'+_0xb03666);return _0x137e20['code']=_0x2abdb4['toUpperCase'](),_0x137e20;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0xa23052){if(Yl['test'](_0xa23052)){const _0x4881e0=Number(_0xa23052);if(_0x4881e0>=Ql&&_0x4881e0<=Jl)return _0x4881e0;}return null;},ft=function(_0x2b44ad){try{_0x2b44ad();}catch(_0x297ded){setTimeout(()=>{const _0x25c712=_0x297ded['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x25c712),_0x297ded;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x45267c,_0x5aee8e){const _0x382fe8=setTimeout(_0x45267c,_0x5aee8e);return typeof _0x382fe8=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x382fe8):typeof _0x382fe8=='object'&&_0x382fe8['unref']&&_0x382fe8['unref'](),_0x382fe8;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x67c525,_0x430013){this['appCheckProvider']=_0x430013,this['appName']=_0x67c525['name'],$(_0x67c525)&&_0x67c525['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x67c525['settings']['appCheckToken']),this['appCheck']=_0x430013==null?void 0x0:_0x430013['getImmediate']({'optional':!0x0}),this['appCheck']||_0x430013==null||_0x430013['get']()['then'](_0x5aa0e=>this['appCheck']=_0x5aa0e);}['getToken'](_0x50562c){if(this['serverAppAppCheckToken']){if(_0x50562c)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x50562c):new Promise((_0x5ebfee,_0x2c7bc1)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x50562c)['then'](_0x5ebfee,_0x2c7bc1):_0x5ebfee(null);},0x0);});}['addTokenChangeListener'](_0x2210d4){var _0x3e23cf;(_0x3e23cf=this['appCheckProvider'])==null||_0x3e23cf['get']()['then'](_0x3861fd=>_0x3861fd['addTokenListener'](_0x2210d4));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x43349d,_0x122a8a,_0x4b63ef){this['appName_']=_0x43349d,this['firebaseOptions_']=_0x122a8a,this['authProvider_']=_0x4b63ef,this['auth_']=null,this['auth_']=_0x4b63ef['getImmediate']({'optional':!0x0}),this['auth_']||_0x4b63ef['onInit'](_0x4206e6=>this['auth_']=_0x4206e6);}['getToken'](_0x1561fb){return this['auth_']?this['auth_']['getToken'](_0x1561fb)['catch'](_0xfa4b1b=>_0xfa4b1b&&_0xfa4b1b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xfa4b1b)):new Promise((_0x15cf35,_0x1b2145)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1561fb)['then'](_0x15cf35,_0x1b2145):_0x15cf35(null);},0x0);});}['addTokenChangeListener'](_0x2d3c2f){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2d3c2f):this['authProvider_']['get']()['then'](_0x4316ca=>_0x4316ca['addAuthTokenListener'](_0x2d3c2f));}['removeTokenChangeListener'](_0x4adc46){this['authProvider_']['get']()['then'](_0x4ea717=>_0x4ea717['removeAuthTokenListener'](_0x4adc46));}['notifyForInvalidToken'](){let _0x3d3d34='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x3d3d34+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x3d3d34+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x3d3d34+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x3d3d34);}}class an{constructor(_0xa0943f){this['accessToken']=_0xa0943f;}['getToken'](_0x2c1f9b){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1a880d){_0x1a880d(this['accessToken']);}['removeTokenChangeListener'](_0xf4c92){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x149e7f,_0x35418c,_0x1a4599,_0x4831be,_0x3e5301=!0x1,_0x19c170='',_0x421d30=!0x1,_0x1d3226=!0x1,_0x23b4ca=null){this['secure']=_0x35418c,this['namespace']=_0x1a4599,this['webSocketOnly']=_0x4831be,this['nodeAdmin']=_0x3e5301,this['persistenceKey']=_0x19c170,this['includeNamespaceInQueryParams']=_0x421d30,this['isUsingEmulator']=_0x1d3226,this['emulatorOptions']=_0x23b4ca,this['_host']=_0x149e7f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x149e7f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x526e5c){_0x526e5c!==this['internalHost']&&(this['internalHost']=_0x526e5c,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2ffa77=this['toURLString']();return this['persistenceKey']&&(_0x2ffa77+='<'+this['persistenceKey']+'>'),_0x2ffa77;}['toURLString'](){const _0x497024=this['secure']?'https://':'http://',_0x335bda=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x497024+this['host']+'/'+_0x335bda;}}function th(_0x389982){return _0x389982['host']!==_0x389982['internalHost']||_0x389982['isCustomHost']()||_0x389982['includeNamespaceInQueryParams'];}function vo(_0x33d97f,_0x3d09d7,_0x18f6c6){f(typeof _0x3d09d7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x18f6c6=='object','typeof\x20params\x20must\x20==\x20object');let _0x1f69ac;if(_0x3d09d7===go)_0x1f69ac=(_0x33d97f['secure']?'wss://':'ws://')+_0x33d97f['internalHost']+'/.ws?';else{if(_0x3d09d7===mo)_0x1f69ac=(_0x33d97f['secure']?'https://':'http://')+_0x33d97f['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3d09d7);}th(_0x33d97f)&&(_0x18f6c6['ns']=_0x33d97f['namespace']);const _0x403918=[];return x(_0x18f6c6,(_0x473d72,_0x5a55eb)=>{_0x403918['push'](_0x473d72+'='+_0x5a55eb);}),_0x1f69ac+_0x403918['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x5bf666,_0x3bd200=0x1){Q(this['counters_'],_0x5bf666)||(this['counters_'][_0x5bf666]=0x0),this['counters_'][_0x5bf666]+=_0x3bd200;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x13e9c4){const _0x1b234a=_0x13e9c4['toString']();return oi[_0x1b234a]||(oi[_0x1b234a]=new nh()),oi[_0x1b234a];}function ih(_0x10ed18,_0x7c2a4c){const _0xd77f8f=_0x10ed18['toString']();return ai[_0xd77f8f]||(ai[_0xd77f8f]=_0x7c2a4c()),ai[_0xd77f8f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3db18e){this['onMessage_']=_0x3db18e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x403ce8,_0xedb0e4){this['closeAfterResponse']=_0x403ce8,this['onClose']=_0xedb0e4,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2a0a35,_0x264787){for(this['pendingResponses'][_0x2a0a35]=_0x264787;this['pendingResponses'][this['currentResponseNum']];){const _0x3e19f3=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4d8e7f=0x0;_0x4d8e7f<_0x3e19f3['length'];++_0x4d8e7f)_0x3e19f3[_0x4d8e7f]&&ft(()=>{this['onMessage_'](_0x3e19f3[_0x4d8e7f]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x9486f8,_0x3b4e33,_0x5c8057,_0x1aa4b2,_0x2d078d,_0xdf4c3d,_0x2de0de){this['connId']=_0x9486f8,this['repoInfo']=_0x3b4e33,this['applicationId']=_0x5c8057,this['appCheckToken']=_0x1aa4b2,this['authToken']=_0x2d078d,this['transportSessionId']=_0xdf4c3d,this['lastSessionId']=_0x2de0de,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x9486f8),this['stats_']=qi(_0x3b4e33),this['urlFn']=_0x5b2d7a=>(this['appCheckToken']&&(_0x5b2d7a[wi]=this['appCheckToken']),vo(_0x3b4e33,mo,_0x5b2d7a));}['open'](_0x44e8e1,_0x22eb1b){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x22eb1b,this['myPacketOrderer']=new sh(_0x44e8e1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x358c2a)=>{const [_0x2e3483,_0x290398,_0x219f21,_0x2d4fce,_0x120048]=_0x358c2a;if(this['incrementIncomingBytes_'](_0x358c2a),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2e3483===qs)this['id']=_0x290398,this['password']=_0x219f21;else{if(_0x2e3483===rh)_0x290398?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x290398,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2e3483);}}},(..._0x58a2d0)=>{const [_0x4ae075,_0x465aea]=_0x58a2d0;this['incrementIncomingBytes_'](_0x58a2d0),this['myPacketOrderer']['handleResponse'](_0x4ae075,_0x465aea);},()=>{this['onClosed_']();},this['urlFn']);const _0x30f534={};_0x30f534[qs]='t',_0x30f534[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x30f534[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x30f534[co]=Gi,this['transportSessionId']&&(_0x30f534[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x30f534[po]=this['lastSessionId']),this['applicationId']&&(_0x30f534[_o]=this['applicationId']),this['appCheckToken']&&(_0x30f534[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x30f534[ho]=uo);const _0x5733ec=this['urlFn'](_0x30f534);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5733ec),this['scriptTagHolder']['addTag'](_0x5733ec,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x287dc5){const _0x32c313=O(_0x287dc5);this['bytesSent']+=_0x32c313['length'],this['stats_']['incrementCounter']('bytes_sent',_0x32c313['length']);const _0xbf82b4=$r(_0x32c313),_0xe43667=oo(_0xbf82b4,fh);for(let _0x5eb175=0x0;_0x5eb175<_0xe43667['length'];_0x5eb175++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xe43667['length'],_0xe43667[_0x5eb175]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5164a9,_0x1e484b){this['myDisconnFrame']=document['createElement']('iframe');const _0x56c970={};_0x56c970[dh]='t',_0x56c970[Eo]=_0x5164a9,_0x56c970[Io]=_0x1e484b,this['myDisconnFrame']['src']=this['urlFn'](_0x56c970),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x396246){const _0x353ead=O(_0x396246)['length'];this['bytesReceived']+=_0x353ead,this['stats_']['incrementCounter']('bytes_received',_0x353ead);}}class zi{constructor(_0x3f2d9b,_0x5eaa59,_0x2bc403,_0x40885b){this['onDisconnect']=_0x2bc403,this['urlFn']=_0x40885b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3f2d9b,window[ah+this['uniqueCallbackIdentifier']]=_0x5eaa59,this['myIFrame']=zi['createIFrame_']();let _0x36e07e='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x36e07e='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3012c0='<html><body>'+_0x36e07e+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3012c0),this['myIFrame']['doc']['close']();}catch(_0x545342){L('frame\x20writing\x20exception'),_0x545342['stack']&&L(_0x545342['stack']),L(_0x545342);}}}static['createIFrame_'](){const _0x59f13c=document['createElement']('iframe');if(_0x59f13c['style']['display']='none',document['body']){document['body']['appendChild'](_0x59f13c);try{_0x59f13c['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x86b38a=document['domain'];_0x59f13c['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x86b38a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x59f13c['contentDocument']?_0x59f13c['doc']=_0x59f13c['contentDocument']:_0x59f13c['contentWindow']?_0x59f13c['doc']=_0x59f13c['contentWindow']['document']:_0x59f13c['document']&&(_0x59f13c['doc']=_0x59f13c['document']),_0x59f13c;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x240731=this['onDisconnect'];_0x240731&&(this['onDisconnect']=null,_0x240731());}['startLongPoll'](_0x3c7281,_0x532240){for(this['myID']=_0x3c7281,this['myPW']=_0x532240,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x4083ed={};_0x4083ed[Eo]=this['myID'],_0x4083ed[Io]=this['myPW'],_0x4083ed[wo]=this['currentSerial'];let _0x1a0418=this['urlFn'](_0x4083ed),_0x2373d4='',_0x5a3c20=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2373d4['length']<=Co;){const _0x311ac9=this['pendingSegs']['shift']();_0x2373d4=_0x2373d4+'&'+lh+_0x5a3c20+'='+_0x311ac9['seg']+'&'+hh+_0x5a3c20+'='+_0x311ac9['ts']+'&'+uh+_0x5a3c20+'='+_0x311ac9['d'],_0x5a3c20++;}return _0x1a0418=_0x1a0418+_0x2373d4,this['addLongPollTag_'](_0x1a0418,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1072ff,_0x1a61ed,_0x2637ec){this['pendingSegs']['push']({'seg':_0x1072ff,'ts':_0x1a61ed,'d':_0x2637ec}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5191d4,_0x28e4e3){this['outstandingRequests']['add'](_0x28e4e3);const _0x13ae7f=()=>{this['outstandingRequests']['delete'](_0x28e4e3),this['newRequest_']();},_0x4d67c9=setTimeout(_0x13ae7f,Math['floor'](ph)),_0x2546a0=()=>{clearTimeout(_0x4d67c9),_0x13ae7f();};this['addTag'](_0x5191d4,_0x2546a0);}['addTag'](_0x3a6100,_0x888dbf){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x580ffe=this['myIFrame']['doc']['createElement']('script');_0x580ffe['type']='text/javascript',_0x580ffe['async']=!0x0,_0x580ffe['src']=_0x3a6100,_0x580ffe['onload']=_0x580ffe['onreadystatechange']=function(){const _0x413bd4=_0x580ffe['readyState'];(!_0x413bd4||_0x413bd4==='loaded'||_0x413bd4==='complete')&&(_0x580ffe['onload']=_0x580ffe['onreadystatechange']=null,_0x580ffe['parentNode']&&_0x580ffe['parentNode']['removeChild'](_0x580ffe),_0x888dbf());},_0x580ffe['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3a6100),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x580ffe);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2e1eea,_0x173744,_0x45675b,_0x26096c,_0x2b3fab,_0x1ee774,_0x455a0a){this['connId']=_0x2e1eea,this['applicationId']=_0x45675b,this['appCheckToken']=_0x26096c,this['authToken']=_0x2b3fab,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x173744),this['connURL']=q['connectionURL_'](_0x173744,_0x1ee774,_0x455a0a,_0x26096c,_0x45675b),this['nodeAdmin']=_0x173744['nodeAdmin'];}static['connectionURL_'](_0x2c580c,_0x192632,_0x40cd45,_0x487810,_0x5b2c57){const _0x3fa62d={};return _0x3fa62d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3fa62d[ho]=uo),_0x192632&&(_0x3fa62d[lo]=_0x192632),_0x40cd45&&(_0x3fa62d[po]=_0x40cd45),_0x487810&&(_0x3fa62d[wi]=_0x487810),_0x5b2c57&&(_0x3fa62d[_o]=_0x5b2c57),vo(_0x2c580c,go,_0x3fa62d);}['open'](_0x4f6bf0,_0x571a9e){this['onDisconnect']=_0x571a9e,this['onMessage']=_0x4f6bf0,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x45ac44;_c(),this['mySock']=new gn(this['connURL'],[],_0x45ac44);}catch(_0xc0f2fb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5cb9a3=_0xc0f2fb['message']||_0xc0f2fb['data'];_0x5cb9a3&&this['log_'](_0x5cb9a3),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x448ea0=>{this['handleIncomingFrame'](_0x448ea0);},this['mySock']['onerror']=_0x27fe53=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x20fb12=_0x27fe53['message']||_0x27fe53['data'];_0x20fb12&&this['log_'](_0x20fb12),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4b9553=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x206dac=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x160b16=navigator['userAgent']['match'](_0x206dac);_0x160b16&&_0x160b16['length']>0x1&&parseFloat(_0x160b16[0x1])<4.4&&(_0x4b9553=!0x0);}return!_0x4b9553&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x4e7efe){if(this['frames']['push'](_0x4e7efe),this['frames']['length']===this['totalFrames']){const _0x1fde7e=this['frames']['join']('');this['frames']=null;const _0x57feec=Nt(_0x1fde7e);this['onMessage'](_0x57feec);}}['handleNewFrameCount_'](_0x108df9){this['totalFrames']=_0x108df9,this['frames']=[];}['extractFrameCount_'](_0x53938e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x53938e['length']<=0x6){const _0x2b49ac=Number(_0x53938e);if(!isNaN(_0x2b49ac))return this['handleNewFrameCount_'](_0x2b49ac),null;}return this['handleNewFrameCount_'](0x1),_0x53938e;}['handleIncomingFrame'](_0x372887){if(this['mySock']===null)return;const _0x12f491=_0x372887['data'];if(this['bytesReceived']+=_0x12f491['length'],this['stats_']['incrementCounter']('bytes_received',_0x12f491['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x12f491);else{const _0x57fb5e=this['extractFrameCount_'](_0x12f491);_0x57fb5e!==null&&this['appendFrame_'](_0x57fb5e);}}['send'](_0x4bde88){this['resetKeepAlive']();const _0x4b71ef=O(_0x4bde88);this['bytesSent']+=_0x4b71ef['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4b71ef['length']);const _0x2899d8=oo(_0x4b71ef,gh);_0x2899d8['length']>0x1&&this['sendString_'](String(_0x2899d8['length']));for(let _0x32ce12=0x0;_0x32ce12<_0x2899d8['length'];_0x32ce12++)this['sendString_'](_0x2899d8[_0x32ce12]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x44029d){try{this['mySock']['send'](_0x44029d);}catch(_0x469e8b){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x469e8b['message']||_0x469e8b['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1ae437){this['initTransports_'](_0x1ae437);}['initTransports_'](_0x14cfdd){const _0x36c4d5=q&&q['isAvailable']();let _0x25f658=_0x36c4d5&&!q['previouslyFailed']();if(_0x14cfdd['webSocketOnly']&&(_0x36c4d5||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x25f658=!0x0),_0x25f658)this['transports_']=[q];else{const _0x49be22=this['transports_']=[];for(const _0xd477ef of Dt['ALL_TRANSPORTS'])_0xd477ef&&_0xd477ef['isAvailable']()&&_0x49be22['push'](_0xd477ef);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x104c51,_0x485893,_0x5147d9,_0x595784,_0xe3dafb,_0x3cadc7,_0x4e3669,_0x11cfb5,_0x2ff3a8,_0xa5e4fb){this['id']=_0x104c51,this['repoInfo_']=_0x485893,this['applicationId_']=_0x5147d9,this['appCheckToken_']=_0x595784,this['authToken_']=_0xe3dafb,this['onMessage_']=_0x3cadc7,this['onReady_']=_0x4e3669,this['onDisconnect_']=_0x11cfb5,this['onKill_']=_0x2ff3a8,this['lastSessionId']=_0xa5e4fb,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x485893),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2f68c7=this['transportManager_']['initialTransport']();this['conn_']=new _0x2f68c7(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2f68c7['responsesRequiredToBeHealthy']||0x0;const _0x517fc7=this['connReceiver_'](this['conn_']),_0x1083fd=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x517fc7,_0x1083fd);},Math['floor'](0x0));const _0x1018b0=_0x2f68c7['healthyTimeout']||0x0;_0x1018b0>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1018b0)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x36ce69){return _0x578a1b=>{_0x36ce69===this['conn_']?this['onConnectionLost_'](_0x578a1b):_0x36ce69===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x23e99e){return _0x52893a=>{this['state_']!==0x2&&(_0x23e99e===this['rx_']?this['onPrimaryMessageReceived_'](_0x52893a):_0x23e99e===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x52893a):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x146861){const _0x3cf354={'t':'d','d':_0x146861};this['sendData_'](_0x3cf354);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1182a2){if(ci in _0x1182a2){const _0xbe26cf=_0x1182a2[ci];_0xbe26cf===Ys?this['upgradeIfSecondaryHealthy_']():_0xbe26cf===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xbe26cf===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1f1f66){const _0x48b9cc=vt('t',_0x1f1f66),_0x572980=vt('d',_0x1f1f66);if(_0x48b9cc==='c')this['onSecondaryControl_'](_0x572980);else{if(_0x48b9cc==='d')this['pendingDataMessages']['push'](_0x572980);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x48b9cc);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xd98d19){const _0x1700b3=vt('t',_0xd98d19),_0x42e34b=vt('d',_0xd98d19);_0x1700b3==='c'?this['onControl_'](_0x42e34b):_0x1700b3==='d'&&this['onDataMessage_'](_0x42e34b);}['onDataMessage_'](_0x2ae4d5){this['onPrimaryResponse_'](),this['onMessage_'](_0x2ae4d5);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5ebc53){const _0x597369=vt(ci,_0x5ebc53);if(zs in _0x5ebc53){const _0x26f875=_0x5ebc53[zs];if(_0x597369===Th){const _0x18ddbd={..._0x26f875};this['repoInfo_']['isUsingEmulator']&&(_0x18ddbd['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x18ddbd);}else{if(_0x597369===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x379172=0x0;_0x379172<this['pendingDataMessages']['length'];++_0x379172)this['onDataMessage_'](this['pendingDataMessages'][_0x379172]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x597369===wh?this['onConnectionShutdown_'](_0x26f875):_0x597369===js?this['onReset_'](_0x26f875):_0x597369===Ch?Ii('Server\x20Error:\x20'+_0x26f875):_0x597369===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x597369);}}}['onHandshake_'](_0xdef5a7){const _0x1c10fe=_0xdef5a7['ts'],_0x4bf201=_0xdef5a7['v'],_0x4507d3=_0xdef5a7['h'];this['sessionId']=_0xdef5a7['s'],this['repoInfo_']['host']=_0x4507d3,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1c10fe),Gi!==_0x4bf201&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x49802a=this['transportManager_']['upgradeTransport']();_0x49802a&&this['startUpgrade_'](_0x49802a);}['startUpgrade_'](_0xf2522d){this['secondaryConn_']=new _0xf2522d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xf2522d['responsesRequiredToBeHealthy']||0x0;const _0x10ef7d=this['connReceiver_'](this['secondaryConn_']),_0x38d253=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x10ef7d,_0x38d253),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0xe59584){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xe59584),this['repoInfo_']['host']=_0xe59584,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x2969bf,_0x38818e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x2969bf,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x38818e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x265daf=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x265daf||this['rx_']===_0x265daf)&&this['close']();}['onConnectionLost_'](_0x163378){this['conn_']=null,!_0x163378&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x121fa6){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x121fa6),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4f7944){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4f7944);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xd6e1ca,_0x534c07,_0x5cb2de,_0xd47ac2){}['merge'](_0x35ecc4,_0x5d0b97,_0x89532f,_0x91633d){}['refreshAuthToken'](_0x3934ee){}['refreshAppCheckToken'](_0x39babf){}['onDisconnectPut'](_0x3020da,_0x3e2369,_0x12d8ec){}['onDisconnectMerge'](_0x2d807f,_0x5744e5,_0x581ffc){}['onDisconnectCancel'](_0x31c52f,_0x3ab062){}['reportStats'](_0x35c8a6){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3b9727){this['allowedEvents_']=_0x3b9727,this['listeners_']={},f(Array['isArray'](_0x3b9727)&&_0x3b9727['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1f0b28,..._0x533743){if(Array['isArray'](this['listeners_'][_0x1f0b28])){const _0x35ce28=[...this['listeners_'][_0x1f0b28]];for(let _0x3e2dba=0x0;_0x3e2dba<_0x35ce28['length'];_0x3e2dba++)_0x35ce28[_0x3e2dba]['callback']['apply'](_0x35ce28[_0x3e2dba]['context'],_0x533743);}}['on'](_0x4226a9,_0x42d6d0,_0x16c593){this['validateEventType_'](_0x4226a9),this['listeners_'][_0x4226a9]=this['listeners_'][_0x4226a9]||[],this['listeners_'][_0x4226a9]['push']({'callback':_0x42d6d0,'context':_0x16c593});const _0x12d0f6=this['getInitialEvent'](_0x4226a9);_0x12d0f6&&_0x42d6d0['apply'](_0x16c593,_0x12d0f6);}['off'](_0x4e5688,_0x1bee70,_0x144e3f){this['validateEventType_'](_0x4e5688);const _0x55b74a=this['listeners_'][_0x4e5688]||[];for(let _0x98126d=0x0;_0x98126d<_0x55b74a['length'];_0x98126d++)if(_0x55b74a[_0x98126d]['callback']===_0x1bee70&&(!_0x144e3f||_0x144e3f===_0x55b74a[_0x98126d]['context'])){_0x55b74a['splice'](_0x98126d,0x1);return;}}['validateEventType_'](_0x637100){f(this['allowedEvents_']['find'](_0x32f408=>_0x32f408===_0x637100),'Unknown\x20event:\x20'+_0x637100);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5d9b0a){return f(_0x5d9b0a==='online','Unknown\x20event\x20type:\x20'+_0x5d9b0a),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x22cfc3,_0x378abd){if(_0x378abd===void 0x0){this['pieces_']=_0x22cfc3['split']('/');let _0x241e29=0x0;for(let _0x112938=0x0;_0x112938<this['pieces_']['length'];_0x112938++)this['pieces_'][_0x112938]['length']>0x0&&(this['pieces_'][_0x241e29]=this['pieces_'][_0x112938],_0x241e29++);this['pieces_']['length']=_0x241e29,this['pieceNum_']=0x0;}else this['pieces_']=_0x22cfc3,this['pieceNum_']=_0x378abd;}['toString'](){let _0x109797='';for(let _0x1a9c69=this['pieceNum_'];_0x1a9c69<this['pieces_']['length'];_0x1a9c69++)this['pieces_'][_0x1a9c69]!==''&&(_0x109797+='/'+this['pieces_'][_0x1a9c69]);return _0x109797||'/';}}function w(){return new C('');}function y(_0x3451b8){return _0x3451b8['pieceNum_']>=_0x3451b8['pieces_']['length']?null:_0x3451b8['pieces_'][_0x3451b8['pieceNum_']];}function Ce(_0x359e48){return _0x359e48['pieces_']['length']-_0x359e48['pieceNum_'];}function S(_0xc37950){let _0x1914fe=_0xc37950['pieceNum_'];return _0x1914fe<_0xc37950['pieces_']['length']&&_0x1914fe++,new C(_0xc37950['pieces_'],_0x1914fe);}function ji(_0x4da3b7){return _0x4da3b7['pieceNum_']<_0x4da3b7['pieces_']['length']?_0x4da3b7['pieces_'][_0x4da3b7['pieces_']['length']-0x1]:null;}function bh(_0x494d7a){let _0x31899d='';for(let _0x2cd4fd=_0x494d7a['pieceNum_'];_0x2cd4fd<_0x494d7a['pieces_']['length'];_0x2cd4fd++)_0x494d7a['pieces_'][_0x2cd4fd]!==''&&(_0x31899d+='/'+encodeURIComponent(String(_0x494d7a['pieces_'][_0x2cd4fd])));return _0x31899d||'/';}function Mt(_0x2e8366,_0x9e10b6=0x0){return _0x2e8366['pieces_']['slice'](_0x2e8366['pieceNum_']+_0x9e10b6);}function Ro(_0x363bcf){if(_0x363bcf['pieceNum_']>=_0x363bcf['pieces_']['length'])return null;const _0x3d6e76=[];for(let _0x33ccb3=_0x363bcf['pieceNum_'];_0x33ccb3<_0x363bcf['pieces_']['length']-0x1;_0x33ccb3++)_0x3d6e76['push'](_0x363bcf['pieces_'][_0x33ccb3]);return new C(_0x3d6e76,0x0);}function k(_0xec6067,_0x55341e){const _0x83b1fe=[];for(let _0x23f95a=_0xec6067['pieceNum_'];_0x23f95a<_0xec6067['pieces_']['length'];_0x23f95a++)_0x83b1fe['push'](_0xec6067['pieces_'][_0x23f95a]);if(_0x55341e instanceof C){for(let _0x240a83=_0x55341e['pieceNum_'];_0x240a83<_0x55341e['pieces_']['length'];_0x240a83++)_0x83b1fe['push'](_0x55341e['pieces_'][_0x240a83]);}else{const _0xc6fd87=_0x55341e['split']('/');for(let _0x123adf=0x0;_0x123adf<_0xc6fd87['length'];_0x123adf++)_0xc6fd87[_0x123adf]['length']>0x0&&_0x83b1fe['push'](_0xc6fd87[_0x123adf]);}return new C(_0x83b1fe,0x0);}function v(_0x446d0f){return _0x446d0f['pieceNum_']>=_0x446d0f['pieces_']['length'];}function F(_0x1daaed,_0x1612d0){const _0x195b53=y(_0x1daaed),_0x2b7ad1=y(_0x1612d0);if(_0x195b53===null)return _0x1612d0;if(_0x195b53===_0x2b7ad1)return F(S(_0x1daaed),S(_0x1612d0));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1612d0+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1daaed+')');}function Rh(_0x47f178,_0xc5e6d9){const _0x4b4eef=Mt(_0x47f178,0x0),_0xad0eeb=Mt(_0xc5e6d9,0x0);for(let _0x299d67=0x0;_0x299d67<_0x4b4eef['length']&&_0x299d67<_0xad0eeb['length'];_0x299d67++){const _0x32aff0=qe(_0x4b4eef[_0x299d67],_0xad0eeb[_0x299d67]);if(_0x32aff0!==0x0)return _0x32aff0;}return _0x4b4eef['length']===_0xad0eeb['length']?0x0:_0x4b4eef['length']<_0xad0eeb['length']?-0x1:0x1;}function Ki(_0x24538e,_0x2c5951){if(Ce(_0x24538e)!==Ce(_0x2c5951))return!0x1;for(let _0x1021df=_0x24538e['pieceNum_'],_0x312da7=_0x2c5951['pieceNum_'];_0x1021df<=_0x24538e['pieces_']['length'];_0x1021df++,_0x312da7++)if(_0x24538e['pieces_'][_0x1021df]!==_0x2c5951['pieces_'][_0x312da7])return!0x1;return!0x0;}function G(_0x3e9d85,_0x191e56){let _0x5bade7=_0x3e9d85['pieceNum_'],_0x1ff325=_0x191e56['pieceNum_'];if(Ce(_0x3e9d85)>Ce(_0x191e56))return!0x1;for(;_0x5bade7<_0x3e9d85['pieces_']['length'];){if(_0x3e9d85['pieces_'][_0x5bade7]!==_0x191e56['pieces_'][_0x1ff325])return!0x1;++_0x5bade7,++_0x1ff325;}return!0x0;}class Ah{constructor(_0xa39bc7,_0x5113e3){this['errorPrefix_']=_0x5113e3,this['parts_']=Mt(_0xa39bc7,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x95d859=0x0;_0x95d859<this['parts_']['length'];_0x95d859++)this['byteLength_']+=Ln(this['parts_'][_0x95d859]);Ao(this);}}function kh(_0x330c37,_0x3e2ca0){_0x330c37['parts_']['length']>0x0&&(_0x330c37['byteLength_']+=0x1),_0x330c37['parts_']['push'](_0x3e2ca0),_0x330c37['byteLength_']+=Ln(_0x3e2ca0),Ao(_0x330c37);}function Ph(_0x25d685){const _0x47d143=_0x25d685['parts_']['pop']();_0x25d685['byteLength_']-=Ln(_0x47d143),_0x25d685['parts_']['length']>0x0&&(_0x25d685['byteLength_']-=0x1);}function Ao(_0x23d6b5){if(_0x23d6b5['byteLength_']>Zs)throw new Error(_0x23d6b5['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x23d6b5['byteLength_']+').');if(_0x23d6b5['parts_']['length']>Xs)throw new Error(_0x23d6b5['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x23d6b5));}function Oe(_0x5713a3){return _0x5713a3['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5713a3['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x599c8f,_0x39e47e;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x39e47e='visibilitychange',_0x599c8f='hidden'):typeof document['mozHidden']<'u'?(_0x39e47e='mozvisibilitychange',_0x599c8f='mozHidden'):typeof document['msHidden']<'u'?(_0x39e47e='msvisibilitychange',_0x599c8f='msHidden'):typeof document['webkitHidden']<'u'&&(_0x39e47e='webkitvisibilitychange',_0x599c8f='webkitHidden')),this['visible_']=!0x0,_0x39e47e&&document['addEventListener'](_0x39e47e,()=>{const _0x566519=!document[_0x599c8f];_0x566519!==this['visible_']&&(this['visible_']=_0x566519,this['trigger']('visible',_0x566519));},!0x1);}['getInitialEvent'](_0x2f2cd4){return f(_0x2f2cd4==='visible','Unknown\x20event\x20type:\x20'+_0x2f2cd4),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x566d77,_0x4d8bec,_0x407d50,_0x3bf0e7,_0xe65d96,_0x295297,_0x2f6304,_0x372dd6){if(super(),this['repoInfo_']=_0x566d77,this['applicationId_']=_0x4d8bec,this['onDataUpdate_']=_0x407d50,this['onConnectStatus_']=_0x3bf0e7,this['onServerInfoUpdate_']=_0xe65d96,this['authTokenProvider_']=_0x295297,this['appCheckTokenProvider_']=_0x2f6304,this['authOverride_']=_0x372dd6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x372dd6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x566d77['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x43fec0,_0x87691c,_0x3b7f88){const _0x3f3290=++this['requestNumber_'],_0x37c28a={'r':_0x3f3290,'a':_0x43fec0,'b':_0x87691c};this['log_'](O(_0x37c28a)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x37c28a),_0x3b7f88&&(this['requestCBHash_'][_0x3f3290]=_0x3b7f88);}['get'](_0x5b2bc){this['initConnection_']();const _0x325929=new H(),_0x2a63b4={'action':'g','request':{'p':_0x5b2bc['_path']['toString'](),'q':_0x5b2bc['_queryObject']},'onComplete':_0x233aa6=>{const _0x16d74e=_0x233aa6['d'];_0x233aa6['s']==='ok'?_0x325929['resolve'](_0x16d74e):_0x325929['reject'](_0x16d74e);}};this['outstandingGets_']['push'](_0x2a63b4),this['outstandingGetCount_']++;const _0x787984=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x787984),_0x325929['promise'];}['listen'](_0x4fac99,_0x4562ca,_0x3bcd5d,_0x50c48f){this['initConnection_']();const _0x3f194d=_0x4fac99['_queryIdentifier'],_0x5cea3d=_0x4fac99['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5cea3d+'\x20'+_0x3f194d),this['listens']['has'](_0x5cea3d)||this['listens']['set'](_0x5cea3d,new Map()),f(_0x4fac99['_queryParams']['isDefault']()||!_0x4fac99['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5cea3d)['has'](_0x3f194d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x4df834={'onComplete':_0x50c48f,'hashFn':_0x4562ca,'query':_0x4fac99,'tag':_0x3bcd5d};this['listens']['get'](_0x5cea3d)['set'](_0x3f194d,_0x4df834),this['connected_']&&this['sendListen_'](_0x4df834);}['sendGet_'](_0x2eb1a3){const _0x44e6cc=this['outstandingGets_'][_0x2eb1a3];this['sendRequest']('g',_0x44e6cc['request'],_0x46ac41=>{delete this['outstandingGets_'][_0x2eb1a3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x44e6cc['onComplete']&&_0x44e6cc['onComplete'](_0x46ac41);});}['sendListen_'](_0x1a1b99){const _0x12dd03=_0x1a1b99['query'],_0x37eeb5=_0x12dd03['_path']['toString'](),_0x4f619d=_0x12dd03['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x37eeb5+'\x20for\x20'+_0x4f619d);const _0x1be78e={'p':_0x37eeb5},_0x5b49a7='q';_0x1a1b99['tag']&&(_0x1be78e['q']=_0x12dd03['_queryObject'],_0x1be78e['t']=_0x1a1b99['tag']),_0x1be78e['h']=_0x1a1b99['hashFn'](),this['sendRequest'](_0x5b49a7,_0x1be78e,_0x4133e3=>{const _0x4ef912=_0x4133e3['d'],_0x20aa0b=_0x4133e3['s'];se['warnOnListenWarnings_'](_0x4ef912,_0x12dd03),(this['listens']['get'](_0x37eeb5)&&this['listens']['get'](_0x37eeb5)['get'](_0x4f619d))===_0x1a1b99&&(this['log_']('listen\x20response',_0x4133e3),_0x20aa0b!=='ok'&&this['removeListen_'](_0x37eeb5,_0x4f619d),_0x1a1b99['onComplete']&&_0x1a1b99['onComplete'](_0x20aa0b,_0x4ef912));});}static['warnOnListenWarnings_'](_0xfbdd38,_0x9a9b95){if(_0xfbdd38&&typeof _0xfbdd38=='object'&&Q(_0xfbdd38,'w')){const _0x675ee5=Le(_0xfbdd38,'w');if(Array['isArray'](_0x675ee5)&&~_0x675ee5['indexOf']('no_index')){const _0x489795='\x22.indexOn\x22:\x20\x22'+_0x9a9b95['_queryParams']['getIndex']()['toString']()+'\x22',_0x88de92=_0x9a9b95['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x489795+'\x20at\x20'+_0x88de92+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3bfce5){this['authToken_']=_0x3bfce5,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3bfce5);}['reduceReconnectDelayIfAdminCredential_'](_0x32588e){(_0x32588e&&_0x32588e['length']===0x28||wc(_0x32588e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x465759){this['appCheckToken_']=_0x465759,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x180967=this['authToken_'],_0x2649b7=Ic(_0x180967)?'auth':'gauth',_0x4b2845={'cred':_0x180967};this['authOverride_']===null?_0x4b2845['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4b2845['authvar']=this['authOverride_']),this['sendRequest'](_0x2649b7,_0x4b2845,_0x5b375b=>{const _0x5ed544=_0x5b375b['s'],_0x127c8b=_0x5b375b['d']||'error';this['authToken_']===_0x180967&&(_0x5ed544==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5ed544,_0x127c8b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x50cf1e=>{const _0x45f501=_0x50cf1e['s'],_0x593b57=_0x50cf1e['d']||'error';_0x45f501==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x45f501,_0x593b57);});}['unlisten'](_0xf2ae73,_0x569d6b){const _0x347bd3=_0xf2ae73['_path']['toString'](),_0x58b643=_0xf2ae73['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x347bd3+'\x20'+_0x58b643),f(_0xf2ae73['_queryParams']['isDefault']()||!_0xf2ae73['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x347bd3,_0x58b643)&&this['connected_']&&this['sendUnlisten_'](_0x347bd3,_0x58b643,_0xf2ae73['_queryObject'],_0x569d6b);}['sendUnlisten_'](_0x30028f,_0x444b33,_0x4d9531,_0x5b7b58){this['log_']('Unlisten\x20on\x20'+_0x30028f+'\x20for\x20'+_0x444b33);const _0x429ccb={'p':_0x30028f},_0x25fbce='n';_0x5b7b58&&(_0x429ccb['q']=_0x4d9531,_0x429ccb['t']=_0x5b7b58),this['sendRequest'](_0x25fbce,_0x429ccb);}['onDisconnectPut'](_0x3aa348,_0xbeb169,_0x160ceb){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3aa348,_0xbeb169,_0x160ceb):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3aa348,'action':'o','data':_0xbeb169,'onComplete':_0x160ceb});}['onDisconnectMerge'](_0x222246,_0x4d995f,_0x4e49ef){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x222246,_0x4d995f,_0x4e49ef):this['onDisconnectRequestQueue_']['push']({'pathString':_0x222246,'action':'om','data':_0x4d995f,'onComplete':_0x4e49ef});}['onDisconnectCancel'](_0x581ef5,_0x5272fe){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x581ef5,null,_0x5272fe):this['onDisconnectRequestQueue_']['push']({'pathString':_0x581ef5,'action':'oc','data':null,'onComplete':_0x5272fe});}['sendOnDisconnect_'](_0x505be1,_0x50cd85,_0xe72630,_0x949a42){const _0x2a2f67={'p':_0x50cd85,'d':_0xe72630};this['log_']('onDisconnect\x20'+_0x505be1,_0x2a2f67),this['sendRequest'](_0x505be1,_0x2a2f67,_0x5d78a3=>{_0x949a42&&setTimeout(()=>{_0x949a42(_0x5d78a3['s'],_0x5d78a3['d']);},Math['floor'](0x0));});}['put'](_0x31d380,_0x6a36a,_0x1b3398,_0x4fc647){this['putInternal']('p',_0x31d380,_0x6a36a,_0x1b3398,_0x4fc647);}['merge'](_0x2a5018,_0x22d0e8,_0x19ca7c,_0xe51f74){this['putInternal']('m',_0x2a5018,_0x22d0e8,_0x19ca7c,_0xe51f74);}['putInternal'](_0x4dbc65,_0x9539ca,_0x571b62,_0x5ae31d,_0x21b200){this['initConnection_']();const _0x2ebc7e={'p':_0x9539ca,'d':_0x571b62};_0x21b200!==void 0x0&&(_0x2ebc7e['h']=_0x21b200),this['outstandingPuts_']['push']({'action':_0x4dbc65,'request':_0x2ebc7e,'onComplete':_0x5ae31d}),this['outstandingPutCount_']++;const _0xd92921=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xd92921):this['log_']('Buffering\x20put:\x20'+_0x9539ca);}['sendPut_'](_0x44e15b){const _0x488b7a=this['outstandingPuts_'][_0x44e15b]['action'],_0x2a6be4=this['outstandingPuts_'][_0x44e15b]['request'],_0x5378c5=this['outstandingPuts_'][_0x44e15b]['onComplete'];this['outstandingPuts_'][_0x44e15b]['queued']=this['connected_'],this['sendRequest'](_0x488b7a,_0x2a6be4,_0x475f7d=>{this['log_'](_0x488b7a+'\x20response',_0x475f7d),delete this['outstandingPuts_'][_0x44e15b],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x5378c5&&_0x5378c5(_0x475f7d['s'],_0x475f7d['d']);});}['reportStats'](_0x492607){if(this['connected_']){const _0x130d03={'c':_0x492607};this['log_']('reportStats',_0x130d03),this['sendRequest']('s',_0x130d03,_0x2b7508=>{if(_0x2b7508['s']!=='ok'){const _0xfa1ce9=_0x2b7508['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xfa1ce9);}});}}['onDataMessage_'](_0x5ce8f9){if('r'in _0x5ce8f9){this['log_']('from\x20server:\x20'+O(_0x5ce8f9));const _0x3d9e81=_0x5ce8f9['r'],_0x58c0dc=this['requestCBHash_'][_0x3d9e81];_0x58c0dc&&(delete this['requestCBHash_'][_0x3d9e81],_0x58c0dc(_0x5ce8f9['b']));}else{if('error'in _0x5ce8f9)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5ce8f9['error'];'a'in _0x5ce8f9&&this['onDataPush_'](_0x5ce8f9['a'],_0x5ce8f9['b']);}}['onDataPush_'](_0xa2d222,_0x448b5c){this['log_']('handleServerMessage',_0xa2d222,_0x448b5c),_0xa2d222==='d'?this['onDataUpdate_'](_0x448b5c['p'],_0x448b5c['d'],!0x1,_0x448b5c['t']):_0xa2d222==='m'?this['onDataUpdate_'](_0x448b5c['p'],_0x448b5c['d'],!0x0,_0x448b5c['t']):_0xa2d222==='c'?this['onListenRevoked_'](_0x448b5c['p'],_0x448b5c['q']):_0xa2d222==='ac'?this['onAuthRevoked_'](_0x448b5c['s'],_0x448b5c['d']):_0xa2d222==='apc'?this['onAppCheckRevoked_'](_0x448b5c['s'],_0x448b5c['d']):_0xa2d222==='sd'?this['onSecurityDebugPacket_'](_0x448b5c):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0xa2d222)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x38ea21,_0x3f04fc){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x38ea21),this['lastSessionId']=_0x3f04fc,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x40cab4){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x40cab4));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x551c6e){_0x551c6e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x551c6e;}['onOnline_'](_0x2034f1){_0x2034f1?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x187b36=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x29824f=Math['max'](0x0,this['reconnectDelay_']-_0x187b36);_0x29824f=Math['random']()*_0x29824f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x29824f+'ms'),this['scheduleConnect_'](_0x29824f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2d5ccb=this['onDataMessage_']['bind'](this),_0x5813aa=this['onReady_']['bind'](this),_0x5683ff=this['onRealtimeDisconnect_']['bind'](this),_0x4fe50a=this['id']+':'+se['nextConnectionId_']++,_0x1a0884=this['lastSessionId'];let _0x44183e=!0x1,_0x2692d9=null;const _0x3008cf=function(){_0x2692d9?_0x2692d9['close']():(_0x44183e=!0x0,_0x5683ff());},_0x5a87ed=function(_0x7df70b){f(_0x2692d9,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2692d9['sendRequest'](_0x7df70b);};this['realtime_']={'close':_0x3008cf,'sendRequest':_0x5a87ed};const _0x283d1b=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x54525a,_0x3e9e38]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x283d1b),this['appCheckTokenProvider_']['getToken'](_0x283d1b)]);_0x44183e?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x54525a&&_0x54525a['accessToken'],this['appCheckToken_']=_0x3e9e38&&_0x3e9e38['token'],_0x2692d9=new Sh(_0x4fe50a,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2d5ccb,_0x5813aa,_0x5683ff,_0x588859=>{U(_0x588859+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1a0884));}catch(_0x320743){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x320743),_0x44183e||(this['repoInfo_']['nodeAdmin']&&U(_0x320743),_0x3008cf());}}}['interrupt'](_0x4db86e){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4db86e),this['interruptReasons_'][_0x4db86e]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1355f7){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1355f7),delete this['interruptReasons_'][_0x1355f7],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4b6d09){const _0x1e765d=_0x4b6d09-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1e765d});}['cancelSentTransactions_'](){for(let _0x1bd3ca=0x0;_0x1bd3ca<this['outstandingPuts_']['length'];_0x1bd3ca++){const _0x2b51a3=this['outstandingPuts_'][_0x1bd3ca];_0x2b51a3&&'h'in _0x2b51a3['request']&&_0x2b51a3['queued']&&(_0x2b51a3['onComplete']&&_0x2b51a3['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1bd3ca],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1dd28c,_0x55c541){let _0x279988;_0x55c541?_0x279988=_0x55c541['map'](_0x35aaff=>$i(_0x35aaff))['join']('$'):_0x279988='default';const _0x2b2096=this['removeListen_'](_0x1dd28c,_0x279988);_0x2b2096&&_0x2b2096['onComplete']&&_0x2b2096['onComplete']('permission_denied');}['removeListen_'](_0x58c43d,_0x38fba7){const _0x2fb1b2=new C(_0x58c43d)['toString']();let _0x2792f4;if(this['listens']['has'](_0x2fb1b2)){const _0x153213=this['listens']['get'](_0x2fb1b2);_0x2792f4=_0x153213['get'](_0x38fba7),_0x153213['delete'](_0x38fba7),_0x153213['size']===0x0&&this['listens']['delete'](_0x2fb1b2);}else _0x2792f4=void 0x0;return _0x2792f4;}['onAuthRevoked_'](_0x3b0ffc,_0x445b57){L('Auth\x20token\x20revoked:\x20'+_0x3b0ffc+'/'+_0x445b57),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3b0ffc==='invalid_token'||_0x3b0ffc==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2a37a9,_0x16bb1b){L('App\x20check\x20token\x20revoked:\x20'+_0x2a37a9+'/'+_0x16bb1b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2a37a9==='invalid_token'||_0x2a37a9==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2da987){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2da987):'msg'in _0x2da987&&console['log']('FIREBASE:\x20'+_0x2da987['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4f811c of this['listens']['values']())for(const _0x35dc9e of _0x4f811c['values']())this['sendListen_'](_0x35dc9e);for(let _0x10b844=0x0;_0x10b844<this['outstandingPuts_']['length'];_0x10b844++)this['outstandingPuts_'][_0x10b844]&&this['sendPut_'](_0x10b844);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1399e2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1399e2['action'],_0x1399e2['pathString'],_0x1399e2['data'],_0x1399e2['onComplete']);}for(let _0x925cf9=0x0;_0x925cf9<this['outstandingGets_']['length'];_0x925cf9++)this['outstandingGets_'][_0x925cf9]&&this['sendGet_'](_0x925cf9);}['sendConnectStats_'](){const _0x418338={};let _0x3f7e42='js';_0x418338['sdk.'+_0x3f7e42+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x418338['framework.cordova']=0x1:Kr()&&(_0x418338['framework.reactnative']=0x1),this['reportStats'](_0x418338);}['shouldReconnect_'](){const _0x41b1af=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x41b1af;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x374f44,_0x1cb434){this['name']=_0x374f44,this['node']=_0x1cb434;}static['Wrap'](_0x42cefe,_0x613a0d){return new E(_0x42cefe,_0x613a0d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x542408,_0x3d23d6){const _0x21deb4=new E(We,_0x542408),_0x3c725e=new E(We,_0x3d23d6);return this['compare'](_0x21deb4,_0x3c725e)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x163176){sn=_0x163176;}['compare'](_0x300c4d,_0x1b65ff){return qe(_0x300c4d['name'],_0x1b65ff['name']);}['isDefinedOn'](_0x2d1d82){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3fdb01,_0xc84810){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x492be1,_0x1efeff){return f(typeof _0x492be1=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x492be1,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x4abff7,_0x5f5a59,_0x1f9979,_0x2d5329,_0x1607c0=null){this['isReverse_']=_0x2d5329,this['resultGenerator_']=_0x1607c0,this['nodeStack_']=[];let _0x5f1360=0x1;for(;!_0x4abff7['isEmpty']();)if(_0x4abff7=_0x4abff7,_0x5f1360=_0x5f5a59?_0x1f9979(_0x4abff7['key'],_0x5f5a59):0x1,_0x2d5329&&(_0x5f1360*=-0x1),_0x5f1360<0x0)this['isReverse_']?_0x4abff7=_0x4abff7['left']:_0x4abff7=_0x4abff7['right'];else{if(_0x5f1360===0x0){this['nodeStack_']['push'](_0x4abff7);break;}else this['nodeStack_']['push'](_0x4abff7),this['isReverse_']?_0x4abff7=_0x4abff7['right']:_0x4abff7=_0x4abff7['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3f535f=this['nodeStack_']['pop'](),_0x10bc83;if(this['resultGenerator_']?_0x10bc83=this['resultGenerator_'](_0x3f535f['key'],_0x3f535f['value']):_0x10bc83={'key':_0x3f535f['key'],'value':_0x3f535f['value']},this['isReverse_']){for(_0x3f535f=_0x3f535f['left'];!_0x3f535f['isEmpty']();)this['nodeStack_']['push'](_0x3f535f),_0x3f535f=_0x3f535f['right'];}else{for(_0x3f535f=_0x3f535f['right'];!_0x3f535f['isEmpty']();)this['nodeStack_']['push'](_0x3f535f),_0x3f535f=_0x3f535f['left'];}return _0x10bc83;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x53940d=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x53940d['key'],_0x53940d['value']):{'key':_0x53940d['key'],'value':_0x53940d['value']};}}class M{constructor(_0x596174,_0x6bf111,_0x50fd62,_0x10d51c,_0x56f1bc){this['key']=_0x596174,this['value']=_0x6bf111,this['color']=_0x50fd62??M['RED'],this['left']=_0x10d51c??B['EMPTY_NODE'],this['right']=_0x56f1bc??B['EMPTY_NODE'];}['copy'](_0xaf069e,_0x416d53,_0x233303,_0x9dea79,_0x5dd305){return new M(_0xaf069e??this['key'],_0x416d53??this['value'],_0x233303??this['color'],_0x9dea79??this['left'],_0x5dd305??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x45c748){return this['left']['inorderTraversal'](_0x45c748)||!!_0x45c748(this['key'],this['value'])||this['right']['inorderTraversal'](_0x45c748);}['reverseTraversal'](_0x3ea679){return this['right']['reverseTraversal'](_0x3ea679)||_0x3ea679(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3ea679);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5b890d,_0x55ad2e,_0x37502a){let _0x51dbfd=this;const _0x599c00=_0x37502a(_0x5b890d,_0x51dbfd['key']);return _0x599c00<0x0?_0x51dbfd=_0x51dbfd['copy'](null,null,null,_0x51dbfd['left']['insert'](_0x5b890d,_0x55ad2e,_0x37502a),null):_0x599c00===0x0?_0x51dbfd=_0x51dbfd['copy'](null,_0x55ad2e,null,null,null):_0x51dbfd=_0x51dbfd['copy'](null,null,null,null,_0x51dbfd['right']['insert'](_0x5b890d,_0x55ad2e,_0x37502a)),_0x51dbfd['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4aaded=this;return!_0x4aaded['left']['isRed_']()&&!_0x4aaded['left']['left']['isRed_']()&&(_0x4aaded=_0x4aaded['moveRedLeft_']()),_0x4aaded=_0x4aaded['copy'](null,null,null,_0x4aaded['left']['removeMin_'](),null),_0x4aaded['fixUp_']();}['remove'](_0x22a070,_0x57dc71){let _0x4d9a18,_0x4fc119;if(_0x4d9a18=this,_0x57dc71(_0x22a070,_0x4d9a18['key'])<0x0)!_0x4d9a18['left']['isEmpty']()&&!_0x4d9a18['left']['isRed_']()&&!_0x4d9a18['left']['left']['isRed_']()&&(_0x4d9a18=_0x4d9a18['moveRedLeft_']()),_0x4d9a18=_0x4d9a18['copy'](null,null,null,_0x4d9a18['left']['remove'](_0x22a070,_0x57dc71),null);else{if(_0x4d9a18['left']['isRed_']()&&(_0x4d9a18=_0x4d9a18['rotateRight_']()),!_0x4d9a18['right']['isEmpty']()&&!_0x4d9a18['right']['isRed_']()&&!_0x4d9a18['right']['left']['isRed_']()&&(_0x4d9a18=_0x4d9a18['moveRedRight_']()),_0x57dc71(_0x22a070,_0x4d9a18['key'])===0x0){if(_0x4d9a18['right']['isEmpty']())return B['EMPTY_NODE'];_0x4fc119=_0x4d9a18['right']['min_'](),_0x4d9a18=_0x4d9a18['copy'](_0x4fc119['key'],_0x4fc119['value'],null,null,_0x4d9a18['right']['removeMin_']());}_0x4d9a18=_0x4d9a18['copy'](null,null,null,null,_0x4d9a18['right']['remove'](_0x22a070,_0x57dc71));}return _0x4d9a18['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x34da28=this;return _0x34da28['right']['isRed_']()&&!_0x34da28['left']['isRed_']()&&(_0x34da28=_0x34da28['rotateLeft_']()),_0x34da28['left']['isRed_']()&&_0x34da28['left']['left']['isRed_']()&&(_0x34da28=_0x34da28['rotateRight_']()),_0x34da28['left']['isRed_']()&&_0x34da28['right']['isRed_']()&&(_0x34da28=_0x34da28['colorFlip_']()),_0x34da28;}['moveRedLeft_'](){let _0x625bdf=this['colorFlip_']();return _0x625bdf['right']['left']['isRed_']()&&(_0x625bdf=_0x625bdf['copy'](null,null,null,null,_0x625bdf['right']['rotateRight_']()),_0x625bdf=_0x625bdf['rotateLeft_'](),_0x625bdf=_0x625bdf['colorFlip_']()),_0x625bdf;}['moveRedRight_'](){let _0x2eb8a4=this['colorFlip_']();return _0x2eb8a4['left']['left']['isRed_']()&&(_0x2eb8a4=_0x2eb8a4['rotateRight_'](),_0x2eb8a4=_0x2eb8a4['colorFlip_']()),_0x2eb8a4;}['rotateLeft_'](){const _0x5451d8=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5451d8,null);}['rotateRight_'](){const _0x1c48de=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1c48de);}['colorFlip_'](){const _0x1e5d7a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2bb5dd=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1e5d7a,_0x2bb5dd);}['checkMaxDepth_'](){const _0x327393=this['check_']();return Math['pow'](0x2,_0x327393)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1852cb=this['left']['check_']();if(_0x1852cb!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1852cb+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x3720f1,_0x48c663,_0x65beba,_0x37445a,_0x272bfe){return this;}['insert'](_0x40cd71,_0x3d8525,_0x52e414){return new M(_0x40cd71,_0x3d8525,null);}['remove'](_0x39cafd,_0x385a28){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3ccb09){return!0x1;}['reverseTraversal'](_0xd741e2){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4cfc37,_0x2f30ee=B['EMPTY_NODE']){this['comparator_']=_0x4cfc37,this['root_']=_0x2f30ee;}['insert'](_0x5db3bb,_0x421c1d){return new B(this['comparator_'],this['root_']['insert'](_0x5db3bb,_0x421c1d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x28d07e){return new B(this['comparator_'],this['root_']['remove'](_0x28d07e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x54c480){let _0x2987f0,_0x1797f2=this['root_'];for(;!_0x1797f2['isEmpty']();){if(_0x2987f0=this['comparator_'](_0x54c480,_0x1797f2['key']),_0x2987f0===0x0)return _0x1797f2['value'];_0x2987f0<0x0?_0x1797f2=_0x1797f2['left']:_0x2987f0>0x0&&(_0x1797f2=_0x1797f2['right']);}return null;}['getPredecessorKey'](_0x513d41){let _0x57b355,_0x36ec5d=this['root_'],_0x2065f2=null;for(;!_0x36ec5d['isEmpty']();)if(_0x57b355=this['comparator_'](_0x513d41,_0x36ec5d['key']),_0x57b355===0x0){if(_0x36ec5d['left']['isEmpty']())return _0x2065f2?_0x2065f2['key']:null;for(_0x36ec5d=_0x36ec5d['left'];!_0x36ec5d['right']['isEmpty']();)_0x36ec5d=_0x36ec5d['right'];return _0x36ec5d['key'];}else _0x57b355<0x0?_0x36ec5d=_0x36ec5d['left']:_0x57b355>0x0&&(_0x2065f2=_0x36ec5d,_0x36ec5d=_0x36ec5d['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x51553c){return this['root_']['inorderTraversal'](_0x51553c);}['reverseTraversal'](_0x18ca20){return this['root_']['reverseTraversal'](_0x18ca20);}['getIterator'](_0x2a1564){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2a1564);}['getIteratorFrom'](_0x44a26b,_0x5a2b71){return new rn(this['root_'],_0x44a26b,this['comparator_'],!0x1,_0x5a2b71);}['getReverseIteratorFrom'](_0x362731,_0x443477){return new rn(this['root_'],_0x362731,this['comparator_'],!0x0,_0x443477);}['getReverseIterator'](_0xd47076){return new rn(this['root_'],null,this['comparator_'],!0x0,_0xd47076);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3a0a35,_0x41c6c6){return qe(_0x3a0a35['name'],_0x41c6c6['name']);}function Qi(_0x182d39,_0x5d8961){return qe(_0x182d39,_0x5d8961);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x110be1){Ci=_0x110be1;}const Po=function(_0x31c957){return typeof _0x31c957=='number'?'number:'+ao(_0x31c957):'string:'+_0x31c957;},No=function(_0x208809){if(_0x208809['isLeafNode']()){const _0x1299f4=_0x208809['val']();f(typeof _0x1299f4=='string'||typeof _0x1299f4=='number'||typeof _0x1299f4=='object'&&Q(_0x1299f4,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x208809===Ci||_0x208809['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x208809===Ci||_0x208809['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1d8b53){nr=_0x1d8b53;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0xac1aa,_0x116539=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xac1aa,this['priorityNode_']=_0x116539,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x2b6f77){return new D(this['value_'],_0x2b6f77);}['getImmediateChild'](_0x4f5a35){return _0x4f5a35==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x394bf8){return v(_0x394bf8)?this:y(_0x394bf8)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4ed570,_0x554ed3){return null;}['updateImmediateChild'](_0xe9d49,_0x29148e){return _0xe9d49==='.priority'?this['updatePriority'](_0x29148e):_0x29148e['isEmpty']()&&_0xe9d49!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xe9d49,_0x29148e)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2696a4,_0x30848b){const _0x351a87=y(_0x2696a4);return _0x351a87===null?_0x30848b:_0x30848b['isEmpty']()&&_0x351a87!=='.priority'?this:(f(_0x351a87!=='.priority'||Ce(_0x2696a4)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x351a87,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2696a4),_0x30848b)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x12ffe9,_0x1de784){return!0x1;}['val'](_0x42587b){return _0x42587b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xa42694='';this['priorityNode_']['isEmpty']()||(_0xa42694+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3b88b1=typeof this['value_'];_0xa42694+=_0x3b88b1+':',_0x3b88b1==='number'?_0xa42694+=ao(this['value_']):_0xa42694+=this['value_'],this['lazyHash_']=ro(_0xa42694);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x53c1c7){return _0x53c1c7===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x53c1c7 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x53c1c7['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x53c1c7));}['compareToLeafNode_'](_0x6a5f5b){const _0x126775=typeof _0x6a5f5b['value_'],_0x4a0435=typeof this['value_'],_0x1e79ff=D['VALUE_TYPE_ORDER']['indexOf'](_0x126775),_0x142a7d=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a0435);return f(_0x1e79ff>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x126775),f(_0x142a7d>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a0435),_0x1e79ff===_0x142a7d?_0x4a0435==='object'?0x0:this['value_']<_0x6a5f5b['value_']?-0x1:this['value_']===_0x6a5f5b['value_']?0x0:0x1:_0x142a7d-_0x1e79ff;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xf3bae8){if(_0xf3bae8===this)return!0x0;if(_0xf3bae8['isLeafNode']()){const _0x776e9c=_0xf3bae8;return this['value_']===_0x776e9c['value_']&&this['priorityNode_']['equals'](_0x776e9c['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5a338b){Oo=_0x5a338b;}function Wh(_0x580e4c){Do=_0x580e4c;}class Bh extends Fn{['compare'](_0x1eb50c,_0x2fc88e){const _0x310fef=_0x1eb50c['node']['getPriority'](),_0x48358f=_0x2fc88e['node']['getPriority'](),_0x8a052c=_0x310fef['compareTo'](_0x48358f);return _0x8a052c===0x0?qe(_0x1eb50c['name'],_0x2fc88e['name']):_0x8a052c;}['isDefinedOn'](_0x4c92a9){return!_0x4c92a9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x251ae1,_0x3ba8d9){return!_0x251ae1['getPriority']()['equals'](_0x3ba8d9['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x233f3f,_0xed4ae0){const _0x21b4fb=Oo(_0x233f3f);return new E(_0xed4ae0,new D('[PRIORITY-POST]',_0x21b4fb));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0xc1653b){const _0x38333c=_0x13ea35=>parseInt(Math['log'](_0x13ea35)/Vh,0xa),_0x48f71a=_0x365b48=>parseInt(Array(_0x365b48+0x1)['join']('1'),0x2);this['count']=_0x38333c(_0xc1653b+0x1),this['current_']=this['count']-0x1;const _0x497a5d=_0x48f71a(this['count']);this['bits_']=_0xc1653b+0x1&_0x497a5d;}['nextBitIsOne'](){const _0x4f81e2=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4f81e2;}}const yn=function(_0x42c3a5,_0x250a35,_0x487949,_0x4064f6){_0x42c3a5['sort'](_0x250a35);const _0x315cdc=function(_0x24f85e,_0x1f4d2d){const _0x34ab76=_0x1f4d2d-_0x24f85e;let _0x1791c7,_0x559a3d;if(_0x34ab76===0x0)return null;if(_0x34ab76===0x1)return _0x1791c7=_0x42c3a5[_0x24f85e],_0x559a3d=_0x487949?_0x487949(_0x1791c7):_0x1791c7,new M(_0x559a3d,_0x1791c7['node'],M['BLACK'],null,null);{const _0x16bf16=parseInt(_0x34ab76/0x2,0xa)+_0x24f85e,_0x2cc487=_0x315cdc(_0x24f85e,_0x16bf16),_0x5f0dfe=_0x315cdc(_0x16bf16+0x1,_0x1f4d2d);return _0x1791c7=_0x42c3a5[_0x16bf16],_0x559a3d=_0x487949?_0x487949(_0x1791c7):_0x1791c7,new M(_0x559a3d,_0x1791c7['node'],M['BLACK'],_0x2cc487,_0x5f0dfe);}},_0x45473d=function(_0xedf67c){let _0x455039=null,_0x42ae7a=null,_0x36169=_0x42c3a5['length'];const _0x2f48b4=function(_0x21f5e2,_0x2df022){const _0x3a5090=_0x36169-_0x21f5e2,_0x3971fe=_0x36169;_0x36169-=_0x21f5e2;const _0x44e46e=_0x315cdc(_0x3a5090+0x1,_0x3971fe),_0x462e82=_0x42c3a5[_0x3a5090],_0x49fa1a=_0x487949?_0x487949(_0x462e82):_0x462e82;_0x3ecf90(new M(_0x49fa1a,_0x462e82['node'],_0x2df022,null,_0x44e46e));},_0x3ecf90=function(_0x19a166){_0x455039?(_0x455039['left']=_0x19a166,_0x455039=_0x19a166):(_0x42ae7a=_0x19a166,_0x455039=_0x19a166);};for(let _0x9114f7=0x0;_0x9114f7<_0xedf67c['count'];++_0x9114f7){const _0x3de465=_0xedf67c['nextBitIsOne'](),_0x43e9b4=Math['pow'](0x2,_0xedf67c['count']-(_0x9114f7+0x1));_0x3de465?_0x2f48b4(_0x43e9b4,M['BLACK']):(_0x2f48b4(_0x43e9b4,M['BLACK']),_0x2f48b4(_0x43e9b4,M['RED']));}return _0x42ae7a;},_0x578039=new Hh(_0x42c3a5['length']),_0x52a1bf=_0x45473d(_0x578039);return new B(_0x4064f6||_0x250a35,_0x52a1bf);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x586e8e,_0x2873c9){this['indexes_']=_0x586e8e,this['indexSet_']=_0x2873c9;}['get'](_0x27786e){const _0xe5c4e5=Le(this['indexes_'],_0x27786e);if(!_0xe5c4e5)throw new Error('No\x20index\x20defined\x20for\x20'+_0x27786e);return _0xe5c4e5 instanceof B?_0xe5c4e5:null;}['hasIndex'](_0x15d575){return Q(this['indexSet_'],_0x15d575['toString']());}['addIndex'](_0x1d6694,_0x14c8fe){f(_0x1d6694!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3e4be8=[];let _0x5b535f=!0x1;const _0x3ae9ad=_0x14c8fe['getIterator'](E['Wrap']);let _0x4e9f85=_0x3ae9ad['getNext']();for(;_0x4e9f85;)_0x5b535f=_0x5b535f||_0x1d6694['isDefinedOn'](_0x4e9f85['node']),_0x3e4be8['push'](_0x4e9f85),_0x4e9f85=_0x3ae9ad['getNext']();let _0x4e35ee;_0x5b535f?_0x4e35ee=yn(_0x3e4be8,_0x1d6694['getCompare']()):_0x4e35ee=Qe;const _0x3d5566=_0x1d6694['toString'](),_0x5ed619={...this['indexSet_']};_0x5ed619[_0x3d5566]=_0x1d6694;const _0x2ff325={...this['indexes_']};return _0x2ff325[_0x3d5566]=_0x4e35ee,new te(_0x2ff325,_0x5ed619);}['addToIndexes'](_0x29cab2,_0xf48e4f){const _0x305085=_n(this['indexes_'],(_0x1566f4,_0x294ea1)=>{const _0x2d610f=Le(this['indexSet_'],_0x294ea1);if(f(_0x2d610f,'Missing\x20index\x20implementation\x20for\x20'+_0x294ea1),_0x1566f4===Qe){if(_0x2d610f['isDefinedOn'](_0x29cab2['node'])){const _0x549ef5=[],_0x82832b=_0xf48e4f['getIterator'](E['Wrap']);let _0x449e25=_0x82832b['getNext']();for(;_0x449e25;)_0x449e25['name']!==_0x29cab2['name']&&_0x549ef5['push'](_0x449e25),_0x449e25=_0x82832b['getNext']();return _0x549ef5['push'](_0x29cab2),yn(_0x549ef5,_0x2d610f['getCompare']());}else return Qe;}else{const _0x485c8f=_0xf48e4f['get'](_0x29cab2['name']);let _0x18ed22=_0x1566f4;return _0x485c8f&&(_0x18ed22=_0x18ed22['remove'](new E(_0x29cab2['name'],_0x485c8f))),_0x18ed22['insert'](_0x29cab2,_0x29cab2['node']);}});return new te(_0x305085,this['indexSet_']);}['removeFromIndexes'](_0x167973,_0x4968e2){const _0x2ea0c3=_n(this['indexes_'],_0x59ecc3=>{if(_0x59ecc3===Qe)return _0x59ecc3;{const _0x5af20f=_0x4968e2['get'](_0x167973['name']);return _0x5af20f?_0x59ecc3['remove'](new E(_0x167973['name'],_0x5af20f)):_0x59ecc3;}});return new te(_0x2ea0c3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x9efa98,_0x274567,_0x1338fe){this['children_']=_0x9efa98,this['priorityNode_']=_0x274567,this['indexMap_']=_0x1338fe,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x37ba7d){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x37ba7d,this['indexMap_']);}['getImmediateChild'](_0x573750){if(_0x573750==='.priority')return this['getPriority']();{const _0x3210ac=this['children_']['get'](_0x573750);return _0x3210ac===null?It:_0x3210ac;}}['getChild'](_0x459b2e){const _0x286446=y(_0x459b2e);return _0x286446===null?this:this['getImmediateChild'](_0x286446)['getChild'](S(_0x459b2e));}['hasChild'](_0x5a1658){return this['children_']['get'](_0x5a1658)!==null;}['updateImmediateChild'](_0x3d83a6,_0x12f2bd){if(f(_0x12f2bd,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3d83a6==='.priority')return this['updatePriority'](_0x12f2bd);{const _0x2e8f4f=new E(_0x3d83a6,_0x12f2bd);let _0x4d3b80,_0x14cd56;_0x12f2bd['isEmpty']()?(_0x4d3b80=this['children_']['remove'](_0x3d83a6),_0x14cd56=this['indexMap_']['removeFromIndexes'](_0x2e8f4f,this['children_'])):(_0x4d3b80=this['children_']['insert'](_0x3d83a6,_0x12f2bd),_0x14cd56=this['indexMap_']['addToIndexes'](_0x2e8f4f,this['children_']));const _0x522ec7=_0x4d3b80['isEmpty']()?It:this['priorityNode_'];return new g(_0x4d3b80,_0x522ec7,_0x14cd56);}}['updateChild'](_0x2eae7f,_0x3401ee){const _0x127848=y(_0x2eae7f);if(_0x127848===null)return _0x3401ee;{f(y(_0x2eae7f)!=='.priority'||Ce(_0x2eae7f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2456b1=this['getImmediateChild'](_0x127848)['updateChild'](S(_0x2eae7f),_0x3401ee);return this['updateImmediateChild'](_0x127848,_0x2456b1);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x47779a){if(this['isEmpty']())return null;const _0x53f627={};let _0x15be44=0x0,_0x1dc119=0x0,_0x42d31a=!0x0;if(this['forEachChild'](R,(_0x58ae69,_0x5af725)=>{_0x53f627[_0x58ae69]=_0x5af725['val'](_0x47779a),_0x15be44++,_0x42d31a&&g['INTEGER_REGEXP_']['test'](_0x58ae69)?_0x1dc119=Math['max'](_0x1dc119,Number(_0x58ae69)):_0x42d31a=!0x1;}),!_0x47779a&&_0x42d31a&&_0x1dc119<0x2*_0x15be44){const _0x2d4c50=[];for(const _0x5e919a in _0x53f627)_0x2d4c50[_0x5e919a]=_0x53f627[_0x5e919a];return _0x2d4c50;}else return _0x47779a&&!this['getPriority']()['isEmpty']()&&(_0x53f627['.priority']=this['getPriority']()['val']()),_0x53f627;}['hash'](){if(this['lazyHash_']===null){let _0x4a6e2e='';this['getPriority']()['isEmpty']()||(_0x4a6e2e+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x12fae0,_0x47b582)=>{const _0x234613=_0x47b582['hash']();_0x234613!==''&&(_0x4a6e2e+=':'+_0x12fae0+':'+_0x234613);}),this['lazyHash_']=_0x4a6e2e===''?'':ro(_0x4a6e2e);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3fd4f2,_0x4b27e3,_0x5510be){const _0x2d1b1e=this['resolveIndex_'](_0x5510be);if(_0x2d1b1e){const _0x4f8bfb=_0x2d1b1e['getPredecessorKey'](new E(_0x3fd4f2,_0x4b27e3));return _0x4f8bfb?_0x4f8bfb['name']:null;}else return this['children_']['getPredecessorKey'](_0x3fd4f2);}['getFirstChildName'](_0x3e3fc4){const _0x5d7be4=this['resolveIndex_'](_0x3e3fc4);if(_0x5d7be4){const _0x15aa0b=_0x5d7be4['minKey']();return _0x15aa0b&&_0x15aa0b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3f3c0e){const _0x273aff=this['getFirstChildName'](_0x3f3c0e);return _0x273aff?new E(_0x273aff,this['children_']['get'](_0x273aff)):null;}['getLastChildName'](_0x4322f2){const _0x2002b6=this['resolveIndex_'](_0x4322f2);if(_0x2002b6){const _0x425196=_0x2002b6['maxKey']();return _0x425196&&_0x425196['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2c87e2){const _0x2661b1=this['getLastChildName'](_0x2c87e2);return _0x2661b1?new E(_0x2661b1,this['children_']['get'](_0x2661b1)):null;}['forEachChild'](_0x212bcc,_0x22177e){const _0x1dd602=this['resolveIndex_'](_0x212bcc);return _0x1dd602?_0x1dd602['inorderTraversal'](_0xdf514c=>_0x22177e(_0xdf514c['name'],_0xdf514c['node'])):this['children_']['inorderTraversal'](_0x22177e);}['getIterator'](_0x3c6aa9){return this['getIteratorFrom'](_0x3c6aa9['minPost'](),_0x3c6aa9);}['getIteratorFrom'](_0x4410f1,_0x2499f5){const _0x1e9cf8=this['resolveIndex_'](_0x2499f5);if(_0x1e9cf8)return _0x1e9cf8['getIteratorFrom'](_0x4410f1,_0xfbe80d=>_0xfbe80d);{const _0x5ef2d0=this['children_']['getIteratorFrom'](_0x4410f1['name'],E['Wrap']);let _0x561dfb=_0x5ef2d0['peek']();for(;_0x561dfb!=null&&_0x2499f5['compare'](_0x561dfb,_0x4410f1)<0x0;)_0x5ef2d0['getNext'](),_0x561dfb=_0x5ef2d0['peek']();return _0x5ef2d0;}}['getReverseIterator'](_0x53168a){return this['getReverseIteratorFrom'](_0x53168a['maxPost'](),_0x53168a);}['getReverseIteratorFrom'](_0xd01f3b,_0x32020d){const _0x5452ff=this['resolveIndex_'](_0x32020d);if(_0x5452ff)return _0x5452ff['getReverseIteratorFrom'](_0xd01f3b,_0x578233=>_0x578233);{const _0x51b6d5=this['children_']['getReverseIteratorFrom'](_0xd01f3b['name'],E['Wrap']);let _0x296489=_0x51b6d5['peek']();for(;_0x296489!=null&&_0x32020d['compare'](_0x296489,_0xd01f3b)>0x0;)_0x51b6d5['getNext'](),_0x296489=_0x51b6d5['peek']();return _0x51b6d5;}}['compareTo'](_0x2e9ac2){return this['isEmpty']()?_0x2e9ac2['isEmpty']()?0x0:-0x1:_0x2e9ac2['isLeafNode']()||_0x2e9ac2['isEmpty']()?0x1:_0x2e9ac2===Kt?-0x1:0x0;}['withIndex'](_0x10cd75){if(_0x10cd75===ve||this['indexMap_']['hasIndex'](_0x10cd75))return this;{const _0xdc8b44=this['indexMap_']['addIndex'](_0x10cd75,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xdc8b44);}}['isIndexed'](_0x5d0bcd){return _0x5d0bcd===ve||this['indexMap_']['hasIndex'](_0x5d0bcd);}['equals'](_0x3d4cd0){if(_0x3d4cd0===this)return!0x0;if(_0x3d4cd0['isLeafNode']())return!0x1;{const _0x461994=_0x3d4cd0;if(this['getPriority']()['equals'](_0x461994['getPriority']())){if(this['children_']['count']()===_0x461994['children_']['count']()){const _0x2fc06c=this['getIterator'](R),_0x10b8eb=_0x461994['getIterator'](R);let _0x39ea6b=_0x2fc06c['getNext'](),_0x4b50de=_0x10b8eb['getNext']();for(;_0x39ea6b&&_0x4b50de;){if(_0x39ea6b['name']!==_0x4b50de['name']||!_0x39ea6b['node']['equals'](_0x4b50de['node']))return!0x1;_0x39ea6b=_0x2fc06c['getNext'](),_0x4b50de=_0x10b8eb['getNext']();}return _0x39ea6b===null&&_0x4b50de===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x301484){return _0x301484===ve?null:this['indexMap_']['get'](_0x301484['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3b85fc){return _0x3b85fc===this?0x0:0x1;}['equals'](_0x510bb7){return _0x510bb7===this;}['getPriority'](){return this;}['getImmediateChild'](_0x56ef3c){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xffcdbb,_0x1989f4=null){if(_0xffcdbb===null)return g['EMPTY_NODE'];if(typeof _0xffcdbb=='object'&&'.priority'in _0xffcdbb&&(_0x1989f4=_0xffcdbb['.priority']),f(_0x1989f4===null||typeof _0x1989f4=='string'||typeof _0x1989f4=='number'||typeof _0x1989f4=='object'&&'.sv'in _0x1989f4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1989f4),typeof _0xffcdbb=='object'&&'.value'in _0xffcdbb&&_0xffcdbb['.value']!==null&&(_0xffcdbb=_0xffcdbb['.value']),typeof _0xffcdbb!='object'||'.sv'in _0xffcdbb){const _0x510162=_0xffcdbb;return new D(_0x510162,A(_0x1989f4));}if(!(_0xffcdbb instanceof Array)&&Gh){const _0x4684f5=[];let _0x2ca03d=!0x1;if(x(_0xffcdbb,(_0x420626,_0x224f75)=>{if(_0x420626['substring'](0x0,0x1)!=='.'){const _0x217481=A(_0x224f75);_0x217481['isEmpty']()||(_0x2ca03d=_0x2ca03d||!_0x217481['getPriority']()['isEmpty'](),_0x4684f5['push'](new E(_0x420626,_0x217481)));}}),_0x4684f5['length']===0x0)return g['EMPTY_NODE'];const _0x57bbb0=yn(_0x4684f5,xh,_0x386140=>_0x386140['name'],Qi);if(_0x2ca03d){const _0x3b2913=yn(_0x4684f5,R['getCompare']());return new g(_0x57bbb0,A(_0x1989f4),new te({'.priority':_0x3b2913},{'.priority':R}));}else return new g(_0x57bbb0,A(_0x1989f4),te['Default']);}else{let _0xd65030=g['EMPTY_NODE'];return x(_0xffcdbb,(_0x3627f4,_0x4da757)=>{if(Q(_0xffcdbb,_0x3627f4)&&_0x3627f4['substring'](0x0,0x1)!=='.'){const _0x48c05b=A(_0x4da757);(_0x48c05b['isLeafNode']()||!_0x48c05b['isEmpty']())&&(_0xd65030=_0xd65030['updateImmediateChild'](_0x3627f4,_0x48c05b));}}),_0xd65030['updatePriority'](A(_0x1989f4));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x49fe45){super(),this['indexPath_']=_0x49fe45,f(!v(_0x49fe45)&&y(_0x49fe45)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x17bdd0){return _0x17bdd0['getChild'](this['indexPath_']);}['isDefinedOn'](_0x7ee2dc){return!_0x7ee2dc['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3f0269,_0xf96cab){const _0x37e4c8=this['extractChild'](_0x3f0269['node']),_0x85bbe2=this['extractChild'](_0xf96cab['node']),_0x2cdb36=_0x37e4c8['compareTo'](_0x85bbe2);return _0x2cdb36===0x0?qe(_0x3f0269['name'],_0xf96cab['name']):_0x2cdb36;}['makePost'](_0x548785,_0x471df9){const _0x14ba3d=A(_0x548785),_0x4c5ecc=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x14ba3d);return new E(_0x471df9,_0x4c5ecc);}['maxPost'](){const _0xb6eeb7=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0xb6eeb7);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x25de68,_0x5777ef){const _0x5baa99=_0x25de68['node']['compareTo'](_0x5777ef['node']);return _0x5baa99===0x0?qe(_0x25de68['name'],_0x5777ef['name']):_0x5baa99;}['isDefinedOn'](_0x3a59c3){return!0x0;}['indexedValueChanged'](_0x1fda64,_0xce7ce8){return!_0x1fda64['equals'](_0xce7ce8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x9ee759,_0x282f16){const _0x236ca2=A(_0x9ee759);return new E(_0x282f16,_0x236ca2);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x5e171c){return{'type':'value','snapshotNode':_0x5e171c};}function rt(_0x425cdd,_0x15c2a4){return{'type':'child_added','snapshotNode':_0x15c2a4,'childName':_0x425cdd};}function Lt(_0x58f111,_0x3cfbd4){return{'type':'child_removed','snapshotNode':_0x3cfbd4,'childName':_0x58f111};}function xt(_0x577647,_0x3d99a2,_0x5269b4){return{'type':'child_changed','snapshotNode':_0x3d99a2,'childName':_0x577647,'oldSnap':_0x5269b4};}function zh(_0x53fe63,_0x4b325e){return{'type':'child_moved','snapshotNode':_0x4b325e,'childName':_0x53fe63};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x53bb8b){this['index_']=_0x53bb8b;}['updateChild'](_0x4e8e7f,_0x22109f,_0x3ac2ac,_0x9bf585,_0xa092bd,_0x14999f){f(_0x4e8e7f['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x5b9225=_0x4e8e7f['getImmediateChild'](_0x22109f);return _0x5b9225['getChild'](_0x9bf585)['equals'](_0x3ac2ac['getChild'](_0x9bf585))&&_0x5b9225['isEmpty']()===_0x3ac2ac['isEmpty']()||(_0x14999f!=null&&(_0x3ac2ac['isEmpty']()?_0x4e8e7f['hasChild'](_0x22109f)?_0x14999f['trackChildChange'](Lt(_0x22109f,_0x5b9225)):f(_0x4e8e7f['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x5b9225['isEmpty']()?_0x14999f['trackChildChange'](rt(_0x22109f,_0x3ac2ac)):_0x14999f['trackChildChange'](xt(_0x22109f,_0x3ac2ac,_0x5b9225))),_0x4e8e7f['isLeafNode']()&&_0x3ac2ac['isEmpty']())?_0x4e8e7f:_0x4e8e7f['updateImmediateChild'](_0x22109f,_0x3ac2ac)['withIndex'](this['index_']);}['updateFullNode'](_0x568d46,_0x418637,_0x124eaf){return _0x124eaf!=null&&(_0x568d46['isLeafNode']()||_0x568d46['forEachChild'](R,(_0x4110b4,_0x100062)=>{_0x418637['hasChild'](_0x4110b4)||_0x124eaf['trackChildChange'](Lt(_0x4110b4,_0x100062));}),_0x418637['isLeafNode']()||_0x418637['forEachChild'](R,(_0x38b5af,_0x5139d2)=>{if(_0x568d46['hasChild'](_0x38b5af)){const _0x2e9362=_0x568d46['getImmediateChild'](_0x38b5af);_0x2e9362['equals'](_0x5139d2)||_0x124eaf['trackChildChange'](xt(_0x38b5af,_0x5139d2,_0x2e9362));}else _0x124eaf['trackChildChange'](rt(_0x38b5af,_0x5139d2));})),_0x418637['withIndex'](this['index_']);}['updatePriority'](_0x31f1af,_0x5d31f2){return _0x31f1af['isEmpty']()?g['EMPTY_NODE']:_0x31f1af['updatePriority'](_0x5d31f2);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x5a40ec){this['indexedFilter_']=new Xi(_0x5a40ec['getIndex']()),this['index_']=_0x5a40ec['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x5a40ec),this['endPost_']=Ft['getEndPost_'](_0x5a40ec),this['startIsInclusive_']=!_0x5a40ec['startAfterSet_'],this['endIsInclusive_']=!_0x5a40ec['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x457dc0){const _0x57e7d0=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x457dc0)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x457dc0)<0x0,_0x33fa1a=this['endIsInclusive_']?this['index_']['compare'](_0x457dc0,this['getEndPost']())<=0x0:this['index_']['compare'](_0x457dc0,this['getEndPost']())<0x0;return _0x57e7d0&&_0x33fa1a;}['updateChild'](_0x41a4f7,_0xc89507,_0x549b1d,_0x4e20af,_0x56f24c,_0x17f9dc){return this['matches'](new E(_0xc89507,_0x549b1d))||(_0x549b1d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x41a4f7,_0xc89507,_0x549b1d,_0x4e20af,_0x56f24c,_0x17f9dc);}['updateFullNode'](_0x4731ec,_0x4627ca,_0x49ea49){_0x4627ca['isLeafNode']()&&(_0x4627ca=g['EMPTY_NODE']);let _0x3013e5=_0x4627ca['withIndex'](this['index_']);_0x3013e5=_0x3013e5['updatePriority'](g['EMPTY_NODE']);const _0x13f86a=this;return _0x4627ca['forEachChild'](R,(_0x7844,_0x55656f)=>{_0x13f86a['matches'](new E(_0x7844,_0x55656f))||(_0x3013e5=_0x3013e5['updateImmediateChild'](_0x7844,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4731ec,_0x3013e5,_0x49ea49);}['updatePriority'](_0x3ae693,_0x36a80c){return _0x3ae693;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x25306c){if(_0x25306c['hasStart']()){const _0x4f902e=_0x25306c['getIndexStartName']();return _0x25306c['getIndex']()['makePost'](_0x25306c['getIndexStartValue'](),_0x4f902e);}else return _0x25306c['getIndex']()['minPost']();}static['getEndPost_'](_0x3726dc){if(_0x3726dc['hasEnd']()){const _0x2bc7a9=_0x3726dc['getIndexEndName']();return _0x3726dc['getIndex']()['makePost'](_0x3726dc['getIndexEndValue'](),_0x2bc7a9);}else return _0x3726dc['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2f1fd1){this['withinDirectionalStart']=_0x7e772e=>this['reverse_']?this['withinEndPost'](_0x7e772e):this['withinStartPost'](_0x7e772e),this['withinDirectionalEnd']=_0x150f65=>this['reverse_']?this['withinStartPost'](_0x150f65):this['withinEndPost'](_0x150f65),this['withinStartPost']=_0x124b33=>{const _0xaebe71=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x124b33);return this['startIsInclusive_']?_0xaebe71<=0x0:_0xaebe71<0x0;},this['withinEndPost']=_0x5a3f95=>{const _0x176766=this['index_']['compare'](_0x5a3f95,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x176766<=0x0:_0x176766<0x0;},this['rangedFilter_']=new Ft(_0x2f1fd1),this['index_']=_0x2f1fd1['getIndex'](),this['limit_']=_0x2f1fd1['getLimit'](),this['reverse_']=!_0x2f1fd1['isViewFromLeft'](),this['startIsInclusive_']=!_0x2f1fd1['startAfterSet_'],this['endIsInclusive_']=!_0x2f1fd1['endBeforeSet_'];}['updateChild'](_0x160278,_0x4e1911,_0x1a0a5e,_0x5b6faf,_0x67591e,_0x4c36f9){return this['rangedFilter_']['matches'](new E(_0x4e1911,_0x1a0a5e))||(_0x1a0a5e=g['EMPTY_NODE']),_0x160278['getImmediateChild'](_0x4e1911)['equals'](_0x1a0a5e)?_0x160278:_0x160278['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x160278,_0x4e1911,_0x1a0a5e,_0x5b6faf,_0x67591e,_0x4c36f9):this['fullLimitUpdateChild_'](_0x160278,_0x4e1911,_0x1a0a5e,_0x67591e,_0x4c36f9);}['updateFullNode'](_0x242b59,_0x390ae1,_0x42d335){let _0x4f5dd4;if(_0x390ae1['isLeafNode']()||_0x390ae1['isEmpty']())_0x4f5dd4=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x390ae1['numChildren']()&&_0x390ae1['isIndexed'](this['index_'])){_0x4f5dd4=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x2752aa;this['reverse_']?_0x2752aa=_0x390ae1['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x2752aa=_0x390ae1['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x17dfa7=0x0;for(;_0x2752aa['hasNext']()&&_0x17dfa7<this['limit_'];){const _0x27bab9=_0x2752aa['getNext']();if(this['withinDirectionalStart'](_0x27bab9)){if(this['withinDirectionalEnd'](_0x27bab9))_0x4f5dd4=_0x4f5dd4['updateImmediateChild'](_0x27bab9['name'],_0x27bab9['node']),_0x17dfa7++;else break;}else continue;}}else{_0x4f5dd4=_0x390ae1['withIndex'](this['index_']),_0x4f5dd4=_0x4f5dd4['updatePriority'](g['EMPTY_NODE']);let _0x3820a3;this['reverse_']?_0x3820a3=_0x4f5dd4['getReverseIterator'](this['index_']):_0x3820a3=_0x4f5dd4['getIterator'](this['index_']);let _0x26cdbf=0x0;for(;_0x3820a3['hasNext']();){const _0x1edeed=_0x3820a3['getNext']();_0x26cdbf<this['limit_']&&this['withinDirectionalStart'](_0x1edeed)&&this['withinDirectionalEnd'](_0x1edeed)?_0x26cdbf++:_0x4f5dd4=_0x4f5dd4['updateImmediateChild'](_0x1edeed['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x242b59,_0x4f5dd4,_0x42d335);}['updatePriority'](_0x58c43b,_0x4bc324){return _0x58c43b;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2cc971,_0x1dc76a,_0x30f07e,_0x39421e,_0xf21f3d){let _0x22869d;if(this['reverse_']){const _0x2a86a1=this['index_']['getCompare']();_0x22869d=(_0x880566,_0x2e6244)=>_0x2a86a1(_0x2e6244,_0x880566);}else _0x22869d=this['index_']['getCompare']();const _0x40eca3=_0x2cc971;f(_0x40eca3['numChildren']()===this['limit_'],'');const _0xe3dc94=new E(_0x1dc76a,_0x30f07e),_0x1ca753=this['reverse_']?_0x40eca3['getFirstChild'](this['index_']):_0x40eca3['getLastChild'](this['index_']),_0x4a698d=this['rangedFilter_']['matches'](_0xe3dc94);if(_0x40eca3['hasChild'](_0x1dc76a)){const _0x4b3873=_0x40eca3['getImmediateChild'](_0x1dc76a);let _0x4436fd=_0x39421e['getChildAfterChild'](this['index_'],_0x1ca753,this['reverse_']);for(;_0x4436fd!=null&&(_0x4436fd['name']===_0x1dc76a||_0x40eca3['hasChild'](_0x4436fd['name']));)_0x4436fd=_0x39421e['getChildAfterChild'](this['index_'],_0x4436fd,this['reverse_']);const _0x233650=_0x4436fd==null?0x1:_0x22869d(_0x4436fd,_0xe3dc94);if(_0x4a698d&&!_0x30f07e['isEmpty']()&&_0x233650>=0x0)return _0xf21f3d!=null&&_0xf21f3d['trackChildChange'](xt(_0x1dc76a,_0x30f07e,_0x4b3873)),_0x40eca3['updateImmediateChild'](_0x1dc76a,_0x30f07e);{_0xf21f3d!=null&&_0xf21f3d['trackChildChange'](Lt(_0x1dc76a,_0x4b3873));const _0x3f84d0=_0x40eca3['updateImmediateChild'](_0x1dc76a,g['EMPTY_NODE']);return _0x4436fd!=null&&this['rangedFilter_']['matches'](_0x4436fd)?(_0xf21f3d!=null&&_0xf21f3d['trackChildChange'](rt(_0x4436fd['name'],_0x4436fd['node'])),_0x3f84d0['updateImmediateChild'](_0x4436fd['name'],_0x4436fd['node'])):_0x3f84d0;}}else return _0x30f07e['isEmpty']()?_0x2cc971:_0x4a698d&&_0x22869d(_0x1ca753,_0xe3dc94)>=0x0?(_0xf21f3d!=null&&(_0xf21f3d['trackChildChange'](Lt(_0x1ca753['name'],_0x1ca753['node'])),_0xf21f3d['trackChildChange'](rt(_0x1dc76a,_0x30f07e))),_0x40eca3['updateImmediateChild'](_0x1dc76a,_0x30f07e)['updateImmediateChild'](_0x1ca753['name'],g['EMPTY_NODE'])):_0x2cc971;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1daa53=new Zi();return _0x1daa53['limitSet_']=this['limitSet_'],_0x1daa53['limit_']=this['limit_'],_0x1daa53['startSet_']=this['startSet_'],_0x1daa53['startAfterSet_']=this['startAfterSet_'],_0x1daa53['indexStartValue_']=this['indexStartValue_'],_0x1daa53['startNameSet_']=this['startNameSet_'],_0x1daa53['indexStartName_']=this['indexStartName_'],_0x1daa53['endSet_']=this['endSet_'],_0x1daa53['endBeforeSet_']=this['endBeforeSet_'],_0x1daa53['indexEndValue_']=this['indexEndValue_'],_0x1daa53['endNameSet_']=this['endNameSet_'],_0x1daa53['indexEndName_']=this['indexEndName_'],_0x1daa53['index_']=this['index_'],_0x1daa53['viewFrom_']=this['viewFrom_'],_0x1daa53;}}function Kh(_0x49efd4){return _0x49efd4['loadsAllData']()?new Xi(_0x49efd4['getIndex']()):_0x49efd4['hasLimit']()?new jh(_0x49efd4):new Ft(_0x49efd4);}function Yh(_0x4f223c,_0x31033a){const _0x1f617c=_0x4f223c['copy']();return _0x1f617c['limitSet_']=!0x0,_0x1f617c['limit_']=_0x31033a,_0x1f617c['viewFrom_']='l',_0x1f617c;}function Qh(_0x537bf1,_0x571488,_0x1d0ce0){const _0x2c0188=_0x537bf1['copy']();return _0x2c0188['startSet_']=!0x0,_0x571488===void 0x0&&(_0x571488=null),_0x2c0188['indexStartValue_']=_0x571488,_0x1d0ce0!=null?(_0x2c0188['startNameSet_']=!0x0,_0x2c0188['indexStartName_']=_0x1d0ce0):(_0x2c0188['startNameSet_']=!0x1,_0x2c0188['indexStartName_']=''),_0x2c0188;}function Jh(_0xdca57e,_0x5d673a,_0xa45df2){const _0x3ffba0=_0xdca57e['copy']();return _0x3ffba0['endSet_']=!0x0,_0x5d673a===void 0x0&&(_0x5d673a=null),_0x3ffba0['indexEndValue_']=_0x5d673a,_0xa45df2!==void 0x0?(_0x3ffba0['endNameSet_']=!0x0,_0x3ffba0['indexEndName_']=_0xa45df2):(_0x3ffba0['endNameSet_']=!0x1,_0x3ffba0['indexEndName_']=''),_0x3ffba0;}function xo(_0x3e9111,_0xaab75b){const _0x4969cf=_0x3e9111['copy']();return _0x4969cf['index_']=_0xaab75b,_0x4969cf;}function ir(_0x100c40){const _0x41263b={};if(_0x100c40['isDefault']())return _0x41263b;let _0x276c9d;if(_0x100c40['index_']===R?_0x276c9d='$priority':_0x100c40['index_']===Mo?_0x276c9d='$value':_0x100c40['index_']===ve?_0x276c9d='$key':(f(_0x100c40['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x276c9d=_0x100c40['index_']['toString']()),_0x41263b['orderBy']=O(_0x276c9d),_0x100c40['startSet_']){const _0x35f8b1=_0x100c40['startAfterSet_']?'startAfter':'startAt';_0x41263b[_0x35f8b1]=O(_0x100c40['indexStartValue_']),_0x100c40['startNameSet_']&&(_0x41263b[_0x35f8b1]+=','+O(_0x100c40['indexStartName_']));}if(_0x100c40['endSet_']){const _0x264829=_0x100c40['endBeforeSet_']?'endBefore':'endAt';_0x41263b[_0x264829]=O(_0x100c40['indexEndValue_']),_0x100c40['endNameSet_']&&(_0x41263b[_0x264829]+=','+O(_0x100c40['indexEndName_']));}return _0x100c40['limitSet_']&&(_0x100c40['isViewFromLeft']()?_0x41263b['limitToFirst']=_0x100c40['limit_']:_0x41263b['limitToLast']=_0x100c40['limit_']),_0x41263b;}function sr(_0x217066){const _0x43c091={};if(_0x217066['startSet_']&&(_0x43c091['sp']=_0x217066['indexStartValue_'],_0x217066['startNameSet_']&&(_0x43c091['sn']=_0x217066['indexStartName_']),_0x43c091['sin']=!_0x217066['startAfterSet_']),_0x217066['endSet_']&&(_0x43c091['ep']=_0x217066['indexEndValue_'],_0x217066['endNameSet_']&&(_0x43c091['en']=_0x217066['indexEndName_']),_0x43c091['ein']=!_0x217066['endBeforeSet_']),_0x217066['limitSet_']){_0x43c091['l']=_0x217066['limit_'];let _0x4bc343=_0x217066['viewFrom_'];_0x4bc343===''&&(_0x217066['isViewFromLeft']()?_0x4bc343='l':_0x4bc343='r'),_0x43c091['vf']=_0x4bc343;}return _0x217066['index_']!==R&&(_0x43c091['i']=_0x217066['index_']['toString']()),_0x43c091;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x595a25){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3c4466,_0x12aed7){return _0x12aed7!==void 0x0?'tag$'+_0x12aed7:(f(_0x3c4466['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3c4466['_path']['toString']());}constructor(_0x255b6f,_0x6da35a,_0x33f890,_0x37d81d){super(),this['repoInfo_']=_0x255b6f,this['onDataUpdate_']=_0x6da35a,this['authTokenProvider_']=_0x33f890,this['appCheckTokenProvider_']=_0x37d81d,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1857f8,_0x31c2c7,_0x437305,_0x2bfaea){const _0x1cdf9f=_0x1857f8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1cdf9f+'\x20'+_0x1857f8['_queryIdentifier']);const _0x4d1302=vn['getListenId_'](_0x1857f8,_0x437305),_0x6cce6c={};this['listens_'][_0x4d1302]=_0x6cce6c;const _0x10269e=ir(_0x1857f8['_queryParams']);this['restRequest_'](_0x1cdf9f+'.json',_0x10269e,(_0x2befd6,_0x304809)=>{let _0x26bc0c=_0x304809;if(_0x2befd6===0x194&&(_0x26bc0c=null,_0x2befd6=null),_0x2befd6===null&&this['onDataUpdate_'](_0x1cdf9f,_0x26bc0c,!0x1,_0x437305),Le(this['listens_'],_0x4d1302)===_0x6cce6c){let _0x5e449f;_0x2befd6?_0x2befd6===0x191?_0x5e449f='permission_denied':_0x5e449f='rest_error:'+_0x2befd6:_0x5e449f='ok',_0x2bfaea(_0x5e449f,null);}});}['unlisten'](_0x252b3b,_0x2efb8f){const _0x535007=vn['getListenId_'](_0x252b3b,_0x2efb8f);delete this['listens_'][_0x535007];}['get'](_0x137681){const _0x5d11c9=ir(_0x137681['_queryParams']),_0x5d8144=_0x137681['_path']['toString'](),_0x331c3d=new H();return this['restRequest_'](_0x5d8144+'.json',_0x5d11c9,(_0x66179c,_0x164c11)=>{let _0x374ddd=_0x164c11;_0x66179c===0x194&&(_0x374ddd=null,_0x66179c=null),_0x66179c===null?(this['onDataUpdate_'](_0x5d8144,_0x374ddd,!0x1,null),_0x331c3d['resolve'](_0x374ddd)):_0x331c3d['reject'](new Error(_0x374ddd));}),_0x331c3d['promise'];}['refreshAuthToken'](_0xd77bed){}['restRequest_'](_0x268f2e,_0x20e2bb={},_0x239cc8){return _0x20e2bb['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0xb8d47c,_0x2eb773])=>{_0xb8d47c&&_0xb8d47c['accessToken']&&(_0x20e2bb['auth']=_0xb8d47c['accessToken']),_0x2eb773&&_0x2eb773['token']&&(_0x20e2bb['ac']=_0x2eb773['token']);const _0x1b9936=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x268f2e+'?ns='+this['repoInfo_']['namespace']+ut(_0x20e2bb);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1b9936);const _0x167b79=new XMLHttpRequest();_0x167b79['onreadystatechange']=()=>{if(_0x239cc8&&_0x167b79['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1b9936+'\x20received.\x20status:',_0x167b79['status'],'response:',_0x167b79['responseText']);let _0x38aa9b=null;if(_0x167b79['status']>=0xc8&&_0x167b79['status']<0x12c){try{_0x38aa9b=Nt(_0x167b79['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1b9936+':\x20'+_0x167b79['responseText']);}_0x239cc8(null,_0x38aa9b);}else _0x167b79['status']!==0x191&&_0x167b79['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1b9936+'\x20Status:\x20'+_0x167b79['status']),_0x239cc8(_0x167b79['status']);_0x239cc8=null;}},_0x167b79['open']('GET',_0x1b9936,!0x0),_0x167b79['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2e632d){return this['rootNode_']['getChild'](_0x2e632d);}['updateSnapshot'](_0x3acc06,_0x579f46){this['rootNode_']=this['rootNode_']['updateChild'](_0x3acc06,_0x579f46);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x57d15c,_0x3e8b1d,_0x2bec2a){if(v(_0x3e8b1d))_0x57d15c['value']=_0x2bec2a,_0x57d15c['children']['clear']();else{if(_0x57d15c['value']!==null)_0x57d15c['value']=_0x57d15c['value']['updateChild'](_0x3e8b1d,_0x2bec2a);else{const _0x32c92b=y(_0x3e8b1d);_0x57d15c['children']['has'](_0x32c92b)||_0x57d15c['children']['set'](_0x32c92b,En());const _0x44ad6e=_0x57d15c['children']['get'](_0x32c92b);_0x3e8b1d=S(_0x3e8b1d),pt(_0x44ad6e,_0x3e8b1d,_0x2bec2a);}}}function Ti(_0x1e2048,_0x4b8087){if(v(_0x4b8087))return _0x1e2048['value']=null,_0x1e2048['children']['clear'](),!0x0;if(_0x1e2048['value']!==null){if(_0x1e2048['value']['isLeafNode']())return!0x1;{const _0x157996=_0x1e2048['value'];return _0x1e2048['value']=null,_0x157996['forEachChild'](R,(_0x11967b,_0x40db90)=>{pt(_0x1e2048,new C(_0x11967b),_0x40db90);}),Ti(_0x1e2048,_0x4b8087);}}else{if(_0x1e2048['children']['size']>0x0){const _0x4a08d6=y(_0x4b8087);return _0x4b8087=S(_0x4b8087),_0x1e2048['children']['has'](_0x4a08d6)&&Ti(_0x1e2048['children']['get'](_0x4a08d6),_0x4b8087)&&_0x1e2048['children']['delete'](_0x4a08d6),_0x1e2048['children']['size']===0x0;}else return!0x0;}}function Si(_0x2bd5d8,_0xa933ac,_0x69f545){_0x2bd5d8['value']!==null?_0x69f545(_0xa933ac,_0x2bd5d8['value']):Zh(_0x2bd5d8,(_0x6e0310,_0x3ba599)=>{const _0x303893=new C(_0xa933ac['toString']()+'/'+_0x6e0310);Si(_0x3ba599,_0x303893,_0x69f545);});}function Zh(_0x8c515,_0x5bc49d){_0x8c515['children']['forEach']((_0x3c4f66,_0x1e3b6c)=>{_0x5bc49d(_0x1e3b6c,_0x3c4f66);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1cbe14){this['collection_']=_0x1cbe14,this['last_']=null;}['get'](){const _0x4cc032=this['collection_']['get'](),_0x347234={..._0x4cc032};return this['last_']&&x(this['last_'],(_0x1b0e37,_0x411e74)=>{_0x347234[_0x1b0e37]=_0x347234[_0x1b0e37]-_0x411e74;}),this['last_']=_0x4cc032,_0x347234;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x351616,_0x360f36){this['server_']=_0x360f36,this['statsToReport_']={},this['statsListener_']=new eu(_0x351616);const _0x251aba=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x251aba));}['reportStats_'](){const _0x357b3e=this['statsListener_']['get'](),_0x79c258={};let _0xe634b5=!0x1;x(_0x357b3e,(_0x23edc1,_0xd5ecd4)=>{_0xd5ecd4>0x0&&Q(this['statsToReport_'],_0x23edc1)&&(_0x79c258[_0x23edc1]=_0xd5ecd4,_0xe634b5=!0x0);}),_0xe634b5&&this['server_']['reportStats'](_0x79c258),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x421c76){_0x421c76[_0x421c76['OVERWRITE']=0x0]='OVERWRITE',_0x421c76[_0x421c76['MERGE']=0x1]='MERGE',_0x421c76[_0x421c76['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x421c76[_0x421c76['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x2f6d1a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2f6d1a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x2cc7bb,_0x8ec1a7,_0x52bb97){this['path']=_0x2cc7bb,this['affectedTree']=_0x8ec1a7,this['revert']=_0x52bb97,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x59e7c9){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x61ea33=this['affectedTree']['subtree'](new C(_0x59e7c9));return new In(w(),_0x61ea33,this['revert']);}}else return f(y(this['path'])===_0x59e7c9,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x76d9ab,_0xa6d89e){this['source']=_0x76d9ab,this['path']=_0xa6d89e,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x44c449){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x44a587,_0x2e7a54,_0x376abc){this['source']=_0x44a587,this['path']=_0x2e7a54,this['snap']=_0x376abc,this['type']=z['OVERWRITE'];}['operationForChild'](_0x11c268){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x11c268)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x52c29c,_0x37a8f2,_0x241467){this['source']=_0x52c29c,this['path']=_0x37a8f2,this['children']=_0x241467,this['type']=z['MERGE'];}['operationForChild'](_0x40b957){if(v(this['path'])){const _0x4a0b44=this['children']['subtree'](new C(_0x40b957));return _0x4a0b44['isEmpty']()?null:_0x4a0b44['value']?new Be(this['source'],w(),_0x4a0b44['value']):new ot(this['source'],w(),_0x4a0b44);}else return f(y(this['path'])===_0x40b957,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x46b7da,_0x3cc276,_0x282a46){this['node_']=_0x46b7da,this['fullyInitialized_']=_0x3cc276,this['filtered_']=_0x282a46;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x30f724){if(v(_0x30f724))return this['isFullyInitialized']()&&!this['filtered_'];const _0x124323=y(_0x30f724);return this['isCompleteForChild'](_0x124323);}['isCompleteForChild'](_0x504c34){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x504c34);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3ec186){this['query_']=_0x3ec186,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x5d16bf,_0x288fe6,_0x4ed557,_0x5dde59){const _0x372f3d=[],_0x4c4187=[];return _0x288fe6['forEach'](_0x5a21b4=>{_0x5a21b4['type']==='child_changed'&&_0x5d16bf['index_']['indexedValueChanged'](_0x5a21b4['oldSnap'],_0x5a21b4['snapshotNode'])&&_0x4c4187['push'](zh(_0x5a21b4['childName'],_0x5a21b4['snapshotNode']));}),wt(_0x5d16bf,_0x372f3d,'child_removed',_0x288fe6,_0x5dde59,_0x4ed557),wt(_0x5d16bf,_0x372f3d,'child_added',_0x288fe6,_0x5dde59,_0x4ed557),wt(_0x5d16bf,_0x372f3d,'child_moved',_0x4c4187,_0x5dde59,_0x4ed557),wt(_0x5d16bf,_0x372f3d,'child_changed',_0x288fe6,_0x5dde59,_0x4ed557),wt(_0x5d16bf,_0x372f3d,'value',_0x288fe6,_0x5dde59,_0x4ed557),_0x372f3d;}function wt(_0x33d193,_0x24a115,_0x1bbafc,_0x516ba7,_0x447aaa,_0x372d58){const _0xba81b8=_0x516ba7['filter'](_0x4b67af=>_0x4b67af['type']===_0x1bbafc);_0xba81b8['sort']((_0x3d2fb9,_0x28ca21)=>au(_0x33d193,_0x3d2fb9,_0x28ca21)),_0xba81b8['forEach'](_0x70d554=>{const _0x89587b=ou(_0x33d193,_0x70d554,_0x372d58);_0x447aaa['forEach'](_0x1f6e4b=>{_0x1f6e4b['respondsTo'](_0x70d554['type'])&&_0x24a115['push'](_0x1f6e4b['createEvent'](_0x89587b,_0x33d193['query_']));});});}function ou(_0x5948b0,_0x431dea,_0x2da4b2){return _0x431dea['type']==='value'||_0x431dea['type']==='child_removed'||(_0x431dea['prevName']=_0x2da4b2['getPredecessorChildName'](_0x431dea['childName'],_0x431dea['snapshotNode'],_0x5948b0['index_'])),_0x431dea;}function au(_0x2723fe,_0x35a7eb,_0x5eddd3){if(_0x35a7eb['childName']==null||_0x5eddd3['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x741708=new E(_0x35a7eb['childName'],_0x35a7eb['snapshotNode']),_0x36ba7c=new E(_0x5eddd3['childName'],_0x5eddd3['snapshotNode']);return _0x2723fe['index_']['compare'](_0x741708,_0x36ba7c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x23430f,_0x366479){return{'eventCache':_0x23430f,'serverCache':_0x366479};}function Rt(_0x31e412,_0x53aaba,_0x1f1be9,_0x40679b){return Un(new Te(_0x53aaba,_0x1f1be9,_0x40679b),_0x31e412['serverCache']);}function Fo(_0x3060cf,_0xd64819,_0x47e92f,_0x4c7a63){return Un(_0x3060cf['eventCache'],new Te(_0xd64819,_0x47e92f,_0x4c7a63));}function wn(_0x479b17){return _0x479b17['eventCache']['isFullyInitialized']()?_0x479b17['eventCache']['getNode']():null;}function Ve(_0x4b798b){return _0x4b798b['serverCache']['isFullyInitialized']()?_0x4b798b['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x12adff){let _0x17fb64=new b(null);return x(_0x12adff,(_0xcdf9d8,_0x5c48a9)=>{_0x17fb64=_0x17fb64['set'](new C(_0xcdf9d8),_0x5c48a9);}),_0x17fb64;}constructor(_0x2c732f,_0x41475f=cu()){this['value']=_0x2c732f,this['children']=_0x41475f;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2f835b,_0x505522){if(this['value']!=null&&_0x505522(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2f835b))return null;{const _0x25a9b8=y(_0x2f835b),_0x152770=this['children']['get'](_0x25a9b8);if(_0x152770!==null){const _0x4c5a5a=_0x152770['findRootMostMatchingPathAndValue'](S(_0x2f835b),_0x505522);return _0x4c5a5a!=null?{'path':k(new C(_0x25a9b8),_0x4c5a5a['path']),'value':_0x4c5a5a['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x55ba80){return this['findRootMostMatchingPathAndValue'](_0x55ba80,()=>!0x0);}['subtree'](_0x53f430){if(v(_0x53f430))return this;{const _0x571ba3=y(_0x53f430),_0x21587f=this['children']['get'](_0x571ba3);return _0x21587f!==null?_0x21587f['subtree'](S(_0x53f430)):new b(null);}}['set'](_0xde94a1,_0x5c162b){if(v(_0xde94a1))return new b(_0x5c162b,this['children']);{const _0x2ddea2=y(_0xde94a1),_0x522102=(this['children']['get'](_0x2ddea2)||new b(null))['set'](S(_0xde94a1),_0x5c162b),_0x7f4fe6=this['children']['insert'](_0x2ddea2,_0x522102);return new b(this['value'],_0x7f4fe6);}}['remove'](_0x230aeb){if(v(_0x230aeb))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x1ccb09=y(_0x230aeb),_0x3cf3fb=this['children']['get'](_0x1ccb09);if(_0x3cf3fb){const _0x510758=_0x3cf3fb['remove'](S(_0x230aeb));let _0x382a2c;return _0x510758['isEmpty']()?_0x382a2c=this['children']['remove'](_0x1ccb09):_0x382a2c=this['children']['insert'](_0x1ccb09,_0x510758),this['value']===null&&_0x382a2c['isEmpty']()?new b(null):new b(this['value'],_0x382a2c);}else return this;}}['get'](_0x2294f2){if(v(_0x2294f2))return this['value'];{const _0x1bde80=y(_0x2294f2),_0x2acc65=this['children']['get'](_0x1bde80);return _0x2acc65?_0x2acc65['get'](S(_0x2294f2)):null;}}['setTree'](_0xfd1880,_0x398c88){if(v(_0xfd1880))return _0x398c88;{const _0x514873=y(_0xfd1880),_0x5c72ed=(this['children']['get'](_0x514873)||new b(null))['setTree'](S(_0xfd1880),_0x398c88);let _0xfabb62;return _0x5c72ed['isEmpty']()?_0xfabb62=this['children']['remove'](_0x514873):_0xfabb62=this['children']['insert'](_0x514873,_0x5c72ed),new b(this['value'],_0xfabb62);}}['fold'](_0x4894cf){return this['fold_'](w(),_0x4894cf);}['fold_'](_0x314efa,_0x20b4cb){const _0x2119d0={};return this['children']['inorderTraversal']((_0x45412a,_0x2c4337)=>{_0x2119d0[_0x45412a]=_0x2c4337['fold_'](k(_0x314efa,_0x45412a),_0x20b4cb);}),_0x20b4cb(_0x314efa,this['value'],_0x2119d0);}['findOnPath'](_0x57b706,_0x2166f9){return this['findOnPath_'](_0x57b706,w(),_0x2166f9);}['findOnPath_'](_0x476d09,_0x8f5823,_0x5ae4b0){const _0x4a5fd1=this['value']?_0x5ae4b0(_0x8f5823,this['value']):!0x1;if(_0x4a5fd1)return _0x4a5fd1;if(v(_0x476d09))return null;{const _0x37d73c=y(_0x476d09),_0x437277=this['children']['get'](_0x37d73c);return _0x437277?_0x437277['findOnPath_'](S(_0x476d09),k(_0x8f5823,_0x37d73c),_0x5ae4b0):null;}}['foreachOnPath'](_0x478106,_0xff6011){return this['foreachOnPath_'](_0x478106,w(),_0xff6011);}['foreachOnPath_'](_0x3e3fe3,_0x2f8fad,_0x578384){if(v(_0x3e3fe3))return this;{this['value']&&_0x578384(_0x2f8fad,this['value']);const _0x226c07=y(_0x3e3fe3),_0x1093a8=this['children']['get'](_0x226c07);return _0x1093a8?_0x1093a8['foreachOnPath_'](S(_0x3e3fe3),k(_0x2f8fad,_0x226c07),_0x578384):new b(null);}}['foreach'](_0x1f956d){this['foreach_'](w(),_0x1f956d);}['foreach_'](_0x1ca1d5,_0x19660d){this['children']['inorderTraversal']((_0x206883,_0x36fe47)=>{_0x36fe47['foreach_'](k(_0x1ca1d5,_0x206883),_0x19660d);}),this['value']&&_0x19660d(_0x1ca1d5,this['value']);}['foreachChild'](_0x4c92f4){this['children']['inorderTraversal']((_0x355e5b,_0x1c9b55)=>{_0x1c9b55['value']&&_0x4c92f4(_0x355e5b,_0x1c9b55['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0xb49660){this['writeTree_']=_0xb49660;}static['empty'](){return new K(new b(null));}}function At(_0xd034a8,_0x49c699,_0x44dc69){if(v(_0x49c699))return new K(new b(_0x44dc69));{const _0x485f13=_0xd034a8['writeTree_']['findRootMostValueAndPath'](_0x49c699);if(_0x485f13!=null){const _0xf164a=_0x485f13['path'];let _0x4c4640=_0x485f13['value'];const _0x4297c1=F(_0xf164a,_0x49c699);return _0x4c4640=_0x4c4640['updateChild'](_0x4297c1,_0x44dc69),new K(_0xd034a8['writeTree_']['set'](_0xf164a,_0x4c4640));}else{const _0x30280a=new b(_0x44dc69),_0x291c91=_0xd034a8['writeTree_']['setTree'](_0x49c699,_0x30280a);return new K(_0x291c91);}}}function bi(_0x9196ab,_0x1fb22d,_0x51536e){let _0xf119f3=_0x9196ab;return x(_0x51536e,(_0x54dccb,_0x10e83e)=>{_0xf119f3=At(_0xf119f3,k(_0x1fb22d,_0x54dccb),_0x10e83e);}),_0xf119f3;}function or(_0x525291,_0xf6cccf){if(v(_0xf6cccf))return K['empty']();{const _0x2caffa=_0x525291['writeTree_']['setTree'](_0xf6cccf,new b(null));return new K(_0x2caffa);}}function Ri(_0x31dca9,_0x386cfe){return ze(_0x31dca9,_0x386cfe)!=null;}function ze(_0x5d4073,_0x4996e9){const _0x25e32d=_0x5d4073['writeTree_']['findRootMostValueAndPath'](_0x4996e9);return _0x25e32d!=null?_0x5d4073['writeTree_']['get'](_0x25e32d['path'])['getChild'](F(_0x25e32d['path'],_0x4996e9)):null;}function ar(_0x5c2fcc){const _0x38ab67=[],_0x5c9df8=_0x5c2fcc['writeTree_']['value'];return _0x5c9df8!=null?_0x5c9df8['isLeafNode']()||_0x5c9df8['forEachChild'](R,(_0x2c99b7,_0x3619d9)=>{_0x38ab67['push'](new E(_0x2c99b7,_0x3619d9));}):_0x5c2fcc['writeTree_']['children']['inorderTraversal']((_0x44896d,_0x35fb3b)=>{_0x35fb3b['value']!=null&&_0x38ab67['push'](new E(_0x44896d,_0x35fb3b['value']));}),_0x38ab67;}function Ee(_0xddf7c9,_0x1ae328){if(v(_0x1ae328))return _0xddf7c9;{const _0x2dfc57=ze(_0xddf7c9,_0x1ae328);return _0x2dfc57!=null?new K(new b(_0x2dfc57)):new K(_0xddf7c9['writeTree_']['subtree'](_0x1ae328));}}function Ai(_0xb18c68){return _0xb18c68['writeTree_']['isEmpty']();}function at(_0x45eb72,_0x5beee9){return Uo(w(),_0x45eb72['writeTree_'],_0x5beee9);}function Uo(_0x1c33a8,_0x25b1a2,_0x1dcfa8){if(_0x25b1a2['value']!=null)return _0x1dcfa8['updateChild'](_0x1c33a8,_0x25b1a2['value']);{let _0x1d6f72=null;return _0x25b1a2['children']['inorderTraversal']((_0x50f1c6,_0x34f6af)=>{_0x50f1c6==='.priority'?(f(_0x34f6af['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1d6f72=_0x34f6af['value']):_0x1dcfa8=Uo(k(_0x1c33a8,_0x50f1c6),_0x34f6af,_0x1dcfa8);}),!_0x1dcfa8['getChild'](_0x1c33a8)['isEmpty']()&&_0x1d6f72!==null&&(_0x1dcfa8=_0x1dcfa8['updateChild'](k(_0x1c33a8,'.priority'),_0x1d6f72)),_0x1dcfa8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x36a89f,_0x116946){return Ho(_0x116946,_0x36a89f);}function lu(_0x39e19b,_0x7a3573,_0x25e23a,_0x38cb18,_0x305f33){f(_0x38cb18>_0x39e19b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x305f33===void 0x0&&(_0x305f33=!0x0),_0x39e19b['allWrites']['push']({'path':_0x7a3573,'snap':_0x25e23a,'writeId':_0x38cb18,'visible':_0x305f33}),_0x305f33&&(_0x39e19b['visibleWrites']=At(_0x39e19b['visibleWrites'],_0x7a3573,_0x25e23a)),_0x39e19b['lastWriteId']=_0x38cb18;}function hu(_0x317d5b,_0x249e65,_0x2ad644,_0x5d8ba3){f(_0x5d8ba3>_0x317d5b['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x317d5b['allWrites']['push']({'path':_0x249e65,'children':_0x2ad644,'writeId':_0x5d8ba3,'visible':!0x0}),_0x317d5b['visibleWrites']=bi(_0x317d5b['visibleWrites'],_0x249e65,_0x2ad644),_0x317d5b['lastWriteId']=_0x5d8ba3;}function uu(_0x32b2bf,_0x7b6259){for(let _0x3bee83=0x0;_0x3bee83<_0x32b2bf['allWrites']['length'];_0x3bee83++){const _0x36f3d6=_0x32b2bf['allWrites'][_0x3bee83];if(_0x36f3d6['writeId']===_0x7b6259)return _0x36f3d6;}return null;}function du(_0x18d1c7,_0x31c063){const _0x36e34a=_0x18d1c7['allWrites']['findIndex'](_0x1d7535=>_0x1d7535['writeId']===_0x31c063);f(_0x36e34a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1f3402=_0x18d1c7['allWrites'][_0x36e34a];_0x18d1c7['allWrites']['splice'](_0x36e34a,0x1);let _0x28bba2=_0x1f3402['visible'],_0x3df7bd=!0x1,_0x1bd29f=_0x18d1c7['allWrites']['length']-0x1;for(;_0x28bba2&&_0x1bd29f>=0x0;){const _0x2e5a87=_0x18d1c7['allWrites'][_0x1bd29f];_0x2e5a87['visible']&&(_0x1bd29f>=_0x36e34a&&fu(_0x2e5a87,_0x1f3402['path'])?_0x28bba2=!0x1:G(_0x1f3402['path'],_0x2e5a87['path'])&&(_0x3df7bd=!0x0)),_0x1bd29f--;}if(_0x28bba2){if(_0x3df7bd)return pu(_0x18d1c7),!0x0;if(_0x1f3402['snap'])_0x18d1c7['visibleWrites']=or(_0x18d1c7['visibleWrites'],_0x1f3402['path']);else{const _0x4af436=_0x1f3402['children'];x(_0x4af436,_0x582df5=>{_0x18d1c7['visibleWrites']=or(_0x18d1c7['visibleWrites'],k(_0x1f3402['path'],_0x582df5));});}return!0x0;}else return!0x1;}function fu(_0xf93d55,_0x7a9c2d){if(_0xf93d55['snap'])return G(_0xf93d55['path'],_0x7a9c2d);for(const _0x1025e2 in _0xf93d55['children'])if(_0xf93d55['children']['hasOwnProperty'](_0x1025e2)&&G(k(_0xf93d55['path'],_0x1025e2),_0x7a9c2d))return!0x0;return!0x1;}function pu(_0x415a9b){_0x415a9b['visibleWrites']=Wo(_0x415a9b['allWrites'],_u,w()),_0x415a9b['allWrites']['length']>0x0?_0x415a9b['lastWriteId']=_0x415a9b['allWrites'][_0x415a9b['allWrites']['length']-0x1]['writeId']:_0x415a9b['lastWriteId']=-0x1;}function _u(_0x261f2f){return _0x261f2f['visible'];}function Wo(_0x54e251,_0xd8418e,_0xb5d7b8){let _0x56a7f4=K['empty']();for(let _0x1c88ed=0x0;_0x1c88ed<_0x54e251['length'];++_0x1c88ed){const _0x4b03d8=_0x54e251[_0x1c88ed];if(_0xd8418e(_0x4b03d8)){const _0x1f079f=_0x4b03d8['path'];let _0x541f41;if(_0x4b03d8['snap'])G(_0xb5d7b8,_0x1f079f)?(_0x541f41=F(_0xb5d7b8,_0x1f079f),_0x56a7f4=At(_0x56a7f4,_0x541f41,_0x4b03d8['snap'])):G(_0x1f079f,_0xb5d7b8)&&(_0x541f41=F(_0x1f079f,_0xb5d7b8),_0x56a7f4=At(_0x56a7f4,w(),_0x4b03d8['snap']['getChild'](_0x541f41)));else{if(_0x4b03d8['children']){if(G(_0xb5d7b8,_0x1f079f))_0x541f41=F(_0xb5d7b8,_0x1f079f),_0x56a7f4=bi(_0x56a7f4,_0x541f41,_0x4b03d8['children']);else{if(G(_0x1f079f,_0xb5d7b8)){if(_0x541f41=F(_0x1f079f,_0xb5d7b8),v(_0x541f41))_0x56a7f4=bi(_0x56a7f4,w(),_0x4b03d8['children']);else{const _0x702960=Le(_0x4b03d8['children'],y(_0x541f41));if(_0x702960){const _0x313900=_0x702960['getChild'](S(_0x541f41));_0x56a7f4=At(_0x56a7f4,w(),_0x313900);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x56a7f4;}function Bo(_0x385f04,_0x483df5,_0x540fd9,_0x1cf27f,_0x245c10){if(!_0x1cf27f&&!_0x245c10){const _0x132e9a=ze(_0x385f04['visibleWrites'],_0x483df5);if(_0x132e9a!=null)return _0x132e9a;{const _0x449702=Ee(_0x385f04['visibleWrites'],_0x483df5);if(Ai(_0x449702))return _0x540fd9;if(_0x540fd9==null&&!Ri(_0x449702,w()))return null;{const _0x4e156b=_0x540fd9||g['EMPTY_NODE'];return at(_0x449702,_0x4e156b);}}}else{const _0x2c3e79=Ee(_0x385f04['visibleWrites'],_0x483df5);if(!_0x245c10&&Ai(_0x2c3e79))return _0x540fd9;if(!_0x245c10&&_0x540fd9==null&&!Ri(_0x2c3e79,w()))return null;{const _0x598b45=function(_0x5946c9){return(_0x5946c9['visible']||_0x245c10)&&(!_0x1cf27f||!~_0x1cf27f['indexOf'](_0x5946c9['writeId']))&&(G(_0x5946c9['path'],_0x483df5)||G(_0x483df5,_0x5946c9['path']));},_0xe78a32=Wo(_0x385f04['allWrites'],_0x598b45,_0x483df5),_0x4da840=_0x540fd9||g['EMPTY_NODE'];return at(_0xe78a32,_0x4da840);}}}function gu(_0x16dd60,_0x44b736,_0x33dad1){let _0x502c04=g['EMPTY_NODE'];const _0x51eeec=ze(_0x16dd60['visibleWrites'],_0x44b736);if(_0x51eeec)return _0x51eeec['isLeafNode']()||_0x51eeec['forEachChild'](R,(_0x23d468,_0x450522)=>{_0x502c04=_0x502c04['updateImmediateChild'](_0x23d468,_0x450522);}),_0x502c04;if(_0x33dad1){const _0x17640=Ee(_0x16dd60['visibleWrites'],_0x44b736);return _0x33dad1['forEachChild'](R,(_0x4769d7,_0xe12aec)=>{const _0x7819c7=at(Ee(_0x17640,new C(_0x4769d7)),_0xe12aec);_0x502c04=_0x502c04['updateImmediateChild'](_0x4769d7,_0x7819c7);}),ar(_0x17640)['forEach'](_0x472840=>{_0x502c04=_0x502c04['updateImmediateChild'](_0x472840['name'],_0x472840['node']);}),_0x502c04;}else{const _0x57ee3c=Ee(_0x16dd60['visibleWrites'],_0x44b736);return ar(_0x57ee3c)['forEach'](_0x5cbf49=>{_0x502c04=_0x502c04['updateImmediateChild'](_0x5cbf49['name'],_0x5cbf49['node']);}),_0x502c04;}}function mu(_0x15fd95,_0x4d50cb,_0x159dd3,_0x3276d8,_0x13d504){f(_0x3276d8||_0x13d504,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x57e826=k(_0x4d50cb,_0x159dd3);if(Ri(_0x15fd95['visibleWrites'],_0x57e826))return null;{const _0xe51507=Ee(_0x15fd95['visibleWrites'],_0x57e826);return Ai(_0xe51507)?_0x13d504['getChild'](_0x159dd3):at(_0xe51507,_0x13d504['getChild'](_0x159dd3));}}function yu(_0x86afd,_0x5f04e0,_0x51d91e,_0x473e5f){const _0x39bd1a=k(_0x5f04e0,_0x51d91e),_0x24ac17=ze(_0x86afd['visibleWrites'],_0x39bd1a);if(_0x24ac17!=null)return _0x24ac17;if(_0x473e5f['isCompleteForChild'](_0x51d91e)){const _0x4b6305=Ee(_0x86afd['visibleWrites'],_0x39bd1a);return at(_0x4b6305,_0x473e5f['getNode']()['getImmediateChild'](_0x51d91e));}else return null;}function vu(_0x416f84,_0x313ff2){return ze(_0x416f84['visibleWrites'],_0x313ff2);}function Eu(_0x5def65,_0x153aad,_0x24bb48,_0x567b4d,_0x1c71d8,_0x4f356c,_0x468197){let _0x4bf97c;const _0x31aac3=Ee(_0x5def65['visibleWrites'],_0x153aad),_0x77cd71=ze(_0x31aac3,w());if(_0x77cd71!=null)_0x4bf97c=_0x77cd71;else{if(_0x24bb48!=null)_0x4bf97c=at(_0x31aac3,_0x24bb48);else return[];}if(_0x4bf97c=_0x4bf97c['withIndex'](_0x468197),!_0x4bf97c['isEmpty']()&&!_0x4bf97c['isLeafNode']()){const _0xe9d7fb=[],_0x42706a=_0x468197['getCompare'](),_0x1b1298=_0x4f356c?_0x4bf97c['getReverseIteratorFrom'](_0x567b4d,_0x468197):_0x4bf97c['getIteratorFrom'](_0x567b4d,_0x468197);let _0x313c03=_0x1b1298['getNext']();for(;_0x313c03&&_0xe9d7fb['length']<_0x1c71d8;)_0x42706a(_0x313c03,_0x567b4d)!==0x0&&_0xe9d7fb['push'](_0x313c03),_0x313c03=_0x1b1298['getNext']();return _0xe9d7fb;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x8332db,_0x2cd09a,_0x323f47,_0x4d2091){return Bo(_0x8332db['writeTree'],_0x8332db['treePath'],_0x2cd09a,_0x323f47,_0x4d2091);}function is(_0x42e1e8,_0x26c1e1){return gu(_0x42e1e8['writeTree'],_0x42e1e8['treePath'],_0x26c1e1);}function cr(_0x24b1d4,_0x22c57a,_0xdd91d5,_0x353c2c){return mu(_0x24b1d4['writeTree'],_0x24b1d4['treePath'],_0x22c57a,_0xdd91d5,_0x353c2c);}function Tn(_0x5e4585,_0x3d5a74){return vu(_0x5e4585['writeTree'],k(_0x5e4585['treePath'],_0x3d5a74));}function wu(_0x11a625,_0x2c5636,_0x2ef251,_0x361e38,_0x514cd7,_0x1c33c3){return Eu(_0x11a625['writeTree'],_0x11a625['treePath'],_0x2c5636,_0x2ef251,_0x361e38,_0x514cd7,_0x1c33c3);}function ss(_0x3968c0,_0x3d9116,_0xf027a7){return yu(_0x3968c0['writeTree'],_0x3968c0['treePath'],_0x3d9116,_0xf027a7);}function Vo(_0x116187,_0x2ff580){return Ho(k(_0x116187['treePath'],_0x2ff580),_0x116187['writeTree']);}function Ho(_0x18fae0,_0x215d1c){return{'treePath':_0x18fae0,'writeTree':_0x215d1c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x25c41e){const _0x700591=_0x25c41e['type'],_0x58ccd9=_0x25c41e['childName'];f(_0x700591==='child_added'||_0x700591==='child_changed'||_0x700591==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x58ccd9!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3cf042=this['changeMap']['get'](_0x58ccd9);if(_0x3cf042){const _0x4d2d33=_0x3cf042['type'];if(_0x700591==='child_added'&&_0x4d2d33==='child_removed')this['changeMap']['set'](_0x58ccd9,xt(_0x58ccd9,_0x25c41e['snapshotNode'],_0x3cf042['snapshotNode']));else{if(_0x700591==='child_removed'&&_0x4d2d33==='child_added')this['changeMap']['delete'](_0x58ccd9);else{if(_0x700591==='child_removed'&&_0x4d2d33==='child_changed')this['changeMap']['set'](_0x58ccd9,Lt(_0x58ccd9,_0x3cf042['oldSnap']));else{if(_0x700591==='child_changed'&&_0x4d2d33==='child_added')this['changeMap']['set'](_0x58ccd9,rt(_0x58ccd9,_0x25c41e['snapshotNode']));else{if(_0x700591==='child_changed'&&_0x4d2d33==='child_changed')this['changeMap']['set'](_0x58ccd9,xt(_0x58ccd9,_0x25c41e['snapshotNode'],_0x3cf042['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x25c41e+'\x20occurred\x20after\x20'+_0x3cf042);}}}}}else this['changeMap']['set'](_0x58ccd9,_0x25c41e);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1ae423){return null;}['getChildAfterChild'](_0x4702b7,_0x20d2c2,_0x4d63cf){return null;}}const $o=new Tu();class rs{constructor(_0x43d061,_0x25a05e,_0xf3db7c=null){this['writes_']=_0x43d061,this['viewCache_']=_0x25a05e,this['optCompleteServerCache_']=_0xf3db7c;}['getCompleteChild'](_0x34df3c){const _0x228196=this['viewCache_']['eventCache'];if(_0x228196['isCompleteForChild'](_0x34df3c))return _0x228196['getNode']()['getImmediateChild'](_0x34df3c);{const _0xcd5df9=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x34df3c,_0xcd5df9);}}['getChildAfterChild'](_0xdff88a,_0x2ea5d7,_0xa6417){const _0x556ffe=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x4350a8=wu(this['writes_'],_0x556ffe,_0x2ea5d7,0x1,_0xa6417,_0xdff88a);return _0x4350a8['length']===0x0?null:_0x4350a8[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x15f279){return{'filter':_0x15f279};}function bu(_0x475620,_0x113470){f(_0x113470['eventCache']['getNode']()['isIndexed'](_0x475620['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x113470['serverCache']['getNode']()['isIndexed'](_0x475620['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x43cf27,_0x3a2edb,_0x18f611,_0x385b58,_0x1c2438){const _0x5938db=new Cu();let _0x513d65,_0x5da32e;if(_0x18f611['type']===z['OVERWRITE']){const _0x16bcf1=_0x18f611;_0x16bcf1['source']['fromUser']?_0x513d65=ki(_0x43cf27,_0x3a2edb,_0x16bcf1['path'],_0x16bcf1['snap'],_0x385b58,_0x1c2438,_0x5938db):(f(_0x16bcf1['source']['fromServer'],'Unknown\x20source.'),_0x5da32e=_0x16bcf1['source']['tagged']||_0x3a2edb['serverCache']['isFiltered']()&&!v(_0x16bcf1['path']),_0x513d65=Sn(_0x43cf27,_0x3a2edb,_0x16bcf1['path'],_0x16bcf1['snap'],_0x385b58,_0x1c2438,_0x5da32e,_0x5938db));}else{if(_0x18f611['type']===z['MERGE']){const _0x5c4f37=_0x18f611;_0x5c4f37['source']['fromUser']?_0x513d65=ku(_0x43cf27,_0x3a2edb,_0x5c4f37['path'],_0x5c4f37['children'],_0x385b58,_0x1c2438,_0x5938db):(f(_0x5c4f37['source']['fromServer'],'Unknown\x20source.'),_0x5da32e=_0x5c4f37['source']['tagged']||_0x3a2edb['serverCache']['isFiltered'](),_0x513d65=Pi(_0x43cf27,_0x3a2edb,_0x5c4f37['path'],_0x5c4f37['children'],_0x385b58,_0x1c2438,_0x5da32e,_0x5938db));}else{if(_0x18f611['type']===z['ACK_USER_WRITE']){const _0x3aecec=_0x18f611;_0x3aecec['revert']?_0x513d65=Ou(_0x43cf27,_0x3a2edb,_0x3aecec['path'],_0x385b58,_0x1c2438,_0x5938db):_0x513d65=Pu(_0x43cf27,_0x3a2edb,_0x3aecec['path'],_0x3aecec['affectedTree'],_0x385b58,_0x1c2438,_0x5938db);}else{if(_0x18f611['type']===z['LISTEN_COMPLETE'])_0x513d65=Nu(_0x43cf27,_0x3a2edb,_0x18f611['path'],_0x385b58,_0x5938db);else throw ht('Unknown\x20operation\x20type:\x20'+_0x18f611['type']);}}}const _0x37565a=_0x5938db['getChanges']();return Au(_0x3a2edb,_0x513d65,_0x37565a),{'viewCache':_0x513d65,'changes':_0x37565a};}function Au(_0x1157cc,_0xc37c87,_0xa9d906){const _0x459a92=_0xc37c87['eventCache'];if(_0x459a92['isFullyInitialized']()){const _0x26f331=_0x459a92['getNode']()['isLeafNode']()||_0x459a92['getNode']()['isEmpty'](),_0x2edfa0=wn(_0x1157cc);(_0xa9d906['length']>0x0||!_0x1157cc['eventCache']['isFullyInitialized']()||_0x26f331&&!_0x459a92['getNode']()['equals'](_0x2edfa0)||!_0x459a92['getNode']()['getPriority']()['equals'](_0x2edfa0['getPriority']()))&&_0xa9d906['push'](Lo(wn(_0xc37c87)));}}function Go(_0x1205bc,_0x5612e2,_0x10d97b,_0x1c3dfd,_0x460e3a,_0x173f5d){const _0x5bebd4=_0x5612e2['eventCache'];if(Tn(_0x1c3dfd,_0x10d97b)!=null)return _0x5612e2;{let _0x9ef5d5,_0x35cbb4;if(v(_0x10d97b)){if(f(_0x5612e2['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5612e2['serverCache']['isFiltered']()){const _0x299e08=Ve(_0x5612e2),_0x403fb5=_0x299e08 instanceof g?_0x299e08:g['EMPTY_NODE'],_0x3264d8=is(_0x1c3dfd,_0x403fb5);_0x9ef5d5=_0x1205bc['filter']['updateFullNode'](_0x5612e2['eventCache']['getNode'](),_0x3264d8,_0x173f5d);}else{const _0xbff16=Cn(_0x1c3dfd,Ve(_0x5612e2));_0x9ef5d5=_0x1205bc['filter']['updateFullNode'](_0x5612e2['eventCache']['getNode'](),_0xbff16,_0x173f5d);}}else{const _0x297ff6=y(_0x10d97b);if(_0x297ff6==='.priority'){f(Ce(_0x10d97b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1da536=_0x5bebd4['getNode']();_0x35cbb4=_0x5612e2['serverCache']['getNode']();const _0x12a159=cr(_0x1c3dfd,_0x10d97b,_0x1da536,_0x35cbb4);_0x12a159!=null?_0x9ef5d5=_0x1205bc['filter']['updatePriority'](_0x1da536,_0x12a159):_0x9ef5d5=_0x5bebd4['getNode']();}else{const _0x4dcd2d=S(_0x10d97b);let _0x37aed0;if(_0x5bebd4['isCompleteForChild'](_0x297ff6)){_0x35cbb4=_0x5612e2['serverCache']['getNode']();const _0x11d564=cr(_0x1c3dfd,_0x10d97b,_0x5bebd4['getNode'](),_0x35cbb4);_0x11d564!=null?_0x37aed0=_0x5bebd4['getNode']()['getImmediateChild'](_0x297ff6)['updateChild'](_0x4dcd2d,_0x11d564):_0x37aed0=_0x5bebd4['getNode']()['getImmediateChild'](_0x297ff6);}else _0x37aed0=ss(_0x1c3dfd,_0x297ff6,_0x5612e2['serverCache']);_0x37aed0!=null?_0x9ef5d5=_0x1205bc['filter']['updateChild'](_0x5bebd4['getNode'](),_0x297ff6,_0x37aed0,_0x4dcd2d,_0x460e3a,_0x173f5d):_0x9ef5d5=_0x5bebd4['getNode']();}}return Rt(_0x5612e2,_0x9ef5d5,_0x5bebd4['isFullyInitialized']()||v(_0x10d97b),_0x1205bc['filter']['filtersNodes']());}}function Sn(_0x5b691a,_0x2e6b25,_0xa6ae52,_0x2359c8,_0x1758f0,_0x4e0029,_0xb4bd9a,_0x183eac){const _0x36a6b8=_0x2e6b25['serverCache'];let _0x426ce4;const _0x5f332e=_0xb4bd9a?_0x5b691a['filter']:_0x5b691a['filter']['getIndexedFilter']();if(v(_0xa6ae52))_0x426ce4=_0x5f332e['updateFullNode'](_0x36a6b8['getNode'](),_0x2359c8,null);else{if(_0x5f332e['filtersNodes']()&&!_0x36a6b8['isFiltered']()){const _0x59f7d6=_0x36a6b8['getNode']()['updateChild'](_0xa6ae52,_0x2359c8);_0x426ce4=_0x5f332e['updateFullNode'](_0x36a6b8['getNode'](),_0x59f7d6,null);}else{const _0x26f7a3=y(_0xa6ae52);if(!_0x36a6b8['isCompleteForPath'](_0xa6ae52)&&Ce(_0xa6ae52)>0x1)return _0x2e6b25;const _0x3d9d4f=S(_0xa6ae52),_0x2c670e=_0x36a6b8['getNode']()['getImmediateChild'](_0x26f7a3)['updateChild'](_0x3d9d4f,_0x2359c8);_0x26f7a3==='.priority'?_0x426ce4=_0x5f332e['updatePriority'](_0x36a6b8['getNode'](),_0x2c670e):_0x426ce4=_0x5f332e['updateChild'](_0x36a6b8['getNode'](),_0x26f7a3,_0x2c670e,_0x3d9d4f,$o,null);}}const _0x58e9e7=Fo(_0x2e6b25,_0x426ce4,_0x36a6b8['isFullyInitialized']()||v(_0xa6ae52),_0x5f332e['filtersNodes']()),_0x20187b=new rs(_0x1758f0,_0x58e9e7,_0x4e0029);return Go(_0x5b691a,_0x58e9e7,_0xa6ae52,_0x1758f0,_0x20187b,_0x183eac);}function ki(_0x496d75,_0x4235a9,_0x10c5a7,_0x189467,_0xf798c3,_0x3d5a8b,_0x95973d){const _0x4c02f1=_0x4235a9['eventCache'];let _0x439fbd,_0x105d55;const _0x52a3be=new rs(_0xf798c3,_0x4235a9,_0x3d5a8b);if(v(_0x10c5a7))_0x105d55=_0x496d75['filter']['updateFullNode'](_0x4235a9['eventCache']['getNode'](),_0x189467,_0x95973d),_0x439fbd=Rt(_0x4235a9,_0x105d55,!0x0,_0x496d75['filter']['filtersNodes']());else{const _0x40d966=y(_0x10c5a7);if(_0x40d966==='.priority')_0x105d55=_0x496d75['filter']['updatePriority'](_0x4235a9['eventCache']['getNode'](),_0x189467),_0x439fbd=Rt(_0x4235a9,_0x105d55,_0x4c02f1['isFullyInitialized'](),_0x4c02f1['isFiltered']());else{const _0x5ddb86=S(_0x10c5a7),_0x12798f=_0x4c02f1['getNode']()['getImmediateChild'](_0x40d966);let _0x43efd0;if(v(_0x5ddb86))_0x43efd0=_0x189467;else{const _0x2a12eb=_0x52a3be['getCompleteChild'](_0x40d966);_0x2a12eb!=null?ji(_0x5ddb86)==='.priority'&&_0x2a12eb['getChild'](Ro(_0x5ddb86))['isEmpty']()?_0x43efd0=_0x2a12eb:_0x43efd0=_0x2a12eb['updateChild'](_0x5ddb86,_0x189467):_0x43efd0=g['EMPTY_NODE'];}if(_0x12798f['equals'](_0x43efd0))_0x439fbd=_0x4235a9;else{const _0x56df5f=_0x496d75['filter']['updateChild'](_0x4c02f1['getNode'](),_0x40d966,_0x43efd0,_0x5ddb86,_0x52a3be,_0x95973d);_0x439fbd=Rt(_0x4235a9,_0x56df5f,_0x4c02f1['isFullyInitialized'](),_0x496d75['filter']['filtersNodes']());}}}return _0x439fbd;}function lr(_0x26cfd5,_0xea7af7){return _0x26cfd5['eventCache']['isCompleteForChild'](_0xea7af7);}function ku(_0x35705f,_0x11c84e,_0x44e76b,_0x4394e1,_0x4d21a4,_0x4b2b56,_0x5f7b89){let _0x21179a=_0x11c84e;return _0x4394e1['foreach']((_0x1f1ee7,_0x3a6a51)=>{const _0x43d0b9=k(_0x44e76b,_0x1f1ee7);lr(_0x11c84e,y(_0x43d0b9))&&(_0x21179a=ki(_0x35705f,_0x21179a,_0x43d0b9,_0x3a6a51,_0x4d21a4,_0x4b2b56,_0x5f7b89));}),_0x4394e1['foreach']((_0x182305,_0x1ff234)=>{const _0x279876=k(_0x44e76b,_0x182305);lr(_0x11c84e,y(_0x279876))||(_0x21179a=ki(_0x35705f,_0x21179a,_0x279876,_0x1ff234,_0x4d21a4,_0x4b2b56,_0x5f7b89));}),_0x21179a;}function hr(_0x277978,_0x433dad,_0x44f42a){return _0x44f42a['foreach']((_0x5a2364,_0x4d8ed1)=>{_0x433dad=_0x433dad['updateChild'](_0x5a2364,_0x4d8ed1);}),_0x433dad;}function Pi(_0x3078d6,_0x3ab241,_0x515bd4,_0x3960f4,_0x1b9ec4,_0x46535d,_0x3ea403,_0x1ef5c7){if(_0x3ab241['serverCache']['getNode']()['isEmpty']()&&!_0x3ab241['serverCache']['isFullyInitialized']())return _0x3ab241;let _0x1be30d=_0x3ab241,_0x450d92;v(_0x515bd4)?_0x450d92=_0x3960f4:_0x450d92=new b(null)['setTree'](_0x515bd4,_0x3960f4);const _0x51608d=_0x3ab241['serverCache']['getNode']();return _0x450d92['children']['inorderTraversal']((_0xb6e860,_0x37e332)=>{if(_0x51608d['hasChild'](_0xb6e860)){const _0x217f47=_0x3ab241['serverCache']['getNode']()['getImmediateChild'](_0xb6e860),_0x13e006=hr(_0x3078d6,_0x217f47,_0x37e332);_0x1be30d=Sn(_0x3078d6,_0x1be30d,new C(_0xb6e860),_0x13e006,_0x1b9ec4,_0x46535d,_0x3ea403,_0x1ef5c7);}}),_0x450d92['children']['inorderTraversal']((_0x571b12,_0x203f86)=>{const _0x380e2d=!_0x3ab241['serverCache']['isCompleteForChild'](_0x571b12)&&_0x203f86['value']===null;if(!_0x51608d['hasChild'](_0x571b12)&&!_0x380e2d){const _0x4b2ec1=_0x3ab241['serverCache']['getNode']()['getImmediateChild'](_0x571b12),_0x8115e9=hr(_0x3078d6,_0x4b2ec1,_0x203f86);_0x1be30d=Sn(_0x3078d6,_0x1be30d,new C(_0x571b12),_0x8115e9,_0x1b9ec4,_0x46535d,_0x3ea403,_0x1ef5c7);}}),_0x1be30d;}function Pu(_0x33d67b,_0x1a5e61,_0x418371,_0x34e767,_0x2e86d0,_0x2f60d3,_0x4701ca){if(Tn(_0x2e86d0,_0x418371)!=null)return _0x1a5e61;const _0x1b24df=_0x1a5e61['serverCache']['isFiltered'](),_0x32a409=_0x1a5e61['serverCache'];if(_0x34e767['value']!=null){if(v(_0x418371)&&_0x32a409['isFullyInitialized']()||_0x32a409['isCompleteForPath'](_0x418371))return Sn(_0x33d67b,_0x1a5e61,_0x418371,_0x32a409['getNode']()['getChild'](_0x418371),_0x2e86d0,_0x2f60d3,_0x1b24df,_0x4701ca);if(v(_0x418371)){let _0x24369b=new b(null);return _0x32a409['getNode']()['forEachChild'](ve,(_0x30988f,_0x1354c0)=>{_0x24369b=_0x24369b['set'](new C(_0x30988f),_0x1354c0);}),Pi(_0x33d67b,_0x1a5e61,_0x418371,_0x24369b,_0x2e86d0,_0x2f60d3,_0x1b24df,_0x4701ca);}else return _0x1a5e61;}else{let _0x2804e4=new b(null);return _0x34e767['foreach']((_0x8591b4,_0x15b444)=>{const _0x31e5d6=k(_0x418371,_0x8591b4);_0x32a409['isCompleteForPath'](_0x31e5d6)&&(_0x2804e4=_0x2804e4['set'](_0x8591b4,_0x32a409['getNode']()['getChild'](_0x31e5d6)));}),Pi(_0x33d67b,_0x1a5e61,_0x418371,_0x2804e4,_0x2e86d0,_0x2f60d3,_0x1b24df,_0x4701ca);}}function Nu(_0x201a1a,_0x36a004,_0x3f063f,_0x31f000,_0x44288e){const _0x1f00e7=_0x36a004['serverCache'],_0x47cd5=Fo(_0x36a004,_0x1f00e7['getNode'](),_0x1f00e7['isFullyInitialized']()||v(_0x3f063f),_0x1f00e7['isFiltered']());return Go(_0x201a1a,_0x47cd5,_0x3f063f,_0x31f000,$o,_0x44288e);}function Ou(_0x97ff24,_0x33d851,_0x3ce33f,_0x58ee02,_0x1006eb,_0x105b57){let _0xd9ab14;if(Tn(_0x58ee02,_0x3ce33f)!=null)return _0x33d851;{const _0x993bdf=new rs(_0x58ee02,_0x33d851,_0x1006eb),_0x4226e4=_0x33d851['eventCache']['getNode']();let _0x48f2fb;if(v(_0x3ce33f)||y(_0x3ce33f)==='.priority'){let _0x27b9c6;if(_0x33d851['serverCache']['isFullyInitialized']())_0x27b9c6=Cn(_0x58ee02,Ve(_0x33d851));else{const _0x11d499=_0x33d851['serverCache']['getNode']();f(_0x11d499 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x27b9c6=is(_0x58ee02,_0x11d499);}_0x27b9c6=_0x27b9c6,_0x48f2fb=_0x97ff24['filter']['updateFullNode'](_0x4226e4,_0x27b9c6,_0x105b57);}else{const _0x417428=y(_0x3ce33f);let _0x250964=ss(_0x58ee02,_0x417428,_0x33d851['serverCache']);_0x250964==null&&_0x33d851['serverCache']['isCompleteForChild'](_0x417428)&&(_0x250964=_0x4226e4['getImmediateChild'](_0x417428)),_0x250964!=null?_0x48f2fb=_0x97ff24['filter']['updateChild'](_0x4226e4,_0x417428,_0x250964,S(_0x3ce33f),_0x993bdf,_0x105b57):_0x33d851['eventCache']['getNode']()['hasChild'](_0x417428)?_0x48f2fb=_0x97ff24['filter']['updateChild'](_0x4226e4,_0x417428,g['EMPTY_NODE'],S(_0x3ce33f),_0x993bdf,_0x105b57):_0x48f2fb=_0x4226e4,_0x48f2fb['isEmpty']()&&_0x33d851['serverCache']['isFullyInitialized']()&&(_0xd9ab14=Cn(_0x58ee02,Ve(_0x33d851)),_0xd9ab14['isLeafNode']()&&(_0x48f2fb=_0x97ff24['filter']['updateFullNode'](_0x48f2fb,_0xd9ab14,_0x105b57)));}return _0xd9ab14=_0x33d851['serverCache']['isFullyInitialized']()||Tn(_0x58ee02,w())!=null,Rt(_0x33d851,_0x48f2fb,_0xd9ab14,_0x97ff24['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5f0bd7,_0x21601c){this['query_']=_0x5f0bd7,this['eventRegistrations_']=[];const _0x4ffb9f=this['query_']['_queryParams'],_0x1fe399=new Xi(_0x4ffb9f['getIndex']()),_0x44ba92=Kh(_0x4ffb9f);this['processor_']=Su(_0x44ba92);const _0x343b44=_0x21601c['serverCache'],_0x495d6a=_0x21601c['eventCache'],_0x20092f=_0x1fe399['updateFullNode'](g['EMPTY_NODE'],_0x343b44['getNode'](),null),_0x13d80b=_0x44ba92['updateFullNode'](g['EMPTY_NODE'],_0x495d6a['getNode'](),null),_0x14b228=new Te(_0x20092f,_0x343b44['isFullyInitialized'](),_0x1fe399['filtersNodes']()),_0x3a76be=new Te(_0x13d80b,_0x495d6a['isFullyInitialized'](),_0x44ba92['filtersNodes']());this['viewCache_']=Un(_0x3a76be,_0x14b228),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x4893d9){return _0x4893d9['viewCache_']['serverCache']['getNode']();}function Lu(_0x860dc){return wn(_0x860dc['viewCache_']);}function xu(_0x22e3cb,_0x2b3225){const _0x1afda1=Ve(_0x22e3cb['viewCache_']);return _0x1afda1&&(_0x22e3cb['query']['_queryParams']['loadsAllData']()||!v(_0x2b3225)&&!_0x1afda1['getImmediateChild'](y(_0x2b3225))['isEmpty']())?_0x1afda1['getChild'](_0x2b3225):null;}function ur(_0x27fc99){return _0x27fc99['eventRegistrations_']['length']===0x0;}function Fu(_0x48ccc9,_0x4aa587){_0x48ccc9['eventRegistrations_']['push'](_0x4aa587);}function dr(_0xd0f6ea,_0xe77e68,_0x39bcbb){const _0x344301=[];if(_0x39bcbb){f(_0xe77e68==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x136b09=_0xd0f6ea['query']['_path'];_0xd0f6ea['eventRegistrations_']['forEach'](_0x56c0e4=>{const _0x1d0394=_0x56c0e4['createCancelEvent'](_0x39bcbb,_0x136b09);_0x1d0394&&_0x344301['push'](_0x1d0394);});}if(_0xe77e68){let _0x15a41d=[];for(let _0x213190=0x0;_0x213190<_0xd0f6ea['eventRegistrations_']['length'];++_0x213190){const _0x3b13fc=_0xd0f6ea['eventRegistrations_'][_0x213190];if(!_0x3b13fc['matches'](_0xe77e68))_0x15a41d['push'](_0x3b13fc);else{if(_0xe77e68['hasAnyCallback']()){_0x15a41d=_0x15a41d['concat'](_0xd0f6ea['eventRegistrations_']['slice'](_0x213190+0x1));break;}}}_0xd0f6ea['eventRegistrations_']=_0x15a41d;}else _0xd0f6ea['eventRegistrations_']=[];return _0x344301;}function fr(_0x2b407d,_0xf2dd11,_0x431d5b,_0x428db0){_0xf2dd11['type']===z['MERGE']&&_0xf2dd11['source']['queryId']!==null&&(f(Ve(_0x2b407d['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2b407d['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0xc49123=_0x2b407d['viewCache_'],_0x584e57=Ru(_0x2b407d['processor_'],_0xc49123,_0xf2dd11,_0x431d5b,_0x428db0);return bu(_0x2b407d['processor_'],_0x584e57['viewCache']),f(_0x584e57['viewCache']['serverCache']['isFullyInitialized']()||!_0xc49123['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2b407d['viewCache_']=_0x584e57['viewCache'],qo(_0x2b407d,_0x584e57['changes'],_0x584e57['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x537774,_0x4a6224){const _0x5b2df6=_0x537774['viewCache_']['eventCache'],_0x4bad3b=[];return _0x5b2df6['getNode']()['isLeafNode']()||_0x5b2df6['getNode']()['forEachChild'](R,(_0x3a8862,_0x57063a)=>{_0x4bad3b['push'](rt(_0x3a8862,_0x57063a));}),_0x5b2df6['isFullyInitialized']()&&_0x4bad3b['push'](Lo(_0x5b2df6['getNode']())),qo(_0x537774,_0x4bad3b,_0x5b2df6['getNode'](),_0x4a6224);}function qo(_0x176048,_0x410426,_0x3d943f,_0x41a8d1){const _0x400c8c=_0x41a8d1?[_0x41a8d1]:_0x176048['eventRegistrations_'];return ru(_0x176048['eventGenerator_'],_0x410426,_0x3d943f,_0x400c8c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x50849e){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x50849e;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1fca67){return _0x1fca67['views']['size']===0x0;}function os(_0x5e8eef,_0xeafbb3,_0x381fda,_0x16130b){const _0x473842=_0xeafbb3['source']['queryId'];if(_0x473842!==null){const _0x34afd8=_0x5e8eef['views']['get'](_0x473842);return f(_0x34afd8!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x34afd8,_0xeafbb3,_0x381fda,_0x16130b);}else{let _0x55c1b8=[];for(const _0x499395 of _0x5e8eef['views']['values']())_0x55c1b8=_0x55c1b8['concat'](fr(_0x499395,_0xeafbb3,_0x381fda,_0x16130b));return _0x55c1b8;}}function jo(_0x49f767,_0x15249f,_0x395ba1,_0x46ffba,_0x12dc92){const _0x110858=_0x15249f['_queryIdentifier'],_0x2aa85d=_0x49f767['views']['get'](_0x110858);if(!_0x2aa85d){let _0x39560b=Cn(_0x395ba1,_0x12dc92?_0x46ffba:null),_0x484a6c=!0x1;_0x39560b?_0x484a6c=!0x0:_0x46ffba instanceof g?(_0x39560b=is(_0x395ba1,_0x46ffba),_0x484a6c=!0x1):(_0x39560b=g['EMPTY_NODE'],_0x484a6c=!0x1);const _0x5a44df=Un(new Te(_0x39560b,_0x484a6c,!0x1),new Te(_0x46ffba,_0x12dc92,!0x1));return new Du(_0x15249f,_0x5a44df);}return _0x2aa85d;}function Hu(_0x319959,_0x3a55e4,_0x135456,_0x91121e,_0x410486,_0x541524){const _0x211252=jo(_0x319959,_0x3a55e4,_0x91121e,_0x410486,_0x541524);return _0x319959['views']['has'](_0x3a55e4['_queryIdentifier'])||_0x319959['views']['set'](_0x3a55e4['_queryIdentifier'],_0x211252),Fu(_0x211252,_0x135456),Uu(_0x211252,_0x135456);}function $u(_0x4db8c7,_0x4fc9fa,_0x5966ca,_0x147c2f){const _0x5d5bea=_0x4fc9fa['_queryIdentifier'],_0x3b2282=[];let _0x3b4ca1=[];const _0x4ed2ec=Se(_0x4db8c7);if(_0x5d5bea==='default'){for(const [_0x285ce9,_0x468a8e]of _0x4db8c7['views']['entries']())_0x3b4ca1=_0x3b4ca1['concat'](dr(_0x468a8e,_0x5966ca,_0x147c2f)),ur(_0x468a8e)&&(_0x4db8c7['views']['delete'](_0x285ce9),_0x468a8e['query']['_queryParams']['loadsAllData']()||_0x3b2282['push'](_0x468a8e['query']));}else{const _0x3a7873=_0x4db8c7['views']['get'](_0x5d5bea);_0x3a7873&&(_0x3b4ca1=_0x3b4ca1['concat'](dr(_0x3a7873,_0x5966ca,_0x147c2f)),ur(_0x3a7873)&&(_0x4db8c7['views']['delete'](_0x5d5bea),_0x3a7873['query']['_queryParams']['loadsAllData']()||_0x3b2282['push'](_0x3a7873['query'])));}return _0x4ed2ec&&!Se(_0x4db8c7)&&_0x3b2282['push'](new(Bu())(_0x4fc9fa['_repo'],_0x4fc9fa['_path'])),{'removed':_0x3b2282,'events':_0x3b4ca1};}function Ko(_0x385f70){const _0x249b22=[];for(const _0x19c489 of _0x385f70['views']['values']())_0x19c489['query']['_queryParams']['loadsAllData']()||_0x249b22['push'](_0x19c489);return _0x249b22;}function Ie(_0xaf0df7,_0x5ec2ad){let _0x520a95=null;for(const _0x187298 of _0xaf0df7['views']['values']())_0x520a95=_0x520a95||xu(_0x187298,_0x5ec2ad);return _0x520a95;}function Yo(_0x569f35,_0x3dea24){if(_0x3dea24['_queryParams']['loadsAllData']())return Bn(_0x569f35);{const _0x694725=_0x3dea24['_queryIdentifier'];return _0x569f35['views']['get'](_0x694725);}}function Qo(_0x132c76,_0x3d2a13){return Yo(_0x132c76,_0x3d2a13)!=null;}function Se(_0x2e5ba7){return Bn(_0x2e5ba7)!=null;}function Bn(_0x551c5e){for(const _0x2214d7 of _0x551c5e['views']['values']())if(_0x2214d7['query']['_queryParams']['loadsAllData']())return _0x2214d7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x5b9ee5){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x5b9ee5;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x27569b){this['listenProvider_']=_0x27569b,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x26e125,_0x520e79,_0x2611e3,_0x1a7b6d,_0x1b235a){return lu(_0x26e125['pendingWriteTree_'],_0x520e79,_0x2611e3,_0x1a7b6d,_0x1b235a),_0x1b235a?_t(_0x26e125,new Be(es(),_0x520e79,_0x2611e3)):[];}function ju(_0x59a9d0,_0x2df31e,_0x2d9429,_0x25868b){hu(_0x59a9d0['pendingWriteTree_'],_0x2df31e,_0x2d9429,_0x25868b);const _0x5e7bf9=b['fromObject'](_0x2d9429);return _t(_0x59a9d0,new ot(es(),_0x2df31e,_0x5e7bf9));}function _e(_0x3c4411,_0x252165,_0x291e40=!0x1){const _0x16b5dd=uu(_0x3c4411['pendingWriteTree_'],_0x252165);if(du(_0x3c4411['pendingWriteTree_'],_0x252165)){let _0x11ffe0=new b(null);return _0x16b5dd['snap']!=null?_0x11ffe0=_0x11ffe0['set'](w(),!0x0):x(_0x16b5dd['children'],_0x4981d5=>{_0x11ffe0=_0x11ffe0['set'](new C(_0x4981d5),!0x0);}),_t(_0x3c4411,new In(_0x16b5dd['path'],_0x11ffe0,_0x291e40));}else return[];}function Yt(_0x389851,_0x12e9ae,_0x1f9920){return _t(_0x389851,new Be(ts(),_0x12e9ae,_0x1f9920));}function Ku(_0x3cca09,_0x3758db,_0x16ccbc){const _0x5e25e0=b['fromObject'](_0x16ccbc);return _t(_0x3cca09,new ot(ts(),_0x3758db,_0x5e25e0));}function Yu(_0x2ac69a,_0x3687eb){return _t(_0x2ac69a,new Ut(ts(),_0x3687eb));}function Qu(_0x1df283,_0x3a7b8a,_0x424cfe){const _0x4f02d5=cs(_0x1df283,_0x424cfe);if(_0x4f02d5){const _0x4e5148=ls(_0x4f02d5),_0x3a15aa=_0x4e5148['path'],_0x247d2c=_0x4e5148['queryId'],_0x3f6b31=F(_0x3a15aa,_0x3a7b8a),_0x1f8c98=new Ut(ns(_0x247d2c),_0x3f6b31);return hs(_0x1df283,_0x3a15aa,_0x1f8c98);}else return[];}function An(_0x219257,_0x3eb08e,_0x2fdea2,_0x25dd80,_0x5dc212=!0x1){const _0x1cee5d=_0x3eb08e['_path'],_0x3c339d=_0x219257['syncPointTree_']['get'](_0x1cee5d);let _0x2cea35=[];if(_0x3c339d&&(_0x3eb08e['_queryIdentifier']==='default'||Qo(_0x3c339d,_0x3eb08e))){const _0x38336b=$u(_0x3c339d,_0x3eb08e,_0x2fdea2,_0x25dd80);Vu(_0x3c339d)&&(_0x219257['syncPointTree_']=_0x219257['syncPointTree_']['remove'](_0x1cee5d));const _0x83fa28=_0x38336b['removed'];if(_0x2cea35=_0x38336b['events'],!_0x5dc212){const _0x19e941=_0x83fa28['findIndex'](_0x8b45ac=>_0x8b45ac['_queryParams']['loadsAllData']())!==-0x1,_0x5b7db0=_0x219257['syncPointTree_']['findOnPath'](_0x1cee5d,(_0x229124,_0x34ea9a)=>Se(_0x34ea9a));if(_0x19e941&&!_0x5b7db0){const _0x10554d=_0x219257['syncPointTree_']['subtree'](_0x1cee5d);if(!_0x10554d['isEmpty']()){const _0xd8c7b8=Zu(_0x10554d);for(let _0x9040bf=0x0;_0x9040bf<_0xd8c7b8['length'];++_0x9040bf){const _0x251e51=_0xd8c7b8[_0x9040bf],_0x3e550f=_0x251e51['query'],_0x4f757e=ea(_0x219257,_0x251e51);_0x219257['listenProvider_']['startListening'](kt(_0x3e550f),Wt(_0x219257,_0x3e550f),_0x4f757e['hashFn'],_0x4f757e['onComplete']);}}}!_0x5b7db0&&_0x83fa28['length']>0x0&&!_0x25dd80&&(_0x19e941?_0x219257['listenProvider_']['stopListening'](kt(_0x3eb08e),null):_0x83fa28['forEach'](_0x4e20ae=>{const _0x462790=_0x219257['queryToTagMap']['get'](Hn(_0x4e20ae));_0x219257['listenProvider_']['stopListening'](kt(_0x4e20ae),_0x462790);}));}ed(_0x219257,_0x83fa28);}return _0x2cea35;}function Jo(_0x1f1ce2,_0x122891,_0x22ae2,_0x1dc129){const _0x254502=cs(_0x1f1ce2,_0x1dc129);if(_0x254502!=null){const _0x5ee003=ls(_0x254502),_0x45319a=_0x5ee003['path'],_0x432db0=_0x5ee003['queryId'],_0x3ccf6a=F(_0x45319a,_0x122891),_0x440111=new Be(ns(_0x432db0),_0x3ccf6a,_0x22ae2);return hs(_0x1f1ce2,_0x45319a,_0x440111);}else return[];}function Ju(_0x8b34b2,_0x457904,_0x1d7e91,_0x13f78c){const _0x3b3400=cs(_0x8b34b2,_0x13f78c);if(_0x3b3400){const _0x64c373=ls(_0x3b3400),_0x3e5b1d=_0x64c373['path'],_0x4e87a1=_0x64c373['queryId'],_0x1c1a5f=F(_0x3e5b1d,_0x457904),_0x2ba2d3=b['fromObject'](_0x1d7e91),_0x36f179=new ot(ns(_0x4e87a1),_0x1c1a5f,_0x2ba2d3);return hs(_0x8b34b2,_0x3e5b1d,_0x36f179);}else return[];}function Ni(_0x4956c8,_0x520de9,_0x257821,_0x7fa218=!0x1){const _0x5cb5dc=_0x520de9['_path'];let _0x4f10d6=null,_0x42494a=!0x1;_0x4956c8['syncPointTree_']['foreachOnPath'](_0x5cb5dc,(_0x514c9e,_0x4ef229)=>{const _0x561925=F(_0x514c9e,_0x5cb5dc);_0x4f10d6=_0x4f10d6||Ie(_0x4ef229,_0x561925),_0x42494a=_0x42494a||Se(_0x4ef229);});let _0x37ac73=_0x4956c8['syncPointTree_']['get'](_0x5cb5dc);_0x37ac73?(_0x42494a=_0x42494a||Se(_0x37ac73),_0x4f10d6=_0x4f10d6||Ie(_0x37ac73,w())):(_0x37ac73=new zo(),_0x4956c8['syncPointTree_']=_0x4956c8['syncPointTree_']['set'](_0x5cb5dc,_0x37ac73));let _0x2b3d54;_0x4f10d6!=null?_0x2b3d54=!0x0:(_0x2b3d54=!0x1,_0x4f10d6=g['EMPTY_NODE'],_0x4956c8['syncPointTree_']['subtree'](_0x5cb5dc)['foreachChild']((_0x57f5c6,_0x2d061c)=>{const _0x52dd2f=Ie(_0x2d061c,w());_0x52dd2f&&(_0x4f10d6=_0x4f10d6['updateImmediateChild'](_0x57f5c6,_0x52dd2f));}));const _0x259fe7=Qo(_0x37ac73,_0x520de9);if(!_0x259fe7&&!_0x520de9['_queryParams']['loadsAllData']()){const _0x19fcce=Hn(_0x520de9);f(!_0x4956c8['queryToTagMap']['has'](_0x19fcce),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1ed767=td();_0x4956c8['queryToTagMap']['set'](_0x19fcce,_0x1ed767),_0x4956c8['tagToQueryMap']['set'](_0x1ed767,_0x19fcce);}const _0x3dbcd6=Wn(_0x4956c8['pendingWriteTree_'],_0x5cb5dc);let _0x62aa27=Hu(_0x37ac73,_0x520de9,_0x257821,_0x3dbcd6,_0x4f10d6,_0x2b3d54);if(!_0x259fe7&&!_0x42494a&&!_0x7fa218){const _0x2002cf=Yo(_0x37ac73,_0x520de9);_0x62aa27=_0x62aa27['concat'](nd(_0x4956c8,_0x520de9,_0x2002cf));}return _0x62aa27;}function Vn(_0x15a1a4,_0x35b171,_0x3a009b){const _0x2ddc25=_0x15a1a4['pendingWriteTree_'],_0x16aec9=_0x15a1a4['syncPointTree_']['findOnPath'](_0x35b171,(_0xdb6ec5,_0x15f897)=>{const _0x22dfb3=F(_0xdb6ec5,_0x35b171),_0x1a0f96=Ie(_0x15f897,_0x22dfb3);if(_0x1a0f96)return _0x1a0f96;});return Bo(_0x2ddc25,_0x35b171,_0x16aec9,_0x3a009b,!0x0);}function Xu(_0x2c9f3e,_0x1779ba){const _0x5c355f=_0x1779ba['_path'];let _0x41f857=null;_0x2c9f3e['syncPointTree_']['foreachOnPath'](_0x5c355f,(_0x503a07,_0x2146e9)=>{const _0x21e955=F(_0x503a07,_0x5c355f);_0x41f857=_0x41f857||Ie(_0x2146e9,_0x21e955);});let _0x10251a=_0x2c9f3e['syncPointTree_']['get'](_0x5c355f);_0x10251a?_0x41f857=_0x41f857||Ie(_0x10251a,w()):(_0x10251a=new zo(),_0x2c9f3e['syncPointTree_']=_0x2c9f3e['syncPointTree_']['set'](_0x5c355f,_0x10251a));const _0x181f9a=_0x41f857!=null,_0x26398b=_0x181f9a?new Te(_0x41f857,!0x0,!0x1):null,_0x21c1f4=Wn(_0x2c9f3e['pendingWriteTree_'],_0x1779ba['_path']),_0x17be77=jo(_0x10251a,_0x1779ba,_0x21c1f4,_0x181f9a?_0x26398b['getNode']():g['EMPTY_NODE'],_0x181f9a);return Lu(_0x17be77);}function _t(_0xce73cd,_0x36b73f){return Xo(_0x36b73f,_0xce73cd['syncPointTree_'],null,Wn(_0xce73cd['pendingWriteTree_'],w()));}function Xo(_0x22187b,_0x341749,_0x1cd74d,_0x5e4b82){if(v(_0x22187b['path']))return Zo(_0x22187b,_0x341749,_0x1cd74d,_0x5e4b82);{const _0x59279a=_0x341749['get'](w());_0x1cd74d==null&&_0x59279a!=null&&(_0x1cd74d=Ie(_0x59279a,w()));let _0x1251d5=[];const _0x59a9fc=y(_0x22187b['path']),_0x4eac72=_0x22187b['operationForChild'](_0x59a9fc),_0x2f9e91=_0x341749['children']['get'](_0x59a9fc);if(_0x2f9e91&&_0x4eac72){const _0x1dc18a=_0x1cd74d?_0x1cd74d['getImmediateChild'](_0x59a9fc):null,_0x12dc2b=Vo(_0x5e4b82,_0x59a9fc);_0x1251d5=_0x1251d5['concat'](Xo(_0x4eac72,_0x2f9e91,_0x1dc18a,_0x12dc2b));}return _0x59279a&&(_0x1251d5=_0x1251d5['concat'](os(_0x59279a,_0x22187b,_0x5e4b82,_0x1cd74d))),_0x1251d5;}}function Zo(_0x2f6235,_0x2caf85,_0x564ab7,_0x3f1624){const _0x299b3f=_0x2caf85['get'](w());_0x564ab7==null&&_0x299b3f!=null&&(_0x564ab7=Ie(_0x299b3f,w()));let _0x200e9a=[];return _0x2caf85['children']['inorderTraversal']((_0x5ea60a,_0x2f6281)=>{const _0x4cecc7=_0x564ab7?_0x564ab7['getImmediateChild'](_0x5ea60a):null,_0xef0279=Vo(_0x3f1624,_0x5ea60a),_0x16475d=_0x2f6235['operationForChild'](_0x5ea60a);_0x16475d&&(_0x200e9a=_0x200e9a['concat'](Zo(_0x16475d,_0x2f6281,_0x4cecc7,_0xef0279)));}),_0x299b3f&&(_0x200e9a=_0x200e9a['concat'](os(_0x299b3f,_0x2f6235,_0x3f1624,_0x564ab7))),_0x200e9a;}function ea(_0x4b6ad0,_0xaf75d3){const _0xedfb5d=_0xaf75d3['query'],_0x1c4e63=Wt(_0x4b6ad0,_0xedfb5d);return{'hashFn':()=>(Mu(_0xaf75d3)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2a9c45=>{if(_0x2a9c45==='ok')return _0x1c4e63?Qu(_0x4b6ad0,_0xedfb5d['_path'],_0x1c4e63):Yu(_0x4b6ad0,_0xedfb5d['_path']);{const _0x5714be=Kl(_0x2a9c45,_0xedfb5d);return An(_0x4b6ad0,_0xedfb5d,null,_0x5714be);}}};}function Wt(_0x2d2120,_0x2405e1){const _0x526592=Hn(_0x2405e1);return _0x2d2120['queryToTagMap']['get'](_0x526592);}function Hn(_0x5be552){return _0x5be552['_path']['toString']()+'$'+_0x5be552['_queryIdentifier'];}function cs(_0x3a3f1e,_0x2ba278){return _0x3a3f1e['tagToQueryMap']['get'](_0x2ba278);}function ls(_0x3537ec){const _0xfe3507=_0x3537ec['indexOf']('$');return f(_0xfe3507!==-0x1&&_0xfe3507<_0x3537ec['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3537ec['substr'](_0xfe3507+0x1),'path':new C(_0x3537ec['substr'](0x0,_0xfe3507))};}function hs(_0x5c3278,_0x23ed67,_0x3383b3){const _0xfb87b7=_0x5c3278['syncPointTree_']['get'](_0x23ed67);f(_0xfb87b7,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4fe792=Wn(_0x5c3278['pendingWriteTree_'],_0x23ed67);return os(_0xfb87b7,_0x3383b3,_0x4fe792,null);}function Zu(_0x8e2f42){return _0x8e2f42['fold']((_0x3ebbc7,_0x1e4cd8,_0x1fd6b5)=>{if(_0x1e4cd8&&Se(_0x1e4cd8))return[Bn(_0x1e4cd8)];{let _0x3904d3=[];return _0x1e4cd8&&(_0x3904d3=Ko(_0x1e4cd8)),x(_0x1fd6b5,(_0x53bf67,_0x1c4a18)=>{_0x3904d3=_0x3904d3['concat'](_0x1c4a18);}),_0x3904d3;}});}function kt(_0x5af456){return _0x5af456['_queryParams']['loadsAllData']()&&!_0x5af456['_queryParams']['isDefault']()?new(qu())(_0x5af456['_repo'],_0x5af456['_path']):_0x5af456;}function ed(_0x53b58a,_0x290111){for(let _0x1d0e52=0x0;_0x1d0e52<_0x290111['length'];++_0x1d0e52){const _0x4cbafa=_0x290111[_0x1d0e52];if(!_0x4cbafa['_queryParams']['loadsAllData']()){const _0x336338=Hn(_0x4cbafa),_0x12900e=_0x53b58a['queryToTagMap']['get'](_0x336338);_0x53b58a['queryToTagMap']['delete'](_0x336338),_0x53b58a['tagToQueryMap']['delete'](_0x12900e);}}}function td(){return zu++;}function nd(_0x82145c,_0x56d324,_0x22a1ff){const _0x587eb4=_0x56d324['_path'],_0x3b1f96=Wt(_0x82145c,_0x56d324),_0x2840c8=ea(_0x82145c,_0x22a1ff),_0x39bb6c=_0x82145c['listenProvider_']['startListening'](kt(_0x56d324),_0x3b1f96,_0x2840c8['hashFn'],_0x2840c8['onComplete']),_0x4dc03b=_0x82145c['syncPointTree_']['subtree'](_0x587eb4);if(_0x3b1f96)f(!Se(_0x4dc03b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x307244=_0x4dc03b['fold']((_0x1b7940,_0x37b9ec,_0x546bae)=>{if(!v(_0x1b7940)&&_0x37b9ec&&Se(_0x37b9ec))return[Bn(_0x37b9ec)['query']];{let _0x248b07=[];return _0x37b9ec&&(_0x248b07=_0x248b07['concat'](Ko(_0x37b9ec)['map'](_0x16f376=>_0x16f376['query']))),x(_0x546bae,(_0x527a57,_0x366e7a)=>{_0x248b07=_0x248b07['concat'](_0x366e7a);}),_0x248b07;}});for(let _0x387380=0x0;_0x387380<_0x307244['length'];++_0x387380){const _0x4c6c48=_0x307244[_0x387380];_0x82145c['listenProvider_']['stopListening'](kt(_0x4c6c48),Wt(_0x82145c,_0x4c6c48));}}return _0x39bb6c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x1f9460){this['node_']=_0x1f9460;}['getImmediateChild'](_0x27ea48){const _0x434097=this['node_']['getImmediateChild'](_0x27ea48);return new us(_0x434097);}['node'](){return this['node_'];}}class ds{constructor(_0x83c96d,_0x37e2a0){this['syncTree_']=_0x83c96d,this['path_']=_0x37e2a0;}['getImmediateChild'](_0x3889f8){const _0x36e7e3=k(this['path_'],_0x3889f8);return new ds(this['syncTree_'],_0x36e7e3);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x261d94){return _0x261d94=_0x261d94||{},_0x261d94['timestamp']=_0x261d94['timestamp']||new Date()['getTime'](),_0x261d94;},_r=function(_0x401f53,_0x412f89,_0x575f89){if(!_0x401f53||typeof _0x401f53!='object')return _0x401f53;if(f('.sv'in _0x401f53,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x401f53['.sv']=='string')return sd(_0x401f53['.sv'],_0x412f89,_0x575f89);if(typeof _0x401f53['.sv']=='object')return rd(_0x401f53['.sv'],_0x412f89);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x401f53,null,0x2));},sd=function(_0x271f9d,_0x150a53,_0x33be89){switch(_0x271f9d){case'timestamp':return _0x33be89['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x271f9d);}},rd=function(_0x38f0ef,_0x3419f4,_0x5c1935){_0x38f0ef['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x38f0ef,null,0x2));const _0x21cd03=_0x38f0ef['increment'];typeof _0x21cd03!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x21cd03);const _0x41874d=_0x3419f4['node']();if(f(_0x41874d!==null&&typeof _0x41874d<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x41874d['isLeafNode']())return _0x21cd03;const _0x44a4bc=_0x41874d['getValue']();return typeof _0x44a4bc!='number'?_0x21cd03:_0x44a4bc+_0x21cd03;},ta=function(_0x95c53b,_0x10529a,_0x126ade,_0x585bba){return ps(_0x10529a,new ds(_0x126ade,_0x95c53b),_0x585bba);},fs=function(_0x321233,_0x4bba0c,_0x43a57b){return ps(_0x321233,new us(_0x4bba0c),_0x43a57b);};function ps(_0x351a8b,_0x56ebe9,_0x1553ea){const _0x297a18=_0x351a8b['getPriority']()['val'](),_0x30d824=_r(_0x297a18,_0x56ebe9['getImmediateChild']('.priority'),_0x1553ea);let _0x24c0f0;if(_0x351a8b['isLeafNode']()){const _0xe4a6a1=_0x351a8b,_0x59f2ff=_r(_0xe4a6a1['getValue'](),_0x56ebe9,_0x1553ea);return _0x59f2ff!==_0xe4a6a1['getValue']()||_0x30d824!==_0xe4a6a1['getPriority']()['val']()?new D(_0x59f2ff,A(_0x30d824)):_0x351a8b;}else{const _0xa2f742=_0x351a8b;return _0x24c0f0=_0xa2f742,_0x30d824!==_0xa2f742['getPriority']()['val']()&&(_0x24c0f0=_0x24c0f0['updatePriority'](new D(_0x30d824))),_0xa2f742['forEachChild'](R,(_0x2b4ee2,_0x353b26)=>{const _0x5ec300=ps(_0x353b26,_0x56ebe9['getImmediateChild'](_0x2b4ee2),_0x1553ea);_0x5ec300!==_0x353b26&&(_0x24c0f0=_0x24c0f0['updateImmediateChild'](_0x2b4ee2,_0x5ec300));}),_0x24c0f0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x5d6453='',_0x4d772e=null,_0x1299ff={'children':{},'childCount':0x0}){this['name']=_0x5d6453,this['parent']=_0x4d772e,this['node']=_0x1299ff;}}function $n(_0x47ec53,_0x438804){let _0x2eb102=_0x438804 instanceof C?_0x438804:new C(_0x438804),_0xe705ed=_0x47ec53,_0x4e58ad=y(_0x2eb102);for(;_0x4e58ad!==null;){const _0x5c7c7d=Le(_0xe705ed['node']['children'],_0x4e58ad)||{'children':{},'childCount':0x0};_0xe705ed=new _s(_0x4e58ad,_0xe705ed,_0x5c7c7d),_0x2eb102=S(_0x2eb102),_0x4e58ad=y(_0x2eb102);}return _0xe705ed;}function je(_0x19aa53){return _0x19aa53['node']['value'];}function gs(_0x290bc4,_0x111da8){_0x290bc4['node']['value']=_0x111da8,Oi(_0x290bc4);}function na(_0x3037fd){return _0x3037fd['node']['childCount']>0x0;}function od(_0x28a527){return je(_0x28a527)===void 0x0&&!na(_0x28a527);}function Gn(_0xaf1407,_0x314832){x(_0xaf1407['node']['children'],(_0xd568ba,_0x5c960a)=>{_0x314832(new _s(_0xd568ba,_0xaf1407,_0x5c960a));});}function ia(_0x2f1de7,_0x2b9b0d,_0x44eea6,_0x1d46ab){_0x44eea6&&_0x2b9b0d(_0x2f1de7),Gn(_0x2f1de7,_0x4d9279=>{ia(_0x4d9279,_0x2b9b0d,!0x0);});}function ad(_0x179041,_0x5137e8,_0x2504cf){let _0x4882f8=_0x179041['parent'];for(;_0x4882f8!==null;){if(_0x5137e8(_0x4882f8))return!0x0;_0x4882f8=_0x4882f8['parent'];}return!0x1;}function Qt(_0x45d273){return new C(_0x45d273['parent']===null?_0x45d273['name']:Qt(_0x45d273['parent'])+'/'+_0x45d273['name']);}function Oi(_0x3a3843){_0x3a3843['parent']!==null&&cd(_0x3a3843['parent'],_0x3a3843['name'],_0x3a3843);}function cd(_0x339c62,_0x20bacd,_0x415a7f){const _0x315df8=od(_0x415a7f),_0x228545=Q(_0x339c62['node']['children'],_0x20bacd);_0x315df8&&_0x228545?(delete _0x339c62['node']['children'][_0x20bacd],_0x339c62['node']['childCount']--,Oi(_0x339c62)):!_0x315df8&&!_0x228545&&(_0x339c62['node']['children'][_0x20bacd]=_0x415a7f['node'],_0x339c62['node']['childCount']++,Oi(_0x339c62));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0xd7ea54){return typeof _0xd7ea54=='string'&&_0xd7ea54['length']!==0x0&&!ld['test'](_0xd7ea54);},sa=function(_0x49a4d2){return typeof _0x49a4d2=='string'&&_0x49a4d2['length']!==0x0&&!hd['test'](_0x49a4d2);},ud=function(_0x5418ac){return _0x5418ac&&(_0x5418ac=_0x5418ac['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x5418ac);},Bt=function(_0x47acd2){return _0x47acd2===null||typeof _0x47acd2=='string'||typeof _0x47acd2=='number'&&!xn(_0x47acd2)||_0x47acd2&&typeof _0x47acd2=='object'&&Q(_0x47acd2,'.sv');},He=function(_0x5e4136,_0x369924,_0x3f1a42,_0x588948){_0x588948&&_0x369924===void 0x0||Jt(it(_0x5e4136,'value'),_0x369924,_0x3f1a42);},Jt=function(_0xee0033,_0xb37acf,_0x384f88){const _0x2589b8=_0x384f88 instanceof C?new Ah(_0x384f88,_0xee0033):_0x384f88;if(_0xb37acf===void 0x0)throw new Error(_0xee0033+'contains\x20undefined\x20'+Oe(_0x2589b8));if(typeof _0xb37acf=='function')throw new Error(_0xee0033+'contains\x20a\x20function\x20'+Oe(_0x2589b8)+'\x20with\x20contents\x20=\x20'+_0xb37acf['toString']());if(xn(_0xb37acf))throw new Error(_0xee0033+'contains\x20'+_0xb37acf['toString']()+'\x20'+Oe(_0x2589b8));if(typeof _0xb37acf=='string'&&_0xb37acf['length']>ui/0x3&&Ln(_0xb37acf)>ui)throw new Error(_0xee0033+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2589b8)+'\x20(\x27'+_0xb37acf['substring'](0x0,0x32)+'...\x27)');if(_0xb37acf&&typeof _0xb37acf=='object'){let _0x1c5991=!0x1,_0x44e5ef=!0x1;if(x(_0xb37acf,(_0x5aee0e,_0x3a70cf)=>{if(_0x5aee0e==='.value')_0x1c5991=!0x0;else{if(_0x5aee0e!=='.priority'&&_0x5aee0e!=='.sv'&&(_0x44e5ef=!0x0,!ms(_0x5aee0e)))throw new Error(_0xee0033+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5aee0e+')\x20'+Oe(_0x2589b8)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2589b8,_0x5aee0e),Jt(_0xee0033,_0x3a70cf,_0x2589b8),Ph(_0x2589b8);}),_0x1c5991&&_0x44e5ef)throw new Error(_0xee0033+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2589b8)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4eb272,_0x251b1d){let _0x4d0b17,_0x146241;for(_0x4d0b17=0x0;_0x4d0b17<_0x251b1d['length'];_0x4d0b17++){_0x146241=_0x251b1d[_0x4d0b17];const _0x4d2228=Mt(_0x146241);for(let _0x2c2f95=0x0;_0x2c2f95<_0x4d2228['length'];_0x2c2f95++)if(!(_0x4d2228[_0x2c2f95]==='.priority'&&_0x2c2f95===_0x4d2228['length']-0x1)){if(!ms(_0x4d2228[_0x2c2f95]))throw new Error(_0x4eb272+'contains\x20an\x20invalid\x20key\x20('+_0x4d2228[_0x2c2f95]+')\x20in\x20path\x20'+_0x146241['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x251b1d['sort'](Rh);let _0xa34e88=null;for(_0x4d0b17=0x0;_0x4d0b17<_0x251b1d['length'];_0x4d0b17++){if(_0x146241=_0x251b1d[_0x4d0b17],_0xa34e88!==null&&G(_0xa34e88,_0x146241))throw new Error(_0x4eb272+'contains\x20a\x20path\x20'+_0xa34e88['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x146241['toString']());_0xa34e88=_0x146241;}},ra=function(_0x5d8a92,_0x4542b6,_0x4dbb9b,_0x3474eb){const _0x1aaa69=it(_0x5d8a92,'values');if(!(_0x4542b6&&typeof _0x4542b6=='object')||Array['isArray'](_0x4542b6))throw new Error(_0x1aaa69+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x311a09=[];x(_0x4542b6,(_0x34f543,_0x158f20)=>{const _0x37edf1=new C(_0x34f543);if(Jt(_0x1aaa69,_0x158f20,k(_0x4dbb9b,_0x37edf1)),ji(_0x37edf1)==='.priority'&&!Bt(_0x158f20))throw new Error(_0x1aaa69+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x37edf1['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x311a09['push'](_0x37edf1);}),dd(_0x1aaa69,_0x311a09);},fd=function(_0xa5915a,_0x3e9266,_0x487a9f){if(xn(_0x3e9266))throw new Error(it(_0xa5915a,'priority')+'is\x20'+_0x3e9266['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3e9266))throw new Error(it(_0xa5915a,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x396e1d,_0x42dbe0,_0x7f83e,_0x2a0663){if(!sa(_0x7f83e))throw new Error(it(_0x396e1d,_0x42dbe0)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x7f83e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1a7973,_0x3f9332,_0x4512aa,_0x3d5a53){_0x4512aa&&(_0x4512aa=_0x4512aa['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1a7973,_0x3f9332,_0x4512aa);},Me=function(_0x2a32a9,_0x329d07){if(y(_0x329d07)==='.info')throw new Error(_0x2a32a9+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3394e6,_0x4f6a51){const _0x183f23=_0x4f6a51['path']['toString']();if(typeof _0x4f6a51['repoInfo']['host']!='string'||_0x4f6a51['repoInfo']['host']['length']===0x0||!ms(_0x4f6a51['repoInfo']['namespace'])&&_0x4f6a51['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x183f23['length']!==0x0&&!ud(_0x183f23))throw new Error(it(_0x3394e6,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x20d77c,_0x5269c8){let _0x3c9e13=null;for(let _0x3441f4=0x0;_0x3441f4<_0x5269c8['length'];_0x3441f4++){const _0x87e0c8=_0x5269c8[_0x3441f4],_0x59eeea=_0x87e0c8['getPath']();_0x3c9e13!==null&&!Ki(_0x59eeea,_0x3c9e13['path'])&&(_0x20d77c['eventLists_']['push'](_0x3c9e13),_0x3c9e13=null),_0x3c9e13===null&&(_0x3c9e13={'events':[],'path':_0x59eeea}),_0x3c9e13['events']['push'](_0x87e0c8);}_0x3c9e13&&_0x20d77c['eventLists_']['push'](_0x3c9e13);}function oa(_0x27a418,_0x509e97,_0x146ffa){qn(_0x27a418,_0x146ffa),aa(_0x27a418,_0x3b741c=>Ki(_0x3b741c,_0x509e97));}function V(_0x36d072,_0x4eb56e,_0x20343b){qn(_0x36d072,_0x20343b),aa(_0x36d072,_0x3321d2=>G(_0x3321d2,_0x4eb56e)||G(_0x4eb56e,_0x3321d2));}function aa(_0x77d6eb,_0x3f5b7a){_0x77d6eb['recursionDepth_']++;let _0x22d58d=!0x0;for(let _0x100a4b=0x0;_0x100a4b<_0x77d6eb['eventLists_']['length'];_0x100a4b++){const _0x556aee=_0x77d6eb['eventLists_'][_0x100a4b];if(_0x556aee){const _0x167a1e=_0x556aee['path'];_0x3f5b7a(_0x167a1e)?(md(_0x77d6eb['eventLists_'][_0x100a4b]),_0x77d6eb['eventLists_'][_0x100a4b]=null):_0x22d58d=!0x1;}}_0x22d58d&&(_0x77d6eb['eventLists_']=[]),_0x77d6eb['recursionDepth_']--;}function md(_0x4e12b1){for(let _0x3b9083=0x0;_0x3b9083<_0x4e12b1['events']['length'];_0x3b9083++){const _0x5489a7=_0x4e12b1['events'][_0x3b9083];if(_0x5489a7!==null){_0x4e12b1['events'][_0x3b9083]=null;const _0x37972b=_0x5489a7['getEventRunner']();St&&L('event:\x20'+_0x5489a7['toString']()),ft(_0x37972b);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4cdbfc,_0x3439d5,_0x10c687,_0x4f2252){this['repoInfo_']=_0x4cdbfc,this['forceRestClient_']=_0x3439d5,this['authTokenProvider_']=_0x10c687,this['appCheckProvider_']=_0x4f2252,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x52c7c6,_0x132b93,_0x26ea2f){if(_0x52c7c6['stats_']=qi(_0x52c7c6['repoInfo_']),_0x52c7c6['forceRestClient_']||Xl())_0x52c7c6['server_']=new vn(_0x52c7c6['repoInfo_'],(_0x191bab,_0x46f776,_0xa8813f,_0x24325f)=>{gr(_0x52c7c6,_0x191bab,_0x46f776,_0xa8813f,_0x24325f);},_0x52c7c6['authTokenProvider_'],_0x52c7c6['appCheckProvider_']),setTimeout(()=>mr(_0x52c7c6,!0x0),0x0);else{if(typeof _0x26ea2f<'u'&&_0x26ea2f!==null){if(typeof _0x26ea2f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x26ea2f);}catch(_0x33f1e){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x33f1e);}}_0x52c7c6['persistentConnection_']=new se(_0x52c7c6['repoInfo_'],_0x132b93,(_0x1a107f,_0x473e34,_0x277bc7,_0x1575ef)=>{gr(_0x52c7c6,_0x1a107f,_0x473e34,_0x277bc7,_0x1575ef);},_0x3e137c=>{mr(_0x52c7c6,_0x3e137c);},_0x193410=>{Id(_0x52c7c6,_0x193410);},_0x52c7c6['authTokenProvider_'],_0x52c7c6['appCheckProvider_'],_0x26ea2f),_0x52c7c6['server_']=_0x52c7c6['persistentConnection_'];}_0x52c7c6['authTokenProvider_']['addTokenChangeListener'](_0x5d2590=>{_0x52c7c6['server_']['refreshAuthToken'](_0x5d2590);}),_0x52c7c6['appCheckProvider_']['addTokenChangeListener'](_0x43710d=>{_0x52c7c6['server_']['refreshAppCheckToken'](_0x43710d['token']);}),_0x52c7c6['statsReporter_']=ih(_0x52c7c6['repoInfo_'],()=>new iu(_0x52c7c6['stats_'],_0x52c7c6['server_'])),_0x52c7c6['infoData_']=new Xh(),_0x52c7c6['infoSyncTree_']=new pr({'startListening':(_0x495c53,_0x478999,_0x996ddf,_0x2eb123)=>{let _0x3360ca=[];const _0x5a7f3b=_0x52c7c6['infoData_']['getNode'](_0x495c53['_path']);return _0x5a7f3b['isEmpty']()||(_0x3360ca=Yt(_0x52c7c6['infoSyncTree_'],_0x495c53['_path'],_0x5a7f3b),setTimeout(()=>{_0x2eb123('ok');},0x0)),_0x3360ca;},'stopListening':()=>{}}),vs(_0x52c7c6,'connected',!0x1),_0x52c7c6['serverSyncTree_']=new pr({'startListening':(_0x4d705a,_0x3f4f08,_0x1cff48,_0x1ea359)=>(_0x52c7c6['server_']['listen'](_0x4d705a,_0x1cff48,_0x3f4f08,(_0x49fe7e,_0x271e23)=>{const _0x2f74dd=_0x1ea359(_0x49fe7e,_0x271e23);V(_0x52c7c6['eventQueue_'],_0x4d705a['_path'],_0x2f74dd);}),[]),'stopListening':(_0x2c737e,_0x1a2740)=>{_0x52c7c6['server_']['unlisten'](_0x2c737e,_0x1a2740);}});}function la(_0x4324f9){const _0x308132=_0x4324f9['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x308132;}function Xt(_0x5c2db5){return id({'timestamp':la(_0x5c2db5)});}function gr(_0x1c18fa,_0x861663,_0x457da9,_0x4aa5e0,_0x333970){_0x1c18fa['dataUpdateCount']++;const _0xb121d1=new C(_0x861663);_0x457da9=_0x1c18fa['interceptServerDataCallback_']?_0x1c18fa['interceptServerDataCallback_'](_0x861663,_0x457da9):_0x457da9;let _0x2fc375=[];if(_0x333970){if(_0x4aa5e0){const _0x703bea=_n(_0x457da9,_0x223063=>A(_0x223063));_0x2fc375=Ju(_0x1c18fa['serverSyncTree_'],_0xb121d1,_0x703bea,_0x333970);}else{const _0xe04052=A(_0x457da9);_0x2fc375=Jo(_0x1c18fa['serverSyncTree_'],_0xb121d1,_0xe04052,_0x333970);}}else{if(_0x4aa5e0){const _0xbffecc=_n(_0x457da9,_0x23d6f0=>A(_0x23d6f0));_0x2fc375=Ku(_0x1c18fa['serverSyncTree_'],_0xb121d1,_0xbffecc);}else{const _0xcb20fa=A(_0x457da9);_0x2fc375=Yt(_0x1c18fa['serverSyncTree_'],_0xb121d1,_0xcb20fa);}}let _0x3029b6=_0xb121d1;_0x2fc375['length']>0x0&&(_0x3029b6=ct(_0x1c18fa,_0xb121d1)),V(_0x1c18fa['eventQueue_'],_0x3029b6,_0x2fc375);}function mr(_0x1bdbc8,_0x2d574f){vs(_0x1bdbc8,'connected',_0x2d574f),_0x2d574f===!0x1&&Sd(_0x1bdbc8);}function Id(_0x531445,_0x59b174){x(_0x59b174,(_0x278fb4,_0x5d340c)=>{vs(_0x531445,_0x278fb4,_0x5d340c);});}function vs(_0x3c0909,_0x1fe5a2,_0x40db45){const _0x1e6169=new C('/.info/'+_0x1fe5a2),_0x246577=A(_0x40db45);_0x3c0909['infoData_']['updateSnapshot'](_0x1e6169,_0x246577);const _0x4f7114=Yt(_0x3c0909['infoSyncTree_'],_0x1e6169,_0x246577);V(_0x3c0909['eventQueue_'],_0x1e6169,_0x4f7114);}function zn(_0x5c40d1){return _0x5c40d1['nextWriteId_']++;}function wd(_0xc5e2fa,_0x47a2b3,_0x4ea692){const _0x4e33b9=Xu(_0xc5e2fa['serverSyncTree_'],_0x47a2b3);return _0x4e33b9!=null?Promise['resolve'](_0x4e33b9):_0xc5e2fa['server_']['get'](_0x47a2b3)['then'](_0x100b23=>{const _0x414ebb=A(_0x100b23)['withIndex'](_0x47a2b3['_queryParams']['getIndex']());Ni(_0xc5e2fa['serverSyncTree_'],_0x47a2b3,_0x4ea692,!0x0);let _0x3f7daf;if(_0x47a2b3['_queryParams']['loadsAllData']())_0x3f7daf=Yt(_0xc5e2fa['serverSyncTree_'],_0x47a2b3['_path'],_0x414ebb);else{const _0x49768c=Wt(_0xc5e2fa['serverSyncTree_'],_0x47a2b3);_0x3f7daf=Jo(_0xc5e2fa['serverSyncTree_'],_0x47a2b3['_path'],_0x414ebb,_0x49768c);}return V(_0xc5e2fa['eventQueue_'],_0x47a2b3['_path'],_0x3f7daf),An(_0xc5e2fa['serverSyncTree_'],_0x47a2b3,_0x4ea692,null,!0x0),_0x414ebb;},_0x3ac1d3=>(gt(_0xc5e2fa,'get\x20for\x20query\x20'+O(_0x47a2b3)+'\x20failed:\x20'+_0x3ac1d3),Promise['reject'](new Error(_0x3ac1d3))));}function Cd(_0x246e08,_0x179943,_0x3348e4,_0x1235e6,_0x3fa278){gt(_0x246e08,'set',{'path':_0x179943['toString'](),'value':_0x3348e4,'priority':_0x1235e6});const _0x43bb5e=Xt(_0x246e08),_0x548503=A(_0x3348e4,_0x1235e6),_0x1de8d8=Vn(_0x246e08['serverSyncTree_'],_0x179943),_0x45bc8d=fs(_0x548503,_0x1de8d8,_0x43bb5e),_0x38146b=zn(_0x246e08),_0x5bbe23=as(_0x246e08['serverSyncTree_'],_0x179943,_0x45bc8d,_0x38146b,!0x0);qn(_0x246e08['eventQueue_'],_0x5bbe23),_0x246e08['server_']['put'](_0x179943['toString'](),_0x548503['val'](!0x0),(_0x5e94b7,_0x4cbef0)=>{const _0x5a02a1=_0x5e94b7==='ok';_0x5a02a1||U('set\x20at\x20'+_0x179943+'\x20failed:\x20'+_0x5e94b7);const _0x2ffe4d=_e(_0x246e08['serverSyncTree_'],_0x38146b,!_0x5a02a1);V(_0x246e08['eventQueue_'],_0x179943,_0x2ffe4d),be(_0x246e08,_0x3fa278,_0x5e94b7,_0x4cbef0);});const _0x1a71d8=Is(_0x246e08,_0x179943);ct(_0x246e08,_0x1a71d8),V(_0x246e08['eventQueue_'],_0x1a71d8,[]);}function Td(_0xfc18ef,_0xd9c6c8,_0xb08b88,_0x357f81){gt(_0xfc18ef,'update',{'path':_0xd9c6c8['toString'](),'value':_0xb08b88});let _0x3f45a2=!0x0;const _0x393492=Xt(_0xfc18ef),_0x5db73c={};if(x(_0xb08b88,(_0x23e006,_0x3344c3)=>{_0x3f45a2=!0x1,_0x5db73c[_0x23e006]=ta(k(_0xd9c6c8,_0x23e006),A(_0x3344c3),_0xfc18ef['serverSyncTree_'],_0x393492);}),_0x3f45a2)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xfc18ef,_0x357f81,'ok',void 0x0);else{const _0x286f98=zn(_0xfc18ef),_0x221113=ju(_0xfc18ef['serverSyncTree_'],_0xd9c6c8,_0x5db73c,_0x286f98);qn(_0xfc18ef['eventQueue_'],_0x221113),_0xfc18ef['server_']['merge'](_0xd9c6c8['toString'](),_0xb08b88,(_0x137e6e,_0x30ff74)=>{const _0x450e96=_0x137e6e==='ok';_0x450e96||U('update\x20at\x20'+_0xd9c6c8+'\x20failed:\x20'+_0x137e6e);const _0x220044=_e(_0xfc18ef['serverSyncTree_'],_0x286f98,!_0x450e96),_0x10090b=_0x220044['length']>0x0?ct(_0xfc18ef,_0xd9c6c8):_0xd9c6c8;V(_0xfc18ef['eventQueue_'],_0x10090b,_0x220044),be(_0xfc18ef,_0x357f81,_0x137e6e,_0x30ff74);}),x(_0xb08b88,_0x12989a=>{const _0x3bf878=Is(_0xfc18ef,k(_0xd9c6c8,_0x12989a));ct(_0xfc18ef,_0x3bf878);}),V(_0xfc18ef['eventQueue_'],_0xd9c6c8,[]);}}function Sd(_0x8a2805){gt(_0x8a2805,'onDisconnectEvents');const _0x2daae0=Xt(_0x8a2805),_0x47dd5d=En();Si(_0x8a2805['onDisconnect_'],w(),(_0x1231c5,_0x5e412d)=>{const _0x22cd23=ta(_0x1231c5,_0x5e412d,_0x8a2805['serverSyncTree_'],_0x2daae0);pt(_0x47dd5d,_0x1231c5,_0x22cd23);});let _0x2d200d=[];Si(_0x47dd5d,w(),(_0xf89175,_0x231c1d)=>{_0x2d200d=_0x2d200d['concat'](Yt(_0x8a2805['serverSyncTree_'],_0xf89175,_0x231c1d));const _0xaeb52a=Is(_0x8a2805,_0xf89175);ct(_0x8a2805,_0xaeb52a);}),_0x8a2805['onDisconnect_']=En(),V(_0x8a2805['eventQueue_'],w(),_0x2d200d);}function bd(_0x4a6de7,_0x2f0498,_0x3c54e2){_0x4a6de7['server_']['onDisconnectCancel'](_0x2f0498['toString'](),(_0x140706,_0x179539)=>{_0x140706==='ok'&&Ti(_0x4a6de7['onDisconnect_'],_0x2f0498),be(_0x4a6de7,_0x3c54e2,_0x140706,_0x179539);});}function yr(_0x1502c0,_0x338a84,_0x12bf8,_0x2439b9){const _0x4ed97d=A(_0x12bf8);_0x1502c0['server_']['onDisconnectPut'](_0x338a84['toString'](),_0x4ed97d['val'](!0x0),(_0xeec8b,_0x5bee67)=>{_0xeec8b==='ok'&&pt(_0x1502c0['onDisconnect_'],_0x338a84,_0x4ed97d),be(_0x1502c0,_0x2439b9,_0xeec8b,_0x5bee67);});}function Rd(_0x5c29f8,_0x3120ac,_0x195e16,_0x293c89,_0x42a539){const _0x451254=A(_0x195e16,_0x293c89);_0x5c29f8['server_']['onDisconnectPut'](_0x3120ac['toString'](),_0x451254['val'](!0x0),(_0x2694f9,_0x584734)=>{_0x2694f9==='ok'&&pt(_0x5c29f8['onDisconnect_'],_0x3120ac,_0x451254),be(_0x5c29f8,_0x42a539,_0x2694f9,_0x584734);});}function Ad(_0x231b91,_0x3d0fec,_0x2b1360,_0x52e804){if(pn(_0x2b1360)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x231b91,_0x52e804,'ok',void 0x0);return;}_0x231b91['server_']['onDisconnectMerge'](_0x3d0fec['toString'](),_0x2b1360,(_0x8f76bb,_0x2c9496)=>{_0x8f76bb==='ok'&&x(_0x2b1360,(_0x149333,_0x3f58c4)=>{const _0x33d181=A(_0x3f58c4);pt(_0x231b91['onDisconnect_'],k(_0x3d0fec,_0x149333),_0x33d181);}),be(_0x231b91,_0x52e804,_0x8f76bb,_0x2c9496);});}function kd(_0x35dcd2,_0x3f323f,_0x5298f4){let _0x34e18a;y(_0x3f323f['_path'])==='.info'?_0x34e18a=Ni(_0x35dcd2['infoSyncTree_'],_0x3f323f,_0x5298f4):_0x34e18a=Ni(_0x35dcd2['serverSyncTree_'],_0x3f323f,_0x5298f4),oa(_0x35dcd2['eventQueue_'],_0x3f323f['_path'],_0x34e18a);}function Pd(_0x59876c,_0x49df85,_0x24c2e1){let _0x375983;y(_0x49df85['_path'])==='.info'?_0x375983=An(_0x59876c['infoSyncTree_'],_0x49df85,_0x24c2e1):_0x375983=An(_0x59876c['serverSyncTree_'],_0x49df85,_0x24c2e1),oa(_0x59876c['eventQueue_'],_0x49df85['_path'],_0x375983);}function ha(_0x553d32){_0x553d32['persistentConnection_']&&_0x553d32['persistentConnection_']['interrupt'](ca);}function Nd(_0x115978){_0x115978['persistentConnection_']&&_0x115978['persistentConnection_']['resume'](ca);}function gt(_0x35f4dc,..._0x11a65b){let _0x17f653='';_0x35f4dc['persistentConnection_']&&(_0x17f653=_0x35f4dc['persistentConnection_']['id']+':'),L(_0x17f653,..._0x11a65b);}function be(_0x87bca9,_0x15ae39,_0x37382e,_0x18064f){_0x15ae39&&ft(()=>{if(_0x37382e==='ok')_0x15ae39(null);else{const _0x2a2654=(_0x37382e||'error')['toUpperCase']();let _0x449763=_0x2a2654;_0x18064f&&(_0x449763+=':\x20'+_0x18064f);const _0x3f55d9=new Error(_0x449763);_0x3f55d9['code']=_0x2a2654,_0x15ae39(_0x3f55d9);}});}function Od(_0x26aad9,_0x31f402,_0x4a7689,_0x52822d,_0x64db3f,_0x4ab814){gt(_0x26aad9,'transaction\x20on\x20'+_0x31f402);const _0x5169d4={'path':_0x31f402,'update':_0x4a7689,'onComplete':_0x52822d,'status':null,'order':so(),'applyLocally':_0x4ab814,'retryCount':0x0,'unwatcher':_0x64db3f,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3f0b80=Es(_0x26aad9,_0x31f402,void 0x0);_0x5169d4['currentInputSnapshot']=_0x3f0b80;const _0x52704f=_0x5169d4['update'](_0x3f0b80['val']());if(_0x52704f===void 0x0)_0x5169d4['unwatcher'](),_0x5169d4['currentOutputSnapshotRaw']=null,_0x5169d4['currentOutputSnapshotResolved']=null,_0x5169d4['onComplete']&&_0x5169d4['onComplete'](null,!0x1,_0x5169d4['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x52704f,_0x5169d4['path']),_0x5169d4['status']=0x0;const _0x5a86cc=$n(_0x26aad9['transactionQueueTree_'],_0x31f402),_0x3854be=je(_0x5a86cc)||[];_0x3854be['push'](_0x5169d4),gs(_0x5a86cc,_0x3854be);let _0x13ecff;typeof _0x52704f=='object'&&_0x52704f!==null&&Q(_0x52704f,'.priority')?(_0x13ecff=Le(_0x52704f,'.priority'),f(Bt(_0x13ecff),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x13ecff=(Vn(_0x26aad9['serverSyncTree_'],_0x31f402)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2cfb30=Xt(_0x26aad9),_0x2ce8d1=A(_0x52704f,_0x13ecff),_0x38e4ee=fs(_0x2ce8d1,_0x3f0b80,_0x2cfb30);_0x5169d4['currentOutputSnapshotRaw']=_0x2ce8d1,_0x5169d4['currentOutputSnapshotResolved']=_0x38e4ee,_0x5169d4['currentWriteId']=zn(_0x26aad9);const _0x130d35=as(_0x26aad9['serverSyncTree_'],_0x31f402,_0x38e4ee,_0x5169d4['currentWriteId'],_0x5169d4['applyLocally']);V(_0x26aad9['eventQueue_'],_0x31f402,_0x130d35),jn(_0x26aad9,_0x26aad9['transactionQueueTree_']);}}function Es(_0x4b3396,_0x516b6a,_0x42685d){return Vn(_0x4b3396['serverSyncTree_'],_0x516b6a,_0x42685d)||g['EMPTY_NODE'];}function jn(_0xc9421d,_0x483f63=_0xc9421d['transactionQueueTree_']){if(_0x483f63||Kn(_0xc9421d,_0x483f63),je(_0x483f63)){const _0x13a892=da(_0xc9421d,_0x483f63);f(_0x13a892['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x13a892['every'](_0x17698e=>_0x17698e['status']===0x0)&&Dd(_0xc9421d,Qt(_0x483f63),_0x13a892);}else na(_0x483f63)&&Gn(_0x483f63,_0x55a8f1=>{jn(_0xc9421d,_0x55a8f1);});}function Dd(_0x538ba1,_0x38a432,_0xa065da){const _0x16111f=_0xa065da['map'](_0x314574=>_0x314574['currentWriteId']),_0x55a7a4=Es(_0x538ba1,_0x38a432,_0x16111f);let _0x191b31=_0x55a7a4;const _0x47d44e=_0x55a7a4['hash']();for(let _0x28eeed=0x0;_0x28eeed<_0xa065da['length'];_0x28eeed++){const _0x49d642=_0xa065da[_0x28eeed];f(_0x49d642['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x49d642['status']=0x1,_0x49d642['retryCount']++;const _0x4c931f=F(_0x38a432,_0x49d642['path']);_0x191b31=_0x191b31['updateChild'](_0x4c931f,_0x49d642['currentOutputSnapshotRaw']);}const _0x353dc7=_0x191b31['val'](!0x0),_0xa6fe0e=_0x38a432;_0x538ba1['server_']['put'](_0xa6fe0e['toString'](),_0x353dc7,_0x540e0f=>{gt(_0x538ba1,'transaction\x20put\x20response',{'path':_0xa6fe0e['toString'](),'status':_0x540e0f});let _0x363bdc=[];if(_0x540e0f==='ok'){const _0x1352de=[];for(let _0x108996=0x0;_0x108996<_0xa065da['length'];_0x108996++)_0xa065da[_0x108996]['status']=0x2,_0x363bdc=_0x363bdc['concat'](_e(_0x538ba1['serverSyncTree_'],_0xa065da[_0x108996]['currentWriteId'])),_0xa065da[_0x108996]['onComplete']&&_0x1352de['push'](()=>_0xa065da[_0x108996]['onComplete'](null,!0x0,_0xa065da[_0x108996]['currentOutputSnapshotResolved'])),_0xa065da[_0x108996]['unwatcher']();Kn(_0x538ba1,$n(_0x538ba1['transactionQueueTree_'],_0x38a432)),jn(_0x538ba1,_0x538ba1['transactionQueueTree_']),V(_0x538ba1['eventQueue_'],_0x38a432,_0x363bdc);for(let _0xc1ad67=0x0;_0xc1ad67<_0x1352de['length'];_0xc1ad67++)ft(_0x1352de[_0xc1ad67]);}else{if(_0x540e0f==='datastale'){for(let _0x9b7728=0x0;_0x9b7728<_0xa065da['length'];_0x9b7728++)_0xa065da[_0x9b7728]['status']===0x3?_0xa065da[_0x9b7728]['status']=0x4:_0xa065da[_0x9b7728]['status']=0x0;}else{U('transaction\x20at\x20'+_0xa6fe0e['toString']()+'\x20failed:\x20'+_0x540e0f);for(let _0x469ae9=0x0;_0x469ae9<_0xa065da['length'];_0x469ae9++)_0xa065da[_0x469ae9]['status']=0x4,_0xa065da[_0x469ae9]['abortReason']=_0x540e0f;}ct(_0x538ba1,_0x38a432);}},_0x47d44e);}function ct(_0x240718,_0x1ff781){const _0x53b393=ua(_0x240718,_0x1ff781),_0x4c3e0f=Qt(_0x53b393),_0x28274e=da(_0x240718,_0x53b393);return Md(_0x240718,_0x28274e,_0x4c3e0f),_0x4c3e0f;}function Md(_0x413052,_0x4964bc,_0x501cba){if(_0x4964bc['length']===0x0)return;const _0x56a248=[];let _0x26a8f4=[];const _0x1a9986=_0x4964bc['filter'](_0x19333a=>_0x19333a['status']===0x0)['map'](_0x2a2f92=>_0x2a2f92['currentWriteId']);for(let _0x2a1260=0x0;_0x2a1260<_0x4964bc['length'];_0x2a1260++){const _0x4d15ca=_0x4964bc[_0x2a1260],_0x173064=F(_0x501cba,_0x4d15ca['path']);let _0x1f1e65=!0x1,_0x4e774e;if(f(_0x173064!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4d15ca['status']===0x4)_0x1f1e65=!0x0,_0x4e774e=_0x4d15ca['abortReason'],_0x26a8f4=_0x26a8f4['concat'](_e(_0x413052['serverSyncTree_'],_0x4d15ca['currentWriteId'],!0x0));else{if(_0x4d15ca['status']===0x0){if(_0x4d15ca['retryCount']>=yd)_0x1f1e65=!0x0,_0x4e774e='maxretry',_0x26a8f4=_0x26a8f4['concat'](_e(_0x413052['serverSyncTree_'],_0x4d15ca['currentWriteId'],!0x0));else{const _0x44d2c6=Es(_0x413052,_0x4d15ca['path'],_0x1a9986);_0x4d15ca['currentInputSnapshot']=_0x44d2c6;const _0x5b42fb=_0x4964bc[_0x2a1260]['update'](_0x44d2c6['val']());if(_0x5b42fb!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5b42fb,_0x4d15ca['path']);let _0x1559ef=A(_0x5b42fb);typeof _0x5b42fb=='object'&&_0x5b42fb!=null&&Q(_0x5b42fb,'.priority')||(_0x1559ef=_0x1559ef['updatePriority'](_0x44d2c6['getPriority']()));const _0x529348=_0x4d15ca['currentWriteId'],_0x112c3b=Xt(_0x413052),_0x2c788d=fs(_0x1559ef,_0x44d2c6,_0x112c3b);_0x4d15ca['currentOutputSnapshotRaw']=_0x1559ef,_0x4d15ca['currentOutputSnapshotResolved']=_0x2c788d,_0x4d15ca['currentWriteId']=zn(_0x413052),_0x1a9986['splice'](_0x1a9986['indexOf'](_0x529348),0x1),_0x26a8f4=_0x26a8f4['concat'](as(_0x413052['serverSyncTree_'],_0x4d15ca['path'],_0x2c788d,_0x4d15ca['currentWriteId'],_0x4d15ca['applyLocally'])),_0x26a8f4=_0x26a8f4['concat'](_e(_0x413052['serverSyncTree_'],_0x529348,!0x0));}else _0x1f1e65=!0x0,_0x4e774e='nodata',_0x26a8f4=_0x26a8f4['concat'](_e(_0x413052['serverSyncTree_'],_0x4d15ca['currentWriteId'],!0x0));}}}V(_0x413052['eventQueue_'],_0x501cba,_0x26a8f4),_0x26a8f4=[],_0x1f1e65&&(_0x4964bc[_0x2a1260]['status']=0x2,function(_0x55c9d8){setTimeout(_0x55c9d8,Math['floor'](0x0));}(_0x4964bc[_0x2a1260]['unwatcher']),_0x4964bc[_0x2a1260]['onComplete']&&(_0x4e774e==='nodata'?_0x56a248['push'](()=>_0x4964bc[_0x2a1260]['onComplete'](null,!0x1,_0x4964bc[_0x2a1260]['currentInputSnapshot'])):_0x56a248['push'](()=>_0x4964bc[_0x2a1260]['onComplete'](new Error(_0x4e774e),!0x1,null))));}Kn(_0x413052,_0x413052['transactionQueueTree_']);for(let _0x14562c=0x0;_0x14562c<_0x56a248['length'];_0x14562c++)ft(_0x56a248[_0x14562c]);jn(_0x413052,_0x413052['transactionQueueTree_']);}function ua(_0x378ae7,_0x535b7d){let _0x24088d,_0x441792=_0x378ae7['transactionQueueTree_'];for(_0x24088d=y(_0x535b7d);_0x24088d!==null&&je(_0x441792)===void 0x0;)_0x441792=$n(_0x441792,_0x24088d),_0x535b7d=S(_0x535b7d),_0x24088d=y(_0x535b7d);return _0x441792;}function da(_0xc89aff,_0x20a31c){const _0x118d35=[];return fa(_0xc89aff,_0x20a31c,_0x118d35),_0x118d35['sort']((_0x531da6,_0x8b5406)=>_0x531da6['order']-_0x8b5406['order']),_0x118d35;}function fa(_0x4a9960,_0x356ea6,_0x28654e){const _0x46ef0f=je(_0x356ea6);if(_0x46ef0f){for(let _0x435123=0x0;_0x435123<_0x46ef0f['length'];_0x435123++)_0x28654e['push'](_0x46ef0f[_0x435123]);}Gn(_0x356ea6,_0x5c5361=>{fa(_0x4a9960,_0x5c5361,_0x28654e);});}function Kn(_0x274615,_0x1b953f){const _0x568935=je(_0x1b953f);if(_0x568935){let _0x31d499=0x0;for(let _0x30707c=0x0;_0x30707c<_0x568935['length'];_0x30707c++)_0x568935[_0x30707c]['status']!==0x2&&(_0x568935[_0x31d499]=_0x568935[_0x30707c],_0x31d499++);_0x568935['length']=_0x31d499,gs(_0x1b953f,_0x568935['length']>0x0?_0x568935:void 0x0);}Gn(_0x1b953f,_0x246082=>{Kn(_0x274615,_0x246082);});}function Is(_0x4edd39,_0x323f30){const _0x3bca36=Qt(ua(_0x4edd39,_0x323f30)),_0x5e6f4b=$n(_0x4edd39['transactionQueueTree_'],_0x323f30);return ad(_0x5e6f4b,_0x1dd22d=>{di(_0x4edd39,_0x1dd22d);}),di(_0x4edd39,_0x5e6f4b),ia(_0x5e6f4b,_0x488035=>{di(_0x4edd39,_0x488035);}),_0x3bca36;}function di(_0x3ed9e2,_0x38119c){const _0x5abb67=je(_0x38119c);if(_0x5abb67){const _0x34bbaa=[];let _0x1f987d=[],_0x4b1904=-0x1;for(let _0x172372=0x0;_0x172372<_0x5abb67['length'];_0x172372++)_0x5abb67[_0x172372]['status']===0x3||(_0x5abb67[_0x172372]['status']===0x1?(f(_0x4b1904===_0x172372-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4b1904=_0x172372,_0x5abb67[_0x172372]['status']=0x3,_0x5abb67[_0x172372]['abortReason']='set'):(f(_0x5abb67[_0x172372]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5abb67[_0x172372]['unwatcher'](),_0x1f987d=_0x1f987d['concat'](_e(_0x3ed9e2['serverSyncTree_'],_0x5abb67[_0x172372]['currentWriteId'],!0x0)),_0x5abb67[_0x172372]['onComplete']&&_0x34bbaa['push'](_0x5abb67[_0x172372]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4b1904===-0x1?gs(_0x38119c,void 0x0):_0x5abb67['length']=_0x4b1904+0x1,V(_0x3ed9e2['eventQueue_'],Qt(_0x38119c),_0x1f987d);for(let _0x2b4a9a=0x0;_0x2b4a9a<_0x34bbaa['length'];_0x2b4a9a++)ft(_0x34bbaa[_0x2b4a9a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x530b38){let _0x53ccf3='';const _0x38fe4a=_0x530b38['split']('/');for(let _0x191a65=0x0;_0x191a65<_0x38fe4a['length'];_0x191a65++)if(_0x38fe4a[_0x191a65]['length']>0x0){let _0x827472=_0x38fe4a[_0x191a65];try{_0x827472=decodeURIComponent(_0x827472['replace'](/\+/g,'\x20'));}catch{}_0x53ccf3+='/'+_0x827472;}return _0x53ccf3;}function xd(_0x55de26){const _0x1a7672={};_0x55de26['charAt'](0x0)==='?'&&(_0x55de26=_0x55de26['substring'](0x1));for(const _0x4085f3 of _0x55de26['split']('&')){if(_0x4085f3['length']===0x0)continue;const _0x5a4891=_0x4085f3['split']('=');_0x5a4891['length']===0x2?_0x1a7672[decodeURIComponent(_0x5a4891[0x0])]=decodeURIComponent(_0x5a4891[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4085f3+'\x27\x20in\x20query\x20\x27'+_0x55de26+'\x27');}return _0x1a7672;}const vr=function(_0x39bb00,_0x5d0d20){const _0x5f29eb=Fd(_0x39bb00),_0x5e4cb4=_0x5f29eb['namespace'];_0x5f29eb['domain']==='firebase.com'&&ae(_0x5f29eb['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5e4cb4||_0x5e4cb4==='undefined')&&_0x5f29eb['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5f29eb['secure']||$l();const _0x33320c=_0x5f29eb['scheme']==='ws'||_0x5f29eb['scheme']==='wss';return{'repoInfo':new yo(_0x5f29eb['host'],_0x5f29eb['secure'],_0x5e4cb4,_0x33320c,_0x5d0d20,'',_0x5e4cb4!==_0x5f29eb['subdomain']),'path':new C(_0x5f29eb['pathString'])};},Fd=function(_0x2ec048){let _0x2323d6='',_0x34413e='',_0x24839c='',_0xfff42='',_0x205ad4='',_0x1daa2b=!0x0,_0x2e4e1f='https',_0x3364af=0x1bb;if(typeof _0x2ec048=='string'){let _0x46e65d=_0x2ec048['indexOf']('//');_0x46e65d>=0x0&&(_0x2e4e1f=_0x2ec048['substring'](0x0,_0x46e65d-0x1),_0x2ec048=_0x2ec048['substring'](_0x46e65d+0x2));let _0x3e5930=_0x2ec048['indexOf']('/');_0x3e5930===-0x1&&(_0x3e5930=_0x2ec048['length']);let _0x478891=_0x2ec048['indexOf']('?');_0x478891===-0x1&&(_0x478891=_0x2ec048['length']),_0x2323d6=_0x2ec048['substring'](0x0,Math['min'](_0x3e5930,_0x478891)),_0x3e5930<_0x478891&&(_0xfff42=Ld(_0x2ec048['substring'](_0x3e5930,_0x478891)));const _0x1ddfd5=xd(_0x2ec048['substring'](Math['min'](_0x2ec048['length'],_0x478891)));_0x46e65d=_0x2323d6['indexOf'](':'),_0x46e65d>=0x0?(_0x1daa2b=_0x2e4e1f==='https'||_0x2e4e1f==='wss',_0x3364af=parseInt(_0x2323d6['substring'](_0x46e65d+0x1),0xa)):_0x46e65d=_0x2323d6['length'];const _0x47c81d=_0x2323d6['slice'](0x0,_0x46e65d);if(_0x47c81d['toLowerCase']()==='localhost')_0x34413e='localhost';else{if(_0x47c81d['split']('.')['length']<=0x2)_0x34413e=_0x47c81d;else{const _0x3f114e=_0x2323d6['indexOf']('.');_0x24839c=_0x2323d6['substring'](0x0,_0x3f114e)['toLowerCase'](),_0x34413e=_0x2323d6['substring'](_0x3f114e+0x1),_0x205ad4=_0x24839c;}}'ns'in _0x1ddfd5&&(_0x205ad4=_0x1ddfd5['ns']);}return{'host':_0x2323d6,'port':_0x3364af,'domain':_0x34413e,'subdomain':_0x24839c,'secure':_0x1daa2b,'scheme':_0x2e4e1f,'pathString':_0xfff42,'namespace':_0x205ad4};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x55f217=0x0;const _0x11d49f=[];return function(_0x50e54c){const _0x3bcd1a=_0x50e54c===_0x55f217;_0x55f217=_0x50e54c;let _0x4d01f3;const _0x1e4761=new Array(0x8);for(_0x4d01f3=0x7;_0x4d01f3>=0x0;_0x4d01f3--)_0x1e4761[_0x4d01f3]=Er['charAt'](_0x50e54c%0x40),_0x50e54c=Math['floor'](_0x50e54c/0x40);f(_0x50e54c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x36b6b4=_0x1e4761['join']('');if(_0x3bcd1a){for(_0x4d01f3=0xb;_0x4d01f3>=0x0&&_0x11d49f[_0x4d01f3]===0x3f;_0x4d01f3--)_0x11d49f[_0x4d01f3]=0x0;_0x11d49f[_0x4d01f3]++;}else{for(_0x4d01f3=0x0;_0x4d01f3<0xc;_0x4d01f3++)_0x11d49f[_0x4d01f3]=Math['floor'](Math['random']()*0x40);}for(_0x4d01f3=0x0;_0x4d01f3<0xc;_0x4d01f3++)_0x36b6b4+=Er['charAt'](_0x11d49f[_0x4d01f3]);return f(_0x36b6b4['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x36b6b4;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0xeaa454,_0x2bd291,_0x23771e,_0x504843){this['eventType']=_0xeaa454,this['eventRegistration']=_0x2bd291,this['snapshot']=_0x23771e,this['prevName']=_0x504843;}['getPath'](){const _0x4e57bf=this['snapshot']['ref'];return this['eventType']==='value'?_0x4e57bf['_path']:_0x4e57bf['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x55cd64,_0xe033fb,_0x4a7a68){this['eventRegistration']=_0x55cd64,this['error']=_0xe033fb,this['path']=_0x4a7a68;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4b717c,_0x2bd3c7){this['snapshotCallback']=_0x4b717c,this['cancelCallback']=_0x2bd3c7;}['onValue'](_0x5cb34a,_0x3ce3a9){this['snapshotCallback']['call'](null,_0x5cb34a,_0x3ce3a9);}['onCancel'](_0x5c494a){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x5c494a);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1a2646){return this['snapshotCallback']===_0x1a2646['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1a2646['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1a2646['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x278321,_0x376694){this['_repo']=_0x278321,this['_path']=_0x376694;}['cancel'](){const _0x3140a0=new H();return bd(this['_repo'],this['_path'],_0x3140a0['wrapCallback'](()=>{})),_0x3140a0['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x4df0df=new H();return yr(this['_repo'],this['_path'],null,_0x4df0df['wrapCallback'](()=>{})),_0x4df0df['promise'];}['set'](_0x4b909b){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x4b909b,this['_path'],!0x1);const _0x49fc22=new H();return yr(this['_repo'],this['_path'],_0x4b909b,_0x49fc22['wrapCallback'](()=>{})),_0x49fc22['promise'];}['setWithPriority'](_0x3d15c8,_0x5a5c19){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x3d15c8,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x5a5c19);const _0x4c4626=new H();return Rd(this['_repo'],this['_path'],_0x3d15c8,_0x5a5c19,_0x4c4626['wrapCallback'](()=>{})),_0x4c4626['promise'];}['update'](_0x5ab35d){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x5ab35d,this['_path']);const _0x3233a7=new H();return Ad(this['_repo'],this['_path'],_0x5ab35d,_0x3233a7['wrapCallback'](()=>{})),_0x3233a7['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x3a4533,_0x89eeba,_0x12d036,_0x5dd18f){this['_repo']=_0x3a4533,this['_path']=_0x89eeba,this['_queryParams']=_0x12d036,this['_orderByCalled']=_0x5dd18f;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x546abb=sr(this['_queryParams']),_0x632a7f=$i(_0x546abb);return _0x632a7f==='{}'?'default':_0x632a7f;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x11c36c){if(_0x11c36c=P(_0x11c36c),!(_0x11c36c instanceof Ae))return!0x1;const _0x5b8d8c=this['_repo']===_0x11c36c['_repo'],_0x4ea534=Ki(this['_path'],_0x11c36c['_path']),_0x56713a=this['_queryIdentifier']===_0x11c36c['_queryIdentifier'];return _0x5b8d8c&&_0x4ea534&&_0x56713a;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x221123,_0x41367e){if(_0x221123['_orderByCalled']===!0x0)throw new Error(_0x41367e+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4f57f8){let _0x47d505=null,_0x161e82=null;if(_0x4f57f8['hasStart']()&&(_0x47d505=_0x4f57f8['getIndexStartValue']()),_0x4f57f8['hasEnd']()&&(_0x161e82=_0x4f57f8['getIndexEndValue']()),_0x4f57f8['getIndex']()===ve){const _0x4c77e4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x167819='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4f57f8['hasStart']()){if(_0x4f57f8['getIndexStartName']()!==We)throw new Error(_0x4c77e4);if(typeof _0x47d505!='string')throw new Error(_0x167819);}if(_0x4f57f8['hasEnd']()){if(_0x4f57f8['getIndexEndName']()!==we)throw new Error(_0x4c77e4);if(typeof _0x161e82!='string')throw new Error(_0x167819);}}else{if(_0x4f57f8['getIndex']()===R){if(_0x47d505!=null&&!Bt(_0x47d505)||_0x161e82!=null&&!Bt(_0x161e82))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4f57f8['getIndex']()instanceof Ji||_0x4f57f8['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x47d505!=null&&typeof _0x47d505=='object'||_0x161e82!=null&&typeof _0x161e82=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x38122c){if(_0x38122c['hasStart']()&&_0x38122c['hasEnd']()&&_0x38122c['hasLimit']()&&!_0x38122c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x447551,_0x536c9f){super(_0x447551,_0x536c9f,new Zi(),!0x1);}get['parent'](){const _0x3c68b0=Ro(this['_path']);return _0x3c68b0===null?null:new ee(this['_repo'],_0x3c68b0);}get['root'](){let _0x3fbcbf=this;for(;_0x3fbcbf['parent']!==null;)_0x3fbcbf=_0x3fbcbf['parent'];return _0x3fbcbf;}}class lt{constructor(_0x5bd0cf,_0x49893c,_0x5b5527){this['_node']=_0x5bd0cf,this['ref']=_0x49893c,this['_index']=_0x5b5527;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x246ad9){const _0x5ade18=new C(_0x246ad9),_0x443771=Vt(this['ref'],_0x246ad9);return new lt(this['_node']['getChild'](_0x5ade18),_0x443771,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x67a28){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5a8fe1,_0x56a704)=>_0x67a28(new lt(_0x56a704,Vt(this['ref'],_0x5a8fe1),R)));}['hasChild'](_0x2c68e5){const _0x52f914=new C(_0x2c68e5);return!this['_node']['getChild'](_0x52f914)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4d063e,_0x563ec1){return _0x4d063e=P(_0x4d063e),_0x4d063e['_checkNotDeleted']('ref'),_0x563ec1!==void 0x0?Vt(_0x4d063e['_root'],_0x563ec1):_0x4d063e['_root'];}function Vt(_0x58f01a,_0x5e180a){return _0x58f01a=P(_0x58f01a),y(_0x58f01a['_path'])===null?pd('child','path',_0x5e180a):ys('child','path',_0x5e180a),new ee(_0x58f01a['_repo'],k(_0x58f01a['_path'],_0x5e180a));}function v_(_0x30cd29){return _0x30cd29=P(_0x30cd29),new Vd(_0x30cd29['_repo'],_0x30cd29['_path']);}function E_(_0xe6dcd6,_0x164765){_0xe6dcd6=P(_0xe6dcd6),Me('push',_0xe6dcd6['_path']),He('push',_0x164765,_0xe6dcd6['_path'],!0x0);const _0x3087a2=la(_0xe6dcd6['_repo']),_0x59fa6d=Ud(_0x3087a2),_0x161542=Vt(_0xe6dcd6,_0x59fa6d),_0x288089=Vt(_0xe6dcd6,_0x59fa6d);let _0x189e7c;return _0x164765!=null?_0x189e7c=Hd(_0x288089,_0x164765)['then'](()=>_0x288089):_0x189e7c=Promise['resolve'](_0x288089),_0x161542['then']=_0x189e7c['then']['bind'](_0x189e7c),_0x161542['catch']=_0x189e7c['then']['bind'](_0x189e7c,void 0x0),_0x161542;}function Hd(_0x800644,_0x2a6d1e){_0x800644=P(_0x800644),Me('set',_0x800644['_path']),He('set',_0x2a6d1e,_0x800644['_path'],!0x1);const _0x3002e1=new H();return Cd(_0x800644['_repo'],_0x800644['_path'],_0x2a6d1e,null,_0x3002e1['wrapCallback'](()=>{})),_0x3002e1['promise'];}function I_(_0x56ca48,_0x6fa4e2){ra('update',_0x6fa4e2,_0x56ca48['_path']);const _0x4c2102=new H();return Td(_0x56ca48['_repo'],_0x56ca48['_path'],_0x6fa4e2,_0x4c2102['wrapCallback'](()=>{})),_0x4c2102['promise'];}function w_(_0x105fdf){_0x105fdf=P(_0x105fdf);const _0x2d3d21=new pa(()=>{}),_0x5c208e=new Qn(_0x2d3d21);return wd(_0x105fdf['_repo'],_0x105fdf,_0x5c208e)['then'](_0x45e851=>new lt(_0x45e851,new ee(_0x105fdf['_repo'],_0x105fdf['_path']),_0x105fdf['_queryParams']['getIndex']()));}class Qn{constructor(_0x3ea1c1){this['callbackContext']=_0x3ea1c1;}['respondsTo'](_0x34a56d){return _0x34a56d==='value';}['createEvent'](_0x4d9003,_0xa1bd00){const _0x2a8759=_0xa1bd00['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4d9003['snapshotNode'],new ee(_0xa1bd00['_repo'],_0xa1bd00['_path']),_0x2a8759));}['getEventRunner'](_0x1b5a41){return _0x1b5a41['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1b5a41['error']):()=>this['callbackContext']['onValue'](_0x1b5a41['snapshot'],null);}['createCancelEvent'](_0x5a4fb4,_0x5479d2){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5a4fb4,_0x5479d2):null;}['matches'](_0x28a7d8){return _0x28a7d8 instanceof Qn?!_0x28a7d8['callbackContext']||!this['callbackContext']?!0x0:_0x28a7d8['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x3fbcd4,_0x11973c,_0x2f812b,_0x3499d9,_0x553fa7){const _0x3d211b=new pa(_0x2f812b,void 0x0),_0x3593e1=new Qn(_0x3d211b);return kd(_0x3fbcd4['_repo'],_0x3fbcd4,_0x3593e1),()=>Pd(_0x3fbcd4['_repo'],_0x3fbcd4,_0x3593e1);}function Gd(_0x2f0aec,_0x825cb9,_0x3dc8a5,_0x29e53d){return $d(_0x2f0aec,'value',_0x825cb9);}class mt{}class ma extends mt{constructor(_0x12eee3,_0x154b18){super(),this['_value']=_0x12eee3,this['_key']=_0x154b18,this['type']='endAt';}['_apply'](_0x4c0258){He('endAt',this['_value'],_0x4c0258['_path'],!0x0);const _0x3ce99b=Jh(_0x4c0258['_queryParams'],this['_value'],this['_key']);if(ga(_0x3ce99b),Yn(_0x3ce99b),_0x4c0258['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x4c0258['_repo'],_0x4c0258['_path'],_0x3ce99b,_0x4c0258['_orderByCalled']);}}function C_(_0x27db30,_0x56bd7f){return new ma(_0x27db30,_0x56bd7f);}class ya extends mt{constructor(_0x1fae52,_0x1c269b){super(),this['_value']=_0x1fae52,this['_key']=_0x1c269b,this['type']='startAt';}['_apply'](_0x19fc78){He('startAt',this['_value'],_0x19fc78['_path'],!0x0);const _0x523712=Qh(_0x19fc78['_queryParams'],this['_value'],this['_key']);if(ga(_0x523712),Yn(_0x523712),_0x19fc78['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x19fc78['_repo'],_0x19fc78['_path'],_0x523712,_0x19fc78['_orderByCalled']);}}function T_(_0x49805a=null,_0x29d3a3){return new ya(_0x49805a,_0x29d3a3);}class qd extends mt{constructor(_0x18c36e){super(),this['_limit']=_0x18c36e,this['type']='limitToFirst';}['_apply'](_0x4dcaca){if(_0x4dcaca['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4dcaca['_repo'],_0x4dcaca['_path'],Yh(_0x4dcaca['_queryParams'],this['_limit']),_0x4dcaca['_orderByCalled']);}}function S_(_0x5cd7dd){if(Math['floor'](_0x5cd7dd)!==_0x5cd7dd||_0x5cd7dd<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x5cd7dd);}class zd extends mt{constructor(_0x69d56d){super(),this['_path']=_0x69d56d,this['type']='orderByChild';}['_apply'](_0x1a9b65){_a(_0x1a9b65,'orderByChild');const _0x340b7f=new C(this['_path']);if(v(_0x340b7f))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2f330f=new Ji(_0x340b7f),_0x58345f=xo(_0x1a9b65['_queryParams'],_0x2f330f);return Yn(_0x58345f),new Ae(_0x1a9b65['_repo'],_0x1a9b65['_path'],_0x58345f,!0x0);}}function b_(_0x5ac4ba){if(_0x5ac4ba==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5ac4ba==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5ac4ba==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5ac4ba),new zd(_0x5ac4ba);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x15420c){_a(_0x15420c,'orderByKey');const _0x5a50e0=xo(_0x15420c['_queryParams'],ve);return Yn(_0x5a50e0),new Ae(_0x15420c['_repo'],_0x15420c['_path'],_0x5a50e0,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x1b9cba,_0x334e50){super(),this['_value']=_0x1b9cba,this['_key']=_0x334e50,this['type']='equalTo';}['_apply'](_0x3c17ca){if(He('equalTo',this['_value'],_0x3c17ca['_path'],!0x1),_0x3c17ca['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3c17ca['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3c17ca));}}function A_(_0x8cfc55,_0xefbfd5){return new Kd(_0x8cfc55,_0xefbfd5);}function k_(_0xd335d7,..._0x446102){let _0x31052e=P(_0xd335d7);for(const _0x305c1c of _0x446102)_0x31052e=_0x305c1c['_apply'](_0x31052e);return _0x31052e;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x134b29,_0x44021a,_0x4dac09,_0x18084a){const _0x4637aa=_0x44021a['lastIndexOf'](':'),_0x17d44c=_0x44021a['substring'](0x0,_0x4637aa),_0x44d3dd=qt(_0x17d44c);_0x134b29['repoInfo_']=new yo(_0x44021a,_0x44d3dd,_0x134b29['repoInfo_']['namespace'],_0x134b29['repoInfo_']['webSocketOnly'],_0x134b29['repoInfo_']['nodeAdmin'],_0x134b29['repoInfo_']['persistenceKey'],_0x134b29['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4dac09),_0x18084a&&(_0x134b29['authTokenProvider_']=_0x18084a);}function Xd(_0x4278a3,_0x141f3f,_0x67dd5c,_0x4e2f0b,_0x3f2f5f){let _0x2029d3=_0x4e2f0b||_0x4278a3['options']['databaseURL'];_0x2029d3===void 0x0&&(_0x4278a3['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4278a3['options']['projectId']),_0x2029d3=_0x4278a3['options']['projectId']+'-default-rtdb.firebaseio.com');let _0xc6a50c=vr(_0x2029d3,_0x3f2f5f),_0x493181=_0xc6a50c['repoInfo'],_0xe7937;typeof process<'u'&&Bs&&(_0xe7937=Bs[Yd]),_0xe7937?(_0x2029d3='http://'+_0xe7937+'?ns='+_0x493181['namespace'],_0xc6a50c=vr(_0x2029d3,_0x3f2f5f),_0x493181=_0xc6a50c['repoInfo']):_0xc6a50c['repoInfo']['secure'];const _0xc08f3c=new eh(_0x4278a3['name'],_0x4278a3['options'],_0x141f3f);_d('Invalid\x20Firebase\x20Database\x20URL',_0xc6a50c),v(_0xc6a50c['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x233150=ef(_0x493181,_0x4278a3,_0xc08f3c,new Zl(_0x4278a3,_0x67dd5c));return new tf(_0x233150,_0x4278a3);}function Zd(_0x4f9238,_0x33b8bf){const _0x51f2c5=Di[_0x33b8bf];(!_0x51f2c5||_0x51f2c5[_0x4f9238['key']]!==_0x4f9238)&&ae('Database\x20'+_0x33b8bf+'('+_0x4f9238['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4f9238),delete _0x51f2c5[_0x4f9238['key']];}function ef(_0x575ad7,_0x10c12d,_0x3df490,_0x49050d){let _0xcf6bed=Di[_0x10c12d['name']];_0xcf6bed||(_0xcf6bed={},Di[_0x10c12d['name']]=_0xcf6bed);let _0x19b3b2=_0xcf6bed[_0x575ad7['toURLString']()];return _0x19b3b2&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x19b3b2=new vd(_0x575ad7,Qd,_0x3df490,_0x49050d),_0xcf6bed[_0x575ad7['toURLString']()]=_0x19b3b2,_0x19b3b2;}class tf{constructor(_0x289acd,_0x3f4e4d){this['_repoInternal']=_0x289acd,this['app']=_0x3f4e4d,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x49e02e){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x49e02e+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2c7478=Zr(),_0x355bd7){const _0x66e637=Hi(_0x2c7478,'database')['getImmediate']({'identifier':_0x355bd7});if(!_0x66e637['_instanceStarted']){const _0x197cdf=hc('database');_0x197cdf&&nf(_0x66e637,..._0x197cdf);}return _0x66e637;}function nf(_0x23a50a,_0x5d6668,_0x1a42ec,_0x39383d={}){_0x23a50a=P(_0x23a50a),_0x23a50a['_checkNotDeleted']('useEmulator');const _0x42865c=_0x5d6668+':'+_0x1a42ec,_0x29e37f=_0x23a50a['_repoInternal'];if(_0x23a50a['_instanceStarted']){if(_0x42865c===_0x23a50a['_repoInternal']['repoInfo_']['host']&&xe(_0x39383d,_0x29e37f['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2b4e2a;if(_0x29e37f['repoInfo_']['nodeAdmin'])_0x39383d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2b4e2a=new an(an['OWNER']);else{if(_0x39383d['mockUserToken']){const _0x8150bb=typeof _0x39383d['mockUserToken']=='string'?_0x39383d['mockUserToken']:uc(_0x39383d['mockUserToken'],_0x23a50a['app']['options']['projectId']);_0x2b4e2a=new an(_0x8150bb);}}qt(_0x5d6668)&&Qr(_0x5d6668),Jd(_0x29e37f,_0x42865c,_0x39383d,_0x2b4e2a);}function N_(_0x3f4a6c){_0x3f4a6c=P(_0x3f4a6c),_0x3f4a6c['_checkNotDeleted']('goOffline'),ha(_0x3f4a6c['_repo']);}function O_(_0x23a1b1){_0x23a1b1=P(_0x23a1b1),_0x23a1b1['_checkNotDeleted']('goOnline'),Nd(_0x23a1b1['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x5be05a){Ul(dt),st(new Fe('database',(_0x537bf0,{instanceIdentifier:_0x283406})=>{const _0x1eb3d6=_0x537bf0['getProvider']('app')['getImmediate'](),_0x3adf94=_0x537bf0['getProvider']('auth-internal'),_0x1f2f79=_0x537bf0['getProvider']('app-check-internal');return Xd(_0x1eb3d6,_0x3adf94,_0x1f2f79,_0x283406);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x5be05a),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x498aa5,_0x11efe9){this['committed']=_0x498aa5,this['snapshot']=_0x11efe9;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x991558,_0x2907b5,_0x427528){if(_0x991558=P(_0x991558),Me('Reference.transaction',_0x991558['_path']),_0x991558['key']==='.length'||_0x991558['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x991558['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2fd00a=!0x0,_0x58bb40=new H(),_0x1dec89=(_0x43e9e9,_0x4fbfae,_0x4bb80e)=>{let _0x28c692=null;_0x43e9e9?_0x58bb40['reject'](_0x43e9e9):(_0x28c692=new lt(_0x4bb80e,new ee(_0x991558['_repo'],_0x991558['_path']),R),_0x58bb40['resolve'](new of(_0x4fbfae,_0x28c692)));},_0x31c290=Gd(_0x991558,()=>{});return Od(_0x991558['_repo'],_0x991558['_path'],_0x2907b5,_0x1dec89,_0x31c290,_0x2fd00a),_0x58bb40['promise'];}se['prototype']['simpleListen']=function(_0x4d824d,_0x3ef869){this['sendRequest']('q',{'p':_0x4d824d},_0x3ef869);},se['prototype']['echo']=function(_0x563c39,_0x21ed63){this['sendRequest']('echo',{'d':_0x563c39},_0x21ed63);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x20c19a,..._0x99f076){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x20c19a,..._0x99f076);}function cn(_0x2c57c3,..._0x400028){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x2c57c3,..._0x400028);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1dc32c,..._0x121899){throw ws(_0x1dc32c,..._0x121899);}function X(_0x3b7083,..._0x425625){return ws(_0x3b7083,..._0x425625);}function Ia(_0x54f282,_0x45f056,_0x2ece85){const _0x350a2b={...af(),[_0x45f056]:_0x2ece85};return new Gt('auth','Firebase',_0x350a2b)['create'](_0x45f056,{'appName':_0x54f282['name']});}function re(_0x1a1e70){return Ia(_0x1a1e70,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1de492,..._0x5ca02a){if(typeof _0x1de492!='string'){const _0x481ab0=_0x5ca02a[0x0],_0x5f5992=[..._0x5ca02a['slice'](0x1)];return _0x5f5992[0x0]&&(_0x5f5992[0x0]['appName']=_0x1de492['name']),_0x1de492['_errorFactory']['create'](_0x481ab0,..._0x5f5992);}return Ea['create'](_0x1de492,..._0x5ca02a);}function m(_0x553e40,_0x3017c1,..._0x22e5c0){if(!_0x553e40)throw ws(_0x3017c1,..._0x22e5c0);}function ne(_0x1c5ab3){const _0x2927fc='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1c5ab3;throw cn(_0x2927fc),new Error(_0x2927fc);}function ce(_0x5dd763,_0xb41577){_0x5dd763||ne(_0xb41577);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x53dfe5;return typeof self<'u'&&((_0x53dfe5=self['location'])==null?void 0x0:_0x53dfe5['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3283f0;return typeof self<'u'&&((_0x3283f0=self['location'])==null?void 0x0:_0x3283f0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x26cf51=navigator;return _0x26cf51['languages']&&_0x26cf51['languages'][0x0]||_0x26cf51['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x558c80,_0x6832cf){this['shortDelay']=_0x558c80,this['longDelay']=_0x6832cf,ce(_0x6832cf>_0x558c80,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x9158a5,_0x1891ea){ce(_0x9158a5['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4bf74d}=_0x9158a5['emulator'];return _0x1891ea?''+_0x4bf74d+(_0x1891ea['startsWith']('/')?_0x1891ea['slice'](0x1):_0x1891ea):_0x4bf74d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x55150e,_0x5ba82a,_0x31f1a0){this['fetchImpl']=_0x55150e,_0x5ba82a&&(this['headersImpl']=_0x5ba82a),_0x31f1a0&&(this['responseImpl']=_0x31f1a0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x226581,_0x47d654){return _0x226581['tenantId']&&!_0x47d654['tenantId']?{..._0x47d654,'tenantId':_0x226581['tenantId']}:_0x47d654;}async function Pe(_0x124481,_0x237998,_0x382164,_0x405a46,_0x47e234={}){return Ca(_0x124481,_0x47e234,async()=>{let _0x28263d={},_0x1fd4ed={};_0x405a46&&(_0x237998==='GET'?_0x1fd4ed=_0x405a46:_0x28263d={'body':JSON['stringify'](_0x405a46)});const _0x3ac1db=ut({..._0x1fd4ed,'key':_0x124481['config']['apiKey']})['slice'](0x1),_0x4b034e=await _0x124481['_getAdditionalHeaders']();_0x4b034e['Content-Type']='application/json',_0x124481['languageCode']&&(_0x4b034e['X-Firebase-Locale']=_0x124481['languageCode']);const _0x54413d={'method':_0x237998,'headers':_0x4b034e,..._0x28263d};return dc()||(_0x54413d['referrerPolicy']='strict-origin-when-cross-origin'),_0x124481['emulatorConfig']&&qt(_0x124481['emulatorConfig']['host'])&&(_0x54413d['credentials']='include'),wa['fetch']()(await Ta(_0x124481,_0x124481['config']['apiHost'],_0x382164,_0x3ac1db),_0x54413d);});}async function Ca(_0x1098ec,_0x2194dc,_0x3c0d94){_0x1098ec['_canInitEmulator']=!0x1;const _0x184df8={...df,..._0x2194dc};try{const _0x12c529=new gf(_0x1098ec),_0x26f37b=await Promise['race']([_0x3c0d94(),_0x12c529['promise']]);_0x12c529['clearNetworkTimeout']();const _0x50a226=await _0x26f37b['json']();if('needConfirmation'in _0x50a226)throw on(_0x1098ec,'account-exists-with-different-credential',_0x50a226);if(_0x26f37b['ok']&&!('errorMessage'in _0x50a226))return _0x50a226;{const _0x449bf2=_0x26f37b['ok']?_0x50a226['errorMessage']:_0x50a226['error']['message'],[_0x528c01,_0x449054]=_0x449bf2['split']('\x20:\x20');if(_0x528c01==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1098ec,'credential-already-in-use',_0x50a226);if(_0x528c01==='EMAIL_EXISTS')throw on(_0x1098ec,'email-already-in-use',_0x50a226);if(_0x528c01==='USER_DISABLED')throw on(_0x1098ec,'user-disabled',_0x50a226);const _0x93385f=_0x184df8[_0x528c01]||_0x528c01['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x449054)throw Ia(_0x1098ec,_0x93385f,_0x449054);Y(_0x1098ec,_0x93385f);}}catch(_0x14a16f){if(_0x14a16f instanceof Re)throw _0x14a16f;Y(_0x1098ec,'network-request-failed',{'message':String(_0x14a16f)});}}async function en(_0x5acbcd,_0x1fc201,_0x2edf17,_0x10a822,_0x4f5fee={}){const _0x3262f0=await Pe(_0x5acbcd,_0x1fc201,_0x2edf17,_0x10a822,_0x4f5fee);return'mfaPendingCredential'in _0x3262f0&&Y(_0x5acbcd,'multi-factor-auth-required',{'_serverResponse':_0x3262f0}),_0x3262f0;}async function Ta(_0x3218ce,_0x3b499c,_0x12780c,_0x1b5585){const _0x37cda5=''+_0x3b499c+_0x12780c+'?'+_0x1b5585,_0x5523b1=_0x3218ce,_0x4ba08a=_0x5523b1['config']['emulator']?Cs(_0x3218ce['config'],_0x37cda5):_0x3218ce['config']['apiScheme']+'://'+_0x37cda5;return ff['includes'](_0x12780c)&&(await _0x5523b1['_persistenceManagerAvailable'],_0x5523b1['_getPersistenceType']()==='COOKIE')?_0x5523b1['_getPersistence']()['_getFinalTarget'](_0x4ba08a)['toString']():_0x4ba08a;}function _f(_0x3cd4cc){switch(_0x3cd4cc){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x86e26c){this['auth']=_0x86e26c,this['timer']=null,this['promise']=new Promise((_0x291108,_0x7a80e7)=>{this['timer']=setTimeout(()=>_0x7a80e7(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x595f58,_0x2540e2,_0x9edc99){const _0x5cfd81={'appName':_0x595f58['name']};_0x9edc99['email']&&(_0x5cfd81['email']=_0x9edc99['email']),_0x9edc99['phoneNumber']&&(_0x5cfd81['phoneNumber']=_0x9edc99['phoneNumber']);const _0x5123f1=X(_0x595f58,_0x2540e2,_0x5cfd81);return _0x5123f1['customData']['_tokenResponse']=_0x9edc99,_0x5123f1;}function wr(_0x509bfb){return _0x509bfb!==void 0x0&&_0x509bfb['enterprise']!==void 0x0;}class mf{constructor(_0x41b90e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x41b90e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x41b90e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x41b90e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2ae0cd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x228026 of this['recaptchaEnforcementState'])if(_0x228026['provider']&&_0x228026['provider']===_0x2ae0cd)return _f(_0x228026['enforcementState']);return null;}['isProviderEnabled'](_0x1e0a6e){return this['getProviderEnforcementState'](_0x1e0a6e)==='ENFORCE'||this['getProviderEnforcementState'](_0x1e0a6e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x196605,_0x4ccf79){return Pe(_0x196605,'GET','/v2/recaptchaConfig',ke(_0x196605,_0x4ccf79));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x47c5d8,_0x395215){return Pe(_0x47c5d8,'POST','/v1/accounts:delete',_0x395215);}async function Pn(_0x12ee65,_0x4d5efe){return Pe(_0x12ee65,'POST','/v1/accounts:lookup',_0x4d5efe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1c9f06){if(_0x1c9f06)try{const _0xf0ecb6=new Date(Number(_0x1c9f06));if(!isNaN(_0xf0ecb6['getTime']()))return _0xf0ecb6['toUTCString']();}catch{}}async function Ef(_0x29ce5a,_0x3025f5=!0x1){const _0x1d54bd=P(_0x29ce5a),_0x347535=await _0x1d54bd['getIdToken'](_0x3025f5),_0x5089be=Ts(_0x347535);m(_0x5089be&&_0x5089be['exp']&&_0x5089be['auth_time']&&_0x5089be['iat'],_0x1d54bd['auth'],'internal-error');const _0x3fca2f=typeof _0x5089be['firebase']=='object'?_0x5089be['firebase']:void 0x0,_0x24e346=_0x3fca2f==null?void 0x0:_0x3fca2f['sign_in_provider'];return{'claims':_0x5089be,'token':_0x347535,'authTime':Pt(fi(_0x5089be['auth_time'])),'issuedAtTime':Pt(fi(_0x5089be['iat'])),'expirationTime':Pt(fi(_0x5089be['exp'])),'signInProvider':_0x24e346||null,'signInSecondFactor':(_0x3fca2f==null?void 0x0:_0x3fca2f['sign_in_second_factor'])||null};}function fi(_0x490024){return Number(_0x490024)*0x3e8;}function Ts(_0x8eddb5){const [_0x117e03,_0x2c9b4e,_0x4d45ea]=_0x8eddb5['split']('.');if(_0x117e03===void 0x0||_0x2c9b4e===void 0x0||_0x4d45ea===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x567f30=fn(_0x2c9b4e);return _0x567f30?JSON['parse'](_0x567f30):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xc8760c){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xc8760c==null?void 0x0:_0xc8760c['toString']()),null;}}function Cr(_0x253e5d){const _0x221fd2=Ts(_0x253e5d);return m(_0x221fd2,'internal-error'),m(typeof _0x221fd2['exp']<'u','internal-error'),m(typeof _0x221fd2['iat']<'u','internal-error'),Number(_0x221fd2['exp'])-Number(_0x221fd2['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0xa8eb6,_0x5bdf4d,_0x50479b=!0x1){if(_0x50479b)return _0x5bdf4d;try{return await _0x5bdf4d;}catch(_0x31122f){throw _0x31122f instanceof Re&&If(_0x31122f)&&_0xa8eb6['auth']['currentUser']===_0xa8eb6&&await _0xa8eb6['auth']['signOut'](),_0x31122f;}}function If({code:_0x321add}){return _0x321add==='auth/user-disabled'||_0x321add==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x53ba79){this['user']=_0x53ba79,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x346fb1){if(_0x346fb1){const _0x116c67=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x116c67;}else{this['errorBackoff']=0x7530;const _0x480c7b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x480c7b);}}['schedule'](_0x11f4e6=!0x1){if(!this['isRunning'])return;const _0x312e62=this['getInterval'](_0x11f4e6);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x312e62);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xd9856e){(_0xd9856e==null?void 0x0:_0xd9856e['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x145090,_0x57a004){this['createdAt']=_0x145090,this['lastLoginAt']=_0x57a004,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0xfdc62e){this['createdAt']=_0xfdc62e['createdAt'],this['lastLoginAt']=_0xfdc62e['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x3d98d8){var _0x329f9d;const _0x40d608=_0x3d98d8['auth'],_0x5aa126=await _0x3d98d8['getIdToken'](),_0x3d7261=await Ht(_0x3d98d8,Pn(_0x40d608,{'idToken':_0x5aa126}));m(_0x3d7261==null?void 0x0:_0x3d7261['users']['length'],_0x40d608,'internal-error');const _0x5eb251=_0x3d7261['users'][0x0];_0x3d98d8['_notifyReloadListener'](_0x5eb251);const _0x464aac=(_0x329f9d=_0x5eb251['providerUserInfo'])!=null&&_0x329f9d['length']?Sa(_0x5eb251['providerUserInfo']):[],_0x3458b7=Tf(_0x3d98d8['providerData'],_0x464aac),_0x3fe61a=_0x3d98d8['isAnonymous'],_0x16f430=!(_0x3d98d8['email']&&_0x5eb251['passwordHash'])&&!(_0x3458b7!=null&&_0x3458b7['length']),_0x21def1=_0x3fe61a?_0x16f430:!0x1,_0x5cd41e={'uid':_0x5eb251['localId'],'displayName':_0x5eb251['displayName']||null,'photoURL':_0x5eb251['photoUrl']||null,'email':_0x5eb251['email']||null,'emailVerified':_0x5eb251['emailVerified']||!0x1,'phoneNumber':_0x5eb251['phoneNumber']||null,'tenantId':_0x5eb251['tenantId']||null,'providerData':_0x3458b7,'metadata':new Li(_0x5eb251['createdAt'],_0x5eb251['lastLoginAt']),'isAnonymous':_0x21def1};Object['assign'](_0x3d98d8,_0x5cd41e);}async function Cf(_0x12f806){const _0x1a8e07=P(_0x12f806);await Nn(_0x1a8e07),await _0x1a8e07['auth']['_persistUserIfCurrent'](_0x1a8e07),_0x1a8e07['auth']['_notifyListenersIfCurrent'](_0x1a8e07);}function Tf(_0x37149b,_0x13f570){return[..._0x37149b['filter'](_0x3c658f=>!_0x13f570['some'](_0xb9013c=>_0xb9013c['providerId']===_0x3c658f['providerId'])),..._0x13f570];}function Sa(_0x16cfda){return _0x16cfda['map'](({providerId:_0x1bdbc3,..._0x479171})=>({'providerId':_0x1bdbc3,'uid':_0x479171['rawId']||'','displayName':_0x479171['displayName']||null,'email':_0x479171['email']||null,'phoneNumber':_0x479171['phoneNumber']||null,'photoURL':_0x479171['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x203704,_0x2131a9){const _0x37d19e=await Ca(_0x203704,{},async()=>{const _0x11083f=ut({'grant_type':'refresh_token','refresh_token':_0x2131a9})['slice'](0x1),{tokenApiHost:_0xd17513,apiKey:_0x23bfec}=_0x203704['config'],_0x4c0087=await Ta(_0x203704,_0xd17513,'/v1/token','key='+_0x23bfec),_0xbab7b4=await _0x203704['_getAdditionalHeaders']();_0xbab7b4['Content-Type']='application/x-www-form-urlencoded';const _0x20c1c0={'method':'POST','headers':_0xbab7b4,'body':_0x11083f};return _0x203704['emulatorConfig']&&qt(_0x203704['emulatorConfig']['host'])&&(_0x20c1c0['credentials']='include'),wa['fetch']()(_0x4c0087,_0x20c1c0);});return{'accessToken':_0x37d19e['access_token'],'expiresIn':_0x37d19e['expires_in'],'refreshToken':_0x37d19e['refresh_token']};}async function bf(_0xf93f51,_0x18d1f6){return Pe(_0xf93f51,'POST','/v2/accounts:revokeToken',ke(_0xf93f51,_0x18d1f6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x54a2a6){m(_0x54a2a6['idToken'],'internal-error'),m(typeof _0x54a2a6['idToken']<'u','internal-error'),m(typeof _0x54a2a6['refreshToken']<'u','internal-error');const _0x1c6675='expiresIn'in _0x54a2a6&&typeof _0x54a2a6['expiresIn']<'u'?Number(_0x54a2a6['expiresIn']):Cr(_0x54a2a6['idToken']);this['updateTokensAndExpiration'](_0x54a2a6['idToken'],_0x54a2a6['refreshToken'],_0x1c6675);}['updateFromIdToken'](_0x2444da){m(_0x2444da['length']!==0x0,'internal-error');const _0x2b7fa2=Cr(_0x2444da);this['updateTokensAndExpiration'](_0x2444da,null,_0x2b7fa2);}async['getToken'](_0x289a38,_0x33d1d3=!0x1){return!_0x33d1d3&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x289a38,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x289a38,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x51cd9d,_0x5a11b6){const {accessToken:_0x5c46ae,refreshToken:_0x2b7f77,expiresIn:_0x13193d}=await Sf(_0x51cd9d,_0x5a11b6);this['updateTokensAndExpiration'](_0x5c46ae,_0x2b7f77,Number(_0x13193d));}['updateTokensAndExpiration'](_0x4b14c6,_0x2e4256,_0x96e52a){this['refreshToken']=_0x2e4256||null,this['accessToken']=_0x4b14c6||null,this['expirationTime']=Date['now']()+_0x96e52a*0x3e8;}static['fromJSON'](_0x5cc996,_0xef0e8d){const {refreshToken:_0x198178,accessToken:_0x544fbd,expirationTime:_0x3353a0}=_0xef0e8d,_0x41bb41=new et();return _0x198178&&(m(typeof _0x198178=='string','internal-error',{'appName':_0x5cc996}),_0x41bb41['refreshToken']=_0x198178),_0x544fbd&&(m(typeof _0x544fbd=='string','internal-error',{'appName':_0x5cc996}),_0x41bb41['accessToken']=_0x544fbd),_0x3353a0&&(m(typeof _0x3353a0=='number','internal-error',{'appName':_0x5cc996}),_0x41bb41['expirationTime']=_0x3353a0),_0x41bb41;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x33a51e){this['accessToken']=_0x33a51e['accessToken'],this['refreshToken']=_0x33a51e['refreshToken'],this['expirationTime']=_0x33a51e['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3a0a2c,_0x57813d){m(typeof _0x3a0a2c=='string'||typeof _0x3a0a2c>'u','internal-error',{'appName':_0x57813d});}class j{constructor({uid:_0x1991a3,auth:_0x57845f,stsTokenManager:_0x1e6442,..._0x705886}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1991a3,this['auth']=_0x57845f,this['stsTokenManager']=_0x1e6442,this['accessToken']=_0x1e6442['accessToken'],this['displayName']=_0x705886['displayName']||null,this['email']=_0x705886['email']||null,this['emailVerified']=_0x705886['emailVerified']||!0x1,this['phoneNumber']=_0x705886['phoneNumber']||null,this['photoURL']=_0x705886['photoURL']||null,this['isAnonymous']=_0x705886['isAnonymous']||!0x1,this['tenantId']=_0x705886['tenantId']||null,this['providerData']=_0x705886['providerData']?[..._0x705886['providerData']]:[],this['metadata']=new Li(_0x705886['createdAt']||void 0x0,_0x705886['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4c1b6e){const _0x1da596=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x4c1b6e));return m(_0x1da596,this['auth'],'internal-error'),this['accessToken']!==_0x1da596&&(this['accessToken']=_0x1da596,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1da596;}['getIdTokenResult'](_0x4ebf2b){return Ef(this,_0x4ebf2b);}['reload'](){return Cf(this);}['_assign'](_0x185878){this!==_0x185878&&(m(this['uid']===_0x185878['uid'],this['auth'],'internal-error'),this['displayName']=_0x185878['displayName'],this['photoURL']=_0x185878['photoURL'],this['email']=_0x185878['email'],this['emailVerified']=_0x185878['emailVerified'],this['phoneNumber']=_0x185878['phoneNumber'],this['isAnonymous']=_0x185878['isAnonymous'],this['tenantId']=_0x185878['tenantId'],this['providerData']=_0x185878['providerData']['map'](_0x1342ad=>({..._0x1342ad})),this['metadata']['_copy'](_0x185878['metadata']),this['stsTokenManager']['_assign'](_0x185878['stsTokenManager']));}['_clone'](_0x5616cf){const _0x290865=new j({...this,'auth':_0x5616cf,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x290865['metadata']['_copy'](this['metadata']),_0x290865;}['_onReload'](_0x2fef7b){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2fef7b,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x39fd92){this['reloadListener']?this['reloadListener'](_0x39fd92):this['reloadUserInfo']=_0x39fd92;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x591c65,_0x4dfd11=!0x1){let _0x19926f=!0x1;_0x591c65['idToken']&&_0x591c65['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x591c65),_0x19926f=!0x0),_0x4dfd11&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x19926f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x456c8a=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x456c8a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x182d08=>({..._0x182d08})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x525bf9,_0x2ab73c){const _0x583986=_0x2ab73c['displayName']??void 0x0,_0x3d90fd=_0x2ab73c['email']??void 0x0,_0x49a12d=_0x2ab73c['phoneNumber']??void 0x0,_0x316be7=_0x2ab73c['photoURL']??void 0x0,_0x2f794a=_0x2ab73c['tenantId']??void 0x0,_0x334089=_0x2ab73c['_redirectEventId']??void 0x0,_0x1d134e=_0x2ab73c['createdAt']??void 0x0,_0xb6932a=_0x2ab73c['lastLoginAt']??void 0x0,{uid:_0xd16853,emailVerified:_0x4c3740,isAnonymous:_0x51f922,providerData:_0x630df2,stsTokenManager:_0x345596}=_0x2ab73c;m(_0xd16853&&_0x345596,_0x525bf9,'internal-error');const _0x52af6a=et['fromJSON'](this['name'],_0x345596);m(typeof _0xd16853=='string',_0x525bf9,'internal-error'),le(_0x583986,_0x525bf9['name']),le(_0x3d90fd,_0x525bf9['name']),m(typeof _0x4c3740=='boolean',_0x525bf9,'internal-error'),m(typeof _0x51f922=='boolean',_0x525bf9,'internal-error'),le(_0x49a12d,_0x525bf9['name']),le(_0x316be7,_0x525bf9['name']),le(_0x2f794a,_0x525bf9['name']),le(_0x334089,_0x525bf9['name']),le(_0x1d134e,_0x525bf9['name']),le(_0xb6932a,_0x525bf9['name']);const _0x1ff72b=new j({'uid':_0xd16853,'auth':_0x525bf9,'email':_0x3d90fd,'emailVerified':_0x4c3740,'displayName':_0x583986,'isAnonymous':_0x51f922,'photoURL':_0x316be7,'phoneNumber':_0x49a12d,'tenantId':_0x2f794a,'stsTokenManager':_0x52af6a,'createdAt':_0x1d134e,'lastLoginAt':_0xb6932a});return _0x630df2&&Array['isArray'](_0x630df2)&&(_0x1ff72b['providerData']=_0x630df2['map'](_0x4ccfca=>({..._0x4ccfca}))),_0x334089&&(_0x1ff72b['_redirectEventId']=_0x334089),_0x1ff72b;}static async['_fromIdTokenResponse'](_0x42411f,_0x171211,_0x527489=!0x1){const _0x5a07b2=new et();_0x5a07b2['updateFromServerResponse'](_0x171211);const _0x453cf7=new j({'uid':_0x171211['localId'],'auth':_0x42411f,'stsTokenManager':_0x5a07b2,'isAnonymous':_0x527489});return await Nn(_0x453cf7),_0x453cf7;}static async['_fromGetAccountInfoResponse'](_0x119e6f,_0x11d1ac,_0x5e4b0e){const _0x2940ad=_0x11d1ac['users'][0x0];m(_0x2940ad['localId']!==void 0x0,'internal-error');const _0xcfc612=_0x2940ad['providerUserInfo']!==void 0x0?Sa(_0x2940ad['providerUserInfo']):[],_0x3ca489=!(_0x2940ad['email']&&_0x2940ad['passwordHash'])&&!(_0xcfc612!=null&&_0xcfc612['length']),_0x59e5e6=new et();_0x59e5e6['updateFromIdToken'](_0x5e4b0e);const _0x3c8e9b=new j({'uid':_0x2940ad['localId'],'auth':_0x119e6f,'stsTokenManager':_0x59e5e6,'isAnonymous':_0x3ca489}),_0x3b48ad={'uid':_0x2940ad['localId'],'displayName':_0x2940ad['displayName']||null,'photoURL':_0x2940ad['photoUrl']||null,'email':_0x2940ad['email']||null,'emailVerified':_0x2940ad['emailVerified']||!0x1,'phoneNumber':_0x2940ad['phoneNumber']||null,'tenantId':_0x2940ad['tenantId']||null,'providerData':_0xcfc612,'metadata':new Li(_0x2940ad['createdAt'],_0x2940ad['lastLoginAt']),'isAnonymous':!(_0x2940ad['email']&&_0x2940ad['passwordHash'])&&!(_0xcfc612!=null&&_0xcfc612['length'])};return Object['assign'](_0x3c8e9b,_0x3b48ad),_0x3c8e9b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1453ec){ce(_0x1453ec instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4daad4=Tr['get'](_0x1453ec);return _0x4daad4?(ce(_0x4daad4 instanceof _0x1453ec,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4daad4):(_0x4daad4=new _0x1453ec(),Tr['set'](_0x1453ec,_0x4daad4),_0x4daad4);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2931ec,_0x1fc8e8){this['storage'][_0x2931ec]=_0x1fc8e8;}async['_get'](_0x4b1e14){const _0x4aa006=this['storage'][_0x4b1e14];return _0x4aa006===void 0x0?null:_0x4aa006;}async['_remove'](_0x75c9d2){delete this['storage'][_0x75c9d2];}['_addListener'](_0x33e373,_0x29dfae){}['_removeListener'](_0x51e170,_0x539ff4){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x480028,_0x41485e,_0x4f6283){return'firebase:'+_0x480028+':'+_0x41485e+':'+_0x4f6283;}class tt{constructor(_0x158106,_0x12f78c,_0x263bdf){this['persistence']=_0x158106,this['auth']=_0x12f78c,this['userKey']=_0x263bdf;const {config:_0x2e14ec,name:_0x1b66c6}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2e14ec['apiKey'],_0x1b66c6),this['fullPersistenceKey']=ln('persistence',_0x2e14ec['apiKey'],_0x1b66c6),this['boundEventHandler']=_0x12f78c['_onStorageEvent']['bind'](_0x12f78c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x10103c){return this['persistence']['_set'](this['fullUserKey'],_0x10103c['toJSON']());}async['getCurrentUser'](){const _0x3e9cbe=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3e9cbe)return null;if(typeof _0x3e9cbe=='string'){const _0x2c1b1e=await Pn(this['auth'],{'idToken':_0x3e9cbe})['catch'](()=>{});return _0x2c1b1e?j['_fromGetAccountInfoResponse'](this['auth'],_0x2c1b1e,_0x3e9cbe):null;}return j['_fromJSON'](this['auth'],_0x3e9cbe);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4bcdd9){if(this['persistence']===_0x4bcdd9)return;const _0x1c29b2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4bcdd9,_0x1c29b2)return this['setCurrentUser'](_0x1c29b2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x292419,_0x40d907,_0x263657='authUser'){if(!_0x40d907['length'])return new tt(ie(Sr),_0x292419,_0x263657);const _0x15694f=(await Promise['all'](_0x40d907['map'](async _0x1fbd4e=>{if(await _0x1fbd4e['_isAvailable']())return _0x1fbd4e;})))['filter'](_0x3c3b6b=>_0x3c3b6b);let _0x41937d=_0x15694f[0x0]||ie(Sr);const _0x27a1af=ln(_0x263657,_0x292419['config']['apiKey'],_0x292419['name']);let _0x5bea95=null;for(const _0x4a9451 of _0x40d907)try{const _0x245076=await _0x4a9451['_get'](_0x27a1af);if(_0x245076){let _0x1a5fae;if(typeof _0x245076=='string'){const _0x2a7d85=await Pn(_0x292419,{'idToken':_0x245076})['catch'](()=>{});if(!_0x2a7d85)break;_0x1a5fae=await j['_fromGetAccountInfoResponse'](_0x292419,_0x2a7d85,_0x245076);}else _0x1a5fae=j['_fromJSON'](_0x292419,_0x245076);_0x4a9451!==_0x41937d&&(_0x5bea95=_0x1a5fae),_0x41937d=_0x4a9451;break;}}catch{}const _0x4e2e95=_0x15694f['filter'](_0x347741=>_0x347741['_shouldAllowMigration']);return!_0x41937d['_shouldAllowMigration']||!_0x4e2e95['length']?new tt(_0x41937d,_0x292419,_0x263657):(_0x41937d=_0x4e2e95[0x0],_0x5bea95&&await _0x41937d['_set'](_0x27a1af,_0x5bea95['toJSON']()),await Promise['all'](_0x40d907['map'](async _0x2b3f66=>{if(_0x2b3f66!==_0x41937d)try{await _0x2b3f66['_remove'](_0x27a1af);}catch{}})),new tt(_0x41937d,_0x292419,_0x263657));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x39d2e7){const _0x596fa7=_0x39d2e7['toLowerCase']();if(_0x596fa7['includes']('opera/')||_0x596fa7['includes']('opr/')||_0x596fa7['includes']('opios/'))return'Opera';if(Pa(_0x596fa7))return'IEMobile';if(_0x596fa7['includes']('msie')||_0x596fa7['includes']('trident/'))return'IE';if(_0x596fa7['includes']('edge/'))return'Edge';if(Ra(_0x596fa7))return'Firefox';if(_0x596fa7['includes']('silk/'))return'Silk';if(Oa(_0x596fa7))return'Blackberry';if(Da(_0x596fa7))return'Webos';if(Aa(_0x596fa7))return'Safari';if((_0x596fa7['includes']('chrome/')||ka(_0x596fa7))&&!_0x596fa7['includes']('edge/'))return'Chrome';if(Na(_0x596fa7))return'Android';{const _0x337dc6=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1b156d=_0x39d2e7['match'](_0x337dc6);if((_0x1b156d==null?void 0x0:_0x1b156d['length'])===0x2)return _0x1b156d[0x1];}return'Other';}function Ra(_0x8796f7=W()){return/firefox\//i['test'](_0x8796f7);}function Aa(_0x156802=W()){const _0x5b2422=_0x156802['toLowerCase']();return _0x5b2422['includes']('safari/')&&!_0x5b2422['includes']('chrome/')&&!_0x5b2422['includes']('crios/')&&!_0x5b2422['includes']('android');}function ka(_0x39a262=W()){return/crios\//i['test'](_0x39a262);}function Pa(_0x272862=W()){return/iemobile/i['test'](_0x272862);}function Na(_0x67d2a1=W()){return/android/i['test'](_0x67d2a1);}function Oa(_0x44f937=W()){return/blackberry/i['test'](_0x44f937);}function Da(_0xab86ae=W()){return/webos/i['test'](_0xab86ae);}function Ss(_0x5cf72e=W()){return/iphone|ipad|ipod/i['test'](_0x5cf72e)||/macintosh/i['test'](_0x5cf72e)&&/mobile/i['test'](_0x5cf72e);}function Rf(_0x5cca04=W()){var _0x1d6441;return Ss(_0x5cca04)&&!!((_0x1d6441=window['navigator'])!=null&&_0x1d6441['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0xd513f5=W()){return Ss(_0xd513f5)||Na(_0xd513f5)||Da(_0xd513f5)||Oa(_0xd513f5)||/windows phone/i['test'](_0xd513f5)||Pa(_0xd513f5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x47ec5e,_0x7d1522=[]){let _0x54713b;switch(_0x47ec5e){case'Browser':_0x54713b=br(W());break;case'Worker':_0x54713b=br(W())+'-'+_0x47ec5e;break;default:_0x54713b=_0x47ec5e;}const _0x1c39b7=_0x7d1522['length']?_0x7d1522['join'](','):'FirebaseCore-web';return _0x54713b+'/JsCore/'+dt+'/'+_0x1c39b7;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4bf27f){this['auth']=_0x4bf27f,this['queue']=[];}['pushCallback'](_0x1bab93,_0x11d5ae){const _0x2069c2=_0x343381=>new Promise((_0x51ddca,_0x3363e7)=>{try{const _0x309e62=_0x1bab93(_0x343381);_0x51ddca(_0x309e62);}catch(_0x435ed4){_0x3363e7(_0x435ed4);}});_0x2069c2['onAbort']=_0x11d5ae,this['queue']['push'](_0x2069c2);const _0x1a9624=this['queue']['length']-0x1;return()=>{this['queue'][_0x1a9624]=()=>Promise['resolve']();};}async['runMiddleware'](_0x897d9a){if(this['auth']['currentUser']===_0x897d9a)return;const _0x29d0b3=[];try{for(const _0x42e3b9 of this['queue'])await _0x42e3b9(_0x897d9a),_0x42e3b9['onAbort']&&_0x29d0b3['push'](_0x42e3b9['onAbort']);}catch(_0x30db08){_0x29d0b3['reverse']();for(const _0x1525cb of _0x29d0b3)try{_0x1525cb();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x30db08==null?void 0x0:_0x30db08['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x19a76b,_0x1a40d6={}){return Pe(_0x19a76b,'GET','/v2/passwordPolicy',ke(_0x19a76b,_0x1a40d6));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3eb6f7){var _0x12176f;const _0x15b3a9=_0x3eb6f7['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x15b3a9['minPasswordLength']??Nf,_0x15b3a9['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x15b3a9['maxPasswordLength']),_0x15b3a9['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x15b3a9['containsLowercaseCharacter']),_0x15b3a9['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x15b3a9['containsUppercaseCharacter']),_0x15b3a9['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x15b3a9['containsNumericCharacter']),_0x15b3a9['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x15b3a9['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3eb6f7['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x12176f=_0x3eb6f7['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x12176f['join'](''))??'',this['forceUpgradeOnSignin']=_0x3eb6f7['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3eb6f7['schemaVersion'];}['validatePassword'](_0x52eb2d){const _0x4fe2e3={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x52eb2d,_0x4fe2e3),this['validatePasswordCharacterOptions'](_0x52eb2d,_0x4fe2e3),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['meetsMinPasswordLength']??!0x0),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['meetsMaxPasswordLength']??!0x0),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['containsLowercaseLetter']??!0x0),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['containsUppercaseLetter']??!0x0),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['containsNumericCharacter']??!0x0),_0x4fe2e3['isValid']&&(_0x4fe2e3['isValid']=_0x4fe2e3['containsNonAlphanumericCharacter']??!0x0),_0x4fe2e3;}['validatePasswordLengthOptions'](_0x15b528,_0x2dfa23){const _0x19d93e=this['customStrengthOptions']['minPasswordLength'],_0x10bc07=this['customStrengthOptions']['maxPasswordLength'];_0x19d93e&&(_0x2dfa23['meetsMinPasswordLength']=_0x15b528['length']>=_0x19d93e),_0x10bc07&&(_0x2dfa23['meetsMaxPasswordLength']=_0x15b528['length']<=_0x10bc07);}['validatePasswordCharacterOptions'](_0x4ab8fb,_0x44826b){this['updatePasswordCharacterOptionsStatuses'](_0x44826b,!0x1,!0x1,!0x1,!0x1);let _0x200156;for(let _0x3e035c=0x0;_0x3e035c<_0x4ab8fb['length'];_0x3e035c++)_0x200156=_0x4ab8fb['charAt'](_0x3e035c),this['updatePasswordCharacterOptionsStatuses'](_0x44826b,_0x200156>='a'&&_0x200156<='z',_0x200156>='A'&&_0x200156<='Z',_0x200156>='0'&&_0x200156<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x200156));}['updatePasswordCharacterOptionsStatuses'](_0x22f7c2,_0x370114,_0x416cc0,_0x29decd,_0x287cef){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x22f7c2['containsLowercaseLetter']||(_0x22f7c2['containsLowercaseLetter']=_0x370114)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x22f7c2['containsUppercaseLetter']||(_0x22f7c2['containsUppercaseLetter']=_0x416cc0)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x22f7c2['containsNumericCharacter']||(_0x22f7c2['containsNumericCharacter']=_0x29decd)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x22f7c2['containsNonAlphanumericCharacter']||(_0x22f7c2['containsNonAlphanumericCharacter']=_0x287cef));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x385919,_0x4ef4d4,_0x1fa428,_0x29526c){this['app']=_0x385919,this['heartbeatServiceProvider']=_0x4ef4d4,this['appCheckServiceProvider']=_0x1fa428,this['config']=_0x29526c,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x385919['name'],this['clientVersion']=_0x29526c['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5bf0ac=>this['_resolvePersistenceManagerAvailable']=_0x5bf0ac);}['_initializeWithPersistence'](_0x2c8e11,_0x21fe6b){return _0x21fe6b&&(this['_popupRedirectResolver']=ie(_0x21fe6b)),this['_initializationPromise']=this['queue'](async()=>{var _0x1d6a0e,_0x5421f8,_0x1eaf69;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2c8e11),(_0x1d6a0e=this['_resolvePersistenceManagerAvailable'])==null||_0x1d6a0e['call'](this),!this['_deleted'])){if((_0x5421f8=this['_popupRedirectResolver'])!=null&&_0x5421f8['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x21fe6b),this['lastNotifiedUid']=((_0x1eaf69=this['currentUser'])==null?void 0x0:_0x1eaf69['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xc85e33=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xc85e33)){if(this['currentUser']&&_0xc85e33&&this['currentUser']['uid']===_0xc85e33['uid']){this['_currentUser']['_assign'](_0xc85e33),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xc85e33,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2d79a2){try{const _0x9b6a07=await Pn(this,{'idToken':_0x2d79a2}),_0x3f91b9=await j['_fromGetAccountInfoResponse'](this,_0x9b6a07,_0x2d79a2);await this['directlySetCurrentUser'](_0x3f91b9);}catch(_0x1131ed){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1131ed),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xdbeefd){var _0x330dbc;if($(this['app'])){const _0x1ab47d=this['app']['settings']['authIdToken'];return _0x1ab47d?new Promise(_0x490540=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1ab47d)['then'](_0x490540,_0x490540));}):this['directlySetCurrentUser'](null);}const _0x412a6c=await this['assertedPersistence']['getCurrentUser']();let _0x389eef=_0x412a6c,_0x53c970=!0x1;if(_0xdbeefd&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1646f0=(_0x330dbc=this['redirectUser'])==null?void 0x0:_0x330dbc['_redirectEventId'],_0x30fdc9=_0x389eef==null?void 0x0:_0x389eef['_redirectEventId'],_0x43712c=await this['tryRedirectSignIn'](_0xdbeefd);(!_0x1646f0||_0x1646f0===_0x30fdc9)&&(_0x43712c!=null&&_0x43712c['user'])&&(_0x389eef=_0x43712c['user'],_0x53c970=!0x0);}if(!_0x389eef)return this['directlySetCurrentUser'](null);if(!_0x389eef['_redirectEventId']){if(_0x53c970)try{await this['beforeStateQueue']['runMiddleware'](_0x389eef);}catch(_0x1eb6c9){_0x389eef=_0x412a6c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1eb6c9));}return _0x389eef?this['reloadAndSetCurrentUserOrClear'](_0x389eef):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x389eef['_redirectEventId']?this['directlySetCurrentUser'](_0x389eef):this['reloadAndSetCurrentUserOrClear'](_0x389eef);}async['tryRedirectSignIn'](_0x3647c5){let _0xc4e863=null;try{_0xc4e863=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3647c5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xc4e863;}async['reloadAndSetCurrentUserOrClear'](_0x395774){try{await Nn(_0x395774);}catch(_0x2adee1){if((_0x2adee1==null?void 0x0:_0x2adee1['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x395774);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x254dfd){if($(this['app']))return Promise['reject'](re(this));const _0x22404e=_0x254dfd?P(_0x254dfd):null;return _0x22404e&&m(_0x22404e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x22404e&&_0x22404e['_clone'](this));}async['_updateCurrentUser'](_0x129810,_0x25cc36=!0x1){if(!this['_deleted'])return _0x129810&&m(this['tenantId']===_0x129810['tenantId'],this,'tenant-id-mismatch'),_0x25cc36||await this['beforeStateQueue']['runMiddleware'](_0x129810),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x129810),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x816dc4){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x816dc4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x407fa3){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x312ff8=this['_getPasswordPolicyInternal']();return _0x312ff8['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x312ff8['validatePassword'](_0x407fa3);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x20294c=await Pf(this),_0x5f0904=new Of(_0x20294c);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5f0904:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5f0904;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1f8ad6){this['_errorFactory']=new Gt('auth','Firebase',_0x1f8ad6());}['onAuthStateChanged'](_0x123724,_0x19eef2,_0x264f4c){return this['registerStateListener'](this['authStateSubscription'],_0x123724,_0x19eef2,_0x264f4c);}['beforeAuthStateChanged'](_0x3a6e96,_0x312c5b){return this['beforeStateQueue']['pushCallback'](_0x3a6e96,_0x312c5b);}['onIdTokenChanged'](_0x29251c,_0x126b82,_0x1d527c){return this['registerStateListener'](this['idTokenSubscription'],_0x29251c,_0x126b82,_0x1d527c);}['authStateReady'](){return new Promise((_0x2185c5,_0x3ad0af)=>{if(this['currentUser'])_0x2185c5();else{const _0x361773=this['onAuthStateChanged'](()=>{_0x361773(),_0x2185c5();},_0x3ad0af);}});}async['revokeAccessToken'](_0x4c8385){if(this['currentUser']){const _0x38de19=await this['currentUser']['getIdToken'](),_0x3bdd3f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4c8385,'idToken':_0x38de19};this['tenantId']!=null&&(_0x3bdd3f['tenantId']=this['tenantId']),await bf(this,_0x3bdd3f);}}['toJSON'](){var _0x190a6a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x190a6a=this['_currentUser'])==null?void 0x0:_0x190a6a['toJSON']()};}async['_setRedirectUser'](_0x5b28e5,_0x1b0d1c){const _0x6ba541=await this['getOrInitRedirectPersistenceManager'](_0x1b0d1c);return _0x5b28e5===null?_0x6ba541['removeCurrentUser']():_0x6ba541['setCurrentUser'](_0x5b28e5);}async['getOrInitRedirectPersistenceManager'](_0x28ccfe){if(!this['redirectPersistenceManager']){const _0x43de0e=_0x28ccfe&&ie(_0x28ccfe)||this['_popupRedirectResolver'];m(_0x43de0e,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x43de0e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x384c88){var _0x5bc7b5,_0x968e75;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5bc7b5=this['_currentUser'])==null?void 0x0:_0x5bc7b5['_redirectEventId'])===_0x384c88?this['_currentUser']:((_0x968e75=this['redirectUser'])==null?void 0x0:_0x968e75['_redirectEventId'])===_0x384c88?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2657b2){if(_0x2657b2===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2657b2));}['_notifyListenersIfCurrent'](_0x103254){_0x103254===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x4a6c7a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x41f0db=((_0x4a6c7a=this['currentUser'])==null?void 0x0:_0x4a6c7a['uid'])??null;this['lastNotifiedUid']!==_0x41f0db&&(this['lastNotifiedUid']=_0x41f0db,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x9e1b55,_0x13ce20,_0x4ecf29,_0x53967a){if(this['_deleted'])return()=>{};const _0x10d16d=typeof _0x13ce20=='function'?_0x13ce20:_0x13ce20['next']['bind'](_0x13ce20);let _0x174aee=!0x1;const _0xd98c94=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xd98c94,this,'internal-error'),_0xd98c94['then'](()=>{_0x174aee||_0x10d16d(this['currentUser']);}),typeof _0x13ce20=='function'){const _0x3e5334=_0x9e1b55['addObserver'](_0x13ce20,_0x4ecf29,_0x53967a);return()=>{_0x174aee=!0x0,_0x3e5334();};}else{const _0x2d4391=_0x9e1b55['addObserver'](_0x13ce20);return()=>{_0x174aee=!0x0,_0x2d4391();};}}async['directlySetCurrentUser'](_0x560e53){this['currentUser']&&this['currentUser']!==_0x560e53&&this['_currentUser']['_stopProactiveRefresh'](),_0x560e53&&this['isProactiveRefreshEnabled']&&_0x560e53['_startProactiveRefresh'](),this['currentUser']=_0x560e53,_0x560e53?await this['assertedPersistence']['setCurrentUser'](_0x560e53):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3d7a0a){return this['operations']=this['operations']['then'](_0x3d7a0a,_0x3d7a0a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x15e333){!_0x15e333||this['frameworks']['includes'](_0x15e333)||(this['frameworks']['push'](_0x15e333),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x238231;const _0x2a8798={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2a8798['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5d89bb=await((_0x238231=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x238231['getHeartbeatsHeader']());_0x5d89bb&&(_0x2a8798['X-Firebase-Client']=_0x5d89bb);const _0x74005e=await this['_getAppCheckToken']();return _0x74005e&&(_0x2a8798['X-Firebase-AppCheck']=_0x74005e),_0x2a8798;}async['_getAppCheckToken'](){var _0x1cd86d;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x543a1c=await((_0x1cd86d=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1cd86d['getToken']());return _0x543a1c!=null&&_0x543a1c['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x543a1c['error']),_0x543a1c==null?void 0x0:_0x543a1c['token'];}}function Ke(_0x53385c){return P(_0x53385c);}class Rr{constructor(_0x3d23b6){this['auth']=_0x3d23b6,this['observer']=null,this['addObserver']=Tc(_0x2f9a62=>this['observer']=_0x2f9a62);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x35e5eb){Jn=_0x35e5eb;}function xa(_0x2ba523){return Jn['loadJS'](_0x2ba523);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x16b52f){return'__'+_0x16b52f+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x321761){_0x321761();}['execute'](_0x504261,_0x4e2aee){return Promise['resolve']('token');}['render'](_0x5f522e,_0x83e00e){return'';}}class Wf{['ready'](_0x24f091){_0x24f091();}['execute'](_0x2b626a,_0x2b5ace){return Promise['resolve']('token');}['render'](_0xbbcebe,_0x5b360b){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x116413){this['type']=Bf,this['auth']=Ke(_0x116413);}async['verify'](_0x196b73='verify',_0x39f67c=!0x1){async function _0x649f40(_0x58f381){if(!_0x39f67c){if(_0x58f381['tenantId']==null&&_0x58f381['_agentRecaptchaConfig']!=null)return _0x58f381['_agentRecaptchaConfig']['siteKey'];if(_0x58f381['tenantId']!=null&&_0x58f381['_tenantRecaptchaConfigs'][_0x58f381['tenantId']]!==void 0x0)return _0x58f381['_tenantRecaptchaConfigs'][_0x58f381['tenantId']]['siteKey'];}return new Promise(async(_0x59b976,_0x562c91)=>{yf(_0x58f381,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x19d4b8=>{if(_0x19d4b8['recaptchaKey']===void 0x0)_0x562c91(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5c493b=new mf(_0x19d4b8);return _0x58f381['tenantId']==null?_0x58f381['_agentRecaptchaConfig']=_0x5c493b:_0x58f381['_tenantRecaptchaConfigs'][_0x58f381['tenantId']]=_0x5c493b,_0x59b976(_0x5c493b['siteKey']);}})['catch'](_0x1821db=>{_0x562c91(_0x1821db);});});}function _0x45b476(_0x175857,_0x4182a4,_0x50c85a){const _0x29764b=window['grecaptcha'];wr(_0x29764b)?_0x29764b['enterprise']['ready'](()=>{_0x29764b['enterprise']['execute'](_0x175857,{'action':_0x196b73})['then'](_0x3665e9=>{_0x4182a4(_0x3665e9);})['catch'](()=>{_0x4182a4(Fa);});}):_0x50c85a(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x54455d,_0x444c3c)=>{_0x649f40(this['auth'])['then'](async _0x4b2839=>{if(!_0x39f67c&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x45b476(_0x4b2839,_0x54455d,_0x444c3c);else{if(typeof window>'u'){_0x444c3c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1fdc85=Lf();_0x1fdc85['length']!==0x0&&(_0x1fdc85+=_0x4b2839+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x395f3a;(_0x395f3a=he['scriptInjectionDeferred'])==null||_0x395f3a['resolve']();},xa(_0x1fdc85)['then'](()=>{var _0x54f712;return(_0x54f712=he['scriptInjectionDeferred'])==null?void 0x0:_0x54f712['promise'];})['then'](()=>{_0x45b476(_0x4b2839,_0x54455d,_0x444c3c);})['catch'](_0x3936d3=>{_0x444c3c(_0x3936d3);});}})['catch'](_0xa7f777=>{_0x444c3c(_0xa7f777);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x15e1d3,_0x2fa3f4,_0x3ccb50,_0x51390c=!0x1,_0x395a1f=!0x1){const _0x520577=new he(_0x15e1d3);let _0x3e379f;if(_0x395a1f)_0x3e379f=Fa;else try{_0x3e379f=await _0x520577['verify'](_0x3ccb50);}catch{_0x3e379f=await _0x520577['verify'](_0x3ccb50,!0x0);}const _0x48bfc0={..._0x2fa3f4};if(_0x3ccb50==='mfaSmsEnrollment'||_0x3ccb50==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x48bfc0){const _0xd06fc9=_0x48bfc0['phoneEnrollmentInfo']['phoneNumber'],_0x2236e2=_0x48bfc0['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x48bfc0,{'phoneEnrollmentInfo':{'phoneNumber':_0xd06fc9,'recaptchaToken':_0x2236e2,'captchaResponse':_0x3e379f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x48bfc0){const _0x583079=_0x48bfc0['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x48bfc0,{'phoneSignInInfo':{'recaptchaToken':_0x583079,'captchaResponse':_0x3e379f,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x48bfc0;}return _0x51390c?Object['assign'](_0x48bfc0,{'captchaResp':_0x3e379f}):Object['assign'](_0x48bfc0,{'captchaResponse':_0x3e379f}),Object['assign'](_0x48bfc0,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x48bfc0,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x48bfc0;}async function xi(_0xff902,_0x42de71,_0xe242f0,_0x31d848,_0x1a3f88){var _0x4541bc;if((_0x4541bc=_0xff902['_getRecaptchaConfig']())!=null&&_0x4541bc['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x593c19=await kr(_0xff902,_0x42de71,_0xe242f0,_0xe242f0==='getOobCode');return _0x31d848(_0xff902,_0x593c19);}else return _0x31d848(_0xff902,_0x42de71)['catch'](async _0x23b10a=>{if(_0x23b10a['code']==='auth/missing-recaptcha-token'){console['log'](_0xe242f0+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3795c6=await kr(_0xff902,_0x42de71,_0xe242f0,_0xe242f0==='getOobCode');return _0x31d848(_0xff902,_0x3795c6);}else return Promise['reject'](_0x23b10a);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x35ca4e,_0x2ee955){const _0x2958fb=Hi(_0x35ca4e,'auth');if(_0x2958fb['isInitialized']()){const _0x40cc4b=_0x2958fb['getImmediate'](),_0x57b66a=_0x2958fb['getOptions']();if(xe(_0x57b66a,_0x2ee955??{}))return _0x40cc4b;Y(_0x40cc4b,'already-initialized');}return _0x2958fb['initialize']({'options':_0x2ee955});}function Hf(_0x3f61b5,_0x1aed85){const _0x10b88e=(_0x1aed85==null?void 0x0:_0x1aed85['persistence'])||[],_0x48f4ab=(Array['isArray'](_0x10b88e)?_0x10b88e:[_0x10b88e])['map'](ie);_0x1aed85!=null&&_0x1aed85['errorMap']&&_0x3f61b5['_updateErrorMap'](_0x1aed85['errorMap']),_0x3f61b5['_initializeWithPersistence'](_0x48f4ab,_0x1aed85==null?void 0x0:_0x1aed85['popupRedirectResolver']);}function $f(_0x482f4f,_0x3d513d,_0x1b9875){const _0x4b66d6=Ke(_0x482f4f);m(/^https?:\/\//['test'](_0x3d513d),_0x4b66d6,'invalid-emulator-scheme');const _0x43edf5=!0x1,_0x43f4bf=Ua(_0x3d513d),{host:_0x425f46,port:_0x15acb0}=Gf(_0x3d513d),_0x1a9727=_0x15acb0===null?'':':'+_0x15acb0,_0x285c77={'url':_0x43f4bf+'//'+_0x425f46+_0x1a9727+'/'},_0x37fdca=Object['freeze']({'host':_0x425f46,'port':_0x15acb0,'protocol':_0x43f4bf['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x43edf5})});if(!_0x4b66d6['_canInitEmulator']){m(_0x4b66d6['config']['emulator']&&_0x4b66d6['emulatorConfig'],_0x4b66d6,'emulator-config-failed'),m(xe(_0x285c77,_0x4b66d6['config']['emulator'])&&xe(_0x37fdca,_0x4b66d6['emulatorConfig']),_0x4b66d6,'emulator-config-failed');return;}_0x4b66d6['config']['emulator']=_0x285c77,_0x4b66d6['emulatorConfig']=_0x37fdca,_0x4b66d6['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x425f46)?Qr(_0x43f4bf+'//'+_0x425f46+_0x1a9727):qf();}function Ua(_0x55a8d0){const _0x593ace=_0x55a8d0['indexOf'](':');return _0x593ace<0x0?'':_0x55a8d0['substr'](0x0,_0x593ace+0x1);}function Gf(_0x451c55){const _0x424d6d=Ua(_0x451c55),_0x3a1e00=/(\/\/)?([^?#/]+)/['exec'](_0x451c55['substr'](_0x424d6d['length']));if(!_0x3a1e00)return{'host':'','port':null};const _0x39bfad=_0x3a1e00[0x2]['split']('@')['pop']()||'',_0xc27772=/^(\[[^\]]+\])(:|$)/['exec'](_0x39bfad);if(_0xc27772){const _0x585c8b=_0xc27772[0x1];return{'host':_0x585c8b,'port':Pr(_0x39bfad['substr'](_0x585c8b['length']+0x1))};}else{const [_0xab0274,_0x1ab11f]=_0x39bfad['split'](':');return{'host':_0xab0274,'port':Pr(_0x1ab11f)};}}function Pr(_0xdf0cf9){if(!_0xdf0cf9)return null;const _0x2b0853=Number(_0xdf0cf9);return isNaN(_0x2b0853)?null:_0x2b0853;}function qf(){function _0x3a3153(){const _0xff5d3d=document['createElement']('p'),_0x357553=_0xff5d3d['style'];_0xff5d3d['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x357553['position']='fixed',_0x357553['width']='100%',_0x357553['backgroundColor']='#ffffff',_0x357553['border']='.1em\x20solid\x20#000000',_0x357553['color']='#b50000',_0x357553['bottom']='0px',_0x357553['left']='0px',_0x357553['margin']='0px',_0x357553['zIndex']='10000',_0x357553['textAlign']='center',_0xff5d3d['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xff5d3d);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x3a3153):_0x3a3153());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x4c547a,_0x17b38b){this['providerId']=_0x4c547a,this['signInMethod']=_0x17b38b;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x5d9780){return ne('not\x20implemented');}['_linkToIdToken'](_0x2804a0,_0x1c0e47){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x31903d){return ne('not\x20implemented');}}async function zf(_0x2fb03f,_0x9bff4e){return Pe(_0x2fb03f,'POST','/v1/accounts:signUp',_0x9bff4e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x16e8f0,_0x312a82){return en(_0x16e8f0,'POST','/v1/accounts:signInWithPassword',ke(_0x16e8f0,_0x312a82));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5a67c4,_0x32e387){return en(_0x5a67c4,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5a67c4,_0x32e387));}async function Yf(_0x1b8b83,_0x56717b){return en(_0x1b8b83,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1b8b83,_0x56717b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x49db7e,_0x2b295e,_0x1fa51d,_0x4df699=null){super('password',_0x1fa51d),this['_email']=_0x49db7e,this['_password']=_0x2b295e,this['_tenantId']=_0x4df699;}static['_fromEmailAndPassword'](_0x343fa2,_0x12da1d){return new $t(_0x343fa2,_0x12da1d,'password');}static['_fromEmailAndCode'](_0x101903,_0x3ad28a,_0x13dc31=null){return new $t(_0x101903,_0x3ad28a,'emailLink',_0x13dc31);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3b3b7b){const _0x37177c=typeof _0x3b3b7b=='string'?JSON['parse'](_0x3b3b7b):_0x3b3b7b;if(_0x37177c!=null&&_0x37177c['email']&&(_0x37177c!=null&&_0x37177c['password'])){if(_0x37177c['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x37177c['email'],_0x37177c['password']);if(_0x37177c['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x37177c['email'],_0x37177c['password'],_0x37177c['tenantId']);}return null;}async['_getIdTokenResponse'](_0x242f78){switch(this['signInMethod']){case'password':const _0x391f3e={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x242f78,_0x391f3e,'signInWithPassword',jf);case'emailLink':return Kf(_0x242f78,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x242f78,'internal-error');}}async['_linkToIdToken'](_0x34ca24,_0x55da5a){switch(this['signInMethod']){case'password':const _0x4cbb84={'idToken':_0x55da5a,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x34ca24,_0x4cbb84,'signUpPassword',zf);case'emailLink':return Yf(_0x34ca24,{'idToken':_0x55da5a,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x34ca24,'internal-error');}}['_getReauthenticationResolver'](_0x53a2cb){return this['_getIdTokenResponse'](_0x53a2cb);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x4398c1,_0x2efeb5){return en(_0x4398c1,'POST','/v1/accounts:signInWithIdp',ke(_0x4398c1,_0x2efeb5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x160ef1){const _0x573819=new $e(_0x160ef1['providerId'],_0x160ef1['signInMethod']);return _0x160ef1['idToken']||_0x160ef1['accessToken']?(_0x160ef1['idToken']&&(_0x573819['idToken']=_0x160ef1['idToken']),_0x160ef1['accessToken']&&(_0x573819['accessToken']=_0x160ef1['accessToken']),_0x160ef1['nonce']&&!_0x160ef1['pendingToken']&&(_0x573819['nonce']=_0x160ef1['nonce']),_0x160ef1['pendingToken']&&(_0x573819['pendingToken']=_0x160ef1['pendingToken'])):_0x160ef1['oauthToken']&&_0x160ef1['oauthTokenSecret']?(_0x573819['accessToken']=_0x160ef1['oauthToken'],_0x573819['secret']=_0x160ef1['oauthTokenSecret']):Y('argument-error'),_0x573819;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1a26c7){const _0x1f7ce5=typeof _0x1a26c7=='string'?JSON['parse'](_0x1a26c7):_0x1a26c7,{providerId:_0x24f6d2,signInMethod:_0x760d9a,..._0xf6c11}=_0x1f7ce5;if(!_0x24f6d2||!_0x760d9a)return null;const _0x2872f2=new $e(_0x24f6d2,_0x760d9a);return _0x2872f2['idToken']=_0xf6c11['idToken']||void 0x0,_0x2872f2['accessToken']=_0xf6c11['accessToken']||void 0x0,_0x2872f2['secret']=_0xf6c11['secret'],_0x2872f2['nonce']=_0xf6c11['nonce'],_0x2872f2['pendingToken']=_0xf6c11['pendingToken']||null,_0x2872f2;}['_getIdTokenResponse'](_0x1037a1){const _0x5590ac=this['buildRequest']();return nt(_0x1037a1,_0x5590ac);}['_linkToIdToken'](_0x503053,_0x123aab){const _0x342e2b=this['buildRequest']();return _0x342e2b['idToken']=_0x123aab,nt(_0x503053,_0x342e2b);}['_getReauthenticationResolver'](_0x3a667f){const _0x1f2489=this['buildRequest']();return _0x1f2489['autoCreate']=!0x1,nt(_0x3a667f,_0x1f2489);}['buildRequest'](){const _0x136f5b={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x136f5b['pendingToken']=this['pendingToken'];else{const _0x158c56={};this['idToken']&&(_0x158c56['id_token']=this['idToken']),this['accessToken']&&(_0x158c56['access_token']=this['accessToken']),this['secret']&&(_0x158c56['oauth_token_secret']=this['secret']),_0x158c56['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x158c56['nonce']=this['nonce']),_0x136f5b['postBody']=ut(_0x158c56);}return _0x136f5b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x58c422){switch(_0x58c422){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x21623f){const _0x149723=Ct(Tt(_0x21623f))['link'],_0x10874d=_0x149723?Ct(Tt(_0x149723))['deep_link_id']:null,_0x877bd4=Ct(Tt(_0x21623f))['deep_link_id'];return(_0x877bd4?Ct(Tt(_0x877bd4))['link']:null)||_0x877bd4||_0x10874d||_0x149723||_0x21623f;}class Rs{constructor(_0x2ea784){const _0x50686c=Ct(Tt(_0x2ea784)),_0xeaa722=_0x50686c['apiKey']??null,_0x4f7970=_0x50686c['oobCode']??null,_0x4084a8=Jf(_0x50686c['mode']??null);m(_0xeaa722&&_0x4f7970&&_0x4084a8,'argument-error'),this['apiKey']=_0xeaa722,this['operation']=_0x4084a8,this['code']=_0x4f7970,this['continueUrl']=_0x50686c['continueUrl']??null,this['languageCode']=_0x50686c['lang']??null,this['tenantId']=_0x50686c['tenantId']??null;}static['parseLink'](_0x471126){const _0x5abded=Xf(_0x471126);try{return new Rs(_0x5abded);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x18bcc1,_0x282b2b){return $t['_fromEmailAndPassword'](_0x18bcc1,_0x282b2b);}static['credentialWithLink'](_0x27c71f,_0x1901f9){const _0x360ae4=Rs['parseLink'](_0x1901f9);return m(_0x360ae4,'argument-error'),$t['_fromEmailAndCode'](_0x27c71f,_0x360ae4['code'],_0x360ae4['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x5b0a68){this['providerId']=_0x5b0a68,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x457985){this['defaultLanguageCode']=_0x457985;}['setCustomParameters'](_0x6eacea){return this['customParameters']=_0x6eacea,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x235623){return this['scopes']['includes'](_0x235623)||this['scopes']['push'](_0x235623),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5c83ed){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5c83ed});}static['credentialFromResult'](_0x5e408f){return ue['credentialFromTaggedObject'](_0x5e408f);}static['credentialFromError'](_0x1ed4a7){return ue['credentialFromTaggedObject'](_0x1ed4a7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x547a81}){if(!_0x547a81||!('oauthAccessToken'in _0x547a81)||!_0x547a81['oauthAccessToken'])return null;try{return ue['credential'](_0x547a81['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xbb01de,_0x4c737b){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xbb01de,'accessToken':_0x4c737b});}static['credentialFromResult'](_0x2e6f20){return de['credentialFromTaggedObject'](_0x2e6f20);}static['credentialFromError'](_0x526a60){return de['credentialFromTaggedObject'](_0x526a60['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30c508}){if(!_0x30c508)return null;const {oauthIdToken:_0x1703af,oauthAccessToken:_0x1047e5}=_0x30c508;if(!_0x1703af&&!_0x1047e5)return null;try{return de['credential'](_0x1703af,_0x1047e5);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x21dba2){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x21dba2});}static['credentialFromResult'](_0x5d4b6e){return fe['credentialFromTaggedObject'](_0x5d4b6e);}static['credentialFromError'](_0x47fad7){return fe['credentialFromTaggedObject'](_0x47fad7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47cb1b}){if(!_0x47cb1b||!('oauthAccessToken'in _0x47cb1b)||!_0x47cb1b['oauthAccessToken'])return null;try{return fe['credential'](_0x47cb1b['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x58d5d7,_0x390770){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x58d5d7,'oauthTokenSecret':_0x390770});}static['credentialFromResult'](_0x512110){return pe['credentialFromTaggedObject'](_0x512110);}static['credentialFromError'](_0x21314c){return pe['credentialFromTaggedObject'](_0x21314c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x25d16b}){if(!_0x25d16b)return null;const {oauthAccessToken:_0x3ce23f,oauthTokenSecret:_0x324c2c}=_0x25d16b;if(!_0x3ce23f||!_0x324c2c)return null;try{return pe['credential'](_0x3ce23f,_0x324c2c);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x1f0b41,_0x51b81e){return en(_0x1f0b41,'POST','/v1/accounts:signUp',ke(_0x1f0b41,_0x51b81e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5c9f3e){this['user']=_0x5c9f3e['user'],this['providerId']=_0x5c9f3e['providerId'],this['_tokenResponse']=_0x5c9f3e['_tokenResponse'],this['operationType']=_0x5c9f3e['operationType'];}static async['_fromIdTokenResponse'](_0x3db25f,_0x666cdf,_0x475994,_0x22998b=!0x1){const _0x4bfaf3=await j['_fromIdTokenResponse'](_0x3db25f,_0x475994,_0x22998b),_0x5397e5=Nr(_0x475994);return new Ge({'user':_0x4bfaf3,'providerId':_0x5397e5,'_tokenResponse':_0x475994,'operationType':_0x666cdf});}static async['_forOperation'](_0x5bdfe8,_0xfe7b45,_0x22a783){await _0x5bdfe8['_updateTokensIfNecessary'](_0x22a783,!0x0);const _0x4cffbb=Nr(_0x22a783);return new Ge({'user':_0x5bdfe8,'providerId':_0x4cffbb,'_tokenResponse':_0x22a783,'operationType':_0xfe7b45});}}function Nr(_0x4cf2ce){return _0x4cf2ce['providerId']?_0x4cf2ce['providerId']:'phoneNumber'in _0x4cf2ce?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x111d7d,_0x170b23,_0x3151ad,_0xb3174c){super(_0x170b23['code'],_0x170b23['message']),this['operationType']=_0x3151ad,this['user']=_0xb3174c,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x111d7d['name'],'tenantId':_0x111d7d['tenantId']??void 0x0,'_serverResponse':_0x170b23['customData']['_serverResponse'],'operationType':_0x3151ad};}static['_fromErrorAndOperation'](_0x5aed06,_0x57b024,_0x40c24f,_0x2b9242){return new On(_0x5aed06,_0x57b024,_0x40c24f,_0x2b9242);}}function Ba(_0x232de3,_0xdb91c8,_0x14f5fb,_0x3e5d35){return(_0xdb91c8==='reauthenticate'?_0x14f5fb['_getReauthenticationResolver'](_0x232de3):_0x14f5fb['_getIdTokenResponse'](_0x232de3))['catch'](_0xcae9d2=>{throw _0xcae9d2['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x232de3,_0xcae9d2,_0xdb91c8,_0x3e5d35):_0xcae9d2;});}async function ep(_0x6a1d35,_0x2a5032,_0xed561c=!0x1){const _0x3ac80e=await Ht(_0x6a1d35,_0x2a5032['_linkToIdToken'](_0x6a1d35['auth'],await _0x6a1d35['getIdToken']()),_0xed561c);return Ge['_forOperation'](_0x6a1d35,'link',_0x3ac80e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x59877e,_0x3677f5,_0x3ed846=!0x1){const {auth:_0x1aa7be}=_0x59877e;if($(_0x1aa7be['app']))return Promise['reject'](re(_0x1aa7be));const _0x1088d0='reauthenticate';try{const _0x3356f5=await Ht(_0x59877e,Ba(_0x1aa7be,_0x1088d0,_0x3677f5,_0x59877e),_0x3ed846);m(_0x3356f5['idToken'],_0x1aa7be,'internal-error');const _0x41cde8=Ts(_0x3356f5['idToken']);m(_0x41cde8,_0x1aa7be,'internal-error');const {sub:_0x3f7ba6}=_0x41cde8;return m(_0x59877e['uid']===_0x3f7ba6,_0x1aa7be,'user-mismatch'),Ge['_forOperation'](_0x59877e,_0x1088d0,_0x3356f5);}catch(_0xcbaeb1){throw(_0xcbaeb1==null?void 0x0:_0xcbaeb1['code'])==='auth/user-not-found'&&Y(_0x1aa7be,'user-mismatch'),_0xcbaeb1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x1a88f2,_0x296913,_0x20f971=!0x1){if($(_0x1a88f2['app']))return Promise['reject'](re(_0x1a88f2));const _0x1e2f42='signIn',_0x21584b=await Ba(_0x1a88f2,_0x1e2f42,_0x296913),_0x81fa59=await Ge['_fromIdTokenResponse'](_0x1a88f2,_0x1e2f42,_0x21584b);return _0x20f971||await _0x1a88f2['_updateCurrentUser'](_0x81fa59['user']),_0x81fa59;}async function np(_0x32fb69,_0x3959db){return Va(Ke(_0x32fb69),_0x3959db);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2cab78){const _0x1717a0=Ke(_0x2cab78);_0x1717a0['_getPasswordPolicyInternal']()&&await _0x1717a0['_updatePasswordPolicy']();}async function L_(_0x5be973,_0x439b50,_0x4a8f77){if($(_0x5be973['app']))return Promise['reject'](re(_0x5be973));const _0x513c3d=Ke(_0x5be973),_0x31d52c=await xi(_0x513c3d,{'returnSecureToken':!0x0,'email':_0x439b50,'password':_0x4a8f77,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x76b00e=>{throw _0x76b00e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5be973),_0x76b00e;}),_0xb2654b=await Ge['_fromIdTokenResponse'](_0x513c3d,'signIn',_0x31d52c);return await _0x513c3d['_updateCurrentUser'](_0xb2654b['user']),_0xb2654b;}function x_(_0x2e90b6,_0x663510,_0x376d52){return $(_0x2e90b6['app'])?Promise['reject'](re(_0x2e90b6)):np(P(_0x2e90b6),yt['credential'](_0x663510,_0x376d52))['catch'](async _0x4043a0=>{throw _0x4043a0['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2e90b6),_0x4043a0;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x20d22a,_0x4577e1){return P(_0x20d22a)['setPersistence'](_0x4577e1);}function ip(_0x33297e,_0x3ad2e1,_0x530f77,_0x2b67ee){return P(_0x33297e)['onIdTokenChanged'](_0x3ad2e1,_0x530f77,_0x2b67ee);}function sp(_0x2c0048,_0x31e507,_0x354b20){return P(_0x2c0048)['beforeAuthStateChanged'](_0x31e507,_0x354b20);}function U_(_0x4c351b,_0x29e0fe,_0x221116,_0x1b3cb6){return P(_0x4c351b)['onAuthStateChanged'](_0x29e0fe,_0x221116,_0x1b3cb6);}function W_(_0x291d68){return P(_0x291d68)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2e7db6,_0x5b1cd3){this['storageRetriever']=_0x2e7db6,this['type']=_0x5b1cd3;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x427420,_0x52cdd4){return this['storage']['setItem'](_0x427420,JSON['stringify'](_0x52cdd4)),Promise['resolve']();}['_get'](_0x2d11a3){const _0x2bf5af=this['storage']['getItem'](_0x2d11a3);return Promise['resolve'](_0x2bf5af?JSON['parse'](_0x2bf5af):null);}['_remove'](_0x345a1f){return this['storage']['removeItem'](_0x345a1f),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x499b03,_0x4efb8e)=>this['onStorageEvent'](_0x499b03,_0x4efb8e),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4359ca){for(const _0x3f88cd of Object['keys'](this['listeners'])){const _0x5eecaa=this['storage']['getItem'](_0x3f88cd),_0x5e5baa=this['localCache'][_0x3f88cd];_0x5eecaa!==_0x5e5baa&&_0x4359ca(_0x3f88cd,_0x5e5baa,_0x5eecaa);}}['onStorageEvent'](_0xd22eb9,_0x15c8f6=!0x1){if(!_0xd22eb9['key']){this['forAllChangedKeys']((_0x275619,_0x4981b4,_0xb9cdd0)=>{this['notifyListeners'](_0x275619,_0xb9cdd0);});return;}const _0x117253=_0xd22eb9['key'];_0x15c8f6?this['detachListener']():this['stopPolling']();const _0x2c16a2=()=>{const _0x583f95=this['storage']['getItem'](_0x117253);!_0x15c8f6&&this['localCache'][_0x117253]===_0x583f95||this['notifyListeners'](_0x117253,_0x583f95);},_0x1f5a79=this['storage']['getItem'](_0x117253);Af()&&_0x1f5a79!==_0xd22eb9['newValue']&&_0xd22eb9['newValue']!==_0xd22eb9['oldValue']?setTimeout(_0x2c16a2,op):_0x2c16a2();}['notifyListeners'](_0x513387,_0x54e9ae){this['localCache'][_0x513387]=_0x54e9ae;const _0x1424e6=this['listeners'][_0x513387];if(_0x1424e6){for(const _0xa6e1d7 of Array['from'](_0x1424e6))_0xa6e1d7(_0x54e9ae&&JSON['parse'](_0x54e9ae));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5982de,_0x3ba903,_0x1a8a66)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5982de,'oldValue':_0x3ba903,'newValue':_0x1a8a66}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4c2357,_0x3b5765){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4c2357]||(this['listeners'][_0x4c2357]=new Set(),this['localCache'][_0x4c2357]=this['storage']['getItem'](_0x4c2357)),this['listeners'][_0x4c2357]['add'](_0x3b5765);}['_removeListener'](_0x2274c3,_0x4e13b1){this['listeners'][_0x2274c3]&&(this['listeners'][_0x2274c3]['delete'](_0x4e13b1),this['listeners'][_0x2274c3]['size']===0x0&&delete this['listeners'][_0x2274c3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1b54ec,_0x4f8db5){await super['_set'](_0x1b54ec,_0x4f8db5),this['localCache'][_0x1b54ec]=JSON['stringify'](_0x4f8db5);}async['_get'](_0xdab1fd){const _0x47d61b=await super['_get'](_0xdab1fd);return this['localCache'][_0xdab1fd]=JSON['stringify'](_0x47d61b),_0x47d61b;}async['_remove'](_0x3dcaa6){await super['_remove'](_0x3dcaa6),delete this['localCache'][_0x3dcaa6];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1b8ba7,_0x8df7a0){}['_removeListener'](_0x493998,_0x35f500){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x263a8b){return Promise['all'](_0x263a8b['map'](async _0xcf424f=>{try{return{'fulfilled':!0x0,'value':await _0xcf424f};}catch(_0x19a3c9){return{'fulfilled':!0x1,'reason':_0x19a3c9};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x26c9ae){this['eventTarget']=_0x26c9ae,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3df733){const _0x4cf2b8=this['receivers']['find'](_0x4ad2c9=>_0x4ad2c9['isListeningto'](_0x3df733));if(_0x4cf2b8)return _0x4cf2b8;const _0x325365=new Xn(_0x3df733);return this['receivers']['push'](_0x325365),_0x325365;}['isListeningto'](_0xd77660){return this['eventTarget']===_0xd77660;}async['handleEvent'](_0x209a4f){const _0x497837=_0x209a4f,{eventId:_0x32517a,eventType:_0x44f0a9,data:_0x51e327}=_0x497837['data'],_0x56bdde=this['handlersMap'][_0x44f0a9];if(!(_0x56bdde!=null&&_0x56bdde['size']))return;_0x497837['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x32517a,'eventType':_0x44f0a9});const _0x42931d=Array['from'](_0x56bdde)['map'](async _0x426611=>_0x426611(_0x497837['origin'],_0x51e327)),_0x1bda0e=await cp(_0x42931d);_0x497837['ports'][0x0]['postMessage']({'status':'done','eventId':_0x32517a,'eventType':_0x44f0a9,'response':_0x1bda0e});}['_subscribe'](_0x21afd8,_0x1fa27a){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x21afd8]||(this['handlersMap'][_0x21afd8]=new Set()),this['handlersMap'][_0x21afd8]['add'](_0x1fa27a);}['_unsubscribe'](_0x47b67a,_0x1ad6d5){this['handlersMap'][_0x47b67a]&&_0x1ad6d5&&this['handlersMap'][_0x47b67a]['delete'](_0x1ad6d5),(!_0x1ad6d5||this['handlersMap'][_0x47b67a]['size']===0x0)&&delete this['handlersMap'][_0x47b67a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x619ae9='',_0x5b5a83=0xa){let _0x41effd='';for(let _0x1e623e=0x0;_0x1e623e<_0x5b5a83;_0x1e623e++)_0x41effd+=Math['floor'](Math['random']()*0xa);return _0x619ae9+_0x41effd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x4ca2e0){this['target']=_0x4ca2e0,this['handlers']=new Set();}['removeMessageHandler'](_0x5f4967){_0x5f4967['messageChannel']&&(_0x5f4967['messageChannel']['port1']['removeEventListener']('message',_0x5f4967['onMessage']),_0x5f4967['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5f4967);}async['_send'](_0x3c7eb2,_0x2c5190,_0x22d1d2=0x32){const _0x386b46=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x386b46)throw new Error('connection_unavailable');let _0x21b350,_0x566da6;return new Promise((_0x45345b,_0x33134e)=>{const _0x577f25=As('',0x14);_0x386b46['port1']['start']();const _0x437f92=setTimeout(()=>{_0x33134e(new Error('unsupported_event'));},_0x22d1d2);_0x566da6={'messageChannel':_0x386b46,'onMessage'(_0x258d1b){const _0x567020=_0x258d1b;if(_0x567020['data']['eventId']===_0x577f25)switch(_0x567020['data']['status']){case'ack':clearTimeout(_0x437f92),_0x21b350=setTimeout(()=>{_0x33134e(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x21b350),_0x45345b(_0x567020['data']['response']);break;default:clearTimeout(_0x437f92),clearTimeout(_0x21b350),_0x33134e(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x566da6),_0x386b46['port1']['addEventListener']('message',_0x566da6['onMessage']),this['target']['postMessage']({'eventType':_0x3c7eb2,'eventId':_0x577f25,'data':_0x2c5190},[_0x386b46['port2']]);})['finally'](()=>{_0x566da6&&this['removeMessageHandler'](_0x566da6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x667622){Z()['location']['href']=_0x667622;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x19ce99;return((_0x19ce99=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x19ce99['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1d7069){this['request']=_0x1d7069;}['toPromise'](){return new Promise((_0x31c307,_0x49fadc)=>{this['request']['addEventListener']('success',()=>{_0x31c307(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x49fadc(this['request']['error']);});});}}function Zn(_0x31b88b,_0x3c4417){return _0x31b88b['transaction']([Mn],_0x3c4417?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x5e8186=indexedDB['deleteDatabase'](Ka);return new nn(_0x5e8186)['toPromise']();}function Qa(){const _0x45d2a2=indexedDB['open'](Ka,pp);return new Promise((_0x53868d,_0x3c4deb)=>{_0x45d2a2['addEventListener']('error',()=>{_0x3c4deb(_0x45d2a2['error']);}),_0x45d2a2['addEventListener']('upgradeneeded',()=>{const _0x3bac9f=_0x45d2a2['result'];try{_0x3bac9f['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4c701e){_0x3c4deb(_0x4c701e);}}),_0x45d2a2['addEventListener']('success',async()=>{const _0x2d7a0b=_0x45d2a2['result'];_0x2d7a0b['objectStoreNames']['contains'](Mn)?_0x53868d(_0x2d7a0b):(_0x2d7a0b['close'](),await _p(),_0x53868d(await Qa()));});});}async function Or(_0x922813,_0x2af9a9,_0x1ced0d){const _0x3dbfaa=Zn(_0x922813,!0x0)['put']({[Ya]:_0x2af9a9,'value':_0x1ced0d});return new nn(_0x3dbfaa)['toPromise']();}async function gp(_0x4a4f50,_0x1625bc){const _0x58ee9c=Zn(_0x4a4f50,!0x1)['get'](_0x1625bc),_0x4955a1=await new nn(_0x58ee9c)['toPromise']();return _0x4955a1===void 0x0?null:_0x4955a1['value'];}function Dr(_0x1d3554,_0x5221c8){const _0x4c65fc=Zn(_0x1d3554,!0x0)['delete'](_0x5221c8);return new nn(_0x4c65fc)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x4ed64e){let _0x402ace=0x0;for(;;)try{const _0x42bae3=await this['_openDb']();return await _0x4ed64e(_0x42bae3);}catch(_0x15520f){if(_0x402ace++>yp)throw _0x15520f;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2feb9a,_0x382df5)=>({'keyProcessed':(await this['_poll']())['includes'](_0x382df5['key'])})),this['receiver']['_subscribe']('ping',async(_0x398dfd,_0x279fa6)=>['keyChanged']);}async['initializeSender'](){var _0x43b5e0,_0x5bbd5e;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x4b9c79=await this['sender']['_send']('ping',{},0x320);_0x4b9c79&&(_0x43b5e0=_0x4b9c79[0x0])!=null&&_0x43b5e0['fulfilled']&&(_0x5bbd5e=_0x4b9c79[0x0])!=null&&_0x5bbd5e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x46b12d){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x46b12d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xbc594d=>{await Or(_0xbc594d,Dn,'1'),await Dr(_0xbc594d,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5ee9a2){this['pendingWrites']++;try{await _0x5ee9a2();}finally{this['pendingWrites']--;}}async['_set'](_0x144f08,_0x185436){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x364833=>Or(_0x364833,_0x144f08,_0x185436)),this['localCache'][_0x144f08]=_0x185436,this['notifyServiceWorker'](_0x144f08)));}async['_get'](_0x37632){const _0x137b2d=await this['_withRetries'](_0x5af8e0=>gp(_0x5af8e0,_0x37632));return this['localCache'][_0x37632]=_0x137b2d,_0x137b2d;}async['_remove'](_0x49988d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x194e5a=>Dr(_0x194e5a,_0x49988d)),delete this['localCache'][_0x49988d],this['notifyServiceWorker'](_0x49988d)));}async['_poll'](){const _0x8bd716=await this['_withRetries'](_0x124b8c=>{const _0x2d3ed3=Zn(_0x124b8c,!0x1)['getAll']();return new nn(_0x2d3ed3)['toPromise']();});if(!_0x8bd716)return[];if(this['pendingWrites']!==0x0)return[];const _0x3e7d77=[],_0xba7720=new Set();if(_0x8bd716['length']!==0x0){for(const {fbase_key:_0x5afce9,value:_0x1da832}of _0x8bd716)_0xba7720['add'](_0x5afce9),JSON['stringify'](this['localCache'][_0x5afce9])!==JSON['stringify'](_0x1da832)&&(this['notifyListeners'](_0x5afce9,_0x1da832),_0x3e7d77['push'](_0x5afce9));}for(const _0x50066e of Object['keys'](this['localCache']))this['localCache'][_0x50066e]&&!_0xba7720['has'](_0x50066e)&&(this['notifyListeners'](_0x50066e,null),_0x3e7d77['push'](_0x50066e));return _0x3e7d77;}['notifyListeners'](_0x2176de,_0xb5af56){this['localCache'][_0x2176de]=_0xb5af56;const _0x2336de=this['listeners'][_0x2176de];if(_0x2336de){for(const _0x203ba5 of Array['from'](_0x2336de))_0x203ba5(_0xb5af56);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2874bc,_0xb95221){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2874bc]||(this['listeners'][_0x2874bc]=new Set(),this['_get'](_0x2874bc)),this['listeners'][_0x2874bc]['add'](_0xb95221);}['_removeListener'](_0x32fd0b,_0x28700d){this['listeners'][_0x32fd0b]&&(this['listeners'][_0x32fd0b]['delete'](_0x28700d),this['listeners'][_0x32fd0b]['size']===0x0&&delete this['listeners'][_0x32fd0b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x3a807c,_0x5c3302){return _0x5c3302?ie(_0x5c3302):(m(_0x3a807c['_popupRedirectResolver'],_0x3a807c,'argument-error'),_0x3a807c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4fbfd4){super('custom','custom'),this['params']=_0x4fbfd4;}['_getIdTokenResponse'](_0x443854){return nt(_0x443854,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2c8ad2,_0x1f67f4){return nt(_0x2c8ad2,this['_buildIdpRequest'](_0x1f67f4));}['_getReauthenticationResolver'](_0x106bfa){return nt(_0x106bfa,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x53e467){const _0x5c9ab0={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x53e467&&(_0x5c9ab0['idToken']=_0x53e467),_0x5c9ab0;}}function Ip(_0x4c9d43){return Va(_0x4c9d43['auth'],new ks(_0x4c9d43),_0x4c9d43['bypassAuthState']);}function wp(_0x3f5152){const {auth:_0x269348,user:_0x5dc448}=_0x3f5152;return m(_0x5dc448,_0x269348,'internal-error'),tp(_0x5dc448,new ks(_0x3f5152),_0x3f5152['bypassAuthState']);}async function Cp(_0x13bcda){const {auth:_0x27e451,user:_0x52fad7}=_0x13bcda;return m(_0x52fad7,_0x27e451,'internal-error'),ep(_0x52fad7,new ks(_0x13bcda),_0x13bcda['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0xae0020,_0x1aef64,_0x4c0e8c,_0x23cfcb,_0x10f8b8=!0x1){this['auth']=_0xae0020,this['resolver']=_0x4c0e8c,this['user']=_0x23cfcb,this['bypassAuthState']=_0x10f8b8,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1aef64)?_0x1aef64:[_0x1aef64];}['execute'](){return new Promise(async(_0x369353,_0x5427cf)=>{this['pendingPromise']={'resolve':_0x369353,'reject':_0x5427cf};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5f2e5e){this['reject'](_0x5f2e5e);}});}async['onAuthEvent'](_0x314d3b){const {urlResponse:_0x2eb254,sessionId:_0x4d8530,postBody:_0x5cab7a,tenantId:_0x368cca,error:_0x4002e0,type:_0x24ad88}=_0x314d3b;if(_0x4002e0){this['reject'](_0x4002e0);return;}const _0x1749ef={'auth':this['auth'],'requestUri':_0x2eb254,'sessionId':_0x4d8530,'tenantId':_0x368cca||void 0x0,'postBody':_0x5cab7a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x24ad88)(_0x1749ef));}catch(_0x2d1a76){this['reject'](_0x2d1a76);}}['onError'](_0x4e5842){this['reject'](_0x4e5842);}['getIdpTask'](_0x4e78ab){switch(_0x4e78ab){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x515229){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x515229),this['unregisterAndCleanUp']();}['reject'](_0x2ac263){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2ac263),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x24656b,_0x3fb324,_0x3881d4,_0x2dc5c0,_0xa08b80){super(_0x24656b,_0x3fb324,_0x2dc5c0,_0xa08b80),this['provider']=_0x3881d4,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3760a0=await this['execute']();return m(_0x3760a0,this['auth'],'internal-error'),_0x3760a0;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3f2f90=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3f2f90),this['authWindow']['associatedEvent']=_0x3f2f90,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4550d4=>{this['reject'](_0x4550d4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3c7a61=>{_0x3c7a61||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4b833b;return((_0x4b833b=this['authWindow'])==null?void 0x0:_0x4b833b['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x3d23d8=()=>{var _0x3f82de,_0x338589;if((_0x338589=(_0x3f82de=this['authWindow'])==null?void 0x0:_0x3f82de['window'])!=null&&_0x338589['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x3d23d8,Tp['get']());};_0x3d23d8();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x368a3e,_0x441bf9,_0x43748e=!0x1){super(_0x368a3e,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x441bf9,void 0x0,_0x43748e),this['eventId']=null;}async['execute'](){let _0x27ab8b=hn['get'](this['auth']['_key']());if(!_0x27ab8b){try{const _0xbeab48=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x27ab8b=()=>Promise['resolve'](_0xbeab48);}catch(_0x363e69){_0x27ab8b=()=>Promise['reject'](_0x363e69);}hn['set'](this['auth']['_key'](),_0x27ab8b);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x27ab8b();}async['onAuthEvent'](_0x543c45){if(_0x543c45['type']==='signInViaRedirect')return super['onAuthEvent'](_0x543c45);if(_0x543c45['type']==='unknown'){this['resolve'](null);return;}if(_0x543c45['eventId']){const _0x2acdd4=await this['auth']['_redirectUserForId'](_0x543c45['eventId']);if(_0x2acdd4)return this['user']=_0x2acdd4,super['onAuthEvent'](_0x543c45);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x2290b9,_0x3b29e8){const _0xd254c6=Pp(_0x3b29e8),_0x344277=kp(_0x2290b9);if(!await _0x344277['_isAvailable']())return!0x1;const _0x30990e=await _0x344277['_get'](_0xd254c6)==='true';return await _0x344277['_remove'](_0xd254c6),_0x30990e;}function Ap(_0x4ee145,_0x57859e){hn['set'](_0x4ee145['_key'](),_0x57859e);}function kp(_0x256f44){return ie(_0x256f44['_redirectPersistence']);}function Pp(_0xec2efd){return ln(Sp,_0xec2efd['config']['apiKey'],_0xec2efd['name']);}async function Np(_0x29232e,_0x56c74f,_0x546786=!0x1){if($(_0x29232e['app']))return Promise['reject'](re(_0x29232e));const _0x99ae15=Ke(_0x29232e),_0xb055bb=Ep(_0x99ae15,_0x56c74f),_0x3dd3c0=await new bp(_0x99ae15,_0xb055bb,_0x546786)['execute']();return _0x3dd3c0&&!_0x546786&&(delete _0x3dd3c0['user']['_redirectEventId'],await _0x99ae15['_persistUserIfCurrent'](_0x3dd3c0['user']),await _0x99ae15['_setRedirectUser'](null,_0x56c74f)),_0x3dd3c0;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x287047){this['auth']=_0x287047,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1e63d1){this['consumers']['add'](_0x1e63d1),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1e63d1)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1e63d1),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x294f2f){this['consumers']['delete'](_0x294f2f);}['onEvent'](_0xc55e2c){if(this['hasEventBeenHandled'](_0xc55e2c))return!0x1;let _0x1ac2a0=!0x1;return this['consumers']['forEach'](_0x3c4381=>{this['isEventForConsumer'](_0xc55e2c,_0x3c4381)&&(_0x1ac2a0=!0x0,this['sendToConsumer'](_0xc55e2c,_0x3c4381),this['saveEventToCache'](_0xc55e2c));}),this['hasHandledPotentialRedirect']||!Mp(_0xc55e2c)||(this['hasHandledPotentialRedirect']=!0x0,_0x1ac2a0||(this['queuedRedirectEvent']=_0xc55e2c,_0x1ac2a0=!0x0)),_0x1ac2a0;}['sendToConsumer'](_0x2fcd27,_0x2d716a){var _0x2562d4;if(_0x2fcd27['error']&&!Za(_0x2fcd27)){const _0x3f9354=((_0x2562d4=_0x2fcd27['error']['code'])==null?void 0x0:_0x2562d4['split']('auth/')[0x1])||'internal-error';_0x2d716a['onError'](X(this['auth'],_0x3f9354));}else _0x2d716a['onAuthEvent'](_0x2fcd27);}['isEventForConsumer'](_0xa6aac4,_0x14cc85){const _0x5a4a52=_0x14cc85['eventId']===null||!!_0xa6aac4['eventId']&&_0xa6aac4['eventId']===_0x14cc85['eventId'];return _0x14cc85['filter']['includes'](_0xa6aac4['type'])&&_0x5a4a52;}['hasEventBeenHandled'](_0x449e6a){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x449e6a));}['saveEventToCache'](_0x4f5996){this['cachedEventUids']['add'](Mr(_0x4f5996)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x460fad){return[_0x460fad['type'],_0x460fad['eventId'],_0x460fad['sessionId'],_0x460fad['tenantId']]['filter'](_0x71ac47=>_0x71ac47)['join']('-');}function Za({type:_0x4edeb2,error:_0x15eb57}){return _0x4edeb2==='unknown'&&(_0x15eb57==null?void 0x0:_0x15eb57['code'])==='auth/no-auth-event';}function Mp(_0x234aed){switch(_0x234aed['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x234aed);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x16af90,_0x2bc51b={}){return Pe(_0x16af90,'GET','/v1/projects',_0x2bc51b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x23885d){if(_0x23885d['config']['emulator'])return;const {authorizedDomains:_0x10f6ef}=await Lp(_0x23885d);for(const _0x251994 of _0x10f6ef)try{if(Wp(_0x251994))return;}catch{}Y(_0x23885d,'unauthorized-domain');}function Wp(_0x4cba93){const _0x29bbef=Mi(),{protocol:_0x47243a,hostname:_0x22fb60}=new URL(_0x29bbef);if(_0x4cba93['startsWith']('chrome-extension://')){const _0x3ef9bc=new URL(_0x4cba93);return _0x3ef9bc['hostname']===''&&_0x22fb60===''?_0x47243a==='chrome-extension:'&&_0x4cba93['replace']('chrome-extension://','')===_0x29bbef['replace']('chrome-extension://',''):_0x47243a==='chrome-extension:'&&_0x3ef9bc['hostname']===_0x22fb60;}if(!Fp['test'](_0x47243a))return!0x1;if(xp['test'](_0x4cba93))return _0x22fb60===_0x4cba93;const _0x364d43=_0x4cba93['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x364d43+'|'+_0x364d43+')$','i')['test'](_0x22fb60);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x2e3f11=Z()['___jsl'];if(_0x2e3f11!=null&&_0x2e3f11['H']){for(const _0x30e66e of Object['keys'](_0x2e3f11['H']))if(_0x2e3f11['H'][_0x30e66e]['r']=_0x2e3f11['H'][_0x30e66e]['r']||[],_0x2e3f11['H'][_0x30e66e]['L']=_0x2e3f11['H'][_0x30e66e]['L']||[],_0x2e3f11['H'][_0x30e66e]['r']=[..._0x2e3f11['H'][_0x30e66e]['L']],_0x2e3f11['CP']){for(let _0x5a7e53=0x0;_0x5a7e53<_0x2e3f11['CP']['length'];_0x5a7e53++)_0x2e3f11['CP'][_0x5a7e53]=null;}}}function Vp(_0x3ca4c7){return new Promise((_0x4b46fe,_0x1c8d40)=>{var _0x370e65,_0x59bcc0,_0xf66ec8;function _0x1c9017(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4b46fe(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1c8d40(X(_0x3ca4c7,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x59bcc0=(_0x370e65=Z()['gapi'])==null?void 0x0:_0x370e65['iframes'])!=null&&_0x59bcc0['Iframe'])_0x4b46fe(gapi['iframes']['getContext']());else{if((_0xf66ec8=Z()['gapi'])!=null&&_0xf66ec8['load'])_0x1c9017();else{const _0x1488a7=Ff('iframefcb');return Z()[_0x1488a7]=()=>{gapi['load']?_0x1c9017():_0x1c8d40(X(_0x3ca4c7,'network-request-failed'));},xa(xf()+'?onload='+_0x1488a7)['catch'](_0x1b243a=>_0x1c8d40(_0x1b243a));}}})['catch'](_0x55566e=>{throw un=null,_0x55566e;});}let un=null;function Hp(_0x240904){return un=un||Vp(_0x240904),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x6e0fde){const _0x413a71=_0x6e0fde['config'];m(_0x413a71['authDomain'],_0x6e0fde,'auth-domain-config-required');const _0xaa88bf=_0x413a71['emulator']?Cs(_0x413a71,qp):'https://'+_0x6e0fde['config']['authDomain']+'/'+Gp,_0x458354={'apiKey':_0x413a71['apiKey'],'appName':_0x6e0fde['name'],'v':dt},_0x330320=jp['get'](_0x6e0fde['config']['apiHost']);_0x330320&&(_0x458354['eid']=_0x330320);const _0x18eeb6=_0x6e0fde['_getFrameworks']();return _0x18eeb6['length']&&(_0x458354['fw']=_0x18eeb6['join'](',')),_0xaa88bf+'?'+ut(_0x458354)['slice'](0x1);}async function Yp(_0x40bc5f){const _0x488dda=await Hp(_0x40bc5f),_0x1e0e83=Z()['gapi'];return m(_0x1e0e83,_0x40bc5f,'internal-error'),_0x488dda['open']({'where':document['body'],'url':Kp(_0x40bc5f),'messageHandlersFilter':_0x1e0e83['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x52e9fe=>new Promise(async(_0x14f278,_0x1ce9e3)=>{await _0x52e9fe['restyle']({'setHideOnLeave':!0x1});const _0x42a985=X(_0x40bc5f,'network-request-failed'),_0x351d2f=Z()['setTimeout'](()=>{_0x1ce9e3(_0x42a985);},$p['get']());function _0x4d96a6(){Z()['clearTimeout'](_0x351d2f),_0x14f278(_0x52e9fe);}_0x52e9fe['ping'](_0x4d96a6)['then'](_0x4d96a6,()=>{_0x1ce9e3(_0x42a985);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x1e8e54){this['window']=_0x1e8e54,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x3123dc,_0xf3c412,_0x1d15a7,_0x518603=Jp,_0x289c38=Xp){const _0x3d8145=Math['max']((window['screen']['availHeight']-_0x289c38)/0x2,0x0)['toString'](),_0x43c313=Math['max']((window['screen']['availWidth']-_0x518603)/0x2,0x0)['toString']();let _0x5c79e2='';const _0x294189={...Qp,'width':_0x518603['toString'](),'height':_0x289c38['toString'](),'top':_0x3d8145,'left':_0x43c313},_0x37c1db=W()['toLowerCase']();_0x1d15a7&&(_0x5c79e2=ka(_0x37c1db)?Zp:_0x1d15a7),Ra(_0x37c1db)&&(_0xf3c412=_0xf3c412||e_,_0x294189['scrollbars']='yes');const _0x6a1783=Object['entries'](_0x294189)['reduce']((_0x27eded,[_0x3b7d1a,_0x54c44f])=>''+_0x27eded+_0x3b7d1a+'='+_0x54c44f+',','');if(Rf(_0x37c1db)&&_0x5c79e2!=='_self')return n_(_0xf3c412||'',_0x5c79e2),new xr(null);const _0x431ea1=window['open'](_0xf3c412||'',_0x5c79e2,_0x6a1783);m(_0x431ea1,_0x3123dc,'popup-blocked');try{_0x431ea1['focus']();}catch{}return new xr(_0x431ea1);}function n_(_0x364533,_0x2445ae){const _0x265347=document['createElement']('a');_0x265347['href']=_0x364533,_0x265347['target']=_0x2445ae;const _0xd8ec14=document['createEvent']('MouseEvent');_0xd8ec14['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x265347['dispatchEvent'](_0xd8ec14);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x260d48,_0x4f32c0,_0x182389,_0x54fac2,_0x2f508a,_0x5c4c67){m(_0x260d48['config']['authDomain'],_0x260d48,'auth-domain-config-required'),m(_0x260d48['config']['apiKey'],_0x260d48,'invalid-api-key');const _0x205368={'apiKey':_0x260d48['config']['apiKey'],'appName':_0x260d48['name'],'authType':_0x182389,'redirectUrl':_0x54fac2,'v':dt,'eventId':_0x2f508a};if(_0x4f32c0 instanceof Wa){_0x4f32c0['setDefaultLanguage'](_0x260d48['languageCode']),_0x205368['providerId']=_0x4f32c0['providerId']||'',pn(_0x4f32c0['getCustomParameters']())||(_0x205368['customParameters']=JSON['stringify'](_0x4f32c0['getCustomParameters']()));for(const [_0x5b414c,_0x4e7420]of Object['entries']({}))_0x205368[_0x5b414c]=_0x4e7420;}if(_0x4f32c0 instanceof tn){const _0x2d0b4a=_0x4f32c0['getScopes']()['filter'](_0x40b7cb=>_0x40b7cb!=='');_0x2d0b4a['length']>0x0&&(_0x205368['scopes']=_0x2d0b4a['join'](','));}_0x260d48['tenantId']&&(_0x205368['tid']=_0x260d48['tenantId']);const _0x1e12f5=_0x205368;for(const _0x20ed61 of Object['keys'](_0x1e12f5))_0x1e12f5[_0x20ed61]===void 0x0&&delete _0x1e12f5[_0x20ed61];const _0x3c2d98=await _0x260d48['_getAppCheckToken'](),_0x299d72=_0x3c2d98?'#'+r_+'='+encodeURIComponent(_0x3c2d98):'';return o_(_0x260d48)+'?'+ut(_0x1e12f5)['slice'](0x1)+_0x299d72;}function o_({config:_0x1d4a1f}){return _0x1d4a1f['emulator']?Cs(_0x1d4a1f,s_):'https://'+_0x1d4a1f['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x449e00,_0x3905a7,_0x5cc8cc,_0x3ad8ed){var _0x7d67ce;ce((_0x7d67ce=this['eventManagers'][_0x449e00['_key']()])==null?void 0x0:_0x7d67ce['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5930cb=await Fr(_0x449e00,_0x3905a7,_0x5cc8cc,Mi(),_0x3ad8ed);return t_(_0x449e00,_0x5930cb,As());}async['_openRedirect'](_0x1d2399,_0x34ef77,_0x2b4724,_0x511c20){await this['_originValidation'](_0x1d2399);const _0x22743a=await Fr(_0x1d2399,_0x34ef77,_0x2b4724,Mi(),_0x511c20);return hp(_0x22743a),new Promise(()=>{});}['_initialize'](_0xa6989f){const _0x59638d=_0xa6989f['_key']();if(this['eventManagers'][_0x59638d]){const {manager:_0x2a0448,promise:_0xe6bd4c}=this['eventManagers'][_0x59638d];return _0x2a0448?Promise['resolve'](_0x2a0448):(ce(_0xe6bd4c,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xe6bd4c);}const _0x1062f1=this['initAndGetManager'](_0xa6989f);return this['eventManagers'][_0x59638d]={'promise':_0x1062f1},_0x1062f1['catch'](()=>{delete this['eventManagers'][_0x59638d];}),_0x1062f1;}async['initAndGetManager'](_0x55f548){const _0x31c9a0=await Yp(_0x55f548),_0x133b5c=new Dp(_0x55f548);return _0x31c9a0['register']('authEvent',_0x2adb65=>(m(_0x2adb65==null?void 0x0:_0x2adb65['authEvent'],_0x55f548,'invalid-auth-event'),{'status':_0x133b5c['onEvent'](_0x2adb65['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x55f548['_key']()]={'manager':_0x133b5c},this['iframes'][_0x55f548['_key']()]=_0x31c9a0,_0x133b5c;}['_isIframeWebStorageSupported'](_0x1e6d3f,_0x57d10f){this['iframes'][_0x1e6d3f['_key']()]['send'](pi,{'type':pi},_0x4f93cf=>{var _0x4d413a;const _0x20d9e5=(_0x4d413a=_0x4f93cf==null?void 0x0:_0x4f93cf[0x0])==null?void 0x0:_0x4d413a[pi];_0x20d9e5!==void 0x0&&_0x57d10f(!!_0x20d9e5),Y(_0x1e6d3f,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4e2af3){const _0x2d4167=_0x4e2af3['_key']();return this['originValidationPromises'][_0x2d4167]||(this['originValidationPromises'][_0x2d4167]=Up(_0x4e2af3)),this['originValidationPromises'][_0x2d4167];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x43bd3c){this['auth']=_0x43bd3c,this['internalListeners']=new Map();}['getUid'](){var _0x5f460e;return this['assertAuthConfigured'](),((_0x5f460e=this['auth']['currentUser'])==null?void 0x0:_0x5f460e['uid'])||null;}async['getToken'](_0x38034f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x38034f)}:null;}['addAuthTokenListener'](_0x170917){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x170917))return;const _0x3c20d1=this['auth']['onIdTokenChanged'](_0xe19b43=>{_0x170917((_0xe19b43==null?void 0x0:_0xe19b43['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x170917,_0x3c20d1),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xc944f6){this['assertAuthConfigured']();const _0x56e38e=this['internalListeners']['get'](_0xc944f6);_0x56e38e&&(this['internalListeners']['delete'](_0xc944f6),_0x56e38e(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x59b031){switch(_0x59b031){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x1e588e){st(new Fe('auth',(_0xdf683a,{options:_0x1bd8e1})=>{const _0x3aabbe=_0xdf683a['getProvider']('app')['getImmediate'](),_0x42baae=_0xdf683a['getProvider']('heartbeat'),_0x5b6a87=_0xdf683a['getProvider']('app-check-internal'),{apiKey:_0x2a115a,authDomain:_0x15ae8b}=_0x3aabbe['options'];m(_0x2a115a&&!_0x2a115a['includes'](':'),'invalid-api-key',{'appName':_0x3aabbe['name']});const _0x24fe18={'apiKey':_0x2a115a,'authDomain':_0x15ae8b,'clientPlatform':_0x1e588e,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1e588e)},_0x113868=new Df(_0x3aabbe,_0x42baae,_0x5b6a87,_0x24fe18);return Hf(_0x113868,_0x1bd8e1),_0x113868;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3cfd6a,_0x8465d0,_0xb3b80e)=>{_0x3cfd6a['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0xfeb45=>{const _0x1700a4=Ke(_0xfeb45['getProvider']('auth')['getImmediate']());return(_0x157705=>new l_(_0x157705))(_0x1700a4);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x1e588e)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x38c34b=>async _0x2c8ee2=>{const _0x4410e5=_0x2c8ee2&&await _0x2c8ee2['getIdTokenResult'](),_0x5df3e2=_0x4410e5&&(new Date()['getTime']()-Date['parse'](_0x4410e5['issuedAtTime']))/0x3e8;if(_0x5df3e2&&_0x5df3e2>f_)return;const _0x59af99=_0x4410e5==null?void 0x0:_0x4410e5['token'];Br!==_0x59af99&&(Br=_0x59af99,await fetch(_0x38c34b,{'method':_0x59af99?'POST':'DELETE','headers':_0x59af99?{'Authorization':'Bearer\x20'+_0x59af99}:{}}));};function B_(_0x271963=Zr()){const _0x139506=Hi(_0x271963,'auth');if(_0x139506['isInitialized']())return _0x139506['getImmediate']();const _0x58256c=Vf(_0x271963,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x2059a0=jr('authTokenSyncURL');if(_0x2059a0&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x28d6a0=new URL(_0x2059a0,location['origin']);if(location['origin']===_0x28d6a0['origin']){const _0x1e6c34=p_(_0x28d6a0['toString']());sp(_0x58256c,_0x1e6c34,()=>_0x1e6c34(_0x58256c['currentUser'])),ip(_0x58256c,_0x7075f=>_0x1e6c34(_0x7075f));}}const _0x21029d=qr('auth');return _0x21029d&&$f(_0x58256c,'http://'+_0x21029d),_0x58256c;}function __(){var _0x37c462;return((_0x37c462=document['getElementsByTagName']('head'))==null?void 0x0:_0x37c462[0x0])??document;}Mf({'loadJS'(_0x32f384){return new Promise((_0x699b9c,_0xedc050)=>{const _0x454730=document['createElement']('script');_0x454730['setAttribute']('src',_0x32f384),_0x454730['onload']=_0x699b9c,_0x454730['onerror']=_0x984af=>{const _0x375045=X('internal-error');_0x375045['customData']=_0x984af,_0xedc050(_0x375045);},_0x454730['type']='text/javascript',_0x454730['charset']='UTF-8',__()['appendChild'](_0x454730);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};