const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2b8bb0,_0x8e6f3a){if(!_0x2b8bb0)throw ht(_0x8e6f3a);},ht=function(_0xd24a6e){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xd24a6e);},Hr=function(_0x83e288){const _0xe88d01=[];let _0x53477b=0x0;for(let _0x508d86=0x0;_0x508d86<_0x83e288['length'];_0x508d86++){let _0x1298bc=_0x83e288['charCodeAt'](_0x508d86);_0x1298bc<0x80?_0xe88d01[_0x53477b++]=_0x1298bc:_0x1298bc<0x800?(_0xe88d01[_0x53477b++]=_0x1298bc>>0x6|0xc0,_0xe88d01[_0x53477b++]=_0x1298bc&0x3f|0x80):(_0x1298bc&0xfc00)===0xd800&&_0x508d86+0x1<_0x83e288['length']&&(_0x83e288['charCodeAt'](_0x508d86+0x1)&0xfc00)===0xdc00?(_0x1298bc=0x10000+((_0x1298bc&0x3ff)<<0xa)+(_0x83e288['charCodeAt'](++_0x508d86)&0x3ff),_0xe88d01[_0x53477b++]=_0x1298bc>>0x12|0xf0,_0xe88d01[_0x53477b++]=_0x1298bc>>0xc&0x3f|0x80,_0xe88d01[_0x53477b++]=_0x1298bc>>0x6&0x3f|0x80,_0xe88d01[_0x53477b++]=_0x1298bc&0x3f|0x80):(_0xe88d01[_0x53477b++]=_0x1298bc>>0xc|0xe0,_0xe88d01[_0x53477b++]=_0x1298bc>>0x6&0x3f|0x80,_0xe88d01[_0x53477b++]=_0x1298bc&0x3f|0x80);}return _0xe88d01;},nc=function(_0x453a6b){const _0x637d2=[];let _0x35f20c=0x0,_0xb86562=0x0;for(;_0x35f20c<_0x453a6b['length'];){const _0x1fbd71=_0x453a6b[_0x35f20c++];if(_0x1fbd71<0x80)_0x637d2[_0xb86562++]=String['fromCharCode'](_0x1fbd71);else{if(_0x1fbd71>0xbf&&_0x1fbd71<0xe0){const _0x696ac7=_0x453a6b[_0x35f20c++];_0x637d2[_0xb86562++]=String['fromCharCode']((_0x1fbd71&0x1f)<<0x6|_0x696ac7&0x3f);}else{if(_0x1fbd71>0xef&&_0x1fbd71<0x16d){const _0x46e6b8=_0x453a6b[_0x35f20c++],_0x417d5c=_0x453a6b[_0x35f20c++],_0x4a2e6b=_0x453a6b[_0x35f20c++],_0x2d9c02=((_0x1fbd71&0x7)<<0x12|(_0x46e6b8&0x3f)<<0xc|(_0x417d5c&0x3f)<<0x6|_0x4a2e6b&0x3f)-0x10000;_0x637d2[_0xb86562++]=String['fromCharCode'](0xd800+(_0x2d9c02>>0xa)),_0x637d2[_0xb86562++]=String['fromCharCode'](0xdc00+(_0x2d9c02&0x3ff));}else{const _0x4c7487=_0x453a6b[_0x35f20c++],_0x4b23f7=_0x453a6b[_0x35f20c++];_0x637d2[_0xb86562++]=String['fromCharCode']((_0x1fbd71&0xf)<<0xc|(_0x4c7487&0x3f)<<0x6|_0x4b23f7&0x3f);}}}}return _0x637d2['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1ec0f6,_0x526c9c){if(!Array['isArray'](_0x1ec0f6))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x56c1f5=_0x526c9c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x45e874=[];for(let _0x294679=0x0;_0x294679<_0x1ec0f6['length'];_0x294679+=0x3){const _0x356390=_0x1ec0f6[_0x294679],_0x4c6d99=_0x294679+0x1<_0x1ec0f6['length'],_0x2f5d49=_0x4c6d99?_0x1ec0f6[_0x294679+0x1]:0x0,_0xbb22d3=_0x294679+0x2<_0x1ec0f6['length'],_0xad2f41=_0xbb22d3?_0x1ec0f6[_0x294679+0x2]:0x0,_0x3ada98=_0x356390>>0x2,_0x5f42c5=(_0x356390&0x3)<<0x4|_0x2f5d49>>0x4;let _0x810c72=(_0x2f5d49&0xf)<<0x2|_0xad2f41>>0x6,_0x5de52a=_0xad2f41&0x3f;_0xbb22d3||(_0x5de52a=0x40,_0x4c6d99||(_0x810c72=0x40)),_0x45e874['push'](_0x56c1f5[_0x3ada98],_0x56c1f5[_0x5f42c5],_0x56c1f5[_0x810c72],_0x56c1f5[_0x5de52a]);}return _0x45e874['join']('');},'encodeString'(_0x4a215d,_0x4e5d6b){return this['HAS_NATIVE_SUPPORT']&&!_0x4e5d6b?btoa(_0x4a215d):this['encodeByteArray'](Hr(_0x4a215d),_0x4e5d6b);},'decodeString'(_0x32b7c9,_0xbb52d7){return this['HAS_NATIVE_SUPPORT']&&!_0xbb52d7?atob(_0x32b7c9):nc(this['decodeStringToByteArray'](_0x32b7c9,_0xbb52d7));},'decodeStringToByteArray'(_0x303cb5,_0x417992){this['init_']();const _0x243e28=_0x417992?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2ea8c5=[];for(let _0x2f2052=0x0;_0x2f2052<_0x303cb5['length'];){const _0x1edacd=_0x243e28[_0x303cb5['charAt'](_0x2f2052++)],_0x35bd43=_0x2f2052<_0x303cb5['length']?_0x243e28[_0x303cb5['charAt'](_0x2f2052)]:0x0;++_0x2f2052;const _0x35f06d=_0x2f2052<_0x303cb5['length']?_0x243e28[_0x303cb5['charAt'](_0x2f2052)]:0x40;++_0x2f2052;const _0x16008f=_0x2f2052<_0x303cb5['length']?_0x243e28[_0x303cb5['charAt'](_0x2f2052)]:0x40;if(++_0x2f2052,_0x1edacd==null||_0x35bd43==null||_0x35f06d==null||_0x16008f==null)throw new ic();const _0x24d35e=_0x1edacd<<0x2|_0x35bd43>>0x4;if(_0x2ea8c5['push'](_0x24d35e),_0x35f06d!==0x40){const _0x341588=_0x35bd43<<0x4&0xf0|_0x35f06d>>0x2;if(_0x2ea8c5['push'](_0x341588),_0x16008f!==0x40){const _0x5ab721=_0x35f06d<<0x6&0xc0|_0x16008f;_0x2ea8c5['push'](_0x5ab721);}}}return _0x2ea8c5;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1b3899=0x0;_0x1b3899<this['ENCODED_VALS']['length'];_0x1b3899++)this['byteToCharMap_'][_0x1b3899]=this['ENCODED_VALS']['charAt'](_0x1b3899),this['charToByteMap_'][this['byteToCharMap_'][_0x1b3899]]=_0x1b3899,this['byteToCharMapWebSafe_'][_0x1b3899]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1b3899),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1b3899]]=_0x1b3899,_0x1b3899>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1b3899)]=_0x1b3899,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1b3899)]=_0x1b3899);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x34fbd0){const _0x101417=Hr(_0x34fbd0);return Fi['encodeByteArray'](_0x101417,!0x0);},dn=function(_0x1530c6){return $r(_0x1530c6)['replace'](/\./g,'');},fn=function(_0x3d6b6f){try{return Fi['decodeString'](_0x3d6b6f,!0x0);}catch(_0x467b47){console['error']('base64Decode\x20failed:\x20',_0x467b47);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x708c3d){return Gr(void 0x0,_0x708c3d);}function Gr(_0x33b83d,_0xf87402){if(!(_0xf87402 instanceof Object))return _0xf87402;switch(_0xf87402['constructor']){case Date:const _0x13004b=_0xf87402;return new Date(_0x13004b['getTime']());case Object:_0x33b83d===void 0x0&&(_0x33b83d={});break;case Array:_0x33b83d=[];break;default:return _0xf87402;}for(const _0x3eb6ad in _0xf87402)!_0xf87402['hasOwnProperty'](_0x3eb6ad)||!rc(_0x3eb6ad)||(_0x33b83d[_0x3eb6ad]=Gr(_0x33b83d[_0x3eb6ad],_0xf87402[_0x3eb6ad]));return _0x33b83d;}function rc(_0x4a5412){return _0x4a5412!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x888793=Ps['__FIREBASE_DEFAULTS__'];if(_0x888793)return JSON['parse'](_0x888793);},lc=()=>{if(typeof document>'u')return;let _0x5d4afd;try{_0x5d4afd=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x57360c=_0x5d4afd&&fn(_0x5d4afd[0x1]);return _0x57360c&&JSON['parse'](_0x57360c);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x1f61f7){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1f61f7);return;}},qr=_0x3b8e9c=>{var _0x43217e,_0x23bc5c;return(_0x23bc5c=(_0x43217e=Ui())==null?void 0x0:_0x43217e['emulatorHosts'])==null?void 0x0:_0x23bc5c[_0x3b8e9c];},hc=_0x473e69=>{const _0x7128b4=qr(_0x473e69);if(!_0x7128b4)return;const _0x16fe87=_0x7128b4['lastIndexOf'](':');if(_0x16fe87<=0x0||_0x16fe87+0x1===_0x7128b4['length'])throw new Error('Invalid\x20host\x20'+_0x7128b4+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1276e0=parseInt(_0x7128b4['substring'](_0x16fe87+0x1),0xa);return _0x7128b4[0x0]==='['?[_0x7128b4['substring'](0x1,_0x16fe87-0x1),_0x1276e0]:[_0x7128b4['substring'](0x0,_0x16fe87),_0x1276e0];},zr=()=>{var _0x3e5d44;return(_0x3e5d44=Ui())==null?void 0x0:_0x3e5d44['config'];},jr=_0x31be2a=>{var _0x16df2e;return(_0x16df2e=Ui())==null?void 0x0:_0x16df2e['_'+_0x31be2a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x11c933,_0x4b16c8)=>{this['resolve']=_0x11c933,this['reject']=_0x4b16c8;});}['wrapCallback'](_0x3710df){return(_0x53f43b,_0x42c458)=>{_0x53f43b?this['reject'](_0x53f43b):this['resolve'](_0x42c458),typeof _0x3710df=='function'&&(this['promise']['catch'](()=>{}),_0x3710df['length']===0x1?_0x3710df(_0x53f43b):_0x3710df(_0x53f43b,_0x42c458));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x3525b7,_0x5c8b65){if(_0x3525b7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4938a1={'alg':'none','type':'JWT'},_0x3fffc0=_0x5c8b65||'demo-project',_0x396ca3=_0x3525b7['iat']||0x0,_0x1ef7c3=_0x3525b7['sub']||_0x3525b7['user_id'];if(!_0x1ef7c3)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x313e57={'iss':'https://securetoken.google.com/'+_0x3fffc0,'aud':_0x3fffc0,'iat':_0x396ca3,'exp':_0x396ca3+0xe10,'auth_time':_0x396ca3,'sub':_0x1ef7c3,'user_id':_0x1ef7c3,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3525b7};return[dn(JSON['stringify'](_0x4938a1)),dn(JSON['stringify'](_0x313e57)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x295b87=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x295b87=='object'&&_0x295b87['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2d581c=W();return _0x2d581c['indexOf']('MSIE\x20')>=0x0||_0x2d581c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2adadd,_0x514187)=>{try{let _0x49f710=!0x0;const _0xf8f850='validate-browser-context-for-indexeddb-analytics-module',_0x3cc26d=self['indexedDB']['open'](_0xf8f850);_0x3cc26d['onsuccess']=()=>{_0x3cc26d['result']['close'](),_0x49f710||self['indexedDB']['deleteDatabase'](_0xf8f850),_0x2adadd(!0x0);},_0x3cc26d['onupgradeneeded']=()=>{_0x49f710=!0x1;},_0x3cc26d['onerror']=()=>{var _0x57573e;_0x514187(((_0x57573e=_0x3cc26d['error'])==null?void 0x0:_0x57573e['message'])||'');};}catch(_0x4c5bae){_0x514187(_0x4c5bae);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x191593,_0x2532d7,_0x39620a){super(_0x2532d7),this['code']=_0x191593,this['customData']=_0x39620a,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x3bea84,_0x39af08,_0xa7375c){this['service']=_0x3bea84,this['serviceName']=_0x39af08,this['errors']=_0xa7375c;}['create'](_0xe0bb3d,..._0x23d380){const _0x2ec080=_0x23d380[0x0]||{},_0x44a4b5=this['service']+'/'+_0xe0bb3d,_0x5d18aa=this['errors'][_0xe0bb3d],_0x1753be=_0x5d18aa?vc(_0x5d18aa,_0x2ec080):'Error',_0x5d7bd7=this['serviceName']+':\x20'+_0x1753be+'\x20('+_0x44a4b5+').';return new Re(_0x44a4b5,_0x5d7bd7,_0x2ec080);}}function vc(_0xf69c58,_0x141b6a){return _0xf69c58['replace'](Ec,(_0x551515,_0x358ded)=>{const _0x306f74=_0x141b6a[_0x358ded];return _0x306f74!=null?String(_0x306f74):'<'+_0x358ded+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x22601c){return JSON['parse'](_0x22601c);}function O(_0x3341fc){return JSON['stringify'](_0x3341fc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x4753a2){let _0x3c0454={},_0x49902b={},_0x3d8b5e={},_0xe10193='';try{const _0x2d3baa=_0x4753a2['split']('.');_0x3c0454=Nt(fn(_0x2d3baa[0x0])||''),_0x49902b=Nt(fn(_0x2d3baa[0x1])||''),_0xe10193=_0x2d3baa[0x2],_0x3d8b5e=_0x49902b['d']||{},delete _0x49902b['d'];}catch{}return{'header':_0x3c0454,'claims':_0x49902b,'data':_0x3d8b5e,'signature':_0xe10193};},Ic=function(_0x1c21e4){const _0x1d7d7f=Yr(_0x1c21e4),_0x4530b7=_0x1d7d7f['claims'];return!!_0x4530b7&&typeof _0x4530b7=='object'&&_0x4530b7['hasOwnProperty']('iat');},wc=function(_0x252942){const _0x343ce8=Yr(_0x252942)['claims'];return typeof _0x343ce8=='object'&&_0x343ce8['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2426e9,_0x3e7434){return Object['prototype']['hasOwnProperty']['call'](_0x2426e9,_0x3e7434);}function Le(_0x8a9a63,_0x33fd91){if(Object['prototype']['hasOwnProperty']['call'](_0x8a9a63,_0x33fd91))return _0x8a9a63[_0x33fd91];}function pn(_0x32bc63){for(const _0x48d9cc in _0x32bc63)if(Object['prototype']['hasOwnProperty']['call'](_0x32bc63,_0x48d9cc))return!0x1;return!0x0;}function _n(_0xd6f408,_0x4c967d,_0x3ae710){const _0x5565a4={};for(const _0xe31fff in _0xd6f408)Object['prototype']['hasOwnProperty']['call'](_0xd6f408,_0xe31fff)&&(_0x5565a4[_0xe31fff]=_0x4c967d['call'](_0x3ae710,_0xd6f408[_0xe31fff],_0xe31fff,_0xd6f408));return _0x5565a4;}function xe(_0x5bf4e0,_0xfe5e6b){if(_0x5bf4e0===_0xfe5e6b)return!0x0;const _0x24a3b2=Object['keys'](_0x5bf4e0),_0x5c9217=Object['keys'](_0xfe5e6b);for(const _0x1ac377 of _0x24a3b2){if(!_0x5c9217['includes'](_0x1ac377))return!0x1;const _0x327bcc=_0x5bf4e0[_0x1ac377],_0x1251b0=_0xfe5e6b[_0x1ac377];if(Ns(_0x327bcc)&&Ns(_0x1251b0)){if(!xe(_0x327bcc,_0x1251b0))return!0x1;}else{if(_0x327bcc!==_0x1251b0)return!0x1;}}for(const _0x1d0cd5 of _0x5c9217)if(!_0x24a3b2['includes'](_0x1d0cd5))return!0x1;return!0x0;}function Ns(_0x5e2fe6){return _0x5e2fe6!==null&&typeof _0x5e2fe6=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4149ed){const _0x5bdcb3=[];for(const [_0x27e3f4,_0x4e1815]of Object['entries'](_0x4149ed))Array['isArray'](_0x4e1815)?_0x4e1815['forEach'](_0x594a6b=>{_0x5bdcb3['push'](encodeURIComponent(_0x27e3f4)+'='+encodeURIComponent(_0x594a6b));}):_0x5bdcb3['push'](encodeURIComponent(_0x27e3f4)+'='+encodeURIComponent(_0x4e1815));return _0x5bdcb3['length']?'&'+_0x5bdcb3['join']('&'):'';}function Ct(_0x4c15a2){const _0x1e02ac={};return _0x4c15a2['replace'](/^\?/,'')['split']('&')['forEach'](_0x24a536=>{if(_0x24a536){const [_0x273e24,_0x926319]=_0x24a536['split']('=');_0x1e02ac[decodeURIComponent(_0x273e24)]=decodeURIComponent(_0x926319);}}),_0x1e02ac;}function Tt(_0x5099d9){const _0x527b35=_0x5099d9['indexOf']('?');if(!_0x527b35)return'';const _0x55f190=_0x5099d9['indexOf']('#',_0x527b35);return _0x5099d9['substring'](_0x527b35,_0x55f190>0x0?_0x55f190:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4a4e09=0x1;_0x4a4e09<this['blockSize'];++_0x4a4e09)this['pad_'][_0x4a4e09]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x4362ed,_0x2a18c7){_0x2a18c7||(_0x2a18c7=0x0);const _0x5f1e87=this['W_'];if(typeof _0x4362ed=='string'){for(let _0x1e88e8=0x0;_0x1e88e8<0x10;_0x1e88e8++)_0x5f1e87[_0x1e88e8]=_0x4362ed['charCodeAt'](_0x2a18c7)<<0x18|_0x4362ed['charCodeAt'](_0x2a18c7+0x1)<<0x10|_0x4362ed['charCodeAt'](_0x2a18c7+0x2)<<0x8|_0x4362ed['charCodeAt'](_0x2a18c7+0x3),_0x2a18c7+=0x4;}else{for(let _0x1d4ba9=0x0;_0x1d4ba9<0x10;_0x1d4ba9++)_0x5f1e87[_0x1d4ba9]=_0x4362ed[_0x2a18c7]<<0x18|_0x4362ed[_0x2a18c7+0x1]<<0x10|_0x4362ed[_0x2a18c7+0x2]<<0x8|_0x4362ed[_0x2a18c7+0x3],_0x2a18c7+=0x4;}for(let _0x12f432=0x10;_0x12f432<0x50;_0x12f432++){const _0x4ea30d=_0x5f1e87[_0x12f432-0x3]^_0x5f1e87[_0x12f432-0x8]^_0x5f1e87[_0x12f432-0xe]^_0x5f1e87[_0x12f432-0x10];_0x5f1e87[_0x12f432]=(_0x4ea30d<<0x1|_0x4ea30d>>>0x1f)&0xffffffff;}let _0x303d77=this['chain_'][0x0],_0x453216=this['chain_'][0x1],_0x186a3a=this['chain_'][0x2],_0x488dc8=this['chain_'][0x3],_0x3bf748=this['chain_'][0x4],_0x1d7e4b,_0x55c7ac;for(let _0x1be6d3=0x0;_0x1be6d3<0x50;_0x1be6d3++){_0x1be6d3<0x28?_0x1be6d3<0x14?(_0x1d7e4b=_0x488dc8^_0x453216&(_0x186a3a^_0x488dc8),_0x55c7ac=0x5a827999):(_0x1d7e4b=_0x453216^_0x186a3a^_0x488dc8,_0x55c7ac=0x6ed9eba1):_0x1be6d3<0x3c?(_0x1d7e4b=_0x453216&_0x186a3a|_0x488dc8&(_0x453216|_0x186a3a),_0x55c7ac=0x8f1bbcdc):(_0x1d7e4b=_0x453216^_0x186a3a^_0x488dc8,_0x55c7ac=0xca62c1d6);const _0x3ae9e8=(_0x303d77<<0x5|_0x303d77>>>0x1b)+_0x1d7e4b+_0x3bf748+_0x55c7ac+_0x5f1e87[_0x1be6d3]&0xffffffff;_0x3bf748=_0x488dc8,_0x488dc8=_0x186a3a,_0x186a3a=(_0x453216<<0x1e|_0x453216>>>0x2)&0xffffffff,_0x453216=_0x303d77,_0x303d77=_0x3ae9e8;}this['chain_'][0x0]=this['chain_'][0x0]+_0x303d77&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x453216&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x186a3a&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x488dc8&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3bf748&0xffffffff;}['update'](_0x28f418,_0x511c6a){if(_0x28f418==null)return;_0x511c6a===void 0x0&&(_0x511c6a=_0x28f418['length']);const _0x5bea0c=_0x511c6a-this['blockSize'];let _0x2647a1=0x0;const _0xd09faa=this['buf_'];let _0x7a108e=this['inbuf_'];for(;_0x2647a1<_0x511c6a;){if(_0x7a108e===0x0){for(;_0x2647a1<=_0x5bea0c;)this['compress_'](_0x28f418,_0x2647a1),_0x2647a1+=this['blockSize'];}if(typeof _0x28f418=='string'){for(;_0x2647a1<_0x511c6a;)if(_0xd09faa[_0x7a108e]=_0x28f418['charCodeAt'](_0x2647a1),++_0x7a108e,++_0x2647a1,_0x7a108e===this['blockSize']){this['compress_'](_0xd09faa),_0x7a108e=0x0;break;}}else{for(;_0x2647a1<_0x511c6a;)if(_0xd09faa[_0x7a108e]=_0x28f418[_0x2647a1],++_0x7a108e,++_0x2647a1,_0x7a108e===this['blockSize']){this['compress_'](_0xd09faa),_0x7a108e=0x0;break;}}}this['inbuf_']=_0x7a108e,this['total_']+=_0x511c6a;}['digest'](){const _0x3386b4=[];let _0x17d273=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x325b62=this['blockSize']-0x1;_0x325b62>=0x38;_0x325b62--)this['buf_'][_0x325b62]=_0x17d273&0xff,_0x17d273/=0x100;this['compress_'](this['buf_']);let _0x4317d2=0x0;for(let _0x235029=0x0;_0x235029<0x5;_0x235029++)for(let _0x282fd6=0x18;_0x282fd6>=0x0;_0x282fd6-=0x8)_0x3386b4[_0x4317d2]=this['chain_'][_0x235029]>>_0x282fd6&0xff,++_0x4317d2;return _0x3386b4;}}function Tc(_0x358ca5,_0x57b659){const _0x52e42f=new Sc(_0x358ca5,_0x57b659);return _0x52e42f['subscribe']['bind'](_0x52e42f);}class Sc{constructor(_0x3b475b,_0x4f95f8){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4f95f8,this['task']['then'](()=>{_0x3b475b(this);})['catch'](_0x54d584=>{this['error'](_0x54d584);});}['next'](_0x5e9cbb){this['forEachObserver'](_0x33e699=>{_0x33e699['next'](_0x5e9cbb);});}['error'](_0x58ad62){this['forEachObserver'](_0xd0fd72=>{_0xd0fd72['error'](_0x58ad62);}),this['close'](_0x58ad62);}['complete'](){this['forEachObserver'](_0x4b7f2e=>{_0x4b7f2e['complete']();}),this['close']();}['subscribe'](_0x273ddf,_0x5c5183,_0x1826ac){let _0x3e2f09;if(_0x273ddf===void 0x0&&_0x5c5183===void 0x0&&_0x1826ac===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x273ddf,['next','error','complete'])?_0x3e2f09=_0x273ddf:_0x3e2f09={'next':_0x273ddf,'error':_0x5c5183,'complete':_0x1826ac},_0x3e2f09['next']===void 0x0&&(_0x3e2f09['next']=ti),_0x3e2f09['error']===void 0x0&&(_0x3e2f09['error']=ti),_0x3e2f09['complete']===void 0x0&&(_0x3e2f09['complete']=ti);const _0x156cf0=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3e2f09['error'](this['finalError']):_0x3e2f09['complete']();}catch{}}),this['observers']['push'](_0x3e2f09),_0x156cf0;}['unsubscribeOne'](_0x27c95c){this['observers']===void 0x0||this['observers'][_0x27c95c]===void 0x0||(delete this['observers'][_0x27c95c],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4fbe26){if(!this['finalized']){for(let _0x29f4ba=0x0;_0x29f4ba<this['observers']['length'];_0x29f4ba++)this['sendOne'](_0x29f4ba,_0x4fbe26);}}['sendOne'](_0x470ae7,_0x4f49f2){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x470ae7]!==void 0x0)try{_0x4f49f2(this['observers'][_0x470ae7]);}catch(_0x3690d6){typeof console<'u'&&console['error']&&console['error'](_0x3690d6);}});}['close'](_0x1fb80a){this['finalized']||(this['finalized']=!0x0,_0x1fb80a!==void 0x0&&(this['finalError']=_0x1fb80a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1e1fc9,_0x8e70ec){if(typeof _0x1e1fc9!='object'||_0x1e1fc9===null)return!0x1;for(const _0x4f5c02 of _0x8e70ec)if(_0x4f5c02 in _0x1e1fc9&&typeof _0x1e1fc9[_0x4f5c02]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x3ec6c7,_0x5d98ad){return _0x3ec6c7+'\x20failed:\x20'+_0x5d98ad+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x9cacef){const _0x401ac3=[];let _0x109dd5=0x0;for(let _0x3336f1=0x0;_0x3336f1<_0x9cacef['length'];_0x3336f1++){let _0x35ac43=_0x9cacef['charCodeAt'](_0x3336f1);if(_0x35ac43>=0xd800&&_0x35ac43<=0xdbff){const _0x3b1b55=_0x35ac43-0xd800;_0x3336f1++,f(_0x3336f1<_0x9cacef['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2fe2cb=_0x9cacef['charCodeAt'](_0x3336f1)-0xdc00;_0x35ac43=0x10000+(_0x3b1b55<<0xa)+_0x2fe2cb;}_0x35ac43<0x80?_0x401ac3[_0x109dd5++]=_0x35ac43:_0x35ac43<0x800?(_0x401ac3[_0x109dd5++]=_0x35ac43>>0x6|0xc0,_0x401ac3[_0x109dd5++]=_0x35ac43&0x3f|0x80):_0x35ac43<0x10000?(_0x401ac3[_0x109dd5++]=_0x35ac43>>0xc|0xe0,_0x401ac3[_0x109dd5++]=_0x35ac43>>0x6&0x3f|0x80,_0x401ac3[_0x109dd5++]=_0x35ac43&0x3f|0x80):(_0x401ac3[_0x109dd5++]=_0x35ac43>>0x12|0xf0,_0x401ac3[_0x109dd5++]=_0x35ac43>>0xc&0x3f|0x80,_0x401ac3[_0x109dd5++]=_0x35ac43>>0x6&0x3f|0x80,_0x401ac3[_0x109dd5++]=_0x35ac43&0x3f|0x80);}return _0x401ac3;},Ln=function(_0x2214ef){let _0x4d02b6=0x0;for(let _0x3a2f81=0x0;_0x3a2f81<_0x2214ef['length'];_0x3a2f81++){const _0x25bb48=_0x2214ef['charCodeAt'](_0x3a2f81);_0x25bb48<0x80?_0x4d02b6++:_0x25bb48<0x800?_0x4d02b6+=0x2:_0x25bb48>=0xd800&&_0x25bb48<=0xdbff?(_0x4d02b6+=0x4,_0x3a2f81++):_0x4d02b6+=0x3;}return _0x4d02b6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3a2f53){return _0x3a2f53&&_0x3a2f53['_delegate']?_0x3a2f53['_delegate']:_0x3a2f53;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3efe98){try{return(_0x3efe98['startsWith']('http://')||_0x3efe98['startsWith']('https://')?new URL(_0x3efe98)['hostname']:_0x3efe98)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x40ab58){return(await fetch(_0x40ab58,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x605d4b,_0x1076be,_0x2cb56e){this['name']=_0x605d4b,this['instanceFactory']=_0x1076be,this['type']=_0x2cb56e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x100d14){return this['instantiationMode']=_0x100d14,this;}['setMultipleInstances'](_0x47d4ca){return this['multipleInstances']=_0x47d4ca,this;}['setServiceProps'](_0x1b50ba){return this['serviceProps']=_0x1b50ba,this;}['setInstanceCreatedCallback'](_0x245f47){return this['onInstanceCreated']=_0x245f47,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x241ad9,_0x474a41){this['name']=_0x241ad9,this['container']=_0x474a41,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x3aacd8){const _0x551a06=this['normalizeInstanceIdentifier'](_0x3aacd8);if(!this['instancesDeferred']['has'](_0x551a06)){const _0x259ce6=new H();if(this['instancesDeferred']['set'](_0x551a06,_0x259ce6),this['isInitialized'](_0x551a06)||this['shouldAutoInitialize']())try{const _0x293a07=this['getOrInitializeService']({'instanceIdentifier':_0x551a06});_0x293a07&&_0x259ce6['resolve'](_0x293a07);}catch{}}return this['instancesDeferred']['get'](_0x551a06)['promise'];}['getImmediate'](_0x3a9041){const _0x124cc4=this['normalizeInstanceIdentifier'](_0x3a9041==null?void 0x0:_0x3a9041['identifier']),_0x52cb4d=(_0x3a9041==null?void 0x0:_0x3a9041['optional'])??!0x1;if(this['isInitialized'](_0x124cc4)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x124cc4});}catch(_0x166984){if(_0x52cb4d)return null;throw _0x166984;}else{if(_0x52cb4d)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x1ab42d){if(_0x1ab42d['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x1ab42d['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x1ab42d,!!this['shouldAutoInitialize']()){if(Pc(_0x1ab42d))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4ae4e5,_0x72eb3]of this['instancesDeferred']['entries']()){const _0x378c1c=this['normalizeInstanceIdentifier'](_0x4ae4e5);try{const _0x31f856=this['getOrInitializeService']({'instanceIdentifier':_0x378c1c});_0x72eb3['resolve'](_0x31f856);}catch{}}}}['clearInstance'](_0x3fec57=Ne){this['instancesDeferred']['delete'](_0x3fec57),this['instancesOptions']['delete'](_0x3fec57),this['instances']['delete'](_0x3fec57);}async['delete'](){const _0xc4eca6=Array['from'](this['instances']['values']());await Promise['all']([..._0xc4eca6['filter'](_0x26e65b=>'INTERNAL'in _0x26e65b)['map'](_0x1aeb12=>_0x1aeb12['INTERNAL']['delete']()),..._0xc4eca6['filter'](_0x120e7b=>'_delete'in _0x120e7b)['map'](_0x2d20b8=>_0x2d20b8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x52d2ea=Ne){return this['instances']['has'](_0x52d2ea);}['getOptions'](_0x28b3f5=Ne){return this['instancesOptions']['get'](_0x28b3f5)||{};}['initialize'](_0x1d9332={}){const {options:_0x3b1afc={}}=_0x1d9332,_0x137099=this['normalizeInstanceIdentifier'](_0x1d9332['instanceIdentifier']);if(this['isInitialized'](_0x137099))throw Error(this['name']+'('+_0x137099+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2f825f=this['getOrInitializeService']({'instanceIdentifier':_0x137099,'options':_0x3b1afc});for(const [_0x5ecb8e,_0x145173]of this['instancesDeferred']['entries']()){const _0x2006e6=this['normalizeInstanceIdentifier'](_0x5ecb8e);_0x137099===_0x2006e6&&_0x145173['resolve'](_0x2f825f);}return _0x2f825f;}['onInit'](_0x4d0b6d,_0x1d3405){const _0x12bf68=this['normalizeInstanceIdentifier'](_0x1d3405),_0xba399b=this['onInitCallbacks']['get'](_0x12bf68)??new Set();_0xba399b['add'](_0x4d0b6d),this['onInitCallbacks']['set'](_0x12bf68,_0xba399b);const _0x19ad0d=this['instances']['get'](_0x12bf68);return _0x19ad0d&&_0x4d0b6d(_0x19ad0d,_0x12bf68),()=>{_0xba399b['delete'](_0x4d0b6d);};}['invokeOnInitCallbacks'](_0x3ae753,_0x56c718){const _0x94b9b1=this['onInitCallbacks']['get'](_0x56c718);if(_0x94b9b1){for(const _0x3c1599 of _0x94b9b1)try{_0x3c1599(_0x3ae753,_0x56c718);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0xccdaf9,options:_0x7a57d6={}}){let _0x631ae=this['instances']['get'](_0xccdaf9);if(!_0x631ae&&this['component']&&(_0x631ae=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0xccdaf9),'options':_0x7a57d6}),this['instances']['set'](_0xccdaf9,_0x631ae),this['instancesOptions']['set'](_0xccdaf9,_0x7a57d6),this['invokeOnInitCallbacks'](_0x631ae,_0xccdaf9),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0xccdaf9,_0x631ae);}catch{}return _0x631ae||null;}['normalizeInstanceIdentifier'](_0x28f7cc=Ne){return this['component']?this['component']['multipleInstances']?_0x28f7cc:Ne:_0x28f7cc;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x120c8e){return _0x120c8e===Ne?void 0x0:_0x120c8e;}function Pc(_0x13cbf2){return _0x13cbf2['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0xc75d41){this['name']=_0xc75d41,this['providers']=new Map();}['addComponent'](_0x32899c){const _0x5cbefd=this['getProvider'](_0x32899c['name']);if(_0x5cbefd['isComponentSet']())throw new Error('Component\x20'+_0x32899c['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5cbefd['setComponent'](_0x32899c);}['addOrOverwriteComponent'](_0x42137){this['getProvider'](_0x42137['name'])['isComponentSet']()&&this['providers']['delete'](_0x42137['name']),this['addComponent'](_0x42137);}['getProvider'](_0x2c5a36){if(this['providers']['has'](_0x2c5a36))return this['providers']['get'](_0x2c5a36);const _0x16db03=new Ac(_0x2c5a36,this);return this['providers']['set'](_0x2c5a36,_0x16db03),_0x16db03;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4928c7){_0x4928c7[_0x4928c7['DEBUG']=0x0]='DEBUG',_0x4928c7[_0x4928c7['VERBOSE']=0x1]='VERBOSE',_0x4928c7[_0x4928c7['INFO']=0x2]='INFO',_0x4928c7[_0x4928c7['WARN']=0x3]='WARN',_0x4928c7[_0x4928c7['ERROR']=0x4]='ERROR',_0x4928c7[_0x4928c7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4953be,_0x571441,..._0x45988c)=>{if(_0x571441<_0x4953be['logLevel'])return;const _0x58f988=new Date()['toISOString'](),_0x27a4fc=Mc[_0x571441];if(_0x27a4fc)console[_0x27a4fc]('['+_0x58f988+']\x20\x20'+_0x4953be['name']+':',..._0x45988c);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x571441+')');};class Bi{constructor(_0x967197){this['name']=_0x967197,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4a2b10){if(!(_0x4a2b10 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4a2b10+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4a2b10;}['setLogLevel'](_0xb217ea){this['_logLevel']=typeof _0xb217ea=='string'?Oc[_0xb217ea]:_0xb217ea;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xb74bc){if(typeof _0xb74bc!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xb74bc;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x12506b){this['_userLogHandler']=_0x12506b;}['debug'](..._0x114efc){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x114efc),this['_logHandler'](this,T['DEBUG'],..._0x114efc);}['log'](..._0x8ad56){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x8ad56),this['_logHandler'](this,T['VERBOSE'],..._0x8ad56);}['info'](..._0x9dd7c2){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x9dd7c2),this['_logHandler'](this,T['INFO'],..._0x9dd7c2);}['warn'](..._0x91b5c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x91b5c),this['_logHandler'](this,T['WARN'],..._0x91b5c);}['error'](..._0x13657){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x13657),this['_logHandler'](this,T['ERROR'],..._0x13657);}}const xc=(_0x3b5670,_0xc7e10a)=>_0xc7e10a['some'](_0x59e945=>_0x3b5670 instanceof _0x59e945);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0xb5a03e){const _0x334abf=new Promise((_0x4f58b9,_0xb77dc3)=>{const _0x3d9b2e=()=>{_0xb5a03e['removeEventListener']('success',_0x8ddfaa),_0xb5a03e['removeEventListener']('error',_0x5c739d);},_0x8ddfaa=()=>{_0x4f58b9(ge(_0xb5a03e['result'])),_0x3d9b2e();},_0x5c739d=()=>{_0xb77dc3(_0xb5a03e['error']),_0x3d9b2e();};_0xb5a03e['addEventListener']('success',_0x8ddfaa),_0xb5a03e['addEventListener']('error',_0x5c739d);});return _0x334abf['then'](_0x1f8620=>{_0x1f8620 instanceof IDBCursor&&Jr['set'](_0x1f8620,_0xb5a03e);})['catch'](()=>{}),Vi['set'](_0x334abf,_0xb5a03e),_0x334abf;}function Bc(_0x21a804){if(_i['has'](_0x21a804))return;const _0x5be35e=new Promise((_0xb02901,_0x6b11c5)=>{const _0x43741c=()=>{_0x21a804['removeEventListener']('complete',_0x2368d8),_0x21a804['removeEventListener']('error',_0x1bad3d),_0x21a804['removeEventListener']('abort',_0x1bad3d);},_0x2368d8=()=>{_0xb02901(),_0x43741c();},_0x1bad3d=()=>{_0x6b11c5(_0x21a804['error']||new DOMException('AbortError','AbortError')),_0x43741c();};_0x21a804['addEventListener']('complete',_0x2368d8),_0x21a804['addEventListener']('error',_0x1bad3d),_0x21a804['addEventListener']('abort',_0x1bad3d);});_i['set'](_0x21a804,_0x5be35e);}let gi={'get'(_0x55d5ab,_0x11529b,_0x2d1271){if(_0x55d5ab instanceof IDBTransaction){if(_0x11529b==='done')return _i['get'](_0x55d5ab);if(_0x11529b==='objectStoreNames')return _0x55d5ab['objectStoreNames']||Xr['get'](_0x55d5ab);if(_0x11529b==='store')return _0x2d1271['objectStoreNames'][0x1]?void 0x0:_0x2d1271['objectStore'](_0x2d1271['objectStoreNames'][0x0]);}return ge(_0x55d5ab[_0x11529b]);},'set'(_0x3ce305,_0x15713e,_0x50e800){return _0x3ce305[_0x15713e]=_0x50e800,!0x0;},'has'(_0x3e2358,_0x1c9b03){return _0x3e2358 instanceof IDBTransaction&&(_0x1c9b03==='done'||_0x1c9b03==='store')?!0x0:_0x1c9b03 in _0x3e2358;}};function Vc(_0x46b8bd){gi=_0x46b8bd(gi);}function Hc(_0x440709){return _0x440709===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x43409e,..._0x404545){const _0x336eb8=_0x440709['call'](ii(this),_0x43409e,..._0x404545);return Xr['set'](_0x336eb8,_0x43409e['sort']?_0x43409e['sort']():[_0x43409e]),ge(_0x336eb8);}:Uc()['includes'](_0x440709)?function(..._0x1b43b4){return _0x440709['apply'](ii(this),_0x1b43b4),ge(Jr['get'](this));}:function(..._0x4e85eb){return ge(_0x440709['apply'](ii(this),_0x4e85eb));};}function $c(_0x56f550){return typeof _0x56f550=='function'?Hc(_0x56f550):(_0x56f550 instanceof IDBTransaction&&Bc(_0x56f550),xc(_0x56f550,Fc())?new Proxy(_0x56f550,gi):_0x56f550);}function ge(_0x4e14ad){if(_0x4e14ad instanceof IDBRequest)return Wc(_0x4e14ad);if(ni['has'](_0x4e14ad))return ni['get'](_0x4e14ad);const _0x5d4a4c=$c(_0x4e14ad);return _0x5d4a4c!==_0x4e14ad&&(ni['set'](_0x4e14ad,_0x5d4a4c),Vi['set'](_0x5d4a4c,_0x4e14ad)),_0x5d4a4c;}const ii=_0x4eec8c=>Vi['get'](_0x4eec8c);function Gc(_0x268ac3,_0x233f40,{blocked:_0x545c8a,upgrade:_0x39be99,blocking:_0x539ef8,terminated:_0x222589}={}){const _0x213586=indexedDB['open'](_0x268ac3,_0x233f40),_0x33c2b2=ge(_0x213586);return _0x39be99&&_0x213586['addEventListener']('upgradeneeded',_0x21ec93=>{_0x39be99(ge(_0x213586['result']),_0x21ec93['oldVersion'],_0x21ec93['newVersion'],ge(_0x213586['transaction']),_0x21ec93);}),_0x545c8a&&_0x213586['addEventListener']('blocked',_0x49199f=>_0x545c8a(_0x49199f['oldVersion'],_0x49199f['newVersion'],_0x49199f)),_0x33c2b2['then'](_0x480ab9=>{_0x222589&&_0x480ab9['addEventListener']('close',()=>_0x222589()),_0x539ef8&&_0x480ab9['addEventListener']('versionchange',_0x49706a=>_0x539ef8(_0x49706a['oldVersion'],_0x49706a['newVersion'],_0x49706a));})['catch'](()=>{}),_0x33c2b2;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x20a654,_0xae7d6d){if(!(_0x20a654 instanceof IDBDatabase&&!(_0xae7d6d in _0x20a654)&&typeof _0xae7d6d=='string'))return;if(si['get'](_0xae7d6d))return si['get'](_0xae7d6d);const _0x3f4857=_0xae7d6d['replace'](/FromIndex$/,''),_0x362665=_0xae7d6d!==_0x3f4857,_0x2842af=zc['includes'](_0x3f4857);if(!(_0x3f4857 in(_0x362665?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2842af||qc['includes'](_0x3f4857)))return;const _0xc5de6e=async function(_0x13f918,..._0x98b308){const _0x2eefc6=this['transaction'](_0x13f918,_0x2842af?'readwrite':'readonly');let _0x22a481=_0x2eefc6['store'];return _0x362665&&(_0x22a481=_0x22a481['index'](_0x98b308['shift']())),(await Promise['all']([_0x22a481[_0x3f4857](..._0x98b308),_0x2842af&&_0x2eefc6['done']]))[0x0];};return si['set'](_0xae7d6d,_0xc5de6e),_0xc5de6e;}Vc(_0x4ab075=>({..._0x4ab075,'get':(_0x545eb2,_0x1365cf,_0x1f3443)=>Ms(_0x545eb2,_0x1365cf)||_0x4ab075['get'](_0x545eb2,_0x1365cf,_0x1f3443),'has':(_0x592aaf,_0x1b954b)=>!!Ms(_0x592aaf,_0x1b954b)||_0x4ab075['has'](_0x592aaf,_0x1b954b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4ed715){this['container']=_0x4ed715;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x22bfb6=>{if(Kc(_0x22bfb6)){const _0x50694a=_0x22bfb6['getImmediate']();return _0x50694a['library']+'/'+_0x50694a['version'];}else return null;})['filter'](_0x414ddd=>_0x414ddd)['join']('\x20');}}function Kc(_0x6f9889){const _0x2b13d3=_0x6f9889['getComponent']();return(_0x2b13d3==null?void 0x0:_0x2b13d3['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x5b84a6,_0xd94d49){try{_0x5b84a6['container']['addComponent'](_0xd94d49);}catch(_0x39d3ae){oe['debug']('Component\x20'+_0xd94d49['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5b84a6['name'],_0x39d3ae);}}function st(_0x203b55){const _0x5dd13f=_0x203b55['name'];if(Ei['has'](_0x5dd13f))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5dd13f+'.'),!0x1;Ei['set'](_0x5dd13f,_0x203b55);for(const _0x378576 of Ue['values']())xs(_0x378576,_0x203b55);for(const _0x202808 of vi['values']())xs(_0x202808,_0x203b55);return!0x0;}function Hi(_0x3ff1ba,_0x33ade4){const _0x4457e5=_0x3ff1ba['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4457e5&&_0x4457e5['triggerHeartbeat'](),_0x3ff1ba['container']['getProvider'](_0x33ade4);}function $(_0x3a3073){return _0x3a3073==null?!0x1:_0x3a3073['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x269ddb,_0x51e3be,_0x50c336){this['_isDeleted']=!0x1,this['_options']={..._0x269ddb},this['_config']={..._0x51e3be},this['_name']=_0x51e3be['name'],this['_automaticDataCollectionEnabled']=_0x51e3be['automaticDataCollectionEnabled'],this['_container']=_0x50c336,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xbd91c4){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xbd91c4;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x4b9f52){this['_isDeleted']=_0x4b9f52;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x2a874a,_0x8afe28={}){let _0x1b1b0a=_0x2a874a;typeof _0x8afe28!='object'&&(_0x8afe28={'name':_0x8afe28});const _0x1574f9={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x8afe28},_0x476861=_0x1574f9['name'];if(typeof _0x476861!='string'||!_0x476861)throw me['create']('bad-app-name',{'appName':String(_0x476861)});if(_0x1b1b0a||(_0x1b1b0a=zr()),!_0x1b1b0a)throw me['create']('no-options');const _0x143970=Ue['get'](_0x476861);if(_0x143970){if(xe(_0x1b1b0a,_0x143970['options'])&&xe(_0x1574f9,_0x143970['config']))return _0x143970;throw me['create']('duplicate-app',{'appName':_0x476861});}const _0x108e8b=new Nc(_0x476861);for(const _0x2db3c5 of Ei['values']())_0x108e8b['addComponent'](_0x2db3c5);const _0x58b707=new Tl(_0x1b1b0a,_0x1574f9,_0x108e8b);return Ue['set'](_0x476861,_0x58b707),_0x58b707;}function Zr(_0x345667=yi){const _0xb0c123=Ue['get'](_0x345667);if(!_0xb0c123&&_0x345667===yi&&zr())return Sl();if(!_0xb0c123)throw me['create']('no-app',{'appName':_0x345667});return _0xb0c123;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x496f00){let _0x47fa81=!0x1;const _0x49a0fd=_0x496f00['name'];Ue['has'](_0x49a0fd)?(_0x47fa81=!0x0,Ue['delete'](_0x49a0fd)):vi['has'](_0x49a0fd)&&_0x496f00['decRefCount']()<=0x0&&(vi['delete'](_0x49a0fd),_0x47fa81=!0x0),_0x47fa81&&(await Promise['all'](_0x496f00['container']['getProviders']()['map'](_0x44abc0=>_0x44abc0['delete']())),_0x496f00['isDeleted']=!0x0);}function ye(_0x2cb122,_0x1a20d4,_0x115373){let _0x49155a=wl[_0x2cb122]??_0x2cb122;_0x115373&&(_0x49155a+='-'+_0x115373);const _0x1563db=_0x49155a['match'](/\s|\//),_0x4d311f=_0x1a20d4['match'](/\s|\//);if(_0x1563db||_0x4d311f){const _0x1a6c1e=['Unable\x20to\x20register\x20library\x20\x22'+_0x49155a+'\x22\x20with\x20version\x20\x22'+_0x1a20d4+'\x22:'];_0x1563db&&_0x1a6c1e['push']('library\x20name\x20\x22'+_0x49155a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1563db&&_0x4d311f&&_0x1a6c1e['push']('and'),_0x4d311f&&_0x1a6c1e['push']('version\x20name\x20\x22'+_0x1a20d4+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1a6c1e['join']('\x20'));return;}st(new Fe(_0x49155a+'-version',()=>({'library':_0x49155a,'version':_0x1a20d4}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x550f7b,_0x271bdf)=>{switch(_0x271bdf){case 0x0:try{_0x550f7b['createObjectStore'](Ot);}catch(_0x22293e){console['warn'](_0x22293e);}}}})['catch'](_0x537c6a=>{throw me['create']('idb-open',{'originalErrorMessage':_0x537c6a['message']});})),ri;}async function Al(_0x25cc0e){try{const _0x41fe95=(await eo())['transaction'](Ot),_0x1cf323=await _0x41fe95['objectStore'](Ot)['get'](to(_0x25cc0e));return await _0x41fe95['done'],_0x1cf323;}catch(_0x128d39){if(_0x128d39 instanceof Re)oe['warn'](_0x128d39['message']);else{const _0xda2b64=me['create']('idb-get',{'originalErrorMessage':_0x128d39==null?void 0x0:_0x128d39['message']});oe['warn'](_0xda2b64['message']);}}}async function Fs(_0x1c32cc,_0x59ce21){try{const _0x22e749=(await eo())['transaction'](Ot,'readwrite');await _0x22e749['objectStore'](Ot)['put'](_0x59ce21,to(_0x1c32cc)),await _0x22e749['done'];}catch(_0x5a2b83){if(_0x5a2b83 instanceof Re)oe['warn'](_0x5a2b83['message']);else{const _0x4fca4a=me['create']('idb-set',{'originalErrorMessage':_0x5a2b83==null?void 0x0:_0x5a2b83['message']});oe['warn'](_0x4fca4a['message']);}}}function to(_0x23951d){return _0x23951d['name']+'!'+_0x23951d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x243001){this['container']=_0x243001,this['_heartbeatsCache']=null;const _0x6ef624=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x6ef624),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x245729=>(this['_heartbeatsCache']=_0x245729,_0x245729));}async['triggerHeartbeat'](){var _0x46b494,_0x5ad20b;try{const _0x2cc565=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3a018a=Us();if(((_0x46b494=this['_heartbeatsCache'])==null?void 0x0:_0x46b494['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5ad20b=this['_heartbeatsCache'])==null?void 0x0:_0x5ad20b['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3a018a||this['_heartbeatsCache']['heartbeats']['some'](_0x443785=>_0x443785['date']===_0x3a018a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3a018a,'agent':_0x2cc565}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x886fe8=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x886fe8,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x48e430){oe['warn'](_0x48e430);}}async['getHeartbeatsHeader'](){var _0x57d18e;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x57d18e=this['_heartbeatsCache'])==null?void 0x0:_0x57d18e['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2d9eab=Us(),{heartbeatsToSend:_0x19c101,unsentEntries:_0x1769c9}=Ol(this['_heartbeatsCache']['heartbeats']),_0x7df13f=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x19c101}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2d9eab,_0x1769c9['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1769c9,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x7df13f;}catch(_0x39afb7){return oe['warn'](_0x39afb7),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x53c59d,_0x5ab25f=kl){const _0x2075f3=[];let _0x1c3862=_0x53c59d['slice']();for(const _0x18b940 of _0x53c59d){const _0x50a3c6=_0x2075f3['find'](_0x252675=>_0x252675['agent']===_0x18b940['agent']);if(_0x50a3c6){if(_0x50a3c6['dates']['push'](_0x18b940['date']),Ws(_0x2075f3)>_0x5ab25f){_0x50a3c6['dates']['pop']();break;}}else{if(_0x2075f3['push']({'agent':_0x18b940['agent'],'dates':[_0x18b940['date']]}),Ws(_0x2075f3)>_0x5ab25f){_0x2075f3['pop']();break;}}_0x1c3862=_0x1c3862['slice'](0x1);}return{'heartbeatsToSend':_0x2075f3,'unsentEntries':_0x1c3862};}class Dl{constructor(_0x5571ad){this['app']=_0x5571ad,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x15ac9e=await Al(this['app']);return _0x15ac9e!=null&&_0x15ac9e['heartbeats']?_0x15ac9e:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4a60b8){if(await this['_canUseIndexedDBPromise']){const _0x615e3d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4a60b8['lastSentHeartbeatDate']??_0x615e3d['lastSentHeartbeatDate'],'heartbeats':_0x4a60b8['heartbeats']});}else return;}async['add'](_0xaa8f03){if(await this['_canUseIndexedDBPromise']){const _0x333d5d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xaa8f03['lastSentHeartbeatDate']??_0x333d5d['lastSentHeartbeatDate'],'heartbeats':[..._0x333d5d['heartbeats'],..._0xaa8f03['heartbeats']]});}else return;}}function Ws(_0x35aa2a){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x35aa2a}))['length'];}function Ml(_0x3bbfc9){if(_0x3bbfc9['length']===0x0)return-0x1;let _0xa1cfb4=0x0,_0x3d500e=_0x3bbfc9[0x0]['date'];for(let _0x51f679=0x1;_0x51f679<_0x3bbfc9['length'];_0x51f679++)_0x3bbfc9[_0x51f679]['date']<_0x3d500e&&(_0x3d500e=_0x3bbfc9[_0x51f679]['date'],_0xa1cfb4=_0x51f679);return _0xa1cfb4;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x5d4e89){st(new Fe('platform-logger',_0x57b46f=>new jc(_0x57b46f),'PRIVATE')),st(new Fe('heartbeat',_0x118547=>new Nl(_0x118547),'PRIVATE')),ye(mi,Ls,_0x5d4e89),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x102d4c){no=_0x102d4c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x10afd2){this['domStorage_']=_0x10afd2,this['prefix_']='firebase:';}['set'](_0x13dfe1,_0x265dc3){_0x265dc3==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x13dfe1)):this['domStorage_']['setItem'](this['prefixedName_'](_0x13dfe1),O(_0x265dc3));}['get'](_0x492929){const _0x323640=this['domStorage_']['getItem'](this['prefixedName_'](_0x492929));return _0x323640==null?null:Nt(_0x323640);}['remove'](_0x48d43e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x48d43e));}['prefixedName_'](_0x42c372){return this['prefix_']+_0x42c372;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x40465b,_0x26ce52){_0x26ce52==null?delete this['cache_'][_0x40465b]:this['cache_'][_0x40465b]=_0x26ce52;}['get'](_0x150ccf){return Q(this['cache_'],_0x150ccf)?this['cache_'][_0x150ccf]:null;}['remove'](_0x14ad8d){delete this['cache_'][_0x14ad8d];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x5d6b9a){try{if(typeof window<'u'&&typeof window[_0x5d6b9a]<'u'){const _0x5eceb5=window[_0x5d6b9a];return _0x5eceb5['setItem']('firebase:sentinel','cache'),_0x5eceb5['removeItem']('firebase:sentinel'),new Wl(_0x5eceb5);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1cd72b=0x1;return function(){return _0x1cd72b++;};}()),ro=function(_0x489606){const _0x5bc13a=Rc(_0x489606),_0x15db97=new Cc();_0x15db97['update'](_0x5bc13a);const _0x3a775c=_0x15db97['digest']();return Fi['encodeByteArray'](_0x3a775c);},zt=function(..._0xf5e64a){let _0x521224='';for(let _0x3758d7=0x0;_0x3758d7<_0xf5e64a['length'];_0x3758d7++){const _0x2cd42a=_0xf5e64a[_0x3758d7];Array['isArray'](_0x2cd42a)||_0x2cd42a&&typeof _0x2cd42a=='object'&&typeof _0x2cd42a['length']=='number'?_0x521224+=zt['apply'](null,_0x2cd42a):typeof _0x2cd42a=='object'?_0x521224+=O(_0x2cd42a):_0x521224+=_0x2cd42a,_0x521224+='\x20';}return _0x521224;};let St=null,$s=!0x0;const Hl=function(_0x240e64,_0xf9de88){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x3c556d){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x25ac98=zt['apply'](null,_0x3c556d);St(_0x25ac98);}},jt=function(_0x512409){return function(..._0x40a4ae){L(_0x512409,..._0x40a4ae);};},Ii=function(..._0x4db258){const _0x207f8e='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x4db258);Ze['error'](_0x207f8e);},ae=function(..._0x1f7980){const _0x486b1d='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1f7980);throw Ze['error'](_0x486b1d),new Error(_0x486b1d);},U=function(..._0x547114){const _0x3aefc3='FIREBASE\x20WARNING:\x20'+zt(..._0x547114);Ze['warn'](_0x3aefc3);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3e877a){return typeof _0x3e877a=='number'&&(_0x3e877a!==_0x3e877a||_0x3e877a===Number['POSITIVE_INFINITY']||_0x3e877a===Number['NEGATIVE_INFINITY']);},Gl=function(_0x353bf0){if(document['readyState']==='complete')_0x353bf0();else{let _0x2da7a4=!0x1;const _0x1e4c4d=function(){if(!document['body']){setTimeout(_0x1e4c4d,Math['floor'](0xa));return;}_0x2da7a4||(_0x2da7a4=!0x0,_0x353bf0());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1e4c4d,!0x1),window['addEventListener']('load',_0x1e4c4d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1e4c4d();}),window['attachEvent']('onload',_0x1e4c4d));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x2d6b80,_0x1c00a9){if(_0x2d6b80===_0x1c00a9)return 0x0;if(_0x2d6b80===We||_0x1c00a9===we)return-0x1;if(_0x1c00a9===We||_0x2d6b80===we)return 0x1;{const _0x17b38e=Gs(_0x2d6b80),_0x477a72=Gs(_0x1c00a9);return _0x17b38e!==null?_0x477a72!==null?_0x17b38e-_0x477a72===0x0?_0x2d6b80['length']-_0x1c00a9['length']:_0x17b38e-_0x477a72:-0x1:_0x477a72!==null?0x1:_0x2d6b80<_0x1c00a9?-0x1:0x1;}},ql=function(_0x356579,_0x595f43){return _0x356579===_0x595f43?0x0:_0x356579<_0x595f43?-0x1:0x1;},vt=function(_0x45b4b3,_0x23bd7){if(_0x23bd7&&_0x45b4b3 in _0x23bd7)return _0x23bd7[_0x45b4b3];throw new Error('Missing\x20required\x20key\x20('+_0x45b4b3+')\x20in\x20object:\x20'+O(_0x23bd7));},$i=function(_0x3f663f){if(typeof _0x3f663f!='object'||_0x3f663f===null)return O(_0x3f663f);const _0x5790e7=[];for(const _0x3251a4 in _0x3f663f)_0x5790e7['push'](_0x3251a4);_0x5790e7['sort']();let _0x22a373='{';for(let _0x28953d=0x0;_0x28953d<_0x5790e7['length'];_0x28953d++)_0x28953d!==0x0&&(_0x22a373+=','),_0x22a373+=O(_0x5790e7[_0x28953d]),_0x22a373+=':',_0x22a373+=$i(_0x3f663f[_0x5790e7[_0x28953d]]);return _0x22a373+='}',_0x22a373;},oo=function(_0x4216b8,_0x11a3b7){const _0x57d99a=_0x4216b8['length'];if(_0x57d99a<=_0x11a3b7)return[_0x4216b8];const _0x5d89b2=[];for(let _0x1796ed=0x0;_0x1796ed<_0x57d99a;_0x1796ed+=_0x11a3b7)_0x1796ed+_0x11a3b7>_0x57d99a?_0x5d89b2['push'](_0x4216b8['substring'](_0x1796ed,_0x57d99a)):_0x5d89b2['push'](_0x4216b8['substring'](_0x1796ed,_0x1796ed+_0x11a3b7));return _0x5d89b2;};function x(_0x474cba,_0xc3a8c4){for(const _0x2e7d4f in _0x474cba)_0x474cba['hasOwnProperty'](_0x2e7d4f)&&_0xc3a8c4(_0x2e7d4f,_0x474cba[_0x2e7d4f]);}const ao=function(_0x3f2b9e){f(!xn(_0x3f2b9e),'Invalid\x20JSON\x20number');const _0x3d1d27=0xb,_0x3213e2=0x34,_0x489d85=(0x1<<_0x3d1d27-0x1)-0x1;let _0xc5164,_0x11c1f4,_0x232700,_0x53f340,_0x59f2cf;_0x3f2b9e===0x0?(_0x11c1f4=0x0,_0x232700=0x0,_0xc5164=0x1/_0x3f2b9e===-0x1/0x0?0x1:0x0):(_0xc5164=_0x3f2b9e<0x0,_0x3f2b9e=Math['abs'](_0x3f2b9e),_0x3f2b9e>=Math['pow'](0x2,0x1-_0x489d85)?(_0x53f340=Math['min'](Math['floor'](Math['log'](_0x3f2b9e)/Math['LN2']),_0x489d85),_0x11c1f4=_0x53f340+_0x489d85,_0x232700=Math['round'](_0x3f2b9e*Math['pow'](0x2,_0x3213e2-_0x53f340)-Math['pow'](0x2,_0x3213e2))):(_0x11c1f4=0x0,_0x232700=Math['round'](_0x3f2b9e/Math['pow'](0x2,0x1-_0x489d85-_0x3213e2))));const _0x5248dc=[];for(_0x59f2cf=_0x3213e2;_0x59f2cf;_0x59f2cf-=0x1)_0x5248dc['push'](_0x232700%0x2?0x1:0x0),_0x232700=Math['floor'](_0x232700/0x2);for(_0x59f2cf=_0x3d1d27;_0x59f2cf;_0x59f2cf-=0x1)_0x5248dc['push'](_0x11c1f4%0x2?0x1:0x0),_0x11c1f4=Math['floor'](_0x11c1f4/0x2);_0x5248dc['push'](_0xc5164?0x1:0x0),_0x5248dc['reverse']();const _0x144585=_0x5248dc['join']('');let _0xd1d67e='';for(_0x59f2cf=0x0;_0x59f2cf<0x40;_0x59f2cf+=0x8){let _0x1615da=parseInt(_0x144585['substr'](_0x59f2cf,0x8),0x2)['toString'](0x10);_0x1615da['length']===0x1&&(_0x1615da='0'+_0x1615da),_0xd1d67e=_0xd1d67e+_0x1615da;}return _0xd1d67e['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x164dfa,_0x590055){let _0x126b1f='Unknown\x20Error';_0x164dfa==='too_big'?_0x126b1f='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x164dfa==='permission_denied'?_0x126b1f='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x164dfa==='unavailable'&&(_0x126b1f='The\x20service\x20is\x20unavailable');const _0x229716=new Error(_0x164dfa+'\x20at\x20'+_0x590055['_path']['toString']()+':\x20'+_0x126b1f);return _0x229716['code']=_0x164dfa['toUpperCase'](),_0x229716;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x439074){if(Yl['test'](_0x439074)){const _0x512a3a=Number(_0x439074);if(_0x512a3a>=Ql&&_0x512a3a<=Jl)return _0x512a3a;}return null;},ft=function(_0x3ab750){try{_0x3ab750();}catch(_0x5aaa88){setTimeout(()=>{const _0x5d161d=_0x5aaa88['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5d161d),_0x5aaa88;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x12366,_0x300d32){const _0x2dffcc=setTimeout(_0x12366,_0x300d32);return typeof _0x2dffcc=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2dffcc):typeof _0x2dffcc=='object'&&_0x2dffcc['unref']&&_0x2dffcc['unref'](),_0x2dffcc;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x278d5c,_0x4501d5){this['appCheckProvider']=_0x4501d5,this['appName']=_0x278d5c['name'],$(_0x278d5c)&&_0x278d5c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x278d5c['settings']['appCheckToken']),this['appCheck']=_0x4501d5==null?void 0x0:_0x4501d5['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4501d5==null||_0x4501d5['get']()['then'](_0xa1fa35=>this['appCheck']=_0xa1fa35);}['getToken'](_0x14c134){if(this['serverAppAppCheckToken']){if(_0x14c134)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x14c134):new Promise((_0x43209e,_0x568671)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x14c134)['then'](_0x43209e,_0x568671):_0x43209e(null);},0x0);});}['addTokenChangeListener'](_0x3d4a64){var _0x34a7e1;(_0x34a7e1=this['appCheckProvider'])==null||_0x34a7e1['get']()['then'](_0x15f833=>_0x15f833['addTokenListener'](_0x3d4a64));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2b5c6c,_0x160758,_0x2440c0){this['appName_']=_0x2b5c6c,this['firebaseOptions_']=_0x160758,this['authProvider_']=_0x2440c0,this['auth_']=null,this['auth_']=_0x2440c0['getImmediate']({'optional':!0x0}),this['auth_']||_0x2440c0['onInit'](_0x10f41a=>this['auth_']=_0x10f41a);}['getToken'](_0x3bf4d4){return this['auth_']?this['auth_']['getToken'](_0x3bf4d4)['catch'](_0x16b07e=>_0x16b07e&&_0x16b07e['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x16b07e)):new Promise((_0x2a6e58,_0xb09bae)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3bf4d4)['then'](_0x2a6e58,_0xb09bae):_0x2a6e58(null);},0x0);});}['addTokenChangeListener'](_0x4017bd){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4017bd):this['authProvider_']['get']()['then'](_0xc4fa13=>_0xc4fa13['addAuthTokenListener'](_0x4017bd));}['removeTokenChangeListener'](_0x4855a0){this['authProvider_']['get']()['then'](_0x2c78de=>_0x2c78de['removeAuthTokenListener'](_0x4855a0));}['notifyForInvalidToken'](){let _0x2b0396='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2b0396+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2b0396+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2b0396+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2b0396);}}class an{constructor(_0x483ca0){this['accessToken']=_0x483ca0;}['getToken'](_0x3844fa){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4d876a){_0x4d876a(this['accessToken']);}['removeTokenChangeListener'](_0x33b02d){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x512fdf,_0x2bc45e,_0x75d824,_0xe43e39,_0x40a4fe=!0x1,_0xa1dde0='',_0x3d79b8=!0x1,_0x5a3ca5=!0x1,_0x408a4a=null){this['secure']=_0x2bc45e,this['namespace']=_0x75d824,this['webSocketOnly']=_0xe43e39,this['nodeAdmin']=_0x40a4fe,this['persistenceKey']=_0xa1dde0,this['includeNamespaceInQueryParams']=_0x3d79b8,this['isUsingEmulator']=_0x5a3ca5,this['emulatorOptions']=_0x408a4a,this['_host']=_0x512fdf['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x512fdf)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x590f57){_0x590f57!==this['internalHost']&&(this['internalHost']=_0x590f57,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x54a755=this['toURLString']();return this['persistenceKey']&&(_0x54a755+='<'+this['persistenceKey']+'>'),_0x54a755;}['toURLString'](){const _0x5dd083=this['secure']?'https://':'http://',_0x2d539c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5dd083+this['host']+'/'+_0x2d539c;}}function th(_0x3b7248){return _0x3b7248['host']!==_0x3b7248['internalHost']||_0x3b7248['isCustomHost']()||_0x3b7248['includeNamespaceInQueryParams'];}function vo(_0x47448b,_0x344786,_0x3ff849){f(typeof _0x344786=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3ff849=='object','typeof\x20params\x20must\x20==\x20object');let _0x1e9403;if(_0x344786===go)_0x1e9403=(_0x47448b['secure']?'wss://':'ws://')+_0x47448b['internalHost']+'/.ws?';else{if(_0x344786===mo)_0x1e9403=(_0x47448b['secure']?'https://':'http://')+_0x47448b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x344786);}th(_0x47448b)&&(_0x3ff849['ns']=_0x47448b['namespace']);const _0x2d8b27=[];return x(_0x3ff849,(_0x4a3849,_0x3df946)=>{_0x2d8b27['push'](_0x4a3849+'='+_0x3df946);}),_0x1e9403+_0x2d8b27['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x31b5b7,_0x56c360=0x1){Q(this['counters_'],_0x31b5b7)||(this['counters_'][_0x31b5b7]=0x0),this['counters_'][_0x31b5b7]+=_0x56c360;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x409e20){const _0x4e12d5=_0x409e20['toString']();return oi[_0x4e12d5]||(oi[_0x4e12d5]=new nh()),oi[_0x4e12d5];}function ih(_0x2fa2a2,_0x275596){const _0x18f2c9=_0x2fa2a2['toString']();return ai[_0x18f2c9]||(ai[_0x18f2c9]=_0x275596()),ai[_0x18f2c9];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x313e34){this['onMessage_']=_0x313e34,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3c08aa,_0x3bb75e){this['closeAfterResponse']=_0x3c08aa,this['onClose']=_0x3bb75e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2d30a8,_0x283476){for(this['pendingResponses'][_0x2d30a8]=_0x283476;this['pendingResponses'][this['currentResponseNum']];){const _0x15683b=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3b13a1=0x0;_0x3b13a1<_0x15683b['length'];++_0x3b13a1)_0x15683b[_0x3b13a1]&&ft(()=>{this['onMessage_'](_0x15683b[_0x3b13a1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x56dc80,_0x4043f0,_0x10d269,_0x24032e,_0x4266b5,_0x5d10cd,_0x3ed570){this['connId']=_0x56dc80,this['repoInfo']=_0x4043f0,this['applicationId']=_0x10d269,this['appCheckToken']=_0x24032e,this['authToken']=_0x4266b5,this['transportSessionId']=_0x5d10cd,this['lastSessionId']=_0x3ed570,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x56dc80),this['stats_']=qi(_0x4043f0),this['urlFn']=_0x2bb446=>(this['appCheckToken']&&(_0x2bb446[wi]=this['appCheckToken']),vo(_0x4043f0,mo,_0x2bb446));}['open'](_0x4907a6,_0x199fe3){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x199fe3,this['myPacketOrderer']=new sh(_0x4907a6),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x113ad2)=>{const [_0x4024b0,_0xb1d7de,_0x2c28f9,_0x88e93c,_0x984ac6]=_0x113ad2;if(this['incrementIncomingBytes_'](_0x113ad2),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4024b0===qs)this['id']=_0xb1d7de,this['password']=_0x2c28f9;else{if(_0x4024b0===rh)_0xb1d7de?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xb1d7de,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4024b0);}}},(..._0x5bc97b)=>{const [_0x4f75c2,_0x29b948]=_0x5bc97b;this['incrementIncomingBytes_'](_0x5bc97b),this['myPacketOrderer']['handleResponse'](_0x4f75c2,_0x29b948);},()=>{this['onClosed_']();},this['urlFn']);const _0x1a6935={};_0x1a6935[qs]='t',_0x1a6935[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1a6935[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1a6935[co]=Gi,this['transportSessionId']&&(_0x1a6935[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1a6935[po]=this['lastSessionId']),this['applicationId']&&(_0x1a6935[_o]=this['applicationId']),this['appCheckToken']&&(_0x1a6935[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1a6935[ho]=uo);const _0x631dba=this['urlFn'](_0x1a6935);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x631dba),this['scriptTagHolder']['addTag'](_0x631dba,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3a2a1a){const _0x454cca=O(_0x3a2a1a);this['bytesSent']+=_0x454cca['length'],this['stats_']['incrementCounter']('bytes_sent',_0x454cca['length']);const _0x503e1a=$r(_0x454cca),_0x4aef7f=oo(_0x503e1a,fh);for(let _0x31eac0=0x0;_0x31eac0<_0x4aef7f['length'];_0x31eac0++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4aef7f['length'],_0x4aef7f[_0x31eac0]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xd92a26,_0x4d9811){this['myDisconnFrame']=document['createElement']('iframe');const _0x16ddfb={};_0x16ddfb[dh]='t',_0x16ddfb[Eo]=_0xd92a26,_0x16ddfb[Io]=_0x4d9811,this['myDisconnFrame']['src']=this['urlFn'](_0x16ddfb),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2a5da4){const _0x14e39e=O(_0x2a5da4)['length'];this['bytesReceived']+=_0x14e39e,this['stats_']['incrementCounter']('bytes_received',_0x14e39e);}}class zi{constructor(_0x2813bd,_0x11442f,_0x214186,_0x229576){this['onDisconnect']=_0x214186,this['urlFn']=_0x229576,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2813bd,window[ah+this['uniqueCallbackIdentifier']]=_0x11442f,this['myIFrame']=zi['createIFrame_']();let _0x261e77='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x261e77='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2dd247='<html><body>'+_0x261e77+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2dd247),this['myIFrame']['doc']['close']();}catch(_0x1b1062){L('frame\x20writing\x20exception'),_0x1b1062['stack']&&L(_0x1b1062['stack']),L(_0x1b1062);}}}static['createIFrame_'](){const _0x57d3a5=document['createElement']('iframe');if(_0x57d3a5['style']['display']='none',document['body']){document['body']['appendChild'](_0x57d3a5);try{_0x57d3a5['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x39dff3=document['domain'];_0x57d3a5['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x39dff3+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x57d3a5['contentDocument']?_0x57d3a5['doc']=_0x57d3a5['contentDocument']:_0x57d3a5['contentWindow']?_0x57d3a5['doc']=_0x57d3a5['contentWindow']['document']:_0x57d3a5['document']&&(_0x57d3a5['doc']=_0x57d3a5['document']),_0x57d3a5;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1364be=this['onDisconnect'];_0x1364be&&(this['onDisconnect']=null,_0x1364be());}['startLongPoll'](_0x4feaf4,_0x19be00){for(this['myID']=_0x4feaf4,this['myPW']=_0x19be00,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x265426={};_0x265426[Eo]=this['myID'],_0x265426[Io]=this['myPW'],_0x265426[wo]=this['currentSerial'];let _0x420ee7=this['urlFn'](_0x265426),_0x1c25c3='',_0x5b9ad3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1c25c3['length']<=Co;){const _0x43d72f=this['pendingSegs']['shift']();_0x1c25c3=_0x1c25c3+'&'+lh+_0x5b9ad3+'='+_0x43d72f['seg']+'&'+hh+_0x5b9ad3+'='+_0x43d72f['ts']+'&'+uh+_0x5b9ad3+'='+_0x43d72f['d'],_0x5b9ad3++;}return _0x420ee7=_0x420ee7+_0x1c25c3,this['addLongPollTag_'](_0x420ee7,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x22a7ca,_0x56a360,_0x147d16){this['pendingSegs']['push']({'seg':_0x22a7ca,'ts':_0x56a360,'d':_0x147d16}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x28320e,_0x5bbd2c){this['outstandingRequests']['add'](_0x5bbd2c);const _0x426937=()=>{this['outstandingRequests']['delete'](_0x5bbd2c),this['newRequest_']();},_0x20937e=setTimeout(_0x426937,Math['floor'](ph)),_0x35332d=()=>{clearTimeout(_0x20937e),_0x426937();};this['addTag'](_0x28320e,_0x35332d);}['addTag'](_0x428723,_0x12bde3){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5bf201=this['myIFrame']['doc']['createElement']('script');_0x5bf201['type']='text/javascript',_0x5bf201['async']=!0x0,_0x5bf201['src']=_0x428723,_0x5bf201['onload']=_0x5bf201['onreadystatechange']=function(){const _0x389614=_0x5bf201['readyState'];(!_0x389614||_0x389614==='loaded'||_0x389614==='complete')&&(_0x5bf201['onload']=_0x5bf201['onreadystatechange']=null,_0x5bf201['parentNode']&&_0x5bf201['parentNode']['removeChild'](_0x5bf201),_0x12bde3());},_0x5bf201['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x428723),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5bf201);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x58c013,_0x1be1d6,_0x1e4971,_0x52125d,_0x56fd7d,_0x4b0161,_0x5da248){this['connId']=_0x58c013,this['applicationId']=_0x1e4971,this['appCheckToken']=_0x52125d,this['authToken']=_0x56fd7d,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x1be1d6),this['connURL']=q['connectionURL_'](_0x1be1d6,_0x4b0161,_0x5da248,_0x52125d,_0x1e4971),this['nodeAdmin']=_0x1be1d6['nodeAdmin'];}static['connectionURL_'](_0x27f635,_0x905918,_0x17e90d,_0x4b6796,_0x1de602){const _0xd7a7ed={};return _0xd7a7ed[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xd7a7ed[ho]=uo),_0x905918&&(_0xd7a7ed[lo]=_0x905918),_0x17e90d&&(_0xd7a7ed[po]=_0x17e90d),_0x4b6796&&(_0xd7a7ed[wi]=_0x4b6796),_0x1de602&&(_0xd7a7ed[_o]=_0x1de602),vo(_0x27f635,go,_0xd7a7ed);}['open'](_0x1f8077,_0x418b12){this['onDisconnect']=_0x418b12,this['onMessage']=_0x1f8077,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x1b3cfd;_c(),this['mySock']=new gn(this['connURL'],[],_0x1b3cfd);}catch(_0x34695c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3a1fc0=_0x34695c['message']||_0x34695c['data'];_0x3a1fc0&&this['log_'](_0x3a1fc0),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3a6f44=>{this['handleIncomingFrame'](_0x3a6f44);},this['mySock']['onerror']=_0x232f98=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1b15a2=_0x232f98['message']||_0x232f98['data'];_0x1b15a2&&this['log_'](_0x1b15a2),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x54ea27=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x18c8a7=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x6a66f=navigator['userAgent']['match'](_0x18c8a7);_0x6a66f&&_0x6a66f['length']>0x1&&parseFloat(_0x6a66f[0x1])<4.4&&(_0x54ea27=!0x0);}return!_0x54ea27&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x38d0c1){if(this['frames']['push'](_0x38d0c1),this['frames']['length']===this['totalFrames']){const _0x7a733c=this['frames']['join']('');this['frames']=null;const _0xb25a91=Nt(_0x7a733c);this['onMessage'](_0xb25a91);}}['handleNewFrameCount_'](_0x2f29d9){this['totalFrames']=_0x2f29d9,this['frames']=[];}['extractFrameCount_'](_0x2a54bd){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2a54bd['length']<=0x6){const _0x4a9e71=Number(_0x2a54bd);if(!isNaN(_0x4a9e71))return this['handleNewFrameCount_'](_0x4a9e71),null;}return this['handleNewFrameCount_'](0x1),_0x2a54bd;}['handleIncomingFrame'](_0x5b74b5){if(this['mySock']===null)return;const _0x47a8d8=_0x5b74b5['data'];if(this['bytesReceived']+=_0x47a8d8['length'],this['stats_']['incrementCounter']('bytes_received',_0x47a8d8['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x47a8d8);else{const _0x57a0d1=this['extractFrameCount_'](_0x47a8d8);_0x57a0d1!==null&&this['appendFrame_'](_0x57a0d1);}}['send'](_0x189cf4){this['resetKeepAlive']();const _0x1f3dc5=O(_0x189cf4);this['bytesSent']+=_0x1f3dc5['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1f3dc5['length']);const _0x56e56d=oo(_0x1f3dc5,gh);_0x56e56d['length']>0x1&&this['sendString_'](String(_0x56e56d['length']));for(let _0x3ccf2b=0x0;_0x3ccf2b<_0x56e56d['length'];_0x3ccf2b++)this['sendString_'](_0x56e56d[_0x3ccf2b]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3fcff0){try{this['mySock']['send'](_0x3fcff0);}catch(_0x5ebfe7){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5ebfe7['message']||_0x5ebfe7['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2227e9){this['initTransports_'](_0x2227e9);}['initTransports_'](_0x399144){const _0x2e6497=q&&q['isAvailable']();let _0x1ee7d9=_0x2e6497&&!q['previouslyFailed']();if(_0x399144['webSocketOnly']&&(_0x2e6497||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1ee7d9=!0x0),_0x1ee7d9)this['transports_']=[q];else{const _0x1e9608=this['transports_']=[];for(const _0x13e764 of Dt['ALL_TRANSPORTS'])_0x13e764&&_0x13e764['isAvailable']()&&_0x1e9608['push'](_0x13e764);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x23aaca,_0x433ed1,_0x797ae9,_0x5bf1ea,_0x3d8edd,_0x2d16b1,_0xe5a3d,_0x48e5d7,_0x56461b,_0x523db9){this['id']=_0x23aaca,this['repoInfo_']=_0x433ed1,this['applicationId_']=_0x797ae9,this['appCheckToken_']=_0x5bf1ea,this['authToken_']=_0x3d8edd,this['onMessage_']=_0x2d16b1,this['onReady_']=_0xe5a3d,this['onDisconnect_']=_0x48e5d7,this['onKill_']=_0x56461b,this['lastSessionId']=_0x523db9,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x433ed1),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xd1ad5c=this['transportManager_']['initialTransport']();this['conn_']=new _0xd1ad5c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xd1ad5c['responsesRequiredToBeHealthy']||0x0;const _0x53a4be=this['connReceiver_'](this['conn_']),_0x41e8d2=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x53a4be,_0x41e8d2);},Math['floor'](0x0));const _0x5bf134=_0xd1ad5c['healthyTimeout']||0x0;_0x5bf134>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5bf134)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x20a707){return _0x4648ff=>{_0x20a707===this['conn_']?this['onConnectionLost_'](_0x4648ff):_0x20a707===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2c2acf){return _0x2a3c4b=>{this['state_']!==0x2&&(_0x2c2acf===this['rx_']?this['onPrimaryMessageReceived_'](_0x2a3c4b):_0x2c2acf===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2a3c4b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x379d70){const _0x30a72e={'t':'d','d':_0x379d70};this['sendData_'](_0x30a72e);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1f2686){if(ci in _0x1f2686){const _0x5118ea=_0x1f2686[ci];_0x5118ea===Ys?this['upgradeIfSecondaryHealthy_']():_0x5118ea===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5118ea===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x166681){const _0x20d575=vt('t',_0x166681),_0x598a0b=vt('d',_0x166681);if(_0x20d575==='c')this['onSecondaryControl_'](_0x598a0b);else{if(_0x20d575==='d')this['pendingDataMessages']['push'](_0x598a0b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x20d575);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xb70835){const _0x9e495e=vt('t',_0xb70835),_0x50991e=vt('d',_0xb70835);_0x9e495e==='c'?this['onControl_'](_0x50991e):_0x9e495e==='d'&&this['onDataMessage_'](_0x50991e);}['onDataMessage_'](_0x2f3fb0){this['onPrimaryResponse_'](),this['onMessage_'](_0x2f3fb0);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x38c6a5){const _0x4f10cf=vt(ci,_0x38c6a5);if(zs in _0x38c6a5){const _0xd9ddee=_0x38c6a5[zs];if(_0x4f10cf===Th){const _0x385e8c={..._0xd9ddee};this['repoInfo_']['isUsingEmulator']&&(_0x385e8c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x385e8c);}else{if(_0x4f10cf===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xbc022b=0x0;_0xbc022b<this['pendingDataMessages']['length'];++_0xbc022b)this['onDataMessage_'](this['pendingDataMessages'][_0xbc022b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4f10cf===wh?this['onConnectionShutdown_'](_0xd9ddee):_0x4f10cf===js?this['onReset_'](_0xd9ddee):_0x4f10cf===Ch?Ii('Server\x20Error:\x20'+_0xd9ddee):_0x4f10cf===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x4f10cf);}}}['onHandshake_'](_0x38190a){const _0xe59b0d=_0x38190a['ts'],_0x2beda8=_0x38190a['v'],_0x409330=_0x38190a['h'];this['sessionId']=_0x38190a['s'],this['repoInfo_']['host']=_0x409330,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xe59b0d),Gi!==_0x2beda8&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xf437bc=this['transportManager_']['upgradeTransport']();_0xf437bc&&this['startUpgrade_'](_0xf437bc);}['startUpgrade_'](_0x287d62){this['secondaryConn_']=new _0x287d62(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x287d62['responsesRequiredToBeHealthy']||0x0;const _0x3bf1d0=this['connReceiver_'](this['secondaryConn_']),_0x37a1d3=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3bf1d0,_0x37a1d3),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x4351ea){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4351ea),this['repoInfo_']['host']=_0x4351ea,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x39f379,_0xf3e8dd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x39f379,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xf3e8dd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3dab08=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3dab08||this['rx_']===_0x3dab08)&&this['close']();}['onConnectionLost_'](_0x2e566d){this['conn_']=null,!_0x2e566d&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x396f9a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x396f9a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x206f90){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x206f90);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4cf60d,_0x401742,_0x228548,_0x1cd618){}['merge'](_0xd0725,_0x5af229,_0x587e0b,_0x4b27a9){}['refreshAuthToken'](_0x2652da){}['refreshAppCheckToken'](_0x1795f1){}['onDisconnectPut'](_0x53d46f,_0x28c617,_0x5338ac){}['onDisconnectMerge'](_0x4f9f4f,_0x45f3be,_0x55752e){}['onDisconnectCancel'](_0xd77ea1,_0xf2ada0){}['reportStats'](_0x31b31a){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1cc588){this['allowedEvents_']=_0x1cc588,this['listeners_']={},f(Array['isArray'](_0x1cc588)&&_0x1cc588['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x28838e,..._0x272a61){if(Array['isArray'](this['listeners_'][_0x28838e])){const _0x160695=[...this['listeners_'][_0x28838e]];for(let _0x2414d7=0x0;_0x2414d7<_0x160695['length'];_0x2414d7++)_0x160695[_0x2414d7]['callback']['apply'](_0x160695[_0x2414d7]['context'],_0x272a61);}}['on'](_0x115f3a,_0x243b47,_0x556583){this['validateEventType_'](_0x115f3a),this['listeners_'][_0x115f3a]=this['listeners_'][_0x115f3a]||[],this['listeners_'][_0x115f3a]['push']({'callback':_0x243b47,'context':_0x556583});const _0x188a17=this['getInitialEvent'](_0x115f3a);_0x188a17&&_0x243b47['apply'](_0x556583,_0x188a17);}['off'](_0x1b343f,_0x3d4c1b,_0x1d1a3a){this['validateEventType_'](_0x1b343f);const _0x1a4e0b=this['listeners_'][_0x1b343f]||[];for(let _0x1a8660=0x0;_0x1a8660<_0x1a4e0b['length'];_0x1a8660++)if(_0x1a4e0b[_0x1a8660]['callback']===_0x3d4c1b&&(!_0x1d1a3a||_0x1d1a3a===_0x1a4e0b[_0x1a8660]['context'])){_0x1a4e0b['splice'](_0x1a8660,0x1);return;}}['validateEventType_'](_0x239cae){f(this['allowedEvents_']['find'](_0x18fd87=>_0x18fd87===_0x239cae),'Unknown\x20event:\x20'+_0x239cae);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x43d417){return f(_0x43d417==='online','Unknown\x20event\x20type:\x20'+_0x43d417),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0xe0f66,_0x51ecb8){if(_0x51ecb8===void 0x0){this['pieces_']=_0xe0f66['split']('/');let _0x40d871=0x0;for(let _0x47d40c=0x0;_0x47d40c<this['pieces_']['length'];_0x47d40c++)this['pieces_'][_0x47d40c]['length']>0x0&&(this['pieces_'][_0x40d871]=this['pieces_'][_0x47d40c],_0x40d871++);this['pieces_']['length']=_0x40d871,this['pieceNum_']=0x0;}else this['pieces_']=_0xe0f66,this['pieceNum_']=_0x51ecb8;}['toString'](){let _0x3014e8='';for(let _0x262f3d=this['pieceNum_'];_0x262f3d<this['pieces_']['length'];_0x262f3d++)this['pieces_'][_0x262f3d]!==''&&(_0x3014e8+='/'+this['pieces_'][_0x262f3d]);return _0x3014e8||'/';}}function w(){return new C('');}function y(_0x173f74){return _0x173f74['pieceNum_']>=_0x173f74['pieces_']['length']?null:_0x173f74['pieces_'][_0x173f74['pieceNum_']];}function Ce(_0x52cc31){return _0x52cc31['pieces_']['length']-_0x52cc31['pieceNum_'];}function S(_0x5e9866){let _0x305e2b=_0x5e9866['pieceNum_'];return _0x305e2b<_0x5e9866['pieces_']['length']&&_0x305e2b++,new C(_0x5e9866['pieces_'],_0x305e2b);}function ji(_0x44c89e){return _0x44c89e['pieceNum_']<_0x44c89e['pieces_']['length']?_0x44c89e['pieces_'][_0x44c89e['pieces_']['length']-0x1]:null;}function bh(_0x20846e){let _0x7fd3bd='';for(let _0x4a3f63=_0x20846e['pieceNum_'];_0x4a3f63<_0x20846e['pieces_']['length'];_0x4a3f63++)_0x20846e['pieces_'][_0x4a3f63]!==''&&(_0x7fd3bd+='/'+encodeURIComponent(String(_0x20846e['pieces_'][_0x4a3f63])));return _0x7fd3bd||'/';}function Mt(_0x330bfb,_0x502c77=0x0){return _0x330bfb['pieces_']['slice'](_0x330bfb['pieceNum_']+_0x502c77);}function Ro(_0x5645b2){if(_0x5645b2['pieceNum_']>=_0x5645b2['pieces_']['length'])return null;const _0x2e09b1=[];for(let _0x1a1988=_0x5645b2['pieceNum_'];_0x1a1988<_0x5645b2['pieces_']['length']-0x1;_0x1a1988++)_0x2e09b1['push'](_0x5645b2['pieces_'][_0x1a1988]);return new C(_0x2e09b1,0x0);}function k(_0x59d38e,_0x58f962){const _0xde77d4=[];for(let _0x2bb70e=_0x59d38e['pieceNum_'];_0x2bb70e<_0x59d38e['pieces_']['length'];_0x2bb70e++)_0xde77d4['push'](_0x59d38e['pieces_'][_0x2bb70e]);if(_0x58f962 instanceof C){for(let _0x21a449=_0x58f962['pieceNum_'];_0x21a449<_0x58f962['pieces_']['length'];_0x21a449++)_0xde77d4['push'](_0x58f962['pieces_'][_0x21a449]);}else{const _0xa22e64=_0x58f962['split']('/');for(let _0x498962=0x0;_0x498962<_0xa22e64['length'];_0x498962++)_0xa22e64[_0x498962]['length']>0x0&&_0xde77d4['push'](_0xa22e64[_0x498962]);}return new C(_0xde77d4,0x0);}function v(_0x2ca92e){return _0x2ca92e['pieceNum_']>=_0x2ca92e['pieces_']['length'];}function F(_0x592eb1,_0x395a76){const _0x165a8c=y(_0x592eb1),_0x284afa=y(_0x395a76);if(_0x165a8c===null)return _0x395a76;if(_0x165a8c===_0x284afa)return F(S(_0x592eb1),S(_0x395a76));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x395a76+')\x20is\x20not\x20within\x20outerPath\x20('+_0x592eb1+')');}function Rh(_0x367e0d,_0x548bf1){const _0x1f7cef=Mt(_0x367e0d,0x0),_0x48c77c=Mt(_0x548bf1,0x0);for(let _0x2d2942=0x0;_0x2d2942<_0x1f7cef['length']&&_0x2d2942<_0x48c77c['length'];_0x2d2942++){const _0x5ce704=qe(_0x1f7cef[_0x2d2942],_0x48c77c[_0x2d2942]);if(_0x5ce704!==0x0)return _0x5ce704;}return _0x1f7cef['length']===_0x48c77c['length']?0x0:_0x1f7cef['length']<_0x48c77c['length']?-0x1:0x1;}function Ki(_0x7eab87,_0x438fc6){if(Ce(_0x7eab87)!==Ce(_0x438fc6))return!0x1;for(let _0x3f9fa6=_0x7eab87['pieceNum_'],_0x1b2a1e=_0x438fc6['pieceNum_'];_0x3f9fa6<=_0x7eab87['pieces_']['length'];_0x3f9fa6++,_0x1b2a1e++)if(_0x7eab87['pieces_'][_0x3f9fa6]!==_0x438fc6['pieces_'][_0x1b2a1e])return!0x1;return!0x0;}function G(_0x30f2f2,_0x1632bf){let _0x19fa23=_0x30f2f2['pieceNum_'],_0x5a207c=_0x1632bf['pieceNum_'];if(Ce(_0x30f2f2)>Ce(_0x1632bf))return!0x1;for(;_0x19fa23<_0x30f2f2['pieces_']['length'];){if(_0x30f2f2['pieces_'][_0x19fa23]!==_0x1632bf['pieces_'][_0x5a207c])return!0x1;++_0x19fa23,++_0x5a207c;}return!0x0;}class Ah{constructor(_0x887691,_0x43fb7a){this['errorPrefix_']=_0x43fb7a,this['parts_']=Mt(_0x887691,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4b759c=0x0;_0x4b759c<this['parts_']['length'];_0x4b759c++)this['byteLength_']+=Ln(this['parts_'][_0x4b759c]);Ao(this);}}function kh(_0x191a0d,_0x2dedf7){_0x191a0d['parts_']['length']>0x0&&(_0x191a0d['byteLength_']+=0x1),_0x191a0d['parts_']['push'](_0x2dedf7),_0x191a0d['byteLength_']+=Ln(_0x2dedf7),Ao(_0x191a0d);}function Ph(_0x19e6c4){const _0xe6a196=_0x19e6c4['parts_']['pop']();_0x19e6c4['byteLength_']-=Ln(_0xe6a196),_0x19e6c4['parts_']['length']>0x0&&(_0x19e6c4['byteLength_']-=0x1);}function Ao(_0x4c1017){if(_0x4c1017['byteLength_']>Zs)throw new Error(_0x4c1017['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4c1017['byteLength_']+').');if(_0x4c1017['parts_']['length']>Xs)throw new Error(_0x4c1017['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4c1017));}function Oe(_0x425537){return _0x425537['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x425537['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x581f01,_0x229203;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x229203='visibilitychange',_0x581f01='hidden'):typeof document['mozHidden']<'u'?(_0x229203='mozvisibilitychange',_0x581f01='mozHidden'):typeof document['msHidden']<'u'?(_0x229203='msvisibilitychange',_0x581f01='msHidden'):typeof document['webkitHidden']<'u'&&(_0x229203='webkitvisibilitychange',_0x581f01='webkitHidden')),this['visible_']=!0x0,_0x229203&&document['addEventListener'](_0x229203,()=>{const _0x48c4e5=!document[_0x581f01];_0x48c4e5!==this['visible_']&&(this['visible_']=_0x48c4e5,this['trigger']('visible',_0x48c4e5));},!0x1);}['getInitialEvent'](_0x14fa39){return f(_0x14fa39==='visible','Unknown\x20event\x20type:\x20'+_0x14fa39),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x838b95,_0x4a03d0,_0x555d19,_0x2df72b,_0x10c6c4,_0xd6755f,_0x1f0b38,_0x50faeb){if(super(),this['repoInfo_']=_0x838b95,this['applicationId_']=_0x4a03d0,this['onDataUpdate_']=_0x555d19,this['onConnectStatus_']=_0x2df72b,this['onServerInfoUpdate_']=_0x10c6c4,this['authTokenProvider_']=_0xd6755f,this['appCheckTokenProvider_']=_0x1f0b38,this['authOverride_']=_0x50faeb,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x50faeb)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x838b95['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2a9c05,_0x182dcb,_0x58212b){const _0x361723=++this['requestNumber_'],_0x178590={'r':_0x361723,'a':_0x2a9c05,'b':_0x182dcb};this['log_'](O(_0x178590)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x178590),_0x58212b&&(this['requestCBHash_'][_0x361723]=_0x58212b);}['get'](_0x4a58ff){this['initConnection_']();const _0x3d847e=new H(),_0x3a9ed4={'action':'g','request':{'p':_0x4a58ff['_path']['toString'](),'q':_0x4a58ff['_queryObject']},'onComplete':_0x43b560=>{const _0x2cb175=_0x43b560['d'];_0x43b560['s']==='ok'?_0x3d847e['resolve'](_0x2cb175):_0x3d847e['reject'](_0x2cb175);}};this['outstandingGets_']['push'](_0x3a9ed4),this['outstandingGetCount_']++;const _0x9d4f1=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x9d4f1),_0x3d847e['promise'];}['listen'](_0x1fd259,_0x3bf65e,_0x582d41,_0x2144da){this['initConnection_']();const _0x3d19e7=_0x1fd259['_queryIdentifier'],_0x55b288=_0x1fd259['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x55b288+'\x20'+_0x3d19e7),this['listens']['has'](_0x55b288)||this['listens']['set'](_0x55b288,new Map()),f(_0x1fd259['_queryParams']['isDefault']()||!_0x1fd259['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x55b288)['has'](_0x3d19e7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1e286d={'onComplete':_0x2144da,'hashFn':_0x3bf65e,'query':_0x1fd259,'tag':_0x582d41};this['listens']['get'](_0x55b288)['set'](_0x3d19e7,_0x1e286d),this['connected_']&&this['sendListen_'](_0x1e286d);}['sendGet_'](_0x206f30){const _0xbe4e39=this['outstandingGets_'][_0x206f30];this['sendRequest']('g',_0xbe4e39['request'],_0x3077d1=>{delete this['outstandingGets_'][_0x206f30],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xbe4e39['onComplete']&&_0xbe4e39['onComplete'](_0x3077d1);});}['sendListen_'](_0x4d6dca){const _0x46b963=_0x4d6dca['query'],_0x437d07=_0x46b963['_path']['toString'](),_0x2b5167=_0x46b963['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x437d07+'\x20for\x20'+_0x2b5167);const _0x32a697={'p':_0x437d07},_0xd31de7='q';_0x4d6dca['tag']&&(_0x32a697['q']=_0x46b963['_queryObject'],_0x32a697['t']=_0x4d6dca['tag']),_0x32a697['h']=_0x4d6dca['hashFn'](),this['sendRequest'](_0xd31de7,_0x32a697,_0x3eed33=>{const _0x38d6a6=_0x3eed33['d'],_0x45772d=_0x3eed33['s'];se['warnOnListenWarnings_'](_0x38d6a6,_0x46b963),(this['listens']['get'](_0x437d07)&&this['listens']['get'](_0x437d07)['get'](_0x2b5167))===_0x4d6dca&&(this['log_']('listen\x20response',_0x3eed33),_0x45772d!=='ok'&&this['removeListen_'](_0x437d07,_0x2b5167),_0x4d6dca['onComplete']&&_0x4d6dca['onComplete'](_0x45772d,_0x38d6a6));});}static['warnOnListenWarnings_'](_0x4f3704,_0x1d63dc){if(_0x4f3704&&typeof _0x4f3704=='object'&&Q(_0x4f3704,'w')){const _0x4c652c=Le(_0x4f3704,'w');if(Array['isArray'](_0x4c652c)&&~_0x4c652c['indexOf']('no_index')){const _0x11dd5d='\x22.indexOn\x22:\x20\x22'+_0x1d63dc['_queryParams']['getIndex']()['toString']()+'\x22',_0x44fb98=_0x1d63dc['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x11dd5d+'\x20at\x20'+_0x44fb98+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3cdf83){this['authToken_']=_0x3cdf83,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3cdf83);}['reduceReconnectDelayIfAdminCredential_'](_0x2fc702){(_0x2fc702&&_0x2fc702['length']===0x28||wc(_0x2fc702))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x438a54){this['appCheckToken_']=_0x438a54,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x379518=this['authToken_'],_0x630896=Ic(_0x379518)?'auth':'gauth',_0x41bda1={'cred':_0x379518};this['authOverride_']===null?_0x41bda1['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x41bda1['authvar']=this['authOverride_']),this['sendRequest'](_0x630896,_0x41bda1,_0x27758c=>{const _0x19465b=_0x27758c['s'],_0x5be378=_0x27758c['d']||'error';this['authToken_']===_0x379518&&(_0x19465b==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x19465b,_0x5be378));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5c199d=>{const _0x24f345=_0x5c199d['s'],_0x4d5288=_0x5c199d['d']||'error';_0x24f345==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x24f345,_0x4d5288);});}['unlisten'](_0x251052,_0x3ba570){const _0x1ae36e=_0x251052['_path']['toString'](),_0x64ba7e=_0x251052['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1ae36e+'\x20'+_0x64ba7e),f(_0x251052['_queryParams']['isDefault']()||!_0x251052['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1ae36e,_0x64ba7e)&&this['connected_']&&this['sendUnlisten_'](_0x1ae36e,_0x64ba7e,_0x251052['_queryObject'],_0x3ba570);}['sendUnlisten_'](_0x6a208,_0x1f67da,_0x163aed,_0x59bb25){this['log_']('Unlisten\x20on\x20'+_0x6a208+'\x20for\x20'+_0x1f67da);const _0x42aea7={'p':_0x6a208},_0x7e9a5c='n';_0x59bb25&&(_0x42aea7['q']=_0x163aed,_0x42aea7['t']=_0x59bb25),this['sendRequest'](_0x7e9a5c,_0x42aea7);}['onDisconnectPut'](_0x31a85f,_0x3b8b37,_0xb92b1e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x31a85f,_0x3b8b37,_0xb92b1e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x31a85f,'action':'o','data':_0x3b8b37,'onComplete':_0xb92b1e});}['onDisconnectMerge'](_0x342d7c,_0x5d6706,_0x5c5754){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x342d7c,_0x5d6706,_0x5c5754):this['onDisconnectRequestQueue_']['push']({'pathString':_0x342d7c,'action':'om','data':_0x5d6706,'onComplete':_0x5c5754});}['onDisconnectCancel'](_0x54b92f,_0x42981b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x54b92f,null,_0x42981b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x54b92f,'action':'oc','data':null,'onComplete':_0x42981b});}['sendOnDisconnect_'](_0x500dca,_0x2acced,_0x261057,_0x1f48db){const _0x43fb0f={'p':_0x2acced,'d':_0x261057};this['log_']('onDisconnect\x20'+_0x500dca,_0x43fb0f),this['sendRequest'](_0x500dca,_0x43fb0f,_0x3f1ca2=>{_0x1f48db&&setTimeout(()=>{_0x1f48db(_0x3f1ca2['s'],_0x3f1ca2['d']);},Math['floor'](0x0));});}['put'](_0x9ed05b,_0x53cc62,_0x8bb7cd,_0x2735fb){this['putInternal']('p',_0x9ed05b,_0x53cc62,_0x8bb7cd,_0x2735fb);}['merge'](_0x3e4ae9,_0x2881aa,_0x3052d7,_0x3afc54){this['putInternal']('m',_0x3e4ae9,_0x2881aa,_0x3052d7,_0x3afc54);}['putInternal'](_0x288d31,_0x381842,_0x1f6db9,_0x147e1b,_0x460b98){this['initConnection_']();const _0x3f4b12={'p':_0x381842,'d':_0x1f6db9};_0x460b98!==void 0x0&&(_0x3f4b12['h']=_0x460b98),this['outstandingPuts_']['push']({'action':_0x288d31,'request':_0x3f4b12,'onComplete':_0x147e1b}),this['outstandingPutCount_']++;const _0x4fc412=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4fc412):this['log_']('Buffering\x20put:\x20'+_0x381842);}['sendPut_'](_0x51d665){const _0xbb77a9=this['outstandingPuts_'][_0x51d665]['action'],_0x519288=this['outstandingPuts_'][_0x51d665]['request'],_0x3c7bb9=this['outstandingPuts_'][_0x51d665]['onComplete'];this['outstandingPuts_'][_0x51d665]['queued']=this['connected_'],this['sendRequest'](_0xbb77a9,_0x519288,_0x5423bf=>{this['log_'](_0xbb77a9+'\x20response',_0x5423bf),delete this['outstandingPuts_'][_0x51d665],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3c7bb9&&_0x3c7bb9(_0x5423bf['s'],_0x5423bf['d']);});}['reportStats'](_0x38d290){if(this['connected_']){const _0x2ab175={'c':_0x38d290};this['log_']('reportStats',_0x2ab175),this['sendRequest']('s',_0x2ab175,_0x379959=>{if(_0x379959['s']!=='ok'){const _0x2a9d8b=_0x379959['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2a9d8b);}});}}['onDataMessage_'](_0x35e1da){if('r'in _0x35e1da){this['log_']('from\x20server:\x20'+O(_0x35e1da));const _0x15ef60=_0x35e1da['r'],_0x3f7934=this['requestCBHash_'][_0x15ef60];_0x3f7934&&(delete this['requestCBHash_'][_0x15ef60],_0x3f7934(_0x35e1da['b']));}else{if('error'in _0x35e1da)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x35e1da['error'];'a'in _0x35e1da&&this['onDataPush_'](_0x35e1da['a'],_0x35e1da['b']);}}['onDataPush_'](_0x266a41,_0x44749a){this['log_']('handleServerMessage',_0x266a41,_0x44749a),_0x266a41==='d'?this['onDataUpdate_'](_0x44749a['p'],_0x44749a['d'],!0x1,_0x44749a['t']):_0x266a41==='m'?this['onDataUpdate_'](_0x44749a['p'],_0x44749a['d'],!0x0,_0x44749a['t']):_0x266a41==='c'?this['onListenRevoked_'](_0x44749a['p'],_0x44749a['q']):_0x266a41==='ac'?this['onAuthRevoked_'](_0x44749a['s'],_0x44749a['d']):_0x266a41==='apc'?this['onAppCheckRevoked_'](_0x44749a['s'],_0x44749a['d']):_0x266a41==='sd'?this['onSecurityDebugPacket_'](_0x44749a):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x266a41)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3634bb,_0x279455){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3634bb),this['lastSessionId']=_0x279455,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4704e3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4704e3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0xc62ed8){_0xc62ed8&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0xc62ed8;}['onOnline_'](_0x2b6f17){_0x2b6f17?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x192d67=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x14d7c5=Math['max'](0x0,this['reconnectDelay_']-_0x192d67);_0x14d7c5=Math['random']()*_0x14d7c5,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x14d7c5+'ms'),this['scheduleConnect_'](_0x14d7c5),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4e274d=this['onDataMessage_']['bind'](this),_0x4bda80=this['onReady_']['bind'](this),_0x36d9c2=this['onRealtimeDisconnect_']['bind'](this),_0x293bbc=this['id']+':'+se['nextConnectionId_']++,_0x588b37=this['lastSessionId'];let _0x3fad98=!0x1,_0x4d3001=null;const _0x3bc673=function(){_0x4d3001?_0x4d3001['close']():(_0x3fad98=!0x0,_0x36d9c2());},_0x33cb6a=function(_0x26d6e9){f(_0x4d3001,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4d3001['sendRequest'](_0x26d6e9);};this['realtime_']={'close':_0x3bc673,'sendRequest':_0x33cb6a};const _0x558f48=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xf26239,_0x105657]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x558f48),this['appCheckTokenProvider_']['getToken'](_0x558f48)]);_0x3fad98?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xf26239&&_0xf26239['accessToken'],this['appCheckToken_']=_0x105657&&_0x105657['token'],_0x4d3001=new Sh(_0x293bbc,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4e274d,_0x4bda80,_0x36d9c2,_0x2c3dc4=>{U(_0x2c3dc4+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x588b37));}catch(_0x470c28){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x470c28),_0x3fad98||(this['repoInfo_']['nodeAdmin']&&U(_0x470c28),_0x3bc673());}}}['interrupt'](_0x500685){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x500685),this['interruptReasons_'][_0x500685]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2b21d5){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2b21d5),delete this['interruptReasons_'][_0x2b21d5],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1fa05c){const _0x35312d=_0x1fa05c-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x35312d});}['cancelSentTransactions_'](){for(let _0x150d12=0x0;_0x150d12<this['outstandingPuts_']['length'];_0x150d12++){const _0x9e78da=this['outstandingPuts_'][_0x150d12];_0x9e78da&&'h'in _0x9e78da['request']&&_0x9e78da['queued']&&(_0x9e78da['onComplete']&&_0x9e78da['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x150d12],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x55a1f6,_0x1a11e1){let _0xb36f1e;_0x1a11e1?_0xb36f1e=_0x1a11e1['map'](_0x52f313=>$i(_0x52f313))['join']('$'):_0xb36f1e='default';const _0x1b6f0c=this['removeListen_'](_0x55a1f6,_0xb36f1e);_0x1b6f0c&&_0x1b6f0c['onComplete']&&_0x1b6f0c['onComplete']('permission_denied');}['removeListen_'](_0x3c0495,_0x3104c5){const _0x32281b=new C(_0x3c0495)['toString']();let _0x4064cc;if(this['listens']['has'](_0x32281b)){const _0x51b6ca=this['listens']['get'](_0x32281b);_0x4064cc=_0x51b6ca['get'](_0x3104c5),_0x51b6ca['delete'](_0x3104c5),_0x51b6ca['size']===0x0&&this['listens']['delete'](_0x32281b);}else _0x4064cc=void 0x0;return _0x4064cc;}['onAuthRevoked_'](_0x10647f,_0x25e515){L('Auth\x20token\x20revoked:\x20'+_0x10647f+'/'+_0x25e515),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x10647f==='invalid_token'||_0x10647f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x24dc21,_0x41a0c3){L('App\x20check\x20token\x20revoked:\x20'+_0x24dc21+'/'+_0x41a0c3),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x24dc21==='invalid_token'||_0x24dc21==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1959c0){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1959c0):'msg'in _0x1959c0&&console['log']('FIREBASE:\x20'+_0x1959c0['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5a4908 of this['listens']['values']())for(const _0x44f485 of _0x5a4908['values']())this['sendListen_'](_0x44f485);for(let _0xe50b7=0x0;_0xe50b7<this['outstandingPuts_']['length'];_0xe50b7++)this['outstandingPuts_'][_0xe50b7]&&this['sendPut_'](_0xe50b7);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3b1302=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3b1302['action'],_0x3b1302['pathString'],_0x3b1302['data'],_0x3b1302['onComplete']);}for(let _0x5b2922=0x0;_0x5b2922<this['outstandingGets_']['length'];_0x5b2922++)this['outstandingGets_'][_0x5b2922]&&this['sendGet_'](_0x5b2922);}['sendConnectStats_'](){const _0x10e4ae={};let _0x265e34='js';_0x10e4ae['sdk.'+_0x265e34+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x10e4ae['framework.cordova']=0x1:Kr()&&(_0x10e4ae['framework.reactnative']=0x1),this['reportStats'](_0x10e4ae);}['shouldReconnect_'](){const _0x222661=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x222661;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x59ed79,_0x395108){this['name']=_0x59ed79,this['node']=_0x395108;}static['Wrap'](_0x394d72,_0x1e255e){return new E(_0x394d72,_0x1e255e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x215fc7,_0x31a804){const _0x2a4a95=new E(We,_0x215fc7),_0x277693=new E(We,_0x31a804);return this['compare'](_0x2a4a95,_0x277693)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x1a9389){sn=_0x1a9389;}['compare'](_0x14a1c1,_0x4b9896){return qe(_0x14a1c1['name'],_0x4b9896['name']);}['isDefinedOn'](_0x1ebb01){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4a1c78,_0x4965ae){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xb200d0,_0x29141d){return f(typeof _0xb200d0=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xb200d0,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3cd1c4,_0x4b2504,_0x7671bc,_0x548d38,_0x59c467=null){this['isReverse_']=_0x548d38,this['resultGenerator_']=_0x59c467,this['nodeStack_']=[];let _0x128e65=0x1;for(;!_0x3cd1c4['isEmpty']();)if(_0x3cd1c4=_0x3cd1c4,_0x128e65=_0x4b2504?_0x7671bc(_0x3cd1c4['key'],_0x4b2504):0x1,_0x548d38&&(_0x128e65*=-0x1),_0x128e65<0x0)this['isReverse_']?_0x3cd1c4=_0x3cd1c4['left']:_0x3cd1c4=_0x3cd1c4['right'];else{if(_0x128e65===0x0){this['nodeStack_']['push'](_0x3cd1c4);break;}else this['nodeStack_']['push'](_0x3cd1c4),this['isReverse_']?_0x3cd1c4=_0x3cd1c4['right']:_0x3cd1c4=_0x3cd1c4['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4ffccf=this['nodeStack_']['pop'](),_0x3ba670;if(this['resultGenerator_']?_0x3ba670=this['resultGenerator_'](_0x4ffccf['key'],_0x4ffccf['value']):_0x3ba670={'key':_0x4ffccf['key'],'value':_0x4ffccf['value']},this['isReverse_']){for(_0x4ffccf=_0x4ffccf['left'];!_0x4ffccf['isEmpty']();)this['nodeStack_']['push'](_0x4ffccf),_0x4ffccf=_0x4ffccf['right'];}else{for(_0x4ffccf=_0x4ffccf['right'];!_0x4ffccf['isEmpty']();)this['nodeStack_']['push'](_0x4ffccf),_0x4ffccf=_0x4ffccf['left'];}return _0x3ba670;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5eabc4=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5eabc4['key'],_0x5eabc4['value']):{'key':_0x5eabc4['key'],'value':_0x5eabc4['value']};}}class M{constructor(_0x5cf637,_0x184a10,_0xada34,_0x3cf1c5,_0x34fba8){this['key']=_0x5cf637,this['value']=_0x184a10,this['color']=_0xada34??M['RED'],this['left']=_0x3cf1c5??B['EMPTY_NODE'],this['right']=_0x34fba8??B['EMPTY_NODE'];}['copy'](_0x3e0f6b,_0x481718,_0xe79d40,_0x3c4076,_0x3bba38){return new M(_0x3e0f6b??this['key'],_0x481718??this['value'],_0xe79d40??this['color'],_0x3c4076??this['left'],_0x3bba38??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5919ed){return this['left']['inorderTraversal'](_0x5919ed)||!!_0x5919ed(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5919ed);}['reverseTraversal'](_0x19ae55){return this['right']['reverseTraversal'](_0x19ae55)||_0x19ae55(this['key'],this['value'])||this['left']['reverseTraversal'](_0x19ae55);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3d3baf,_0x4c5217,_0x1d217c){let _0x138ff0=this;const _0x58bb50=_0x1d217c(_0x3d3baf,_0x138ff0['key']);return _0x58bb50<0x0?_0x138ff0=_0x138ff0['copy'](null,null,null,_0x138ff0['left']['insert'](_0x3d3baf,_0x4c5217,_0x1d217c),null):_0x58bb50===0x0?_0x138ff0=_0x138ff0['copy'](null,_0x4c5217,null,null,null):_0x138ff0=_0x138ff0['copy'](null,null,null,null,_0x138ff0['right']['insert'](_0x3d3baf,_0x4c5217,_0x1d217c)),_0x138ff0['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0xbceb38=this;return!_0xbceb38['left']['isRed_']()&&!_0xbceb38['left']['left']['isRed_']()&&(_0xbceb38=_0xbceb38['moveRedLeft_']()),_0xbceb38=_0xbceb38['copy'](null,null,null,_0xbceb38['left']['removeMin_'](),null),_0xbceb38['fixUp_']();}['remove'](_0x58fa6e,_0x17d716){let _0x1f61a1,_0x4a265a;if(_0x1f61a1=this,_0x17d716(_0x58fa6e,_0x1f61a1['key'])<0x0)!_0x1f61a1['left']['isEmpty']()&&!_0x1f61a1['left']['isRed_']()&&!_0x1f61a1['left']['left']['isRed_']()&&(_0x1f61a1=_0x1f61a1['moveRedLeft_']()),_0x1f61a1=_0x1f61a1['copy'](null,null,null,_0x1f61a1['left']['remove'](_0x58fa6e,_0x17d716),null);else{if(_0x1f61a1['left']['isRed_']()&&(_0x1f61a1=_0x1f61a1['rotateRight_']()),!_0x1f61a1['right']['isEmpty']()&&!_0x1f61a1['right']['isRed_']()&&!_0x1f61a1['right']['left']['isRed_']()&&(_0x1f61a1=_0x1f61a1['moveRedRight_']()),_0x17d716(_0x58fa6e,_0x1f61a1['key'])===0x0){if(_0x1f61a1['right']['isEmpty']())return B['EMPTY_NODE'];_0x4a265a=_0x1f61a1['right']['min_'](),_0x1f61a1=_0x1f61a1['copy'](_0x4a265a['key'],_0x4a265a['value'],null,null,_0x1f61a1['right']['removeMin_']());}_0x1f61a1=_0x1f61a1['copy'](null,null,null,null,_0x1f61a1['right']['remove'](_0x58fa6e,_0x17d716));}return _0x1f61a1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x423d8c=this;return _0x423d8c['right']['isRed_']()&&!_0x423d8c['left']['isRed_']()&&(_0x423d8c=_0x423d8c['rotateLeft_']()),_0x423d8c['left']['isRed_']()&&_0x423d8c['left']['left']['isRed_']()&&(_0x423d8c=_0x423d8c['rotateRight_']()),_0x423d8c['left']['isRed_']()&&_0x423d8c['right']['isRed_']()&&(_0x423d8c=_0x423d8c['colorFlip_']()),_0x423d8c;}['moveRedLeft_'](){let _0x13299e=this['colorFlip_']();return _0x13299e['right']['left']['isRed_']()&&(_0x13299e=_0x13299e['copy'](null,null,null,null,_0x13299e['right']['rotateRight_']()),_0x13299e=_0x13299e['rotateLeft_'](),_0x13299e=_0x13299e['colorFlip_']()),_0x13299e;}['moveRedRight_'](){let _0xce2a84=this['colorFlip_']();return _0xce2a84['left']['left']['isRed_']()&&(_0xce2a84=_0xce2a84['rotateRight_'](),_0xce2a84=_0xce2a84['colorFlip_']()),_0xce2a84;}['rotateLeft_'](){const _0x284f5f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x284f5f,null);}['rotateRight_'](){const _0x359d04=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x359d04);}['colorFlip_'](){const _0x13057a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x43c26d=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x13057a,_0x43c26d);}['checkMaxDepth_'](){const _0x41c50c=this['check_']();return Math['pow'](0x2,_0x41c50c)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4192d3=this['left']['check_']();if(_0x4192d3!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4192d3+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x2d8836,_0x3c0de8,_0x202b2f,_0x28ba6d,_0x36cb3e){return this;}['insert'](_0x129442,_0x5223a5,_0xc7c4c){return new M(_0x129442,_0x5223a5,null);}['remove'](_0x4bb4de,_0x5e45c8){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x68ea04){return!0x1;}['reverseTraversal'](_0x95d94e){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2a139c,_0x3b0cd3=B['EMPTY_NODE']){this['comparator_']=_0x2a139c,this['root_']=_0x3b0cd3;}['insert'](_0x1b26e0,_0x1d38c3){return new B(this['comparator_'],this['root_']['insert'](_0x1b26e0,_0x1d38c3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x7cde66){return new B(this['comparator_'],this['root_']['remove'](_0x7cde66,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x232699){let _0x45df79,_0x283561=this['root_'];for(;!_0x283561['isEmpty']();){if(_0x45df79=this['comparator_'](_0x232699,_0x283561['key']),_0x45df79===0x0)return _0x283561['value'];_0x45df79<0x0?_0x283561=_0x283561['left']:_0x45df79>0x0&&(_0x283561=_0x283561['right']);}return null;}['getPredecessorKey'](_0x29d987){let _0x5016dd,_0xabd72=this['root_'],_0x45423f=null;for(;!_0xabd72['isEmpty']();)if(_0x5016dd=this['comparator_'](_0x29d987,_0xabd72['key']),_0x5016dd===0x0){if(_0xabd72['left']['isEmpty']())return _0x45423f?_0x45423f['key']:null;for(_0xabd72=_0xabd72['left'];!_0xabd72['right']['isEmpty']();)_0xabd72=_0xabd72['right'];return _0xabd72['key'];}else _0x5016dd<0x0?_0xabd72=_0xabd72['left']:_0x5016dd>0x0&&(_0x45423f=_0xabd72,_0xabd72=_0xabd72['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x389a74){return this['root_']['inorderTraversal'](_0x389a74);}['reverseTraversal'](_0x5e640d){return this['root_']['reverseTraversal'](_0x5e640d);}['getIterator'](_0x52e0e2){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x52e0e2);}['getIteratorFrom'](_0x252df9,_0x54eb22){return new rn(this['root_'],_0x252df9,this['comparator_'],!0x1,_0x54eb22);}['getReverseIteratorFrom'](_0x1435b6,_0x355216){return new rn(this['root_'],_0x1435b6,this['comparator_'],!0x0,_0x355216);}['getReverseIterator'](_0x34f471){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x34f471);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2bb20c,_0x460537){return qe(_0x2bb20c['name'],_0x460537['name']);}function Qi(_0x50f324,_0x2fcf46){return qe(_0x50f324,_0x2fcf46);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x1348c4){Ci=_0x1348c4;}const Po=function(_0x2ffd1a){return typeof _0x2ffd1a=='number'?'number:'+ao(_0x2ffd1a):'string:'+_0x2ffd1a;},No=function(_0x53301b){if(_0x53301b['isLeafNode']()){const _0x4f789e=_0x53301b['val']();f(typeof _0x4f789e=='string'||typeof _0x4f789e=='number'||typeof _0x4f789e=='object'&&Q(_0x4f789e,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x53301b===Ci||_0x53301b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x53301b===Ci||_0x53301b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x9d2783){nr=_0x9d2783;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x4df16b,_0x39fbc0=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4df16b,this['priorityNode_']=_0x39fbc0,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1ddd6e){return new D(this['value_'],_0x1ddd6e);}['getImmediateChild'](_0x40e179){return _0x40e179==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x21c30d){return v(_0x21c30d)?this:y(_0x21c30d)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5bcbf6,_0xfea1a0){return null;}['updateImmediateChild'](_0x340f2b,_0x1a13f0){return _0x340f2b==='.priority'?this['updatePriority'](_0x1a13f0):_0x1a13f0['isEmpty']()&&_0x340f2b!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x340f2b,_0x1a13f0)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5c67b9,_0x3ad98e){const _0x1c26e6=y(_0x5c67b9);return _0x1c26e6===null?_0x3ad98e:_0x3ad98e['isEmpty']()&&_0x1c26e6!=='.priority'?this:(f(_0x1c26e6!=='.priority'||Ce(_0x5c67b9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1c26e6,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x5c67b9),_0x3ad98e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1effe9,_0x1f506b){return!0x1;}['val'](_0x399e1b){return _0x399e1b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x252f13='';this['priorityNode_']['isEmpty']()||(_0x252f13+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x2eab2d=typeof this['value_'];_0x252f13+=_0x2eab2d+':',_0x2eab2d==='number'?_0x252f13+=ao(this['value_']):_0x252f13+=this['value_'],this['lazyHash_']=ro(_0x252f13);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1469b1){return _0x1469b1===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1469b1 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1469b1['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1469b1));}['compareToLeafNode_'](_0xfb6e5f){const _0x511953=typeof _0xfb6e5f['value_'],_0x305984=typeof this['value_'],_0x2590cb=D['VALUE_TYPE_ORDER']['indexOf'](_0x511953),_0xc514c3=D['VALUE_TYPE_ORDER']['indexOf'](_0x305984);return f(_0x2590cb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x511953),f(_0xc514c3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x305984),_0x2590cb===_0xc514c3?_0x305984==='object'?0x0:this['value_']<_0xfb6e5f['value_']?-0x1:this['value_']===_0xfb6e5f['value_']?0x0:0x1:_0xc514c3-_0x2590cb;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3f17b7){if(_0x3f17b7===this)return!0x0;if(_0x3f17b7['isLeafNode']()){const _0x4374a5=_0x3f17b7;return this['value_']===_0x4374a5['value_']&&this['priorityNode_']['equals'](_0x4374a5['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x7b148f){Oo=_0x7b148f;}function Wh(_0x41db3a){Do=_0x41db3a;}class Bh extends Fn{['compare'](_0x119097,_0x101591){const _0x249d14=_0x119097['node']['getPriority'](),_0xd304d2=_0x101591['node']['getPriority'](),_0x457567=_0x249d14['compareTo'](_0xd304d2);return _0x457567===0x0?qe(_0x119097['name'],_0x101591['name']):_0x457567;}['isDefinedOn'](_0x297acc){return!_0x297acc['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x128d11,_0x5ac4c5){return!_0x128d11['getPriority']()['equals'](_0x5ac4c5['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x58c6a3,_0xa2d0e9){const _0x28d8cf=Oo(_0x58c6a3);return new E(_0xa2d0e9,new D('[PRIORITY-POST]',_0x28d8cf));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x32ad14){const _0x2d6ab3=_0x38f1c7=>parseInt(Math['log'](_0x38f1c7)/Vh,0xa),_0x1ea2ba=_0x4d1a83=>parseInt(Array(_0x4d1a83+0x1)['join']('1'),0x2);this['count']=_0x2d6ab3(_0x32ad14+0x1),this['current_']=this['count']-0x1;const _0x4a094b=_0x1ea2ba(this['count']);this['bits_']=_0x32ad14+0x1&_0x4a094b;}['nextBitIsOne'](){const _0x516d2b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x516d2b;}}const yn=function(_0x15d185,_0x3bcef6,_0x2c1e1b,_0x1951fd){_0x15d185['sort'](_0x3bcef6);const _0x3432c6=function(_0x5835a1,_0x3f9216){const _0x3b778a=_0x3f9216-_0x5835a1;let _0x4ff130,_0xc05f07;if(_0x3b778a===0x0)return null;if(_0x3b778a===0x1)return _0x4ff130=_0x15d185[_0x5835a1],_0xc05f07=_0x2c1e1b?_0x2c1e1b(_0x4ff130):_0x4ff130,new M(_0xc05f07,_0x4ff130['node'],M['BLACK'],null,null);{const _0x52fc95=parseInt(_0x3b778a/0x2,0xa)+_0x5835a1,_0x45ded3=_0x3432c6(_0x5835a1,_0x52fc95),_0x444a15=_0x3432c6(_0x52fc95+0x1,_0x3f9216);return _0x4ff130=_0x15d185[_0x52fc95],_0xc05f07=_0x2c1e1b?_0x2c1e1b(_0x4ff130):_0x4ff130,new M(_0xc05f07,_0x4ff130['node'],M['BLACK'],_0x45ded3,_0x444a15);}},_0x8eac05=function(_0x5ab018){let _0x2cb8f9=null,_0x478d31=null,_0x42dbd1=_0x15d185['length'];const _0x367a34=function(_0xd4de19,_0x2163e5){const _0x4edb7f=_0x42dbd1-_0xd4de19,_0x556f9d=_0x42dbd1;_0x42dbd1-=_0xd4de19;const _0x4dfcb5=_0x3432c6(_0x4edb7f+0x1,_0x556f9d),_0x4dadb8=_0x15d185[_0x4edb7f],_0x29eea6=_0x2c1e1b?_0x2c1e1b(_0x4dadb8):_0x4dadb8;_0x42dc04(new M(_0x29eea6,_0x4dadb8['node'],_0x2163e5,null,_0x4dfcb5));},_0x42dc04=function(_0x59f285){_0x2cb8f9?(_0x2cb8f9['left']=_0x59f285,_0x2cb8f9=_0x59f285):(_0x478d31=_0x59f285,_0x2cb8f9=_0x59f285);};for(let _0x375a47=0x0;_0x375a47<_0x5ab018['count'];++_0x375a47){const _0x36a5b4=_0x5ab018['nextBitIsOne'](),_0x453677=Math['pow'](0x2,_0x5ab018['count']-(_0x375a47+0x1));_0x36a5b4?_0x367a34(_0x453677,M['BLACK']):(_0x367a34(_0x453677,M['BLACK']),_0x367a34(_0x453677,M['RED']));}return _0x478d31;},_0x6427f3=new Hh(_0x15d185['length']),_0x26ff7e=_0x8eac05(_0x6427f3);return new B(_0x1951fd||_0x3bcef6,_0x26ff7e);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x650e4b,_0x1b5392){this['indexes_']=_0x650e4b,this['indexSet_']=_0x1b5392;}['get'](_0x9aaf84){const _0x2faad1=Le(this['indexes_'],_0x9aaf84);if(!_0x2faad1)throw new Error('No\x20index\x20defined\x20for\x20'+_0x9aaf84);return _0x2faad1 instanceof B?_0x2faad1:null;}['hasIndex'](_0x46a4fb){return Q(this['indexSet_'],_0x46a4fb['toString']());}['addIndex'](_0xee1d14,_0x5e70b6){f(_0xee1d14!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x43ad45=[];let _0x204bb4=!0x1;const _0x26935e=_0x5e70b6['getIterator'](E['Wrap']);let _0x852983=_0x26935e['getNext']();for(;_0x852983;)_0x204bb4=_0x204bb4||_0xee1d14['isDefinedOn'](_0x852983['node']),_0x43ad45['push'](_0x852983),_0x852983=_0x26935e['getNext']();let _0x15b9ea;_0x204bb4?_0x15b9ea=yn(_0x43ad45,_0xee1d14['getCompare']()):_0x15b9ea=Qe;const _0x2ebddf=_0xee1d14['toString'](),_0x2b2f37={...this['indexSet_']};_0x2b2f37[_0x2ebddf]=_0xee1d14;const _0x2062a9={...this['indexes_']};return _0x2062a9[_0x2ebddf]=_0x15b9ea,new te(_0x2062a9,_0x2b2f37);}['addToIndexes'](_0x3d63b2,_0x1b6103){const _0x5de8b2=_n(this['indexes_'],(_0x3f7ef5,_0x3a9b0c)=>{const _0x369859=Le(this['indexSet_'],_0x3a9b0c);if(f(_0x369859,'Missing\x20index\x20implementation\x20for\x20'+_0x3a9b0c),_0x3f7ef5===Qe){if(_0x369859['isDefinedOn'](_0x3d63b2['node'])){const _0x614b5=[],_0x572cf6=_0x1b6103['getIterator'](E['Wrap']);let _0x784730=_0x572cf6['getNext']();for(;_0x784730;)_0x784730['name']!==_0x3d63b2['name']&&_0x614b5['push'](_0x784730),_0x784730=_0x572cf6['getNext']();return _0x614b5['push'](_0x3d63b2),yn(_0x614b5,_0x369859['getCompare']());}else return Qe;}else{const _0x5dec64=_0x1b6103['get'](_0x3d63b2['name']);let _0xe17d45=_0x3f7ef5;return _0x5dec64&&(_0xe17d45=_0xe17d45['remove'](new E(_0x3d63b2['name'],_0x5dec64))),_0xe17d45['insert'](_0x3d63b2,_0x3d63b2['node']);}});return new te(_0x5de8b2,this['indexSet_']);}['removeFromIndexes'](_0x535a9e,_0x4ffba3){const _0x37c61b=_n(this['indexes_'],_0xd75e38=>{if(_0xd75e38===Qe)return _0xd75e38;{const _0x542047=_0x4ffba3['get'](_0x535a9e['name']);return _0x542047?_0xd75e38['remove'](new E(_0x535a9e['name'],_0x542047)):_0xd75e38;}});return new te(_0x37c61b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x2d18a8,_0x4df82,_0x3883af){this['children_']=_0x2d18a8,this['priorityNode_']=_0x4df82,this['indexMap_']=_0x3883af,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x2d15d6){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2d15d6,this['indexMap_']);}['getImmediateChild'](_0x15b2e0){if(_0x15b2e0==='.priority')return this['getPriority']();{const _0x33f8ab=this['children_']['get'](_0x15b2e0);return _0x33f8ab===null?It:_0x33f8ab;}}['getChild'](_0x219eb0){const _0x192316=y(_0x219eb0);return _0x192316===null?this:this['getImmediateChild'](_0x192316)['getChild'](S(_0x219eb0));}['hasChild'](_0x37b29c){return this['children_']['get'](_0x37b29c)!==null;}['updateImmediateChild'](_0x15f08d,_0x518f7a){if(f(_0x518f7a,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x15f08d==='.priority')return this['updatePriority'](_0x518f7a);{const _0x19bec8=new E(_0x15f08d,_0x518f7a);let _0x88526e,_0x241ca3;_0x518f7a['isEmpty']()?(_0x88526e=this['children_']['remove'](_0x15f08d),_0x241ca3=this['indexMap_']['removeFromIndexes'](_0x19bec8,this['children_'])):(_0x88526e=this['children_']['insert'](_0x15f08d,_0x518f7a),_0x241ca3=this['indexMap_']['addToIndexes'](_0x19bec8,this['children_']));const _0x77e1bc=_0x88526e['isEmpty']()?It:this['priorityNode_'];return new g(_0x88526e,_0x77e1bc,_0x241ca3);}}['updateChild'](_0x1f9924,_0xc631f7){const _0x3cae2b=y(_0x1f9924);if(_0x3cae2b===null)return _0xc631f7;{f(y(_0x1f9924)!=='.priority'||Ce(_0x1f9924)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5711da=this['getImmediateChild'](_0x3cae2b)['updateChild'](S(_0x1f9924),_0xc631f7);return this['updateImmediateChild'](_0x3cae2b,_0x5711da);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4a5886){if(this['isEmpty']())return null;const _0x1085d2={};let _0x20129c=0x0,_0x5376b6=0x0,_0x2dd664=!0x0;if(this['forEachChild'](R,(_0x323cf5,_0x534d05)=>{_0x1085d2[_0x323cf5]=_0x534d05['val'](_0x4a5886),_0x20129c++,_0x2dd664&&g['INTEGER_REGEXP_']['test'](_0x323cf5)?_0x5376b6=Math['max'](_0x5376b6,Number(_0x323cf5)):_0x2dd664=!0x1;}),!_0x4a5886&&_0x2dd664&&_0x5376b6<0x2*_0x20129c){const _0x1ad035=[];for(const _0x1ad43d in _0x1085d2)_0x1ad035[_0x1ad43d]=_0x1085d2[_0x1ad43d];return _0x1ad035;}else return _0x4a5886&&!this['getPriority']()['isEmpty']()&&(_0x1085d2['.priority']=this['getPriority']()['val']()),_0x1085d2;}['hash'](){if(this['lazyHash_']===null){let _0x2dca44='';this['getPriority']()['isEmpty']()||(_0x2dca44+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4893d0,_0x1471a9)=>{const _0xe40dc1=_0x1471a9['hash']();_0xe40dc1!==''&&(_0x2dca44+=':'+_0x4893d0+':'+_0xe40dc1);}),this['lazyHash_']=_0x2dca44===''?'':ro(_0x2dca44);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3ab975,_0x4820a7,_0x32946a){const _0x59c748=this['resolveIndex_'](_0x32946a);if(_0x59c748){const _0x3129b2=_0x59c748['getPredecessorKey'](new E(_0x3ab975,_0x4820a7));return _0x3129b2?_0x3129b2['name']:null;}else return this['children_']['getPredecessorKey'](_0x3ab975);}['getFirstChildName'](_0x34858a){const _0x376c66=this['resolveIndex_'](_0x34858a);if(_0x376c66){const _0x4ba4ce=_0x376c66['minKey']();return _0x4ba4ce&&_0x4ba4ce['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1c795a){const _0x337992=this['getFirstChildName'](_0x1c795a);return _0x337992?new E(_0x337992,this['children_']['get'](_0x337992)):null;}['getLastChildName'](_0x162ca0){const _0x1e5be1=this['resolveIndex_'](_0x162ca0);if(_0x1e5be1){const _0x560d53=_0x1e5be1['maxKey']();return _0x560d53&&_0x560d53['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x35f968){const _0x2db58e=this['getLastChildName'](_0x35f968);return _0x2db58e?new E(_0x2db58e,this['children_']['get'](_0x2db58e)):null;}['forEachChild'](_0x304f8b,_0x24e20b){const _0xd7cda7=this['resolveIndex_'](_0x304f8b);return _0xd7cda7?_0xd7cda7['inorderTraversal'](_0x515fdf=>_0x24e20b(_0x515fdf['name'],_0x515fdf['node'])):this['children_']['inorderTraversal'](_0x24e20b);}['getIterator'](_0x494602){return this['getIteratorFrom'](_0x494602['minPost'](),_0x494602);}['getIteratorFrom'](_0x1689b4,_0x27402a){const _0x4e159a=this['resolveIndex_'](_0x27402a);if(_0x4e159a)return _0x4e159a['getIteratorFrom'](_0x1689b4,_0x2a6b2b=>_0x2a6b2b);{const _0x176afb=this['children_']['getIteratorFrom'](_0x1689b4['name'],E['Wrap']);let _0x24af23=_0x176afb['peek']();for(;_0x24af23!=null&&_0x27402a['compare'](_0x24af23,_0x1689b4)<0x0;)_0x176afb['getNext'](),_0x24af23=_0x176afb['peek']();return _0x176afb;}}['getReverseIterator'](_0xd078ee){return this['getReverseIteratorFrom'](_0xd078ee['maxPost'](),_0xd078ee);}['getReverseIteratorFrom'](_0x23a574,_0x363c49){const _0x128d31=this['resolveIndex_'](_0x363c49);if(_0x128d31)return _0x128d31['getReverseIteratorFrom'](_0x23a574,_0x441f4b=>_0x441f4b);{const _0x4c7b77=this['children_']['getReverseIteratorFrom'](_0x23a574['name'],E['Wrap']);let _0x3bdaf1=_0x4c7b77['peek']();for(;_0x3bdaf1!=null&&_0x363c49['compare'](_0x3bdaf1,_0x23a574)>0x0;)_0x4c7b77['getNext'](),_0x3bdaf1=_0x4c7b77['peek']();return _0x4c7b77;}}['compareTo'](_0x588a8c){return this['isEmpty']()?_0x588a8c['isEmpty']()?0x0:-0x1:_0x588a8c['isLeafNode']()||_0x588a8c['isEmpty']()?0x1:_0x588a8c===Kt?-0x1:0x0;}['withIndex'](_0x57b2e0){if(_0x57b2e0===ve||this['indexMap_']['hasIndex'](_0x57b2e0))return this;{const _0x249409=this['indexMap_']['addIndex'](_0x57b2e0,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x249409);}}['isIndexed'](_0x35ebb4){return _0x35ebb4===ve||this['indexMap_']['hasIndex'](_0x35ebb4);}['equals'](_0x16954a){if(_0x16954a===this)return!0x0;if(_0x16954a['isLeafNode']())return!0x1;{const _0x2696d5=_0x16954a;if(this['getPriority']()['equals'](_0x2696d5['getPriority']())){if(this['children_']['count']()===_0x2696d5['children_']['count']()){const _0x4cfe2c=this['getIterator'](R),_0x28be3f=_0x2696d5['getIterator'](R);let _0x359662=_0x4cfe2c['getNext'](),_0x54e95d=_0x28be3f['getNext']();for(;_0x359662&&_0x54e95d;){if(_0x359662['name']!==_0x54e95d['name']||!_0x359662['node']['equals'](_0x54e95d['node']))return!0x1;_0x359662=_0x4cfe2c['getNext'](),_0x54e95d=_0x28be3f['getNext']();}return _0x359662===null&&_0x54e95d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xef183){return _0xef183===ve?null:this['indexMap_']['get'](_0xef183['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x434571){return _0x434571===this?0x0:0x1;}['equals'](_0x2c5fa1){return _0x2c5fa1===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5c6e84){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x277b5c,_0x1d4956=null){if(_0x277b5c===null)return g['EMPTY_NODE'];if(typeof _0x277b5c=='object'&&'.priority'in _0x277b5c&&(_0x1d4956=_0x277b5c['.priority']),f(_0x1d4956===null||typeof _0x1d4956=='string'||typeof _0x1d4956=='number'||typeof _0x1d4956=='object'&&'.sv'in _0x1d4956,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1d4956),typeof _0x277b5c=='object'&&'.value'in _0x277b5c&&_0x277b5c['.value']!==null&&(_0x277b5c=_0x277b5c['.value']),typeof _0x277b5c!='object'||'.sv'in _0x277b5c){const _0x3bb899=_0x277b5c;return new D(_0x3bb899,A(_0x1d4956));}if(!(_0x277b5c instanceof Array)&&Gh){const _0x29fa6c=[];let _0x528f8a=!0x1;if(x(_0x277b5c,(_0x4ea3c9,_0x15b2fd)=>{if(_0x4ea3c9['substring'](0x0,0x1)!=='.'){const _0x24cd3d=A(_0x15b2fd);_0x24cd3d['isEmpty']()||(_0x528f8a=_0x528f8a||!_0x24cd3d['getPriority']()['isEmpty'](),_0x29fa6c['push'](new E(_0x4ea3c9,_0x24cd3d)));}}),_0x29fa6c['length']===0x0)return g['EMPTY_NODE'];const _0x4f92c3=yn(_0x29fa6c,xh,_0x4ded29=>_0x4ded29['name'],Qi);if(_0x528f8a){const _0x3c846d=yn(_0x29fa6c,R['getCompare']());return new g(_0x4f92c3,A(_0x1d4956),new te({'.priority':_0x3c846d},{'.priority':R}));}else return new g(_0x4f92c3,A(_0x1d4956),te['Default']);}else{let _0x2dea1e=g['EMPTY_NODE'];return x(_0x277b5c,(_0xc8822b,_0x14dc01)=>{if(Q(_0x277b5c,_0xc8822b)&&_0xc8822b['substring'](0x0,0x1)!=='.'){const _0xfbd925=A(_0x14dc01);(_0xfbd925['isLeafNode']()||!_0xfbd925['isEmpty']())&&(_0x2dea1e=_0x2dea1e['updateImmediateChild'](_0xc8822b,_0xfbd925));}}),_0x2dea1e['updatePriority'](A(_0x1d4956));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x5a7534){super(),this['indexPath_']=_0x5a7534,f(!v(_0x5a7534)&&y(_0x5a7534)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x592bd7){return _0x592bd7['getChild'](this['indexPath_']);}['isDefinedOn'](_0x511d96){return!_0x511d96['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5b0fbf,_0x14cb12){const _0xe10ab9=this['extractChild'](_0x5b0fbf['node']),_0x3a9883=this['extractChild'](_0x14cb12['node']),_0x48b217=_0xe10ab9['compareTo'](_0x3a9883);return _0x48b217===0x0?qe(_0x5b0fbf['name'],_0x14cb12['name']):_0x48b217;}['makePost'](_0x15f7ff,_0xae287a){const _0x29bb2f=A(_0x15f7ff),_0xfd9fcd=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x29bb2f);return new E(_0xae287a,_0xfd9fcd);}['maxPost'](){const _0x5072fa=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x5072fa);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x1d37f9,_0x1399a1){const _0x437d99=_0x1d37f9['node']['compareTo'](_0x1399a1['node']);return _0x437d99===0x0?qe(_0x1d37f9['name'],_0x1399a1['name']):_0x437d99;}['isDefinedOn'](_0x34e03b){return!0x0;}['indexedValueChanged'](_0x235a64,_0x413d20){return!_0x235a64['equals'](_0x413d20);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x43fbe5,_0x52a118){const _0x210a92=A(_0x43fbe5);return new E(_0x52a118,_0x210a92);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x1203bf){return{'type':'value','snapshotNode':_0x1203bf};}function rt(_0x5cde65,_0xd6aabe){return{'type':'child_added','snapshotNode':_0xd6aabe,'childName':_0x5cde65};}function Lt(_0x3417c6,_0x2ec23d){return{'type':'child_removed','snapshotNode':_0x2ec23d,'childName':_0x3417c6};}function xt(_0x218fc1,_0x4d9166,_0x117b09){return{'type':'child_changed','snapshotNode':_0x4d9166,'childName':_0x218fc1,'oldSnap':_0x117b09};}function zh(_0x2c896a,_0x360c51){return{'type':'child_moved','snapshotNode':_0x360c51,'childName':_0x2c896a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x40471f){this['index_']=_0x40471f;}['updateChild'](_0x5d4b40,_0x4ca07a,_0x444397,_0x5e3bfc,_0x3c0983,_0x4f88d2){f(_0x5d4b40['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4cd876=_0x5d4b40['getImmediateChild'](_0x4ca07a);return _0x4cd876['getChild'](_0x5e3bfc)['equals'](_0x444397['getChild'](_0x5e3bfc))&&_0x4cd876['isEmpty']()===_0x444397['isEmpty']()||(_0x4f88d2!=null&&(_0x444397['isEmpty']()?_0x5d4b40['hasChild'](_0x4ca07a)?_0x4f88d2['trackChildChange'](Lt(_0x4ca07a,_0x4cd876)):f(_0x5d4b40['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4cd876['isEmpty']()?_0x4f88d2['trackChildChange'](rt(_0x4ca07a,_0x444397)):_0x4f88d2['trackChildChange'](xt(_0x4ca07a,_0x444397,_0x4cd876))),_0x5d4b40['isLeafNode']()&&_0x444397['isEmpty']())?_0x5d4b40:_0x5d4b40['updateImmediateChild'](_0x4ca07a,_0x444397)['withIndex'](this['index_']);}['updateFullNode'](_0x259800,_0x49c259,_0x1d4423){return _0x1d4423!=null&&(_0x259800['isLeafNode']()||_0x259800['forEachChild'](R,(_0x27e05,_0x240105)=>{_0x49c259['hasChild'](_0x27e05)||_0x1d4423['trackChildChange'](Lt(_0x27e05,_0x240105));}),_0x49c259['isLeafNode']()||_0x49c259['forEachChild'](R,(_0x3e7c2d,_0x45cf3e)=>{if(_0x259800['hasChild'](_0x3e7c2d)){const _0x3a260d=_0x259800['getImmediateChild'](_0x3e7c2d);_0x3a260d['equals'](_0x45cf3e)||_0x1d4423['trackChildChange'](xt(_0x3e7c2d,_0x45cf3e,_0x3a260d));}else _0x1d4423['trackChildChange'](rt(_0x3e7c2d,_0x45cf3e));})),_0x49c259['withIndex'](this['index_']);}['updatePriority'](_0x340a89,_0x6a5f14){return _0x340a89['isEmpty']()?g['EMPTY_NODE']:_0x340a89['updatePriority'](_0x6a5f14);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0xf59aed){this['indexedFilter_']=new Xi(_0xf59aed['getIndex']()),this['index_']=_0xf59aed['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0xf59aed),this['endPost_']=Ft['getEndPost_'](_0xf59aed),this['startIsInclusive_']=!_0xf59aed['startAfterSet_'],this['endIsInclusive_']=!_0xf59aed['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x552dd4){const _0x417600=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x552dd4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x552dd4)<0x0,_0x272ac3=this['endIsInclusive_']?this['index_']['compare'](_0x552dd4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x552dd4,this['getEndPost']())<0x0;return _0x417600&&_0x272ac3;}['updateChild'](_0x53cbb1,_0x33ea3f,_0x4ae4b3,_0x18c438,_0xc32edd,_0x576c21){return this['matches'](new E(_0x33ea3f,_0x4ae4b3))||(_0x4ae4b3=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x53cbb1,_0x33ea3f,_0x4ae4b3,_0x18c438,_0xc32edd,_0x576c21);}['updateFullNode'](_0x21e0c9,_0x20b359,_0x2cb8fd){_0x20b359['isLeafNode']()&&(_0x20b359=g['EMPTY_NODE']);let _0x14a480=_0x20b359['withIndex'](this['index_']);_0x14a480=_0x14a480['updatePriority'](g['EMPTY_NODE']);const _0x278cb4=this;return _0x20b359['forEachChild'](R,(_0x5c0dbc,_0x14a8ed)=>{_0x278cb4['matches'](new E(_0x5c0dbc,_0x14a8ed))||(_0x14a480=_0x14a480['updateImmediateChild'](_0x5c0dbc,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x21e0c9,_0x14a480,_0x2cb8fd);}['updatePriority'](_0x3d4589,_0xf1a822){return _0x3d4589;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x57ca5e){if(_0x57ca5e['hasStart']()){const _0x4d1b52=_0x57ca5e['getIndexStartName']();return _0x57ca5e['getIndex']()['makePost'](_0x57ca5e['getIndexStartValue'](),_0x4d1b52);}else return _0x57ca5e['getIndex']()['minPost']();}static['getEndPost_'](_0xebb01c){if(_0xebb01c['hasEnd']()){const _0x18adcc=_0xebb01c['getIndexEndName']();return _0xebb01c['getIndex']()['makePost'](_0xebb01c['getIndexEndValue'](),_0x18adcc);}else return _0xebb01c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x42d87d){this['withinDirectionalStart']=_0x171403=>this['reverse_']?this['withinEndPost'](_0x171403):this['withinStartPost'](_0x171403),this['withinDirectionalEnd']=_0xfeae58=>this['reverse_']?this['withinStartPost'](_0xfeae58):this['withinEndPost'](_0xfeae58),this['withinStartPost']=_0x54be31=>{const _0x58fa28=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x54be31);return this['startIsInclusive_']?_0x58fa28<=0x0:_0x58fa28<0x0;},this['withinEndPost']=_0x4716be=>{const _0x1a5e4f=this['index_']['compare'](_0x4716be,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1a5e4f<=0x0:_0x1a5e4f<0x0;},this['rangedFilter_']=new Ft(_0x42d87d),this['index_']=_0x42d87d['getIndex'](),this['limit_']=_0x42d87d['getLimit'](),this['reverse_']=!_0x42d87d['isViewFromLeft'](),this['startIsInclusive_']=!_0x42d87d['startAfterSet_'],this['endIsInclusive_']=!_0x42d87d['endBeforeSet_'];}['updateChild'](_0x2c797a,_0x19e531,_0x4519e3,_0x5da941,_0x413ecd,_0x18ace6){return this['rangedFilter_']['matches'](new E(_0x19e531,_0x4519e3))||(_0x4519e3=g['EMPTY_NODE']),_0x2c797a['getImmediateChild'](_0x19e531)['equals'](_0x4519e3)?_0x2c797a:_0x2c797a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2c797a,_0x19e531,_0x4519e3,_0x5da941,_0x413ecd,_0x18ace6):this['fullLimitUpdateChild_'](_0x2c797a,_0x19e531,_0x4519e3,_0x413ecd,_0x18ace6);}['updateFullNode'](_0xbc294d,_0x44bd96,_0x21c682){let _0xef2207;if(_0x44bd96['isLeafNode']()||_0x44bd96['isEmpty']())_0xef2207=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x44bd96['numChildren']()&&_0x44bd96['isIndexed'](this['index_'])){_0xef2207=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x486e80;this['reverse_']?_0x486e80=_0x44bd96['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x486e80=_0x44bd96['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4dc579=0x0;for(;_0x486e80['hasNext']()&&_0x4dc579<this['limit_'];){const _0x1f4f54=_0x486e80['getNext']();if(this['withinDirectionalStart'](_0x1f4f54)){if(this['withinDirectionalEnd'](_0x1f4f54))_0xef2207=_0xef2207['updateImmediateChild'](_0x1f4f54['name'],_0x1f4f54['node']),_0x4dc579++;else break;}else continue;}}else{_0xef2207=_0x44bd96['withIndex'](this['index_']),_0xef2207=_0xef2207['updatePriority'](g['EMPTY_NODE']);let _0x5c0a3a;this['reverse_']?_0x5c0a3a=_0xef2207['getReverseIterator'](this['index_']):_0x5c0a3a=_0xef2207['getIterator'](this['index_']);let _0x576865=0x0;for(;_0x5c0a3a['hasNext']();){const _0x471807=_0x5c0a3a['getNext']();_0x576865<this['limit_']&&this['withinDirectionalStart'](_0x471807)&&this['withinDirectionalEnd'](_0x471807)?_0x576865++:_0xef2207=_0xef2207['updateImmediateChild'](_0x471807['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xbc294d,_0xef2207,_0x21c682);}['updatePriority'](_0x44b48d,_0x2a7677){return _0x44b48d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x35fbab,_0x1bbdf6,_0x5a3f1d,_0x5aed03,_0x26ad3f){let _0x20a1f6;if(this['reverse_']){const _0x489100=this['index_']['getCompare']();_0x20a1f6=(_0x5f1e0b,_0x107863)=>_0x489100(_0x107863,_0x5f1e0b);}else _0x20a1f6=this['index_']['getCompare']();const _0x502008=_0x35fbab;f(_0x502008['numChildren']()===this['limit_'],'');const _0x5d9bdb=new E(_0x1bbdf6,_0x5a3f1d),_0x1cca8e=this['reverse_']?_0x502008['getFirstChild'](this['index_']):_0x502008['getLastChild'](this['index_']),_0x386944=this['rangedFilter_']['matches'](_0x5d9bdb);if(_0x502008['hasChild'](_0x1bbdf6)){const _0x36cf0d=_0x502008['getImmediateChild'](_0x1bbdf6);let _0xd91afa=_0x5aed03['getChildAfterChild'](this['index_'],_0x1cca8e,this['reverse_']);for(;_0xd91afa!=null&&(_0xd91afa['name']===_0x1bbdf6||_0x502008['hasChild'](_0xd91afa['name']));)_0xd91afa=_0x5aed03['getChildAfterChild'](this['index_'],_0xd91afa,this['reverse_']);const _0x27b134=_0xd91afa==null?0x1:_0x20a1f6(_0xd91afa,_0x5d9bdb);if(_0x386944&&!_0x5a3f1d['isEmpty']()&&_0x27b134>=0x0)return _0x26ad3f!=null&&_0x26ad3f['trackChildChange'](xt(_0x1bbdf6,_0x5a3f1d,_0x36cf0d)),_0x502008['updateImmediateChild'](_0x1bbdf6,_0x5a3f1d);{_0x26ad3f!=null&&_0x26ad3f['trackChildChange'](Lt(_0x1bbdf6,_0x36cf0d));const _0x33d712=_0x502008['updateImmediateChild'](_0x1bbdf6,g['EMPTY_NODE']);return _0xd91afa!=null&&this['rangedFilter_']['matches'](_0xd91afa)?(_0x26ad3f!=null&&_0x26ad3f['trackChildChange'](rt(_0xd91afa['name'],_0xd91afa['node'])),_0x33d712['updateImmediateChild'](_0xd91afa['name'],_0xd91afa['node'])):_0x33d712;}}else return _0x5a3f1d['isEmpty']()?_0x35fbab:_0x386944&&_0x20a1f6(_0x1cca8e,_0x5d9bdb)>=0x0?(_0x26ad3f!=null&&(_0x26ad3f['trackChildChange'](Lt(_0x1cca8e['name'],_0x1cca8e['node'])),_0x26ad3f['trackChildChange'](rt(_0x1bbdf6,_0x5a3f1d))),_0x502008['updateImmediateChild'](_0x1bbdf6,_0x5a3f1d)['updateImmediateChild'](_0x1cca8e['name'],g['EMPTY_NODE'])):_0x35fbab;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x595adf=new Zi();return _0x595adf['limitSet_']=this['limitSet_'],_0x595adf['limit_']=this['limit_'],_0x595adf['startSet_']=this['startSet_'],_0x595adf['startAfterSet_']=this['startAfterSet_'],_0x595adf['indexStartValue_']=this['indexStartValue_'],_0x595adf['startNameSet_']=this['startNameSet_'],_0x595adf['indexStartName_']=this['indexStartName_'],_0x595adf['endSet_']=this['endSet_'],_0x595adf['endBeforeSet_']=this['endBeforeSet_'],_0x595adf['indexEndValue_']=this['indexEndValue_'],_0x595adf['endNameSet_']=this['endNameSet_'],_0x595adf['indexEndName_']=this['indexEndName_'],_0x595adf['index_']=this['index_'],_0x595adf['viewFrom_']=this['viewFrom_'],_0x595adf;}}function Kh(_0x13d51c){return _0x13d51c['loadsAllData']()?new Xi(_0x13d51c['getIndex']()):_0x13d51c['hasLimit']()?new jh(_0x13d51c):new Ft(_0x13d51c);}function Yh(_0x555cc4,_0x259c25){const _0x51ea94=_0x555cc4['copy']();return _0x51ea94['limitSet_']=!0x0,_0x51ea94['limit_']=_0x259c25,_0x51ea94['viewFrom_']='l',_0x51ea94;}function Qh(_0x522075,_0x55ef35,_0x1e37ab){const _0x379999=_0x522075['copy']();return _0x379999['startSet_']=!0x0,_0x55ef35===void 0x0&&(_0x55ef35=null),_0x379999['indexStartValue_']=_0x55ef35,_0x1e37ab!=null?(_0x379999['startNameSet_']=!0x0,_0x379999['indexStartName_']=_0x1e37ab):(_0x379999['startNameSet_']=!0x1,_0x379999['indexStartName_']=''),_0x379999;}function Jh(_0x4b0e65,_0x41826e,_0x14ca74){const _0x195267=_0x4b0e65['copy']();return _0x195267['endSet_']=!0x0,_0x41826e===void 0x0&&(_0x41826e=null),_0x195267['indexEndValue_']=_0x41826e,_0x14ca74!==void 0x0?(_0x195267['endNameSet_']=!0x0,_0x195267['indexEndName_']=_0x14ca74):(_0x195267['endNameSet_']=!0x1,_0x195267['indexEndName_']=''),_0x195267;}function xo(_0x4610d5,_0x5a56d8){const _0x6d671c=_0x4610d5['copy']();return _0x6d671c['index_']=_0x5a56d8,_0x6d671c;}function ir(_0x5e529a){const _0x4de8f9={};if(_0x5e529a['isDefault']())return _0x4de8f9;let _0x25a383;if(_0x5e529a['index_']===R?_0x25a383='$priority':_0x5e529a['index_']===Mo?_0x25a383='$value':_0x5e529a['index_']===ve?_0x25a383='$key':(f(_0x5e529a['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x25a383=_0x5e529a['index_']['toString']()),_0x4de8f9['orderBy']=O(_0x25a383),_0x5e529a['startSet_']){const _0x4f0dca=_0x5e529a['startAfterSet_']?'startAfter':'startAt';_0x4de8f9[_0x4f0dca]=O(_0x5e529a['indexStartValue_']),_0x5e529a['startNameSet_']&&(_0x4de8f9[_0x4f0dca]+=','+O(_0x5e529a['indexStartName_']));}if(_0x5e529a['endSet_']){const _0x2e5d3f=_0x5e529a['endBeforeSet_']?'endBefore':'endAt';_0x4de8f9[_0x2e5d3f]=O(_0x5e529a['indexEndValue_']),_0x5e529a['endNameSet_']&&(_0x4de8f9[_0x2e5d3f]+=','+O(_0x5e529a['indexEndName_']));}return _0x5e529a['limitSet_']&&(_0x5e529a['isViewFromLeft']()?_0x4de8f9['limitToFirst']=_0x5e529a['limit_']:_0x4de8f9['limitToLast']=_0x5e529a['limit_']),_0x4de8f9;}function sr(_0x47d501){const _0x299ac1={};if(_0x47d501['startSet_']&&(_0x299ac1['sp']=_0x47d501['indexStartValue_'],_0x47d501['startNameSet_']&&(_0x299ac1['sn']=_0x47d501['indexStartName_']),_0x299ac1['sin']=!_0x47d501['startAfterSet_']),_0x47d501['endSet_']&&(_0x299ac1['ep']=_0x47d501['indexEndValue_'],_0x47d501['endNameSet_']&&(_0x299ac1['en']=_0x47d501['indexEndName_']),_0x299ac1['ein']=!_0x47d501['endBeforeSet_']),_0x47d501['limitSet_']){_0x299ac1['l']=_0x47d501['limit_'];let _0x4c65f0=_0x47d501['viewFrom_'];_0x4c65f0===''&&(_0x47d501['isViewFromLeft']()?_0x4c65f0='l':_0x4c65f0='r'),_0x299ac1['vf']=_0x4c65f0;}return _0x47d501['index_']!==R&&(_0x299ac1['i']=_0x47d501['index_']['toString']()),_0x299ac1;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2d73d2){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5d1cd9,_0x4a609a){return _0x4a609a!==void 0x0?'tag$'+_0x4a609a:(f(_0x5d1cd9['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5d1cd9['_path']['toString']());}constructor(_0x10e800,_0x32921f,_0x4abba4,_0x3d675e){super(),this['repoInfo_']=_0x10e800,this['onDataUpdate_']=_0x32921f,this['authTokenProvider_']=_0x4abba4,this['appCheckTokenProvider_']=_0x3d675e,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4825eb,_0x2c4198,_0x2cf80e,_0x5a3806){const _0x599520=_0x4825eb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x599520+'\x20'+_0x4825eb['_queryIdentifier']);const _0x5a1e35=vn['getListenId_'](_0x4825eb,_0x2cf80e),_0x4f5fb1={};this['listens_'][_0x5a1e35]=_0x4f5fb1;const _0x41726c=ir(_0x4825eb['_queryParams']);this['restRequest_'](_0x599520+'.json',_0x41726c,(_0x39f184,_0x4c8aa0)=>{let _0x50b010=_0x4c8aa0;if(_0x39f184===0x194&&(_0x50b010=null,_0x39f184=null),_0x39f184===null&&this['onDataUpdate_'](_0x599520,_0x50b010,!0x1,_0x2cf80e),Le(this['listens_'],_0x5a1e35)===_0x4f5fb1){let _0x1e8ba1;_0x39f184?_0x39f184===0x191?_0x1e8ba1='permission_denied':_0x1e8ba1='rest_error:'+_0x39f184:_0x1e8ba1='ok',_0x5a3806(_0x1e8ba1,null);}});}['unlisten'](_0x3337bc,_0x32324d){const _0x436120=vn['getListenId_'](_0x3337bc,_0x32324d);delete this['listens_'][_0x436120];}['get'](_0x302ab7){const _0x3d6d1e=ir(_0x302ab7['_queryParams']),_0x4ee165=_0x302ab7['_path']['toString'](),_0x2c04d8=new H();return this['restRequest_'](_0x4ee165+'.json',_0x3d6d1e,(_0x15a18f,_0x58f297)=>{let _0x306340=_0x58f297;_0x15a18f===0x194&&(_0x306340=null,_0x15a18f=null),_0x15a18f===null?(this['onDataUpdate_'](_0x4ee165,_0x306340,!0x1,null),_0x2c04d8['resolve'](_0x306340)):_0x2c04d8['reject'](new Error(_0x306340));}),_0x2c04d8['promise'];}['refreshAuthToken'](_0xe7c1de){}['restRequest_'](_0x4363d9,_0x203a5e={},_0x3e43c4){return _0x203a5e['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x47886c,_0x4529c9])=>{_0x47886c&&_0x47886c['accessToken']&&(_0x203a5e['auth']=_0x47886c['accessToken']),_0x4529c9&&_0x4529c9['token']&&(_0x203a5e['ac']=_0x4529c9['token']);const _0xe9acee=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4363d9+'?ns='+this['repoInfo_']['namespace']+ut(_0x203a5e);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xe9acee);const _0x38b4fd=new XMLHttpRequest();_0x38b4fd['onreadystatechange']=()=>{if(_0x3e43c4&&_0x38b4fd['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xe9acee+'\x20received.\x20status:',_0x38b4fd['status'],'response:',_0x38b4fd['responseText']);let _0x405725=null;if(_0x38b4fd['status']>=0xc8&&_0x38b4fd['status']<0x12c){try{_0x405725=Nt(_0x38b4fd['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xe9acee+':\x20'+_0x38b4fd['responseText']);}_0x3e43c4(null,_0x405725);}else _0x38b4fd['status']!==0x191&&_0x38b4fd['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xe9acee+'\x20Status:\x20'+_0x38b4fd['status']),_0x3e43c4(_0x38b4fd['status']);_0x3e43c4=null;}},_0x38b4fd['open']('GET',_0xe9acee,!0x0),_0x38b4fd['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x17dced){return this['rootNode_']['getChild'](_0x17dced);}['updateSnapshot'](_0x1843d5,_0x59f716){this['rootNode_']=this['rootNode_']['updateChild'](_0x1843d5,_0x59f716);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x1a6f13,_0x351826,_0x2c1c68){if(v(_0x351826))_0x1a6f13['value']=_0x2c1c68,_0x1a6f13['children']['clear']();else{if(_0x1a6f13['value']!==null)_0x1a6f13['value']=_0x1a6f13['value']['updateChild'](_0x351826,_0x2c1c68);else{const _0xf5f078=y(_0x351826);_0x1a6f13['children']['has'](_0xf5f078)||_0x1a6f13['children']['set'](_0xf5f078,En());const _0x541d8a=_0x1a6f13['children']['get'](_0xf5f078);_0x351826=S(_0x351826),pt(_0x541d8a,_0x351826,_0x2c1c68);}}}function Ti(_0x3e9820,_0x1af893){if(v(_0x1af893))return _0x3e9820['value']=null,_0x3e9820['children']['clear'](),!0x0;if(_0x3e9820['value']!==null){if(_0x3e9820['value']['isLeafNode']())return!0x1;{const _0x2c7acb=_0x3e9820['value'];return _0x3e9820['value']=null,_0x2c7acb['forEachChild'](R,(_0x2eff6b,_0x229edb)=>{pt(_0x3e9820,new C(_0x2eff6b),_0x229edb);}),Ti(_0x3e9820,_0x1af893);}}else{if(_0x3e9820['children']['size']>0x0){const _0xbce47e=y(_0x1af893);return _0x1af893=S(_0x1af893),_0x3e9820['children']['has'](_0xbce47e)&&Ti(_0x3e9820['children']['get'](_0xbce47e),_0x1af893)&&_0x3e9820['children']['delete'](_0xbce47e),_0x3e9820['children']['size']===0x0;}else return!0x0;}}function Si(_0x13ae28,_0x4ff008,_0x5984e0){_0x13ae28['value']!==null?_0x5984e0(_0x4ff008,_0x13ae28['value']):Zh(_0x13ae28,(_0x52d931,_0x58b593)=>{const _0x1449da=new C(_0x4ff008['toString']()+'/'+_0x52d931);Si(_0x58b593,_0x1449da,_0x5984e0);});}function Zh(_0x50c1a7,_0x254258){_0x50c1a7['children']['forEach']((_0x31dc77,_0x27fd33)=>{_0x254258(_0x27fd33,_0x31dc77);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3441aa){this['collection_']=_0x3441aa,this['last_']=null;}['get'](){const _0x1524bd=this['collection_']['get'](),_0x4f72f9={..._0x1524bd};return this['last_']&&x(this['last_'],(_0x33da53,_0x5aa1a9)=>{_0x4f72f9[_0x33da53]=_0x4f72f9[_0x33da53]-_0x5aa1a9;}),this['last_']=_0x1524bd,_0x4f72f9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x32c944,_0x303e16){this['server_']=_0x303e16,this['statsToReport_']={},this['statsListener_']=new eu(_0x32c944);const _0x505a18=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x505a18));}['reportStats_'](){const _0x8a10fd=this['statsListener_']['get'](),_0x99ec6f={};let _0x5714ab=!0x1;x(_0x8a10fd,(_0x5c2d25,_0x35eeb0)=>{_0x35eeb0>0x0&&Q(this['statsToReport_'],_0x5c2d25)&&(_0x99ec6f[_0x5c2d25]=_0x35eeb0,_0x5714ab=!0x0);}),_0x5714ab&&this['server_']['reportStats'](_0x99ec6f),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2e826b){_0x2e826b[_0x2e826b['OVERWRITE']=0x0]='OVERWRITE',_0x2e826b[_0x2e826b['MERGE']=0x1]='MERGE',_0x2e826b[_0x2e826b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2e826b[_0x2e826b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0xacc731){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xacc731,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x439e14,_0x849360,_0x3195f1){this['path']=_0x439e14,this['affectedTree']=_0x849360,this['revert']=_0x3195f1,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x255ba2){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4cebe1=this['affectedTree']['subtree'](new C(_0x255ba2));return new In(w(),_0x4cebe1,this['revert']);}}else return f(y(this['path'])===_0x255ba2,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x142a69,_0x16dada){this['source']=_0x142a69,this['path']=_0x16dada,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5ba2b6){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x401169,_0x57d662,_0x49757d){this['source']=_0x401169,this['path']=_0x57d662,this['snap']=_0x49757d,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1c923a){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1c923a)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x323c51,_0x3ecae0,_0x197036){this['source']=_0x323c51,this['path']=_0x3ecae0,this['children']=_0x197036,this['type']=z['MERGE'];}['operationForChild'](_0x1378e3){if(v(this['path'])){const _0x2897b7=this['children']['subtree'](new C(_0x1378e3));return _0x2897b7['isEmpty']()?null:_0x2897b7['value']?new Be(this['source'],w(),_0x2897b7['value']):new ot(this['source'],w(),_0x2897b7);}else return f(y(this['path'])===_0x1378e3,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x1d2747,_0x24cd25,_0x2020b4){this['node_']=_0x1d2747,this['fullyInitialized_']=_0x24cd25,this['filtered_']=_0x2020b4;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x470cbf){if(v(_0x470cbf))return this['isFullyInitialized']()&&!this['filtered_'];const _0xb12270=y(_0x470cbf);return this['isCompleteForChild'](_0xb12270);}['isCompleteForChild'](_0x524b2b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x524b2b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2028cf){this['query_']=_0x2028cf,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x577649,_0xf07f45,_0x58d626,_0x559773){const _0x4156db=[],_0x347d24=[];return _0xf07f45['forEach'](_0x5566f8=>{_0x5566f8['type']==='child_changed'&&_0x577649['index_']['indexedValueChanged'](_0x5566f8['oldSnap'],_0x5566f8['snapshotNode'])&&_0x347d24['push'](zh(_0x5566f8['childName'],_0x5566f8['snapshotNode']));}),wt(_0x577649,_0x4156db,'child_removed',_0xf07f45,_0x559773,_0x58d626),wt(_0x577649,_0x4156db,'child_added',_0xf07f45,_0x559773,_0x58d626),wt(_0x577649,_0x4156db,'child_moved',_0x347d24,_0x559773,_0x58d626),wt(_0x577649,_0x4156db,'child_changed',_0xf07f45,_0x559773,_0x58d626),wt(_0x577649,_0x4156db,'value',_0xf07f45,_0x559773,_0x58d626),_0x4156db;}function wt(_0x1ffd8d,_0x22b5b8,_0x2cd24c,_0x38856e,_0x1fb7fd,_0x36ea0a){const _0x27983e=_0x38856e['filter'](_0x3a3d66=>_0x3a3d66['type']===_0x2cd24c);_0x27983e['sort']((_0xeef374,_0x1f6c9f)=>au(_0x1ffd8d,_0xeef374,_0x1f6c9f)),_0x27983e['forEach'](_0x129bcf=>{const _0x5eb93c=ou(_0x1ffd8d,_0x129bcf,_0x36ea0a);_0x1fb7fd['forEach'](_0x3e7890=>{_0x3e7890['respondsTo'](_0x129bcf['type'])&&_0x22b5b8['push'](_0x3e7890['createEvent'](_0x5eb93c,_0x1ffd8d['query_']));});});}function ou(_0x32a5bd,_0x3713b0,_0x350106){return _0x3713b0['type']==='value'||_0x3713b0['type']==='child_removed'||(_0x3713b0['prevName']=_0x350106['getPredecessorChildName'](_0x3713b0['childName'],_0x3713b0['snapshotNode'],_0x32a5bd['index_'])),_0x3713b0;}function au(_0x389405,_0x34b6d7,_0x162835){if(_0x34b6d7['childName']==null||_0x162835['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x37547c=new E(_0x34b6d7['childName'],_0x34b6d7['snapshotNode']),_0x3da099=new E(_0x162835['childName'],_0x162835['snapshotNode']);return _0x389405['index_']['compare'](_0x37547c,_0x3da099);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x375559,_0x2af2fb){return{'eventCache':_0x375559,'serverCache':_0x2af2fb};}function Rt(_0x4ab9d5,_0x29dc44,_0x5203d7,_0x49619b){return Un(new Te(_0x29dc44,_0x5203d7,_0x49619b),_0x4ab9d5['serverCache']);}function Fo(_0x746f71,_0x5dc039,_0x790ec4,_0x48e569){return Un(_0x746f71['eventCache'],new Te(_0x5dc039,_0x790ec4,_0x48e569));}function wn(_0x2096a9){return _0x2096a9['eventCache']['isFullyInitialized']()?_0x2096a9['eventCache']['getNode']():null;}function Ve(_0x4cd8e0){return _0x4cd8e0['serverCache']['isFullyInitialized']()?_0x4cd8e0['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x213144){let _0xdf379f=new b(null);return x(_0x213144,(_0x3607c3,_0x2c486b)=>{_0xdf379f=_0xdf379f['set'](new C(_0x3607c3),_0x2c486b);}),_0xdf379f;}constructor(_0x54f14e,_0x3a0c29=cu()){this['value']=_0x54f14e,this['children']=_0x3a0c29;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x223046,_0xea4a1a){if(this['value']!=null&&_0xea4a1a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x223046))return null;{const _0x586466=y(_0x223046),_0x4171c0=this['children']['get'](_0x586466);if(_0x4171c0!==null){const _0x454134=_0x4171c0['findRootMostMatchingPathAndValue'](S(_0x223046),_0xea4a1a);return _0x454134!=null?{'path':k(new C(_0x586466),_0x454134['path']),'value':_0x454134['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x482de6){return this['findRootMostMatchingPathAndValue'](_0x482de6,()=>!0x0);}['subtree'](_0x414519){if(v(_0x414519))return this;{const _0x4979d0=y(_0x414519),_0x5ce317=this['children']['get'](_0x4979d0);return _0x5ce317!==null?_0x5ce317['subtree'](S(_0x414519)):new b(null);}}['set'](_0x496af0,_0x5b57e0){if(v(_0x496af0))return new b(_0x5b57e0,this['children']);{const _0xdc0fb6=y(_0x496af0),_0x5e0b8e=(this['children']['get'](_0xdc0fb6)||new b(null))['set'](S(_0x496af0),_0x5b57e0),_0x57ed8b=this['children']['insert'](_0xdc0fb6,_0x5e0b8e);return new b(this['value'],_0x57ed8b);}}['remove'](_0x10cbee){if(v(_0x10cbee))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x260448=y(_0x10cbee),_0x5bf221=this['children']['get'](_0x260448);if(_0x5bf221){const _0x556d83=_0x5bf221['remove'](S(_0x10cbee));let _0x340f28;return _0x556d83['isEmpty']()?_0x340f28=this['children']['remove'](_0x260448):_0x340f28=this['children']['insert'](_0x260448,_0x556d83),this['value']===null&&_0x340f28['isEmpty']()?new b(null):new b(this['value'],_0x340f28);}else return this;}}['get'](_0x24d12a){if(v(_0x24d12a))return this['value'];{const _0x409a1e=y(_0x24d12a),_0x1959ea=this['children']['get'](_0x409a1e);return _0x1959ea?_0x1959ea['get'](S(_0x24d12a)):null;}}['setTree'](_0x922027,_0x1b4fcb){if(v(_0x922027))return _0x1b4fcb;{const _0x148b5b=y(_0x922027),_0x5d82f2=(this['children']['get'](_0x148b5b)||new b(null))['setTree'](S(_0x922027),_0x1b4fcb);let _0x56d819;return _0x5d82f2['isEmpty']()?_0x56d819=this['children']['remove'](_0x148b5b):_0x56d819=this['children']['insert'](_0x148b5b,_0x5d82f2),new b(this['value'],_0x56d819);}}['fold'](_0x25cd15){return this['fold_'](w(),_0x25cd15);}['fold_'](_0x2ff8f2,_0x4a81c4){const _0x124c40={};return this['children']['inorderTraversal']((_0x27d702,_0x4bf7c7)=>{_0x124c40[_0x27d702]=_0x4bf7c7['fold_'](k(_0x2ff8f2,_0x27d702),_0x4a81c4);}),_0x4a81c4(_0x2ff8f2,this['value'],_0x124c40);}['findOnPath'](_0x573159,_0x5ea66a){return this['findOnPath_'](_0x573159,w(),_0x5ea66a);}['findOnPath_'](_0x2af6b7,_0x5ce587,_0x306108){const _0x164567=this['value']?_0x306108(_0x5ce587,this['value']):!0x1;if(_0x164567)return _0x164567;if(v(_0x2af6b7))return null;{const _0x138a25=y(_0x2af6b7),_0x4f4e8c=this['children']['get'](_0x138a25);return _0x4f4e8c?_0x4f4e8c['findOnPath_'](S(_0x2af6b7),k(_0x5ce587,_0x138a25),_0x306108):null;}}['foreachOnPath'](_0x5b5a4f,_0x2284e5){return this['foreachOnPath_'](_0x5b5a4f,w(),_0x2284e5);}['foreachOnPath_'](_0x1a5f8f,_0x39b91b,_0x2c6b23){if(v(_0x1a5f8f))return this;{this['value']&&_0x2c6b23(_0x39b91b,this['value']);const _0x2af169=y(_0x1a5f8f),_0x5be0ee=this['children']['get'](_0x2af169);return _0x5be0ee?_0x5be0ee['foreachOnPath_'](S(_0x1a5f8f),k(_0x39b91b,_0x2af169),_0x2c6b23):new b(null);}}['foreach'](_0x550621){this['foreach_'](w(),_0x550621);}['foreach_'](_0x192dcc,_0x69b6d3){this['children']['inorderTraversal']((_0x4be35f,_0x454ece)=>{_0x454ece['foreach_'](k(_0x192dcc,_0x4be35f),_0x69b6d3);}),this['value']&&_0x69b6d3(_0x192dcc,this['value']);}['foreachChild'](_0x72d6b7){this['children']['inorderTraversal']((_0x679b01,_0x3747b1)=>{_0x3747b1['value']&&_0x72d6b7(_0x679b01,_0x3747b1['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x1743f0){this['writeTree_']=_0x1743f0;}static['empty'](){return new K(new b(null));}}function At(_0x23403f,_0x513bec,_0x7054e0){if(v(_0x513bec))return new K(new b(_0x7054e0));{const _0x39569c=_0x23403f['writeTree_']['findRootMostValueAndPath'](_0x513bec);if(_0x39569c!=null){const _0x374d6a=_0x39569c['path'];let _0x1eb299=_0x39569c['value'];const _0x2275e9=F(_0x374d6a,_0x513bec);return _0x1eb299=_0x1eb299['updateChild'](_0x2275e9,_0x7054e0),new K(_0x23403f['writeTree_']['set'](_0x374d6a,_0x1eb299));}else{const _0x4f7bc9=new b(_0x7054e0),_0x280ab6=_0x23403f['writeTree_']['setTree'](_0x513bec,_0x4f7bc9);return new K(_0x280ab6);}}}function bi(_0x1bd895,_0x55d3b0,_0x1c7ef8){let _0x27317b=_0x1bd895;return x(_0x1c7ef8,(_0x3f1708,_0x4e75ab)=>{_0x27317b=At(_0x27317b,k(_0x55d3b0,_0x3f1708),_0x4e75ab);}),_0x27317b;}function or(_0xeb3577,_0x396b33){if(v(_0x396b33))return K['empty']();{const _0x34395a=_0xeb3577['writeTree_']['setTree'](_0x396b33,new b(null));return new K(_0x34395a);}}function Ri(_0x27bace,_0x45b7e7){return ze(_0x27bace,_0x45b7e7)!=null;}function ze(_0x3cd4e6,_0x5a3fb3){const _0x239020=_0x3cd4e6['writeTree_']['findRootMostValueAndPath'](_0x5a3fb3);return _0x239020!=null?_0x3cd4e6['writeTree_']['get'](_0x239020['path'])['getChild'](F(_0x239020['path'],_0x5a3fb3)):null;}function ar(_0x11dab0){const _0x20c126=[],_0x2d7aa1=_0x11dab0['writeTree_']['value'];return _0x2d7aa1!=null?_0x2d7aa1['isLeafNode']()||_0x2d7aa1['forEachChild'](R,(_0x3e88b1,_0x4e22fb)=>{_0x20c126['push'](new E(_0x3e88b1,_0x4e22fb));}):_0x11dab0['writeTree_']['children']['inorderTraversal']((_0x76781d,_0x4599d4)=>{_0x4599d4['value']!=null&&_0x20c126['push'](new E(_0x76781d,_0x4599d4['value']));}),_0x20c126;}function Ee(_0x1d97af,_0x482dda){if(v(_0x482dda))return _0x1d97af;{const _0x45fdc0=ze(_0x1d97af,_0x482dda);return _0x45fdc0!=null?new K(new b(_0x45fdc0)):new K(_0x1d97af['writeTree_']['subtree'](_0x482dda));}}function Ai(_0xdc92fc){return _0xdc92fc['writeTree_']['isEmpty']();}function at(_0x3dc143,_0x226ed2){return Uo(w(),_0x3dc143['writeTree_'],_0x226ed2);}function Uo(_0x5c8e51,_0x211b21,_0x45dd68){if(_0x211b21['value']!=null)return _0x45dd68['updateChild'](_0x5c8e51,_0x211b21['value']);{let _0x4d76c5=null;return _0x211b21['children']['inorderTraversal']((_0x2a9b50,_0x2a47a0)=>{_0x2a9b50==='.priority'?(f(_0x2a47a0['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4d76c5=_0x2a47a0['value']):_0x45dd68=Uo(k(_0x5c8e51,_0x2a9b50),_0x2a47a0,_0x45dd68);}),!_0x45dd68['getChild'](_0x5c8e51)['isEmpty']()&&_0x4d76c5!==null&&(_0x45dd68=_0x45dd68['updateChild'](k(_0x5c8e51,'.priority'),_0x4d76c5)),_0x45dd68;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5974f0,_0x3e1fc0){return Ho(_0x3e1fc0,_0x5974f0);}function lu(_0x320a69,_0x4f2d52,_0x45939b,_0xeae450,_0x12ef0a){f(_0xeae450>_0x320a69['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x12ef0a===void 0x0&&(_0x12ef0a=!0x0),_0x320a69['allWrites']['push']({'path':_0x4f2d52,'snap':_0x45939b,'writeId':_0xeae450,'visible':_0x12ef0a}),_0x12ef0a&&(_0x320a69['visibleWrites']=At(_0x320a69['visibleWrites'],_0x4f2d52,_0x45939b)),_0x320a69['lastWriteId']=_0xeae450;}function hu(_0x48e218,_0x2e98ef,_0x169c34,_0x546637){f(_0x546637>_0x48e218['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x48e218['allWrites']['push']({'path':_0x2e98ef,'children':_0x169c34,'writeId':_0x546637,'visible':!0x0}),_0x48e218['visibleWrites']=bi(_0x48e218['visibleWrites'],_0x2e98ef,_0x169c34),_0x48e218['lastWriteId']=_0x546637;}function uu(_0x280b2a,_0x2969e8){for(let _0x4257c5=0x0;_0x4257c5<_0x280b2a['allWrites']['length'];_0x4257c5++){const _0x8bee39=_0x280b2a['allWrites'][_0x4257c5];if(_0x8bee39['writeId']===_0x2969e8)return _0x8bee39;}return null;}function du(_0x1e1979,_0x373cf7){const _0x315392=_0x1e1979['allWrites']['findIndex'](_0x23a83b=>_0x23a83b['writeId']===_0x373cf7);f(_0x315392>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1363df=_0x1e1979['allWrites'][_0x315392];_0x1e1979['allWrites']['splice'](_0x315392,0x1);let _0xc08d8d=_0x1363df['visible'],_0x3c774f=!0x1,_0x1a4645=_0x1e1979['allWrites']['length']-0x1;for(;_0xc08d8d&&_0x1a4645>=0x0;){const _0x298f88=_0x1e1979['allWrites'][_0x1a4645];_0x298f88['visible']&&(_0x1a4645>=_0x315392&&fu(_0x298f88,_0x1363df['path'])?_0xc08d8d=!0x1:G(_0x1363df['path'],_0x298f88['path'])&&(_0x3c774f=!0x0)),_0x1a4645--;}if(_0xc08d8d){if(_0x3c774f)return pu(_0x1e1979),!0x0;if(_0x1363df['snap'])_0x1e1979['visibleWrites']=or(_0x1e1979['visibleWrites'],_0x1363df['path']);else{const _0x1aaf40=_0x1363df['children'];x(_0x1aaf40,_0x415ea3=>{_0x1e1979['visibleWrites']=or(_0x1e1979['visibleWrites'],k(_0x1363df['path'],_0x415ea3));});}return!0x0;}else return!0x1;}function fu(_0x3b52f5,_0x4ca83e){if(_0x3b52f5['snap'])return G(_0x3b52f5['path'],_0x4ca83e);for(const _0x5ad1e4 in _0x3b52f5['children'])if(_0x3b52f5['children']['hasOwnProperty'](_0x5ad1e4)&&G(k(_0x3b52f5['path'],_0x5ad1e4),_0x4ca83e))return!0x0;return!0x1;}function pu(_0x2dfc45){_0x2dfc45['visibleWrites']=Wo(_0x2dfc45['allWrites'],_u,w()),_0x2dfc45['allWrites']['length']>0x0?_0x2dfc45['lastWriteId']=_0x2dfc45['allWrites'][_0x2dfc45['allWrites']['length']-0x1]['writeId']:_0x2dfc45['lastWriteId']=-0x1;}function _u(_0x1421a4){return _0x1421a4['visible'];}function Wo(_0x1c60dd,_0x1a625a,_0xb09ad4){let _0x563487=K['empty']();for(let _0xe9261f=0x0;_0xe9261f<_0x1c60dd['length'];++_0xe9261f){const _0x9577a2=_0x1c60dd[_0xe9261f];if(_0x1a625a(_0x9577a2)){const _0xa1414d=_0x9577a2['path'];let _0x507666;if(_0x9577a2['snap'])G(_0xb09ad4,_0xa1414d)?(_0x507666=F(_0xb09ad4,_0xa1414d),_0x563487=At(_0x563487,_0x507666,_0x9577a2['snap'])):G(_0xa1414d,_0xb09ad4)&&(_0x507666=F(_0xa1414d,_0xb09ad4),_0x563487=At(_0x563487,w(),_0x9577a2['snap']['getChild'](_0x507666)));else{if(_0x9577a2['children']){if(G(_0xb09ad4,_0xa1414d))_0x507666=F(_0xb09ad4,_0xa1414d),_0x563487=bi(_0x563487,_0x507666,_0x9577a2['children']);else{if(G(_0xa1414d,_0xb09ad4)){if(_0x507666=F(_0xa1414d,_0xb09ad4),v(_0x507666))_0x563487=bi(_0x563487,w(),_0x9577a2['children']);else{const _0x42fad4=Le(_0x9577a2['children'],y(_0x507666));if(_0x42fad4){const _0x196abd=_0x42fad4['getChild'](S(_0x507666));_0x563487=At(_0x563487,w(),_0x196abd);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x563487;}function Bo(_0x2cd640,_0x2e00bf,_0x112d4e,_0x484b85,_0x5a8bf2){if(!_0x484b85&&!_0x5a8bf2){const _0x2c74a1=ze(_0x2cd640['visibleWrites'],_0x2e00bf);if(_0x2c74a1!=null)return _0x2c74a1;{const _0xbb491a=Ee(_0x2cd640['visibleWrites'],_0x2e00bf);if(Ai(_0xbb491a))return _0x112d4e;if(_0x112d4e==null&&!Ri(_0xbb491a,w()))return null;{const _0x4e5691=_0x112d4e||g['EMPTY_NODE'];return at(_0xbb491a,_0x4e5691);}}}else{const _0x154f46=Ee(_0x2cd640['visibleWrites'],_0x2e00bf);if(!_0x5a8bf2&&Ai(_0x154f46))return _0x112d4e;if(!_0x5a8bf2&&_0x112d4e==null&&!Ri(_0x154f46,w()))return null;{const _0x4599cf=function(_0x539ac4){return(_0x539ac4['visible']||_0x5a8bf2)&&(!_0x484b85||!~_0x484b85['indexOf'](_0x539ac4['writeId']))&&(G(_0x539ac4['path'],_0x2e00bf)||G(_0x2e00bf,_0x539ac4['path']));},_0x503704=Wo(_0x2cd640['allWrites'],_0x4599cf,_0x2e00bf),_0xad5d4d=_0x112d4e||g['EMPTY_NODE'];return at(_0x503704,_0xad5d4d);}}}function gu(_0x379374,_0x46d09a,_0x3d997c){let _0x3007ab=g['EMPTY_NODE'];const _0x14a61f=ze(_0x379374['visibleWrites'],_0x46d09a);if(_0x14a61f)return _0x14a61f['isLeafNode']()||_0x14a61f['forEachChild'](R,(_0x39af2c,_0x21b792)=>{_0x3007ab=_0x3007ab['updateImmediateChild'](_0x39af2c,_0x21b792);}),_0x3007ab;if(_0x3d997c){const _0x170afe=Ee(_0x379374['visibleWrites'],_0x46d09a);return _0x3d997c['forEachChild'](R,(_0xb835f2,_0x304245)=>{const _0xf5aa9c=at(Ee(_0x170afe,new C(_0xb835f2)),_0x304245);_0x3007ab=_0x3007ab['updateImmediateChild'](_0xb835f2,_0xf5aa9c);}),ar(_0x170afe)['forEach'](_0x5a9ac3=>{_0x3007ab=_0x3007ab['updateImmediateChild'](_0x5a9ac3['name'],_0x5a9ac3['node']);}),_0x3007ab;}else{const _0x1e857d=Ee(_0x379374['visibleWrites'],_0x46d09a);return ar(_0x1e857d)['forEach'](_0x5ebb9e=>{_0x3007ab=_0x3007ab['updateImmediateChild'](_0x5ebb9e['name'],_0x5ebb9e['node']);}),_0x3007ab;}}function mu(_0x55ff05,_0x12ee46,_0x95ded7,_0x19054b,_0x5db18d){f(_0x19054b||_0x5db18d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x45af5b=k(_0x12ee46,_0x95ded7);if(Ri(_0x55ff05['visibleWrites'],_0x45af5b))return null;{const _0x3b1a8c=Ee(_0x55ff05['visibleWrites'],_0x45af5b);return Ai(_0x3b1a8c)?_0x5db18d['getChild'](_0x95ded7):at(_0x3b1a8c,_0x5db18d['getChild'](_0x95ded7));}}function yu(_0x262a69,_0x1741c1,_0x26327b,_0x42c26f){const _0x20a491=k(_0x1741c1,_0x26327b),_0x1298e2=ze(_0x262a69['visibleWrites'],_0x20a491);if(_0x1298e2!=null)return _0x1298e2;if(_0x42c26f['isCompleteForChild'](_0x26327b)){const _0x3725d9=Ee(_0x262a69['visibleWrites'],_0x20a491);return at(_0x3725d9,_0x42c26f['getNode']()['getImmediateChild'](_0x26327b));}else return null;}function vu(_0x5853e2,_0x5534d0){return ze(_0x5853e2['visibleWrites'],_0x5534d0);}function Eu(_0x5c0886,_0xeef4d4,_0x45637b,_0x150b52,_0x4df9b9,_0x4fc706,_0x53af51){let _0x30b66d;const _0x2fc142=Ee(_0x5c0886['visibleWrites'],_0xeef4d4),_0xb2b418=ze(_0x2fc142,w());if(_0xb2b418!=null)_0x30b66d=_0xb2b418;else{if(_0x45637b!=null)_0x30b66d=at(_0x2fc142,_0x45637b);else return[];}if(_0x30b66d=_0x30b66d['withIndex'](_0x53af51),!_0x30b66d['isEmpty']()&&!_0x30b66d['isLeafNode']()){const _0x1c0e44=[],_0x12e836=_0x53af51['getCompare'](),_0xbd9fcc=_0x4fc706?_0x30b66d['getReverseIteratorFrom'](_0x150b52,_0x53af51):_0x30b66d['getIteratorFrom'](_0x150b52,_0x53af51);let _0x548847=_0xbd9fcc['getNext']();for(;_0x548847&&_0x1c0e44['length']<_0x4df9b9;)_0x12e836(_0x548847,_0x150b52)!==0x0&&_0x1c0e44['push'](_0x548847),_0x548847=_0xbd9fcc['getNext']();return _0x1c0e44;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x972994,_0x1aefbf,_0x52fa24,_0x52eafc){return Bo(_0x972994['writeTree'],_0x972994['treePath'],_0x1aefbf,_0x52fa24,_0x52eafc);}function is(_0x552244,_0x586484){return gu(_0x552244['writeTree'],_0x552244['treePath'],_0x586484);}function cr(_0x59f002,_0xccad3a,_0x12c596,_0x12e59c){return mu(_0x59f002['writeTree'],_0x59f002['treePath'],_0xccad3a,_0x12c596,_0x12e59c);}function Tn(_0xef2758,_0x1d1abb){return vu(_0xef2758['writeTree'],k(_0xef2758['treePath'],_0x1d1abb));}function wu(_0x121485,_0x2d703c,_0x3b5a5b,_0xc6c342,_0x17d92c,_0x436c9f){return Eu(_0x121485['writeTree'],_0x121485['treePath'],_0x2d703c,_0x3b5a5b,_0xc6c342,_0x17d92c,_0x436c9f);}function ss(_0x343e96,_0x993715,_0x4f10c5){return yu(_0x343e96['writeTree'],_0x343e96['treePath'],_0x993715,_0x4f10c5);}function Vo(_0x4f1aaa,_0x450914){return Ho(k(_0x4f1aaa['treePath'],_0x450914),_0x4f1aaa['writeTree']);}function Ho(_0x21fbed,_0x11cd37){return{'treePath':_0x21fbed,'writeTree':_0x11cd37};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xee7db0){const _0x1e0369=_0xee7db0['type'],_0x29f740=_0xee7db0['childName'];f(_0x1e0369==='child_added'||_0x1e0369==='child_changed'||_0x1e0369==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x29f740!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1e0b81=this['changeMap']['get'](_0x29f740);if(_0x1e0b81){const _0x22386f=_0x1e0b81['type'];if(_0x1e0369==='child_added'&&_0x22386f==='child_removed')this['changeMap']['set'](_0x29f740,xt(_0x29f740,_0xee7db0['snapshotNode'],_0x1e0b81['snapshotNode']));else{if(_0x1e0369==='child_removed'&&_0x22386f==='child_added')this['changeMap']['delete'](_0x29f740);else{if(_0x1e0369==='child_removed'&&_0x22386f==='child_changed')this['changeMap']['set'](_0x29f740,Lt(_0x29f740,_0x1e0b81['oldSnap']));else{if(_0x1e0369==='child_changed'&&_0x22386f==='child_added')this['changeMap']['set'](_0x29f740,rt(_0x29f740,_0xee7db0['snapshotNode']));else{if(_0x1e0369==='child_changed'&&_0x22386f==='child_changed')this['changeMap']['set'](_0x29f740,xt(_0x29f740,_0xee7db0['snapshotNode'],_0x1e0b81['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0xee7db0+'\x20occurred\x20after\x20'+_0x1e0b81);}}}}}else this['changeMap']['set'](_0x29f740,_0xee7db0);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x33f32d){return null;}['getChildAfterChild'](_0x4dc017,_0x516765,_0x59f980){return null;}}const $o=new Tu();class rs{constructor(_0x16a130,_0x48b2bf,_0x20158d=null){this['writes_']=_0x16a130,this['viewCache_']=_0x48b2bf,this['optCompleteServerCache_']=_0x20158d;}['getCompleteChild'](_0x47ad56){const _0x5ed1d6=this['viewCache_']['eventCache'];if(_0x5ed1d6['isCompleteForChild'](_0x47ad56))return _0x5ed1d6['getNode']()['getImmediateChild'](_0x47ad56);{const _0x4449d0=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x47ad56,_0x4449d0);}}['getChildAfterChild'](_0x4faf63,_0x136bc7,_0xf23b3d){const _0x30dd0f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x7150b0=wu(this['writes_'],_0x30dd0f,_0x136bc7,0x1,_0xf23b3d,_0x4faf63);return _0x7150b0['length']===0x0?null:_0x7150b0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x136912){return{'filter':_0x136912};}function bu(_0x5e64c4,_0x18001a){f(_0x18001a['eventCache']['getNode']()['isIndexed'](_0x5e64c4['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x18001a['serverCache']['getNode']()['isIndexed'](_0x5e64c4['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x100373,_0x2a0710,_0x43540d,_0x1607f7,_0x4726e2){const _0xeb7ef0=new Cu();let _0x16eab6,_0x3ce36;if(_0x43540d['type']===z['OVERWRITE']){const _0x2ddf08=_0x43540d;_0x2ddf08['source']['fromUser']?_0x16eab6=ki(_0x100373,_0x2a0710,_0x2ddf08['path'],_0x2ddf08['snap'],_0x1607f7,_0x4726e2,_0xeb7ef0):(f(_0x2ddf08['source']['fromServer'],'Unknown\x20source.'),_0x3ce36=_0x2ddf08['source']['tagged']||_0x2a0710['serverCache']['isFiltered']()&&!v(_0x2ddf08['path']),_0x16eab6=Sn(_0x100373,_0x2a0710,_0x2ddf08['path'],_0x2ddf08['snap'],_0x1607f7,_0x4726e2,_0x3ce36,_0xeb7ef0));}else{if(_0x43540d['type']===z['MERGE']){const _0x9d465b=_0x43540d;_0x9d465b['source']['fromUser']?_0x16eab6=ku(_0x100373,_0x2a0710,_0x9d465b['path'],_0x9d465b['children'],_0x1607f7,_0x4726e2,_0xeb7ef0):(f(_0x9d465b['source']['fromServer'],'Unknown\x20source.'),_0x3ce36=_0x9d465b['source']['tagged']||_0x2a0710['serverCache']['isFiltered'](),_0x16eab6=Pi(_0x100373,_0x2a0710,_0x9d465b['path'],_0x9d465b['children'],_0x1607f7,_0x4726e2,_0x3ce36,_0xeb7ef0));}else{if(_0x43540d['type']===z['ACK_USER_WRITE']){const _0x1fe26a=_0x43540d;_0x1fe26a['revert']?_0x16eab6=Ou(_0x100373,_0x2a0710,_0x1fe26a['path'],_0x1607f7,_0x4726e2,_0xeb7ef0):_0x16eab6=Pu(_0x100373,_0x2a0710,_0x1fe26a['path'],_0x1fe26a['affectedTree'],_0x1607f7,_0x4726e2,_0xeb7ef0);}else{if(_0x43540d['type']===z['LISTEN_COMPLETE'])_0x16eab6=Nu(_0x100373,_0x2a0710,_0x43540d['path'],_0x1607f7,_0xeb7ef0);else throw ht('Unknown\x20operation\x20type:\x20'+_0x43540d['type']);}}}const _0x216d99=_0xeb7ef0['getChanges']();return Au(_0x2a0710,_0x16eab6,_0x216d99),{'viewCache':_0x16eab6,'changes':_0x216d99};}function Au(_0x4398c4,_0x2eeaa3,_0x5db10f){const _0x595561=_0x2eeaa3['eventCache'];if(_0x595561['isFullyInitialized']()){const _0x1fc2de=_0x595561['getNode']()['isLeafNode']()||_0x595561['getNode']()['isEmpty'](),_0x50da23=wn(_0x4398c4);(_0x5db10f['length']>0x0||!_0x4398c4['eventCache']['isFullyInitialized']()||_0x1fc2de&&!_0x595561['getNode']()['equals'](_0x50da23)||!_0x595561['getNode']()['getPriority']()['equals'](_0x50da23['getPriority']()))&&_0x5db10f['push'](Lo(wn(_0x2eeaa3)));}}function Go(_0x475ef3,_0x9dac31,_0x4bc2bd,_0xe7bb73,_0x19cd1c,_0x31d47c){const _0x41eb40=_0x9dac31['eventCache'];if(Tn(_0xe7bb73,_0x4bc2bd)!=null)return _0x9dac31;{let _0x1306b0,_0x42377e;if(v(_0x4bc2bd)){if(f(_0x9dac31['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x9dac31['serverCache']['isFiltered']()){const _0x266ba0=Ve(_0x9dac31),_0xdb5332=_0x266ba0 instanceof g?_0x266ba0:g['EMPTY_NODE'],_0x19a6bb=is(_0xe7bb73,_0xdb5332);_0x1306b0=_0x475ef3['filter']['updateFullNode'](_0x9dac31['eventCache']['getNode'](),_0x19a6bb,_0x31d47c);}else{const _0x5b8a1d=Cn(_0xe7bb73,Ve(_0x9dac31));_0x1306b0=_0x475ef3['filter']['updateFullNode'](_0x9dac31['eventCache']['getNode'](),_0x5b8a1d,_0x31d47c);}}else{const _0x22387c=y(_0x4bc2bd);if(_0x22387c==='.priority'){f(Ce(_0x4bc2bd)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x53bb15=_0x41eb40['getNode']();_0x42377e=_0x9dac31['serverCache']['getNode']();const _0x2daf79=cr(_0xe7bb73,_0x4bc2bd,_0x53bb15,_0x42377e);_0x2daf79!=null?_0x1306b0=_0x475ef3['filter']['updatePriority'](_0x53bb15,_0x2daf79):_0x1306b0=_0x41eb40['getNode']();}else{const _0x5ae5dc=S(_0x4bc2bd);let _0x1c0894;if(_0x41eb40['isCompleteForChild'](_0x22387c)){_0x42377e=_0x9dac31['serverCache']['getNode']();const _0x4cd27e=cr(_0xe7bb73,_0x4bc2bd,_0x41eb40['getNode'](),_0x42377e);_0x4cd27e!=null?_0x1c0894=_0x41eb40['getNode']()['getImmediateChild'](_0x22387c)['updateChild'](_0x5ae5dc,_0x4cd27e):_0x1c0894=_0x41eb40['getNode']()['getImmediateChild'](_0x22387c);}else _0x1c0894=ss(_0xe7bb73,_0x22387c,_0x9dac31['serverCache']);_0x1c0894!=null?_0x1306b0=_0x475ef3['filter']['updateChild'](_0x41eb40['getNode'](),_0x22387c,_0x1c0894,_0x5ae5dc,_0x19cd1c,_0x31d47c):_0x1306b0=_0x41eb40['getNode']();}}return Rt(_0x9dac31,_0x1306b0,_0x41eb40['isFullyInitialized']()||v(_0x4bc2bd),_0x475ef3['filter']['filtersNodes']());}}function Sn(_0x867d32,_0xeab6b4,_0x21c41d,_0x52cd72,_0x26bda9,_0x2788c6,_0x40bfdd,_0x2b915d){const _0x338df9=_0xeab6b4['serverCache'];let _0x2f1c1a;const _0xe4e633=_0x40bfdd?_0x867d32['filter']:_0x867d32['filter']['getIndexedFilter']();if(v(_0x21c41d))_0x2f1c1a=_0xe4e633['updateFullNode'](_0x338df9['getNode'](),_0x52cd72,null);else{if(_0xe4e633['filtersNodes']()&&!_0x338df9['isFiltered']()){const _0x16618b=_0x338df9['getNode']()['updateChild'](_0x21c41d,_0x52cd72);_0x2f1c1a=_0xe4e633['updateFullNode'](_0x338df9['getNode'](),_0x16618b,null);}else{const _0x2b1187=y(_0x21c41d);if(!_0x338df9['isCompleteForPath'](_0x21c41d)&&Ce(_0x21c41d)>0x1)return _0xeab6b4;const _0x4ffb6a=S(_0x21c41d),_0x5955ff=_0x338df9['getNode']()['getImmediateChild'](_0x2b1187)['updateChild'](_0x4ffb6a,_0x52cd72);_0x2b1187==='.priority'?_0x2f1c1a=_0xe4e633['updatePriority'](_0x338df9['getNode'](),_0x5955ff):_0x2f1c1a=_0xe4e633['updateChild'](_0x338df9['getNode'](),_0x2b1187,_0x5955ff,_0x4ffb6a,$o,null);}}const _0x2f8e6d=Fo(_0xeab6b4,_0x2f1c1a,_0x338df9['isFullyInitialized']()||v(_0x21c41d),_0xe4e633['filtersNodes']()),_0x115269=new rs(_0x26bda9,_0x2f8e6d,_0x2788c6);return Go(_0x867d32,_0x2f8e6d,_0x21c41d,_0x26bda9,_0x115269,_0x2b915d);}function ki(_0x5609d2,_0x283f4f,_0x2d14ad,_0x3917d8,_0x40c027,_0x3a2809,_0x53913d){const _0x5857d7=_0x283f4f['eventCache'];let _0xb2c086,_0x4886fb;const _0x3a0bd0=new rs(_0x40c027,_0x283f4f,_0x3a2809);if(v(_0x2d14ad))_0x4886fb=_0x5609d2['filter']['updateFullNode'](_0x283f4f['eventCache']['getNode'](),_0x3917d8,_0x53913d),_0xb2c086=Rt(_0x283f4f,_0x4886fb,!0x0,_0x5609d2['filter']['filtersNodes']());else{const _0x99384=y(_0x2d14ad);if(_0x99384==='.priority')_0x4886fb=_0x5609d2['filter']['updatePriority'](_0x283f4f['eventCache']['getNode'](),_0x3917d8),_0xb2c086=Rt(_0x283f4f,_0x4886fb,_0x5857d7['isFullyInitialized'](),_0x5857d7['isFiltered']());else{const _0x3a101d=S(_0x2d14ad),_0x5f34b6=_0x5857d7['getNode']()['getImmediateChild'](_0x99384);let _0x4bc8e0;if(v(_0x3a101d))_0x4bc8e0=_0x3917d8;else{const _0x328cdf=_0x3a0bd0['getCompleteChild'](_0x99384);_0x328cdf!=null?ji(_0x3a101d)==='.priority'&&_0x328cdf['getChild'](Ro(_0x3a101d))['isEmpty']()?_0x4bc8e0=_0x328cdf:_0x4bc8e0=_0x328cdf['updateChild'](_0x3a101d,_0x3917d8):_0x4bc8e0=g['EMPTY_NODE'];}if(_0x5f34b6['equals'](_0x4bc8e0))_0xb2c086=_0x283f4f;else{const _0x429c1d=_0x5609d2['filter']['updateChild'](_0x5857d7['getNode'](),_0x99384,_0x4bc8e0,_0x3a101d,_0x3a0bd0,_0x53913d);_0xb2c086=Rt(_0x283f4f,_0x429c1d,_0x5857d7['isFullyInitialized'](),_0x5609d2['filter']['filtersNodes']());}}}return _0xb2c086;}function lr(_0x7e20f2,_0x4490d0){return _0x7e20f2['eventCache']['isCompleteForChild'](_0x4490d0);}function ku(_0x4f190c,_0x23232a,_0x2dc21f,_0x3bd33,_0x2cb991,_0x57898f,_0x2851d3){let _0x4598be=_0x23232a;return _0x3bd33['foreach']((_0x400280,_0x245c90)=>{const _0x3849b1=k(_0x2dc21f,_0x400280);lr(_0x23232a,y(_0x3849b1))&&(_0x4598be=ki(_0x4f190c,_0x4598be,_0x3849b1,_0x245c90,_0x2cb991,_0x57898f,_0x2851d3));}),_0x3bd33['foreach']((_0x67f0c7,_0x411d5b)=>{const _0x2ecf87=k(_0x2dc21f,_0x67f0c7);lr(_0x23232a,y(_0x2ecf87))||(_0x4598be=ki(_0x4f190c,_0x4598be,_0x2ecf87,_0x411d5b,_0x2cb991,_0x57898f,_0x2851d3));}),_0x4598be;}function hr(_0x82e46e,_0x254d72,_0x598e69){return _0x598e69['foreach']((_0x5ed94f,_0x1e94af)=>{_0x254d72=_0x254d72['updateChild'](_0x5ed94f,_0x1e94af);}),_0x254d72;}function Pi(_0x534056,_0x2b1a8b,_0x17a5fa,_0x266482,_0xb4e6d2,_0x5104af,_0x2d0267,_0x427dda){if(_0x2b1a8b['serverCache']['getNode']()['isEmpty']()&&!_0x2b1a8b['serverCache']['isFullyInitialized']())return _0x2b1a8b;let _0xe41e37=_0x2b1a8b,_0x5ed08c;v(_0x17a5fa)?_0x5ed08c=_0x266482:_0x5ed08c=new b(null)['setTree'](_0x17a5fa,_0x266482);const _0xa80660=_0x2b1a8b['serverCache']['getNode']();return _0x5ed08c['children']['inorderTraversal']((_0x5f4e86,_0x1fb1ad)=>{if(_0xa80660['hasChild'](_0x5f4e86)){const _0x26afbf=_0x2b1a8b['serverCache']['getNode']()['getImmediateChild'](_0x5f4e86),_0x54ca97=hr(_0x534056,_0x26afbf,_0x1fb1ad);_0xe41e37=Sn(_0x534056,_0xe41e37,new C(_0x5f4e86),_0x54ca97,_0xb4e6d2,_0x5104af,_0x2d0267,_0x427dda);}}),_0x5ed08c['children']['inorderTraversal']((_0x157f8c,_0x4dee61)=>{const _0x1b3a7a=!_0x2b1a8b['serverCache']['isCompleteForChild'](_0x157f8c)&&_0x4dee61['value']===null;if(!_0xa80660['hasChild'](_0x157f8c)&&!_0x1b3a7a){const _0x1ee3df=_0x2b1a8b['serverCache']['getNode']()['getImmediateChild'](_0x157f8c),_0x18c301=hr(_0x534056,_0x1ee3df,_0x4dee61);_0xe41e37=Sn(_0x534056,_0xe41e37,new C(_0x157f8c),_0x18c301,_0xb4e6d2,_0x5104af,_0x2d0267,_0x427dda);}}),_0xe41e37;}function Pu(_0xe5223d,_0x1f1c3b,_0x5d541b,_0x37a35c,_0x31db41,_0x32d943,_0x2d1706){if(Tn(_0x31db41,_0x5d541b)!=null)return _0x1f1c3b;const _0x743849=_0x1f1c3b['serverCache']['isFiltered'](),_0xc7c1a7=_0x1f1c3b['serverCache'];if(_0x37a35c['value']!=null){if(v(_0x5d541b)&&_0xc7c1a7['isFullyInitialized']()||_0xc7c1a7['isCompleteForPath'](_0x5d541b))return Sn(_0xe5223d,_0x1f1c3b,_0x5d541b,_0xc7c1a7['getNode']()['getChild'](_0x5d541b),_0x31db41,_0x32d943,_0x743849,_0x2d1706);if(v(_0x5d541b)){let _0x3741d3=new b(null);return _0xc7c1a7['getNode']()['forEachChild'](ve,(_0x4931d7,_0x218015)=>{_0x3741d3=_0x3741d3['set'](new C(_0x4931d7),_0x218015);}),Pi(_0xe5223d,_0x1f1c3b,_0x5d541b,_0x3741d3,_0x31db41,_0x32d943,_0x743849,_0x2d1706);}else return _0x1f1c3b;}else{let _0x39bdb9=new b(null);return _0x37a35c['foreach']((_0x496fb5,_0x13bdac)=>{const _0x3ec77b=k(_0x5d541b,_0x496fb5);_0xc7c1a7['isCompleteForPath'](_0x3ec77b)&&(_0x39bdb9=_0x39bdb9['set'](_0x496fb5,_0xc7c1a7['getNode']()['getChild'](_0x3ec77b)));}),Pi(_0xe5223d,_0x1f1c3b,_0x5d541b,_0x39bdb9,_0x31db41,_0x32d943,_0x743849,_0x2d1706);}}function Nu(_0x2c418c,_0x55a2c2,_0x29d435,_0x295193,_0x4cdf46){const _0xf1101f=_0x55a2c2['serverCache'],_0x22b76b=Fo(_0x55a2c2,_0xf1101f['getNode'](),_0xf1101f['isFullyInitialized']()||v(_0x29d435),_0xf1101f['isFiltered']());return Go(_0x2c418c,_0x22b76b,_0x29d435,_0x295193,$o,_0x4cdf46);}function Ou(_0x3ea49d,_0xd9f76d,_0x361a81,_0x345438,_0x34923d,_0x279e19){let _0x36a584;if(Tn(_0x345438,_0x361a81)!=null)return _0xd9f76d;{const _0x2566cb=new rs(_0x345438,_0xd9f76d,_0x34923d),_0x2177bb=_0xd9f76d['eventCache']['getNode']();let _0x2e6ae1;if(v(_0x361a81)||y(_0x361a81)==='.priority'){let _0x3d0446;if(_0xd9f76d['serverCache']['isFullyInitialized']())_0x3d0446=Cn(_0x345438,Ve(_0xd9f76d));else{const _0x154e93=_0xd9f76d['serverCache']['getNode']();f(_0x154e93 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3d0446=is(_0x345438,_0x154e93);}_0x3d0446=_0x3d0446,_0x2e6ae1=_0x3ea49d['filter']['updateFullNode'](_0x2177bb,_0x3d0446,_0x279e19);}else{const _0x5ae9b4=y(_0x361a81);let _0x49e0c3=ss(_0x345438,_0x5ae9b4,_0xd9f76d['serverCache']);_0x49e0c3==null&&_0xd9f76d['serverCache']['isCompleteForChild'](_0x5ae9b4)&&(_0x49e0c3=_0x2177bb['getImmediateChild'](_0x5ae9b4)),_0x49e0c3!=null?_0x2e6ae1=_0x3ea49d['filter']['updateChild'](_0x2177bb,_0x5ae9b4,_0x49e0c3,S(_0x361a81),_0x2566cb,_0x279e19):_0xd9f76d['eventCache']['getNode']()['hasChild'](_0x5ae9b4)?_0x2e6ae1=_0x3ea49d['filter']['updateChild'](_0x2177bb,_0x5ae9b4,g['EMPTY_NODE'],S(_0x361a81),_0x2566cb,_0x279e19):_0x2e6ae1=_0x2177bb,_0x2e6ae1['isEmpty']()&&_0xd9f76d['serverCache']['isFullyInitialized']()&&(_0x36a584=Cn(_0x345438,Ve(_0xd9f76d)),_0x36a584['isLeafNode']()&&(_0x2e6ae1=_0x3ea49d['filter']['updateFullNode'](_0x2e6ae1,_0x36a584,_0x279e19)));}return _0x36a584=_0xd9f76d['serverCache']['isFullyInitialized']()||Tn(_0x345438,w())!=null,Rt(_0xd9f76d,_0x2e6ae1,_0x36a584,_0x3ea49d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4996d1,_0x291c33){this['query_']=_0x4996d1,this['eventRegistrations_']=[];const _0x5b5150=this['query_']['_queryParams'],_0x4b0291=new Xi(_0x5b5150['getIndex']()),_0x58fc77=Kh(_0x5b5150);this['processor_']=Su(_0x58fc77);const _0x153455=_0x291c33['serverCache'],_0x40974a=_0x291c33['eventCache'],_0x38eef0=_0x4b0291['updateFullNode'](g['EMPTY_NODE'],_0x153455['getNode'](),null),_0x457d85=_0x58fc77['updateFullNode'](g['EMPTY_NODE'],_0x40974a['getNode'](),null),_0x411fec=new Te(_0x38eef0,_0x153455['isFullyInitialized'](),_0x4b0291['filtersNodes']()),_0x15cfa0=new Te(_0x457d85,_0x40974a['isFullyInitialized'](),_0x58fc77['filtersNodes']());this['viewCache_']=Un(_0x15cfa0,_0x411fec),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xb9756){return _0xb9756['viewCache_']['serverCache']['getNode']();}function Lu(_0x4cc3de){return wn(_0x4cc3de['viewCache_']);}function xu(_0x41fe36,_0x5f51e7){const _0x53d4eb=Ve(_0x41fe36['viewCache_']);return _0x53d4eb&&(_0x41fe36['query']['_queryParams']['loadsAllData']()||!v(_0x5f51e7)&&!_0x53d4eb['getImmediateChild'](y(_0x5f51e7))['isEmpty']())?_0x53d4eb['getChild'](_0x5f51e7):null;}function ur(_0x5d3465){return _0x5d3465['eventRegistrations_']['length']===0x0;}function Fu(_0x4bdabe,_0x17f4b3){_0x4bdabe['eventRegistrations_']['push'](_0x17f4b3);}function dr(_0x18b2c8,_0x919ddf,_0x48260c){const _0x32b196=[];if(_0x48260c){f(_0x919ddf==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x59cd9a=_0x18b2c8['query']['_path'];_0x18b2c8['eventRegistrations_']['forEach'](_0x16ae51=>{const _0x4f9b32=_0x16ae51['createCancelEvent'](_0x48260c,_0x59cd9a);_0x4f9b32&&_0x32b196['push'](_0x4f9b32);});}if(_0x919ddf){let _0x19af95=[];for(let _0x2c8b21=0x0;_0x2c8b21<_0x18b2c8['eventRegistrations_']['length'];++_0x2c8b21){const _0x5a0b67=_0x18b2c8['eventRegistrations_'][_0x2c8b21];if(!_0x5a0b67['matches'](_0x919ddf))_0x19af95['push'](_0x5a0b67);else{if(_0x919ddf['hasAnyCallback']()){_0x19af95=_0x19af95['concat'](_0x18b2c8['eventRegistrations_']['slice'](_0x2c8b21+0x1));break;}}}_0x18b2c8['eventRegistrations_']=_0x19af95;}else _0x18b2c8['eventRegistrations_']=[];return _0x32b196;}function fr(_0x158b71,_0x34b456,_0x4f0008,_0x30e24c){_0x34b456['type']===z['MERGE']&&_0x34b456['source']['queryId']!==null&&(f(Ve(_0x158b71['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x158b71['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2bac1f=_0x158b71['viewCache_'],_0x3a8f56=Ru(_0x158b71['processor_'],_0x2bac1f,_0x34b456,_0x4f0008,_0x30e24c);return bu(_0x158b71['processor_'],_0x3a8f56['viewCache']),f(_0x3a8f56['viewCache']['serverCache']['isFullyInitialized']()||!_0x2bac1f['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x158b71['viewCache_']=_0x3a8f56['viewCache'],qo(_0x158b71,_0x3a8f56['changes'],_0x3a8f56['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x428027,_0x1065c8){const _0x2941de=_0x428027['viewCache_']['eventCache'],_0x3a5fa9=[];return _0x2941de['getNode']()['isLeafNode']()||_0x2941de['getNode']()['forEachChild'](R,(_0x1a3535,_0x5d25ba)=>{_0x3a5fa9['push'](rt(_0x1a3535,_0x5d25ba));}),_0x2941de['isFullyInitialized']()&&_0x3a5fa9['push'](Lo(_0x2941de['getNode']())),qo(_0x428027,_0x3a5fa9,_0x2941de['getNode'](),_0x1065c8);}function qo(_0x29bdf6,_0x2c0a5b,_0x4f178a,_0x22d0c1){const _0x56ab92=_0x22d0c1?[_0x22d0c1]:_0x29bdf6['eventRegistrations_'];return ru(_0x29bdf6['eventGenerator_'],_0x2c0a5b,_0x4f178a,_0x56ab92);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x369b2e){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x369b2e;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x2b5956){return _0x2b5956['views']['size']===0x0;}function os(_0x31a0be,_0x4ccb0e,_0x4c22e5,_0x3f4cf2){const _0x27ee68=_0x4ccb0e['source']['queryId'];if(_0x27ee68!==null){const _0x14b85=_0x31a0be['views']['get'](_0x27ee68);return f(_0x14b85!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x14b85,_0x4ccb0e,_0x4c22e5,_0x3f4cf2);}else{let _0x2a835e=[];for(const _0xbc31ba of _0x31a0be['views']['values']())_0x2a835e=_0x2a835e['concat'](fr(_0xbc31ba,_0x4ccb0e,_0x4c22e5,_0x3f4cf2));return _0x2a835e;}}function jo(_0x3cd61f,_0x2bfbc0,_0x24c391,_0x225b62,_0x32c723){const _0x208f61=_0x2bfbc0['_queryIdentifier'],_0x123d3a=_0x3cd61f['views']['get'](_0x208f61);if(!_0x123d3a){let _0x27227f=Cn(_0x24c391,_0x32c723?_0x225b62:null),_0x55104c=!0x1;_0x27227f?_0x55104c=!0x0:_0x225b62 instanceof g?(_0x27227f=is(_0x24c391,_0x225b62),_0x55104c=!0x1):(_0x27227f=g['EMPTY_NODE'],_0x55104c=!0x1);const _0x18b50f=Un(new Te(_0x27227f,_0x55104c,!0x1),new Te(_0x225b62,_0x32c723,!0x1));return new Du(_0x2bfbc0,_0x18b50f);}return _0x123d3a;}function Hu(_0x13615d,_0x594494,_0x32315d,_0x20b8f5,_0x1c05cb,_0x345c53){const _0x2caab3=jo(_0x13615d,_0x594494,_0x20b8f5,_0x1c05cb,_0x345c53);return _0x13615d['views']['has'](_0x594494['_queryIdentifier'])||_0x13615d['views']['set'](_0x594494['_queryIdentifier'],_0x2caab3),Fu(_0x2caab3,_0x32315d),Uu(_0x2caab3,_0x32315d);}function $u(_0x11d7b7,_0x2e9204,_0x41b1c6,_0x7004e8){const _0x193d71=_0x2e9204['_queryIdentifier'],_0x466282=[];let _0x572a16=[];const _0x52d6b6=Se(_0x11d7b7);if(_0x193d71==='default'){for(const [_0x3e4cee,_0x5cb36d]of _0x11d7b7['views']['entries']())_0x572a16=_0x572a16['concat'](dr(_0x5cb36d,_0x41b1c6,_0x7004e8)),ur(_0x5cb36d)&&(_0x11d7b7['views']['delete'](_0x3e4cee),_0x5cb36d['query']['_queryParams']['loadsAllData']()||_0x466282['push'](_0x5cb36d['query']));}else{const _0x3720ee=_0x11d7b7['views']['get'](_0x193d71);_0x3720ee&&(_0x572a16=_0x572a16['concat'](dr(_0x3720ee,_0x41b1c6,_0x7004e8)),ur(_0x3720ee)&&(_0x11d7b7['views']['delete'](_0x193d71),_0x3720ee['query']['_queryParams']['loadsAllData']()||_0x466282['push'](_0x3720ee['query'])));}return _0x52d6b6&&!Se(_0x11d7b7)&&_0x466282['push'](new(Bu())(_0x2e9204['_repo'],_0x2e9204['_path'])),{'removed':_0x466282,'events':_0x572a16};}function Ko(_0x3d410e){const _0x2727d7=[];for(const _0x27fc02 of _0x3d410e['views']['values']())_0x27fc02['query']['_queryParams']['loadsAllData']()||_0x2727d7['push'](_0x27fc02);return _0x2727d7;}function Ie(_0x472421,_0x3ded67){let _0x133beb=null;for(const _0x63d831 of _0x472421['views']['values']())_0x133beb=_0x133beb||xu(_0x63d831,_0x3ded67);return _0x133beb;}function Yo(_0xabcbc,_0x26008c){if(_0x26008c['_queryParams']['loadsAllData']())return Bn(_0xabcbc);{const _0x1911c1=_0x26008c['_queryIdentifier'];return _0xabcbc['views']['get'](_0x1911c1);}}function Qo(_0x2e53b4,_0x392c1d){return Yo(_0x2e53b4,_0x392c1d)!=null;}function Se(_0x374a88){return Bn(_0x374a88)!=null;}function Bn(_0x2de1d4){for(const _0x3edb19 of _0x2de1d4['views']['values']())if(_0x3edb19['query']['_queryParams']['loadsAllData']())return _0x3edb19;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x16f4b4){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x16f4b4;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x4d0f2a){this['listenProvider_']=_0x4d0f2a,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x36feba,_0xf21e30,_0x414c85,_0x472ef7,_0x13bb16){return lu(_0x36feba['pendingWriteTree_'],_0xf21e30,_0x414c85,_0x472ef7,_0x13bb16),_0x13bb16?_t(_0x36feba,new Be(es(),_0xf21e30,_0x414c85)):[];}function ju(_0x359c16,_0x2ffc02,_0x5c8afe,_0x4ecc96){hu(_0x359c16['pendingWriteTree_'],_0x2ffc02,_0x5c8afe,_0x4ecc96);const _0x3eac1c=b['fromObject'](_0x5c8afe);return _t(_0x359c16,new ot(es(),_0x2ffc02,_0x3eac1c));}function _e(_0x4a9b8e,_0x53b052,_0x4e4279=!0x1){const _0xc0d11a=uu(_0x4a9b8e['pendingWriteTree_'],_0x53b052);if(du(_0x4a9b8e['pendingWriteTree_'],_0x53b052)){let _0x53b755=new b(null);return _0xc0d11a['snap']!=null?_0x53b755=_0x53b755['set'](w(),!0x0):x(_0xc0d11a['children'],_0x170e15=>{_0x53b755=_0x53b755['set'](new C(_0x170e15),!0x0);}),_t(_0x4a9b8e,new In(_0xc0d11a['path'],_0x53b755,_0x4e4279));}else return[];}function Yt(_0x1d148e,_0x2b6f11,_0x2ebf19){return _t(_0x1d148e,new Be(ts(),_0x2b6f11,_0x2ebf19));}function Ku(_0x4b7634,_0x50ea4f,_0x304c86){const _0x386aff=b['fromObject'](_0x304c86);return _t(_0x4b7634,new ot(ts(),_0x50ea4f,_0x386aff));}function Yu(_0x4ff6b9,_0x23fc4c){return _t(_0x4ff6b9,new Ut(ts(),_0x23fc4c));}function Qu(_0x556c6d,_0x27e0c1,_0x10bf1d){const _0x2340b5=cs(_0x556c6d,_0x10bf1d);if(_0x2340b5){const _0x44c80c=ls(_0x2340b5),_0x1cde01=_0x44c80c['path'],_0x1a8ae2=_0x44c80c['queryId'],_0x6a0093=F(_0x1cde01,_0x27e0c1),_0x11b00d=new Ut(ns(_0x1a8ae2),_0x6a0093);return hs(_0x556c6d,_0x1cde01,_0x11b00d);}else return[];}function An(_0x4c0239,_0x5a0dc2,_0x2a153c,_0x536740,_0x4e0a98=!0x1){const _0x5cdbb8=_0x5a0dc2['_path'],_0x41ca08=_0x4c0239['syncPointTree_']['get'](_0x5cdbb8);let _0xfdc11b=[];if(_0x41ca08&&(_0x5a0dc2['_queryIdentifier']==='default'||Qo(_0x41ca08,_0x5a0dc2))){const _0x3c560b=$u(_0x41ca08,_0x5a0dc2,_0x2a153c,_0x536740);Vu(_0x41ca08)&&(_0x4c0239['syncPointTree_']=_0x4c0239['syncPointTree_']['remove'](_0x5cdbb8));const _0x8a0da6=_0x3c560b['removed'];if(_0xfdc11b=_0x3c560b['events'],!_0x4e0a98){const _0x5d0c90=_0x8a0da6['findIndex'](_0x421d2e=>_0x421d2e['_queryParams']['loadsAllData']())!==-0x1,_0x2c624a=_0x4c0239['syncPointTree_']['findOnPath'](_0x5cdbb8,(_0x38bf06,_0x156f9c)=>Se(_0x156f9c));if(_0x5d0c90&&!_0x2c624a){const _0x225dfd=_0x4c0239['syncPointTree_']['subtree'](_0x5cdbb8);if(!_0x225dfd['isEmpty']()){const _0x491405=Zu(_0x225dfd);for(let _0xe5fe4=0x0;_0xe5fe4<_0x491405['length'];++_0xe5fe4){const _0x2b7536=_0x491405[_0xe5fe4],_0x29ad72=_0x2b7536['query'],_0xd01a9d=ea(_0x4c0239,_0x2b7536);_0x4c0239['listenProvider_']['startListening'](kt(_0x29ad72),Wt(_0x4c0239,_0x29ad72),_0xd01a9d['hashFn'],_0xd01a9d['onComplete']);}}}!_0x2c624a&&_0x8a0da6['length']>0x0&&!_0x536740&&(_0x5d0c90?_0x4c0239['listenProvider_']['stopListening'](kt(_0x5a0dc2),null):_0x8a0da6['forEach'](_0x159178=>{const _0x2c39eb=_0x4c0239['queryToTagMap']['get'](Hn(_0x159178));_0x4c0239['listenProvider_']['stopListening'](kt(_0x159178),_0x2c39eb);}));}ed(_0x4c0239,_0x8a0da6);}return _0xfdc11b;}function Jo(_0x438a80,_0x341f2d,_0x1aa2ef,_0x292c47){const _0x3b3f18=cs(_0x438a80,_0x292c47);if(_0x3b3f18!=null){const _0x107be3=ls(_0x3b3f18),_0x2ecaef=_0x107be3['path'],_0x33f557=_0x107be3['queryId'],_0x1d5314=F(_0x2ecaef,_0x341f2d),_0x5bd522=new Be(ns(_0x33f557),_0x1d5314,_0x1aa2ef);return hs(_0x438a80,_0x2ecaef,_0x5bd522);}else return[];}function Ju(_0x1d5269,_0x4d1549,_0x362734,_0x5132f6){const _0x3994cf=cs(_0x1d5269,_0x5132f6);if(_0x3994cf){const _0x593e61=ls(_0x3994cf),_0x579e74=_0x593e61['path'],_0x1d335b=_0x593e61['queryId'],_0x287103=F(_0x579e74,_0x4d1549),_0x4907aa=b['fromObject'](_0x362734),_0x45ae4b=new ot(ns(_0x1d335b),_0x287103,_0x4907aa);return hs(_0x1d5269,_0x579e74,_0x45ae4b);}else return[];}function Ni(_0xc6437a,_0x4fad17,_0xeda3a9,_0x3bccf4=!0x1){const _0x1a434f=_0x4fad17['_path'];let _0x3b3332=null,_0x5a7620=!0x1;_0xc6437a['syncPointTree_']['foreachOnPath'](_0x1a434f,(_0x80eb63,_0xa2707b)=>{const _0x2a64a5=F(_0x80eb63,_0x1a434f);_0x3b3332=_0x3b3332||Ie(_0xa2707b,_0x2a64a5),_0x5a7620=_0x5a7620||Se(_0xa2707b);});let _0x4fb51a=_0xc6437a['syncPointTree_']['get'](_0x1a434f);_0x4fb51a?(_0x5a7620=_0x5a7620||Se(_0x4fb51a),_0x3b3332=_0x3b3332||Ie(_0x4fb51a,w())):(_0x4fb51a=new zo(),_0xc6437a['syncPointTree_']=_0xc6437a['syncPointTree_']['set'](_0x1a434f,_0x4fb51a));let _0x3889c9;_0x3b3332!=null?_0x3889c9=!0x0:(_0x3889c9=!0x1,_0x3b3332=g['EMPTY_NODE'],_0xc6437a['syncPointTree_']['subtree'](_0x1a434f)['foreachChild']((_0x1c2981,_0x5ad81b)=>{const _0x42591d=Ie(_0x5ad81b,w());_0x42591d&&(_0x3b3332=_0x3b3332['updateImmediateChild'](_0x1c2981,_0x42591d));}));const _0x4db6a5=Qo(_0x4fb51a,_0x4fad17);if(!_0x4db6a5&&!_0x4fad17['_queryParams']['loadsAllData']()){const _0x1f14eb=Hn(_0x4fad17);f(!_0xc6437a['queryToTagMap']['has'](_0x1f14eb),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x47308c=td();_0xc6437a['queryToTagMap']['set'](_0x1f14eb,_0x47308c),_0xc6437a['tagToQueryMap']['set'](_0x47308c,_0x1f14eb);}const _0x274edd=Wn(_0xc6437a['pendingWriteTree_'],_0x1a434f);let _0xbc2e96=Hu(_0x4fb51a,_0x4fad17,_0xeda3a9,_0x274edd,_0x3b3332,_0x3889c9);if(!_0x4db6a5&&!_0x5a7620&&!_0x3bccf4){const _0x15b4b8=Yo(_0x4fb51a,_0x4fad17);_0xbc2e96=_0xbc2e96['concat'](nd(_0xc6437a,_0x4fad17,_0x15b4b8));}return _0xbc2e96;}function Vn(_0x4de199,_0x2cab9c,_0x8e8c5d){const _0x1334be=_0x4de199['pendingWriteTree_'],_0x46fce1=_0x4de199['syncPointTree_']['findOnPath'](_0x2cab9c,(_0x4fd270,_0x365341)=>{const _0x5a0cf3=F(_0x4fd270,_0x2cab9c),_0x5cc5dc=Ie(_0x365341,_0x5a0cf3);if(_0x5cc5dc)return _0x5cc5dc;});return Bo(_0x1334be,_0x2cab9c,_0x46fce1,_0x8e8c5d,!0x0);}function Xu(_0x2d4029,_0x11f606){const _0x27d76c=_0x11f606['_path'];let _0x4f6052=null;_0x2d4029['syncPointTree_']['foreachOnPath'](_0x27d76c,(_0x196e83,_0x3798c7)=>{const _0x2d720e=F(_0x196e83,_0x27d76c);_0x4f6052=_0x4f6052||Ie(_0x3798c7,_0x2d720e);});let _0x245be0=_0x2d4029['syncPointTree_']['get'](_0x27d76c);_0x245be0?_0x4f6052=_0x4f6052||Ie(_0x245be0,w()):(_0x245be0=new zo(),_0x2d4029['syncPointTree_']=_0x2d4029['syncPointTree_']['set'](_0x27d76c,_0x245be0));const _0x358783=_0x4f6052!=null,_0x2ec3e1=_0x358783?new Te(_0x4f6052,!0x0,!0x1):null,_0x5f1070=Wn(_0x2d4029['pendingWriteTree_'],_0x11f606['_path']),_0x2b2742=jo(_0x245be0,_0x11f606,_0x5f1070,_0x358783?_0x2ec3e1['getNode']():g['EMPTY_NODE'],_0x358783);return Lu(_0x2b2742);}function _t(_0x1d6365,_0x324bda){return Xo(_0x324bda,_0x1d6365['syncPointTree_'],null,Wn(_0x1d6365['pendingWriteTree_'],w()));}function Xo(_0x1c8188,_0x315a60,_0x2d0242,_0x472512){if(v(_0x1c8188['path']))return Zo(_0x1c8188,_0x315a60,_0x2d0242,_0x472512);{const _0x257e0c=_0x315a60['get'](w());_0x2d0242==null&&_0x257e0c!=null&&(_0x2d0242=Ie(_0x257e0c,w()));let _0x5da10a=[];const _0x566868=y(_0x1c8188['path']),_0x19976c=_0x1c8188['operationForChild'](_0x566868),_0x478d18=_0x315a60['children']['get'](_0x566868);if(_0x478d18&&_0x19976c){const _0x9e0fcb=_0x2d0242?_0x2d0242['getImmediateChild'](_0x566868):null,_0x3d7d0b=Vo(_0x472512,_0x566868);_0x5da10a=_0x5da10a['concat'](Xo(_0x19976c,_0x478d18,_0x9e0fcb,_0x3d7d0b));}return _0x257e0c&&(_0x5da10a=_0x5da10a['concat'](os(_0x257e0c,_0x1c8188,_0x472512,_0x2d0242))),_0x5da10a;}}function Zo(_0x586349,_0x479484,_0x131440,_0x232f2a){const _0x225c8a=_0x479484['get'](w());_0x131440==null&&_0x225c8a!=null&&(_0x131440=Ie(_0x225c8a,w()));let _0x5f2be4=[];return _0x479484['children']['inorderTraversal']((_0xcf97ee,_0x252780)=>{const _0x44586b=_0x131440?_0x131440['getImmediateChild'](_0xcf97ee):null,_0x4c4b57=Vo(_0x232f2a,_0xcf97ee),_0x2e858e=_0x586349['operationForChild'](_0xcf97ee);_0x2e858e&&(_0x5f2be4=_0x5f2be4['concat'](Zo(_0x2e858e,_0x252780,_0x44586b,_0x4c4b57)));}),_0x225c8a&&(_0x5f2be4=_0x5f2be4['concat'](os(_0x225c8a,_0x586349,_0x232f2a,_0x131440))),_0x5f2be4;}function ea(_0x5b1f0a,_0x571d26){const _0x30ceec=_0x571d26['query'],_0x4e2b89=Wt(_0x5b1f0a,_0x30ceec);return{'hashFn':()=>(Mu(_0x571d26)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x933c57=>{if(_0x933c57==='ok')return _0x4e2b89?Qu(_0x5b1f0a,_0x30ceec['_path'],_0x4e2b89):Yu(_0x5b1f0a,_0x30ceec['_path']);{const _0x44b1c2=Kl(_0x933c57,_0x30ceec);return An(_0x5b1f0a,_0x30ceec,null,_0x44b1c2);}}};}function Wt(_0x2ef678,_0x4303c2){const _0x49d762=Hn(_0x4303c2);return _0x2ef678['queryToTagMap']['get'](_0x49d762);}function Hn(_0x27ce92){return _0x27ce92['_path']['toString']()+'$'+_0x27ce92['_queryIdentifier'];}function cs(_0x2cef67,_0x3dec35){return _0x2cef67['tagToQueryMap']['get'](_0x3dec35);}function ls(_0x2f6687){const _0x407b20=_0x2f6687['indexOf']('$');return f(_0x407b20!==-0x1&&_0x407b20<_0x2f6687['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2f6687['substr'](_0x407b20+0x1),'path':new C(_0x2f6687['substr'](0x0,_0x407b20))};}function hs(_0x155ea7,_0x3baabf,_0x2d365a){const _0x2f4ece=_0x155ea7['syncPointTree_']['get'](_0x3baabf);f(_0x2f4ece,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x2f3c30=Wn(_0x155ea7['pendingWriteTree_'],_0x3baabf);return os(_0x2f4ece,_0x2d365a,_0x2f3c30,null);}function Zu(_0x54282e){return _0x54282e['fold']((_0x12275f,_0x405cd6,_0x178544)=>{if(_0x405cd6&&Se(_0x405cd6))return[Bn(_0x405cd6)];{let _0x54e490=[];return _0x405cd6&&(_0x54e490=Ko(_0x405cd6)),x(_0x178544,(_0x16b5ed,_0x3a027b)=>{_0x54e490=_0x54e490['concat'](_0x3a027b);}),_0x54e490;}});}function kt(_0x5c770e){return _0x5c770e['_queryParams']['loadsAllData']()&&!_0x5c770e['_queryParams']['isDefault']()?new(qu())(_0x5c770e['_repo'],_0x5c770e['_path']):_0x5c770e;}function ed(_0x422ea9,_0x1f2340){for(let _0x33a8be=0x0;_0x33a8be<_0x1f2340['length'];++_0x33a8be){const _0x5919f5=_0x1f2340[_0x33a8be];if(!_0x5919f5['_queryParams']['loadsAllData']()){const _0x3798e5=Hn(_0x5919f5),_0x329bc0=_0x422ea9['queryToTagMap']['get'](_0x3798e5);_0x422ea9['queryToTagMap']['delete'](_0x3798e5),_0x422ea9['tagToQueryMap']['delete'](_0x329bc0);}}}function td(){return zu++;}function nd(_0x3e529d,_0x3076b2,_0x1c4039){const _0x12836e=_0x3076b2['_path'],_0x2a4d0d=Wt(_0x3e529d,_0x3076b2),_0x1b0e02=ea(_0x3e529d,_0x1c4039),_0x3581f9=_0x3e529d['listenProvider_']['startListening'](kt(_0x3076b2),_0x2a4d0d,_0x1b0e02['hashFn'],_0x1b0e02['onComplete']),_0x2f771a=_0x3e529d['syncPointTree_']['subtree'](_0x12836e);if(_0x2a4d0d)f(!Se(_0x2f771a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x549c73=_0x2f771a['fold']((_0x13ebf0,_0x21d4d5,_0x142a20)=>{if(!v(_0x13ebf0)&&_0x21d4d5&&Se(_0x21d4d5))return[Bn(_0x21d4d5)['query']];{let _0x1e8a4a=[];return _0x21d4d5&&(_0x1e8a4a=_0x1e8a4a['concat'](Ko(_0x21d4d5)['map'](_0x5d2677=>_0x5d2677['query']))),x(_0x142a20,(_0x273f45,_0x500ae1)=>{_0x1e8a4a=_0x1e8a4a['concat'](_0x500ae1);}),_0x1e8a4a;}});for(let _0x29099b=0x0;_0x29099b<_0x549c73['length'];++_0x29099b){const _0x4b4ff7=_0x549c73[_0x29099b];_0x3e529d['listenProvider_']['stopListening'](kt(_0x4b4ff7),Wt(_0x3e529d,_0x4b4ff7));}}return _0x3581f9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x58aa50){this['node_']=_0x58aa50;}['getImmediateChild'](_0x413040){const _0x3f37a2=this['node_']['getImmediateChild'](_0x413040);return new us(_0x3f37a2);}['node'](){return this['node_'];}}class ds{constructor(_0x54bd65,_0x3d6be5){this['syncTree_']=_0x54bd65,this['path_']=_0x3d6be5;}['getImmediateChild'](_0x4d89c2){const _0x1591c9=k(this['path_'],_0x4d89c2);return new ds(this['syncTree_'],_0x1591c9);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x192bb9){return _0x192bb9=_0x192bb9||{},_0x192bb9['timestamp']=_0x192bb9['timestamp']||new Date()['getTime'](),_0x192bb9;},_r=function(_0x208f59,_0x594cc0,_0x590c67){if(!_0x208f59||typeof _0x208f59!='object')return _0x208f59;if(f('.sv'in _0x208f59,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x208f59['.sv']=='string')return sd(_0x208f59['.sv'],_0x594cc0,_0x590c67);if(typeof _0x208f59['.sv']=='object')return rd(_0x208f59['.sv'],_0x594cc0);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x208f59,null,0x2));},sd=function(_0x636d03,_0x3ff6e3,_0x16089d){switch(_0x636d03){case'timestamp':return _0x16089d['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x636d03);}},rd=function(_0x50dfb9,_0xfbe72c,_0x526e7c){_0x50dfb9['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x50dfb9,null,0x2));const _0x2ef272=_0x50dfb9['increment'];typeof _0x2ef272!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2ef272);const _0x1ee7ad=_0xfbe72c['node']();if(f(_0x1ee7ad!==null&&typeof _0x1ee7ad<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1ee7ad['isLeafNode']())return _0x2ef272;const _0x3b1031=_0x1ee7ad['getValue']();return typeof _0x3b1031!='number'?_0x2ef272:_0x3b1031+_0x2ef272;},ta=function(_0x4065cb,_0x16ed2c,_0x194f7a,_0x32ff42){return ps(_0x16ed2c,new ds(_0x194f7a,_0x4065cb),_0x32ff42);},fs=function(_0x24c0e8,_0x298ad7,_0x29b739){return ps(_0x24c0e8,new us(_0x298ad7),_0x29b739);};function ps(_0x1de53e,_0x7c696a,_0x2d3d65){const _0x3db31e=_0x1de53e['getPriority']()['val'](),_0xe0304f=_r(_0x3db31e,_0x7c696a['getImmediateChild']('.priority'),_0x2d3d65);let _0x28ad27;if(_0x1de53e['isLeafNode']()){const _0x380bdb=_0x1de53e,_0x115156=_r(_0x380bdb['getValue'](),_0x7c696a,_0x2d3d65);return _0x115156!==_0x380bdb['getValue']()||_0xe0304f!==_0x380bdb['getPriority']()['val']()?new D(_0x115156,A(_0xe0304f)):_0x1de53e;}else{const _0x132281=_0x1de53e;return _0x28ad27=_0x132281,_0xe0304f!==_0x132281['getPriority']()['val']()&&(_0x28ad27=_0x28ad27['updatePriority'](new D(_0xe0304f))),_0x132281['forEachChild'](R,(_0x567ad8,_0x5192e3)=>{const _0x59d5f3=ps(_0x5192e3,_0x7c696a['getImmediateChild'](_0x567ad8),_0x2d3d65);_0x59d5f3!==_0x5192e3&&(_0x28ad27=_0x28ad27['updateImmediateChild'](_0x567ad8,_0x59d5f3));}),_0x28ad27;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x573bea='',_0x109ca2=null,_0x335c26={'children':{},'childCount':0x0}){this['name']=_0x573bea,this['parent']=_0x109ca2,this['node']=_0x335c26;}}function $n(_0x11731c,_0x6417be){let _0x211762=_0x6417be instanceof C?_0x6417be:new C(_0x6417be),_0x50a9c1=_0x11731c,_0x25f256=y(_0x211762);for(;_0x25f256!==null;){const _0x31c5f6=Le(_0x50a9c1['node']['children'],_0x25f256)||{'children':{},'childCount':0x0};_0x50a9c1=new _s(_0x25f256,_0x50a9c1,_0x31c5f6),_0x211762=S(_0x211762),_0x25f256=y(_0x211762);}return _0x50a9c1;}function je(_0x4d95e5){return _0x4d95e5['node']['value'];}function gs(_0x298a5a,_0x3fc622){_0x298a5a['node']['value']=_0x3fc622,Oi(_0x298a5a);}function na(_0x22ab34){return _0x22ab34['node']['childCount']>0x0;}function od(_0x17c6f8){return je(_0x17c6f8)===void 0x0&&!na(_0x17c6f8);}function Gn(_0x1ee1ae,_0x286a73){x(_0x1ee1ae['node']['children'],(_0x1f2697,_0x12744b)=>{_0x286a73(new _s(_0x1f2697,_0x1ee1ae,_0x12744b));});}function ia(_0x12dd76,_0x2c2d8c,_0x16a30c,_0x4ff282){_0x16a30c&&_0x2c2d8c(_0x12dd76),Gn(_0x12dd76,_0xa5d1f2=>{ia(_0xa5d1f2,_0x2c2d8c,!0x0);});}function ad(_0x3f3703,_0x571a49,_0x50e6a9){let _0x41da57=_0x3f3703['parent'];for(;_0x41da57!==null;){if(_0x571a49(_0x41da57))return!0x0;_0x41da57=_0x41da57['parent'];}return!0x1;}function Qt(_0x2492bf){return new C(_0x2492bf['parent']===null?_0x2492bf['name']:Qt(_0x2492bf['parent'])+'/'+_0x2492bf['name']);}function Oi(_0x3e4a98){_0x3e4a98['parent']!==null&&cd(_0x3e4a98['parent'],_0x3e4a98['name'],_0x3e4a98);}function cd(_0xce10b7,_0x281256,_0x2ba56e){const _0x7bdf3=od(_0x2ba56e),_0x11cdbc=Q(_0xce10b7['node']['children'],_0x281256);_0x7bdf3&&_0x11cdbc?(delete _0xce10b7['node']['children'][_0x281256],_0xce10b7['node']['childCount']--,Oi(_0xce10b7)):!_0x7bdf3&&!_0x11cdbc&&(_0xce10b7['node']['children'][_0x281256]=_0x2ba56e['node'],_0xce10b7['node']['childCount']++,Oi(_0xce10b7));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x278572){return typeof _0x278572=='string'&&_0x278572['length']!==0x0&&!ld['test'](_0x278572);},sa=function(_0xb9282e){return typeof _0xb9282e=='string'&&_0xb9282e['length']!==0x0&&!hd['test'](_0xb9282e);},ud=function(_0x240e58){return _0x240e58&&(_0x240e58=_0x240e58['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x240e58);},Bt=function(_0x265038){return _0x265038===null||typeof _0x265038=='string'||typeof _0x265038=='number'&&!xn(_0x265038)||_0x265038&&typeof _0x265038=='object'&&Q(_0x265038,'.sv');},He=function(_0x291095,_0x3adaf2,_0x1f8c0b,_0x8f97c1){_0x8f97c1&&_0x3adaf2===void 0x0||Jt(it(_0x291095,'value'),_0x3adaf2,_0x1f8c0b);},Jt=function(_0x2abf5b,_0x32a3f0,_0x3d0416){const _0x2e40c8=_0x3d0416 instanceof C?new Ah(_0x3d0416,_0x2abf5b):_0x3d0416;if(_0x32a3f0===void 0x0)throw new Error(_0x2abf5b+'contains\x20undefined\x20'+Oe(_0x2e40c8));if(typeof _0x32a3f0=='function')throw new Error(_0x2abf5b+'contains\x20a\x20function\x20'+Oe(_0x2e40c8)+'\x20with\x20contents\x20=\x20'+_0x32a3f0['toString']());if(xn(_0x32a3f0))throw new Error(_0x2abf5b+'contains\x20'+_0x32a3f0['toString']()+'\x20'+Oe(_0x2e40c8));if(typeof _0x32a3f0=='string'&&_0x32a3f0['length']>ui/0x3&&Ln(_0x32a3f0)>ui)throw new Error(_0x2abf5b+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2e40c8)+'\x20(\x27'+_0x32a3f0['substring'](0x0,0x32)+'...\x27)');if(_0x32a3f0&&typeof _0x32a3f0=='object'){let _0x20c0d9=!0x1,_0x20c072=!0x1;if(x(_0x32a3f0,(_0x3b4ede,_0x35d412)=>{if(_0x3b4ede==='.value')_0x20c0d9=!0x0;else{if(_0x3b4ede!=='.priority'&&_0x3b4ede!=='.sv'&&(_0x20c072=!0x0,!ms(_0x3b4ede)))throw new Error(_0x2abf5b+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3b4ede+')\x20'+Oe(_0x2e40c8)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2e40c8,_0x3b4ede),Jt(_0x2abf5b,_0x35d412,_0x2e40c8),Ph(_0x2e40c8);}),_0x20c0d9&&_0x20c072)throw new Error(_0x2abf5b+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2e40c8)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2b3f1f,_0x30a6e9){let _0xae5920,_0x59ad13;for(_0xae5920=0x0;_0xae5920<_0x30a6e9['length'];_0xae5920++){_0x59ad13=_0x30a6e9[_0xae5920];const _0x51a7f3=Mt(_0x59ad13);for(let _0x5a2840=0x0;_0x5a2840<_0x51a7f3['length'];_0x5a2840++)if(!(_0x51a7f3[_0x5a2840]==='.priority'&&_0x5a2840===_0x51a7f3['length']-0x1)){if(!ms(_0x51a7f3[_0x5a2840]))throw new Error(_0x2b3f1f+'contains\x20an\x20invalid\x20key\x20('+_0x51a7f3[_0x5a2840]+')\x20in\x20path\x20'+_0x59ad13['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x30a6e9['sort'](Rh);let _0x3f136f=null;for(_0xae5920=0x0;_0xae5920<_0x30a6e9['length'];_0xae5920++){if(_0x59ad13=_0x30a6e9[_0xae5920],_0x3f136f!==null&&G(_0x3f136f,_0x59ad13))throw new Error(_0x2b3f1f+'contains\x20a\x20path\x20'+_0x3f136f['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x59ad13['toString']());_0x3f136f=_0x59ad13;}},ra=function(_0x83dfb1,_0x1c3622,_0x4daa0f,_0x340852){const _0x479c98=it(_0x83dfb1,'values');if(!(_0x1c3622&&typeof _0x1c3622=='object')||Array['isArray'](_0x1c3622))throw new Error(_0x479c98+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x9a046=[];x(_0x1c3622,(_0x1e2499,_0x4170d1)=>{const _0x3fb2e0=new C(_0x1e2499);if(Jt(_0x479c98,_0x4170d1,k(_0x4daa0f,_0x3fb2e0)),ji(_0x3fb2e0)==='.priority'&&!Bt(_0x4170d1))throw new Error(_0x479c98+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3fb2e0['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x9a046['push'](_0x3fb2e0);}),dd(_0x479c98,_0x9a046);},fd=function(_0x1afa55,_0x255455,_0x4d6763){if(xn(_0x255455))throw new Error(it(_0x1afa55,'priority')+'is\x20'+_0x255455['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x255455))throw new Error(it(_0x1afa55,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x2f03ff,_0x10bb96,_0x2863e9,_0x29486a){if(!sa(_0x2863e9))throw new Error(it(_0x2f03ff,_0x10bb96)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2863e9+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1204ee,_0x5dead2,_0x4af1bb,_0x3dc587){_0x4af1bb&&(_0x4af1bb=_0x4af1bb['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1204ee,_0x5dead2,_0x4af1bb);},Me=function(_0x1593e1,_0x4687bc){if(y(_0x4687bc)==='.info')throw new Error(_0x1593e1+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x4bba67,_0x38c39b){const _0xd9568a=_0x38c39b['path']['toString']();if(typeof _0x38c39b['repoInfo']['host']!='string'||_0x38c39b['repoInfo']['host']['length']===0x0||!ms(_0x38c39b['repoInfo']['namespace'])&&_0x38c39b['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xd9568a['length']!==0x0&&!ud(_0xd9568a))throw new Error(it(_0x4bba67,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x4c0010,_0x59eb6f){let _0x4d56e5=null;for(let _0x38886f=0x0;_0x38886f<_0x59eb6f['length'];_0x38886f++){const _0x57ede7=_0x59eb6f[_0x38886f],_0x498116=_0x57ede7['getPath']();_0x4d56e5!==null&&!Ki(_0x498116,_0x4d56e5['path'])&&(_0x4c0010['eventLists_']['push'](_0x4d56e5),_0x4d56e5=null),_0x4d56e5===null&&(_0x4d56e5={'events':[],'path':_0x498116}),_0x4d56e5['events']['push'](_0x57ede7);}_0x4d56e5&&_0x4c0010['eventLists_']['push'](_0x4d56e5);}function oa(_0x36bd59,_0x35fb63,_0x403d6f){qn(_0x36bd59,_0x403d6f),aa(_0x36bd59,_0xa2f3d2=>Ki(_0xa2f3d2,_0x35fb63));}function V(_0x3e3a85,_0x4f7061,_0x3d32e4){qn(_0x3e3a85,_0x3d32e4),aa(_0x3e3a85,_0x359db6=>G(_0x359db6,_0x4f7061)||G(_0x4f7061,_0x359db6));}function aa(_0x357a80,_0x38a386){_0x357a80['recursionDepth_']++;let _0x48294e=!0x0;for(let _0x4716c4=0x0;_0x4716c4<_0x357a80['eventLists_']['length'];_0x4716c4++){const _0x51dcd8=_0x357a80['eventLists_'][_0x4716c4];if(_0x51dcd8){const _0x47bf9d=_0x51dcd8['path'];_0x38a386(_0x47bf9d)?(md(_0x357a80['eventLists_'][_0x4716c4]),_0x357a80['eventLists_'][_0x4716c4]=null):_0x48294e=!0x1;}}_0x48294e&&(_0x357a80['eventLists_']=[]),_0x357a80['recursionDepth_']--;}function md(_0x1b89c1){for(let _0x261381=0x0;_0x261381<_0x1b89c1['events']['length'];_0x261381++){const _0x136347=_0x1b89c1['events'][_0x261381];if(_0x136347!==null){_0x1b89c1['events'][_0x261381]=null;const _0x4988db=_0x136347['getEventRunner']();St&&L('event:\x20'+_0x136347['toString']()),ft(_0x4988db);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x2173bc,_0x525ed7,_0x55c55b,_0x54f125){this['repoInfo_']=_0x2173bc,this['forceRestClient_']=_0x525ed7,this['authTokenProvider_']=_0x55c55b,this['appCheckProvider_']=_0x54f125,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1b453a,_0x39cea1,_0x42d97f){if(_0x1b453a['stats_']=qi(_0x1b453a['repoInfo_']),_0x1b453a['forceRestClient_']||Xl())_0x1b453a['server_']=new vn(_0x1b453a['repoInfo_'],(_0x46b6d8,_0x1d1447,_0x53e2c0,_0x5a61ab)=>{gr(_0x1b453a,_0x46b6d8,_0x1d1447,_0x53e2c0,_0x5a61ab);},_0x1b453a['authTokenProvider_'],_0x1b453a['appCheckProvider_']),setTimeout(()=>mr(_0x1b453a,!0x0),0x0);else{if(typeof _0x42d97f<'u'&&_0x42d97f!==null){if(typeof _0x42d97f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x42d97f);}catch(_0x443836){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x443836);}}_0x1b453a['persistentConnection_']=new se(_0x1b453a['repoInfo_'],_0x39cea1,(_0x5e213f,_0x2027bb,_0x295e2c,_0x54c51d)=>{gr(_0x1b453a,_0x5e213f,_0x2027bb,_0x295e2c,_0x54c51d);},_0x455c6d=>{mr(_0x1b453a,_0x455c6d);},_0x834a17=>{Id(_0x1b453a,_0x834a17);},_0x1b453a['authTokenProvider_'],_0x1b453a['appCheckProvider_'],_0x42d97f),_0x1b453a['server_']=_0x1b453a['persistentConnection_'];}_0x1b453a['authTokenProvider_']['addTokenChangeListener'](_0x30df83=>{_0x1b453a['server_']['refreshAuthToken'](_0x30df83);}),_0x1b453a['appCheckProvider_']['addTokenChangeListener'](_0x4cd620=>{_0x1b453a['server_']['refreshAppCheckToken'](_0x4cd620['token']);}),_0x1b453a['statsReporter_']=ih(_0x1b453a['repoInfo_'],()=>new iu(_0x1b453a['stats_'],_0x1b453a['server_'])),_0x1b453a['infoData_']=new Xh(),_0x1b453a['infoSyncTree_']=new pr({'startListening':(_0x32830c,_0x342340,_0x16f8ec,_0x597256)=>{let _0x73a26e=[];const _0x51cc01=_0x1b453a['infoData_']['getNode'](_0x32830c['_path']);return _0x51cc01['isEmpty']()||(_0x73a26e=Yt(_0x1b453a['infoSyncTree_'],_0x32830c['_path'],_0x51cc01),setTimeout(()=>{_0x597256('ok');},0x0)),_0x73a26e;},'stopListening':()=>{}}),vs(_0x1b453a,'connected',!0x1),_0x1b453a['serverSyncTree_']=new pr({'startListening':(_0x511012,_0x3a3f10,_0x3abf1f,_0x1d14d5)=>(_0x1b453a['server_']['listen'](_0x511012,_0x3abf1f,_0x3a3f10,(_0x2af040,_0x1477f9)=>{const _0x36b697=_0x1d14d5(_0x2af040,_0x1477f9);V(_0x1b453a['eventQueue_'],_0x511012['_path'],_0x36b697);}),[]),'stopListening':(_0x147a38,_0x5adffe)=>{_0x1b453a['server_']['unlisten'](_0x147a38,_0x5adffe);}});}function la(_0x51e88b){const _0x42eb96=_0x51e88b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x42eb96;}function Xt(_0x15a51e){return id({'timestamp':la(_0x15a51e)});}function gr(_0x550947,_0x32000d,_0x28f103,_0x57ebc5,_0x5b09c0){_0x550947['dataUpdateCount']++;const _0x1afb41=new C(_0x32000d);_0x28f103=_0x550947['interceptServerDataCallback_']?_0x550947['interceptServerDataCallback_'](_0x32000d,_0x28f103):_0x28f103;let _0x53b824=[];if(_0x5b09c0){if(_0x57ebc5){const _0x5a5985=_n(_0x28f103,_0x210969=>A(_0x210969));_0x53b824=Ju(_0x550947['serverSyncTree_'],_0x1afb41,_0x5a5985,_0x5b09c0);}else{const _0x3a16d2=A(_0x28f103);_0x53b824=Jo(_0x550947['serverSyncTree_'],_0x1afb41,_0x3a16d2,_0x5b09c0);}}else{if(_0x57ebc5){const _0x5da1fe=_n(_0x28f103,_0x191d3e=>A(_0x191d3e));_0x53b824=Ku(_0x550947['serverSyncTree_'],_0x1afb41,_0x5da1fe);}else{const _0x7c686a=A(_0x28f103);_0x53b824=Yt(_0x550947['serverSyncTree_'],_0x1afb41,_0x7c686a);}}let _0x56176f=_0x1afb41;_0x53b824['length']>0x0&&(_0x56176f=ct(_0x550947,_0x1afb41)),V(_0x550947['eventQueue_'],_0x56176f,_0x53b824);}function mr(_0x28dbad,_0x4820c7){vs(_0x28dbad,'connected',_0x4820c7),_0x4820c7===!0x1&&Sd(_0x28dbad);}function Id(_0x2edd8d,_0x541b50){x(_0x541b50,(_0x2bd363,_0x121263)=>{vs(_0x2edd8d,_0x2bd363,_0x121263);});}function vs(_0x491cff,_0x596140,_0x5df3aa){const _0x310d04=new C('/.info/'+_0x596140),_0x9954f4=A(_0x5df3aa);_0x491cff['infoData_']['updateSnapshot'](_0x310d04,_0x9954f4);const _0x4d161a=Yt(_0x491cff['infoSyncTree_'],_0x310d04,_0x9954f4);V(_0x491cff['eventQueue_'],_0x310d04,_0x4d161a);}function zn(_0x3d085f){return _0x3d085f['nextWriteId_']++;}function wd(_0x1d9135,_0x58c700,_0x70a22f){const _0x143aba=Xu(_0x1d9135['serverSyncTree_'],_0x58c700);return _0x143aba!=null?Promise['resolve'](_0x143aba):_0x1d9135['server_']['get'](_0x58c700)['then'](_0x2dea66=>{const _0x2fa0d6=A(_0x2dea66)['withIndex'](_0x58c700['_queryParams']['getIndex']());Ni(_0x1d9135['serverSyncTree_'],_0x58c700,_0x70a22f,!0x0);let _0x596444;if(_0x58c700['_queryParams']['loadsAllData']())_0x596444=Yt(_0x1d9135['serverSyncTree_'],_0x58c700['_path'],_0x2fa0d6);else{const _0x166232=Wt(_0x1d9135['serverSyncTree_'],_0x58c700);_0x596444=Jo(_0x1d9135['serverSyncTree_'],_0x58c700['_path'],_0x2fa0d6,_0x166232);}return V(_0x1d9135['eventQueue_'],_0x58c700['_path'],_0x596444),An(_0x1d9135['serverSyncTree_'],_0x58c700,_0x70a22f,null,!0x0),_0x2fa0d6;},_0x4bda40=>(gt(_0x1d9135,'get\x20for\x20query\x20'+O(_0x58c700)+'\x20failed:\x20'+_0x4bda40),Promise['reject'](new Error(_0x4bda40))));}function Cd(_0x218084,_0x2e28a1,_0x332d94,_0x3388db,_0x6790cb){gt(_0x218084,'set',{'path':_0x2e28a1['toString'](),'value':_0x332d94,'priority':_0x3388db});const _0x4b33b5=Xt(_0x218084),_0x9b60af=A(_0x332d94,_0x3388db),_0x281b84=Vn(_0x218084['serverSyncTree_'],_0x2e28a1),_0x4405ea=fs(_0x9b60af,_0x281b84,_0x4b33b5),_0x31173a=zn(_0x218084),_0xdaa0ef=as(_0x218084['serverSyncTree_'],_0x2e28a1,_0x4405ea,_0x31173a,!0x0);qn(_0x218084['eventQueue_'],_0xdaa0ef),_0x218084['server_']['put'](_0x2e28a1['toString'](),_0x9b60af['val'](!0x0),(_0x226ed6,_0x18fb38)=>{const _0x38a2b1=_0x226ed6==='ok';_0x38a2b1||U('set\x20at\x20'+_0x2e28a1+'\x20failed:\x20'+_0x226ed6);const _0x1ed168=_e(_0x218084['serverSyncTree_'],_0x31173a,!_0x38a2b1);V(_0x218084['eventQueue_'],_0x2e28a1,_0x1ed168),be(_0x218084,_0x6790cb,_0x226ed6,_0x18fb38);});const _0x55695e=Is(_0x218084,_0x2e28a1);ct(_0x218084,_0x55695e),V(_0x218084['eventQueue_'],_0x55695e,[]);}function Td(_0x573a27,_0x2dd5f0,_0x29dd34,_0x2d09f5){gt(_0x573a27,'update',{'path':_0x2dd5f0['toString'](),'value':_0x29dd34});let _0x1463a6=!0x0;const _0xda8257=Xt(_0x573a27),_0xe4c2e2={};if(x(_0x29dd34,(_0x4137b2,_0x164f1b)=>{_0x1463a6=!0x1,_0xe4c2e2[_0x4137b2]=ta(k(_0x2dd5f0,_0x4137b2),A(_0x164f1b),_0x573a27['serverSyncTree_'],_0xda8257);}),_0x1463a6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x573a27,_0x2d09f5,'ok',void 0x0);else{const _0x1535d9=zn(_0x573a27),_0x519d1a=ju(_0x573a27['serverSyncTree_'],_0x2dd5f0,_0xe4c2e2,_0x1535d9);qn(_0x573a27['eventQueue_'],_0x519d1a),_0x573a27['server_']['merge'](_0x2dd5f0['toString'](),_0x29dd34,(_0x524b6d,_0xaff39a)=>{const _0x4a232a=_0x524b6d==='ok';_0x4a232a||U('update\x20at\x20'+_0x2dd5f0+'\x20failed:\x20'+_0x524b6d);const _0xa6fb46=_e(_0x573a27['serverSyncTree_'],_0x1535d9,!_0x4a232a),_0xfafa33=_0xa6fb46['length']>0x0?ct(_0x573a27,_0x2dd5f0):_0x2dd5f0;V(_0x573a27['eventQueue_'],_0xfafa33,_0xa6fb46),be(_0x573a27,_0x2d09f5,_0x524b6d,_0xaff39a);}),x(_0x29dd34,_0x20d9bb=>{const _0x16ccf0=Is(_0x573a27,k(_0x2dd5f0,_0x20d9bb));ct(_0x573a27,_0x16ccf0);}),V(_0x573a27['eventQueue_'],_0x2dd5f0,[]);}}function Sd(_0x275386){gt(_0x275386,'onDisconnectEvents');const _0x102672=Xt(_0x275386),_0x596dc4=En();Si(_0x275386['onDisconnect_'],w(),(_0x3abbe9,_0x3b57bc)=>{const _0x67dccc=ta(_0x3abbe9,_0x3b57bc,_0x275386['serverSyncTree_'],_0x102672);pt(_0x596dc4,_0x3abbe9,_0x67dccc);});let _0x5f108b=[];Si(_0x596dc4,w(),(_0x339e42,_0x488f32)=>{_0x5f108b=_0x5f108b['concat'](Yt(_0x275386['serverSyncTree_'],_0x339e42,_0x488f32));const _0x1d6072=Is(_0x275386,_0x339e42);ct(_0x275386,_0x1d6072);}),_0x275386['onDisconnect_']=En(),V(_0x275386['eventQueue_'],w(),_0x5f108b);}function bd(_0x60bfdc,_0x41280a,_0x37786d){_0x60bfdc['server_']['onDisconnectCancel'](_0x41280a['toString'](),(_0x53fd59,_0x3619bb)=>{_0x53fd59==='ok'&&Ti(_0x60bfdc['onDisconnect_'],_0x41280a),be(_0x60bfdc,_0x37786d,_0x53fd59,_0x3619bb);});}function yr(_0x27cddd,_0x1ecf9f,_0x50e9c2,_0x1b40f5){const _0x13b7ee=A(_0x50e9c2);_0x27cddd['server_']['onDisconnectPut'](_0x1ecf9f['toString'](),_0x13b7ee['val'](!0x0),(_0x4c06e8,_0xde70cb)=>{_0x4c06e8==='ok'&&pt(_0x27cddd['onDisconnect_'],_0x1ecf9f,_0x13b7ee),be(_0x27cddd,_0x1b40f5,_0x4c06e8,_0xde70cb);});}function Rd(_0x3c877c,_0x32ca24,_0x32fc,_0x57fe62,_0x537cad){const _0x49f90e=A(_0x32fc,_0x57fe62);_0x3c877c['server_']['onDisconnectPut'](_0x32ca24['toString'](),_0x49f90e['val'](!0x0),(_0x19c3f8,_0x2650bd)=>{_0x19c3f8==='ok'&&pt(_0x3c877c['onDisconnect_'],_0x32ca24,_0x49f90e),be(_0x3c877c,_0x537cad,_0x19c3f8,_0x2650bd);});}function Ad(_0x1ffae6,_0x5a3f09,_0x10ec3d,_0x3e45f5){if(pn(_0x10ec3d)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1ffae6,_0x3e45f5,'ok',void 0x0);return;}_0x1ffae6['server_']['onDisconnectMerge'](_0x5a3f09['toString'](),_0x10ec3d,(_0x1538af,_0x5ee9cd)=>{_0x1538af==='ok'&&x(_0x10ec3d,(_0x4eb054,_0x16b5ca)=>{const _0x52b738=A(_0x16b5ca);pt(_0x1ffae6['onDisconnect_'],k(_0x5a3f09,_0x4eb054),_0x52b738);}),be(_0x1ffae6,_0x3e45f5,_0x1538af,_0x5ee9cd);});}function kd(_0x217c39,_0x29c87c,_0x13fa61){let _0x5f1e37;y(_0x29c87c['_path'])==='.info'?_0x5f1e37=Ni(_0x217c39['infoSyncTree_'],_0x29c87c,_0x13fa61):_0x5f1e37=Ni(_0x217c39['serverSyncTree_'],_0x29c87c,_0x13fa61),oa(_0x217c39['eventQueue_'],_0x29c87c['_path'],_0x5f1e37);}function Pd(_0x3738f8,_0x1c5722,_0x4a8d59){let _0x507f60;y(_0x1c5722['_path'])==='.info'?_0x507f60=An(_0x3738f8['infoSyncTree_'],_0x1c5722,_0x4a8d59):_0x507f60=An(_0x3738f8['serverSyncTree_'],_0x1c5722,_0x4a8d59),oa(_0x3738f8['eventQueue_'],_0x1c5722['_path'],_0x507f60);}function ha(_0x2e08bd){_0x2e08bd['persistentConnection_']&&_0x2e08bd['persistentConnection_']['interrupt'](ca);}function Nd(_0x472c16){_0x472c16['persistentConnection_']&&_0x472c16['persistentConnection_']['resume'](ca);}function gt(_0x15c7a5,..._0x4e3205){let _0x3aabd7='';_0x15c7a5['persistentConnection_']&&(_0x3aabd7=_0x15c7a5['persistentConnection_']['id']+':'),L(_0x3aabd7,..._0x4e3205);}function be(_0x4a866f,_0x3f3904,_0x5b3053,_0x7c096a){_0x3f3904&&ft(()=>{if(_0x5b3053==='ok')_0x3f3904(null);else{const _0x4d42ff=(_0x5b3053||'error')['toUpperCase']();let _0x4faf2b=_0x4d42ff;_0x7c096a&&(_0x4faf2b+=':\x20'+_0x7c096a);const _0xe2be4b=new Error(_0x4faf2b);_0xe2be4b['code']=_0x4d42ff,_0x3f3904(_0xe2be4b);}});}function Od(_0x4c35e4,_0x1ed9f4,_0x5ebf10,_0x4a9d22,_0x3c157b,_0x3f6311){gt(_0x4c35e4,'transaction\x20on\x20'+_0x1ed9f4);const _0x2938eb={'path':_0x1ed9f4,'update':_0x5ebf10,'onComplete':_0x4a9d22,'status':null,'order':so(),'applyLocally':_0x3f6311,'retryCount':0x0,'unwatcher':_0x3c157b,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x73bafe=Es(_0x4c35e4,_0x1ed9f4,void 0x0);_0x2938eb['currentInputSnapshot']=_0x73bafe;const _0x177d4d=_0x2938eb['update'](_0x73bafe['val']());if(_0x177d4d===void 0x0)_0x2938eb['unwatcher'](),_0x2938eb['currentOutputSnapshotRaw']=null,_0x2938eb['currentOutputSnapshotResolved']=null,_0x2938eb['onComplete']&&_0x2938eb['onComplete'](null,!0x1,_0x2938eb['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x177d4d,_0x2938eb['path']),_0x2938eb['status']=0x0;const _0x179285=$n(_0x4c35e4['transactionQueueTree_'],_0x1ed9f4),_0x26a583=je(_0x179285)||[];_0x26a583['push'](_0x2938eb),gs(_0x179285,_0x26a583);let _0xd13748;typeof _0x177d4d=='object'&&_0x177d4d!==null&&Q(_0x177d4d,'.priority')?(_0xd13748=Le(_0x177d4d,'.priority'),f(Bt(_0xd13748),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xd13748=(Vn(_0x4c35e4['serverSyncTree_'],_0x1ed9f4)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4edbf2=Xt(_0x4c35e4),_0x3f81eb=A(_0x177d4d,_0xd13748),_0x5a9d84=fs(_0x3f81eb,_0x73bafe,_0x4edbf2);_0x2938eb['currentOutputSnapshotRaw']=_0x3f81eb,_0x2938eb['currentOutputSnapshotResolved']=_0x5a9d84,_0x2938eb['currentWriteId']=zn(_0x4c35e4);const _0x24571c=as(_0x4c35e4['serverSyncTree_'],_0x1ed9f4,_0x5a9d84,_0x2938eb['currentWriteId'],_0x2938eb['applyLocally']);V(_0x4c35e4['eventQueue_'],_0x1ed9f4,_0x24571c),jn(_0x4c35e4,_0x4c35e4['transactionQueueTree_']);}}function Es(_0x1b88fe,_0x2ce8ab,_0x39fe2c){return Vn(_0x1b88fe['serverSyncTree_'],_0x2ce8ab,_0x39fe2c)||g['EMPTY_NODE'];}function jn(_0x235ad8,_0x1b14d2=_0x235ad8['transactionQueueTree_']){if(_0x1b14d2||Kn(_0x235ad8,_0x1b14d2),je(_0x1b14d2)){const _0x3fb077=da(_0x235ad8,_0x1b14d2);f(_0x3fb077['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3fb077['every'](_0x4d74c3=>_0x4d74c3['status']===0x0)&&Dd(_0x235ad8,Qt(_0x1b14d2),_0x3fb077);}else na(_0x1b14d2)&&Gn(_0x1b14d2,_0x3d4d51=>{jn(_0x235ad8,_0x3d4d51);});}function Dd(_0x329704,_0x2bdfa6,_0x218a8f){const _0x24c380=_0x218a8f['map'](_0x4334c3=>_0x4334c3['currentWriteId']),_0x3b20f7=Es(_0x329704,_0x2bdfa6,_0x24c380);let _0x2b7367=_0x3b20f7;const _0x583c99=_0x3b20f7['hash']();for(let _0xde053=0x0;_0xde053<_0x218a8f['length'];_0xde053++){const _0x16eadd=_0x218a8f[_0xde053];f(_0x16eadd['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x16eadd['status']=0x1,_0x16eadd['retryCount']++;const _0x4e3b80=F(_0x2bdfa6,_0x16eadd['path']);_0x2b7367=_0x2b7367['updateChild'](_0x4e3b80,_0x16eadd['currentOutputSnapshotRaw']);}const _0x1d25b1=_0x2b7367['val'](!0x0),_0x498447=_0x2bdfa6;_0x329704['server_']['put'](_0x498447['toString'](),_0x1d25b1,_0x529eef=>{gt(_0x329704,'transaction\x20put\x20response',{'path':_0x498447['toString'](),'status':_0x529eef});let _0xbca00e=[];if(_0x529eef==='ok'){const _0x28870a=[];for(let _0x3a1204=0x0;_0x3a1204<_0x218a8f['length'];_0x3a1204++)_0x218a8f[_0x3a1204]['status']=0x2,_0xbca00e=_0xbca00e['concat'](_e(_0x329704['serverSyncTree_'],_0x218a8f[_0x3a1204]['currentWriteId'])),_0x218a8f[_0x3a1204]['onComplete']&&_0x28870a['push'](()=>_0x218a8f[_0x3a1204]['onComplete'](null,!0x0,_0x218a8f[_0x3a1204]['currentOutputSnapshotResolved'])),_0x218a8f[_0x3a1204]['unwatcher']();Kn(_0x329704,$n(_0x329704['transactionQueueTree_'],_0x2bdfa6)),jn(_0x329704,_0x329704['transactionQueueTree_']),V(_0x329704['eventQueue_'],_0x2bdfa6,_0xbca00e);for(let _0x7a9483=0x0;_0x7a9483<_0x28870a['length'];_0x7a9483++)ft(_0x28870a[_0x7a9483]);}else{if(_0x529eef==='datastale'){for(let _0x2d7d09=0x0;_0x2d7d09<_0x218a8f['length'];_0x2d7d09++)_0x218a8f[_0x2d7d09]['status']===0x3?_0x218a8f[_0x2d7d09]['status']=0x4:_0x218a8f[_0x2d7d09]['status']=0x0;}else{U('transaction\x20at\x20'+_0x498447['toString']()+'\x20failed:\x20'+_0x529eef);for(let _0xeffd5f=0x0;_0xeffd5f<_0x218a8f['length'];_0xeffd5f++)_0x218a8f[_0xeffd5f]['status']=0x4,_0x218a8f[_0xeffd5f]['abortReason']=_0x529eef;}ct(_0x329704,_0x2bdfa6);}},_0x583c99);}function ct(_0x56899d,_0x3fe0f6){const _0x11706f=ua(_0x56899d,_0x3fe0f6),_0x238604=Qt(_0x11706f),_0x30f24c=da(_0x56899d,_0x11706f);return Md(_0x56899d,_0x30f24c,_0x238604),_0x238604;}function Md(_0x1b5753,_0x325436,_0x1370c3){if(_0x325436['length']===0x0)return;const _0x2d0368=[];let _0x478afd=[];const _0x295a58=_0x325436['filter'](_0x2ff726=>_0x2ff726['status']===0x0)['map'](_0x3056dc=>_0x3056dc['currentWriteId']);for(let _0x10e4f6=0x0;_0x10e4f6<_0x325436['length'];_0x10e4f6++){const _0x284742=_0x325436[_0x10e4f6],_0x6c36d3=F(_0x1370c3,_0x284742['path']);let _0x2527b2=!0x1,_0x288964;if(f(_0x6c36d3!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x284742['status']===0x4)_0x2527b2=!0x0,_0x288964=_0x284742['abortReason'],_0x478afd=_0x478afd['concat'](_e(_0x1b5753['serverSyncTree_'],_0x284742['currentWriteId'],!0x0));else{if(_0x284742['status']===0x0){if(_0x284742['retryCount']>=yd)_0x2527b2=!0x0,_0x288964='maxretry',_0x478afd=_0x478afd['concat'](_e(_0x1b5753['serverSyncTree_'],_0x284742['currentWriteId'],!0x0));else{const _0x38efa4=Es(_0x1b5753,_0x284742['path'],_0x295a58);_0x284742['currentInputSnapshot']=_0x38efa4;const _0xb7b6c3=_0x325436[_0x10e4f6]['update'](_0x38efa4['val']());if(_0xb7b6c3!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0xb7b6c3,_0x284742['path']);let _0x19f966=A(_0xb7b6c3);typeof _0xb7b6c3=='object'&&_0xb7b6c3!=null&&Q(_0xb7b6c3,'.priority')||(_0x19f966=_0x19f966['updatePriority'](_0x38efa4['getPriority']()));const _0x1a8560=_0x284742['currentWriteId'],_0x2f757d=Xt(_0x1b5753),_0x348a60=fs(_0x19f966,_0x38efa4,_0x2f757d);_0x284742['currentOutputSnapshotRaw']=_0x19f966,_0x284742['currentOutputSnapshotResolved']=_0x348a60,_0x284742['currentWriteId']=zn(_0x1b5753),_0x295a58['splice'](_0x295a58['indexOf'](_0x1a8560),0x1),_0x478afd=_0x478afd['concat'](as(_0x1b5753['serverSyncTree_'],_0x284742['path'],_0x348a60,_0x284742['currentWriteId'],_0x284742['applyLocally'])),_0x478afd=_0x478afd['concat'](_e(_0x1b5753['serverSyncTree_'],_0x1a8560,!0x0));}else _0x2527b2=!0x0,_0x288964='nodata',_0x478afd=_0x478afd['concat'](_e(_0x1b5753['serverSyncTree_'],_0x284742['currentWriteId'],!0x0));}}}V(_0x1b5753['eventQueue_'],_0x1370c3,_0x478afd),_0x478afd=[],_0x2527b2&&(_0x325436[_0x10e4f6]['status']=0x2,function(_0x482302){setTimeout(_0x482302,Math['floor'](0x0));}(_0x325436[_0x10e4f6]['unwatcher']),_0x325436[_0x10e4f6]['onComplete']&&(_0x288964==='nodata'?_0x2d0368['push'](()=>_0x325436[_0x10e4f6]['onComplete'](null,!0x1,_0x325436[_0x10e4f6]['currentInputSnapshot'])):_0x2d0368['push'](()=>_0x325436[_0x10e4f6]['onComplete'](new Error(_0x288964),!0x1,null))));}Kn(_0x1b5753,_0x1b5753['transactionQueueTree_']);for(let _0x5659d9=0x0;_0x5659d9<_0x2d0368['length'];_0x5659d9++)ft(_0x2d0368[_0x5659d9]);jn(_0x1b5753,_0x1b5753['transactionQueueTree_']);}function ua(_0x144a5d,_0x2b9d30){let _0x41d4fc,_0xfe89a4=_0x144a5d['transactionQueueTree_'];for(_0x41d4fc=y(_0x2b9d30);_0x41d4fc!==null&&je(_0xfe89a4)===void 0x0;)_0xfe89a4=$n(_0xfe89a4,_0x41d4fc),_0x2b9d30=S(_0x2b9d30),_0x41d4fc=y(_0x2b9d30);return _0xfe89a4;}function da(_0x315311,_0x2885a6){const _0x9298b1=[];return fa(_0x315311,_0x2885a6,_0x9298b1),_0x9298b1['sort']((_0x37703b,_0x1deae6)=>_0x37703b['order']-_0x1deae6['order']),_0x9298b1;}function fa(_0x10ebc9,_0x9058fa,_0x23a910){const _0x38aad1=je(_0x9058fa);if(_0x38aad1){for(let _0x5d924a=0x0;_0x5d924a<_0x38aad1['length'];_0x5d924a++)_0x23a910['push'](_0x38aad1[_0x5d924a]);}Gn(_0x9058fa,_0x207b9c=>{fa(_0x10ebc9,_0x207b9c,_0x23a910);});}function Kn(_0x31690a,_0x6dea47){const _0x6be39e=je(_0x6dea47);if(_0x6be39e){let _0x5e6d79=0x0;for(let _0x5222f9=0x0;_0x5222f9<_0x6be39e['length'];_0x5222f9++)_0x6be39e[_0x5222f9]['status']!==0x2&&(_0x6be39e[_0x5e6d79]=_0x6be39e[_0x5222f9],_0x5e6d79++);_0x6be39e['length']=_0x5e6d79,gs(_0x6dea47,_0x6be39e['length']>0x0?_0x6be39e:void 0x0);}Gn(_0x6dea47,_0x52cb92=>{Kn(_0x31690a,_0x52cb92);});}function Is(_0x39a54c,_0x32dd31){const _0x4a0241=Qt(ua(_0x39a54c,_0x32dd31)),_0x2b23b5=$n(_0x39a54c['transactionQueueTree_'],_0x32dd31);return ad(_0x2b23b5,_0x33aa49=>{di(_0x39a54c,_0x33aa49);}),di(_0x39a54c,_0x2b23b5),ia(_0x2b23b5,_0x1dcbe5=>{di(_0x39a54c,_0x1dcbe5);}),_0x4a0241;}function di(_0x35c84c,_0x3c5f35){const _0x14795b=je(_0x3c5f35);if(_0x14795b){const _0x43b62b=[];let _0x5668c1=[],_0x56dc3e=-0x1;for(let _0x57272c=0x0;_0x57272c<_0x14795b['length'];_0x57272c++)_0x14795b[_0x57272c]['status']===0x3||(_0x14795b[_0x57272c]['status']===0x1?(f(_0x56dc3e===_0x57272c-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x56dc3e=_0x57272c,_0x14795b[_0x57272c]['status']=0x3,_0x14795b[_0x57272c]['abortReason']='set'):(f(_0x14795b[_0x57272c]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x14795b[_0x57272c]['unwatcher'](),_0x5668c1=_0x5668c1['concat'](_e(_0x35c84c['serverSyncTree_'],_0x14795b[_0x57272c]['currentWriteId'],!0x0)),_0x14795b[_0x57272c]['onComplete']&&_0x43b62b['push'](_0x14795b[_0x57272c]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x56dc3e===-0x1?gs(_0x3c5f35,void 0x0):_0x14795b['length']=_0x56dc3e+0x1,V(_0x35c84c['eventQueue_'],Qt(_0x3c5f35),_0x5668c1);for(let _0x3c4e2e=0x0;_0x3c4e2e<_0x43b62b['length'];_0x3c4e2e++)ft(_0x43b62b[_0x3c4e2e]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x10b2e0){let _0x23013c='';const _0x66c596=_0x10b2e0['split']('/');for(let _0x4b6db7=0x0;_0x4b6db7<_0x66c596['length'];_0x4b6db7++)if(_0x66c596[_0x4b6db7]['length']>0x0){let _0x3730c8=_0x66c596[_0x4b6db7];try{_0x3730c8=decodeURIComponent(_0x3730c8['replace'](/\+/g,'\x20'));}catch{}_0x23013c+='/'+_0x3730c8;}return _0x23013c;}function xd(_0x4f9647){const _0x847a26={};_0x4f9647['charAt'](0x0)==='?'&&(_0x4f9647=_0x4f9647['substring'](0x1));for(const _0x47daca of _0x4f9647['split']('&')){if(_0x47daca['length']===0x0)continue;const _0x5cf840=_0x47daca['split']('=');_0x5cf840['length']===0x2?_0x847a26[decodeURIComponent(_0x5cf840[0x0])]=decodeURIComponent(_0x5cf840[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x47daca+'\x27\x20in\x20query\x20\x27'+_0x4f9647+'\x27');}return _0x847a26;}const vr=function(_0x40b622,_0x3d62b8){const _0x40e758=Fd(_0x40b622),_0x2c5f00=_0x40e758['namespace'];_0x40e758['domain']==='firebase.com'&&ae(_0x40e758['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2c5f00||_0x2c5f00==='undefined')&&_0x40e758['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x40e758['secure']||$l();const _0x592e57=_0x40e758['scheme']==='ws'||_0x40e758['scheme']==='wss';return{'repoInfo':new yo(_0x40e758['host'],_0x40e758['secure'],_0x2c5f00,_0x592e57,_0x3d62b8,'',_0x2c5f00!==_0x40e758['subdomain']),'path':new C(_0x40e758['pathString'])};},Fd=function(_0x1a94e1){let _0x1bd0c0='',_0x5ad33a='',_0x2912cf='',_0x2cc003='',_0x5def63='',_0x360bf4=!0x0,_0x6aa718='https',_0x1f14f9=0x1bb;if(typeof _0x1a94e1=='string'){let _0xfabfbd=_0x1a94e1['indexOf']('//');_0xfabfbd>=0x0&&(_0x6aa718=_0x1a94e1['substring'](0x0,_0xfabfbd-0x1),_0x1a94e1=_0x1a94e1['substring'](_0xfabfbd+0x2));let _0x459e38=_0x1a94e1['indexOf']('/');_0x459e38===-0x1&&(_0x459e38=_0x1a94e1['length']);let _0x907c5a=_0x1a94e1['indexOf']('?');_0x907c5a===-0x1&&(_0x907c5a=_0x1a94e1['length']),_0x1bd0c0=_0x1a94e1['substring'](0x0,Math['min'](_0x459e38,_0x907c5a)),_0x459e38<_0x907c5a&&(_0x2cc003=Ld(_0x1a94e1['substring'](_0x459e38,_0x907c5a)));const _0x308a6e=xd(_0x1a94e1['substring'](Math['min'](_0x1a94e1['length'],_0x907c5a)));_0xfabfbd=_0x1bd0c0['indexOf'](':'),_0xfabfbd>=0x0?(_0x360bf4=_0x6aa718==='https'||_0x6aa718==='wss',_0x1f14f9=parseInt(_0x1bd0c0['substring'](_0xfabfbd+0x1),0xa)):_0xfabfbd=_0x1bd0c0['length'];const _0xc24676=_0x1bd0c0['slice'](0x0,_0xfabfbd);if(_0xc24676['toLowerCase']()==='localhost')_0x5ad33a='localhost';else{if(_0xc24676['split']('.')['length']<=0x2)_0x5ad33a=_0xc24676;else{const _0x3e28d8=_0x1bd0c0['indexOf']('.');_0x2912cf=_0x1bd0c0['substring'](0x0,_0x3e28d8)['toLowerCase'](),_0x5ad33a=_0x1bd0c0['substring'](_0x3e28d8+0x1),_0x5def63=_0x2912cf;}}'ns'in _0x308a6e&&(_0x5def63=_0x308a6e['ns']);}return{'host':_0x1bd0c0,'port':_0x1f14f9,'domain':_0x5ad33a,'subdomain':_0x2912cf,'secure':_0x360bf4,'scheme':_0x6aa718,'pathString':_0x2cc003,'namespace':_0x5def63};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x37655a=0x0;const _0x1ad044=[];return function(_0x2e5d07){const _0x55999c=_0x2e5d07===_0x37655a;_0x37655a=_0x2e5d07;let _0x78c101;const _0x495bd6=new Array(0x8);for(_0x78c101=0x7;_0x78c101>=0x0;_0x78c101--)_0x495bd6[_0x78c101]=Er['charAt'](_0x2e5d07%0x40),_0x2e5d07=Math['floor'](_0x2e5d07/0x40);f(_0x2e5d07===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x149b0f=_0x495bd6['join']('');if(_0x55999c){for(_0x78c101=0xb;_0x78c101>=0x0&&_0x1ad044[_0x78c101]===0x3f;_0x78c101--)_0x1ad044[_0x78c101]=0x0;_0x1ad044[_0x78c101]++;}else{for(_0x78c101=0x0;_0x78c101<0xc;_0x78c101++)_0x1ad044[_0x78c101]=Math['floor'](Math['random']()*0x40);}for(_0x78c101=0x0;_0x78c101<0xc;_0x78c101++)_0x149b0f+=Er['charAt'](_0x1ad044[_0x78c101]);return f(_0x149b0f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x149b0f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1a8e77,_0x3c7144,_0x27c17e,_0x27d93f){this['eventType']=_0x1a8e77,this['eventRegistration']=_0x3c7144,this['snapshot']=_0x27c17e,this['prevName']=_0x27d93f;}['getPath'](){const _0x524f49=this['snapshot']['ref'];return this['eventType']==='value'?_0x524f49['_path']:_0x524f49['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x56d764,_0x52943a,_0x54d744){this['eventRegistration']=_0x56d764,this['error']=_0x52943a,this['path']=_0x54d744;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x182303,_0x12ad64){this['snapshotCallback']=_0x182303,this['cancelCallback']=_0x12ad64;}['onValue'](_0x3bbc63,_0x7735cd){this['snapshotCallback']['call'](null,_0x3bbc63,_0x7735cd);}['onCancel'](_0x4256a6){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4256a6);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4b735a){return this['snapshotCallback']===_0x4b735a['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4b735a['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4b735a['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0xf03690,_0xebc4d6){this['_repo']=_0xf03690,this['_path']=_0xebc4d6;}['cancel'](){const _0x192af5=new H();return bd(this['_repo'],this['_path'],_0x192af5['wrapCallback'](()=>{})),_0x192af5['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x364a01=new H();return yr(this['_repo'],this['_path'],null,_0x364a01['wrapCallback'](()=>{})),_0x364a01['promise'];}['set'](_0x34e1f9){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x34e1f9,this['_path'],!0x1);const _0x3ce877=new H();return yr(this['_repo'],this['_path'],_0x34e1f9,_0x3ce877['wrapCallback'](()=>{})),_0x3ce877['promise'];}['setWithPriority'](_0x2a4331,_0xbd933){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x2a4331,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0xbd933);const _0x84e0bc=new H();return Rd(this['_repo'],this['_path'],_0x2a4331,_0xbd933,_0x84e0bc['wrapCallback'](()=>{})),_0x84e0bc['promise'];}['update'](_0xdd355c){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0xdd355c,this['_path']);const _0x3ec2de=new H();return Ad(this['_repo'],this['_path'],_0xdd355c,_0x3ec2de['wrapCallback'](()=>{})),_0x3ec2de['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x16074d,_0x5f2b0b,_0x4cae8e,_0xc0efa5){this['_repo']=_0x16074d,this['_path']=_0x5f2b0b,this['_queryParams']=_0x4cae8e,this['_orderByCalled']=_0xc0efa5;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xd6a34d=sr(this['_queryParams']),_0x4d18ba=$i(_0xd6a34d);return _0x4d18ba==='{}'?'default':_0x4d18ba;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xf3e9f3){if(_0xf3e9f3=P(_0xf3e9f3),!(_0xf3e9f3 instanceof Ae))return!0x1;const _0x4a3363=this['_repo']===_0xf3e9f3['_repo'],_0xd5acbf=Ki(this['_path'],_0xf3e9f3['_path']),_0x54f6d1=this['_queryIdentifier']===_0xf3e9f3['_queryIdentifier'];return _0x4a3363&&_0xd5acbf&&_0x54f6d1;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x1cf54a,_0x50ab5a){if(_0x1cf54a['_orderByCalled']===!0x0)throw new Error(_0x50ab5a+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x366a35){let _0x31408e=null,_0x4a5e67=null;if(_0x366a35['hasStart']()&&(_0x31408e=_0x366a35['getIndexStartValue']()),_0x366a35['hasEnd']()&&(_0x4a5e67=_0x366a35['getIndexEndValue']()),_0x366a35['getIndex']()===ve){const _0x308f3a='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xcc2ae4='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x366a35['hasStart']()){if(_0x366a35['getIndexStartName']()!==We)throw new Error(_0x308f3a);if(typeof _0x31408e!='string')throw new Error(_0xcc2ae4);}if(_0x366a35['hasEnd']()){if(_0x366a35['getIndexEndName']()!==we)throw new Error(_0x308f3a);if(typeof _0x4a5e67!='string')throw new Error(_0xcc2ae4);}}else{if(_0x366a35['getIndex']()===R){if(_0x31408e!=null&&!Bt(_0x31408e)||_0x4a5e67!=null&&!Bt(_0x4a5e67))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x366a35['getIndex']()instanceof Ji||_0x366a35['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x31408e!=null&&typeof _0x31408e=='object'||_0x4a5e67!=null&&typeof _0x4a5e67=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x851618){if(_0x851618['hasStart']()&&_0x851618['hasEnd']()&&_0x851618['hasLimit']()&&!_0x851618['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x4f38dc,_0x26f419){super(_0x4f38dc,_0x26f419,new Zi(),!0x1);}get['parent'](){const _0x5a2961=Ro(this['_path']);return _0x5a2961===null?null:new ee(this['_repo'],_0x5a2961);}get['root'](){let _0x3cad77=this;for(;_0x3cad77['parent']!==null;)_0x3cad77=_0x3cad77['parent'];return _0x3cad77;}}class lt{constructor(_0x30593a,_0x13345d,_0x840a36){this['_node']=_0x30593a,this['ref']=_0x13345d,this['_index']=_0x840a36;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x388224){const _0x393209=new C(_0x388224),_0x278526=Vt(this['ref'],_0x388224);return new lt(this['_node']['getChild'](_0x393209),_0x278526,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x59b4cb){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x327748,_0x978cf1)=>_0x59b4cb(new lt(_0x978cf1,Vt(this['ref'],_0x327748),R)));}['hasChild'](_0x2b4cc1){const _0x5b7852=new C(_0x2b4cc1);return!this['_node']['getChild'](_0x5b7852)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x180b42,_0x3bd15a){return _0x180b42=P(_0x180b42),_0x180b42['_checkNotDeleted']('ref'),_0x3bd15a!==void 0x0?Vt(_0x180b42['_root'],_0x3bd15a):_0x180b42['_root'];}function Vt(_0x5bd68d,_0x822d06){return _0x5bd68d=P(_0x5bd68d),y(_0x5bd68d['_path'])===null?pd('child','path',_0x822d06):ys('child','path',_0x822d06),new ee(_0x5bd68d['_repo'],k(_0x5bd68d['_path'],_0x822d06));}function v_(_0x5b4a3e){return _0x5b4a3e=P(_0x5b4a3e),new Vd(_0x5b4a3e['_repo'],_0x5b4a3e['_path']);}function E_(_0x535ca3,_0x345da7){_0x535ca3=P(_0x535ca3),Me('push',_0x535ca3['_path']),He('push',_0x345da7,_0x535ca3['_path'],!0x0);const _0x2a158d=la(_0x535ca3['_repo']),_0x40e83e=Ud(_0x2a158d),_0x2a504c=Vt(_0x535ca3,_0x40e83e),_0x24a0e6=Vt(_0x535ca3,_0x40e83e);let _0x19f663;return _0x345da7!=null?_0x19f663=Hd(_0x24a0e6,_0x345da7)['then'](()=>_0x24a0e6):_0x19f663=Promise['resolve'](_0x24a0e6),_0x2a504c['then']=_0x19f663['then']['bind'](_0x19f663),_0x2a504c['catch']=_0x19f663['then']['bind'](_0x19f663,void 0x0),_0x2a504c;}function Hd(_0x25a191,_0x1a13e6){_0x25a191=P(_0x25a191),Me('set',_0x25a191['_path']),He('set',_0x1a13e6,_0x25a191['_path'],!0x1);const _0xdea004=new H();return Cd(_0x25a191['_repo'],_0x25a191['_path'],_0x1a13e6,null,_0xdea004['wrapCallback'](()=>{})),_0xdea004['promise'];}function I_(_0x52c0f1,_0x48e3f4){ra('update',_0x48e3f4,_0x52c0f1['_path']);const _0x3226cc=new H();return Td(_0x52c0f1['_repo'],_0x52c0f1['_path'],_0x48e3f4,_0x3226cc['wrapCallback'](()=>{})),_0x3226cc['promise'];}function w_(_0x318b96){_0x318b96=P(_0x318b96);const _0x2fccca=new pa(()=>{}),_0x49a03d=new Qn(_0x2fccca);return wd(_0x318b96['_repo'],_0x318b96,_0x49a03d)['then'](_0x199ff3=>new lt(_0x199ff3,new ee(_0x318b96['_repo'],_0x318b96['_path']),_0x318b96['_queryParams']['getIndex']()));}class Qn{constructor(_0x356640){this['callbackContext']=_0x356640;}['respondsTo'](_0x27fd77){return _0x27fd77==='value';}['createEvent'](_0xd3df3d,_0x417b08){const _0x34d017=_0x417b08['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0xd3df3d['snapshotNode'],new ee(_0x417b08['_repo'],_0x417b08['_path']),_0x34d017));}['getEventRunner'](_0x3f9f29){return _0x3f9f29['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3f9f29['error']):()=>this['callbackContext']['onValue'](_0x3f9f29['snapshot'],null);}['createCancelEvent'](_0x4d3b25,_0x31eaa3){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4d3b25,_0x31eaa3):null;}['matches'](_0x34ec27){return _0x34ec27 instanceof Qn?!_0x34ec27['callbackContext']||!this['callbackContext']?!0x0:_0x34ec27['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x41cab0,_0x1dee43,_0x27c96a,_0x22357a,_0x247d91){const _0x22f769=new pa(_0x27c96a,void 0x0),_0x5dc678=new Qn(_0x22f769);return kd(_0x41cab0['_repo'],_0x41cab0,_0x5dc678),()=>Pd(_0x41cab0['_repo'],_0x41cab0,_0x5dc678);}function Gd(_0x445c79,_0x3c0e39,_0x3a8b19,_0x403eb7){return $d(_0x445c79,'value',_0x3c0e39);}class mt{}class ma extends mt{constructor(_0x399e8c,_0x2aeaec){super(),this['_value']=_0x399e8c,this['_key']=_0x2aeaec,this['type']='endAt';}['_apply'](_0x2d5d8f){He('endAt',this['_value'],_0x2d5d8f['_path'],!0x0);const _0x4bd466=Jh(_0x2d5d8f['_queryParams'],this['_value'],this['_key']);if(ga(_0x4bd466),Yn(_0x4bd466),_0x2d5d8f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x2d5d8f['_repo'],_0x2d5d8f['_path'],_0x4bd466,_0x2d5d8f['_orderByCalled']);}}function C_(_0x15b2d9,_0x367b66){return new ma(_0x15b2d9,_0x367b66);}class ya extends mt{constructor(_0x13104f,_0x13693e){super(),this['_value']=_0x13104f,this['_key']=_0x13693e,this['type']='startAt';}['_apply'](_0x2818c3){He('startAt',this['_value'],_0x2818c3['_path'],!0x0);const _0x9730d4=Qh(_0x2818c3['_queryParams'],this['_value'],this['_key']);if(ga(_0x9730d4),Yn(_0x9730d4),_0x2818c3['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x2818c3['_repo'],_0x2818c3['_path'],_0x9730d4,_0x2818c3['_orderByCalled']);}}function T_(_0x2028c1=null,_0x45351b){return new ya(_0x2028c1,_0x45351b);}class qd extends mt{constructor(_0x26045b){super(),this['_limit']=_0x26045b,this['type']='limitToFirst';}['_apply'](_0x4ee4f4){if(_0x4ee4f4['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4ee4f4['_repo'],_0x4ee4f4['_path'],Yh(_0x4ee4f4['_queryParams'],this['_limit']),_0x4ee4f4['_orderByCalled']);}}function S_(_0x4c4a26){if(Math['floor'](_0x4c4a26)!==_0x4c4a26||_0x4c4a26<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x4c4a26);}class zd extends mt{constructor(_0x2dce60){super(),this['_path']=_0x2dce60,this['type']='orderByChild';}['_apply'](_0xff5ca2){_a(_0xff5ca2,'orderByChild');const _0xd18902=new C(this['_path']);if(v(_0xd18902))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xcd7e04=new Ji(_0xd18902),_0x5f25e9=xo(_0xff5ca2['_queryParams'],_0xcd7e04);return Yn(_0x5f25e9),new Ae(_0xff5ca2['_repo'],_0xff5ca2['_path'],_0x5f25e9,!0x0);}}function b_(_0x52a367){if(_0x52a367==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x52a367==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x52a367==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x52a367),new zd(_0x52a367);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x28c88d){_a(_0x28c88d,'orderByKey');const _0x1638e7=xo(_0x28c88d['_queryParams'],ve);return Yn(_0x1638e7),new Ae(_0x28c88d['_repo'],_0x28c88d['_path'],_0x1638e7,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x32903f,_0x1bc8b4){super(),this['_value']=_0x32903f,this['_key']=_0x1bc8b4,this['type']='equalTo';}['_apply'](_0x30d884){if(He('equalTo',this['_value'],_0x30d884['_path'],!0x1),_0x30d884['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x30d884['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x30d884));}}function A_(_0x2962ba,_0x16544c){return new Kd(_0x2962ba,_0x16544c);}function k_(_0x2c2f18,..._0x25e6b7){let _0x5257c8=P(_0x2c2f18);for(const _0x26a9f3 of _0x25e6b7)_0x5257c8=_0x26a9f3['_apply'](_0x5257c8);return _0x5257c8;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4d99d7,_0x503351,_0x1d32eb,_0x41b9ee){const _0x22be7a=_0x503351['lastIndexOf'](':'),_0x111823=_0x503351['substring'](0x0,_0x22be7a),_0x1f6537=qt(_0x111823);_0x4d99d7['repoInfo_']=new yo(_0x503351,_0x1f6537,_0x4d99d7['repoInfo_']['namespace'],_0x4d99d7['repoInfo_']['webSocketOnly'],_0x4d99d7['repoInfo_']['nodeAdmin'],_0x4d99d7['repoInfo_']['persistenceKey'],_0x4d99d7['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1d32eb),_0x41b9ee&&(_0x4d99d7['authTokenProvider_']=_0x41b9ee);}function Xd(_0xfe11f2,_0x38eac8,_0x2f27bb,_0x40ed50,_0x20f58e){let _0xf0ba37=_0x40ed50||_0xfe11f2['options']['databaseURL'];_0xf0ba37===void 0x0&&(_0xfe11f2['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0xfe11f2['options']['projectId']),_0xf0ba37=_0xfe11f2['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2e8dd3=vr(_0xf0ba37,_0x20f58e),_0x11c251=_0x2e8dd3['repoInfo'],_0x34bb39;typeof process<'u'&&Bs&&(_0x34bb39=Bs[Yd]),_0x34bb39?(_0xf0ba37='http://'+_0x34bb39+'?ns='+_0x11c251['namespace'],_0x2e8dd3=vr(_0xf0ba37,_0x20f58e),_0x11c251=_0x2e8dd3['repoInfo']):_0x2e8dd3['repoInfo']['secure'];const _0x2e77ba=new eh(_0xfe11f2['name'],_0xfe11f2['options'],_0x38eac8);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2e8dd3),v(_0x2e8dd3['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4ebd78=ef(_0x11c251,_0xfe11f2,_0x2e77ba,new Zl(_0xfe11f2,_0x2f27bb));return new tf(_0x4ebd78,_0xfe11f2);}function Zd(_0xafd10b,_0x25575b){const _0x190d09=Di[_0x25575b];(!_0x190d09||_0x190d09[_0xafd10b['key']]!==_0xafd10b)&&ae('Database\x20'+_0x25575b+'('+_0xafd10b['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0xafd10b),delete _0x190d09[_0xafd10b['key']];}function ef(_0x1aa7fa,_0x1adeeb,_0x24de77,_0x4f6d95){let _0x3018db=Di[_0x1adeeb['name']];_0x3018db||(_0x3018db={},Di[_0x1adeeb['name']]=_0x3018db);let _0x43c63b=_0x3018db[_0x1aa7fa['toURLString']()];return _0x43c63b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x43c63b=new vd(_0x1aa7fa,Qd,_0x24de77,_0x4f6d95),_0x3018db[_0x1aa7fa['toURLString']()]=_0x43c63b,_0x43c63b;}class tf{constructor(_0x2f2006,_0x565f72){this['_repoInternal']=_0x2f2006,this['app']=_0x565f72,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2f04a6){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x2f04a6+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x287931=Zr(),_0x2d293a){const _0x2d7484=Hi(_0x287931,'database')['getImmediate']({'identifier':_0x2d293a});if(!_0x2d7484['_instanceStarted']){const _0x3bce6e=hc('database');_0x3bce6e&&nf(_0x2d7484,..._0x3bce6e);}return _0x2d7484;}function nf(_0x3cfdb5,_0x45c422,_0x368872,_0xf71e56={}){_0x3cfdb5=P(_0x3cfdb5),_0x3cfdb5['_checkNotDeleted']('useEmulator');const _0x35d90f=_0x45c422+':'+_0x368872,_0x56503d=_0x3cfdb5['_repoInternal'];if(_0x3cfdb5['_instanceStarted']){if(_0x35d90f===_0x3cfdb5['_repoInternal']['repoInfo_']['host']&&xe(_0xf71e56,_0x56503d['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4c0113;if(_0x56503d['repoInfo_']['nodeAdmin'])_0xf71e56['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4c0113=new an(an['OWNER']);else{if(_0xf71e56['mockUserToken']){const _0x2b9026=typeof _0xf71e56['mockUserToken']=='string'?_0xf71e56['mockUserToken']:uc(_0xf71e56['mockUserToken'],_0x3cfdb5['app']['options']['projectId']);_0x4c0113=new an(_0x2b9026);}}qt(_0x45c422)&&Qr(_0x45c422),Jd(_0x56503d,_0x35d90f,_0xf71e56,_0x4c0113);}function N_(_0x3374c9){_0x3374c9=P(_0x3374c9),_0x3374c9['_checkNotDeleted']('goOffline'),ha(_0x3374c9['_repo']);}function O_(_0x465fd8){_0x465fd8=P(_0x465fd8),_0x465fd8['_checkNotDeleted']('goOnline'),Nd(_0x465fd8['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x23e478){Ul(dt),st(new Fe('database',(_0x4abe12,{instanceIdentifier:_0x1b2355})=>{const _0x5c5f04=_0x4abe12['getProvider']('app')['getImmediate'](),_0x145240=_0x4abe12['getProvider']('auth-internal'),_0x3807be=_0x4abe12['getProvider']('app-check-internal');return Xd(_0x5c5f04,_0x145240,_0x3807be,_0x1b2355);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x23e478),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x316578,_0x2eb5c9){this['committed']=_0x316578,this['snapshot']=_0x2eb5c9;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x4e2b8c,_0x4ce98f,_0x2d6a09){if(_0x4e2b8c=P(_0x4e2b8c),Me('Reference.transaction',_0x4e2b8c['_path']),_0x4e2b8c['key']==='.length'||_0x4e2b8c['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4e2b8c['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5761ad=!0x0,_0x36b301=new H(),_0x5ba17e=(_0x35c186,_0x1c19e9,_0x5c1e80)=>{let _0x10a6d7=null;_0x35c186?_0x36b301['reject'](_0x35c186):(_0x10a6d7=new lt(_0x5c1e80,new ee(_0x4e2b8c['_repo'],_0x4e2b8c['_path']),R),_0x36b301['resolve'](new of(_0x1c19e9,_0x10a6d7)));},_0x4a8e29=Gd(_0x4e2b8c,()=>{});return Od(_0x4e2b8c['_repo'],_0x4e2b8c['_path'],_0x4ce98f,_0x5ba17e,_0x4a8e29,_0x5761ad),_0x36b301['promise'];}se['prototype']['simpleListen']=function(_0x20cae1,_0x1be286){this['sendRequest']('q',{'p':_0x20cae1},_0x1be286);},se['prototype']['echo']=function(_0x206490,_0x5b7da2){this['sendRequest']('echo',{'d':_0x206490},_0x5b7da2);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5f1cbe,..._0x56a66a){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5f1cbe,..._0x56a66a);}function cn(_0x4a3953,..._0x19a952){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x4a3953,..._0x19a952);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x468ce0,..._0x2bf6f5){throw ws(_0x468ce0,..._0x2bf6f5);}function X(_0x8df0f6,..._0xf28036){return ws(_0x8df0f6,..._0xf28036);}function Ia(_0x43c116,_0x36de9b,_0x26ed28){const _0x1f0aba={...af(),[_0x36de9b]:_0x26ed28};return new Gt('auth','Firebase',_0x1f0aba)['create'](_0x36de9b,{'appName':_0x43c116['name']});}function re(_0x578cd2){return Ia(_0x578cd2,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xfa5170,..._0x4472a5){if(typeof _0xfa5170!='string'){const _0x193ba4=_0x4472a5[0x0],_0x3bf33c=[..._0x4472a5['slice'](0x1)];return _0x3bf33c[0x0]&&(_0x3bf33c[0x0]['appName']=_0xfa5170['name']),_0xfa5170['_errorFactory']['create'](_0x193ba4,..._0x3bf33c);}return Ea['create'](_0xfa5170,..._0x4472a5);}function m(_0x18a779,_0x286abd,..._0x2e90db){if(!_0x18a779)throw ws(_0x286abd,..._0x2e90db);}function ne(_0x284116){const _0x455f83='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x284116;throw cn(_0x455f83),new Error(_0x455f83);}function ce(_0x48e4a3,_0x5c3508){_0x48e4a3||ne(_0x5c3508);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x4db15a;return typeof self<'u'&&((_0x4db15a=self['location'])==null?void 0x0:_0x4db15a['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x435a18;return typeof self<'u'&&((_0x435a18=self['location'])==null?void 0x0:_0x435a18['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x3843cf=navigator;return _0x3843cf['languages']&&_0x3843cf['languages'][0x0]||_0x3843cf['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2464dd,_0x4e7c52){this['shortDelay']=_0x2464dd,this['longDelay']=_0x4e7c52,ce(_0x4e7c52>_0x2464dd,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x4bc54f,_0x3cdb6e){ce(_0x4bc54f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4953d3}=_0x4bc54f['emulator'];return _0x3cdb6e?''+_0x4953d3+(_0x3cdb6e['startsWith']('/')?_0x3cdb6e['slice'](0x1):_0x3cdb6e):_0x4953d3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x40c0d5,_0x33f1aa,_0x3c1527){this['fetchImpl']=_0x40c0d5,_0x33f1aa&&(this['headersImpl']=_0x33f1aa),_0x3c1527&&(this['responseImpl']=_0x3c1527);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4be8e8,_0xaa7836){return _0x4be8e8['tenantId']&&!_0xaa7836['tenantId']?{..._0xaa7836,'tenantId':_0x4be8e8['tenantId']}:_0xaa7836;}async function Pe(_0x17feb7,_0x2674b5,_0x1b6621,_0x411f6e,_0x233570={}){return Ca(_0x17feb7,_0x233570,async()=>{let _0xbd3f8e={},_0x52f948={};_0x411f6e&&(_0x2674b5==='GET'?_0x52f948=_0x411f6e:_0xbd3f8e={'body':JSON['stringify'](_0x411f6e)});const _0x451b4d=ut({..._0x52f948,'key':_0x17feb7['config']['apiKey']})['slice'](0x1),_0x4c87d1=await _0x17feb7['_getAdditionalHeaders']();_0x4c87d1['Content-Type']='application/json',_0x17feb7['languageCode']&&(_0x4c87d1['X-Firebase-Locale']=_0x17feb7['languageCode']);const _0xf9f1e4={'method':_0x2674b5,'headers':_0x4c87d1,..._0xbd3f8e};return dc()||(_0xf9f1e4['referrerPolicy']='strict-origin-when-cross-origin'),_0x17feb7['emulatorConfig']&&qt(_0x17feb7['emulatorConfig']['host'])&&(_0xf9f1e4['credentials']='include'),wa['fetch']()(await Ta(_0x17feb7,_0x17feb7['config']['apiHost'],_0x1b6621,_0x451b4d),_0xf9f1e4);});}async function Ca(_0x4d2f1b,_0x4422e1,_0x3e2ee7){_0x4d2f1b['_canInitEmulator']=!0x1;const _0x2ce3e8={...df,..._0x4422e1};try{const _0x4ab5ab=new gf(_0x4d2f1b),_0x58dda8=await Promise['race']([_0x3e2ee7(),_0x4ab5ab['promise']]);_0x4ab5ab['clearNetworkTimeout']();const _0x38273a=await _0x58dda8['json']();if('needConfirmation'in _0x38273a)throw on(_0x4d2f1b,'account-exists-with-different-credential',_0x38273a);if(_0x58dda8['ok']&&!('errorMessage'in _0x38273a))return _0x38273a;{const _0x55f2a6=_0x58dda8['ok']?_0x38273a['errorMessage']:_0x38273a['error']['message'],[_0x1386c6,_0x55ec8e]=_0x55f2a6['split']('\x20:\x20');if(_0x1386c6==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x4d2f1b,'credential-already-in-use',_0x38273a);if(_0x1386c6==='EMAIL_EXISTS')throw on(_0x4d2f1b,'email-already-in-use',_0x38273a);if(_0x1386c6==='USER_DISABLED')throw on(_0x4d2f1b,'user-disabled',_0x38273a);const _0xdedb5a=_0x2ce3e8[_0x1386c6]||_0x1386c6['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x55ec8e)throw Ia(_0x4d2f1b,_0xdedb5a,_0x55ec8e);Y(_0x4d2f1b,_0xdedb5a);}}catch(_0xcae585){if(_0xcae585 instanceof Re)throw _0xcae585;Y(_0x4d2f1b,'network-request-failed',{'message':String(_0xcae585)});}}async function en(_0x21bd0d,_0x1f20da,_0x391705,_0x15ff69,_0x4d4d84={}){const _0x3e543f=await Pe(_0x21bd0d,_0x1f20da,_0x391705,_0x15ff69,_0x4d4d84);return'mfaPendingCredential'in _0x3e543f&&Y(_0x21bd0d,'multi-factor-auth-required',{'_serverResponse':_0x3e543f}),_0x3e543f;}async function Ta(_0x19922e,_0x1ac17e,_0x326b46,_0x6571c5){const _0x14bb62=''+_0x1ac17e+_0x326b46+'?'+_0x6571c5,_0x1cc1a1=_0x19922e,_0x37aa9c=_0x1cc1a1['config']['emulator']?Cs(_0x19922e['config'],_0x14bb62):_0x19922e['config']['apiScheme']+'://'+_0x14bb62;return ff['includes'](_0x326b46)&&(await _0x1cc1a1['_persistenceManagerAvailable'],_0x1cc1a1['_getPersistenceType']()==='COOKIE')?_0x1cc1a1['_getPersistence']()['_getFinalTarget'](_0x37aa9c)['toString']():_0x37aa9c;}function _f(_0x2ad03e){switch(_0x2ad03e){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4bb171){this['auth']=_0x4bb171,this['timer']=null,this['promise']=new Promise((_0x33e320,_0x963f91)=>{this['timer']=setTimeout(()=>_0x963f91(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x13e451,_0x4e0603,_0x5ab0e4){const _0x377d88={'appName':_0x13e451['name']};_0x5ab0e4['email']&&(_0x377d88['email']=_0x5ab0e4['email']),_0x5ab0e4['phoneNumber']&&(_0x377d88['phoneNumber']=_0x5ab0e4['phoneNumber']);const _0x625e6c=X(_0x13e451,_0x4e0603,_0x377d88);return _0x625e6c['customData']['_tokenResponse']=_0x5ab0e4,_0x625e6c;}function wr(_0x207132){return _0x207132!==void 0x0&&_0x207132['enterprise']!==void 0x0;}class mf{constructor(_0x511c78){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x511c78['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x511c78['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x511c78['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x54e5c8){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x3139f8 of this['recaptchaEnforcementState'])if(_0x3139f8['provider']&&_0x3139f8['provider']===_0x54e5c8)return _f(_0x3139f8['enforcementState']);return null;}['isProviderEnabled'](_0x524581){return this['getProviderEnforcementState'](_0x524581)==='ENFORCE'||this['getProviderEnforcementState'](_0x524581)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x1b13c9,_0x2c66b5){return Pe(_0x1b13c9,'GET','/v2/recaptchaConfig',ke(_0x1b13c9,_0x2c66b5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x1b29e4,_0x430428){return Pe(_0x1b29e4,'POST','/v1/accounts:delete',_0x430428);}async function Pn(_0x456ff4,_0xec2163){return Pe(_0x456ff4,'POST','/v1/accounts:lookup',_0xec2163);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x439727){if(_0x439727)try{const _0x227067=new Date(Number(_0x439727));if(!isNaN(_0x227067['getTime']()))return _0x227067['toUTCString']();}catch{}}async function Ef(_0x4b93f7,_0x3274ab=!0x1){const _0x2cb841=P(_0x4b93f7),_0x468e50=await _0x2cb841['getIdToken'](_0x3274ab),_0x4d6617=Ts(_0x468e50);m(_0x4d6617&&_0x4d6617['exp']&&_0x4d6617['auth_time']&&_0x4d6617['iat'],_0x2cb841['auth'],'internal-error');const _0x44f6c0=typeof _0x4d6617['firebase']=='object'?_0x4d6617['firebase']:void 0x0,_0x3447fc=_0x44f6c0==null?void 0x0:_0x44f6c0['sign_in_provider'];return{'claims':_0x4d6617,'token':_0x468e50,'authTime':Pt(fi(_0x4d6617['auth_time'])),'issuedAtTime':Pt(fi(_0x4d6617['iat'])),'expirationTime':Pt(fi(_0x4d6617['exp'])),'signInProvider':_0x3447fc||null,'signInSecondFactor':(_0x44f6c0==null?void 0x0:_0x44f6c0['sign_in_second_factor'])||null};}function fi(_0x49f550){return Number(_0x49f550)*0x3e8;}function Ts(_0x5d8fd5){const [_0x426603,_0x47b38a,_0x39792e]=_0x5d8fd5['split']('.');if(_0x426603===void 0x0||_0x47b38a===void 0x0||_0x39792e===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x358f05=fn(_0x47b38a);return _0x358f05?JSON['parse'](_0x358f05):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5a9640){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5a9640==null?void 0x0:_0x5a9640['toString']()),null;}}function Cr(_0x3de14){const _0x7b50d6=Ts(_0x3de14);return m(_0x7b50d6,'internal-error'),m(typeof _0x7b50d6['exp']<'u','internal-error'),m(typeof _0x7b50d6['iat']<'u','internal-error'),Number(_0x7b50d6['exp'])-Number(_0x7b50d6['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x9e726c,_0x33b735,_0xbf6290=!0x1){if(_0xbf6290)return _0x33b735;try{return await _0x33b735;}catch(_0x8d6175){throw _0x8d6175 instanceof Re&&If(_0x8d6175)&&_0x9e726c['auth']['currentUser']===_0x9e726c&&await _0x9e726c['auth']['signOut'](),_0x8d6175;}}function If({code:_0x29ae7f}){return _0x29ae7f==='auth/user-disabled'||_0x29ae7f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5c30ac){this['user']=_0x5c30ac,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x29ce9f){if(_0x29ce9f){const _0x2684ab=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2684ab;}else{this['errorBackoff']=0x7530;const _0x5d1b5a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5d1b5a);}}['schedule'](_0x5ca402=!0x1){if(!this['isRunning'])return;const _0x130ccc=this['getInterval'](_0x5ca402);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x130ccc);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x560357){(_0x560357==null?void 0x0:_0x560357['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x3a9ebb,_0x4bae9d){this['createdAt']=_0x3a9ebb,this['lastLoginAt']=_0x4bae9d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x27c56b){this['createdAt']=_0x27c56b['createdAt'],this['lastLoginAt']=_0x27c56b['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x24e409){var _0x34d69a;const _0x3dc659=_0x24e409['auth'],_0x58cee5=await _0x24e409['getIdToken'](),_0x525aa1=await Ht(_0x24e409,Pn(_0x3dc659,{'idToken':_0x58cee5}));m(_0x525aa1==null?void 0x0:_0x525aa1['users']['length'],_0x3dc659,'internal-error');const _0x3e7d18=_0x525aa1['users'][0x0];_0x24e409['_notifyReloadListener'](_0x3e7d18);const _0x1b68cb=(_0x34d69a=_0x3e7d18['providerUserInfo'])!=null&&_0x34d69a['length']?Sa(_0x3e7d18['providerUserInfo']):[],_0x220c08=Tf(_0x24e409['providerData'],_0x1b68cb),_0x2163d3=_0x24e409['isAnonymous'],_0x77adc5=!(_0x24e409['email']&&_0x3e7d18['passwordHash'])&&!(_0x220c08!=null&&_0x220c08['length']),_0x52d706=_0x2163d3?_0x77adc5:!0x1,_0x5ca156={'uid':_0x3e7d18['localId'],'displayName':_0x3e7d18['displayName']||null,'photoURL':_0x3e7d18['photoUrl']||null,'email':_0x3e7d18['email']||null,'emailVerified':_0x3e7d18['emailVerified']||!0x1,'phoneNumber':_0x3e7d18['phoneNumber']||null,'tenantId':_0x3e7d18['tenantId']||null,'providerData':_0x220c08,'metadata':new Li(_0x3e7d18['createdAt'],_0x3e7d18['lastLoginAt']),'isAnonymous':_0x52d706};Object['assign'](_0x24e409,_0x5ca156);}async function Cf(_0x4b4819){const _0x3f5a4d=P(_0x4b4819);await Nn(_0x3f5a4d),await _0x3f5a4d['auth']['_persistUserIfCurrent'](_0x3f5a4d),_0x3f5a4d['auth']['_notifyListenersIfCurrent'](_0x3f5a4d);}function Tf(_0x17b0ee,_0xa3830){return[..._0x17b0ee['filter'](_0x48058e=>!_0xa3830['some'](_0x104464=>_0x104464['providerId']===_0x48058e['providerId'])),..._0xa3830];}function Sa(_0x282a9d){return _0x282a9d['map'](({providerId:_0x1bbf5c,..._0x5d0129})=>({'providerId':_0x1bbf5c,'uid':_0x5d0129['rawId']||'','displayName':_0x5d0129['displayName']||null,'email':_0x5d0129['email']||null,'phoneNumber':_0x5d0129['phoneNumber']||null,'photoURL':_0x5d0129['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x41450a,_0x390705){const _0x5cb920=await Ca(_0x41450a,{},async()=>{const _0x95e454=ut({'grant_type':'refresh_token','refresh_token':_0x390705})['slice'](0x1),{tokenApiHost:_0x2101b1,apiKey:_0x552d6a}=_0x41450a['config'],_0x484f24=await Ta(_0x41450a,_0x2101b1,'/v1/token','key='+_0x552d6a),_0x3f1510=await _0x41450a['_getAdditionalHeaders']();_0x3f1510['Content-Type']='application/x-www-form-urlencoded';const _0x2ce623={'method':'POST','headers':_0x3f1510,'body':_0x95e454};return _0x41450a['emulatorConfig']&&qt(_0x41450a['emulatorConfig']['host'])&&(_0x2ce623['credentials']='include'),wa['fetch']()(_0x484f24,_0x2ce623);});return{'accessToken':_0x5cb920['access_token'],'expiresIn':_0x5cb920['expires_in'],'refreshToken':_0x5cb920['refresh_token']};}async function bf(_0x4eb6f6,_0x5ed6f1){return Pe(_0x4eb6f6,'POST','/v2/accounts:revokeToken',ke(_0x4eb6f6,_0x5ed6f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2ad629){m(_0x2ad629['idToken'],'internal-error'),m(typeof _0x2ad629['idToken']<'u','internal-error'),m(typeof _0x2ad629['refreshToken']<'u','internal-error');const _0x5871ac='expiresIn'in _0x2ad629&&typeof _0x2ad629['expiresIn']<'u'?Number(_0x2ad629['expiresIn']):Cr(_0x2ad629['idToken']);this['updateTokensAndExpiration'](_0x2ad629['idToken'],_0x2ad629['refreshToken'],_0x5871ac);}['updateFromIdToken'](_0x2f5919){m(_0x2f5919['length']!==0x0,'internal-error');const _0x1573ce=Cr(_0x2f5919);this['updateTokensAndExpiration'](_0x2f5919,null,_0x1573ce);}async['getToken'](_0x3e6110,_0x3a7574=!0x1){return!_0x3a7574&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3e6110,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3e6110,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x334ee7,_0x4f5402){const {accessToken:_0x842d5f,refreshToken:_0x13cb45,expiresIn:_0x1551f3}=await Sf(_0x334ee7,_0x4f5402);this['updateTokensAndExpiration'](_0x842d5f,_0x13cb45,Number(_0x1551f3));}['updateTokensAndExpiration'](_0x38fc5b,_0x4fb669,_0x29759f){this['refreshToken']=_0x4fb669||null,this['accessToken']=_0x38fc5b||null,this['expirationTime']=Date['now']()+_0x29759f*0x3e8;}static['fromJSON'](_0x51c439,_0x3a7de6){const {refreshToken:_0x18726d,accessToken:_0x238157,expirationTime:_0x514ad8}=_0x3a7de6,_0x58cd64=new et();return _0x18726d&&(m(typeof _0x18726d=='string','internal-error',{'appName':_0x51c439}),_0x58cd64['refreshToken']=_0x18726d),_0x238157&&(m(typeof _0x238157=='string','internal-error',{'appName':_0x51c439}),_0x58cd64['accessToken']=_0x238157),_0x514ad8&&(m(typeof _0x514ad8=='number','internal-error',{'appName':_0x51c439}),_0x58cd64['expirationTime']=_0x514ad8),_0x58cd64;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1c24cc){this['accessToken']=_0x1c24cc['accessToken'],this['refreshToken']=_0x1c24cc['refreshToken'],this['expirationTime']=_0x1c24cc['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x2252c5,_0x26ebe8){m(typeof _0x2252c5=='string'||typeof _0x2252c5>'u','internal-error',{'appName':_0x26ebe8});}class j{constructor({uid:_0x4b6152,auth:_0x576dd2,stsTokenManager:_0x13af7b,..._0x2ba8c1}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x4b6152,this['auth']=_0x576dd2,this['stsTokenManager']=_0x13af7b,this['accessToken']=_0x13af7b['accessToken'],this['displayName']=_0x2ba8c1['displayName']||null,this['email']=_0x2ba8c1['email']||null,this['emailVerified']=_0x2ba8c1['emailVerified']||!0x1,this['phoneNumber']=_0x2ba8c1['phoneNumber']||null,this['photoURL']=_0x2ba8c1['photoURL']||null,this['isAnonymous']=_0x2ba8c1['isAnonymous']||!0x1,this['tenantId']=_0x2ba8c1['tenantId']||null,this['providerData']=_0x2ba8c1['providerData']?[..._0x2ba8c1['providerData']]:[],this['metadata']=new Li(_0x2ba8c1['createdAt']||void 0x0,_0x2ba8c1['lastLoginAt']||void 0x0);}async['getIdToken'](_0x41a2f6){const _0x352010=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x41a2f6));return m(_0x352010,this['auth'],'internal-error'),this['accessToken']!==_0x352010&&(this['accessToken']=_0x352010,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x352010;}['getIdTokenResult'](_0x2e50f8){return Ef(this,_0x2e50f8);}['reload'](){return Cf(this);}['_assign'](_0x295e05){this!==_0x295e05&&(m(this['uid']===_0x295e05['uid'],this['auth'],'internal-error'),this['displayName']=_0x295e05['displayName'],this['photoURL']=_0x295e05['photoURL'],this['email']=_0x295e05['email'],this['emailVerified']=_0x295e05['emailVerified'],this['phoneNumber']=_0x295e05['phoneNumber'],this['isAnonymous']=_0x295e05['isAnonymous'],this['tenantId']=_0x295e05['tenantId'],this['providerData']=_0x295e05['providerData']['map'](_0x382c0b=>({..._0x382c0b})),this['metadata']['_copy'](_0x295e05['metadata']),this['stsTokenManager']['_assign'](_0x295e05['stsTokenManager']));}['_clone'](_0x2ee2e7){const _0x2bc14f=new j({...this,'auth':_0x2ee2e7,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2bc14f['metadata']['_copy'](this['metadata']),_0x2bc14f;}['_onReload'](_0x383d21){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x383d21,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x1fc549){this['reloadListener']?this['reloadListener'](_0x1fc549):this['reloadUserInfo']=_0x1fc549;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3143fb,_0x57bef4=!0x1){let _0x46380e=!0x1;_0x3143fb['idToken']&&_0x3143fb['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3143fb),_0x46380e=!0x0),_0x57bef4&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x46380e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0xbceb08=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0xbceb08})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x39a707=>({..._0x39a707})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x174dd0,_0xb93fe0){const _0x3dcce3=_0xb93fe0['displayName']??void 0x0,_0x54f1b1=_0xb93fe0['email']??void 0x0,_0x34c93a=_0xb93fe0['phoneNumber']??void 0x0,_0x4ff8d0=_0xb93fe0['photoURL']??void 0x0,_0x5db2c8=_0xb93fe0['tenantId']??void 0x0,_0x1d474c=_0xb93fe0['_redirectEventId']??void 0x0,_0x390019=_0xb93fe0['createdAt']??void 0x0,_0x3abf07=_0xb93fe0['lastLoginAt']??void 0x0,{uid:_0x493c1b,emailVerified:_0x364eb9,isAnonymous:_0x14bca1,providerData:_0x3b0523,stsTokenManager:_0xaceeff}=_0xb93fe0;m(_0x493c1b&&_0xaceeff,_0x174dd0,'internal-error');const _0x24c69f=et['fromJSON'](this['name'],_0xaceeff);m(typeof _0x493c1b=='string',_0x174dd0,'internal-error'),le(_0x3dcce3,_0x174dd0['name']),le(_0x54f1b1,_0x174dd0['name']),m(typeof _0x364eb9=='boolean',_0x174dd0,'internal-error'),m(typeof _0x14bca1=='boolean',_0x174dd0,'internal-error'),le(_0x34c93a,_0x174dd0['name']),le(_0x4ff8d0,_0x174dd0['name']),le(_0x5db2c8,_0x174dd0['name']),le(_0x1d474c,_0x174dd0['name']),le(_0x390019,_0x174dd0['name']),le(_0x3abf07,_0x174dd0['name']);const _0x170dde=new j({'uid':_0x493c1b,'auth':_0x174dd0,'email':_0x54f1b1,'emailVerified':_0x364eb9,'displayName':_0x3dcce3,'isAnonymous':_0x14bca1,'photoURL':_0x4ff8d0,'phoneNumber':_0x34c93a,'tenantId':_0x5db2c8,'stsTokenManager':_0x24c69f,'createdAt':_0x390019,'lastLoginAt':_0x3abf07});return _0x3b0523&&Array['isArray'](_0x3b0523)&&(_0x170dde['providerData']=_0x3b0523['map'](_0xcc75a8=>({..._0xcc75a8}))),_0x1d474c&&(_0x170dde['_redirectEventId']=_0x1d474c),_0x170dde;}static async['_fromIdTokenResponse'](_0x292ecb,_0x260db6,_0xa9f7cc=!0x1){const _0x3e1e4d=new et();_0x3e1e4d['updateFromServerResponse'](_0x260db6);const _0x4d3da5=new j({'uid':_0x260db6['localId'],'auth':_0x292ecb,'stsTokenManager':_0x3e1e4d,'isAnonymous':_0xa9f7cc});return await Nn(_0x4d3da5),_0x4d3da5;}static async['_fromGetAccountInfoResponse'](_0x18b7c4,_0x40b9da,_0x2797b1){const _0x51f4e1=_0x40b9da['users'][0x0];m(_0x51f4e1['localId']!==void 0x0,'internal-error');const _0x288c2b=_0x51f4e1['providerUserInfo']!==void 0x0?Sa(_0x51f4e1['providerUserInfo']):[],_0x452c26=!(_0x51f4e1['email']&&_0x51f4e1['passwordHash'])&&!(_0x288c2b!=null&&_0x288c2b['length']),_0x5ed05e=new et();_0x5ed05e['updateFromIdToken'](_0x2797b1);const _0x4d2b8e=new j({'uid':_0x51f4e1['localId'],'auth':_0x18b7c4,'stsTokenManager':_0x5ed05e,'isAnonymous':_0x452c26}),_0x2a760a={'uid':_0x51f4e1['localId'],'displayName':_0x51f4e1['displayName']||null,'photoURL':_0x51f4e1['photoUrl']||null,'email':_0x51f4e1['email']||null,'emailVerified':_0x51f4e1['emailVerified']||!0x1,'phoneNumber':_0x51f4e1['phoneNumber']||null,'tenantId':_0x51f4e1['tenantId']||null,'providerData':_0x288c2b,'metadata':new Li(_0x51f4e1['createdAt'],_0x51f4e1['lastLoginAt']),'isAnonymous':!(_0x51f4e1['email']&&_0x51f4e1['passwordHash'])&&!(_0x288c2b!=null&&_0x288c2b['length'])};return Object['assign'](_0x4d2b8e,_0x2a760a),_0x4d2b8e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x34169f){ce(_0x34169f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x18aed4=Tr['get'](_0x34169f);return _0x18aed4?(ce(_0x18aed4 instanceof _0x34169f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x18aed4):(_0x18aed4=new _0x34169f(),Tr['set'](_0x34169f,_0x18aed4),_0x18aed4);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x5c88c9,_0x4d10dc){this['storage'][_0x5c88c9]=_0x4d10dc;}async['_get'](_0x6c3c22){const _0x4df479=this['storage'][_0x6c3c22];return _0x4df479===void 0x0?null:_0x4df479;}async['_remove'](_0x364920){delete this['storage'][_0x364920];}['_addListener'](_0x31122f,_0x7ecd07){}['_removeListener'](_0x427b30,_0x5baadd){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0xb4a9f4,_0x233d12,_0x1734a4){return'firebase:'+_0xb4a9f4+':'+_0x233d12+':'+_0x1734a4;}class tt{constructor(_0x2fe090,_0x10b681,_0x5604b9){this['persistence']=_0x2fe090,this['auth']=_0x10b681,this['userKey']=_0x5604b9;const {config:_0x1671c4,name:_0x5caa5f}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x1671c4['apiKey'],_0x5caa5f),this['fullPersistenceKey']=ln('persistence',_0x1671c4['apiKey'],_0x5caa5f),this['boundEventHandler']=_0x10b681['_onStorageEvent']['bind'](_0x10b681),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x554382){return this['persistence']['_set'](this['fullUserKey'],_0x554382['toJSON']());}async['getCurrentUser'](){const _0x4717e5=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4717e5)return null;if(typeof _0x4717e5=='string'){const _0x4b648b=await Pn(this['auth'],{'idToken':_0x4717e5})['catch'](()=>{});return _0x4b648b?j['_fromGetAccountInfoResponse'](this['auth'],_0x4b648b,_0x4717e5):null;}return j['_fromJSON'](this['auth'],_0x4717e5);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x43b1de){if(this['persistence']===_0x43b1de)return;const _0x44dc4d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x43b1de,_0x44dc4d)return this['setCurrentUser'](_0x44dc4d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5077f7,_0x1866d1,_0x2e62c8='authUser'){if(!_0x1866d1['length'])return new tt(ie(Sr),_0x5077f7,_0x2e62c8);const _0x49a24f=(await Promise['all'](_0x1866d1['map'](async _0x4df69e=>{if(await _0x4df69e['_isAvailable']())return _0x4df69e;})))['filter'](_0x11e460=>_0x11e460);let _0x23ac3e=_0x49a24f[0x0]||ie(Sr);const _0x3a6070=ln(_0x2e62c8,_0x5077f7['config']['apiKey'],_0x5077f7['name']);let _0x52b972=null;for(const _0x50a2a9 of _0x1866d1)try{const _0x488b3f=await _0x50a2a9['_get'](_0x3a6070);if(_0x488b3f){let _0x76663e;if(typeof _0x488b3f=='string'){const _0x4ac9a8=await Pn(_0x5077f7,{'idToken':_0x488b3f})['catch'](()=>{});if(!_0x4ac9a8)break;_0x76663e=await j['_fromGetAccountInfoResponse'](_0x5077f7,_0x4ac9a8,_0x488b3f);}else _0x76663e=j['_fromJSON'](_0x5077f7,_0x488b3f);_0x50a2a9!==_0x23ac3e&&(_0x52b972=_0x76663e),_0x23ac3e=_0x50a2a9;break;}}catch{}const _0x5d759=_0x49a24f['filter'](_0x723e54=>_0x723e54['_shouldAllowMigration']);return!_0x23ac3e['_shouldAllowMigration']||!_0x5d759['length']?new tt(_0x23ac3e,_0x5077f7,_0x2e62c8):(_0x23ac3e=_0x5d759[0x0],_0x52b972&&await _0x23ac3e['_set'](_0x3a6070,_0x52b972['toJSON']()),await Promise['all'](_0x1866d1['map'](async _0x36ce25=>{if(_0x36ce25!==_0x23ac3e)try{await _0x36ce25['_remove'](_0x3a6070);}catch{}})),new tt(_0x23ac3e,_0x5077f7,_0x2e62c8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x352cef){const _0x519dcd=_0x352cef['toLowerCase']();if(_0x519dcd['includes']('opera/')||_0x519dcd['includes']('opr/')||_0x519dcd['includes']('opios/'))return'Opera';if(Pa(_0x519dcd))return'IEMobile';if(_0x519dcd['includes']('msie')||_0x519dcd['includes']('trident/'))return'IE';if(_0x519dcd['includes']('edge/'))return'Edge';if(Ra(_0x519dcd))return'Firefox';if(_0x519dcd['includes']('silk/'))return'Silk';if(Oa(_0x519dcd))return'Blackberry';if(Da(_0x519dcd))return'Webos';if(Aa(_0x519dcd))return'Safari';if((_0x519dcd['includes']('chrome/')||ka(_0x519dcd))&&!_0x519dcd['includes']('edge/'))return'Chrome';if(Na(_0x519dcd))return'Android';{const _0x5c0a10=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1fc562=_0x352cef['match'](_0x5c0a10);if((_0x1fc562==null?void 0x0:_0x1fc562['length'])===0x2)return _0x1fc562[0x1];}return'Other';}function Ra(_0xe0b527=W()){return/firefox\//i['test'](_0xe0b527);}function Aa(_0x5b0fe1=W()){const _0x19e7a6=_0x5b0fe1['toLowerCase']();return _0x19e7a6['includes']('safari/')&&!_0x19e7a6['includes']('chrome/')&&!_0x19e7a6['includes']('crios/')&&!_0x19e7a6['includes']('android');}function ka(_0x170741=W()){return/crios\//i['test'](_0x170741);}function Pa(_0x508ea7=W()){return/iemobile/i['test'](_0x508ea7);}function Na(_0x293b86=W()){return/android/i['test'](_0x293b86);}function Oa(_0x1e46e8=W()){return/blackberry/i['test'](_0x1e46e8);}function Da(_0x1233d9=W()){return/webos/i['test'](_0x1233d9);}function Ss(_0x595715=W()){return/iphone|ipad|ipod/i['test'](_0x595715)||/macintosh/i['test'](_0x595715)&&/mobile/i['test'](_0x595715);}function Rf(_0x1fa2b3=W()){var _0x2b73d7;return Ss(_0x1fa2b3)&&!!((_0x2b73d7=window['navigator'])!=null&&_0x2b73d7['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0xf6a6f=W()){return Ss(_0xf6a6f)||Na(_0xf6a6f)||Da(_0xf6a6f)||Oa(_0xf6a6f)||/windows phone/i['test'](_0xf6a6f)||Pa(_0xf6a6f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4a6599,_0x365175=[]){let _0x41d6bf;switch(_0x4a6599){case'Browser':_0x41d6bf=br(W());break;case'Worker':_0x41d6bf=br(W())+'-'+_0x4a6599;break;default:_0x41d6bf=_0x4a6599;}const _0x4b4b65=_0x365175['length']?_0x365175['join'](','):'FirebaseCore-web';return _0x41d6bf+'/JsCore/'+dt+'/'+_0x4b4b65;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x286362){this['auth']=_0x286362,this['queue']=[];}['pushCallback'](_0x330128,_0x5c60bf){const _0x37fd12=_0x34cb30=>new Promise((_0x4b151e,_0x5aa231)=>{try{const _0x4a7e94=_0x330128(_0x34cb30);_0x4b151e(_0x4a7e94);}catch(_0x222b4c){_0x5aa231(_0x222b4c);}});_0x37fd12['onAbort']=_0x5c60bf,this['queue']['push'](_0x37fd12);const _0x5bf4da=this['queue']['length']-0x1;return()=>{this['queue'][_0x5bf4da]=()=>Promise['resolve']();};}async['runMiddleware'](_0x26855b){if(this['auth']['currentUser']===_0x26855b)return;const _0x537feb=[];try{for(const _0x302e99 of this['queue'])await _0x302e99(_0x26855b),_0x302e99['onAbort']&&_0x537feb['push'](_0x302e99['onAbort']);}catch(_0x3a23d8){_0x537feb['reverse']();for(const _0x5b82c6 of _0x537feb)try{_0x5b82c6();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3a23d8==null?void 0x0:_0x3a23d8['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x43e1e0,_0x5b01ed={}){return Pe(_0x43e1e0,'GET','/v2/passwordPolicy',ke(_0x43e1e0,_0x5b01ed));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x56684b){var _0xd0392c;const _0x3afd24=_0x56684b['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x3afd24['minPasswordLength']??Nf,_0x3afd24['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x3afd24['maxPasswordLength']),_0x3afd24['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x3afd24['containsLowercaseCharacter']),_0x3afd24['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x3afd24['containsUppercaseCharacter']),_0x3afd24['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x3afd24['containsNumericCharacter']),_0x3afd24['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x3afd24['containsNonAlphanumericCharacter']),this['enforcementState']=_0x56684b['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xd0392c=_0x56684b['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xd0392c['join'](''))??'',this['forceUpgradeOnSignin']=_0x56684b['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x56684b['schemaVersion'];}['validatePassword'](_0x5098d0){const _0xbd3641={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x5098d0,_0xbd3641),this['validatePasswordCharacterOptions'](_0x5098d0,_0xbd3641),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['meetsMinPasswordLength']??!0x0),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['meetsMaxPasswordLength']??!0x0),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['containsLowercaseLetter']??!0x0),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['containsUppercaseLetter']??!0x0),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['containsNumericCharacter']??!0x0),_0xbd3641['isValid']&&(_0xbd3641['isValid']=_0xbd3641['containsNonAlphanumericCharacter']??!0x0),_0xbd3641;}['validatePasswordLengthOptions'](_0x5c0069,_0x5b6361){const _0x3add79=this['customStrengthOptions']['minPasswordLength'],_0x166ff7=this['customStrengthOptions']['maxPasswordLength'];_0x3add79&&(_0x5b6361['meetsMinPasswordLength']=_0x5c0069['length']>=_0x3add79),_0x166ff7&&(_0x5b6361['meetsMaxPasswordLength']=_0x5c0069['length']<=_0x166ff7);}['validatePasswordCharacterOptions'](_0x178657,_0x1b0e70){this['updatePasswordCharacterOptionsStatuses'](_0x1b0e70,!0x1,!0x1,!0x1,!0x1);let _0x430050;for(let _0x14078a=0x0;_0x14078a<_0x178657['length'];_0x14078a++)_0x430050=_0x178657['charAt'](_0x14078a),this['updatePasswordCharacterOptionsStatuses'](_0x1b0e70,_0x430050>='a'&&_0x430050<='z',_0x430050>='A'&&_0x430050<='Z',_0x430050>='0'&&_0x430050<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x430050));}['updatePasswordCharacterOptionsStatuses'](_0x2124e9,_0x132e2a,_0x3a0b33,_0xe97fee,_0x4daad9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2124e9['containsLowercaseLetter']||(_0x2124e9['containsLowercaseLetter']=_0x132e2a)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2124e9['containsUppercaseLetter']||(_0x2124e9['containsUppercaseLetter']=_0x3a0b33)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2124e9['containsNumericCharacter']||(_0x2124e9['containsNumericCharacter']=_0xe97fee)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2124e9['containsNonAlphanumericCharacter']||(_0x2124e9['containsNonAlphanumericCharacter']=_0x4daad9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x1a6884,_0x281f22,_0x1cbf45,_0x5c3993){this['app']=_0x1a6884,this['heartbeatServiceProvider']=_0x281f22,this['appCheckServiceProvider']=_0x1cbf45,this['config']=_0x5c3993,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1a6884['name'],this['clientVersion']=_0x5c3993['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2f7eb0=>this['_resolvePersistenceManagerAvailable']=_0x2f7eb0);}['_initializeWithPersistence'](_0x212f46,_0x1a9f3a){return _0x1a9f3a&&(this['_popupRedirectResolver']=ie(_0x1a9f3a)),this['_initializationPromise']=this['queue'](async()=>{var _0xfe6b80,_0x41dd5f,_0x187bbb;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x212f46),(_0xfe6b80=this['_resolvePersistenceManagerAvailable'])==null||_0xfe6b80['call'](this),!this['_deleted'])){if((_0x41dd5f=this['_popupRedirectResolver'])!=null&&_0x41dd5f['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1a9f3a),this['lastNotifiedUid']=((_0x187bbb=this['currentUser'])==null?void 0x0:_0x187bbb['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1f459a=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1f459a)){if(this['currentUser']&&_0x1f459a&&this['currentUser']['uid']===_0x1f459a['uid']){this['_currentUser']['_assign'](_0x1f459a),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1f459a,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2c4e2d){try{const _0x525eb2=await Pn(this,{'idToken':_0x2c4e2d}),_0x35a62f=await j['_fromGetAccountInfoResponse'](this,_0x525eb2,_0x2c4e2d);await this['directlySetCurrentUser'](_0x35a62f);}catch(_0x349e99){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x349e99),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x34fff8){var _0x213ad8;if($(this['app'])){const _0x3ebc0d=this['app']['settings']['authIdToken'];return _0x3ebc0d?new Promise(_0x256010=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3ebc0d)['then'](_0x256010,_0x256010));}):this['directlySetCurrentUser'](null);}const _0x10f32d=await this['assertedPersistence']['getCurrentUser']();let _0x51b8e9=_0x10f32d,_0x156c4b=!0x1;if(_0x34fff8&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x39c249=(_0x213ad8=this['redirectUser'])==null?void 0x0:_0x213ad8['_redirectEventId'],_0x1d3073=_0x51b8e9==null?void 0x0:_0x51b8e9['_redirectEventId'],_0x494a3f=await this['tryRedirectSignIn'](_0x34fff8);(!_0x39c249||_0x39c249===_0x1d3073)&&(_0x494a3f!=null&&_0x494a3f['user'])&&(_0x51b8e9=_0x494a3f['user'],_0x156c4b=!0x0);}if(!_0x51b8e9)return this['directlySetCurrentUser'](null);if(!_0x51b8e9['_redirectEventId']){if(_0x156c4b)try{await this['beforeStateQueue']['runMiddleware'](_0x51b8e9);}catch(_0x24c4da){_0x51b8e9=_0x10f32d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x24c4da));}return _0x51b8e9?this['reloadAndSetCurrentUserOrClear'](_0x51b8e9):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x51b8e9['_redirectEventId']?this['directlySetCurrentUser'](_0x51b8e9):this['reloadAndSetCurrentUserOrClear'](_0x51b8e9);}async['tryRedirectSignIn'](_0x59bc6d){let _0x5437fe=null;try{_0x5437fe=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x59bc6d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5437fe;}async['reloadAndSetCurrentUserOrClear'](_0x2332b9){try{await Nn(_0x2332b9);}catch(_0x2645b9){if((_0x2645b9==null?void 0x0:_0x2645b9['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2332b9);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1e2f7e){if($(this['app']))return Promise['reject'](re(this));const _0xe620a3=_0x1e2f7e?P(_0x1e2f7e):null;return _0xe620a3&&m(_0xe620a3['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0xe620a3&&_0xe620a3['_clone'](this));}async['_updateCurrentUser'](_0x8b502a,_0x4c8874=!0x1){if(!this['_deleted'])return _0x8b502a&&m(this['tenantId']===_0x8b502a['tenantId'],this,'tenant-id-mismatch'),_0x4c8874||await this['beforeStateQueue']['runMiddleware'](_0x8b502a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x8b502a),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4bde21){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4bde21));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x524f95){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x51390f=this['_getPasswordPolicyInternal']();return _0x51390f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x51390f['validatePassword'](_0x524f95);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x498dba=await Pf(this),_0xb17d4f=new Of(_0x498dba);this['tenantId']===null?this['_projectPasswordPolicy']=_0xb17d4f:this['_tenantPasswordPolicies'][this['tenantId']]=_0xb17d4f;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5a8f35){this['_errorFactory']=new Gt('auth','Firebase',_0x5a8f35());}['onAuthStateChanged'](_0x8d4fba,_0xedbeb2,_0x1cf377){return this['registerStateListener'](this['authStateSubscription'],_0x8d4fba,_0xedbeb2,_0x1cf377);}['beforeAuthStateChanged'](_0x58cad6,_0x34ce9e){return this['beforeStateQueue']['pushCallback'](_0x58cad6,_0x34ce9e);}['onIdTokenChanged'](_0x4635f4,_0x19bec4,_0x4fcb6b){return this['registerStateListener'](this['idTokenSubscription'],_0x4635f4,_0x19bec4,_0x4fcb6b);}['authStateReady'](){return new Promise((_0xa8e29a,_0x3c5634)=>{if(this['currentUser'])_0xa8e29a();else{const _0x38290e=this['onAuthStateChanged'](()=>{_0x38290e(),_0xa8e29a();},_0x3c5634);}});}async['revokeAccessToken'](_0x80ca2f){if(this['currentUser']){const _0x372112=await this['currentUser']['getIdToken'](),_0x54128d={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x80ca2f,'idToken':_0x372112};this['tenantId']!=null&&(_0x54128d['tenantId']=this['tenantId']),await bf(this,_0x54128d);}}['toJSON'](){var _0x5c0a45;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5c0a45=this['_currentUser'])==null?void 0x0:_0x5c0a45['toJSON']()};}async['_setRedirectUser'](_0x4b8032,_0x1ee95e){const _0x27b504=await this['getOrInitRedirectPersistenceManager'](_0x1ee95e);return _0x4b8032===null?_0x27b504['removeCurrentUser']():_0x27b504['setCurrentUser'](_0x4b8032);}async['getOrInitRedirectPersistenceManager'](_0xdacaeb){if(!this['redirectPersistenceManager']){const _0x3fa83b=_0xdacaeb&&ie(_0xdacaeb)||this['_popupRedirectResolver'];m(_0x3fa83b,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3fa83b['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4772dc){var _0x142804,_0x15df41;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x142804=this['_currentUser'])==null?void 0x0:_0x142804['_redirectEventId'])===_0x4772dc?this['_currentUser']:((_0x15df41=this['redirectUser'])==null?void 0x0:_0x15df41['_redirectEventId'])===_0x4772dc?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1ddd27){if(_0x1ddd27===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1ddd27));}['_notifyListenersIfCurrent'](_0x16cae3){_0x16cae3===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5e9259;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x218b04=((_0x5e9259=this['currentUser'])==null?void 0x0:_0x5e9259['uid'])??null;this['lastNotifiedUid']!==_0x218b04&&(this['lastNotifiedUid']=_0x218b04,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x22531f,_0x187735,_0x47217b,_0x3a3273){if(this['_deleted'])return()=>{};const _0x58655e=typeof _0x187735=='function'?_0x187735:_0x187735['next']['bind'](_0x187735);let _0x1841f5=!0x1;const _0x1acd1b=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1acd1b,this,'internal-error'),_0x1acd1b['then'](()=>{_0x1841f5||_0x58655e(this['currentUser']);}),typeof _0x187735=='function'){const _0x4923b8=_0x22531f['addObserver'](_0x187735,_0x47217b,_0x3a3273);return()=>{_0x1841f5=!0x0,_0x4923b8();};}else{const _0x5eba87=_0x22531f['addObserver'](_0x187735);return()=>{_0x1841f5=!0x0,_0x5eba87();};}}async['directlySetCurrentUser'](_0x2de7af){this['currentUser']&&this['currentUser']!==_0x2de7af&&this['_currentUser']['_stopProactiveRefresh'](),_0x2de7af&&this['isProactiveRefreshEnabled']&&_0x2de7af['_startProactiveRefresh'](),this['currentUser']=_0x2de7af,_0x2de7af?await this['assertedPersistence']['setCurrentUser'](_0x2de7af):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x56047e){return this['operations']=this['operations']['then'](_0x56047e,_0x56047e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x456c62){!_0x456c62||this['frameworks']['includes'](_0x456c62)||(this['frameworks']['push'](_0x456c62),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x439d38;const _0x51bee2={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x51bee2['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x569722=await((_0x439d38=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x439d38['getHeartbeatsHeader']());_0x569722&&(_0x51bee2['X-Firebase-Client']=_0x569722);const _0x4df551=await this['_getAppCheckToken']();return _0x4df551&&(_0x51bee2['X-Firebase-AppCheck']=_0x4df551),_0x51bee2;}async['_getAppCheckToken'](){var _0x48b15f;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x83abd1=await((_0x48b15f=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x48b15f['getToken']());return _0x83abd1!=null&&_0x83abd1['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x83abd1['error']),_0x83abd1==null?void 0x0:_0x83abd1['token'];}}function Ke(_0x4ae492){return P(_0x4ae492);}class Rr{constructor(_0x2a7acc){this['auth']=_0x2a7acc,this['observer']=null,this['addObserver']=Tc(_0x1a18d2=>this['observer']=_0x1a18d2);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x28eb70){Jn=_0x28eb70;}function xa(_0xc974d7){return Jn['loadJS'](_0xc974d7);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x197f1d){return'__'+_0x197f1d+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x168347){_0x168347();}['execute'](_0x5c5480,_0x1fae3a){return Promise['resolve']('token');}['render'](_0xd37799,_0x31a554){return'';}}class Wf{['ready'](_0x3e56c4){_0x3e56c4();}['execute'](_0x5ae5f5,_0x18f07c){return Promise['resolve']('token');}['render'](_0x53d13e,_0x47c8eb){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x1df91e){this['type']=Bf,this['auth']=Ke(_0x1df91e);}async['verify'](_0xcc86eb='verify',_0x5b53f6=!0x1){async function _0x101a54(_0x42c817){if(!_0x5b53f6){if(_0x42c817['tenantId']==null&&_0x42c817['_agentRecaptchaConfig']!=null)return _0x42c817['_agentRecaptchaConfig']['siteKey'];if(_0x42c817['tenantId']!=null&&_0x42c817['_tenantRecaptchaConfigs'][_0x42c817['tenantId']]!==void 0x0)return _0x42c817['_tenantRecaptchaConfigs'][_0x42c817['tenantId']]['siteKey'];}return new Promise(async(_0x4edc98,_0x4de4bc)=>{yf(_0x42c817,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x549b31=>{if(_0x549b31['recaptchaKey']===void 0x0)_0x4de4bc(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4715f1=new mf(_0x549b31);return _0x42c817['tenantId']==null?_0x42c817['_agentRecaptchaConfig']=_0x4715f1:_0x42c817['_tenantRecaptchaConfigs'][_0x42c817['tenantId']]=_0x4715f1,_0x4edc98(_0x4715f1['siteKey']);}})['catch'](_0x1a79b7=>{_0x4de4bc(_0x1a79b7);});});}function _0x5a2fe6(_0x4d0048,_0x1eb16b,_0x4789bc){const _0x498de7=window['grecaptcha'];wr(_0x498de7)?_0x498de7['enterprise']['ready'](()=>{_0x498de7['enterprise']['execute'](_0x4d0048,{'action':_0xcc86eb})['then'](_0x2f7a22=>{_0x1eb16b(_0x2f7a22);})['catch'](()=>{_0x1eb16b(Fa);});}):_0x4789bc(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4f2286,_0x4f2fce)=>{_0x101a54(this['auth'])['then'](async _0xca275b=>{if(!_0x5b53f6&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x5a2fe6(_0xca275b,_0x4f2286,_0x4f2fce);else{if(typeof window>'u'){_0x4f2fce(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5211e1=Lf();_0x5211e1['length']!==0x0&&(_0x5211e1+=_0xca275b+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x25193b;(_0x25193b=he['scriptInjectionDeferred'])==null||_0x25193b['resolve']();},xa(_0x5211e1)['then'](()=>{var _0x481374;return(_0x481374=he['scriptInjectionDeferred'])==null?void 0x0:_0x481374['promise'];})['then'](()=>{_0x5a2fe6(_0xca275b,_0x4f2286,_0x4f2fce);})['catch'](_0x639f4=>{_0x4f2fce(_0x639f4);});}})['catch'](_0x1a7b5e=>{_0x4f2fce(_0x1a7b5e);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x20f8fc,_0x1d1db5,_0x3fd195,_0x2244aa=!0x1,_0x2cc34c=!0x1){const _0x14559c=new he(_0x20f8fc);let _0xa4da;if(_0x2cc34c)_0xa4da=Fa;else try{_0xa4da=await _0x14559c['verify'](_0x3fd195);}catch{_0xa4da=await _0x14559c['verify'](_0x3fd195,!0x0);}const _0x587090={..._0x1d1db5};if(_0x3fd195==='mfaSmsEnrollment'||_0x3fd195==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x587090){const _0x362c5c=_0x587090['phoneEnrollmentInfo']['phoneNumber'],_0x269eb4=_0x587090['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x587090,{'phoneEnrollmentInfo':{'phoneNumber':_0x362c5c,'recaptchaToken':_0x269eb4,'captchaResponse':_0xa4da,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x587090){const _0x58daba=_0x587090['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x587090,{'phoneSignInInfo':{'recaptchaToken':_0x58daba,'captchaResponse':_0xa4da,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x587090;}return _0x2244aa?Object['assign'](_0x587090,{'captchaResp':_0xa4da}):Object['assign'](_0x587090,{'captchaResponse':_0xa4da}),Object['assign'](_0x587090,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x587090,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x587090;}async function xi(_0x2c339c,_0x4a34dd,_0xf74090,_0x1fe42f,_0x3efefc){var _0x532ef3;if((_0x532ef3=_0x2c339c['_getRecaptchaConfig']())!=null&&_0x532ef3['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1326a3=await kr(_0x2c339c,_0x4a34dd,_0xf74090,_0xf74090==='getOobCode');return _0x1fe42f(_0x2c339c,_0x1326a3);}else return _0x1fe42f(_0x2c339c,_0x4a34dd)['catch'](async _0x1aedd1=>{if(_0x1aedd1['code']==='auth/missing-recaptcha-token'){console['log'](_0xf74090+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x350462=await kr(_0x2c339c,_0x4a34dd,_0xf74090,_0xf74090==='getOobCode');return _0x1fe42f(_0x2c339c,_0x350462);}else return Promise['reject'](_0x1aedd1);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x42cff5,_0xe6166b){const _0x2241f1=Hi(_0x42cff5,'auth');if(_0x2241f1['isInitialized']()){const _0x441dc3=_0x2241f1['getImmediate'](),_0x2819dc=_0x2241f1['getOptions']();if(xe(_0x2819dc,_0xe6166b??{}))return _0x441dc3;Y(_0x441dc3,'already-initialized');}return _0x2241f1['initialize']({'options':_0xe6166b});}function Hf(_0x488c58,_0xf63798){const _0x55a791=(_0xf63798==null?void 0x0:_0xf63798['persistence'])||[],_0x314209=(Array['isArray'](_0x55a791)?_0x55a791:[_0x55a791])['map'](ie);_0xf63798!=null&&_0xf63798['errorMap']&&_0x488c58['_updateErrorMap'](_0xf63798['errorMap']),_0x488c58['_initializeWithPersistence'](_0x314209,_0xf63798==null?void 0x0:_0xf63798['popupRedirectResolver']);}function $f(_0x2ad666,_0x22c8ea,_0x388bb7){const _0x4c5215=Ke(_0x2ad666);m(/^https?:\/\//['test'](_0x22c8ea),_0x4c5215,'invalid-emulator-scheme');const _0x59e5aa=!0x1,_0x5074aa=Ua(_0x22c8ea),{host:_0xbbfbf6,port:_0x3efd2b}=Gf(_0x22c8ea),_0x2ab202=_0x3efd2b===null?'':':'+_0x3efd2b,_0x295592={'url':_0x5074aa+'//'+_0xbbfbf6+_0x2ab202+'/'},_0x53523a=Object['freeze']({'host':_0xbbfbf6,'port':_0x3efd2b,'protocol':_0x5074aa['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x59e5aa})});if(!_0x4c5215['_canInitEmulator']){m(_0x4c5215['config']['emulator']&&_0x4c5215['emulatorConfig'],_0x4c5215,'emulator-config-failed'),m(xe(_0x295592,_0x4c5215['config']['emulator'])&&xe(_0x53523a,_0x4c5215['emulatorConfig']),_0x4c5215,'emulator-config-failed');return;}_0x4c5215['config']['emulator']=_0x295592,_0x4c5215['emulatorConfig']=_0x53523a,_0x4c5215['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0xbbfbf6)?Qr(_0x5074aa+'//'+_0xbbfbf6+_0x2ab202):qf();}function Ua(_0x2f0363){const _0x392bc2=_0x2f0363['indexOf'](':');return _0x392bc2<0x0?'':_0x2f0363['substr'](0x0,_0x392bc2+0x1);}function Gf(_0x34bf96){const _0x29cbbb=Ua(_0x34bf96),_0x3024e1=/(\/\/)?([^?#/]+)/['exec'](_0x34bf96['substr'](_0x29cbbb['length']));if(!_0x3024e1)return{'host':'','port':null};const _0x5b0946=_0x3024e1[0x2]['split']('@')['pop']()||'',_0x4e82c3=/^(\[[^\]]+\])(:|$)/['exec'](_0x5b0946);if(_0x4e82c3){const _0x32e201=_0x4e82c3[0x1];return{'host':_0x32e201,'port':Pr(_0x5b0946['substr'](_0x32e201['length']+0x1))};}else{const [_0x4fb37c,_0x448c05]=_0x5b0946['split'](':');return{'host':_0x4fb37c,'port':Pr(_0x448c05)};}}function Pr(_0x39e050){if(!_0x39e050)return null;const _0x2141ef=Number(_0x39e050);return isNaN(_0x2141ef)?null:_0x2141ef;}function qf(){function _0xe5e177(){const _0x439286=document['createElement']('p'),_0x1a8948=_0x439286['style'];_0x439286['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x1a8948['position']='fixed',_0x1a8948['width']='100%',_0x1a8948['backgroundColor']='#ffffff',_0x1a8948['border']='.1em\x20solid\x20#000000',_0x1a8948['color']='#b50000',_0x1a8948['bottom']='0px',_0x1a8948['left']='0px',_0x1a8948['margin']='0px',_0x1a8948['zIndex']='10000',_0x1a8948['textAlign']='center',_0x439286['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x439286);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xe5e177):_0xe5e177());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x2581e7,_0x49da66){this['providerId']=_0x2581e7,this['signInMethod']=_0x49da66;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x362da9){return ne('not\x20implemented');}['_linkToIdToken'](_0x2fe242,_0x7e5ada){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x3193dd){return ne('not\x20implemented');}}async function zf(_0xc47caf,_0x391959){return Pe(_0xc47caf,'POST','/v1/accounts:signUp',_0x391959);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x4c44e9,_0x5826f1){return en(_0x4c44e9,'POST','/v1/accounts:signInWithPassword',ke(_0x4c44e9,_0x5826f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x55206c,_0x221a8b){return en(_0x55206c,'POST','/v1/accounts:signInWithEmailLink',ke(_0x55206c,_0x221a8b));}async function Yf(_0x305c73,_0x25faae){return en(_0x305c73,'POST','/v1/accounts:signInWithEmailLink',ke(_0x305c73,_0x25faae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x4b2d5e,_0x31d7ec,_0x237251,_0x1c1dbc=null){super('password',_0x237251),this['_email']=_0x4b2d5e,this['_password']=_0x31d7ec,this['_tenantId']=_0x1c1dbc;}static['_fromEmailAndPassword'](_0x3444b5,_0x3cc624){return new $t(_0x3444b5,_0x3cc624,'password');}static['_fromEmailAndCode'](_0x126ea7,_0x5970c5,_0x580eeb=null){return new $t(_0x126ea7,_0x5970c5,'emailLink',_0x580eeb);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x485956){const _0x55a9d2=typeof _0x485956=='string'?JSON['parse'](_0x485956):_0x485956;if(_0x55a9d2!=null&&_0x55a9d2['email']&&(_0x55a9d2!=null&&_0x55a9d2['password'])){if(_0x55a9d2['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x55a9d2['email'],_0x55a9d2['password']);if(_0x55a9d2['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x55a9d2['email'],_0x55a9d2['password'],_0x55a9d2['tenantId']);}return null;}async['_getIdTokenResponse'](_0x2b10b7){switch(this['signInMethod']){case'password':const _0x1fe3c2={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2b10b7,_0x1fe3c2,'signInWithPassword',jf);case'emailLink':return Kf(_0x2b10b7,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2b10b7,'internal-error');}}async['_linkToIdToken'](_0x1a38f9,_0x3fd591){switch(this['signInMethod']){case'password':const _0x35df89={'idToken':_0x3fd591,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1a38f9,_0x35df89,'signUpPassword',zf);case'emailLink':return Yf(_0x1a38f9,{'idToken':_0x3fd591,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1a38f9,'internal-error');}}['_getReauthenticationResolver'](_0x27e10c){return this['_getIdTokenResponse'](_0x27e10c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x13b31d,_0x4c1bbd){return en(_0x13b31d,'POST','/v1/accounts:signInWithIdp',ke(_0x13b31d,_0x4c1bbd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x12010a){const _0x5007c2=new $e(_0x12010a['providerId'],_0x12010a['signInMethod']);return _0x12010a['idToken']||_0x12010a['accessToken']?(_0x12010a['idToken']&&(_0x5007c2['idToken']=_0x12010a['idToken']),_0x12010a['accessToken']&&(_0x5007c2['accessToken']=_0x12010a['accessToken']),_0x12010a['nonce']&&!_0x12010a['pendingToken']&&(_0x5007c2['nonce']=_0x12010a['nonce']),_0x12010a['pendingToken']&&(_0x5007c2['pendingToken']=_0x12010a['pendingToken'])):_0x12010a['oauthToken']&&_0x12010a['oauthTokenSecret']?(_0x5007c2['accessToken']=_0x12010a['oauthToken'],_0x5007c2['secret']=_0x12010a['oauthTokenSecret']):Y('argument-error'),_0x5007c2;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x32c34e){const _0x2a2053=typeof _0x32c34e=='string'?JSON['parse'](_0x32c34e):_0x32c34e,{providerId:_0x147773,signInMethod:_0x286faa,..._0xe8fc96}=_0x2a2053;if(!_0x147773||!_0x286faa)return null;const _0x2a9426=new $e(_0x147773,_0x286faa);return _0x2a9426['idToken']=_0xe8fc96['idToken']||void 0x0,_0x2a9426['accessToken']=_0xe8fc96['accessToken']||void 0x0,_0x2a9426['secret']=_0xe8fc96['secret'],_0x2a9426['nonce']=_0xe8fc96['nonce'],_0x2a9426['pendingToken']=_0xe8fc96['pendingToken']||null,_0x2a9426;}['_getIdTokenResponse'](_0x3550b6){const _0x1a3ad7=this['buildRequest']();return nt(_0x3550b6,_0x1a3ad7);}['_linkToIdToken'](_0x2f561c,_0x518c45){const _0xe4dc2b=this['buildRequest']();return _0xe4dc2b['idToken']=_0x518c45,nt(_0x2f561c,_0xe4dc2b);}['_getReauthenticationResolver'](_0x3f3aa5){const _0x4f22fe=this['buildRequest']();return _0x4f22fe['autoCreate']=!0x1,nt(_0x3f3aa5,_0x4f22fe);}['buildRequest'](){const _0x33fbcd={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x33fbcd['pendingToken']=this['pendingToken'];else{const _0x598a21={};this['idToken']&&(_0x598a21['id_token']=this['idToken']),this['accessToken']&&(_0x598a21['access_token']=this['accessToken']),this['secret']&&(_0x598a21['oauth_token_secret']=this['secret']),_0x598a21['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x598a21['nonce']=this['nonce']),_0x33fbcd['postBody']=ut(_0x598a21);}return _0x33fbcd;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x25d871){switch(_0x25d871){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x21318d){const _0x3153ad=Ct(Tt(_0x21318d))['link'],_0x23f6b9=_0x3153ad?Ct(Tt(_0x3153ad))['deep_link_id']:null,_0x3127a5=Ct(Tt(_0x21318d))['deep_link_id'];return(_0x3127a5?Ct(Tt(_0x3127a5))['link']:null)||_0x3127a5||_0x23f6b9||_0x3153ad||_0x21318d;}class Rs{constructor(_0x5612b2){const _0x5b3d3c=Ct(Tt(_0x5612b2)),_0x5cc044=_0x5b3d3c['apiKey']??null,_0x954964=_0x5b3d3c['oobCode']??null,_0x12242e=Jf(_0x5b3d3c['mode']??null);m(_0x5cc044&&_0x954964&&_0x12242e,'argument-error'),this['apiKey']=_0x5cc044,this['operation']=_0x12242e,this['code']=_0x954964,this['continueUrl']=_0x5b3d3c['continueUrl']??null,this['languageCode']=_0x5b3d3c['lang']??null,this['tenantId']=_0x5b3d3c['tenantId']??null;}static['parseLink'](_0x5da104){const _0x1cf36e=Xf(_0x5da104);try{return new Rs(_0x1cf36e);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x1e6590,_0x2e7d66){return $t['_fromEmailAndPassword'](_0x1e6590,_0x2e7d66);}static['credentialWithLink'](_0x115198,_0x37152b){const _0x3e442b=Rs['parseLink'](_0x37152b);return m(_0x3e442b,'argument-error'),$t['_fromEmailAndCode'](_0x115198,_0x3e442b['code'],_0x3e442b['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3e50bb){this['providerId']=_0x3e50bb,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1f9e8f){this['defaultLanguageCode']=_0x1f9e8f;}['setCustomParameters'](_0x20ade7){return this['customParameters']=_0x20ade7,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x21d77e){return this['scopes']['includes'](_0x21d77e)||this['scopes']['push'](_0x21d77e),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5aaac6){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5aaac6});}static['credentialFromResult'](_0x23cd32){return ue['credentialFromTaggedObject'](_0x23cd32);}static['credentialFromError'](_0x2c3e5){return ue['credentialFromTaggedObject'](_0x2c3e5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xe9caa2}){if(!_0xe9caa2||!('oauthAccessToken'in _0xe9caa2)||!_0xe9caa2['oauthAccessToken'])return null;try{return ue['credential'](_0xe9caa2['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x28fa77,_0x3ea2d3){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x28fa77,'accessToken':_0x3ea2d3});}static['credentialFromResult'](_0x3cd211){return de['credentialFromTaggedObject'](_0x3cd211);}static['credentialFromError'](_0x5d6993){return de['credentialFromTaggedObject'](_0x5d6993['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1d03e7}){if(!_0x1d03e7)return null;const {oauthIdToken:_0x5394d6,oauthAccessToken:_0x482781}=_0x1d03e7;if(!_0x5394d6&&!_0x482781)return null;try{return de['credential'](_0x5394d6,_0x482781);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x512526){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x512526});}static['credentialFromResult'](_0x40319c){return fe['credentialFromTaggedObject'](_0x40319c);}static['credentialFromError'](_0x28d8ba){return fe['credentialFromTaggedObject'](_0x28d8ba['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x16e417}){if(!_0x16e417||!('oauthAccessToken'in _0x16e417)||!_0x16e417['oauthAccessToken'])return null;try{return fe['credential'](_0x16e417['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x1b456f,_0x37510b){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1b456f,'oauthTokenSecret':_0x37510b});}static['credentialFromResult'](_0x149f09){return pe['credentialFromTaggedObject'](_0x149f09);}static['credentialFromError'](_0x27c5c5){return pe['credentialFromTaggedObject'](_0x27c5c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x115e87}){if(!_0x115e87)return null;const {oauthAccessToken:_0x50f794,oauthTokenSecret:_0x6e7163}=_0x115e87;if(!_0x50f794||!_0x6e7163)return null;try{return pe['credential'](_0x50f794,_0x6e7163);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x529b05,_0x145132){return en(_0x529b05,'POST','/v1/accounts:signUp',ke(_0x529b05,_0x145132));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x7002e4){this['user']=_0x7002e4['user'],this['providerId']=_0x7002e4['providerId'],this['_tokenResponse']=_0x7002e4['_tokenResponse'],this['operationType']=_0x7002e4['operationType'];}static async['_fromIdTokenResponse'](_0x457517,_0x44624c,_0x3e0fc0,_0x4be22a=!0x1){const _0x5eaf3d=await j['_fromIdTokenResponse'](_0x457517,_0x3e0fc0,_0x4be22a),_0x5afef6=Nr(_0x3e0fc0);return new Ge({'user':_0x5eaf3d,'providerId':_0x5afef6,'_tokenResponse':_0x3e0fc0,'operationType':_0x44624c});}static async['_forOperation'](_0x156cdb,_0x13369d,_0x3913fa){await _0x156cdb['_updateTokensIfNecessary'](_0x3913fa,!0x0);const _0x1eb799=Nr(_0x3913fa);return new Ge({'user':_0x156cdb,'providerId':_0x1eb799,'_tokenResponse':_0x3913fa,'operationType':_0x13369d});}}function Nr(_0x20bda3){return _0x20bda3['providerId']?_0x20bda3['providerId']:'phoneNumber'in _0x20bda3?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x130ab6,_0x291744,_0x2e3ac1,_0x22dbdd){super(_0x291744['code'],_0x291744['message']),this['operationType']=_0x2e3ac1,this['user']=_0x22dbdd,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x130ab6['name'],'tenantId':_0x130ab6['tenantId']??void 0x0,'_serverResponse':_0x291744['customData']['_serverResponse'],'operationType':_0x2e3ac1};}static['_fromErrorAndOperation'](_0x63a983,_0x1fe1da,_0xadd56,_0x1e3741){return new On(_0x63a983,_0x1fe1da,_0xadd56,_0x1e3741);}}function Ba(_0x5aa591,_0x3bdc2a,_0xb78986,_0x50c437){return(_0x3bdc2a==='reauthenticate'?_0xb78986['_getReauthenticationResolver'](_0x5aa591):_0xb78986['_getIdTokenResponse'](_0x5aa591))['catch'](_0x264b1d=>{throw _0x264b1d['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x5aa591,_0x264b1d,_0x3bdc2a,_0x50c437):_0x264b1d;});}async function ep(_0x298163,_0x87a8b9,_0x1ba837=!0x1){const _0x5111ac=await Ht(_0x298163,_0x87a8b9['_linkToIdToken'](_0x298163['auth'],await _0x298163['getIdToken']()),_0x1ba837);return Ge['_forOperation'](_0x298163,'link',_0x5111ac);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x15b8ab,_0x4b5cae,_0x194ffb=!0x1){const {auth:_0x3046ca}=_0x15b8ab;if($(_0x3046ca['app']))return Promise['reject'](re(_0x3046ca));const _0x5bc610='reauthenticate';try{const _0x5e5653=await Ht(_0x15b8ab,Ba(_0x3046ca,_0x5bc610,_0x4b5cae,_0x15b8ab),_0x194ffb);m(_0x5e5653['idToken'],_0x3046ca,'internal-error');const _0x304647=Ts(_0x5e5653['idToken']);m(_0x304647,_0x3046ca,'internal-error');const {sub:_0x53d8b1}=_0x304647;return m(_0x15b8ab['uid']===_0x53d8b1,_0x3046ca,'user-mismatch'),Ge['_forOperation'](_0x15b8ab,_0x5bc610,_0x5e5653);}catch(_0x4dd560){throw(_0x4dd560==null?void 0x0:_0x4dd560['code'])==='auth/user-not-found'&&Y(_0x3046ca,'user-mismatch'),_0x4dd560;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2d977d,_0x1fe518,_0x5cd84d=!0x1){if($(_0x2d977d['app']))return Promise['reject'](re(_0x2d977d));const _0x392845='signIn',_0x296918=await Ba(_0x2d977d,_0x392845,_0x1fe518),_0x3af5b7=await Ge['_fromIdTokenResponse'](_0x2d977d,_0x392845,_0x296918);return _0x5cd84d||await _0x2d977d['_updateCurrentUser'](_0x3af5b7['user']),_0x3af5b7;}async function np(_0x2cc6f6,_0x137c66){return Va(Ke(_0x2cc6f6),_0x137c66);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x16a343){const _0x1ec39=Ke(_0x16a343);_0x1ec39['_getPasswordPolicyInternal']()&&await _0x1ec39['_updatePasswordPolicy']();}async function L_(_0x128a15,_0x1486c7,_0x341b49){if($(_0x128a15['app']))return Promise['reject'](re(_0x128a15));const _0x3ab325=Ke(_0x128a15),_0x5dbb32=await xi(_0x3ab325,{'returnSecureToken':!0x0,'email':_0x1486c7,'password':_0x341b49,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x379d86=>{throw _0x379d86['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x128a15),_0x379d86;}),_0x537a41=await Ge['_fromIdTokenResponse'](_0x3ab325,'signIn',_0x5dbb32);return await _0x3ab325['_updateCurrentUser'](_0x537a41['user']),_0x537a41;}function x_(_0x15b57f,_0x147690,_0x4f4471){return $(_0x15b57f['app'])?Promise['reject'](re(_0x15b57f)):np(P(_0x15b57f),yt['credential'](_0x147690,_0x4f4471))['catch'](async _0xf2cb8f=>{throw _0xf2cb8f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x15b57f),_0xf2cb8f;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x47caaf,_0x2f99a6){return P(_0x47caaf)['setPersistence'](_0x2f99a6);}function ip(_0x610792,_0x54563a,_0x5587b4,_0x2eb10f){return P(_0x610792)['onIdTokenChanged'](_0x54563a,_0x5587b4,_0x2eb10f);}function sp(_0x3c7702,_0x3bf9eb,_0x3fba51){return P(_0x3c7702)['beforeAuthStateChanged'](_0x3bf9eb,_0x3fba51);}function U_(_0xffdad8,_0x24fa55,_0x5f1194,_0x2d7ca6){return P(_0xffdad8)['onAuthStateChanged'](_0x24fa55,_0x5f1194,_0x2d7ca6);}function W_(_0x2816bf){return P(_0x2816bf)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x367ab7,_0x4baf15){this['storageRetriever']=_0x367ab7,this['type']=_0x4baf15;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x56380b,_0x51f9dc){return this['storage']['setItem'](_0x56380b,JSON['stringify'](_0x51f9dc)),Promise['resolve']();}['_get'](_0x4a6fdc){const _0xd94b9d=this['storage']['getItem'](_0x4a6fdc);return Promise['resolve'](_0xd94b9d?JSON['parse'](_0xd94b9d):null);}['_remove'](_0x48ee96){return this['storage']['removeItem'](_0x48ee96),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x492a47,_0x5600f3)=>this['onStorageEvent'](_0x492a47,_0x5600f3),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x12a4f7){for(const _0x59b97c of Object['keys'](this['listeners'])){const _0x228356=this['storage']['getItem'](_0x59b97c),_0xcca38a=this['localCache'][_0x59b97c];_0x228356!==_0xcca38a&&_0x12a4f7(_0x59b97c,_0xcca38a,_0x228356);}}['onStorageEvent'](_0x585e97,_0x52751d=!0x1){if(!_0x585e97['key']){this['forAllChangedKeys']((_0x52313d,_0x248385,_0x31ffc0)=>{this['notifyListeners'](_0x52313d,_0x31ffc0);});return;}const _0x543e29=_0x585e97['key'];_0x52751d?this['detachListener']():this['stopPolling']();const _0x5bb51c=()=>{const _0x308d8e=this['storage']['getItem'](_0x543e29);!_0x52751d&&this['localCache'][_0x543e29]===_0x308d8e||this['notifyListeners'](_0x543e29,_0x308d8e);},_0x3e0263=this['storage']['getItem'](_0x543e29);Af()&&_0x3e0263!==_0x585e97['newValue']&&_0x585e97['newValue']!==_0x585e97['oldValue']?setTimeout(_0x5bb51c,op):_0x5bb51c();}['notifyListeners'](_0x253e15,_0x222f6f){this['localCache'][_0x253e15]=_0x222f6f;const _0x1f687b=this['listeners'][_0x253e15];if(_0x1f687b){for(const _0x4bd407 of Array['from'](_0x1f687b))_0x4bd407(_0x222f6f&&JSON['parse'](_0x222f6f));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x50a556,_0x378e7b,_0x4314ad)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x50a556,'oldValue':_0x378e7b,'newValue':_0x4314ad}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x5cba3c,_0x311d6c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x5cba3c]||(this['listeners'][_0x5cba3c]=new Set(),this['localCache'][_0x5cba3c]=this['storage']['getItem'](_0x5cba3c)),this['listeners'][_0x5cba3c]['add'](_0x311d6c);}['_removeListener'](_0x421379,_0x3e0a8c){this['listeners'][_0x421379]&&(this['listeners'][_0x421379]['delete'](_0x3e0a8c),this['listeners'][_0x421379]['size']===0x0&&delete this['listeners'][_0x421379]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x15cad2,_0x3214de){await super['_set'](_0x15cad2,_0x3214de),this['localCache'][_0x15cad2]=JSON['stringify'](_0x3214de);}async['_get'](_0x380e0f){const _0x10b893=await super['_get'](_0x380e0f);return this['localCache'][_0x380e0f]=JSON['stringify'](_0x10b893),_0x10b893;}async['_remove'](_0x26881e){await super['_remove'](_0x26881e),delete this['localCache'][_0x26881e];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1236b2,_0x3125b4){}['_removeListener'](_0x278653,_0x1509da){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2b10be){return Promise['all'](_0x2b10be['map'](async _0xcf275b=>{try{return{'fulfilled':!0x0,'value':await _0xcf275b};}catch(_0x445509){return{'fulfilled':!0x1,'reason':_0x445509};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4ab27f){this['eventTarget']=_0x4ab27f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xe46fed){const _0x405e3c=this['receivers']['find'](_0x2b3d3a=>_0x2b3d3a['isListeningto'](_0xe46fed));if(_0x405e3c)return _0x405e3c;const _0x22e417=new Xn(_0xe46fed);return this['receivers']['push'](_0x22e417),_0x22e417;}['isListeningto'](_0x22dfcb){return this['eventTarget']===_0x22dfcb;}async['handleEvent'](_0x19c275){const _0x40d178=_0x19c275,{eventId:_0x4dce63,eventType:_0x5a392a,data:_0x5f5baa}=_0x40d178['data'],_0x627a79=this['handlersMap'][_0x5a392a];if(!(_0x627a79!=null&&_0x627a79['size']))return;_0x40d178['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4dce63,'eventType':_0x5a392a});const _0x5d5a73=Array['from'](_0x627a79)['map'](async _0x30c92a=>_0x30c92a(_0x40d178['origin'],_0x5f5baa)),_0x20b6db=await cp(_0x5d5a73);_0x40d178['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4dce63,'eventType':_0x5a392a,'response':_0x20b6db});}['_subscribe'](_0x71dadf,_0x1c859){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x71dadf]||(this['handlersMap'][_0x71dadf]=new Set()),this['handlersMap'][_0x71dadf]['add'](_0x1c859);}['_unsubscribe'](_0x2d7444,_0x1095ba){this['handlersMap'][_0x2d7444]&&_0x1095ba&&this['handlersMap'][_0x2d7444]['delete'](_0x1095ba),(!_0x1095ba||this['handlersMap'][_0x2d7444]['size']===0x0)&&delete this['handlersMap'][_0x2d7444],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x55aa5b='',_0x2b97b6=0xa){let _0x3505d7='';for(let _0x250df1=0x0;_0x250df1<_0x2b97b6;_0x250df1++)_0x3505d7+=Math['floor'](Math['random']()*0xa);return _0x55aa5b+_0x3505d7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x112ac8){this['target']=_0x112ac8,this['handlers']=new Set();}['removeMessageHandler'](_0xc15a7){_0xc15a7['messageChannel']&&(_0xc15a7['messageChannel']['port1']['removeEventListener']('message',_0xc15a7['onMessage']),_0xc15a7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0xc15a7);}async['_send'](_0x504178,_0x565e00,_0x2db71e=0x32){const _0x2d7145=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2d7145)throw new Error('connection_unavailable');let _0x367582,_0x47d735;return new Promise((_0x37b77b,_0x301096)=>{const _0x381bb3=As('',0x14);_0x2d7145['port1']['start']();const _0x4a6878=setTimeout(()=>{_0x301096(new Error('unsupported_event'));},_0x2db71e);_0x47d735={'messageChannel':_0x2d7145,'onMessage'(_0x4b291e){const _0x382732=_0x4b291e;if(_0x382732['data']['eventId']===_0x381bb3)switch(_0x382732['data']['status']){case'ack':clearTimeout(_0x4a6878),_0x367582=setTimeout(()=>{_0x301096(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x367582),_0x37b77b(_0x382732['data']['response']);break;default:clearTimeout(_0x4a6878),clearTimeout(_0x367582),_0x301096(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x47d735),_0x2d7145['port1']['addEventListener']('message',_0x47d735['onMessage']),this['target']['postMessage']({'eventType':_0x504178,'eventId':_0x381bb3,'data':_0x565e00},[_0x2d7145['port2']]);})['finally'](()=>{_0x47d735&&this['removeMessageHandler'](_0x47d735);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x148793){Z()['location']['href']=_0x148793;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x3d924;return((_0x3d924=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3d924['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x3b9344){this['request']=_0x3b9344;}['toPromise'](){return new Promise((_0x3328ca,_0x46b347)=>{this['request']['addEventListener']('success',()=>{_0x3328ca(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x46b347(this['request']['error']);});});}}function Zn(_0x1ef2be,_0x2daacb){return _0x1ef2be['transaction']([Mn],_0x2daacb?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x2560c8=indexedDB['deleteDatabase'](Ka);return new nn(_0x2560c8)['toPromise']();}function Qa(){const _0xd01df9=indexedDB['open'](Ka,pp);return new Promise((_0x4ef30d,_0x3dad38)=>{_0xd01df9['addEventListener']('error',()=>{_0x3dad38(_0xd01df9['error']);}),_0xd01df9['addEventListener']('upgradeneeded',()=>{const _0x162404=_0xd01df9['result'];try{_0x162404['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4ad8d2){_0x3dad38(_0x4ad8d2);}}),_0xd01df9['addEventListener']('success',async()=>{const _0x206a00=_0xd01df9['result'];_0x206a00['objectStoreNames']['contains'](Mn)?_0x4ef30d(_0x206a00):(_0x206a00['close'](),await _p(),_0x4ef30d(await Qa()));});});}async function Or(_0x347e63,_0x48fd60,_0x3eae9a){const _0x55b26f=Zn(_0x347e63,!0x0)['put']({[Ya]:_0x48fd60,'value':_0x3eae9a});return new nn(_0x55b26f)['toPromise']();}async function gp(_0x3220f2,_0x52c5f2){const _0x3fca4a=Zn(_0x3220f2,!0x1)['get'](_0x52c5f2),_0x5ce374=await new nn(_0x3fca4a)['toPromise']();return _0x5ce374===void 0x0?null:_0x5ce374['value'];}function Dr(_0x72a669,_0x562dca){const _0x1d6633=Zn(_0x72a669,!0x0)['delete'](_0x562dca);return new nn(_0x1d6633)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x1f5253){let _0x17fd78=0x0;for(;;)try{const _0x46311b=await this['_openDb']();return await _0x1f5253(_0x46311b);}catch(_0x57022b){if(_0x17fd78++>yp)throw _0x57022b;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x3069be,_0x26e253)=>({'keyProcessed':(await this['_poll']())['includes'](_0x26e253['key'])})),this['receiver']['_subscribe']('ping',async(_0x149fd1,_0x213a6f)=>['keyChanged']);}async['initializeSender'](){var _0x3935fc,_0x4d0edd;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x12e8b5=await this['sender']['_send']('ping',{},0x320);_0x12e8b5&&(_0x3935fc=_0x12e8b5[0x0])!=null&&_0x3935fc['fulfilled']&&(_0x4d0edd=_0x12e8b5[0x0])!=null&&_0x4d0edd['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4a690b){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4a690b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5071b5=>{await Or(_0x5071b5,Dn,'1'),await Dr(_0x5071b5,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3721d1){this['pendingWrites']++;try{await _0x3721d1();}finally{this['pendingWrites']--;}}async['_set'](_0x2f40cb,_0x473d96){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x9aa60e=>Or(_0x9aa60e,_0x2f40cb,_0x473d96)),this['localCache'][_0x2f40cb]=_0x473d96,this['notifyServiceWorker'](_0x2f40cb)));}async['_get'](_0x1a7f05){const _0x35eaf0=await this['_withRetries'](_0x19da1b=>gp(_0x19da1b,_0x1a7f05));return this['localCache'][_0x1a7f05]=_0x35eaf0,_0x35eaf0;}async['_remove'](_0x1d9756){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x218a5b=>Dr(_0x218a5b,_0x1d9756)),delete this['localCache'][_0x1d9756],this['notifyServiceWorker'](_0x1d9756)));}async['_poll'](){const _0x5d1380=await this['_withRetries'](_0x4cb5be=>{const _0x4c6035=Zn(_0x4cb5be,!0x1)['getAll']();return new nn(_0x4c6035)['toPromise']();});if(!_0x5d1380)return[];if(this['pendingWrites']!==0x0)return[];const _0x11901c=[],_0x1b0f76=new Set();if(_0x5d1380['length']!==0x0){for(const {fbase_key:_0x1a3559,value:_0x5aacba}of _0x5d1380)_0x1b0f76['add'](_0x1a3559),JSON['stringify'](this['localCache'][_0x1a3559])!==JSON['stringify'](_0x5aacba)&&(this['notifyListeners'](_0x1a3559,_0x5aacba),_0x11901c['push'](_0x1a3559));}for(const _0x42ce11 of Object['keys'](this['localCache']))this['localCache'][_0x42ce11]&&!_0x1b0f76['has'](_0x42ce11)&&(this['notifyListeners'](_0x42ce11,null),_0x11901c['push'](_0x42ce11));return _0x11901c;}['notifyListeners'](_0x5cd554,_0x3f21dc){this['localCache'][_0x5cd554]=_0x3f21dc;const _0x4e7dcc=this['listeners'][_0x5cd554];if(_0x4e7dcc){for(const _0x3ea638 of Array['from'](_0x4e7dcc))_0x3ea638(_0x3f21dc);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5d9b74,_0x1d4f70){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5d9b74]||(this['listeners'][_0x5d9b74]=new Set(),this['_get'](_0x5d9b74)),this['listeners'][_0x5d9b74]['add'](_0x1d4f70);}['_removeListener'](_0x267470,_0x53e54a){this['listeners'][_0x267470]&&(this['listeners'][_0x267470]['delete'](_0x53e54a),this['listeners'][_0x267470]['size']===0x0&&delete this['listeners'][_0x267470]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x517583,_0x51544a){return _0x51544a?ie(_0x51544a):(m(_0x517583['_popupRedirectResolver'],_0x517583,'argument-error'),_0x517583['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x33894f){super('custom','custom'),this['params']=_0x33894f;}['_getIdTokenResponse'](_0x47b726){return nt(_0x47b726,this['_buildIdpRequest']());}['_linkToIdToken'](_0x283959,_0x5e2204){return nt(_0x283959,this['_buildIdpRequest'](_0x5e2204));}['_getReauthenticationResolver'](_0x307fdd){return nt(_0x307fdd,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x39331b){const _0x2d0c85={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x39331b&&(_0x2d0c85['idToken']=_0x39331b),_0x2d0c85;}}function Ip(_0x5a6199){return Va(_0x5a6199['auth'],new ks(_0x5a6199),_0x5a6199['bypassAuthState']);}function wp(_0x48c5d9){const {auth:_0x3fb03a,user:_0x43f29b}=_0x48c5d9;return m(_0x43f29b,_0x3fb03a,'internal-error'),tp(_0x43f29b,new ks(_0x48c5d9),_0x48c5d9['bypassAuthState']);}async function Cp(_0x87bdab){const {auth:_0x3861e2,user:_0x15a783}=_0x87bdab;return m(_0x15a783,_0x3861e2,'internal-error'),ep(_0x15a783,new ks(_0x87bdab),_0x87bdab['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x1725f5,_0xe5d676,_0x2323a6,_0x3abc2b,_0x38700e=!0x1){this['auth']=_0x1725f5,this['resolver']=_0x2323a6,this['user']=_0x3abc2b,this['bypassAuthState']=_0x38700e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0xe5d676)?_0xe5d676:[_0xe5d676];}['execute'](){return new Promise(async(_0x5e75e4,_0x3c874b)=>{this['pendingPromise']={'resolve':_0x5e75e4,'reject':_0x3c874b};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x483144){this['reject'](_0x483144);}});}async['onAuthEvent'](_0x4c2b60){const {urlResponse:_0x389ead,sessionId:_0x19162f,postBody:_0x444402,tenantId:_0x400c87,error:_0x4932d0,type:_0x3df1e5}=_0x4c2b60;if(_0x4932d0){this['reject'](_0x4932d0);return;}const _0x4136d4={'auth':this['auth'],'requestUri':_0x389ead,'sessionId':_0x19162f,'tenantId':_0x400c87||void 0x0,'postBody':_0x444402||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3df1e5)(_0x4136d4));}catch(_0x423d1d){this['reject'](_0x423d1d);}}['onError'](_0x222831){this['reject'](_0x222831);}['getIdpTask'](_0x1b5daa){switch(_0x1b5daa){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0xe63cd0){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0xe63cd0),this['unregisterAndCleanUp']();}['reject'](_0x3d5283){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3d5283),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5c363c,_0x229a45,_0xaab77a,_0x2a1e1e,_0x4c1c1d){super(_0x5c363c,_0x229a45,_0x2a1e1e,_0x4c1c1d),this['provider']=_0xaab77a,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1b4b36=await this['execute']();return m(_0x1b4b36,this['auth'],'internal-error'),_0x1b4b36;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x33bc6d=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x33bc6d),this['authWindow']['associatedEvent']=_0x33bc6d,this['resolver']['_originValidation'](this['auth'])['catch'](_0x20a1f1=>{this['reject'](_0x20a1f1);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x218db2=>{_0x218db2||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x223548;return((_0x223548=this['authWindow'])==null?void 0x0:_0x223548['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0xa9b40=()=>{var _0x5cdb54,_0x4b6e83;if((_0x4b6e83=(_0x5cdb54=this['authWindow'])==null?void 0x0:_0x5cdb54['window'])!=null&&_0x4b6e83['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xa9b40,Tp['get']());};_0xa9b40();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x3000df,_0x167a08,_0xc0f039=!0x1){super(_0x3000df,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x167a08,void 0x0,_0xc0f039),this['eventId']=null;}async['execute'](){let _0x4c7889=hn['get'](this['auth']['_key']());if(!_0x4c7889){try{const _0x440671=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4c7889=()=>Promise['resolve'](_0x440671);}catch(_0x2e7466){_0x4c7889=()=>Promise['reject'](_0x2e7466);}hn['set'](this['auth']['_key'](),_0x4c7889);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4c7889();}async['onAuthEvent'](_0x423c47){if(_0x423c47['type']==='signInViaRedirect')return super['onAuthEvent'](_0x423c47);if(_0x423c47['type']==='unknown'){this['resolve'](null);return;}if(_0x423c47['eventId']){const _0x2397ae=await this['auth']['_redirectUserForId'](_0x423c47['eventId']);if(_0x2397ae)return this['user']=_0x2397ae,super['onAuthEvent'](_0x423c47);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x4d3b0b,_0x32ce74){const _0x4ecf1c=Pp(_0x32ce74),_0x476c80=kp(_0x4d3b0b);if(!await _0x476c80['_isAvailable']())return!0x1;const _0x3836f0=await _0x476c80['_get'](_0x4ecf1c)==='true';return await _0x476c80['_remove'](_0x4ecf1c),_0x3836f0;}function Ap(_0x55dbc2,_0x5417c6){hn['set'](_0x55dbc2['_key'](),_0x5417c6);}function kp(_0x1df34f){return ie(_0x1df34f['_redirectPersistence']);}function Pp(_0x30dad5){return ln(Sp,_0x30dad5['config']['apiKey'],_0x30dad5['name']);}async function Np(_0x38b6af,_0x52e8b2,_0x397f6b=!0x1){if($(_0x38b6af['app']))return Promise['reject'](re(_0x38b6af));const _0x45dd8e=Ke(_0x38b6af),_0x17b596=Ep(_0x45dd8e,_0x52e8b2),_0x580ddb=await new bp(_0x45dd8e,_0x17b596,_0x397f6b)['execute']();return _0x580ddb&&!_0x397f6b&&(delete _0x580ddb['user']['_redirectEventId'],await _0x45dd8e['_persistUserIfCurrent'](_0x580ddb['user']),await _0x45dd8e['_setRedirectUser'](null,_0x52e8b2)),_0x580ddb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x23258d){this['auth']=_0x23258d,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3052df){this['consumers']['add'](_0x3052df),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3052df)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3052df),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5d7c04){this['consumers']['delete'](_0x5d7c04);}['onEvent'](_0x24c203){if(this['hasEventBeenHandled'](_0x24c203))return!0x1;let _0xfbc77d=!0x1;return this['consumers']['forEach'](_0x4081fd=>{this['isEventForConsumer'](_0x24c203,_0x4081fd)&&(_0xfbc77d=!0x0,this['sendToConsumer'](_0x24c203,_0x4081fd),this['saveEventToCache'](_0x24c203));}),this['hasHandledPotentialRedirect']||!Mp(_0x24c203)||(this['hasHandledPotentialRedirect']=!0x0,_0xfbc77d||(this['queuedRedirectEvent']=_0x24c203,_0xfbc77d=!0x0)),_0xfbc77d;}['sendToConsumer'](_0x5efcf0,_0x397435){var _0x2b4e55;if(_0x5efcf0['error']&&!Za(_0x5efcf0)){const _0x343d56=((_0x2b4e55=_0x5efcf0['error']['code'])==null?void 0x0:_0x2b4e55['split']('auth/')[0x1])||'internal-error';_0x397435['onError'](X(this['auth'],_0x343d56));}else _0x397435['onAuthEvent'](_0x5efcf0);}['isEventForConsumer'](_0x514ba9,_0xebc97a){const _0x1e2d56=_0xebc97a['eventId']===null||!!_0x514ba9['eventId']&&_0x514ba9['eventId']===_0xebc97a['eventId'];return _0xebc97a['filter']['includes'](_0x514ba9['type'])&&_0x1e2d56;}['hasEventBeenHandled'](_0xf675de){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0xf675de));}['saveEventToCache'](_0x20e0cc){this['cachedEventUids']['add'](Mr(_0x20e0cc)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0xc1a59a){return[_0xc1a59a['type'],_0xc1a59a['eventId'],_0xc1a59a['sessionId'],_0xc1a59a['tenantId']]['filter'](_0x56f8e3=>_0x56f8e3)['join']('-');}function Za({type:_0x1dd101,error:_0x1de4c1}){return _0x1dd101==='unknown'&&(_0x1de4c1==null?void 0x0:_0x1de4c1['code'])==='auth/no-auth-event';}function Mp(_0x4bffb7){switch(_0x4bffb7['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x4bffb7);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x260e22,_0x181292={}){return Pe(_0x260e22,'GET','/v1/projects',_0x181292);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x18e4c5){if(_0x18e4c5['config']['emulator'])return;const {authorizedDomains:_0x5d342a}=await Lp(_0x18e4c5);for(const _0x144b6c of _0x5d342a)try{if(Wp(_0x144b6c))return;}catch{}Y(_0x18e4c5,'unauthorized-domain');}function Wp(_0x5b6212){const _0x34d1f6=Mi(),{protocol:_0x35b1b3,hostname:_0x4fa9ba}=new URL(_0x34d1f6);if(_0x5b6212['startsWith']('chrome-extension://')){const _0x39da9c=new URL(_0x5b6212);return _0x39da9c['hostname']===''&&_0x4fa9ba===''?_0x35b1b3==='chrome-extension:'&&_0x5b6212['replace']('chrome-extension://','')===_0x34d1f6['replace']('chrome-extension://',''):_0x35b1b3==='chrome-extension:'&&_0x39da9c['hostname']===_0x4fa9ba;}if(!Fp['test'](_0x35b1b3))return!0x1;if(xp['test'](_0x5b6212))return _0x4fa9ba===_0x5b6212;const _0x2a8441=_0x5b6212['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2a8441+'|'+_0x2a8441+')$','i')['test'](_0x4fa9ba);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x3a0ae7=Z()['___jsl'];if(_0x3a0ae7!=null&&_0x3a0ae7['H']){for(const _0x38a7d5 of Object['keys'](_0x3a0ae7['H']))if(_0x3a0ae7['H'][_0x38a7d5]['r']=_0x3a0ae7['H'][_0x38a7d5]['r']||[],_0x3a0ae7['H'][_0x38a7d5]['L']=_0x3a0ae7['H'][_0x38a7d5]['L']||[],_0x3a0ae7['H'][_0x38a7d5]['r']=[..._0x3a0ae7['H'][_0x38a7d5]['L']],_0x3a0ae7['CP']){for(let _0x361a36=0x0;_0x361a36<_0x3a0ae7['CP']['length'];_0x361a36++)_0x3a0ae7['CP'][_0x361a36]=null;}}}function Vp(_0x2b7c04){return new Promise((_0x3658d0,_0x407ddd)=>{var _0xa9582b,_0x354638,_0x549b07;function _0x50bb4a(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x3658d0(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x407ddd(X(_0x2b7c04,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x354638=(_0xa9582b=Z()['gapi'])==null?void 0x0:_0xa9582b['iframes'])!=null&&_0x354638['Iframe'])_0x3658d0(gapi['iframes']['getContext']());else{if((_0x549b07=Z()['gapi'])!=null&&_0x549b07['load'])_0x50bb4a();else{const _0xbcc4e4=Ff('iframefcb');return Z()[_0xbcc4e4]=()=>{gapi['load']?_0x50bb4a():_0x407ddd(X(_0x2b7c04,'network-request-failed'));},xa(xf()+'?onload='+_0xbcc4e4)['catch'](_0x320fd2=>_0x407ddd(_0x320fd2));}}})['catch'](_0x4d8860=>{throw un=null,_0x4d8860;});}let un=null;function Hp(_0x215b7e){return un=un||Vp(_0x215b7e),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x286f27){const _0x3ed63f=_0x286f27['config'];m(_0x3ed63f['authDomain'],_0x286f27,'auth-domain-config-required');const _0x3ebbe9=_0x3ed63f['emulator']?Cs(_0x3ed63f,qp):'https://'+_0x286f27['config']['authDomain']+'/'+Gp,_0x219bb7={'apiKey':_0x3ed63f['apiKey'],'appName':_0x286f27['name'],'v':dt},_0x3c4633=jp['get'](_0x286f27['config']['apiHost']);_0x3c4633&&(_0x219bb7['eid']=_0x3c4633);const _0x119eb3=_0x286f27['_getFrameworks']();return _0x119eb3['length']&&(_0x219bb7['fw']=_0x119eb3['join'](',')),_0x3ebbe9+'?'+ut(_0x219bb7)['slice'](0x1);}async function Yp(_0x420c26){const _0x587b4c=await Hp(_0x420c26),_0x9fb0b7=Z()['gapi'];return m(_0x9fb0b7,_0x420c26,'internal-error'),_0x587b4c['open']({'where':document['body'],'url':Kp(_0x420c26),'messageHandlersFilter':_0x9fb0b7['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x1436f3=>new Promise(async(_0x4b8e92,_0x210e97)=>{await _0x1436f3['restyle']({'setHideOnLeave':!0x1});const _0x49403f=X(_0x420c26,'network-request-failed'),_0x191f93=Z()['setTimeout'](()=>{_0x210e97(_0x49403f);},$p['get']());function _0x158087(){Z()['clearTimeout'](_0x191f93),_0x4b8e92(_0x1436f3);}_0x1436f3['ping'](_0x158087)['then'](_0x158087,()=>{_0x210e97(_0x49403f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x1d05af){this['window']=_0x1d05af,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x5c6938,_0x1bc3c6,_0x142244,_0x49e389=Jp,_0x1ea95e=Xp){const _0x2c8c8b=Math['max']((window['screen']['availHeight']-_0x1ea95e)/0x2,0x0)['toString'](),_0xf80029=Math['max']((window['screen']['availWidth']-_0x49e389)/0x2,0x0)['toString']();let _0x1877e4='';const _0x42e3f4={...Qp,'width':_0x49e389['toString'](),'height':_0x1ea95e['toString'](),'top':_0x2c8c8b,'left':_0xf80029},_0x525dfb=W()['toLowerCase']();_0x142244&&(_0x1877e4=ka(_0x525dfb)?Zp:_0x142244),Ra(_0x525dfb)&&(_0x1bc3c6=_0x1bc3c6||e_,_0x42e3f4['scrollbars']='yes');const _0x2a4277=Object['entries'](_0x42e3f4)['reduce']((_0x282001,[_0x265222,_0x3f6b88])=>''+_0x282001+_0x265222+'='+_0x3f6b88+',','');if(Rf(_0x525dfb)&&_0x1877e4!=='_self')return n_(_0x1bc3c6||'',_0x1877e4),new xr(null);const _0x7d4f13=window['open'](_0x1bc3c6||'',_0x1877e4,_0x2a4277);m(_0x7d4f13,_0x5c6938,'popup-blocked');try{_0x7d4f13['focus']();}catch{}return new xr(_0x7d4f13);}function n_(_0x41898b,_0x4947c0){const _0x1b5f1d=document['createElement']('a');_0x1b5f1d['href']=_0x41898b,_0x1b5f1d['target']=_0x4947c0;const _0x830203=document['createEvent']('MouseEvent');_0x830203['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1b5f1d['dispatchEvent'](_0x830203);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x465c43,_0x26da2c,_0x4fe55b,_0x6145ec,_0x19110d,_0x24b8c1){m(_0x465c43['config']['authDomain'],_0x465c43,'auth-domain-config-required'),m(_0x465c43['config']['apiKey'],_0x465c43,'invalid-api-key');const _0x59b3c0={'apiKey':_0x465c43['config']['apiKey'],'appName':_0x465c43['name'],'authType':_0x4fe55b,'redirectUrl':_0x6145ec,'v':dt,'eventId':_0x19110d};if(_0x26da2c instanceof Wa){_0x26da2c['setDefaultLanguage'](_0x465c43['languageCode']),_0x59b3c0['providerId']=_0x26da2c['providerId']||'',pn(_0x26da2c['getCustomParameters']())||(_0x59b3c0['customParameters']=JSON['stringify'](_0x26da2c['getCustomParameters']()));for(const [_0x1701f1,_0x504fa3]of Object['entries']({}))_0x59b3c0[_0x1701f1]=_0x504fa3;}if(_0x26da2c instanceof tn){const _0x5bad67=_0x26da2c['getScopes']()['filter'](_0x34c4f3=>_0x34c4f3!=='');_0x5bad67['length']>0x0&&(_0x59b3c0['scopes']=_0x5bad67['join'](','));}_0x465c43['tenantId']&&(_0x59b3c0['tid']=_0x465c43['tenantId']);const _0xd9fa=_0x59b3c0;for(const _0x2a320e of Object['keys'](_0xd9fa))_0xd9fa[_0x2a320e]===void 0x0&&delete _0xd9fa[_0x2a320e];const _0x2ef04e=await _0x465c43['_getAppCheckToken'](),_0x136226=_0x2ef04e?'#'+r_+'='+encodeURIComponent(_0x2ef04e):'';return o_(_0x465c43)+'?'+ut(_0xd9fa)['slice'](0x1)+_0x136226;}function o_({config:_0x2d44e1}){return _0x2d44e1['emulator']?Cs(_0x2d44e1,s_):'https://'+_0x2d44e1['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x549d55,_0x12e8e0,_0x131c45,_0x2cb92d){var _0x47e22f;ce((_0x47e22f=this['eventManagers'][_0x549d55['_key']()])==null?void 0x0:_0x47e22f['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5f497b=await Fr(_0x549d55,_0x12e8e0,_0x131c45,Mi(),_0x2cb92d);return t_(_0x549d55,_0x5f497b,As());}async['_openRedirect'](_0x1b395b,_0x287f36,_0x46b55d,_0x1a75cc){await this['_originValidation'](_0x1b395b);const _0x5d5df6=await Fr(_0x1b395b,_0x287f36,_0x46b55d,Mi(),_0x1a75cc);return hp(_0x5d5df6),new Promise(()=>{});}['_initialize'](_0x57bbce){const _0x3f5956=_0x57bbce['_key']();if(this['eventManagers'][_0x3f5956]){const {manager:_0x2bd333,promise:_0x254969}=this['eventManagers'][_0x3f5956];return _0x2bd333?Promise['resolve'](_0x2bd333):(ce(_0x254969,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x254969);}const _0x2b3205=this['initAndGetManager'](_0x57bbce);return this['eventManagers'][_0x3f5956]={'promise':_0x2b3205},_0x2b3205['catch'](()=>{delete this['eventManagers'][_0x3f5956];}),_0x2b3205;}async['initAndGetManager'](_0x1c233f){const _0x116698=await Yp(_0x1c233f),_0x6533cf=new Dp(_0x1c233f);return _0x116698['register']('authEvent',_0x43afdc=>(m(_0x43afdc==null?void 0x0:_0x43afdc['authEvent'],_0x1c233f,'invalid-auth-event'),{'status':_0x6533cf['onEvent'](_0x43afdc['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1c233f['_key']()]={'manager':_0x6533cf},this['iframes'][_0x1c233f['_key']()]=_0x116698,_0x6533cf;}['_isIframeWebStorageSupported'](_0x4a5fc0,_0x33c364){this['iframes'][_0x4a5fc0['_key']()]['send'](pi,{'type':pi},_0x17cb12=>{var _0x5aedfd;const _0x348ad1=(_0x5aedfd=_0x17cb12==null?void 0x0:_0x17cb12[0x0])==null?void 0x0:_0x5aedfd[pi];_0x348ad1!==void 0x0&&_0x33c364(!!_0x348ad1),Y(_0x4a5fc0,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x225b86){const _0x3c085f=_0x225b86['_key']();return this['originValidationPromises'][_0x3c085f]||(this['originValidationPromises'][_0x3c085f]=Up(_0x225b86)),this['originValidationPromises'][_0x3c085f];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x1933db){this['auth']=_0x1933db,this['internalListeners']=new Map();}['getUid'](){var _0x1fe13f;return this['assertAuthConfigured'](),((_0x1fe13f=this['auth']['currentUser'])==null?void 0x0:_0x1fe13f['uid'])||null;}async['getToken'](_0x4a5745){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4a5745)}:null;}['addAuthTokenListener'](_0x3a5aab){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3a5aab))return;const _0x5814d5=this['auth']['onIdTokenChanged'](_0x48d244=>{_0x3a5aab((_0x48d244==null?void 0x0:_0x48d244['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3a5aab,_0x5814d5),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x162e34){this['assertAuthConfigured']();const _0x15a504=this['internalListeners']['get'](_0x162e34);_0x15a504&&(this['internalListeners']['delete'](_0x162e34),_0x15a504(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x187a2a){switch(_0x187a2a){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x3faa82){st(new Fe('auth',(_0x57931a,{options:_0x4b79b0})=>{const _0x222c1c=_0x57931a['getProvider']('app')['getImmediate'](),_0xbabcd=_0x57931a['getProvider']('heartbeat'),_0x3fc6c8=_0x57931a['getProvider']('app-check-internal'),{apiKey:_0x59db6a,authDomain:_0x4e3acd}=_0x222c1c['options'];m(_0x59db6a&&!_0x59db6a['includes'](':'),'invalid-api-key',{'appName':_0x222c1c['name']});const _0x1defea={'apiKey':_0x59db6a,'authDomain':_0x4e3acd,'clientPlatform':_0x3faa82,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x3faa82)},_0x3630b7=new Df(_0x222c1c,_0xbabcd,_0x3fc6c8,_0x1defea);return Hf(_0x3630b7,_0x4b79b0),_0x3630b7;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x468ec8,_0x2a00a1,_0x7e1783)=>{_0x468ec8['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x551837=>{const _0x758e0b=Ke(_0x551837['getProvider']('auth')['getImmediate']());return(_0x49c01d=>new l_(_0x49c01d))(_0x758e0b);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x3faa82)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x520114=>async _0x57f3cf=>{const _0x4ebfed=_0x57f3cf&&await _0x57f3cf['getIdTokenResult'](),_0x22d493=_0x4ebfed&&(new Date()['getTime']()-Date['parse'](_0x4ebfed['issuedAtTime']))/0x3e8;if(_0x22d493&&_0x22d493>f_)return;const _0xdaffa=_0x4ebfed==null?void 0x0:_0x4ebfed['token'];Br!==_0xdaffa&&(Br=_0xdaffa,await fetch(_0x520114,{'method':_0xdaffa?'POST':'DELETE','headers':_0xdaffa?{'Authorization':'Bearer\x20'+_0xdaffa}:{}}));};function B_(_0x4f260f=Zr()){const _0xd80745=Hi(_0x4f260f,'auth');if(_0xd80745['isInitialized']())return _0xd80745['getImmediate']();const _0xc415b6=Vf(_0x4f260f,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x12338c=jr('authTokenSyncURL');if(_0x12338c&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xa410a8=new URL(_0x12338c,location['origin']);if(location['origin']===_0xa410a8['origin']){const _0x5a149a=p_(_0xa410a8['toString']());sp(_0xc415b6,_0x5a149a,()=>_0x5a149a(_0xc415b6['currentUser'])),ip(_0xc415b6,_0x76aa84=>_0x5a149a(_0x76aa84));}}const _0x2d6b3d=qr('auth');return _0x2d6b3d&&$f(_0xc415b6,'http://'+_0x2d6b3d),_0xc415b6;}function __(){var _0x2344b1;return((_0x2344b1=document['getElementsByTagName']('head'))==null?void 0x0:_0x2344b1[0x0])??document;}Mf({'loadJS'(_0x129ad6){return new Promise((_0x6fac61,_0x315e6b)=>{const _0xd0ada3=document['createElement']('script');_0xd0ada3['setAttribute']('src',_0x129ad6),_0xd0ada3['onload']=_0x6fac61,_0xd0ada3['onerror']=_0x31fe5a=>{const _0x263476=X('internal-error');_0x263476['customData']=_0x31fe5a,_0x315e6b(_0x263476);},_0xd0ada3['type']='text/javascript',_0xd0ada3['charset']='UTF-8',__()['appendChild'](_0xd0ada3);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};