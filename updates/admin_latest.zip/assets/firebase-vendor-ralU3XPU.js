const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x45c5ed,_0xafdb0b){if(!_0x45c5ed)throw ht(_0xafdb0b);},ht=function(_0x5833c6){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5833c6);},Hr=function(_0x2a2c40){const _0x283e9d=[];let _0x2c0826=0x0;for(let _0x2ea551=0x0;_0x2ea551<_0x2a2c40['length'];_0x2ea551++){let _0x43beb9=_0x2a2c40['charCodeAt'](_0x2ea551);_0x43beb9<0x80?_0x283e9d[_0x2c0826++]=_0x43beb9:_0x43beb9<0x800?(_0x283e9d[_0x2c0826++]=_0x43beb9>>0x6|0xc0,_0x283e9d[_0x2c0826++]=_0x43beb9&0x3f|0x80):(_0x43beb9&0xfc00)===0xd800&&_0x2ea551+0x1<_0x2a2c40['length']&&(_0x2a2c40['charCodeAt'](_0x2ea551+0x1)&0xfc00)===0xdc00?(_0x43beb9=0x10000+((_0x43beb9&0x3ff)<<0xa)+(_0x2a2c40['charCodeAt'](++_0x2ea551)&0x3ff),_0x283e9d[_0x2c0826++]=_0x43beb9>>0x12|0xf0,_0x283e9d[_0x2c0826++]=_0x43beb9>>0xc&0x3f|0x80,_0x283e9d[_0x2c0826++]=_0x43beb9>>0x6&0x3f|0x80,_0x283e9d[_0x2c0826++]=_0x43beb9&0x3f|0x80):(_0x283e9d[_0x2c0826++]=_0x43beb9>>0xc|0xe0,_0x283e9d[_0x2c0826++]=_0x43beb9>>0x6&0x3f|0x80,_0x283e9d[_0x2c0826++]=_0x43beb9&0x3f|0x80);}return _0x283e9d;},nc=function(_0x53d45d){const _0x6db462=[];let _0x12e496=0x0,_0x4133a7=0x0;for(;_0x12e496<_0x53d45d['length'];){const _0x3e95cf=_0x53d45d[_0x12e496++];if(_0x3e95cf<0x80)_0x6db462[_0x4133a7++]=String['fromCharCode'](_0x3e95cf);else{if(_0x3e95cf>0xbf&&_0x3e95cf<0xe0){const _0x1975d6=_0x53d45d[_0x12e496++];_0x6db462[_0x4133a7++]=String['fromCharCode']((_0x3e95cf&0x1f)<<0x6|_0x1975d6&0x3f);}else{if(_0x3e95cf>0xef&&_0x3e95cf<0x16d){const _0x350380=_0x53d45d[_0x12e496++],_0x248f1d=_0x53d45d[_0x12e496++],_0x3f9cab=_0x53d45d[_0x12e496++],_0x5264b0=((_0x3e95cf&0x7)<<0x12|(_0x350380&0x3f)<<0xc|(_0x248f1d&0x3f)<<0x6|_0x3f9cab&0x3f)-0x10000;_0x6db462[_0x4133a7++]=String['fromCharCode'](0xd800+(_0x5264b0>>0xa)),_0x6db462[_0x4133a7++]=String['fromCharCode'](0xdc00+(_0x5264b0&0x3ff));}else{const _0x5ae383=_0x53d45d[_0x12e496++],_0x38bb68=_0x53d45d[_0x12e496++];_0x6db462[_0x4133a7++]=String['fromCharCode']((_0x3e95cf&0xf)<<0xc|(_0x5ae383&0x3f)<<0x6|_0x38bb68&0x3f);}}}}return _0x6db462['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3a1f63,_0x1563d9){if(!Array['isArray'](_0x3a1f63))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x29f456=_0x1563d9?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x573221=[];for(let _0x45c5=0x0;_0x45c5<_0x3a1f63['length'];_0x45c5+=0x3){const _0x1ec6e2=_0x3a1f63[_0x45c5],_0x4a64df=_0x45c5+0x1<_0x3a1f63['length'],_0x31554b=_0x4a64df?_0x3a1f63[_0x45c5+0x1]:0x0,_0x3aa403=_0x45c5+0x2<_0x3a1f63['length'],_0x462279=_0x3aa403?_0x3a1f63[_0x45c5+0x2]:0x0,_0x195a21=_0x1ec6e2>>0x2,_0x357d99=(_0x1ec6e2&0x3)<<0x4|_0x31554b>>0x4;let _0x1f3d5c=(_0x31554b&0xf)<<0x2|_0x462279>>0x6,_0x3e9499=_0x462279&0x3f;_0x3aa403||(_0x3e9499=0x40,_0x4a64df||(_0x1f3d5c=0x40)),_0x573221['push'](_0x29f456[_0x195a21],_0x29f456[_0x357d99],_0x29f456[_0x1f3d5c],_0x29f456[_0x3e9499]);}return _0x573221['join']('');},'encodeString'(_0x57d070,_0x32bb08){return this['HAS_NATIVE_SUPPORT']&&!_0x32bb08?btoa(_0x57d070):this['encodeByteArray'](Hr(_0x57d070),_0x32bb08);},'decodeString'(_0x34c951,_0x425c5f){return this['HAS_NATIVE_SUPPORT']&&!_0x425c5f?atob(_0x34c951):nc(this['decodeStringToByteArray'](_0x34c951,_0x425c5f));},'decodeStringToByteArray'(_0x41e5d2,_0x3a0e9c){this['init_']();const _0x4a44db=_0x3a0e9c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x196a50=[];for(let _0x532a4e=0x0;_0x532a4e<_0x41e5d2['length'];){const _0x22f5e1=_0x4a44db[_0x41e5d2['charAt'](_0x532a4e++)],_0xabef78=_0x532a4e<_0x41e5d2['length']?_0x4a44db[_0x41e5d2['charAt'](_0x532a4e)]:0x0;++_0x532a4e;const _0x58d8ff=_0x532a4e<_0x41e5d2['length']?_0x4a44db[_0x41e5d2['charAt'](_0x532a4e)]:0x40;++_0x532a4e;const _0x312fa0=_0x532a4e<_0x41e5d2['length']?_0x4a44db[_0x41e5d2['charAt'](_0x532a4e)]:0x40;if(++_0x532a4e,_0x22f5e1==null||_0xabef78==null||_0x58d8ff==null||_0x312fa0==null)throw new ic();const _0x4427dd=_0x22f5e1<<0x2|_0xabef78>>0x4;if(_0x196a50['push'](_0x4427dd),_0x58d8ff!==0x40){const _0x3d3b0f=_0xabef78<<0x4&0xf0|_0x58d8ff>>0x2;if(_0x196a50['push'](_0x3d3b0f),_0x312fa0!==0x40){const _0x157ea0=_0x58d8ff<<0x6&0xc0|_0x312fa0;_0x196a50['push'](_0x157ea0);}}}return _0x196a50;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x560773=0x0;_0x560773<this['ENCODED_VALS']['length'];_0x560773++)this['byteToCharMap_'][_0x560773]=this['ENCODED_VALS']['charAt'](_0x560773),this['charToByteMap_'][this['byteToCharMap_'][_0x560773]]=_0x560773,this['byteToCharMapWebSafe_'][_0x560773]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x560773),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x560773]]=_0x560773,_0x560773>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x560773)]=_0x560773,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x560773)]=_0x560773);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x15dd88){const _0x4b7c91=Hr(_0x15dd88);return Fi['encodeByteArray'](_0x4b7c91,!0x0);},dn=function(_0x4cdd34){return $r(_0x4cdd34)['replace'](/\./g,'');},fn=function(_0x81b9c1){try{return Fi['decodeString'](_0x81b9c1,!0x0);}catch(_0x23ba4e){console['error']('base64Decode\x20failed:\x20',_0x23ba4e);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x56aa43){return Gr(void 0x0,_0x56aa43);}function Gr(_0x5cf2e2,_0x5a1c8a){if(!(_0x5a1c8a instanceof Object))return _0x5a1c8a;switch(_0x5a1c8a['constructor']){case Date:const _0x250fbc=_0x5a1c8a;return new Date(_0x250fbc['getTime']());case Object:_0x5cf2e2===void 0x0&&(_0x5cf2e2={});break;case Array:_0x5cf2e2=[];break;default:return _0x5a1c8a;}for(const _0x3aa172 in _0x5a1c8a)!_0x5a1c8a['hasOwnProperty'](_0x3aa172)||!rc(_0x3aa172)||(_0x5cf2e2[_0x3aa172]=Gr(_0x5cf2e2[_0x3aa172],_0x5a1c8a[_0x3aa172]));return _0x5cf2e2;}function rc(_0x2ad3a0){return _0x2ad3a0!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xad23c2=Ps['__FIREBASE_DEFAULTS__'];if(_0xad23c2)return JSON['parse'](_0xad23c2);},lc=()=>{if(typeof document>'u')return;let _0x97e0f3;try{_0x97e0f3=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x42dbd0=_0x97e0f3&&fn(_0x97e0f3[0x1]);return _0x42dbd0&&JSON['parse'](_0x42dbd0);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x501d06){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x501d06);return;}},qr=_0x4c93f6=>{var _0x474781,_0x2279bb;return(_0x2279bb=(_0x474781=Ui())==null?void 0x0:_0x474781['emulatorHosts'])==null?void 0x0:_0x2279bb[_0x4c93f6];},hc=_0x2b59ae=>{const _0x2a4880=qr(_0x2b59ae);if(!_0x2a4880)return;const _0x858164=_0x2a4880['lastIndexOf'](':');if(_0x858164<=0x0||_0x858164+0x1===_0x2a4880['length'])throw new Error('Invalid\x20host\x20'+_0x2a4880+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2b48a3=parseInt(_0x2a4880['substring'](_0x858164+0x1),0xa);return _0x2a4880[0x0]==='['?[_0x2a4880['substring'](0x1,_0x858164-0x1),_0x2b48a3]:[_0x2a4880['substring'](0x0,_0x858164),_0x2b48a3];},zr=()=>{var _0x3bd0e1;return(_0x3bd0e1=Ui())==null?void 0x0:_0x3bd0e1['config'];},jr=_0x1fa028=>{var _0x5b5f11;return(_0x5b5f11=Ui())==null?void 0x0:_0x5b5f11['_'+_0x1fa028];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1c7e92,_0x5d32d4)=>{this['resolve']=_0x1c7e92,this['reject']=_0x5d32d4;});}['wrapCallback'](_0x380b26){return(_0x3d066d,_0x47be4d)=>{_0x3d066d?this['reject'](_0x3d066d):this['resolve'](_0x47be4d),typeof _0x380b26=='function'&&(this['promise']['catch'](()=>{}),_0x380b26['length']===0x1?_0x380b26(_0x3d066d):_0x380b26(_0x3d066d,_0x47be4d));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x45cb4f,_0x35755e){if(_0x45cb4f['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x31253f={'alg':'none','type':'JWT'},_0x2d38f2=_0x35755e||'demo-project',_0x34c74d=_0x45cb4f['iat']||0x0,_0x32f33c=_0x45cb4f['sub']||_0x45cb4f['user_id'];if(!_0x32f33c)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x180648={'iss':'https://securetoken.google.com/'+_0x2d38f2,'aud':_0x2d38f2,'iat':_0x34c74d,'exp':_0x34c74d+0xe10,'auth_time':_0x34c74d,'sub':_0x32f33c,'user_id':_0x32f33c,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x45cb4f};return[dn(JSON['stringify'](_0x31253f)),dn(JSON['stringify'](_0x180648)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x37e446=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x37e446=='object'&&_0x37e446['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x475f88=W();return _0x475f88['indexOf']('MSIE\x20')>=0x0||_0x475f88['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x1c5198,_0x3364c8)=>{try{let _0x2f5d27=!0x0;const _0x18dad4='validate-browser-context-for-indexeddb-analytics-module',_0x10a8e4=self['indexedDB']['open'](_0x18dad4);_0x10a8e4['onsuccess']=()=>{_0x10a8e4['result']['close'](),_0x2f5d27||self['indexedDB']['deleteDatabase'](_0x18dad4),_0x1c5198(!0x0);},_0x10a8e4['onupgradeneeded']=()=>{_0x2f5d27=!0x1;},_0x10a8e4['onerror']=()=>{var _0x48227c;_0x3364c8(((_0x48227c=_0x10a8e4['error'])==null?void 0x0:_0x48227c['message'])||'');};}catch(_0x185a69){_0x3364c8(_0x185a69);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x872f89,_0x2289ce,_0x1fe588){super(_0x2289ce),this['code']=_0x872f89,this['customData']=_0x1fe588,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4208b9,_0x492b52,_0x1e5728){this['service']=_0x4208b9,this['serviceName']=_0x492b52,this['errors']=_0x1e5728;}['create'](_0x4b71f4,..._0x36ecfb){const _0x5d2193=_0x36ecfb[0x0]||{},_0x19222c=this['service']+'/'+_0x4b71f4,_0x17cb63=this['errors'][_0x4b71f4],_0x177b83=_0x17cb63?vc(_0x17cb63,_0x5d2193):'Error',_0x2468c2=this['serviceName']+':\x20'+_0x177b83+'\x20('+_0x19222c+').';return new Re(_0x19222c,_0x2468c2,_0x5d2193);}}function vc(_0x31cc44,_0x73ad7e){return _0x31cc44['replace'](Ec,(_0x36cf38,_0x52ca71)=>{const _0x73070b=_0x73ad7e[_0x52ca71];return _0x73070b!=null?String(_0x73070b):'<'+_0x52ca71+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2de95b){return JSON['parse'](_0x2de95b);}function O(_0x9be993){return JSON['stringify'](_0x9be993);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0xd4da2b){let _0x347dd5={},_0x59cb5c={},_0xe0ef1e={},_0xecae02='';try{const _0x2420a5=_0xd4da2b['split']('.');_0x347dd5=Nt(fn(_0x2420a5[0x0])||''),_0x59cb5c=Nt(fn(_0x2420a5[0x1])||''),_0xecae02=_0x2420a5[0x2],_0xe0ef1e=_0x59cb5c['d']||{},delete _0x59cb5c['d'];}catch{}return{'header':_0x347dd5,'claims':_0x59cb5c,'data':_0xe0ef1e,'signature':_0xecae02};},Ic=function(_0x13e79c){const _0x130819=Yr(_0x13e79c),_0x1bcc31=_0x130819['claims'];return!!_0x1bcc31&&typeof _0x1bcc31=='object'&&_0x1bcc31['hasOwnProperty']('iat');},wc=function(_0xf0060){const _0x7387d3=Yr(_0xf0060)['claims'];return typeof _0x7387d3=='object'&&_0x7387d3['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x295fea,_0x4b3147){return Object['prototype']['hasOwnProperty']['call'](_0x295fea,_0x4b3147);}function Le(_0x2cbefe,_0x4270d1){if(Object['prototype']['hasOwnProperty']['call'](_0x2cbefe,_0x4270d1))return _0x2cbefe[_0x4270d1];}function pn(_0x100097){for(const _0x20c4b0 in _0x100097)if(Object['prototype']['hasOwnProperty']['call'](_0x100097,_0x20c4b0))return!0x1;return!0x0;}function _n(_0x95bf3a,_0x18d970,_0x22b727){const _0x99ad9e={};for(const _0x3e3070 in _0x95bf3a)Object['prototype']['hasOwnProperty']['call'](_0x95bf3a,_0x3e3070)&&(_0x99ad9e[_0x3e3070]=_0x18d970['call'](_0x22b727,_0x95bf3a[_0x3e3070],_0x3e3070,_0x95bf3a));return _0x99ad9e;}function xe(_0x23b5f3,_0x40db3c){if(_0x23b5f3===_0x40db3c)return!0x0;const _0x114c1f=Object['keys'](_0x23b5f3),_0x54c033=Object['keys'](_0x40db3c);for(const _0x1f6e3d of _0x114c1f){if(!_0x54c033['includes'](_0x1f6e3d))return!0x1;const _0x1d8dcf=_0x23b5f3[_0x1f6e3d],_0x40dde5=_0x40db3c[_0x1f6e3d];if(Ns(_0x1d8dcf)&&Ns(_0x40dde5)){if(!xe(_0x1d8dcf,_0x40dde5))return!0x1;}else{if(_0x1d8dcf!==_0x40dde5)return!0x1;}}for(const _0x46febb of _0x54c033)if(!_0x114c1f['includes'](_0x46febb))return!0x1;return!0x0;}function Ns(_0x54daf3){return _0x54daf3!==null&&typeof _0x54daf3=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x58a53d){const _0xe1700d=[];for(const [_0xa54498,_0x2e69ab]of Object['entries'](_0x58a53d))Array['isArray'](_0x2e69ab)?_0x2e69ab['forEach'](_0x42cdc2=>{_0xe1700d['push'](encodeURIComponent(_0xa54498)+'='+encodeURIComponent(_0x42cdc2));}):_0xe1700d['push'](encodeURIComponent(_0xa54498)+'='+encodeURIComponent(_0x2e69ab));return _0xe1700d['length']?'&'+_0xe1700d['join']('&'):'';}function Ct(_0x56f676){const _0x59be4a={};return _0x56f676['replace'](/^\?/,'')['split']('&')['forEach'](_0x16dd83=>{if(_0x16dd83){const [_0xf44e9a,_0x5b1ae2]=_0x16dd83['split']('=');_0x59be4a[decodeURIComponent(_0xf44e9a)]=decodeURIComponent(_0x5b1ae2);}}),_0x59be4a;}function Tt(_0x57d011){const _0x29f494=_0x57d011['indexOf']('?');if(!_0x29f494)return'';const _0x6b6ff2=_0x57d011['indexOf']('#',_0x29f494);return _0x57d011['substring'](_0x29f494,_0x6b6ff2>0x0?_0x6b6ff2:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x506462=0x1;_0x506462<this['blockSize'];++_0x506462)this['pad_'][_0x506462]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x39c201,_0x27e4ec){_0x27e4ec||(_0x27e4ec=0x0);const _0x45fe47=this['W_'];if(typeof _0x39c201=='string'){for(let _0x150aa9=0x0;_0x150aa9<0x10;_0x150aa9++)_0x45fe47[_0x150aa9]=_0x39c201['charCodeAt'](_0x27e4ec)<<0x18|_0x39c201['charCodeAt'](_0x27e4ec+0x1)<<0x10|_0x39c201['charCodeAt'](_0x27e4ec+0x2)<<0x8|_0x39c201['charCodeAt'](_0x27e4ec+0x3),_0x27e4ec+=0x4;}else{for(let _0x78998=0x0;_0x78998<0x10;_0x78998++)_0x45fe47[_0x78998]=_0x39c201[_0x27e4ec]<<0x18|_0x39c201[_0x27e4ec+0x1]<<0x10|_0x39c201[_0x27e4ec+0x2]<<0x8|_0x39c201[_0x27e4ec+0x3],_0x27e4ec+=0x4;}for(let _0x109f46=0x10;_0x109f46<0x50;_0x109f46++){const _0x23fe81=_0x45fe47[_0x109f46-0x3]^_0x45fe47[_0x109f46-0x8]^_0x45fe47[_0x109f46-0xe]^_0x45fe47[_0x109f46-0x10];_0x45fe47[_0x109f46]=(_0x23fe81<<0x1|_0x23fe81>>>0x1f)&0xffffffff;}let _0x38b17f=this['chain_'][0x0],_0x3566e9=this['chain_'][0x1],_0x1ba325=this['chain_'][0x2],_0x2daf14=this['chain_'][0x3],_0x1ef2d8=this['chain_'][0x4],_0x1ad7f1,_0x3a2d69;for(let _0x475aff=0x0;_0x475aff<0x50;_0x475aff++){_0x475aff<0x28?_0x475aff<0x14?(_0x1ad7f1=_0x2daf14^_0x3566e9&(_0x1ba325^_0x2daf14),_0x3a2d69=0x5a827999):(_0x1ad7f1=_0x3566e9^_0x1ba325^_0x2daf14,_0x3a2d69=0x6ed9eba1):_0x475aff<0x3c?(_0x1ad7f1=_0x3566e9&_0x1ba325|_0x2daf14&(_0x3566e9|_0x1ba325),_0x3a2d69=0x8f1bbcdc):(_0x1ad7f1=_0x3566e9^_0x1ba325^_0x2daf14,_0x3a2d69=0xca62c1d6);const _0x13755d=(_0x38b17f<<0x5|_0x38b17f>>>0x1b)+_0x1ad7f1+_0x1ef2d8+_0x3a2d69+_0x45fe47[_0x475aff]&0xffffffff;_0x1ef2d8=_0x2daf14,_0x2daf14=_0x1ba325,_0x1ba325=(_0x3566e9<<0x1e|_0x3566e9>>>0x2)&0xffffffff,_0x3566e9=_0x38b17f,_0x38b17f=_0x13755d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x38b17f&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3566e9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x1ba325&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2daf14&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x1ef2d8&0xffffffff;}['update'](_0x115f22,_0x1e7599){if(_0x115f22==null)return;_0x1e7599===void 0x0&&(_0x1e7599=_0x115f22['length']);const _0x2b8e71=_0x1e7599-this['blockSize'];let _0x530f29=0x0;const _0xc475c8=this['buf_'];let _0x232905=this['inbuf_'];for(;_0x530f29<_0x1e7599;){if(_0x232905===0x0){for(;_0x530f29<=_0x2b8e71;)this['compress_'](_0x115f22,_0x530f29),_0x530f29+=this['blockSize'];}if(typeof _0x115f22=='string'){for(;_0x530f29<_0x1e7599;)if(_0xc475c8[_0x232905]=_0x115f22['charCodeAt'](_0x530f29),++_0x232905,++_0x530f29,_0x232905===this['blockSize']){this['compress_'](_0xc475c8),_0x232905=0x0;break;}}else{for(;_0x530f29<_0x1e7599;)if(_0xc475c8[_0x232905]=_0x115f22[_0x530f29],++_0x232905,++_0x530f29,_0x232905===this['blockSize']){this['compress_'](_0xc475c8),_0x232905=0x0;break;}}}this['inbuf_']=_0x232905,this['total_']+=_0x1e7599;}['digest'](){const _0x6d9ca9=[];let _0x5bf47b=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5ebb46=this['blockSize']-0x1;_0x5ebb46>=0x38;_0x5ebb46--)this['buf_'][_0x5ebb46]=_0x5bf47b&0xff,_0x5bf47b/=0x100;this['compress_'](this['buf_']);let _0xa4e5dc=0x0;for(let _0x1e5aa9=0x0;_0x1e5aa9<0x5;_0x1e5aa9++)for(let _0x3fb794=0x18;_0x3fb794>=0x0;_0x3fb794-=0x8)_0x6d9ca9[_0xa4e5dc]=this['chain_'][_0x1e5aa9]>>_0x3fb794&0xff,++_0xa4e5dc;return _0x6d9ca9;}}function Tc(_0xf48547,_0x457c8c){const _0x35706b=new Sc(_0xf48547,_0x457c8c);return _0x35706b['subscribe']['bind'](_0x35706b);}class Sc{constructor(_0x4c7b23,_0x1a99a9){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1a99a9,this['task']['then'](()=>{_0x4c7b23(this);})['catch'](_0x58931a=>{this['error'](_0x58931a);});}['next'](_0x541b42){this['forEachObserver'](_0x14014d=>{_0x14014d['next'](_0x541b42);});}['error'](_0x49a5d0){this['forEachObserver'](_0x506521=>{_0x506521['error'](_0x49a5d0);}),this['close'](_0x49a5d0);}['complete'](){this['forEachObserver'](_0x5b508f=>{_0x5b508f['complete']();}),this['close']();}['subscribe'](_0x39e934,_0x4a5cab,_0x6e7e8b){let _0x508dd9;if(_0x39e934===void 0x0&&_0x4a5cab===void 0x0&&_0x6e7e8b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x39e934,['next','error','complete'])?_0x508dd9=_0x39e934:_0x508dd9={'next':_0x39e934,'error':_0x4a5cab,'complete':_0x6e7e8b},_0x508dd9['next']===void 0x0&&(_0x508dd9['next']=ti),_0x508dd9['error']===void 0x0&&(_0x508dd9['error']=ti),_0x508dd9['complete']===void 0x0&&(_0x508dd9['complete']=ti);const _0x5cfa73=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x508dd9['error'](this['finalError']):_0x508dd9['complete']();}catch{}}),this['observers']['push'](_0x508dd9),_0x5cfa73;}['unsubscribeOne'](_0xbbb4a1){this['observers']===void 0x0||this['observers'][_0xbbb4a1]===void 0x0||(delete this['observers'][_0xbbb4a1],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x199c5b){if(!this['finalized']){for(let _0x5637d4=0x0;_0x5637d4<this['observers']['length'];_0x5637d4++)this['sendOne'](_0x5637d4,_0x199c5b);}}['sendOne'](_0x4f06fc,_0x3dc2e4){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x4f06fc]!==void 0x0)try{_0x3dc2e4(this['observers'][_0x4f06fc]);}catch(_0x181fd4){typeof console<'u'&&console['error']&&console['error'](_0x181fd4);}});}['close'](_0x1c345f){this['finalized']||(this['finalized']=!0x0,_0x1c345f!==void 0x0&&(this['finalError']=_0x1c345f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x49e149,_0x124ccc){if(typeof _0x49e149!='object'||_0x49e149===null)return!0x1;for(const _0x5e90ce of _0x124ccc)if(_0x5e90ce in _0x49e149&&typeof _0x49e149[_0x5e90ce]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x15b6a3,_0x1cf57a){return _0x15b6a3+'\x20failed:\x20'+_0x1cf57a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0xc00e56){const _0x24c98e=[];let _0x382eef=0x0;for(let _0x16711e=0x0;_0x16711e<_0xc00e56['length'];_0x16711e++){let _0xcc2e7f=_0xc00e56['charCodeAt'](_0x16711e);if(_0xcc2e7f>=0xd800&&_0xcc2e7f<=0xdbff){const _0x5092a0=_0xcc2e7f-0xd800;_0x16711e++,f(_0x16711e<_0xc00e56['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x51afa1=_0xc00e56['charCodeAt'](_0x16711e)-0xdc00;_0xcc2e7f=0x10000+(_0x5092a0<<0xa)+_0x51afa1;}_0xcc2e7f<0x80?_0x24c98e[_0x382eef++]=_0xcc2e7f:_0xcc2e7f<0x800?(_0x24c98e[_0x382eef++]=_0xcc2e7f>>0x6|0xc0,_0x24c98e[_0x382eef++]=_0xcc2e7f&0x3f|0x80):_0xcc2e7f<0x10000?(_0x24c98e[_0x382eef++]=_0xcc2e7f>>0xc|0xe0,_0x24c98e[_0x382eef++]=_0xcc2e7f>>0x6&0x3f|0x80,_0x24c98e[_0x382eef++]=_0xcc2e7f&0x3f|0x80):(_0x24c98e[_0x382eef++]=_0xcc2e7f>>0x12|0xf0,_0x24c98e[_0x382eef++]=_0xcc2e7f>>0xc&0x3f|0x80,_0x24c98e[_0x382eef++]=_0xcc2e7f>>0x6&0x3f|0x80,_0x24c98e[_0x382eef++]=_0xcc2e7f&0x3f|0x80);}return _0x24c98e;},Ln=function(_0xa1346f){let _0xd437bb=0x0;for(let _0x5e93a0=0x0;_0x5e93a0<_0xa1346f['length'];_0x5e93a0++){const _0x9618c7=_0xa1346f['charCodeAt'](_0x5e93a0);_0x9618c7<0x80?_0xd437bb++:_0x9618c7<0x800?_0xd437bb+=0x2:_0x9618c7>=0xd800&&_0x9618c7<=0xdbff?(_0xd437bb+=0x4,_0x5e93a0++):_0xd437bb+=0x3;}return _0xd437bb;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3086f1){return _0x3086f1&&_0x3086f1['_delegate']?_0x3086f1['_delegate']:_0x3086f1;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3be917){try{return(_0x3be917['startsWith']('http://')||_0x3be917['startsWith']('https://')?new URL(_0x3be917)['hostname']:_0x3be917)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x30c946){return(await fetch(_0x30c946,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x3d5a02,_0x3ba056,_0xe60c4b){this['name']=_0x3d5a02,this['instanceFactory']=_0x3ba056,this['type']=_0xe60c4b,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x299801){return this['instantiationMode']=_0x299801,this;}['setMultipleInstances'](_0x1633da){return this['multipleInstances']=_0x1633da,this;}['setServiceProps'](_0x13f895){return this['serviceProps']=_0x13f895,this;}['setInstanceCreatedCallback'](_0x2705d2){return this['onInstanceCreated']=_0x2705d2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2a1426,_0x24ba9e){this['name']=_0x2a1426,this['container']=_0x24ba9e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xbcc9b8){const _0x5e5f93=this['normalizeInstanceIdentifier'](_0xbcc9b8);if(!this['instancesDeferred']['has'](_0x5e5f93)){const _0x1f4d7a=new H();if(this['instancesDeferred']['set'](_0x5e5f93,_0x1f4d7a),this['isInitialized'](_0x5e5f93)||this['shouldAutoInitialize']())try{const _0x24905a=this['getOrInitializeService']({'instanceIdentifier':_0x5e5f93});_0x24905a&&_0x1f4d7a['resolve'](_0x24905a);}catch{}}return this['instancesDeferred']['get'](_0x5e5f93)['promise'];}['getImmediate'](_0x9cbf04){const _0x5b54e5=this['normalizeInstanceIdentifier'](_0x9cbf04==null?void 0x0:_0x9cbf04['identifier']),_0x4c3fa1=(_0x9cbf04==null?void 0x0:_0x9cbf04['optional'])??!0x1;if(this['isInitialized'](_0x5b54e5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5b54e5});}catch(_0x237339){if(_0x4c3fa1)return null;throw _0x237339;}else{if(_0x4c3fa1)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x497955){if(_0x497955['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x497955['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x497955,!!this['shouldAutoInitialize']()){if(Pc(_0x497955))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x455a58,_0xc95102]of this['instancesDeferred']['entries']()){const _0x33ec34=this['normalizeInstanceIdentifier'](_0x455a58);try{const _0x114276=this['getOrInitializeService']({'instanceIdentifier':_0x33ec34});_0xc95102['resolve'](_0x114276);}catch{}}}}['clearInstance'](_0x58cf1a=Ne){this['instancesDeferred']['delete'](_0x58cf1a),this['instancesOptions']['delete'](_0x58cf1a),this['instances']['delete'](_0x58cf1a);}async['delete'](){const _0x291efb=Array['from'](this['instances']['values']());await Promise['all']([..._0x291efb['filter'](_0x4a71db=>'INTERNAL'in _0x4a71db)['map'](_0x5cde87=>_0x5cde87['INTERNAL']['delete']()),..._0x291efb['filter'](_0x3dbaa8=>'_delete'in _0x3dbaa8)['map'](_0x191fd8=>_0x191fd8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x55dfce=Ne){return this['instances']['has'](_0x55dfce);}['getOptions'](_0x3db1e5=Ne){return this['instancesOptions']['get'](_0x3db1e5)||{};}['initialize'](_0x504b9c={}){const {options:_0x2685fd={}}=_0x504b9c,_0x45bbc5=this['normalizeInstanceIdentifier'](_0x504b9c['instanceIdentifier']);if(this['isInitialized'](_0x45bbc5))throw Error(this['name']+'('+_0x45bbc5+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x43258d=this['getOrInitializeService']({'instanceIdentifier':_0x45bbc5,'options':_0x2685fd});for(const [_0x59a3b6,_0x4ef9e0]of this['instancesDeferred']['entries']()){const _0x5c5bdf=this['normalizeInstanceIdentifier'](_0x59a3b6);_0x45bbc5===_0x5c5bdf&&_0x4ef9e0['resolve'](_0x43258d);}return _0x43258d;}['onInit'](_0xf35413,_0x52f145){const _0x2b1868=this['normalizeInstanceIdentifier'](_0x52f145),_0x41a43a=this['onInitCallbacks']['get'](_0x2b1868)??new Set();_0x41a43a['add'](_0xf35413),this['onInitCallbacks']['set'](_0x2b1868,_0x41a43a);const _0x3149fc=this['instances']['get'](_0x2b1868);return _0x3149fc&&_0xf35413(_0x3149fc,_0x2b1868),()=>{_0x41a43a['delete'](_0xf35413);};}['invokeOnInitCallbacks'](_0x50312e,_0x10b053){const _0x50bc40=this['onInitCallbacks']['get'](_0x10b053);if(_0x50bc40){for(const _0x326420 of _0x50bc40)try{_0x326420(_0x50312e,_0x10b053);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3ae9ba,options:_0xee61e0={}}){let _0x404916=this['instances']['get'](_0x3ae9ba);if(!_0x404916&&this['component']&&(_0x404916=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x3ae9ba),'options':_0xee61e0}),this['instances']['set'](_0x3ae9ba,_0x404916),this['instancesOptions']['set'](_0x3ae9ba,_0xee61e0),this['invokeOnInitCallbacks'](_0x404916,_0x3ae9ba),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3ae9ba,_0x404916);}catch{}return _0x404916||null;}['normalizeInstanceIdentifier'](_0x4dc217=Ne){return this['component']?this['component']['multipleInstances']?_0x4dc217:Ne:_0x4dc217;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x36cd87){return _0x36cd87===Ne?void 0x0:_0x36cd87;}function Pc(_0x285719){return _0x285719['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x489c74){this['name']=_0x489c74,this['providers']=new Map();}['addComponent'](_0x195015){const _0x4e9052=this['getProvider'](_0x195015['name']);if(_0x4e9052['isComponentSet']())throw new Error('Component\x20'+_0x195015['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4e9052['setComponent'](_0x195015);}['addOrOverwriteComponent'](_0x2886fa){this['getProvider'](_0x2886fa['name'])['isComponentSet']()&&this['providers']['delete'](_0x2886fa['name']),this['addComponent'](_0x2886fa);}['getProvider'](_0x24429b){if(this['providers']['has'](_0x24429b))return this['providers']['get'](_0x24429b);const _0x5827e4=new Ac(_0x24429b,this);return this['providers']['set'](_0x24429b,_0x5827e4),_0x5827e4;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x375ad0){_0x375ad0[_0x375ad0['DEBUG']=0x0]='DEBUG',_0x375ad0[_0x375ad0['VERBOSE']=0x1]='VERBOSE',_0x375ad0[_0x375ad0['INFO']=0x2]='INFO',_0x375ad0[_0x375ad0['WARN']=0x3]='WARN',_0x375ad0[_0x375ad0['ERROR']=0x4]='ERROR',_0x375ad0[_0x375ad0['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x14887f,_0x296fab,..._0x2061a1)=>{if(_0x296fab<_0x14887f['logLevel'])return;const _0x4718b9=new Date()['toISOString'](),_0x3376aa=Mc[_0x296fab];if(_0x3376aa)console[_0x3376aa]('['+_0x4718b9+']\x20\x20'+_0x14887f['name']+':',..._0x2061a1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x296fab+')');};class Bi{constructor(_0x24eb24){this['name']=_0x24eb24,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xd828b2){if(!(_0xd828b2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xd828b2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xd828b2;}['setLogLevel'](_0x432dff){this['_logLevel']=typeof _0x432dff=='string'?Oc[_0x432dff]:_0x432dff;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x35ee8c){if(typeof _0x35ee8c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x35ee8c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x22c7c2){this['_userLogHandler']=_0x22c7c2;}['debug'](..._0x508f53){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x508f53),this['_logHandler'](this,T['DEBUG'],..._0x508f53);}['log'](..._0x180bc1){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x180bc1),this['_logHandler'](this,T['VERBOSE'],..._0x180bc1);}['info'](..._0x492db9){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x492db9),this['_logHandler'](this,T['INFO'],..._0x492db9);}['warn'](..._0x2707c9){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2707c9),this['_logHandler'](this,T['WARN'],..._0x2707c9);}['error'](..._0x549573){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x549573),this['_logHandler'](this,T['ERROR'],..._0x549573);}}const xc=(_0x2db9aa,_0x4bdb1b)=>_0x4bdb1b['some'](_0x3aa442=>_0x2db9aa instanceof _0x3aa442);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x3a726e){const _0xd9139f=new Promise((_0x29d5e9,_0x39cfff)=>{const _0x25a33e=()=>{_0x3a726e['removeEventListener']('success',_0x184593),_0x3a726e['removeEventListener']('error',_0x44ee2a);},_0x184593=()=>{_0x29d5e9(ge(_0x3a726e['result'])),_0x25a33e();},_0x44ee2a=()=>{_0x39cfff(_0x3a726e['error']),_0x25a33e();};_0x3a726e['addEventListener']('success',_0x184593),_0x3a726e['addEventListener']('error',_0x44ee2a);});return _0xd9139f['then'](_0x388288=>{_0x388288 instanceof IDBCursor&&Jr['set'](_0x388288,_0x3a726e);})['catch'](()=>{}),Vi['set'](_0xd9139f,_0x3a726e),_0xd9139f;}function Bc(_0x5c232a){if(_i['has'](_0x5c232a))return;const _0x1944c2=new Promise((_0x4715c1,_0x291373)=>{const _0x376faa=()=>{_0x5c232a['removeEventListener']('complete',_0x1966de),_0x5c232a['removeEventListener']('error',_0x32d3cf),_0x5c232a['removeEventListener']('abort',_0x32d3cf);},_0x1966de=()=>{_0x4715c1(),_0x376faa();},_0x32d3cf=()=>{_0x291373(_0x5c232a['error']||new DOMException('AbortError','AbortError')),_0x376faa();};_0x5c232a['addEventListener']('complete',_0x1966de),_0x5c232a['addEventListener']('error',_0x32d3cf),_0x5c232a['addEventListener']('abort',_0x32d3cf);});_i['set'](_0x5c232a,_0x1944c2);}let gi={'get'(_0x2bd35b,_0x412203,_0x52224e){if(_0x2bd35b instanceof IDBTransaction){if(_0x412203==='done')return _i['get'](_0x2bd35b);if(_0x412203==='objectStoreNames')return _0x2bd35b['objectStoreNames']||Xr['get'](_0x2bd35b);if(_0x412203==='store')return _0x52224e['objectStoreNames'][0x1]?void 0x0:_0x52224e['objectStore'](_0x52224e['objectStoreNames'][0x0]);}return ge(_0x2bd35b[_0x412203]);},'set'(_0x3fbe67,_0x2d4cd2,_0x2d9cd7){return _0x3fbe67[_0x2d4cd2]=_0x2d9cd7,!0x0;},'has'(_0x38c3f5,_0x386c62){return _0x38c3f5 instanceof IDBTransaction&&(_0x386c62==='done'||_0x386c62==='store')?!0x0:_0x386c62 in _0x38c3f5;}};function Vc(_0x3d6264){gi=_0x3d6264(gi);}function Hc(_0xcd65e6){return _0xcd65e6===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x1748b4,..._0x586e76){const _0x26498b=_0xcd65e6['call'](ii(this),_0x1748b4,..._0x586e76);return Xr['set'](_0x26498b,_0x1748b4['sort']?_0x1748b4['sort']():[_0x1748b4]),ge(_0x26498b);}:Uc()['includes'](_0xcd65e6)?function(..._0x4336d2){return _0xcd65e6['apply'](ii(this),_0x4336d2),ge(Jr['get'](this));}:function(..._0x526c49){return ge(_0xcd65e6['apply'](ii(this),_0x526c49));};}function $c(_0x79e4e){return typeof _0x79e4e=='function'?Hc(_0x79e4e):(_0x79e4e instanceof IDBTransaction&&Bc(_0x79e4e),xc(_0x79e4e,Fc())?new Proxy(_0x79e4e,gi):_0x79e4e);}function ge(_0x17df46){if(_0x17df46 instanceof IDBRequest)return Wc(_0x17df46);if(ni['has'](_0x17df46))return ni['get'](_0x17df46);const _0x17a0e8=$c(_0x17df46);return _0x17a0e8!==_0x17df46&&(ni['set'](_0x17df46,_0x17a0e8),Vi['set'](_0x17a0e8,_0x17df46)),_0x17a0e8;}const ii=_0x40d262=>Vi['get'](_0x40d262);function Gc(_0x1de875,_0x228ef2,{blocked:_0x3ae832,upgrade:_0x21ef1d,blocking:_0x389c54,terminated:_0x490561}={}){const _0x4568f6=indexedDB['open'](_0x1de875,_0x228ef2),_0x588d5e=ge(_0x4568f6);return _0x21ef1d&&_0x4568f6['addEventListener']('upgradeneeded',_0x3069f5=>{_0x21ef1d(ge(_0x4568f6['result']),_0x3069f5['oldVersion'],_0x3069f5['newVersion'],ge(_0x4568f6['transaction']),_0x3069f5);}),_0x3ae832&&_0x4568f6['addEventListener']('blocked',_0x276922=>_0x3ae832(_0x276922['oldVersion'],_0x276922['newVersion'],_0x276922)),_0x588d5e['then'](_0x29194f=>{_0x490561&&_0x29194f['addEventListener']('close',()=>_0x490561()),_0x389c54&&_0x29194f['addEventListener']('versionchange',_0x1354e6=>_0x389c54(_0x1354e6['oldVersion'],_0x1354e6['newVersion'],_0x1354e6));})['catch'](()=>{}),_0x588d5e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x23d670,_0x3d5937){if(!(_0x23d670 instanceof IDBDatabase&&!(_0x3d5937 in _0x23d670)&&typeof _0x3d5937=='string'))return;if(si['get'](_0x3d5937))return si['get'](_0x3d5937);const _0x453e57=_0x3d5937['replace'](/FromIndex$/,''),_0x2a77f4=_0x3d5937!==_0x453e57,_0x1b4d5c=zc['includes'](_0x453e57);if(!(_0x453e57 in(_0x2a77f4?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1b4d5c||qc['includes'](_0x453e57)))return;const _0x1a64a5=async function(_0x40d973,..._0x2f81c1){const _0x5b8af9=this['transaction'](_0x40d973,_0x1b4d5c?'readwrite':'readonly');let _0x1043c8=_0x5b8af9['store'];return _0x2a77f4&&(_0x1043c8=_0x1043c8['index'](_0x2f81c1['shift']())),(await Promise['all']([_0x1043c8[_0x453e57](..._0x2f81c1),_0x1b4d5c&&_0x5b8af9['done']]))[0x0];};return si['set'](_0x3d5937,_0x1a64a5),_0x1a64a5;}Vc(_0xf8cdc5=>({..._0xf8cdc5,'get':(_0x5f2bce,_0xe5d790,_0x3bf761)=>Ms(_0x5f2bce,_0xe5d790)||_0xf8cdc5['get'](_0x5f2bce,_0xe5d790,_0x3bf761),'has':(_0x355c6a,_0x1fd59f)=>!!Ms(_0x355c6a,_0x1fd59f)||_0xf8cdc5['has'](_0x355c6a,_0x1fd59f)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4c6260){this['container']=_0x4c6260;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2d31b2=>{if(Kc(_0x2d31b2)){const _0x344a07=_0x2d31b2['getImmediate']();return _0x344a07['library']+'/'+_0x344a07['version'];}else return null;})['filter'](_0x4313a4=>_0x4313a4)['join']('\x20');}}function Kc(_0x9dd0bc){const _0x52cb23=_0x9dd0bc['getComponent']();return(_0x52cb23==null?void 0x0:_0x52cb23['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2cfb80,_0x308513){try{_0x2cfb80['container']['addComponent'](_0x308513);}catch(_0x5749d2){oe['debug']('Component\x20'+_0x308513['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2cfb80['name'],_0x5749d2);}}function st(_0x151bb4){const _0x31e793=_0x151bb4['name'];if(Ei['has'](_0x31e793))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x31e793+'.'),!0x1;Ei['set'](_0x31e793,_0x151bb4);for(const _0x3d03ac of Ue['values']())xs(_0x3d03ac,_0x151bb4);for(const _0x451776 of vi['values']())xs(_0x451776,_0x151bb4);return!0x0;}function Hi(_0x52b0de,_0x3fe5b3){const _0x116f5f=_0x52b0de['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x116f5f&&_0x116f5f['triggerHeartbeat'](),_0x52b0de['container']['getProvider'](_0x3fe5b3);}function $(_0x2fcfb9){return _0x2fcfb9==null?!0x1:_0x2fcfb9['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x39ffe1,_0x782761,_0xa1674e){this['_isDeleted']=!0x1,this['_options']={..._0x39ffe1},this['_config']={..._0x782761},this['_name']=_0x782761['name'],this['_automaticDataCollectionEnabled']=_0x782761['automaticDataCollectionEnabled'],this['_container']=_0xa1674e,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x348927){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x348927;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1bd070){this['_isDeleted']=_0x1bd070;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0xc1bae7,_0x4eeba2={}){let _0x135e68=_0xc1bae7;typeof _0x4eeba2!='object'&&(_0x4eeba2={'name':_0x4eeba2});const _0x1c3e98={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4eeba2},_0x16b851=_0x1c3e98['name'];if(typeof _0x16b851!='string'||!_0x16b851)throw me['create']('bad-app-name',{'appName':String(_0x16b851)});if(_0x135e68||(_0x135e68=zr()),!_0x135e68)throw me['create']('no-options');const _0x3d8b51=Ue['get'](_0x16b851);if(_0x3d8b51){if(xe(_0x135e68,_0x3d8b51['options'])&&xe(_0x1c3e98,_0x3d8b51['config']))return _0x3d8b51;throw me['create']('duplicate-app',{'appName':_0x16b851});}const _0xa98c48=new Nc(_0x16b851);for(const _0x1d8b0c of Ei['values']())_0xa98c48['addComponent'](_0x1d8b0c);const _0x36197a=new Tl(_0x135e68,_0x1c3e98,_0xa98c48);return Ue['set'](_0x16b851,_0x36197a),_0x36197a;}function Zr(_0x32454b=yi){const _0xde0b7b=Ue['get'](_0x32454b);if(!_0xde0b7b&&_0x32454b===yi&&zr())return Sl();if(!_0xde0b7b)throw me['create']('no-app',{'appName':_0x32454b});return _0xde0b7b;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x1fd79b){let _0x1a8a91=!0x1;const _0x2f61c3=_0x1fd79b['name'];Ue['has'](_0x2f61c3)?(_0x1a8a91=!0x0,Ue['delete'](_0x2f61c3)):vi['has'](_0x2f61c3)&&_0x1fd79b['decRefCount']()<=0x0&&(vi['delete'](_0x2f61c3),_0x1a8a91=!0x0),_0x1a8a91&&(await Promise['all'](_0x1fd79b['container']['getProviders']()['map'](_0x17fc53=>_0x17fc53['delete']())),_0x1fd79b['isDeleted']=!0x0);}function ye(_0x35b627,_0x3f25f1,_0x2a8e03){let _0x5398a5=wl[_0x35b627]??_0x35b627;_0x2a8e03&&(_0x5398a5+='-'+_0x2a8e03);const _0x3fb06f=_0x5398a5['match'](/\s|\//),_0x32660c=_0x3f25f1['match'](/\s|\//);if(_0x3fb06f||_0x32660c){const _0x2fe78d=['Unable\x20to\x20register\x20library\x20\x22'+_0x5398a5+'\x22\x20with\x20version\x20\x22'+_0x3f25f1+'\x22:'];_0x3fb06f&&_0x2fe78d['push']('library\x20name\x20\x22'+_0x5398a5+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3fb06f&&_0x32660c&&_0x2fe78d['push']('and'),_0x32660c&&_0x2fe78d['push']('version\x20name\x20\x22'+_0x3f25f1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2fe78d['join']('\x20'));return;}st(new Fe(_0x5398a5+'-version',()=>({'library':_0x5398a5,'version':_0x3f25f1}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x21a72a,_0x3ffc57)=>{switch(_0x3ffc57){case 0x0:try{_0x21a72a['createObjectStore'](Ot);}catch(_0x942e28){console['warn'](_0x942e28);}}}})['catch'](_0x41c6ae=>{throw me['create']('idb-open',{'originalErrorMessage':_0x41c6ae['message']});})),ri;}async function Al(_0x28ffca){try{const _0x5754e4=(await eo())['transaction'](Ot),_0x356db4=await _0x5754e4['objectStore'](Ot)['get'](to(_0x28ffca));return await _0x5754e4['done'],_0x356db4;}catch(_0x11a9f4){if(_0x11a9f4 instanceof Re)oe['warn'](_0x11a9f4['message']);else{const _0x84c469=me['create']('idb-get',{'originalErrorMessage':_0x11a9f4==null?void 0x0:_0x11a9f4['message']});oe['warn'](_0x84c469['message']);}}}async function Fs(_0x4aedee,_0x4afa1e){try{const _0x3b48d3=(await eo())['transaction'](Ot,'readwrite');await _0x3b48d3['objectStore'](Ot)['put'](_0x4afa1e,to(_0x4aedee)),await _0x3b48d3['done'];}catch(_0x2f242d){if(_0x2f242d instanceof Re)oe['warn'](_0x2f242d['message']);else{const _0x2bf650=me['create']('idb-set',{'originalErrorMessage':_0x2f242d==null?void 0x0:_0x2f242d['message']});oe['warn'](_0x2bf650['message']);}}}function to(_0x3b4d25){return _0x3b4d25['name']+'!'+_0x3b4d25['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x5e826b){this['container']=_0x5e826b,this['_heartbeatsCache']=null;const _0x5bdc13=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5bdc13),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2f3e8b=>(this['_heartbeatsCache']=_0x2f3e8b,_0x2f3e8b));}async['triggerHeartbeat'](){var _0x5a9c9b,_0x3a5dff;try{const _0x45c4d9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x20a4d3=Us();if(((_0x5a9c9b=this['_heartbeatsCache'])==null?void 0x0:_0x5a9c9b['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3a5dff=this['_heartbeatsCache'])==null?void 0x0:_0x3a5dff['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x20a4d3||this['_heartbeatsCache']['heartbeats']['some'](_0x272f5e=>_0x272f5e['date']===_0x20a4d3))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x20a4d3,'agent':_0x45c4d9}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x2272dd=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2272dd,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x36bca6){oe['warn'](_0x36bca6);}}async['getHeartbeatsHeader'](){var _0x661674;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x661674=this['_heartbeatsCache'])==null?void 0x0:_0x661674['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1a06e3=Us(),{heartbeatsToSend:_0x41d952,unsentEntries:_0xd8fbaa}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4be309=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x41d952}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1a06e3,_0xd8fbaa['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xd8fbaa,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4be309;}catch(_0x53b7f5){return oe['warn'](_0x53b7f5),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x357762,_0x121930=kl){const _0x21045f=[];let _0x165878=_0x357762['slice']();for(const _0x94f4ca of _0x357762){const _0xcbfe84=_0x21045f['find'](_0x1da121=>_0x1da121['agent']===_0x94f4ca['agent']);if(_0xcbfe84){if(_0xcbfe84['dates']['push'](_0x94f4ca['date']),Ws(_0x21045f)>_0x121930){_0xcbfe84['dates']['pop']();break;}}else{if(_0x21045f['push']({'agent':_0x94f4ca['agent'],'dates':[_0x94f4ca['date']]}),Ws(_0x21045f)>_0x121930){_0x21045f['pop']();break;}}_0x165878=_0x165878['slice'](0x1);}return{'heartbeatsToSend':_0x21045f,'unsentEntries':_0x165878};}class Dl{constructor(_0x11ec46){this['app']=_0x11ec46,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x138ed3=await Al(this['app']);return _0x138ed3!=null&&_0x138ed3['heartbeats']?_0x138ed3:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4dd8f2){if(await this['_canUseIndexedDBPromise']){const _0x3e38d0=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4dd8f2['lastSentHeartbeatDate']??_0x3e38d0['lastSentHeartbeatDate'],'heartbeats':_0x4dd8f2['heartbeats']});}else return;}async['add'](_0x4e0d12){if(await this['_canUseIndexedDBPromise']){const _0x2318cb=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4e0d12['lastSentHeartbeatDate']??_0x2318cb['lastSentHeartbeatDate'],'heartbeats':[..._0x2318cb['heartbeats'],..._0x4e0d12['heartbeats']]});}else return;}}function Ws(_0x3712d3){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3712d3}))['length'];}function Ml(_0x5e48f3){if(_0x5e48f3['length']===0x0)return-0x1;let _0x50b08c=0x0,_0x32a271=_0x5e48f3[0x0]['date'];for(let _0x917b85=0x1;_0x917b85<_0x5e48f3['length'];_0x917b85++)_0x5e48f3[_0x917b85]['date']<_0x32a271&&(_0x32a271=_0x5e48f3[_0x917b85]['date'],_0x50b08c=_0x917b85);return _0x50b08c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x106c8c){st(new Fe('platform-logger',_0x366a22=>new jc(_0x366a22),'PRIVATE')),st(new Fe('heartbeat',_0x5e3436=>new Nl(_0x5e3436),'PRIVATE')),ye(mi,Ls,_0x106c8c),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x279622){no=_0x279622;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x46737d){this['domStorage_']=_0x46737d,this['prefix_']='firebase:';}['set'](_0x384ee3,_0x40135c){_0x40135c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x384ee3)):this['domStorage_']['setItem'](this['prefixedName_'](_0x384ee3),O(_0x40135c));}['get'](_0x432f77){const _0xf0e547=this['domStorage_']['getItem'](this['prefixedName_'](_0x432f77));return _0xf0e547==null?null:Nt(_0xf0e547);}['remove'](_0x251e38){this['domStorage_']['removeItem'](this['prefixedName_'](_0x251e38));}['prefixedName_'](_0x5b7c7){return this['prefix_']+_0x5b7c7;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4d2c03,_0x15530c){_0x15530c==null?delete this['cache_'][_0x4d2c03]:this['cache_'][_0x4d2c03]=_0x15530c;}['get'](_0x135a3d){return Q(this['cache_'],_0x135a3d)?this['cache_'][_0x135a3d]:null;}['remove'](_0x294a96){delete this['cache_'][_0x294a96];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4772ca){try{if(typeof window<'u'&&typeof window[_0x4772ca]<'u'){const _0x3b4ff6=window[_0x4772ca];return _0x3b4ff6['setItem']('firebase:sentinel','cache'),_0x3b4ff6['removeItem']('firebase:sentinel'),new Wl(_0x3b4ff6);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1536dd=0x1;return function(){return _0x1536dd++;};}()),ro=function(_0xf1b077){const _0x5a24fe=Rc(_0xf1b077),_0x5d31e7=new Cc();_0x5d31e7['update'](_0x5a24fe);const _0x2e1e17=_0x5d31e7['digest']();return Fi['encodeByteArray'](_0x2e1e17);},zt=function(..._0x232dd1){let _0x2c492d='';for(let _0x159056=0x0;_0x159056<_0x232dd1['length'];_0x159056++){const _0x2976f3=_0x232dd1[_0x159056];Array['isArray'](_0x2976f3)||_0x2976f3&&typeof _0x2976f3=='object'&&typeof _0x2976f3['length']=='number'?_0x2c492d+=zt['apply'](null,_0x2976f3):typeof _0x2976f3=='object'?_0x2c492d+=O(_0x2976f3):_0x2c492d+=_0x2976f3,_0x2c492d+='\x20';}return _0x2c492d;};let St=null,$s=!0x0;const Hl=function(_0x11ac1f,_0x4f5411){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x376ca2){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x510ef0=zt['apply'](null,_0x376ca2);St(_0x510ef0);}},jt=function(_0x2f9fc3){return function(..._0x5c7711){L(_0x2f9fc3,..._0x5c7711);};},Ii=function(..._0x1adadb){const _0x4ecc08='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1adadb);Ze['error'](_0x4ecc08);},ae=function(..._0x1f9575){const _0x3e0f54='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1f9575);throw Ze['error'](_0x3e0f54),new Error(_0x3e0f54);},U=function(..._0xd623a4){const _0x23c6c9='FIREBASE\x20WARNING:\x20'+zt(..._0xd623a4);Ze['warn'](_0x23c6c9);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x368c6e){return typeof _0x368c6e=='number'&&(_0x368c6e!==_0x368c6e||_0x368c6e===Number['POSITIVE_INFINITY']||_0x368c6e===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2aa605){if(document['readyState']==='complete')_0x2aa605();else{let _0x2ae64d=!0x1;const _0x5cb13b=function(){if(!document['body']){setTimeout(_0x5cb13b,Math['floor'](0xa));return;}_0x2ae64d||(_0x2ae64d=!0x0,_0x2aa605());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5cb13b,!0x1),window['addEventListener']('load',_0x5cb13b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5cb13b();}),window['attachEvent']('onload',_0x5cb13b));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4cd17b,_0x178693){if(_0x4cd17b===_0x178693)return 0x0;if(_0x4cd17b===We||_0x178693===we)return-0x1;if(_0x178693===We||_0x4cd17b===we)return 0x1;{const _0x53a2e3=Gs(_0x4cd17b),_0xc93d96=Gs(_0x178693);return _0x53a2e3!==null?_0xc93d96!==null?_0x53a2e3-_0xc93d96===0x0?_0x4cd17b['length']-_0x178693['length']:_0x53a2e3-_0xc93d96:-0x1:_0xc93d96!==null?0x1:_0x4cd17b<_0x178693?-0x1:0x1;}},ql=function(_0x16ba94,_0x4ac0b3){return _0x16ba94===_0x4ac0b3?0x0:_0x16ba94<_0x4ac0b3?-0x1:0x1;},vt=function(_0x4a7489,_0xbd64f2){if(_0xbd64f2&&_0x4a7489 in _0xbd64f2)return _0xbd64f2[_0x4a7489];throw new Error('Missing\x20required\x20key\x20('+_0x4a7489+')\x20in\x20object:\x20'+O(_0xbd64f2));},$i=function(_0x30a305){if(typeof _0x30a305!='object'||_0x30a305===null)return O(_0x30a305);const _0x47a64c=[];for(const _0xb5e141 in _0x30a305)_0x47a64c['push'](_0xb5e141);_0x47a64c['sort']();let _0x19a91f='{';for(let _0x32d344=0x0;_0x32d344<_0x47a64c['length'];_0x32d344++)_0x32d344!==0x0&&(_0x19a91f+=','),_0x19a91f+=O(_0x47a64c[_0x32d344]),_0x19a91f+=':',_0x19a91f+=$i(_0x30a305[_0x47a64c[_0x32d344]]);return _0x19a91f+='}',_0x19a91f;},oo=function(_0x180117,_0x332df0){const _0x5cfda4=_0x180117['length'];if(_0x5cfda4<=_0x332df0)return[_0x180117];const _0x4d7139=[];for(let _0x529e73=0x0;_0x529e73<_0x5cfda4;_0x529e73+=_0x332df0)_0x529e73+_0x332df0>_0x5cfda4?_0x4d7139['push'](_0x180117['substring'](_0x529e73,_0x5cfda4)):_0x4d7139['push'](_0x180117['substring'](_0x529e73,_0x529e73+_0x332df0));return _0x4d7139;};function x(_0x550655,_0x2a18e9){for(const _0x282623 in _0x550655)_0x550655['hasOwnProperty'](_0x282623)&&_0x2a18e9(_0x282623,_0x550655[_0x282623]);}const ao=function(_0x4a3157){f(!xn(_0x4a3157),'Invalid\x20JSON\x20number');const _0x21e867=0xb,_0x5d9791=0x34,_0x59d320=(0x1<<_0x21e867-0x1)-0x1;let _0x443ed0,_0x1020c9,_0x41c4eb,_0xad0566,_0x2c4536;_0x4a3157===0x0?(_0x1020c9=0x0,_0x41c4eb=0x0,_0x443ed0=0x1/_0x4a3157===-0x1/0x0?0x1:0x0):(_0x443ed0=_0x4a3157<0x0,_0x4a3157=Math['abs'](_0x4a3157),_0x4a3157>=Math['pow'](0x2,0x1-_0x59d320)?(_0xad0566=Math['min'](Math['floor'](Math['log'](_0x4a3157)/Math['LN2']),_0x59d320),_0x1020c9=_0xad0566+_0x59d320,_0x41c4eb=Math['round'](_0x4a3157*Math['pow'](0x2,_0x5d9791-_0xad0566)-Math['pow'](0x2,_0x5d9791))):(_0x1020c9=0x0,_0x41c4eb=Math['round'](_0x4a3157/Math['pow'](0x2,0x1-_0x59d320-_0x5d9791))));const _0x4dee1a=[];for(_0x2c4536=_0x5d9791;_0x2c4536;_0x2c4536-=0x1)_0x4dee1a['push'](_0x41c4eb%0x2?0x1:0x0),_0x41c4eb=Math['floor'](_0x41c4eb/0x2);for(_0x2c4536=_0x21e867;_0x2c4536;_0x2c4536-=0x1)_0x4dee1a['push'](_0x1020c9%0x2?0x1:0x0),_0x1020c9=Math['floor'](_0x1020c9/0x2);_0x4dee1a['push'](_0x443ed0?0x1:0x0),_0x4dee1a['reverse']();const _0xcefe1e=_0x4dee1a['join']('');let _0x26c41b='';for(_0x2c4536=0x0;_0x2c4536<0x40;_0x2c4536+=0x8){let _0x2bd90c=parseInt(_0xcefe1e['substr'](_0x2c4536,0x8),0x2)['toString'](0x10);_0x2bd90c['length']===0x1&&(_0x2bd90c='0'+_0x2bd90c),_0x26c41b=_0x26c41b+_0x2bd90c;}return _0x26c41b['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x4e09d9,_0x2199b2){let _0x1a7396='Unknown\x20Error';_0x4e09d9==='too_big'?_0x1a7396='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4e09d9==='permission_denied'?_0x1a7396='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4e09d9==='unavailable'&&(_0x1a7396='The\x20service\x20is\x20unavailable');const _0x1c4a11=new Error(_0x4e09d9+'\x20at\x20'+_0x2199b2['_path']['toString']()+':\x20'+_0x1a7396);return _0x1c4a11['code']=_0x4e09d9['toUpperCase'](),_0x1c4a11;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x10f1a0){if(Yl['test'](_0x10f1a0)){const _0x3a3562=Number(_0x10f1a0);if(_0x3a3562>=Ql&&_0x3a3562<=Jl)return _0x3a3562;}return null;},ft=function(_0x374aab){try{_0x374aab();}catch(_0x2d7791){setTimeout(()=>{const _0x1fbef3=_0x2d7791['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1fbef3),_0x2d7791;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x3e9ea3,_0x2a0b91){const _0x5a0d60=setTimeout(_0x3e9ea3,_0x2a0b91);return typeof _0x5a0d60=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x5a0d60):typeof _0x5a0d60=='object'&&_0x5a0d60['unref']&&_0x5a0d60['unref'](),_0x5a0d60;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x457644,_0x35df7d){this['appCheckProvider']=_0x35df7d,this['appName']=_0x457644['name'],$(_0x457644)&&_0x457644['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x457644['settings']['appCheckToken']),this['appCheck']=_0x35df7d==null?void 0x0:_0x35df7d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x35df7d==null||_0x35df7d['get']()['then'](_0x2fec0c=>this['appCheck']=_0x2fec0c);}['getToken'](_0x506839){if(this['serverAppAppCheckToken']){if(_0x506839)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x506839):new Promise((_0x5f849c,_0x2d716d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x506839)['then'](_0x5f849c,_0x2d716d):_0x5f849c(null);},0x0);});}['addTokenChangeListener'](_0x55547a){var _0x2b2f79;(_0x2b2f79=this['appCheckProvider'])==null||_0x2b2f79['get']()['then'](_0x23cfcd=>_0x23cfcd['addTokenListener'](_0x55547a));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x400273,_0x2f231a,_0x4152ff){this['appName_']=_0x400273,this['firebaseOptions_']=_0x2f231a,this['authProvider_']=_0x4152ff,this['auth_']=null,this['auth_']=_0x4152ff['getImmediate']({'optional':!0x0}),this['auth_']||_0x4152ff['onInit'](_0x128019=>this['auth_']=_0x128019);}['getToken'](_0x4afd6c){return this['auth_']?this['auth_']['getToken'](_0x4afd6c)['catch'](_0x4ef777=>_0x4ef777&&_0x4ef777['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4ef777)):new Promise((_0x2ca44f,_0x2f936e)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4afd6c)['then'](_0x2ca44f,_0x2f936e):_0x2ca44f(null);},0x0);});}['addTokenChangeListener'](_0x4e5fe1){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4e5fe1):this['authProvider_']['get']()['then'](_0x5b51a1=>_0x5b51a1['addAuthTokenListener'](_0x4e5fe1));}['removeTokenChangeListener'](_0x337494){this['authProvider_']['get']()['then'](_0x2be557=>_0x2be557['removeAuthTokenListener'](_0x337494));}['notifyForInvalidToken'](){let _0x597be8='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x597be8+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x597be8+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x597be8+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x597be8);}}class an{constructor(_0x231894){this['accessToken']=_0x231894;}['getToken'](_0x14b063){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3c8ba1){_0x3c8ba1(this['accessToken']);}['removeTokenChangeListener'](_0x3ba5eb){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x2525f3,_0x495e57,_0x2674e5,_0x57c143,_0x4e07d6=!0x1,_0x45a0a1='',_0x3f5899=!0x1,_0x2d2e73=!0x1,_0x1d7ea5=null){this['secure']=_0x495e57,this['namespace']=_0x2674e5,this['webSocketOnly']=_0x57c143,this['nodeAdmin']=_0x4e07d6,this['persistenceKey']=_0x45a0a1,this['includeNamespaceInQueryParams']=_0x3f5899,this['isUsingEmulator']=_0x2d2e73,this['emulatorOptions']=_0x1d7ea5,this['_host']=_0x2525f3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x2525f3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3e3d14){_0x3e3d14!==this['internalHost']&&(this['internalHost']=_0x3e3d14,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5ad0ee=this['toURLString']();return this['persistenceKey']&&(_0x5ad0ee+='<'+this['persistenceKey']+'>'),_0x5ad0ee;}['toURLString'](){const _0x4d4066=this['secure']?'https://':'http://',_0x449d45=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4d4066+this['host']+'/'+_0x449d45;}}function th(_0x5dca66){return _0x5dca66['host']!==_0x5dca66['internalHost']||_0x5dca66['isCustomHost']()||_0x5dca66['includeNamespaceInQueryParams'];}function vo(_0x42a2a0,_0x40b0bd,_0x4b5f08){f(typeof _0x40b0bd=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4b5f08=='object','typeof\x20params\x20must\x20==\x20object');let _0x7a5bdc;if(_0x40b0bd===go)_0x7a5bdc=(_0x42a2a0['secure']?'wss://':'ws://')+_0x42a2a0['internalHost']+'/.ws?';else{if(_0x40b0bd===mo)_0x7a5bdc=(_0x42a2a0['secure']?'https://':'http://')+_0x42a2a0['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x40b0bd);}th(_0x42a2a0)&&(_0x4b5f08['ns']=_0x42a2a0['namespace']);const _0x10a7fb=[];return x(_0x4b5f08,(_0x3bf4cd,_0x159a6a)=>{_0x10a7fb['push'](_0x3bf4cd+'='+_0x159a6a);}),_0x7a5bdc+_0x10a7fb['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x38a758,_0x4ee8ed=0x1){Q(this['counters_'],_0x38a758)||(this['counters_'][_0x38a758]=0x0),this['counters_'][_0x38a758]+=_0x4ee8ed;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3ebab9){const _0x38140c=_0x3ebab9['toString']();return oi[_0x38140c]||(oi[_0x38140c]=new nh()),oi[_0x38140c];}function ih(_0xce8627,_0x3320f1){const _0x12b842=_0xce8627['toString']();return ai[_0x12b842]||(ai[_0x12b842]=_0x3320f1()),ai[_0x12b842];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x39f1ff){this['onMessage_']=_0x39f1ff,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x47f44e,_0x7f7dc2){this['closeAfterResponse']=_0x47f44e,this['onClose']=_0x7f7dc2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2ad371,_0x3a3ed2){for(this['pendingResponses'][_0x2ad371]=_0x3a3ed2;this['pendingResponses'][this['currentResponseNum']];){const _0x40cb6f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3075d3=0x0;_0x3075d3<_0x40cb6f['length'];++_0x3075d3)_0x40cb6f[_0x3075d3]&&ft(()=>{this['onMessage_'](_0x40cb6f[_0x3075d3]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x394d34,_0x185529,_0x222bd3,_0xee8287,_0x3ce1e8,_0x2a74d7,_0x26248f){this['connId']=_0x394d34,this['repoInfo']=_0x185529,this['applicationId']=_0x222bd3,this['appCheckToken']=_0xee8287,this['authToken']=_0x3ce1e8,this['transportSessionId']=_0x2a74d7,this['lastSessionId']=_0x26248f,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x394d34),this['stats_']=qi(_0x185529),this['urlFn']=_0x35b937=>(this['appCheckToken']&&(_0x35b937[wi]=this['appCheckToken']),vo(_0x185529,mo,_0x35b937));}['open'](_0x59d9b1,_0x50cd9d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x50cd9d,this['myPacketOrderer']=new sh(_0x59d9b1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x459a03)=>{const [_0x14d9ea,_0x26864f,_0x2bbfc9,_0x24a210,_0x317918]=_0x459a03;if(this['incrementIncomingBytes_'](_0x459a03),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x14d9ea===qs)this['id']=_0x26864f,this['password']=_0x2bbfc9;else{if(_0x14d9ea===rh)_0x26864f?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x26864f,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x14d9ea);}}},(..._0x7c059e)=>{const [_0x31e85d,_0x32f547]=_0x7c059e;this['incrementIncomingBytes_'](_0x7c059e),this['myPacketOrderer']['handleResponse'](_0x31e85d,_0x32f547);},()=>{this['onClosed_']();},this['urlFn']);const _0x499613={};_0x499613[qs]='t',_0x499613[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x499613[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x499613[co]=Gi,this['transportSessionId']&&(_0x499613[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x499613[po]=this['lastSessionId']),this['applicationId']&&(_0x499613[_o]=this['applicationId']),this['appCheckToken']&&(_0x499613[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x499613[ho]=uo);const _0xa6dd4a=this['urlFn'](_0x499613);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xa6dd4a),this['scriptTagHolder']['addTag'](_0xa6dd4a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x318c9a){const _0x255eaa=O(_0x318c9a);this['bytesSent']+=_0x255eaa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x255eaa['length']);const _0xebd72c=$r(_0x255eaa),_0x5404a5=oo(_0xebd72c,fh);for(let _0xcd6db6=0x0;_0xcd6db6<_0x5404a5['length'];_0xcd6db6++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5404a5['length'],_0x5404a5[_0xcd6db6]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x65dec2,_0x4604c9){this['myDisconnFrame']=document['createElement']('iframe');const _0x276e61={};_0x276e61[dh]='t',_0x276e61[Eo]=_0x65dec2,_0x276e61[Io]=_0x4604c9,this['myDisconnFrame']['src']=this['urlFn'](_0x276e61),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x33bb84){const _0x179edf=O(_0x33bb84)['length'];this['bytesReceived']+=_0x179edf,this['stats_']['incrementCounter']('bytes_received',_0x179edf);}}class zi{constructor(_0x4ca346,_0x24467f,_0x81ee29,_0x477e66){this['onDisconnect']=_0x81ee29,this['urlFn']=_0x477e66,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x4ca346,window[ah+this['uniqueCallbackIdentifier']]=_0x24467f,this['myIFrame']=zi['createIFrame_']();let _0x48b010='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x48b010='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x20d6c9='<html><body>'+_0x48b010+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x20d6c9),this['myIFrame']['doc']['close']();}catch(_0x390562){L('frame\x20writing\x20exception'),_0x390562['stack']&&L(_0x390562['stack']),L(_0x390562);}}}static['createIFrame_'](){const _0x1f6f2e=document['createElement']('iframe');if(_0x1f6f2e['style']['display']='none',document['body']){document['body']['appendChild'](_0x1f6f2e);try{_0x1f6f2e['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0xbe02d=document['domain'];_0x1f6f2e['src']='javascript:void((function(){document.open();document.domain=\x27'+_0xbe02d+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1f6f2e['contentDocument']?_0x1f6f2e['doc']=_0x1f6f2e['contentDocument']:_0x1f6f2e['contentWindow']?_0x1f6f2e['doc']=_0x1f6f2e['contentWindow']['document']:_0x1f6f2e['document']&&(_0x1f6f2e['doc']=_0x1f6f2e['document']),_0x1f6f2e;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x1d8ce1=this['onDisconnect'];_0x1d8ce1&&(this['onDisconnect']=null,_0x1d8ce1());}['startLongPoll'](_0x5a83dc,_0x38db3f){for(this['myID']=_0x5a83dc,this['myPW']=_0x38db3f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x514993={};_0x514993[Eo]=this['myID'],_0x514993[Io]=this['myPW'],_0x514993[wo]=this['currentSerial'];let _0x331962=this['urlFn'](_0x514993),_0x380e76='',_0x4d5280=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x380e76['length']<=Co;){const _0x1d93c0=this['pendingSegs']['shift']();_0x380e76=_0x380e76+'&'+lh+_0x4d5280+'='+_0x1d93c0['seg']+'&'+hh+_0x4d5280+'='+_0x1d93c0['ts']+'&'+uh+_0x4d5280+'='+_0x1d93c0['d'],_0x4d5280++;}return _0x331962=_0x331962+_0x380e76,this['addLongPollTag_'](_0x331962,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3e5339,_0x3409d3,_0x473717){this['pendingSegs']['push']({'seg':_0x3e5339,'ts':_0x3409d3,'d':_0x473717}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1f7d77,_0x274c51){this['outstandingRequests']['add'](_0x274c51);const _0x115101=()=>{this['outstandingRequests']['delete'](_0x274c51),this['newRequest_']();},_0x37bc80=setTimeout(_0x115101,Math['floor'](ph)),_0x33f7fc=()=>{clearTimeout(_0x37bc80),_0x115101();};this['addTag'](_0x1f7d77,_0x33f7fc);}['addTag'](_0x2ebac9,_0xd05d2f){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x570fd4=this['myIFrame']['doc']['createElement']('script');_0x570fd4['type']='text/javascript',_0x570fd4['async']=!0x0,_0x570fd4['src']=_0x2ebac9,_0x570fd4['onload']=_0x570fd4['onreadystatechange']=function(){const _0x60bc97=_0x570fd4['readyState'];(!_0x60bc97||_0x60bc97==='loaded'||_0x60bc97==='complete')&&(_0x570fd4['onload']=_0x570fd4['onreadystatechange']=null,_0x570fd4['parentNode']&&_0x570fd4['parentNode']['removeChild'](_0x570fd4),_0xd05d2f());},_0x570fd4['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2ebac9),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x570fd4);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x4dd47a,_0x3f9234,_0xcd6656,_0x51055e,_0x7157b5,_0x3b3f02,_0x227178){this['connId']=_0x4dd47a,this['applicationId']=_0xcd6656,this['appCheckToken']=_0x51055e,this['authToken']=_0x7157b5,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x3f9234),this['connURL']=q['connectionURL_'](_0x3f9234,_0x3b3f02,_0x227178,_0x51055e,_0xcd6656),this['nodeAdmin']=_0x3f9234['nodeAdmin'];}static['connectionURL_'](_0x141238,_0x3a1297,_0x3426a7,_0x593a51,_0x327880){const _0x406650={};return _0x406650[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x406650[ho]=uo),_0x3a1297&&(_0x406650[lo]=_0x3a1297),_0x3426a7&&(_0x406650[po]=_0x3426a7),_0x593a51&&(_0x406650[wi]=_0x593a51),_0x327880&&(_0x406650[_o]=_0x327880),vo(_0x141238,go,_0x406650);}['open'](_0x54431c,_0x578b76){this['onDisconnect']=_0x578b76,this['onMessage']=_0x54431c,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x2a4367;_c(),this['mySock']=new gn(this['connURL'],[],_0x2a4367);}catch(_0xb856ea){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x15770a=_0xb856ea['message']||_0xb856ea['data'];_0x15770a&&this['log_'](_0x15770a),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5a0a58=>{this['handleIncomingFrame'](_0x5a0a58);},this['mySock']['onerror']=_0x1b7c8b=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5de85b=_0x1b7c8b['message']||_0x1b7c8b['data'];_0x5de85b&&this['log_'](_0x5de85b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x258f7a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1c6bef=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x24fdd5=navigator['userAgent']['match'](_0x1c6bef);_0x24fdd5&&_0x24fdd5['length']>0x1&&parseFloat(_0x24fdd5[0x1])<4.4&&(_0x258f7a=!0x0);}return!_0x258f7a&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x13603e){if(this['frames']['push'](_0x13603e),this['frames']['length']===this['totalFrames']){const _0x4cbc6f=this['frames']['join']('');this['frames']=null;const _0x522160=Nt(_0x4cbc6f);this['onMessage'](_0x522160);}}['handleNewFrameCount_'](_0x1b6414){this['totalFrames']=_0x1b6414,this['frames']=[];}['extractFrameCount_'](_0x5f01d0){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5f01d0['length']<=0x6){const _0x914673=Number(_0x5f01d0);if(!isNaN(_0x914673))return this['handleNewFrameCount_'](_0x914673),null;}return this['handleNewFrameCount_'](0x1),_0x5f01d0;}['handleIncomingFrame'](_0x41db96){if(this['mySock']===null)return;const _0x39cb84=_0x41db96['data'];if(this['bytesReceived']+=_0x39cb84['length'],this['stats_']['incrementCounter']('bytes_received',_0x39cb84['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x39cb84);else{const _0xcc1aea=this['extractFrameCount_'](_0x39cb84);_0xcc1aea!==null&&this['appendFrame_'](_0xcc1aea);}}['send'](_0x53caa2){this['resetKeepAlive']();const _0x28dff0=O(_0x53caa2);this['bytesSent']+=_0x28dff0['length'],this['stats_']['incrementCounter']('bytes_sent',_0x28dff0['length']);const _0x1a64db=oo(_0x28dff0,gh);_0x1a64db['length']>0x1&&this['sendString_'](String(_0x1a64db['length']));for(let _0x4b1d13=0x0;_0x4b1d13<_0x1a64db['length'];_0x4b1d13++)this['sendString_'](_0x1a64db[_0x4b1d13]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x76660a){try{this['mySock']['send'](_0x76660a);}catch(_0x451a37){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x451a37['message']||_0x451a37['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x371e5){this['initTransports_'](_0x371e5);}['initTransports_'](_0x429b4d){const _0x3bc08d=q&&q['isAvailable']();let _0x52ed7c=_0x3bc08d&&!q['previouslyFailed']();if(_0x429b4d['webSocketOnly']&&(_0x3bc08d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x52ed7c=!0x0),_0x52ed7c)this['transports_']=[q];else{const _0x5ef642=this['transports_']=[];for(const _0x5bdadc of Dt['ALL_TRANSPORTS'])_0x5bdadc&&_0x5bdadc['isAvailable']()&&_0x5ef642['push'](_0x5bdadc);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x162dd0,_0x1f529e,_0x4337dd,_0x34dda9,_0x37f114,_0x1a2189,_0x10d3b6,_0x283b9a,_0x24eb6a,_0x31429a){this['id']=_0x162dd0,this['repoInfo_']=_0x1f529e,this['applicationId_']=_0x4337dd,this['appCheckToken_']=_0x34dda9,this['authToken_']=_0x37f114,this['onMessage_']=_0x1a2189,this['onReady_']=_0x10d3b6,this['onDisconnect_']=_0x283b9a,this['onKill_']=_0x24eb6a,this['lastSessionId']=_0x31429a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x1f529e),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2a0f76=this['transportManager_']['initialTransport']();this['conn_']=new _0x2a0f76(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2a0f76['responsesRequiredToBeHealthy']||0x0;const _0x28244b=this['connReceiver_'](this['conn_']),_0x332439=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x28244b,_0x332439);},Math['floor'](0x0));const _0x1cca62=_0x2a0f76['healthyTimeout']||0x0;_0x1cca62>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1cca62)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x43378b){return _0x5f08b6=>{_0x43378b===this['conn_']?this['onConnectionLost_'](_0x5f08b6):_0x43378b===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x163f68){return _0x55aedb=>{this['state_']!==0x2&&(_0x163f68===this['rx_']?this['onPrimaryMessageReceived_'](_0x55aedb):_0x163f68===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x55aedb):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3a77f8){const _0x534d75={'t':'d','d':_0x3a77f8};this['sendData_'](_0x534d75);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x11cc27){if(ci in _0x11cc27){const _0x16d685=_0x11cc27[ci];_0x16d685===Ys?this['upgradeIfSecondaryHealthy_']():_0x16d685===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x16d685===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3d893d){const _0x28b105=vt('t',_0x3d893d),_0x3f824a=vt('d',_0x3d893d);if(_0x28b105==='c')this['onSecondaryControl_'](_0x3f824a);else{if(_0x28b105==='d')this['pendingDataMessages']['push'](_0x3f824a);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x28b105);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x228806){const _0x1341b3=vt('t',_0x228806),_0x941996=vt('d',_0x228806);_0x1341b3==='c'?this['onControl_'](_0x941996):_0x1341b3==='d'&&this['onDataMessage_'](_0x941996);}['onDataMessage_'](_0x5e5881){this['onPrimaryResponse_'](),this['onMessage_'](_0x5e5881);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x54856f){const _0x4cf0ff=vt(ci,_0x54856f);if(zs in _0x54856f){const _0x3508b3=_0x54856f[zs];if(_0x4cf0ff===Th){const _0x9633b3={..._0x3508b3};this['repoInfo_']['isUsingEmulator']&&(_0x9633b3['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x9633b3);}else{if(_0x4cf0ff===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4fac37=0x0;_0x4fac37<this['pendingDataMessages']['length'];++_0x4fac37)this['onDataMessage_'](this['pendingDataMessages'][_0x4fac37]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4cf0ff===wh?this['onConnectionShutdown_'](_0x3508b3):_0x4cf0ff===js?this['onReset_'](_0x3508b3):_0x4cf0ff===Ch?Ii('Server\x20Error:\x20'+_0x3508b3):_0x4cf0ff===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x4cf0ff);}}}['onHandshake_'](_0x5ec665){const _0x344ad4=_0x5ec665['ts'],_0x5e7539=_0x5ec665['v'],_0x3a22d5=_0x5ec665['h'];this['sessionId']=_0x5ec665['s'],this['repoInfo_']['host']=_0x3a22d5,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x344ad4),Gi!==_0x5e7539&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2fdcc9=this['transportManager_']['upgradeTransport']();_0x2fdcc9&&this['startUpgrade_'](_0x2fdcc9);}['startUpgrade_'](_0x140105){this['secondaryConn_']=new _0x140105(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x140105['responsesRequiredToBeHealthy']||0x0;const _0x13162c=this['connReceiver_'](this['secondaryConn_']),_0x5fad33=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x13162c,_0x5fad33),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x2ee734){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x2ee734),this['repoInfo_']['host']=_0x2ee734,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x363926,_0x1ef2b0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x363926,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1ef2b0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3a58fb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3a58fb||this['rx_']===_0x3a58fb)&&this['close']();}['onConnectionLost_'](_0x9e364e){this['conn_']=null,!_0x9e364e&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x7ae685){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x7ae685),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2b2ef9){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2b2ef9);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3bad17,_0x33c864,_0x44f52c,_0x2b8aad){}['merge'](_0x188836,_0x822307,_0x1f8718,_0x5e1009){}['refreshAuthToken'](_0x3dd6ac){}['refreshAppCheckToken'](_0x33442f){}['onDisconnectPut'](_0x4b02d9,_0x5f3861,_0x2e9be4){}['onDisconnectMerge'](_0x288d14,_0x26ae51,_0x38d27f){}['onDisconnectCancel'](_0xe8f022,_0x22558e){}['reportStats'](_0x25b432){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x317b69){this['allowedEvents_']=_0x317b69,this['listeners_']={},f(Array['isArray'](_0x317b69)&&_0x317b69['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xc83aec,..._0x128d4c){if(Array['isArray'](this['listeners_'][_0xc83aec])){const _0x4b3181=[...this['listeners_'][_0xc83aec]];for(let _0xb692a8=0x0;_0xb692a8<_0x4b3181['length'];_0xb692a8++)_0x4b3181[_0xb692a8]['callback']['apply'](_0x4b3181[_0xb692a8]['context'],_0x128d4c);}}['on'](_0x24951f,_0x2e86c2,_0x22826b){this['validateEventType_'](_0x24951f),this['listeners_'][_0x24951f]=this['listeners_'][_0x24951f]||[],this['listeners_'][_0x24951f]['push']({'callback':_0x2e86c2,'context':_0x22826b});const _0x3f2678=this['getInitialEvent'](_0x24951f);_0x3f2678&&_0x2e86c2['apply'](_0x22826b,_0x3f2678);}['off'](_0x500bcf,_0x380306,_0x2c2811){this['validateEventType_'](_0x500bcf);const _0x3d6541=this['listeners_'][_0x500bcf]||[];for(let _0x2ba1b3=0x0;_0x2ba1b3<_0x3d6541['length'];_0x2ba1b3++)if(_0x3d6541[_0x2ba1b3]['callback']===_0x380306&&(!_0x2c2811||_0x2c2811===_0x3d6541[_0x2ba1b3]['context'])){_0x3d6541['splice'](_0x2ba1b3,0x1);return;}}['validateEventType_'](_0xe3b3a4){f(this['allowedEvents_']['find'](_0x2d4cb8=>_0x2d4cb8===_0xe3b3a4),'Unknown\x20event:\x20'+_0xe3b3a4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2ccdce){return f(_0x2ccdce==='online','Unknown\x20event\x20type:\x20'+_0x2ccdce),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x201a5,_0x2be5e9){if(_0x2be5e9===void 0x0){this['pieces_']=_0x201a5['split']('/');let _0x3e6368=0x0;for(let _0x5c1596=0x0;_0x5c1596<this['pieces_']['length'];_0x5c1596++)this['pieces_'][_0x5c1596]['length']>0x0&&(this['pieces_'][_0x3e6368]=this['pieces_'][_0x5c1596],_0x3e6368++);this['pieces_']['length']=_0x3e6368,this['pieceNum_']=0x0;}else this['pieces_']=_0x201a5,this['pieceNum_']=_0x2be5e9;}['toString'](){let _0x4945f1='';for(let _0x1af1ff=this['pieceNum_'];_0x1af1ff<this['pieces_']['length'];_0x1af1ff++)this['pieces_'][_0x1af1ff]!==''&&(_0x4945f1+='/'+this['pieces_'][_0x1af1ff]);return _0x4945f1||'/';}}function w(){return new C('');}function y(_0x24826a){return _0x24826a['pieceNum_']>=_0x24826a['pieces_']['length']?null:_0x24826a['pieces_'][_0x24826a['pieceNum_']];}function Ce(_0x22f3ad){return _0x22f3ad['pieces_']['length']-_0x22f3ad['pieceNum_'];}function S(_0x25dcfc){let _0x45d175=_0x25dcfc['pieceNum_'];return _0x45d175<_0x25dcfc['pieces_']['length']&&_0x45d175++,new C(_0x25dcfc['pieces_'],_0x45d175);}function ji(_0x2377a1){return _0x2377a1['pieceNum_']<_0x2377a1['pieces_']['length']?_0x2377a1['pieces_'][_0x2377a1['pieces_']['length']-0x1]:null;}function bh(_0x59c576){let _0x423056='';for(let _0x1df125=_0x59c576['pieceNum_'];_0x1df125<_0x59c576['pieces_']['length'];_0x1df125++)_0x59c576['pieces_'][_0x1df125]!==''&&(_0x423056+='/'+encodeURIComponent(String(_0x59c576['pieces_'][_0x1df125])));return _0x423056||'/';}function Mt(_0x14949b,_0x5454d3=0x0){return _0x14949b['pieces_']['slice'](_0x14949b['pieceNum_']+_0x5454d3);}function Ro(_0x2e7e5c){if(_0x2e7e5c['pieceNum_']>=_0x2e7e5c['pieces_']['length'])return null;const _0x159ffe=[];for(let _0x589ace=_0x2e7e5c['pieceNum_'];_0x589ace<_0x2e7e5c['pieces_']['length']-0x1;_0x589ace++)_0x159ffe['push'](_0x2e7e5c['pieces_'][_0x589ace]);return new C(_0x159ffe,0x0);}function k(_0x5b7d73,_0x497fa1){const _0xca5a12=[];for(let _0x209e84=_0x5b7d73['pieceNum_'];_0x209e84<_0x5b7d73['pieces_']['length'];_0x209e84++)_0xca5a12['push'](_0x5b7d73['pieces_'][_0x209e84]);if(_0x497fa1 instanceof C){for(let _0x1d2125=_0x497fa1['pieceNum_'];_0x1d2125<_0x497fa1['pieces_']['length'];_0x1d2125++)_0xca5a12['push'](_0x497fa1['pieces_'][_0x1d2125]);}else{const _0x4322f8=_0x497fa1['split']('/');for(let _0xcc6dac=0x0;_0xcc6dac<_0x4322f8['length'];_0xcc6dac++)_0x4322f8[_0xcc6dac]['length']>0x0&&_0xca5a12['push'](_0x4322f8[_0xcc6dac]);}return new C(_0xca5a12,0x0);}function v(_0x27c93d){return _0x27c93d['pieceNum_']>=_0x27c93d['pieces_']['length'];}function F(_0x2ae26e,_0x2b0a2d){const _0x2624c6=y(_0x2ae26e),_0x15b390=y(_0x2b0a2d);if(_0x2624c6===null)return _0x2b0a2d;if(_0x2624c6===_0x15b390)return F(S(_0x2ae26e),S(_0x2b0a2d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2b0a2d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2ae26e+')');}function Rh(_0x33f222,_0x2b3a06){const _0x336e20=Mt(_0x33f222,0x0),_0x51be69=Mt(_0x2b3a06,0x0);for(let _0x20dd05=0x0;_0x20dd05<_0x336e20['length']&&_0x20dd05<_0x51be69['length'];_0x20dd05++){const _0x2a2c28=qe(_0x336e20[_0x20dd05],_0x51be69[_0x20dd05]);if(_0x2a2c28!==0x0)return _0x2a2c28;}return _0x336e20['length']===_0x51be69['length']?0x0:_0x336e20['length']<_0x51be69['length']?-0x1:0x1;}function Ki(_0x475975,_0x181875){if(Ce(_0x475975)!==Ce(_0x181875))return!0x1;for(let _0x23c7a5=_0x475975['pieceNum_'],_0x3d26b6=_0x181875['pieceNum_'];_0x23c7a5<=_0x475975['pieces_']['length'];_0x23c7a5++,_0x3d26b6++)if(_0x475975['pieces_'][_0x23c7a5]!==_0x181875['pieces_'][_0x3d26b6])return!0x1;return!0x0;}function G(_0x330020,_0x5c4642){let _0x96475f=_0x330020['pieceNum_'],_0x2fb574=_0x5c4642['pieceNum_'];if(Ce(_0x330020)>Ce(_0x5c4642))return!0x1;for(;_0x96475f<_0x330020['pieces_']['length'];){if(_0x330020['pieces_'][_0x96475f]!==_0x5c4642['pieces_'][_0x2fb574])return!0x1;++_0x96475f,++_0x2fb574;}return!0x0;}class Ah{constructor(_0x56f3f8,_0x37605f){this['errorPrefix_']=_0x37605f,this['parts_']=Mt(_0x56f3f8,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4da1fe=0x0;_0x4da1fe<this['parts_']['length'];_0x4da1fe++)this['byteLength_']+=Ln(this['parts_'][_0x4da1fe]);Ao(this);}}function kh(_0x4d42f6,_0x5e7f5d){_0x4d42f6['parts_']['length']>0x0&&(_0x4d42f6['byteLength_']+=0x1),_0x4d42f6['parts_']['push'](_0x5e7f5d),_0x4d42f6['byteLength_']+=Ln(_0x5e7f5d),Ao(_0x4d42f6);}function Ph(_0x49954f){const _0x390aee=_0x49954f['parts_']['pop']();_0x49954f['byteLength_']-=Ln(_0x390aee),_0x49954f['parts_']['length']>0x0&&(_0x49954f['byteLength_']-=0x1);}function Ao(_0x14f359){if(_0x14f359['byteLength_']>Zs)throw new Error(_0x14f359['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x14f359['byteLength_']+').');if(_0x14f359['parts_']['length']>Xs)throw new Error(_0x14f359['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x14f359));}function Oe(_0x4b372d){return _0x4b372d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4b372d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x17bbd8,_0x58a7c7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x58a7c7='visibilitychange',_0x17bbd8='hidden'):typeof document['mozHidden']<'u'?(_0x58a7c7='mozvisibilitychange',_0x17bbd8='mozHidden'):typeof document['msHidden']<'u'?(_0x58a7c7='msvisibilitychange',_0x17bbd8='msHidden'):typeof document['webkitHidden']<'u'&&(_0x58a7c7='webkitvisibilitychange',_0x17bbd8='webkitHidden')),this['visible_']=!0x0,_0x58a7c7&&document['addEventListener'](_0x58a7c7,()=>{const _0x43f065=!document[_0x17bbd8];_0x43f065!==this['visible_']&&(this['visible_']=_0x43f065,this['trigger']('visible',_0x43f065));},!0x1);}['getInitialEvent'](_0x4fc86a){return f(_0x4fc86a==='visible','Unknown\x20event\x20type:\x20'+_0x4fc86a),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x1d5401,_0x336bb4,_0x7dda49,_0x59bb2a,_0x34b1db,_0xe960bf,_0x322a3f,_0x53e625){if(super(),this['repoInfo_']=_0x1d5401,this['applicationId_']=_0x336bb4,this['onDataUpdate_']=_0x7dda49,this['onConnectStatus_']=_0x59bb2a,this['onServerInfoUpdate_']=_0x34b1db,this['authTokenProvider_']=_0xe960bf,this['appCheckTokenProvider_']=_0x322a3f,this['authOverride_']=_0x53e625,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x53e625)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1d5401['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x561cfe,_0x55fe03,_0x2d01ea){const _0x62bd1d=++this['requestNumber_'],_0x453008={'r':_0x62bd1d,'a':_0x561cfe,'b':_0x55fe03};this['log_'](O(_0x453008)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x453008),_0x2d01ea&&(this['requestCBHash_'][_0x62bd1d]=_0x2d01ea);}['get'](_0x49ea35){this['initConnection_']();const _0x52e6c1=new H(),_0x39fc06={'action':'g','request':{'p':_0x49ea35['_path']['toString'](),'q':_0x49ea35['_queryObject']},'onComplete':_0x3246b1=>{const _0xd14719=_0x3246b1['d'];_0x3246b1['s']==='ok'?_0x52e6c1['resolve'](_0xd14719):_0x52e6c1['reject'](_0xd14719);}};this['outstandingGets_']['push'](_0x39fc06),this['outstandingGetCount_']++;const _0x37fd9e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x37fd9e),_0x52e6c1['promise'];}['listen'](_0x5d6338,_0xb1d4fe,_0x523576,_0x3ae37d){this['initConnection_']();const _0x43da7=_0x5d6338['_queryIdentifier'],_0x5ab51c=_0x5d6338['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5ab51c+'\x20'+_0x43da7),this['listens']['has'](_0x5ab51c)||this['listens']['set'](_0x5ab51c,new Map()),f(_0x5d6338['_queryParams']['isDefault']()||!_0x5d6338['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5ab51c)['has'](_0x43da7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5d3e74={'onComplete':_0x3ae37d,'hashFn':_0xb1d4fe,'query':_0x5d6338,'tag':_0x523576};this['listens']['get'](_0x5ab51c)['set'](_0x43da7,_0x5d3e74),this['connected_']&&this['sendListen_'](_0x5d3e74);}['sendGet_'](_0x59cf00){const _0x5f3b64=this['outstandingGets_'][_0x59cf00];this['sendRequest']('g',_0x5f3b64['request'],_0x42edf5=>{delete this['outstandingGets_'][_0x59cf00],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5f3b64['onComplete']&&_0x5f3b64['onComplete'](_0x42edf5);});}['sendListen_'](_0x461cbf){const _0xc15dfb=_0x461cbf['query'],_0x30be9d=_0xc15dfb['_path']['toString'](),_0x51f325=_0xc15dfb['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x30be9d+'\x20for\x20'+_0x51f325);const _0x45bff6={'p':_0x30be9d},_0x32a6d4='q';_0x461cbf['tag']&&(_0x45bff6['q']=_0xc15dfb['_queryObject'],_0x45bff6['t']=_0x461cbf['tag']),_0x45bff6['h']=_0x461cbf['hashFn'](),this['sendRequest'](_0x32a6d4,_0x45bff6,_0x388754=>{const _0x3ed7a6=_0x388754['d'],_0x367290=_0x388754['s'];se['warnOnListenWarnings_'](_0x3ed7a6,_0xc15dfb),(this['listens']['get'](_0x30be9d)&&this['listens']['get'](_0x30be9d)['get'](_0x51f325))===_0x461cbf&&(this['log_']('listen\x20response',_0x388754),_0x367290!=='ok'&&this['removeListen_'](_0x30be9d,_0x51f325),_0x461cbf['onComplete']&&_0x461cbf['onComplete'](_0x367290,_0x3ed7a6));});}static['warnOnListenWarnings_'](_0x4a0ad7,_0x3e6fa4){if(_0x4a0ad7&&typeof _0x4a0ad7=='object'&&Q(_0x4a0ad7,'w')){const _0x30e43b=Le(_0x4a0ad7,'w');if(Array['isArray'](_0x30e43b)&&~_0x30e43b['indexOf']('no_index')){const _0x2c374a='\x22.indexOn\x22:\x20\x22'+_0x3e6fa4['_queryParams']['getIndex']()['toString']()+'\x22',_0x12b765=_0x3e6fa4['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2c374a+'\x20at\x20'+_0x12b765+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x57f773){this['authToken_']=_0x57f773,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x57f773);}['reduceReconnectDelayIfAdminCredential_'](_0x21cfa9){(_0x21cfa9&&_0x21cfa9['length']===0x28||wc(_0x21cfa9))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3e9ddf){this['appCheckToken_']=_0x3e9ddf,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x428ea2=this['authToken_'],_0x18e289=Ic(_0x428ea2)?'auth':'gauth',_0x413778={'cred':_0x428ea2};this['authOverride_']===null?_0x413778['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x413778['authvar']=this['authOverride_']),this['sendRequest'](_0x18e289,_0x413778,_0x3970d5=>{const _0x243dfb=_0x3970d5['s'],_0x5d3274=_0x3970d5['d']||'error';this['authToken_']===_0x428ea2&&(_0x243dfb==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x243dfb,_0x5d3274));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x3b73ea=>{const _0x16cf89=_0x3b73ea['s'],_0x20d03c=_0x3b73ea['d']||'error';_0x16cf89==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x16cf89,_0x20d03c);});}['unlisten'](_0x120a21,_0x3bd2bf){const _0x294cc2=_0x120a21['_path']['toString'](),_0xf4fbea=_0x120a21['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x294cc2+'\x20'+_0xf4fbea),f(_0x120a21['_queryParams']['isDefault']()||!_0x120a21['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x294cc2,_0xf4fbea)&&this['connected_']&&this['sendUnlisten_'](_0x294cc2,_0xf4fbea,_0x120a21['_queryObject'],_0x3bd2bf);}['sendUnlisten_'](_0x181836,_0x144722,_0x5ee06a,_0x5122bd){this['log_']('Unlisten\x20on\x20'+_0x181836+'\x20for\x20'+_0x144722);const _0x550fb4={'p':_0x181836},_0x79dd3='n';_0x5122bd&&(_0x550fb4['q']=_0x5ee06a,_0x550fb4['t']=_0x5122bd),this['sendRequest'](_0x79dd3,_0x550fb4);}['onDisconnectPut'](_0x3dbe56,_0x83c752,_0x300189){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3dbe56,_0x83c752,_0x300189):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3dbe56,'action':'o','data':_0x83c752,'onComplete':_0x300189});}['onDisconnectMerge'](_0xe65f2e,_0x553bc5,_0x56fe50){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xe65f2e,_0x553bc5,_0x56fe50):this['onDisconnectRequestQueue_']['push']({'pathString':_0xe65f2e,'action':'om','data':_0x553bc5,'onComplete':_0x56fe50});}['onDisconnectCancel'](_0x4edd26,_0x1d8c2d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4edd26,null,_0x1d8c2d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4edd26,'action':'oc','data':null,'onComplete':_0x1d8c2d});}['sendOnDisconnect_'](_0x4d1b98,_0x46d976,_0x54009e,_0x9ad524){const _0x59b806={'p':_0x46d976,'d':_0x54009e};this['log_']('onDisconnect\x20'+_0x4d1b98,_0x59b806),this['sendRequest'](_0x4d1b98,_0x59b806,_0x5710c2=>{_0x9ad524&&setTimeout(()=>{_0x9ad524(_0x5710c2['s'],_0x5710c2['d']);},Math['floor'](0x0));});}['put'](_0x2fcb64,_0x158ddc,_0x520f07,_0x869059){this['putInternal']('p',_0x2fcb64,_0x158ddc,_0x520f07,_0x869059);}['merge'](_0x208583,_0x335c22,_0x35f3b2,_0x8cf25f){this['putInternal']('m',_0x208583,_0x335c22,_0x35f3b2,_0x8cf25f);}['putInternal'](_0x29125a,_0x5303fa,_0x58cb89,_0x481bbb,_0xf9d22a){this['initConnection_']();const _0x1769ed={'p':_0x5303fa,'d':_0x58cb89};_0xf9d22a!==void 0x0&&(_0x1769ed['h']=_0xf9d22a),this['outstandingPuts_']['push']({'action':_0x29125a,'request':_0x1769ed,'onComplete':_0x481bbb}),this['outstandingPutCount_']++;const _0x5f53c4=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5f53c4):this['log_']('Buffering\x20put:\x20'+_0x5303fa);}['sendPut_'](_0x50384d){const _0x5920be=this['outstandingPuts_'][_0x50384d]['action'],_0x2f25f2=this['outstandingPuts_'][_0x50384d]['request'],_0x2234a7=this['outstandingPuts_'][_0x50384d]['onComplete'];this['outstandingPuts_'][_0x50384d]['queued']=this['connected_'],this['sendRequest'](_0x5920be,_0x2f25f2,_0x4e4e2f=>{this['log_'](_0x5920be+'\x20response',_0x4e4e2f),delete this['outstandingPuts_'][_0x50384d],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2234a7&&_0x2234a7(_0x4e4e2f['s'],_0x4e4e2f['d']);});}['reportStats'](_0x28204a){if(this['connected_']){const _0x51f2d9={'c':_0x28204a};this['log_']('reportStats',_0x51f2d9),this['sendRequest']('s',_0x51f2d9,_0x174e1a=>{if(_0x174e1a['s']!=='ok'){const _0x4cdd98=_0x174e1a['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x4cdd98);}});}}['onDataMessage_'](_0x4e33bf){if('r'in _0x4e33bf){this['log_']('from\x20server:\x20'+O(_0x4e33bf));const _0x6dc44e=_0x4e33bf['r'],_0x15a5e2=this['requestCBHash_'][_0x6dc44e];_0x15a5e2&&(delete this['requestCBHash_'][_0x6dc44e],_0x15a5e2(_0x4e33bf['b']));}else{if('error'in _0x4e33bf)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4e33bf['error'];'a'in _0x4e33bf&&this['onDataPush_'](_0x4e33bf['a'],_0x4e33bf['b']);}}['onDataPush_'](_0x3904a8,_0x11c8df){this['log_']('handleServerMessage',_0x3904a8,_0x11c8df),_0x3904a8==='d'?this['onDataUpdate_'](_0x11c8df['p'],_0x11c8df['d'],!0x1,_0x11c8df['t']):_0x3904a8==='m'?this['onDataUpdate_'](_0x11c8df['p'],_0x11c8df['d'],!0x0,_0x11c8df['t']):_0x3904a8==='c'?this['onListenRevoked_'](_0x11c8df['p'],_0x11c8df['q']):_0x3904a8==='ac'?this['onAuthRevoked_'](_0x11c8df['s'],_0x11c8df['d']):_0x3904a8==='apc'?this['onAppCheckRevoked_'](_0x11c8df['s'],_0x11c8df['d']):_0x3904a8==='sd'?this['onSecurityDebugPacket_'](_0x11c8df):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3904a8)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5562c7,_0x4d8444){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5562c7),this['lastSessionId']=_0x4d8444,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4017f5){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4017f5));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4ec9b1){_0x4ec9b1&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4ec9b1;}['onOnline_'](_0x18ccde){_0x18ccde?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x33f608=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x50b4c6=Math['max'](0x0,this['reconnectDelay_']-_0x33f608);_0x50b4c6=Math['random']()*_0x50b4c6,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x50b4c6+'ms'),this['scheduleConnect_'](_0x50b4c6),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1842f4=this['onDataMessage_']['bind'](this),_0x285e8e=this['onReady_']['bind'](this),_0x396b46=this['onRealtimeDisconnect_']['bind'](this),_0x2e4af8=this['id']+':'+se['nextConnectionId_']++,_0x1f8698=this['lastSessionId'];let _0x5d61c9=!0x1,_0x18d3fa=null;const _0x3efbc9=function(){_0x18d3fa?_0x18d3fa['close']():(_0x5d61c9=!0x0,_0x396b46());},_0x47b623=function(_0x3a7571){f(_0x18d3fa,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x18d3fa['sendRequest'](_0x3a7571);};this['realtime_']={'close':_0x3efbc9,'sendRequest':_0x47b623};const _0xd97b81=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x59a4e7,_0x1382af]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xd97b81),this['appCheckTokenProvider_']['getToken'](_0xd97b81)]);_0x5d61c9?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x59a4e7&&_0x59a4e7['accessToken'],this['appCheckToken_']=_0x1382af&&_0x1382af['token'],_0x18d3fa=new Sh(_0x2e4af8,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1842f4,_0x285e8e,_0x396b46,_0x172208=>{U(_0x172208+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1f8698));}catch(_0xe8c49f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0xe8c49f),_0x5d61c9||(this['repoInfo_']['nodeAdmin']&&U(_0xe8c49f),_0x3efbc9());}}}['interrupt'](_0x567020){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x567020),this['interruptReasons_'][_0x567020]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x179481){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x179481),delete this['interruptReasons_'][_0x179481],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2c092f){const _0x4b504f=_0x2c092f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4b504f});}['cancelSentTransactions_'](){for(let _0x10afd1=0x0;_0x10afd1<this['outstandingPuts_']['length'];_0x10afd1++){const _0x4b0b23=this['outstandingPuts_'][_0x10afd1];_0x4b0b23&&'h'in _0x4b0b23['request']&&_0x4b0b23['queued']&&(_0x4b0b23['onComplete']&&_0x4b0b23['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x10afd1],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2523c2,_0x460e0f){let _0x23150c;_0x460e0f?_0x23150c=_0x460e0f['map'](_0x57b676=>$i(_0x57b676))['join']('$'):_0x23150c='default';const _0x20c342=this['removeListen_'](_0x2523c2,_0x23150c);_0x20c342&&_0x20c342['onComplete']&&_0x20c342['onComplete']('permission_denied');}['removeListen_'](_0x3e6a2e,_0x42b7c0){const _0x1b1378=new C(_0x3e6a2e)['toString']();let _0x386a1d;if(this['listens']['has'](_0x1b1378)){const _0x2c821b=this['listens']['get'](_0x1b1378);_0x386a1d=_0x2c821b['get'](_0x42b7c0),_0x2c821b['delete'](_0x42b7c0),_0x2c821b['size']===0x0&&this['listens']['delete'](_0x1b1378);}else _0x386a1d=void 0x0;return _0x386a1d;}['onAuthRevoked_'](_0x8ae68f,_0x3fe84f){L('Auth\x20token\x20revoked:\x20'+_0x8ae68f+'/'+_0x3fe84f),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x8ae68f==='invalid_token'||_0x8ae68f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x53b156,_0x57b95f){L('App\x20check\x20token\x20revoked:\x20'+_0x53b156+'/'+_0x57b95f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x53b156==='invalid_token'||_0x53b156==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x8e86df){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x8e86df):'msg'in _0x8e86df&&console['log']('FIREBASE:\x20'+_0x8e86df['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x5edb28 of this['listens']['values']())for(const _0x5ab455 of _0x5edb28['values']())this['sendListen_'](_0x5ab455);for(let _0x1d7801=0x0;_0x1d7801<this['outstandingPuts_']['length'];_0x1d7801++)this['outstandingPuts_'][_0x1d7801]&&this['sendPut_'](_0x1d7801);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1b79fa=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1b79fa['action'],_0x1b79fa['pathString'],_0x1b79fa['data'],_0x1b79fa['onComplete']);}for(let _0x1e8f0f=0x0;_0x1e8f0f<this['outstandingGets_']['length'];_0x1e8f0f++)this['outstandingGets_'][_0x1e8f0f]&&this['sendGet_'](_0x1e8f0f);}['sendConnectStats_'](){const _0x2edcd4={};let _0x30ebe9='js';_0x2edcd4['sdk.'+_0x30ebe9+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x2edcd4['framework.cordova']=0x1:Kr()&&(_0x2edcd4['framework.reactnative']=0x1),this['reportStats'](_0x2edcd4);}['shouldReconnect_'](){const _0x389178=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x389178;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x32d419,_0x4c5240){this['name']=_0x32d419,this['node']=_0x4c5240;}static['Wrap'](_0x27c1f9,_0x57d3b0){return new E(_0x27c1f9,_0x57d3b0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x9e5ca6,_0x31bd06){const _0x4e2f83=new E(We,_0x9e5ca6),_0x45b2b9=new E(We,_0x31bd06);return this['compare'](_0x4e2f83,_0x45b2b9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x54430d){sn=_0x54430d;}['compare'](_0x32ab5d,_0x143ea5){return qe(_0x32ab5d['name'],_0x143ea5['name']);}['isDefinedOn'](_0x3aafac){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x12ccfb,_0x173024){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x81dcae,_0x2c82b1){return f(typeof _0x81dcae=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x81dcae,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x2cace8,_0xfe247f,_0x26e92c,_0x32342b,_0x336676=null){this['isReverse_']=_0x32342b,this['resultGenerator_']=_0x336676,this['nodeStack_']=[];let _0x1f4b9e=0x1;for(;!_0x2cace8['isEmpty']();)if(_0x2cace8=_0x2cace8,_0x1f4b9e=_0xfe247f?_0x26e92c(_0x2cace8['key'],_0xfe247f):0x1,_0x32342b&&(_0x1f4b9e*=-0x1),_0x1f4b9e<0x0)this['isReverse_']?_0x2cace8=_0x2cace8['left']:_0x2cace8=_0x2cace8['right'];else{if(_0x1f4b9e===0x0){this['nodeStack_']['push'](_0x2cace8);break;}else this['nodeStack_']['push'](_0x2cace8),this['isReverse_']?_0x2cace8=_0x2cace8['right']:_0x2cace8=_0x2cace8['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3053e6=this['nodeStack_']['pop'](),_0x141ecf;if(this['resultGenerator_']?_0x141ecf=this['resultGenerator_'](_0x3053e6['key'],_0x3053e6['value']):_0x141ecf={'key':_0x3053e6['key'],'value':_0x3053e6['value']},this['isReverse_']){for(_0x3053e6=_0x3053e6['left'];!_0x3053e6['isEmpty']();)this['nodeStack_']['push'](_0x3053e6),_0x3053e6=_0x3053e6['right'];}else{for(_0x3053e6=_0x3053e6['right'];!_0x3053e6['isEmpty']();)this['nodeStack_']['push'](_0x3053e6),_0x3053e6=_0x3053e6['left'];}return _0x141ecf;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5baf0c=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5baf0c['key'],_0x5baf0c['value']):{'key':_0x5baf0c['key'],'value':_0x5baf0c['value']};}}class M{constructor(_0x17cc38,_0x3fe743,_0x56a5a1,_0x318bdd,_0x75eb66){this['key']=_0x17cc38,this['value']=_0x3fe743,this['color']=_0x56a5a1??M['RED'],this['left']=_0x318bdd??B['EMPTY_NODE'],this['right']=_0x75eb66??B['EMPTY_NODE'];}['copy'](_0x1ec307,_0x30f59a,_0x4d2c07,_0x6d765a,_0x1cdd70){return new M(_0x1ec307??this['key'],_0x30f59a??this['value'],_0x4d2c07??this['color'],_0x6d765a??this['left'],_0x1cdd70??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x251d66){return this['left']['inorderTraversal'](_0x251d66)||!!_0x251d66(this['key'],this['value'])||this['right']['inorderTraversal'](_0x251d66);}['reverseTraversal'](_0x5916ad){return this['right']['reverseTraversal'](_0x5916ad)||_0x5916ad(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5916ad);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x12b333,_0x5aeec6,_0x27cfb7){let _0x58dc4e=this;const _0x22a268=_0x27cfb7(_0x12b333,_0x58dc4e['key']);return _0x22a268<0x0?_0x58dc4e=_0x58dc4e['copy'](null,null,null,_0x58dc4e['left']['insert'](_0x12b333,_0x5aeec6,_0x27cfb7),null):_0x22a268===0x0?_0x58dc4e=_0x58dc4e['copy'](null,_0x5aeec6,null,null,null):_0x58dc4e=_0x58dc4e['copy'](null,null,null,null,_0x58dc4e['right']['insert'](_0x12b333,_0x5aeec6,_0x27cfb7)),_0x58dc4e['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1c02a0=this;return!_0x1c02a0['left']['isRed_']()&&!_0x1c02a0['left']['left']['isRed_']()&&(_0x1c02a0=_0x1c02a0['moveRedLeft_']()),_0x1c02a0=_0x1c02a0['copy'](null,null,null,_0x1c02a0['left']['removeMin_'](),null),_0x1c02a0['fixUp_']();}['remove'](_0xcf5a25,_0x412120){let _0x169fd8,_0x6b61e;if(_0x169fd8=this,_0x412120(_0xcf5a25,_0x169fd8['key'])<0x0)!_0x169fd8['left']['isEmpty']()&&!_0x169fd8['left']['isRed_']()&&!_0x169fd8['left']['left']['isRed_']()&&(_0x169fd8=_0x169fd8['moveRedLeft_']()),_0x169fd8=_0x169fd8['copy'](null,null,null,_0x169fd8['left']['remove'](_0xcf5a25,_0x412120),null);else{if(_0x169fd8['left']['isRed_']()&&(_0x169fd8=_0x169fd8['rotateRight_']()),!_0x169fd8['right']['isEmpty']()&&!_0x169fd8['right']['isRed_']()&&!_0x169fd8['right']['left']['isRed_']()&&(_0x169fd8=_0x169fd8['moveRedRight_']()),_0x412120(_0xcf5a25,_0x169fd8['key'])===0x0){if(_0x169fd8['right']['isEmpty']())return B['EMPTY_NODE'];_0x6b61e=_0x169fd8['right']['min_'](),_0x169fd8=_0x169fd8['copy'](_0x6b61e['key'],_0x6b61e['value'],null,null,_0x169fd8['right']['removeMin_']());}_0x169fd8=_0x169fd8['copy'](null,null,null,null,_0x169fd8['right']['remove'](_0xcf5a25,_0x412120));}return _0x169fd8['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x20af61=this;return _0x20af61['right']['isRed_']()&&!_0x20af61['left']['isRed_']()&&(_0x20af61=_0x20af61['rotateLeft_']()),_0x20af61['left']['isRed_']()&&_0x20af61['left']['left']['isRed_']()&&(_0x20af61=_0x20af61['rotateRight_']()),_0x20af61['left']['isRed_']()&&_0x20af61['right']['isRed_']()&&(_0x20af61=_0x20af61['colorFlip_']()),_0x20af61;}['moveRedLeft_'](){let _0x30690c=this['colorFlip_']();return _0x30690c['right']['left']['isRed_']()&&(_0x30690c=_0x30690c['copy'](null,null,null,null,_0x30690c['right']['rotateRight_']()),_0x30690c=_0x30690c['rotateLeft_'](),_0x30690c=_0x30690c['colorFlip_']()),_0x30690c;}['moveRedRight_'](){let _0xb54ac4=this['colorFlip_']();return _0xb54ac4['left']['left']['isRed_']()&&(_0xb54ac4=_0xb54ac4['rotateRight_'](),_0xb54ac4=_0xb54ac4['colorFlip_']()),_0xb54ac4;}['rotateLeft_'](){const _0x4c70d5=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4c70d5,null);}['rotateRight_'](){const _0x30373a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x30373a);}['colorFlip_'](){const _0x38e768=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x500c37=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x38e768,_0x500c37);}['checkMaxDepth_'](){const _0x538bea=this['check_']();return Math['pow'](0x2,_0x538bea)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1e4daf=this['left']['check_']();if(_0x1e4daf!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1e4daf+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x32cf50,_0x3301da,_0x1e4157,_0x187ea9,_0x587083){return this;}['insert'](_0x35badc,_0x32130e,_0x558c5f){return new M(_0x35badc,_0x32130e,null);}['remove'](_0x3aac4f,_0x4ecba3){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x377ded){return!0x1;}['reverseTraversal'](_0x583bc5){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x178c8f,_0x5a979f=B['EMPTY_NODE']){this['comparator_']=_0x178c8f,this['root_']=_0x5a979f;}['insert'](_0x212049,_0x198fbb){return new B(this['comparator_'],this['root_']['insert'](_0x212049,_0x198fbb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x58d18a){return new B(this['comparator_'],this['root_']['remove'](_0x58d18a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x33e4e9){let _0x596dbd,_0x16e39c=this['root_'];for(;!_0x16e39c['isEmpty']();){if(_0x596dbd=this['comparator_'](_0x33e4e9,_0x16e39c['key']),_0x596dbd===0x0)return _0x16e39c['value'];_0x596dbd<0x0?_0x16e39c=_0x16e39c['left']:_0x596dbd>0x0&&(_0x16e39c=_0x16e39c['right']);}return null;}['getPredecessorKey'](_0x553826){let _0xd4b9ba,_0x4ac16d=this['root_'],_0x427848=null;for(;!_0x4ac16d['isEmpty']();)if(_0xd4b9ba=this['comparator_'](_0x553826,_0x4ac16d['key']),_0xd4b9ba===0x0){if(_0x4ac16d['left']['isEmpty']())return _0x427848?_0x427848['key']:null;for(_0x4ac16d=_0x4ac16d['left'];!_0x4ac16d['right']['isEmpty']();)_0x4ac16d=_0x4ac16d['right'];return _0x4ac16d['key'];}else _0xd4b9ba<0x0?_0x4ac16d=_0x4ac16d['left']:_0xd4b9ba>0x0&&(_0x427848=_0x4ac16d,_0x4ac16d=_0x4ac16d['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x104611){return this['root_']['inorderTraversal'](_0x104611);}['reverseTraversal'](_0x45975c){return this['root_']['reverseTraversal'](_0x45975c);}['getIterator'](_0x26fa81){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x26fa81);}['getIteratorFrom'](_0x573ca5,_0x71950f){return new rn(this['root_'],_0x573ca5,this['comparator_'],!0x1,_0x71950f);}['getReverseIteratorFrom'](_0x441bb6,_0x53ca8a){return new rn(this['root_'],_0x441bb6,this['comparator_'],!0x0,_0x53ca8a);}['getReverseIterator'](_0x49d307){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x49d307);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0xeb3215,_0x310760){return qe(_0xeb3215['name'],_0x310760['name']);}function Qi(_0x3c71e1,_0x4989a8){return qe(_0x3c71e1,_0x4989a8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0xd2aa1a){Ci=_0xd2aa1a;}const Po=function(_0x20e14d){return typeof _0x20e14d=='number'?'number:'+ao(_0x20e14d):'string:'+_0x20e14d;},No=function(_0x42cbab){if(_0x42cbab['isLeafNode']()){const _0x647e00=_0x42cbab['val']();f(typeof _0x647e00=='string'||typeof _0x647e00=='number'||typeof _0x647e00=='object'&&Q(_0x647e00,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x42cbab===Ci||_0x42cbab['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x42cbab===Ci||_0x42cbab['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x5b1454){nr=_0x5b1454;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x347f11,_0x15a77d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x347f11,this['priorityNode_']=_0x15a77d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5d44d3){return new D(this['value_'],_0x5d44d3);}['getImmediateChild'](_0x5edbdc){return _0x5edbdc==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x133e35){return v(_0x133e35)?this:y(_0x133e35)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0xac359,_0xd3fcd9){return null;}['updateImmediateChild'](_0x2a1cd3,_0x5431f5){return _0x2a1cd3==='.priority'?this['updatePriority'](_0x5431f5):_0x5431f5['isEmpty']()&&_0x2a1cd3!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2a1cd3,_0x5431f5)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x407e6b,_0x59332a){const _0x2c3a64=y(_0x407e6b);return _0x2c3a64===null?_0x59332a:_0x59332a['isEmpty']()&&_0x2c3a64!=='.priority'?this:(f(_0x2c3a64!=='.priority'||Ce(_0x407e6b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2c3a64,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x407e6b),_0x59332a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x12dc8c,_0x151446){return!0x1;}['val'](_0x177e80){return _0x177e80&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x565165='';this['priorityNode_']['isEmpty']()||(_0x565165+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3a69d0=typeof this['value_'];_0x565165+=_0x3a69d0+':',_0x3a69d0==='number'?_0x565165+=ao(this['value_']):_0x565165+=this['value_'],this['lazyHash_']=ro(_0x565165);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x35ce4f){return _0x35ce4f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x35ce4f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x35ce4f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x35ce4f));}['compareToLeafNode_'](_0x4423f0){const _0x398fbf=typeof _0x4423f0['value_'],_0x920da7=typeof this['value_'],_0x19363e=D['VALUE_TYPE_ORDER']['indexOf'](_0x398fbf),_0x2e67c6=D['VALUE_TYPE_ORDER']['indexOf'](_0x920da7);return f(_0x19363e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x398fbf),f(_0x2e67c6>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x920da7),_0x19363e===_0x2e67c6?_0x920da7==='object'?0x0:this['value_']<_0x4423f0['value_']?-0x1:this['value_']===_0x4423f0['value_']?0x0:0x1:_0x2e67c6-_0x19363e;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x14b681){if(_0x14b681===this)return!0x0;if(_0x14b681['isLeafNode']()){const _0x1c6948=_0x14b681;return this['value_']===_0x1c6948['value_']&&this['priorityNode_']['equals'](_0x1c6948['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5c0f6a){Oo=_0x5c0f6a;}function Wh(_0xbb87b1){Do=_0xbb87b1;}class Bh extends Fn{['compare'](_0x292667,_0x3e72ca){const _0x1eead5=_0x292667['node']['getPriority'](),_0x31e6c2=_0x3e72ca['node']['getPriority'](),_0x5552e4=_0x1eead5['compareTo'](_0x31e6c2);return _0x5552e4===0x0?qe(_0x292667['name'],_0x3e72ca['name']):_0x5552e4;}['isDefinedOn'](_0x4f40f0){return!_0x4f40f0['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x6d6a5c,_0x4d7fe5){return!_0x6d6a5c['getPriority']()['equals'](_0x4d7fe5['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x2a5b05,_0x42749){const _0x547698=Oo(_0x2a5b05);return new E(_0x42749,new D('[PRIORITY-POST]',_0x547698));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0xb1b8c6){const _0x3fbcc8=_0x48b93a=>parseInt(Math['log'](_0x48b93a)/Vh,0xa),_0xfd2a28=_0x129417=>parseInt(Array(_0x129417+0x1)['join']('1'),0x2);this['count']=_0x3fbcc8(_0xb1b8c6+0x1),this['current_']=this['count']-0x1;const _0x2c7198=_0xfd2a28(this['count']);this['bits_']=_0xb1b8c6+0x1&_0x2c7198;}['nextBitIsOne'](){const _0x3cfa6e=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3cfa6e;}}const yn=function(_0x4661ea,_0x334706,_0x52f9c7,_0x3b918c){_0x4661ea['sort'](_0x334706);const _0x5cd94f=function(_0x59dd6c,_0x2c9e20){const _0x28d247=_0x2c9e20-_0x59dd6c;let _0x3b271b,_0x396e02;if(_0x28d247===0x0)return null;if(_0x28d247===0x1)return _0x3b271b=_0x4661ea[_0x59dd6c],_0x396e02=_0x52f9c7?_0x52f9c7(_0x3b271b):_0x3b271b,new M(_0x396e02,_0x3b271b['node'],M['BLACK'],null,null);{const _0x28f0b6=parseInt(_0x28d247/0x2,0xa)+_0x59dd6c,_0x3dd39f=_0x5cd94f(_0x59dd6c,_0x28f0b6),_0x3f2775=_0x5cd94f(_0x28f0b6+0x1,_0x2c9e20);return _0x3b271b=_0x4661ea[_0x28f0b6],_0x396e02=_0x52f9c7?_0x52f9c7(_0x3b271b):_0x3b271b,new M(_0x396e02,_0x3b271b['node'],M['BLACK'],_0x3dd39f,_0x3f2775);}},_0x2ff177=function(_0x599ee6){let _0x576364=null,_0x51677b=null,_0x120351=_0x4661ea['length'];const _0x4b7063=function(_0x51e354,_0x2ad32a){const _0x10e9b2=_0x120351-_0x51e354,_0x5bb675=_0x120351;_0x120351-=_0x51e354;const _0xc05f52=_0x5cd94f(_0x10e9b2+0x1,_0x5bb675),_0x22b722=_0x4661ea[_0x10e9b2],_0x317ec0=_0x52f9c7?_0x52f9c7(_0x22b722):_0x22b722;_0x404134(new M(_0x317ec0,_0x22b722['node'],_0x2ad32a,null,_0xc05f52));},_0x404134=function(_0x1f0f97){_0x576364?(_0x576364['left']=_0x1f0f97,_0x576364=_0x1f0f97):(_0x51677b=_0x1f0f97,_0x576364=_0x1f0f97);};for(let _0x12fffc=0x0;_0x12fffc<_0x599ee6['count'];++_0x12fffc){const _0x7c4d76=_0x599ee6['nextBitIsOne'](),_0x194679=Math['pow'](0x2,_0x599ee6['count']-(_0x12fffc+0x1));_0x7c4d76?_0x4b7063(_0x194679,M['BLACK']):(_0x4b7063(_0x194679,M['BLACK']),_0x4b7063(_0x194679,M['RED']));}return _0x51677b;},_0x5bfe69=new Hh(_0x4661ea['length']),_0x5e3240=_0x2ff177(_0x5bfe69);return new B(_0x3b918c||_0x334706,_0x5e3240);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x150177,_0x31db07){this['indexes_']=_0x150177,this['indexSet_']=_0x31db07;}['get'](_0x4d1d37){const _0x16892c=Le(this['indexes_'],_0x4d1d37);if(!_0x16892c)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4d1d37);return _0x16892c instanceof B?_0x16892c:null;}['hasIndex'](_0x426f21){return Q(this['indexSet_'],_0x426f21['toString']());}['addIndex'](_0x4640ba,_0x1dc09f){f(_0x4640ba!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x23a879=[];let _0x5d497d=!0x1;const _0x1a4695=_0x1dc09f['getIterator'](E['Wrap']);let _0x33cdaa=_0x1a4695['getNext']();for(;_0x33cdaa;)_0x5d497d=_0x5d497d||_0x4640ba['isDefinedOn'](_0x33cdaa['node']),_0x23a879['push'](_0x33cdaa),_0x33cdaa=_0x1a4695['getNext']();let _0x5d55a4;_0x5d497d?_0x5d55a4=yn(_0x23a879,_0x4640ba['getCompare']()):_0x5d55a4=Qe;const _0x472eac=_0x4640ba['toString'](),_0xac4750={...this['indexSet_']};_0xac4750[_0x472eac]=_0x4640ba;const _0x31dd20={...this['indexes_']};return _0x31dd20[_0x472eac]=_0x5d55a4,new te(_0x31dd20,_0xac4750);}['addToIndexes'](_0x14be67,_0x2263f6){const _0x56ba11=_n(this['indexes_'],(_0x1ecad4,_0x423fe0)=>{const _0x57dea9=Le(this['indexSet_'],_0x423fe0);if(f(_0x57dea9,'Missing\x20index\x20implementation\x20for\x20'+_0x423fe0),_0x1ecad4===Qe){if(_0x57dea9['isDefinedOn'](_0x14be67['node'])){const _0x4c1533=[],_0x212a85=_0x2263f6['getIterator'](E['Wrap']);let _0x2b72e3=_0x212a85['getNext']();for(;_0x2b72e3;)_0x2b72e3['name']!==_0x14be67['name']&&_0x4c1533['push'](_0x2b72e3),_0x2b72e3=_0x212a85['getNext']();return _0x4c1533['push'](_0x14be67),yn(_0x4c1533,_0x57dea9['getCompare']());}else return Qe;}else{const _0x14e1f7=_0x2263f6['get'](_0x14be67['name']);let _0x303355=_0x1ecad4;return _0x14e1f7&&(_0x303355=_0x303355['remove'](new E(_0x14be67['name'],_0x14e1f7))),_0x303355['insert'](_0x14be67,_0x14be67['node']);}});return new te(_0x56ba11,this['indexSet_']);}['removeFromIndexes'](_0x3567d6,_0x3a588e){const _0x269697=_n(this['indexes_'],_0x55ec8c=>{if(_0x55ec8c===Qe)return _0x55ec8c;{const _0x13f3a3=_0x3a588e['get'](_0x3567d6['name']);return _0x13f3a3?_0x55ec8c['remove'](new E(_0x3567d6['name'],_0x13f3a3)):_0x55ec8c;}});return new te(_0x269697,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x529e7c,_0x1a479f,_0x958f0b){this['children_']=_0x529e7c,this['priorityNode_']=_0x1a479f,this['indexMap_']=_0x958f0b,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1caa80){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1caa80,this['indexMap_']);}['getImmediateChild'](_0x5c2a55){if(_0x5c2a55==='.priority')return this['getPriority']();{const _0x55354d=this['children_']['get'](_0x5c2a55);return _0x55354d===null?It:_0x55354d;}}['getChild'](_0x20348d){const _0x5b87f9=y(_0x20348d);return _0x5b87f9===null?this:this['getImmediateChild'](_0x5b87f9)['getChild'](S(_0x20348d));}['hasChild'](_0x36d4f9){return this['children_']['get'](_0x36d4f9)!==null;}['updateImmediateChild'](_0x1422f1,_0x4a47d9){if(f(_0x4a47d9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1422f1==='.priority')return this['updatePriority'](_0x4a47d9);{const _0x1f3226=new E(_0x1422f1,_0x4a47d9);let _0x58e400,_0x35e36c;_0x4a47d9['isEmpty']()?(_0x58e400=this['children_']['remove'](_0x1422f1),_0x35e36c=this['indexMap_']['removeFromIndexes'](_0x1f3226,this['children_'])):(_0x58e400=this['children_']['insert'](_0x1422f1,_0x4a47d9),_0x35e36c=this['indexMap_']['addToIndexes'](_0x1f3226,this['children_']));const _0x48b0c0=_0x58e400['isEmpty']()?It:this['priorityNode_'];return new g(_0x58e400,_0x48b0c0,_0x35e36c);}}['updateChild'](_0x2680a1,_0x3d60cb){const _0x2d5c3a=y(_0x2680a1);if(_0x2d5c3a===null)return _0x3d60cb;{f(y(_0x2680a1)!=='.priority'||Ce(_0x2680a1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x3a876a=this['getImmediateChild'](_0x2d5c3a)['updateChild'](S(_0x2680a1),_0x3d60cb);return this['updateImmediateChild'](_0x2d5c3a,_0x3a876a);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5c42fe){if(this['isEmpty']())return null;const _0x21f0a6={};let _0x2c4136=0x0,_0x22ba69=0x0,_0x3f4ff5=!0x0;if(this['forEachChild'](R,(_0x2b2613,_0x1e5091)=>{_0x21f0a6[_0x2b2613]=_0x1e5091['val'](_0x5c42fe),_0x2c4136++,_0x3f4ff5&&g['INTEGER_REGEXP_']['test'](_0x2b2613)?_0x22ba69=Math['max'](_0x22ba69,Number(_0x2b2613)):_0x3f4ff5=!0x1;}),!_0x5c42fe&&_0x3f4ff5&&_0x22ba69<0x2*_0x2c4136){const _0x59c073=[];for(const _0x3490ab in _0x21f0a6)_0x59c073[_0x3490ab]=_0x21f0a6[_0x3490ab];return _0x59c073;}else return _0x5c42fe&&!this['getPriority']()['isEmpty']()&&(_0x21f0a6['.priority']=this['getPriority']()['val']()),_0x21f0a6;}['hash'](){if(this['lazyHash_']===null){let _0x5c3d6d='';this['getPriority']()['isEmpty']()||(_0x5c3d6d+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x33c47b,_0x2a8789)=>{const _0x2d2df5=_0x2a8789['hash']();_0x2d2df5!==''&&(_0x5c3d6d+=':'+_0x33c47b+':'+_0x2d2df5);}),this['lazyHash_']=_0x5c3d6d===''?'':ro(_0x5c3d6d);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3b0bc4,_0x1ba21f,_0x9ff7b7){const _0x19b56a=this['resolveIndex_'](_0x9ff7b7);if(_0x19b56a){const _0x2b7888=_0x19b56a['getPredecessorKey'](new E(_0x3b0bc4,_0x1ba21f));return _0x2b7888?_0x2b7888['name']:null;}else return this['children_']['getPredecessorKey'](_0x3b0bc4);}['getFirstChildName'](_0x4fed88){const _0x4d4ec=this['resolveIndex_'](_0x4fed88);if(_0x4d4ec){const _0xd20a19=_0x4d4ec['minKey']();return _0xd20a19&&_0xd20a19['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x367ba3){const _0x69c2a9=this['getFirstChildName'](_0x367ba3);return _0x69c2a9?new E(_0x69c2a9,this['children_']['get'](_0x69c2a9)):null;}['getLastChildName'](_0x1c4401){const _0x28d03f=this['resolveIndex_'](_0x1c4401);if(_0x28d03f){const _0x21f6ff=_0x28d03f['maxKey']();return _0x21f6ff&&_0x21f6ff['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2b28f4){const _0x10807c=this['getLastChildName'](_0x2b28f4);return _0x10807c?new E(_0x10807c,this['children_']['get'](_0x10807c)):null;}['forEachChild'](_0x28a1b0,_0xfce150){const _0x9b72b4=this['resolveIndex_'](_0x28a1b0);return _0x9b72b4?_0x9b72b4['inorderTraversal'](_0x1fa9ff=>_0xfce150(_0x1fa9ff['name'],_0x1fa9ff['node'])):this['children_']['inorderTraversal'](_0xfce150);}['getIterator'](_0x5d89ce){return this['getIteratorFrom'](_0x5d89ce['minPost'](),_0x5d89ce);}['getIteratorFrom'](_0xd8f8df,_0x5b3fae){const _0x5360d5=this['resolveIndex_'](_0x5b3fae);if(_0x5360d5)return _0x5360d5['getIteratorFrom'](_0xd8f8df,_0x446628=>_0x446628);{const _0x18a804=this['children_']['getIteratorFrom'](_0xd8f8df['name'],E['Wrap']);let _0x3ce505=_0x18a804['peek']();for(;_0x3ce505!=null&&_0x5b3fae['compare'](_0x3ce505,_0xd8f8df)<0x0;)_0x18a804['getNext'](),_0x3ce505=_0x18a804['peek']();return _0x18a804;}}['getReverseIterator'](_0x436f4d){return this['getReverseIteratorFrom'](_0x436f4d['maxPost'](),_0x436f4d);}['getReverseIteratorFrom'](_0x563378,_0x361fa8){const _0x4147ab=this['resolveIndex_'](_0x361fa8);if(_0x4147ab)return _0x4147ab['getReverseIteratorFrom'](_0x563378,_0x709ba5=>_0x709ba5);{const _0x5aaeae=this['children_']['getReverseIteratorFrom'](_0x563378['name'],E['Wrap']);let _0x2d542f=_0x5aaeae['peek']();for(;_0x2d542f!=null&&_0x361fa8['compare'](_0x2d542f,_0x563378)>0x0;)_0x5aaeae['getNext'](),_0x2d542f=_0x5aaeae['peek']();return _0x5aaeae;}}['compareTo'](_0x5c484e){return this['isEmpty']()?_0x5c484e['isEmpty']()?0x0:-0x1:_0x5c484e['isLeafNode']()||_0x5c484e['isEmpty']()?0x1:_0x5c484e===Kt?-0x1:0x0;}['withIndex'](_0x3160d6){if(_0x3160d6===ve||this['indexMap_']['hasIndex'](_0x3160d6))return this;{const _0x4f5c9c=this['indexMap_']['addIndex'](_0x3160d6,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4f5c9c);}}['isIndexed'](_0x1d7889){return _0x1d7889===ve||this['indexMap_']['hasIndex'](_0x1d7889);}['equals'](_0x2ad428){if(_0x2ad428===this)return!0x0;if(_0x2ad428['isLeafNode']())return!0x1;{const _0x3d6a57=_0x2ad428;if(this['getPriority']()['equals'](_0x3d6a57['getPriority']())){if(this['children_']['count']()===_0x3d6a57['children_']['count']()){const _0x278125=this['getIterator'](R),_0x4dff14=_0x3d6a57['getIterator'](R);let _0x5f1c0f=_0x278125['getNext'](),_0x1aca63=_0x4dff14['getNext']();for(;_0x5f1c0f&&_0x1aca63;){if(_0x5f1c0f['name']!==_0x1aca63['name']||!_0x5f1c0f['node']['equals'](_0x1aca63['node']))return!0x1;_0x5f1c0f=_0x278125['getNext'](),_0x1aca63=_0x4dff14['getNext']();}return _0x5f1c0f===null&&_0x1aca63===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x1edb2c){return _0x1edb2c===ve?null:this['indexMap_']['get'](_0x1edb2c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x544a06){return _0x544a06===this?0x0:0x1;}['equals'](_0x3a9330){return _0x3a9330===this;}['getPriority'](){return this;}['getImmediateChild'](_0x352698){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3fd43b,_0x180764=null){if(_0x3fd43b===null)return g['EMPTY_NODE'];if(typeof _0x3fd43b=='object'&&'.priority'in _0x3fd43b&&(_0x180764=_0x3fd43b['.priority']),f(_0x180764===null||typeof _0x180764=='string'||typeof _0x180764=='number'||typeof _0x180764=='object'&&'.sv'in _0x180764,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x180764),typeof _0x3fd43b=='object'&&'.value'in _0x3fd43b&&_0x3fd43b['.value']!==null&&(_0x3fd43b=_0x3fd43b['.value']),typeof _0x3fd43b!='object'||'.sv'in _0x3fd43b){const _0x5a19e7=_0x3fd43b;return new D(_0x5a19e7,A(_0x180764));}if(!(_0x3fd43b instanceof Array)&&Gh){const _0x28cb6f=[];let _0xa3edba=!0x1;if(x(_0x3fd43b,(_0x508eb9,_0x50a5bc)=>{if(_0x508eb9['substring'](0x0,0x1)!=='.'){const _0x158fcb=A(_0x50a5bc);_0x158fcb['isEmpty']()||(_0xa3edba=_0xa3edba||!_0x158fcb['getPriority']()['isEmpty'](),_0x28cb6f['push'](new E(_0x508eb9,_0x158fcb)));}}),_0x28cb6f['length']===0x0)return g['EMPTY_NODE'];const _0x2ce46b=yn(_0x28cb6f,xh,_0x4fd762=>_0x4fd762['name'],Qi);if(_0xa3edba){const _0x1a3520=yn(_0x28cb6f,R['getCompare']());return new g(_0x2ce46b,A(_0x180764),new te({'.priority':_0x1a3520},{'.priority':R}));}else return new g(_0x2ce46b,A(_0x180764),te['Default']);}else{let _0x500491=g['EMPTY_NODE'];return x(_0x3fd43b,(_0x5bdd70,_0x11bda3)=>{if(Q(_0x3fd43b,_0x5bdd70)&&_0x5bdd70['substring'](0x0,0x1)!=='.'){const _0x181cd7=A(_0x11bda3);(_0x181cd7['isLeafNode']()||!_0x181cd7['isEmpty']())&&(_0x500491=_0x500491['updateImmediateChild'](_0x5bdd70,_0x181cd7));}}),_0x500491['updatePriority'](A(_0x180764));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x301189){super(),this['indexPath_']=_0x301189,f(!v(_0x301189)&&y(_0x301189)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xfc146c){return _0xfc146c['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1496ef){return!_0x1496ef['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2d19de,_0x497bbb){const _0x21ab68=this['extractChild'](_0x2d19de['node']),_0x5567d5=this['extractChild'](_0x497bbb['node']),_0x3b57ab=_0x21ab68['compareTo'](_0x5567d5);return _0x3b57ab===0x0?qe(_0x2d19de['name'],_0x497bbb['name']):_0x3b57ab;}['makePost'](_0x4298fa,_0x12aafb){const _0x5d87b8=A(_0x4298fa),_0x24b59c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5d87b8);return new E(_0x12aafb,_0x24b59c);}['maxPost'](){const _0x6a642f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x6a642f);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x498656,_0x3cac5d){const _0xd67a75=_0x498656['node']['compareTo'](_0x3cac5d['node']);return _0xd67a75===0x0?qe(_0x498656['name'],_0x3cac5d['name']):_0xd67a75;}['isDefinedOn'](_0x5cd305){return!0x0;}['indexedValueChanged'](_0x133e3f,_0x3828ef){return!_0x133e3f['equals'](_0x3828ef);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x44665d,_0x1fe7bd){const _0x4b66e3=A(_0x44665d);return new E(_0x1fe7bd,_0x4b66e3);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x1f0df3){return{'type':'value','snapshotNode':_0x1f0df3};}function rt(_0x1e551a,_0x21d6ad){return{'type':'child_added','snapshotNode':_0x21d6ad,'childName':_0x1e551a};}function Lt(_0x19ff4c,_0x344867){return{'type':'child_removed','snapshotNode':_0x344867,'childName':_0x19ff4c};}function xt(_0x3bfec6,_0x1af38a,_0x55174a){return{'type':'child_changed','snapshotNode':_0x1af38a,'childName':_0x3bfec6,'oldSnap':_0x55174a};}function zh(_0x2e10f0,_0x282427){return{'type':'child_moved','snapshotNode':_0x282427,'childName':_0x2e10f0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x40870c){this['index_']=_0x40870c;}['updateChild'](_0x23808e,_0x571b8,_0x4e056f,_0x835aa3,_0x24e034,_0xf7d021){f(_0x23808e['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x28f746=_0x23808e['getImmediateChild'](_0x571b8);return _0x28f746['getChild'](_0x835aa3)['equals'](_0x4e056f['getChild'](_0x835aa3))&&_0x28f746['isEmpty']()===_0x4e056f['isEmpty']()||(_0xf7d021!=null&&(_0x4e056f['isEmpty']()?_0x23808e['hasChild'](_0x571b8)?_0xf7d021['trackChildChange'](Lt(_0x571b8,_0x28f746)):f(_0x23808e['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x28f746['isEmpty']()?_0xf7d021['trackChildChange'](rt(_0x571b8,_0x4e056f)):_0xf7d021['trackChildChange'](xt(_0x571b8,_0x4e056f,_0x28f746))),_0x23808e['isLeafNode']()&&_0x4e056f['isEmpty']())?_0x23808e:_0x23808e['updateImmediateChild'](_0x571b8,_0x4e056f)['withIndex'](this['index_']);}['updateFullNode'](_0x4b9c60,_0x5f0e07,_0x2004b9){return _0x2004b9!=null&&(_0x4b9c60['isLeafNode']()||_0x4b9c60['forEachChild'](R,(_0x1af564,_0x38dd4c)=>{_0x5f0e07['hasChild'](_0x1af564)||_0x2004b9['trackChildChange'](Lt(_0x1af564,_0x38dd4c));}),_0x5f0e07['isLeafNode']()||_0x5f0e07['forEachChild'](R,(_0x543d3f,_0x1b5e28)=>{if(_0x4b9c60['hasChild'](_0x543d3f)){const _0x3b35a6=_0x4b9c60['getImmediateChild'](_0x543d3f);_0x3b35a6['equals'](_0x1b5e28)||_0x2004b9['trackChildChange'](xt(_0x543d3f,_0x1b5e28,_0x3b35a6));}else _0x2004b9['trackChildChange'](rt(_0x543d3f,_0x1b5e28));})),_0x5f0e07['withIndex'](this['index_']);}['updatePriority'](_0x28f1da,_0x449184){return _0x28f1da['isEmpty']()?g['EMPTY_NODE']:_0x28f1da['updatePriority'](_0x449184);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x991f8a){this['indexedFilter_']=new Xi(_0x991f8a['getIndex']()),this['index_']=_0x991f8a['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x991f8a),this['endPost_']=Ft['getEndPost_'](_0x991f8a),this['startIsInclusive_']=!_0x991f8a['startAfterSet_'],this['endIsInclusive_']=!_0x991f8a['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x463a05){const _0x10d7ad=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x463a05)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x463a05)<0x0,_0x29ca96=this['endIsInclusive_']?this['index_']['compare'](_0x463a05,this['getEndPost']())<=0x0:this['index_']['compare'](_0x463a05,this['getEndPost']())<0x0;return _0x10d7ad&&_0x29ca96;}['updateChild'](_0x5b70bd,_0x14177f,_0x115c64,_0x1f1e9b,_0x33a4e3,_0x1da78f){return this['matches'](new E(_0x14177f,_0x115c64))||(_0x115c64=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5b70bd,_0x14177f,_0x115c64,_0x1f1e9b,_0x33a4e3,_0x1da78f);}['updateFullNode'](_0x35ad34,_0x12a05e,_0x3a2378){_0x12a05e['isLeafNode']()&&(_0x12a05e=g['EMPTY_NODE']);let _0x49af1d=_0x12a05e['withIndex'](this['index_']);_0x49af1d=_0x49af1d['updatePriority'](g['EMPTY_NODE']);const _0x116d77=this;return _0x12a05e['forEachChild'](R,(_0x1eea96,_0x11f114)=>{_0x116d77['matches'](new E(_0x1eea96,_0x11f114))||(_0x49af1d=_0x49af1d['updateImmediateChild'](_0x1eea96,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x35ad34,_0x49af1d,_0x3a2378);}['updatePriority'](_0xad7271,_0x45046b){return _0xad7271;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1c0cf6){if(_0x1c0cf6['hasStart']()){const _0x48b946=_0x1c0cf6['getIndexStartName']();return _0x1c0cf6['getIndex']()['makePost'](_0x1c0cf6['getIndexStartValue'](),_0x48b946);}else return _0x1c0cf6['getIndex']()['minPost']();}static['getEndPost_'](_0x4e39e2){if(_0x4e39e2['hasEnd']()){const _0x263f62=_0x4e39e2['getIndexEndName']();return _0x4e39e2['getIndex']()['makePost'](_0x4e39e2['getIndexEndValue'](),_0x263f62);}else return _0x4e39e2['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x1c60df){this['withinDirectionalStart']=_0xbb2ec0=>this['reverse_']?this['withinEndPost'](_0xbb2ec0):this['withinStartPost'](_0xbb2ec0),this['withinDirectionalEnd']=_0x5b6f58=>this['reverse_']?this['withinStartPost'](_0x5b6f58):this['withinEndPost'](_0x5b6f58),this['withinStartPost']=_0x184f15=>{const _0x3b41af=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x184f15);return this['startIsInclusive_']?_0x3b41af<=0x0:_0x3b41af<0x0;},this['withinEndPost']=_0x23b0b9=>{const _0x303957=this['index_']['compare'](_0x23b0b9,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x303957<=0x0:_0x303957<0x0;},this['rangedFilter_']=new Ft(_0x1c60df),this['index_']=_0x1c60df['getIndex'](),this['limit_']=_0x1c60df['getLimit'](),this['reverse_']=!_0x1c60df['isViewFromLeft'](),this['startIsInclusive_']=!_0x1c60df['startAfterSet_'],this['endIsInclusive_']=!_0x1c60df['endBeforeSet_'];}['updateChild'](_0x2ed50c,_0x1db6f6,_0x818664,_0x143d6e,_0x5a79a4,_0x26e94e){return this['rangedFilter_']['matches'](new E(_0x1db6f6,_0x818664))||(_0x818664=g['EMPTY_NODE']),_0x2ed50c['getImmediateChild'](_0x1db6f6)['equals'](_0x818664)?_0x2ed50c:_0x2ed50c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2ed50c,_0x1db6f6,_0x818664,_0x143d6e,_0x5a79a4,_0x26e94e):this['fullLimitUpdateChild_'](_0x2ed50c,_0x1db6f6,_0x818664,_0x5a79a4,_0x26e94e);}['updateFullNode'](_0x260bce,_0x5655ab,_0x27a6b0){let _0x5cee19;if(_0x5655ab['isLeafNode']()||_0x5655ab['isEmpty']())_0x5cee19=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5655ab['numChildren']()&&_0x5655ab['isIndexed'](this['index_'])){_0x5cee19=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1bcec5;this['reverse_']?_0x1bcec5=_0x5655ab['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1bcec5=_0x5655ab['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2fcef4=0x0;for(;_0x1bcec5['hasNext']()&&_0x2fcef4<this['limit_'];){const _0x4e80cb=_0x1bcec5['getNext']();if(this['withinDirectionalStart'](_0x4e80cb)){if(this['withinDirectionalEnd'](_0x4e80cb))_0x5cee19=_0x5cee19['updateImmediateChild'](_0x4e80cb['name'],_0x4e80cb['node']),_0x2fcef4++;else break;}else continue;}}else{_0x5cee19=_0x5655ab['withIndex'](this['index_']),_0x5cee19=_0x5cee19['updatePriority'](g['EMPTY_NODE']);let _0x1ac64f;this['reverse_']?_0x1ac64f=_0x5cee19['getReverseIterator'](this['index_']):_0x1ac64f=_0x5cee19['getIterator'](this['index_']);let _0x2f8fbb=0x0;for(;_0x1ac64f['hasNext']();){const _0x12d24e=_0x1ac64f['getNext']();_0x2f8fbb<this['limit_']&&this['withinDirectionalStart'](_0x12d24e)&&this['withinDirectionalEnd'](_0x12d24e)?_0x2f8fbb++:_0x5cee19=_0x5cee19['updateImmediateChild'](_0x12d24e['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x260bce,_0x5cee19,_0x27a6b0);}['updatePriority'](_0x5e9213,_0x1be1b8){return _0x5e9213;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x36b291,_0x37c87b,_0x53f469,_0x1656df,_0x4f8609){let _0x226a25;if(this['reverse_']){const _0x474519=this['index_']['getCompare']();_0x226a25=(_0x188b88,_0x46f9e9)=>_0x474519(_0x46f9e9,_0x188b88);}else _0x226a25=this['index_']['getCompare']();const _0xc65fa3=_0x36b291;f(_0xc65fa3['numChildren']()===this['limit_'],'');const _0x5cf632=new E(_0x37c87b,_0x53f469),_0x5b4669=this['reverse_']?_0xc65fa3['getFirstChild'](this['index_']):_0xc65fa3['getLastChild'](this['index_']),_0x2d5b41=this['rangedFilter_']['matches'](_0x5cf632);if(_0xc65fa3['hasChild'](_0x37c87b)){const _0x463ab8=_0xc65fa3['getImmediateChild'](_0x37c87b);let _0x4d48b6=_0x1656df['getChildAfterChild'](this['index_'],_0x5b4669,this['reverse_']);for(;_0x4d48b6!=null&&(_0x4d48b6['name']===_0x37c87b||_0xc65fa3['hasChild'](_0x4d48b6['name']));)_0x4d48b6=_0x1656df['getChildAfterChild'](this['index_'],_0x4d48b6,this['reverse_']);const _0x1b6170=_0x4d48b6==null?0x1:_0x226a25(_0x4d48b6,_0x5cf632);if(_0x2d5b41&&!_0x53f469['isEmpty']()&&_0x1b6170>=0x0)return _0x4f8609!=null&&_0x4f8609['trackChildChange'](xt(_0x37c87b,_0x53f469,_0x463ab8)),_0xc65fa3['updateImmediateChild'](_0x37c87b,_0x53f469);{_0x4f8609!=null&&_0x4f8609['trackChildChange'](Lt(_0x37c87b,_0x463ab8));const _0xde1fb5=_0xc65fa3['updateImmediateChild'](_0x37c87b,g['EMPTY_NODE']);return _0x4d48b6!=null&&this['rangedFilter_']['matches'](_0x4d48b6)?(_0x4f8609!=null&&_0x4f8609['trackChildChange'](rt(_0x4d48b6['name'],_0x4d48b6['node'])),_0xde1fb5['updateImmediateChild'](_0x4d48b6['name'],_0x4d48b6['node'])):_0xde1fb5;}}else return _0x53f469['isEmpty']()?_0x36b291:_0x2d5b41&&_0x226a25(_0x5b4669,_0x5cf632)>=0x0?(_0x4f8609!=null&&(_0x4f8609['trackChildChange'](Lt(_0x5b4669['name'],_0x5b4669['node'])),_0x4f8609['trackChildChange'](rt(_0x37c87b,_0x53f469))),_0xc65fa3['updateImmediateChild'](_0x37c87b,_0x53f469)['updateImmediateChild'](_0x5b4669['name'],g['EMPTY_NODE'])):_0x36b291;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5580de=new Zi();return _0x5580de['limitSet_']=this['limitSet_'],_0x5580de['limit_']=this['limit_'],_0x5580de['startSet_']=this['startSet_'],_0x5580de['startAfterSet_']=this['startAfterSet_'],_0x5580de['indexStartValue_']=this['indexStartValue_'],_0x5580de['startNameSet_']=this['startNameSet_'],_0x5580de['indexStartName_']=this['indexStartName_'],_0x5580de['endSet_']=this['endSet_'],_0x5580de['endBeforeSet_']=this['endBeforeSet_'],_0x5580de['indexEndValue_']=this['indexEndValue_'],_0x5580de['endNameSet_']=this['endNameSet_'],_0x5580de['indexEndName_']=this['indexEndName_'],_0x5580de['index_']=this['index_'],_0x5580de['viewFrom_']=this['viewFrom_'],_0x5580de;}}function Kh(_0x18335b){return _0x18335b['loadsAllData']()?new Xi(_0x18335b['getIndex']()):_0x18335b['hasLimit']()?new jh(_0x18335b):new Ft(_0x18335b);}function Yh(_0x581771,_0x48bc32){const _0x20762d=_0x581771['copy']();return _0x20762d['limitSet_']=!0x0,_0x20762d['limit_']=_0x48bc32,_0x20762d['viewFrom_']='l',_0x20762d;}function Qh(_0x479261,_0x32830c,_0x4c141f){const _0x396e3a=_0x479261['copy']();return _0x396e3a['startSet_']=!0x0,_0x32830c===void 0x0&&(_0x32830c=null),_0x396e3a['indexStartValue_']=_0x32830c,_0x4c141f!=null?(_0x396e3a['startNameSet_']=!0x0,_0x396e3a['indexStartName_']=_0x4c141f):(_0x396e3a['startNameSet_']=!0x1,_0x396e3a['indexStartName_']=''),_0x396e3a;}function Jh(_0xab2d7d,_0x56f115,_0x63c42){const _0x45631b=_0xab2d7d['copy']();return _0x45631b['endSet_']=!0x0,_0x56f115===void 0x0&&(_0x56f115=null),_0x45631b['indexEndValue_']=_0x56f115,_0x63c42!==void 0x0?(_0x45631b['endNameSet_']=!0x0,_0x45631b['indexEndName_']=_0x63c42):(_0x45631b['endNameSet_']=!0x1,_0x45631b['indexEndName_']=''),_0x45631b;}function xo(_0xcc148d,_0x453621){const _0x27fd63=_0xcc148d['copy']();return _0x27fd63['index_']=_0x453621,_0x27fd63;}function ir(_0x331e69){const _0x46bea4={};if(_0x331e69['isDefault']())return _0x46bea4;let _0x449dd9;if(_0x331e69['index_']===R?_0x449dd9='$priority':_0x331e69['index_']===Mo?_0x449dd9='$value':_0x331e69['index_']===ve?_0x449dd9='$key':(f(_0x331e69['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x449dd9=_0x331e69['index_']['toString']()),_0x46bea4['orderBy']=O(_0x449dd9),_0x331e69['startSet_']){const _0x5e16c0=_0x331e69['startAfterSet_']?'startAfter':'startAt';_0x46bea4[_0x5e16c0]=O(_0x331e69['indexStartValue_']),_0x331e69['startNameSet_']&&(_0x46bea4[_0x5e16c0]+=','+O(_0x331e69['indexStartName_']));}if(_0x331e69['endSet_']){const _0x47a07b=_0x331e69['endBeforeSet_']?'endBefore':'endAt';_0x46bea4[_0x47a07b]=O(_0x331e69['indexEndValue_']),_0x331e69['endNameSet_']&&(_0x46bea4[_0x47a07b]+=','+O(_0x331e69['indexEndName_']));}return _0x331e69['limitSet_']&&(_0x331e69['isViewFromLeft']()?_0x46bea4['limitToFirst']=_0x331e69['limit_']:_0x46bea4['limitToLast']=_0x331e69['limit_']),_0x46bea4;}function sr(_0x5b8765){const _0x47056e={};if(_0x5b8765['startSet_']&&(_0x47056e['sp']=_0x5b8765['indexStartValue_'],_0x5b8765['startNameSet_']&&(_0x47056e['sn']=_0x5b8765['indexStartName_']),_0x47056e['sin']=!_0x5b8765['startAfterSet_']),_0x5b8765['endSet_']&&(_0x47056e['ep']=_0x5b8765['indexEndValue_'],_0x5b8765['endNameSet_']&&(_0x47056e['en']=_0x5b8765['indexEndName_']),_0x47056e['ein']=!_0x5b8765['endBeforeSet_']),_0x5b8765['limitSet_']){_0x47056e['l']=_0x5b8765['limit_'];let _0x3cb69b=_0x5b8765['viewFrom_'];_0x3cb69b===''&&(_0x5b8765['isViewFromLeft']()?_0x3cb69b='l':_0x3cb69b='r'),_0x47056e['vf']=_0x3cb69b;}return _0x5b8765['index_']!==R&&(_0x47056e['i']=_0x5b8765['index_']['toString']()),_0x47056e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x14f353){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4c5df4,_0x5cbc8b){return _0x5cbc8b!==void 0x0?'tag$'+_0x5cbc8b:(f(_0x4c5df4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4c5df4['_path']['toString']());}constructor(_0x2ef029,_0x4a5f7c,_0x414a3a,_0x2338ad){super(),this['repoInfo_']=_0x2ef029,this['onDataUpdate_']=_0x4a5f7c,this['authTokenProvider_']=_0x414a3a,this['appCheckTokenProvider_']=_0x2338ad,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x29c61f,_0xc295a,_0x2c6ac7,_0x10efa4){const _0x1b83cf=_0x29c61f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1b83cf+'\x20'+_0x29c61f['_queryIdentifier']);const _0x3330e7=vn['getListenId_'](_0x29c61f,_0x2c6ac7),_0x32587b={};this['listens_'][_0x3330e7]=_0x32587b;const _0x4509f6=ir(_0x29c61f['_queryParams']);this['restRequest_'](_0x1b83cf+'.json',_0x4509f6,(_0x1c8f67,_0x3b5e76)=>{let _0x320cc2=_0x3b5e76;if(_0x1c8f67===0x194&&(_0x320cc2=null,_0x1c8f67=null),_0x1c8f67===null&&this['onDataUpdate_'](_0x1b83cf,_0x320cc2,!0x1,_0x2c6ac7),Le(this['listens_'],_0x3330e7)===_0x32587b){let _0x4be7cb;_0x1c8f67?_0x1c8f67===0x191?_0x4be7cb='permission_denied':_0x4be7cb='rest_error:'+_0x1c8f67:_0x4be7cb='ok',_0x10efa4(_0x4be7cb,null);}});}['unlisten'](_0x3f3cd3,_0x4d86de){const _0x39ae26=vn['getListenId_'](_0x3f3cd3,_0x4d86de);delete this['listens_'][_0x39ae26];}['get'](_0x487e33){const _0x548e46=ir(_0x487e33['_queryParams']),_0x4edeea=_0x487e33['_path']['toString'](),_0x53766a=new H();return this['restRequest_'](_0x4edeea+'.json',_0x548e46,(_0x1c5057,_0x37362a)=>{let _0x27cd60=_0x37362a;_0x1c5057===0x194&&(_0x27cd60=null,_0x1c5057=null),_0x1c5057===null?(this['onDataUpdate_'](_0x4edeea,_0x27cd60,!0x1,null),_0x53766a['resolve'](_0x27cd60)):_0x53766a['reject'](new Error(_0x27cd60));}),_0x53766a['promise'];}['refreshAuthToken'](_0x492520){}['restRequest_'](_0x321ba8,_0x46f0c8={},_0x2f41fa){return _0x46f0c8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x148da1,_0x5a871c])=>{_0x148da1&&_0x148da1['accessToken']&&(_0x46f0c8['auth']=_0x148da1['accessToken']),_0x5a871c&&_0x5a871c['token']&&(_0x46f0c8['ac']=_0x5a871c['token']);const _0x1363c6=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x321ba8+'?ns='+this['repoInfo_']['namespace']+ut(_0x46f0c8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1363c6);const _0x513b65=new XMLHttpRequest();_0x513b65['onreadystatechange']=()=>{if(_0x2f41fa&&_0x513b65['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1363c6+'\x20received.\x20status:',_0x513b65['status'],'response:',_0x513b65['responseText']);let _0x5bfd6e=null;if(_0x513b65['status']>=0xc8&&_0x513b65['status']<0x12c){try{_0x5bfd6e=Nt(_0x513b65['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1363c6+':\x20'+_0x513b65['responseText']);}_0x2f41fa(null,_0x5bfd6e);}else _0x513b65['status']!==0x191&&_0x513b65['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1363c6+'\x20Status:\x20'+_0x513b65['status']),_0x2f41fa(_0x513b65['status']);_0x2f41fa=null;}},_0x513b65['open']('GET',_0x1363c6,!0x0),_0x513b65['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2e1957){return this['rootNode_']['getChild'](_0x2e1957);}['updateSnapshot'](_0x5de5e2,_0x5a1c12){this['rootNode_']=this['rootNode_']['updateChild'](_0x5de5e2,_0x5a1c12);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x3a8de1,_0x409841,_0x408f28){if(v(_0x409841))_0x3a8de1['value']=_0x408f28,_0x3a8de1['children']['clear']();else{if(_0x3a8de1['value']!==null)_0x3a8de1['value']=_0x3a8de1['value']['updateChild'](_0x409841,_0x408f28);else{const _0x412859=y(_0x409841);_0x3a8de1['children']['has'](_0x412859)||_0x3a8de1['children']['set'](_0x412859,En());const _0x3d008c=_0x3a8de1['children']['get'](_0x412859);_0x409841=S(_0x409841),pt(_0x3d008c,_0x409841,_0x408f28);}}}function Ti(_0x11819e,_0x4fea6a){if(v(_0x4fea6a))return _0x11819e['value']=null,_0x11819e['children']['clear'](),!0x0;if(_0x11819e['value']!==null){if(_0x11819e['value']['isLeafNode']())return!0x1;{const _0x156b39=_0x11819e['value'];return _0x11819e['value']=null,_0x156b39['forEachChild'](R,(_0x5f4622,_0x2383f8)=>{pt(_0x11819e,new C(_0x5f4622),_0x2383f8);}),Ti(_0x11819e,_0x4fea6a);}}else{if(_0x11819e['children']['size']>0x0){const _0x5ea8a2=y(_0x4fea6a);return _0x4fea6a=S(_0x4fea6a),_0x11819e['children']['has'](_0x5ea8a2)&&Ti(_0x11819e['children']['get'](_0x5ea8a2),_0x4fea6a)&&_0x11819e['children']['delete'](_0x5ea8a2),_0x11819e['children']['size']===0x0;}else return!0x0;}}function Si(_0x226da0,_0x11ba4d,_0xdfd82e){_0x226da0['value']!==null?_0xdfd82e(_0x11ba4d,_0x226da0['value']):Zh(_0x226da0,(_0x29567a,_0x64641b)=>{const _0xe03880=new C(_0x11ba4d['toString']()+'/'+_0x29567a);Si(_0x64641b,_0xe03880,_0xdfd82e);});}function Zh(_0x4ca6db,_0x3d4f8d){_0x4ca6db['children']['forEach']((_0x4be236,_0x23ffc3)=>{_0x3d4f8d(_0x23ffc3,_0x4be236);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x5e7aca){this['collection_']=_0x5e7aca,this['last_']=null;}['get'](){const _0xdbe1f7=this['collection_']['get'](),_0x4a8ec7={..._0xdbe1f7};return this['last_']&&x(this['last_'],(_0x5eef4f,_0x1287c0)=>{_0x4a8ec7[_0x5eef4f]=_0x4a8ec7[_0x5eef4f]-_0x1287c0;}),this['last_']=_0xdbe1f7,_0x4a8ec7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x1bc296,_0x3c79b4){this['server_']=_0x3c79b4,this['statsToReport_']={},this['statsListener_']=new eu(_0x1bc296);const _0x283b5c=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x283b5c));}['reportStats_'](){const _0x307ced=this['statsListener_']['get'](),_0x1fa885={};let _0x4dd64d=!0x1;x(_0x307ced,(_0x225917,_0x166792)=>{_0x166792>0x0&&Q(this['statsToReport_'],_0x225917)&&(_0x1fa885[_0x225917]=_0x166792,_0x4dd64d=!0x0);}),_0x4dd64d&&this['server_']['reportStats'](_0x1fa885),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x464d30){_0x464d30[_0x464d30['OVERWRITE']=0x0]='OVERWRITE',_0x464d30[_0x464d30['MERGE']=0x1]='MERGE',_0x464d30[_0x464d30['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x464d30[_0x464d30['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x236e6c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x236e6c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xc719d5,_0x5ec8de,_0x42fd17){this['path']=_0xc719d5,this['affectedTree']=_0x5ec8de,this['revert']=_0x42fd17,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1bcd02){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x22148d=this['affectedTree']['subtree'](new C(_0x1bcd02));return new In(w(),_0x22148d,this['revert']);}}else return f(y(this['path'])===_0x1bcd02,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4e70b5,_0x321385){this['source']=_0x4e70b5,this['path']=_0x321385,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5d55f4){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x16a976,_0xfaadb5,_0x29df0d){this['source']=_0x16a976,this['path']=_0xfaadb5,this['snap']=_0x29df0d,this['type']=z['OVERWRITE'];}['operationForChild'](_0x45e899){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x45e899)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x20342b,_0x426216,_0x10e9b0){this['source']=_0x20342b,this['path']=_0x426216,this['children']=_0x10e9b0,this['type']=z['MERGE'];}['operationForChild'](_0x18f1d5){if(v(this['path'])){const _0x69fa90=this['children']['subtree'](new C(_0x18f1d5));return _0x69fa90['isEmpty']()?null:_0x69fa90['value']?new Be(this['source'],w(),_0x69fa90['value']):new ot(this['source'],w(),_0x69fa90);}else return f(y(this['path'])===_0x18f1d5,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x308057,_0x52903c,_0x125a25){this['node_']=_0x308057,this['fullyInitialized_']=_0x52903c,this['filtered_']=_0x125a25;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x299030){if(v(_0x299030))return this['isFullyInitialized']()&&!this['filtered_'];const _0x43567c=y(_0x299030);return this['isCompleteForChild'](_0x43567c);}['isCompleteForChild'](_0x35be53){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x35be53);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x193b4a){this['query_']=_0x193b4a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x41abc8,_0x4ad932,_0x4457b3,_0x2102c5){const _0x8879df=[],_0x488c36=[];return _0x4ad932['forEach'](_0x5cc271=>{_0x5cc271['type']==='child_changed'&&_0x41abc8['index_']['indexedValueChanged'](_0x5cc271['oldSnap'],_0x5cc271['snapshotNode'])&&_0x488c36['push'](zh(_0x5cc271['childName'],_0x5cc271['snapshotNode']));}),wt(_0x41abc8,_0x8879df,'child_removed',_0x4ad932,_0x2102c5,_0x4457b3),wt(_0x41abc8,_0x8879df,'child_added',_0x4ad932,_0x2102c5,_0x4457b3),wt(_0x41abc8,_0x8879df,'child_moved',_0x488c36,_0x2102c5,_0x4457b3),wt(_0x41abc8,_0x8879df,'child_changed',_0x4ad932,_0x2102c5,_0x4457b3),wt(_0x41abc8,_0x8879df,'value',_0x4ad932,_0x2102c5,_0x4457b3),_0x8879df;}function wt(_0x11516f,_0x36a41e,_0x108ca3,_0x1c1eb0,_0x1123cb,_0x2be201){const _0x1dc4c3=_0x1c1eb0['filter'](_0x2ac207=>_0x2ac207['type']===_0x108ca3);_0x1dc4c3['sort']((_0x56685c,_0x5ebdaf)=>au(_0x11516f,_0x56685c,_0x5ebdaf)),_0x1dc4c3['forEach'](_0x5dd0eb=>{const _0xccd9e8=ou(_0x11516f,_0x5dd0eb,_0x2be201);_0x1123cb['forEach'](_0x29f55c=>{_0x29f55c['respondsTo'](_0x5dd0eb['type'])&&_0x36a41e['push'](_0x29f55c['createEvent'](_0xccd9e8,_0x11516f['query_']));});});}function ou(_0x4d3431,_0x5d7a99,_0x4e6bd7){return _0x5d7a99['type']==='value'||_0x5d7a99['type']==='child_removed'||(_0x5d7a99['prevName']=_0x4e6bd7['getPredecessorChildName'](_0x5d7a99['childName'],_0x5d7a99['snapshotNode'],_0x4d3431['index_'])),_0x5d7a99;}function au(_0x50f972,_0x41ba93,_0x162553){if(_0x41ba93['childName']==null||_0x162553['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x4e7fd9=new E(_0x41ba93['childName'],_0x41ba93['snapshotNode']),_0x59fc3d=new E(_0x162553['childName'],_0x162553['snapshotNode']);return _0x50f972['index_']['compare'](_0x4e7fd9,_0x59fc3d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x23824b,_0x2b24ec){return{'eventCache':_0x23824b,'serverCache':_0x2b24ec};}function Rt(_0x5994ed,_0x325b35,_0x1a3eb7,_0x4b58bb){return Un(new Te(_0x325b35,_0x1a3eb7,_0x4b58bb),_0x5994ed['serverCache']);}function Fo(_0x49637b,_0x451299,_0x46077f,_0x11b26e){return Un(_0x49637b['eventCache'],new Te(_0x451299,_0x46077f,_0x11b26e));}function wn(_0x186dea){return _0x186dea['eventCache']['isFullyInitialized']()?_0x186dea['eventCache']['getNode']():null;}function Ve(_0x5e781f){return _0x5e781f['serverCache']['isFullyInitialized']()?_0x5e781f['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x27b4c7){let _0x4e6274=new b(null);return x(_0x27b4c7,(_0x1e422d,_0x41a25d)=>{_0x4e6274=_0x4e6274['set'](new C(_0x1e422d),_0x41a25d);}),_0x4e6274;}constructor(_0x12becb,_0x49ac0b=cu()){this['value']=_0x12becb,this['children']=_0x49ac0b;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x52be93,_0xd2f468){if(this['value']!=null&&_0xd2f468(this['value']))return{'path':w(),'value':this['value']};if(v(_0x52be93))return null;{const _0x95d4af=y(_0x52be93),_0x1a6946=this['children']['get'](_0x95d4af);if(_0x1a6946!==null){const _0x277e04=_0x1a6946['findRootMostMatchingPathAndValue'](S(_0x52be93),_0xd2f468);return _0x277e04!=null?{'path':k(new C(_0x95d4af),_0x277e04['path']),'value':_0x277e04['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3c640d){return this['findRootMostMatchingPathAndValue'](_0x3c640d,()=>!0x0);}['subtree'](_0xb8505e){if(v(_0xb8505e))return this;{const _0x5a072f=y(_0xb8505e),_0x4746f7=this['children']['get'](_0x5a072f);return _0x4746f7!==null?_0x4746f7['subtree'](S(_0xb8505e)):new b(null);}}['set'](_0x3c9c,_0x2f2727){if(v(_0x3c9c))return new b(_0x2f2727,this['children']);{const _0x32d472=y(_0x3c9c),_0x532dc8=(this['children']['get'](_0x32d472)||new b(null))['set'](S(_0x3c9c),_0x2f2727),_0x497961=this['children']['insert'](_0x32d472,_0x532dc8);return new b(this['value'],_0x497961);}}['remove'](_0x148fcd){if(v(_0x148fcd))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x75a24f=y(_0x148fcd),_0x3c0356=this['children']['get'](_0x75a24f);if(_0x3c0356){const _0x4ea225=_0x3c0356['remove'](S(_0x148fcd));let _0x35b80c;return _0x4ea225['isEmpty']()?_0x35b80c=this['children']['remove'](_0x75a24f):_0x35b80c=this['children']['insert'](_0x75a24f,_0x4ea225),this['value']===null&&_0x35b80c['isEmpty']()?new b(null):new b(this['value'],_0x35b80c);}else return this;}}['get'](_0x512189){if(v(_0x512189))return this['value'];{const _0x26c149=y(_0x512189),_0x2b9d7d=this['children']['get'](_0x26c149);return _0x2b9d7d?_0x2b9d7d['get'](S(_0x512189)):null;}}['setTree'](_0x487e45,_0x2ef9f1){if(v(_0x487e45))return _0x2ef9f1;{const _0x108a1a=y(_0x487e45),_0x1e621a=(this['children']['get'](_0x108a1a)||new b(null))['setTree'](S(_0x487e45),_0x2ef9f1);let _0xbe8d80;return _0x1e621a['isEmpty']()?_0xbe8d80=this['children']['remove'](_0x108a1a):_0xbe8d80=this['children']['insert'](_0x108a1a,_0x1e621a),new b(this['value'],_0xbe8d80);}}['fold'](_0x3daccf){return this['fold_'](w(),_0x3daccf);}['fold_'](_0x18df72,_0x38e30c){const _0x3d9365={};return this['children']['inorderTraversal']((_0x58bb83,_0x5958f8)=>{_0x3d9365[_0x58bb83]=_0x5958f8['fold_'](k(_0x18df72,_0x58bb83),_0x38e30c);}),_0x38e30c(_0x18df72,this['value'],_0x3d9365);}['findOnPath'](_0x45a99b,_0x55cefe){return this['findOnPath_'](_0x45a99b,w(),_0x55cefe);}['findOnPath_'](_0x1e3cc8,_0x321463,_0x4674c8){const _0x49d4c3=this['value']?_0x4674c8(_0x321463,this['value']):!0x1;if(_0x49d4c3)return _0x49d4c3;if(v(_0x1e3cc8))return null;{const _0x2c69d3=y(_0x1e3cc8),_0x353047=this['children']['get'](_0x2c69d3);return _0x353047?_0x353047['findOnPath_'](S(_0x1e3cc8),k(_0x321463,_0x2c69d3),_0x4674c8):null;}}['foreachOnPath'](_0x14ae21,_0x40ebc1){return this['foreachOnPath_'](_0x14ae21,w(),_0x40ebc1);}['foreachOnPath_'](_0x2ae41d,_0x5137af,_0x58385a){if(v(_0x2ae41d))return this;{this['value']&&_0x58385a(_0x5137af,this['value']);const _0x380413=y(_0x2ae41d),_0x57176d=this['children']['get'](_0x380413);return _0x57176d?_0x57176d['foreachOnPath_'](S(_0x2ae41d),k(_0x5137af,_0x380413),_0x58385a):new b(null);}}['foreach'](_0x25a00c){this['foreach_'](w(),_0x25a00c);}['foreach_'](_0x441c40,_0x3a5add){this['children']['inorderTraversal']((_0x4f76b5,_0x159f51)=>{_0x159f51['foreach_'](k(_0x441c40,_0x4f76b5),_0x3a5add);}),this['value']&&_0x3a5add(_0x441c40,this['value']);}['foreachChild'](_0x539fae){this['children']['inorderTraversal']((_0xe184d,_0x47602a)=>{_0x47602a['value']&&_0x539fae(_0xe184d,_0x47602a['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x316ed0){this['writeTree_']=_0x316ed0;}static['empty'](){return new K(new b(null));}}function At(_0x1be779,_0x34af00,_0x590fd1){if(v(_0x34af00))return new K(new b(_0x590fd1));{const _0x1f7467=_0x1be779['writeTree_']['findRootMostValueAndPath'](_0x34af00);if(_0x1f7467!=null){const _0x1fb7f3=_0x1f7467['path'];let _0x197c79=_0x1f7467['value'];const _0x3550ee=F(_0x1fb7f3,_0x34af00);return _0x197c79=_0x197c79['updateChild'](_0x3550ee,_0x590fd1),new K(_0x1be779['writeTree_']['set'](_0x1fb7f3,_0x197c79));}else{const _0x842150=new b(_0x590fd1),_0x3a20de=_0x1be779['writeTree_']['setTree'](_0x34af00,_0x842150);return new K(_0x3a20de);}}}function bi(_0x4cfd14,_0x1966c3,_0x4b2f5e){let _0x2fd811=_0x4cfd14;return x(_0x4b2f5e,(_0x5ad496,_0x26f82f)=>{_0x2fd811=At(_0x2fd811,k(_0x1966c3,_0x5ad496),_0x26f82f);}),_0x2fd811;}function or(_0x1f0b49,_0x31e034){if(v(_0x31e034))return K['empty']();{const _0x5a5cb9=_0x1f0b49['writeTree_']['setTree'](_0x31e034,new b(null));return new K(_0x5a5cb9);}}function Ri(_0x5cd379,_0x1ac1d0){return ze(_0x5cd379,_0x1ac1d0)!=null;}function ze(_0x24c1f4,_0x2fb053){const _0x4e5084=_0x24c1f4['writeTree_']['findRootMostValueAndPath'](_0x2fb053);return _0x4e5084!=null?_0x24c1f4['writeTree_']['get'](_0x4e5084['path'])['getChild'](F(_0x4e5084['path'],_0x2fb053)):null;}function ar(_0x2c11cd){const _0x30bf90=[],_0x1badf2=_0x2c11cd['writeTree_']['value'];return _0x1badf2!=null?_0x1badf2['isLeafNode']()||_0x1badf2['forEachChild'](R,(_0x2f5661,_0x1b32bb)=>{_0x30bf90['push'](new E(_0x2f5661,_0x1b32bb));}):_0x2c11cd['writeTree_']['children']['inorderTraversal']((_0xbd2fa0,_0xadab37)=>{_0xadab37['value']!=null&&_0x30bf90['push'](new E(_0xbd2fa0,_0xadab37['value']));}),_0x30bf90;}function Ee(_0x431522,_0x56fca3){if(v(_0x56fca3))return _0x431522;{const _0x4062c8=ze(_0x431522,_0x56fca3);return _0x4062c8!=null?new K(new b(_0x4062c8)):new K(_0x431522['writeTree_']['subtree'](_0x56fca3));}}function Ai(_0x39c960){return _0x39c960['writeTree_']['isEmpty']();}function at(_0x13a2a0,_0x2fd55d){return Uo(w(),_0x13a2a0['writeTree_'],_0x2fd55d);}function Uo(_0x2696dc,_0x5c2572,_0x1e54e7){if(_0x5c2572['value']!=null)return _0x1e54e7['updateChild'](_0x2696dc,_0x5c2572['value']);{let _0x2b41c3=null;return _0x5c2572['children']['inorderTraversal']((_0x341082,_0x2a7181)=>{_0x341082==='.priority'?(f(_0x2a7181['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2b41c3=_0x2a7181['value']):_0x1e54e7=Uo(k(_0x2696dc,_0x341082),_0x2a7181,_0x1e54e7);}),!_0x1e54e7['getChild'](_0x2696dc)['isEmpty']()&&_0x2b41c3!==null&&(_0x1e54e7=_0x1e54e7['updateChild'](k(_0x2696dc,'.priority'),_0x2b41c3)),_0x1e54e7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x2ad2b8,_0x5a2059){return Ho(_0x5a2059,_0x2ad2b8);}function lu(_0x32a21f,_0x1f2687,_0x341936,_0x4eadfd,_0x397b01){f(_0x4eadfd>_0x32a21f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x397b01===void 0x0&&(_0x397b01=!0x0),_0x32a21f['allWrites']['push']({'path':_0x1f2687,'snap':_0x341936,'writeId':_0x4eadfd,'visible':_0x397b01}),_0x397b01&&(_0x32a21f['visibleWrites']=At(_0x32a21f['visibleWrites'],_0x1f2687,_0x341936)),_0x32a21f['lastWriteId']=_0x4eadfd;}function hu(_0xec12b4,_0x1f2a9b,_0x3b3eeb,_0x5c2e12){f(_0x5c2e12>_0xec12b4['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xec12b4['allWrites']['push']({'path':_0x1f2a9b,'children':_0x3b3eeb,'writeId':_0x5c2e12,'visible':!0x0}),_0xec12b4['visibleWrites']=bi(_0xec12b4['visibleWrites'],_0x1f2a9b,_0x3b3eeb),_0xec12b4['lastWriteId']=_0x5c2e12;}function uu(_0x30293c,_0x50d190){for(let _0x4c49a5=0x0;_0x4c49a5<_0x30293c['allWrites']['length'];_0x4c49a5++){const _0x3028fa=_0x30293c['allWrites'][_0x4c49a5];if(_0x3028fa['writeId']===_0x50d190)return _0x3028fa;}return null;}function du(_0x231733,_0x4b2013){const _0x5219d7=_0x231733['allWrites']['findIndex'](_0x1c6f72=>_0x1c6f72['writeId']===_0x4b2013);f(_0x5219d7>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x22c512=_0x231733['allWrites'][_0x5219d7];_0x231733['allWrites']['splice'](_0x5219d7,0x1);let _0x160fbd=_0x22c512['visible'],_0x359745=!0x1,_0x5592be=_0x231733['allWrites']['length']-0x1;for(;_0x160fbd&&_0x5592be>=0x0;){const _0x397391=_0x231733['allWrites'][_0x5592be];_0x397391['visible']&&(_0x5592be>=_0x5219d7&&fu(_0x397391,_0x22c512['path'])?_0x160fbd=!0x1:G(_0x22c512['path'],_0x397391['path'])&&(_0x359745=!0x0)),_0x5592be--;}if(_0x160fbd){if(_0x359745)return pu(_0x231733),!0x0;if(_0x22c512['snap'])_0x231733['visibleWrites']=or(_0x231733['visibleWrites'],_0x22c512['path']);else{const _0x329773=_0x22c512['children'];x(_0x329773,_0xeff4c1=>{_0x231733['visibleWrites']=or(_0x231733['visibleWrites'],k(_0x22c512['path'],_0xeff4c1));});}return!0x0;}else return!0x1;}function fu(_0x3cb639,_0x56410f){if(_0x3cb639['snap'])return G(_0x3cb639['path'],_0x56410f);for(const _0x1efe95 in _0x3cb639['children'])if(_0x3cb639['children']['hasOwnProperty'](_0x1efe95)&&G(k(_0x3cb639['path'],_0x1efe95),_0x56410f))return!0x0;return!0x1;}function pu(_0x14e0fb){_0x14e0fb['visibleWrites']=Wo(_0x14e0fb['allWrites'],_u,w()),_0x14e0fb['allWrites']['length']>0x0?_0x14e0fb['lastWriteId']=_0x14e0fb['allWrites'][_0x14e0fb['allWrites']['length']-0x1]['writeId']:_0x14e0fb['lastWriteId']=-0x1;}function _u(_0x12e194){return _0x12e194['visible'];}function Wo(_0x54c3d6,_0x3d8944,_0x3a0e32){let _0x806582=K['empty']();for(let _0x59b766=0x0;_0x59b766<_0x54c3d6['length'];++_0x59b766){const _0x1404f8=_0x54c3d6[_0x59b766];if(_0x3d8944(_0x1404f8)){const _0x413926=_0x1404f8['path'];let _0x2a273a;if(_0x1404f8['snap'])G(_0x3a0e32,_0x413926)?(_0x2a273a=F(_0x3a0e32,_0x413926),_0x806582=At(_0x806582,_0x2a273a,_0x1404f8['snap'])):G(_0x413926,_0x3a0e32)&&(_0x2a273a=F(_0x413926,_0x3a0e32),_0x806582=At(_0x806582,w(),_0x1404f8['snap']['getChild'](_0x2a273a)));else{if(_0x1404f8['children']){if(G(_0x3a0e32,_0x413926))_0x2a273a=F(_0x3a0e32,_0x413926),_0x806582=bi(_0x806582,_0x2a273a,_0x1404f8['children']);else{if(G(_0x413926,_0x3a0e32)){if(_0x2a273a=F(_0x413926,_0x3a0e32),v(_0x2a273a))_0x806582=bi(_0x806582,w(),_0x1404f8['children']);else{const _0x432fda=Le(_0x1404f8['children'],y(_0x2a273a));if(_0x432fda){const _0x4629eb=_0x432fda['getChild'](S(_0x2a273a));_0x806582=At(_0x806582,w(),_0x4629eb);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x806582;}function Bo(_0x24aead,_0x253ecf,_0x1e5e36,_0xce9b53,_0xd4c519){if(!_0xce9b53&&!_0xd4c519){const _0x276c93=ze(_0x24aead['visibleWrites'],_0x253ecf);if(_0x276c93!=null)return _0x276c93;{const _0x1dd93c=Ee(_0x24aead['visibleWrites'],_0x253ecf);if(Ai(_0x1dd93c))return _0x1e5e36;if(_0x1e5e36==null&&!Ri(_0x1dd93c,w()))return null;{const _0x3d2966=_0x1e5e36||g['EMPTY_NODE'];return at(_0x1dd93c,_0x3d2966);}}}else{const _0x1f843a=Ee(_0x24aead['visibleWrites'],_0x253ecf);if(!_0xd4c519&&Ai(_0x1f843a))return _0x1e5e36;if(!_0xd4c519&&_0x1e5e36==null&&!Ri(_0x1f843a,w()))return null;{const _0x355415=function(_0x222713){return(_0x222713['visible']||_0xd4c519)&&(!_0xce9b53||!~_0xce9b53['indexOf'](_0x222713['writeId']))&&(G(_0x222713['path'],_0x253ecf)||G(_0x253ecf,_0x222713['path']));},_0x6307bd=Wo(_0x24aead['allWrites'],_0x355415,_0x253ecf),_0x5eac4b=_0x1e5e36||g['EMPTY_NODE'];return at(_0x6307bd,_0x5eac4b);}}}function gu(_0x283057,_0x55f45c,_0xcfab74){let _0x450e26=g['EMPTY_NODE'];const _0x385244=ze(_0x283057['visibleWrites'],_0x55f45c);if(_0x385244)return _0x385244['isLeafNode']()||_0x385244['forEachChild'](R,(_0x50eafb,_0x23ecb9)=>{_0x450e26=_0x450e26['updateImmediateChild'](_0x50eafb,_0x23ecb9);}),_0x450e26;if(_0xcfab74){const _0x12f707=Ee(_0x283057['visibleWrites'],_0x55f45c);return _0xcfab74['forEachChild'](R,(_0x1736fe,_0x1ef250)=>{const _0x229f6b=at(Ee(_0x12f707,new C(_0x1736fe)),_0x1ef250);_0x450e26=_0x450e26['updateImmediateChild'](_0x1736fe,_0x229f6b);}),ar(_0x12f707)['forEach'](_0x1be010=>{_0x450e26=_0x450e26['updateImmediateChild'](_0x1be010['name'],_0x1be010['node']);}),_0x450e26;}else{const _0x23ab79=Ee(_0x283057['visibleWrites'],_0x55f45c);return ar(_0x23ab79)['forEach'](_0x17bad0=>{_0x450e26=_0x450e26['updateImmediateChild'](_0x17bad0['name'],_0x17bad0['node']);}),_0x450e26;}}function mu(_0x1e2ba0,_0x307e81,_0x2c3435,_0x5b3bce,_0x39ad20){f(_0x5b3bce||_0x39ad20,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x1aa6df=k(_0x307e81,_0x2c3435);if(Ri(_0x1e2ba0['visibleWrites'],_0x1aa6df))return null;{const _0x3a7ed3=Ee(_0x1e2ba0['visibleWrites'],_0x1aa6df);return Ai(_0x3a7ed3)?_0x39ad20['getChild'](_0x2c3435):at(_0x3a7ed3,_0x39ad20['getChild'](_0x2c3435));}}function yu(_0x3d3194,_0x328132,_0xb6a519,_0x57db52){const _0x56f432=k(_0x328132,_0xb6a519),_0x5286a6=ze(_0x3d3194['visibleWrites'],_0x56f432);if(_0x5286a6!=null)return _0x5286a6;if(_0x57db52['isCompleteForChild'](_0xb6a519)){const _0x5c2593=Ee(_0x3d3194['visibleWrites'],_0x56f432);return at(_0x5c2593,_0x57db52['getNode']()['getImmediateChild'](_0xb6a519));}else return null;}function vu(_0x2f5650,_0x1de235){return ze(_0x2f5650['visibleWrites'],_0x1de235);}function Eu(_0x33c2a8,_0x5f2e1b,_0x374ae4,_0x3f3708,_0x43c3d9,_0x187834,_0x3f97cd){let _0x9df12b;const _0x58f1ae=Ee(_0x33c2a8['visibleWrites'],_0x5f2e1b),_0x391b98=ze(_0x58f1ae,w());if(_0x391b98!=null)_0x9df12b=_0x391b98;else{if(_0x374ae4!=null)_0x9df12b=at(_0x58f1ae,_0x374ae4);else return[];}if(_0x9df12b=_0x9df12b['withIndex'](_0x3f97cd),!_0x9df12b['isEmpty']()&&!_0x9df12b['isLeafNode']()){const _0x32e47c=[],_0x1c358a=_0x3f97cd['getCompare'](),_0x3e37c0=_0x187834?_0x9df12b['getReverseIteratorFrom'](_0x3f3708,_0x3f97cd):_0x9df12b['getIteratorFrom'](_0x3f3708,_0x3f97cd);let _0x4faee=_0x3e37c0['getNext']();for(;_0x4faee&&_0x32e47c['length']<_0x43c3d9;)_0x1c358a(_0x4faee,_0x3f3708)!==0x0&&_0x32e47c['push'](_0x4faee),_0x4faee=_0x3e37c0['getNext']();return _0x32e47c;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2d6946,_0x274675,_0x432f8b,_0x51a613){return Bo(_0x2d6946['writeTree'],_0x2d6946['treePath'],_0x274675,_0x432f8b,_0x51a613);}function is(_0xbf342a,_0x24b232){return gu(_0xbf342a['writeTree'],_0xbf342a['treePath'],_0x24b232);}function cr(_0x5cf822,_0x177b21,_0x2b299d,_0x532f22){return mu(_0x5cf822['writeTree'],_0x5cf822['treePath'],_0x177b21,_0x2b299d,_0x532f22);}function Tn(_0x32a7d9,_0x4262d1){return vu(_0x32a7d9['writeTree'],k(_0x32a7d9['treePath'],_0x4262d1));}function wu(_0x2fd1ea,_0x353273,_0x5d2af4,_0x375317,_0x47499d,_0x4e60af){return Eu(_0x2fd1ea['writeTree'],_0x2fd1ea['treePath'],_0x353273,_0x5d2af4,_0x375317,_0x47499d,_0x4e60af);}function ss(_0x1d684f,_0x4adbef,_0x1c5d0f){return yu(_0x1d684f['writeTree'],_0x1d684f['treePath'],_0x4adbef,_0x1c5d0f);}function Vo(_0x59d84f,_0x1b68ff){return Ho(k(_0x59d84f['treePath'],_0x1b68ff),_0x59d84f['writeTree']);}function Ho(_0x3ba60f,_0x4b23c9){return{'treePath':_0x3ba60f,'writeTree':_0x4b23c9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x512fe5){const _0x1a1af0=_0x512fe5['type'],_0x2eb8a7=_0x512fe5['childName'];f(_0x1a1af0==='child_added'||_0x1a1af0==='child_changed'||_0x1a1af0==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2eb8a7!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x39284b=this['changeMap']['get'](_0x2eb8a7);if(_0x39284b){const _0x1c08e3=_0x39284b['type'];if(_0x1a1af0==='child_added'&&_0x1c08e3==='child_removed')this['changeMap']['set'](_0x2eb8a7,xt(_0x2eb8a7,_0x512fe5['snapshotNode'],_0x39284b['snapshotNode']));else{if(_0x1a1af0==='child_removed'&&_0x1c08e3==='child_added')this['changeMap']['delete'](_0x2eb8a7);else{if(_0x1a1af0==='child_removed'&&_0x1c08e3==='child_changed')this['changeMap']['set'](_0x2eb8a7,Lt(_0x2eb8a7,_0x39284b['oldSnap']));else{if(_0x1a1af0==='child_changed'&&_0x1c08e3==='child_added')this['changeMap']['set'](_0x2eb8a7,rt(_0x2eb8a7,_0x512fe5['snapshotNode']));else{if(_0x1a1af0==='child_changed'&&_0x1c08e3==='child_changed')this['changeMap']['set'](_0x2eb8a7,xt(_0x2eb8a7,_0x512fe5['snapshotNode'],_0x39284b['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x512fe5+'\x20occurred\x20after\x20'+_0x39284b);}}}}}else this['changeMap']['set'](_0x2eb8a7,_0x512fe5);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5cbbee){return null;}['getChildAfterChild'](_0x33ea34,_0x25b588,_0x29860e){return null;}}const $o=new Tu();class rs{constructor(_0x38a50d,_0x5e9d5f,_0x3e5f37=null){this['writes_']=_0x38a50d,this['viewCache_']=_0x5e9d5f,this['optCompleteServerCache_']=_0x3e5f37;}['getCompleteChild'](_0x47ec33){const _0x3ca356=this['viewCache_']['eventCache'];if(_0x3ca356['isCompleteForChild'](_0x47ec33))return _0x3ca356['getNode']()['getImmediateChild'](_0x47ec33);{const _0x5101f5=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x47ec33,_0x5101f5);}}['getChildAfterChild'](_0x207433,_0x255ad4,_0x541503){const _0x10a7e6=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x5e3b12=wu(this['writes_'],_0x10a7e6,_0x255ad4,0x1,_0x541503,_0x207433);return _0x5e3b12['length']===0x0?null:_0x5e3b12[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3773e4){return{'filter':_0x3773e4};}function bu(_0x3539e4,_0x1a4399){f(_0x1a4399['eventCache']['getNode']()['isIndexed'](_0x3539e4['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1a4399['serverCache']['getNode']()['isIndexed'](_0x3539e4['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x15b35f,_0x221482,_0x1563b9,_0x177482,_0xbb741f){const _0x4d2b5a=new Cu();let _0x4dc1a3,_0x7c53f3;if(_0x1563b9['type']===z['OVERWRITE']){const _0x1b4dfa=_0x1563b9;_0x1b4dfa['source']['fromUser']?_0x4dc1a3=ki(_0x15b35f,_0x221482,_0x1b4dfa['path'],_0x1b4dfa['snap'],_0x177482,_0xbb741f,_0x4d2b5a):(f(_0x1b4dfa['source']['fromServer'],'Unknown\x20source.'),_0x7c53f3=_0x1b4dfa['source']['tagged']||_0x221482['serverCache']['isFiltered']()&&!v(_0x1b4dfa['path']),_0x4dc1a3=Sn(_0x15b35f,_0x221482,_0x1b4dfa['path'],_0x1b4dfa['snap'],_0x177482,_0xbb741f,_0x7c53f3,_0x4d2b5a));}else{if(_0x1563b9['type']===z['MERGE']){const _0x100430=_0x1563b9;_0x100430['source']['fromUser']?_0x4dc1a3=ku(_0x15b35f,_0x221482,_0x100430['path'],_0x100430['children'],_0x177482,_0xbb741f,_0x4d2b5a):(f(_0x100430['source']['fromServer'],'Unknown\x20source.'),_0x7c53f3=_0x100430['source']['tagged']||_0x221482['serverCache']['isFiltered'](),_0x4dc1a3=Pi(_0x15b35f,_0x221482,_0x100430['path'],_0x100430['children'],_0x177482,_0xbb741f,_0x7c53f3,_0x4d2b5a));}else{if(_0x1563b9['type']===z['ACK_USER_WRITE']){const _0x555bc9=_0x1563b9;_0x555bc9['revert']?_0x4dc1a3=Ou(_0x15b35f,_0x221482,_0x555bc9['path'],_0x177482,_0xbb741f,_0x4d2b5a):_0x4dc1a3=Pu(_0x15b35f,_0x221482,_0x555bc9['path'],_0x555bc9['affectedTree'],_0x177482,_0xbb741f,_0x4d2b5a);}else{if(_0x1563b9['type']===z['LISTEN_COMPLETE'])_0x4dc1a3=Nu(_0x15b35f,_0x221482,_0x1563b9['path'],_0x177482,_0x4d2b5a);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1563b9['type']);}}}const _0x21824b=_0x4d2b5a['getChanges']();return Au(_0x221482,_0x4dc1a3,_0x21824b),{'viewCache':_0x4dc1a3,'changes':_0x21824b};}function Au(_0x596059,_0x55b275,_0x47f630){const _0x59481c=_0x55b275['eventCache'];if(_0x59481c['isFullyInitialized']()){const _0xd3d90c=_0x59481c['getNode']()['isLeafNode']()||_0x59481c['getNode']()['isEmpty'](),_0x317dd2=wn(_0x596059);(_0x47f630['length']>0x0||!_0x596059['eventCache']['isFullyInitialized']()||_0xd3d90c&&!_0x59481c['getNode']()['equals'](_0x317dd2)||!_0x59481c['getNode']()['getPriority']()['equals'](_0x317dd2['getPriority']()))&&_0x47f630['push'](Lo(wn(_0x55b275)));}}function Go(_0x657c44,_0x5c36c2,_0x433a85,_0x4efac1,_0x532296,_0x5a03b0){const _0xe1f5af=_0x5c36c2['eventCache'];if(Tn(_0x4efac1,_0x433a85)!=null)return _0x5c36c2;{let _0x25bfce,_0x19ddc5;if(v(_0x433a85)){if(f(_0x5c36c2['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5c36c2['serverCache']['isFiltered']()){const _0x266de1=Ve(_0x5c36c2),_0x1690d3=_0x266de1 instanceof g?_0x266de1:g['EMPTY_NODE'],_0x3ae533=is(_0x4efac1,_0x1690d3);_0x25bfce=_0x657c44['filter']['updateFullNode'](_0x5c36c2['eventCache']['getNode'](),_0x3ae533,_0x5a03b0);}else{const _0x4ca70c=Cn(_0x4efac1,Ve(_0x5c36c2));_0x25bfce=_0x657c44['filter']['updateFullNode'](_0x5c36c2['eventCache']['getNode'](),_0x4ca70c,_0x5a03b0);}}else{const _0x480143=y(_0x433a85);if(_0x480143==='.priority'){f(Ce(_0x433a85)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2da130=_0xe1f5af['getNode']();_0x19ddc5=_0x5c36c2['serverCache']['getNode']();const _0x3e8f09=cr(_0x4efac1,_0x433a85,_0x2da130,_0x19ddc5);_0x3e8f09!=null?_0x25bfce=_0x657c44['filter']['updatePriority'](_0x2da130,_0x3e8f09):_0x25bfce=_0xe1f5af['getNode']();}else{const _0x176e66=S(_0x433a85);let _0x105f30;if(_0xe1f5af['isCompleteForChild'](_0x480143)){_0x19ddc5=_0x5c36c2['serverCache']['getNode']();const _0xffc331=cr(_0x4efac1,_0x433a85,_0xe1f5af['getNode'](),_0x19ddc5);_0xffc331!=null?_0x105f30=_0xe1f5af['getNode']()['getImmediateChild'](_0x480143)['updateChild'](_0x176e66,_0xffc331):_0x105f30=_0xe1f5af['getNode']()['getImmediateChild'](_0x480143);}else _0x105f30=ss(_0x4efac1,_0x480143,_0x5c36c2['serverCache']);_0x105f30!=null?_0x25bfce=_0x657c44['filter']['updateChild'](_0xe1f5af['getNode'](),_0x480143,_0x105f30,_0x176e66,_0x532296,_0x5a03b0):_0x25bfce=_0xe1f5af['getNode']();}}return Rt(_0x5c36c2,_0x25bfce,_0xe1f5af['isFullyInitialized']()||v(_0x433a85),_0x657c44['filter']['filtersNodes']());}}function Sn(_0x199a6a,_0xf563fd,_0x27d65a,_0x516718,_0x2a734c,_0x55ded2,_0xe934c4,_0xe11d53){const _0x4c9552=_0xf563fd['serverCache'];let _0x256e79;const _0x5757ef=_0xe934c4?_0x199a6a['filter']:_0x199a6a['filter']['getIndexedFilter']();if(v(_0x27d65a))_0x256e79=_0x5757ef['updateFullNode'](_0x4c9552['getNode'](),_0x516718,null);else{if(_0x5757ef['filtersNodes']()&&!_0x4c9552['isFiltered']()){const _0x565fec=_0x4c9552['getNode']()['updateChild'](_0x27d65a,_0x516718);_0x256e79=_0x5757ef['updateFullNode'](_0x4c9552['getNode'](),_0x565fec,null);}else{const _0x527046=y(_0x27d65a);if(!_0x4c9552['isCompleteForPath'](_0x27d65a)&&Ce(_0x27d65a)>0x1)return _0xf563fd;const _0xc70188=S(_0x27d65a),_0x11a5f5=_0x4c9552['getNode']()['getImmediateChild'](_0x527046)['updateChild'](_0xc70188,_0x516718);_0x527046==='.priority'?_0x256e79=_0x5757ef['updatePriority'](_0x4c9552['getNode'](),_0x11a5f5):_0x256e79=_0x5757ef['updateChild'](_0x4c9552['getNode'](),_0x527046,_0x11a5f5,_0xc70188,$o,null);}}const _0x5cc7fd=Fo(_0xf563fd,_0x256e79,_0x4c9552['isFullyInitialized']()||v(_0x27d65a),_0x5757ef['filtersNodes']()),_0x46fcaa=new rs(_0x2a734c,_0x5cc7fd,_0x55ded2);return Go(_0x199a6a,_0x5cc7fd,_0x27d65a,_0x2a734c,_0x46fcaa,_0xe11d53);}function ki(_0x21fc4a,_0x2511e2,_0x19289b,_0x56478c,_0xbbf9e2,_0x10805e,_0x8baa97){const _0x337203=_0x2511e2['eventCache'];let _0x51b7b5,_0x108411;const _0x5da3a4=new rs(_0xbbf9e2,_0x2511e2,_0x10805e);if(v(_0x19289b))_0x108411=_0x21fc4a['filter']['updateFullNode'](_0x2511e2['eventCache']['getNode'](),_0x56478c,_0x8baa97),_0x51b7b5=Rt(_0x2511e2,_0x108411,!0x0,_0x21fc4a['filter']['filtersNodes']());else{const _0x20c86e=y(_0x19289b);if(_0x20c86e==='.priority')_0x108411=_0x21fc4a['filter']['updatePriority'](_0x2511e2['eventCache']['getNode'](),_0x56478c),_0x51b7b5=Rt(_0x2511e2,_0x108411,_0x337203['isFullyInitialized'](),_0x337203['isFiltered']());else{const _0x52b4fb=S(_0x19289b),_0xb5488e=_0x337203['getNode']()['getImmediateChild'](_0x20c86e);let _0x2a845e;if(v(_0x52b4fb))_0x2a845e=_0x56478c;else{const _0x2478b6=_0x5da3a4['getCompleteChild'](_0x20c86e);_0x2478b6!=null?ji(_0x52b4fb)==='.priority'&&_0x2478b6['getChild'](Ro(_0x52b4fb))['isEmpty']()?_0x2a845e=_0x2478b6:_0x2a845e=_0x2478b6['updateChild'](_0x52b4fb,_0x56478c):_0x2a845e=g['EMPTY_NODE'];}if(_0xb5488e['equals'](_0x2a845e))_0x51b7b5=_0x2511e2;else{const _0x3f3ebb=_0x21fc4a['filter']['updateChild'](_0x337203['getNode'](),_0x20c86e,_0x2a845e,_0x52b4fb,_0x5da3a4,_0x8baa97);_0x51b7b5=Rt(_0x2511e2,_0x3f3ebb,_0x337203['isFullyInitialized'](),_0x21fc4a['filter']['filtersNodes']());}}}return _0x51b7b5;}function lr(_0x3dde9d,_0x35145c){return _0x3dde9d['eventCache']['isCompleteForChild'](_0x35145c);}function ku(_0x1da820,_0x2f1855,_0x2d0d71,_0x25211a,_0x38c708,_0x5d25bf,_0x4fc45c){let _0x21d8cd=_0x2f1855;return _0x25211a['foreach']((_0x1b5a27,_0x4a26d8)=>{const _0x2c5d56=k(_0x2d0d71,_0x1b5a27);lr(_0x2f1855,y(_0x2c5d56))&&(_0x21d8cd=ki(_0x1da820,_0x21d8cd,_0x2c5d56,_0x4a26d8,_0x38c708,_0x5d25bf,_0x4fc45c));}),_0x25211a['foreach']((_0x2e1f84,_0x35383f)=>{const _0x40d914=k(_0x2d0d71,_0x2e1f84);lr(_0x2f1855,y(_0x40d914))||(_0x21d8cd=ki(_0x1da820,_0x21d8cd,_0x40d914,_0x35383f,_0x38c708,_0x5d25bf,_0x4fc45c));}),_0x21d8cd;}function hr(_0x4c2b3d,_0x28f050,_0xe23f86){return _0xe23f86['foreach']((_0x8211c4,_0x484a47)=>{_0x28f050=_0x28f050['updateChild'](_0x8211c4,_0x484a47);}),_0x28f050;}function Pi(_0x564a67,_0x116fc1,_0x36d3dc,_0x42bfa9,_0x12dc4c,_0x40ff2d,_0x23f62e,_0x63829f){if(_0x116fc1['serverCache']['getNode']()['isEmpty']()&&!_0x116fc1['serverCache']['isFullyInitialized']())return _0x116fc1;let _0x507270=_0x116fc1,_0x4e0de6;v(_0x36d3dc)?_0x4e0de6=_0x42bfa9:_0x4e0de6=new b(null)['setTree'](_0x36d3dc,_0x42bfa9);const _0x35910f=_0x116fc1['serverCache']['getNode']();return _0x4e0de6['children']['inorderTraversal']((_0x1bfe7e,_0x3c3341)=>{if(_0x35910f['hasChild'](_0x1bfe7e)){const _0x349579=_0x116fc1['serverCache']['getNode']()['getImmediateChild'](_0x1bfe7e),_0x4605c7=hr(_0x564a67,_0x349579,_0x3c3341);_0x507270=Sn(_0x564a67,_0x507270,new C(_0x1bfe7e),_0x4605c7,_0x12dc4c,_0x40ff2d,_0x23f62e,_0x63829f);}}),_0x4e0de6['children']['inorderTraversal']((_0x2d5612,_0x51f762)=>{const _0x22d72c=!_0x116fc1['serverCache']['isCompleteForChild'](_0x2d5612)&&_0x51f762['value']===null;if(!_0x35910f['hasChild'](_0x2d5612)&&!_0x22d72c){const _0x4ded1a=_0x116fc1['serverCache']['getNode']()['getImmediateChild'](_0x2d5612),_0x1007b8=hr(_0x564a67,_0x4ded1a,_0x51f762);_0x507270=Sn(_0x564a67,_0x507270,new C(_0x2d5612),_0x1007b8,_0x12dc4c,_0x40ff2d,_0x23f62e,_0x63829f);}}),_0x507270;}function Pu(_0x4ef7dd,_0x4b12fb,_0x575fba,_0x252728,_0x15e200,_0x4f5e87,_0x25f0cf){if(Tn(_0x15e200,_0x575fba)!=null)return _0x4b12fb;const _0x203c85=_0x4b12fb['serverCache']['isFiltered'](),_0x2ddba3=_0x4b12fb['serverCache'];if(_0x252728['value']!=null){if(v(_0x575fba)&&_0x2ddba3['isFullyInitialized']()||_0x2ddba3['isCompleteForPath'](_0x575fba))return Sn(_0x4ef7dd,_0x4b12fb,_0x575fba,_0x2ddba3['getNode']()['getChild'](_0x575fba),_0x15e200,_0x4f5e87,_0x203c85,_0x25f0cf);if(v(_0x575fba)){let _0x21406e=new b(null);return _0x2ddba3['getNode']()['forEachChild'](ve,(_0xd7a1f3,_0x490524)=>{_0x21406e=_0x21406e['set'](new C(_0xd7a1f3),_0x490524);}),Pi(_0x4ef7dd,_0x4b12fb,_0x575fba,_0x21406e,_0x15e200,_0x4f5e87,_0x203c85,_0x25f0cf);}else return _0x4b12fb;}else{let _0x584f9c=new b(null);return _0x252728['foreach']((_0x3d0965,_0x39e84c)=>{const _0x12dd32=k(_0x575fba,_0x3d0965);_0x2ddba3['isCompleteForPath'](_0x12dd32)&&(_0x584f9c=_0x584f9c['set'](_0x3d0965,_0x2ddba3['getNode']()['getChild'](_0x12dd32)));}),Pi(_0x4ef7dd,_0x4b12fb,_0x575fba,_0x584f9c,_0x15e200,_0x4f5e87,_0x203c85,_0x25f0cf);}}function Nu(_0xd79952,_0x1729cb,_0x9db02,_0x4a2872,_0x1030f4){const _0x376ff0=_0x1729cb['serverCache'],_0x3007ed=Fo(_0x1729cb,_0x376ff0['getNode'](),_0x376ff0['isFullyInitialized']()||v(_0x9db02),_0x376ff0['isFiltered']());return Go(_0xd79952,_0x3007ed,_0x9db02,_0x4a2872,$o,_0x1030f4);}function Ou(_0x2061cf,_0x17aae6,_0x36fb0d,_0x484971,_0x20ca92,_0x55dc4f){let _0x117506;if(Tn(_0x484971,_0x36fb0d)!=null)return _0x17aae6;{const _0x199c33=new rs(_0x484971,_0x17aae6,_0x20ca92),_0x2bd89f=_0x17aae6['eventCache']['getNode']();let _0x40cd7f;if(v(_0x36fb0d)||y(_0x36fb0d)==='.priority'){let _0x3c0f1f;if(_0x17aae6['serverCache']['isFullyInitialized']())_0x3c0f1f=Cn(_0x484971,Ve(_0x17aae6));else{const _0xc864e9=_0x17aae6['serverCache']['getNode']();f(_0xc864e9 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3c0f1f=is(_0x484971,_0xc864e9);}_0x3c0f1f=_0x3c0f1f,_0x40cd7f=_0x2061cf['filter']['updateFullNode'](_0x2bd89f,_0x3c0f1f,_0x55dc4f);}else{const _0x4aa97e=y(_0x36fb0d);let _0x1ca5d9=ss(_0x484971,_0x4aa97e,_0x17aae6['serverCache']);_0x1ca5d9==null&&_0x17aae6['serverCache']['isCompleteForChild'](_0x4aa97e)&&(_0x1ca5d9=_0x2bd89f['getImmediateChild'](_0x4aa97e)),_0x1ca5d9!=null?_0x40cd7f=_0x2061cf['filter']['updateChild'](_0x2bd89f,_0x4aa97e,_0x1ca5d9,S(_0x36fb0d),_0x199c33,_0x55dc4f):_0x17aae6['eventCache']['getNode']()['hasChild'](_0x4aa97e)?_0x40cd7f=_0x2061cf['filter']['updateChild'](_0x2bd89f,_0x4aa97e,g['EMPTY_NODE'],S(_0x36fb0d),_0x199c33,_0x55dc4f):_0x40cd7f=_0x2bd89f,_0x40cd7f['isEmpty']()&&_0x17aae6['serverCache']['isFullyInitialized']()&&(_0x117506=Cn(_0x484971,Ve(_0x17aae6)),_0x117506['isLeafNode']()&&(_0x40cd7f=_0x2061cf['filter']['updateFullNode'](_0x40cd7f,_0x117506,_0x55dc4f)));}return _0x117506=_0x17aae6['serverCache']['isFullyInitialized']()||Tn(_0x484971,w())!=null,Rt(_0x17aae6,_0x40cd7f,_0x117506,_0x2061cf['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x596dbf,_0x4412b6){this['query_']=_0x596dbf,this['eventRegistrations_']=[];const _0x5530ec=this['query_']['_queryParams'],_0x153889=new Xi(_0x5530ec['getIndex']()),_0x5f2cd2=Kh(_0x5530ec);this['processor_']=Su(_0x5f2cd2);const _0x194705=_0x4412b6['serverCache'],_0x145a93=_0x4412b6['eventCache'],_0x5abd55=_0x153889['updateFullNode'](g['EMPTY_NODE'],_0x194705['getNode'](),null),_0x3ebf59=_0x5f2cd2['updateFullNode'](g['EMPTY_NODE'],_0x145a93['getNode'](),null),_0x5aa5c8=new Te(_0x5abd55,_0x194705['isFullyInitialized'](),_0x153889['filtersNodes']()),_0x50e6d7=new Te(_0x3ebf59,_0x145a93['isFullyInitialized'](),_0x5f2cd2['filtersNodes']());this['viewCache_']=Un(_0x50e6d7,_0x5aa5c8),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x3e46be){return _0x3e46be['viewCache_']['serverCache']['getNode']();}function Lu(_0x547f57){return wn(_0x547f57['viewCache_']);}function xu(_0x503dfe,_0xb22048){const _0x9afcfd=Ve(_0x503dfe['viewCache_']);return _0x9afcfd&&(_0x503dfe['query']['_queryParams']['loadsAllData']()||!v(_0xb22048)&&!_0x9afcfd['getImmediateChild'](y(_0xb22048))['isEmpty']())?_0x9afcfd['getChild'](_0xb22048):null;}function ur(_0xdac922){return _0xdac922['eventRegistrations_']['length']===0x0;}function Fu(_0x148ee1,_0x201292){_0x148ee1['eventRegistrations_']['push'](_0x201292);}function dr(_0x3277a9,_0xb662b8,_0x347bfc){const _0x20bf46=[];if(_0x347bfc){f(_0xb662b8==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x486779=_0x3277a9['query']['_path'];_0x3277a9['eventRegistrations_']['forEach'](_0x392779=>{const _0x117b71=_0x392779['createCancelEvent'](_0x347bfc,_0x486779);_0x117b71&&_0x20bf46['push'](_0x117b71);});}if(_0xb662b8){let _0x49cd4c=[];for(let _0x2fc8b2=0x0;_0x2fc8b2<_0x3277a9['eventRegistrations_']['length'];++_0x2fc8b2){const _0xafe128=_0x3277a9['eventRegistrations_'][_0x2fc8b2];if(!_0xafe128['matches'](_0xb662b8))_0x49cd4c['push'](_0xafe128);else{if(_0xb662b8['hasAnyCallback']()){_0x49cd4c=_0x49cd4c['concat'](_0x3277a9['eventRegistrations_']['slice'](_0x2fc8b2+0x1));break;}}}_0x3277a9['eventRegistrations_']=_0x49cd4c;}else _0x3277a9['eventRegistrations_']=[];return _0x20bf46;}function fr(_0x53ec85,_0x22af92,_0x350212,_0x251986){_0x22af92['type']===z['MERGE']&&_0x22af92['source']['queryId']!==null&&(f(Ve(_0x53ec85['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x53ec85['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x29be3b=_0x53ec85['viewCache_'],_0x247f8e=Ru(_0x53ec85['processor_'],_0x29be3b,_0x22af92,_0x350212,_0x251986);return bu(_0x53ec85['processor_'],_0x247f8e['viewCache']),f(_0x247f8e['viewCache']['serverCache']['isFullyInitialized']()||!_0x29be3b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x53ec85['viewCache_']=_0x247f8e['viewCache'],qo(_0x53ec85,_0x247f8e['changes'],_0x247f8e['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x491887,_0x2e8da5){const _0x113e11=_0x491887['viewCache_']['eventCache'],_0x179492=[];return _0x113e11['getNode']()['isLeafNode']()||_0x113e11['getNode']()['forEachChild'](R,(_0x27f848,_0x4c7e5c)=>{_0x179492['push'](rt(_0x27f848,_0x4c7e5c));}),_0x113e11['isFullyInitialized']()&&_0x179492['push'](Lo(_0x113e11['getNode']())),qo(_0x491887,_0x179492,_0x113e11['getNode'](),_0x2e8da5);}function qo(_0xe4343d,_0x1f7946,_0x2890a4,_0x1d9eac){const _0x4eec13=_0x1d9eac?[_0x1d9eac]:_0xe4343d['eventRegistrations_'];return ru(_0xe4343d['eventGenerator_'],_0x1f7946,_0x2890a4,_0x4eec13);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x57df30){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x57df30;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0xb591e4){return _0xb591e4['views']['size']===0x0;}function os(_0x4d0090,_0x59b865,_0x384a00,_0x30eea0){const _0xe34d2b=_0x59b865['source']['queryId'];if(_0xe34d2b!==null){const _0x4913d5=_0x4d0090['views']['get'](_0xe34d2b);return f(_0x4913d5!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x4913d5,_0x59b865,_0x384a00,_0x30eea0);}else{let _0x42e3e4=[];for(const _0xb94982 of _0x4d0090['views']['values']())_0x42e3e4=_0x42e3e4['concat'](fr(_0xb94982,_0x59b865,_0x384a00,_0x30eea0));return _0x42e3e4;}}function jo(_0x56cd95,_0x48c50f,_0x368f3c,_0x2de757,_0xbf9abc){const _0x578792=_0x48c50f['_queryIdentifier'],_0xfbd31b=_0x56cd95['views']['get'](_0x578792);if(!_0xfbd31b){let _0x54b40f=Cn(_0x368f3c,_0xbf9abc?_0x2de757:null),_0x265349=!0x1;_0x54b40f?_0x265349=!0x0:_0x2de757 instanceof g?(_0x54b40f=is(_0x368f3c,_0x2de757),_0x265349=!0x1):(_0x54b40f=g['EMPTY_NODE'],_0x265349=!0x1);const _0x31fb01=Un(new Te(_0x54b40f,_0x265349,!0x1),new Te(_0x2de757,_0xbf9abc,!0x1));return new Du(_0x48c50f,_0x31fb01);}return _0xfbd31b;}function Hu(_0x25d31a,_0x49780e,_0x50fce2,_0x5a140b,_0x3de3e2,_0x161959){const _0x10d680=jo(_0x25d31a,_0x49780e,_0x5a140b,_0x3de3e2,_0x161959);return _0x25d31a['views']['has'](_0x49780e['_queryIdentifier'])||_0x25d31a['views']['set'](_0x49780e['_queryIdentifier'],_0x10d680),Fu(_0x10d680,_0x50fce2),Uu(_0x10d680,_0x50fce2);}function $u(_0x2ee05a,_0x298d4a,_0x24ef10,_0x460fc1){const _0x197e1f=_0x298d4a['_queryIdentifier'],_0x327bf2=[];let _0x2de893=[];const _0x5a838b=Se(_0x2ee05a);if(_0x197e1f==='default'){for(const [_0x472ee7,_0x54af53]of _0x2ee05a['views']['entries']())_0x2de893=_0x2de893['concat'](dr(_0x54af53,_0x24ef10,_0x460fc1)),ur(_0x54af53)&&(_0x2ee05a['views']['delete'](_0x472ee7),_0x54af53['query']['_queryParams']['loadsAllData']()||_0x327bf2['push'](_0x54af53['query']));}else{const _0x19a8f8=_0x2ee05a['views']['get'](_0x197e1f);_0x19a8f8&&(_0x2de893=_0x2de893['concat'](dr(_0x19a8f8,_0x24ef10,_0x460fc1)),ur(_0x19a8f8)&&(_0x2ee05a['views']['delete'](_0x197e1f),_0x19a8f8['query']['_queryParams']['loadsAllData']()||_0x327bf2['push'](_0x19a8f8['query'])));}return _0x5a838b&&!Se(_0x2ee05a)&&_0x327bf2['push'](new(Bu())(_0x298d4a['_repo'],_0x298d4a['_path'])),{'removed':_0x327bf2,'events':_0x2de893};}function Ko(_0x50923c){const _0x4fd8e7=[];for(const _0xdad65e of _0x50923c['views']['values']())_0xdad65e['query']['_queryParams']['loadsAllData']()||_0x4fd8e7['push'](_0xdad65e);return _0x4fd8e7;}function Ie(_0x380a6b,_0x2a9372){let _0x4a5bfc=null;for(const _0x4c1521 of _0x380a6b['views']['values']())_0x4a5bfc=_0x4a5bfc||xu(_0x4c1521,_0x2a9372);return _0x4a5bfc;}function Yo(_0x54d6b7,_0x162011){if(_0x162011['_queryParams']['loadsAllData']())return Bn(_0x54d6b7);{const _0x4608cb=_0x162011['_queryIdentifier'];return _0x54d6b7['views']['get'](_0x4608cb);}}function Qo(_0x1d6126,_0x56bc8a){return Yo(_0x1d6126,_0x56bc8a)!=null;}function Se(_0x5568b2){return Bn(_0x5568b2)!=null;}function Bn(_0x413c5b){for(const _0x1017f3 of _0x413c5b['views']['values']())if(_0x1017f3['query']['_queryParams']['loadsAllData']())return _0x1017f3;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2ec304){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2ec304;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x5bd056){this['listenProvider_']=_0x5bd056,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x5706f3,_0x5de24a,_0x14bb93,_0x8c698e,_0x4e56ae){return lu(_0x5706f3['pendingWriteTree_'],_0x5de24a,_0x14bb93,_0x8c698e,_0x4e56ae),_0x4e56ae?_t(_0x5706f3,new Be(es(),_0x5de24a,_0x14bb93)):[];}function ju(_0x56942e,_0x39a028,_0x4dbba5,_0x2bad50){hu(_0x56942e['pendingWriteTree_'],_0x39a028,_0x4dbba5,_0x2bad50);const _0x5c694f=b['fromObject'](_0x4dbba5);return _t(_0x56942e,new ot(es(),_0x39a028,_0x5c694f));}function _e(_0x176b5d,_0x5f3769,_0x5b101b=!0x1){const _0x170a64=uu(_0x176b5d['pendingWriteTree_'],_0x5f3769);if(du(_0x176b5d['pendingWriteTree_'],_0x5f3769)){let _0x4cf131=new b(null);return _0x170a64['snap']!=null?_0x4cf131=_0x4cf131['set'](w(),!0x0):x(_0x170a64['children'],_0x396443=>{_0x4cf131=_0x4cf131['set'](new C(_0x396443),!0x0);}),_t(_0x176b5d,new In(_0x170a64['path'],_0x4cf131,_0x5b101b));}else return[];}function Yt(_0x260ef6,_0x480679,_0x2cb91d){return _t(_0x260ef6,new Be(ts(),_0x480679,_0x2cb91d));}function Ku(_0x1ba5a6,_0x283ac9,_0x49667b){const _0x41dd56=b['fromObject'](_0x49667b);return _t(_0x1ba5a6,new ot(ts(),_0x283ac9,_0x41dd56));}function Yu(_0x4b4bf4,_0x2e319b){return _t(_0x4b4bf4,new Ut(ts(),_0x2e319b));}function Qu(_0x37497a,_0x1235f7,_0x4c68e0){const _0x55ec35=cs(_0x37497a,_0x4c68e0);if(_0x55ec35){const _0xcf3ec2=ls(_0x55ec35),_0x52d18c=_0xcf3ec2['path'],_0x580152=_0xcf3ec2['queryId'],_0x4d7b61=F(_0x52d18c,_0x1235f7),_0x42a745=new Ut(ns(_0x580152),_0x4d7b61);return hs(_0x37497a,_0x52d18c,_0x42a745);}else return[];}function An(_0x18c834,_0x161912,_0x7de73d,_0x1dbeae,_0x545d66=!0x1){const _0x59539c=_0x161912['_path'],_0x5900d5=_0x18c834['syncPointTree_']['get'](_0x59539c);let _0x4af24d=[];if(_0x5900d5&&(_0x161912['_queryIdentifier']==='default'||Qo(_0x5900d5,_0x161912))){const _0x27fa53=$u(_0x5900d5,_0x161912,_0x7de73d,_0x1dbeae);Vu(_0x5900d5)&&(_0x18c834['syncPointTree_']=_0x18c834['syncPointTree_']['remove'](_0x59539c));const _0x32b6ba=_0x27fa53['removed'];if(_0x4af24d=_0x27fa53['events'],!_0x545d66){const _0x93817a=_0x32b6ba['findIndex'](_0x245c9f=>_0x245c9f['_queryParams']['loadsAllData']())!==-0x1,_0x4ddb13=_0x18c834['syncPointTree_']['findOnPath'](_0x59539c,(_0xcc6623,_0x5cffe1)=>Se(_0x5cffe1));if(_0x93817a&&!_0x4ddb13){const _0xc5fe24=_0x18c834['syncPointTree_']['subtree'](_0x59539c);if(!_0xc5fe24['isEmpty']()){const _0x115729=Zu(_0xc5fe24);for(let _0x26774b=0x0;_0x26774b<_0x115729['length'];++_0x26774b){const _0x1634ce=_0x115729[_0x26774b],_0x2a450d=_0x1634ce['query'],_0x1a9876=ea(_0x18c834,_0x1634ce);_0x18c834['listenProvider_']['startListening'](kt(_0x2a450d),Wt(_0x18c834,_0x2a450d),_0x1a9876['hashFn'],_0x1a9876['onComplete']);}}}!_0x4ddb13&&_0x32b6ba['length']>0x0&&!_0x1dbeae&&(_0x93817a?_0x18c834['listenProvider_']['stopListening'](kt(_0x161912),null):_0x32b6ba['forEach'](_0x316fe0=>{const _0x42d37f=_0x18c834['queryToTagMap']['get'](Hn(_0x316fe0));_0x18c834['listenProvider_']['stopListening'](kt(_0x316fe0),_0x42d37f);}));}ed(_0x18c834,_0x32b6ba);}return _0x4af24d;}function Jo(_0x5e97bf,_0x511fe0,_0x5e3981,_0x32edc1){const _0x8d3d8a=cs(_0x5e97bf,_0x32edc1);if(_0x8d3d8a!=null){const _0x5b5891=ls(_0x8d3d8a),_0x5db7af=_0x5b5891['path'],_0x27e63a=_0x5b5891['queryId'],_0x198303=F(_0x5db7af,_0x511fe0),_0x16c087=new Be(ns(_0x27e63a),_0x198303,_0x5e3981);return hs(_0x5e97bf,_0x5db7af,_0x16c087);}else return[];}function Ju(_0x214bba,_0x454b51,_0xe84130,_0x2a7f27){const _0x4d6b4a=cs(_0x214bba,_0x2a7f27);if(_0x4d6b4a){const _0x57268e=ls(_0x4d6b4a),_0x2aca52=_0x57268e['path'],_0x2ceafb=_0x57268e['queryId'],_0x1cc84d=F(_0x2aca52,_0x454b51),_0x3f420f=b['fromObject'](_0xe84130),_0x2e6d81=new ot(ns(_0x2ceafb),_0x1cc84d,_0x3f420f);return hs(_0x214bba,_0x2aca52,_0x2e6d81);}else return[];}function Ni(_0x291a51,_0x3f1e34,_0x496f9a,_0x402238=!0x1){const _0x33152e=_0x3f1e34['_path'];let _0x4c5513=null,_0x358c76=!0x1;_0x291a51['syncPointTree_']['foreachOnPath'](_0x33152e,(_0x31b3ce,_0x55d753)=>{const _0xbde3fc=F(_0x31b3ce,_0x33152e);_0x4c5513=_0x4c5513||Ie(_0x55d753,_0xbde3fc),_0x358c76=_0x358c76||Se(_0x55d753);});let _0x148b43=_0x291a51['syncPointTree_']['get'](_0x33152e);_0x148b43?(_0x358c76=_0x358c76||Se(_0x148b43),_0x4c5513=_0x4c5513||Ie(_0x148b43,w())):(_0x148b43=new zo(),_0x291a51['syncPointTree_']=_0x291a51['syncPointTree_']['set'](_0x33152e,_0x148b43));let _0x1374aa;_0x4c5513!=null?_0x1374aa=!0x0:(_0x1374aa=!0x1,_0x4c5513=g['EMPTY_NODE'],_0x291a51['syncPointTree_']['subtree'](_0x33152e)['foreachChild']((_0x2eb597,_0x56e55f)=>{const _0x41d031=Ie(_0x56e55f,w());_0x41d031&&(_0x4c5513=_0x4c5513['updateImmediateChild'](_0x2eb597,_0x41d031));}));const _0xbc00ba=Qo(_0x148b43,_0x3f1e34);if(!_0xbc00ba&&!_0x3f1e34['_queryParams']['loadsAllData']()){const _0x12f82c=Hn(_0x3f1e34);f(!_0x291a51['queryToTagMap']['has'](_0x12f82c),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x334331=td();_0x291a51['queryToTagMap']['set'](_0x12f82c,_0x334331),_0x291a51['tagToQueryMap']['set'](_0x334331,_0x12f82c);}const _0x1c1f5e=Wn(_0x291a51['pendingWriteTree_'],_0x33152e);let _0x2de673=Hu(_0x148b43,_0x3f1e34,_0x496f9a,_0x1c1f5e,_0x4c5513,_0x1374aa);if(!_0xbc00ba&&!_0x358c76&&!_0x402238){const _0x584ad3=Yo(_0x148b43,_0x3f1e34);_0x2de673=_0x2de673['concat'](nd(_0x291a51,_0x3f1e34,_0x584ad3));}return _0x2de673;}function Vn(_0x476d2b,_0x1e5b36,_0xad5aa3){const _0x1cf25b=_0x476d2b['pendingWriteTree_'],_0x589113=_0x476d2b['syncPointTree_']['findOnPath'](_0x1e5b36,(_0x4b77d9,_0x1a37b0)=>{const _0x5bbef2=F(_0x4b77d9,_0x1e5b36),_0x2d0ea1=Ie(_0x1a37b0,_0x5bbef2);if(_0x2d0ea1)return _0x2d0ea1;});return Bo(_0x1cf25b,_0x1e5b36,_0x589113,_0xad5aa3,!0x0);}function Xu(_0x66cfa4,_0xb76ea5){const _0x510849=_0xb76ea5['_path'];let _0x237b83=null;_0x66cfa4['syncPointTree_']['foreachOnPath'](_0x510849,(_0x51a97c,_0x2a0686)=>{const _0x2d33c5=F(_0x51a97c,_0x510849);_0x237b83=_0x237b83||Ie(_0x2a0686,_0x2d33c5);});let _0x3efc73=_0x66cfa4['syncPointTree_']['get'](_0x510849);_0x3efc73?_0x237b83=_0x237b83||Ie(_0x3efc73,w()):(_0x3efc73=new zo(),_0x66cfa4['syncPointTree_']=_0x66cfa4['syncPointTree_']['set'](_0x510849,_0x3efc73));const _0x15d3bb=_0x237b83!=null,_0x2aadf1=_0x15d3bb?new Te(_0x237b83,!0x0,!0x1):null,_0x2f6fa5=Wn(_0x66cfa4['pendingWriteTree_'],_0xb76ea5['_path']),_0x4defab=jo(_0x3efc73,_0xb76ea5,_0x2f6fa5,_0x15d3bb?_0x2aadf1['getNode']():g['EMPTY_NODE'],_0x15d3bb);return Lu(_0x4defab);}function _t(_0x44c387,_0x43b78c){return Xo(_0x43b78c,_0x44c387['syncPointTree_'],null,Wn(_0x44c387['pendingWriteTree_'],w()));}function Xo(_0x40e6e0,_0x4345cd,_0x1f00c9,_0x4a425b){if(v(_0x40e6e0['path']))return Zo(_0x40e6e0,_0x4345cd,_0x1f00c9,_0x4a425b);{const _0xb6b17=_0x4345cd['get'](w());_0x1f00c9==null&&_0xb6b17!=null&&(_0x1f00c9=Ie(_0xb6b17,w()));let _0x280a26=[];const _0x437651=y(_0x40e6e0['path']),_0x346b90=_0x40e6e0['operationForChild'](_0x437651),_0xee9d65=_0x4345cd['children']['get'](_0x437651);if(_0xee9d65&&_0x346b90){const _0x3a7d26=_0x1f00c9?_0x1f00c9['getImmediateChild'](_0x437651):null,_0x1ba87e=Vo(_0x4a425b,_0x437651);_0x280a26=_0x280a26['concat'](Xo(_0x346b90,_0xee9d65,_0x3a7d26,_0x1ba87e));}return _0xb6b17&&(_0x280a26=_0x280a26['concat'](os(_0xb6b17,_0x40e6e0,_0x4a425b,_0x1f00c9))),_0x280a26;}}function Zo(_0x4a26b3,_0xeb55a5,_0x5d7608,_0x306c80){const _0x3ec21c=_0xeb55a5['get'](w());_0x5d7608==null&&_0x3ec21c!=null&&(_0x5d7608=Ie(_0x3ec21c,w()));let _0x58c0b3=[];return _0xeb55a5['children']['inorderTraversal']((_0x33cd30,_0x221dca)=>{const _0xc7889d=_0x5d7608?_0x5d7608['getImmediateChild'](_0x33cd30):null,_0x19ffd5=Vo(_0x306c80,_0x33cd30),_0xe6185b=_0x4a26b3['operationForChild'](_0x33cd30);_0xe6185b&&(_0x58c0b3=_0x58c0b3['concat'](Zo(_0xe6185b,_0x221dca,_0xc7889d,_0x19ffd5)));}),_0x3ec21c&&(_0x58c0b3=_0x58c0b3['concat'](os(_0x3ec21c,_0x4a26b3,_0x306c80,_0x5d7608))),_0x58c0b3;}function ea(_0x5f36bb,_0x4f0ed5){const _0x573ca0=_0x4f0ed5['query'],_0x572faf=Wt(_0x5f36bb,_0x573ca0);return{'hashFn':()=>(Mu(_0x4f0ed5)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x2eed73=>{if(_0x2eed73==='ok')return _0x572faf?Qu(_0x5f36bb,_0x573ca0['_path'],_0x572faf):Yu(_0x5f36bb,_0x573ca0['_path']);{const _0x442fe8=Kl(_0x2eed73,_0x573ca0);return An(_0x5f36bb,_0x573ca0,null,_0x442fe8);}}};}function Wt(_0x1c8dd8,_0x15be21){const _0x4a008e=Hn(_0x15be21);return _0x1c8dd8['queryToTagMap']['get'](_0x4a008e);}function Hn(_0x157a57){return _0x157a57['_path']['toString']()+'$'+_0x157a57['_queryIdentifier'];}function cs(_0x5f5695,_0x155a71){return _0x5f5695['tagToQueryMap']['get'](_0x155a71);}function ls(_0x1b7cab){const _0x167af4=_0x1b7cab['indexOf']('$');return f(_0x167af4!==-0x1&&_0x167af4<_0x1b7cab['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1b7cab['substr'](_0x167af4+0x1),'path':new C(_0x1b7cab['substr'](0x0,_0x167af4))};}function hs(_0x2a7a32,_0x1de985,_0x553b0c){const _0x25058c=_0x2a7a32['syncPointTree_']['get'](_0x1de985);f(_0x25058c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x859d36=Wn(_0x2a7a32['pendingWriteTree_'],_0x1de985);return os(_0x25058c,_0x553b0c,_0x859d36,null);}function Zu(_0x1c03c3){return _0x1c03c3['fold']((_0x27c938,_0x3079fb,_0x2db1e2)=>{if(_0x3079fb&&Se(_0x3079fb))return[Bn(_0x3079fb)];{let _0x3e788b=[];return _0x3079fb&&(_0x3e788b=Ko(_0x3079fb)),x(_0x2db1e2,(_0x292443,_0x2534ea)=>{_0x3e788b=_0x3e788b['concat'](_0x2534ea);}),_0x3e788b;}});}function kt(_0x3d8615){return _0x3d8615['_queryParams']['loadsAllData']()&&!_0x3d8615['_queryParams']['isDefault']()?new(qu())(_0x3d8615['_repo'],_0x3d8615['_path']):_0x3d8615;}function ed(_0x1aa715,_0x57eec0){for(let _0x28443e=0x0;_0x28443e<_0x57eec0['length'];++_0x28443e){const _0x4b7553=_0x57eec0[_0x28443e];if(!_0x4b7553['_queryParams']['loadsAllData']()){const _0xc9886c=Hn(_0x4b7553),_0x580936=_0x1aa715['queryToTagMap']['get'](_0xc9886c);_0x1aa715['queryToTagMap']['delete'](_0xc9886c),_0x1aa715['tagToQueryMap']['delete'](_0x580936);}}}function td(){return zu++;}function nd(_0x33741b,_0x3529ed,_0x4ca027){const _0x5bd6fa=_0x3529ed['_path'],_0x25f95c=Wt(_0x33741b,_0x3529ed),_0x29437c=ea(_0x33741b,_0x4ca027),_0x39769f=_0x33741b['listenProvider_']['startListening'](kt(_0x3529ed),_0x25f95c,_0x29437c['hashFn'],_0x29437c['onComplete']),_0x324bf1=_0x33741b['syncPointTree_']['subtree'](_0x5bd6fa);if(_0x25f95c)f(!Se(_0x324bf1['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2e98d5=_0x324bf1['fold']((_0x26e39a,_0x5a7c3,_0x4a1a6d)=>{if(!v(_0x26e39a)&&_0x5a7c3&&Se(_0x5a7c3))return[Bn(_0x5a7c3)['query']];{let _0x500a84=[];return _0x5a7c3&&(_0x500a84=_0x500a84['concat'](Ko(_0x5a7c3)['map'](_0x3f6bc8=>_0x3f6bc8['query']))),x(_0x4a1a6d,(_0x2c0d41,_0x4e9880)=>{_0x500a84=_0x500a84['concat'](_0x4e9880);}),_0x500a84;}});for(let _0x12b15e=0x0;_0x12b15e<_0x2e98d5['length'];++_0x12b15e){const _0x5b3324=_0x2e98d5[_0x12b15e];_0x33741b['listenProvider_']['stopListening'](kt(_0x5b3324),Wt(_0x33741b,_0x5b3324));}}return _0x39769f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x5861b1){this['node_']=_0x5861b1;}['getImmediateChild'](_0x64f4d0){const _0x11488b=this['node_']['getImmediateChild'](_0x64f4d0);return new us(_0x11488b);}['node'](){return this['node_'];}}class ds{constructor(_0x2bfd37,_0x995aee){this['syncTree_']=_0x2bfd37,this['path_']=_0x995aee;}['getImmediateChild'](_0x233e14){const _0x422411=k(this['path_'],_0x233e14);return new ds(this['syncTree_'],_0x422411);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x46d894){return _0x46d894=_0x46d894||{},_0x46d894['timestamp']=_0x46d894['timestamp']||new Date()['getTime'](),_0x46d894;},_r=function(_0x25df72,_0x2cda1b,_0x9f54e0){if(!_0x25df72||typeof _0x25df72!='object')return _0x25df72;if(f('.sv'in _0x25df72,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x25df72['.sv']=='string')return sd(_0x25df72['.sv'],_0x2cda1b,_0x9f54e0);if(typeof _0x25df72['.sv']=='object')return rd(_0x25df72['.sv'],_0x2cda1b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x25df72,null,0x2));},sd=function(_0x53ab53,_0x974ad0,_0x1f4e66){switch(_0x53ab53){case'timestamp':return _0x1f4e66['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x53ab53);}},rd=function(_0x589a16,_0x4da3a0,_0x3cce92){_0x589a16['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x589a16,null,0x2));const _0x4615cf=_0x589a16['increment'];typeof _0x4615cf!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4615cf);const _0x462224=_0x4da3a0['node']();if(f(_0x462224!==null&&typeof _0x462224<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x462224['isLeafNode']())return _0x4615cf;const _0x3c50b9=_0x462224['getValue']();return typeof _0x3c50b9!='number'?_0x4615cf:_0x3c50b9+_0x4615cf;},ta=function(_0x5a0add,_0x1f2460,_0x1500b9,_0x2f1c5e){return ps(_0x1f2460,new ds(_0x1500b9,_0x5a0add),_0x2f1c5e);},fs=function(_0x2ac165,_0x2e5534,_0x1df08a){return ps(_0x2ac165,new us(_0x2e5534),_0x1df08a);};function ps(_0x197b39,_0x513235,_0x46fe6d){const _0x243914=_0x197b39['getPriority']()['val'](),_0x182b1d=_r(_0x243914,_0x513235['getImmediateChild']('.priority'),_0x46fe6d);let _0x5e78c6;if(_0x197b39['isLeafNode']()){const _0x1b55f2=_0x197b39,_0x2d0bab=_r(_0x1b55f2['getValue'](),_0x513235,_0x46fe6d);return _0x2d0bab!==_0x1b55f2['getValue']()||_0x182b1d!==_0x1b55f2['getPriority']()['val']()?new D(_0x2d0bab,A(_0x182b1d)):_0x197b39;}else{const _0x4c59ef=_0x197b39;return _0x5e78c6=_0x4c59ef,_0x182b1d!==_0x4c59ef['getPriority']()['val']()&&(_0x5e78c6=_0x5e78c6['updatePriority'](new D(_0x182b1d))),_0x4c59ef['forEachChild'](R,(_0x252f50,_0x57b61a)=>{const _0x56d40c=ps(_0x57b61a,_0x513235['getImmediateChild'](_0x252f50),_0x46fe6d);_0x56d40c!==_0x57b61a&&(_0x5e78c6=_0x5e78c6['updateImmediateChild'](_0x252f50,_0x56d40c));}),_0x5e78c6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x3c73b4='',_0x35fdb1=null,_0x5b01b9={'children':{},'childCount':0x0}){this['name']=_0x3c73b4,this['parent']=_0x35fdb1,this['node']=_0x5b01b9;}}function $n(_0xb4be89,_0x5a9a24){let _0x28252d=_0x5a9a24 instanceof C?_0x5a9a24:new C(_0x5a9a24),_0x2d7f2f=_0xb4be89,_0x54d002=y(_0x28252d);for(;_0x54d002!==null;){const _0x6ae84f=Le(_0x2d7f2f['node']['children'],_0x54d002)||{'children':{},'childCount':0x0};_0x2d7f2f=new _s(_0x54d002,_0x2d7f2f,_0x6ae84f),_0x28252d=S(_0x28252d),_0x54d002=y(_0x28252d);}return _0x2d7f2f;}function je(_0x5ea03b){return _0x5ea03b['node']['value'];}function gs(_0x4ae13e,_0x361d93){_0x4ae13e['node']['value']=_0x361d93,Oi(_0x4ae13e);}function na(_0x2a5bd1){return _0x2a5bd1['node']['childCount']>0x0;}function od(_0x59b028){return je(_0x59b028)===void 0x0&&!na(_0x59b028);}function Gn(_0x13f3a9,_0x2901d6){x(_0x13f3a9['node']['children'],(_0x288f79,_0x4b1496)=>{_0x2901d6(new _s(_0x288f79,_0x13f3a9,_0x4b1496));});}function ia(_0x22cec3,_0x19e8a3,_0x5bdc1c,_0x4e8885){_0x5bdc1c&&_0x19e8a3(_0x22cec3),Gn(_0x22cec3,_0x21425c=>{ia(_0x21425c,_0x19e8a3,!0x0);});}function ad(_0x46fa32,_0x15c070,_0x5f4c75){let _0x413899=_0x46fa32['parent'];for(;_0x413899!==null;){if(_0x15c070(_0x413899))return!0x0;_0x413899=_0x413899['parent'];}return!0x1;}function Qt(_0xe52c64){return new C(_0xe52c64['parent']===null?_0xe52c64['name']:Qt(_0xe52c64['parent'])+'/'+_0xe52c64['name']);}function Oi(_0x2050eb){_0x2050eb['parent']!==null&&cd(_0x2050eb['parent'],_0x2050eb['name'],_0x2050eb);}function cd(_0x4af3e9,_0x58fe70,_0x5e8ce5){const _0x2eabb2=od(_0x5e8ce5),_0x2a1ebd=Q(_0x4af3e9['node']['children'],_0x58fe70);_0x2eabb2&&_0x2a1ebd?(delete _0x4af3e9['node']['children'][_0x58fe70],_0x4af3e9['node']['childCount']--,Oi(_0x4af3e9)):!_0x2eabb2&&!_0x2a1ebd&&(_0x4af3e9['node']['children'][_0x58fe70]=_0x5e8ce5['node'],_0x4af3e9['node']['childCount']++,Oi(_0x4af3e9));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3082b9){return typeof _0x3082b9=='string'&&_0x3082b9['length']!==0x0&&!ld['test'](_0x3082b9);},sa=function(_0x2bd428){return typeof _0x2bd428=='string'&&_0x2bd428['length']!==0x0&&!hd['test'](_0x2bd428);},ud=function(_0x4ca8c0){return _0x4ca8c0&&(_0x4ca8c0=_0x4ca8c0['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x4ca8c0);},Bt=function(_0x567468){return _0x567468===null||typeof _0x567468=='string'||typeof _0x567468=='number'&&!xn(_0x567468)||_0x567468&&typeof _0x567468=='object'&&Q(_0x567468,'.sv');},He=function(_0x2b90bc,_0x1ac684,_0x3b9db9,_0x5794a6){_0x5794a6&&_0x1ac684===void 0x0||Jt(it(_0x2b90bc,'value'),_0x1ac684,_0x3b9db9);},Jt=function(_0x1d75a8,_0x4a69df,_0x523fd9){const _0x151108=_0x523fd9 instanceof C?new Ah(_0x523fd9,_0x1d75a8):_0x523fd9;if(_0x4a69df===void 0x0)throw new Error(_0x1d75a8+'contains\x20undefined\x20'+Oe(_0x151108));if(typeof _0x4a69df=='function')throw new Error(_0x1d75a8+'contains\x20a\x20function\x20'+Oe(_0x151108)+'\x20with\x20contents\x20=\x20'+_0x4a69df['toString']());if(xn(_0x4a69df))throw new Error(_0x1d75a8+'contains\x20'+_0x4a69df['toString']()+'\x20'+Oe(_0x151108));if(typeof _0x4a69df=='string'&&_0x4a69df['length']>ui/0x3&&Ln(_0x4a69df)>ui)throw new Error(_0x1d75a8+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x151108)+'\x20(\x27'+_0x4a69df['substring'](0x0,0x32)+'...\x27)');if(_0x4a69df&&typeof _0x4a69df=='object'){let _0x32ff0f=!0x1,_0xabd463=!0x1;if(x(_0x4a69df,(_0x2aa647,_0x4863b7)=>{if(_0x2aa647==='.value')_0x32ff0f=!0x0;else{if(_0x2aa647!=='.priority'&&_0x2aa647!=='.sv'&&(_0xabd463=!0x0,!ms(_0x2aa647)))throw new Error(_0x1d75a8+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2aa647+')\x20'+Oe(_0x151108)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x151108,_0x2aa647),Jt(_0x1d75a8,_0x4863b7,_0x151108),Ph(_0x151108);}),_0x32ff0f&&_0xabd463)throw new Error(_0x1d75a8+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x151108)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x23de9c,_0x5a0651){let _0x5d076b,_0x3b7593;for(_0x5d076b=0x0;_0x5d076b<_0x5a0651['length'];_0x5d076b++){_0x3b7593=_0x5a0651[_0x5d076b];const _0x4f649e=Mt(_0x3b7593);for(let _0x49fdf5=0x0;_0x49fdf5<_0x4f649e['length'];_0x49fdf5++)if(!(_0x4f649e[_0x49fdf5]==='.priority'&&_0x49fdf5===_0x4f649e['length']-0x1)){if(!ms(_0x4f649e[_0x49fdf5]))throw new Error(_0x23de9c+'contains\x20an\x20invalid\x20key\x20('+_0x4f649e[_0x49fdf5]+')\x20in\x20path\x20'+_0x3b7593['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5a0651['sort'](Rh);let _0x2b4ee0=null;for(_0x5d076b=0x0;_0x5d076b<_0x5a0651['length'];_0x5d076b++){if(_0x3b7593=_0x5a0651[_0x5d076b],_0x2b4ee0!==null&&G(_0x2b4ee0,_0x3b7593))throw new Error(_0x23de9c+'contains\x20a\x20path\x20'+_0x2b4ee0['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3b7593['toString']());_0x2b4ee0=_0x3b7593;}},ra=function(_0x84cd6e,_0x3e7b2b,_0x17e0a9,_0x225cb3){const _0x2477a7=it(_0x84cd6e,'values');if(!(_0x3e7b2b&&typeof _0x3e7b2b=='object')||Array['isArray'](_0x3e7b2b))throw new Error(_0x2477a7+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4dd1d3=[];x(_0x3e7b2b,(_0x42007e,_0x722d0)=>{const _0x2697f0=new C(_0x42007e);if(Jt(_0x2477a7,_0x722d0,k(_0x17e0a9,_0x2697f0)),ji(_0x2697f0)==='.priority'&&!Bt(_0x722d0))throw new Error(_0x2477a7+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2697f0['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4dd1d3['push'](_0x2697f0);}),dd(_0x2477a7,_0x4dd1d3);},fd=function(_0x3861f6,_0x4a4b96,_0xc1aa90){if(xn(_0x4a4b96))throw new Error(it(_0x3861f6,'priority')+'is\x20'+_0x4a4b96['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4a4b96))throw new Error(it(_0x3861f6,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x467638,_0x1da0ea,_0x38bba8,_0x320704){if(!sa(_0x38bba8))throw new Error(it(_0x467638,_0x1da0ea)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x38bba8+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x264d92,_0x4621a8,_0x59fdcc,_0x35ee6f){_0x59fdcc&&(_0x59fdcc=_0x59fdcc['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x264d92,_0x4621a8,_0x59fdcc);},Me=function(_0x152b79,_0x116ecd){if(y(_0x116ecd)==='.info')throw new Error(_0x152b79+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x21fda8,_0x3495b0){const _0xa0b794=_0x3495b0['path']['toString']();if(typeof _0x3495b0['repoInfo']['host']!='string'||_0x3495b0['repoInfo']['host']['length']===0x0||!ms(_0x3495b0['repoInfo']['namespace'])&&_0x3495b0['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xa0b794['length']!==0x0&&!ud(_0xa0b794))throw new Error(it(_0x21fda8,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3274ac,_0x85a4bf){let _0xabdd=null;for(let _0x418966=0x0;_0x418966<_0x85a4bf['length'];_0x418966++){const _0x347161=_0x85a4bf[_0x418966],_0x4c4bac=_0x347161['getPath']();_0xabdd!==null&&!Ki(_0x4c4bac,_0xabdd['path'])&&(_0x3274ac['eventLists_']['push'](_0xabdd),_0xabdd=null),_0xabdd===null&&(_0xabdd={'events':[],'path':_0x4c4bac}),_0xabdd['events']['push'](_0x347161);}_0xabdd&&_0x3274ac['eventLists_']['push'](_0xabdd);}function oa(_0x1cc822,_0x306739,_0x530b8f){qn(_0x1cc822,_0x530b8f),aa(_0x1cc822,_0x161d97=>Ki(_0x161d97,_0x306739));}function V(_0x42b725,_0x14392f,_0x485f58){qn(_0x42b725,_0x485f58),aa(_0x42b725,_0x78a36=>G(_0x78a36,_0x14392f)||G(_0x14392f,_0x78a36));}function aa(_0x27e855,_0x2e8588){_0x27e855['recursionDepth_']++;let _0x15f1fb=!0x0;for(let _0x2c7f0a=0x0;_0x2c7f0a<_0x27e855['eventLists_']['length'];_0x2c7f0a++){const _0xfbbfd0=_0x27e855['eventLists_'][_0x2c7f0a];if(_0xfbbfd0){const _0x560ea6=_0xfbbfd0['path'];_0x2e8588(_0x560ea6)?(md(_0x27e855['eventLists_'][_0x2c7f0a]),_0x27e855['eventLists_'][_0x2c7f0a]=null):_0x15f1fb=!0x1;}}_0x15f1fb&&(_0x27e855['eventLists_']=[]),_0x27e855['recursionDepth_']--;}function md(_0x199561){for(let _0x458046=0x0;_0x458046<_0x199561['events']['length'];_0x458046++){const _0x53af83=_0x199561['events'][_0x458046];if(_0x53af83!==null){_0x199561['events'][_0x458046]=null;const _0x392f59=_0x53af83['getEventRunner']();St&&L('event:\x20'+_0x53af83['toString']()),ft(_0x392f59);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x5849a0,_0x14dc4b,_0x15be2f,_0x583015){this['repoInfo_']=_0x5849a0,this['forceRestClient_']=_0x14dc4b,this['authTokenProvider_']=_0x15be2f,this['appCheckProvider_']=_0x583015,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1a24d8,_0x2892ac,_0x239883){if(_0x1a24d8['stats_']=qi(_0x1a24d8['repoInfo_']),_0x1a24d8['forceRestClient_']||Xl())_0x1a24d8['server_']=new vn(_0x1a24d8['repoInfo_'],(_0x5c9c06,_0x48aeb0,_0x443a7,_0x48f3f5)=>{gr(_0x1a24d8,_0x5c9c06,_0x48aeb0,_0x443a7,_0x48f3f5);},_0x1a24d8['authTokenProvider_'],_0x1a24d8['appCheckProvider_']),setTimeout(()=>mr(_0x1a24d8,!0x0),0x0);else{if(typeof _0x239883<'u'&&_0x239883!==null){if(typeof _0x239883!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x239883);}catch(_0x725f34){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x725f34);}}_0x1a24d8['persistentConnection_']=new se(_0x1a24d8['repoInfo_'],_0x2892ac,(_0x3db8a6,_0x257320,_0x2cf40c,_0x44a9db)=>{gr(_0x1a24d8,_0x3db8a6,_0x257320,_0x2cf40c,_0x44a9db);},_0x14a5d9=>{mr(_0x1a24d8,_0x14a5d9);},_0x551e34=>{Id(_0x1a24d8,_0x551e34);},_0x1a24d8['authTokenProvider_'],_0x1a24d8['appCheckProvider_'],_0x239883),_0x1a24d8['server_']=_0x1a24d8['persistentConnection_'];}_0x1a24d8['authTokenProvider_']['addTokenChangeListener'](_0x475c67=>{_0x1a24d8['server_']['refreshAuthToken'](_0x475c67);}),_0x1a24d8['appCheckProvider_']['addTokenChangeListener'](_0x1c4408=>{_0x1a24d8['server_']['refreshAppCheckToken'](_0x1c4408['token']);}),_0x1a24d8['statsReporter_']=ih(_0x1a24d8['repoInfo_'],()=>new iu(_0x1a24d8['stats_'],_0x1a24d8['server_'])),_0x1a24d8['infoData_']=new Xh(),_0x1a24d8['infoSyncTree_']=new pr({'startListening':(_0x41c9c1,_0x16fc62,_0x48a02c,_0xec6f7c)=>{let _0x230a49=[];const _0x17f972=_0x1a24d8['infoData_']['getNode'](_0x41c9c1['_path']);return _0x17f972['isEmpty']()||(_0x230a49=Yt(_0x1a24d8['infoSyncTree_'],_0x41c9c1['_path'],_0x17f972),setTimeout(()=>{_0xec6f7c('ok');},0x0)),_0x230a49;},'stopListening':()=>{}}),vs(_0x1a24d8,'connected',!0x1),_0x1a24d8['serverSyncTree_']=new pr({'startListening':(_0x3913bc,_0x5ec0e3,_0x5b41f9,_0x4b42d8)=>(_0x1a24d8['server_']['listen'](_0x3913bc,_0x5b41f9,_0x5ec0e3,(_0x58ce38,_0x329220)=>{const _0x403b49=_0x4b42d8(_0x58ce38,_0x329220);V(_0x1a24d8['eventQueue_'],_0x3913bc['_path'],_0x403b49);}),[]),'stopListening':(_0xe2ea1d,_0x5da7c8)=>{_0x1a24d8['server_']['unlisten'](_0xe2ea1d,_0x5da7c8);}});}function la(_0x10ba64){const _0x87c338=_0x10ba64['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x87c338;}function Xt(_0x371630){return id({'timestamp':la(_0x371630)});}function gr(_0x38656c,_0x2af940,_0x33f92d,_0x3c0907,_0x3a2947){_0x38656c['dataUpdateCount']++;const _0x2aa473=new C(_0x2af940);_0x33f92d=_0x38656c['interceptServerDataCallback_']?_0x38656c['interceptServerDataCallback_'](_0x2af940,_0x33f92d):_0x33f92d;let _0x5790c8=[];if(_0x3a2947){if(_0x3c0907){const _0x4771d1=_n(_0x33f92d,_0x3571d1=>A(_0x3571d1));_0x5790c8=Ju(_0x38656c['serverSyncTree_'],_0x2aa473,_0x4771d1,_0x3a2947);}else{const _0x2f108d=A(_0x33f92d);_0x5790c8=Jo(_0x38656c['serverSyncTree_'],_0x2aa473,_0x2f108d,_0x3a2947);}}else{if(_0x3c0907){const _0x3483de=_n(_0x33f92d,_0x2e5f02=>A(_0x2e5f02));_0x5790c8=Ku(_0x38656c['serverSyncTree_'],_0x2aa473,_0x3483de);}else{const _0xf9062e=A(_0x33f92d);_0x5790c8=Yt(_0x38656c['serverSyncTree_'],_0x2aa473,_0xf9062e);}}let _0x3d4613=_0x2aa473;_0x5790c8['length']>0x0&&(_0x3d4613=ct(_0x38656c,_0x2aa473)),V(_0x38656c['eventQueue_'],_0x3d4613,_0x5790c8);}function mr(_0x3e08ff,_0x338a17){vs(_0x3e08ff,'connected',_0x338a17),_0x338a17===!0x1&&Sd(_0x3e08ff);}function Id(_0x13d313,_0x1439e3){x(_0x1439e3,(_0x18c63b,_0xb13aec)=>{vs(_0x13d313,_0x18c63b,_0xb13aec);});}function vs(_0x356dd1,_0x3c2062,_0x2494ae){const _0x2746a4=new C('/.info/'+_0x3c2062),_0xae2fda=A(_0x2494ae);_0x356dd1['infoData_']['updateSnapshot'](_0x2746a4,_0xae2fda);const _0x222671=Yt(_0x356dd1['infoSyncTree_'],_0x2746a4,_0xae2fda);V(_0x356dd1['eventQueue_'],_0x2746a4,_0x222671);}function zn(_0x22eede){return _0x22eede['nextWriteId_']++;}function wd(_0x2b57e7,_0x5b4965,_0x4cd966){const _0x1bf987=Xu(_0x2b57e7['serverSyncTree_'],_0x5b4965);return _0x1bf987!=null?Promise['resolve'](_0x1bf987):_0x2b57e7['server_']['get'](_0x5b4965)['then'](_0x4afd90=>{const _0x65a442=A(_0x4afd90)['withIndex'](_0x5b4965['_queryParams']['getIndex']());Ni(_0x2b57e7['serverSyncTree_'],_0x5b4965,_0x4cd966,!0x0);let _0x447319;if(_0x5b4965['_queryParams']['loadsAllData']())_0x447319=Yt(_0x2b57e7['serverSyncTree_'],_0x5b4965['_path'],_0x65a442);else{const _0x336583=Wt(_0x2b57e7['serverSyncTree_'],_0x5b4965);_0x447319=Jo(_0x2b57e7['serverSyncTree_'],_0x5b4965['_path'],_0x65a442,_0x336583);}return V(_0x2b57e7['eventQueue_'],_0x5b4965['_path'],_0x447319),An(_0x2b57e7['serverSyncTree_'],_0x5b4965,_0x4cd966,null,!0x0),_0x65a442;},_0x14db3d=>(gt(_0x2b57e7,'get\x20for\x20query\x20'+O(_0x5b4965)+'\x20failed:\x20'+_0x14db3d),Promise['reject'](new Error(_0x14db3d))));}function Cd(_0x106958,_0x2002a9,_0xe8d4b7,_0xa3fe78,_0x30a511){gt(_0x106958,'set',{'path':_0x2002a9['toString'](),'value':_0xe8d4b7,'priority':_0xa3fe78});const _0x4b1310=Xt(_0x106958),_0x32c7b5=A(_0xe8d4b7,_0xa3fe78),_0x4dcd40=Vn(_0x106958['serverSyncTree_'],_0x2002a9),_0x28412b=fs(_0x32c7b5,_0x4dcd40,_0x4b1310),_0xddded1=zn(_0x106958),_0x48caba=as(_0x106958['serverSyncTree_'],_0x2002a9,_0x28412b,_0xddded1,!0x0);qn(_0x106958['eventQueue_'],_0x48caba),_0x106958['server_']['put'](_0x2002a9['toString'](),_0x32c7b5['val'](!0x0),(_0x3af6b4,_0x42374a)=>{const _0x1d9a3f=_0x3af6b4==='ok';_0x1d9a3f||U('set\x20at\x20'+_0x2002a9+'\x20failed:\x20'+_0x3af6b4);const _0xcdb0dd=_e(_0x106958['serverSyncTree_'],_0xddded1,!_0x1d9a3f);V(_0x106958['eventQueue_'],_0x2002a9,_0xcdb0dd),be(_0x106958,_0x30a511,_0x3af6b4,_0x42374a);});const _0x50fb1b=Is(_0x106958,_0x2002a9);ct(_0x106958,_0x50fb1b),V(_0x106958['eventQueue_'],_0x50fb1b,[]);}function Td(_0x3be949,_0x516cb8,_0x2ec2ce,_0x2d30c0){gt(_0x3be949,'update',{'path':_0x516cb8['toString'](),'value':_0x2ec2ce});let _0x3fc1e0=!0x0;const _0xefbe7b=Xt(_0x3be949),_0x32578a={};if(x(_0x2ec2ce,(_0x563da5,_0x229cde)=>{_0x3fc1e0=!0x1,_0x32578a[_0x563da5]=ta(k(_0x516cb8,_0x563da5),A(_0x229cde),_0x3be949['serverSyncTree_'],_0xefbe7b);}),_0x3fc1e0)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3be949,_0x2d30c0,'ok',void 0x0);else{const _0x2db38e=zn(_0x3be949),_0x461ac3=ju(_0x3be949['serverSyncTree_'],_0x516cb8,_0x32578a,_0x2db38e);qn(_0x3be949['eventQueue_'],_0x461ac3),_0x3be949['server_']['merge'](_0x516cb8['toString'](),_0x2ec2ce,(_0x202c97,_0x54b4ad)=>{const _0x2df7d3=_0x202c97==='ok';_0x2df7d3||U('update\x20at\x20'+_0x516cb8+'\x20failed:\x20'+_0x202c97);const _0x557f69=_e(_0x3be949['serverSyncTree_'],_0x2db38e,!_0x2df7d3),_0x10638b=_0x557f69['length']>0x0?ct(_0x3be949,_0x516cb8):_0x516cb8;V(_0x3be949['eventQueue_'],_0x10638b,_0x557f69),be(_0x3be949,_0x2d30c0,_0x202c97,_0x54b4ad);}),x(_0x2ec2ce,_0x17bde6=>{const _0x150ec8=Is(_0x3be949,k(_0x516cb8,_0x17bde6));ct(_0x3be949,_0x150ec8);}),V(_0x3be949['eventQueue_'],_0x516cb8,[]);}}function Sd(_0x2e3c7c){gt(_0x2e3c7c,'onDisconnectEvents');const _0x2fed38=Xt(_0x2e3c7c),_0x281128=En();Si(_0x2e3c7c['onDisconnect_'],w(),(_0xf236b5,_0x46809f)=>{const _0x27f139=ta(_0xf236b5,_0x46809f,_0x2e3c7c['serverSyncTree_'],_0x2fed38);pt(_0x281128,_0xf236b5,_0x27f139);});let _0x255828=[];Si(_0x281128,w(),(_0x700489,_0x3cef13)=>{_0x255828=_0x255828['concat'](Yt(_0x2e3c7c['serverSyncTree_'],_0x700489,_0x3cef13));const _0x5c14e4=Is(_0x2e3c7c,_0x700489);ct(_0x2e3c7c,_0x5c14e4);}),_0x2e3c7c['onDisconnect_']=En(),V(_0x2e3c7c['eventQueue_'],w(),_0x255828);}function bd(_0x318a09,_0x3e9b3b,_0x4046cc){_0x318a09['server_']['onDisconnectCancel'](_0x3e9b3b['toString'](),(_0xba65ea,_0x450b69)=>{_0xba65ea==='ok'&&Ti(_0x318a09['onDisconnect_'],_0x3e9b3b),be(_0x318a09,_0x4046cc,_0xba65ea,_0x450b69);});}function yr(_0x55ea32,_0xfc9252,_0xe69939,_0x18a7d4){const _0x203a16=A(_0xe69939);_0x55ea32['server_']['onDisconnectPut'](_0xfc9252['toString'](),_0x203a16['val'](!0x0),(_0x3f9890,_0x572615)=>{_0x3f9890==='ok'&&pt(_0x55ea32['onDisconnect_'],_0xfc9252,_0x203a16),be(_0x55ea32,_0x18a7d4,_0x3f9890,_0x572615);});}function Rd(_0x94419b,_0x207981,_0x2aa779,_0x2da4f3,_0x3e5932){const _0x187ecb=A(_0x2aa779,_0x2da4f3);_0x94419b['server_']['onDisconnectPut'](_0x207981['toString'](),_0x187ecb['val'](!0x0),(_0x58240f,_0x1f58b1)=>{_0x58240f==='ok'&&pt(_0x94419b['onDisconnect_'],_0x207981,_0x187ecb),be(_0x94419b,_0x3e5932,_0x58240f,_0x1f58b1);});}function Ad(_0x1173be,_0x505a42,_0x2ed2b3,_0x133930){if(pn(_0x2ed2b3)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1173be,_0x133930,'ok',void 0x0);return;}_0x1173be['server_']['onDisconnectMerge'](_0x505a42['toString'](),_0x2ed2b3,(_0x223515,_0x3a74e3)=>{_0x223515==='ok'&&x(_0x2ed2b3,(_0x1160b7,_0x17beac)=>{const _0x5b99a2=A(_0x17beac);pt(_0x1173be['onDisconnect_'],k(_0x505a42,_0x1160b7),_0x5b99a2);}),be(_0x1173be,_0x133930,_0x223515,_0x3a74e3);});}function kd(_0x7b4650,_0x2d7a47,_0x309d25){let _0x213b0f;y(_0x2d7a47['_path'])==='.info'?_0x213b0f=Ni(_0x7b4650['infoSyncTree_'],_0x2d7a47,_0x309d25):_0x213b0f=Ni(_0x7b4650['serverSyncTree_'],_0x2d7a47,_0x309d25),oa(_0x7b4650['eventQueue_'],_0x2d7a47['_path'],_0x213b0f);}function Pd(_0x33ffb8,_0x4f502b,_0x40e46c){let _0x5e4a37;y(_0x4f502b['_path'])==='.info'?_0x5e4a37=An(_0x33ffb8['infoSyncTree_'],_0x4f502b,_0x40e46c):_0x5e4a37=An(_0x33ffb8['serverSyncTree_'],_0x4f502b,_0x40e46c),oa(_0x33ffb8['eventQueue_'],_0x4f502b['_path'],_0x5e4a37);}function ha(_0xd60646){_0xd60646['persistentConnection_']&&_0xd60646['persistentConnection_']['interrupt'](ca);}function Nd(_0x6a42fb){_0x6a42fb['persistentConnection_']&&_0x6a42fb['persistentConnection_']['resume'](ca);}function gt(_0x1e9625,..._0x36ffb){let _0x2b4288='';_0x1e9625['persistentConnection_']&&(_0x2b4288=_0x1e9625['persistentConnection_']['id']+':'),L(_0x2b4288,..._0x36ffb);}function be(_0x217ff8,_0x32e0d3,_0x52dedc,_0x301d6f){_0x32e0d3&&ft(()=>{if(_0x52dedc==='ok')_0x32e0d3(null);else{const _0x3cc75e=(_0x52dedc||'error')['toUpperCase']();let _0x375aad=_0x3cc75e;_0x301d6f&&(_0x375aad+=':\x20'+_0x301d6f);const _0x4c0f75=new Error(_0x375aad);_0x4c0f75['code']=_0x3cc75e,_0x32e0d3(_0x4c0f75);}});}function Od(_0x5e4fdf,_0x184fba,_0x1d2d0b,_0x37dd73,_0x5a8360,_0x10beb5){gt(_0x5e4fdf,'transaction\x20on\x20'+_0x184fba);const _0x24dac0={'path':_0x184fba,'update':_0x1d2d0b,'onComplete':_0x37dd73,'status':null,'order':so(),'applyLocally':_0x10beb5,'retryCount':0x0,'unwatcher':_0x5a8360,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4cfe7f=Es(_0x5e4fdf,_0x184fba,void 0x0);_0x24dac0['currentInputSnapshot']=_0x4cfe7f;const _0x425e0d=_0x24dac0['update'](_0x4cfe7f['val']());if(_0x425e0d===void 0x0)_0x24dac0['unwatcher'](),_0x24dac0['currentOutputSnapshotRaw']=null,_0x24dac0['currentOutputSnapshotResolved']=null,_0x24dac0['onComplete']&&_0x24dac0['onComplete'](null,!0x1,_0x24dac0['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x425e0d,_0x24dac0['path']),_0x24dac0['status']=0x0;const _0x5b3a75=$n(_0x5e4fdf['transactionQueueTree_'],_0x184fba),_0x1cd6d1=je(_0x5b3a75)||[];_0x1cd6d1['push'](_0x24dac0),gs(_0x5b3a75,_0x1cd6d1);let _0x4aaa83;typeof _0x425e0d=='object'&&_0x425e0d!==null&&Q(_0x425e0d,'.priority')?(_0x4aaa83=Le(_0x425e0d,'.priority'),f(Bt(_0x4aaa83),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4aaa83=(Vn(_0x5e4fdf['serverSyncTree_'],_0x184fba)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x4cc81c=Xt(_0x5e4fdf),_0xaaa6f5=A(_0x425e0d,_0x4aaa83),_0x739d49=fs(_0xaaa6f5,_0x4cfe7f,_0x4cc81c);_0x24dac0['currentOutputSnapshotRaw']=_0xaaa6f5,_0x24dac0['currentOutputSnapshotResolved']=_0x739d49,_0x24dac0['currentWriteId']=zn(_0x5e4fdf);const _0x323ae2=as(_0x5e4fdf['serverSyncTree_'],_0x184fba,_0x739d49,_0x24dac0['currentWriteId'],_0x24dac0['applyLocally']);V(_0x5e4fdf['eventQueue_'],_0x184fba,_0x323ae2),jn(_0x5e4fdf,_0x5e4fdf['transactionQueueTree_']);}}function Es(_0x9132e,_0x4deb69,_0x100b9f){return Vn(_0x9132e['serverSyncTree_'],_0x4deb69,_0x100b9f)||g['EMPTY_NODE'];}function jn(_0x44b2f8,_0x4a8f21=_0x44b2f8['transactionQueueTree_']){if(_0x4a8f21||Kn(_0x44b2f8,_0x4a8f21),je(_0x4a8f21)){const _0x255a39=da(_0x44b2f8,_0x4a8f21);f(_0x255a39['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x255a39['every'](_0x23691f=>_0x23691f['status']===0x0)&&Dd(_0x44b2f8,Qt(_0x4a8f21),_0x255a39);}else na(_0x4a8f21)&&Gn(_0x4a8f21,_0x2c49d7=>{jn(_0x44b2f8,_0x2c49d7);});}function Dd(_0x41d698,_0x552572,_0x190597){const _0x1f934e=_0x190597['map'](_0x2f4fa4=>_0x2f4fa4['currentWriteId']),_0x25c47c=Es(_0x41d698,_0x552572,_0x1f934e);let _0x21dc01=_0x25c47c;const _0x36f592=_0x25c47c['hash']();for(let _0xeeb0c2=0x0;_0xeeb0c2<_0x190597['length'];_0xeeb0c2++){const _0x116012=_0x190597[_0xeeb0c2];f(_0x116012['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x116012['status']=0x1,_0x116012['retryCount']++;const _0x430597=F(_0x552572,_0x116012['path']);_0x21dc01=_0x21dc01['updateChild'](_0x430597,_0x116012['currentOutputSnapshotRaw']);}const _0xbb86b5=_0x21dc01['val'](!0x0),_0x3c6b1b=_0x552572;_0x41d698['server_']['put'](_0x3c6b1b['toString'](),_0xbb86b5,_0x193f33=>{gt(_0x41d698,'transaction\x20put\x20response',{'path':_0x3c6b1b['toString'](),'status':_0x193f33});let _0x1dbc80=[];if(_0x193f33==='ok'){const _0x325072=[];for(let _0x2ad052=0x0;_0x2ad052<_0x190597['length'];_0x2ad052++)_0x190597[_0x2ad052]['status']=0x2,_0x1dbc80=_0x1dbc80['concat'](_e(_0x41d698['serverSyncTree_'],_0x190597[_0x2ad052]['currentWriteId'])),_0x190597[_0x2ad052]['onComplete']&&_0x325072['push'](()=>_0x190597[_0x2ad052]['onComplete'](null,!0x0,_0x190597[_0x2ad052]['currentOutputSnapshotResolved'])),_0x190597[_0x2ad052]['unwatcher']();Kn(_0x41d698,$n(_0x41d698['transactionQueueTree_'],_0x552572)),jn(_0x41d698,_0x41d698['transactionQueueTree_']),V(_0x41d698['eventQueue_'],_0x552572,_0x1dbc80);for(let _0x5cec93=0x0;_0x5cec93<_0x325072['length'];_0x5cec93++)ft(_0x325072[_0x5cec93]);}else{if(_0x193f33==='datastale'){for(let _0x58c5c4=0x0;_0x58c5c4<_0x190597['length'];_0x58c5c4++)_0x190597[_0x58c5c4]['status']===0x3?_0x190597[_0x58c5c4]['status']=0x4:_0x190597[_0x58c5c4]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3c6b1b['toString']()+'\x20failed:\x20'+_0x193f33);for(let _0x4e4260=0x0;_0x4e4260<_0x190597['length'];_0x4e4260++)_0x190597[_0x4e4260]['status']=0x4,_0x190597[_0x4e4260]['abortReason']=_0x193f33;}ct(_0x41d698,_0x552572);}},_0x36f592);}function ct(_0xb0ba7f,_0x134262){const _0xf85525=ua(_0xb0ba7f,_0x134262),_0xdb5a97=Qt(_0xf85525),_0x4f9c0e=da(_0xb0ba7f,_0xf85525);return Md(_0xb0ba7f,_0x4f9c0e,_0xdb5a97),_0xdb5a97;}function Md(_0x5ceb4b,_0x2c32be,_0x586a23){if(_0x2c32be['length']===0x0)return;const _0xfaeb7c=[];let _0x5ce98f=[];const _0x49ab8d=_0x2c32be['filter'](_0x37d103=>_0x37d103['status']===0x0)['map'](_0x9b2caa=>_0x9b2caa['currentWriteId']);for(let _0x50fce4=0x0;_0x50fce4<_0x2c32be['length'];_0x50fce4++){const _0xe6e357=_0x2c32be[_0x50fce4],_0x706bdd=F(_0x586a23,_0xe6e357['path']);let _0x5cce6d=!0x1,_0x58b4d3;if(f(_0x706bdd!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xe6e357['status']===0x4)_0x5cce6d=!0x0,_0x58b4d3=_0xe6e357['abortReason'],_0x5ce98f=_0x5ce98f['concat'](_e(_0x5ceb4b['serverSyncTree_'],_0xe6e357['currentWriteId'],!0x0));else{if(_0xe6e357['status']===0x0){if(_0xe6e357['retryCount']>=yd)_0x5cce6d=!0x0,_0x58b4d3='maxretry',_0x5ce98f=_0x5ce98f['concat'](_e(_0x5ceb4b['serverSyncTree_'],_0xe6e357['currentWriteId'],!0x0));else{const _0x5069ae=Es(_0x5ceb4b,_0xe6e357['path'],_0x49ab8d);_0xe6e357['currentInputSnapshot']=_0x5069ae;const _0x3f228c=_0x2c32be[_0x50fce4]['update'](_0x5069ae['val']());if(_0x3f228c!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3f228c,_0xe6e357['path']);let _0x416415=A(_0x3f228c);typeof _0x3f228c=='object'&&_0x3f228c!=null&&Q(_0x3f228c,'.priority')||(_0x416415=_0x416415['updatePriority'](_0x5069ae['getPriority']()));const _0x22b364=_0xe6e357['currentWriteId'],_0x42f650=Xt(_0x5ceb4b),_0x251371=fs(_0x416415,_0x5069ae,_0x42f650);_0xe6e357['currentOutputSnapshotRaw']=_0x416415,_0xe6e357['currentOutputSnapshotResolved']=_0x251371,_0xe6e357['currentWriteId']=zn(_0x5ceb4b),_0x49ab8d['splice'](_0x49ab8d['indexOf'](_0x22b364),0x1),_0x5ce98f=_0x5ce98f['concat'](as(_0x5ceb4b['serverSyncTree_'],_0xe6e357['path'],_0x251371,_0xe6e357['currentWriteId'],_0xe6e357['applyLocally'])),_0x5ce98f=_0x5ce98f['concat'](_e(_0x5ceb4b['serverSyncTree_'],_0x22b364,!0x0));}else _0x5cce6d=!0x0,_0x58b4d3='nodata',_0x5ce98f=_0x5ce98f['concat'](_e(_0x5ceb4b['serverSyncTree_'],_0xe6e357['currentWriteId'],!0x0));}}}V(_0x5ceb4b['eventQueue_'],_0x586a23,_0x5ce98f),_0x5ce98f=[],_0x5cce6d&&(_0x2c32be[_0x50fce4]['status']=0x2,function(_0xfab93a){setTimeout(_0xfab93a,Math['floor'](0x0));}(_0x2c32be[_0x50fce4]['unwatcher']),_0x2c32be[_0x50fce4]['onComplete']&&(_0x58b4d3==='nodata'?_0xfaeb7c['push'](()=>_0x2c32be[_0x50fce4]['onComplete'](null,!0x1,_0x2c32be[_0x50fce4]['currentInputSnapshot'])):_0xfaeb7c['push'](()=>_0x2c32be[_0x50fce4]['onComplete'](new Error(_0x58b4d3),!0x1,null))));}Kn(_0x5ceb4b,_0x5ceb4b['transactionQueueTree_']);for(let _0x4e863d=0x0;_0x4e863d<_0xfaeb7c['length'];_0x4e863d++)ft(_0xfaeb7c[_0x4e863d]);jn(_0x5ceb4b,_0x5ceb4b['transactionQueueTree_']);}function ua(_0x27caa1,_0xd5c4d8){let _0x72619f,_0xffcb50=_0x27caa1['transactionQueueTree_'];for(_0x72619f=y(_0xd5c4d8);_0x72619f!==null&&je(_0xffcb50)===void 0x0;)_0xffcb50=$n(_0xffcb50,_0x72619f),_0xd5c4d8=S(_0xd5c4d8),_0x72619f=y(_0xd5c4d8);return _0xffcb50;}function da(_0x1e3d30,_0x382e68){const _0x41c44f=[];return fa(_0x1e3d30,_0x382e68,_0x41c44f),_0x41c44f['sort']((_0x4ba25b,_0x1a4968)=>_0x4ba25b['order']-_0x1a4968['order']),_0x41c44f;}function fa(_0x1eb434,_0x389629,_0x142af0){const _0x34d2e1=je(_0x389629);if(_0x34d2e1){for(let _0x5a5a82=0x0;_0x5a5a82<_0x34d2e1['length'];_0x5a5a82++)_0x142af0['push'](_0x34d2e1[_0x5a5a82]);}Gn(_0x389629,_0x2a6ed0=>{fa(_0x1eb434,_0x2a6ed0,_0x142af0);});}function Kn(_0x205d6b,_0x569918){const _0x2c482e=je(_0x569918);if(_0x2c482e){let _0x335d29=0x0;for(let _0x45b7c1=0x0;_0x45b7c1<_0x2c482e['length'];_0x45b7c1++)_0x2c482e[_0x45b7c1]['status']!==0x2&&(_0x2c482e[_0x335d29]=_0x2c482e[_0x45b7c1],_0x335d29++);_0x2c482e['length']=_0x335d29,gs(_0x569918,_0x2c482e['length']>0x0?_0x2c482e:void 0x0);}Gn(_0x569918,_0x52805d=>{Kn(_0x205d6b,_0x52805d);});}function Is(_0x30606d,_0x2e1d51){const _0x4b4420=Qt(ua(_0x30606d,_0x2e1d51)),_0x16c1ef=$n(_0x30606d['transactionQueueTree_'],_0x2e1d51);return ad(_0x16c1ef,_0x3b72d2=>{di(_0x30606d,_0x3b72d2);}),di(_0x30606d,_0x16c1ef),ia(_0x16c1ef,_0x2bf5f9=>{di(_0x30606d,_0x2bf5f9);}),_0x4b4420;}function di(_0x37ab1c,_0x5ecc99){const _0x2acafb=je(_0x5ecc99);if(_0x2acafb){const _0x2216ee=[];let _0x25cdd3=[],_0x1424ef=-0x1;for(let _0x5ba331=0x0;_0x5ba331<_0x2acafb['length'];_0x5ba331++)_0x2acafb[_0x5ba331]['status']===0x3||(_0x2acafb[_0x5ba331]['status']===0x1?(f(_0x1424ef===_0x5ba331-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1424ef=_0x5ba331,_0x2acafb[_0x5ba331]['status']=0x3,_0x2acafb[_0x5ba331]['abortReason']='set'):(f(_0x2acafb[_0x5ba331]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2acafb[_0x5ba331]['unwatcher'](),_0x25cdd3=_0x25cdd3['concat'](_e(_0x37ab1c['serverSyncTree_'],_0x2acafb[_0x5ba331]['currentWriteId'],!0x0)),_0x2acafb[_0x5ba331]['onComplete']&&_0x2216ee['push'](_0x2acafb[_0x5ba331]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1424ef===-0x1?gs(_0x5ecc99,void 0x0):_0x2acafb['length']=_0x1424ef+0x1,V(_0x37ab1c['eventQueue_'],Qt(_0x5ecc99),_0x25cdd3);for(let _0x572083=0x0;_0x572083<_0x2216ee['length'];_0x572083++)ft(_0x2216ee[_0x572083]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x23ca8e){let _0x23c5e7='';const _0xb4b45f=_0x23ca8e['split']('/');for(let _0x4c3c27=0x0;_0x4c3c27<_0xb4b45f['length'];_0x4c3c27++)if(_0xb4b45f[_0x4c3c27]['length']>0x0){let _0x162a58=_0xb4b45f[_0x4c3c27];try{_0x162a58=decodeURIComponent(_0x162a58['replace'](/\+/g,'\x20'));}catch{}_0x23c5e7+='/'+_0x162a58;}return _0x23c5e7;}function xd(_0x15cd6a){const _0x3c7724={};_0x15cd6a['charAt'](0x0)==='?'&&(_0x15cd6a=_0x15cd6a['substring'](0x1));for(const _0x3ad676 of _0x15cd6a['split']('&')){if(_0x3ad676['length']===0x0)continue;const _0x50c318=_0x3ad676['split']('=');_0x50c318['length']===0x2?_0x3c7724[decodeURIComponent(_0x50c318[0x0])]=decodeURIComponent(_0x50c318[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3ad676+'\x27\x20in\x20query\x20\x27'+_0x15cd6a+'\x27');}return _0x3c7724;}const vr=function(_0x346194,_0x436ec7){const _0x5096d0=Fd(_0x346194),_0x3ab109=_0x5096d0['namespace'];_0x5096d0['domain']==='firebase.com'&&ae(_0x5096d0['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3ab109||_0x3ab109==='undefined')&&_0x5096d0['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x5096d0['secure']||$l();const _0x3cdf86=_0x5096d0['scheme']==='ws'||_0x5096d0['scheme']==='wss';return{'repoInfo':new yo(_0x5096d0['host'],_0x5096d0['secure'],_0x3ab109,_0x3cdf86,_0x436ec7,'',_0x3ab109!==_0x5096d0['subdomain']),'path':new C(_0x5096d0['pathString'])};},Fd=function(_0xef8c0c){let _0x907aa6='',_0x3d4f84='',_0x5d5df7='',_0x3ace75='',_0x255160='',_0x551f3d=!0x0,_0x713f34='https',_0x1b8788=0x1bb;if(typeof _0xef8c0c=='string'){let _0x554e51=_0xef8c0c['indexOf']('//');_0x554e51>=0x0&&(_0x713f34=_0xef8c0c['substring'](0x0,_0x554e51-0x1),_0xef8c0c=_0xef8c0c['substring'](_0x554e51+0x2));let _0x1ece6b=_0xef8c0c['indexOf']('/');_0x1ece6b===-0x1&&(_0x1ece6b=_0xef8c0c['length']);let _0x2cf6d8=_0xef8c0c['indexOf']('?');_0x2cf6d8===-0x1&&(_0x2cf6d8=_0xef8c0c['length']),_0x907aa6=_0xef8c0c['substring'](0x0,Math['min'](_0x1ece6b,_0x2cf6d8)),_0x1ece6b<_0x2cf6d8&&(_0x3ace75=Ld(_0xef8c0c['substring'](_0x1ece6b,_0x2cf6d8)));const _0x3dd7ca=xd(_0xef8c0c['substring'](Math['min'](_0xef8c0c['length'],_0x2cf6d8)));_0x554e51=_0x907aa6['indexOf'](':'),_0x554e51>=0x0?(_0x551f3d=_0x713f34==='https'||_0x713f34==='wss',_0x1b8788=parseInt(_0x907aa6['substring'](_0x554e51+0x1),0xa)):_0x554e51=_0x907aa6['length'];const _0x5b1522=_0x907aa6['slice'](0x0,_0x554e51);if(_0x5b1522['toLowerCase']()==='localhost')_0x3d4f84='localhost';else{if(_0x5b1522['split']('.')['length']<=0x2)_0x3d4f84=_0x5b1522;else{const _0x3aea40=_0x907aa6['indexOf']('.');_0x5d5df7=_0x907aa6['substring'](0x0,_0x3aea40)['toLowerCase'](),_0x3d4f84=_0x907aa6['substring'](_0x3aea40+0x1),_0x255160=_0x5d5df7;}}'ns'in _0x3dd7ca&&(_0x255160=_0x3dd7ca['ns']);}return{'host':_0x907aa6,'port':_0x1b8788,'domain':_0x3d4f84,'subdomain':_0x5d5df7,'secure':_0x551f3d,'scheme':_0x713f34,'pathString':_0x3ace75,'namespace':_0x255160};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x12d12b=0x0;const _0x102b03=[];return function(_0x352a23){const _0x484de6=_0x352a23===_0x12d12b;_0x12d12b=_0x352a23;let _0x30842b;const _0x4576b7=new Array(0x8);for(_0x30842b=0x7;_0x30842b>=0x0;_0x30842b--)_0x4576b7[_0x30842b]=Er['charAt'](_0x352a23%0x40),_0x352a23=Math['floor'](_0x352a23/0x40);f(_0x352a23===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x34f829=_0x4576b7['join']('');if(_0x484de6){for(_0x30842b=0xb;_0x30842b>=0x0&&_0x102b03[_0x30842b]===0x3f;_0x30842b--)_0x102b03[_0x30842b]=0x0;_0x102b03[_0x30842b]++;}else{for(_0x30842b=0x0;_0x30842b<0xc;_0x30842b++)_0x102b03[_0x30842b]=Math['floor'](Math['random']()*0x40);}for(_0x30842b=0x0;_0x30842b<0xc;_0x30842b++)_0x34f829+=Er['charAt'](_0x102b03[_0x30842b]);return f(_0x34f829['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x34f829;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x4fb6ec,_0x47bd78,_0x377d6e,_0xe1fbb9){this['eventType']=_0x4fb6ec,this['eventRegistration']=_0x47bd78,this['snapshot']=_0x377d6e,this['prevName']=_0xe1fbb9;}['getPath'](){const _0x280b82=this['snapshot']['ref'];return this['eventType']==='value'?_0x280b82['_path']:_0x280b82['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x567d45,_0x1ac993,_0xc3ca34){this['eventRegistration']=_0x567d45,this['error']=_0x1ac993,this['path']=_0xc3ca34;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x5bd213,_0x46cbdf){this['snapshotCallback']=_0x5bd213,this['cancelCallback']=_0x46cbdf;}['onValue'](_0x37d661,_0x44b375){this['snapshotCallback']['call'](null,_0x37d661,_0x44b375);}['onCancel'](_0x202b34){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x202b34);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x56e4cd){return this['snapshotCallback']===_0x56e4cd['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x56e4cd['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x56e4cd['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x28bd75,_0x515c92){this['_repo']=_0x28bd75,this['_path']=_0x515c92;}['cancel'](){const _0x1c93f5=new H();return bd(this['_repo'],this['_path'],_0x1c93f5['wrapCallback'](()=>{})),_0x1c93f5['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0xbac9c3=new H();return yr(this['_repo'],this['_path'],null,_0xbac9c3['wrapCallback'](()=>{})),_0xbac9c3['promise'];}['set'](_0x1958fd){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x1958fd,this['_path'],!0x1);const _0x30ddb7=new H();return yr(this['_repo'],this['_path'],_0x1958fd,_0x30ddb7['wrapCallback'](()=>{})),_0x30ddb7['promise'];}['setWithPriority'](_0x23aca0,_0x42b6a7){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x23aca0,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x42b6a7);const _0x43c44b=new H();return Rd(this['_repo'],this['_path'],_0x23aca0,_0x42b6a7,_0x43c44b['wrapCallback'](()=>{})),_0x43c44b['promise'];}['update'](_0x2ac31d){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x2ac31d,this['_path']);const _0x4e7e28=new H();return Ad(this['_repo'],this['_path'],_0x2ac31d,_0x4e7e28['wrapCallback'](()=>{})),_0x4e7e28['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x532b93,_0xb1326e,_0x17866a,_0xd3245d){this['_repo']=_0x532b93,this['_path']=_0xb1326e,this['_queryParams']=_0x17866a,this['_orderByCalled']=_0xd3245d;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xe09157=sr(this['_queryParams']),_0x49a338=$i(_0xe09157);return _0x49a338==='{}'?'default':_0x49a338;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x242553){if(_0x242553=P(_0x242553),!(_0x242553 instanceof Ae))return!0x1;const _0x750dc9=this['_repo']===_0x242553['_repo'],_0x5ec8e1=Ki(this['_path'],_0x242553['_path']),_0xb6afb9=this['_queryIdentifier']===_0x242553['_queryIdentifier'];return _0x750dc9&&_0x5ec8e1&&_0xb6afb9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x457536,_0x8b7dfd){if(_0x457536['_orderByCalled']===!0x0)throw new Error(_0x8b7dfd+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4d8fb0){let _0x44d2d1=null,_0x572a7c=null;if(_0x4d8fb0['hasStart']()&&(_0x44d2d1=_0x4d8fb0['getIndexStartValue']()),_0x4d8fb0['hasEnd']()&&(_0x572a7c=_0x4d8fb0['getIndexEndValue']()),_0x4d8fb0['getIndex']()===ve){const _0x3399d4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4e1521='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4d8fb0['hasStart']()){if(_0x4d8fb0['getIndexStartName']()!==We)throw new Error(_0x3399d4);if(typeof _0x44d2d1!='string')throw new Error(_0x4e1521);}if(_0x4d8fb0['hasEnd']()){if(_0x4d8fb0['getIndexEndName']()!==we)throw new Error(_0x3399d4);if(typeof _0x572a7c!='string')throw new Error(_0x4e1521);}}else{if(_0x4d8fb0['getIndex']()===R){if(_0x44d2d1!=null&&!Bt(_0x44d2d1)||_0x572a7c!=null&&!Bt(_0x572a7c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4d8fb0['getIndex']()instanceof Ji||_0x4d8fb0['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x44d2d1!=null&&typeof _0x44d2d1=='object'||_0x572a7c!=null&&typeof _0x572a7c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3fdb1c){if(_0x3fdb1c['hasStart']()&&_0x3fdb1c['hasEnd']()&&_0x3fdb1c['hasLimit']()&&!_0x3fdb1c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x7bb8b6,_0x11a79a){super(_0x7bb8b6,_0x11a79a,new Zi(),!0x1);}get['parent'](){const _0x49ea84=Ro(this['_path']);return _0x49ea84===null?null:new ee(this['_repo'],_0x49ea84);}get['root'](){let _0x5bafae=this;for(;_0x5bafae['parent']!==null;)_0x5bafae=_0x5bafae['parent'];return _0x5bafae;}}class lt{constructor(_0x6f0076,_0xbb89c2,_0x1e406b){this['_node']=_0x6f0076,this['ref']=_0xbb89c2,this['_index']=_0x1e406b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x385ad1){const _0x37d947=new C(_0x385ad1),_0x326481=Vt(this['ref'],_0x385ad1);return new lt(this['_node']['getChild'](_0x37d947),_0x326481,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x57998f){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5ee855,_0x48fc9d)=>_0x57998f(new lt(_0x48fc9d,Vt(this['ref'],_0x5ee855),R)));}['hasChild'](_0xaa7799){const _0xc7d1d9=new C(_0xaa7799);return!this['_node']['getChild'](_0xc7d1d9)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1df275,_0x3d1421){return _0x1df275=P(_0x1df275),_0x1df275['_checkNotDeleted']('ref'),_0x3d1421!==void 0x0?Vt(_0x1df275['_root'],_0x3d1421):_0x1df275['_root'];}function Vt(_0x309b43,_0xbbc5ec){return _0x309b43=P(_0x309b43),y(_0x309b43['_path'])===null?pd('child','path',_0xbbc5ec):ys('child','path',_0xbbc5ec),new ee(_0x309b43['_repo'],k(_0x309b43['_path'],_0xbbc5ec));}function v_(_0x53d2b1){return _0x53d2b1=P(_0x53d2b1),new Vd(_0x53d2b1['_repo'],_0x53d2b1['_path']);}function E_(_0x4b31b3,_0x242e34){_0x4b31b3=P(_0x4b31b3),Me('push',_0x4b31b3['_path']),He('push',_0x242e34,_0x4b31b3['_path'],!0x0);const _0xec8781=la(_0x4b31b3['_repo']),_0x502d3f=Ud(_0xec8781),_0x195820=Vt(_0x4b31b3,_0x502d3f),_0x327c11=Vt(_0x4b31b3,_0x502d3f);let _0x2c4918;return _0x242e34!=null?_0x2c4918=Hd(_0x327c11,_0x242e34)['then'](()=>_0x327c11):_0x2c4918=Promise['resolve'](_0x327c11),_0x195820['then']=_0x2c4918['then']['bind'](_0x2c4918),_0x195820['catch']=_0x2c4918['then']['bind'](_0x2c4918,void 0x0),_0x195820;}function Hd(_0x3baf54,_0x20b43e){_0x3baf54=P(_0x3baf54),Me('set',_0x3baf54['_path']),He('set',_0x20b43e,_0x3baf54['_path'],!0x1);const _0x9aeafb=new H();return Cd(_0x3baf54['_repo'],_0x3baf54['_path'],_0x20b43e,null,_0x9aeafb['wrapCallback'](()=>{})),_0x9aeafb['promise'];}function I_(_0x4840eb,_0x3a8539){ra('update',_0x3a8539,_0x4840eb['_path']);const _0x1e2a06=new H();return Td(_0x4840eb['_repo'],_0x4840eb['_path'],_0x3a8539,_0x1e2a06['wrapCallback'](()=>{})),_0x1e2a06['promise'];}function w_(_0x3b14ed){_0x3b14ed=P(_0x3b14ed);const _0x3c75b3=new pa(()=>{}),_0x221b59=new Qn(_0x3c75b3);return wd(_0x3b14ed['_repo'],_0x3b14ed,_0x221b59)['then'](_0x479086=>new lt(_0x479086,new ee(_0x3b14ed['_repo'],_0x3b14ed['_path']),_0x3b14ed['_queryParams']['getIndex']()));}class Qn{constructor(_0x6e8709){this['callbackContext']=_0x6e8709;}['respondsTo'](_0x51e26f){return _0x51e26f==='value';}['createEvent'](_0x3b770a,_0x1ac779){const _0x4c855c=_0x1ac779['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x3b770a['snapshotNode'],new ee(_0x1ac779['_repo'],_0x1ac779['_path']),_0x4c855c));}['getEventRunner'](_0x59a260){return _0x59a260['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x59a260['error']):()=>this['callbackContext']['onValue'](_0x59a260['snapshot'],null);}['createCancelEvent'](_0x42eff0,_0x4e499f){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x42eff0,_0x4e499f):null;}['matches'](_0x2260f8){return _0x2260f8 instanceof Qn?!_0x2260f8['callbackContext']||!this['callbackContext']?!0x0:_0x2260f8['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x45c37f,_0x28a8ea,_0x2123b6,_0x1e51fa,_0x2e7375){const _0x2c04b9=new pa(_0x2123b6,void 0x0),_0x3c2603=new Qn(_0x2c04b9);return kd(_0x45c37f['_repo'],_0x45c37f,_0x3c2603),()=>Pd(_0x45c37f['_repo'],_0x45c37f,_0x3c2603);}function Gd(_0x2b3b01,_0x2306dd,_0x165c9b,_0x14b844){return $d(_0x2b3b01,'value',_0x2306dd);}class mt{}class ma extends mt{constructor(_0x285ab7,_0x6fd75a){super(),this['_value']=_0x285ab7,this['_key']=_0x6fd75a,this['type']='endAt';}['_apply'](_0x227f9f){He('endAt',this['_value'],_0x227f9f['_path'],!0x0);const _0x1fc8e4=Jh(_0x227f9f['_queryParams'],this['_value'],this['_key']);if(ga(_0x1fc8e4),Yn(_0x1fc8e4),_0x227f9f['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x227f9f['_repo'],_0x227f9f['_path'],_0x1fc8e4,_0x227f9f['_orderByCalled']);}}function C_(_0x264f65,_0x2e1b98){return new ma(_0x264f65,_0x2e1b98);}class ya extends mt{constructor(_0x26ef65,_0x334732){super(),this['_value']=_0x26ef65,this['_key']=_0x334732,this['type']='startAt';}['_apply'](_0x16031b){He('startAt',this['_value'],_0x16031b['_path'],!0x0);const _0x3b107f=Qh(_0x16031b['_queryParams'],this['_value'],this['_key']);if(ga(_0x3b107f),Yn(_0x3b107f),_0x16031b['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x16031b['_repo'],_0x16031b['_path'],_0x3b107f,_0x16031b['_orderByCalled']);}}function T_(_0x590f34=null,_0x395cf5){return new ya(_0x590f34,_0x395cf5);}class qd extends mt{constructor(_0x5b54c6){super(),this['_limit']=_0x5b54c6,this['type']='limitToFirst';}['_apply'](_0x3b1101){if(_0x3b1101['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x3b1101['_repo'],_0x3b1101['_path'],Yh(_0x3b1101['_queryParams'],this['_limit']),_0x3b1101['_orderByCalled']);}}function S_(_0x3b8fcb){if(Math['floor'](_0x3b8fcb)!==_0x3b8fcb||_0x3b8fcb<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3b8fcb);}class zd extends mt{constructor(_0x3775b8){super(),this['_path']=_0x3775b8,this['type']='orderByChild';}['_apply'](_0x178f09){_a(_0x178f09,'orderByChild');const _0x3e6cc8=new C(this['_path']);if(v(_0x3e6cc8))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2374ab=new Ji(_0x3e6cc8),_0x4f3107=xo(_0x178f09['_queryParams'],_0x2374ab);return Yn(_0x4f3107),new Ae(_0x178f09['_repo'],_0x178f09['_path'],_0x4f3107,!0x0);}}function b_(_0x831962){if(_0x831962==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x831962==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x831962==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x831962),new zd(_0x831962);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1b3cfa){_a(_0x1b3cfa,'orderByKey');const _0x3c2138=xo(_0x1b3cfa['_queryParams'],ve);return Yn(_0x3c2138),new Ae(_0x1b3cfa['_repo'],_0x1b3cfa['_path'],_0x3c2138,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x350459,_0x32b3c8){super(),this['_value']=_0x350459,this['_key']=_0x32b3c8,this['type']='equalTo';}['_apply'](_0x2d2d73){if(He('equalTo',this['_value'],_0x2d2d73['_path'],!0x1),_0x2d2d73['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2d2d73['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2d2d73));}}function A_(_0x365a84,_0x5155b7){return new Kd(_0x365a84,_0x5155b7);}function k_(_0x864865,..._0x37aae3){let _0x347745=P(_0x864865);for(const _0x638a01 of _0x37aae3)_0x347745=_0x638a01['_apply'](_0x347745);return _0x347745;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4894e7,_0x3136e7,_0x854c6e,_0x4450e9){const _0xef6bbf=_0x3136e7['lastIndexOf'](':'),_0x198f7a=_0x3136e7['substring'](0x0,_0xef6bbf),_0x533c3a=qt(_0x198f7a);_0x4894e7['repoInfo_']=new yo(_0x3136e7,_0x533c3a,_0x4894e7['repoInfo_']['namespace'],_0x4894e7['repoInfo_']['webSocketOnly'],_0x4894e7['repoInfo_']['nodeAdmin'],_0x4894e7['repoInfo_']['persistenceKey'],_0x4894e7['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x854c6e),_0x4450e9&&(_0x4894e7['authTokenProvider_']=_0x4450e9);}function Xd(_0x4251e7,_0x56c245,_0x5e631a,_0x1a400e,_0xb0f574){let _0x2d6878=_0x1a400e||_0x4251e7['options']['databaseURL'];_0x2d6878===void 0x0&&(_0x4251e7['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4251e7['options']['projectId']),_0x2d6878=_0x4251e7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x13012f=vr(_0x2d6878,_0xb0f574),_0x3d6846=_0x13012f['repoInfo'],_0x48d34a;typeof process<'u'&&Bs&&(_0x48d34a=Bs[Yd]),_0x48d34a?(_0x2d6878='http://'+_0x48d34a+'?ns='+_0x3d6846['namespace'],_0x13012f=vr(_0x2d6878,_0xb0f574),_0x3d6846=_0x13012f['repoInfo']):_0x13012f['repoInfo']['secure'];const _0xe3f9cd=new eh(_0x4251e7['name'],_0x4251e7['options'],_0x56c245);_d('Invalid\x20Firebase\x20Database\x20URL',_0x13012f),v(_0x13012f['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x42cd02=ef(_0x3d6846,_0x4251e7,_0xe3f9cd,new Zl(_0x4251e7,_0x5e631a));return new tf(_0x42cd02,_0x4251e7);}function Zd(_0x347dda,_0x3b4c57){const _0x29ad9d=Di[_0x3b4c57];(!_0x29ad9d||_0x29ad9d[_0x347dda['key']]!==_0x347dda)&&ae('Database\x20'+_0x3b4c57+'('+_0x347dda['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x347dda),delete _0x29ad9d[_0x347dda['key']];}function ef(_0x2b6b06,_0x53ad32,_0x4c0647,_0x14e7a1){let _0x56e05b=Di[_0x53ad32['name']];_0x56e05b||(_0x56e05b={},Di[_0x53ad32['name']]=_0x56e05b);let _0x138e81=_0x56e05b[_0x2b6b06['toURLString']()];return _0x138e81&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x138e81=new vd(_0x2b6b06,Qd,_0x4c0647,_0x14e7a1),_0x56e05b[_0x2b6b06['toURLString']()]=_0x138e81,_0x138e81;}class tf{constructor(_0x150c31,_0x1fc2c8){this['_repoInternal']=_0x150c31,this['app']=_0x1fc2c8,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x53f407){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x53f407+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x114c73=Zr(),_0x35dd8d){const _0x414c34=Hi(_0x114c73,'database')['getImmediate']({'identifier':_0x35dd8d});if(!_0x414c34['_instanceStarted']){const _0x1adb5c=hc('database');_0x1adb5c&&nf(_0x414c34,..._0x1adb5c);}return _0x414c34;}function nf(_0xa754d7,_0x7356c1,_0x5c689e,_0x3b447d={}){_0xa754d7=P(_0xa754d7),_0xa754d7['_checkNotDeleted']('useEmulator');const _0x597fa1=_0x7356c1+':'+_0x5c689e,_0x2fce58=_0xa754d7['_repoInternal'];if(_0xa754d7['_instanceStarted']){if(_0x597fa1===_0xa754d7['_repoInternal']['repoInfo_']['host']&&xe(_0x3b447d,_0x2fce58['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x608a58;if(_0x2fce58['repoInfo_']['nodeAdmin'])_0x3b447d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x608a58=new an(an['OWNER']);else{if(_0x3b447d['mockUserToken']){const _0x21f664=typeof _0x3b447d['mockUserToken']=='string'?_0x3b447d['mockUserToken']:uc(_0x3b447d['mockUserToken'],_0xa754d7['app']['options']['projectId']);_0x608a58=new an(_0x21f664);}}qt(_0x7356c1)&&Qr(_0x7356c1),Jd(_0x2fce58,_0x597fa1,_0x3b447d,_0x608a58);}function N_(_0x5299e4){_0x5299e4=P(_0x5299e4),_0x5299e4['_checkNotDeleted']('goOffline'),ha(_0x5299e4['_repo']);}function O_(_0x435f89){_0x435f89=P(_0x435f89),_0x435f89['_checkNotDeleted']('goOnline'),Nd(_0x435f89['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x2571c6){Ul(dt),st(new Fe('database',(_0x67dfdc,{instanceIdentifier:_0x1ea76c})=>{const _0x38e626=_0x67dfdc['getProvider']('app')['getImmediate'](),_0x136e9d=_0x67dfdc['getProvider']('auth-internal'),_0x318738=_0x67dfdc['getProvider']('app-check-internal');return Xd(_0x38e626,_0x136e9d,_0x318738,_0x1ea76c);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x2571c6),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0xb69a1b,_0x4febbc){this['committed']=_0xb69a1b,this['snapshot']=_0x4febbc;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x3aefc3,_0x19fb84,_0xc9750e){if(_0x3aefc3=P(_0x3aefc3),Me('Reference.transaction',_0x3aefc3['_path']),_0x3aefc3['key']==='.length'||_0x3aefc3['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3aefc3['key']+'\x20is\x20a\x20read-only\x20object.';const _0xe774ba=!0x0,_0x3eab7d=new H(),_0x3979a5=(_0x1cf5a8,_0x5ab73a,_0x3334ed)=>{let _0x10bb26=null;_0x1cf5a8?_0x3eab7d['reject'](_0x1cf5a8):(_0x10bb26=new lt(_0x3334ed,new ee(_0x3aefc3['_repo'],_0x3aefc3['_path']),R),_0x3eab7d['resolve'](new of(_0x5ab73a,_0x10bb26)));},_0x4de202=Gd(_0x3aefc3,()=>{});return Od(_0x3aefc3['_repo'],_0x3aefc3['_path'],_0x19fb84,_0x3979a5,_0x4de202,_0xe774ba),_0x3eab7d['promise'];}se['prototype']['simpleListen']=function(_0x2e0065,_0xdf0c8){this['sendRequest']('q',{'p':_0x2e0065},_0xdf0c8);},se['prototype']['echo']=function(_0x319180,_0x1401cf){this['sendRequest']('echo',{'d':_0x319180},_0x1401cf);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x4d2351,..._0x2286fd){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x4d2351,..._0x2286fd);}function cn(_0x24b990,..._0xaff19e){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x24b990,..._0xaff19e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1bdda9,..._0x195174){throw ws(_0x1bdda9,..._0x195174);}function X(_0x47c4e3,..._0x5e0348){return ws(_0x47c4e3,..._0x5e0348);}function Ia(_0x41c0d1,_0x5b83aa,_0x17dea2){const _0x163d68={...af(),[_0x5b83aa]:_0x17dea2};return new Gt('auth','Firebase',_0x163d68)['create'](_0x5b83aa,{'appName':_0x41c0d1['name']});}function re(_0x3ffe7e){return Ia(_0x3ffe7e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x413e43,..._0x3fdd84){if(typeof _0x413e43!='string'){const _0x291118=_0x3fdd84[0x0],_0x2f2df9=[..._0x3fdd84['slice'](0x1)];return _0x2f2df9[0x0]&&(_0x2f2df9[0x0]['appName']=_0x413e43['name']),_0x413e43['_errorFactory']['create'](_0x291118,..._0x2f2df9);}return Ea['create'](_0x413e43,..._0x3fdd84);}function m(_0x194c8d,_0x29549a,..._0xd30612){if(!_0x194c8d)throw ws(_0x29549a,..._0xd30612);}function ne(_0x228ee5){const _0x28ac58='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x228ee5;throw cn(_0x28ac58),new Error(_0x28ac58);}function ce(_0x2180a4,_0x1e4bf2){_0x2180a4||ne(_0x1e4bf2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3f431a;return typeof self<'u'&&((_0x3f431a=self['location'])==null?void 0x0:_0x3f431a['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x4ec4f0;return typeof self<'u'&&((_0x4ec4f0=self['location'])==null?void 0x0:_0x4ec4f0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x11cbd9=navigator;return _0x11cbd9['languages']&&_0x11cbd9['languages'][0x0]||_0x11cbd9['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x223c6f,_0x2f2ad9){this['shortDelay']=_0x223c6f,this['longDelay']=_0x2f2ad9,ce(_0x2f2ad9>_0x223c6f,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xf2c993,_0x4d0bd2){ce(_0xf2c993['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x90a35c}=_0xf2c993['emulator'];return _0x4d0bd2?''+_0x90a35c+(_0x4d0bd2['startsWith']('/')?_0x4d0bd2['slice'](0x1):_0x4d0bd2):_0x90a35c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x5a6fe0,_0x165952,_0x4414a9){this['fetchImpl']=_0x5a6fe0,_0x165952&&(this['headersImpl']=_0x165952),_0x4414a9&&(this['responseImpl']=_0x4414a9);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4d7191,_0x14df9b){return _0x4d7191['tenantId']&&!_0x14df9b['tenantId']?{..._0x14df9b,'tenantId':_0x4d7191['tenantId']}:_0x14df9b;}async function Pe(_0x4e42a7,_0x58a131,_0x2448aa,_0x2cde3a,_0x48f966={}){return Ca(_0x4e42a7,_0x48f966,async()=>{let _0x69cbb0={},_0xea21db={};_0x2cde3a&&(_0x58a131==='GET'?_0xea21db=_0x2cde3a:_0x69cbb0={'body':JSON['stringify'](_0x2cde3a)});const _0x3a9113=ut({..._0xea21db,'key':_0x4e42a7['config']['apiKey']})['slice'](0x1),_0x3273bd=await _0x4e42a7['_getAdditionalHeaders']();_0x3273bd['Content-Type']='application/json',_0x4e42a7['languageCode']&&(_0x3273bd['X-Firebase-Locale']=_0x4e42a7['languageCode']);const _0x24f78e={'method':_0x58a131,'headers':_0x3273bd,..._0x69cbb0};return dc()||(_0x24f78e['referrerPolicy']='strict-origin-when-cross-origin'),_0x4e42a7['emulatorConfig']&&qt(_0x4e42a7['emulatorConfig']['host'])&&(_0x24f78e['credentials']='include'),wa['fetch']()(await Ta(_0x4e42a7,_0x4e42a7['config']['apiHost'],_0x2448aa,_0x3a9113),_0x24f78e);});}async function Ca(_0x427666,_0x4c6a19,_0x3f461d){_0x427666['_canInitEmulator']=!0x1;const _0x3f684a={...df,..._0x4c6a19};try{const _0x55c344=new gf(_0x427666),_0x1323ef=await Promise['race']([_0x3f461d(),_0x55c344['promise']]);_0x55c344['clearNetworkTimeout']();const _0x4eff6a=await _0x1323ef['json']();if('needConfirmation'in _0x4eff6a)throw on(_0x427666,'account-exists-with-different-credential',_0x4eff6a);if(_0x1323ef['ok']&&!('errorMessage'in _0x4eff6a))return _0x4eff6a;{const _0x8c12cf=_0x1323ef['ok']?_0x4eff6a['errorMessage']:_0x4eff6a['error']['message'],[_0xc60488,_0x54e70e]=_0x8c12cf['split']('\x20:\x20');if(_0xc60488==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x427666,'credential-already-in-use',_0x4eff6a);if(_0xc60488==='EMAIL_EXISTS')throw on(_0x427666,'email-already-in-use',_0x4eff6a);if(_0xc60488==='USER_DISABLED')throw on(_0x427666,'user-disabled',_0x4eff6a);const _0x3f6a5a=_0x3f684a[_0xc60488]||_0xc60488['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x54e70e)throw Ia(_0x427666,_0x3f6a5a,_0x54e70e);Y(_0x427666,_0x3f6a5a);}}catch(_0x288ad4){if(_0x288ad4 instanceof Re)throw _0x288ad4;Y(_0x427666,'network-request-failed',{'message':String(_0x288ad4)});}}async function en(_0x4ac19c,_0x28a1ed,_0x391282,_0x44f433,_0x36b5d3={}){const _0x23b2a1=await Pe(_0x4ac19c,_0x28a1ed,_0x391282,_0x44f433,_0x36b5d3);return'mfaPendingCredential'in _0x23b2a1&&Y(_0x4ac19c,'multi-factor-auth-required',{'_serverResponse':_0x23b2a1}),_0x23b2a1;}async function Ta(_0x203c82,_0x3fba66,_0x5b71d3,_0x464eda){const _0x1cb07d=''+_0x3fba66+_0x5b71d3+'?'+_0x464eda,_0x24fd2b=_0x203c82,_0x23849c=_0x24fd2b['config']['emulator']?Cs(_0x203c82['config'],_0x1cb07d):_0x203c82['config']['apiScheme']+'://'+_0x1cb07d;return ff['includes'](_0x5b71d3)&&(await _0x24fd2b['_persistenceManagerAvailable'],_0x24fd2b['_getPersistenceType']()==='COOKIE')?_0x24fd2b['_getPersistence']()['_getFinalTarget'](_0x23849c)['toString']():_0x23849c;}function _f(_0x5b0d77){switch(_0x5b0d77){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x42a017){this['auth']=_0x42a017,this['timer']=null,this['promise']=new Promise((_0x45ec6d,_0x519113)=>{this['timer']=setTimeout(()=>_0x519113(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0xb01559,_0x5e3c1c,_0x541374){const _0x19e350={'appName':_0xb01559['name']};_0x541374['email']&&(_0x19e350['email']=_0x541374['email']),_0x541374['phoneNumber']&&(_0x19e350['phoneNumber']=_0x541374['phoneNumber']);const _0x10b12a=X(_0xb01559,_0x5e3c1c,_0x19e350);return _0x10b12a['customData']['_tokenResponse']=_0x541374,_0x10b12a;}function wr(_0x27c189){return _0x27c189!==void 0x0&&_0x27c189['enterprise']!==void 0x0;}class mf{constructor(_0x49067f){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x49067f['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x49067f['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x49067f['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x473711){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x1052be of this['recaptchaEnforcementState'])if(_0x1052be['provider']&&_0x1052be['provider']===_0x473711)return _f(_0x1052be['enforcementState']);return null;}['isProviderEnabled'](_0x217149){return this['getProviderEnforcementState'](_0x217149)==='ENFORCE'||this['getProviderEnforcementState'](_0x217149)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5691bd,_0x2510ac){return Pe(_0x5691bd,'GET','/v2/recaptchaConfig',ke(_0x5691bd,_0x2510ac));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3322d9,_0x5007ff){return Pe(_0x3322d9,'POST','/v1/accounts:delete',_0x5007ff);}async function Pn(_0x468725,_0x52aaef){return Pe(_0x468725,'POST','/v1/accounts:lookup',_0x52aaef);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x5d8770){if(_0x5d8770)try{const _0x2fb9ab=new Date(Number(_0x5d8770));if(!isNaN(_0x2fb9ab['getTime']()))return _0x2fb9ab['toUTCString']();}catch{}}async function Ef(_0x358cab,_0x44d697=!0x1){const _0x32dfed=P(_0x358cab),_0x5d1859=await _0x32dfed['getIdToken'](_0x44d697),_0x581845=Ts(_0x5d1859);m(_0x581845&&_0x581845['exp']&&_0x581845['auth_time']&&_0x581845['iat'],_0x32dfed['auth'],'internal-error');const _0x462eda=typeof _0x581845['firebase']=='object'?_0x581845['firebase']:void 0x0,_0x14c299=_0x462eda==null?void 0x0:_0x462eda['sign_in_provider'];return{'claims':_0x581845,'token':_0x5d1859,'authTime':Pt(fi(_0x581845['auth_time'])),'issuedAtTime':Pt(fi(_0x581845['iat'])),'expirationTime':Pt(fi(_0x581845['exp'])),'signInProvider':_0x14c299||null,'signInSecondFactor':(_0x462eda==null?void 0x0:_0x462eda['sign_in_second_factor'])||null};}function fi(_0x2c71d6){return Number(_0x2c71d6)*0x3e8;}function Ts(_0x3a8f07){const [_0x5b444b,_0x89b858,_0x348ce3]=_0x3a8f07['split']('.');if(_0x5b444b===void 0x0||_0x89b858===void 0x0||_0x348ce3===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4a5316=fn(_0x89b858);return _0x4a5316?JSON['parse'](_0x4a5316):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3629d0){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3629d0==null?void 0x0:_0x3629d0['toString']()),null;}}function Cr(_0x11ce05){const _0x39dbbd=Ts(_0x11ce05);return m(_0x39dbbd,'internal-error'),m(typeof _0x39dbbd['exp']<'u','internal-error'),m(typeof _0x39dbbd['iat']<'u','internal-error'),Number(_0x39dbbd['exp'])-Number(_0x39dbbd['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x297c6c,_0x4298c0,_0x30a3f5=!0x1){if(_0x30a3f5)return _0x4298c0;try{return await _0x4298c0;}catch(_0x33c985){throw _0x33c985 instanceof Re&&If(_0x33c985)&&_0x297c6c['auth']['currentUser']===_0x297c6c&&await _0x297c6c['auth']['signOut'](),_0x33c985;}}function If({code:_0x272094}){return _0x272094==='auth/user-disabled'||_0x272094==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x1fff6c){this['user']=_0x1fff6c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2c253e){if(_0x2c253e){const _0x368aba=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x368aba;}else{this['errorBackoff']=0x7530;const _0x315c64=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x315c64);}}['schedule'](_0x472d23=!0x1){if(!this['isRunning'])return;const _0x207069=this['getInterval'](_0x472d23);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x207069);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x33b591){(_0x33b591==null?void 0x0:_0x33b591['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x5c6001,_0x4c8b2d){this['createdAt']=_0x5c6001,this['lastLoginAt']=_0x4c8b2d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x3fc7be){this['createdAt']=_0x3fc7be['createdAt'],this['lastLoginAt']=_0x3fc7be['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2ec334){var _0x336913;const _0x282322=_0x2ec334['auth'],_0x4d1b40=await _0x2ec334['getIdToken'](),_0x5556c6=await Ht(_0x2ec334,Pn(_0x282322,{'idToken':_0x4d1b40}));m(_0x5556c6==null?void 0x0:_0x5556c6['users']['length'],_0x282322,'internal-error');const _0x526d12=_0x5556c6['users'][0x0];_0x2ec334['_notifyReloadListener'](_0x526d12);const _0x5ead00=(_0x336913=_0x526d12['providerUserInfo'])!=null&&_0x336913['length']?Sa(_0x526d12['providerUserInfo']):[],_0x58c7c6=Tf(_0x2ec334['providerData'],_0x5ead00),_0x40d29d=_0x2ec334['isAnonymous'],_0xeb91b0=!(_0x2ec334['email']&&_0x526d12['passwordHash'])&&!(_0x58c7c6!=null&&_0x58c7c6['length']),_0x1298e9=_0x40d29d?_0xeb91b0:!0x1,_0x491315={'uid':_0x526d12['localId'],'displayName':_0x526d12['displayName']||null,'photoURL':_0x526d12['photoUrl']||null,'email':_0x526d12['email']||null,'emailVerified':_0x526d12['emailVerified']||!0x1,'phoneNumber':_0x526d12['phoneNumber']||null,'tenantId':_0x526d12['tenantId']||null,'providerData':_0x58c7c6,'metadata':new Li(_0x526d12['createdAt'],_0x526d12['lastLoginAt']),'isAnonymous':_0x1298e9};Object['assign'](_0x2ec334,_0x491315);}async function Cf(_0x377b5e){const _0xc5533c=P(_0x377b5e);await Nn(_0xc5533c),await _0xc5533c['auth']['_persistUserIfCurrent'](_0xc5533c),_0xc5533c['auth']['_notifyListenersIfCurrent'](_0xc5533c);}function Tf(_0x246935,_0xbef1f7){return[..._0x246935['filter'](_0x32b9a3=>!_0xbef1f7['some'](_0x5b9bda=>_0x5b9bda['providerId']===_0x32b9a3['providerId'])),..._0xbef1f7];}function Sa(_0x485070){return _0x485070['map'](({providerId:_0x256e08,..._0x3f9c96})=>({'providerId':_0x256e08,'uid':_0x3f9c96['rawId']||'','displayName':_0x3f9c96['displayName']||null,'email':_0x3f9c96['email']||null,'phoneNumber':_0x3f9c96['phoneNumber']||null,'photoURL':_0x3f9c96['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x42b119,_0x2084dc){const _0x585aa0=await Ca(_0x42b119,{},async()=>{const _0x26a757=ut({'grant_type':'refresh_token','refresh_token':_0x2084dc})['slice'](0x1),{tokenApiHost:_0x3cc6a1,apiKey:_0x2edc0a}=_0x42b119['config'],_0xf64ead=await Ta(_0x42b119,_0x3cc6a1,'/v1/token','key='+_0x2edc0a),_0x50b9c9=await _0x42b119['_getAdditionalHeaders']();_0x50b9c9['Content-Type']='application/x-www-form-urlencoded';const _0x251603={'method':'POST','headers':_0x50b9c9,'body':_0x26a757};return _0x42b119['emulatorConfig']&&qt(_0x42b119['emulatorConfig']['host'])&&(_0x251603['credentials']='include'),wa['fetch']()(_0xf64ead,_0x251603);});return{'accessToken':_0x585aa0['access_token'],'expiresIn':_0x585aa0['expires_in'],'refreshToken':_0x585aa0['refresh_token']};}async function bf(_0x3bce44,_0x54ba92){return Pe(_0x3bce44,'POST','/v2/accounts:revokeToken',ke(_0x3bce44,_0x54ba92));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1b1f27){m(_0x1b1f27['idToken'],'internal-error'),m(typeof _0x1b1f27['idToken']<'u','internal-error'),m(typeof _0x1b1f27['refreshToken']<'u','internal-error');const _0x4b20fa='expiresIn'in _0x1b1f27&&typeof _0x1b1f27['expiresIn']<'u'?Number(_0x1b1f27['expiresIn']):Cr(_0x1b1f27['idToken']);this['updateTokensAndExpiration'](_0x1b1f27['idToken'],_0x1b1f27['refreshToken'],_0x4b20fa);}['updateFromIdToken'](_0x3039f6){m(_0x3039f6['length']!==0x0,'internal-error');const _0x1db402=Cr(_0x3039f6);this['updateTokensAndExpiration'](_0x3039f6,null,_0x1db402);}async['getToken'](_0x1d1156,_0xec0be8=!0x1){return!_0xec0be8&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1d1156,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1d1156,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x293ac2,_0x267ecc){const {accessToken:_0x3415c3,refreshToken:_0x452fef,expiresIn:_0x57c90a}=await Sf(_0x293ac2,_0x267ecc);this['updateTokensAndExpiration'](_0x3415c3,_0x452fef,Number(_0x57c90a));}['updateTokensAndExpiration'](_0x43266d,_0x10a11e,_0x3d992f){this['refreshToken']=_0x10a11e||null,this['accessToken']=_0x43266d||null,this['expirationTime']=Date['now']()+_0x3d992f*0x3e8;}static['fromJSON'](_0x30a566,_0x1554b1){const {refreshToken:_0x33de88,accessToken:_0x5db2ee,expirationTime:_0x54b669}=_0x1554b1,_0x469884=new et();return _0x33de88&&(m(typeof _0x33de88=='string','internal-error',{'appName':_0x30a566}),_0x469884['refreshToken']=_0x33de88),_0x5db2ee&&(m(typeof _0x5db2ee=='string','internal-error',{'appName':_0x30a566}),_0x469884['accessToken']=_0x5db2ee),_0x54b669&&(m(typeof _0x54b669=='number','internal-error',{'appName':_0x30a566}),_0x469884['expirationTime']=_0x54b669),_0x469884;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x122767){this['accessToken']=_0x122767['accessToken'],this['refreshToken']=_0x122767['refreshToken'],this['expirationTime']=_0x122767['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xf0d71e,_0x1d94c2){m(typeof _0xf0d71e=='string'||typeof _0xf0d71e>'u','internal-error',{'appName':_0x1d94c2});}class j{constructor({uid:_0x2453ca,auth:_0x20e8fe,stsTokenManager:_0xb2ece1,..._0x2e8189}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2453ca,this['auth']=_0x20e8fe,this['stsTokenManager']=_0xb2ece1,this['accessToken']=_0xb2ece1['accessToken'],this['displayName']=_0x2e8189['displayName']||null,this['email']=_0x2e8189['email']||null,this['emailVerified']=_0x2e8189['emailVerified']||!0x1,this['phoneNumber']=_0x2e8189['phoneNumber']||null,this['photoURL']=_0x2e8189['photoURL']||null,this['isAnonymous']=_0x2e8189['isAnonymous']||!0x1,this['tenantId']=_0x2e8189['tenantId']||null,this['providerData']=_0x2e8189['providerData']?[..._0x2e8189['providerData']]:[],this['metadata']=new Li(_0x2e8189['createdAt']||void 0x0,_0x2e8189['lastLoginAt']||void 0x0);}async['getIdToken'](_0x42bd0b){const _0x1cf5fa=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x42bd0b));return m(_0x1cf5fa,this['auth'],'internal-error'),this['accessToken']!==_0x1cf5fa&&(this['accessToken']=_0x1cf5fa,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1cf5fa;}['getIdTokenResult'](_0x58df4e){return Ef(this,_0x58df4e);}['reload'](){return Cf(this);}['_assign'](_0x28ca5b){this!==_0x28ca5b&&(m(this['uid']===_0x28ca5b['uid'],this['auth'],'internal-error'),this['displayName']=_0x28ca5b['displayName'],this['photoURL']=_0x28ca5b['photoURL'],this['email']=_0x28ca5b['email'],this['emailVerified']=_0x28ca5b['emailVerified'],this['phoneNumber']=_0x28ca5b['phoneNumber'],this['isAnonymous']=_0x28ca5b['isAnonymous'],this['tenantId']=_0x28ca5b['tenantId'],this['providerData']=_0x28ca5b['providerData']['map'](_0xeace9d=>({..._0xeace9d})),this['metadata']['_copy'](_0x28ca5b['metadata']),this['stsTokenManager']['_assign'](_0x28ca5b['stsTokenManager']));}['_clone'](_0x4a24c4){const _0x14d8c7=new j({...this,'auth':_0x4a24c4,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x14d8c7['metadata']['_copy'](this['metadata']),_0x14d8c7;}['_onReload'](_0x3eaa85){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x3eaa85,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x41560e){this['reloadListener']?this['reloadListener'](_0x41560e):this['reloadUserInfo']=_0x41560e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xe1b4f,_0x1c4195=!0x1){let _0x440c3e=!0x1;_0xe1b4f['idToken']&&_0xe1b4f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xe1b4f),_0x440c3e=!0x0),_0x1c4195&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x440c3e&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x24a97f=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x24a97f})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4e2f08=>({..._0x4e2f08})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x49e201,_0x1e048f){const _0x52e316=_0x1e048f['displayName']??void 0x0,_0x4ee6c9=_0x1e048f['email']??void 0x0,_0x26b0b2=_0x1e048f['phoneNumber']??void 0x0,_0x5d00a4=_0x1e048f['photoURL']??void 0x0,_0x15f652=_0x1e048f['tenantId']??void 0x0,_0x21d2fa=_0x1e048f['_redirectEventId']??void 0x0,_0x404e2e=_0x1e048f['createdAt']??void 0x0,_0x5193ca=_0x1e048f['lastLoginAt']??void 0x0,{uid:_0x39e785,emailVerified:_0x30ffb4,isAnonymous:_0x373a57,providerData:_0x297292,stsTokenManager:_0x71f669}=_0x1e048f;m(_0x39e785&&_0x71f669,_0x49e201,'internal-error');const _0x5eee87=et['fromJSON'](this['name'],_0x71f669);m(typeof _0x39e785=='string',_0x49e201,'internal-error'),le(_0x52e316,_0x49e201['name']),le(_0x4ee6c9,_0x49e201['name']),m(typeof _0x30ffb4=='boolean',_0x49e201,'internal-error'),m(typeof _0x373a57=='boolean',_0x49e201,'internal-error'),le(_0x26b0b2,_0x49e201['name']),le(_0x5d00a4,_0x49e201['name']),le(_0x15f652,_0x49e201['name']),le(_0x21d2fa,_0x49e201['name']),le(_0x404e2e,_0x49e201['name']),le(_0x5193ca,_0x49e201['name']);const _0x282381=new j({'uid':_0x39e785,'auth':_0x49e201,'email':_0x4ee6c9,'emailVerified':_0x30ffb4,'displayName':_0x52e316,'isAnonymous':_0x373a57,'photoURL':_0x5d00a4,'phoneNumber':_0x26b0b2,'tenantId':_0x15f652,'stsTokenManager':_0x5eee87,'createdAt':_0x404e2e,'lastLoginAt':_0x5193ca});return _0x297292&&Array['isArray'](_0x297292)&&(_0x282381['providerData']=_0x297292['map'](_0x23e5a0=>({..._0x23e5a0}))),_0x21d2fa&&(_0x282381['_redirectEventId']=_0x21d2fa),_0x282381;}static async['_fromIdTokenResponse'](_0x2632a7,_0x57adc7,_0x24e53b=!0x1){const _0x428baf=new et();_0x428baf['updateFromServerResponse'](_0x57adc7);const _0x3fcc7d=new j({'uid':_0x57adc7['localId'],'auth':_0x2632a7,'stsTokenManager':_0x428baf,'isAnonymous':_0x24e53b});return await Nn(_0x3fcc7d),_0x3fcc7d;}static async['_fromGetAccountInfoResponse'](_0x5b4097,_0x1f853a,_0x5378ae){const _0x3fc797=_0x1f853a['users'][0x0];m(_0x3fc797['localId']!==void 0x0,'internal-error');const _0xfe513a=_0x3fc797['providerUserInfo']!==void 0x0?Sa(_0x3fc797['providerUserInfo']):[],_0x4b5bf8=!(_0x3fc797['email']&&_0x3fc797['passwordHash'])&&!(_0xfe513a!=null&&_0xfe513a['length']),_0x326516=new et();_0x326516['updateFromIdToken'](_0x5378ae);const _0x3ada24=new j({'uid':_0x3fc797['localId'],'auth':_0x5b4097,'stsTokenManager':_0x326516,'isAnonymous':_0x4b5bf8}),_0x3a5492={'uid':_0x3fc797['localId'],'displayName':_0x3fc797['displayName']||null,'photoURL':_0x3fc797['photoUrl']||null,'email':_0x3fc797['email']||null,'emailVerified':_0x3fc797['emailVerified']||!0x1,'phoneNumber':_0x3fc797['phoneNumber']||null,'tenantId':_0x3fc797['tenantId']||null,'providerData':_0xfe513a,'metadata':new Li(_0x3fc797['createdAt'],_0x3fc797['lastLoginAt']),'isAnonymous':!(_0x3fc797['email']&&_0x3fc797['passwordHash'])&&!(_0xfe513a!=null&&_0xfe513a['length'])};return Object['assign'](_0x3ada24,_0x3a5492),_0x3ada24;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1e0d86){ce(_0x1e0d86 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x54db4b=Tr['get'](_0x1e0d86);return _0x54db4b?(ce(_0x54db4b instanceof _0x1e0d86,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x54db4b):(_0x54db4b=new _0x1e0d86(),Tr['set'](_0x1e0d86,_0x54db4b),_0x54db4b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2cf46f,_0x16977c){this['storage'][_0x2cf46f]=_0x16977c;}async['_get'](_0x1d47d7){const _0xc2ba89=this['storage'][_0x1d47d7];return _0xc2ba89===void 0x0?null:_0xc2ba89;}async['_remove'](_0x14de77){delete this['storage'][_0x14de77];}['_addListener'](_0x692240,_0x1f3f91){}['_removeListener'](_0x55f05f,_0x4f3105){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3b4857,_0x2ed8ad,_0x105795){return'firebase:'+_0x3b4857+':'+_0x2ed8ad+':'+_0x105795;}class tt{constructor(_0x3d9f62,_0x4d1c3f,_0x4ca5f3){this['persistence']=_0x3d9f62,this['auth']=_0x4d1c3f,this['userKey']=_0x4ca5f3;const {config:_0x1d99ef,name:_0x4c0431}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x1d99ef['apiKey'],_0x4c0431),this['fullPersistenceKey']=ln('persistence',_0x1d99ef['apiKey'],_0x4c0431),this['boundEventHandler']=_0x4d1c3f['_onStorageEvent']['bind'](_0x4d1c3f),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x30a615){return this['persistence']['_set'](this['fullUserKey'],_0x30a615['toJSON']());}async['getCurrentUser'](){const _0x399834=await this['persistence']['_get'](this['fullUserKey']);if(!_0x399834)return null;if(typeof _0x399834=='string'){const _0x5769fd=await Pn(this['auth'],{'idToken':_0x399834})['catch'](()=>{});return _0x5769fd?j['_fromGetAccountInfoResponse'](this['auth'],_0x5769fd,_0x399834):null;}return j['_fromJSON'](this['auth'],_0x399834);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x847315){if(this['persistence']===_0x847315)return;const _0x471882=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x847315,_0x471882)return this['setCurrentUser'](_0x471882);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x56e80a,_0x4c8c11,_0x267d57='authUser'){if(!_0x4c8c11['length'])return new tt(ie(Sr),_0x56e80a,_0x267d57);const _0x57984f=(await Promise['all'](_0x4c8c11['map'](async _0x3f6155=>{if(await _0x3f6155['_isAvailable']())return _0x3f6155;})))['filter'](_0x423faf=>_0x423faf);let _0x425d5b=_0x57984f[0x0]||ie(Sr);const _0x525042=ln(_0x267d57,_0x56e80a['config']['apiKey'],_0x56e80a['name']);let _0x3c163d=null;for(const _0x37026f of _0x4c8c11)try{const _0x2d904a=await _0x37026f['_get'](_0x525042);if(_0x2d904a){let _0x72a482;if(typeof _0x2d904a=='string'){const _0x2ef136=await Pn(_0x56e80a,{'idToken':_0x2d904a})['catch'](()=>{});if(!_0x2ef136)break;_0x72a482=await j['_fromGetAccountInfoResponse'](_0x56e80a,_0x2ef136,_0x2d904a);}else _0x72a482=j['_fromJSON'](_0x56e80a,_0x2d904a);_0x37026f!==_0x425d5b&&(_0x3c163d=_0x72a482),_0x425d5b=_0x37026f;break;}}catch{}const _0x2a2a6c=_0x57984f['filter'](_0x5ec843=>_0x5ec843['_shouldAllowMigration']);return!_0x425d5b['_shouldAllowMigration']||!_0x2a2a6c['length']?new tt(_0x425d5b,_0x56e80a,_0x267d57):(_0x425d5b=_0x2a2a6c[0x0],_0x3c163d&&await _0x425d5b['_set'](_0x525042,_0x3c163d['toJSON']()),await Promise['all'](_0x4c8c11['map'](async _0x22343b=>{if(_0x22343b!==_0x425d5b)try{await _0x22343b['_remove'](_0x525042);}catch{}})),new tt(_0x425d5b,_0x56e80a,_0x267d57));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x491780){const _0x1ca747=_0x491780['toLowerCase']();if(_0x1ca747['includes']('opera/')||_0x1ca747['includes']('opr/')||_0x1ca747['includes']('opios/'))return'Opera';if(Pa(_0x1ca747))return'IEMobile';if(_0x1ca747['includes']('msie')||_0x1ca747['includes']('trident/'))return'IE';if(_0x1ca747['includes']('edge/'))return'Edge';if(Ra(_0x1ca747))return'Firefox';if(_0x1ca747['includes']('silk/'))return'Silk';if(Oa(_0x1ca747))return'Blackberry';if(Da(_0x1ca747))return'Webos';if(Aa(_0x1ca747))return'Safari';if((_0x1ca747['includes']('chrome/')||ka(_0x1ca747))&&!_0x1ca747['includes']('edge/'))return'Chrome';if(Na(_0x1ca747))return'Android';{const _0x5cecbe=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x21de33=_0x491780['match'](_0x5cecbe);if((_0x21de33==null?void 0x0:_0x21de33['length'])===0x2)return _0x21de33[0x1];}return'Other';}function Ra(_0x375ae4=W()){return/firefox\//i['test'](_0x375ae4);}function Aa(_0x459a4e=W()){const _0x4ceba9=_0x459a4e['toLowerCase']();return _0x4ceba9['includes']('safari/')&&!_0x4ceba9['includes']('chrome/')&&!_0x4ceba9['includes']('crios/')&&!_0x4ceba9['includes']('android');}function ka(_0x2c5cc8=W()){return/crios\//i['test'](_0x2c5cc8);}function Pa(_0x49dac8=W()){return/iemobile/i['test'](_0x49dac8);}function Na(_0x16a8cd=W()){return/android/i['test'](_0x16a8cd);}function Oa(_0x9792b6=W()){return/blackberry/i['test'](_0x9792b6);}function Da(_0x24128e=W()){return/webos/i['test'](_0x24128e);}function Ss(_0x21166e=W()){return/iphone|ipad|ipod/i['test'](_0x21166e)||/macintosh/i['test'](_0x21166e)&&/mobile/i['test'](_0x21166e);}function Rf(_0x3c5d2d=W()){var _0x42d91e;return Ss(_0x3c5d2d)&&!!((_0x42d91e=window['navigator'])!=null&&_0x42d91e['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x154009=W()){return Ss(_0x154009)||Na(_0x154009)||Da(_0x154009)||Oa(_0x154009)||/windows phone/i['test'](_0x154009)||Pa(_0x154009);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4b182f,_0x495e1c=[]){let _0x2de474;switch(_0x4b182f){case'Browser':_0x2de474=br(W());break;case'Worker':_0x2de474=br(W())+'-'+_0x4b182f;break;default:_0x2de474=_0x4b182f;}const _0x2fe51e=_0x495e1c['length']?_0x495e1c['join'](','):'FirebaseCore-web';return _0x2de474+'/JsCore/'+dt+'/'+_0x2fe51e;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x470979){this['auth']=_0x470979,this['queue']=[];}['pushCallback'](_0x35a15a,_0x13718c){const _0x4733b1=_0x1b019d=>new Promise((_0x3d1fe1,_0x1651d4)=>{try{const _0x1135bf=_0x35a15a(_0x1b019d);_0x3d1fe1(_0x1135bf);}catch(_0x4a5de1){_0x1651d4(_0x4a5de1);}});_0x4733b1['onAbort']=_0x13718c,this['queue']['push'](_0x4733b1);const _0x28c6b9=this['queue']['length']-0x1;return()=>{this['queue'][_0x28c6b9]=()=>Promise['resolve']();};}async['runMiddleware'](_0x551162){if(this['auth']['currentUser']===_0x551162)return;const _0x1501e9=[];try{for(const _0x333a05 of this['queue'])await _0x333a05(_0x551162),_0x333a05['onAbort']&&_0x1501e9['push'](_0x333a05['onAbort']);}catch(_0x3ecdab){_0x1501e9['reverse']();for(const _0x294ca3 of _0x1501e9)try{_0x294ca3();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3ecdab==null?void 0x0:_0x3ecdab['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x294ca1,_0x5d0c38={}){return Pe(_0x294ca1,'GET','/v2/passwordPolicy',ke(_0x294ca1,_0x5d0c38));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x1d27d7){var _0x50152b;const _0x2a9d11=_0x1d27d7['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2a9d11['minPasswordLength']??Nf,_0x2a9d11['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2a9d11['maxPasswordLength']),_0x2a9d11['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2a9d11['containsLowercaseCharacter']),_0x2a9d11['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2a9d11['containsUppercaseCharacter']),_0x2a9d11['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2a9d11['containsNumericCharacter']),_0x2a9d11['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2a9d11['containsNonAlphanumericCharacter']),this['enforcementState']=_0x1d27d7['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x50152b=_0x1d27d7['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x50152b['join'](''))??'',this['forceUpgradeOnSignin']=_0x1d27d7['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x1d27d7['schemaVersion'];}['validatePassword'](_0x19ca08){const _0x352d2b={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x19ca08,_0x352d2b),this['validatePasswordCharacterOptions'](_0x19ca08,_0x352d2b),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['meetsMinPasswordLength']??!0x0),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['meetsMaxPasswordLength']??!0x0),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['containsLowercaseLetter']??!0x0),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['containsUppercaseLetter']??!0x0),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['containsNumericCharacter']??!0x0),_0x352d2b['isValid']&&(_0x352d2b['isValid']=_0x352d2b['containsNonAlphanumericCharacter']??!0x0),_0x352d2b;}['validatePasswordLengthOptions'](_0x36827a,_0x1a5aea){const _0x323839=this['customStrengthOptions']['minPasswordLength'],_0x146022=this['customStrengthOptions']['maxPasswordLength'];_0x323839&&(_0x1a5aea['meetsMinPasswordLength']=_0x36827a['length']>=_0x323839),_0x146022&&(_0x1a5aea['meetsMaxPasswordLength']=_0x36827a['length']<=_0x146022);}['validatePasswordCharacterOptions'](_0x52c6e5,_0x212a25){this['updatePasswordCharacterOptionsStatuses'](_0x212a25,!0x1,!0x1,!0x1,!0x1);let _0x507663;for(let _0x369dfe=0x0;_0x369dfe<_0x52c6e5['length'];_0x369dfe++)_0x507663=_0x52c6e5['charAt'](_0x369dfe),this['updatePasswordCharacterOptionsStatuses'](_0x212a25,_0x507663>='a'&&_0x507663<='z',_0x507663>='A'&&_0x507663<='Z',_0x507663>='0'&&_0x507663<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x507663));}['updatePasswordCharacterOptionsStatuses'](_0x1e6311,_0x28fdf0,_0xd86256,_0x221d60,_0x1e5067){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1e6311['containsLowercaseLetter']||(_0x1e6311['containsLowercaseLetter']=_0x28fdf0)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1e6311['containsUppercaseLetter']||(_0x1e6311['containsUppercaseLetter']=_0xd86256)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1e6311['containsNumericCharacter']||(_0x1e6311['containsNumericCharacter']=_0x221d60)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1e6311['containsNonAlphanumericCharacter']||(_0x1e6311['containsNonAlphanumericCharacter']=_0x1e5067));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x1894c9,_0x541f6d,_0x33efe3,_0x3dd3da){this['app']=_0x1894c9,this['heartbeatServiceProvider']=_0x541f6d,this['appCheckServiceProvider']=_0x33efe3,this['config']=_0x3dd3da,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x1894c9['name'],this['clientVersion']=_0x3dd3da['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1ba834=>this['_resolvePersistenceManagerAvailable']=_0x1ba834);}['_initializeWithPersistence'](_0x32113e,_0x1e9925){return _0x1e9925&&(this['_popupRedirectResolver']=ie(_0x1e9925)),this['_initializationPromise']=this['queue'](async()=>{var _0x30aa72,_0xedb982,_0x53f9af;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x32113e),(_0x30aa72=this['_resolvePersistenceManagerAvailable'])==null||_0x30aa72['call'](this),!this['_deleted'])){if((_0xedb982=this['_popupRedirectResolver'])!=null&&_0xedb982['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1e9925),this['lastNotifiedUid']=((_0x53f9af=this['currentUser'])==null?void 0x0:_0x53f9af['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3f3246=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3f3246)){if(this['currentUser']&&_0x3f3246&&this['currentUser']['uid']===_0x3f3246['uid']){this['_currentUser']['_assign'](_0x3f3246),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3f3246,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3ffa5e){try{const _0xcc3928=await Pn(this,{'idToken':_0x3ffa5e}),_0x7c414a=await j['_fromGetAccountInfoResponse'](this,_0xcc3928,_0x3ffa5e);await this['directlySetCurrentUser'](_0x7c414a);}catch(_0x2a048f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2a048f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x256062){var _0x588a9b;if($(this['app'])){const _0x4d869f=this['app']['settings']['authIdToken'];return _0x4d869f?new Promise(_0x4d6dc4=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x4d869f)['then'](_0x4d6dc4,_0x4d6dc4));}):this['directlySetCurrentUser'](null);}const _0x432c5c=await this['assertedPersistence']['getCurrentUser']();let _0x51ec62=_0x432c5c,_0x5736d7=!0x1;if(_0x256062&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x59a8ec=(_0x588a9b=this['redirectUser'])==null?void 0x0:_0x588a9b['_redirectEventId'],_0x3225ce=_0x51ec62==null?void 0x0:_0x51ec62['_redirectEventId'],_0x2a4e26=await this['tryRedirectSignIn'](_0x256062);(!_0x59a8ec||_0x59a8ec===_0x3225ce)&&(_0x2a4e26!=null&&_0x2a4e26['user'])&&(_0x51ec62=_0x2a4e26['user'],_0x5736d7=!0x0);}if(!_0x51ec62)return this['directlySetCurrentUser'](null);if(!_0x51ec62['_redirectEventId']){if(_0x5736d7)try{await this['beforeStateQueue']['runMiddleware'](_0x51ec62);}catch(_0x53eba5){_0x51ec62=_0x432c5c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x53eba5));}return _0x51ec62?this['reloadAndSetCurrentUserOrClear'](_0x51ec62):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x51ec62['_redirectEventId']?this['directlySetCurrentUser'](_0x51ec62):this['reloadAndSetCurrentUserOrClear'](_0x51ec62);}async['tryRedirectSignIn'](_0x263564){let _0x40be0b=null;try{_0x40be0b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x263564,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x40be0b;}async['reloadAndSetCurrentUserOrClear'](_0x547680){try{await Nn(_0x547680);}catch(_0x3754e5){if((_0x3754e5==null?void 0x0:_0x3754e5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x547680);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x39fc3f){if($(this['app']))return Promise['reject'](re(this));const _0x371f0f=_0x39fc3f?P(_0x39fc3f):null;return _0x371f0f&&m(_0x371f0f['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x371f0f&&_0x371f0f['_clone'](this));}async['_updateCurrentUser'](_0xa1d24d,_0x86f93e=!0x1){if(!this['_deleted'])return _0xa1d24d&&m(this['tenantId']===_0xa1d24d['tenantId'],this,'tenant-id-mismatch'),_0x86f93e||await this['beforeStateQueue']['runMiddleware'](_0xa1d24d),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xa1d24d),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xd4c6d5){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xd4c6d5));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5325e1){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4d9912=this['_getPasswordPolicyInternal']();return _0x4d9912['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4d9912['validatePassword'](_0x5325e1);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5b185b=await Pf(this),_0x365592=new Of(_0x5b185b);this['tenantId']===null?this['_projectPasswordPolicy']=_0x365592:this['_tenantPasswordPolicies'][this['tenantId']]=_0x365592;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x272505){this['_errorFactory']=new Gt('auth','Firebase',_0x272505());}['onAuthStateChanged'](_0x1ec1ce,_0x3cb2e4,_0x13381c){return this['registerStateListener'](this['authStateSubscription'],_0x1ec1ce,_0x3cb2e4,_0x13381c);}['beforeAuthStateChanged'](_0x43381b,_0x43362b){return this['beforeStateQueue']['pushCallback'](_0x43381b,_0x43362b);}['onIdTokenChanged'](_0x304d9f,_0x58434a,_0x4f04f1){return this['registerStateListener'](this['idTokenSubscription'],_0x304d9f,_0x58434a,_0x4f04f1);}['authStateReady'](){return new Promise((_0x337ce1,_0x3758a7)=>{if(this['currentUser'])_0x337ce1();else{const _0x4dc015=this['onAuthStateChanged'](()=>{_0x4dc015(),_0x337ce1();},_0x3758a7);}});}async['revokeAccessToken'](_0x328769){if(this['currentUser']){const _0x1ce0c5=await this['currentUser']['getIdToken'](),_0x572ad1={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x328769,'idToken':_0x1ce0c5};this['tenantId']!=null&&(_0x572ad1['tenantId']=this['tenantId']),await bf(this,_0x572ad1);}}['toJSON'](){var _0x90c260;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x90c260=this['_currentUser'])==null?void 0x0:_0x90c260['toJSON']()};}async['_setRedirectUser'](_0x1d81b9,_0x3eadb0){const _0xb21419=await this['getOrInitRedirectPersistenceManager'](_0x3eadb0);return _0x1d81b9===null?_0xb21419['removeCurrentUser']():_0xb21419['setCurrentUser'](_0x1d81b9);}async['getOrInitRedirectPersistenceManager'](_0x4f44b2){if(!this['redirectPersistenceManager']){const _0x579e7e=_0x4f44b2&&ie(_0x4f44b2)||this['_popupRedirectResolver'];m(_0x579e7e,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x579e7e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1a3e72){var _0x3cdc30,_0x1d3737;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3cdc30=this['_currentUser'])==null?void 0x0:_0x3cdc30['_redirectEventId'])===_0x1a3e72?this['_currentUser']:((_0x1d3737=this['redirectUser'])==null?void 0x0:_0x1d3737['_redirectEventId'])===_0x1a3e72?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2ee6c9){if(_0x2ee6c9===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2ee6c9));}['_notifyListenersIfCurrent'](_0x1c87d5){_0x1c87d5===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x428611;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x358150=((_0x428611=this['currentUser'])==null?void 0x0:_0x428611['uid'])??null;this['lastNotifiedUid']!==_0x358150&&(this['lastNotifiedUid']=_0x358150,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5045fd,_0x5ee193,_0x43d68e,_0x3b98e9){if(this['_deleted'])return()=>{};const _0x1c0019=typeof _0x5ee193=='function'?_0x5ee193:_0x5ee193['next']['bind'](_0x5ee193);let _0x4d79b0=!0x1;const _0x59ef02=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x59ef02,this,'internal-error'),_0x59ef02['then'](()=>{_0x4d79b0||_0x1c0019(this['currentUser']);}),typeof _0x5ee193=='function'){const _0x45d5a7=_0x5045fd['addObserver'](_0x5ee193,_0x43d68e,_0x3b98e9);return()=>{_0x4d79b0=!0x0,_0x45d5a7();};}else{const _0x1e186c=_0x5045fd['addObserver'](_0x5ee193);return()=>{_0x4d79b0=!0x0,_0x1e186c();};}}async['directlySetCurrentUser'](_0x2bfb6e){this['currentUser']&&this['currentUser']!==_0x2bfb6e&&this['_currentUser']['_stopProactiveRefresh'](),_0x2bfb6e&&this['isProactiveRefreshEnabled']&&_0x2bfb6e['_startProactiveRefresh'](),this['currentUser']=_0x2bfb6e,_0x2bfb6e?await this['assertedPersistence']['setCurrentUser'](_0x2bfb6e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x31690a){return this['operations']=this['operations']['then'](_0x31690a,_0x31690a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1e89f9){!_0x1e89f9||this['frameworks']['includes'](_0x1e89f9)||(this['frameworks']['push'](_0x1e89f9),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1b362b;const _0x45f59e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x45f59e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x32a9ad=await((_0x1b362b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1b362b['getHeartbeatsHeader']());_0x32a9ad&&(_0x45f59e['X-Firebase-Client']=_0x32a9ad);const _0xf6ec8e=await this['_getAppCheckToken']();return _0xf6ec8e&&(_0x45f59e['X-Firebase-AppCheck']=_0xf6ec8e),_0x45f59e;}async['_getAppCheckToken'](){var _0xffd2a6;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x26f86a=await((_0xffd2a6=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xffd2a6['getToken']());return _0x26f86a!=null&&_0x26f86a['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x26f86a['error']),_0x26f86a==null?void 0x0:_0x26f86a['token'];}}function Ke(_0x24a4e9){return P(_0x24a4e9);}class Rr{constructor(_0x252549){this['auth']=_0x252549,this['observer']=null,this['addObserver']=Tc(_0xaeb07f=>this['observer']=_0xaeb07f);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1af199){Jn=_0x1af199;}function xa(_0x2b383f){return Jn['loadJS'](_0x2b383f);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x459d8f){return'__'+_0x459d8f+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xfe3e87){_0xfe3e87();}['execute'](_0x5082bf,_0x9b3ea5){return Promise['resolve']('token');}['render'](_0x205835,_0x30f38b){return'';}}class Wf{['ready'](_0x4f7492){_0x4f7492();}['execute'](_0x3530f6,_0x2f896f){return Promise['resolve']('token');}['render'](_0xed3aeb,_0x37f639){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x23daa5){this['type']=Bf,this['auth']=Ke(_0x23daa5);}async['verify'](_0x5b4fb6='verify',_0x2fe02d=!0x1){async function _0x4b5f91(_0xdc7171){if(!_0x2fe02d){if(_0xdc7171['tenantId']==null&&_0xdc7171['_agentRecaptchaConfig']!=null)return _0xdc7171['_agentRecaptchaConfig']['siteKey'];if(_0xdc7171['tenantId']!=null&&_0xdc7171['_tenantRecaptchaConfigs'][_0xdc7171['tenantId']]!==void 0x0)return _0xdc7171['_tenantRecaptchaConfigs'][_0xdc7171['tenantId']]['siteKey'];}return new Promise(async(_0x356c87,_0x246537)=>{yf(_0xdc7171,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1315b7=>{if(_0x1315b7['recaptchaKey']===void 0x0)_0x246537(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x455560=new mf(_0x1315b7);return _0xdc7171['tenantId']==null?_0xdc7171['_agentRecaptchaConfig']=_0x455560:_0xdc7171['_tenantRecaptchaConfigs'][_0xdc7171['tenantId']]=_0x455560,_0x356c87(_0x455560['siteKey']);}})['catch'](_0x49d805=>{_0x246537(_0x49d805);});});}function _0x1b5615(_0x44290c,_0xfa9116,_0x49edf0){const _0x123d93=window['grecaptcha'];wr(_0x123d93)?_0x123d93['enterprise']['ready'](()=>{_0x123d93['enterprise']['execute'](_0x44290c,{'action':_0x5b4fb6})['then'](_0x543125=>{_0xfa9116(_0x543125);})['catch'](()=>{_0xfa9116(Fa);});}):_0x49edf0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x44c439,_0x200cee)=>{_0x4b5f91(this['auth'])['then'](async _0x500bb2=>{if(!_0x2fe02d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x1b5615(_0x500bb2,_0x44c439,_0x200cee);else{if(typeof window>'u'){_0x200cee(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5986c9=Lf();_0x5986c9['length']!==0x0&&(_0x5986c9+=_0x500bb2+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x119377;(_0x119377=he['scriptInjectionDeferred'])==null||_0x119377['resolve']();},xa(_0x5986c9)['then'](()=>{var _0x2594ad;return(_0x2594ad=he['scriptInjectionDeferred'])==null?void 0x0:_0x2594ad['promise'];})['then'](()=>{_0x1b5615(_0x500bb2,_0x44c439,_0x200cee);})['catch'](_0x502017=>{_0x200cee(_0x502017);});}})['catch'](_0x2a8821=>{_0x200cee(_0x2a8821);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x317c71,_0x401f15,_0x3ea36b,_0x3c9849=!0x1,_0x315951=!0x1){const _0x4ec398=new he(_0x317c71);let _0x568e44;if(_0x315951)_0x568e44=Fa;else try{_0x568e44=await _0x4ec398['verify'](_0x3ea36b);}catch{_0x568e44=await _0x4ec398['verify'](_0x3ea36b,!0x0);}const _0x1025ec={..._0x401f15};if(_0x3ea36b==='mfaSmsEnrollment'||_0x3ea36b==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1025ec){const _0x4221a6=_0x1025ec['phoneEnrollmentInfo']['phoneNumber'],_0x323a23=_0x1025ec['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1025ec,{'phoneEnrollmentInfo':{'phoneNumber':_0x4221a6,'recaptchaToken':_0x323a23,'captchaResponse':_0x568e44,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1025ec){const _0x4fb179=_0x1025ec['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1025ec,{'phoneSignInInfo':{'recaptchaToken':_0x4fb179,'captchaResponse':_0x568e44,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1025ec;}return _0x3c9849?Object['assign'](_0x1025ec,{'captchaResp':_0x568e44}):Object['assign'](_0x1025ec,{'captchaResponse':_0x568e44}),Object['assign'](_0x1025ec,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1025ec,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1025ec;}async function xi(_0x1f6f1b,_0x5785bc,_0x4b154b,_0x4c59aa,_0x4f2f35){var _0x127db7;if((_0x127db7=_0x1f6f1b['_getRecaptchaConfig']())!=null&&_0x127db7['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1dc24c=await kr(_0x1f6f1b,_0x5785bc,_0x4b154b,_0x4b154b==='getOobCode');return _0x4c59aa(_0x1f6f1b,_0x1dc24c);}else return _0x4c59aa(_0x1f6f1b,_0x5785bc)['catch'](async _0x35754e=>{if(_0x35754e['code']==='auth/missing-recaptcha-token'){console['log'](_0x4b154b+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x283339=await kr(_0x1f6f1b,_0x5785bc,_0x4b154b,_0x4b154b==='getOobCode');return _0x4c59aa(_0x1f6f1b,_0x283339);}else return Promise['reject'](_0x35754e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2f541d,_0x1203e6){const _0x4a95ac=Hi(_0x2f541d,'auth');if(_0x4a95ac['isInitialized']()){const _0x881195=_0x4a95ac['getImmediate'](),_0x3346f0=_0x4a95ac['getOptions']();if(xe(_0x3346f0,_0x1203e6??{}))return _0x881195;Y(_0x881195,'already-initialized');}return _0x4a95ac['initialize']({'options':_0x1203e6});}function Hf(_0x98164f,_0x467df4){const _0x3f3f1e=(_0x467df4==null?void 0x0:_0x467df4['persistence'])||[],_0x4bfa20=(Array['isArray'](_0x3f3f1e)?_0x3f3f1e:[_0x3f3f1e])['map'](ie);_0x467df4!=null&&_0x467df4['errorMap']&&_0x98164f['_updateErrorMap'](_0x467df4['errorMap']),_0x98164f['_initializeWithPersistence'](_0x4bfa20,_0x467df4==null?void 0x0:_0x467df4['popupRedirectResolver']);}function $f(_0x218255,_0x3697bd,_0x42a997){const _0x2a8a88=Ke(_0x218255);m(/^https?:\/\//['test'](_0x3697bd),_0x2a8a88,'invalid-emulator-scheme');const _0x3a90f2=!0x1,_0x3a8eb7=Ua(_0x3697bd),{host:_0x1eb998,port:_0x33f819}=Gf(_0x3697bd),_0x22e8e1=_0x33f819===null?'':':'+_0x33f819,_0x2d952c={'url':_0x3a8eb7+'//'+_0x1eb998+_0x22e8e1+'/'},_0x3c575b=Object['freeze']({'host':_0x1eb998,'port':_0x33f819,'protocol':_0x3a8eb7['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3a90f2})});if(!_0x2a8a88['_canInitEmulator']){m(_0x2a8a88['config']['emulator']&&_0x2a8a88['emulatorConfig'],_0x2a8a88,'emulator-config-failed'),m(xe(_0x2d952c,_0x2a8a88['config']['emulator'])&&xe(_0x3c575b,_0x2a8a88['emulatorConfig']),_0x2a8a88,'emulator-config-failed');return;}_0x2a8a88['config']['emulator']=_0x2d952c,_0x2a8a88['emulatorConfig']=_0x3c575b,_0x2a8a88['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x1eb998)?Qr(_0x3a8eb7+'//'+_0x1eb998+_0x22e8e1):qf();}function Ua(_0xcb92e1){const _0x7763e=_0xcb92e1['indexOf'](':');return _0x7763e<0x0?'':_0xcb92e1['substr'](0x0,_0x7763e+0x1);}function Gf(_0x98ecee){const _0x413587=Ua(_0x98ecee),_0x12f76a=/(\/\/)?([^?#/]+)/['exec'](_0x98ecee['substr'](_0x413587['length']));if(!_0x12f76a)return{'host':'','port':null};const _0x44ede1=_0x12f76a[0x2]['split']('@')['pop']()||'',_0x58ed95=/^(\[[^\]]+\])(:|$)/['exec'](_0x44ede1);if(_0x58ed95){const _0x883746=_0x58ed95[0x1];return{'host':_0x883746,'port':Pr(_0x44ede1['substr'](_0x883746['length']+0x1))};}else{const [_0x427b3f,_0x261bd4]=_0x44ede1['split'](':');return{'host':_0x427b3f,'port':Pr(_0x261bd4)};}}function Pr(_0x5ad814){if(!_0x5ad814)return null;const _0x47f3e6=Number(_0x5ad814);return isNaN(_0x47f3e6)?null:_0x47f3e6;}function qf(){function _0x337aa1(){const _0x349fb8=document['createElement']('p'),_0x53f71e=_0x349fb8['style'];_0x349fb8['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x53f71e['position']='fixed',_0x53f71e['width']='100%',_0x53f71e['backgroundColor']='#ffffff',_0x53f71e['border']='.1em\x20solid\x20#000000',_0x53f71e['color']='#b50000',_0x53f71e['bottom']='0px',_0x53f71e['left']='0px',_0x53f71e['margin']='0px',_0x53f71e['zIndex']='10000',_0x53f71e['textAlign']='center',_0x349fb8['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x349fb8);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x337aa1):_0x337aa1());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x523aa7,_0x342aba){this['providerId']=_0x523aa7,this['signInMethod']=_0x342aba;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x1303b8){return ne('not\x20implemented');}['_linkToIdToken'](_0x4790b4,_0x354c8f){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x201d02){return ne('not\x20implemented');}}async function zf(_0x1380bc,_0x3aedfa){return Pe(_0x1380bc,'POST','/v1/accounts:signUp',_0x3aedfa);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x190479,_0x2b2c2d){return en(_0x190479,'POST','/v1/accounts:signInWithPassword',ke(_0x190479,_0x2b2c2d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xdc02d9,_0x1691b7){return en(_0xdc02d9,'POST','/v1/accounts:signInWithEmailLink',ke(_0xdc02d9,_0x1691b7));}async function Yf(_0x3c0baa,_0x349289){return en(_0x3c0baa,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3c0baa,_0x349289));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1f64bc,_0x31f859,_0xca3d46,_0x2173ae=null){super('password',_0xca3d46),this['_email']=_0x1f64bc,this['_password']=_0x31f859,this['_tenantId']=_0x2173ae;}static['_fromEmailAndPassword'](_0x1c68d5,_0xc2f653){return new $t(_0x1c68d5,_0xc2f653,'password');}static['_fromEmailAndCode'](_0x2354cd,_0x181dc2,_0x262a33=null){return new $t(_0x2354cd,_0x181dc2,'emailLink',_0x262a33);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4985){const _0x306c0d=typeof _0x4985=='string'?JSON['parse'](_0x4985):_0x4985;if(_0x306c0d!=null&&_0x306c0d['email']&&(_0x306c0d!=null&&_0x306c0d['password'])){if(_0x306c0d['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x306c0d['email'],_0x306c0d['password']);if(_0x306c0d['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x306c0d['email'],_0x306c0d['password'],_0x306c0d['tenantId']);}return null;}async['_getIdTokenResponse'](_0x56e9f7){switch(this['signInMethod']){case'password':const _0x20705f={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x56e9f7,_0x20705f,'signInWithPassword',jf);case'emailLink':return Kf(_0x56e9f7,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x56e9f7,'internal-error');}}async['_linkToIdToken'](_0x2c7af2,_0x42d62d){switch(this['signInMethod']){case'password':const _0x3674a0={'idToken':_0x42d62d,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2c7af2,_0x3674a0,'signUpPassword',zf);case'emailLink':return Yf(_0x2c7af2,{'idToken':_0x42d62d,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2c7af2,'internal-error');}}['_getReauthenticationResolver'](_0x574cdc){return this['_getIdTokenResponse'](_0x574cdc);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x535087,_0x57d7b4){return en(_0x535087,'POST','/v1/accounts:signInWithIdp',ke(_0x535087,_0x57d7b4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x327ae5){const _0x348d8f=new $e(_0x327ae5['providerId'],_0x327ae5['signInMethod']);return _0x327ae5['idToken']||_0x327ae5['accessToken']?(_0x327ae5['idToken']&&(_0x348d8f['idToken']=_0x327ae5['idToken']),_0x327ae5['accessToken']&&(_0x348d8f['accessToken']=_0x327ae5['accessToken']),_0x327ae5['nonce']&&!_0x327ae5['pendingToken']&&(_0x348d8f['nonce']=_0x327ae5['nonce']),_0x327ae5['pendingToken']&&(_0x348d8f['pendingToken']=_0x327ae5['pendingToken'])):_0x327ae5['oauthToken']&&_0x327ae5['oauthTokenSecret']?(_0x348d8f['accessToken']=_0x327ae5['oauthToken'],_0x348d8f['secret']=_0x327ae5['oauthTokenSecret']):Y('argument-error'),_0x348d8f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5f09a1){const _0x10008c=typeof _0x5f09a1=='string'?JSON['parse'](_0x5f09a1):_0x5f09a1,{providerId:_0xde5db1,signInMethod:_0xd54ba8,..._0x2d7140}=_0x10008c;if(!_0xde5db1||!_0xd54ba8)return null;const _0x14bdba=new $e(_0xde5db1,_0xd54ba8);return _0x14bdba['idToken']=_0x2d7140['idToken']||void 0x0,_0x14bdba['accessToken']=_0x2d7140['accessToken']||void 0x0,_0x14bdba['secret']=_0x2d7140['secret'],_0x14bdba['nonce']=_0x2d7140['nonce'],_0x14bdba['pendingToken']=_0x2d7140['pendingToken']||null,_0x14bdba;}['_getIdTokenResponse'](_0x197876){const _0x1f0db9=this['buildRequest']();return nt(_0x197876,_0x1f0db9);}['_linkToIdToken'](_0x139a73,_0x1a35f6){const _0x354552=this['buildRequest']();return _0x354552['idToken']=_0x1a35f6,nt(_0x139a73,_0x354552);}['_getReauthenticationResolver'](_0x6334a9){const _0x2c3a11=this['buildRequest']();return _0x2c3a11['autoCreate']=!0x1,nt(_0x6334a9,_0x2c3a11);}['buildRequest'](){const _0x441642={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x441642['pendingToken']=this['pendingToken'];else{const _0x36b90c={};this['idToken']&&(_0x36b90c['id_token']=this['idToken']),this['accessToken']&&(_0x36b90c['access_token']=this['accessToken']),this['secret']&&(_0x36b90c['oauth_token_secret']=this['secret']),_0x36b90c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x36b90c['nonce']=this['nonce']),_0x441642['postBody']=ut(_0x36b90c);}return _0x441642;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2f6590){switch(_0x2f6590){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x5237d2){const _0x351cfa=Ct(Tt(_0x5237d2))['link'],_0x4c563a=_0x351cfa?Ct(Tt(_0x351cfa))['deep_link_id']:null,_0x29e352=Ct(Tt(_0x5237d2))['deep_link_id'];return(_0x29e352?Ct(Tt(_0x29e352))['link']:null)||_0x29e352||_0x4c563a||_0x351cfa||_0x5237d2;}class Rs{constructor(_0x42cfd5){const _0x4b1ac2=Ct(Tt(_0x42cfd5)),_0x408c42=_0x4b1ac2['apiKey']??null,_0x82226d=_0x4b1ac2['oobCode']??null,_0x2c2a29=Jf(_0x4b1ac2['mode']??null);m(_0x408c42&&_0x82226d&&_0x2c2a29,'argument-error'),this['apiKey']=_0x408c42,this['operation']=_0x2c2a29,this['code']=_0x82226d,this['continueUrl']=_0x4b1ac2['continueUrl']??null,this['languageCode']=_0x4b1ac2['lang']??null,this['tenantId']=_0x4b1ac2['tenantId']??null;}static['parseLink'](_0x57a83b){const _0x2c4791=Xf(_0x57a83b);try{return new Rs(_0x2c4791);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x3f1d3d,_0x561270){return $t['_fromEmailAndPassword'](_0x3f1d3d,_0x561270);}static['credentialWithLink'](_0x41c9d1,_0x43c801){const _0x4d2dad=Rs['parseLink'](_0x43c801);return m(_0x4d2dad,'argument-error'),$t['_fromEmailAndCode'](_0x41c9d1,_0x4d2dad['code'],_0x4d2dad['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2b7215){this['providerId']=_0x2b7215,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x3d2e66){this['defaultLanguageCode']=_0x3d2e66;}['setCustomParameters'](_0x56a190){return this['customParameters']=_0x56a190,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5ce387){return this['scopes']['includes'](_0x5ce387)||this['scopes']['push'](_0x5ce387),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4c30b8){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4c30b8});}static['credentialFromResult'](_0x3de432){return ue['credentialFromTaggedObject'](_0x3de432);}static['credentialFromError'](_0x34ea5d){return ue['credentialFromTaggedObject'](_0x34ea5d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x42cf87}){if(!_0x42cf87||!('oauthAccessToken'in _0x42cf87)||!_0x42cf87['oauthAccessToken'])return null;try{return ue['credential'](_0x42cf87['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x484cf6,_0x4aa849){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x484cf6,'accessToken':_0x4aa849});}static['credentialFromResult'](_0x5d1f0b){return de['credentialFromTaggedObject'](_0x5d1f0b);}static['credentialFromError'](_0x57cbf5){return de['credentialFromTaggedObject'](_0x57cbf5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x16957c}){if(!_0x16957c)return null;const {oauthIdToken:_0x4f7fcf,oauthAccessToken:_0x3d0e96}=_0x16957c;if(!_0x4f7fcf&&!_0x3d0e96)return null;try{return de['credential'](_0x4f7fcf,_0x3d0e96);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x591415){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x591415});}static['credentialFromResult'](_0x560725){return fe['credentialFromTaggedObject'](_0x560725);}static['credentialFromError'](_0x1d975a){return fe['credentialFromTaggedObject'](_0x1d975a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4e2e65}){if(!_0x4e2e65||!('oauthAccessToken'in _0x4e2e65)||!_0x4e2e65['oauthAccessToken'])return null;try{return fe['credential'](_0x4e2e65['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x5c44d6,_0x20bf29){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5c44d6,'oauthTokenSecret':_0x20bf29});}static['credentialFromResult'](_0x4dd2ce){return pe['credentialFromTaggedObject'](_0x4dd2ce);}static['credentialFromError'](_0x5ef6b3){return pe['credentialFromTaggedObject'](_0x5ef6b3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1f5f01}){if(!_0x1f5f01)return null;const {oauthAccessToken:_0x39cd09,oauthTokenSecret:_0x55bc70}=_0x1f5f01;if(!_0x39cd09||!_0x55bc70)return null;try{return pe['credential'](_0x39cd09,_0x55bc70);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4e29d1,_0x430c52){return en(_0x4e29d1,'POST','/v1/accounts:signUp',ke(_0x4e29d1,_0x430c52));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x56c3de){this['user']=_0x56c3de['user'],this['providerId']=_0x56c3de['providerId'],this['_tokenResponse']=_0x56c3de['_tokenResponse'],this['operationType']=_0x56c3de['operationType'];}static async['_fromIdTokenResponse'](_0x1e129c,_0x33b83b,_0x22c78c,_0xc16d3a=!0x1){const _0x4327cc=await j['_fromIdTokenResponse'](_0x1e129c,_0x22c78c,_0xc16d3a),_0x21c8e8=Nr(_0x22c78c);return new Ge({'user':_0x4327cc,'providerId':_0x21c8e8,'_tokenResponse':_0x22c78c,'operationType':_0x33b83b});}static async['_forOperation'](_0x2f3729,_0x278d1f,_0x2d3706){await _0x2f3729['_updateTokensIfNecessary'](_0x2d3706,!0x0);const _0x46c7e3=Nr(_0x2d3706);return new Ge({'user':_0x2f3729,'providerId':_0x46c7e3,'_tokenResponse':_0x2d3706,'operationType':_0x278d1f});}}function Nr(_0x21f197){return _0x21f197['providerId']?_0x21f197['providerId']:'phoneNumber'in _0x21f197?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xf668f0,_0x44f71e,_0x7225ab,_0x2f8eb2){super(_0x44f71e['code'],_0x44f71e['message']),this['operationType']=_0x7225ab,this['user']=_0x2f8eb2,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xf668f0['name'],'tenantId':_0xf668f0['tenantId']??void 0x0,'_serverResponse':_0x44f71e['customData']['_serverResponse'],'operationType':_0x7225ab};}static['_fromErrorAndOperation'](_0xf44022,_0x390713,_0x36b0e1,_0xeb2fff){return new On(_0xf44022,_0x390713,_0x36b0e1,_0xeb2fff);}}function Ba(_0x44aaa1,_0x3e6d05,_0x30a523,_0x571247){return(_0x3e6d05==='reauthenticate'?_0x30a523['_getReauthenticationResolver'](_0x44aaa1):_0x30a523['_getIdTokenResponse'](_0x44aaa1))['catch'](_0x4a4b69=>{throw _0x4a4b69['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x44aaa1,_0x4a4b69,_0x3e6d05,_0x571247):_0x4a4b69;});}async function ep(_0x1cc059,_0x4f6f9d,_0x2f1207=!0x1){const _0x1e8eb9=await Ht(_0x1cc059,_0x4f6f9d['_linkToIdToken'](_0x1cc059['auth'],await _0x1cc059['getIdToken']()),_0x2f1207);return Ge['_forOperation'](_0x1cc059,'link',_0x1e8eb9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x45e5d7,_0x43e0ee,_0x2fa226=!0x1){const {auth:_0x3a0481}=_0x45e5d7;if($(_0x3a0481['app']))return Promise['reject'](re(_0x3a0481));const _0x232697='reauthenticate';try{const _0x5b6f30=await Ht(_0x45e5d7,Ba(_0x3a0481,_0x232697,_0x43e0ee,_0x45e5d7),_0x2fa226);m(_0x5b6f30['idToken'],_0x3a0481,'internal-error');const _0xe49ed8=Ts(_0x5b6f30['idToken']);m(_0xe49ed8,_0x3a0481,'internal-error');const {sub:_0x3c3a9b}=_0xe49ed8;return m(_0x45e5d7['uid']===_0x3c3a9b,_0x3a0481,'user-mismatch'),Ge['_forOperation'](_0x45e5d7,_0x232697,_0x5b6f30);}catch(_0x357d0f){throw(_0x357d0f==null?void 0x0:_0x357d0f['code'])==='auth/user-not-found'&&Y(_0x3a0481,'user-mismatch'),_0x357d0f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x142139,_0x8e3dc4,_0x167a0d=!0x1){if($(_0x142139['app']))return Promise['reject'](re(_0x142139));const _0x39509d='signIn',_0x46982f=await Ba(_0x142139,_0x39509d,_0x8e3dc4),_0xa9a6b7=await Ge['_fromIdTokenResponse'](_0x142139,_0x39509d,_0x46982f);return _0x167a0d||await _0x142139['_updateCurrentUser'](_0xa9a6b7['user']),_0xa9a6b7;}async function np(_0x44a4cf,_0x2e407e){return Va(Ke(_0x44a4cf),_0x2e407e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x42d6dd){const _0x1e9f0b=Ke(_0x42d6dd);_0x1e9f0b['_getPasswordPolicyInternal']()&&await _0x1e9f0b['_updatePasswordPolicy']();}async function L_(_0x38f627,_0x52515e,_0x3fa724){if($(_0x38f627['app']))return Promise['reject'](re(_0x38f627));const _0x1fd5a4=Ke(_0x38f627),_0x882297=await xi(_0x1fd5a4,{'returnSecureToken':!0x0,'email':_0x52515e,'password':_0x3fa724,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x453c99=>{throw _0x453c99['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x38f627),_0x453c99;}),_0x22ce0d=await Ge['_fromIdTokenResponse'](_0x1fd5a4,'signIn',_0x882297);return await _0x1fd5a4['_updateCurrentUser'](_0x22ce0d['user']),_0x22ce0d;}function x_(_0x4ee727,_0x544994,_0x447924){return $(_0x4ee727['app'])?Promise['reject'](re(_0x4ee727)):np(P(_0x4ee727),yt['credential'](_0x544994,_0x447924))['catch'](async _0x1f1f1b=>{throw _0x1f1f1b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4ee727),_0x1f1f1b;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x34b669,_0x35c837){return P(_0x34b669)['setPersistence'](_0x35c837);}function ip(_0x31b898,_0x1d0844,_0x581aef,_0xe2b9c3){return P(_0x31b898)['onIdTokenChanged'](_0x1d0844,_0x581aef,_0xe2b9c3);}function sp(_0x491816,_0x4b10d6,_0x5aac86){return P(_0x491816)['beforeAuthStateChanged'](_0x4b10d6,_0x5aac86);}function U_(_0x513a2a,_0x2c6cc4,_0x3713c3,_0x3db2f3){return P(_0x513a2a)['onAuthStateChanged'](_0x2c6cc4,_0x3713c3,_0x3db2f3);}function W_(_0x39bb12){return P(_0x39bb12)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x127f79,_0x351623){this['storageRetriever']=_0x127f79,this['type']=_0x351623;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x49bece,_0x52ac57){return this['storage']['setItem'](_0x49bece,JSON['stringify'](_0x52ac57)),Promise['resolve']();}['_get'](_0x954f88){const _0x30e57f=this['storage']['getItem'](_0x954f88);return Promise['resolve'](_0x30e57f?JSON['parse'](_0x30e57f):null);}['_remove'](_0xf3c6f8){return this['storage']['removeItem'](_0xf3c6f8),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x163454,_0x366ed2)=>this['onStorageEvent'](_0x163454,_0x366ed2),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4eabf1){for(const _0x29ed15 of Object['keys'](this['listeners'])){const _0x2a996c=this['storage']['getItem'](_0x29ed15),_0xa524be=this['localCache'][_0x29ed15];_0x2a996c!==_0xa524be&&_0x4eabf1(_0x29ed15,_0xa524be,_0x2a996c);}}['onStorageEvent'](_0x288865,_0x4c8fc9=!0x1){if(!_0x288865['key']){this['forAllChangedKeys']((_0x1ade5f,_0x3d7ef4,_0x1d64db)=>{this['notifyListeners'](_0x1ade5f,_0x1d64db);});return;}const _0x4f2ee0=_0x288865['key'];_0x4c8fc9?this['detachListener']():this['stopPolling']();const _0x51366e=()=>{const _0xb8075c=this['storage']['getItem'](_0x4f2ee0);!_0x4c8fc9&&this['localCache'][_0x4f2ee0]===_0xb8075c||this['notifyListeners'](_0x4f2ee0,_0xb8075c);},_0x31674a=this['storage']['getItem'](_0x4f2ee0);Af()&&_0x31674a!==_0x288865['newValue']&&_0x288865['newValue']!==_0x288865['oldValue']?setTimeout(_0x51366e,op):_0x51366e();}['notifyListeners'](_0x2cc481,_0x44ed7c){this['localCache'][_0x2cc481]=_0x44ed7c;const _0x4f81d0=this['listeners'][_0x2cc481];if(_0x4f81d0){for(const _0x1e8427 of Array['from'](_0x4f81d0))_0x1e8427(_0x44ed7c&&JSON['parse'](_0x44ed7c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x20417c,_0x39997a,_0x201626)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x20417c,'oldValue':_0x39997a,'newValue':_0x201626}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x110bca,_0x22681c){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x110bca]||(this['listeners'][_0x110bca]=new Set(),this['localCache'][_0x110bca]=this['storage']['getItem'](_0x110bca)),this['listeners'][_0x110bca]['add'](_0x22681c);}['_removeListener'](_0x492d8b,_0x317085){this['listeners'][_0x492d8b]&&(this['listeners'][_0x492d8b]['delete'](_0x317085),this['listeners'][_0x492d8b]['size']===0x0&&delete this['listeners'][_0x492d8b]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x12dfa3,_0x1dec42){await super['_set'](_0x12dfa3,_0x1dec42),this['localCache'][_0x12dfa3]=JSON['stringify'](_0x1dec42);}async['_get'](_0x1d02a7){const _0x4ac3bf=await super['_get'](_0x1d02a7);return this['localCache'][_0x1d02a7]=JSON['stringify'](_0x4ac3bf),_0x4ac3bf;}async['_remove'](_0x2e4e0){await super['_remove'](_0x2e4e0),delete this['localCache'][_0x2e4e0];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1f34d7,_0x379b3d){}['_removeListener'](_0x238f3d,_0x25c911){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x342452){return Promise['all'](_0x342452['map'](async _0xc602c2=>{try{return{'fulfilled':!0x0,'value':await _0xc602c2};}catch(_0x428491){return{'fulfilled':!0x1,'reason':_0x428491};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xf3f954){this['eventTarget']=_0xf3f954,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x231f81){const _0x283581=this['receivers']['find'](_0x44bd76=>_0x44bd76['isListeningto'](_0x231f81));if(_0x283581)return _0x283581;const _0x4657e2=new Xn(_0x231f81);return this['receivers']['push'](_0x4657e2),_0x4657e2;}['isListeningto'](_0x4ef831){return this['eventTarget']===_0x4ef831;}async['handleEvent'](_0x1ccf78){const _0x55bb6b=_0x1ccf78,{eventId:_0x36da11,eventType:_0x314498,data:_0x8562a1}=_0x55bb6b['data'],_0x23000d=this['handlersMap'][_0x314498];if(!(_0x23000d!=null&&_0x23000d['size']))return;_0x55bb6b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x36da11,'eventType':_0x314498});const _0x4da7f9=Array['from'](_0x23000d)['map'](async _0xb50649=>_0xb50649(_0x55bb6b['origin'],_0x8562a1)),_0x4f8065=await cp(_0x4da7f9);_0x55bb6b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x36da11,'eventType':_0x314498,'response':_0x4f8065});}['_subscribe'](_0xbaf92f,_0x2a3605){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xbaf92f]||(this['handlersMap'][_0xbaf92f]=new Set()),this['handlersMap'][_0xbaf92f]['add'](_0x2a3605);}['_unsubscribe'](_0x4bff87,_0x2814d3){this['handlersMap'][_0x4bff87]&&_0x2814d3&&this['handlersMap'][_0x4bff87]['delete'](_0x2814d3),(!_0x2814d3||this['handlersMap'][_0x4bff87]['size']===0x0)&&delete this['handlersMap'][_0x4bff87],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x6cda32='',_0x3d9ecb=0xa){let _0x3335cb='';for(let _0x7abfdc=0x0;_0x7abfdc<_0x3d9ecb;_0x7abfdc++)_0x3335cb+=Math['floor'](Math['random']()*0xa);return _0x6cda32+_0x3335cb;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x176b0a){this['target']=_0x176b0a,this['handlers']=new Set();}['removeMessageHandler'](_0x368a5b){_0x368a5b['messageChannel']&&(_0x368a5b['messageChannel']['port1']['removeEventListener']('message',_0x368a5b['onMessage']),_0x368a5b['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x368a5b);}async['_send'](_0x23f945,_0x2fbd44,_0x1a75c3=0x32){const _0x4c98ab=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4c98ab)throw new Error('connection_unavailable');let _0x4ddacc,_0xee99ad;return new Promise((_0x36fff4,_0x38dba6)=>{const _0x4561a6=As('',0x14);_0x4c98ab['port1']['start']();const _0x4dbe5c=setTimeout(()=>{_0x38dba6(new Error('unsupported_event'));},_0x1a75c3);_0xee99ad={'messageChannel':_0x4c98ab,'onMessage'(_0x7181e0){const _0xad620b=_0x7181e0;if(_0xad620b['data']['eventId']===_0x4561a6)switch(_0xad620b['data']['status']){case'ack':clearTimeout(_0x4dbe5c),_0x4ddacc=setTimeout(()=>{_0x38dba6(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4ddacc),_0x36fff4(_0xad620b['data']['response']);break;default:clearTimeout(_0x4dbe5c),clearTimeout(_0x4ddacc),_0x38dba6(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xee99ad),_0x4c98ab['port1']['addEventListener']('message',_0xee99ad['onMessage']),this['target']['postMessage']({'eventType':_0x23f945,'eventId':_0x4561a6,'data':_0x2fbd44},[_0x4c98ab['port2']]);})['finally'](()=>{_0xee99ad&&this['removeMessageHandler'](_0xee99ad);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0xd21d1d){Z()['location']['href']=_0xd21d1d;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4a20be;return((_0x4a20be=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4a20be['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x24a6b7){this['request']=_0x24a6b7;}['toPromise'](){return new Promise((_0x58f8f8,_0x2675cc)=>{this['request']['addEventListener']('success',()=>{_0x58f8f8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2675cc(this['request']['error']);});});}}function Zn(_0x12aee8,_0x954300){return _0x12aee8['transaction']([Mn],_0x954300?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x1fae55=indexedDB['deleteDatabase'](Ka);return new nn(_0x1fae55)['toPromise']();}function Qa(){const _0x56b4e8=indexedDB['open'](Ka,pp);return new Promise((_0x20ce64,_0x33b90b)=>{_0x56b4e8['addEventListener']('error',()=>{_0x33b90b(_0x56b4e8['error']);}),_0x56b4e8['addEventListener']('upgradeneeded',()=>{const _0x113314=_0x56b4e8['result'];try{_0x113314['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x35381c){_0x33b90b(_0x35381c);}}),_0x56b4e8['addEventListener']('success',async()=>{const _0x209bf3=_0x56b4e8['result'];_0x209bf3['objectStoreNames']['contains'](Mn)?_0x20ce64(_0x209bf3):(_0x209bf3['close'](),await _p(),_0x20ce64(await Qa()));});});}async function Or(_0x2b7f0b,_0x423b11,_0x4c81e7){const _0x32d845=Zn(_0x2b7f0b,!0x0)['put']({[Ya]:_0x423b11,'value':_0x4c81e7});return new nn(_0x32d845)['toPromise']();}async function gp(_0x5d1591,_0x3d51be){const _0x38df11=Zn(_0x5d1591,!0x1)['get'](_0x3d51be),_0x5c1ee4=await new nn(_0x38df11)['toPromise']();return _0x5c1ee4===void 0x0?null:_0x5c1ee4['value'];}function Dr(_0x1b411b,_0x5ca5c7){const _0x2b069b=Zn(_0x1b411b,!0x0)['delete'](_0x5ca5c7);return new nn(_0x2b069b)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2466bf){let _0x22195a=0x0;for(;;)try{const _0x4adf80=await this['_openDb']();return await _0x2466bf(_0x4adf80);}catch(_0x348cfa){if(_0x22195a++>yp)throw _0x348cfa;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x13bfff,_0x4bd987)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4bd987['key'])})),this['receiver']['_subscribe']('ping',async(_0x592ff1,_0x3358bc)=>['keyChanged']);}async['initializeSender'](){var _0x5b865a,_0x85cf13;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x272357=await this['sender']['_send']('ping',{},0x320);_0x272357&&(_0x5b865a=_0x272357[0x0])!=null&&_0x5b865a['fulfilled']&&(_0x85cf13=_0x272357[0x0])!=null&&_0x85cf13['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x44cfc4){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x44cfc4},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2c448d=>{await Or(_0x2c448d,Dn,'1'),await Dr(_0x2c448d,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x441f9b){this['pendingWrites']++;try{await _0x441f9b();}finally{this['pendingWrites']--;}}async['_set'](_0x2a6206,_0x33323f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x550a1a=>Or(_0x550a1a,_0x2a6206,_0x33323f)),this['localCache'][_0x2a6206]=_0x33323f,this['notifyServiceWorker'](_0x2a6206)));}async['_get'](_0x135305){const _0x2faf9e=await this['_withRetries'](_0x2ddd18=>gp(_0x2ddd18,_0x135305));return this['localCache'][_0x135305]=_0x2faf9e,_0x2faf9e;}async['_remove'](_0x47f079){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4026ed=>Dr(_0x4026ed,_0x47f079)),delete this['localCache'][_0x47f079],this['notifyServiceWorker'](_0x47f079)));}async['_poll'](){const _0x40558b=await this['_withRetries'](_0x4ffbc9=>{const _0x57cc5d=Zn(_0x4ffbc9,!0x1)['getAll']();return new nn(_0x57cc5d)['toPromise']();});if(!_0x40558b)return[];if(this['pendingWrites']!==0x0)return[];const _0x3487d7=[],_0x5bff49=new Set();if(_0x40558b['length']!==0x0){for(const {fbase_key:_0x2bf0da,value:_0x11f1ff}of _0x40558b)_0x5bff49['add'](_0x2bf0da),JSON['stringify'](this['localCache'][_0x2bf0da])!==JSON['stringify'](_0x11f1ff)&&(this['notifyListeners'](_0x2bf0da,_0x11f1ff),_0x3487d7['push'](_0x2bf0da));}for(const _0x2504fe of Object['keys'](this['localCache']))this['localCache'][_0x2504fe]&&!_0x5bff49['has'](_0x2504fe)&&(this['notifyListeners'](_0x2504fe,null),_0x3487d7['push'](_0x2504fe));return _0x3487d7;}['notifyListeners'](_0x252a7a,_0x976725){this['localCache'][_0x252a7a]=_0x976725;const _0xd039d1=this['listeners'][_0x252a7a];if(_0xd039d1){for(const _0x190df7 of Array['from'](_0xd039d1))_0x190df7(_0x976725);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4b3db1,_0x7d3990){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4b3db1]||(this['listeners'][_0x4b3db1]=new Set(),this['_get'](_0x4b3db1)),this['listeners'][_0x4b3db1]['add'](_0x7d3990);}['_removeListener'](_0x55d355,_0x5941c4){this['listeners'][_0x55d355]&&(this['listeners'][_0x55d355]['delete'](_0x5941c4),this['listeners'][_0x55d355]['size']===0x0&&delete this['listeners'][_0x55d355]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1578cd,_0xde5f84){return _0xde5f84?ie(_0xde5f84):(m(_0x1578cd['_popupRedirectResolver'],_0x1578cd,'argument-error'),_0x1578cd['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4401f8){super('custom','custom'),this['params']=_0x4401f8;}['_getIdTokenResponse'](_0x345f57){return nt(_0x345f57,this['_buildIdpRequest']());}['_linkToIdToken'](_0x26dd0e,_0x24326f){return nt(_0x26dd0e,this['_buildIdpRequest'](_0x24326f));}['_getReauthenticationResolver'](_0x4c0768){return nt(_0x4c0768,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x26cfc1){const _0x2c103d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x26cfc1&&(_0x2c103d['idToken']=_0x26cfc1),_0x2c103d;}}function Ip(_0xe12800){return Va(_0xe12800['auth'],new ks(_0xe12800),_0xe12800['bypassAuthState']);}function wp(_0x3c35f4){const {auth:_0x5af4ee,user:_0x59e3a5}=_0x3c35f4;return m(_0x59e3a5,_0x5af4ee,'internal-error'),tp(_0x59e3a5,new ks(_0x3c35f4),_0x3c35f4['bypassAuthState']);}async function Cp(_0x49427d){const {auth:_0x4bb03d,user:_0x3ef3be}=_0x49427d;return m(_0x3ef3be,_0x4bb03d,'internal-error'),ep(_0x3ef3be,new ks(_0x49427d),_0x49427d['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x46d668,_0x553c04,_0x36a74e,_0x4c1606,_0x59356b=!0x1){this['auth']=_0x46d668,this['resolver']=_0x36a74e,this['user']=_0x4c1606,this['bypassAuthState']=_0x59356b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x553c04)?_0x553c04:[_0x553c04];}['execute'](){return new Promise(async(_0x5c3c71,_0x3ed331)=>{this['pendingPromise']={'resolve':_0x5c3c71,'reject':_0x3ed331};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4cfafb){this['reject'](_0x4cfafb);}});}async['onAuthEvent'](_0x4c4871){const {urlResponse:_0x2b0fd8,sessionId:_0x2d382d,postBody:_0x46576e,tenantId:_0x52b14b,error:_0x2c2ec4,type:_0x2d50ab}=_0x4c4871;if(_0x2c2ec4){this['reject'](_0x2c2ec4);return;}const _0x2ae1b5={'auth':this['auth'],'requestUri':_0x2b0fd8,'sessionId':_0x2d382d,'tenantId':_0x52b14b||void 0x0,'postBody':_0x46576e||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2d50ab)(_0x2ae1b5));}catch(_0x36dc4f){this['reject'](_0x36dc4f);}}['onError'](_0x26e878){this['reject'](_0x26e878);}['getIdpTask'](_0x370674){switch(_0x370674){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x549bc0){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x549bc0),this['unregisterAndCleanUp']();}['reject'](_0x100222){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x100222),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0xdf9424,_0x24d97e,_0x14eabd,_0x1f5105,_0x17a5ea){super(_0xdf9424,_0x24d97e,_0x1f5105,_0x17a5ea),this['provider']=_0x14eabd,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x420e9f=await this['execute']();return m(_0x420e9f,this['auth'],'internal-error'),_0x420e9f;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x11242f=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x11242f),this['authWindow']['associatedEvent']=_0x11242f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x42707c=>{this['reject'](_0x42707c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x393e35=>{_0x393e35||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3cbb0b;return((_0x3cbb0b=this['authWindow'])==null?void 0x0:_0x3cbb0b['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0xa71046=()=>{var _0x2be6a2,_0x33f314;if((_0x33f314=(_0x2be6a2=this['authWindow'])==null?void 0x0:_0x2be6a2['window'])!=null&&_0x33f314['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xa71046,Tp['get']());};_0xa71046();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x55e53d,_0x4e4b52,_0x5e1236=!0x1){super(_0x55e53d,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4e4b52,void 0x0,_0x5e1236),this['eventId']=null;}async['execute'](){let _0x6301c3=hn['get'](this['auth']['_key']());if(!_0x6301c3){try{const _0x2646dd=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x6301c3=()=>Promise['resolve'](_0x2646dd);}catch(_0x1b89c8){_0x6301c3=()=>Promise['reject'](_0x1b89c8);}hn['set'](this['auth']['_key'](),_0x6301c3);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x6301c3();}async['onAuthEvent'](_0x4409fa){if(_0x4409fa['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4409fa);if(_0x4409fa['type']==='unknown'){this['resolve'](null);return;}if(_0x4409fa['eventId']){const _0x84d5ed=await this['auth']['_redirectUserForId'](_0x4409fa['eventId']);if(_0x84d5ed)return this['user']=_0x84d5ed,super['onAuthEvent'](_0x4409fa);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3f57f9,_0x229d09){const _0x1bd7b0=Pp(_0x229d09),_0x254537=kp(_0x3f57f9);if(!await _0x254537['_isAvailable']())return!0x1;const _0x21b7e5=await _0x254537['_get'](_0x1bd7b0)==='true';return await _0x254537['_remove'](_0x1bd7b0),_0x21b7e5;}function Ap(_0x11961a,_0x4eb74c){hn['set'](_0x11961a['_key'](),_0x4eb74c);}function kp(_0x29ee37){return ie(_0x29ee37['_redirectPersistence']);}function Pp(_0x272020){return ln(Sp,_0x272020['config']['apiKey'],_0x272020['name']);}async function Np(_0x480307,_0x501447,_0x3444a3=!0x1){if($(_0x480307['app']))return Promise['reject'](re(_0x480307));const _0x15cced=Ke(_0x480307),_0x40e72d=Ep(_0x15cced,_0x501447),_0x1a35e2=await new bp(_0x15cced,_0x40e72d,_0x3444a3)['execute']();return _0x1a35e2&&!_0x3444a3&&(delete _0x1a35e2['user']['_redirectEventId'],await _0x15cced['_persistUserIfCurrent'](_0x1a35e2['user']),await _0x15cced['_setRedirectUser'](null,_0x501447)),_0x1a35e2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x202a20){this['auth']=_0x202a20,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x498af8){this['consumers']['add'](_0x498af8),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x498af8)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x498af8),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x35e0ee){this['consumers']['delete'](_0x35e0ee);}['onEvent'](_0x459e41){if(this['hasEventBeenHandled'](_0x459e41))return!0x1;let _0x3e986c=!0x1;return this['consumers']['forEach'](_0x11e72c=>{this['isEventForConsumer'](_0x459e41,_0x11e72c)&&(_0x3e986c=!0x0,this['sendToConsumer'](_0x459e41,_0x11e72c),this['saveEventToCache'](_0x459e41));}),this['hasHandledPotentialRedirect']||!Mp(_0x459e41)||(this['hasHandledPotentialRedirect']=!0x0,_0x3e986c||(this['queuedRedirectEvent']=_0x459e41,_0x3e986c=!0x0)),_0x3e986c;}['sendToConsumer'](_0x41fcdc,_0x49dc11){var _0x4a1f15;if(_0x41fcdc['error']&&!Za(_0x41fcdc)){const _0x5c5636=((_0x4a1f15=_0x41fcdc['error']['code'])==null?void 0x0:_0x4a1f15['split']('auth/')[0x1])||'internal-error';_0x49dc11['onError'](X(this['auth'],_0x5c5636));}else _0x49dc11['onAuthEvent'](_0x41fcdc);}['isEventForConsumer'](_0x1620a0,_0x360ba1){const _0xd52e2c=_0x360ba1['eventId']===null||!!_0x1620a0['eventId']&&_0x1620a0['eventId']===_0x360ba1['eventId'];return _0x360ba1['filter']['includes'](_0x1620a0['type'])&&_0xd52e2c;}['hasEventBeenHandled'](_0xded2ba){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0xded2ba));}['saveEventToCache'](_0x13f4ef){this['cachedEventUids']['add'](Mr(_0x13f4ef)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2cd8d1){return[_0x2cd8d1['type'],_0x2cd8d1['eventId'],_0x2cd8d1['sessionId'],_0x2cd8d1['tenantId']]['filter'](_0x4e480e=>_0x4e480e)['join']('-');}function Za({type:_0x75bd84,error:_0x380ad6}){return _0x75bd84==='unknown'&&(_0x380ad6==null?void 0x0:_0x380ad6['code'])==='auth/no-auth-event';}function Mp(_0x1f0afd){switch(_0x1f0afd['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1f0afd);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1683e5,_0x524e93={}){return Pe(_0x1683e5,'GET','/v1/projects',_0x524e93);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x340972){if(_0x340972['config']['emulator'])return;const {authorizedDomains:_0x338219}=await Lp(_0x340972);for(const _0x49ba4f of _0x338219)try{if(Wp(_0x49ba4f))return;}catch{}Y(_0x340972,'unauthorized-domain');}function Wp(_0x2faf4a){const _0x23ffe1=Mi(),{protocol:_0x3bf3ff,hostname:_0x49a3f3}=new URL(_0x23ffe1);if(_0x2faf4a['startsWith']('chrome-extension://')){const _0x3ac9ae=new URL(_0x2faf4a);return _0x3ac9ae['hostname']===''&&_0x49a3f3===''?_0x3bf3ff==='chrome-extension:'&&_0x2faf4a['replace']('chrome-extension://','')===_0x23ffe1['replace']('chrome-extension://',''):_0x3bf3ff==='chrome-extension:'&&_0x3ac9ae['hostname']===_0x49a3f3;}if(!Fp['test'](_0x3bf3ff))return!0x1;if(xp['test'](_0x2faf4a))return _0x49a3f3===_0x2faf4a;const _0x863105=_0x2faf4a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x863105+'|'+_0x863105+')$','i')['test'](_0x49a3f3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x246566=Z()['___jsl'];if(_0x246566!=null&&_0x246566['H']){for(const _0x40bca8 of Object['keys'](_0x246566['H']))if(_0x246566['H'][_0x40bca8]['r']=_0x246566['H'][_0x40bca8]['r']||[],_0x246566['H'][_0x40bca8]['L']=_0x246566['H'][_0x40bca8]['L']||[],_0x246566['H'][_0x40bca8]['r']=[..._0x246566['H'][_0x40bca8]['L']],_0x246566['CP']){for(let _0x3dba7d=0x0;_0x3dba7d<_0x246566['CP']['length'];_0x3dba7d++)_0x246566['CP'][_0x3dba7d]=null;}}}function Vp(_0xd64756){return new Promise((_0x5b926c,_0x876e48)=>{var _0x137470,_0x2d99d1,_0x3fb646;function _0x2a1cc7(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5b926c(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x876e48(X(_0xd64756,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2d99d1=(_0x137470=Z()['gapi'])==null?void 0x0:_0x137470['iframes'])!=null&&_0x2d99d1['Iframe'])_0x5b926c(gapi['iframes']['getContext']());else{if((_0x3fb646=Z()['gapi'])!=null&&_0x3fb646['load'])_0x2a1cc7();else{const _0xf132a8=Ff('iframefcb');return Z()[_0xf132a8]=()=>{gapi['load']?_0x2a1cc7():_0x876e48(X(_0xd64756,'network-request-failed'));},xa(xf()+'?onload='+_0xf132a8)['catch'](_0x4d8344=>_0x876e48(_0x4d8344));}}})['catch'](_0x26e4a3=>{throw un=null,_0x26e4a3;});}let un=null;function Hp(_0x3d3bf8){return un=un||Vp(_0x3d3bf8),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x5979a0){const _0x552333=_0x5979a0['config'];m(_0x552333['authDomain'],_0x5979a0,'auth-domain-config-required');const _0x541a5f=_0x552333['emulator']?Cs(_0x552333,qp):'https://'+_0x5979a0['config']['authDomain']+'/'+Gp,_0x6c9d5a={'apiKey':_0x552333['apiKey'],'appName':_0x5979a0['name'],'v':dt},_0x31df51=jp['get'](_0x5979a0['config']['apiHost']);_0x31df51&&(_0x6c9d5a['eid']=_0x31df51);const _0x44903d=_0x5979a0['_getFrameworks']();return _0x44903d['length']&&(_0x6c9d5a['fw']=_0x44903d['join'](',')),_0x541a5f+'?'+ut(_0x6c9d5a)['slice'](0x1);}async function Yp(_0x2e5902){const _0x26cfe9=await Hp(_0x2e5902),_0x306fa6=Z()['gapi'];return m(_0x306fa6,_0x2e5902,'internal-error'),_0x26cfe9['open']({'where':document['body'],'url':Kp(_0x2e5902),'messageHandlersFilter':_0x306fa6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x38dd5e=>new Promise(async(_0x3a56f0,_0x44c2d4)=>{await _0x38dd5e['restyle']({'setHideOnLeave':!0x1});const _0x43bc7e=X(_0x2e5902,'network-request-failed'),_0x14636a=Z()['setTimeout'](()=>{_0x44c2d4(_0x43bc7e);},$p['get']());function _0x2812a1(){Z()['clearTimeout'](_0x14636a),_0x3a56f0(_0x38dd5e);}_0x38dd5e['ping'](_0x2812a1)['then'](_0x2812a1,()=>{_0x44c2d4(_0x43bc7e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x15bc56){this['window']=_0x15bc56,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x214c07,_0x2155f4,_0x47d7ea,_0x27a6ee=Jp,_0x508a35=Xp){const _0x248e89=Math['max']((window['screen']['availHeight']-_0x508a35)/0x2,0x0)['toString'](),_0x58f4ec=Math['max']((window['screen']['availWidth']-_0x27a6ee)/0x2,0x0)['toString']();let _0x863778='';const _0x317e0c={...Qp,'width':_0x27a6ee['toString'](),'height':_0x508a35['toString'](),'top':_0x248e89,'left':_0x58f4ec},_0xffa849=W()['toLowerCase']();_0x47d7ea&&(_0x863778=ka(_0xffa849)?Zp:_0x47d7ea),Ra(_0xffa849)&&(_0x2155f4=_0x2155f4||e_,_0x317e0c['scrollbars']='yes');const _0xc34126=Object['entries'](_0x317e0c)['reduce']((_0x535306,[_0x5f00e7,_0x5fd969])=>''+_0x535306+_0x5f00e7+'='+_0x5fd969+',','');if(Rf(_0xffa849)&&_0x863778!=='_self')return n_(_0x2155f4||'',_0x863778),new xr(null);const _0x1d07fd=window['open'](_0x2155f4||'',_0x863778,_0xc34126);m(_0x1d07fd,_0x214c07,'popup-blocked');try{_0x1d07fd['focus']();}catch{}return new xr(_0x1d07fd);}function n_(_0xd50fa6,_0x26edb4){const _0x29d75a=document['createElement']('a');_0x29d75a['href']=_0xd50fa6,_0x29d75a['target']=_0x26edb4;const _0x67ae4a=document['createEvent']('MouseEvent');_0x67ae4a['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x29d75a['dispatchEvent'](_0x67ae4a);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x2280ba,_0x2342e1,_0xbd5f89,_0x5eec97,_0x2625b1,_0x3659b1){m(_0x2280ba['config']['authDomain'],_0x2280ba,'auth-domain-config-required'),m(_0x2280ba['config']['apiKey'],_0x2280ba,'invalid-api-key');const _0x34d54e={'apiKey':_0x2280ba['config']['apiKey'],'appName':_0x2280ba['name'],'authType':_0xbd5f89,'redirectUrl':_0x5eec97,'v':dt,'eventId':_0x2625b1};if(_0x2342e1 instanceof Wa){_0x2342e1['setDefaultLanguage'](_0x2280ba['languageCode']),_0x34d54e['providerId']=_0x2342e1['providerId']||'',pn(_0x2342e1['getCustomParameters']())||(_0x34d54e['customParameters']=JSON['stringify'](_0x2342e1['getCustomParameters']()));for(const [_0x27ec30,_0x46608a]of Object['entries']({}))_0x34d54e[_0x27ec30]=_0x46608a;}if(_0x2342e1 instanceof tn){const _0x226b8a=_0x2342e1['getScopes']()['filter'](_0x36fbb6=>_0x36fbb6!=='');_0x226b8a['length']>0x0&&(_0x34d54e['scopes']=_0x226b8a['join'](','));}_0x2280ba['tenantId']&&(_0x34d54e['tid']=_0x2280ba['tenantId']);const _0x225a82=_0x34d54e;for(const _0x359500 of Object['keys'](_0x225a82))_0x225a82[_0x359500]===void 0x0&&delete _0x225a82[_0x359500];const _0x378ddd=await _0x2280ba['_getAppCheckToken'](),_0x40e134=_0x378ddd?'#'+r_+'='+encodeURIComponent(_0x378ddd):'';return o_(_0x2280ba)+'?'+ut(_0x225a82)['slice'](0x1)+_0x40e134;}function o_({config:_0x37498f}){return _0x37498f['emulator']?Cs(_0x37498f,s_):'https://'+_0x37498f['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x3528c0,_0x1e47bc,_0x264ea0,_0x266efc){var _0x433f3d;ce((_0x433f3d=this['eventManagers'][_0x3528c0['_key']()])==null?void 0x0:_0x433f3d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1ebdc6=await Fr(_0x3528c0,_0x1e47bc,_0x264ea0,Mi(),_0x266efc);return t_(_0x3528c0,_0x1ebdc6,As());}async['_openRedirect'](_0x3937a1,_0x5bc137,_0x397fab,_0x7fdef3){await this['_originValidation'](_0x3937a1);const _0x580148=await Fr(_0x3937a1,_0x5bc137,_0x397fab,Mi(),_0x7fdef3);return hp(_0x580148),new Promise(()=>{});}['_initialize'](_0x2cd0f4){const _0x45e27e=_0x2cd0f4['_key']();if(this['eventManagers'][_0x45e27e]){const {manager:_0x35bac6,promise:_0x4605b7}=this['eventManagers'][_0x45e27e];return _0x35bac6?Promise['resolve'](_0x35bac6):(ce(_0x4605b7,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4605b7);}const _0x36c940=this['initAndGetManager'](_0x2cd0f4);return this['eventManagers'][_0x45e27e]={'promise':_0x36c940},_0x36c940['catch'](()=>{delete this['eventManagers'][_0x45e27e];}),_0x36c940;}async['initAndGetManager'](_0xe7d13a){const _0x51d1eb=await Yp(_0xe7d13a),_0x559f24=new Dp(_0xe7d13a);return _0x51d1eb['register']('authEvent',_0x4e73a7=>(m(_0x4e73a7==null?void 0x0:_0x4e73a7['authEvent'],_0xe7d13a,'invalid-auth-event'),{'status':_0x559f24['onEvent'](_0x4e73a7['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xe7d13a['_key']()]={'manager':_0x559f24},this['iframes'][_0xe7d13a['_key']()]=_0x51d1eb,_0x559f24;}['_isIframeWebStorageSupported'](_0x5a3dc0,_0x2b1119){this['iframes'][_0x5a3dc0['_key']()]['send'](pi,{'type':pi},_0x410451=>{var _0x319f37;const _0x51bc8d=(_0x319f37=_0x410451==null?void 0x0:_0x410451[0x0])==null?void 0x0:_0x319f37[pi];_0x51bc8d!==void 0x0&&_0x2b1119(!!_0x51bc8d),Y(_0x5a3dc0,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x968233){const _0x59b005=_0x968233['_key']();return this['originValidationPromises'][_0x59b005]||(this['originValidationPromises'][_0x59b005]=Up(_0x968233)),this['originValidationPromises'][_0x59b005];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x430b93){this['auth']=_0x430b93,this['internalListeners']=new Map();}['getUid'](){var _0x2f8111;return this['assertAuthConfigured'](),((_0x2f8111=this['auth']['currentUser'])==null?void 0x0:_0x2f8111['uid'])||null;}async['getToken'](_0x1eaa5d){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1eaa5d)}:null;}['addAuthTokenListener'](_0xbcf292){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0xbcf292))return;const _0x45b54a=this['auth']['onIdTokenChanged'](_0x9ef49f=>{_0xbcf292((_0x9ef49f==null?void 0x0:_0x9ef49f['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0xbcf292,_0x45b54a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x317e5a){this['assertAuthConfigured']();const _0xd9094b=this['internalListeners']['get'](_0x317e5a);_0xd9094b&&(this['internalListeners']['delete'](_0x317e5a),_0xd9094b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x55c904){switch(_0x55c904){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x56538b){st(new Fe('auth',(_0x16d9cc,{options:_0xb661f0})=>{const _0x4c9d10=_0x16d9cc['getProvider']('app')['getImmediate'](),_0x3fd3eb=_0x16d9cc['getProvider']('heartbeat'),_0xfbcb33=_0x16d9cc['getProvider']('app-check-internal'),{apiKey:_0x2a0ed3,authDomain:_0x210f3b}=_0x4c9d10['options'];m(_0x2a0ed3&&!_0x2a0ed3['includes'](':'),'invalid-api-key',{'appName':_0x4c9d10['name']});const _0x135efd={'apiKey':_0x2a0ed3,'authDomain':_0x210f3b,'clientPlatform':_0x56538b,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x56538b)},_0x17ff45=new Df(_0x4c9d10,_0x3fd3eb,_0xfbcb33,_0x135efd);return Hf(_0x17ff45,_0xb661f0),_0x17ff45;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x31d309,_0x366912,_0x22c2a0)=>{_0x31d309['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x5a24b4=>{const _0x197902=Ke(_0x5a24b4['getProvider']('auth')['getImmediate']());return(_0x6ed158=>new l_(_0x6ed158))(_0x197902);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x56538b)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1b7ae6=>async _0x50e603=>{const _0x408f99=_0x50e603&&await _0x50e603['getIdTokenResult'](),_0x3320fe=_0x408f99&&(new Date()['getTime']()-Date['parse'](_0x408f99['issuedAtTime']))/0x3e8;if(_0x3320fe&&_0x3320fe>f_)return;const _0x16b03a=_0x408f99==null?void 0x0:_0x408f99['token'];Br!==_0x16b03a&&(Br=_0x16b03a,await fetch(_0x1b7ae6,{'method':_0x16b03a?'POST':'DELETE','headers':_0x16b03a?{'Authorization':'Bearer\x20'+_0x16b03a}:{}}));};function B_(_0x5dc9ca=Zr()){const _0x3a46a8=Hi(_0x5dc9ca,'auth');if(_0x3a46a8['isInitialized']())return _0x3a46a8['getImmediate']();const _0x4b31e8=Vf(_0x5dc9ca,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x500177=jr('authTokenSyncURL');if(_0x500177&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2889be=new URL(_0x500177,location['origin']);if(location['origin']===_0x2889be['origin']){const _0x58d413=p_(_0x2889be['toString']());sp(_0x4b31e8,_0x58d413,()=>_0x58d413(_0x4b31e8['currentUser'])),ip(_0x4b31e8,_0x3f27bf=>_0x58d413(_0x3f27bf));}}const _0x269afd=qr('auth');return _0x269afd&&$f(_0x4b31e8,'http://'+_0x269afd),_0x4b31e8;}function __(){var _0x5b7a09;return((_0x5b7a09=document['getElementsByTagName']('head'))==null?void 0x0:_0x5b7a09[0x0])??document;}Mf({'loadJS'(_0x40dfcf){return new Promise((_0x3a3485,_0x12d4c2)=>{const _0x1eba70=document['createElement']('script');_0x1eba70['setAttribute']('src',_0x40dfcf),_0x1eba70['onload']=_0x3a3485,_0x1eba70['onerror']=_0x2d1c4a=>{const _0x56c387=X('internal-error');_0x56c387['customData']=_0x2d1c4a,_0x12d4c2(_0x56c387);},_0x1eba70['type']='text/javascript',_0x1eba70['charset']='UTF-8',__()['appendChild'](_0x1eba70);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};