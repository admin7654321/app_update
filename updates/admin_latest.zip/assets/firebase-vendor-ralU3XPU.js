const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3a97ed,_0x5d984a){if(!_0x3a97ed)throw ht(_0x5d984a);},ht=function(_0x5f64f2){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5f64f2);},Hr=function(_0x480278){const _0x413a2d=[];let _0x1a51d6=0x0;for(let _0x274561=0x0;_0x274561<_0x480278['length'];_0x274561++){let _0x56da8e=_0x480278['charCodeAt'](_0x274561);_0x56da8e<0x80?_0x413a2d[_0x1a51d6++]=_0x56da8e:_0x56da8e<0x800?(_0x413a2d[_0x1a51d6++]=_0x56da8e>>0x6|0xc0,_0x413a2d[_0x1a51d6++]=_0x56da8e&0x3f|0x80):(_0x56da8e&0xfc00)===0xd800&&_0x274561+0x1<_0x480278['length']&&(_0x480278['charCodeAt'](_0x274561+0x1)&0xfc00)===0xdc00?(_0x56da8e=0x10000+((_0x56da8e&0x3ff)<<0xa)+(_0x480278['charCodeAt'](++_0x274561)&0x3ff),_0x413a2d[_0x1a51d6++]=_0x56da8e>>0x12|0xf0,_0x413a2d[_0x1a51d6++]=_0x56da8e>>0xc&0x3f|0x80,_0x413a2d[_0x1a51d6++]=_0x56da8e>>0x6&0x3f|0x80,_0x413a2d[_0x1a51d6++]=_0x56da8e&0x3f|0x80):(_0x413a2d[_0x1a51d6++]=_0x56da8e>>0xc|0xe0,_0x413a2d[_0x1a51d6++]=_0x56da8e>>0x6&0x3f|0x80,_0x413a2d[_0x1a51d6++]=_0x56da8e&0x3f|0x80);}return _0x413a2d;},nc=function(_0x50d907){const _0x26657d=[];let _0x4aaf79=0x0,_0x257c2e=0x0;for(;_0x4aaf79<_0x50d907['length'];){const _0x210582=_0x50d907[_0x4aaf79++];if(_0x210582<0x80)_0x26657d[_0x257c2e++]=String['fromCharCode'](_0x210582);else{if(_0x210582>0xbf&&_0x210582<0xe0){const _0x47db3a=_0x50d907[_0x4aaf79++];_0x26657d[_0x257c2e++]=String['fromCharCode']((_0x210582&0x1f)<<0x6|_0x47db3a&0x3f);}else{if(_0x210582>0xef&&_0x210582<0x16d){const _0x21275a=_0x50d907[_0x4aaf79++],_0x12c934=_0x50d907[_0x4aaf79++],_0x5216bd=_0x50d907[_0x4aaf79++],_0x5031e9=((_0x210582&0x7)<<0x12|(_0x21275a&0x3f)<<0xc|(_0x12c934&0x3f)<<0x6|_0x5216bd&0x3f)-0x10000;_0x26657d[_0x257c2e++]=String['fromCharCode'](0xd800+(_0x5031e9>>0xa)),_0x26657d[_0x257c2e++]=String['fromCharCode'](0xdc00+(_0x5031e9&0x3ff));}else{const _0x1d5a8a=_0x50d907[_0x4aaf79++],_0x14a906=_0x50d907[_0x4aaf79++];_0x26657d[_0x257c2e++]=String['fromCharCode']((_0x210582&0xf)<<0xc|(_0x1d5a8a&0x3f)<<0x6|_0x14a906&0x3f);}}}}return _0x26657d['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3672da,_0x26c92b){if(!Array['isArray'](_0x3672da))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x21e555=_0x26c92b?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x378b5d=[];for(let _0xdeeab4=0x0;_0xdeeab4<_0x3672da['length'];_0xdeeab4+=0x3){const _0x502e96=_0x3672da[_0xdeeab4],_0x25092d=_0xdeeab4+0x1<_0x3672da['length'],_0x127f90=_0x25092d?_0x3672da[_0xdeeab4+0x1]:0x0,_0x13edc2=_0xdeeab4+0x2<_0x3672da['length'],_0x2f8ca8=_0x13edc2?_0x3672da[_0xdeeab4+0x2]:0x0,_0x201d84=_0x502e96>>0x2,_0x4a8cbf=(_0x502e96&0x3)<<0x4|_0x127f90>>0x4;let _0x188f07=(_0x127f90&0xf)<<0x2|_0x2f8ca8>>0x6,_0x2fdea7=_0x2f8ca8&0x3f;_0x13edc2||(_0x2fdea7=0x40,_0x25092d||(_0x188f07=0x40)),_0x378b5d['push'](_0x21e555[_0x201d84],_0x21e555[_0x4a8cbf],_0x21e555[_0x188f07],_0x21e555[_0x2fdea7]);}return _0x378b5d['join']('');},'encodeString'(_0x114506,_0x117246){return this['HAS_NATIVE_SUPPORT']&&!_0x117246?btoa(_0x114506):this['encodeByteArray'](Hr(_0x114506),_0x117246);},'decodeString'(_0x11f11f,_0x1185e8){return this['HAS_NATIVE_SUPPORT']&&!_0x1185e8?atob(_0x11f11f):nc(this['decodeStringToByteArray'](_0x11f11f,_0x1185e8));},'decodeStringToByteArray'(_0x207daa,_0x4965b6){this['init_']();const _0x441c36=_0x4965b6?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x12bbb8=[];for(let _0x4d7883=0x0;_0x4d7883<_0x207daa['length'];){const _0x3048e8=_0x441c36[_0x207daa['charAt'](_0x4d7883++)],_0x369d84=_0x4d7883<_0x207daa['length']?_0x441c36[_0x207daa['charAt'](_0x4d7883)]:0x0;++_0x4d7883;const _0x16815f=_0x4d7883<_0x207daa['length']?_0x441c36[_0x207daa['charAt'](_0x4d7883)]:0x40;++_0x4d7883;const _0x188f5e=_0x4d7883<_0x207daa['length']?_0x441c36[_0x207daa['charAt'](_0x4d7883)]:0x40;if(++_0x4d7883,_0x3048e8==null||_0x369d84==null||_0x16815f==null||_0x188f5e==null)throw new ic();const _0x30c34e=_0x3048e8<<0x2|_0x369d84>>0x4;if(_0x12bbb8['push'](_0x30c34e),_0x16815f!==0x40){const _0xe5feca=_0x369d84<<0x4&0xf0|_0x16815f>>0x2;if(_0x12bbb8['push'](_0xe5feca),_0x188f5e!==0x40){const _0xc16b7e=_0x16815f<<0x6&0xc0|_0x188f5e;_0x12bbb8['push'](_0xc16b7e);}}}return _0x12bbb8;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3e5f2e=0x0;_0x3e5f2e<this['ENCODED_VALS']['length'];_0x3e5f2e++)this['byteToCharMap_'][_0x3e5f2e]=this['ENCODED_VALS']['charAt'](_0x3e5f2e),this['charToByteMap_'][this['byteToCharMap_'][_0x3e5f2e]]=_0x3e5f2e,this['byteToCharMapWebSafe_'][_0x3e5f2e]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3e5f2e),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3e5f2e]]=_0x3e5f2e,_0x3e5f2e>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3e5f2e)]=_0x3e5f2e,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3e5f2e)]=_0x3e5f2e);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3a66e4){const _0x1b7534=Hr(_0x3a66e4);return Fi['encodeByteArray'](_0x1b7534,!0x0);},dn=function(_0x2b34a3){return $r(_0x2b34a3)['replace'](/\./g,'');},fn=function(_0x2948f9){try{return Fi['decodeString'](_0x2948f9,!0x0);}catch(_0x47adde){console['error']('base64Decode\x20failed:\x20',_0x47adde);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x398863){return Gr(void 0x0,_0x398863);}function Gr(_0x32bcfd,_0x1c06df){if(!(_0x1c06df instanceof Object))return _0x1c06df;switch(_0x1c06df['constructor']){case Date:const _0x6f5aa7=_0x1c06df;return new Date(_0x6f5aa7['getTime']());case Object:_0x32bcfd===void 0x0&&(_0x32bcfd={});break;case Array:_0x32bcfd=[];break;default:return _0x1c06df;}for(const _0x313248 in _0x1c06df)!_0x1c06df['hasOwnProperty'](_0x313248)||!rc(_0x313248)||(_0x32bcfd[_0x313248]=Gr(_0x32bcfd[_0x313248],_0x1c06df[_0x313248]));return _0x32bcfd;}function rc(_0x541415){return _0x541415!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1c57da=Ps['__FIREBASE_DEFAULTS__'];if(_0x1c57da)return JSON['parse'](_0x1c57da);},lc=()=>{if(typeof document>'u')return;let _0x34245f;try{_0x34245f=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x4bab85=_0x34245f&&fn(_0x34245f[0x1]);return _0x4bab85&&JSON['parse'](_0x4bab85);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x155e27){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x155e27);return;}},qr=_0x4d4aff=>{var _0x1fbf76,_0x32245c;return(_0x32245c=(_0x1fbf76=Ui())==null?void 0x0:_0x1fbf76['emulatorHosts'])==null?void 0x0:_0x32245c[_0x4d4aff];},hc=_0x1a6fc5=>{const _0x597c24=qr(_0x1a6fc5);if(!_0x597c24)return;const _0x588347=_0x597c24['lastIndexOf'](':');if(_0x588347<=0x0||_0x588347+0x1===_0x597c24['length'])throw new Error('Invalid\x20host\x20'+_0x597c24+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x31bd1f=parseInt(_0x597c24['substring'](_0x588347+0x1),0xa);return _0x597c24[0x0]==='['?[_0x597c24['substring'](0x1,_0x588347-0x1),_0x31bd1f]:[_0x597c24['substring'](0x0,_0x588347),_0x31bd1f];},zr=()=>{var _0x2774fb;return(_0x2774fb=Ui())==null?void 0x0:_0x2774fb['config'];},jr=_0x5bcc3b=>{var _0x4a2d84;return(_0x4a2d84=Ui())==null?void 0x0:_0x4a2d84['_'+_0x5bcc3b];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3a1dde,_0x5f3ecc)=>{this['resolve']=_0x3a1dde,this['reject']=_0x5f3ecc;});}['wrapCallback'](_0xa34ff9){return(_0x21375e,_0x5cdb0f)=>{_0x21375e?this['reject'](_0x21375e):this['resolve'](_0x5cdb0f),typeof _0xa34ff9=='function'&&(this['promise']['catch'](()=>{}),_0xa34ff9['length']===0x1?_0xa34ff9(_0x21375e):_0xa34ff9(_0x21375e,_0x5cdb0f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x39bcc2,_0x5d4c99){if(_0x39bcc2['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4943a2={'alg':'none','type':'JWT'},_0x9d70bd=_0x5d4c99||'demo-project',_0x1f8359=_0x39bcc2['iat']||0x0,_0x3da44a=_0x39bcc2['sub']||_0x39bcc2['user_id'];if(!_0x3da44a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x751993={'iss':'https://securetoken.google.com/'+_0x9d70bd,'aud':_0x9d70bd,'iat':_0x1f8359,'exp':_0x1f8359+0xe10,'auth_time':_0x1f8359,'sub':_0x3da44a,'user_id':_0x3da44a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x39bcc2};return[dn(JSON['stringify'](_0x4943a2)),dn(JSON['stringify'](_0x751993)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x2f9653=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2f9653=='object'&&_0x2f9653['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2dc998=W();return _0x2dc998['indexOf']('MSIE\x20')>=0x0||_0x2dc998['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x8d981d,_0x4487fc)=>{try{let _0x53144b=!0x0;const _0x1d0c37='validate-browser-context-for-indexeddb-analytics-module',_0x20dc68=self['indexedDB']['open'](_0x1d0c37);_0x20dc68['onsuccess']=()=>{_0x20dc68['result']['close'](),_0x53144b||self['indexedDB']['deleteDatabase'](_0x1d0c37),_0x8d981d(!0x0);},_0x20dc68['onupgradeneeded']=()=>{_0x53144b=!0x1;},_0x20dc68['onerror']=()=>{var _0x2342e0;_0x4487fc(((_0x2342e0=_0x20dc68['error'])==null?void 0x0:_0x2342e0['message'])||'');};}catch(_0x4531ca){_0x4487fc(_0x4531ca);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x36b8dd,_0x14a311,_0x5dd464){super(_0x14a311),this['code']=_0x36b8dd,this['customData']=_0x5dd464,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x309fda,_0x188136,_0x3129d7){this['service']=_0x309fda,this['serviceName']=_0x188136,this['errors']=_0x3129d7;}['create'](_0x469e0a,..._0x553428){const _0x352916=_0x553428[0x0]||{},_0x12bc2d=this['service']+'/'+_0x469e0a,_0x549ed8=this['errors'][_0x469e0a],_0x2dc281=_0x549ed8?vc(_0x549ed8,_0x352916):'Error',_0x3713e8=this['serviceName']+':\x20'+_0x2dc281+'\x20('+_0x12bc2d+').';return new Re(_0x12bc2d,_0x3713e8,_0x352916);}}function vc(_0x5ea5e2,_0x978ea7){return _0x5ea5e2['replace'](Ec,(_0x46f429,_0x4c7884)=>{const _0x27903a=_0x978ea7[_0x4c7884];return _0x27903a!=null?String(_0x27903a):'<'+_0x4c7884+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x51fcb8){return JSON['parse'](_0x51fcb8);}function O(_0x65b08d){return JSON['stringify'](_0x65b08d);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2f3300){let _0x45b5a5={},_0x5212c2={},_0x48eccc={},_0x19034c='';try{const _0x23bc02=_0x2f3300['split']('.');_0x45b5a5=Nt(fn(_0x23bc02[0x0])||''),_0x5212c2=Nt(fn(_0x23bc02[0x1])||''),_0x19034c=_0x23bc02[0x2],_0x48eccc=_0x5212c2['d']||{},delete _0x5212c2['d'];}catch{}return{'header':_0x45b5a5,'claims':_0x5212c2,'data':_0x48eccc,'signature':_0x19034c};},Ic=function(_0x150729){const _0x206700=Yr(_0x150729),_0x4a0dcf=_0x206700['claims'];return!!_0x4a0dcf&&typeof _0x4a0dcf=='object'&&_0x4a0dcf['hasOwnProperty']('iat');},wc=function(_0x313015){const _0x1beb08=Yr(_0x313015)['claims'];return typeof _0x1beb08=='object'&&_0x1beb08['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2f1055,_0x5bb722){return Object['prototype']['hasOwnProperty']['call'](_0x2f1055,_0x5bb722);}function Le(_0x2f2c95,_0x34dbf9){if(Object['prototype']['hasOwnProperty']['call'](_0x2f2c95,_0x34dbf9))return _0x2f2c95[_0x34dbf9];}function pn(_0x32ba75){for(const _0x199829 in _0x32ba75)if(Object['prototype']['hasOwnProperty']['call'](_0x32ba75,_0x199829))return!0x1;return!0x0;}function _n(_0x328cfb,_0x396fa6,_0x1aa904){const _0x285384={};for(const _0x514ed1 in _0x328cfb)Object['prototype']['hasOwnProperty']['call'](_0x328cfb,_0x514ed1)&&(_0x285384[_0x514ed1]=_0x396fa6['call'](_0x1aa904,_0x328cfb[_0x514ed1],_0x514ed1,_0x328cfb));return _0x285384;}function xe(_0x456e44,_0x1e8c52){if(_0x456e44===_0x1e8c52)return!0x0;const _0x198111=Object['keys'](_0x456e44),_0x38dd35=Object['keys'](_0x1e8c52);for(const _0x26049c of _0x198111){if(!_0x38dd35['includes'](_0x26049c))return!0x1;const _0x3e8523=_0x456e44[_0x26049c],_0x2e3c21=_0x1e8c52[_0x26049c];if(Ns(_0x3e8523)&&Ns(_0x2e3c21)){if(!xe(_0x3e8523,_0x2e3c21))return!0x1;}else{if(_0x3e8523!==_0x2e3c21)return!0x1;}}for(const _0x3c9832 of _0x38dd35)if(!_0x198111['includes'](_0x3c9832))return!0x1;return!0x0;}function Ns(_0x19787b){return _0x19787b!==null&&typeof _0x19787b=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x51daf6){const _0x486b0f=[];for(const [_0x395fd2,_0x565b76]of Object['entries'](_0x51daf6))Array['isArray'](_0x565b76)?_0x565b76['forEach'](_0x13e5db=>{_0x486b0f['push'](encodeURIComponent(_0x395fd2)+'='+encodeURIComponent(_0x13e5db));}):_0x486b0f['push'](encodeURIComponent(_0x395fd2)+'='+encodeURIComponent(_0x565b76));return _0x486b0f['length']?'&'+_0x486b0f['join']('&'):'';}function Ct(_0x5b3885){const _0xe37770={};return _0x5b3885['replace'](/^\?/,'')['split']('&')['forEach'](_0x365f78=>{if(_0x365f78){const [_0x353052,_0x4b8e8a]=_0x365f78['split']('=');_0xe37770[decodeURIComponent(_0x353052)]=decodeURIComponent(_0x4b8e8a);}}),_0xe37770;}function Tt(_0x1a072a){const _0x3bc319=_0x1a072a['indexOf']('?');if(!_0x3bc319)return'';const _0x1335d9=_0x1a072a['indexOf']('#',_0x3bc319);return _0x1a072a['substring'](_0x3bc319,_0x1335d9>0x0?_0x1335d9:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xfcf7ed=0x1;_0xfcf7ed<this['blockSize'];++_0xfcf7ed)this['pad_'][_0xfcf7ed]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1435ec,_0x2cd3aa){_0x2cd3aa||(_0x2cd3aa=0x0);const _0x2681cc=this['W_'];if(typeof _0x1435ec=='string'){for(let _0x1d7dd7=0x0;_0x1d7dd7<0x10;_0x1d7dd7++)_0x2681cc[_0x1d7dd7]=_0x1435ec['charCodeAt'](_0x2cd3aa)<<0x18|_0x1435ec['charCodeAt'](_0x2cd3aa+0x1)<<0x10|_0x1435ec['charCodeAt'](_0x2cd3aa+0x2)<<0x8|_0x1435ec['charCodeAt'](_0x2cd3aa+0x3),_0x2cd3aa+=0x4;}else{for(let _0x593dfd=0x0;_0x593dfd<0x10;_0x593dfd++)_0x2681cc[_0x593dfd]=_0x1435ec[_0x2cd3aa]<<0x18|_0x1435ec[_0x2cd3aa+0x1]<<0x10|_0x1435ec[_0x2cd3aa+0x2]<<0x8|_0x1435ec[_0x2cd3aa+0x3],_0x2cd3aa+=0x4;}for(let _0x5b44a6=0x10;_0x5b44a6<0x50;_0x5b44a6++){const _0x1143b6=_0x2681cc[_0x5b44a6-0x3]^_0x2681cc[_0x5b44a6-0x8]^_0x2681cc[_0x5b44a6-0xe]^_0x2681cc[_0x5b44a6-0x10];_0x2681cc[_0x5b44a6]=(_0x1143b6<<0x1|_0x1143b6>>>0x1f)&0xffffffff;}let _0x311cee=this['chain_'][0x0],_0x202865=this['chain_'][0x1],_0x2a645a=this['chain_'][0x2],_0x5960b1=this['chain_'][0x3],_0x15b4bb=this['chain_'][0x4],_0x58c4e0,_0xff0b58;for(let _0x8a7b90=0x0;_0x8a7b90<0x50;_0x8a7b90++){_0x8a7b90<0x28?_0x8a7b90<0x14?(_0x58c4e0=_0x5960b1^_0x202865&(_0x2a645a^_0x5960b1),_0xff0b58=0x5a827999):(_0x58c4e0=_0x202865^_0x2a645a^_0x5960b1,_0xff0b58=0x6ed9eba1):_0x8a7b90<0x3c?(_0x58c4e0=_0x202865&_0x2a645a|_0x5960b1&(_0x202865|_0x2a645a),_0xff0b58=0x8f1bbcdc):(_0x58c4e0=_0x202865^_0x2a645a^_0x5960b1,_0xff0b58=0xca62c1d6);const _0x4f1b0b=(_0x311cee<<0x5|_0x311cee>>>0x1b)+_0x58c4e0+_0x15b4bb+_0xff0b58+_0x2681cc[_0x8a7b90]&0xffffffff;_0x15b4bb=_0x5960b1,_0x5960b1=_0x2a645a,_0x2a645a=(_0x202865<<0x1e|_0x202865>>>0x2)&0xffffffff,_0x202865=_0x311cee,_0x311cee=_0x4f1b0b;}this['chain_'][0x0]=this['chain_'][0x0]+_0x311cee&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x202865&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2a645a&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5960b1&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x15b4bb&0xffffffff;}['update'](_0x35feef,_0x4c6ad1){if(_0x35feef==null)return;_0x4c6ad1===void 0x0&&(_0x4c6ad1=_0x35feef['length']);const _0x43f38a=_0x4c6ad1-this['blockSize'];let _0x30622b=0x0;const _0x228488=this['buf_'];let _0x125936=this['inbuf_'];for(;_0x30622b<_0x4c6ad1;){if(_0x125936===0x0){for(;_0x30622b<=_0x43f38a;)this['compress_'](_0x35feef,_0x30622b),_0x30622b+=this['blockSize'];}if(typeof _0x35feef=='string'){for(;_0x30622b<_0x4c6ad1;)if(_0x228488[_0x125936]=_0x35feef['charCodeAt'](_0x30622b),++_0x125936,++_0x30622b,_0x125936===this['blockSize']){this['compress_'](_0x228488),_0x125936=0x0;break;}}else{for(;_0x30622b<_0x4c6ad1;)if(_0x228488[_0x125936]=_0x35feef[_0x30622b],++_0x125936,++_0x30622b,_0x125936===this['blockSize']){this['compress_'](_0x228488),_0x125936=0x0;break;}}}this['inbuf_']=_0x125936,this['total_']+=_0x4c6ad1;}['digest'](){const _0x261fc4=[];let _0x2a5081=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3913b3=this['blockSize']-0x1;_0x3913b3>=0x38;_0x3913b3--)this['buf_'][_0x3913b3]=_0x2a5081&0xff,_0x2a5081/=0x100;this['compress_'](this['buf_']);let _0x24ba47=0x0;for(let _0xede012=0x0;_0xede012<0x5;_0xede012++)for(let _0x59dcab=0x18;_0x59dcab>=0x0;_0x59dcab-=0x8)_0x261fc4[_0x24ba47]=this['chain_'][_0xede012]>>_0x59dcab&0xff,++_0x24ba47;return _0x261fc4;}}function Tc(_0x4b455f,_0x57e932){const _0x105d0d=new Sc(_0x4b455f,_0x57e932);return _0x105d0d['subscribe']['bind'](_0x105d0d);}class Sc{constructor(_0x59bee2,_0x3ea489){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3ea489,this['task']['then'](()=>{_0x59bee2(this);})['catch'](_0xcce582=>{this['error'](_0xcce582);});}['next'](_0x467d28){this['forEachObserver'](_0x3c1c64=>{_0x3c1c64['next'](_0x467d28);});}['error'](_0x323f6b){this['forEachObserver'](_0x78a137=>{_0x78a137['error'](_0x323f6b);}),this['close'](_0x323f6b);}['complete'](){this['forEachObserver'](_0x14be5a=>{_0x14be5a['complete']();}),this['close']();}['subscribe'](_0xf4e3ee,_0xa4ff9,_0x343078){let _0x133228;if(_0xf4e3ee===void 0x0&&_0xa4ff9===void 0x0&&_0x343078===void 0x0)throw new Error('Missing\x20Observer.');bc(_0xf4e3ee,['next','error','complete'])?_0x133228=_0xf4e3ee:_0x133228={'next':_0xf4e3ee,'error':_0xa4ff9,'complete':_0x343078},_0x133228['next']===void 0x0&&(_0x133228['next']=ti),_0x133228['error']===void 0x0&&(_0x133228['error']=ti),_0x133228['complete']===void 0x0&&(_0x133228['complete']=ti);const _0x1ccf8a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x133228['error'](this['finalError']):_0x133228['complete']();}catch{}}),this['observers']['push'](_0x133228),_0x1ccf8a;}['unsubscribeOne'](_0x16f84d){this['observers']===void 0x0||this['observers'][_0x16f84d]===void 0x0||(delete this['observers'][_0x16f84d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x13e48b){if(!this['finalized']){for(let _0x1c9855=0x0;_0x1c9855<this['observers']['length'];_0x1c9855++)this['sendOne'](_0x1c9855,_0x13e48b);}}['sendOne'](_0xdccda7,_0x5652c9){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xdccda7]!==void 0x0)try{_0x5652c9(this['observers'][_0xdccda7]);}catch(_0x1e6541){typeof console<'u'&&console['error']&&console['error'](_0x1e6541);}});}['close'](_0x3fff39){this['finalized']||(this['finalized']=!0x0,_0x3fff39!==void 0x0&&(this['finalError']=_0x3fff39),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x161b33,_0x2ace1f){if(typeof _0x161b33!='object'||_0x161b33===null)return!0x1;for(const _0x72d3ce of _0x2ace1f)if(_0x72d3ce in _0x161b33&&typeof _0x161b33[_0x72d3ce]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x32c836,_0x2dd2a7){return _0x32c836+'\x20failed:\x20'+_0x2dd2a7+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3612a8){const _0x28f863=[];let _0x3cde39=0x0;for(let _0x292dcc=0x0;_0x292dcc<_0x3612a8['length'];_0x292dcc++){let _0x214944=_0x3612a8['charCodeAt'](_0x292dcc);if(_0x214944>=0xd800&&_0x214944<=0xdbff){const _0x3f0033=_0x214944-0xd800;_0x292dcc++,f(_0x292dcc<_0x3612a8['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x7f2d63=_0x3612a8['charCodeAt'](_0x292dcc)-0xdc00;_0x214944=0x10000+(_0x3f0033<<0xa)+_0x7f2d63;}_0x214944<0x80?_0x28f863[_0x3cde39++]=_0x214944:_0x214944<0x800?(_0x28f863[_0x3cde39++]=_0x214944>>0x6|0xc0,_0x28f863[_0x3cde39++]=_0x214944&0x3f|0x80):_0x214944<0x10000?(_0x28f863[_0x3cde39++]=_0x214944>>0xc|0xe0,_0x28f863[_0x3cde39++]=_0x214944>>0x6&0x3f|0x80,_0x28f863[_0x3cde39++]=_0x214944&0x3f|0x80):(_0x28f863[_0x3cde39++]=_0x214944>>0x12|0xf0,_0x28f863[_0x3cde39++]=_0x214944>>0xc&0x3f|0x80,_0x28f863[_0x3cde39++]=_0x214944>>0x6&0x3f|0x80,_0x28f863[_0x3cde39++]=_0x214944&0x3f|0x80);}return _0x28f863;},Ln=function(_0x29a251){let _0x22e540=0x0;for(let _0x27fb5c=0x0;_0x27fb5c<_0x29a251['length'];_0x27fb5c++){const _0x439681=_0x29a251['charCodeAt'](_0x27fb5c);_0x439681<0x80?_0x22e540++:_0x439681<0x800?_0x22e540+=0x2:_0x439681>=0xd800&&_0x439681<=0xdbff?(_0x22e540+=0x4,_0x27fb5c++):_0x22e540+=0x3;}return _0x22e540;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x260f2b){return _0x260f2b&&_0x260f2b['_delegate']?_0x260f2b['_delegate']:_0x260f2b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x43baa9){try{return(_0x43baa9['startsWith']('http://')||_0x43baa9['startsWith']('https://')?new URL(_0x43baa9)['hostname']:_0x43baa9)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x2f7121){return(await fetch(_0x2f7121,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x441527,_0x4fe5e4,_0x3a64b7){this['name']=_0x441527,this['instanceFactory']=_0x4fe5e4,this['type']=_0x3a64b7,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x44cad7){return this['instantiationMode']=_0x44cad7,this;}['setMultipleInstances'](_0x2aa447){return this['multipleInstances']=_0x2aa447,this;}['setServiceProps'](_0x5050a7){return this['serviceProps']=_0x5050a7,this;}['setInstanceCreatedCallback'](_0xf1de07){return this['onInstanceCreated']=_0xf1de07,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x5667c7,_0x219421){this['name']=_0x5667c7,this['container']=_0x219421,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x49090b){const _0x207076=this['normalizeInstanceIdentifier'](_0x49090b);if(!this['instancesDeferred']['has'](_0x207076)){const _0x24146d=new H();if(this['instancesDeferred']['set'](_0x207076,_0x24146d),this['isInitialized'](_0x207076)||this['shouldAutoInitialize']())try{const _0x4e4604=this['getOrInitializeService']({'instanceIdentifier':_0x207076});_0x4e4604&&_0x24146d['resolve'](_0x4e4604);}catch{}}return this['instancesDeferred']['get'](_0x207076)['promise'];}['getImmediate'](_0x278455){const _0x34cf4a=this['normalizeInstanceIdentifier'](_0x278455==null?void 0x0:_0x278455['identifier']),_0x5d9fc4=(_0x278455==null?void 0x0:_0x278455['optional'])??!0x1;if(this['isInitialized'](_0x34cf4a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x34cf4a});}catch(_0x217960){if(_0x5d9fc4)return null;throw _0x217960;}else{if(_0x5d9fc4)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x569fdf){if(_0x569fdf['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x569fdf['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x569fdf,!!this['shouldAutoInitialize']()){if(Pc(_0x569fdf))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x272106,_0x1e2671]of this['instancesDeferred']['entries']()){const _0x91a72b=this['normalizeInstanceIdentifier'](_0x272106);try{const _0x3730d2=this['getOrInitializeService']({'instanceIdentifier':_0x91a72b});_0x1e2671['resolve'](_0x3730d2);}catch{}}}}['clearInstance'](_0x4c1105=Ne){this['instancesDeferred']['delete'](_0x4c1105),this['instancesOptions']['delete'](_0x4c1105),this['instances']['delete'](_0x4c1105);}async['delete'](){const _0x50247f=Array['from'](this['instances']['values']());await Promise['all']([..._0x50247f['filter'](_0x1fe173=>'INTERNAL'in _0x1fe173)['map'](_0x3f4ccc=>_0x3f4ccc['INTERNAL']['delete']()),..._0x50247f['filter'](_0xcaea70=>'_delete'in _0xcaea70)['map'](_0x3848b4=>_0x3848b4['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4b0019=Ne){return this['instances']['has'](_0x4b0019);}['getOptions'](_0x48948c=Ne){return this['instancesOptions']['get'](_0x48948c)||{};}['initialize'](_0x1a6c09={}){const {options:_0x41d79c={}}=_0x1a6c09,_0x4e1c90=this['normalizeInstanceIdentifier'](_0x1a6c09['instanceIdentifier']);if(this['isInitialized'](_0x4e1c90))throw Error(this['name']+'('+_0x4e1c90+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x2edd97=this['getOrInitializeService']({'instanceIdentifier':_0x4e1c90,'options':_0x41d79c});for(const [_0x241d87,_0x2b8aac]of this['instancesDeferred']['entries']()){const _0x2719a1=this['normalizeInstanceIdentifier'](_0x241d87);_0x4e1c90===_0x2719a1&&_0x2b8aac['resolve'](_0x2edd97);}return _0x2edd97;}['onInit'](_0x11136f,_0x1a782c){const _0x2488b0=this['normalizeInstanceIdentifier'](_0x1a782c),_0x5ab9ab=this['onInitCallbacks']['get'](_0x2488b0)??new Set();_0x5ab9ab['add'](_0x11136f),this['onInitCallbacks']['set'](_0x2488b0,_0x5ab9ab);const _0x50811f=this['instances']['get'](_0x2488b0);return _0x50811f&&_0x11136f(_0x50811f,_0x2488b0),()=>{_0x5ab9ab['delete'](_0x11136f);};}['invokeOnInitCallbacks'](_0x4558fd,_0x1ad89f){const _0x20af1c=this['onInitCallbacks']['get'](_0x1ad89f);if(_0x20af1c){for(const _0x1ca588 of _0x20af1c)try{_0x1ca588(_0x4558fd,_0x1ad89f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x273627,options:_0x39d79d={}}){let _0xd90cef=this['instances']['get'](_0x273627);if(!_0xd90cef&&this['component']&&(_0xd90cef=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x273627),'options':_0x39d79d}),this['instances']['set'](_0x273627,_0xd90cef),this['instancesOptions']['set'](_0x273627,_0x39d79d),this['invokeOnInitCallbacks'](_0xd90cef,_0x273627),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x273627,_0xd90cef);}catch{}return _0xd90cef||null;}['normalizeInstanceIdentifier'](_0x4aff67=Ne){return this['component']?this['component']['multipleInstances']?_0x4aff67:Ne:_0x4aff67;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x288009){return _0x288009===Ne?void 0x0:_0x288009;}function Pc(_0x5de4f9){return _0x5de4f9['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x55474b){this['name']=_0x55474b,this['providers']=new Map();}['addComponent'](_0x50a84a){const _0x182b34=this['getProvider'](_0x50a84a['name']);if(_0x182b34['isComponentSet']())throw new Error('Component\x20'+_0x50a84a['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x182b34['setComponent'](_0x50a84a);}['addOrOverwriteComponent'](_0x2b33f9){this['getProvider'](_0x2b33f9['name'])['isComponentSet']()&&this['providers']['delete'](_0x2b33f9['name']),this['addComponent'](_0x2b33f9);}['getProvider'](_0x3ea1de){if(this['providers']['has'](_0x3ea1de))return this['providers']['get'](_0x3ea1de);const _0x132174=new Ac(_0x3ea1de,this);return this['providers']['set'](_0x3ea1de,_0x132174),_0x132174;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x378be7){_0x378be7[_0x378be7['DEBUG']=0x0]='DEBUG',_0x378be7[_0x378be7['VERBOSE']=0x1]='VERBOSE',_0x378be7[_0x378be7['INFO']=0x2]='INFO',_0x378be7[_0x378be7['WARN']=0x3]='WARN',_0x378be7[_0x378be7['ERROR']=0x4]='ERROR',_0x378be7[_0x378be7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x256204,_0x47001d,..._0x30a791)=>{if(_0x47001d<_0x256204['logLevel'])return;const _0x1ea58b=new Date()['toISOString'](),_0xeeeacf=Mc[_0x47001d];if(_0xeeeacf)console[_0xeeeacf]('['+_0x1ea58b+']\x20\x20'+_0x256204['name']+':',..._0x30a791);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x47001d+')');};class Bi{constructor(_0xea40f){this['name']=_0xea40f,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5ebe74){if(!(_0x5ebe74 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5ebe74+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5ebe74;}['setLogLevel'](_0x158dac){this['_logLevel']=typeof _0x158dac=='string'?Oc[_0x158dac]:_0x158dac;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x26ba03){if(typeof _0x26ba03!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x26ba03;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x506c14){this['_userLogHandler']=_0x506c14;}['debug'](..._0x45e42d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x45e42d),this['_logHandler'](this,T['DEBUG'],..._0x45e42d);}['log'](..._0x54d8ed){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x54d8ed),this['_logHandler'](this,T['VERBOSE'],..._0x54d8ed);}['info'](..._0x5e9a65){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5e9a65),this['_logHandler'](this,T['INFO'],..._0x5e9a65);}['warn'](..._0x48d453){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x48d453),this['_logHandler'](this,T['WARN'],..._0x48d453);}['error'](..._0x5e8358){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5e8358),this['_logHandler'](this,T['ERROR'],..._0x5e8358);}}const xc=(_0x53f6cc,_0x50e68e)=>_0x50e68e['some'](_0x4a374f=>_0x53f6cc instanceof _0x4a374f);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0xfb1f71){const _0x3c46be=new Promise((_0x1678b6,_0x5dfd56)=>{const _0x1d9279=()=>{_0xfb1f71['removeEventListener']('success',_0x5e3616),_0xfb1f71['removeEventListener']('error',_0x496c39);},_0x5e3616=()=>{_0x1678b6(ge(_0xfb1f71['result'])),_0x1d9279();},_0x496c39=()=>{_0x5dfd56(_0xfb1f71['error']),_0x1d9279();};_0xfb1f71['addEventListener']('success',_0x5e3616),_0xfb1f71['addEventListener']('error',_0x496c39);});return _0x3c46be['then'](_0x272cef=>{_0x272cef instanceof IDBCursor&&Jr['set'](_0x272cef,_0xfb1f71);})['catch'](()=>{}),Vi['set'](_0x3c46be,_0xfb1f71),_0x3c46be;}function Bc(_0x576392){if(_i['has'](_0x576392))return;const _0x45b7cc=new Promise((_0x5e3737,_0x443471)=>{const _0x3e6c61=()=>{_0x576392['removeEventListener']('complete',_0x273103),_0x576392['removeEventListener']('error',_0x4408e9),_0x576392['removeEventListener']('abort',_0x4408e9);},_0x273103=()=>{_0x5e3737(),_0x3e6c61();},_0x4408e9=()=>{_0x443471(_0x576392['error']||new DOMException('AbortError','AbortError')),_0x3e6c61();};_0x576392['addEventListener']('complete',_0x273103),_0x576392['addEventListener']('error',_0x4408e9),_0x576392['addEventListener']('abort',_0x4408e9);});_i['set'](_0x576392,_0x45b7cc);}let gi={'get'(_0x28dcde,_0x43c85d,_0xd252b9){if(_0x28dcde instanceof IDBTransaction){if(_0x43c85d==='done')return _i['get'](_0x28dcde);if(_0x43c85d==='objectStoreNames')return _0x28dcde['objectStoreNames']||Xr['get'](_0x28dcde);if(_0x43c85d==='store')return _0xd252b9['objectStoreNames'][0x1]?void 0x0:_0xd252b9['objectStore'](_0xd252b9['objectStoreNames'][0x0]);}return ge(_0x28dcde[_0x43c85d]);},'set'(_0x436629,_0x2122a8,_0x47e344){return _0x436629[_0x2122a8]=_0x47e344,!0x0;},'has'(_0x3c9173,_0x118236){return _0x3c9173 instanceof IDBTransaction&&(_0x118236==='done'||_0x118236==='store')?!0x0:_0x118236 in _0x3c9173;}};function Vc(_0x474c4e){gi=_0x474c4e(gi);}function Hc(_0x4b7305){return _0x4b7305===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x1faa4,..._0x5b0152){const _0x583735=_0x4b7305['call'](ii(this),_0x1faa4,..._0x5b0152);return Xr['set'](_0x583735,_0x1faa4['sort']?_0x1faa4['sort']():[_0x1faa4]),ge(_0x583735);}:Uc()['includes'](_0x4b7305)?function(..._0x4f4eee){return _0x4b7305['apply'](ii(this),_0x4f4eee),ge(Jr['get'](this));}:function(..._0x142c0c){return ge(_0x4b7305['apply'](ii(this),_0x142c0c));};}function $c(_0x57de04){return typeof _0x57de04=='function'?Hc(_0x57de04):(_0x57de04 instanceof IDBTransaction&&Bc(_0x57de04),xc(_0x57de04,Fc())?new Proxy(_0x57de04,gi):_0x57de04);}function ge(_0x326dc5){if(_0x326dc5 instanceof IDBRequest)return Wc(_0x326dc5);if(ni['has'](_0x326dc5))return ni['get'](_0x326dc5);const _0x5121a3=$c(_0x326dc5);return _0x5121a3!==_0x326dc5&&(ni['set'](_0x326dc5,_0x5121a3),Vi['set'](_0x5121a3,_0x326dc5)),_0x5121a3;}const ii=_0x1afec9=>Vi['get'](_0x1afec9);function Gc(_0xe34044,_0x483022,{blocked:_0x1afea0,upgrade:_0x2a3153,blocking:_0x19507a,terminated:_0x3aff31}={}){const _0x462b6e=indexedDB['open'](_0xe34044,_0x483022),_0x993b6e=ge(_0x462b6e);return _0x2a3153&&_0x462b6e['addEventListener']('upgradeneeded',_0x5283d2=>{_0x2a3153(ge(_0x462b6e['result']),_0x5283d2['oldVersion'],_0x5283d2['newVersion'],ge(_0x462b6e['transaction']),_0x5283d2);}),_0x1afea0&&_0x462b6e['addEventListener']('blocked',_0x41fe50=>_0x1afea0(_0x41fe50['oldVersion'],_0x41fe50['newVersion'],_0x41fe50)),_0x993b6e['then'](_0x5f2320=>{_0x3aff31&&_0x5f2320['addEventListener']('close',()=>_0x3aff31()),_0x19507a&&_0x5f2320['addEventListener']('versionchange',_0x174c0f=>_0x19507a(_0x174c0f['oldVersion'],_0x174c0f['newVersion'],_0x174c0f));})['catch'](()=>{}),_0x993b6e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x5b4244,_0x110364){if(!(_0x5b4244 instanceof IDBDatabase&&!(_0x110364 in _0x5b4244)&&typeof _0x110364=='string'))return;if(si['get'](_0x110364))return si['get'](_0x110364);const _0x4a28d9=_0x110364['replace'](/FromIndex$/,''),_0x23c1ce=_0x110364!==_0x4a28d9,_0x5e7729=zc['includes'](_0x4a28d9);if(!(_0x4a28d9 in(_0x23c1ce?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5e7729||qc['includes'](_0x4a28d9)))return;const _0x4e50dc=async function(_0x391015,..._0x57749c){const _0x4fa0d6=this['transaction'](_0x391015,_0x5e7729?'readwrite':'readonly');let _0x3c6df1=_0x4fa0d6['store'];return _0x23c1ce&&(_0x3c6df1=_0x3c6df1['index'](_0x57749c['shift']())),(await Promise['all']([_0x3c6df1[_0x4a28d9](..._0x57749c),_0x5e7729&&_0x4fa0d6['done']]))[0x0];};return si['set'](_0x110364,_0x4e50dc),_0x4e50dc;}Vc(_0x15f81e=>({..._0x15f81e,'get':(_0x125e0c,_0x5c2307,_0x1dccd5)=>Ms(_0x125e0c,_0x5c2307)||_0x15f81e['get'](_0x125e0c,_0x5c2307,_0x1dccd5),'has':(_0x22b7f,_0x719bc8)=>!!Ms(_0x22b7f,_0x719bc8)||_0x15f81e['has'](_0x22b7f,_0x719bc8)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x456f99){this['container']=_0x456f99;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x20d1ac=>{if(Kc(_0x20d1ac)){const _0x5d18e6=_0x20d1ac['getImmediate']();return _0x5d18e6['library']+'/'+_0x5d18e6['version'];}else return null;})['filter'](_0x241b9e=>_0x241b9e)['join']('\x20');}}function Kc(_0x23837e){const _0x1b0be2=_0x23837e['getComponent']();return(_0x1b0be2==null?void 0x0:_0x1b0be2['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x307c5e,_0x570371){try{_0x307c5e['container']['addComponent'](_0x570371);}catch(_0x409d35){oe['debug']('Component\x20'+_0x570371['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x307c5e['name'],_0x409d35);}}function st(_0x15c172){const _0x330254=_0x15c172['name'];if(Ei['has'](_0x330254))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x330254+'.'),!0x1;Ei['set'](_0x330254,_0x15c172);for(const _0x3c3eca of Ue['values']())xs(_0x3c3eca,_0x15c172);for(const _0x46f132 of vi['values']())xs(_0x46f132,_0x15c172);return!0x0;}function Hi(_0x24dca1,_0x2e3c28){const _0xb23a44=_0x24dca1['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xb23a44&&_0xb23a44['triggerHeartbeat'](),_0x24dca1['container']['getProvider'](_0x2e3c28);}function $(_0x53bdba){return _0x53bdba==null?!0x1:_0x53bdba['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x199d71,_0xd63e7,_0x4da694){this['_isDeleted']=!0x1,this['_options']={..._0x199d71},this['_config']={..._0xd63e7},this['_name']=_0xd63e7['name'],this['_automaticDataCollectionEnabled']=_0xd63e7['automaticDataCollectionEnabled'],this['_container']=_0x4da694,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x197cd2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x197cd2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x59bf4b){this['_isDeleted']=_0x59bf4b;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x5706d2,_0x17bc87={}){let _0x134450=_0x5706d2;typeof _0x17bc87!='object'&&(_0x17bc87={'name':_0x17bc87});const _0x295f4f={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x17bc87},_0x25c6b5=_0x295f4f['name'];if(typeof _0x25c6b5!='string'||!_0x25c6b5)throw me['create']('bad-app-name',{'appName':String(_0x25c6b5)});if(_0x134450||(_0x134450=zr()),!_0x134450)throw me['create']('no-options');const _0x47be87=Ue['get'](_0x25c6b5);if(_0x47be87){if(xe(_0x134450,_0x47be87['options'])&&xe(_0x295f4f,_0x47be87['config']))return _0x47be87;throw me['create']('duplicate-app',{'appName':_0x25c6b5});}const _0x3ab310=new Nc(_0x25c6b5);for(const _0x24b003 of Ei['values']())_0x3ab310['addComponent'](_0x24b003);const _0xfe3e64=new Tl(_0x134450,_0x295f4f,_0x3ab310);return Ue['set'](_0x25c6b5,_0xfe3e64),_0xfe3e64;}function Zr(_0x59bf36=yi){const _0x4f87cf=Ue['get'](_0x59bf36);if(!_0x4f87cf&&_0x59bf36===yi&&zr())return Sl();if(!_0x4f87cf)throw me['create']('no-app',{'appName':_0x59bf36});return _0x4f87cf;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x22e216){let _0x2bd123=!0x1;const _0x479a6a=_0x22e216['name'];Ue['has'](_0x479a6a)?(_0x2bd123=!0x0,Ue['delete'](_0x479a6a)):vi['has'](_0x479a6a)&&_0x22e216['decRefCount']()<=0x0&&(vi['delete'](_0x479a6a),_0x2bd123=!0x0),_0x2bd123&&(await Promise['all'](_0x22e216['container']['getProviders']()['map'](_0x204c3e=>_0x204c3e['delete']())),_0x22e216['isDeleted']=!0x0);}function ye(_0x2637b4,_0x63aa76,_0x400a3f){let _0x2aa8a4=wl[_0x2637b4]??_0x2637b4;_0x400a3f&&(_0x2aa8a4+='-'+_0x400a3f);const _0x142e6d=_0x2aa8a4['match'](/\s|\//),_0x20388d=_0x63aa76['match'](/\s|\//);if(_0x142e6d||_0x20388d){const _0x4b55c9=['Unable\x20to\x20register\x20library\x20\x22'+_0x2aa8a4+'\x22\x20with\x20version\x20\x22'+_0x63aa76+'\x22:'];_0x142e6d&&_0x4b55c9['push']('library\x20name\x20\x22'+_0x2aa8a4+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x142e6d&&_0x20388d&&_0x4b55c9['push']('and'),_0x20388d&&_0x4b55c9['push']('version\x20name\x20\x22'+_0x63aa76+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x4b55c9['join']('\x20'));return;}st(new Fe(_0x2aa8a4+'-version',()=>({'library':_0x2aa8a4,'version':_0x63aa76}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x5a391f,_0x15ecef)=>{switch(_0x15ecef){case 0x0:try{_0x5a391f['createObjectStore'](Ot);}catch(_0x221b22){console['warn'](_0x221b22);}}}})['catch'](_0x58b0e7=>{throw me['create']('idb-open',{'originalErrorMessage':_0x58b0e7['message']});})),ri;}async function Al(_0x54881d){try{const _0xf29700=(await eo())['transaction'](Ot),_0x5a81ad=await _0xf29700['objectStore'](Ot)['get'](to(_0x54881d));return await _0xf29700['done'],_0x5a81ad;}catch(_0x4969cf){if(_0x4969cf instanceof Re)oe['warn'](_0x4969cf['message']);else{const _0xae94f3=me['create']('idb-get',{'originalErrorMessage':_0x4969cf==null?void 0x0:_0x4969cf['message']});oe['warn'](_0xae94f3['message']);}}}async function Fs(_0x3632ab,_0x17c0f5){try{const _0x14160c=(await eo())['transaction'](Ot,'readwrite');await _0x14160c['objectStore'](Ot)['put'](_0x17c0f5,to(_0x3632ab)),await _0x14160c['done'];}catch(_0x1d5219){if(_0x1d5219 instanceof Re)oe['warn'](_0x1d5219['message']);else{const _0x426410=me['create']('idb-set',{'originalErrorMessage':_0x1d5219==null?void 0x0:_0x1d5219['message']});oe['warn'](_0x426410['message']);}}}function to(_0x2e4002){return _0x2e4002['name']+'!'+_0x2e4002['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x4a1511){this['container']=_0x4a1511,this['_heartbeatsCache']=null;const _0x39e19e=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x39e19e),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x19337a=>(this['_heartbeatsCache']=_0x19337a,_0x19337a));}async['triggerHeartbeat'](){var _0x429acd,_0x3f6b14;try{const _0x42f05d=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x20a4e3=Us();if(((_0x429acd=this['_heartbeatsCache'])==null?void 0x0:_0x429acd['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3f6b14=this['_heartbeatsCache'])==null?void 0x0:_0x3f6b14['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x20a4e3||this['_heartbeatsCache']['heartbeats']['some'](_0xf93604=>_0xf93604['date']===_0x20a4e3))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x20a4e3,'agent':_0x42f05d}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x267a64=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x267a64,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x788b54){oe['warn'](_0x788b54);}}async['getHeartbeatsHeader'](){var _0x4435b3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4435b3=this['_heartbeatsCache'])==null?void 0x0:_0x4435b3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x1610ae=Us(),{heartbeatsToSend:_0x15b84b,unsentEntries:_0x34d148}=Ol(this['_heartbeatsCache']['heartbeats']),_0x407d8c=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x15b84b}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x1610ae,_0x34d148['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x34d148,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x407d8c;}catch(_0x32a6af){return oe['warn'](_0x32a6af),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2893cb,_0x2e144f=kl){const _0x2141e2=[];let _0x2be3b5=_0x2893cb['slice']();for(const _0x10c6e0 of _0x2893cb){const _0x30e734=_0x2141e2['find'](_0x48728c=>_0x48728c['agent']===_0x10c6e0['agent']);if(_0x30e734){if(_0x30e734['dates']['push'](_0x10c6e0['date']),Ws(_0x2141e2)>_0x2e144f){_0x30e734['dates']['pop']();break;}}else{if(_0x2141e2['push']({'agent':_0x10c6e0['agent'],'dates':[_0x10c6e0['date']]}),Ws(_0x2141e2)>_0x2e144f){_0x2141e2['pop']();break;}}_0x2be3b5=_0x2be3b5['slice'](0x1);}return{'heartbeatsToSend':_0x2141e2,'unsentEntries':_0x2be3b5};}class Dl{constructor(_0x20c15f){this['app']=_0x20c15f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4da497=await Al(this['app']);return _0x4da497!=null&&_0x4da497['heartbeats']?_0x4da497:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x31f271){if(await this['_canUseIndexedDBPromise']){const _0x21bad3=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x31f271['lastSentHeartbeatDate']??_0x21bad3['lastSentHeartbeatDate'],'heartbeats':_0x31f271['heartbeats']});}else return;}async['add'](_0x26173e){if(await this['_canUseIndexedDBPromise']){const _0x55d6f7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x26173e['lastSentHeartbeatDate']??_0x55d6f7['lastSentHeartbeatDate'],'heartbeats':[..._0x55d6f7['heartbeats'],..._0x26173e['heartbeats']]});}else return;}}function Ws(_0x30767e){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x30767e}))['length'];}function Ml(_0x8d3caf){if(_0x8d3caf['length']===0x0)return-0x1;let _0x217f64=0x0,_0x148bd2=_0x8d3caf[0x0]['date'];for(let _0x3720f7=0x1;_0x3720f7<_0x8d3caf['length'];_0x3720f7++)_0x8d3caf[_0x3720f7]['date']<_0x148bd2&&(_0x148bd2=_0x8d3caf[_0x3720f7]['date'],_0x217f64=_0x3720f7);return _0x217f64;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4611c8){st(new Fe('platform-logger',_0x42f933=>new jc(_0x42f933),'PRIVATE')),st(new Fe('heartbeat',_0x4b2d92=>new Nl(_0x4b2d92),'PRIVATE')),ye(mi,Ls,_0x4611c8),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2aec03){no=_0x2aec03;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3d3ad1){this['domStorage_']=_0x3d3ad1,this['prefix_']='firebase:';}['set'](_0x1301c6,_0x31d9db){_0x31d9db==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1301c6)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1301c6),O(_0x31d9db));}['get'](_0x78fdab){const _0x501ac5=this['domStorage_']['getItem'](this['prefixedName_'](_0x78fdab));return _0x501ac5==null?null:Nt(_0x501ac5);}['remove'](_0x124258){this['domStorage_']['removeItem'](this['prefixedName_'](_0x124258));}['prefixedName_'](_0x1e3425){return this['prefix_']+_0x1e3425;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5c0a74,_0x34069d){_0x34069d==null?delete this['cache_'][_0x5c0a74]:this['cache_'][_0x5c0a74]=_0x34069d;}['get'](_0x54f529){return Q(this['cache_'],_0x54f529)?this['cache_'][_0x54f529]:null;}['remove'](_0x330b03){delete this['cache_'][_0x330b03];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3dbb62){try{if(typeof window<'u'&&typeof window[_0x3dbb62]<'u'){const _0xe93338=window[_0x3dbb62];return _0xe93338['setItem']('firebase:sentinel','cache'),_0xe93338['removeItem']('firebase:sentinel'),new Wl(_0xe93338);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3d9f14=0x1;return function(){return _0x3d9f14++;};}()),ro=function(_0x56f001){const _0x5ad91c=Rc(_0x56f001),_0x2eeb51=new Cc();_0x2eeb51['update'](_0x5ad91c);const _0x47f989=_0x2eeb51['digest']();return Fi['encodeByteArray'](_0x47f989);},zt=function(..._0x2db988){let _0x43e1af='';for(let _0x1c230f=0x0;_0x1c230f<_0x2db988['length'];_0x1c230f++){const _0x46a402=_0x2db988[_0x1c230f];Array['isArray'](_0x46a402)||_0x46a402&&typeof _0x46a402=='object'&&typeof _0x46a402['length']=='number'?_0x43e1af+=zt['apply'](null,_0x46a402):typeof _0x46a402=='object'?_0x43e1af+=O(_0x46a402):_0x43e1af+=_0x46a402,_0x43e1af+='\x20';}return _0x43e1af;};let St=null,$s=!0x0;const Hl=function(_0x367dff,_0x60b03a){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x45fa0b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x8f558e=zt['apply'](null,_0x45fa0b);St(_0x8f558e);}},jt=function(_0x26a5ed){return function(..._0x9a5203){L(_0x26a5ed,..._0x9a5203);};},Ii=function(..._0x1b9a73){const _0xb71f15='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1b9a73);Ze['error'](_0xb71f15);},ae=function(..._0x41075c){const _0x41a0e6='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x41075c);throw Ze['error'](_0x41a0e6),new Error(_0x41a0e6);},U=function(..._0x264dd6){const _0xdc1c44='FIREBASE\x20WARNING:\x20'+zt(..._0x264dd6);Ze['warn'](_0xdc1c44);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x298c40){return typeof _0x298c40=='number'&&(_0x298c40!==_0x298c40||_0x298c40===Number['POSITIVE_INFINITY']||_0x298c40===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3f2cb3){if(document['readyState']==='complete')_0x3f2cb3();else{let _0x59eb2d=!0x1;const _0x4fefc5=function(){if(!document['body']){setTimeout(_0x4fefc5,Math['floor'](0xa));return;}_0x59eb2d||(_0x59eb2d=!0x0,_0x3f2cb3());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4fefc5,!0x1),window['addEventListener']('load',_0x4fefc5,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4fefc5();}),window['attachEvent']('onload',_0x4fefc5));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x504d2b,_0x3b5fc6){if(_0x504d2b===_0x3b5fc6)return 0x0;if(_0x504d2b===We||_0x3b5fc6===we)return-0x1;if(_0x3b5fc6===We||_0x504d2b===we)return 0x1;{const _0x447b87=Gs(_0x504d2b),_0x2c3857=Gs(_0x3b5fc6);return _0x447b87!==null?_0x2c3857!==null?_0x447b87-_0x2c3857===0x0?_0x504d2b['length']-_0x3b5fc6['length']:_0x447b87-_0x2c3857:-0x1:_0x2c3857!==null?0x1:_0x504d2b<_0x3b5fc6?-0x1:0x1;}},ql=function(_0x4b39da,_0x30c06f){return _0x4b39da===_0x30c06f?0x0:_0x4b39da<_0x30c06f?-0x1:0x1;},vt=function(_0x1a269a,_0x3753f3){if(_0x3753f3&&_0x1a269a in _0x3753f3)return _0x3753f3[_0x1a269a];throw new Error('Missing\x20required\x20key\x20('+_0x1a269a+')\x20in\x20object:\x20'+O(_0x3753f3));},$i=function(_0x84a809){if(typeof _0x84a809!='object'||_0x84a809===null)return O(_0x84a809);const _0x26a39d=[];for(const _0x1303af in _0x84a809)_0x26a39d['push'](_0x1303af);_0x26a39d['sort']();let _0x25984b='{';for(let _0x1acd7=0x0;_0x1acd7<_0x26a39d['length'];_0x1acd7++)_0x1acd7!==0x0&&(_0x25984b+=','),_0x25984b+=O(_0x26a39d[_0x1acd7]),_0x25984b+=':',_0x25984b+=$i(_0x84a809[_0x26a39d[_0x1acd7]]);return _0x25984b+='}',_0x25984b;},oo=function(_0x41a997,_0x529a0a){const _0x2cb0ba=_0x41a997['length'];if(_0x2cb0ba<=_0x529a0a)return[_0x41a997];const _0x2afbca=[];for(let _0x51ccfa=0x0;_0x51ccfa<_0x2cb0ba;_0x51ccfa+=_0x529a0a)_0x51ccfa+_0x529a0a>_0x2cb0ba?_0x2afbca['push'](_0x41a997['substring'](_0x51ccfa,_0x2cb0ba)):_0x2afbca['push'](_0x41a997['substring'](_0x51ccfa,_0x51ccfa+_0x529a0a));return _0x2afbca;};function x(_0x54c1b6,_0x5377ec){for(const _0x121994 in _0x54c1b6)_0x54c1b6['hasOwnProperty'](_0x121994)&&_0x5377ec(_0x121994,_0x54c1b6[_0x121994]);}const ao=function(_0x1daf9c){f(!xn(_0x1daf9c),'Invalid\x20JSON\x20number');const _0x539fec=0xb,_0x43a8f7=0x34,_0x324ffa=(0x1<<_0x539fec-0x1)-0x1;let _0x587b3a,_0x79bfa4,_0x11caa5,_0x1e5ad4,_0x4563ad;_0x1daf9c===0x0?(_0x79bfa4=0x0,_0x11caa5=0x0,_0x587b3a=0x1/_0x1daf9c===-0x1/0x0?0x1:0x0):(_0x587b3a=_0x1daf9c<0x0,_0x1daf9c=Math['abs'](_0x1daf9c),_0x1daf9c>=Math['pow'](0x2,0x1-_0x324ffa)?(_0x1e5ad4=Math['min'](Math['floor'](Math['log'](_0x1daf9c)/Math['LN2']),_0x324ffa),_0x79bfa4=_0x1e5ad4+_0x324ffa,_0x11caa5=Math['round'](_0x1daf9c*Math['pow'](0x2,_0x43a8f7-_0x1e5ad4)-Math['pow'](0x2,_0x43a8f7))):(_0x79bfa4=0x0,_0x11caa5=Math['round'](_0x1daf9c/Math['pow'](0x2,0x1-_0x324ffa-_0x43a8f7))));const _0x526c70=[];for(_0x4563ad=_0x43a8f7;_0x4563ad;_0x4563ad-=0x1)_0x526c70['push'](_0x11caa5%0x2?0x1:0x0),_0x11caa5=Math['floor'](_0x11caa5/0x2);for(_0x4563ad=_0x539fec;_0x4563ad;_0x4563ad-=0x1)_0x526c70['push'](_0x79bfa4%0x2?0x1:0x0),_0x79bfa4=Math['floor'](_0x79bfa4/0x2);_0x526c70['push'](_0x587b3a?0x1:0x0),_0x526c70['reverse']();const _0xc37fab=_0x526c70['join']('');let _0x2810e0='';for(_0x4563ad=0x0;_0x4563ad<0x40;_0x4563ad+=0x8){let _0x39de06=parseInt(_0xc37fab['substr'](_0x4563ad,0x8),0x2)['toString'](0x10);_0x39de06['length']===0x1&&(_0x39de06='0'+_0x39de06),_0x2810e0=_0x2810e0+_0x39de06;}return _0x2810e0['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x5adb81,_0xeef3ae){let _0x531a36='Unknown\x20Error';_0x5adb81==='too_big'?_0x531a36='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5adb81==='permission_denied'?_0x531a36='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5adb81==='unavailable'&&(_0x531a36='The\x20service\x20is\x20unavailable');const _0x438247=new Error(_0x5adb81+'\x20at\x20'+_0xeef3ae['_path']['toString']()+':\x20'+_0x531a36);return _0x438247['code']=_0x5adb81['toUpperCase'](),_0x438247;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x14a4cc){if(Yl['test'](_0x14a4cc)){const _0x33db8e=Number(_0x14a4cc);if(_0x33db8e>=Ql&&_0x33db8e<=Jl)return _0x33db8e;}return null;},ft=function(_0x504284){try{_0x504284();}catch(_0x26f8b4){setTimeout(()=>{const _0x1b22f5=_0x26f8b4['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1b22f5),_0x26f8b4;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xac2efd,_0x5d872b){const _0x3005a0=setTimeout(_0xac2efd,_0x5d872b);return typeof _0x3005a0=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3005a0):typeof _0x3005a0=='object'&&_0x3005a0['unref']&&_0x3005a0['unref'](),_0x3005a0;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x54e6ef,_0x140c33){this['appCheckProvider']=_0x140c33,this['appName']=_0x54e6ef['name'],$(_0x54e6ef)&&_0x54e6ef['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x54e6ef['settings']['appCheckToken']),this['appCheck']=_0x140c33==null?void 0x0:_0x140c33['getImmediate']({'optional':!0x0}),this['appCheck']||_0x140c33==null||_0x140c33['get']()['then'](_0x5b1ef6=>this['appCheck']=_0x5b1ef6);}['getToken'](_0x5f284b){if(this['serverAppAppCheckToken']){if(_0x5f284b)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5f284b):new Promise((_0x547a79,_0x49072d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5f284b)['then'](_0x547a79,_0x49072d):_0x547a79(null);},0x0);});}['addTokenChangeListener'](_0x21c1c6){var _0x201773;(_0x201773=this['appCheckProvider'])==null||_0x201773['get']()['then'](_0x5dbd8b=>_0x5dbd8b['addTokenListener'](_0x21c1c6));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5a2e69,_0x2f294b,_0x5efb39){this['appName_']=_0x5a2e69,this['firebaseOptions_']=_0x2f294b,this['authProvider_']=_0x5efb39,this['auth_']=null,this['auth_']=_0x5efb39['getImmediate']({'optional':!0x0}),this['auth_']||_0x5efb39['onInit'](_0x4195dd=>this['auth_']=_0x4195dd);}['getToken'](_0x311e75){return this['auth_']?this['auth_']['getToken'](_0x311e75)['catch'](_0x495b69=>_0x495b69&&_0x495b69['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x495b69)):new Promise((_0x8843fd,_0xed5ca5)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x311e75)['then'](_0x8843fd,_0xed5ca5):_0x8843fd(null);},0x0);});}['addTokenChangeListener'](_0x13fe3d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x13fe3d):this['authProvider_']['get']()['then'](_0x5e6d29=>_0x5e6d29['addAuthTokenListener'](_0x13fe3d));}['removeTokenChangeListener'](_0x52ac8f){this['authProvider_']['get']()['then'](_0x2e16af=>_0x2e16af['removeAuthTokenListener'](_0x52ac8f));}['notifyForInvalidToken'](){let _0x582640='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x582640+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x582640+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x582640+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x582640);}}class an{constructor(_0x382eb4){this['accessToken']=_0x382eb4;}['getToken'](_0x36ccba){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3a5e52){_0x3a5e52(this['accessToken']);}['removeTokenChangeListener'](_0x1a4c4b){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x30bc8e,_0x2a3d3f,_0x24f240,_0xdf2547,_0x2041e4=!0x1,_0x1d1cd7='',_0xf3205a=!0x1,_0x4bf6b2=!0x1,_0x14cc42=null){this['secure']=_0x2a3d3f,this['namespace']=_0x24f240,this['webSocketOnly']=_0xdf2547,this['nodeAdmin']=_0x2041e4,this['persistenceKey']=_0x1d1cd7,this['includeNamespaceInQueryParams']=_0xf3205a,this['isUsingEmulator']=_0x4bf6b2,this['emulatorOptions']=_0x14cc42,this['_host']=_0x30bc8e['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x30bc8e)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5dfbf7){_0x5dfbf7!==this['internalHost']&&(this['internalHost']=_0x5dfbf7,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x37d9f8=this['toURLString']();return this['persistenceKey']&&(_0x37d9f8+='<'+this['persistenceKey']+'>'),_0x37d9f8;}['toURLString'](){const _0x43699c=this['secure']?'https://':'http://',_0x559281=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x43699c+this['host']+'/'+_0x559281;}}function th(_0x508df0){return _0x508df0['host']!==_0x508df0['internalHost']||_0x508df0['isCustomHost']()||_0x508df0['includeNamespaceInQueryParams'];}function vo(_0x49818a,_0x1c99e7,_0x1c9b97){f(typeof _0x1c99e7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1c9b97=='object','typeof\x20params\x20must\x20==\x20object');let _0x3f3a81;if(_0x1c99e7===go)_0x3f3a81=(_0x49818a['secure']?'wss://':'ws://')+_0x49818a['internalHost']+'/.ws?';else{if(_0x1c99e7===mo)_0x3f3a81=(_0x49818a['secure']?'https://':'http://')+_0x49818a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1c99e7);}th(_0x49818a)&&(_0x1c9b97['ns']=_0x49818a['namespace']);const _0x576c9e=[];return x(_0x1c9b97,(_0x224d87,_0x1408eb)=>{_0x576c9e['push'](_0x224d87+'='+_0x1408eb);}),_0x3f3a81+_0x576c9e['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3002b4,_0x30159e=0x1){Q(this['counters_'],_0x3002b4)||(this['counters_'][_0x3002b4]=0x0),this['counters_'][_0x3002b4]+=_0x30159e;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x7b80ef){const _0x5c7345=_0x7b80ef['toString']();return oi[_0x5c7345]||(oi[_0x5c7345]=new nh()),oi[_0x5c7345];}function ih(_0x3e5ec7,_0xc597b0){const _0x46d18f=_0x3e5ec7['toString']();return ai[_0x46d18f]||(ai[_0x46d18f]=_0xc597b0()),ai[_0x46d18f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5a2964){this['onMessage_']=_0x5a2964,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x281d17,_0x48b677){this['closeAfterResponse']=_0x281d17,this['onClose']=_0x48b677,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x59fd88,_0x585767){for(this['pendingResponses'][_0x59fd88]=_0x585767;this['pendingResponses'][this['currentResponseNum']];){const _0x334397=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4b04da=0x0;_0x4b04da<_0x334397['length'];++_0x4b04da)_0x334397[_0x4b04da]&&ft(()=>{this['onMessage_'](_0x334397[_0x4b04da]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x29acc2,_0x20c38c,_0x2bafc3,_0x4e7020,_0x1ab8aa,_0x3d2667,_0xc33a0e){this['connId']=_0x29acc2,this['repoInfo']=_0x20c38c,this['applicationId']=_0x2bafc3,this['appCheckToken']=_0x4e7020,this['authToken']=_0x1ab8aa,this['transportSessionId']=_0x3d2667,this['lastSessionId']=_0xc33a0e,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x29acc2),this['stats_']=qi(_0x20c38c),this['urlFn']=_0x116b34=>(this['appCheckToken']&&(_0x116b34[wi]=this['appCheckToken']),vo(_0x20c38c,mo,_0x116b34));}['open'](_0x323319,_0x21afb9){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x21afb9,this['myPacketOrderer']=new sh(_0x323319),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x48bcf3)=>{const [_0x2f8b4c,_0x232cb0,_0x299c0c,_0x49e640,_0x5cfd4a]=_0x48bcf3;if(this['incrementIncomingBytes_'](_0x48bcf3),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2f8b4c===qs)this['id']=_0x232cb0,this['password']=_0x299c0c;else{if(_0x2f8b4c===rh)_0x232cb0?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x232cb0,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2f8b4c);}}},(..._0x485798)=>{const [_0x406b91,_0x162b27]=_0x485798;this['incrementIncomingBytes_'](_0x485798),this['myPacketOrderer']['handleResponse'](_0x406b91,_0x162b27);},()=>{this['onClosed_']();},this['urlFn']);const _0x415d6a={};_0x415d6a[qs]='t',_0x415d6a[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x415d6a[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x415d6a[co]=Gi,this['transportSessionId']&&(_0x415d6a[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x415d6a[po]=this['lastSessionId']),this['applicationId']&&(_0x415d6a[_o]=this['applicationId']),this['appCheckToken']&&(_0x415d6a[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x415d6a[ho]=uo);const _0x381d8d=this['urlFn'](_0x415d6a);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x381d8d),this['scriptTagHolder']['addTag'](_0x381d8d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x41cb21){const _0x19c439=O(_0x41cb21);this['bytesSent']+=_0x19c439['length'],this['stats_']['incrementCounter']('bytes_sent',_0x19c439['length']);const _0x5cf994=$r(_0x19c439),_0x2fd681=oo(_0x5cf994,fh);for(let _0x45ba30=0x0;_0x45ba30<_0x2fd681['length'];_0x45ba30++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2fd681['length'],_0x2fd681[_0x45ba30]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x589235,_0x99ad6b){this['myDisconnFrame']=document['createElement']('iframe');const _0x5840a1={};_0x5840a1[dh]='t',_0x5840a1[Eo]=_0x589235,_0x5840a1[Io]=_0x99ad6b,this['myDisconnFrame']['src']=this['urlFn'](_0x5840a1),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1cc0c1){const _0x4a7010=O(_0x1cc0c1)['length'];this['bytesReceived']+=_0x4a7010,this['stats_']['incrementCounter']('bytes_received',_0x4a7010);}}class zi{constructor(_0x195fc5,_0x4ad77e,_0x51b38b,_0x1bdba2){this['onDisconnect']=_0x51b38b,this['urlFn']=_0x1bdba2,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x195fc5,window[ah+this['uniqueCallbackIdentifier']]=_0x4ad77e,this['myIFrame']=zi['createIFrame_']();let _0x154bbe='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x154bbe='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x58346d='<html><body>'+_0x154bbe+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x58346d),this['myIFrame']['doc']['close']();}catch(_0xfcc186){L('frame\x20writing\x20exception'),_0xfcc186['stack']&&L(_0xfcc186['stack']),L(_0xfcc186);}}}static['createIFrame_'](){const _0xf1ff9d=document['createElement']('iframe');if(_0xf1ff9d['style']['display']='none',document['body']){document['body']['appendChild'](_0xf1ff9d);try{_0xf1ff9d['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3675b1=document['domain'];_0xf1ff9d['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3675b1+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xf1ff9d['contentDocument']?_0xf1ff9d['doc']=_0xf1ff9d['contentDocument']:_0xf1ff9d['contentWindow']?_0xf1ff9d['doc']=_0xf1ff9d['contentWindow']['document']:_0xf1ff9d['document']&&(_0xf1ff9d['doc']=_0xf1ff9d['document']),_0xf1ff9d;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2685cd=this['onDisconnect'];_0x2685cd&&(this['onDisconnect']=null,_0x2685cd());}['startLongPoll'](_0x2acc73,_0x6bbf26){for(this['myID']=_0x2acc73,this['myPW']=_0x6bbf26,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5bbf24={};_0x5bbf24[Eo]=this['myID'],_0x5bbf24[Io]=this['myPW'],_0x5bbf24[wo]=this['currentSerial'];let _0x2ef652=this['urlFn'](_0x5bbf24),_0x199d1b='',_0x476bb2=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x199d1b['length']<=Co;){const _0x4ad498=this['pendingSegs']['shift']();_0x199d1b=_0x199d1b+'&'+lh+_0x476bb2+'='+_0x4ad498['seg']+'&'+hh+_0x476bb2+'='+_0x4ad498['ts']+'&'+uh+_0x476bb2+'='+_0x4ad498['d'],_0x476bb2++;}return _0x2ef652=_0x2ef652+_0x199d1b,this['addLongPollTag_'](_0x2ef652,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3debbe,_0x5253b9,_0xa97483){this['pendingSegs']['push']({'seg':_0x3debbe,'ts':_0x5253b9,'d':_0xa97483}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x52daee,_0x318a85){this['outstandingRequests']['add'](_0x318a85);const _0x11fee8=()=>{this['outstandingRequests']['delete'](_0x318a85),this['newRequest_']();},_0xb022b2=setTimeout(_0x11fee8,Math['floor'](ph)),_0x195c69=()=>{clearTimeout(_0xb022b2),_0x11fee8();};this['addTag'](_0x52daee,_0x195c69);}['addTag'](_0x4adc44,_0x579a46){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x5da9ec=this['myIFrame']['doc']['createElement']('script');_0x5da9ec['type']='text/javascript',_0x5da9ec['async']=!0x0,_0x5da9ec['src']=_0x4adc44,_0x5da9ec['onload']=_0x5da9ec['onreadystatechange']=function(){const _0x4e99a5=_0x5da9ec['readyState'];(!_0x4e99a5||_0x4e99a5==='loaded'||_0x4e99a5==='complete')&&(_0x5da9ec['onload']=_0x5da9ec['onreadystatechange']=null,_0x5da9ec['parentNode']&&_0x5da9ec['parentNode']['removeChild'](_0x5da9ec),_0x579a46());},_0x5da9ec['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4adc44),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x5da9ec);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x490090,_0x46911c,_0x11248e,_0x2d7f74,_0x388b49,_0x5e115b,_0xc8e0a4){this['connId']=_0x490090,this['applicationId']=_0x11248e,this['appCheckToken']=_0x2d7f74,this['authToken']=_0x388b49,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x46911c),this['connURL']=q['connectionURL_'](_0x46911c,_0x5e115b,_0xc8e0a4,_0x2d7f74,_0x11248e),this['nodeAdmin']=_0x46911c['nodeAdmin'];}static['connectionURL_'](_0x2cc95c,_0x270a09,_0x50bb23,_0x40814c,_0x39d184){const _0x354ccc={};return _0x354ccc[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x354ccc[ho]=uo),_0x270a09&&(_0x354ccc[lo]=_0x270a09),_0x50bb23&&(_0x354ccc[po]=_0x50bb23),_0x40814c&&(_0x354ccc[wi]=_0x40814c),_0x39d184&&(_0x354ccc[_o]=_0x39d184),vo(_0x2cc95c,go,_0x354ccc);}['open'](_0x579fed,_0x55719c){this['onDisconnect']=_0x55719c,this['onMessage']=_0x579fed,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4c8b26;_c(),this['mySock']=new gn(this['connURL'],[],_0x4c8b26);}catch(_0x243ce4){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x404b07=_0x243ce4['message']||_0x243ce4['data'];_0x404b07&&this['log_'](_0x404b07),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x139659=>{this['handleIncomingFrame'](_0x139659);},this['mySock']['onerror']=_0x11c1c6=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x39f742=_0x11c1c6['message']||_0x11c1c6['data'];_0x39f742&&this['log_'](_0x39f742),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2eba85=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xe439fd=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4930e2=navigator['userAgent']['match'](_0xe439fd);_0x4930e2&&_0x4930e2['length']>0x1&&parseFloat(_0x4930e2[0x1])<4.4&&(_0x2eba85=!0x0);}return!_0x2eba85&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x569bd9){if(this['frames']['push'](_0x569bd9),this['frames']['length']===this['totalFrames']){const _0x79d7f3=this['frames']['join']('');this['frames']=null;const _0x5afe7b=Nt(_0x79d7f3);this['onMessage'](_0x5afe7b);}}['handleNewFrameCount_'](_0x3c9231){this['totalFrames']=_0x3c9231,this['frames']=[];}['extractFrameCount_'](_0x36ba20){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x36ba20['length']<=0x6){const _0x550d74=Number(_0x36ba20);if(!isNaN(_0x550d74))return this['handleNewFrameCount_'](_0x550d74),null;}return this['handleNewFrameCount_'](0x1),_0x36ba20;}['handleIncomingFrame'](_0x3138f7){if(this['mySock']===null)return;const _0x2fe041=_0x3138f7['data'];if(this['bytesReceived']+=_0x2fe041['length'],this['stats_']['incrementCounter']('bytes_received',_0x2fe041['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2fe041);else{const _0x1feea4=this['extractFrameCount_'](_0x2fe041);_0x1feea4!==null&&this['appendFrame_'](_0x1feea4);}}['send'](_0x1c63c8){this['resetKeepAlive']();const _0x445a1c=O(_0x1c63c8);this['bytesSent']+=_0x445a1c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x445a1c['length']);const _0x11f09b=oo(_0x445a1c,gh);_0x11f09b['length']>0x1&&this['sendString_'](String(_0x11f09b['length']));for(let _0x4780ba=0x0;_0x4780ba<_0x11f09b['length'];_0x4780ba++)this['sendString_'](_0x11f09b[_0x4780ba]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x5aa745){try{this['mySock']['send'](_0x5aa745);}catch(_0x1537e6){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1537e6['message']||_0x1537e6['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4f3656){this['initTransports_'](_0x4f3656);}['initTransports_'](_0x322d11){const _0x1d212f=q&&q['isAvailable']();let _0x10ebf1=_0x1d212f&&!q['previouslyFailed']();if(_0x322d11['webSocketOnly']&&(_0x1d212f||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x10ebf1=!0x0),_0x10ebf1)this['transports_']=[q];else{const _0x266ca2=this['transports_']=[];for(const _0x2c6ba5 of Dt['ALL_TRANSPORTS'])_0x2c6ba5&&_0x2c6ba5['isAvailable']()&&_0x266ca2['push'](_0x2c6ba5);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x5e2180,_0x40e902,_0x505d11,_0x3a1271,_0x200b25,_0xb47158,_0x3e5911,_0x52903f,_0x4eb84c,_0x4b7459){this['id']=_0x5e2180,this['repoInfo_']=_0x40e902,this['applicationId_']=_0x505d11,this['appCheckToken_']=_0x3a1271,this['authToken_']=_0x200b25,this['onMessage_']=_0xb47158,this['onReady_']=_0x3e5911,this['onDisconnect_']=_0x52903f,this['onKill_']=_0x4eb84c,this['lastSessionId']=_0x4b7459,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x40e902),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x20a760=this['transportManager_']['initialTransport']();this['conn_']=new _0x20a760(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x20a760['responsesRequiredToBeHealthy']||0x0;const _0x2c72e7=this['connReceiver_'](this['conn_']),_0x2c8310=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2c72e7,_0x2c8310);},Math['floor'](0x0));const _0x1c9416=_0x20a760['healthyTimeout']||0x0;_0x1c9416>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x1c9416)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x184bdb){return _0x364e6a=>{_0x184bdb===this['conn_']?this['onConnectionLost_'](_0x364e6a):_0x184bdb===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2480ad){return _0x22f9db=>{this['state_']!==0x2&&(_0x2480ad===this['rx_']?this['onPrimaryMessageReceived_'](_0x22f9db):_0x2480ad===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x22f9db):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5543eb){const _0x1a2ffa={'t':'d','d':_0x5543eb};this['sendData_'](_0x1a2ffa);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x36912c){if(ci in _0x36912c){const _0x385e81=_0x36912c[ci];_0x385e81===Ys?this['upgradeIfSecondaryHealthy_']():_0x385e81===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x385e81===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x175229){const _0x5d1203=vt('t',_0x175229),_0x1e3f35=vt('d',_0x175229);if(_0x5d1203==='c')this['onSecondaryControl_'](_0x1e3f35);else{if(_0x5d1203==='d')this['pendingDataMessages']['push'](_0x1e3f35);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5d1203);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x29874b){const _0xce5ba1=vt('t',_0x29874b),_0x31f53e=vt('d',_0x29874b);_0xce5ba1==='c'?this['onControl_'](_0x31f53e):_0xce5ba1==='d'&&this['onDataMessage_'](_0x31f53e);}['onDataMessage_'](_0x3364e0){this['onPrimaryResponse_'](),this['onMessage_'](_0x3364e0);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x6d08d3){const _0xb34603=vt(ci,_0x6d08d3);if(zs in _0x6d08d3){const _0x3bc55a=_0x6d08d3[zs];if(_0xb34603===Th){const _0x5893c2={..._0x3bc55a};this['repoInfo_']['isUsingEmulator']&&(_0x5893c2['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5893c2);}else{if(_0xb34603===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xf2c3a1=0x0;_0xf2c3a1<this['pendingDataMessages']['length'];++_0xf2c3a1)this['onDataMessage_'](this['pendingDataMessages'][_0xf2c3a1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xb34603===wh?this['onConnectionShutdown_'](_0x3bc55a):_0xb34603===js?this['onReset_'](_0x3bc55a):_0xb34603===Ch?Ii('Server\x20Error:\x20'+_0x3bc55a):_0xb34603===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xb34603);}}}['onHandshake_'](_0x182048){const _0x119560=_0x182048['ts'],_0x4ee2d5=_0x182048['v'],_0x5399c6=_0x182048['h'];this['sessionId']=_0x182048['s'],this['repoInfo_']['host']=_0x5399c6,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x119560),Gi!==_0x4ee2d5&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x10c6ab=this['transportManager_']['upgradeTransport']();_0x10c6ab&&this['startUpgrade_'](_0x10c6ab);}['startUpgrade_'](_0x39317b){this['secondaryConn_']=new _0x39317b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x39317b['responsesRequiredToBeHealthy']||0x0;const _0x9c96f5=this['connReceiver_'](this['secondaryConn_']),_0x525269=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x9c96f5,_0x525269),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x4c8dd9){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4c8dd9),this['repoInfo_']['host']=_0x4c8dd9,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4e362c,_0xd4450a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4e362c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xd4450a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x592428=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x592428||this['rx_']===_0x592428)&&this['close']();}['onConnectionLost_'](_0x4114c8){this['conn_']=null,!_0x4114c8&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2ed15a){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2ed15a),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4cc489){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4cc489);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x58f13e,_0x4efbe5,_0x5913cd,_0x281ec8){}['merge'](_0x47554e,_0x4a1be8,_0x360373,_0x23c289){}['refreshAuthToken'](_0x2f39bb){}['refreshAppCheckToken'](_0x255deb){}['onDisconnectPut'](_0x74d095,_0x1fa1ec,_0x4b8427){}['onDisconnectMerge'](_0x1e5260,_0xcc7135,_0x3ca4e5){}['onDisconnectCancel'](_0x2246d4,_0x2bb318){}['reportStats'](_0x10342c){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1db12d){this['allowedEvents_']=_0x1db12d,this['listeners_']={},f(Array['isArray'](_0x1db12d)&&_0x1db12d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x6d39ef,..._0x5bad86){if(Array['isArray'](this['listeners_'][_0x6d39ef])){const _0x5d95b1=[...this['listeners_'][_0x6d39ef]];for(let _0x299f97=0x0;_0x299f97<_0x5d95b1['length'];_0x299f97++)_0x5d95b1[_0x299f97]['callback']['apply'](_0x5d95b1[_0x299f97]['context'],_0x5bad86);}}['on'](_0x49555c,_0x4beb60,_0x33b808){this['validateEventType_'](_0x49555c),this['listeners_'][_0x49555c]=this['listeners_'][_0x49555c]||[],this['listeners_'][_0x49555c]['push']({'callback':_0x4beb60,'context':_0x33b808});const _0x4cb769=this['getInitialEvent'](_0x49555c);_0x4cb769&&_0x4beb60['apply'](_0x33b808,_0x4cb769);}['off'](_0x21f270,_0x59a6ee,_0x48b751){this['validateEventType_'](_0x21f270);const _0x118a01=this['listeners_'][_0x21f270]||[];for(let _0x33097c=0x0;_0x33097c<_0x118a01['length'];_0x33097c++)if(_0x118a01[_0x33097c]['callback']===_0x59a6ee&&(!_0x48b751||_0x48b751===_0x118a01[_0x33097c]['context'])){_0x118a01['splice'](_0x33097c,0x1);return;}}['validateEventType_'](_0x13a8b7){f(this['allowedEvents_']['find'](_0x5f5b23=>_0x5f5b23===_0x13a8b7),'Unknown\x20event:\x20'+_0x13a8b7);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x12c4e5){return f(_0x12c4e5==='online','Unknown\x20event\x20type:\x20'+_0x12c4e5),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x51102e,_0x188b02){if(_0x188b02===void 0x0){this['pieces_']=_0x51102e['split']('/');let _0x28a90e=0x0;for(let _0x4f1843=0x0;_0x4f1843<this['pieces_']['length'];_0x4f1843++)this['pieces_'][_0x4f1843]['length']>0x0&&(this['pieces_'][_0x28a90e]=this['pieces_'][_0x4f1843],_0x28a90e++);this['pieces_']['length']=_0x28a90e,this['pieceNum_']=0x0;}else this['pieces_']=_0x51102e,this['pieceNum_']=_0x188b02;}['toString'](){let _0x4fd0cd='';for(let _0x3e5c0e=this['pieceNum_'];_0x3e5c0e<this['pieces_']['length'];_0x3e5c0e++)this['pieces_'][_0x3e5c0e]!==''&&(_0x4fd0cd+='/'+this['pieces_'][_0x3e5c0e]);return _0x4fd0cd||'/';}}function w(){return new C('');}function y(_0x485f97){return _0x485f97['pieceNum_']>=_0x485f97['pieces_']['length']?null:_0x485f97['pieces_'][_0x485f97['pieceNum_']];}function Ce(_0x254771){return _0x254771['pieces_']['length']-_0x254771['pieceNum_'];}function S(_0x22e217){let _0x4df59b=_0x22e217['pieceNum_'];return _0x4df59b<_0x22e217['pieces_']['length']&&_0x4df59b++,new C(_0x22e217['pieces_'],_0x4df59b);}function ji(_0x186fe2){return _0x186fe2['pieceNum_']<_0x186fe2['pieces_']['length']?_0x186fe2['pieces_'][_0x186fe2['pieces_']['length']-0x1]:null;}function bh(_0x212910){let _0x3648f9='';for(let _0x456304=_0x212910['pieceNum_'];_0x456304<_0x212910['pieces_']['length'];_0x456304++)_0x212910['pieces_'][_0x456304]!==''&&(_0x3648f9+='/'+encodeURIComponent(String(_0x212910['pieces_'][_0x456304])));return _0x3648f9||'/';}function Mt(_0x4e52c0,_0x483741=0x0){return _0x4e52c0['pieces_']['slice'](_0x4e52c0['pieceNum_']+_0x483741);}function Ro(_0x107124){if(_0x107124['pieceNum_']>=_0x107124['pieces_']['length'])return null;const _0x570609=[];for(let _0x20937d=_0x107124['pieceNum_'];_0x20937d<_0x107124['pieces_']['length']-0x1;_0x20937d++)_0x570609['push'](_0x107124['pieces_'][_0x20937d]);return new C(_0x570609,0x0);}function k(_0x24d91b,_0x55ff10){const _0x59f36b=[];for(let _0x318cf7=_0x24d91b['pieceNum_'];_0x318cf7<_0x24d91b['pieces_']['length'];_0x318cf7++)_0x59f36b['push'](_0x24d91b['pieces_'][_0x318cf7]);if(_0x55ff10 instanceof C){for(let _0x3d7f79=_0x55ff10['pieceNum_'];_0x3d7f79<_0x55ff10['pieces_']['length'];_0x3d7f79++)_0x59f36b['push'](_0x55ff10['pieces_'][_0x3d7f79]);}else{const _0x53adc0=_0x55ff10['split']('/');for(let _0x3549f7=0x0;_0x3549f7<_0x53adc0['length'];_0x3549f7++)_0x53adc0[_0x3549f7]['length']>0x0&&_0x59f36b['push'](_0x53adc0[_0x3549f7]);}return new C(_0x59f36b,0x0);}function v(_0x56fe2b){return _0x56fe2b['pieceNum_']>=_0x56fe2b['pieces_']['length'];}function F(_0x1c0985,_0x1eeca4){const _0x49d60e=y(_0x1c0985),_0x57dfd1=y(_0x1eeca4);if(_0x49d60e===null)return _0x1eeca4;if(_0x49d60e===_0x57dfd1)return F(S(_0x1c0985),S(_0x1eeca4));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1eeca4+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1c0985+')');}function Rh(_0x25ab68,_0x511b74){const _0x459e51=Mt(_0x25ab68,0x0),_0x478535=Mt(_0x511b74,0x0);for(let _0x2d1310=0x0;_0x2d1310<_0x459e51['length']&&_0x2d1310<_0x478535['length'];_0x2d1310++){const _0x2bb8cf=qe(_0x459e51[_0x2d1310],_0x478535[_0x2d1310]);if(_0x2bb8cf!==0x0)return _0x2bb8cf;}return _0x459e51['length']===_0x478535['length']?0x0:_0x459e51['length']<_0x478535['length']?-0x1:0x1;}function Ki(_0x3eda91,_0x4efd8c){if(Ce(_0x3eda91)!==Ce(_0x4efd8c))return!0x1;for(let _0x16c93e=_0x3eda91['pieceNum_'],_0x4d75ed=_0x4efd8c['pieceNum_'];_0x16c93e<=_0x3eda91['pieces_']['length'];_0x16c93e++,_0x4d75ed++)if(_0x3eda91['pieces_'][_0x16c93e]!==_0x4efd8c['pieces_'][_0x4d75ed])return!0x1;return!0x0;}function G(_0x2bb8aa,_0x3eebe4){let _0x595ea1=_0x2bb8aa['pieceNum_'],_0x596d6e=_0x3eebe4['pieceNum_'];if(Ce(_0x2bb8aa)>Ce(_0x3eebe4))return!0x1;for(;_0x595ea1<_0x2bb8aa['pieces_']['length'];){if(_0x2bb8aa['pieces_'][_0x595ea1]!==_0x3eebe4['pieces_'][_0x596d6e])return!0x1;++_0x595ea1,++_0x596d6e;}return!0x0;}class Ah{constructor(_0x9b0aa0,_0x5b6c43){this['errorPrefix_']=_0x5b6c43,this['parts_']=Mt(_0x9b0aa0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4e1e9e=0x0;_0x4e1e9e<this['parts_']['length'];_0x4e1e9e++)this['byteLength_']+=Ln(this['parts_'][_0x4e1e9e]);Ao(this);}}function kh(_0x3e2bd4,_0x4a5c53){_0x3e2bd4['parts_']['length']>0x0&&(_0x3e2bd4['byteLength_']+=0x1),_0x3e2bd4['parts_']['push'](_0x4a5c53),_0x3e2bd4['byteLength_']+=Ln(_0x4a5c53),Ao(_0x3e2bd4);}function Ph(_0x1216f5){const _0x2ee273=_0x1216f5['parts_']['pop']();_0x1216f5['byteLength_']-=Ln(_0x2ee273),_0x1216f5['parts_']['length']>0x0&&(_0x1216f5['byteLength_']-=0x1);}function Ao(_0x2ee610){if(_0x2ee610['byteLength_']>Zs)throw new Error(_0x2ee610['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x2ee610['byteLength_']+').');if(_0x2ee610['parts_']['length']>Xs)throw new Error(_0x2ee610['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x2ee610));}function Oe(_0x1aaaeb){return _0x1aaaeb['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x1aaaeb['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x1e1e34,_0x5a8bd3;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5a8bd3='visibilitychange',_0x1e1e34='hidden'):typeof document['mozHidden']<'u'?(_0x5a8bd3='mozvisibilitychange',_0x1e1e34='mozHidden'):typeof document['msHidden']<'u'?(_0x5a8bd3='msvisibilitychange',_0x1e1e34='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5a8bd3='webkitvisibilitychange',_0x1e1e34='webkitHidden')),this['visible_']=!0x0,_0x5a8bd3&&document['addEventListener'](_0x5a8bd3,()=>{const _0x3b1a8f=!document[_0x1e1e34];_0x3b1a8f!==this['visible_']&&(this['visible_']=_0x3b1a8f,this['trigger']('visible',_0x3b1a8f));},!0x1);}['getInitialEvent'](_0x5af6d4){return f(_0x5af6d4==='visible','Unknown\x20event\x20type:\x20'+_0x5af6d4),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2bdd0b,_0x4b865c,_0x5affb3,_0x58b1d0,_0x73c749,_0x26de95,_0x5d7d24,_0x554a45){if(super(),this['repoInfo_']=_0x2bdd0b,this['applicationId_']=_0x4b865c,this['onDataUpdate_']=_0x5affb3,this['onConnectStatus_']=_0x58b1d0,this['onServerInfoUpdate_']=_0x73c749,this['authTokenProvider_']=_0x26de95,this['appCheckTokenProvider_']=_0x5d7d24,this['authOverride_']=_0x554a45,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x554a45)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2bdd0b['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1b3b98,_0x2ffc92,_0x15055a){const _0x159935=++this['requestNumber_'],_0xb60c6={'r':_0x159935,'a':_0x1b3b98,'b':_0x2ffc92};this['log_'](O(_0xb60c6)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xb60c6),_0x15055a&&(this['requestCBHash_'][_0x159935]=_0x15055a);}['get'](_0xc9f1c7){this['initConnection_']();const _0x4440f3=new H(),_0x569a7c={'action':'g','request':{'p':_0xc9f1c7['_path']['toString'](),'q':_0xc9f1c7['_queryObject']},'onComplete':_0xebd034=>{const _0x5e2993=_0xebd034['d'];_0xebd034['s']==='ok'?_0x4440f3['resolve'](_0x5e2993):_0x4440f3['reject'](_0x5e2993);}};this['outstandingGets_']['push'](_0x569a7c),this['outstandingGetCount_']++;const _0x353c1f=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x353c1f),_0x4440f3['promise'];}['listen'](_0x6ac955,_0x8c68d6,_0x43e16c,_0xf085c8){this['initConnection_']();const _0x14cfa9=_0x6ac955['_queryIdentifier'],_0x5c8af6=_0x6ac955['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5c8af6+'\x20'+_0x14cfa9),this['listens']['has'](_0x5c8af6)||this['listens']['set'](_0x5c8af6,new Map()),f(_0x6ac955['_queryParams']['isDefault']()||!_0x6ac955['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5c8af6)['has'](_0x14cfa9),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x545c78={'onComplete':_0xf085c8,'hashFn':_0x8c68d6,'query':_0x6ac955,'tag':_0x43e16c};this['listens']['get'](_0x5c8af6)['set'](_0x14cfa9,_0x545c78),this['connected_']&&this['sendListen_'](_0x545c78);}['sendGet_'](_0x2696c8){const _0x11e474=this['outstandingGets_'][_0x2696c8];this['sendRequest']('g',_0x11e474['request'],_0x1135ff=>{delete this['outstandingGets_'][_0x2696c8],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x11e474['onComplete']&&_0x11e474['onComplete'](_0x1135ff);});}['sendListen_'](_0x13fb4e){const _0x22b49d=_0x13fb4e['query'],_0x44fcb4=_0x22b49d['_path']['toString'](),_0x1fb80a=_0x22b49d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x44fcb4+'\x20for\x20'+_0x1fb80a);const _0x348fe0={'p':_0x44fcb4},_0x4bac6d='q';_0x13fb4e['tag']&&(_0x348fe0['q']=_0x22b49d['_queryObject'],_0x348fe0['t']=_0x13fb4e['tag']),_0x348fe0['h']=_0x13fb4e['hashFn'](),this['sendRequest'](_0x4bac6d,_0x348fe0,_0x1f5b18=>{const _0x52d691=_0x1f5b18['d'],_0x1f8c26=_0x1f5b18['s'];se['warnOnListenWarnings_'](_0x52d691,_0x22b49d),(this['listens']['get'](_0x44fcb4)&&this['listens']['get'](_0x44fcb4)['get'](_0x1fb80a))===_0x13fb4e&&(this['log_']('listen\x20response',_0x1f5b18),_0x1f8c26!=='ok'&&this['removeListen_'](_0x44fcb4,_0x1fb80a),_0x13fb4e['onComplete']&&_0x13fb4e['onComplete'](_0x1f8c26,_0x52d691));});}static['warnOnListenWarnings_'](_0x216532,_0x3b28f6){if(_0x216532&&typeof _0x216532=='object'&&Q(_0x216532,'w')){const _0x33215b=Le(_0x216532,'w');if(Array['isArray'](_0x33215b)&&~_0x33215b['indexOf']('no_index')){const _0x5c4aad='\x22.indexOn\x22:\x20\x22'+_0x3b28f6['_queryParams']['getIndex']()['toString']()+'\x22',_0x157e1d=_0x3b28f6['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5c4aad+'\x20at\x20'+_0x157e1d+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x6a301d){this['authToken_']=_0x6a301d,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x6a301d);}['reduceReconnectDelayIfAdminCredential_'](_0x732930){(_0x732930&&_0x732930['length']===0x28||wc(_0x732930))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2d55df){this['appCheckToken_']=_0x2d55df,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x1c4ab0=this['authToken_'],_0x34d8c0=Ic(_0x1c4ab0)?'auth':'gauth',_0x282226={'cred':_0x1c4ab0};this['authOverride_']===null?_0x282226['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x282226['authvar']=this['authOverride_']),this['sendRequest'](_0x34d8c0,_0x282226,_0x598c24=>{const _0x33f546=_0x598c24['s'],_0x15d948=_0x598c24['d']||'error';this['authToken_']===_0x1c4ab0&&(_0x33f546==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x33f546,_0x15d948));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x589d4c=>{const _0x35d76f=_0x589d4c['s'],_0x5c6a4b=_0x589d4c['d']||'error';_0x35d76f==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x35d76f,_0x5c6a4b);});}['unlisten'](_0x404b5f,_0x14ac44){const _0x34eb3e=_0x404b5f['_path']['toString'](),_0x49467d=_0x404b5f['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x34eb3e+'\x20'+_0x49467d),f(_0x404b5f['_queryParams']['isDefault']()||!_0x404b5f['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x34eb3e,_0x49467d)&&this['connected_']&&this['sendUnlisten_'](_0x34eb3e,_0x49467d,_0x404b5f['_queryObject'],_0x14ac44);}['sendUnlisten_'](_0x771fd5,_0x5267ef,_0x164982,_0x3b86cc){this['log_']('Unlisten\x20on\x20'+_0x771fd5+'\x20for\x20'+_0x5267ef);const _0x2e85fe={'p':_0x771fd5},_0x42da84='n';_0x3b86cc&&(_0x2e85fe['q']=_0x164982,_0x2e85fe['t']=_0x3b86cc),this['sendRequest'](_0x42da84,_0x2e85fe);}['onDisconnectPut'](_0x432e49,_0x306999,_0x406752){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x432e49,_0x306999,_0x406752):this['onDisconnectRequestQueue_']['push']({'pathString':_0x432e49,'action':'o','data':_0x306999,'onComplete':_0x406752});}['onDisconnectMerge'](_0x3cea5a,_0x2f5f2f,_0x137759){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x3cea5a,_0x2f5f2f,_0x137759):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3cea5a,'action':'om','data':_0x2f5f2f,'onComplete':_0x137759});}['onDisconnectCancel'](_0x183752,_0xebc44d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x183752,null,_0xebc44d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x183752,'action':'oc','data':null,'onComplete':_0xebc44d});}['sendOnDisconnect_'](_0x264712,_0x5ce29f,_0x3b3fc7,_0x494f18){const _0x36aa9={'p':_0x5ce29f,'d':_0x3b3fc7};this['log_']('onDisconnect\x20'+_0x264712,_0x36aa9),this['sendRequest'](_0x264712,_0x36aa9,_0x14a860=>{_0x494f18&&setTimeout(()=>{_0x494f18(_0x14a860['s'],_0x14a860['d']);},Math['floor'](0x0));});}['put'](_0x1b13cf,_0x5c62ec,_0x3479f4,_0x1cf048){this['putInternal']('p',_0x1b13cf,_0x5c62ec,_0x3479f4,_0x1cf048);}['merge'](_0x36fe00,_0x521b90,_0x439369,_0x581b8f){this['putInternal']('m',_0x36fe00,_0x521b90,_0x439369,_0x581b8f);}['putInternal'](_0x2f445a,_0xa08f92,_0x1c97b7,_0x897343,_0x2fabe0){this['initConnection_']();const _0x1fd151={'p':_0xa08f92,'d':_0x1c97b7};_0x2fabe0!==void 0x0&&(_0x1fd151['h']=_0x2fabe0),this['outstandingPuts_']['push']({'action':_0x2f445a,'request':_0x1fd151,'onComplete':_0x897343}),this['outstandingPutCount_']++;const _0x5e0af3=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x5e0af3):this['log_']('Buffering\x20put:\x20'+_0xa08f92);}['sendPut_'](_0x3569df){const _0x2a6352=this['outstandingPuts_'][_0x3569df]['action'],_0x2beab7=this['outstandingPuts_'][_0x3569df]['request'],_0x3c1000=this['outstandingPuts_'][_0x3569df]['onComplete'];this['outstandingPuts_'][_0x3569df]['queued']=this['connected_'],this['sendRequest'](_0x2a6352,_0x2beab7,_0xdc90db=>{this['log_'](_0x2a6352+'\x20response',_0xdc90db),delete this['outstandingPuts_'][_0x3569df],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3c1000&&_0x3c1000(_0xdc90db['s'],_0xdc90db['d']);});}['reportStats'](_0x2adf84){if(this['connected_']){const _0x575f9a={'c':_0x2adf84};this['log_']('reportStats',_0x575f9a),this['sendRequest']('s',_0x575f9a,_0x5f042b=>{if(_0x5f042b['s']!=='ok'){const _0x33f932=_0x5f042b['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x33f932);}});}}['onDataMessage_'](_0x2bb009){if('r'in _0x2bb009){this['log_']('from\x20server:\x20'+O(_0x2bb009));const _0x4ef403=_0x2bb009['r'],_0x10e97b=this['requestCBHash_'][_0x4ef403];_0x10e97b&&(delete this['requestCBHash_'][_0x4ef403],_0x10e97b(_0x2bb009['b']));}else{if('error'in _0x2bb009)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2bb009['error'];'a'in _0x2bb009&&this['onDataPush_'](_0x2bb009['a'],_0x2bb009['b']);}}['onDataPush_'](_0x31a7c4,_0x49a499){this['log_']('handleServerMessage',_0x31a7c4,_0x49a499),_0x31a7c4==='d'?this['onDataUpdate_'](_0x49a499['p'],_0x49a499['d'],!0x1,_0x49a499['t']):_0x31a7c4==='m'?this['onDataUpdate_'](_0x49a499['p'],_0x49a499['d'],!0x0,_0x49a499['t']):_0x31a7c4==='c'?this['onListenRevoked_'](_0x49a499['p'],_0x49a499['q']):_0x31a7c4==='ac'?this['onAuthRevoked_'](_0x49a499['s'],_0x49a499['d']):_0x31a7c4==='apc'?this['onAppCheckRevoked_'](_0x49a499['s'],_0x49a499['d']):_0x31a7c4==='sd'?this['onSecurityDebugPacket_'](_0x49a499):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x31a7c4)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x50d95b,_0x28cadc){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x50d95b),this['lastSessionId']=_0x28cadc,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1dfc18){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1dfc18));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x190add){_0x190add&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x190add;}['onOnline_'](_0x279150){_0x279150?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4315cb=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xd8e5ef=Math['max'](0x0,this['reconnectDelay_']-_0x4315cb);_0xd8e5ef=Math['random']()*_0xd8e5ef,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xd8e5ef+'ms'),this['scheduleConnect_'](_0xd8e5ef),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5ac603=this['onDataMessage_']['bind'](this),_0x50d621=this['onReady_']['bind'](this),_0x633076=this['onRealtimeDisconnect_']['bind'](this),_0x4543f1=this['id']+':'+se['nextConnectionId_']++,_0xcd973e=this['lastSessionId'];let _0x46d9d4=!0x1,_0x4623bb=null;const _0x3857b1=function(){_0x4623bb?_0x4623bb['close']():(_0x46d9d4=!0x0,_0x633076());},_0x1403f8=function(_0x395a95){f(_0x4623bb,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4623bb['sendRequest'](_0x395a95);};this['realtime_']={'close':_0x3857b1,'sendRequest':_0x1403f8};const _0x4f62bf=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x59c60e,_0x3aa3ef]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4f62bf),this['appCheckTokenProvider_']['getToken'](_0x4f62bf)]);_0x46d9d4?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x59c60e&&_0x59c60e['accessToken'],this['appCheckToken_']=_0x3aa3ef&&_0x3aa3ef['token'],_0x4623bb=new Sh(_0x4543f1,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5ac603,_0x50d621,_0x633076,_0x382e7b=>{U(_0x382e7b+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xcd973e));}catch(_0x3b7377){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x3b7377),_0x46d9d4||(this['repoInfo_']['nodeAdmin']&&U(_0x3b7377),_0x3857b1());}}}['interrupt'](_0x9d37e9){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x9d37e9),this['interruptReasons_'][_0x9d37e9]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x98f77){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x98f77),delete this['interruptReasons_'][_0x98f77],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x182e80){const _0x157c61=_0x182e80-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x157c61});}['cancelSentTransactions_'](){for(let _0x35e7cc=0x0;_0x35e7cc<this['outstandingPuts_']['length'];_0x35e7cc++){const _0x9aac64=this['outstandingPuts_'][_0x35e7cc];_0x9aac64&&'h'in _0x9aac64['request']&&_0x9aac64['queued']&&(_0x9aac64['onComplete']&&_0x9aac64['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x35e7cc],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5140c0,_0x3d90e2){let _0x46b008;_0x3d90e2?_0x46b008=_0x3d90e2['map'](_0x273502=>$i(_0x273502))['join']('$'):_0x46b008='default';const _0x9fa437=this['removeListen_'](_0x5140c0,_0x46b008);_0x9fa437&&_0x9fa437['onComplete']&&_0x9fa437['onComplete']('permission_denied');}['removeListen_'](_0x331e13,_0x19bd6a){const _0x2fc345=new C(_0x331e13)['toString']();let _0x21ce5c;if(this['listens']['has'](_0x2fc345)){const _0x3807aa=this['listens']['get'](_0x2fc345);_0x21ce5c=_0x3807aa['get'](_0x19bd6a),_0x3807aa['delete'](_0x19bd6a),_0x3807aa['size']===0x0&&this['listens']['delete'](_0x2fc345);}else _0x21ce5c=void 0x0;return _0x21ce5c;}['onAuthRevoked_'](_0x1d09d5,_0x5caa85){L('Auth\x20token\x20revoked:\x20'+_0x1d09d5+'/'+_0x5caa85),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1d09d5==='invalid_token'||_0x1d09d5==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1ab39f,_0x52b601){L('App\x20check\x20token\x20revoked:\x20'+_0x1ab39f+'/'+_0x52b601),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1ab39f==='invalid_token'||_0x1ab39f==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x585049){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x585049):'msg'in _0x585049&&console['log']('FIREBASE:\x20'+_0x585049['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1b3105 of this['listens']['values']())for(const _0x4e9bc7 of _0x1b3105['values']())this['sendListen_'](_0x4e9bc7);for(let _0x50e64b=0x0;_0x50e64b<this['outstandingPuts_']['length'];_0x50e64b++)this['outstandingPuts_'][_0x50e64b]&&this['sendPut_'](_0x50e64b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x17ef41=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x17ef41['action'],_0x17ef41['pathString'],_0x17ef41['data'],_0x17ef41['onComplete']);}for(let _0x5df3bf=0x0;_0x5df3bf<this['outstandingGets_']['length'];_0x5df3bf++)this['outstandingGets_'][_0x5df3bf]&&this['sendGet_'](_0x5df3bf);}['sendConnectStats_'](){const _0xdca770={};let _0x5d9404='js';_0xdca770['sdk.'+_0x5d9404+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xdca770['framework.cordova']=0x1:Kr()&&(_0xdca770['framework.reactnative']=0x1),this['reportStats'](_0xdca770);}['shouldReconnect_'](){const _0x5f4730=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5f4730;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x169db2,_0x50fa9f){this['name']=_0x169db2,this['node']=_0x50fa9f;}static['Wrap'](_0x1fde22,_0x23c2e1){return new E(_0x1fde22,_0x23c2e1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x14ce81,_0x4ce362){const _0xf2d203=new E(We,_0x14ce81),_0x524c47=new E(We,_0x4ce362);return this['compare'](_0xf2d203,_0x524c47)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x1c5d42){sn=_0x1c5d42;}['compare'](_0x1787b7,_0x4fe273){return qe(_0x1787b7['name'],_0x4fe273['name']);}['isDefinedOn'](_0x5dca88){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x59e899,_0x12fd98){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x410011,_0x3a9112){return f(typeof _0x410011=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x410011,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x5606ad,_0x83c050,_0x21d99a,_0x48ee3e,_0x215171=null){this['isReverse_']=_0x48ee3e,this['resultGenerator_']=_0x215171,this['nodeStack_']=[];let _0x49e3a6=0x1;for(;!_0x5606ad['isEmpty']();)if(_0x5606ad=_0x5606ad,_0x49e3a6=_0x83c050?_0x21d99a(_0x5606ad['key'],_0x83c050):0x1,_0x48ee3e&&(_0x49e3a6*=-0x1),_0x49e3a6<0x0)this['isReverse_']?_0x5606ad=_0x5606ad['left']:_0x5606ad=_0x5606ad['right'];else{if(_0x49e3a6===0x0){this['nodeStack_']['push'](_0x5606ad);break;}else this['nodeStack_']['push'](_0x5606ad),this['isReverse_']?_0x5606ad=_0x5606ad['right']:_0x5606ad=_0x5606ad['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3db6a2=this['nodeStack_']['pop'](),_0x41418f;if(this['resultGenerator_']?_0x41418f=this['resultGenerator_'](_0x3db6a2['key'],_0x3db6a2['value']):_0x41418f={'key':_0x3db6a2['key'],'value':_0x3db6a2['value']},this['isReverse_']){for(_0x3db6a2=_0x3db6a2['left'];!_0x3db6a2['isEmpty']();)this['nodeStack_']['push'](_0x3db6a2),_0x3db6a2=_0x3db6a2['right'];}else{for(_0x3db6a2=_0x3db6a2['right'];!_0x3db6a2['isEmpty']();)this['nodeStack_']['push'](_0x3db6a2),_0x3db6a2=_0x3db6a2['left'];}return _0x41418f;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4bd3d3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4bd3d3['key'],_0x4bd3d3['value']):{'key':_0x4bd3d3['key'],'value':_0x4bd3d3['value']};}}class M{constructor(_0xe2c8a7,_0x4b5984,_0x5f414c,_0x3d5785,_0x23c347){this['key']=_0xe2c8a7,this['value']=_0x4b5984,this['color']=_0x5f414c??M['RED'],this['left']=_0x3d5785??B['EMPTY_NODE'],this['right']=_0x23c347??B['EMPTY_NODE'];}['copy'](_0x330220,_0x2ce503,_0x3b46fa,_0x20ee05,_0x5a5322){return new M(_0x330220??this['key'],_0x2ce503??this['value'],_0x3b46fa??this['color'],_0x20ee05??this['left'],_0x5a5322??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0xb0dbf0){return this['left']['inorderTraversal'](_0xb0dbf0)||!!_0xb0dbf0(this['key'],this['value'])||this['right']['inorderTraversal'](_0xb0dbf0);}['reverseTraversal'](_0x2adcad){return this['right']['reverseTraversal'](_0x2adcad)||_0x2adcad(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2adcad);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x52e9f6,_0x10001f,_0x4387c6){let _0x21a6c3=this;const _0x1d42f1=_0x4387c6(_0x52e9f6,_0x21a6c3['key']);return _0x1d42f1<0x0?_0x21a6c3=_0x21a6c3['copy'](null,null,null,_0x21a6c3['left']['insert'](_0x52e9f6,_0x10001f,_0x4387c6),null):_0x1d42f1===0x0?_0x21a6c3=_0x21a6c3['copy'](null,_0x10001f,null,null,null):_0x21a6c3=_0x21a6c3['copy'](null,null,null,null,_0x21a6c3['right']['insert'](_0x52e9f6,_0x10001f,_0x4387c6)),_0x21a6c3['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4a108b=this;return!_0x4a108b['left']['isRed_']()&&!_0x4a108b['left']['left']['isRed_']()&&(_0x4a108b=_0x4a108b['moveRedLeft_']()),_0x4a108b=_0x4a108b['copy'](null,null,null,_0x4a108b['left']['removeMin_'](),null),_0x4a108b['fixUp_']();}['remove'](_0x44fd15,_0x4c5eae){let _0x493887,_0x1c540a;if(_0x493887=this,_0x4c5eae(_0x44fd15,_0x493887['key'])<0x0)!_0x493887['left']['isEmpty']()&&!_0x493887['left']['isRed_']()&&!_0x493887['left']['left']['isRed_']()&&(_0x493887=_0x493887['moveRedLeft_']()),_0x493887=_0x493887['copy'](null,null,null,_0x493887['left']['remove'](_0x44fd15,_0x4c5eae),null);else{if(_0x493887['left']['isRed_']()&&(_0x493887=_0x493887['rotateRight_']()),!_0x493887['right']['isEmpty']()&&!_0x493887['right']['isRed_']()&&!_0x493887['right']['left']['isRed_']()&&(_0x493887=_0x493887['moveRedRight_']()),_0x4c5eae(_0x44fd15,_0x493887['key'])===0x0){if(_0x493887['right']['isEmpty']())return B['EMPTY_NODE'];_0x1c540a=_0x493887['right']['min_'](),_0x493887=_0x493887['copy'](_0x1c540a['key'],_0x1c540a['value'],null,null,_0x493887['right']['removeMin_']());}_0x493887=_0x493887['copy'](null,null,null,null,_0x493887['right']['remove'](_0x44fd15,_0x4c5eae));}return _0x493887['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1c8f9b=this;return _0x1c8f9b['right']['isRed_']()&&!_0x1c8f9b['left']['isRed_']()&&(_0x1c8f9b=_0x1c8f9b['rotateLeft_']()),_0x1c8f9b['left']['isRed_']()&&_0x1c8f9b['left']['left']['isRed_']()&&(_0x1c8f9b=_0x1c8f9b['rotateRight_']()),_0x1c8f9b['left']['isRed_']()&&_0x1c8f9b['right']['isRed_']()&&(_0x1c8f9b=_0x1c8f9b['colorFlip_']()),_0x1c8f9b;}['moveRedLeft_'](){let _0x247673=this['colorFlip_']();return _0x247673['right']['left']['isRed_']()&&(_0x247673=_0x247673['copy'](null,null,null,null,_0x247673['right']['rotateRight_']()),_0x247673=_0x247673['rotateLeft_'](),_0x247673=_0x247673['colorFlip_']()),_0x247673;}['moveRedRight_'](){let _0x15324d=this['colorFlip_']();return _0x15324d['left']['left']['isRed_']()&&(_0x15324d=_0x15324d['rotateRight_'](),_0x15324d=_0x15324d['colorFlip_']()),_0x15324d;}['rotateLeft_'](){const _0x5157dd=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x5157dd,null);}['rotateRight_'](){const _0x1d1715=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1d1715);}['colorFlip_'](){const _0x50295c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x26a725=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x50295c,_0x26a725);}['checkMaxDepth_'](){const _0x16282f=this['check_']();return Math['pow'](0x2,_0x16282f)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x433bda=this['left']['check_']();if(_0x433bda!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x433bda+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x577bdd,_0x2af505,_0x387967,_0x5ba255,_0x5ec4ba){return this;}['insert'](_0x26a73a,_0xb6f041,_0x36167b){return new M(_0x26a73a,_0xb6f041,null);}['remove'](_0xd12729,_0x18b037){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x4042ca){return!0x1;}['reverseTraversal'](_0x1124cc){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1dbfd7,_0x50a469=B['EMPTY_NODE']){this['comparator_']=_0x1dbfd7,this['root_']=_0x50a469;}['insert'](_0x2595a3,_0x6d8dac){return new B(this['comparator_'],this['root_']['insert'](_0x2595a3,_0x6d8dac,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3652b1){return new B(this['comparator_'],this['root_']['remove'](_0x3652b1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x240bb4){let _0x246ce5,_0x3e3b35=this['root_'];for(;!_0x3e3b35['isEmpty']();){if(_0x246ce5=this['comparator_'](_0x240bb4,_0x3e3b35['key']),_0x246ce5===0x0)return _0x3e3b35['value'];_0x246ce5<0x0?_0x3e3b35=_0x3e3b35['left']:_0x246ce5>0x0&&(_0x3e3b35=_0x3e3b35['right']);}return null;}['getPredecessorKey'](_0x1a8430){let _0x4fcca7,_0x166af6=this['root_'],_0x4ed0ed=null;for(;!_0x166af6['isEmpty']();)if(_0x4fcca7=this['comparator_'](_0x1a8430,_0x166af6['key']),_0x4fcca7===0x0){if(_0x166af6['left']['isEmpty']())return _0x4ed0ed?_0x4ed0ed['key']:null;for(_0x166af6=_0x166af6['left'];!_0x166af6['right']['isEmpty']();)_0x166af6=_0x166af6['right'];return _0x166af6['key'];}else _0x4fcca7<0x0?_0x166af6=_0x166af6['left']:_0x4fcca7>0x0&&(_0x4ed0ed=_0x166af6,_0x166af6=_0x166af6['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x39cd23){return this['root_']['inorderTraversal'](_0x39cd23);}['reverseTraversal'](_0xa4fe72){return this['root_']['reverseTraversal'](_0xa4fe72);}['getIterator'](_0x5ab15b){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x5ab15b);}['getIteratorFrom'](_0x3db323,_0x82816d){return new rn(this['root_'],_0x3db323,this['comparator_'],!0x1,_0x82816d);}['getReverseIteratorFrom'](_0x4a6ee3,_0x4bea25){return new rn(this['root_'],_0x4a6ee3,this['comparator_'],!0x0,_0x4bea25);}['getReverseIterator'](_0x107cb7){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x107cb7);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x47f259,_0x2dc85f){return qe(_0x47f259['name'],_0x2dc85f['name']);}function Qi(_0x315a24,_0x47725a){return qe(_0x315a24,_0x47725a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x5420b2){Ci=_0x5420b2;}const Po=function(_0x418711){return typeof _0x418711=='number'?'number:'+ao(_0x418711):'string:'+_0x418711;},No=function(_0x5e60c8){if(_0x5e60c8['isLeafNode']()){const _0x43744a=_0x5e60c8['val']();f(typeof _0x43744a=='string'||typeof _0x43744a=='number'||typeof _0x43744a=='object'&&Q(_0x43744a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5e60c8===Ci||_0x5e60c8['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5e60c8===Ci||_0x5e60c8['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x40d75a){nr=_0x40d75a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x4990f9,_0x146d24=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4990f9,this['priorityNode_']=_0x146d24,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1f95ff){return new D(this['value_'],_0x1f95ff);}['getImmediateChild'](_0x2f8dbf){return _0x2f8dbf==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x577360){return v(_0x577360)?this:y(_0x577360)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1845ae,_0x593a2d){return null;}['updateImmediateChild'](_0x2f9fdc,_0x18fb84){return _0x2f9fdc==='.priority'?this['updatePriority'](_0x18fb84):_0x18fb84['isEmpty']()&&_0x2f9fdc!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2f9fdc,_0x18fb84)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x573022,_0x371549){const _0x302a0c=y(_0x573022);return _0x302a0c===null?_0x371549:_0x371549['isEmpty']()&&_0x302a0c!=='.priority'?this:(f(_0x302a0c!=='.priority'||Ce(_0x573022)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x302a0c,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x573022),_0x371549)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xff9217,_0x6acf11){return!0x1;}['val'](_0x2368e9){return _0x2368e9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x250833='';this['priorityNode_']['isEmpty']()||(_0x250833+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3bcc7e=typeof this['value_'];_0x250833+=_0x3bcc7e+':',_0x3bcc7e==='number'?_0x250833+=ao(this['value_']):_0x250833+=this['value_'],this['lazyHash_']=ro(_0x250833);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x10a298){return _0x10a298===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x10a298 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x10a298['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x10a298));}['compareToLeafNode_'](_0x56adba){const _0xc08318=typeof _0x56adba['value_'],_0x2e5c4b=typeof this['value_'],_0x132d86=D['VALUE_TYPE_ORDER']['indexOf'](_0xc08318),_0x36dd54=D['VALUE_TYPE_ORDER']['indexOf'](_0x2e5c4b);return f(_0x132d86>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xc08318),f(_0x36dd54>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2e5c4b),_0x132d86===_0x36dd54?_0x2e5c4b==='object'?0x0:this['value_']<_0x56adba['value_']?-0x1:this['value_']===_0x56adba['value_']?0x0:0x1:_0x36dd54-_0x132d86;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xec7eaa){if(_0xec7eaa===this)return!0x0;if(_0xec7eaa['isLeafNode']()){const _0x4ca849=_0xec7eaa;return this['value_']===_0x4ca849['value_']&&this['priorityNode_']['equals'](_0x4ca849['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0xe90465){Oo=_0xe90465;}function Wh(_0x469a82){Do=_0x469a82;}class Bh extends Fn{['compare'](_0x56d1f7,_0x215eb6){const _0xa52bdb=_0x56d1f7['node']['getPriority'](),_0x4e20c3=_0x215eb6['node']['getPriority'](),_0x345201=_0xa52bdb['compareTo'](_0x4e20c3);return _0x345201===0x0?qe(_0x56d1f7['name'],_0x215eb6['name']):_0x345201;}['isDefinedOn'](_0x2a82a9){return!_0x2a82a9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x256d19,_0x4abfb9){return!_0x256d19['getPriority']()['equals'](_0x4abfb9['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5518b6,_0x1563c0){const _0xba40db=Oo(_0x5518b6);return new E(_0x1563c0,new D('[PRIORITY-POST]',_0xba40db));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x362a05){const _0x415cff=_0x43283f=>parseInt(Math['log'](_0x43283f)/Vh,0xa),_0xa1dc36=_0x5c6df0=>parseInt(Array(_0x5c6df0+0x1)['join']('1'),0x2);this['count']=_0x415cff(_0x362a05+0x1),this['current_']=this['count']-0x1;const _0x4653c8=_0xa1dc36(this['count']);this['bits_']=_0x362a05+0x1&_0x4653c8;}['nextBitIsOne'](){const _0x316b5f=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x316b5f;}}const yn=function(_0x2665d6,_0x2e590a,_0xd19e28,_0x46a121){_0x2665d6['sort'](_0x2e590a);const _0x2539cc=function(_0x4c770e,_0x1bcf9f){const _0x3575cd=_0x1bcf9f-_0x4c770e;let _0x54da0d,_0x1fb1cb;if(_0x3575cd===0x0)return null;if(_0x3575cd===0x1)return _0x54da0d=_0x2665d6[_0x4c770e],_0x1fb1cb=_0xd19e28?_0xd19e28(_0x54da0d):_0x54da0d,new M(_0x1fb1cb,_0x54da0d['node'],M['BLACK'],null,null);{const _0x2c8c02=parseInt(_0x3575cd/0x2,0xa)+_0x4c770e,_0x1518ca=_0x2539cc(_0x4c770e,_0x2c8c02),_0x41b021=_0x2539cc(_0x2c8c02+0x1,_0x1bcf9f);return _0x54da0d=_0x2665d6[_0x2c8c02],_0x1fb1cb=_0xd19e28?_0xd19e28(_0x54da0d):_0x54da0d,new M(_0x1fb1cb,_0x54da0d['node'],M['BLACK'],_0x1518ca,_0x41b021);}},_0x4321f9=function(_0x5a62b1){let _0x3cde89=null,_0x4c99df=null,_0x285456=_0x2665d6['length'];const _0x1cd440=function(_0xbded5f,_0xed9ea5){const _0x22471b=_0x285456-_0xbded5f,_0xd21ee4=_0x285456;_0x285456-=_0xbded5f;const _0x4d3517=_0x2539cc(_0x22471b+0x1,_0xd21ee4),_0xd9b492=_0x2665d6[_0x22471b],_0x531a88=_0xd19e28?_0xd19e28(_0xd9b492):_0xd9b492;_0x31ce56(new M(_0x531a88,_0xd9b492['node'],_0xed9ea5,null,_0x4d3517));},_0x31ce56=function(_0x6ad637){_0x3cde89?(_0x3cde89['left']=_0x6ad637,_0x3cde89=_0x6ad637):(_0x4c99df=_0x6ad637,_0x3cde89=_0x6ad637);};for(let _0x1b510f=0x0;_0x1b510f<_0x5a62b1['count'];++_0x1b510f){const _0x40900f=_0x5a62b1['nextBitIsOne'](),_0x3f013f=Math['pow'](0x2,_0x5a62b1['count']-(_0x1b510f+0x1));_0x40900f?_0x1cd440(_0x3f013f,M['BLACK']):(_0x1cd440(_0x3f013f,M['BLACK']),_0x1cd440(_0x3f013f,M['RED']));}return _0x4c99df;},_0x4ffd94=new Hh(_0x2665d6['length']),_0x377666=_0x4321f9(_0x4ffd94);return new B(_0x46a121||_0x2e590a,_0x377666);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x59adac,_0x5ed2f3){this['indexes_']=_0x59adac,this['indexSet_']=_0x5ed2f3;}['get'](_0x4c9f21){const _0x224dd4=Le(this['indexes_'],_0x4c9f21);if(!_0x224dd4)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4c9f21);return _0x224dd4 instanceof B?_0x224dd4:null;}['hasIndex'](_0x5222c2){return Q(this['indexSet_'],_0x5222c2['toString']());}['addIndex'](_0x474f95,_0x59b09d){f(_0x474f95!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2b75a2=[];let _0x3f3739=!0x1;const _0x54a20b=_0x59b09d['getIterator'](E['Wrap']);let _0x41f325=_0x54a20b['getNext']();for(;_0x41f325;)_0x3f3739=_0x3f3739||_0x474f95['isDefinedOn'](_0x41f325['node']),_0x2b75a2['push'](_0x41f325),_0x41f325=_0x54a20b['getNext']();let _0x53b7b8;_0x3f3739?_0x53b7b8=yn(_0x2b75a2,_0x474f95['getCompare']()):_0x53b7b8=Qe;const _0xf74e76=_0x474f95['toString'](),_0x29f1ba={...this['indexSet_']};_0x29f1ba[_0xf74e76]=_0x474f95;const _0x5c8bef={...this['indexes_']};return _0x5c8bef[_0xf74e76]=_0x53b7b8,new te(_0x5c8bef,_0x29f1ba);}['addToIndexes'](_0x48e660,_0x3859f6){const _0x5912c8=_n(this['indexes_'],(_0x313e6e,_0xe531b8)=>{const _0x20e52e=Le(this['indexSet_'],_0xe531b8);if(f(_0x20e52e,'Missing\x20index\x20implementation\x20for\x20'+_0xe531b8),_0x313e6e===Qe){if(_0x20e52e['isDefinedOn'](_0x48e660['node'])){const _0x19187e=[],_0x240ca0=_0x3859f6['getIterator'](E['Wrap']);let _0xdb6dcf=_0x240ca0['getNext']();for(;_0xdb6dcf;)_0xdb6dcf['name']!==_0x48e660['name']&&_0x19187e['push'](_0xdb6dcf),_0xdb6dcf=_0x240ca0['getNext']();return _0x19187e['push'](_0x48e660),yn(_0x19187e,_0x20e52e['getCompare']());}else return Qe;}else{const _0x26c7cb=_0x3859f6['get'](_0x48e660['name']);let _0x28eb67=_0x313e6e;return _0x26c7cb&&(_0x28eb67=_0x28eb67['remove'](new E(_0x48e660['name'],_0x26c7cb))),_0x28eb67['insert'](_0x48e660,_0x48e660['node']);}});return new te(_0x5912c8,this['indexSet_']);}['removeFromIndexes'](_0x4b19f4,_0x120d47){const _0xb7828d=_n(this['indexes_'],_0x448227=>{if(_0x448227===Qe)return _0x448227;{const _0x1c92cc=_0x120d47['get'](_0x4b19f4['name']);return _0x1c92cc?_0x448227['remove'](new E(_0x4b19f4['name'],_0x1c92cc)):_0x448227;}});return new te(_0xb7828d,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x2ecd2d,_0x3d1879,_0xf3036){this['children_']=_0x2ecd2d,this['priorityNode_']=_0x3d1879,this['indexMap_']=_0xf3036,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1589b7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1589b7,this['indexMap_']);}['getImmediateChild'](_0x3f75a6){if(_0x3f75a6==='.priority')return this['getPriority']();{const _0x5f1106=this['children_']['get'](_0x3f75a6);return _0x5f1106===null?It:_0x5f1106;}}['getChild'](_0x44634f){const _0xa39bfe=y(_0x44634f);return _0xa39bfe===null?this:this['getImmediateChild'](_0xa39bfe)['getChild'](S(_0x44634f));}['hasChild'](_0x580e2d){return this['children_']['get'](_0x580e2d)!==null;}['updateImmediateChild'](_0x47d5b7,_0x2abb38){if(f(_0x2abb38,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x47d5b7==='.priority')return this['updatePriority'](_0x2abb38);{const _0x1abe9d=new E(_0x47d5b7,_0x2abb38);let _0x172222,_0x543a54;_0x2abb38['isEmpty']()?(_0x172222=this['children_']['remove'](_0x47d5b7),_0x543a54=this['indexMap_']['removeFromIndexes'](_0x1abe9d,this['children_'])):(_0x172222=this['children_']['insert'](_0x47d5b7,_0x2abb38),_0x543a54=this['indexMap_']['addToIndexes'](_0x1abe9d,this['children_']));const _0x22fad0=_0x172222['isEmpty']()?It:this['priorityNode_'];return new g(_0x172222,_0x22fad0,_0x543a54);}}['updateChild'](_0x184d0a,_0x245233){const _0x4860cc=y(_0x184d0a);if(_0x4860cc===null)return _0x245233;{f(y(_0x184d0a)!=='.priority'||Ce(_0x184d0a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5a3788=this['getImmediateChild'](_0x4860cc)['updateChild'](S(_0x184d0a),_0x245233);return this['updateImmediateChild'](_0x4860cc,_0x5a3788);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x41334f){if(this['isEmpty']())return null;const _0x311e94={};let _0x317f7b=0x0,_0x238cbf=0x0,_0x39ead3=!0x0;if(this['forEachChild'](R,(_0x29fd6a,_0x28648f)=>{_0x311e94[_0x29fd6a]=_0x28648f['val'](_0x41334f),_0x317f7b++,_0x39ead3&&g['INTEGER_REGEXP_']['test'](_0x29fd6a)?_0x238cbf=Math['max'](_0x238cbf,Number(_0x29fd6a)):_0x39ead3=!0x1;}),!_0x41334f&&_0x39ead3&&_0x238cbf<0x2*_0x317f7b){const _0x35bf74=[];for(const _0x24f824 in _0x311e94)_0x35bf74[_0x24f824]=_0x311e94[_0x24f824];return _0x35bf74;}else return _0x41334f&&!this['getPriority']()['isEmpty']()&&(_0x311e94['.priority']=this['getPriority']()['val']()),_0x311e94;}['hash'](){if(this['lazyHash_']===null){let _0x455216='';this['getPriority']()['isEmpty']()||(_0x455216+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x51a69a,_0xb0345f)=>{const _0x566ed0=_0xb0345f['hash']();_0x566ed0!==''&&(_0x455216+=':'+_0x51a69a+':'+_0x566ed0);}),this['lazyHash_']=_0x455216===''?'':ro(_0x455216);}return this['lazyHash_'];}['getPredecessorChildName'](_0x50bf0a,_0x3ad410,_0x2c9c20){const _0x39bb98=this['resolveIndex_'](_0x2c9c20);if(_0x39bb98){const _0x2ee09a=_0x39bb98['getPredecessorKey'](new E(_0x50bf0a,_0x3ad410));return _0x2ee09a?_0x2ee09a['name']:null;}else return this['children_']['getPredecessorKey'](_0x50bf0a);}['getFirstChildName'](_0x58a47d){const _0x4878d9=this['resolveIndex_'](_0x58a47d);if(_0x4878d9){const _0x3ebaff=_0x4878d9['minKey']();return _0x3ebaff&&_0x3ebaff['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3fc8da){const _0x1a60f6=this['getFirstChildName'](_0x3fc8da);return _0x1a60f6?new E(_0x1a60f6,this['children_']['get'](_0x1a60f6)):null;}['getLastChildName'](_0x1843c6){const _0x520af8=this['resolveIndex_'](_0x1843c6);if(_0x520af8){const _0x1955a0=_0x520af8['maxKey']();return _0x1955a0&&_0x1955a0['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1bfc03){const _0x417d4f=this['getLastChildName'](_0x1bfc03);return _0x417d4f?new E(_0x417d4f,this['children_']['get'](_0x417d4f)):null;}['forEachChild'](_0xcb36d3,_0x24d2b3){const _0x35a2c1=this['resolveIndex_'](_0xcb36d3);return _0x35a2c1?_0x35a2c1['inorderTraversal'](_0x2c5bfe=>_0x24d2b3(_0x2c5bfe['name'],_0x2c5bfe['node'])):this['children_']['inorderTraversal'](_0x24d2b3);}['getIterator'](_0x533313){return this['getIteratorFrom'](_0x533313['minPost'](),_0x533313);}['getIteratorFrom'](_0x48446c,_0x513286){const _0x4dc981=this['resolveIndex_'](_0x513286);if(_0x4dc981)return _0x4dc981['getIteratorFrom'](_0x48446c,_0x2c4a38=>_0x2c4a38);{const _0x3e7324=this['children_']['getIteratorFrom'](_0x48446c['name'],E['Wrap']);let _0x7276fd=_0x3e7324['peek']();for(;_0x7276fd!=null&&_0x513286['compare'](_0x7276fd,_0x48446c)<0x0;)_0x3e7324['getNext'](),_0x7276fd=_0x3e7324['peek']();return _0x3e7324;}}['getReverseIterator'](_0x5b7287){return this['getReverseIteratorFrom'](_0x5b7287['maxPost'](),_0x5b7287);}['getReverseIteratorFrom'](_0x35e566,_0x1c41b9){const _0x42f478=this['resolveIndex_'](_0x1c41b9);if(_0x42f478)return _0x42f478['getReverseIteratorFrom'](_0x35e566,_0x5ebf67=>_0x5ebf67);{const _0x553546=this['children_']['getReverseIteratorFrom'](_0x35e566['name'],E['Wrap']);let _0x576093=_0x553546['peek']();for(;_0x576093!=null&&_0x1c41b9['compare'](_0x576093,_0x35e566)>0x0;)_0x553546['getNext'](),_0x576093=_0x553546['peek']();return _0x553546;}}['compareTo'](_0xf39f38){return this['isEmpty']()?_0xf39f38['isEmpty']()?0x0:-0x1:_0xf39f38['isLeafNode']()||_0xf39f38['isEmpty']()?0x1:_0xf39f38===Kt?-0x1:0x0;}['withIndex'](_0x2a79e4){if(_0x2a79e4===ve||this['indexMap_']['hasIndex'](_0x2a79e4))return this;{const _0x3ddf43=this['indexMap_']['addIndex'](_0x2a79e4,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x3ddf43);}}['isIndexed'](_0x374fd5){return _0x374fd5===ve||this['indexMap_']['hasIndex'](_0x374fd5);}['equals'](_0x316b39){if(_0x316b39===this)return!0x0;if(_0x316b39['isLeafNode']())return!0x1;{const _0x304a5b=_0x316b39;if(this['getPriority']()['equals'](_0x304a5b['getPriority']())){if(this['children_']['count']()===_0x304a5b['children_']['count']()){const _0x13b4a1=this['getIterator'](R),_0x44aef9=_0x304a5b['getIterator'](R);let _0x258258=_0x13b4a1['getNext'](),_0x11c824=_0x44aef9['getNext']();for(;_0x258258&&_0x11c824;){if(_0x258258['name']!==_0x11c824['name']||!_0x258258['node']['equals'](_0x11c824['node']))return!0x1;_0x258258=_0x13b4a1['getNext'](),_0x11c824=_0x44aef9['getNext']();}return _0x258258===null&&_0x11c824===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x52210d){return _0x52210d===ve?null:this['indexMap_']['get'](_0x52210d['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x541abe){return _0x541abe===this?0x0:0x1;}['equals'](_0x55b837){return _0x55b837===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5bed41){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x421b11,_0x294860=null){if(_0x421b11===null)return g['EMPTY_NODE'];if(typeof _0x421b11=='object'&&'.priority'in _0x421b11&&(_0x294860=_0x421b11['.priority']),f(_0x294860===null||typeof _0x294860=='string'||typeof _0x294860=='number'||typeof _0x294860=='object'&&'.sv'in _0x294860,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x294860),typeof _0x421b11=='object'&&'.value'in _0x421b11&&_0x421b11['.value']!==null&&(_0x421b11=_0x421b11['.value']),typeof _0x421b11!='object'||'.sv'in _0x421b11){const _0x22804d=_0x421b11;return new D(_0x22804d,A(_0x294860));}if(!(_0x421b11 instanceof Array)&&Gh){const _0x326396=[];let _0x40a630=!0x1;if(x(_0x421b11,(_0x239204,_0x2099b9)=>{if(_0x239204['substring'](0x0,0x1)!=='.'){const _0x869329=A(_0x2099b9);_0x869329['isEmpty']()||(_0x40a630=_0x40a630||!_0x869329['getPriority']()['isEmpty'](),_0x326396['push'](new E(_0x239204,_0x869329)));}}),_0x326396['length']===0x0)return g['EMPTY_NODE'];const _0x5a8a80=yn(_0x326396,xh,_0x1552f=>_0x1552f['name'],Qi);if(_0x40a630){const _0x3b34df=yn(_0x326396,R['getCompare']());return new g(_0x5a8a80,A(_0x294860),new te({'.priority':_0x3b34df},{'.priority':R}));}else return new g(_0x5a8a80,A(_0x294860),te['Default']);}else{let _0x5083f3=g['EMPTY_NODE'];return x(_0x421b11,(_0x8d3bb3,_0x4838de)=>{if(Q(_0x421b11,_0x8d3bb3)&&_0x8d3bb3['substring'](0x0,0x1)!=='.'){const _0x190cd6=A(_0x4838de);(_0x190cd6['isLeafNode']()||!_0x190cd6['isEmpty']())&&(_0x5083f3=_0x5083f3['updateImmediateChild'](_0x8d3bb3,_0x190cd6));}}),_0x5083f3['updatePriority'](A(_0x294860));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x238fbb){super(),this['indexPath_']=_0x238fbb,f(!v(_0x238fbb)&&y(_0x238fbb)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4615ae){return _0x4615ae['getChild'](this['indexPath_']);}['isDefinedOn'](_0x33fc61){return!_0x33fc61['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4b7a55,_0x5c2e98){const _0x565366=this['extractChild'](_0x4b7a55['node']),_0x49a573=this['extractChild'](_0x5c2e98['node']),_0x4a7810=_0x565366['compareTo'](_0x49a573);return _0x4a7810===0x0?qe(_0x4b7a55['name'],_0x5c2e98['name']):_0x4a7810;}['makePost'](_0x3ad449,_0x44a3b6){const _0x1ceee5=A(_0x3ad449),_0x15346d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1ceee5);return new E(_0x44a3b6,_0x15346d);}['maxPost'](){const _0x3d5064=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x3d5064);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x1eb7e2,_0x5f0b79){const _0x1d71a7=_0x1eb7e2['node']['compareTo'](_0x5f0b79['node']);return _0x1d71a7===0x0?qe(_0x1eb7e2['name'],_0x5f0b79['name']):_0x1d71a7;}['isDefinedOn'](_0x148a9d){return!0x0;}['indexedValueChanged'](_0x3c48cd,_0x59a7a1){return!_0x3c48cd['equals'](_0x59a7a1);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x507b5a,_0x19f09f){const _0x2fde2d=A(_0x507b5a);return new E(_0x19f09f,_0x2fde2d);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x45b8c7){return{'type':'value','snapshotNode':_0x45b8c7};}function rt(_0x3e311f,_0x12d79b){return{'type':'child_added','snapshotNode':_0x12d79b,'childName':_0x3e311f};}function Lt(_0x449d47,_0x101295){return{'type':'child_removed','snapshotNode':_0x101295,'childName':_0x449d47};}function xt(_0x5af22e,_0x874322,_0x404804){return{'type':'child_changed','snapshotNode':_0x874322,'childName':_0x5af22e,'oldSnap':_0x404804};}function zh(_0x5495cd,_0x1d9703){return{'type':'child_moved','snapshotNode':_0x1d9703,'childName':_0x5495cd};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x3871dc){this['index_']=_0x3871dc;}['updateChild'](_0xa24379,_0x1548bd,_0x548790,_0x404ff7,_0xf7c12e,_0x255dbc){f(_0xa24379['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x100181=_0xa24379['getImmediateChild'](_0x1548bd);return _0x100181['getChild'](_0x404ff7)['equals'](_0x548790['getChild'](_0x404ff7))&&_0x100181['isEmpty']()===_0x548790['isEmpty']()||(_0x255dbc!=null&&(_0x548790['isEmpty']()?_0xa24379['hasChild'](_0x1548bd)?_0x255dbc['trackChildChange'](Lt(_0x1548bd,_0x100181)):f(_0xa24379['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x100181['isEmpty']()?_0x255dbc['trackChildChange'](rt(_0x1548bd,_0x548790)):_0x255dbc['trackChildChange'](xt(_0x1548bd,_0x548790,_0x100181))),_0xa24379['isLeafNode']()&&_0x548790['isEmpty']())?_0xa24379:_0xa24379['updateImmediateChild'](_0x1548bd,_0x548790)['withIndex'](this['index_']);}['updateFullNode'](_0x2d60cf,_0x1168f4,_0x442737){return _0x442737!=null&&(_0x2d60cf['isLeafNode']()||_0x2d60cf['forEachChild'](R,(_0x4b70c3,_0x154959)=>{_0x1168f4['hasChild'](_0x4b70c3)||_0x442737['trackChildChange'](Lt(_0x4b70c3,_0x154959));}),_0x1168f4['isLeafNode']()||_0x1168f4['forEachChild'](R,(_0x573997,_0x18fbc1)=>{if(_0x2d60cf['hasChild'](_0x573997)){const _0x3f44a6=_0x2d60cf['getImmediateChild'](_0x573997);_0x3f44a6['equals'](_0x18fbc1)||_0x442737['trackChildChange'](xt(_0x573997,_0x18fbc1,_0x3f44a6));}else _0x442737['trackChildChange'](rt(_0x573997,_0x18fbc1));})),_0x1168f4['withIndex'](this['index_']);}['updatePriority'](_0x245a0c,_0x483516){return _0x245a0c['isEmpty']()?g['EMPTY_NODE']:_0x245a0c['updatePriority'](_0x483516);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2b8a82){this['indexedFilter_']=new Xi(_0x2b8a82['getIndex']()),this['index_']=_0x2b8a82['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x2b8a82),this['endPost_']=Ft['getEndPost_'](_0x2b8a82),this['startIsInclusive_']=!_0x2b8a82['startAfterSet_'],this['endIsInclusive_']=!_0x2b8a82['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x765f62){const _0x51de90=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x765f62)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x765f62)<0x0,_0x45fa7b=this['endIsInclusive_']?this['index_']['compare'](_0x765f62,this['getEndPost']())<=0x0:this['index_']['compare'](_0x765f62,this['getEndPost']())<0x0;return _0x51de90&&_0x45fa7b;}['updateChild'](_0x158d68,_0x6b7cea,_0x5d4f35,_0x3a1c95,_0x197a25,_0x11a1df){return this['matches'](new E(_0x6b7cea,_0x5d4f35))||(_0x5d4f35=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x158d68,_0x6b7cea,_0x5d4f35,_0x3a1c95,_0x197a25,_0x11a1df);}['updateFullNode'](_0x31e7ef,_0x13ca6f,_0x1e68c5){_0x13ca6f['isLeafNode']()&&(_0x13ca6f=g['EMPTY_NODE']);let _0x34696d=_0x13ca6f['withIndex'](this['index_']);_0x34696d=_0x34696d['updatePriority'](g['EMPTY_NODE']);const _0x32e8fc=this;return _0x13ca6f['forEachChild'](R,(_0x491b37,_0x10573f)=>{_0x32e8fc['matches'](new E(_0x491b37,_0x10573f))||(_0x34696d=_0x34696d['updateImmediateChild'](_0x491b37,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x31e7ef,_0x34696d,_0x1e68c5);}['updatePriority'](_0x436955,_0x1f4088){return _0x436955;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x170e0f){if(_0x170e0f['hasStart']()){const _0x481d44=_0x170e0f['getIndexStartName']();return _0x170e0f['getIndex']()['makePost'](_0x170e0f['getIndexStartValue'](),_0x481d44);}else return _0x170e0f['getIndex']()['minPost']();}static['getEndPost_'](_0x2bc1a0){if(_0x2bc1a0['hasEnd']()){const _0x5a3e2d=_0x2bc1a0['getIndexEndName']();return _0x2bc1a0['getIndex']()['makePost'](_0x2bc1a0['getIndexEndValue'](),_0x5a3e2d);}else return _0x2bc1a0['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x77dd2e){this['withinDirectionalStart']=_0x4dd980=>this['reverse_']?this['withinEndPost'](_0x4dd980):this['withinStartPost'](_0x4dd980),this['withinDirectionalEnd']=_0x448f30=>this['reverse_']?this['withinStartPost'](_0x448f30):this['withinEndPost'](_0x448f30),this['withinStartPost']=_0x2740e4=>{const _0x50d32a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2740e4);return this['startIsInclusive_']?_0x50d32a<=0x0:_0x50d32a<0x0;},this['withinEndPost']=_0x5c3710=>{const _0x54e1fb=this['index_']['compare'](_0x5c3710,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x54e1fb<=0x0:_0x54e1fb<0x0;},this['rangedFilter_']=new Ft(_0x77dd2e),this['index_']=_0x77dd2e['getIndex'](),this['limit_']=_0x77dd2e['getLimit'](),this['reverse_']=!_0x77dd2e['isViewFromLeft'](),this['startIsInclusive_']=!_0x77dd2e['startAfterSet_'],this['endIsInclusive_']=!_0x77dd2e['endBeforeSet_'];}['updateChild'](_0x383277,_0x3e39fd,_0x2d7827,_0x30f2e5,_0x2f3212,_0x1de674){return this['rangedFilter_']['matches'](new E(_0x3e39fd,_0x2d7827))||(_0x2d7827=g['EMPTY_NODE']),_0x383277['getImmediateChild'](_0x3e39fd)['equals'](_0x2d7827)?_0x383277:_0x383277['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x383277,_0x3e39fd,_0x2d7827,_0x30f2e5,_0x2f3212,_0x1de674):this['fullLimitUpdateChild_'](_0x383277,_0x3e39fd,_0x2d7827,_0x2f3212,_0x1de674);}['updateFullNode'](_0x48128d,_0x5b1101,_0x1e9783){let _0x494975;if(_0x5b1101['isLeafNode']()||_0x5b1101['isEmpty']())_0x494975=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5b1101['numChildren']()&&_0x5b1101['isIndexed'](this['index_'])){_0x494975=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xd2d932;this['reverse_']?_0xd2d932=_0x5b1101['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xd2d932=_0x5b1101['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1cce61=0x0;for(;_0xd2d932['hasNext']()&&_0x1cce61<this['limit_'];){const _0x1f7609=_0xd2d932['getNext']();if(this['withinDirectionalStart'](_0x1f7609)){if(this['withinDirectionalEnd'](_0x1f7609))_0x494975=_0x494975['updateImmediateChild'](_0x1f7609['name'],_0x1f7609['node']),_0x1cce61++;else break;}else continue;}}else{_0x494975=_0x5b1101['withIndex'](this['index_']),_0x494975=_0x494975['updatePriority'](g['EMPTY_NODE']);let _0x3344a3;this['reverse_']?_0x3344a3=_0x494975['getReverseIterator'](this['index_']):_0x3344a3=_0x494975['getIterator'](this['index_']);let _0x32bf3d=0x0;for(;_0x3344a3['hasNext']();){const _0x4a5281=_0x3344a3['getNext']();_0x32bf3d<this['limit_']&&this['withinDirectionalStart'](_0x4a5281)&&this['withinDirectionalEnd'](_0x4a5281)?_0x32bf3d++:_0x494975=_0x494975['updateImmediateChild'](_0x4a5281['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x48128d,_0x494975,_0x1e9783);}['updatePriority'](_0x3b66a7,_0x1825b7){return _0x3b66a7;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2185f9,_0x8087db,_0x10a59d,_0x455e6e,_0x2ca70e){let _0x1b79c4;if(this['reverse_']){const _0x189c36=this['index_']['getCompare']();_0x1b79c4=(_0x270816,_0x4d8506)=>_0x189c36(_0x4d8506,_0x270816);}else _0x1b79c4=this['index_']['getCompare']();const _0xe93c56=_0x2185f9;f(_0xe93c56['numChildren']()===this['limit_'],'');const _0x493665=new E(_0x8087db,_0x10a59d),_0x204890=this['reverse_']?_0xe93c56['getFirstChild'](this['index_']):_0xe93c56['getLastChild'](this['index_']),_0x421f95=this['rangedFilter_']['matches'](_0x493665);if(_0xe93c56['hasChild'](_0x8087db)){const _0x1416de=_0xe93c56['getImmediateChild'](_0x8087db);let _0x2d19dd=_0x455e6e['getChildAfterChild'](this['index_'],_0x204890,this['reverse_']);for(;_0x2d19dd!=null&&(_0x2d19dd['name']===_0x8087db||_0xe93c56['hasChild'](_0x2d19dd['name']));)_0x2d19dd=_0x455e6e['getChildAfterChild'](this['index_'],_0x2d19dd,this['reverse_']);const _0x1ff845=_0x2d19dd==null?0x1:_0x1b79c4(_0x2d19dd,_0x493665);if(_0x421f95&&!_0x10a59d['isEmpty']()&&_0x1ff845>=0x0)return _0x2ca70e!=null&&_0x2ca70e['trackChildChange'](xt(_0x8087db,_0x10a59d,_0x1416de)),_0xe93c56['updateImmediateChild'](_0x8087db,_0x10a59d);{_0x2ca70e!=null&&_0x2ca70e['trackChildChange'](Lt(_0x8087db,_0x1416de));const _0x547a08=_0xe93c56['updateImmediateChild'](_0x8087db,g['EMPTY_NODE']);return _0x2d19dd!=null&&this['rangedFilter_']['matches'](_0x2d19dd)?(_0x2ca70e!=null&&_0x2ca70e['trackChildChange'](rt(_0x2d19dd['name'],_0x2d19dd['node'])),_0x547a08['updateImmediateChild'](_0x2d19dd['name'],_0x2d19dd['node'])):_0x547a08;}}else return _0x10a59d['isEmpty']()?_0x2185f9:_0x421f95&&_0x1b79c4(_0x204890,_0x493665)>=0x0?(_0x2ca70e!=null&&(_0x2ca70e['trackChildChange'](Lt(_0x204890['name'],_0x204890['node'])),_0x2ca70e['trackChildChange'](rt(_0x8087db,_0x10a59d))),_0xe93c56['updateImmediateChild'](_0x8087db,_0x10a59d)['updateImmediateChild'](_0x204890['name'],g['EMPTY_NODE'])):_0x2185f9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x298d29=new Zi();return _0x298d29['limitSet_']=this['limitSet_'],_0x298d29['limit_']=this['limit_'],_0x298d29['startSet_']=this['startSet_'],_0x298d29['startAfterSet_']=this['startAfterSet_'],_0x298d29['indexStartValue_']=this['indexStartValue_'],_0x298d29['startNameSet_']=this['startNameSet_'],_0x298d29['indexStartName_']=this['indexStartName_'],_0x298d29['endSet_']=this['endSet_'],_0x298d29['endBeforeSet_']=this['endBeforeSet_'],_0x298d29['indexEndValue_']=this['indexEndValue_'],_0x298d29['endNameSet_']=this['endNameSet_'],_0x298d29['indexEndName_']=this['indexEndName_'],_0x298d29['index_']=this['index_'],_0x298d29['viewFrom_']=this['viewFrom_'],_0x298d29;}}function Kh(_0x2d400d){return _0x2d400d['loadsAllData']()?new Xi(_0x2d400d['getIndex']()):_0x2d400d['hasLimit']()?new jh(_0x2d400d):new Ft(_0x2d400d);}function Yh(_0x11370d,_0x7bffae){const _0x57df47=_0x11370d['copy']();return _0x57df47['limitSet_']=!0x0,_0x57df47['limit_']=_0x7bffae,_0x57df47['viewFrom_']='l',_0x57df47;}function Qh(_0x663c0b,_0x4ffa4d,_0x5b5f10){const _0x395f4b=_0x663c0b['copy']();return _0x395f4b['startSet_']=!0x0,_0x4ffa4d===void 0x0&&(_0x4ffa4d=null),_0x395f4b['indexStartValue_']=_0x4ffa4d,_0x5b5f10!=null?(_0x395f4b['startNameSet_']=!0x0,_0x395f4b['indexStartName_']=_0x5b5f10):(_0x395f4b['startNameSet_']=!0x1,_0x395f4b['indexStartName_']=''),_0x395f4b;}function Jh(_0x1d997e,_0x5ccc8c,_0x32496a){const _0x19ca24=_0x1d997e['copy']();return _0x19ca24['endSet_']=!0x0,_0x5ccc8c===void 0x0&&(_0x5ccc8c=null),_0x19ca24['indexEndValue_']=_0x5ccc8c,_0x32496a!==void 0x0?(_0x19ca24['endNameSet_']=!0x0,_0x19ca24['indexEndName_']=_0x32496a):(_0x19ca24['endNameSet_']=!0x1,_0x19ca24['indexEndName_']=''),_0x19ca24;}function xo(_0xfc4b7d,_0xda9f07){const _0x5b8d1a=_0xfc4b7d['copy']();return _0x5b8d1a['index_']=_0xda9f07,_0x5b8d1a;}function ir(_0x220432){const _0x200a3c={};if(_0x220432['isDefault']())return _0x200a3c;let _0x20ba98;if(_0x220432['index_']===R?_0x20ba98='$priority':_0x220432['index_']===Mo?_0x20ba98='$value':_0x220432['index_']===ve?_0x20ba98='$key':(f(_0x220432['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x20ba98=_0x220432['index_']['toString']()),_0x200a3c['orderBy']=O(_0x20ba98),_0x220432['startSet_']){const _0x13bc1a=_0x220432['startAfterSet_']?'startAfter':'startAt';_0x200a3c[_0x13bc1a]=O(_0x220432['indexStartValue_']),_0x220432['startNameSet_']&&(_0x200a3c[_0x13bc1a]+=','+O(_0x220432['indexStartName_']));}if(_0x220432['endSet_']){const _0x518c63=_0x220432['endBeforeSet_']?'endBefore':'endAt';_0x200a3c[_0x518c63]=O(_0x220432['indexEndValue_']),_0x220432['endNameSet_']&&(_0x200a3c[_0x518c63]+=','+O(_0x220432['indexEndName_']));}return _0x220432['limitSet_']&&(_0x220432['isViewFromLeft']()?_0x200a3c['limitToFirst']=_0x220432['limit_']:_0x200a3c['limitToLast']=_0x220432['limit_']),_0x200a3c;}function sr(_0x4d418e){const _0x481a51={};if(_0x4d418e['startSet_']&&(_0x481a51['sp']=_0x4d418e['indexStartValue_'],_0x4d418e['startNameSet_']&&(_0x481a51['sn']=_0x4d418e['indexStartName_']),_0x481a51['sin']=!_0x4d418e['startAfterSet_']),_0x4d418e['endSet_']&&(_0x481a51['ep']=_0x4d418e['indexEndValue_'],_0x4d418e['endNameSet_']&&(_0x481a51['en']=_0x4d418e['indexEndName_']),_0x481a51['ein']=!_0x4d418e['endBeforeSet_']),_0x4d418e['limitSet_']){_0x481a51['l']=_0x4d418e['limit_'];let _0x4e1791=_0x4d418e['viewFrom_'];_0x4e1791===''&&(_0x4d418e['isViewFromLeft']()?_0x4e1791='l':_0x4e1791='r'),_0x481a51['vf']=_0x4e1791;}return _0x4d418e['index_']!==R&&(_0x481a51['i']=_0x4d418e['index_']['toString']()),_0x481a51;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x10990d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5edc35,_0x3967ec){return _0x3967ec!==void 0x0?'tag$'+_0x3967ec:(f(_0x5edc35['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5edc35['_path']['toString']());}constructor(_0x1d8cd7,_0xca9c63,_0x302e2a,_0x39909b){super(),this['repoInfo_']=_0x1d8cd7,this['onDataUpdate_']=_0xca9c63,this['authTokenProvider_']=_0x302e2a,this['appCheckTokenProvider_']=_0x39909b,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0xb7c0ab,_0x45730a,_0xffa3c8,_0x8a2888){const _0x3a2572=_0xb7c0ab['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3a2572+'\x20'+_0xb7c0ab['_queryIdentifier']);const _0x524611=vn['getListenId_'](_0xb7c0ab,_0xffa3c8),_0x752f8c={};this['listens_'][_0x524611]=_0x752f8c;const _0x2496d9=ir(_0xb7c0ab['_queryParams']);this['restRequest_'](_0x3a2572+'.json',_0x2496d9,(_0x3e7ce7,_0x26374f)=>{let _0xe3ee51=_0x26374f;if(_0x3e7ce7===0x194&&(_0xe3ee51=null,_0x3e7ce7=null),_0x3e7ce7===null&&this['onDataUpdate_'](_0x3a2572,_0xe3ee51,!0x1,_0xffa3c8),Le(this['listens_'],_0x524611)===_0x752f8c){let _0x119ad8;_0x3e7ce7?_0x3e7ce7===0x191?_0x119ad8='permission_denied':_0x119ad8='rest_error:'+_0x3e7ce7:_0x119ad8='ok',_0x8a2888(_0x119ad8,null);}});}['unlisten'](_0x5d0d66,_0x1ed81e){const _0x287529=vn['getListenId_'](_0x5d0d66,_0x1ed81e);delete this['listens_'][_0x287529];}['get'](_0x47fc63){const _0x1b1ee8=ir(_0x47fc63['_queryParams']),_0x10f9ac=_0x47fc63['_path']['toString'](),_0x2ee136=new H();return this['restRequest_'](_0x10f9ac+'.json',_0x1b1ee8,(_0x773ef9,_0xaa12e4)=>{let _0x15755a=_0xaa12e4;_0x773ef9===0x194&&(_0x15755a=null,_0x773ef9=null),_0x773ef9===null?(this['onDataUpdate_'](_0x10f9ac,_0x15755a,!0x1,null),_0x2ee136['resolve'](_0x15755a)):_0x2ee136['reject'](new Error(_0x15755a));}),_0x2ee136['promise'];}['refreshAuthToken'](_0x4e14b5){}['restRequest_'](_0x2e4c08,_0x1f4fb7={},_0x2f74a5){return _0x1f4fb7['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x311d46,_0x2b0fe3])=>{_0x311d46&&_0x311d46['accessToken']&&(_0x1f4fb7['auth']=_0x311d46['accessToken']),_0x2b0fe3&&_0x2b0fe3['token']&&(_0x1f4fb7['ac']=_0x2b0fe3['token']);const _0x5cb1bf=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2e4c08+'?ns='+this['repoInfo_']['namespace']+ut(_0x1f4fb7);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5cb1bf);const _0x5c7383=new XMLHttpRequest();_0x5c7383['onreadystatechange']=()=>{if(_0x2f74a5&&_0x5c7383['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5cb1bf+'\x20received.\x20status:',_0x5c7383['status'],'response:',_0x5c7383['responseText']);let _0x51f551=null;if(_0x5c7383['status']>=0xc8&&_0x5c7383['status']<0x12c){try{_0x51f551=Nt(_0x5c7383['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5cb1bf+':\x20'+_0x5c7383['responseText']);}_0x2f74a5(null,_0x51f551);}else _0x5c7383['status']!==0x191&&_0x5c7383['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5cb1bf+'\x20Status:\x20'+_0x5c7383['status']),_0x2f74a5(_0x5c7383['status']);_0x2f74a5=null;}},_0x5c7383['open']('GET',_0x5cb1bf,!0x0),_0x5c7383['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x290d79){return this['rootNode_']['getChild'](_0x290d79);}['updateSnapshot'](_0x232751,_0xcf106e){this['rootNode_']=this['rootNode_']['updateChild'](_0x232751,_0xcf106e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2ca35d,_0x19df44,_0x63187c){if(v(_0x19df44))_0x2ca35d['value']=_0x63187c,_0x2ca35d['children']['clear']();else{if(_0x2ca35d['value']!==null)_0x2ca35d['value']=_0x2ca35d['value']['updateChild'](_0x19df44,_0x63187c);else{const _0x33e082=y(_0x19df44);_0x2ca35d['children']['has'](_0x33e082)||_0x2ca35d['children']['set'](_0x33e082,En());const _0x4a3362=_0x2ca35d['children']['get'](_0x33e082);_0x19df44=S(_0x19df44),pt(_0x4a3362,_0x19df44,_0x63187c);}}}function Ti(_0x5358a4,_0x7f4016){if(v(_0x7f4016))return _0x5358a4['value']=null,_0x5358a4['children']['clear'](),!0x0;if(_0x5358a4['value']!==null){if(_0x5358a4['value']['isLeafNode']())return!0x1;{const _0x1c4b15=_0x5358a4['value'];return _0x5358a4['value']=null,_0x1c4b15['forEachChild'](R,(_0x1f08f3,_0x3db9ee)=>{pt(_0x5358a4,new C(_0x1f08f3),_0x3db9ee);}),Ti(_0x5358a4,_0x7f4016);}}else{if(_0x5358a4['children']['size']>0x0){const _0x56d20b=y(_0x7f4016);return _0x7f4016=S(_0x7f4016),_0x5358a4['children']['has'](_0x56d20b)&&Ti(_0x5358a4['children']['get'](_0x56d20b),_0x7f4016)&&_0x5358a4['children']['delete'](_0x56d20b),_0x5358a4['children']['size']===0x0;}else return!0x0;}}function Si(_0x3e800f,_0x4c5480,_0x39fe9d){_0x3e800f['value']!==null?_0x39fe9d(_0x4c5480,_0x3e800f['value']):Zh(_0x3e800f,(_0x1a3974,_0x12bd59)=>{const _0x4675ea=new C(_0x4c5480['toString']()+'/'+_0x1a3974);Si(_0x12bd59,_0x4675ea,_0x39fe9d);});}function Zh(_0xfad3b1,_0xfc722d){_0xfad3b1['children']['forEach']((_0xcad737,_0x20e29a)=>{_0xfc722d(_0x20e29a,_0xcad737);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x14031e){this['collection_']=_0x14031e,this['last_']=null;}['get'](){const _0x20e568=this['collection_']['get'](),_0x546928={..._0x20e568};return this['last_']&&x(this['last_'],(_0x4815a6,_0x5d300e)=>{_0x546928[_0x4815a6]=_0x546928[_0x4815a6]-_0x5d300e;}),this['last_']=_0x20e568,_0x546928;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x5988b7,_0x280307){this['server_']=_0x280307,this['statsToReport_']={},this['statsListener_']=new eu(_0x5988b7);const _0x5a66cd=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5a66cd));}['reportStats_'](){const _0x4a657f=this['statsListener_']['get'](),_0xb8cdc8={};let _0x2622f9=!0x1;x(_0x4a657f,(_0xbd4980,_0x3c9815)=>{_0x3c9815>0x0&&Q(this['statsToReport_'],_0xbd4980)&&(_0xb8cdc8[_0xbd4980]=_0x3c9815,_0x2622f9=!0x0);}),_0x2622f9&&this['server_']['reportStats'](_0xb8cdc8),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x45d7ac){_0x45d7ac[_0x45d7ac['OVERWRITE']=0x0]='OVERWRITE',_0x45d7ac[_0x45d7ac['MERGE']=0x1]='MERGE',_0x45d7ac[_0x45d7ac['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x45d7ac[_0x45d7ac['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x4e68a4){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x4e68a4,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xe1dd4a,_0x1909f1,_0x40945c){this['path']=_0xe1dd4a,this['affectedTree']=_0x1909f1,this['revert']=_0x40945c,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x25f6a1){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3798a3=this['affectedTree']['subtree'](new C(_0x25f6a1));return new In(w(),_0x3798a3,this['revert']);}}else return f(y(this['path'])===_0x25f6a1,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4e1d7b,_0x3ff42f){this['source']=_0x4e1d7b,this['path']=_0x3ff42f,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x404c8b){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x41f150,_0x102737,_0x4c222c){this['source']=_0x41f150,this['path']=_0x102737,this['snap']=_0x4c222c,this['type']=z['OVERWRITE'];}['operationForChild'](_0x17ac9f){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x17ac9f)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x432069,_0x3cddd9,_0x2fa1f7){this['source']=_0x432069,this['path']=_0x3cddd9,this['children']=_0x2fa1f7,this['type']=z['MERGE'];}['operationForChild'](_0x5d13f0){if(v(this['path'])){const _0x4a1ea7=this['children']['subtree'](new C(_0x5d13f0));return _0x4a1ea7['isEmpty']()?null:_0x4a1ea7['value']?new Be(this['source'],w(),_0x4a1ea7['value']):new ot(this['source'],w(),_0x4a1ea7);}else return f(y(this['path'])===_0x5d13f0,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x4b436f,_0x135541,_0x4ee8f5){this['node_']=_0x4b436f,this['fullyInitialized_']=_0x135541,this['filtered_']=_0x4ee8f5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1d6648){if(v(_0x1d6648))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5adaf8=y(_0x1d6648);return this['isCompleteForChild'](_0x5adaf8);}['isCompleteForChild'](_0x3d6cda){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3d6cda);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2b53c6){this['query_']=_0x2b53c6,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x406f8f,_0x552e72,_0x19f27d,_0x46d408){const _0x2caa22=[],_0x18ae89=[];return _0x552e72['forEach'](_0x1acade=>{_0x1acade['type']==='child_changed'&&_0x406f8f['index_']['indexedValueChanged'](_0x1acade['oldSnap'],_0x1acade['snapshotNode'])&&_0x18ae89['push'](zh(_0x1acade['childName'],_0x1acade['snapshotNode']));}),wt(_0x406f8f,_0x2caa22,'child_removed',_0x552e72,_0x46d408,_0x19f27d),wt(_0x406f8f,_0x2caa22,'child_added',_0x552e72,_0x46d408,_0x19f27d),wt(_0x406f8f,_0x2caa22,'child_moved',_0x18ae89,_0x46d408,_0x19f27d),wt(_0x406f8f,_0x2caa22,'child_changed',_0x552e72,_0x46d408,_0x19f27d),wt(_0x406f8f,_0x2caa22,'value',_0x552e72,_0x46d408,_0x19f27d),_0x2caa22;}function wt(_0x17c72d,_0x53d300,_0x197dae,_0x5e84b1,_0x192618,_0x49c0c6){const _0x1edebe=_0x5e84b1['filter'](_0x4a3474=>_0x4a3474['type']===_0x197dae);_0x1edebe['sort']((_0x243a36,_0x4eb389)=>au(_0x17c72d,_0x243a36,_0x4eb389)),_0x1edebe['forEach'](_0x5aa840=>{const _0x4445bf=ou(_0x17c72d,_0x5aa840,_0x49c0c6);_0x192618['forEach'](_0xe7c12e=>{_0xe7c12e['respondsTo'](_0x5aa840['type'])&&_0x53d300['push'](_0xe7c12e['createEvent'](_0x4445bf,_0x17c72d['query_']));});});}function ou(_0x5cf21e,_0x2540f9,_0x574e1a){return _0x2540f9['type']==='value'||_0x2540f9['type']==='child_removed'||(_0x2540f9['prevName']=_0x574e1a['getPredecessorChildName'](_0x2540f9['childName'],_0x2540f9['snapshotNode'],_0x5cf21e['index_'])),_0x2540f9;}function au(_0x4fe846,_0x1423d1,_0xb2993a){if(_0x1423d1['childName']==null||_0xb2993a['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x47885a=new E(_0x1423d1['childName'],_0x1423d1['snapshotNode']),_0x348ae8=new E(_0xb2993a['childName'],_0xb2993a['snapshotNode']);return _0x4fe846['index_']['compare'](_0x47885a,_0x348ae8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2bec46,_0x2e3df6){return{'eventCache':_0x2bec46,'serverCache':_0x2e3df6};}function Rt(_0x3e2587,_0x143b84,_0xceb8a7,_0x56626d){return Un(new Te(_0x143b84,_0xceb8a7,_0x56626d),_0x3e2587['serverCache']);}function Fo(_0x4a22cb,_0x40f7c7,_0x2b5604,_0x5f112f){return Un(_0x4a22cb['eventCache'],new Te(_0x40f7c7,_0x2b5604,_0x5f112f));}function wn(_0x41a0c1){return _0x41a0c1['eventCache']['isFullyInitialized']()?_0x41a0c1['eventCache']['getNode']():null;}function Ve(_0x491bbf){return _0x491bbf['serverCache']['isFullyInitialized']()?_0x491bbf['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x28eddf){let _0x4547c8=new b(null);return x(_0x28eddf,(_0x46493f,_0x2f2e95)=>{_0x4547c8=_0x4547c8['set'](new C(_0x46493f),_0x2f2e95);}),_0x4547c8;}constructor(_0x1eb666,_0x49af0f=cu()){this['value']=_0x1eb666,this['children']=_0x49af0f;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xc3f750,_0xd09926){if(this['value']!=null&&_0xd09926(this['value']))return{'path':w(),'value':this['value']};if(v(_0xc3f750))return null;{const _0x1aa67e=y(_0xc3f750),_0x552b3a=this['children']['get'](_0x1aa67e);if(_0x552b3a!==null){const _0x4c1fc6=_0x552b3a['findRootMostMatchingPathAndValue'](S(_0xc3f750),_0xd09926);return _0x4c1fc6!=null?{'path':k(new C(_0x1aa67e),_0x4c1fc6['path']),'value':_0x4c1fc6['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3b9e64){return this['findRootMostMatchingPathAndValue'](_0x3b9e64,()=>!0x0);}['subtree'](_0x42328e){if(v(_0x42328e))return this;{const _0x109e78=y(_0x42328e),_0x4ee40c=this['children']['get'](_0x109e78);return _0x4ee40c!==null?_0x4ee40c['subtree'](S(_0x42328e)):new b(null);}}['set'](_0x37bf73,_0x1fecff){if(v(_0x37bf73))return new b(_0x1fecff,this['children']);{const _0x189c98=y(_0x37bf73),_0x5ad5c0=(this['children']['get'](_0x189c98)||new b(null))['set'](S(_0x37bf73),_0x1fecff),_0x39bffd=this['children']['insert'](_0x189c98,_0x5ad5c0);return new b(this['value'],_0x39bffd);}}['remove'](_0x434777){if(v(_0x434777))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x36c3e3=y(_0x434777),_0x1bb965=this['children']['get'](_0x36c3e3);if(_0x1bb965){const _0x40ba38=_0x1bb965['remove'](S(_0x434777));let _0xd9cd36;return _0x40ba38['isEmpty']()?_0xd9cd36=this['children']['remove'](_0x36c3e3):_0xd9cd36=this['children']['insert'](_0x36c3e3,_0x40ba38),this['value']===null&&_0xd9cd36['isEmpty']()?new b(null):new b(this['value'],_0xd9cd36);}else return this;}}['get'](_0x5a0a0d){if(v(_0x5a0a0d))return this['value'];{const _0x324463=y(_0x5a0a0d),_0x3a3764=this['children']['get'](_0x324463);return _0x3a3764?_0x3a3764['get'](S(_0x5a0a0d)):null;}}['setTree'](_0x34cc05,_0x5d8e27){if(v(_0x34cc05))return _0x5d8e27;{const _0x3d33aa=y(_0x34cc05),_0x26f7dd=(this['children']['get'](_0x3d33aa)||new b(null))['setTree'](S(_0x34cc05),_0x5d8e27);let _0x171e6f;return _0x26f7dd['isEmpty']()?_0x171e6f=this['children']['remove'](_0x3d33aa):_0x171e6f=this['children']['insert'](_0x3d33aa,_0x26f7dd),new b(this['value'],_0x171e6f);}}['fold'](_0x511cea){return this['fold_'](w(),_0x511cea);}['fold_'](_0x209c26,_0x5e49c1){const _0xed0f6f={};return this['children']['inorderTraversal']((_0x5245c,_0x395ca9)=>{_0xed0f6f[_0x5245c]=_0x395ca9['fold_'](k(_0x209c26,_0x5245c),_0x5e49c1);}),_0x5e49c1(_0x209c26,this['value'],_0xed0f6f);}['findOnPath'](_0x7b959f,_0x4eef4e){return this['findOnPath_'](_0x7b959f,w(),_0x4eef4e);}['findOnPath_'](_0x1db89d,_0x49dd78,_0x13021c){const _0x58196d=this['value']?_0x13021c(_0x49dd78,this['value']):!0x1;if(_0x58196d)return _0x58196d;if(v(_0x1db89d))return null;{const _0x589c08=y(_0x1db89d),_0xb44668=this['children']['get'](_0x589c08);return _0xb44668?_0xb44668['findOnPath_'](S(_0x1db89d),k(_0x49dd78,_0x589c08),_0x13021c):null;}}['foreachOnPath'](_0x10f7ee,_0x5d39e4){return this['foreachOnPath_'](_0x10f7ee,w(),_0x5d39e4);}['foreachOnPath_'](_0x1c578e,_0xb73bae,_0x4b9be8){if(v(_0x1c578e))return this;{this['value']&&_0x4b9be8(_0xb73bae,this['value']);const _0x48fc5d=y(_0x1c578e),_0x183335=this['children']['get'](_0x48fc5d);return _0x183335?_0x183335['foreachOnPath_'](S(_0x1c578e),k(_0xb73bae,_0x48fc5d),_0x4b9be8):new b(null);}}['foreach'](_0xfe6d){this['foreach_'](w(),_0xfe6d);}['foreach_'](_0x59e765,_0xe8c0db){this['children']['inorderTraversal']((_0xa46b67,_0x5cb317)=>{_0x5cb317['foreach_'](k(_0x59e765,_0xa46b67),_0xe8c0db);}),this['value']&&_0xe8c0db(_0x59e765,this['value']);}['foreachChild'](_0x4ec553){this['children']['inorderTraversal']((_0x3979d0,_0x25e610)=>{_0x25e610['value']&&_0x4ec553(_0x3979d0,_0x25e610['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x2e4ecf){this['writeTree_']=_0x2e4ecf;}static['empty'](){return new K(new b(null));}}function At(_0x180651,_0x246517,_0x52cbe0){if(v(_0x246517))return new K(new b(_0x52cbe0));{const _0x8cb01f=_0x180651['writeTree_']['findRootMostValueAndPath'](_0x246517);if(_0x8cb01f!=null){const _0x178543=_0x8cb01f['path'];let _0x2fdc96=_0x8cb01f['value'];const _0x1741a5=F(_0x178543,_0x246517);return _0x2fdc96=_0x2fdc96['updateChild'](_0x1741a5,_0x52cbe0),new K(_0x180651['writeTree_']['set'](_0x178543,_0x2fdc96));}else{const _0x1a3392=new b(_0x52cbe0),_0x3c4d80=_0x180651['writeTree_']['setTree'](_0x246517,_0x1a3392);return new K(_0x3c4d80);}}}function bi(_0x45610d,_0x21d3c4,_0x589508){let _0x2a9ebf=_0x45610d;return x(_0x589508,(_0x20af65,_0x2b6c2a)=>{_0x2a9ebf=At(_0x2a9ebf,k(_0x21d3c4,_0x20af65),_0x2b6c2a);}),_0x2a9ebf;}function or(_0x478a55,_0x1617db){if(v(_0x1617db))return K['empty']();{const _0x7ca8b8=_0x478a55['writeTree_']['setTree'](_0x1617db,new b(null));return new K(_0x7ca8b8);}}function Ri(_0x31e242,_0x5f9bd1){return ze(_0x31e242,_0x5f9bd1)!=null;}function ze(_0x20fb83,_0x2d7b04){const _0x52bdc5=_0x20fb83['writeTree_']['findRootMostValueAndPath'](_0x2d7b04);return _0x52bdc5!=null?_0x20fb83['writeTree_']['get'](_0x52bdc5['path'])['getChild'](F(_0x52bdc5['path'],_0x2d7b04)):null;}function ar(_0x226846){const _0x4a50ca=[],_0x3f9cf0=_0x226846['writeTree_']['value'];return _0x3f9cf0!=null?_0x3f9cf0['isLeafNode']()||_0x3f9cf0['forEachChild'](R,(_0x33c76c,_0x9a371a)=>{_0x4a50ca['push'](new E(_0x33c76c,_0x9a371a));}):_0x226846['writeTree_']['children']['inorderTraversal']((_0x56fd6e,_0xc3a5b4)=>{_0xc3a5b4['value']!=null&&_0x4a50ca['push'](new E(_0x56fd6e,_0xc3a5b4['value']));}),_0x4a50ca;}function Ee(_0x300211,_0x42d4eb){if(v(_0x42d4eb))return _0x300211;{const _0x36b10e=ze(_0x300211,_0x42d4eb);return _0x36b10e!=null?new K(new b(_0x36b10e)):new K(_0x300211['writeTree_']['subtree'](_0x42d4eb));}}function Ai(_0x512573){return _0x512573['writeTree_']['isEmpty']();}function at(_0xd280f2,_0x4b7576){return Uo(w(),_0xd280f2['writeTree_'],_0x4b7576);}function Uo(_0x2edf2c,_0x52f459,_0x329b85){if(_0x52f459['value']!=null)return _0x329b85['updateChild'](_0x2edf2c,_0x52f459['value']);{let _0x21c5ba=null;return _0x52f459['children']['inorderTraversal']((_0x38ffec,_0x258fc4)=>{_0x38ffec==='.priority'?(f(_0x258fc4['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x21c5ba=_0x258fc4['value']):_0x329b85=Uo(k(_0x2edf2c,_0x38ffec),_0x258fc4,_0x329b85);}),!_0x329b85['getChild'](_0x2edf2c)['isEmpty']()&&_0x21c5ba!==null&&(_0x329b85=_0x329b85['updateChild'](k(_0x2edf2c,'.priority'),_0x21c5ba)),_0x329b85;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x8bb325,_0x58b5b7){return Ho(_0x58b5b7,_0x8bb325);}function lu(_0x487018,_0x2b5753,_0x38e70c,_0x3d9fdc,_0x2d95a8){f(_0x3d9fdc>_0x487018['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2d95a8===void 0x0&&(_0x2d95a8=!0x0),_0x487018['allWrites']['push']({'path':_0x2b5753,'snap':_0x38e70c,'writeId':_0x3d9fdc,'visible':_0x2d95a8}),_0x2d95a8&&(_0x487018['visibleWrites']=At(_0x487018['visibleWrites'],_0x2b5753,_0x38e70c)),_0x487018['lastWriteId']=_0x3d9fdc;}function hu(_0x4c9565,_0x5deab2,_0x1808bc,_0xf20b43){f(_0xf20b43>_0x4c9565['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4c9565['allWrites']['push']({'path':_0x5deab2,'children':_0x1808bc,'writeId':_0xf20b43,'visible':!0x0}),_0x4c9565['visibleWrites']=bi(_0x4c9565['visibleWrites'],_0x5deab2,_0x1808bc),_0x4c9565['lastWriteId']=_0xf20b43;}function uu(_0x4bb3e2,_0x1685de){for(let _0x4b6117=0x0;_0x4b6117<_0x4bb3e2['allWrites']['length'];_0x4b6117++){const _0x407159=_0x4bb3e2['allWrites'][_0x4b6117];if(_0x407159['writeId']===_0x1685de)return _0x407159;}return null;}function du(_0x528559,_0x188345){const _0x516ec8=_0x528559['allWrites']['findIndex'](_0x15eb77=>_0x15eb77['writeId']===_0x188345);f(_0x516ec8>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x107aa2=_0x528559['allWrites'][_0x516ec8];_0x528559['allWrites']['splice'](_0x516ec8,0x1);let _0x5359d3=_0x107aa2['visible'],_0x49cd0b=!0x1,_0xf8dd2c=_0x528559['allWrites']['length']-0x1;for(;_0x5359d3&&_0xf8dd2c>=0x0;){const _0x327ddb=_0x528559['allWrites'][_0xf8dd2c];_0x327ddb['visible']&&(_0xf8dd2c>=_0x516ec8&&fu(_0x327ddb,_0x107aa2['path'])?_0x5359d3=!0x1:G(_0x107aa2['path'],_0x327ddb['path'])&&(_0x49cd0b=!0x0)),_0xf8dd2c--;}if(_0x5359d3){if(_0x49cd0b)return pu(_0x528559),!0x0;if(_0x107aa2['snap'])_0x528559['visibleWrites']=or(_0x528559['visibleWrites'],_0x107aa2['path']);else{const _0x12584b=_0x107aa2['children'];x(_0x12584b,_0x159ed0=>{_0x528559['visibleWrites']=or(_0x528559['visibleWrites'],k(_0x107aa2['path'],_0x159ed0));});}return!0x0;}else return!0x1;}function fu(_0xad0f79,_0x54e42c){if(_0xad0f79['snap'])return G(_0xad0f79['path'],_0x54e42c);for(const _0x331dc7 in _0xad0f79['children'])if(_0xad0f79['children']['hasOwnProperty'](_0x331dc7)&&G(k(_0xad0f79['path'],_0x331dc7),_0x54e42c))return!0x0;return!0x1;}function pu(_0xb277e3){_0xb277e3['visibleWrites']=Wo(_0xb277e3['allWrites'],_u,w()),_0xb277e3['allWrites']['length']>0x0?_0xb277e3['lastWriteId']=_0xb277e3['allWrites'][_0xb277e3['allWrites']['length']-0x1]['writeId']:_0xb277e3['lastWriteId']=-0x1;}function _u(_0x360977){return _0x360977['visible'];}function Wo(_0x39177f,_0xeb8d20,_0x27eb2b){let _0xe1c7d9=K['empty']();for(let _0x2847b8=0x0;_0x2847b8<_0x39177f['length'];++_0x2847b8){const _0x3dbb68=_0x39177f[_0x2847b8];if(_0xeb8d20(_0x3dbb68)){const _0x3d860a=_0x3dbb68['path'];let _0x1071d2;if(_0x3dbb68['snap'])G(_0x27eb2b,_0x3d860a)?(_0x1071d2=F(_0x27eb2b,_0x3d860a),_0xe1c7d9=At(_0xe1c7d9,_0x1071d2,_0x3dbb68['snap'])):G(_0x3d860a,_0x27eb2b)&&(_0x1071d2=F(_0x3d860a,_0x27eb2b),_0xe1c7d9=At(_0xe1c7d9,w(),_0x3dbb68['snap']['getChild'](_0x1071d2)));else{if(_0x3dbb68['children']){if(G(_0x27eb2b,_0x3d860a))_0x1071d2=F(_0x27eb2b,_0x3d860a),_0xe1c7d9=bi(_0xe1c7d9,_0x1071d2,_0x3dbb68['children']);else{if(G(_0x3d860a,_0x27eb2b)){if(_0x1071d2=F(_0x3d860a,_0x27eb2b),v(_0x1071d2))_0xe1c7d9=bi(_0xe1c7d9,w(),_0x3dbb68['children']);else{const _0x306815=Le(_0x3dbb68['children'],y(_0x1071d2));if(_0x306815){const _0x287db5=_0x306815['getChild'](S(_0x1071d2));_0xe1c7d9=At(_0xe1c7d9,w(),_0x287db5);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xe1c7d9;}function Bo(_0x47b6da,_0x3272e6,_0x195bc5,_0x4fa0f9,_0xf337d4){if(!_0x4fa0f9&&!_0xf337d4){const _0x3d94b4=ze(_0x47b6da['visibleWrites'],_0x3272e6);if(_0x3d94b4!=null)return _0x3d94b4;{const _0x4e8503=Ee(_0x47b6da['visibleWrites'],_0x3272e6);if(Ai(_0x4e8503))return _0x195bc5;if(_0x195bc5==null&&!Ri(_0x4e8503,w()))return null;{const _0x1ce66c=_0x195bc5||g['EMPTY_NODE'];return at(_0x4e8503,_0x1ce66c);}}}else{const _0x6bf576=Ee(_0x47b6da['visibleWrites'],_0x3272e6);if(!_0xf337d4&&Ai(_0x6bf576))return _0x195bc5;if(!_0xf337d4&&_0x195bc5==null&&!Ri(_0x6bf576,w()))return null;{const _0x4b79fe=function(_0x2a55ee){return(_0x2a55ee['visible']||_0xf337d4)&&(!_0x4fa0f9||!~_0x4fa0f9['indexOf'](_0x2a55ee['writeId']))&&(G(_0x2a55ee['path'],_0x3272e6)||G(_0x3272e6,_0x2a55ee['path']));},_0x4dc929=Wo(_0x47b6da['allWrites'],_0x4b79fe,_0x3272e6),_0x837f7=_0x195bc5||g['EMPTY_NODE'];return at(_0x4dc929,_0x837f7);}}}function gu(_0x48442c,_0x2cab4d,_0x451fc2){let _0x1ef081=g['EMPTY_NODE'];const _0x5ae233=ze(_0x48442c['visibleWrites'],_0x2cab4d);if(_0x5ae233)return _0x5ae233['isLeafNode']()||_0x5ae233['forEachChild'](R,(_0x22c426,_0x2c94e7)=>{_0x1ef081=_0x1ef081['updateImmediateChild'](_0x22c426,_0x2c94e7);}),_0x1ef081;if(_0x451fc2){const _0x1633c9=Ee(_0x48442c['visibleWrites'],_0x2cab4d);return _0x451fc2['forEachChild'](R,(_0x42953f,_0x19b546)=>{const _0x23de02=at(Ee(_0x1633c9,new C(_0x42953f)),_0x19b546);_0x1ef081=_0x1ef081['updateImmediateChild'](_0x42953f,_0x23de02);}),ar(_0x1633c9)['forEach'](_0x136cb7=>{_0x1ef081=_0x1ef081['updateImmediateChild'](_0x136cb7['name'],_0x136cb7['node']);}),_0x1ef081;}else{const _0x53c43f=Ee(_0x48442c['visibleWrites'],_0x2cab4d);return ar(_0x53c43f)['forEach'](_0x4cda12=>{_0x1ef081=_0x1ef081['updateImmediateChild'](_0x4cda12['name'],_0x4cda12['node']);}),_0x1ef081;}}function mu(_0x4e4110,_0x440fea,_0x4b4599,_0x5a73a,_0x406574){f(_0x5a73a||_0x406574,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xa3241a=k(_0x440fea,_0x4b4599);if(Ri(_0x4e4110['visibleWrites'],_0xa3241a))return null;{const _0x4b70e9=Ee(_0x4e4110['visibleWrites'],_0xa3241a);return Ai(_0x4b70e9)?_0x406574['getChild'](_0x4b4599):at(_0x4b70e9,_0x406574['getChild'](_0x4b4599));}}function yu(_0x3cb78d,_0x180913,_0x38c30f,_0x6ad106){const _0x6a9f7f=k(_0x180913,_0x38c30f),_0x42ccc1=ze(_0x3cb78d['visibleWrites'],_0x6a9f7f);if(_0x42ccc1!=null)return _0x42ccc1;if(_0x6ad106['isCompleteForChild'](_0x38c30f)){const _0x1fb251=Ee(_0x3cb78d['visibleWrites'],_0x6a9f7f);return at(_0x1fb251,_0x6ad106['getNode']()['getImmediateChild'](_0x38c30f));}else return null;}function vu(_0x19faef,_0x10fff4){return ze(_0x19faef['visibleWrites'],_0x10fff4);}function Eu(_0x142551,_0x345879,_0x882a57,_0x32a3df,_0x40f8f1,_0x2a37fe,_0x138a24){let _0x116d32;const _0x44f03f=Ee(_0x142551['visibleWrites'],_0x345879),_0x248cbf=ze(_0x44f03f,w());if(_0x248cbf!=null)_0x116d32=_0x248cbf;else{if(_0x882a57!=null)_0x116d32=at(_0x44f03f,_0x882a57);else return[];}if(_0x116d32=_0x116d32['withIndex'](_0x138a24),!_0x116d32['isEmpty']()&&!_0x116d32['isLeafNode']()){const _0x147f1f=[],_0x4d2f43=_0x138a24['getCompare'](),_0x393f28=_0x2a37fe?_0x116d32['getReverseIteratorFrom'](_0x32a3df,_0x138a24):_0x116d32['getIteratorFrom'](_0x32a3df,_0x138a24);let _0x3ab5dd=_0x393f28['getNext']();for(;_0x3ab5dd&&_0x147f1f['length']<_0x40f8f1;)_0x4d2f43(_0x3ab5dd,_0x32a3df)!==0x0&&_0x147f1f['push'](_0x3ab5dd),_0x3ab5dd=_0x393f28['getNext']();return _0x147f1f;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x29d076,_0x3f34f,_0x45be80,_0xb9d81c){return Bo(_0x29d076['writeTree'],_0x29d076['treePath'],_0x3f34f,_0x45be80,_0xb9d81c);}function is(_0x49cef6,_0xe9fb8a){return gu(_0x49cef6['writeTree'],_0x49cef6['treePath'],_0xe9fb8a);}function cr(_0x466d78,_0x42ba72,_0x4ac1d7,_0x665a9e){return mu(_0x466d78['writeTree'],_0x466d78['treePath'],_0x42ba72,_0x4ac1d7,_0x665a9e);}function Tn(_0x526f79,_0xf4b5da){return vu(_0x526f79['writeTree'],k(_0x526f79['treePath'],_0xf4b5da));}function wu(_0x3c10db,_0x3bea71,_0x331d58,_0x1124f6,_0x3a5030,_0x42ebaf){return Eu(_0x3c10db['writeTree'],_0x3c10db['treePath'],_0x3bea71,_0x331d58,_0x1124f6,_0x3a5030,_0x42ebaf);}function ss(_0x88175f,_0x4321c5,_0x636f92){return yu(_0x88175f['writeTree'],_0x88175f['treePath'],_0x4321c5,_0x636f92);}function Vo(_0x51bfb1,_0x28d9ef){return Ho(k(_0x51bfb1['treePath'],_0x28d9ef),_0x51bfb1['writeTree']);}function Ho(_0x5adb3f,_0x177975){return{'treePath':_0x5adb3f,'writeTree':_0x177975};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3903a1){const _0x1ba164=_0x3903a1['type'],_0x2f1247=_0x3903a1['childName'];f(_0x1ba164==='child_added'||_0x1ba164==='child_changed'||_0x1ba164==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2f1247!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x379618=this['changeMap']['get'](_0x2f1247);if(_0x379618){const _0x49990c=_0x379618['type'];if(_0x1ba164==='child_added'&&_0x49990c==='child_removed')this['changeMap']['set'](_0x2f1247,xt(_0x2f1247,_0x3903a1['snapshotNode'],_0x379618['snapshotNode']));else{if(_0x1ba164==='child_removed'&&_0x49990c==='child_added')this['changeMap']['delete'](_0x2f1247);else{if(_0x1ba164==='child_removed'&&_0x49990c==='child_changed')this['changeMap']['set'](_0x2f1247,Lt(_0x2f1247,_0x379618['oldSnap']));else{if(_0x1ba164==='child_changed'&&_0x49990c==='child_added')this['changeMap']['set'](_0x2f1247,rt(_0x2f1247,_0x3903a1['snapshotNode']));else{if(_0x1ba164==='child_changed'&&_0x49990c==='child_changed')this['changeMap']['set'](_0x2f1247,xt(_0x2f1247,_0x3903a1['snapshotNode'],_0x379618['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x3903a1+'\x20occurred\x20after\x20'+_0x379618);}}}}}else this['changeMap']['set'](_0x2f1247,_0x3903a1);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x4ae1fa){return null;}['getChildAfterChild'](_0x16abec,_0x22a9ed,_0x2c748b){return null;}}const $o=new Tu();class rs{constructor(_0x45bba6,_0x1b0554,_0x1f8f9d=null){this['writes_']=_0x45bba6,this['viewCache_']=_0x1b0554,this['optCompleteServerCache_']=_0x1f8f9d;}['getCompleteChild'](_0xe64dec){const _0x501c83=this['viewCache_']['eventCache'];if(_0x501c83['isCompleteForChild'](_0xe64dec))return _0x501c83['getNode']()['getImmediateChild'](_0xe64dec);{const _0x5abc14=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0xe64dec,_0x5abc14);}}['getChildAfterChild'](_0x1b8a3c,_0x2772a7,_0xfb94c8){const _0x302b46=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x24abac=wu(this['writes_'],_0x302b46,_0x2772a7,0x1,_0xfb94c8,_0x1b8a3c);return _0x24abac['length']===0x0?null:_0x24abac[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x54cea5){return{'filter':_0x54cea5};}function bu(_0x3c52d9,_0x26a2ed){f(_0x26a2ed['eventCache']['getNode']()['isIndexed'](_0x3c52d9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x26a2ed['serverCache']['getNode']()['isIndexed'](_0x3c52d9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4c6e11,_0x3d07aa,_0x464e32,_0x4aab1d,_0x33315d){const _0x2df237=new Cu();let _0x1b1a60,_0x2abd63;if(_0x464e32['type']===z['OVERWRITE']){const _0x56de28=_0x464e32;_0x56de28['source']['fromUser']?_0x1b1a60=ki(_0x4c6e11,_0x3d07aa,_0x56de28['path'],_0x56de28['snap'],_0x4aab1d,_0x33315d,_0x2df237):(f(_0x56de28['source']['fromServer'],'Unknown\x20source.'),_0x2abd63=_0x56de28['source']['tagged']||_0x3d07aa['serverCache']['isFiltered']()&&!v(_0x56de28['path']),_0x1b1a60=Sn(_0x4c6e11,_0x3d07aa,_0x56de28['path'],_0x56de28['snap'],_0x4aab1d,_0x33315d,_0x2abd63,_0x2df237));}else{if(_0x464e32['type']===z['MERGE']){const _0x2ec747=_0x464e32;_0x2ec747['source']['fromUser']?_0x1b1a60=ku(_0x4c6e11,_0x3d07aa,_0x2ec747['path'],_0x2ec747['children'],_0x4aab1d,_0x33315d,_0x2df237):(f(_0x2ec747['source']['fromServer'],'Unknown\x20source.'),_0x2abd63=_0x2ec747['source']['tagged']||_0x3d07aa['serverCache']['isFiltered'](),_0x1b1a60=Pi(_0x4c6e11,_0x3d07aa,_0x2ec747['path'],_0x2ec747['children'],_0x4aab1d,_0x33315d,_0x2abd63,_0x2df237));}else{if(_0x464e32['type']===z['ACK_USER_WRITE']){const _0x313211=_0x464e32;_0x313211['revert']?_0x1b1a60=Ou(_0x4c6e11,_0x3d07aa,_0x313211['path'],_0x4aab1d,_0x33315d,_0x2df237):_0x1b1a60=Pu(_0x4c6e11,_0x3d07aa,_0x313211['path'],_0x313211['affectedTree'],_0x4aab1d,_0x33315d,_0x2df237);}else{if(_0x464e32['type']===z['LISTEN_COMPLETE'])_0x1b1a60=Nu(_0x4c6e11,_0x3d07aa,_0x464e32['path'],_0x4aab1d,_0x2df237);else throw ht('Unknown\x20operation\x20type:\x20'+_0x464e32['type']);}}}const _0x2203aa=_0x2df237['getChanges']();return Au(_0x3d07aa,_0x1b1a60,_0x2203aa),{'viewCache':_0x1b1a60,'changes':_0x2203aa};}function Au(_0x93a22a,_0x5b7a70,_0x1f5870){const _0x180281=_0x5b7a70['eventCache'];if(_0x180281['isFullyInitialized']()){const _0x15e65a=_0x180281['getNode']()['isLeafNode']()||_0x180281['getNode']()['isEmpty'](),_0x32098e=wn(_0x93a22a);(_0x1f5870['length']>0x0||!_0x93a22a['eventCache']['isFullyInitialized']()||_0x15e65a&&!_0x180281['getNode']()['equals'](_0x32098e)||!_0x180281['getNode']()['getPriority']()['equals'](_0x32098e['getPriority']()))&&_0x1f5870['push'](Lo(wn(_0x5b7a70)));}}function Go(_0x15991a,_0x4a9a2a,_0x522d5b,_0x202ebe,_0xbb5293,_0x18272b){const _0x5a51b8=_0x4a9a2a['eventCache'];if(Tn(_0x202ebe,_0x522d5b)!=null)return _0x4a9a2a;{let _0x186295,_0x586ac0;if(v(_0x522d5b)){if(f(_0x4a9a2a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4a9a2a['serverCache']['isFiltered']()){const _0x1bc3b8=Ve(_0x4a9a2a),_0x3783d7=_0x1bc3b8 instanceof g?_0x1bc3b8:g['EMPTY_NODE'],_0x5cd648=is(_0x202ebe,_0x3783d7);_0x186295=_0x15991a['filter']['updateFullNode'](_0x4a9a2a['eventCache']['getNode'](),_0x5cd648,_0x18272b);}else{const _0x4d819b=Cn(_0x202ebe,Ve(_0x4a9a2a));_0x186295=_0x15991a['filter']['updateFullNode'](_0x4a9a2a['eventCache']['getNode'](),_0x4d819b,_0x18272b);}}else{const _0xcbad60=y(_0x522d5b);if(_0xcbad60==='.priority'){f(Ce(_0x522d5b)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x26e1fc=_0x5a51b8['getNode']();_0x586ac0=_0x4a9a2a['serverCache']['getNode']();const _0x3a0450=cr(_0x202ebe,_0x522d5b,_0x26e1fc,_0x586ac0);_0x3a0450!=null?_0x186295=_0x15991a['filter']['updatePriority'](_0x26e1fc,_0x3a0450):_0x186295=_0x5a51b8['getNode']();}else{const _0x5cfb49=S(_0x522d5b);let _0x2f882c;if(_0x5a51b8['isCompleteForChild'](_0xcbad60)){_0x586ac0=_0x4a9a2a['serverCache']['getNode']();const _0x3c5ddf=cr(_0x202ebe,_0x522d5b,_0x5a51b8['getNode'](),_0x586ac0);_0x3c5ddf!=null?_0x2f882c=_0x5a51b8['getNode']()['getImmediateChild'](_0xcbad60)['updateChild'](_0x5cfb49,_0x3c5ddf):_0x2f882c=_0x5a51b8['getNode']()['getImmediateChild'](_0xcbad60);}else _0x2f882c=ss(_0x202ebe,_0xcbad60,_0x4a9a2a['serverCache']);_0x2f882c!=null?_0x186295=_0x15991a['filter']['updateChild'](_0x5a51b8['getNode'](),_0xcbad60,_0x2f882c,_0x5cfb49,_0xbb5293,_0x18272b):_0x186295=_0x5a51b8['getNode']();}}return Rt(_0x4a9a2a,_0x186295,_0x5a51b8['isFullyInitialized']()||v(_0x522d5b),_0x15991a['filter']['filtersNodes']());}}function Sn(_0x5b0726,_0x2d96da,_0x98b082,_0x5c6ef5,_0x8f9a2d,_0x53534e,_0x5a44ec,_0x5a21bb){const _0xef1e39=_0x2d96da['serverCache'];let _0x80fa6f;const _0x2f3ab4=_0x5a44ec?_0x5b0726['filter']:_0x5b0726['filter']['getIndexedFilter']();if(v(_0x98b082))_0x80fa6f=_0x2f3ab4['updateFullNode'](_0xef1e39['getNode'](),_0x5c6ef5,null);else{if(_0x2f3ab4['filtersNodes']()&&!_0xef1e39['isFiltered']()){const _0x726248=_0xef1e39['getNode']()['updateChild'](_0x98b082,_0x5c6ef5);_0x80fa6f=_0x2f3ab4['updateFullNode'](_0xef1e39['getNode'](),_0x726248,null);}else{const _0xcc8286=y(_0x98b082);if(!_0xef1e39['isCompleteForPath'](_0x98b082)&&Ce(_0x98b082)>0x1)return _0x2d96da;const _0x266750=S(_0x98b082),_0x7a446f=_0xef1e39['getNode']()['getImmediateChild'](_0xcc8286)['updateChild'](_0x266750,_0x5c6ef5);_0xcc8286==='.priority'?_0x80fa6f=_0x2f3ab4['updatePriority'](_0xef1e39['getNode'](),_0x7a446f):_0x80fa6f=_0x2f3ab4['updateChild'](_0xef1e39['getNode'](),_0xcc8286,_0x7a446f,_0x266750,$o,null);}}const _0x3d18fb=Fo(_0x2d96da,_0x80fa6f,_0xef1e39['isFullyInitialized']()||v(_0x98b082),_0x2f3ab4['filtersNodes']()),_0x5df45a=new rs(_0x8f9a2d,_0x3d18fb,_0x53534e);return Go(_0x5b0726,_0x3d18fb,_0x98b082,_0x8f9a2d,_0x5df45a,_0x5a21bb);}function ki(_0x54c475,_0x3f7a15,_0x2e1d4c,_0x1038fb,_0x234f1d,_0x4e5cc4,_0x5c3ba9){const _0x5ef548=_0x3f7a15['eventCache'];let _0x4db32c,_0x20a185;const _0x392a7a=new rs(_0x234f1d,_0x3f7a15,_0x4e5cc4);if(v(_0x2e1d4c))_0x20a185=_0x54c475['filter']['updateFullNode'](_0x3f7a15['eventCache']['getNode'](),_0x1038fb,_0x5c3ba9),_0x4db32c=Rt(_0x3f7a15,_0x20a185,!0x0,_0x54c475['filter']['filtersNodes']());else{const _0x52e5a7=y(_0x2e1d4c);if(_0x52e5a7==='.priority')_0x20a185=_0x54c475['filter']['updatePriority'](_0x3f7a15['eventCache']['getNode'](),_0x1038fb),_0x4db32c=Rt(_0x3f7a15,_0x20a185,_0x5ef548['isFullyInitialized'](),_0x5ef548['isFiltered']());else{const _0x2bff01=S(_0x2e1d4c),_0x53f71e=_0x5ef548['getNode']()['getImmediateChild'](_0x52e5a7);let _0x27947c;if(v(_0x2bff01))_0x27947c=_0x1038fb;else{const _0x23c059=_0x392a7a['getCompleteChild'](_0x52e5a7);_0x23c059!=null?ji(_0x2bff01)==='.priority'&&_0x23c059['getChild'](Ro(_0x2bff01))['isEmpty']()?_0x27947c=_0x23c059:_0x27947c=_0x23c059['updateChild'](_0x2bff01,_0x1038fb):_0x27947c=g['EMPTY_NODE'];}if(_0x53f71e['equals'](_0x27947c))_0x4db32c=_0x3f7a15;else{const _0x51d9b9=_0x54c475['filter']['updateChild'](_0x5ef548['getNode'](),_0x52e5a7,_0x27947c,_0x2bff01,_0x392a7a,_0x5c3ba9);_0x4db32c=Rt(_0x3f7a15,_0x51d9b9,_0x5ef548['isFullyInitialized'](),_0x54c475['filter']['filtersNodes']());}}}return _0x4db32c;}function lr(_0x3e24fb,_0x2cc55a){return _0x3e24fb['eventCache']['isCompleteForChild'](_0x2cc55a);}function ku(_0x4ebdeb,_0x15e659,_0x5dc99d,_0x12d455,_0x4294c2,_0x42706d,_0x27c99b){let _0xce756=_0x15e659;return _0x12d455['foreach']((_0x157782,_0x3348d2)=>{const _0x530509=k(_0x5dc99d,_0x157782);lr(_0x15e659,y(_0x530509))&&(_0xce756=ki(_0x4ebdeb,_0xce756,_0x530509,_0x3348d2,_0x4294c2,_0x42706d,_0x27c99b));}),_0x12d455['foreach']((_0x44e785,_0x47337b)=>{const _0x2e695d=k(_0x5dc99d,_0x44e785);lr(_0x15e659,y(_0x2e695d))||(_0xce756=ki(_0x4ebdeb,_0xce756,_0x2e695d,_0x47337b,_0x4294c2,_0x42706d,_0x27c99b));}),_0xce756;}function hr(_0x5efe50,_0x41f2f4,_0x42d00){return _0x42d00['foreach']((_0x17ce49,_0x2d8c20)=>{_0x41f2f4=_0x41f2f4['updateChild'](_0x17ce49,_0x2d8c20);}),_0x41f2f4;}function Pi(_0x3cc38a,_0xc6c60e,_0x645c01,_0x388026,_0x6de53c,_0x47116c,_0x1d1d53,_0x770944){if(_0xc6c60e['serverCache']['getNode']()['isEmpty']()&&!_0xc6c60e['serverCache']['isFullyInitialized']())return _0xc6c60e;let _0x3e343f=_0xc6c60e,_0x2c0d8c;v(_0x645c01)?_0x2c0d8c=_0x388026:_0x2c0d8c=new b(null)['setTree'](_0x645c01,_0x388026);const _0x38477a=_0xc6c60e['serverCache']['getNode']();return _0x2c0d8c['children']['inorderTraversal']((_0x573b80,_0x9a58b9)=>{if(_0x38477a['hasChild'](_0x573b80)){const _0x159956=_0xc6c60e['serverCache']['getNode']()['getImmediateChild'](_0x573b80),_0x308805=hr(_0x3cc38a,_0x159956,_0x9a58b9);_0x3e343f=Sn(_0x3cc38a,_0x3e343f,new C(_0x573b80),_0x308805,_0x6de53c,_0x47116c,_0x1d1d53,_0x770944);}}),_0x2c0d8c['children']['inorderTraversal']((_0x45fccb,_0x1730bb)=>{const _0x42a425=!_0xc6c60e['serverCache']['isCompleteForChild'](_0x45fccb)&&_0x1730bb['value']===null;if(!_0x38477a['hasChild'](_0x45fccb)&&!_0x42a425){const _0x4dcffc=_0xc6c60e['serverCache']['getNode']()['getImmediateChild'](_0x45fccb),_0x4da03a=hr(_0x3cc38a,_0x4dcffc,_0x1730bb);_0x3e343f=Sn(_0x3cc38a,_0x3e343f,new C(_0x45fccb),_0x4da03a,_0x6de53c,_0x47116c,_0x1d1d53,_0x770944);}}),_0x3e343f;}function Pu(_0x282d6c,_0x5881af,_0x421c81,_0x1c0caa,_0x134b32,_0x525715,_0x28338a){if(Tn(_0x134b32,_0x421c81)!=null)return _0x5881af;const _0x48ea03=_0x5881af['serverCache']['isFiltered'](),_0x4cf8c8=_0x5881af['serverCache'];if(_0x1c0caa['value']!=null){if(v(_0x421c81)&&_0x4cf8c8['isFullyInitialized']()||_0x4cf8c8['isCompleteForPath'](_0x421c81))return Sn(_0x282d6c,_0x5881af,_0x421c81,_0x4cf8c8['getNode']()['getChild'](_0x421c81),_0x134b32,_0x525715,_0x48ea03,_0x28338a);if(v(_0x421c81)){let _0x5603d3=new b(null);return _0x4cf8c8['getNode']()['forEachChild'](ve,(_0x2707df,_0x33201a)=>{_0x5603d3=_0x5603d3['set'](new C(_0x2707df),_0x33201a);}),Pi(_0x282d6c,_0x5881af,_0x421c81,_0x5603d3,_0x134b32,_0x525715,_0x48ea03,_0x28338a);}else return _0x5881af;}else{let _0x5db12f=new b(null);return _0x1c0caa['foreach']((_0x576bc3,_0x536df2)=>{const _0x180b06=k(_0x421c81,_0x576bc3);_0x4cf8c8['isCompleteForPath'](_0x180b06)&&(_0x5db12f=_0x5db12f['set'](_0x576bc3,_0x4cf8c8['getNode']()['getChild'](_0x180b06)));}),Pi(_0x282d6c,_0x5881af,_0x421c81,_0x5db12f,_0x134b32,_0x525715,_0x48ea03,_0x28338a);}}function Nu(_0x3d531f,_0x5f3516,_0x5d8ce9,_0x93d300,_0x1d2460){const _0x2cd4fd=_0x5f3516['serverCache'],_0x4946ac=Fo(_0x5f3516,_0x2cd4fd['getNode'](),_0x2cd4fd['isFullyInitialized']()||v(_0x5d8ce9),_0x2cd4fd['isFiltered']());return Go(_0x3d531f,_0x4946ac,_0x5d8ce9,_0x93d300,$o,_0x1d2460);}function Ou(_0xa2954,_0x515cde,_0x17f5d9,_0x3dc88e,_0x3df2c0,_0x299f48){let _0x43ed68;if(Tn(_0x3dc88e,_0x17f5d9)!=null)return _0x515cde;{const _0x790f61=new rs(_0x3dc88e,_0x515cde,_0x3df2c0),_0x4ad1fb=_0x515cde['eventCache']['getNode']();let _0x7d9346;if(v(_0x17f5d9)||y(_0x17f5d9)==='.priority'){let _0x1cec51;if(_0x515cde['serverCache']['isFullyInitialized']())_0x1cec51=Cn(_0x3dc88e,Ve(_0x515cde));else{const _0x4a5e31=_0x515cde['serverCache']['getNode']();f(_0x4a5e31 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1cec51=is(_0x3dc88e,_0x4a5e31);}_0x1cec51=_0x1cec51,_0x7d9346=_0xa2954['filter']['updateFullNode'](_0x4ad1fb,_0x1cec51,_0x299f48);}else{const _0x4ecf70=y(_0x17f5d9);let _0x25756=ss(_0x3dc88e,_0x4ecf70,_0x515cde['serverCache']);_0x25756==null&&_0x515cde['serverCache']['isCompleteForChild'](_0x4ecf70)&&(_0x25756=_0x4ad1fb['getImmediateChild'](_0x4ecf70)),_0x25756!=null?_0x7d9346=_0xa2954['filter']['updateChild'](_0x4ad1fb,_0x4ecf70,_0x25756,S(_0x17f5d9),_0x790f61,_0x299f48):_0x515cde['eventCache']['getNode']()['hasChild'](_0x4ecf70)?_0x7d9346=_0xa2954['filter']['updateChild'](_0x4ad1fb,_0x4ecf70,g['EMPTY_NODE'],S(_0x17f5d9),_0x790f61,_0x299f48):_0x7d9346=_0x4ad1fb,_0x7d9346['isEmpty']()&&_0x515cde['serverCache']['isFullyInitialized']()&&(_0x43ed68=Cn(_0x3dc88e,Ve(_0x515cde)),_0x43ed68['isLeafNode']()&&(_0x7d9346=_0xa2954['filter']['updateFullNode'](_0x7d9346,_0x43ed68,_0x299f48)));}return _0x43ed68=_0x515cde['serverCache']['isFullyInitialized']()||Tn(_0x3dc88e,w())!=null,Rt(_0x515cde,_0x7d9346,_0x43ed68,_0xa2954['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x57f145,_0x47a350){this['query_']=_0x57f145,this['eventRegistrations_']=[];const _0x5580d5=this['query_']['_queryParams'],_0x56d5b3=new Xi(_0x5580d5['getIndex']()),_0x29d847=Kh(_0x5580d5);this['processor_']=Su(_0x29d847);const _0x101f0d=_0x47a350['serverCache'],_0x56997b=_0x47a350['eventCache'],_0x140b67=_0x56d5b3['updateFullNode'](g['EMPTY_NODE'],_0x101f0d['getNode'](),null),_0xd6e0b1=_0x29d847['updateFullNode'](g['EMPTY_NODE'],_0x56997b['getNode'](),null),_0x218162=new Te(_0x140b67,_0x101f0d['isFullyInitialized'](),_0x56d5b3['filtersNodes']()),_0x1ec2ae=new Te(_0xd6e0b1,_0x56997b['isFullyInitialized'](),_0x29d847['filtersNodes']());this['viewCache_']=Un(_0x1ec2ae,_0x218162),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x4a524b){return _0x4a524b['viewCache_']['serverCache']['getNode']();}function Lu(_0x3c5aa3){return wn(_0x3c5aa3['viewCache_']);}function xu(_0x10ed2d,_0x58f57f){const _0xfa9d0a=Ve(_0x10ed2d['viewCache_']);return _0xfa9d0a&&(_0x10ed2d['query']['_queryParams']['loadsAllData']()||!v(_0x58f57f)&&!_0xfa9d0a['getImmediateChild'](y(_0x58f57f))['isEmpty']())?_0xfa9d0a['getChild'](_0x58f57f):null;}function ur(_0x425e73){return _0x425e73['eventRegistrations_']['length']===0x0;}function Fu(_0x3edb95,_0x43be7e){_0x3edb95['eventRegistrations_']['push'](_0x43be7e);}function dr(_0x5f3033,_0x121735,_0x32c902){const _0x541b17=[];if(_0x32c902){f(_0x121735==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x539b29=_0x5f3033['query']['_path'];_0x5f3033['eventRegistrations_']['forEach'](_0x4bf834=>{const _0x557884=_0x4bf834['createCancelEvent'](_0x32c902,_0x539b29);_0x557884&&_0x541b17['push'](_0x557884);});}if(_0x121735){let _0x95ac21=[];for(let _0x243fdc=0x0;_0x243fdc<_0x5f3033['eventRegistrations_']['length'];++_0x243fdc){const _0x134f19=_0x5f3033['eventRegistrations_'][_0x243fdc];if(!_0x134f19['matches'](_0x121735))_0x95ac21['push'](_0x134f19);else{if(_0x121735['hasAnyCallback']()){_0x95ac21=_0x95ac21['concat'](_0x5f3033['eventRegistrations_']['slice'](_0x243fdc+0x1));break;}}}_0x5f3033['eventRegistrations_']=_0x95ac21;}else _0x5f3033['eventRegistrations_']=[];return _0x541b17;}function fr(_0x57f917,_0x26162e,_0xf8a479,_0x58856a){_0x26162e['type']===z['MERGE']&&_0x26162e['source']['queryId']!==null&&(f(Ve(_0x57f917['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x57f917['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4bb85c=_0x57f917['viewCache_'],_0x1ad4d6=Ru(_0x57f917['processor_'],_0x4bb85c,_0x26162e,_0xf8a479,_0x58856a);return bu(_0x57f917['processor_'],_0x1ad4d6['viewCache']),f(_0x1ad4d6['viewCache']['serverCache']['isFullyInitialized']()||!_0x4bb85c['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x57f917['viewCache_']=_0x1ad4d6['viewCache'],qo(_0x57f917,_0x1ad4d6['changes'],_0x1ad4d6['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2c7a7c,_0x5dbf93){const _0x41178d=_0x2c7a7c['viewCache_']['eventCache'],_0x1fde8c=[];return _0x41178d['getNode']()['isLeafNode']()||_0x41178d['getNode']()['forEachChild'](R,(_0x4540e2,_0x1cff35)=>{_0x1fde8c['push'](rt(_0x4540e2,_0x1cff35));}),_0x41178d['isFullyInitialized']()&&_0x1fde8c['push'](Lo(_0x41178d['getNode']())),qo(_0x2c7a7c,_0x1fde8c,_0x41178d['getNode'](),_0x5dbf93);}function qo(_0x5ecb26,_0x4bf8f0,_0x26203b,_0x42948c){const _0x58df7e=_0x42948c?[_0x42948c]:_0x5ecb26['eventRegistrations_'];return ru(_0x5ecb26['eventGenerator_'],_0x4bf8f0,_0x26203b,_0x58df7e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x346d25){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x346d25;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x555e06){return _0x555e06['views']['size']===0x0;}function os(_0x11eaa6,_0x1e19e5,_0x414530,_0x8ec92c){const _0x50944d=_0x1e19e5['source']['queryId'];if(_0x50944d!==null){const _0x412399=_0x11eaa6['views']['get'](_0x50944d);return f(_0x412399!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x412399,_0x1e19e5,_0x414530,_0x8ec92c);}else{let _0x117c5a=[];for(const _0xc90d43 of _0x11eaa6['views']['values']())_0x117c5a=_0x117c5a['concat'](fr(_0xc90d43,_0x1e19e5,_0x414530,_0x8ec92c));return _0x117c5a;}}function jo(_0x5b440b,_0x5a7f81,_0x491f65,_0x24af97,_0xf4edd9){const _0x57c18d=_0x5a7f81['_queryIdentifier'],_0x433cae=_0x5b440b['views']['get'](_0x57c18d);if(!_0x433cae){let _0xb27b51=Cn(_0x491f65,_0xf4edd9?_0x24af97:null),_0x3f4b71=!0x1;_0xb27b51?_0x3f4b71=!0x0:_0x24af97 instanceof g?(_0xb27b51=is(_0x491f65,_0x24af97),_0x3f4b71=!0x1):(_0xb27b51=g['EMPTY_NODE'],_0x3f4b71=!0x1);const _0x542d37=Un(new Te(_0xb27b51,_0x3f4b71,!0x1),new Te(_0x24af97,_0xf4edd9,!0x1));return new Du(_0x5a7f81,_0x542d37);}return _0x433cae;}function Hu(_0x231b9a,_0x3b4cc1,_0xcd4f10,_0x6b854b,_0x5254c8,_0x3a312d){const _0x597c30=jo(_0x231b9a,_0x3b4cc1,_0x6b854b,_0x5254c8,_0x3a312d);return _0x231b9a['views']['has'](_0x3b4cc1['_queryIdentifier'])||_0x231b9a['views']['set'](_0x3b4cc1['_queryIdentifier'],_0x597c30),Fu(_0x597c30,_0xcd4f10),Uu(_0x597c30,_0xcd4f10);}function $u(_0x3cbe63,_0x129e95,_0x4afeec,_0x20f709){const _0xd1ea43=_0x129e95['_queryIdentifier'],_0x3c8bdb=[];let _0x2fef13=[];const _0x3a8c75=Se(_0x3cbe63);if(_0xd1ea43==='default'){for(const [_0x399fe1,_0x297a9b]of _0x3cbe63['views']['entries']())_0x2fef13=_0x2fef13['concat'](dr(_0x297a9b,_0x4afeec,_0x20f709)),ur(_0x297a9b)&&(_0x3cbe63['views']['delete'](_0x399fe1),_0x297a9b['query']['_queryParams']['loadsAllData']()||_0x3c8bdb['push'](_0x297a9b['query']));}else{const _0x56fcb7=_0x3cbe63['views']['get'](_0xd1ea43);_0x56fcb7&&(_0x2fef13=_0x2fef13['concat'](dr(_0x56fcb7,_0x4afeec,_0x20f709)),ur(_0x56fcb7)&&(_0x3cbe63['views']['delete'](_0xd1ea43),_0x56fcb7['query']['_queryParams']['loadsAllData']()||_0x3c8bdb['push'](_0x56fcb7['query'])));}return _0x3a8c75&&!Se(_0x3cbe63)&&_0x3c8bdb['push'](new(Bu())(_0x129e95['_repo'],_0x129e95['_path'])),{'removed':_0x3c8bdb,'events':_0x2fef13};}function Ko(_0x57a6bc){const _0x496d88=[];for(const _0x362f5d of _0x57a6bc['views']['values']())_0x362f5d['query']['_queryParams']['loadsAllData']()||_0x496d88['push'](_0x362f5d);return _0x496d88;}function Ie(_0x3feacc,_0x4d0342){let _0x1ae495=null;for(const _0x4b6e7d of _0x3feacc['views']['values']())_0x1ae495=_0x1ae495||xu(_0x4b6e7d,_0x4d0342);return _0x1ae495;}function Yo(_0x45ba1b,_0x86d8d6){if(_0x86d8d6['_queryParams']['loadsAllData']())return Bn(_0x45ba1b);{const _0x30a3f3=_0x86d8d6['_queryIdentifier'];return _0x45ba1b['views']['get'](_0x30a3f3);}}function Qo(_0x112810,_0x50477e){return Yo(_0x112810,_0x50477e)!=null;}function Se(_0x502a01){return Bn(_0x502a01)!=null;}function Bn(_0x3af905){for(const _0xc91677 of _0x3af905['views']['values']())if(_0xc91677['query']['_queryParams']['loadsAllData']())return _0xc91677;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x29003c){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x29003c;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x5925d7){this['listenProvider_']=_0x5925d7,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x4811d9,_0x145dd5,_0x20dfab,_0x23ee86,_0x56ce4f){return lu(_0x4811d9['pendingWriteTree_'],_0x145dd5,_0x20dfab,_0x23ee86,_0x56ce4f),_0x56ce4f?_t(_0x4811d9,new Be(es(),_0x145dd5,_0x20dfab)):[];}function ju(_0x36cad4,_0x280599,_0xeddc7e,_0x230426){hu(_0x36cad4['pendingWriteTree_'],_0x280599,_0xeddc7e,_0x230426);const _0x4e945a=b['fromObject'](_0xeddc7e);return _t(_0x36cad4,new ot(es(),_0x280599,_0x4e945a));}function _e(_0x3b0e4a,_0x4e9156,_0x499ae5=!0x1){const _0x17a2de=uu(_0x3b0e4a['pendingWriteTree_'],_0x4e9156);if(du(_0x3b0e4a['pendingWriteTree_'],_0x4e9156)){let _0x2bab4b=new b(null);return _0x17a2de['snap']!=null?_0x2bab4b=_0x2bab4b['set'](w(),!0x0):x(_0x17a2de['children'],_0x14e8e2=>{_0x2bab4b=_0x2bab4b['set'](new C(_0x14e8e2),!0x0);}),_t(_0x3b0e4a,new In(_0x17a2de['path'],_0x2bab4b,_0x499ae5));}else return[];}function Yt(_0x3308a8,_0x4f8add,_0x34f0e5){return _t(_0x3308a8,new Be(ts(),_0x4f8add,_0x34f0e5));}function Ku(_0x4b674c,_0x27177f,_0x5b5eb2){const _0x39230c=b['fromObject'](_0x5b5eb2);return _t(_0x4b674c,new ot(ts(),_0x27177f,_0x39230c));}function Yu(_0x4e4dca,_0x205917){return _t(_0x4e4dca,new Ut(ts(),_0x205917));}function Qu(_0x22ec2c,_0xcf78b0,_0x186fb8){const _0xda45ae=cs(_0x22ec2c,_0x186fb8);if(_0xda45ae){const _0x3b1ba1=ls(_0xda45ae),_0x399415=_0x3b1ba1['path'],_0x2e190c=_0x3b1ba1['queryId'],_0x52cbdf=F(_0x399415,_0xcf78b0),_0xc27123=new Ut(ns(_0x2e190c),_0x52cbdf);return hs(_0x22ec2c,_0x399415,_0xc27123);}else return[];}function An(_0x353a76,_0x53196b,_0x40417c,_0x3db6a6,_0x491ece=!0x1){const _0x268cfc=_0x53196b['_path'],_0x314188=_0x353a76['syncPointTree_']['get'](_0x268cfc);let _0x8fafc8=[];if(_0x314188&&(_0x53196b['_queryIdentifier']==='default'||Qo(_0x314188,_0x53196b))){const _0x249443=$u(_0x314188,_0x53196b,_0x40417c,_0x3db6a6);Vu(_0x314188)&&(_0x353a76['syncPointTree_']=_0x353a76['syncPointTree_']['remove'](_0x268cfc));const _0x4199ed=_0x249443['removed'];if(_0x8fafc8=_0x249443['events'],!_0x491ece){const _0xc4e62f=_0x4199ed['findIndex'](_0x26c273=>_0x26c273['_queryParams']['loadsAllData']())!==-0x1,_0x70dcfc=_0x353a76['syncPointTree_']['findOnPath'](_0x268cfc,(_0x158236,_0x1a4862)=>Se(_0x1a4862));if(_0xc4e62f&&!_0x70dcfc){const _0x2de0b1=_0x353a76['syncPointTree_']['subtree'](_0x268cfc);if(!_0x2de0b1['isEmpty']()){const _0x38d422=Zu(_0x2de0b1);for(let _0x3587ed=0x0;_0x3587ed<_0x38d422['length'];++_0x3587ed){const _0x78e689=_0x38d422[_0x3587ed],_0x491813=_0x78e689['query'],_0x3ebf43=ea(_0x353a76,_0x78e689);_0x353a76['listenProvider_']['startListening'](kt(_0x491813),Wt(_0x353a76,_0x491813),_0x3ebf43['hashFn'],_0x3ebf43['onComplete']);}}}!_0x70dcfc&&_0x4199ed['length']>0x0&&!_0x3db6a6&&(_0xc4e62f?_0x353a76['listenProvider_']['stopListening'](kt(_0x53196b),null):_0x4199ed['forEach'](_0x35e862=>{const _0x3dc2f2=_0x353a76['queryToTagMap']['get'](Hn(_0x35e862));_0x353a76['listenProvider_']['stopListening'](kt(_0x35e862),_0x3dc2f2);}));}ed(_0x353a76,_0x4199ed);}return _0x8fafc8;}function Jo(_0x52eef6,_0x59113e,_0x5ee49e,_0x35a9ec){const _0x13e9d0=cs(_0x52eef6,_0x35a9ec);if(_0x13e9d0!=null){const _0xc5aed7=ls(_0x13e9d0),_0x3d843c=_0xc5aed7['path'],_0x7d81c0=_0xc5aed7['queryId'],_0x1f3f7e=F(_0x3d843c,_0x59113e),_0x4f56e8=new Be(ns(_0x7d81c0),_0x1f3f7e,_0x5ee49e);return hs(_0x52eef6,_0x3d843c,_0x4f56e8);}else return[];}function Ju(_0x8d8eb2,_0x5bcf35,_0x348bc1,_0x4638d1){const _0x12ae18=cs(_0x8d8eb2,_0x4638d1);if(_0x12ae18){const _0x26898d=ls(_0x12ae18),_0x20070d=_0x26898d['path'],_0x255963=_0x26898d['queryId'],_0x122eb9=F(_0x20070d,_0x5bcf35),_0x2d8cba=b['fromObject'](_0x348bc1),_0x4a330c=new ot(ns(_0x255963),_0x122eb9,_0x2d8cba);return hs(_0x8d8eb2,_0x20070d,_0x4a330c);}else return[];}function Ni(_0x278c99,_0x10d8ed,_0x5729a6,_0x4763fe=!0x1){const _0x53d2b6=_0x10d8ed['_path'];let _0x53f21f=null,_0x2b7293=!0x1;_0x278c99['syncPointTree_']['foreachOnPath'](_0x53d2b6,(_0x28a3f3,_0x1e8e7b)=>{const _0xd10c24=F(_0x28a3f3,_0x53d2b6);_0x53f21f=_0x53f21f||Ie(_0x1e8e7b,_0xd10c24),_0x2b7293=_0x2b7293||Se(_0x1e8e7b);});let _0x23402b=_0x278c99['syncPointTree_']['get'](_0x53d2b6);_0x23402b?(_0x2b7293=_0x2b7293||Se(_0x23402b),_0x53f21f=_0x53f21f||Ie(_0x23402b,w())):(_0x23402b=new zo(),_0x278c99['syncPointTree_']=_0x278c99['syncPointTree_']['set'](_0x53d2b6,_0x23402b));let _0x38e9bd;_0x53f21f!=null?_0x38e9bd=!0x0:(_0x38e9bd=!0x1,_0x53f21f=g['EMPTY_NODE'],_0x278c99['syncPointTree_']['subtree'](_0x53d2b6)['foreachChild']((_0x1d43e6,_0x29e22e)=>{const _0x58ff3a=Ie(_0x29e22e,w());_0x58ff3a&&(_0x53f21f=_0x53f21f['updateImmediateChild'](_0x1d43e6,_0x58ff3a));}));const _0x16f6a2=Qo(_0x23402b,_0x10d8ed);if(!_0x16f6a2&&!_0x10d8ed['_queryParams']['loadsAllData']()){const _0x26d4be=Hn(_0x10d8ed);f(!_0x278c99['queryToTagMap']['has'](_0x26d4be),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1230ae=td();_0x278c99['queryToTagMap']['set'](_0x26d4be,_0x1230ae),_0x278c99['tagToQueryMap']['set'](_0x1230ae,_0x26d4be);}const _0x2fb4d3=Wn(_0x278c99['pendingWriteTree_'],_0x53d2b6);let _0x2b6178=Hu(_0x23402b,_0x10d8ed,_0x5729a6,_0x2fb4d3,_0x53f21f,_0x38e9bd);if(!_0x16f6a2&&!_0x2b7293&&!_0x4763fe){const _0x3cee13=Yo(_0x23402b,_0x10d8ed);_0x2b6178=_0x2b6178['concat'](nd(_0x278c99,_0x10d8ed,_0x3cee13));}return _0x2b6178;}function Vn(_0x5c6073,_0x34885e,_0x23b489){const _0x508226=_0x5c6073['pendingWriteTree_'],_0x3f6597=_0x5c6073['syncPointTree_']['findOnPath'](_0x34885e,(_0x560bb7,_0x1fec4e)=>{const _0x513ba2=F(_0x560bb7,_0x34885e),_0x187e8e=Ie(_0x1fec4e,_0x513ba2);if(_0x187e8e)return _0x187e8e;});return Bo(_0x508226,_0x34885e,_0x3f6597,_0x23b489,!0x0);}function Xu(_0x316088,_0xd9e9c8){const _0x4e0f2d=_0xd9e9c8['_path'];let _0x3f3618=null;_0x316088['syncPointTree_']['foreachOnPath'](_0x4e0f2d,(_0xdee393,_0x51f89d)=>{const _0x1068a3=F(_0xdee393,_0x4e0f2d);_0x3f3618=_0x3f3618||Ie(_0x51f89d,_0x1068a3);});let _0x11e811=_0x316088['syncPointTree_']['get'](_0x4e0f2d);_0x11e811?_0x3f3618=_0x3f3618||Ie(_0x11e811,w()):(_0x11e811=new zo(),_0x316088['syncPointTree_']=_0x316088['syncPointTree_']['set'](_0x4e0f2d,_0x11e811));const _0x1b45ff=_0x3f3618!=null,_0x2dc2c7=_0x1b45ff?new Te(_0x3f3618,!0x0,!0x1):null,_0x4810f1=Wn(_0x316088['pendingWriteTree_'],_0xd9e9c8['_path']),_0x5dc5ca=jo(_0x11e811,_0xd9e9c8,_0x4810f1,_0x1b45ff?_0x2dc2c7['getNode']():g['EMPTY_NODE'],_0x1b45ff);return Lu(_0x5dc5ca);}function _t(_0x3e9947,_0x18a8a2){return Xo(_0x18a8a2,_0x3e9947['syncPointTree_'],null,Wn(_0x3e9947['pendingWriteTree_'],w()));}function Xo(_0x171a92,_0x177551,_0x465ac6,_0x4d920b){if(v(_0x171a92['path']))return Zo(_0x171a92,_0x177551,_0x465ac6,_0x4d920b);{const _0x16eb83=_0x177551['get'](w());_0x465ac6==null&&_0x16eb83!=null&&(_0x465ac6=Ie(_0x16eb83,w()));let _0x3c7bc7=[];const _0x3adb34=y(_0x171a92['path']),_0x4f69fb=_0x171a92['operationForChild'](_0x3adb34),_0x521060=_0x177551['children']['get'](_0x3adb34);if(_0x521060&&_0x4f69fb){const _0x110f50=_0x465ac6?_0x465ac6['getImmediateChild'](_0x3adb34):null,_0x37d331=Vo(_0x4d920b,_0x3adb34);_0x3c7bc7=_0x3c7bc7['concat'](Xo(_0x4f69fb,_0x521060,_0x110f50,_0x37d331));}return _0x16eb83&&(_0x3c7bc7=_0x3c7bc7['concat'](os(_0x16eb83,_0x171a92,_0x4d920b,_0x465ac6))),_0x3c7bc7;}}function Zo(_0x70c1cd,_0x4e2405,_0x11f427,_0x4348eb){const _0x36b1ff=_0x4e2405['get'](w());_0x11f427==null&&_0x36b1ff!=null&&(_0x11f427=Ie(_0x36b1ff,w()));let _0x15c733=[];return _0x4e2405['children']['inorderTraversal']((_0x17d16b,_0x16b604)=>{const _0x295fb1=_0x11f427?_0x11f427['getImmediateChild'](_0x17d16b):null,_0x417974=Vo(_0x4348eb,_0x17d16b),_0x57455b=_0x70c1cd['operationForChild'](_0x17d16b);_0x57455b&&(_0x15c733=_0x15c733['concat'](Zo(_0x57455b,_0x16b604,_0x295fb1,_0x417974)));}),_0x36b1ff&&(_0x15c733=_0x15c733['concat'](os(_0x36b1ff,_0x70c1cd,_0x4348eb,_0x11f427))),_0x15c733;}function ea(_0x4c4a3f,_0x2323a8){const _0x38be97=_0x2323a8['query'],_0x45d660=Wt(_0x4c4a3f,_0x38be97);return{'hashFn':()=>(Mu(_0x2323a8)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3d43f2=>{if(_0x3d43f2==='ok')return _0x45d660?Qu(_0x4c4a3f,_0x38be97['_path'],_0x45d660):Yu(_0x4c4a3f,_0x38be97['_path']);{const _0x383ccc=Kl(_0x3d43f2,_0x38be97);return An(_0x4c4a3f,_0x38be97,null,_0x383ccc);}}};}function Wt(_0x44d83e,_0x4853ab){const _0xddfc06=Hn(_0x4853ab);return _0x44d83e['queryToTagMap']['get'](_0xddfc06);}function Hn(_0x1e8032){return _0x1e8032['_path']['toString']()+'$'+_0x1e8032['_queryIdentifier'];}function cs(_0x1fef05,_0x51a468){return _0x1fef05['tagToQueryMap']['get'](_0x51a468);}function ls(_0x596d76){const _0xf4527b=_0x596d76['indexOf']('$');return f(_0xf4527b!==-0x1&&_0xf4527b<_0x596d76['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x596d76['substr'](_0xf4527b+0x1),'path':new C(_0x596d76['substr'](0x0,_0xf4527b))};}function hs(_0x2a6129,_0x14e577,_0x452de3){const _0x3d0100=_0x2a6129['syncPointTree_']['get'](_0x14e577);f(_0x3d0100,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x37f050=Wn(_0x2a6129['pendingWriteTree_'],_0x14e577);return os(_0x3d0100,_0x452de3,_0x37f050,null);}function Zu(_0xb2057){return _0xb2057['fold']((_0x50014e,_0x48a24c,_0x26755e)=>{if(_0x48a24c&&Se(_0x48a24c))return[Bn(_0x48a24c)];{let _0x144911=[];return _0x48a24c&&(_0x144911=Ko(_0x48a24c)),x(_0x26755e,(_0x463f21,_0x4f0f17)=>{_0x144911=_0x144911['concat'](_0x4f0f17);}),_0x144911;}});}function kt(_0x53d980){return _0x53d980['_queryParams']['loadsAllData']()&&!_0x53d980['_queryParams']['isDefault']()?new(qu())(_0x53d980['_repo'],_0x53d980['_path']):_0x53d980;}function ed(_0x28a03e,_0x156ebd){for(let _0x4fa1ce=0x0;_0x4fa1ce<_0x156ebd['length'];++_0x4fa1ce){const _0x3e47af=_0x156ebd[_0x4fa1ce];if(!_0x3e47af['_queryParams']['loadsAllData']()){const _0x48298e=Hn(_0x3e47af),_0x403884=_0x28a03e['queryToTagMap']['get'](_0x48298e);_0x28a03e['queryToTagMap']['delete'](_0x48298e),_0x28a03e['tagToQueryMap']['delete'](_0x403884);}}}function td(){return zu++;}function nd(_0x32cc1c,_0x428cb4,_0x34e303){const _0x19fd8f=_0x428cb4['_path'],_0x356063=Wt(_0x32cc1c,_0x428cb4),_0x387470=ea(_0x32cc1c,_0x34e303),_0x4763c5=_0x32cc1c['listenProvider_']['startListening'](kt(_0x428cb4),_0x356063,_0x387470['hashFn'],_0x387470['onComplete']),_0x472e64=_0x32cc1c['syncPointTree_']['subtree'](_0x19fd8f);if(_0x356063)f(!Se(_0x472e64['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xe8bec=_0x472e64['fold']((_0x2a739c,_0x593047,_0x4bfbb4)=>{if(!v(_0x2a739c)&&_0x593047&&Se(_0x593047))return[Bn(_0x593047)['query']];{let _0xbc0cef=[];return _0x593047&&(_0xbc0cef=_0xbc0cef['concat'](Ko(_0x593047)['map'](_0x81a8=>_0x81a8['query']))),x(_0x4bfbb4,(_0x21b7a5,_0x44ee29)=>{_0xbc0cef=_0xbc0cef['concat'](_0x44ee29);}),_0xbc0cef;}});for(let _0x3f78d7=0x0;_0x3f78d7<_0xe8bec['length'];++_0x3f78d7){const _0x7dfd=_0xe8bec[_0x3f78d7];_0x32cc1c['listenProvider_']['stopListening'](kt(_0x7dfd),Wt(_0x32cc1c,_0x7dfd));}}return _0x4763c5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0xc919d1){this['node_']=_0xc919d1;}['getImmediateChild'](_0xc9efe4){const _0x52c874=this['node_']['getImmediateChild'](_0xc9efe4);return new us(_0x52c874);}['node'](){return this['node_'];}}class ds{constructor(_0x56fbc5,_0x28e806){this['syncTree_']=_0x56fbc5,this['path_']=_0x28e806;}['getImmediateChild'](_0x288012){const _0x139009=k(this['path_'],_0x288012);return new ds(this['syncTree_'],_0x139009);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x202364){return _0x202364=_0x202364||{},_0x202364['timestamp']=_0x202364['timestamp']||new Date()['getTime'](),_0x202364;},_r=function(_0x4ea166,_0x5dc23f,_0x32f6bf){if(!_0x4ea166||typeof _0x4ea166!='object')return _0x4ea166;if(f('.sv'in _0x4ea166,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4ea166['.sv']=='string')return sd(_0x4ea166['.sv'],_0x5dc23f,_0x32f6bf);if(typeof _0x4ea166['.sv']=='object')return rd(_0x4ea166['.sv'],_0x5dc23f);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4ea166,null,0x2));},sd=function(_0x2f024d,_0x29f12e,_0x3f4da0){switch(_0x2f024d){case'timestamp':return _0x3f4da0['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2f024d);}},rd=function(_0x730c9b,_0x1cab14,_0xb06b13){_0x730c9b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x730c9b,null,0x2));const _0x239ac8=_0x730c9b['increment'];typeof _0x239ac8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x239ac8);const _0x5eff9d=_0x1cab14['node']();if(f(_0x5eff9d!==null&&typeof _0x5eff9d<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5eff9d['isLeafNode']())return _0x239ac8;const _0x40cc28=_0x5eff9d['getValue']();return typeof _0x40cc28!='number'?_0x239ac8:_0x40cc28+_0x239ac8;},ta=function(_0x2c8b85,_0x581e80,_0x278b78,_0x4ff389){return ps(_0x581e80,new ds(_0x278b78,_0x2c8b85),_0x4ff389);},fs=function(_0x1859df,_0x1aba5,_0x112c53){return ps(_0x1859df,new us(_0x1aba5),_0x112c53);};function ps(_0x550f61,_0x3d9351,_0xa97a5f){const _0x3f431e=_0x550f61['getPriority']()['val'](),_0x86d2b6=_r(_0x3f431e,_0x3d9351['getImmediateChild']('.priority'),_0xa97a5f);let _0x52b8ef;if(_0x550f61['isLeafNode']()){const _0x22b579=_0x550f61,_0x32d606=_r(_0x22b579['getValue'](),_0x3d9351,_0xa97a5f);return _0x32d606!==_0x22b579['getValue']()||_0x86d2b6!==_0x22b579['getPriority']()['val']()?new D(_0x32d606,A(_0x86d2b6)):_0x550f61;}else{const _0x3b1234=_0x550f61;return _0x52b8ef=_0x3b1234,_0x86d2b6!==_0x3b1234['getPriority']()['val']()&&(_0x52b8ef=_0x52b8ef['updatePriority'](new D(_0x86d2b6))),_0x3b1234['forEachChild'](R,(_0xb24863,_0x5356ad)=>{const _0x250598=ps(_0x5356ad,_0x3d9351['getImmediateChild'](_0xb24863),_0xa97a5f);_0x250598!==_0x5356ad&&(_0x52b8ef=_0x52b8ef['updateImmediateChild'](_0xb24863,_0x250598));}),_0x52b8ef;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x158c5d='',_0xea2173=null,_0x5c4a11={'children':{},'childCount':0x0}){this['name']=_0x158c5d,this['parent']=_0xea2173,this['node']=_0x5c4a11;}}function $n(_0xc18afa,_0x543221){let _0x25e1cc=_0x543221 instanceof C?_0x543221:new C(_0x543221),_0x305abb=_0xc18afa,_0x358a2b=y(_0x25e1cc);for(;_0x358a2b!==null;){const _0x5af62a=Le(_0x305abb['node']['children'],_0x358a2b)||{'children':{},'childCount':0x0};_0x305abb=new _s(_0x358a2b,_0x305abb,_0x5af62a),_0x25e1cc=S(_0x25e1cc),_0x358a2b=y(_0x25e1cc);}return _0x305abb;}function je(_0x4042d4){return _0x4042d4['node']['value'];}function gs(_0x39b2fa,_0x5bcffa){_0x39b2fa['node']['value']=_0x5bcffa,Oi(_0x39b2fa);}function na(_0x2a25d4){return _0x2a25d4['node']['childCount']>0x0;}function od(_0x5d86d5){return je(_0x5d86d5)===void 0x0&&!na(_0x5d86d5);}function Gn(_0x5bfff9,_0x1940aa){x(_0x5bfff9['node']['children'],(_0x361438,_0x16fbb6)=>{_0x1940aa(new _s(_0x361438,_0x5bfff9,_0x16fbb6));});}function ia(_0x175eb0,_0x23562e,_0x7f790e,_0x4ac619){_0x7f790e&&_0x23562e(_0x175eb0),Gn(_0x175eb0,_0x871f71=>{ia(_0x871f71,_0x23562e,!0x0);});}function ad(_0x2c4a23,_0x58576c,_0x54a0fc){let _0x288655=_0x2c4a23['parent'];for(;_0x288655!==null;){if(_0x58576c(_0x288655))return!0x0;_0x288655=_0x288655['parent'];}return!0x1;}function Qt(_0x44264a){return new C(_0x44264a['parent']===null?_0x44264a['name']:Qt(_0x44264a['parent'])+'/'+_0x44264a['name']);}function Oi(_0x5b4dc9){_0x5b4dc9['parent']!==null&&cd(_0x5b4dc9['parent'],_0x5b4dc9['name'],_0x5b4dc9);}function cd(_0x231d86,_0x73e8c5,_0xfe3692){const _0x16cc8e=od(_0xfe3692),_0x4fd214=Q(_0x231d86['node']['children'],_0x73e8c5);_0x16cc8e&&_0x4fd214?(delete _0x231d86['node']['children'][_0x73e8c5],_0x231d86['node']['childCount']--,Oi(_0x231d86)):!_0x16cc8e&&!_0x4fd214&&(_0x231d86['node']['children'][_0x73e8c5]=_0xfe3692['node'],_0x231d86['node']['childCount']++,Oi(_0x231d86));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x31f567){return typeof _0x31f567=='string'&&_0x31f567['length']!==0x0&&!ld['test'](_0x31f567);},sa=function(_0x40d97f){return typeof _0x40d97f=='string'&&_0x40d97f['length']!==0x0&&!hd['test'](_0x40d97f);},ud=function(_0x521bae){return _0x521bae&&(_0x521bae=_0x521bae['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x521bae);},Bt=function(_0x30c7d1){return _0x30c7d1===null||typeof _0x30c7d1=='string'||typeof _0x30c7d1=='number'&&!xn(_0x30c7d1)||_0x30c7d1&&typeof _0x30c7d1=='object'&&Q(_0x30c7d1,'.sv');},He=function(_0x2c5fd2,_0x445e28,_0x4e1ca9,_0x59a6fd){_0x59a6fd&&_0x445e28===void 0x0||Jt(it(_0x2c5fd2,'value'),_0x445e28,_0x4e1ca9);},Jt=function(_0x1ba4f7,_0x59d88f,_0x36dbf2){const _0x3e8394=_0x36dbf2 instanceof C?new Ah(_0x36dbf2,_0x1ba4f7):_0x36dbf2;if(_0x59d88f===void 0x0)throw new Error(_0x1ba4f7+'contains\x20undefined\x20'+Oe(_0x3e8394));if(typeof _0x59d88f=='function')throw new Error(_0x1ba4f7+'contains\x20a\x20function\x20'+Oe(_0x3e8394)+'\x20with\x20contents\x20=\x20'+_0x59d88f['toString']());if(xn(_0x59d88f))throw new Error(_0x1ba4f7+'contains\x20'+_0x59d88f['toString']()+'\x20'+Oe(_0x3e8394));if(typeof _0x59d88f=='string'&&_0x59d88f['length']>ui/0x3&&Ln(_0x59d88f)>ui)throw new Error(_0x1ba4f7+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x3e8394)+'\x20(\x27'+_0x59d88f['substring'](0x0,0x32)+'...\x27)');if(_0x59d88f&&typeof _0x59d88f=='object'){let _0x1353ca=!0x1,_0x576722=!0x1;if(x(_0x59d88f,(_0x204477,_0x3cd2ce)=>{if(_0x204477==='.value')_0x1353ca=!0x0;else{if(_0x204477!=='.priority'&&_0x204477!=='.sv'&&(_0x576722=!0x0,!ms(_0x204477)))throw new Error(_0x1ba4f7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x204477+')\x20'+Oe(_0x3e8394)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3e8394,_0x204477),Jt(_0x1ba4f7,_0x3cd2ce,_0x3e8394),Ph(_0x3e8394);}),_0x1353ca&&_0x576722)throw new Error(_0x1ba4f7+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x3e8394)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x42e13e,_0x5d69b6){let _0x2cd505,_0x354b88;for(_0x2cd505=0x0;_0x2cd505<_0x5d69b6['length'];_0x2cd505++){_0x354b88=_0x5d69b6[_0x2cd505];const _0x3dd0ff=Mt(_0x354b88);for(let _0x1221d3=0x0;_0x1221d3<_0x3dd0ff['length'];_0x1221d3++)if(!(_0x3dd0ff[_0x1221d3]==='.priority'&&_0x1221d3===_0x3dd0ff['length']-0x1)){if(!ms(_0x3dd0ff[_0x1221d3]))throw new Error(_0x42e13e+'contains\x20an\x20invalid\x20key\x20('+_0x3dd0ff[_0x1221d3]+')\x20in\x20path\x20'+_0x354b88['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5d69b6['sort'](Rh);let _0x59ef25=null;for(_0x2cd505=0x0;_0x2cd505<_0x5d69b6['length'];_0x2cd505++){if(_0x354b88=_0x5d69b6[_0x2cd505],_0x59ef25!==null&&G(_0x59ef25,_0x354b88))throw new Error(_0x42e13e+'contains\x20a\x20path\x20'+_0x59ef25['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x354b88['toString']());_0x59ef25=_0x354b88;}},ra=function(_0x18b41d,_0x40d46d,_0x28ffd5,_0x298d88){const _0x5553e4=it(_0x18b41d,'values');if(!(_0x40d46d&&typeof _0x40d46d=='object')||Array['isArray'](_0x40d46d))throw new Error(_0x5553e4+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xb1f3c9=[];x(_0x40d46d,(_0x4ab30a,_0x3d8554)=>{const _0x3bde76=new C(_0x4ab30a);if(Jt(_0x5553e4,_0x3d8554,k(_0x28ffd5,_0x3bde76)),ji(_0x3bde76)==='.priority'&&!Bt(_0x3d8554))throw new Error(_0x5553e4+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3bde76['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xb1f3c9['push'](_0x3bde76);}),dd(_0x5553e4,_0xb1f3c9);},fd=function(_0x1faf84,_0x3bcec4,_0x37a1e1){if(xn(_0x3bcec4))throw new Error(it(_0x1faf84,'priority')+'is\x20'+_0x3bcec4['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3bcec4))throw new Error(it(_0x1faf84,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x36ac67,_0x549ace,_0x4d811f,_0x371ebb){if(!sa(_0x4d811f))throw new Error(it(_0x36ac67,_0x549ace)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4d811f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4634e0,_0x421044,_0x321000,_0x2b863b){_0x321000&&(_0x321000=_0x321000['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4634e0,_0x421044,_0x321000);},Me=function(_0x38200e,_0x150a6c){if(y(_0x150a6c)==='.info')throw new Error(_0x38200e+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x417705,_0x4ce4ae){const _0x1a935d=_0x4ce4ae['path']['toString']();if(typeof _0x4ce4ae['repoInfo']['host']!='string'||_0x4ce4ae['repoInfo']['host']['length']===0x0||!ms(_0x4ce4ae['repoInfo']['namespace'])&&_0x4ce4ae['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1a935d['length']!==0x0&&!ud(_0x1a935d))throw new Error(it(_0x417705,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x56a16a,_0x451a7b){let _0xc8de8d=null;for(let _0x18052c=0x0;_0x18052c<_0x451a7b['length'];_0x18052c++){const _0x545b68=_0x451a7b[_0x18052c],_0x26324b=_0x545b68['getPath']();_0xc8de8d!==null&&!Ki(_0x26324b,_0xc8de8d['path'])&&(_0x56a16a['eventLists_']['push'](_0xc8de8d),_0xc8de8d=null),_0xc8de8d===null&&(_0xc8de8d={'events':[],'path':_0x26324b}),_0xc8de8d['events']['push'](_0x545b68);}_0xc8de8d&&_0x56a16a['eventLists_']['push'](_0xc8de8d);}function oa(_0x54ce73,_0x18d064,_0x2a5f27){qn(_0x54ce73,_0x2a5f27),aa(_0x54ce73,_0x2897c0=>Ki(_0x2897c0,_0x18d064));}function V(_0x1d7157,_0x40c5d3,_0x332be0){qn(_0x1d7157,_0x332be0),aa(_0x1d7157,_0x4349ad=>G(_0x4349ad,_0x40c5d3)||G(_0x40c5d3,_0x4349ad));}function aa(_0x429e07,_0x5ca79e){_0x429e07['recursionDepth_']++;let _0x36e10f=!0x0;for(let _0x4ed039=0x0;_0x4ed039<_0x429e07['eventLists_']['length'];_0x4ed039++){const _0x40b9cd=_0x429e07['eventLists_'][_0x4ed039];if(_0x40b9cd){const _0x11c102=_0x40b9cd['path'];_0x5ca79e(_0x11c102)?(md(_0x429e07['eventLists_'][_0x4ed039]),_0x429e07['eventLists_'][_0x4ed039]=null):_0x36e10f=!0x1;}}_0x36e10f&&(_0x429e07['eventLists_']=[]),_0x429e07['recursionDepth_']--;}function md(_0x474143){for(let _0x181110=0x0;_0x181110<_0x474143['events']['length'];_0x181110++){const _0x3e67b5=_0x474143['events'][_0x181110];if(_0x3e67b5!==null){_0x474143['events'][_0x181110]=null;const _0x28dca4=_0x3e67b5['getEventRunner']();St&&L('event:\x20'+_0x3e67b5['toString']()),ft(_0x28dca4);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x48ad69,_0xb9693b,_0x4949aa,_0x33b3b4){this['repoInfo_']=_0x48ad69,this['forceRestClient_']=_0xb9693b,this['authTokenProvider_']=_0x4949aa,this['appCheckProvider_']=_0x33b3b4,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x360bd9,_0x52b499,_0x490cff){if(_0x360bd9['stats_']=qi(_0x360bd9['repoInfo_']),_0x360bd9['forceRestClient_']||Xl())_0x360bd9['server_']=new vn(_0x360bd9['repoInfo_'],(_0x48782f,_0x1e1e1a,_0x48abfe,_0x53f98b)=>{gr(_0x360bd9,_0x48782f,_0x1e1e1a,_0x48abfe,_0x53f98b);},_0x360bd9['authTokenProvider_'],_0x360bd9['appCheckProvider_']),setTimeout(()=>mr(_0x360bd9,!0x0),0x0);else{if(typeof _0x490cff<'u'&&_0x490cff!==null){if(typeof _0x490cff!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x490cff);}catch(_0x13e90a){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x13e90a);}}_0x360bd9['persistentConnection_']=new se(_0x360bd9['repoInfo_'],_0x52b499,(_0x291d0e,_0x5d2d8c,_0x25003d,_0x2558f9)=>{gr(_0x360bd9,_0x291d0e,_0x5d2d8c,_0x25003d,_0x2558f9);},_0x2358b0=>{mr(_0x360bd9,_0x2358b0);},_0x50db49=>{Id(_0x360bd9,_0x50db49);},_0x360bd9['authTokenProvider_'],_0x360bd9['appCheckProvider_'],_0x490cff),_0x360bd9['server_']=_0x360bd9['persistentConnection_'];}_0x360bd9['authTokenProvider_']['addTokenChangeListener'](_0x41ed21=>{_0x360bd9['server_']['refreshAuthToken'](_0x41ed21);}),_0x360bd9['appCheckProvider_']['addTokenChangeListener'](_0x46bd03=>{_0x360bd9['server_']['refreshAppCheckToken'](_0x46bd03['token']);}),_0x360bd9['statsReporter_']=ih(_0x360bd9['repoInfo_'],()=>new iu(_0x360bd9['stats_'],_0x360bd9['server_'])),_0x360bd9['infoData_']=new Xh(),_0x360bd9['infoSyncTree_']=new pr({'startListening':(_0x3d031b,_0x43512c,_0xce8fec,_0x435632)=>{let _0x49ceca=[];const _0x1158f6=_0x360bd9['infoData_']['getNode'](_0x3d031b['_path']);return _0x1158f6['isEmpty']()||(_0x49ceca=Yt(_0x360bd9['infoSyncTree_'],_0x3d031b['_path'],_0x1158f6),setTimeout(()=>{_0x435632('ok');},0x0)),_0x49ceca;},'stopListening':()=>{}}),vs(_0x360bd9,'connected',!0x1),_0x360bd9['serverSyncTree_']=new pr({'startListening':(_0x350e12,_0x4a6008,_0x5ac11b,_0x3d2d52)=>(_0x360bd9['server_']['listen'](_0x350e12,_0x5ac11b,_0x4a6008,(_0xf415d9,_0x50c415)=>{const _0x2bbb56=_0x3d2d52(_0xf415d9,_0x50c415);V(_0x360bd9['eventQueue_'],_0x350e12['_path'],_0x2bbb56);}),[]),'stopListening':(_0x468897,_0xf90409)=>{_0x360bd9['server_']['unlisten'](_0x468897,_0xf90409);}});}function la(_0x535023){const _0xc1e777=_0x535023['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xc1e777;}function Xt(_0x2479f0){return id({'timestamp':la(_0x2479f0)});}function gr(_0x3d27c6,_0x2f8357,_0x14b4ac,_0x475905,_0x2a406d){_0x3d27c6['dataUpdateCount']++;const _0x2aca08=new C(_0x2f8357);_0x14b4ac=_0x3d27c6['interceptServerDataCallback_']?_0x3d27c6['interceptServerDataCallback_'](_0x2f8357,_0x14b4ac):_0x14b4ac;let _0x2b1868=[];if(_0x2a406d){if(_0x475905){const _0x1dfd50=_n(_0x14b4ac,_0x2cbd48=>A(_0x2cbd48));_0x2b1868=Ju(_0x3d27c6['serverSyncTree_'],_0x2aca08,_0x1dfd50,_0x2a406d);}else{const _0x5a90a0=A(_0x14b4ac);_0x2b1868=Jo(_0x3d27c6['serverSyncTree_'],_0x2aca08,_0x5a90a0,_0x2a406d);}}else{if(_0x475905){const _0x2e6871=_n(_0x14b4ac,_0x58be91=>A(_0x58be91));_0x2b1868=Ku(_0x3d27c6['serverSyncTree_'],_0x2aca08,_0x2e6871);}else{const _0x11e0c2=A(_0x14b4ac);_0x2b1868=Yt(_0x3d27c6['serverSyncTree_'],_0x2aca08,_0x11e0c2);}}let _0x12f3c2=_0x2aca08;_0x2b1868['length']>0x0&&(_0x12f3c2=ct(_0x3d27c6,_0x2aca08)),V(_0x3d27c6['eventQueue_'],_0x12f3c2,_0x2b1868);}function mr(_0x3b2a85,_0x28fc30){vs(_0x3b2a85,'connected',_0x28fc30),_0x28fc30===!0x1&&Sd(_0x3b2a85);}function Id(_0x19fa69,_0x96f99c){x(_0x96f99c,(_0x1ab1b5,_0x57574c)=>{vs(_0x19fa69,_0x1ab1b5,_0x57574c);});}function vs(_0x398f52,_0x314e1e,_0x593131){const _0x384acc=new C('/.info/'+_0x314e1e),_0x2485f1=A(_0x593131);_0x398f52['infoData_']['updateSnapshot'](_0x384acc,_0x2485f1);const _0x42281b=Yt(_0x398f52['infoSyncTree_'],_0x384acc,_0x2485f1);V(_0x398f52['eventQueue_'],_0x384acc,_0x42281b);}function zn(_0x39d4ef){return _0x39d4ef['nextWriteId_']++;}function wd(_0x32a206,_0x1ba1dd,_0x4bd2e3){const _0x2b161b=Xu(_0x32a206['serverSyncTree_'],_0x1ba1dd);return _0x2b161b!=null?Promise['resolve'](_0x2b161b):_0x32a206['server_']['get'](_0x1ba1dd)['then'](_0x3db7d6=>{const _0x143e61=A(_0x3db7d6)['withIndex'](_0x1ba1dd['_queryParams']['getIndex']());Ni(_0x32a206['serverSyncTree_'],_0x1ba1dd,_0x4bd2e3,!0x0);let _0xbd4cc8;if(_0x1ba1dd['_queryParams']['loadsAllData']())_0xbd4cc8=Yt(_0x32a206['serverSyncTree_'],_0x1ba1dd['_path'],_0x143e61);else{const _0x58ae4f=Wt(_0x32a206['serverSyncTree_'],_0x1ba1dd);_0xbd4cc8=Jo(_0x32a206['serverSyncTree_'],_0x1ba1dd['_path'],_0x143e61,_0x58ae4f);}return V(_0x32a206['eventQueue_'],_0x1ba1dd['_path'],_0xbd4cc8),An(_0x32a206['serverSyncTree_'],_0x1ba1dd,_0x4bd2e3,null,!0x0),_0x143e61;},_0x7bff73=>(gt(_0x32a206,'get\x20for\x20query\x20'+O(_0x1ba1dd)+'\x20failed:\x20'+_0x7bff73),Promise['reject'](new Error(_0x7bff73))));}function Cd(_0x17b054,_0x3cb6d0,_0x367dbe,_0x5d0762,_0x2b22fb){gt(_0x17b054,'set',{'path':_0x3cb6d0['toString'](),'value':_0x367dbe,'priority':_0x5d0762});const _0x31d681=Xt(_0x17b054),_0x2d503b=A(_0x367dbe,_0x5d0762),_0x34f176=Vn(_0x17b054['serverSyncTree_'],_0x3cb6d0),_0x37fbf6=fs(_0x2d503b,_0x34f176,_0x31d681),_0x4a9ea8=zn(_0x17b054),_0x48ce1e=as(_0x17b054['serverSyncTree_'],_0x3cb6d0,_0x37fbf6,_0x4a9ea8,!0x0);qn(_0x17b054['eventQueue_'],_0x48ce1e),_0x17b054['server_']['put'](_0x3cb6d0['toString'](),_0x2d503b['val'](!0x0),(_0x187dab,_0x5d766a)=>{const _0x1f5b9f=_0x187dab==='ok';_0x1f5b9f||U('set\x20at\x20'+_0x3cb6d0+'\x20failed:\x20'+_0x187dab);const _0x5427d1=_e(_0x17b054['serverSyncTree_'],_0x4a9ea8,!_0x1f5b9f);V(_0x17b054['eventQueue_'],_0x3cb6d0,_0x5427d1),be(_0x17b054,_0x2b22fb,_0x187dab,_0x5d766a);});const _0x905167=Is(_0x17b054,_0x3cb6d0);ct(_0x17b054,_0x905167),V(_0x17b054['eventQueue_'],_0x905167,[]);}function Td(_0x9abaae,_0x1ce489,_0x10ea13,_0x3b073d){gt(_0x9abaae,'update',{'path':_0x1ce489['toString'](),'value':_0x10ea13});let _0x4efcd5=!0x0;const _0x855dd7=Xt(_0x9abaae),_0x10ca51={};if(x(_0x10ea13,(_0x463528,_0x5c4608)=>{_0x4efcd5=!0x1,_0x10ca51[_0x463528]=ta(k(_0x1ce489,_0x463528),A(_0x5c4608),_0x9abaae['serverSyncTree_'],_0x855dd7);}),_0x4efcd5)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x9abaae,_0x3b073d,'ok',void 0x0);else{const _0x441ebf=zn(_0x9abaae),_0x36e036=ju(_0x9abaae['serverSyncTree_'],_0x1ce489,_0x10ca51,_0x441ebf);qn(_0x9abaae['eventQueue_'],_0x36e036),_0x9abaae['server_']['merge'](_0x1ce489['toString'](),_0x10ea13,(_0x2f8c85,_0x51d7c6)=>{const _0x497b7=_0x2f8c85==='ok';_0x497b7||U('update\x20at\x20'+_0x1ce489+'\x20failed:\x20'+_0x2f8c85);const _0x480012=_e(_0x9abaae['serverSyncTree_'],_0x441ebf,!_0x497b7),_0x3cdc39=_0x480012['length']>0x0?ct(_0x9abaae,_0x1ce489):_0x1ce489;V(_0x9abaae['eventQueue_'],_0x3cdc39,_0x480012),be(_0x9abaae,_0x3b073d,_0x2f8c85,_0x51d7c6);}),x(_0x10ea13,_0xfcf15e=>{const _0x17533f=Is(_0x9abaae,k(_0x1ce489,_0xfcf15e));ct(_0x9abaae,_0x17533f);}),V(_0x9abaae['eventQueue_'],_0x1ce489,[]);}}function Sd(_0x2d5b88){gt(_0x2d5b88,'onDisconnectEvents');const _0xc0e4b=Xt(_0x2d5b88),_0x200c6f=En();Si(_0x2d5b88['onDisconnect_'],w(),(_0x1de4cf,_0x31e4eb)=>{const _0x308f70=ta(_0x1de4cf,_0x31e4eb,_0x2d5b88['serverSyncTree_'],_0xc0e4b);pt(_0x200c6f,_0x1de4cf,_0x308f70);});let _0x25f034=[];Si(_0x200c6f,w(),(_0x315178,_0x1701d4)=>{_0x25f034=_0x25f034['concat'](Yt(_0x2d5b88['serverSyncTree_'],_0x315178,_0x1701d4));const _0x18e8c2=Is(_0x2d5b88,_0x315178);ct(_0x2d5b88,_0x18e8c2);}),_0x2d5b88['onDisconnect_']=En(),V(_0x2d5b88['eventQueue_'],w(),_0x25f034);}function bd(_0x419b7d,_0x15334c,_0x2aa8ca){_0x419b7d['server_']['onDisconnectCancel'](_0x15334c['toString'](),(_0x411778,_0x338b85)=>{_0x411778==='ok'&&Ti(_0x419b7d['onDisconnect_'],_0x15334c),be(_0x419b7d,_0x2aa8ca,_0x411778,_0x338b85);});}function yr(_0x2850e5,_0x59ab71,_0x48f54a,_0x40b4bd){const _0x5d6ba5=A(_0x48f54a);_0x2850e5['server_']['onDisconnectPut'](_0x59ab71['toString'](),_0x5d6ba5['val'](!0x0),(_0x262ec5,_0x3ba255)=>{_0x262ec5==='ok'&&pt(_0x2850e5['onDisconnect_'],_0x59ab71,_0x5d6ba5),be(_0x2850e5,_0x40b4bd,_0x262ec5,_0x3ba255);});}function Rd(_0x414975,_0xbb0c88,_0x4bb5a9,_0x2e6e0f,_0x20123c){const _0xd2a6b0=A(_0x4bb5a9,_0x2e6e0f);_0x414975['server_']['onDisconnectPut'](_0xbb0c88['toString'](),_0xd2a6b0['val'](!0x0),(_0x2045d8,_0x2ec512)=>{_0x2045d8==='ok'&&pt(_0x414975['onDisconnect_'],_0xbb0c88,_0xd2a6b0),be(_0x414975,_0x20123c,_0x2045d8,_0x2ec512);});}function Ad(_0x36b34d,_0x564765,_0x25110f,_0x2baf33){if(pn(_0x25110f)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x36b34d,_0x2baf33,'ok',void 0x0);return;}_0x36b34d['server_']['onDisconnectMerge'](_0x564765['toString'](),_0x25110f,(_0x156482,_0x33a852)=>{_0x156482==='ok'&&x(_0x25110f,(_0x3fa8e9,_0x5fd962)=>{const _0x35207f=A(_0x5fd962);pt(_0x36b34d['onDisconnect_'],k(_0x564765,_0x3fa8e9),_0x35207f);}),be(_0x36b34d,_0x2baf33,_0x156482,_0x33a852);});}function kd(_0x4c6a21,_0x28c48e,_0x5f0b16){let _0x2de415;y(_0x28c48e['_path'])==='.info'?_0x2de415=Ni(_0x4c6a21['infoSyncTree_'],_0x28c48e,_0x5f0b16):_0x2de415=Ni(_0x4c6a21['serverSyncTree_'],_0x28c48e,_0x5f0b16),oa(_0x4c6a21['eventQueue_'],_0x28c48e['_path'],_0x2de415);}function Pd(_0x4f27da,_0x47e8fe,_0x506355){let _0x3e229b;y(_0x47e8fe['_path'])==='.info'?_0x3e229b=An(_0x4f27da['infoSyncTree_'],_0x47e8fe,_0x506355):_0x3e229b=An(_0x4f27da['serverSyncTree_'],_0x47e8fe,_0x506355),oa(_0x4f27da['eventQueue_'],_0x47e8fe['_path'],_0x3e229b);}function ha(_0x236180){_0x236180['persistentConnection_']&&_0x236180['persistentConnection_']['interrupt'](ca);}function Nd(_0x143149){_0x143149['persistentConnection_']&&_0x143149['persistentConnection_']['resume'](ca);}function gt(_0x207320,..._0x13bc0b){let _0x138e5f='';_0x207320['persistentConnection_']&&(_0x138e5f=_0x207320['persistentConnection_']['id']+':'),L(_0x138e5f,..._0x13bc0b);}function be(_0x1400c6,_0x3861e2,_0x8f0eea,_0x36d6e7){_0x3861e2&&ft(()=>{if(_0x8f0eea==='ok')_0x3861e2(null);else{const _0x4b1860=(_0x8f0eea||'error')['toUpperCase']();let _0x388d0d=_0x4b1860;_0x36d6e7&&(_0x388d0d+=':\x20'+_0x36d6e7);const _0x29cee5=new Error(_0x388d0d);_0x29cee5['code']=_0x4b1860,_0x3861e2(_0x29cee5);}});}function Od(_0x3cc886,_0x44777e,_0x19ea39,_0x2147a1,_0x374552,_0x4aa5e5){gt(_0x3cc886,'transaction\x20on\x20'+_0x44777e);const _0x3c46d8={'path':_0x44777e,'update':_0x19ea39,'onComplete':_0x2147a1,'status':null,'order':so(),'applyLocally':_0x4aa5e5,'retryCount':0x0,'unwatcher':_0x374552,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x146f37=Es(_0x3cc886,_0x44777e,void 0x0);_0x3c46d8['currentInputSnapshot']=_0x146f37;const _0x128127=_0x3c46d8['update'](_0x146f37['val']());if(_0x128127===void 0x0)_0x3c46d8['unwatcher'](),_0x3c46d8['currentOutputSnapshotRaw']=null,_0x3c46d8['currentOutputSnapshotResolved']=null,_0x3c46d8['onComplete']&&_0x3c46d8['onComplete'](null,!0x1,_0x3c46d8['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x128127,_0x3c46d8['path']),_0x3c46d8['status']=0x0;const _0x23b81e=$n(_0x3cc886['transactionQueueTree_'],_0x44777e),_0x1124c7=je(_0x23b81e)||[];_0x1124c7['push'](_0x3c46d8),gs(_0x23b81e,_0x1124c7);let _0x2ebff7;typeof _0x128127=='object'&&_0x128127!==null&&Q(_0x128127,'.priority')?(_0x2ebff7=Le(_0x128127,'.priority'),f(Bt(_0x2ebff7),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x2ebff7=(Vn(_0x3cc886['serverSyncTree_'],_0x44777e)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x85ee1b=Xt(_0x3cc886),_0x4cebaf=A(_0x128127,_0x2ebff7),_0x4a20b7=fs(_0x4cebaf,_0x146f37,_0x85ee1b);_0x3c46d8['currentOutputSnapshotRaw']=_0x4cebaf,_0x3c46d8['currentOutputSnapshotResolved']=_0x4a20b7,_0x3c46d8['currentWriteId']=zn(_0x3cc886);const _0x2ef3c3=as(_0x3cc886['serverSyncTree_'],_0x44777e,_0x4a20b7,_0x3c46d8['currentWriteId'],_0x3c46d8['applyLocally']);V(_0x3cc886['eventQueue_'],_0x44777e,_0x2ef3c3),jn(_0x3cc886,_0x3cc886['transactionQueueTree_']);}}function Es(_0x3cb212,_0x2ea57d,_0xb6d105){return Vn(_0x3cb212['serverSyncTree_'],_0x2ea57d,_0xb6d105)||g['EMPTY_NODE'];}function jn(_0x10cd35,_0x16d6bd=_0x10cd35['transactionQueueTree_']){if(_0x16d6bd||Kn(_0x10cd35,_0x16d6bd),je(_0x16d6bd)){const _0x5a8df5=da(_0x10cd35,_0x16d6bd);f(_0x5a8df5['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5a8df5['every'](_0x513d40=>_0x513d40['status']===0x0)&&Dd(_0x10cd35,Qt(_0x16d6bd),_0x5a8df5);}else na(_0x16d6bd)&&Gn(_0x16d6bd,_0x1c7f76=>{jn(_0x10cd35,_0x1c7f76);});}function Dd(_0x29462e,_0x2f6e87,_0x1b4070){const _0x1f20b7=_0x1b4070['map'](_0x547627=>_0x547627['currentWriteId']),_0x150218=Es(_0x29462e,_0x2f6e87,_0x1f20b7);let _0x48deff=_0x150218;const _0x5837de=_0x150218['hash']();for(let _0x5b84de=0x0;_0x5b84de<_0x1b4070['length'];_0x5b84de++){const _0x15f2bb=_0x1b4070[_0x5b84de];f(_0x15f2bb['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x15f2bb['status']=0x1,_0x15f2bb['retryCount']++;const _0x342d95=F(_0x2f6e87,_0x15f2bb['path']);_0x48deff=_0x48deff['updateChild'](_0x342d95,_0x15f2bb['currentOutputSnapshotRaw']);}const _0x143572=_0x48deff['val'](!0x0),_0x25e917=_0x2f6e87;_0x29462e['server_']['put'](_0x25e917['toString'](),_0x143572,_0x40ab9a=>{gt(_0x29462e,'transaction\x20put\x20response',{'path':_0x25e917['toString'](),'status':_0x40ab9a});let _0x448ab1=[];if(_0x40ab9a==='ok'){const _0x50cff2=[];for(let _0x180fda=0x0;_0x180fda<_0x1b4070['length'];_0x180fda++)_0x1b4070[_0x180fda]['status']=0x2,_0x448ab1=_0x448ab1['concat'](_e(_0x29462e['serverSyncTree_'],_0x1b4070[_0x180fda]['currentWriteId'])),_0x1b4070[_0x180fda]['onComplete']&&_0x50cff2['push'](()=>_0x1b4070[_0x180fda]['onComplete'](null,!0x0,_0x1b4070[_0x180fda]['currentOutputSnapshotResolved'])),_0x1b4070[_0x180fda]['unwatcher']();Kn(_0x29462e,$n(_0x29462e['transactionQueueTree_'],_0x2f6e87)),jn(_0x29462e,_0x29462e['transactionQueueTree_']),V(_0x29462e['eventQueue_'],_0x2f6e87,_0x448ab1);for(let _0x463df9=0x0;_0x463df9<_0x50cff2['length'];_0x463df9++)ft(_0x50cff2[_0x463df9]);}else{if(_0x40ab9a==='datastale'){for(let _0x505f85=0x0;_0x505f85<_0x1b4070['length'];_0x505f85++)_0x1b4070[_0x505f85]['status']===0x3?_0x1b4070[_0x505f85]['status']=0x4:_0x1b4070[_0x505f85]['status']=0x0;}else{U('transaction\x20at\x20'+_0x25e917['toString']()+'\x20failed:\x20'+_0x40ab9a);for(let _0x9c4795=0x0;_0x9c4795<_0x1b4070['length'];_0x9c4795++)_0x1b4070[_0x9c4795]['status']=0x4,_0x1b4070[_0x9c4795]['abortReason']=_0x40ab9a;}ct(_0x29462e,_0x2f6e87);}},_0x5837de);}function ct(_0x14423a,_0x115ac1){const _0x402070=ua(_0x14423a,_0x115ac1),_0x4217e1=Qt(_0x402070),_0x564da2=da(_0x14423a,_0x402070);return Md(_0x14423a,_0x564da2,_0x4217e1),_0x4217e1;}function Md(_0x547178,_0x50e352,_0x22001c){if(_0x50e352['length']===0x0)return;const _0x478945=[];let _0x58bac2=[];const _0x17203f=_0x50e352['filter'](_0x48b59a=>_0x48b59a['status']===0x0)['map'](_0x4e1c51=>_0x4e1c51['currentWriteId']);for(let _0x308cd0=0x0;_0x308cd0<_0x50e352['length'];_0x308cd0++){const _0x1ac15e=_0x50e352[_0x308cd0],_0x2f852d=F(_0x22001c,_0x1ac15e['path']);let _0xc71e5e=!0x1,_0x30c0f9;if(f(_0x2f852d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1ac15e['status']===0x4)_0xc71e5e=!0x0,_0x30c0f9=_0x1ac15e['abortReason'],_0x58bac2=_0x58bac2['concat'](_e(_0x547178['serverSyncTree_'],_0x1ac15e['currentWriteId'],!0x0));else{if(_0x1ac15e['status']===0x0){if(_0x1ac15e['retryCount']>=yd)_0xc71e5e=!0x0,_0x30c0f9='maxretry',_0x58bac2=_0x58bac2['concat'](_e(_0x547178['serverSyncTree_'],_0x1ac15e['currentWriteId'],!0x0));else{const _0x46ed14=Es(_0x547178,_0x1ac15e['path'],_0x17203f);_0x1ac15e['currentInputSnapshot']=_0x46ed14;const _0x3b203c=_0x50e352[_0x308cd0]['update'](_0x46ed14['val']());if(_0x3b203c!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3b203c,_0x1ac15e['path']);let _0x4dbab4=A(_0x3b203c);typeof _0x3b203c=='object'&&_0x3b203c!=null&&Q(_0x3b203c,'.priority')||(_0x4dbab4=_0x4dbab4['updatePriority'](_0x46ed14['getPriority']()));const _0x3ce44c=_0x1ac15e['currentWriteId'],_0x88b3eb=Xt(_0x547178),_0x17a162=fs(_0x4dbab4,_0x46ed14,_0x88b3eb);_0x1ac15e['currentOutputSnapshotRaw']=_0x4dbab4,_0x1ac15e['currentOutputSnapshotResolved']=_0x17a162,_0x1ac15e['currentWriteId']=zn(_0x547178),_0x17203f['splice'](_0x17203f['indexOf'](_0x3ce44c),0x1),_0x58bac2=_0x58bac2['concat'](as(_0x547178['serverSyncTree_'],_0x1ac15e['path'],_0x17a162,_0x1ac15e['currentWriteId'],_0x1ac15e['applyLocally'])),_0x58bac2=_0x58bac2['concat'](_e(_0x547178['serverSyncTree_'],_0x3ce44c,!0x0));}else _0xc71e5e=!0x0,_0x30c0f9='nodata',_0x58bac2=_0x58bac2['concat'](_e(_0x547178['serverSyncTree_'],_0x1ac15e['currentWriteId'],!0x0));}}}V(_0x547178['eventQueue_'],_0x22001c,_0x58bac2),_0x58bac2=[],_0xc71e5e&&(_0x50e352[_0x308cd0]['status']=0x2,function(_0x54cab6){setTimeout(_0x54cab6,Math['floor'](0x0));}(_0x50e352[_0x308cd0]['unwatcher']),_0x50e352[_0x308cd0]['onComplete']&&(_0x30c0f9==='nodata'?_0x478945['push'](()=>_0x50e352[_0x308cd0]['onComplete'](null,!0x1,_0x50e352[_0x308cd0]['currentInputSnapshot'])):_0x478945['push'](()=>_0x50e352[_0x308cd0]['onComplete'](new Error(_0x30c0f9),!0x1,null))));}Kn(_0x547178,_0x547178['transactionQueueTree_']);for(let _0x429dab=0x0;_0x429dab<_0x478945['length'];_0x429dab++)ft(_0x478945[_0x429dab]);jn(_0x547178,_0x547178['transactionQueueTree_']);}function ua(_0x48fd64,_0x4a27d8){let _0x4cdfa2,_0x7e1040=_0x48fd64['transactionQueueTree_'];for(_0x4cdfa2=y(_0x4a27d8);_0x4cdfa2!==null&&je(_0x7e1040)===void 0x0;)_0x7e1040=$n(_0x7e1040,_0x4cdfa2),_0x4a27d8=S(_0x4a27d8),_0x4cdfa2=y(_0x4a27d8);return _0x7e1040;}function da(_0x32d087,_0x418e46){const _0x1703f2=[];return fa(_0x32d087,_0x418e46,_0x1703f2),_0x1703f2['sort']((_0x3e0dd2,_0x404523)=>_0x3e0dd2['order']-_0x404523['order']),_0x1703f2;}function fa(_0x2c645c,_0x5c060d,_0x5885bf){const _0x4ab504=je(_0x5c060d);if(_0x4ab504){for(let _0x2d4709=0x0;_0x2d4709<_0x4ab504['length'];_0x2d4709++)_0x5885bf['push'](_0x4ab504[_0x2d4709]);}Gn(_0x5c060d,_0x284b3c=>{fa(_0x2c645c,_0x284b3c,_0x5885bf);});}function Kn(_0x3623b5,_0x4ff6f7){const _0x3781e1=je(_0x4ff6f7);if(_0x3781e1){let _0xec02c8=0x0;for(let _0x8cfd7e=0x0;_0x8cfd7e<_0x3781e1['length'];_0x8cfd7e++)_0x3781e1[_0x8cfd7e]['status']!==0x2&&(_0x3781e1[_0xec02c8]=_0x3781e1[_0x8cfd7e],_0xec02c8++);_0x3781e1['length']=_0xec02c8,gs(_0x4ff6f7,_0x3781e1['length']>0x0?_0x3781e1:void 0x0);}Gn(_0x4ff6f7,_0x1c5e3c=>{Kn(_0x3623b5,_0x1c5e3c);});}function Is(_0x5ab92b,_0x4b6a0c){const _0x892310=Qt(ua(_0x5ab92b,_0x4b6a0c)),_0x134d9f=$n(_0x5ab92b['transactionQueueTree_'],_0x4b6a0c);return ad(_0x134d9f,_0x1f3422=>{di(_0x5ab92b,_0x1f3422);}),di(_0x5ab92b,_0x134d9f),ia(_0x134d9f,_0x326862=>{di(_0x5ab92b,_0x326862);}),_0x892310;}function di(_0x59803d,_0x3c9b56){const _0x414849=je(_0x3c9b56);if(_0x414849){const _0x2d4d47=[];let _0x18c3ae=[],_0x5cb9e6=-0x1;for(let _0x5a0766=0x0;_0x5a0766<_0x414849['length'];_0x5a0766++)_0x414849[_0x5a0766]['status']===0x3||(_0x414849[_0x5a0766]['status']===0x1?(f(_0x5cb9e6===_0x5a0766-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5cb9e6=_0x5a0766,_0x414849[_0x5a0766]['status']=0x3,_0x414849[_0x5a0766]['abortReason']='set'):(f(_0x414849[_0x5a0766]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x414849[_0x5a0766]['unwatcher'](),_0x18c3ae=_0x18c3ae['concat'](_e(_0x59803d['serverSyncTree_'],_0x414849[_0x5a0766]['currentWriteId'],!0x0)),_0x414849[_0x5a0766]['onComplete']&&_0x2d4d47['push'](_0x414849[_0x5a0766]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5cb9e6===-0x1?gs(_0x3c9b56,void 0x0):_0x414849['length']=_0x5cb9e6+0x1,V(_0x59803d['eventQueue_'],Qt(_0x3c9b56),_0x18c3ae);for(let _0x2e1f93=0x0;_0x2e1f93<_0x2d4d47['length'];_0x2e1f93++)ft(_0x2d4d47[_0x2e1f93]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2c58d3){let _0x3e1726='';const _0x7c2032=_0x2c58d3['split']('/');for(let _0x23eccc=0x0;_0x23eccc<_0x7c2032['length'];_0x23eccc++)if(_0x7c2032[_0x23eccc]['length']>0x0){let _0x26ca46=_0x7c2032[_0x23eccc];try{_0x26ca46=decodeURIComponent(_0x26ca46['replace'](/\+/g,'\x20'));}catch{}_0x3e1726+='/'+_0x26ca46;}return _0x3e1726;}function xd(_0x37cc5a){const _0x343551={};_0x37cc5a['charAt'](0x0)==='?'&&(_0x37cc5a=_0x37cc5a['substring'](0x1));for(const _0x3b72c4 of _0x37cc5a['split']('&')){if(_0x3b72c4['length']===0x0)continue;const _0x50ba9e=_0x3b72c4['split']('=');_0x50ba9e['length']===0x2?_0x343551[decodeURIComponent(_0x50ba9e[0x0])]=decodeURIComponent(_0x50ba9e[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3b72c4+'\x27\x20in\x20query\x20\x27'+_0x37cc5a+'\x27');}return _0x343551;}const vr=function(_0x24ec03,_0x503e72){const _0x43a9cf=Fd(_0x24ec03),_0x53d2d9=_0x43a9cf['namespace'];_0x43a9cf['domain']==='firebase.com'&&ae(_0x43a9cf['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x53d2d9||_0x53d2d9==='undefined')&&_0x43a9cf['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x43a9cf['secure']||$l();const _0x4fe57f=_0x43a9cf['scheme']==='ws'||_0x43a9cf['scheme']==='wss';return{'repoInfo':new yo(_0x43a9cf['host'],_0x43a9cf['secure'],_0x53d2d9,_0x4fe57f,_0x503e72,'',_0x53d2d9!==_0x43a9cf['subdomain']),'path':new C(_0x43a9cf['pathString'])};},Fd=function(_0x2e1c14){let _0x4cb334='',_0x13bd01='',_0x43b133='',_0x19b1e2='',_0x3dbff6='',_0x5903d1=!0x0,_0x3aa4d5='https',_0x3d5d43=0x1bb;if(typeof _0x2e1c14=='string'){let _0x120a0e=_0x2e1c14['indexOf']('//');_0x120a0e>=0x0&&(_0x3aa4d5=_0x2e1c14['substring'](0x0,_0x120a0e-0x1),_0x2e1c14=_0x2e1c14['substring'](_0x120a0e+0x2));let _0x790a5c=_0x2e1c14['indexOf']('/');_0x790a5c===-0x1&&(_0x790a5c=_0x2e1c14['length']);let _0x19a199=_0x2e1c14['indexOf']('?');_0x19a199===-0x1&&(_0x19a199=_0x2e1c14['length']),_0x4cb334=_0x2e1c14['substring'](0x0,Math['min'](_0x790a5c,_0x19a199)),_0x790a5c<_0x19a199&&(_0x19b1e2=Ld(_0x2e1c14['substring'](_0x790a5c,_0x19a199)));const _0x27b205=xd(_0x2e1c14['substring'](Math['min'](_0x2e1c14['length'],_0x19a199)));_0x120a0e=_0x4cb334['indexOf'](':'),_0x120a0e>=0x0?(_0x5903d1=_0x3aa4d5==='https'||_0x3aa4d5==='wss',_0x3d5d43=parseInt(_0x4cb334['substring'](_0x120a0e+0x1),0xa)):_0x120a0e=_0x4cb334['length'];const _0x4084b2=_0x4cb334['slice'](0x0,_0x120a0e);if(_0x4084b2['toLowerCase']()==='localhost')_0x13bd01='localhost';else{if(_0x4084b2['split']('.')['length']<=0x2)_0x13bd01=_0x4084b2;else{const _0x34381b=_0x4cb334['indexOf']('.');_0x43b133=_0x4cb334['substring'](0x0,_0x34381b)['toLowerCase'](),_0x13bd01=_0x4cb334['substring'](_0x34381b+0x1),_0x3dbff6=_0x43b133;}}'ns'in _0x27b205&&(_0x3dbff6=_0x27b205['ns']);}return{'host':_0x4cb334,'port':_0x3d5d43,'domain':_0x13bd01,'subdomain':_0x43b133,'secure':_0x5903d1,'scheme':_0x3aa4d5,'pathString':_0x19b1e2,'namespace':_0x3dbff6};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x283c6c=0x0;const _0x46f629=[];return function(_0x57da21){const _0x3cff3b=_0x57da21===_0x283c6c;_0x283c6c=_0x57da21;let _0x37abc4;const _0x4be91a=new Array(0x8);for(_0x37abc4=0x7;_0x37abc4>=0x0;_0x37abc4--)_0x4be91a[_0x37abc4]=Er['charAt'](_0x57da21%0x40),_0x57da21=Math['floor'](_0x57da21/0x40);f(_0x57da21===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x51ac36=_0x4be91a['join']('');if(_0x3cff3b){for(_0x37abc4=0xb;_0x37abc4>=0x0&&_0x46f629[_0x37abc4]===0x3f;_0x37abc4--)_0x46f629[_0x37abc4]=0x0;_0x46f629[_0x37abc4]++;}else{for(_0x37abc4=0x0;_0x37abc4<0xc;_0x37abc4++)_0x46f629[_0x37abc4]=Math['floor'](Math['random']()*0x40);}for(_0x37abc4=0x0;_0x37abc4<0xc;_0x37abc4++)_0x51ac36+=Er['charAt'](_0x46f629[_0x37abc4]);return f(_0x51ac36['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x51ac36;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x3a88d9,_0x4e4f4e,_0x459f6a,_0x194be4){this['eventType']=_0x3a88d9,this['eventRegistration']=_0x4e4f4e,this['snapshot']=_0x459f6a,this['prevName']=_0x194be4;}['getPath'](){const _0x461e45=this['snapshot']['ref'];return this['eventType']==='value'?_0x461e45['_path']:_0x461e45['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2965b6,_0x527d24,_0x28d3fd){this['eventRegistration']=_0x2965b6,this['error']=_0x527d24,this['path']=_0x28d3fd;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x23412f,_0x122a64){this['snapshotCallback']=_0x23412f,this['cancelCallback']=_0x122a64;}['onValue'](_0x2adf00,_0x301d5b){this['snapshotCallback']['call'](null,_0x2adf00,_0x301d5b);}['onCancel'](_0x99486d){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x99486d);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2690af){return this['snapshotCallback']===_0x2690af['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2690af['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2690af['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x33078a,_0x5bc748){this['_repo']=_0x33078a,this['_path']=_0x5bc748;}['cancel'](){const _0x3f44c3=new H();return bd(this['_repo'],this['_path'],_0x3f44c3['wrapCallback'](()=>{})),_0x3f44c3['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x576d97=new H();return yr(this['_repo'],this['_path'],null,_0x576d97['wrapCallback'](()=>{})),_0x576d97['promise'];}['set'](_0x1b7669){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x1b7669,this['_path'],!0x1);const _0x5b53c1=new H();return yr(this['_repo'],this['_path'],_0x1b7669,_0x5b53c1['wrapCallback'](()=>{})),_0x5b53c1['promise'];}['setWithPriority'](_0x57850b,_0x4cb55d){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x57850b,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4cb55d);const _0xc082d8=new H();return Rd(this['_repo'],this['_path'],_0x57850b,_0x4cb55d,_0xc082d8['wrapCallback'](()=>{})),_0xc082d8['promise'];}['update'](_0x4eb4e3){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x4eb4e3,this['_path']);const _0x45d525=new H();return Ad(this['_repo'],this['_path'],_0x4eb4e3,_0x45d525['wrapCallback'](()=>{})),_0x45d525['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x5cd456,_0x52f760,_0x2a0085,_0x37ed8d){this['_repo']=_0x5cd456,this['_path']=_0x52f760,this['_queryParams']=_0x2a0085,this['_orderByCalled']=_0x37ed8d;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x56b198=sr(this['_queryParams']),_0x5b5055=$i(_0x56b198);return _0x5b5055==='{}'?'default':_0x5b5055;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2743dd){if(_0x2743dd=P(_0x2743dd),!(_0x2743dd instanceof Ae))return!0x1;const _0x59fb7d=this['_repo']===_0x2743dd['_repo'],_0x456bf3=Ki(this['_path'],_0x2743dd['_path']),_0x403633=this['_queryIdentifier']===_0x2743dd['_queryIdentifier'];return _0x59fb7d&&_0x456bf3&&_0x403633;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x141c9d,_0x34ea21){if(_0x141c9d['_orderByCalled']===!0x0)throw new Error(_0x34ea21+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x19fc65){let _0x31e02b=null,_0x1a0c7c=null;if(_0x19fc65['hasStart']()&&(_0x31e02b=_0x19fc65['getIndexStartValue']()),_0x19fc65['hasEnd']()&&(_0x1a0c7c=_0x19fc65['getIndexEndValue']()),_0x19fc65['getIndex']()===ve){const _0x2dd633='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x42573f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x19fc65['hasStart']()){if(_0x19fc65['getIndexStartName']()!==We)throw new Error(_0x2dd633);if(typeof _0x31e02b!='string')throw new Error(_0x42573f);}if(_0x19fc65['hasEnd']()){if(_0x19fc65['getIndexEndName']()!==we)throw new Error(_0x2dd633);if(typeof _0x1a0c7c!='string')throw new Error(_0x42573f);}}else{if(_0x19fc65['getIndex']()===R){if(_0x31e02b!=null&&!Bt(_0x31e02b)||_0x1a0c7c!=null&&!Bt(_0x1a0c7c))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x19fc65['getIndex']()instanceof Ji||_0x19fc65['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x31e02b!=null&&typeof _0x31e02b=='object'||_0x1a0c7c!=null&&typeof _0x1a0c7c=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2c10a8){if(_0x2c10a8['hasStart']()&&_0x2c10a8['hasEnd']()&&_0x2c10a8['hasLimit']()&&!_0x2c10a8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x2ba404,_0x4347c2){super(_0x2ba404,_0x4347c2,new Zi(),!0x1);}get['parent'](){const _0x6fdc4c=Ro(this['_path']);return _0x6fdc4c===null?null:new ee(this['_repo'],_0x6fdc4c);}get['root'](){let _0x795075=this;for(;_0x795075['parent']!==null;)_0x795075=_0x795075['parent'];return _0x795075;}}class lt{constructor(_0x73436a,_0x1fb03a,_0x4a3277){this['_node']=_0x73436a,this['ref']=_0x1fb03a,this['_index']=_0x4a3277;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3bec27){const _0x4a4348=new C(_0x3bec27),_0xa6b009=Vt(this['ref'],_0x3bec27);return new lt(this['_node']['getChild'](_0x4a4348),_0xa6b009,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x3c2e6c){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4d1cc4,_0x4ec54b)=>_0x3c2e6c(new lt(_0x4ec54b,Vt(this['ref'],_0x4d1cc4),R)));}['hasChild'](_0x2ae1ae){const _0x4df581=new C(_0x2ae1ae);return!this['_node']['getChild'](_0x4df581)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x35592,_0x153403){return _0x35592=P(_0x35592),_0x35592['_checkNotDeleted']('ref'),_0x153403!==void 0x0?Vt(_0x35592['_root'],_0x153403):_0x35592['_root'];}function Vt(_0x15a75a,_0x34cecc){return _0x15a75a=P(_0x15a75a),y(_0x15a75a['_path'])===null?pd('child','path',_0x34cecc):ys('child','path',_0x34cecc),new ee(_0x15a75a['_repo'],k(_0x15a75a['_path'],_0x34cecc));}function v_(_0x3fd83c){return _0x3fd83c=P(_0x3fd83c),new Vd(_0x3fd83c['_repo'],_0x3fd83c['_path']);}function E_(_0x1c5ecc,_0x3c99c9){_0x1c5ecc=P(_0x1c5ecc),Me('push',_0x1c5ecc['_path']),He('push',_0x3c99c9,_0x1c5ecc['_path'],!0x0);const _0x719973=la(_0x1c5ecc['_repo']),_0xae1fdb=Ud(_0x719973),_0x11bd91=Vt(_0x1c5ecc,_0xae1fdb),_0xaa2637=Vt(_0x1c5ecc,_0xae1fdb);let _0x7b3af7;return _0x3c99c9!=null?_0x7b3af7=Hd(_0xaa2637,_0x3c99c9)['then'](()=>_0xaa2637):_0x7b3af7=Promise['resolve'](_0xaa2637),_0x11bd91['then']=_0x7b3af7['then']['bind'](_0x7b3af7),_0x11bd91['catch']=_0x7b3af7['then']['bind'](_0x7b3af7,void 0x0),_0x11bd91;}function Hd(_0x4d49d8,_0x2238e9){_0x4d49d8=P(_0x4d49d8),Me('set',_0x4d49d8['_path']),He('set',_0x2238e9,_0x4d49d8['_path'],!0x1);const _0x19d0f1=new H();return Cd(_0x4d49d8['_repo'],_0x4d49d8['_path'],_0x2238e9,null,_0x19d0f1['wrapCallback'](()=>{})),_0x19d0f1['promise'];}function I_(_0x1cef59,_0x5a1979){ra('update',_0x5a1979,_0x1cef59['_path']);const _0xe54874=new H();return Td(_0x1cef59['_repo'],_0x1cef59['_path'],_0x5a1979,_0xe54874['wrapCallback'](()=>{})),_0xe54874['promise'];}function w_(_0x20d409){_0x20d409=P(_0x20d409);const _0x13f4a7=new pa(()=>{}),_0x137219=new Qn(_0x13f4a7);return wd(_0x20d409['_repo'],_0x20d409,_0x137219)['then'](_0x1b4149=>new lt(_0x1b4149,new ee(_0x20d409['_repo'],_0x20d409['_path']),_0x20d409['_queryParams']['getIndex']()));}class Qn{constructor(_0x3fc1dd){this['callbackContext']=_0x3fc1dd;}['respondsTo'](_0x1ee60e){return _0x1ee60e==='value';}['createEvent'](_0x1eedf4,_0x508d17){const _0x14ca78=_0x508d17['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x1eedf4['snapshotNode'],new ee(_0x508d17['_repo'],_0x508d17['_path']),_0x14ca78));}['getEventRunner'](_0x271646){return _0x271646['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x271646['error']):()=>this['callbackContext']['onValue'](_0x271646['snapshot'],null);}['createCancelEvent'](_0x239d0a,_0x44fc00){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x239d0a,_0x44fc00):null;}['matches'](_0x343a7f){return _0x343a7f instanceof Qn?!_0x343a7f['callbackContext']||!this['callbackContext']?!0x0:_0x343a7f['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0xc7b8b4,_0x426a55,_0x219e3a,_0x36d65b,_0x43bb8c){const _0x3858e9=new pa(_0x219e3a,void 0x0),_0x2748d2=new Qn(_0x3858e9);return kd(_0xc7b8b4['_repo'],_0xc7b8b4,_0x2748d2),()=>Pd(_0xc7b8b4['_repo'],_0xc7b8b4,_0x2748d2);}function Gd(_0x5113ac,_0x5445de,_0x57a078,_0x27114c){return $d(_0x5113ac,'value',_0x5445de);}class mt{}class ma extends mt{constructor(_0x2159af,_0x58a94f){super(),this['_value']=_0x2159af,this['_key']=_0x58a94f,this['type']='endAt';}['_apply'](_0x1fd7a8){He('endAt',this['_value'],_0x1fd7a8['_path'],!0x0);const _0xf42d52=Jh(_0x1fd7a8['_queryParams'],this['_value'],this['_key']);if(ga(_0xf42d52),Yn(_0xf42d52),_0x1fd7a8['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x1fd7a8['_repo'],_0x1fd7a8['_path'],_0xf42d52,_0x1fd7a8['_orderByCalled']);}}function C_(_0x366fee,_0x4a2727){return new ma(_0x366fee,_0x4a2727);}class ya extends mt{constructor(_0x1d0aeb,_0xebb5fb){super(),this['_value']=_0x1d0aeb,this['_key']=_0xebb5fb,this['type']='startAt';}['_apply'](_0x20eb9c){He('startAt',this['_value'],_0x20eb9c['_path'],!0x0);const _0x3b1e2d=Qh(_0x20eb9c['_queryParams'],this['_value'],this['_key']);if(ga(_0x3b1e2d),Yn(_0x3b1e2d),_0x20eb9c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x20eb9c['_repo'],_0x20eb9c['_path'],_0x3b1e2d,_0x20eb9c['_orderByCalled']);}}function T_(_0x2b5a3c=null,_0x288d5d){return new ya(_0x2b5a3c,_0x288d5d);}class qd extends mt{constructor(_0x555d67){super(),this['_limit']=_0x555d67,this['type']='limitToFirst';}['_apply'](_0x671dbb){if(_0x671dbb['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x671dbb['_repo'],_0x671dbb['_path'],Yh(_0x671dbb['_queryParams'],this['_limit']),_0x671dbb['_orderByCalled']);}}function S_(_0x101ba8){if(Math['floor'](_0x101ba8)!==_0x101ba8||_0x101ba8<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x101ba8);}class zd extends mt{constructor(_0x45f275){super(),this['_path']=_0x45f275,this['type']='orderByChild';}['_apply'](_0xaeeee7){_a(_0xaeeee7,'orderByChild');const _0x451671=new C(this['_path']);if(v(_0x451671))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4c2e07=new Ji(_0x451671),_0x449a31=xo(_0xaeeee7['_queryParams'],_0x4c2e07);return Yn(_0x449a31),new Ae(_0xaeeee7['_repo'],_0xaeeee7['_path'],_0x449a31,!0x0);}}function b_(_0x5b819b){if(_0x5b819b==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5b819b==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5b819b==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5b819b),new zd(_0x5b819b);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x521eec){_a(_0x521eec,'orderByKey');const _0x218fc1=xo(_0x521eec['_queryParams'],ve);return Yn(_0x218fc1),new Ae(_0x521eec['_repo'],_0x521eec['_path'],_0x218fc1,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x149c62,_0x28ae61){super(),this['_value']=_0x149c62,this['_key']=_0x28ae61,this['type']='equalTo';}['_apply'](_0x4d49ff){if(He('equalTo',this['_value'],_0x4d49ff['_path'],!0x1),_0x4d49ff['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4d49ff['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4d49ff));}}function A_(_0x33db28,_0x1e757b){return new Kd(_0x33db28,_0x1e757b);}function k_(_0x3c1e5d,..._0x578c35){let _0x194d23=P(_0x3c1e5d);for(const _0x2570c7 of _0x578c35)_0x194d23=_0x2570c7['_apply'](_0x194d23);return _0x194d23;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x26426b,_0xd47c4d,_0xae2c3,_0x2465dd){const _0x1f00fa=_0xd47c4d['lastIndexOf'](':'),_0x4823cc=_0xd47c4d['substring'](0x0,_0x1f00fa),_0x472f5c=qt(_0x4823cc);_0x26426b['repoInfo_']=new yo(_0xd47c4d,_0x472f5c,_0x26426b['repoInfo_']['namespace'],_0x26426b['repoInfo_']['webSocketOnly'],_0x26426b['repoInfo_']['nodeAdmin'],_0x26426b['repoInfo_']['persistenceKey'],_0x26426b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0xae2c3),_0x2465dd&&(_0x26426b['authTokenProvider_']=_0x2465dd);}function Xd(_0x341ca4,_0x3579eb,_0x3a9180,_0x5e4188,_0x30dbce){let _0x4b434c=_0x5e4188||_0x341ca4['options']['databaseURL'];_0x4b434c===void 0x0&&(_0x341ca4['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x341ca4['options']['projectId']),_0x4b434c=_0x341ca4['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x45f56d=vr(_0x4b434c,_0x30dbce),_0x39eef4=_0x45f56d['repoInfo'],_0x5c4758;typeof process<'u'&&Bs&&(_0x5c4758=Bs[Yd]),_0x5c4758?(_0x4b434c='http://'+_0x5c4758+'?ns='+_0x39eef4['namespace'],_0x45f56d=vr(_0x4b434c,_0x30dbce),_0x39eef4=_0x45f56d['repoInfo']):_0x45f56d['repoInfo']['secure'];const _0x4f2408=new eh(_0x341ca4['name'],_0x341ca4['options'],_0x3579eb);_d('Invalid\x20Firebase\x20Database\x20URL',_0x45f56d),v(_0x45f56d['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x1c1b88=ef(_0x39eef4,_0x341ca4,_0x4f2408,new Zl(_0x341ca4,_0x3a9180));return new tf(_0x1c1b88,_0x341ca4);}function Zd(_0x3d0b6a,_0x5d281f){const _0x1bf0de=Di[_0x5d281f];(!_0x1bf0de||_0x1bf0de[_0x3d0b6a['key']]!==_0x3d0b6a)&&ae('Database\x20'+_0x5d281f+'('+_0x3d0b6a['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x3d0b6a),delete _0x1bf0de[_0x3d0b6a['key']];}function ef(_0x3154ef,_0x1848ae,_0x252dfe,_0x49ade7){let _0x1dc384=Di[_0x1848ae['name']];_0x1dc384||(_0x1dc384={},Di[_0x1848ae['name']]=_0x1dc384);let _0x4fab6c=_0x1dc384[_0x3154ef['toURLString']()];return _0x4fab6c&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4fab6c=new vd(_0x3154ef,Qd,_0x252dfe,_0x49ade7),_0x1dc384[_0x3154ef['toURLString']()]=_0x4fab6c,_0x4fab6c;}class tf{constructor(_0x4cf81c,_0x140259){this['_repoInternal']=_0x4cf81c,this['app']=_0x140259,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3d81ad){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3d81ad+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2eede1=Zr(),_0x1f7403){const _0x5b4d67=Hi(_0x2eede1,'database')['getImmediate']({'identifier':_0x1f7403});if(!_0x5b4d67['_instanceStarted']){const _0x3fdb30=hc('database');_0x3fdb30&&nf(_0x5b4d67,..._0x3fdb30);}return _0x5b4d67;}function nf(_0x5e3331,_0x2cc115,_0x17b54d,_0x2e7fe2={}){_0x5e3331=P(_0x5e3331),_0x5e3331['_checkNotDeleted']('useEmulator');const _0xd343cc=_0x2cc115+':'+_0x17b54d,_0x4a36a=_0x5e3331['_repoInternal'];if(_0x5e3331['_instanceStarted']){if(_0xd343cc===_0x5e3331['_repoInternal']['repoInfo_']['host']&&xe(_0x2e7fe2,_0x4a36a['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x421f46;if(_0x4a36a['repoInfo_']['nodeAdmin'])_0x2e7fe2['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x421f46=new an(an['OWNER']);else{if(_0x2e7fe2['mockUserToken']){const _0xdf91b4=typeof _0x2e7fe2['mockUserToken']=='string'?_0x2e7fe2['mockUserToken']:uc(_0x2e7fe2['mockUserToken'],_0x5e3331['app']['options']['projectId']);_0x421f46=new an(_0xdf91b4);}}qt(_0x2cc115)&&Qr(_0x2cc115),Jd(_0x4a36a,_0xd343cc,_0x2e7fe2,_0x421f46);}function N_(_0x5f0e96){_0x5f0e96=P(_0x5f0e96),_0x5f0e96['_checkNotDeleted']('goOffline'),ha(_0x5f0e96['_repo']);}function O_(_0x2327fd){_0x2327fd=P(_0x2327fd),_0x2327fd['_checkNotDeleted']('goOnline'),Nd(_0x2327fd['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0xc62e75){Ul(dt),st(new Fe('database',(_0x34dbc0,{instanceIdentifier:_0x44315a})=>{const _0x5e9ba6=_0x34dbc0['getProvider']('app')['getImmediate'](),_0x25af79=_0x34dbc0['getProvider']('auth-internal'),_0xd5157d=_0x34dbc0['getProvider']('app-check-internal');return Xd(_0x5e9ba6,_0x25af79,_0xd5157d,_0x44315a);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xc62e75),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x328091,_0x3e010e){this['committed']=_0x328091,this['snapshot']=_0x3e010e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x477ee3,_0x84837a,_0x9d5630){if(_0x477ee3=P(_0x477ee3),Me('Reference.transaction',_0x477ee3['_path']),_0x477ee3['key']==='.length'||_0x477ee3['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x477ee3['key']+'\x20is\x20a\x20read-only\x20object.';const _0x2e3a20=!0x0,_0x5e21a7=new H(),_0x5231b1=(_0x4f87a3,_0x15c344,_0xffdc47)=>{let _0x10ee07=null;_0x4f87a3?_0x5e21a7['reject'](_0x4f87a3):(_0x10ee07=new lt(_0xffdc47,new ee(_0x477ee3['_repo'],_0x477ee3['_path']),R),_0x5e21a7['resolve'](new of(_0x15c344,_0x10ee07)));},_0x2292ce=Gd(_0x477ee3,()=>{});return Od(_0x477ee3['_repo'],_0x477ee3['_path'],_0x84837a,_0x5231b1,_0x2292ce,_0x2e3a20),_0x5e21a7['promise'];}se['prototype']['simpleListen']=function(_0x783393,_0x5dace7){this['sendRequest']('q',{'p':_0x783393},_0x5dace7);},se['prototype']['echo']=function(_0x495cbe,_0xfb098b){this['sendRequest']('echo',{'d':_0x495cbe},_0xfb098b);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x13bd31,..._0x13fc37){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x13bd31,..._0x13fc37);}function cn(_0x94a2c9,..._0x298bda){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x94a2c9,..._0x298bda);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x43cf10,..._0x4bced4){throw ws(_0x43cf10,..._0x4bced4);}function X(_0x434c04,..._0x5299d6){return ws(_0x434c04,..._0x5299d6);}function Ia(_0x50aaff,_0x5e040f,_0x236dd0){const _0x470396={...af(),[_0x5e040f]:_0x236dd0};return new Gt('auth','Firebase',_0x470396)['create'](_0x5e040f,{'appName':_0x50aaff['name']});}function re(_0x16515e){return Ia(_0x16515e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1b4eb0,..._0xc0f9df){if(typeof _0x1b4eb0!='string'){const _0x5cbd72=_0xc0f9df[0x0],_0x2e722d=[..._0xc0f9df['slice'](0x1)];return _0x2e722d[0x0]&&(_0x2e722d[0x0]['appName']=_0x1b4eb0['name']),_0x1b4eb0['_errorFactory']['create'](_0x5cbd72,..._0x2e722d);}return Ea['create'](_0x1b4eb0,..._0xc0f9df);}function m(_0x54d335,_0x384dcd,..._0x2a223a){if(!_0x54d335)throw ws(_0x384dcd,..._0x2a223a);}function ne(_0x4136e9){const _0x507dff='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x4136e9;throw cn(_0x507dff),new Error(_0x507dff);}function ce(_0x31cf34,_0x285745){_0x31cf34||ne(_0x285745);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x389108;return typeof self<'u'&&((_0x389108=self['location'])==null?void 0x0:_0x389108['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x28a67d;return typeof self<'u'&&((_0x28a67d=self['location'])==null?void 0x0:_0x28a67d['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x2fa8a3=navigator;return _0x2fa8a3['languages']&&_0x2fa8a3['languages'][0x0]||_0x2fa8a3['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4ec750,_0x2e8292){this['shortDelay']=_0x4ec750,this['longDelay']=_0x2e8292,ce(_0x2e8292>_0x4ec750,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x1dea1c,_0x484345){ce(_0x1dea1c['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x37fd3f}=_0x1dea1c['emulator'];return _0x484345?''+_0x37fd3f+(_0x484345['startsWith']('/')?_0x484345['slice'](0x1):_0x484345):_0x37fd3f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x321d34,_0x2f5329,_0x4b261c){this['fetchImpl']=_0x321d34,_0x2f5329&&(this['headersImpl']=_0x2f5329),_0x4b261c&&(this['responseImpl']=_0x4b261c);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x56aa14,_0x91af7c){return _0x56aa14['tenantId']&&!_0x91af7c['tenantId']?{..._0x91af7c,'tenantId':_0x56aa14['tenantId']}:_0x91af7c;}async function Pe(_0x355c7f,_0x3b50ab,_0x2f8b38,_0x4a2022,_0x241ce7={}){return Ca(_0x355c7f,_0x241ce7,async()=>{let _0x1722d9={},_0x5b1c6a={};_0x4a2022&&(_0x3b50ab==='GET'?_0x5b1c6a=_0x4a2022:_0x1722d9={'body':JSON['stringify'](_0x4a2022)});const _0x206e13=ut({..._0x5b1c6a,'key':_0x355c7f['config']['apiKey']})['slice'](0x1),_0x181f7d=await _0x355c7f['_getAdditionalHeaders']();_0x181f7d['Content-Type']='application/json',_0x355c7f['languageCode']&&(_0x181f7d['X-Firebase-Locale']=_0x355c7f['languageCode']);const _0x19e511={'method':_0x3b50ab,'headers':_0x181f7d,..._0x1722d9};return dc()||(_0x19e511['referrerPolicy']='strict-origin-when-cross-origin'),_0x355c7f['emulatorConfig']&&qt(_0x355c7f['emulatorConfig']['host'])&&(_0x19e511['credentials']='include'),wa['fetch']()(await Ta(_0x355c7f,_0x355c7f['config']['apiHost'],_0x2f8b38,_0x206e13),_0x19e511);});}async function Ca(_0x52893c,_0x16d226,_0x23b877){_0x52893c['_canInitEmulator']=!0x1;const _0x199958={...df,..._0x16d226};try{const _0x14a851=new gf(_0x52893c),_0x46ca28=await Promise['race']([_0x23b877(),_0x14a851['promise']]);_0x14a851['clearNetworkTimeout']();const _0x4f1d2d=await _0x46ca28['json']();if('needConfirmation'in _0x4f1d2d)throw on(_0x52893c,'account-exists-with-different-credential',_0x4f1d2d);if(_0x46ca28['ok']&&!('errorMessage'in _0x4f1d2d))return _0x4f1d2d;{const _0x76201b=_0x46ca28['ok']?_0x4f1d2d['errorMessage']:_0x4f1d2d['error']['message'],[_0x1f919e,_0x455774]=_0x76201b['split']('\x20:\x20');if(_0x1f919e==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x52893c,'credential-already-in-use',_0x4f1d2d);if(_0x1f919e==='EMAIL_EXISTS')throw on(_0x52893c,'email-already-in-use',_0x4f1d2d);if(_0x1f919e==='USER_DISABLED')throw on(_0x52893c,'user-disabled',_0x4f1d2d);const _0x221a33=_0x199958[_0x1f919e]||_0x1f919e['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x455774)throw Ia(_0x52893c,_0x221a33,_0x455774);Y(_0x52893c,_0x221a33);}}catch(_0x1f9668){if(_0x1f9668 instanceof Re)throw _0x1f9668;Y(_0x52893c,'network-request-failed',{'message':String(_0x1f9668)});}}async function en(_0x33c144,_0x57d453,_0x3ce27a,_0x2b32db,_0x29f5a5={}){const _0x5187c1=await Pe(_0x33c144,_0x57d453,_0x3ce27a,_0x2b32db,_0x29f5a5);return'mfaPendingCredential'in _0x5187c1&&Y(_0x33c144,'multi-factor-auth-required',{'_serverResponse':_0x5187c1}),_0x5187c1;}async function Ta(_0x123fa1,_0x1778fb,_0x1ec235,_0x23bb7a){const _0x2c11bf=''+_0x1778fb+_0x1ec235+'?'+_0x23bb7a,_0xe38683=_0x123fa1,_0x864609=_0xe38683['config']['emulator']?Cs(_0x123fa1['config'],_0x2c11bf):_0x123fa1['config']['apiScheme']+'://'+_0x2c11bf;return ff['includes'](_0x1ec235)&&(await _0xe38683['_persistenceManagerAvailable'],_0xe38683['_getPersistenceType']()==='COOKIE')?_0xe38683['_getPersistence']()['_getFinalTarget'](_0x864609)['toString']():_0x864609;}function _f(_0x357b83){switch(_0x357b83){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x59304b){this['auth']=_0x59304b,this['timer']=null,this['promise']=new Promise((_0xc22a92,_0x14f713)=>{this['timer']=setTimeout(()=>_0x14f713(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x143201,_0x2bd96f,_0x1fa475){const _0x26a9bf={'appName':_0x143201['name']};_0x1fa475['email']&&(_0x26a9bf['email']=_0x1fa475['email']),_0x1fa475['phoneNumber']&&(_0x26a9bf['phoneNumber']=_0x1fa475['phoneNumber']);const _0x21ef56=X(_0x143201,_0x2bd96f,_0x26a9bf);return _0x21ef56['customData']['_tokenResponse']=_0x1fa475,_0x21ef56;}function wr(_0x36abd5){return _0x36abd5!==void 0x0&&_0x36abd5['enterprise']!==void 0x0;}class mf{constructor(_0x2c4d26){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2c4d26['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2c4d26['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2c4d26['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xd8dccd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xbf826e of this['recaptchaEnforcementState'])if(_0xbf826e['provider']&&_0xbf826e['provider']===_0xd8dccd)return _f(_0xbf826e['enforcementState']);return null;}['isProviderEnabled'](_0x34d6f2){return this['getProviderEnforcementState'](_0x34d6f2)==='ENFORCE'||this['getProviderEnforcementState'](_0x34d6f2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x51ecc9,_0x3fd957){return Pe(_0x51ecc9,'GET','/v2/recaptchaConfig',ke(_0x51ecc9,_0x3fd957));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x5f4f38,_0x16cb31){return Pe(_0x5f4f38,'POST','/v1/accounts:delete',_0x16cb31);}async function Pn(_0x5550e2,_0x1cd127){return Pe(_0x5550e2,'POST','/v1/accounts:lookup',_0x1cd127);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x5ce170){if(_0x5ce170)try{const _0x1d0a09=new Date(Number(_0x5ce170));if(!isNaN(_0x1d0a09['getTime']()))return _0x1d0a09['toUTCString']();}catch{}}async function Ef(_0x557a32,_0xe6a984=!0x1){const _0xa1aab1=P(_0x557a32),_0x3c8547=await _0xa1aab1['getIdToken'](_0xe6a984),_0x2afa5c=Ts(_0x3c8547);m(_0x2afa5c&&_0x2afa5c['exp']&&_0x2afa5c['auth_time']&&_0x2afa5c['iat'],_0xa1aab1['auth'],'internal-error');const _0x3da951=typeof _0x2afa5c['firebase']=='object'?_0x2afa5c['firebase']:void 0x0,_0x4d8c72=_0x3da951==null?void 0x0:_0x3da951['sign_in_provider'];return{'claims':_0x2afa5c,'token':_0x3c8547,'authTime':Pt(fi(_0x2afa5c['auth_time'])),'issuedAtTime':Pt(fi(_0x2afa5c['iat'])),'expirationTime':Pt(fi(_0x2afa5c['exp'])),'signInProvider':_0x4d8c72||null,'signInSecondFactor':(_0x3da951==null?void 0x0:_0x3da951['sign_in_second_factor'])||null};}function fi(_0x2a1d8e){return Number(_0x2a1d8e)*0x3e8;}function Ts(_0x25a8a0){const [_0x480300,_0x41b060,_0x5299bd]=_0x25a8a0['split']('.');if(_0x480300===void 0x0||_0x41b060===void 0x0||_0x5299bd===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x16bd9b=fn(_0x41b060);return _0x16bd9b?JSON['parse'](_0x16bd9b):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3654c4){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3654c4==null?void 0x0:_0x3654c4['toString']()),null;}}function Cr(_0x713033){const _0x3578ea=Ts(_0x713033);return m(_0x3578ea,'internal-error'),m(typeof _0x3578ea['exp']<'u','internal-error'),m(typeof _0x3578ea['iat']<'u','internal-error'),Number(_0x3578ea['exp'])-Number(_0x3578ea['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x123dbf,_0x5a6d7e,_0x2829b6=!0x1){if(_0x2829b6)return _0x5a6d7e;try{return await _0x5a6d7e;}catch(_0x303705){throw _0x303705 instanceof Re&&If(_0x303705)&&_0x123dbf['auth']['currentUser']===_0x123dbf&&await _0x123dbf['auth']['signOut'](),_0x303705;}}function If({code:_0x5f55e1}){return _0x5f55e1==='auth/user-disabled'||_0x5f55e1==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x482095){this['user']=_0x482095,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1fb82f){if(_0x1fb82f){const _0x4e7fbb=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4e7fbb;}else{this['errorBackoff']=0x7530;const _0x3002ad=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3002ad);}}['schedule'](_0x5853a5=!0x1){if(!this['isRunning'])return;const _0x4829af=this['getInterval'](_0x5853a5);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4829af);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xcf2448){(_0xcf2448==null?void 0x0:_0xcf2448['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x120e22,_0x55587e){this['createdAt']=_0x120e22,this['lastLoginAt']=_0x55587e,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x45c5a7){this['createdAt']=_0x45c5a7['createdAt'],this['lastLoginAt']=_0x45c5a7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x30f519){var _0x308495;const _0x325802=_0x30f519['auth'],_0xbbf3d=await _0x30f519['getIdToken'](),_0x1915c7=await Ht(_0x30f519,Pn(_0x325802,{'idToken':_0xbbf3d}));m(_0x1915c7==null?void 0x0:_0x1915c7['users']['length'],_0x325802,'internal-error');const _0x26335b=_0x1915c7['users'][0x0];_0x30f519['_notifyReloadListener'](_0x26335b);const _0x272b31=(_0x308495=_0x26335b['providerUserInfo'])!=null&&_0x308495['length']?Sa(_0x26335b['providerUserInfo']):[],_0x208a10=Tf(_0x30f519['providerData'],_0x272b31),_0x2a0815=_0x30f519['isAnonymous'],_0x233f6e=!(_0x30f519['email']&&_0x26335b['passwordHash'])&&!(_0x208a10!=null&&_0x208a10['length']),_0x1b409d=_0x2a0815?_0x233f6e:!0x1,_0x27f226={'uid':_0x26335b['localId'],'displayName':_0x26335b['displayName']||null,'photoURL':_0x26335b['photoUrl']||null,'email':_0x26335b['email']||null,'emailVerified':_0x26335b['emailVerified']||!0x1,'phoneNumber':_0x26335b['phoneNumber']||null,'tenantId':_0x26335b['tenantId']||null,'providerData':_0x208a10,'metadata':new Li(_0x26335b['createdAt'],_0x26335b['lastLoginAt']),'isAnonymous':_0x1b409d};Object['assign'](_0x30f519,_0x27f226);}async function Cf(_0x10b1ca){const _0x53162b=P(_0x10b1ca);await Nn(_0x53162b),await _0x53162b['auth']['_persistUserIfCurrent'](_0x53162b),_0x53162b['auth']['_notifyListenersIfCurrent'](_0x53162b);}function Tf(_0x293fa3,_0x5c3c5c){return[..._0x293fa3['filter'](_0x390147=>!_0x5c3c5c['some'](_0x25f0b7=>_0x25f0b7['providerId']===_0x390147['providerId'])),..._0x5c3c5c];}function Sa(_0xc13005){return _0xc13005['map'](({providerId:_0x24e4b0,..._0x26bca8})=>({'providerId':_0x24e4b0,'uid':_0x26bca8['rawId']||'','displayName':_0x26bca8['displayName']||null,'email':_0x26bca8['email']||null,'phoneNumber':_0x26bca8['phoneNumber']||null,'photoURL':_0x26bca8['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x156ac4,_0x2da265){const _0x5c76b4=await Ca(_0x156ac4,{},async()=>{const _0x2f13a4=ut({'grant_type':'refresh_token','refresh_token':_0x2da265})['slice'](0x1),{tokenApiHost:_0xbd80e4,apiKey:_0x2e5ad9}=_0x156ac4['config'],_0x2587f7=await Ta(_0x156ac4,_0xbd80e4,'/v1/token','key='+_0x2e5ad9),_0x38f37e=await _0x156ac4['_getAdditionalHeaders']();_0x38f37e['Content-Type']='application/x-www-form-urlencoded';const _0x235785={'method':'POST','headers':_0x38f37e,'body':_0x2f13a4};return _0x156ac4['emulatorConfig']&&qt(_0x156ac4['emulatorConfig']['host'])&&(_0x235785['credentials']='include'),wa['fetch']()(_0x2587f7,_0x235785);});return{'accessToken':_0x5c76b4['access_token'],'expiresIn':_0x5c76b4['expires_in'],'refreshToken':_0x5c76b4['refresh_token']};}async function bf(_0x33b2df,_0x5f086e){return Pe(_0x33b2df,'POST','/v2/accounts:revokeToken',ke(_0x33b2df,_0x5f086e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1b312f){m(_0x1b312f['idToken'],'internal-error'),m(typeof _0x1b312f['idToken']<'u','internal-error'),m(typeof _0x1b312f['refreshToken']<'u','internal-error');const _0x41f33b='expiresIn'in _0x1b312f&&typeof _0x1b312f['expiresIn']<'u'?Number(_0x1b312f['expiresIn']):Cr(_0x1b312f['idToken']);this['updateTokensAndExpiration'](_0x1b312f['idToken'],_0x1b312f['refreshToken'],_0x41f33b);}['updateFromIdToken'](_0x1d65be){m(_0x1d65be['length']!==0x0,'internal-error');const _0x176477=Cr(_0x1d65be);this['updateTokensAndExpiration'](_0x1d65be,null,_0x176477);}async['getToken'](_0x5d8c63,_0x2e8777=!0x1){return!_0x2e8777&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5d8c63,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5d8c63,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3444b,_0x4d5bde){const {accessToken:_0x25a51e,refreshToken:_0x3e8ea4,expiresIn:_0x3d62d6}=await Sf(_0x3444b,_0x4d5bde);this['updateTokensAndExpiration'](_0x25a51e,_0x3e8ea4,Number(_0x3d62d6));}['updateTokensAndExpiration'](_0x429384,_0x42a70a,_0x3acdbe){this['refreshToken']=_0x42a70a||null,this['accessToken']=_0x429384||null,this['expirationTime']=Date['now']()+_0x3acdbe*0x3e8;}static['fromJSON'](_0x326e06,_0x24ccd4){const {refreshToken:_0x59c012,accessToken:_0x51cb96,expirationTime:_0xcbc62b}=_0x24ccd4,_0x427385=new et();return _0x59c012&&(m(typeof _0x59c012=='string','internal-error',{'appName':_0x326e06}),_0x427385['refreshToken']=_0x59c012),_0x51cb96&&(m(typeof _0x51cb96=='string','internal-error',{'appName':_0x326e06}),_0x427385['accessToken']=_0x51cb96),_0xcbc62b&&(m(typeof _0xcbc62b=='number','internal-error',{'appName':_0x326e06}),_0x427385['expirationTime']=_0xcbc62b),_0x427385;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x312e4c){this['accessToken']=_0x312e4c['accessToken'],this['refreshToken']=_0x312e4c['refreshToken'],this['expirationTime']=_0x312e4c['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x467a42,_0x5d0c41){m(typeof _0x467a42=='string'||typeof _0x467a42>'u','internal-error',{'appName':_0x5d0c41});}class j{constructor({uid:_0x3231ef,auth:_0xec51b4,stsTokenManager:_0x3ad230,..._0x1b24bd}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3231ef,this['auth']=_0xec51b4,this['stsTokenManager']=_0x3ad230,this['accessToken']=_0x3ad230['accessToken'],this['displayName']=_0x1b24bd['displayName']||null,this['email']=_0x1b24bd['email']||null,this['emailVerified']=_0x1b24bd['emailVerified']||!0x1,this['phoneNumber']=_0x1b24bd['phoneNumber']||null,this['photoURL']=_0x1b24bd['photoURL']||null,this['isAnonymous']=_0x1b24bd['isAnonymous']||!0x1,this['tenantId']=_0x1b24bd['tenantId']||null,this['providerData']=_0x1b24bd['providerData']?[..._0x1b24bd['providerData']]:[],this['metadata']=new Li(_0x1b24bd['createdAt']||void 0x0,_0x1b24bd['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3e1058){const _0x9b0f6a=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x3e1058));return m(_0x9b0f6a,this['auth'],'internal-error'),this['accessToken']!==_0x9b0f6a&&(this['accessToken']=_0x9b0f6a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x9b0f6a;}['getIdTokenResult'](_0x51697c){return Ef(this,_0x51697c);}['reload'](){return Cf(this);}['_assign'](_0x57d73e){this!==_0x57d73e&&(m(this['uid']===_0x57d73e['uid'],this['auth'],'internal-error'),this['displayName']=_0x57d73e['displayName'],this['photoURL']=_0x57d73e['photoURL'],this['email']=_0x57d73e['email'],this['emailVerified']=_0x57d73e['emailVerified'],this['phoneNumber']=_0x57d73e['phoneNumber'],this['isAnonymous']=_0x57d73e['isAnonymous'],this['tenantId']=_0x57d73e['tenantId'],this['providerData']=_0x57d73e['providerData']['map'](_0x40e29d=>({..._0x40e29d})),this['metadata']['_copy'](_0x57d73e['metadata']),this['stsTokenManager']['_assign'](_0x57d73e['stsTokenManager']));}['_clone'](_0x4c638c){const _0x3e6618=new j({...this,'auth':_0x4c638c,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3e6618['metadata']['_copy'](this['metadata']),_0x3e6618;}['_onReload'](_0x466b70){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x466b70,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x34e205){this['reloadListener']?this['reloadListener'](_0x34e205):this['reloadUserInfo']=_0x34e205;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x12e585,_0x1dfb5e=!0x1){let _0x334cff=!0x1;_0x12e585['idToken']&&_0x12e585['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x12e585),_0x334cff=!0x0),_0x1dfb5e&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x334cff&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x5495c5=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x5495c5})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x51cba5=>({..._0x51cba5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x358c11,_0x10e96c){const _0x2d1863=_0x10e96c['displayName']??void 0x0,_0x5b77da=_0x10e96c['email']??void 0x0,_0xedc355=_0x10e96c['phoneNumber']??void 0x0,_0x309d79=_0x10e96c['photoURL']??void 0x0,_0x1e3206=_0x10e96c['tenantId']??void 0x0,_0x31884e=_0x10e96c['_redirectEventId']??void 0x0,_0x59118e=_0x10e96c['createdAt']??void 0x0,_0x3c7953=_0x10e96c['lastLoginAt']??void 0x0,{uid:_0x5c78f8,emailVerified:_0x1c1ec2,isAnonymous:_0x1fdb78,providerData:_0x1adab3,stsTokenManager:_0x5dc45e}=_0x10e96c;m(_0x5c78f8&&_0x5dc45e,_0x358c11,'internal-error');const _0x31107c=et['fromJSON'](this['name'],_0x5dc45e);m(typeof _0x5c78f8=='string',_0x358c11,'internal-error'),le(_0x2d1863,_0x358c11['name']),le(_0x5b77da,_0x358c11['name']),m(typeof _0x1c1ec2=='boolean',_0x358c11,'internal-error'),m(typeof _0x1fdb78=='boolean',_0x358c11,'internal-error'),le(_0xedc355,_0x358c11['name']),le(_0x309d79,_0x358c11['name']),le(_0x1e3206,_0x358c11['name']),le(_0x31884e,_0x358c11['name']),le(_0x59118e,_0x358c11['name']),le(_0x3c7953,_0x358c11['name']);const _0x2786ec=new j({'uid':_0x5c78f8,'auth':_0x358c11,'email':_0x5b77da,'emailVerified':_0x1c1ec2,'displayName':_0x2d1863,'isAnonymous':_0x1fdb78,'photoURL':_0x309d79,'phoneNumber':_0xedc355,'tenantId':_0x1e3206,'stsTokenManager':_0x31107c,'createdAt':_0x59118e,'lastLoginAt':_0x3c7953});return _0x1adab3&&Array['isArray'](_0x1adab3)&&(_0x2786ec['providerData']=_0x1adab3['map'](_0x477764=>({..._0x477764}))),_0x31884e&&(_0x2786ec['_redirectEventId']=_0x31884e),_0x2786ec;}static async['_fromIdTokenResponse'](_0x1a2eac,_0x1b4165,_0x137bc6=!0x1){const _0x259627=new et();_0x259627['updateFromServerResponse'](_0x1b4165);const _0x4fa211=new j({'uid':_0x1b4165['localId'],'auth':_0x1a2eac,'stsTokenManager':_0x259627,'isAnonymous':_0x137bc6});return await Nn(_0x4fa211),_0x4fa211;}static async['_fromGetAccountInfoResponse'](_0x4b1552,_0x3ff668,_0x387974){const _0x270c62=_0x3ff668['users'][0x0];m(_0x270c62['localId']!==void 0x0,'internal-error');const _0x20638f=_0x270c62['providerUserInfo']!==void 0x0?Sa(_0x270c62['providerUserInfo']):[],_0x35034f=!(_0x270c62['email']&&_0x270c62['passwordHash'])&&!(_0x20638f!=null&&_0x20638f['length']),_0xee8c76=new et();_0xee8c76['updateFromIdToken'](_0x387974);const _0x52c7c8=new j({'uid':_0x270c62['localId'],'auth':_0x4b1552,'stsTokenManager':_0xee8c76,'isAnonymous':_0x35034f}),_0x501a7b={'uid':_0x270c62['localId'],'displayName':_0x270c62['displayName']||null,'photoURL':_0x270c62['photoUrl']||null,'email':_0x270c62['email']||null,'emailVerified':_0x270c62['emailVerified']||!0x1,'phoneNumber':_0x270c62['phoneNumber']||null,'tenantId':_0x270c62['tenantId']||null,'providerData':_0x20638f,'metadata':new Li(_0x270c62['createdAt'],_0x270c62['lastLoginAt']),'isAnonymous':!(_0x270c62['email']&&_0x270c62['passwordHash'])&&!(_0x20638f!=null&&_0x20638f['length'])};return Object['assign'](_0x52c7c8,_0x501a7b),_0x52c7c8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x1edef8){ce(_0x1edef8 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4fbbd3=Tr['get'](_0x1edef8);return _0x4fbbd3?(ce(_0x4fbbd3 instanceof _0x1edef8,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4fbbd3):(_0x4fbbd3=new _0x1edef8(),Tr['set'](_0x1edef8,_0x4fbbd3),_0x4fbbd3);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3c5744,_0x457738){this['storage'][_0x3c5744]=_0x457738;}async['_get'](_0x133e38){const _0x4ad2d0=this['storage'][_0x133e38];return _0x4ad2d0===void 0x0?null:_0x4ad2d0;}async['_remove'](_0x1cf456){delete this['storage'][_0x1cf456];}['_addListener'](_0x336e81,_0x3e1e6e){}['_removeListener'](_0x83e7e,_0x3a3d10){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x7c0323,_0x323e4f,_0x28bd3d){return'firebase:'+_0x7c0323+':'+_0x323e4f+':'+_0x28bd3d;}class tt{constructor(_0x3bffa2,_0x198245,_0x1d69ca){this['persistence']=_0x3bffa2,this['auth']=_0x198245,this['userKey']=_0x1d69ca;const {config:_0x342d28,name:_0x1becce}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x342d28['apiKey'],_0x1becce),this['fullPersistenceKey']=ln('persistence',_0x342d28['apiKey'],_0x1becce),this['boundEventHandler']=_0x198245['_onStorageEvent']['bind'](_0x198245),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x4abe87){return this['persistence']['_set'](this['fullUserKey'],_0x4abe87['toJSON']());}async['getCurrentUser'](){const _0x4cf911=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4cf911)return null;if(typeof _0x4cf911=='string'){const _0x28c1b7=await Pn(this['auth'],{'idToken':_0x4cf911})['catch'](()=>{});return _0x28c1b7?j['_fromGetAccountInfoResponse'](this['auth'],_0x28c1b7,_0x4cf911):null;}return j['_fromJSON'](this['auth'],_0x4cf911);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2db0af){if(this['persistence']===_0x2db0af)return;const _0x42d9cb=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2db0af,_0x42d9cb)return this['setCurrentUser'](_0x42d9cb);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x855e27,_0x1ed6f0,_0x18ec2f='authUser'){if(!_0x1ed6f0['length'])return new tt(ie(Sr),_0x855e27,_0x18ec2f);const _0x2635e4=(await Promise['all'](_0x1ed6f0['map'](async _0x55dd55=>{if(await _0x55dd55['_isAvailable']())return _0x55dd55;})))['filter'](_0x55405a=>_0x55405a);let _0x1a7c01=_0x2635e4[0x0]||ie(Sr);const _0x3190bd=ln(_0x18ec2f,_0x855e27['config']['apiKey'],_0x855e27['name']);let _0x5d6603=null;for(const _0x2186d0 of _0x1ed6f0)try{const _0x36b1e6=await _0x2186d0['_get'](_0x3190bd);if(_0x36b1e6){let _0x41e95a;if(typeof _0x36b1e6=='string'){const _0x5e08ee=await Pn(_0x855e27,{'idToken':_0x36b1e6})['catch'](()=>{});if(!_0x5e08ee)break;_0x41e95a=await j['_fromGetAccountInfoResponse'](_0x855e27,_0x5e08ee,_0x36b1e6);}else _0x41e95a=j['_fromJSON'](_0x855e27,_0x36b1e6);_0x2186d0!==_0x1a7c01&&(_0x5d6603=_0x41e95a),_0x1a7c01=_0x2186d0;break;}}catch{}const _0x18f817=_0x2635e4['filter'](_0x20052e=>_0x20052e['_shouldAllowMigration']);return!_0x1a7c01['_shouldAllowMigration']||!_0x18f817['length']?new tt(_0x1a7c01,_0x855e27,_0x18ec2f):(_0x1a7c01=_0x18f817[0x0],_0x5d6603&&await _0x1a7c01['_set'](_0x3190bd,_0x5d6603['toJSON']()),await Promise['all'](_0x1ed6f0['map'](async _0x12501b=>{if(_0x12501b!==_0x1a7c01)try{await _0x12501b['_remove'](_0x3190bd);}catch{}})),new tt(_0x1a7c01,_0x855e27,_0x18ec2f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4de9be){const _0x3eee3b=_0x4de9be['toLowerCase']();if(_0x3eee3b['includes']('opera/')||_0x3eee3b['includes']('opr/')||_0x3eee3b['includes']('opios/'))return'Opera';if(Pa(_0x3eee3b))return'IEMobile';if(_0x3eee3b['includes']('msie')||_0x3eee3b['includes']('trident/'))return'IE';if(_0x3eee3b['includes']('edge/'))return'Edge';if(Ra(_0x3eee3b))return'Firefox';if(_0x3eee3b['includes']('silk/'))return'Silk';if(Oa(_0x3eee3b))return'Blackberry';if(Da(_0x3eee3b))return'Webos';if(Aa(_0x3eee3b))return'Safari';if((_0x3eee3b['includes']('chrome/')||ka(_0x3eee3b))&&!_0x3eee3b['includes']('edge/'))return'Chrome';if(Na(_0x3eee3b))return'Android';{const _0x5c71fb=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xd9b72c=_0x4de9be['match'](_0x5c71fb);if((_0xd9b72c==null?void 0x0:_0xd9b72c['length'])===0x2)return _0xd9b72c[0x1];}return'Other';}function Ra(_0x283f88=W()){return/firefox\//i['test'](_0x283f88);}function Aa(_0x5ad926=W()){const _0x5b966d=_0x5ad926['toLowerCase']();return _0x5b966d['includes']('safari/')&&!_0x5b966d['includes']('chrome/')&&!_0x5b966d['includes']('crios/')&&!_0x5b966d['includes']('android');}function ka(_0x285501=W()){return/crios\//i['test'](_0x285501);}function Pa(_0x1c8585=W()){return/iemobile/i['test'](_0x1c8585);}function Na(_0x346901=W()){return/android/i['test'](_0x346901);}function Oa(_0x2c30b9=W()){return/blackberry/i['test'](_0x2c30b9);}function Da(_0x5548ca=W()){return/webos/i['test'](_0x5548ca);}function Ss(_0x3206b8=W()){return/iphone|ipad|ipod/i['test'](_0x3206b8)||/macintosh/i['test'](_0x3206b8)&&/mobile/i['test'](_0x3206b8);}function Rf(_0x1b67f0=W()){var _0x5006ec;return Ss(_0x1b67f0)&&!!((_0x5006ec=window['navigator'])!=null&&_0x5006ec['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x12a008=W()){return Ss(_0x12a008)||Na(_0x12a008)||Da(_0x12a008)||Oa(_0x12a008)||/windows phone/i['test'](_0x12a008)||Pa(_0x12a008);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x515ffb,_0x408e81=[]){let _0x3bf674;switch(_0x515ffb){case'Browser':_0x3bf674=br(W());break;case'Worker':_0x3bf674=br(W())+'-'+_0x515ffb;break;default:_0x3bf674=_0x515ffb;}const _0xea027a=_0x408e81['length']?_0x408e81['join'](','):'FirebaseCore-web';return _0x3bf674+'/JsCore/'+dt+'/'+_0xea027a;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x60c977){this['auth']=_0x60c977,this['queue']=[];}['pushCallback'](_0x557d7c,_0x31eaaa){const _0x47fa06=_0x12c17d=>new Promise((_0x4b3514,_0x502ac1)=>{try{const _0x309bbf=_0x557d7c(_0x12c17d);_0x4b3514(_0x309bbf);}catch(_0xc34ea9){_0x502ac1(_0xc34ea9);}});_0x47fa06['onAbort']=_0x31eaaa,this['queue']['push'](_0x47fa06);const _0x388a20=this['queue']['length']-0x1;return()=>{this['queue'][_0x388a20]=()=>Promise['resolve']();};}async['runMiddleware'](_0x423ac1){if(this['auth']['currentUser']===_0x423ac1)return;const _0x929230=[];try{for(const _0x3fbfc8 of this['queue'])await _0x3fbfc8(_0x423ac1),_0x3fbfc8['onAbort']&&_0x929230['push'](_0x3fbfc8['onAbort']);}catch(_0x5f1ad7){_0x929230['reverse']();for(const _0x138428 of _0x929230)try{_0x138428();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x5f1ad7==null?void 0x0:_0x5f1ad7['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x58693b,_0x18d7cf={}){return Pe(_0x58693b,'GET','/v2/passwordPolicy',ke(_0x58693b,_0x18d7cf));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x4223f8){var _0x26948a;const _0x433369=_0x4223f8['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x433369['minPasswordLength']??Nf,_0x433369['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x433369['maxPasswordLength']),_0x433369['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x433369['containsLowercaseCharacter']),_0x433369['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x433369['containsUppercaseCharacter']),_0x433369['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x433369['containsNumericCharacter']),_0x433369['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x433369['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4223f8['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x26948a=_0x4223f8['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x26948a['join'](''))??'',this['forceUpgradeOnSignin']=_0x4223f8['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4223f8['schemaVersion'];}['validatePassword'](_0x4ddcd1){const _0x2d22b5={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4ddcd1,_0x2d22b5),this['validatePasswordCharacterOptions'](_0x4ddcd1,_0x2d22b5),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['meetsMinPasswordLength']??!0x0),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['meetsMaxPasswordLength']??!0x0),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['containsLowercaseLetter']??!0x0),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['containsUppercaseLetter']??!0x0),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['containsNumericCharacter']??!0x0),_0x2d22b5['isValid']&&(_0x2d22b5['isValid']=_0x2d22b5['containsNonAlphanumericCharacter']??!0x0),_0x2d22b5;}['validatePasswordLengthOptions'](_0x7d0988,_0xc55e88){const _0x482fe0=this['customStrengthOptions']['minPasswordLength'],_0x1b6389=this['customStrengthOptions']['maxPasswordLength'];_0x482fe0&&(_0xc55e88['meetsMinPasswordLength']=_0x7d0988['length']>=_0x482fe0),_0x1b6389&&(_0xc55e88['meetsMaxPasswordLength']=_0x7d0988['length']<=_0x1b6389);}['validatePasswordCharacterOptions'](_0x1f906e,_0xb0fcec){this['updatePasswordCharacterOptionsStatuses'](_0xb0fcec,!0x1,!0x1,!0x1,!0x1);let _0x4c41d2;for(let _0x325177=0x0;_0x325177<_0x1f906e['length'];_0x325177++)_0x4c41d2=_0x1f906e['charAt'](_0x325177),this['updatePasswordCharacterOptionsStatuses'](_0xb0fcec,_0x4c41d2>='a'&&_0x4c41d2<='z',_0x4c41d2>='A'&&_0x4c41d2<='Z',_0x4c41d2>='0'&&_0x4c41d2<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4c41d2));}['updatePasswordCharacterOptionsStatuses'](_0x1564d0,_0x333e2f,_0x8c46d2,_0x489232,_0x3516a9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1564d0['containsLowercaseLetter']||(_0x1564d0['containsLowercaseLetter']=_0x333e2f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1564d0['containsUppercaseLetter']||(_0x1564d0['containsUppercaseLetter']=_0x8c46d2)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1564d0['containsNumericCharacter']||(_0x1564d0['containsNumericCharacter']=_0x489232)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1564d0['containsNonAlphanumericCharacter']||(_0x1564d0['containsNonAlphanumericCharacter']=_0x3516a9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x32dcd2,_0x4681be,_0x390e35,_0x11b1fc){this['app']=_0x32dcd2,this['heartbeatServiceProvider']=_0x4681be,this['appCheckServiceProvider']=_0x390e35,this['config']=_0x11b1fc,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x32dcd2['name'],this['clientVersion']=_0x11b1fc['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x548759=>this['_resolvePersistenceManagerAvailable']=_0x548759);}['_initializeWithPersistence'](_0x247b7b,_0x2dd17d){return _0x2dd17d&&(this['_popupRedirectResolver']=ie(_0x2dd17d)),this['_initializationPromise']=this['queue'](async()=>{var _0x66bb18,_0xe906f3,_0x3ef789;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x247b7b),(_0x66bb18=this['_resolvePersistenceManagerAvailable'])==null||_0x66bb18['call'](this),!this['_deleted'])){if((_0xe906f3=this['_popupRedirectResolver'])!=null&&_0xe906f3['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2dd17d),this['lastNotifiedUid']=((_0x3ef789=this['currentUser'])==null?void 0x0:_0x3ef789['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x434457=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x434457)){if(this['currentUser']&&_0x434457&&this['currentUser']['uid']===_0x434457['uid']){this['_currentUser']['_assign'](_0x434457),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x434457,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x47d36e){try{const _0x64cf73=await Pn(this,{'idToken':_0x47d36e}),_0x165aa5=await j['_fromGetAccountInfoResponse'](this,_0x64cf73,_0x47d36e);await this['directlySetCurrentUser'](_0x165aa5);}catch(_0x1df987){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1df987),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5a85b2){var _0x135fb9;if($(this['app'])){const _0x225671=this['app']['settings']['authIdToken'];return _0x225671?new Promise(_0x2908fc=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x225671)['then'](_0x2908fc,_0x2908fc));}):this['directlySetCurrentUser'](null);}const _0x453890=await this['assertedPersistence']['getCurrentUser']();let _0x29df94=_0x453890,_0x21a65e=!0x1;if(_0x5a85b2&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x193de8=(_0x135fb9=this['redirectUser'])==null?void 0x0:_0x135fb9['_redirectEventId'],_0x5d3daa=_0x29df94==null?void 0x0:_0x29df94['_redirectEventId'],_0x49fb46=await this['tryRedirectSignIn'](_0x5a85b2);(!_0x193de8||_0x193de8===_0x5d3daa)&&(_0x49fb46!=null&&_0x49fb46['user'])&&(_0x29df94=_0x49fb46['user'],_0x21a65e=!0x0);}if(!_0x29df94)return this['directlySetCurrentUser'](null);if(!_0x29df94['_redirectEventId']){if(_0x21a65e)try{await this['beforeStateQueue']['runMiddleware'](_0x29df94);}catch(_0x45d8a1){_0x29df94=_0x453890,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x45d8a1));}return _0x29df94?this['reloadAndSetCurrentUserOrClear'](_0x29df94):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x29df94['_redirectEventId']?this['directlySetCurrentUser'](_0x29df94):this['reloadAndSetCurrentUserOrClear'](_0x29df94);}async['tryRedirectSignIn'](_0x3df06a){let _0x116c07=null;try{_0x116c07=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3df06a,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x116c07;}async['reloadAndSetCurrentUserOrClear'](_0x15b736){try{await Nn(_0x15b736);}catch(_0x310430){if((_0x310430==null?void 0x0:_0x310430['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x15b736);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5b18bc){if($(this['app']))return Promise['reject'](re(this));const _0x5493c9=_0x5b18bc?P(_0x5b18bc):null;return _0x5493c9&&m(_0x5493c9['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5493c9&&_0x5493c9['_clone'](this));}async['_updateCurrentUser'](_0x1d0ac9,_0x5b2d47=!0x1){if(!this['_deleted'])return _0x1d0ac9&&m(this['tenantId']===_0x1d0ac9['tenantId'],this,'tenant-id-mismatch'),_0x5b2d47||await this['beforeStateQueue']['runMiddleware'](_0x1d0ac9),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1d0ac9),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x208ec8){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x208ec8));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2f0b09){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4da3ae=this['_getPasswordPolicyInternal']();return _0x4da3ae['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4da3ae['validatePassword'](_0x2f0b09);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5116ca=await Pf(this),_0x4563f0=new Of(_0x5116ca);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4563f0:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4563f0;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x141aa9){this['_errorFactory']=new Gt('auth','Firebase',_0x141aa9());}['onAuthStateChanged'](_0x173ff,_0x23bb5e,_0x1e8794){return this['registerStateListener'](this['authStateSubscription'],_0x173ff,_0x23bb5e,_0x1e8794);}['beforeAuthStateChanged'](_0x1b28ab,_0x4af71f){return this['beforeStateQueue']['pushCallback'](_0x1b28ab,_0x4af71f);}['onIdTokenChanged'](_0x26f934,_0xb930bf,_0x59b847){return this['registerStateListener'](this['idTokenSubscription'],_0x26f934,_0xb930bf,_0x59b847);}['authStateReady'](){return new Promise((_0x2788db,_0x14265e)=>{if(this['currentUser'])_0x2788db();else{const _0x433110=this['onAuthStateChanged'](()=>{_0x433110(),_0x2788db();},_0x14265e);}});}async['revokeAccessToken'](_0x4f567b){if(this['currentUser']){const _0x1466e5=await this['currentUser']['getIdToken'](),_0x1cdac8={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x4f567b,'idToken':_0x1466e5};this['tenantId']!=null&&(_0x1cdac8['tenantId']=this['tenantId']),await bf(this,_0x1cdac8);}}['toJSON'](){var _0x54a25e;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x54a25e=this['_currentUser'])==null?void 0x0:_0x54a25e['toJSON']()};}async['_setRedirectUser'](_0x4e1771,_0x1cbf63){const _0x374bc1=await this['getOrInitRedirectPersistenceManager'](_0x1cbf63);return _0x4e1771===null?_0x374bc1['removeCurrentUser']():_0x374bc1['setCurrentUser'](_0x4e1771);}async['getOrInitRedirectPersistenceManager'](_0x68ec13){if(!this['redirectPersistenceManager']){const _0x28d994=_0x68ec13&&ie(_0x68ec13)||this['_popupRedirectResolver'];m(_0x28d994,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x28d994['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x3cfafd){var _0x460b42,_0x23619f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x460b42=this['_currentUser'])==null?void 0x0:_0x460b42['_redirectEventId'])===_0x3cfafd?this['_currentUser']:((_0x23619f=this['redirectUser'])==null?void 0x0:_0x23619f['_redirectEventId'])===_0x3cfafd?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5599d6){if(_0x5599d6===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5599d6));}['_notifyListenersIfCurrent'](_0x1c488d){_0x1c488d===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x59d2bd;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x94a9fa=((_0x59d2bd=this['currentUser'])==null?void 0x0:_0x59d2bd['uid'])??null;this['lastNotifiedUid']!==_0x94a9fa&&(this['lastNotifiedUid']=_0x94a9fa,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x31ea14,_0x375528,_0x65ffec,_0x5d00bb){if(this['_deleted'])return()=>{};const _0x20c63b=typeof _0x375528=='function'?_0x375528:_0x375528['next']['bind'](_0x375528);let _0x3ec5a2=!0x1;const _0x1dc615=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1dc615,this,'internal-error'),_0x1dc615['then'](()=>{_0x3ec5a2||_0x20c63b(this['currentUser']);}),typeof _0x375528=='function'){const _0xc6ba58=_0x31ea14['addObserver'](_0x375528,_0x65ffec,_0x5d00bb);return()=>{_0x3ec5a2=!0x0,_0xc6ba58();};}else{const _0x2e78ca=_0x31ea14['addObserver'](_0x375528);return()=>{_0x3ec5a2=!0x0,_0x2e78ca();};}}async['directlySetCurrentUser'](_0x589f25){this['currentUser']&&this['currentUser']!==_0x589f25&&this['_currentUser']['_stopProactiveRefresh'](),_0x589f25&&this['isProactiveRefreshEnabled']&&_0x589f25['_startProactiveRefresh'](),this['currentUser']=_0x589f25,_0x589f25?await this['assertedPersistence']['setCurrentUser'](_0x589f25):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x12b759){return this['operations']=this['operations']['then'](_0x12b759,_0x12b759),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x465bd2){!_0x465bd2||this['frameworks']['includes'](_0x465bd2)||(this['frameworks']['push'](_0x465bd2),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x539249;const _0x4bf1c1={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4bf1c1['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x214194=await((_0x539249=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x539249['getHeartbeatsHeader']());_0x214194&&(_0x4bf1c1['X-Firebase-Client']=_0x214194);const _0x9596a3=await this['_getAppCheckToken']();return _0x9596a3&&(_0x4bf1c1['X-Firebase-AppCheck']=_0x9596a3),_0x4bf1c1;}async['_getAppCheckToken'](){var _0x4cc9dc;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3eb50c=await((_0x4cc9dc=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4cc9dc['getToken']());return _0x3eb50c!=null&&_0x3eb50c['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3eb50c['error']),_0x3eb50c==null?void 0x0:_0x3eb50c['token'];}}function Ke(_0x160175){return P(_0x160175);}class Rr{constructor(_0x17601a){this['auth']=_0x17601a,this['observer']=null,this['addObserver']=Tc(_0x2f64bf=>this['observer']=_0x2f64bf);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1e08eb){Jn=_0x1e08eb;}function xa(_0x4288a6){return Jn['loadJS'](_0x4288a6);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x3dea14){return'__'+_0x3dea14+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x2d5eba){_0x2d5eba();}['execute'](_0x4fe99d,_0x799b8d){return Promise['resolve']('token');}['render'](_0x323852,_0x4d7ef4){return'';}}class Wf{['ready'](_0x217987){_0x217987();}['execute'](_0xe5337,_0x349f02){return Promise['resolve']('token');}['render'](_0x273b24,_0x3ed5f3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3e3a14){this['type']=Bf,this['auth']=Ke(_0x3e3a14);}async['verify'](_0x175ef6='verify',_0x5c7249=!0x1){async function _0x51e346(_0x359c1f){if(!_0x5c7249){if(_0x359c1f['tenantId']==null&&_0x359c1f['_agentRecaptchaConfig']!=null)return _0x359c1f['_agentRecaptchaConfig']['siteKey'];if(_0x359c1f['tenantId']!=null&&_0x359c1f['_tenantRecaptchaConfigs'][_0x359c1f['tenantId']]!==void 0x0)return _0x359c1f['_tenantRecaptchaConfigs'][_0x359c1f['tenantId']]['siteKey'];}return new Promise(async(_0x35f129,_0x529bb7)=>{yf(_0x359c1f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1df8bb=>{if(_0x1df8bb['recaptchaKey']===void 0x0)_0x529bb7(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x56a0f3=new mf(_0x1df8bb);return _0x359c1f['tenantId']==null?_0x359c1f['_agentRecaptchaConfig']=_0x56a0f3:_0x359c1f['_tenantRecaptchaConfigs'][_0x359c1f['tenantId']]=_0x56a0f3,_0x35f129(_0x56a0f3['siteKey']);}})['catch'](_0x4cbc29=>{_0x529bb7(_0x4cbc29);});});}function _0x232d2a(_0x586964,_0x207cf5,_0x546cdc){const _0x37d11e=window['grecaptcha'];wr(_0x37d11e)?_0x37d11e['enterprise']['ready'](()=>{_0x37d11e['enterprise']['execute'](_0x586964,{'action':_0x175ef6})['then'](_0x196185=>{_0x207cf5(_0x196185);})['catch'](()=>{_0x207cf5(Fa);});}):_0x546cdc(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x2608a1,_0x4cbb82)=>{_0x51e346(this['auth'])['then'](async _0x270096=>{if(!_0x5c7249&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x232d2a(_0x270096,_0x2608a1,_0x4cbb82);else{if(typeof window>'u'){_0x4cbb82(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x52009d=Lf();_0x52009d['length']!==0x0&&(_0x52009d+=_0x270096+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0xadb271;(_0xadb271=he['scriptInjectionDeferred'])==null||_0xadb271['resolve']();},xa(_0x52009d)['then'](()=>{var _0x287d34;return(_0x287d34=he['scriptInjectionDeferred'])==null?void 0x0:_0x287d34['promise'];})['then'](()=>{_0x232d2a(_0x270096,_0x2608a1,_0x4cbb82);})['catch'](_0x3792a5=>{_0x4cbb82(_0x3792a5);});}})['catch'](_0x4679be=>{_0x4cbb82(_0x4679be);});});}}he['scriptInjectionDeferred']=null;async function kr(_0xa05052,_0x387e64,_0x2f5b54,_0x34f72f=!0x1,_0x3106d1=!0x1){const _0x517f7d=new he(_0xa05052);let _0x38ee46;if(_0x3106d1)_0x38ee46=Fa;else try{_0x38ee46=await _0x517f7d['verify'](_0x2f5b54);}catch{_0x38ee46=await _0x517f7d['verify'](_0x2f5b54,!0x0);}const _0x5a8a89={..._0x387e64};if(_0x2f5b54==='mfaSmsEnrollment'||_0x2f5b54==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5a8a89){const _0x433278=_0x5a8a89['phoneEnrollmentInfo']['phoneNumber'],_0x168a12=_0x5a8a89['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5a8a89,{'phoneEnrollmentInfo':{'phoneNumber':_0x433278,'recaptchaToken':_0x168a12,'captchaResponse':_0x38ee46,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5a8a89){const _0x20a1bc=_0x5a8a89['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5a8a89,{'phoneSignInInfo':{'recaptchaToken':_0x20a1bc,'captchaResponse':_0x38ee46,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5a8a89;}return _0x34f72f?Object['assign'](_0x5a8a89,{'captchaResp':_0x38ee46}):Object['assign'](_0x5a8a89,{'captchaResponse':_0x38ee46}),Object['assign'](_0x5a8a89,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5a8a89,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5a8a89;}async function xi(_0x4e8c67,_0x28ea4f,_0x425f9c,_0xc5ba5f,_0x259748){var _0x5d0f79;if((_0x5d0f79=_0x4e8c67['_getRecaptchaConfig']())!=null&&_0x5d0f79['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x49bc5b=await kr(_0x4e8c67,_0x28ea4f,_0x425f9c,_0x425f9c==='getOobCode');return _0xc5ba5f(_0x4e8c67,_0x49bc5b);}else return _0xc5ba5f(_0x4e8c67,_0x28ea4f)['catch'](async _0x275db7=>{if(_0x275db7['code']==='auth/missing-recaptcha-token'){console['log'](_0x425f9c+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x27b2f9=await kr(_0x4e8c67,_0x28ea4f,_0x425f9c,_0x425f9c==='getOobCode');return _0xc5ba5f(_0x4e8c67,_0x27b2f9);}else return Promise['reject'](_0x275db7);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2faaec,_0x4dedff){const _0x67c8ac=Hi(_0x2faaec,'auth');if(_0x67c8ac['isInitialized']()){const _0x3965e7=_0x67c8ac['getImmediate'](),_0x7e2d0e=_0x67c8ac['getOptions']();if(xe(_0x7e2d0e,_0x4dedff??{}))return _0x3965e7;Y(_0x3965e7,'already-initialized');}return _0x67c8ac['initialize']({'options':_0x4dedff});}function Hf(_0x5b61e6,_0x2a460d){const _0x28785d=(_0x2a460d==null?void 0x0:_0x2a460d['persistence'])||[],_0x511d9c=(Array['isArray'](_0x28785d)?_0x28785d:[_0x28785d])['map'](ie);_0x2a460d!=null&&_0x2a460d['errorMap']&&_0x5b61e6['_updateErrorMap'](_0x2a460d['errorMap']),_0x5b61e6['_initializeWithPersistence'](_0x511d9c,_0x2a460d==null?void 0x0:_0x2a460d['popupRedirectResolver']);}function $f(_0x14a690,_0x228b6c,_0x4d5508){const _0x65552f=Ke(_0x14a690);m(/^https?:\/\//['test'](_0x228b6c),_0x65552f,'invalid-emulator-scheme');const _0x1020d0=!0x1,_0xb04d74=Ua(_0x228b6c),{host:_0x56827c,port:_0x583f60}=Gf(_0x228b6c),_0x2fdf5f=_0x583f60===null?'':':'+_0x583f60,_0x248d9f={'url':_0xb04d74+'//'+_0x56827c+_0x2fdf5f+'/'},_0x318d8e=Object['freeze']({'host':_0x56827c,'port':_0x583f60,'protocol':_0xb04d74['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1020d0})});if(!_0x65552f['_canInitEmulator']){m(_0x65552f['config']['emulator']&&_0x65552f['emulatorConfig'],_0x65552f,'emulator-config-failed'),m(xe(_0x248d9f,_0x65552f['config']['emulator'])&&xe(_0x318d8e,_0x65552f['emulatorConfig']),_0x65552f,'emulator-config-failed');return;}_0x65552f['config']['emulator']=_0x248d9f,_0x65552f['emulatorConfig']=_0x318d8e,_0x65552f['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x56827c)?Qr(_0xb04d74+'//'+_0x56827c+_0x2fdf5f):qf();}function Ua(_0x40caac){const _0x147cc1=_0x40caac['indexOf'](':');return _0x147cc1<0x0?'':_0x40caac['substr'](0x0,_0x147cc1+0x1);}function Gf(_0x40bb4c){const _0x448c73=Ua(_0x40bb4c),_0x23dd10=/(\/\/)?([^?#/]+)/['exec'](_0x40bb4c['substr'](_0x448c73['length']));if(!_0x23dd10)return{'host':'','port':null};const _0xbf5220=_0x23dd10[0x2]['split']('@')['pop']()||'',_0x4ee57f=/^(\[[^\]]+\])(:|$)/['exec'](_0xbf5220);if(_0x4ee57f){const _0x180dfd=_0x4ee57f[0x1];return{'host':_0x180dfd,'port':Pr(_0xbf5220['substr'](_0x180dfd['length']+0x1))};}else{const [_0x4a2286,_0x2fd6a3]=_0xbf5220['split'](':');return{'host':_0x4a2286,'port':Pr(_0x2fd6a3)};}}function Pr(_0x55aa6c){if(!_0x55aa6c)return null;const _0x16f7c9=Number(_0x55aa6c);return isNaN(_0x16f7c9)?null:_0x16f7c9;}function qf(){function _0x39bf56(){const _0x2233a9=document['createElement']('p'),_0x3df96a=_0x2233a9['style'];_0x2233a9['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x3df96a['position']='fixed',_0x3df96a['width']='100%',_0x3df96a['backgroundColor']='#ffffff',_0x3df96a['border']='.1em\x20solid\x20#000000',_0x3df96a['color']='#b50000',_0x3df96a['bottom']='0px',_0x3df96a['left']='0px',_0x3df96a['margin']='0px',_0x3df96a['zIndex']='10000',_0x3df96a['textAlign']='center',_0x2233a9['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2233a9);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x39bf56):_0x39bf56());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x38bf16,_0x54efc0){this['providerId']=_0x38bf16,this['signInMethod']=_0x54efc0;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3b338c){return ne('not\x20implemented');}['_linkToIdToken'](_0x54ec1b,_0x29d432){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x28d6c1){return ne('not\x20implemented');}}async function zf(_0x309464,_0x55cb12){return Pe(_0x309464,'POST','/v1/accounts:signUp',_0x55cb12);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0xddba89,_0x1976ae){return en(_0xddba89,'POST','/v1/accounts:signInWithPassword',ke(_0xddba89,_0x1976ae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x5e8aef,_0x4356ff){return en(_0x5e8aef,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5e8aef,_0x4356ff));}async function Yf(_0x32afa0,_0xeb84f7){return en(_0x32afa0,'POST','/v1/accounts:signInWithEmailLink',ke(_0x32afa0,_0xeb84f7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x96681f,_0x27c19e,_0x384800,_0x1d45db=null){super('password',_0x384800),this['_email']=_0x96681f,this['_password']=_0x27c19e,this['_tenantId']=_0x1d45db;}static['_fromEmailAndPassword'](_0x3d5bb6,_0x4d6d85){return new $t(_0x3d5bb6,_0x4d6d85,'password');}static['_fromEmailAndCode'](_0x267f79,_0x555867,_0x27eb21=null){return new $t(_0x267f79,_0x555867,'emailLink',_0x27eb21);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x495030){const _0x1d37f7=typeof _0x495030=='string'?JSON['parse'](_0x495030):_0x495030;if(_0x1d37f7!=null&&_0x1d37f7['email']&&(_0x1d37f7!=null&&_0x1d37f7['password'])){if(_0x1d37f7['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1d37f7['email'],_0x1d37f7['password']);if(_0x1d37f7['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1d37f7['email'],_0x1d37f7['password'],_0x1d37f7['tenantId']);}return null;}async['_getIdTokenResponse'](_0x31b21b){switch(this['signInMethod']){case'password':const _0x3c64ff={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x31b21b,_0x3c64ff,'signInWithPassword',jf);case'emailLink':return Kf(_0x31b21b,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x31b21b,'internal-error');}}async['_linkToIdToken'](_0x465cf1,_0x27b6bb){switch(this['signInMethod']){case'password':const _0x5dfe44={'idToken':_0x27b6bb,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x465cf1,_0x5dfe44,'signUpPassword',zf);case'emailLink':return Yf(_0x465cf1,{'idToken':_0x27b6bb,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x465cf1,'internal-error');}}['_getReauthenticationResolver'](_0x2b46d9){return this['_getIdTokenResponse'](_0x2b46d9);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x4c4d3e,_0x23b4f1){return en(_0x4c4d3e,'POST','/v1/accounts:signInWithIdp',ke(_0x4c4d3e,_0x23b4f1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x35ce58){const _0x55af69=new $e(_0x35ce58['providerId'],_0x35ce58['signInMethod']);return _0x35ce58['idToken']||_0x35ce58['accessToken']?(_0x35ce58['idToken']&&(_0x55af69['idToken']=_0x35ce58['idToken']),_0x35ce58['accessToken']&&(_0x55af69['accessToken']=_0x35ce58['accessToken']),_0x35ce58['nonce']&&!_0x35ce58['pendingToken']&&(_0x55af69['nonce']=_0x35ce58['nonce']),_0x35ce58['pendingToken']&&(_0x55af69['pendingToken']=_0x35ce58['pendingToken'])):_0x35ce58['oauthToken']&&_0x35ce58['oauthTokenSecret']?(_0x55af69['accessToken']=_0x35ce58['oauthToken'],_0x55af69['secret']=_0x35ce58['oauthTokenSecret']):Y('argument-error'),_0x55af69;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xd93798){const _0x5b548b=typeof _0xd93798=='string'?JSON['parse'](_0xd93798):_0xd93798,{providerId:_0x3e66d1,signInMethod:_0x487554,..._0x1f09dc}=_0x5b548b;if(!_0x3e66d1||!_0x487554)return null;const _0x3ab8f8=new $e(_0x3e66d1,_0x487554);return _0x3ab8f8['idToken']=_0x1f09dc['idToken']||void 0x0,_0x3ab8f8['accessToken']=_0x1f09dc['accessToken']||void 0x0,_0x3ab8f8['secret']=_0x1f09dc['secret'],_0x3ab8f8['nonce']=_0x1f09dc['nonce'],_0x3ab8f8['pendingToken']=_0x1f09dc['pendingToken']||null,_0x3ab8f8;}['_getIdTokenResponse'](_0x285cfb){const _0x256acb=this['buildRequest']();return nt(_0x285cfb,_0x256acb);}['_linkToIdToken'](_0x4c0e98,_0x442b8f){const _0x324cd3=this['buildRequest']();return _0x324cd3['idToken']=_0x442b8f,nt(_0x4c0e98,_0x324cd3);}['_getReauthenticationResolver'](_0x2e3aa5){const _0x188a14=this['buildRequest']();return _0x188a14['autoCreate']=!0x1,nt(_0x2e3aa5,_0x188a14);}['buildRequest'](){const _0x47956e={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x47956e['pendingToken']=this['pendingToken'];else{const _0x1ff6d0={};this['idToken']&&(_0x1ff6d0['id_token']=this['idToken']),this['accessToken']&&(_0x1ff6d0['access_token']=this['accessToken']),this['secret']&&(_0x1ff6d0['oauth_token_secret']=this['secret']),_0x1ff6d0['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1ff6d0['nonce']=this['nonce']),_0x47956e['postBody']=ut(_0x1ff6d0);}return _0x47956e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2b459f){switch(_0x2b459f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x28e339){const _0x5b2a8e=Ct(Tt(_0x28e339))['link'],_0x5206b8=_0x5b2a8e?Ct(Tt(_0x5b2a8e))['deep_link_id']:null,_0xf10d2c=Ct(Tt(_0x28e339))['deep_link_id'];return(_0xf10d2c?Ct(Tt(_0xf10d2c))['link']:null)||_0xf10d2c||_0x5206b8||_0x5b2a8e||_0x28e339;}class Rs{constructor(_0x2e631){const _0x18ff15=Ct(Tt(_0x2e631)),_0x5987e5=_0x18ff15['apiKey']??null,_0x2a2cbe=_0x18ff15['oobCode']??null,_0x2264f1=Jf(_0x18ff15['mode']??null);m(_0x5987e5&&_0x2a2cbe&&_0x2264f1,'argument-error'),this['apiKey']=_0x5987e5,this['operation']=_0x2264f1,this['code']=_0x2a2cbe,this['continueUrl']=_0x18ff15['continueUrl']??null,this['languageCode']=_0x18ff15['lang']??null,this['tenantId']=_0x18ff15['tenantId']??null;}static['parseLink'](_0x7f0479){const _0x32a272=Xf(_0x7f0479);try{return new Rs(_0x32a272);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x226e42,_0x46d840){return $t['_fromEmailAndPassword'](_0x226e42,_0x46d840);}static['credentialWithLink'](_0x196658,_0x1b5bbb){const _0x29ca2e=Rs['parseLink'](_0x1b5bbb);return m(_0x29ca2e,'argument-error'),$t['_fromEmailAndCode'](_0x196658,_0x29ca2e['code'],_0x29ca2e['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x4ae16f){this['providerId']=_0x4ae16f,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x85370){this['defaultLanguageCode']=_0x85370;}['setCustomParameters'](_0x483324){return this['customParameters']=_0x483324,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x8128df){return this['scopes']['includes'](_0x8128df)||this['scopes']['push'](_0x8128df),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5beb0a){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5beb0a});}static['credentialFromResult'](_0x19e71a){return ue['credentialFromTaggedObject'](_0x19e71a);}static['credentialFromError'](_0x1f9de4){return ue['credentialFromTaggedObject'](_0x1f9de4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2d87c6}){if(!_0x2d87c6||!('oauthAccessToken'in _0x2d87c6)||!_0x2d87c6['oauthAccessToken'])return null;try{return ue['credential'](_0x2d87c6['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5e89d6,_0x490d64){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5e89d6,'accessToken':_0x490d64});}static['credentialFromResult'](_0x15e27c){return de['credentialFromTaggedObject'](_0x15e27c);}static['credentialFromError'](_0xb59579){return de['credentialFromTaggedObject'](_0xb59579['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x56cb82}){if(!_0x56cb82)return null;const {oauthIdToken:_0x3c99ca,oauthAccessToken:_0x1a622e}=_0x56cb82;if(!_0x3c99ca&&!_0x1a622e)return null;try{return de['credential'](_0x3c99ca,_0x1a622e);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0xd726d4){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0xd726d4});}static['credentialFromResult'](_0xd7c7ab){return fe['credentialFromTaggedObject'](_0xd7c7ab);}static['credentialFromError'](_0x3e28c5){return fe['credentialFromTaggedObject'](_0x3e28c5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1dd1b8}){if(!_0x1dd1b8||!('oauthAccessToken'in _0x1dd1b8)||!_0x1dd1b8['oauthAccessToken'])return null;try{return fe['credential'](_0x1dd1b8['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3c77a2,_0x4b6d7a){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3c77a2,'oauthTokenSecret':_0x4b6d7a});}static['credentialFromResult'](_0xb2c9e9){return pe['credentialFromTaggedObject'](_0xb2c9e9);}static['credentialFromError'](_0x2a1b74){return pe['credentialFromTaggedObject'](_0x2a1b74['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4feb1c}){if(!_0x4feb1c)return null;const {oauthAccessToken:_0x1bb98c,oauthTokenSecret:_0xfff93d}=_0x4feb1c;if(!_0x1bb98c||!_0xfff93d)return null;try{return pe['credential'](_0x1bb98c,_0xfff93d);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x466a50,_0x5afee1){return en(_0x466a50,'POST','/v1/accounts:signUp',ke(_0x466a50,_0x5afee1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x2adf57){this['user']=_0x2adf57['user'],this['providerId']=_0x2adf57['providerId'],this['_tokenResponse']=_0x2adf57['_tokenResponse'],this['operationType']=_0x2adf57['operationType'];}static async['_fromIdTokenResponse'](_0x304c12,_0x13337b,_0x4bdf77,_0x5f47fb=!0x1){const _0x24fc5f=await j['_fromIdTokenResponse'](_0x304c12,_0x4bdf77,_0x5f47fb),_0x29669c=Nr(_0x4bdf77);return new Ge({'user':_0x24fc5f,'providerId':_0x29669c,'_tokenResponse':_0x4bdf77,'operationType':_0x13337b});}static async['_forOperation'](_0xa33fe9,_0x3a1d9f,_0x2bb856){await _0xa33fe9['_updateTokensIfNecessary'](_0x2bb856,!0x0);const _0x412e72=Nr(_0x2bb856);return new Ge({'user':_0xa33fe9,'providerId':_0x412e72,'_tokenResponse':_0x2bb856,'operationType':_0x3a1d9f});}}function Nr(_0xe9701f){return _0xe9701f['providerId']?_0xe9701f['providerId']:'phoneNumber'in _0xe9701f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xbe4318,_0x3156e1,_0x1fadf2,_0x2b4d01){super(_0x3156e1['code'],_0x3156e1['message']),this['operationType']=_0x1fadf2,this['user']=_0x2b4d01,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xbe4318['name'],'tenantId':_0xbe4318['tenantId']??void 0x0,'_serverResponse':_0x3156e1['customData']['_serverResponse'],'operationType':_0x1fadf2};}static['_fromErrorAndOperation'](_0xf8a367,_0x33700b,_0xa59b1c,_0x48d758){return new On(_0xf8a367,_0x33700b,_0xa59b1c,_0x48d758);}}function Ba(_0x2b6631,_0xb556d3,_0x27d1c6,_0x3065ab){return(_0xb556d3==='reauthenticate'?_0x27d1c6['_getReauthenticationResolver'](_0x2b6631):_0x27d1c6['_getIdTokenResponse'](_0x2b6631))['catch'](_0x537b5f=>{throw _0x537b5f['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x2b6631,_0x537b5f,_0xb556d3,_0x3065ab):_0x537b5f;});}async function ep(_0x1a57d3,_0x13ea08,_0x4e31e6=!0x1){const _0xb098bf=await Ht(_0x1a57d3,_0x13ea08['_linkToIdToken'](_0x1a57d3['auth'],await _0x1a57d3['getIdToken']()),_0x4e31e6);return Ge['_forOperation'](_0x1a57d3,'link',_0xb098bf);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x4f5acb,_0x555a1a,_0x2110cd=!0x1){const {auth:_0x30340a}=_0x4f5acb;if($(_0x30340a['app']))return Promise['reject'](re(_0x30340a));const _0x19f32c='reauthenticate';try{const _0x12d389=await Ht(_0x4f5acb,Ba(_0x30340a,_0x19f32c,_0x555a1a,_0x4f5acb),_0x2110cd);m(_0x12d389['idToken'],_0x30340a,'internal-error');const _0x2bada1=Ts(_0x12d389['idToken']);m(_0x2bada1,_0x30340a,'internal-error');const {sub:_0x44699e}=_0x2bada1;return m(_0x4f5acb['uid']===_0x44699e,_0x30340a,'user-mismatch'),Ge['_forOperation'](_0x4f5acb,_0x19f32c,_0x12d389);}catch(_0x4ec59d){throw(_0x4ec59d==null?void 0x0:_0x4ec59d['code'])==='auth/user-not-found'&&Y(_0x30340a,'user-mismatch'),_0x4ec59d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x319280,_0x30862e,_0x3eecae=!0x1){if($(_0x319280['app']))return Promise['reject'](re(_0x319280));const _0x2b981b='signIn',_0x109ff8=await Ba(_0x319280,_0x2b981b,_0x30862e),_0x209902=await Ge['_fromIdTokenResponse'](_0x319280,_0x2b981b,_0x109ff8);return _0x3eecae||await _0x319280['_updateCurrentUser'](_0x209902['user']),_0x209902;}async function np(_0x5cef82,_0xdcce81){return Va(Ke(_0x5cef82),_0xdcce81);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x1fe1eb){const _0x4e90a8=Ke(_0x1fe1eb);_0x4e90a8['_getPasswordPolicyInternal']()&&await _0x4e90a8['_updatePasswordPolicy']();}async function L_(_0x4f623c,_0x31188f,_0x10f777){if($(_0x4f623c['app']))return Promise['reject'](re(_0x4f623c));const _0x599e6c=Ke(_0x4f623c),_0x22b056=await xi(_0x599e6c,{'returnSecureToken':!0x0,'email':_0x31188f,'password':_0x10f777,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x269b97=>{throw _0x269b97['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4f623c),_0x269b97;}),_0x1cfcb4=await Ge['_fromIdTokenResponse'](_0x599e6c,'signIn',_0x22b056);return await _0x599e6c['_updateCurrentUser'](_0x1cfcb4['user']),_0x1cfcb4;}function x_(_0x5a04d0,_0x2328c0,_0x43bbe7){return $(_0x5a04d0['app'])?Promise['reject'](re(_0x5a04d0)):np(P(_0x5a04d0),yt['credential'](_0x2328c0,_0x43bbe7))['catch'](async _0x3a819b=>{throw _0x3a819b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5a04d0),_0x3a819b;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x3ba810,_0x26201a){return P(_0x3ba810)['setPersistence'](_0x26201a);}function ip(_0x2b8b82,_0x5c7636,_0x5d667f,_0x3ba125){return P(_0x2b8b82)['onIdTokenChanged'](_0x5c7636,_0x5d667f,_0x3ba125);}function sp(_0x2119c7,_0x24787f,_0x4c3b12){return P(_0x2119c7)['beforeAuthStateChanged'](_0x24787f,_0x4c3b12);}function U_(_0x2ae126,_0x58769d,_0x4094a5,_0x442d3d){return P(_0x2ae126)['onAuthStateChanged'](_0x58769d,_0x4094a5,_0x442d3d);}function W_(_0x16db3e){return P(_0x16db3e)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x1b3d4e,_0x35bd46){this['storageRetriever']=_0x1b3d4e,this['type']=_0x35bd46;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x15aacd,_0x2b59e9){return this['storage']['setItem'](_0x15aacd,JSON['stringify'](_0x2b59e9)),Promise['resolve']();}['_get'](_0x1e889d){const _0x605787=this['storage']['getItem'](_0x1e889d);return Promise['resolve'](_0x605787?JSON['parse'](_0x605787):null);}['_remove'](_0x47b305){return this['storage']['removeItem'](_0x47b305),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5cf891,_0x49fe9f)=>this['onStorageEvent'](_0x5cf891,_0x49fe9f),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x47ed5b){for(const _0x144206 of Object['keys'](this['listeners'])){const _0x412a82=this['storage']['getItem'](_0x144206),_0x176e94=this['localCache'][_0x144206];_0x412a82!==_0x176e94&&_0x47ed5b(_0x144206,_0x176e94,_0x412a82);}}['onStorageEvent'](_0x3b5733,_0x2b9374=!0x1){if(!_0x3b5733['key']){this['forAllChangedKeys']((_0x5870e6,_0x5302e8,_0x487644)=>{this['notifyListeners'](_0x5870e6,_0x487644);});return;}const _0x35619e=_0x3b5733['key'];_0x2b9374?this['detachListener']():this['stopPolling']();const _0x5e3690=()=>{const _0x26da25=this['storage']['getItem'](_0x35619e);!_0x2b9374&&this['localCache'][_0x35619e]===_0x26da25||this['notifyListeners'](_0x35619e,_0x26da25);},_0x1151ca=this['storage']['getItem'](_0x35619e);Af()&&_0x1151ca!==_0x3b5733['newValue']&&_0x3b5733['newValue']!==_0x3b5733['oldValue']?setTimeout(_0x5e3690,op):_0x5e3690();}['notifyListeners'](_0x25692b,_0x16ed3d){this['localCache'][_0x25692b]=_0x16ed3d;const _0x34fddb=this['listeners'][_0x25692b];if(_0x34fddb){for(const _0x2376a1 of Array['from'](_0x34fddb))_0x2376a1(_0x16ed3d&&JSON['parse'](_0x16ed3d));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1f6d59,_0x5b113b,_0x330ebc)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1f6d59,'oldValue':_0x5b113b,'newValue':_0x330ebc}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4665ab,_0x171c8f){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4665ab]||(this['listeners'][_0x4665ab]=new Set(),this['localCache'][_0x4665ab]=this['storage']['getItem'](_0x4665ab)),this['listeners'][_0x4665ab]['add'](_0x171c8f);}['_removeListener'](_0x117cf6,_0x8b2519){this['listeners'][_0x117cf6]&&(this['listeners'][_0x117cf6]['delete'](_0x8b2519),this['listeners'][_0x117cf6]['size']===0x0&&delete this['listeners'][_0x117cf6]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x309807,_0x1c4ef6){await super['_set'](_0x309807,_0x1c4ef6),this['localCache'][_0x309807]=JSON['stringify'](_0x1c4ef6);}async['_get'](_0x34c595){const _0x124930=await super['_get'](_0x34c595);return this['localCache'][_0x34c595]=JSON['stringify'](_0x124930),_0x124930;}async['_remove'](_0x32b228){await super['_remove'](_0x32b228),delete this['localCache'][_0x32b228];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x20ef9a,_0x2a0f50){}['_removeListener'](_0x1b69f5,_0x20df36){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x102298){return Promise['all'](_0x102298['map'](async _0x1af236=>{try{return{'fulfilled':!0x0,'value':await _0x1af236};}catch(_0x19c5fd){return{'fulfilled':!0x1,'reason':_0x19c5fd};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4fc248){this['eventTarget']=_0x4fc248,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x35553c){const _0x32dafc=this['receivers']['find'](_0x192040=>_0x192040['isListeningto'](_0x35553c));if(_0x32dafc)return _0x32dafc;const _0x5d6ca8=new Xn(_0x35553c);return this['receivers']['push'](_0x5d6ca8),_0x5d6ca8;}['isListeningto'](_0x3d1794){return this['eventTarget']===_0x3d1794;}async['handleEvent'](_0x36494b){const _0x7f86a9=_0x36494b,{eventId:_0x56ed9b,eventType:_0x5d14b0,data:_0x3eb920}=_0x7f86a9['data'],_0x25d3dc=this['handlersMap'][_0x5d14b0];if(!(_0x25d3dc!=null&&_0x25d3dc['size']))return;_0x7f86a9['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x56ed9b,'eventType':_0x5d14b0});const _0x3c0811=Array['from'](_0x25d3dc)['map'](async _0x5a0a9c=>_0x5a0a9c(_0x7f86a9['origin'],_0x3eb920)),_0x3b65e0=await cp(_0x3c0811);_0x7f86a9['ports'][0x0]['postMessage']({'status':'done','eventId':_0x56ed9b,'eventType':_0x5d14b0,'response':_0x3b65e0});}['_subscribe'](_0x1b0a1b,_0x5845c0){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x1b0a1b]||(this['handlersMap'][_0x1b0a1b]=new Set()),this['handlersMap'][_0x1b0a1b]['add'](_0x5845c0);}['_unsubscribe'](_0xdf5a8e,_0x3ed175){this['handlersMap'][_0xdf5a8e]&&_0x3ed175&&this['handlersMap'][_0xdf5a8e]['delete'](_0x3ed175),(!_0x3ed175||this['handlersMap'][_0xdf5a8e]['size']===0x0)&&delete this['handlersMap'][_0xdf5a8e],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4c6773='',_0x3d13a1=0xa){let _0x89f387='';for(let _0x13163d=0x0;_0x13163d<_0x3d13a1;_0x13163d++)_0x89f387+=Math['floor'](Math['random']()*0xa);return _0x4c6773+_0x89f387;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x591513){this['target']=_0x591513,this['handlers']=new Set();}['removeMessageHandler'](_0x515d78){_0x515d78['messageChannel']&&(_0x515d78['messageChannel']['port1']['removeEventListener']('message',_0x515d78['onMessage']),_0x515d78['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x515d78);}async['_send'](_0x523df6,_0x3a2d93,_0x51ed8c=0x32){const _0x4ca911=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4ca911)throw new Error('connection_unavailable');let _0x2f9cbb,_0x174844;return new Promise((_0x413d92,_0x5e85a4)=>{const _0x4b0d10=As('',0x14);_0x4ca911['port1']['start']();const _0x382f69=setTimeout(()=>{_0x5e85a4(new Error('unsupported_event'));},_0x51ed8c);_0x174844={'messageChannel':_0x4ca911,'onMessage'(_0x159ae0){const _0x59febe=_0x159ae0;if(_0x59febe['data']['eventId']===_0x4b0d10)switch(_0x59febe['data']['status']){case'ack':clearTimeout(_0x382f69),_0x2f9cbb=setTimeout(()=>{_0x5e85a4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2f9cbb),_0x413d92(_0x59febe['data']['response']);break;default:clearTimeout(_0x382f69),clearTimeout(_0x2f9cbb),_0x5e85a4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x174844),_0x4ca911['port1']['addEventListener']('message',_0x174844['onMessage']),this['target']['postMessage']({'eventType':_0x523df6,'eventId':_0x4b0d10,'data':_0x3a2d93},[_0x4ca911['port2']]);})['finally'](()=>{_0x174844&&this['removeMessageHandler'](_0x174844);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x113a04){Z()['location']['href']=_0x113a04;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1f1569;return((_0x1f1569=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1f1569['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x171859){this['request']=_0x171859;}['toPromise'](){return new Promise((_0x4bf640,_0xda41bd)=>{this['request']['addEventListener']('success',()=>{_0x4bf640(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xda41bd(this['request']['error']);});});}}function Zn(_0x3f7c6f,_0x1f0e6d){return _0x3f7c6f['transaction']([Mn],_0x1f0e6d?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x4824b6=indexedDB['deleteDatabase'](Ka);return new nn(_0x4824b6)['toPromise']();}function Qa(){const _0x38c37a=indexedDB['open'](Ka,pp);return new Promise((_0x3a4f7f,_0x4a6fc7)=>{_0x38c37a['addEventListener']('error',()=>{_0x4a6fc7(_0x38c37a['error']);}),_0x38c37a['addEventListener']('upgradeneeded',()=>{const _0x42a3d6=_0x38c37a['result'];try{_0x42a3d6['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3a8469){_0x4a6fc7(_0x3a8469);}}),_0x38c37a['addEventListener']('success',async()=>{const _0x360cad=_0x38c37a['result'];_0x360cad['objectStoreNames']['contains'](Mn)?_0x3a4f7f(_0x360cad):(_0x360cad['close'](),await _p(),_0x3a4f7f(await Qa()));});});}async function Or(_0x17a89e,_0x25ce16,_0x2af31d){const _0x4bd15f=Zn(_0x17a89e,!0x0)['put']({[Ya]:_0x25ce16,'value':_0x2af31d});return new nn(_0x4bd15f)['toPromise']();}async function gp(_0x3384a0,_0x154b85){const _0x5b9e2d=Zn(_0x3384a0,!0x1)['get'](_0x154b85),_0x56e9e4=await new nn(_0x5b9e2d)['toPromise']();return _0x56e9e4===void 0x0?null:_0x56e9e4['value'];}function Dr(_0x17fccf,_0xad5955){const _0x527b6e=Zn(_0x17fccf,!0x0)['delete'](_0xad5955);return new nn(_0x527b6e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x39979d){let _0x2c4258=0x0;for(;;)try{const _0x12dc5d=await this['_openDb']();return await _0x39979d(_0x12dc5d);}catch(_0x4eeb1e){if(_0x2c4258++>yp)throw _0x4eeb1e;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2a22dc,_0x174488)=>({'keyProcessed':(await this['_poll']())['includes'](_0x174488['key'])})),this['receiver']['_subscribe']('ping',async(_0x173a16,_0x1a2dc0)=>['keyChanged']);}async['initializeSender'](){var _0x8502b3,_0x319f7d;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x1fce92=await this['sender']['_send']('ping',{},0x320);_0x1fce92&&(_0x8502b3=_0x1fce92[0x0])!=null&&_0x8502b3['fulfilled']&&(_0x319f7d=_0x1fce92[0x0])!=null&&_0x319f7d['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1a550e){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1a550e},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x678fa4=>{await Or(_0x678fa4,Dn,'1'),await Dr(_0x678fa4,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x26ba9f){this['pendingWrites']++;try{await _0x26ba9f();}finally{this['pendingWrites']--;}}async['_set'](_0x190b85,_0x252c25){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4fa4ac=>Or(_0x4fa4ac,_0x190b85,_0x252c25)),this['localCache'][_0x190b85]=_0x252c25,this['notifyServiceWorker'](_0x190b85)));}async['_get'](_0x2b55b9){const _0xa299e7=await this['_withRetries'](_0x28bfae=>gp(_0x28bfae,_0x2b55b9));return this['localCache'][_0x2b55b9]=_0xa299e7,_0xa299e7;}async['_remove'](_0x7dbf72){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2f4010=>Dr(_0x2f4010,_0x7dbf72)),delete this['localCache'][_0x7dbf72],this['notifyServiceWorker'](_0x7dbf72)));}async['_poll'](){const _0x1a9e21=await this['_withRetries'](_0x16d092=>{const _0x5b0a21=Zn(_0x16d092,!0x1)['getAll']();return new nn(_0x5b0a21)['toPromise']();});if(!_0x1a9e21)return[];if(this['pendingWrites']!==0x0)return[];const _0x55de12=[],_0x5002bb=new Set();if(_0x1a9e21['length']!==0x0){for(const {fbase_key:_0x1a60da,value:_0x49136d}of _0x1a9e21)_0x5002bb['add'](_0x1a60da),JSON['stringify'](this['localCache'][_0x1a60da])!==JSON['stringify'](_0x49136d)&&(this['notifyListeners'](_0x1a60da,_0x49136d),_0x55de12['push'](_0x1a60da));}for(const _0x2a3d2a of Object['keys'](this['localCache']))this['localCache'][_0x2a3d2a]&&!_0x5002bb['has'](_0x2a3d2a)&&(this['notifyListeners'](_0x2a3d2a,null),_0x55de12['push'](_0x2a3d2a));return _0x55de12;}['notifyListeners'](_0x2a34ec,_0x360f85){this['localCache'][_0x2a34ec]=_0x360f85;const _0x1a1cbb=this['listeners'][_0x2a34ec];if(_0x1a1cbb){for(const _0x4e99b7 of Array['from'](_0x1a1cbb))_0x4e99b7(_0x360f85);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5f4cbe,_0x5a97ba){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5f4cbe]||(this['listeners'][_0x5f4cbe]=new Set(),this['_get'](_0x5f4cbe)),this['listeners'][_0x5f4cbe]['add'](_0x5a97ba);}['_removeListener'](_0x9375e1,_0x2ac327){this['listeners'][_0x9375e1]&&(this['listeners'][_0x9375e1]['delete'](_0x2ac327),this['listeners'][_0x9375e1]['size']===0x0&&delete this['listeners'][_0x9375e1]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x26b31c,_0xf44b97){return _0xf44b97?ie(_0xf44b97):(m(_0x26b31c['_popupRedirectResolver'],_0x26b31c,'argument-error'),_0x26b31c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x551cdf){super('custom','custom'),this['params']=_0x551cdf;}['_getIdTokenResponse'](_0x7f92ef){return nt(_0x7f92ef,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5a87ee,_0x8d42b9){return nt(_0x5a87ee,this['_buildIdpRequest'](_0x8d42b9));}['_getReauthenticationResolver'](_0x43a21a){return nt(_0x43a21a,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3a16b0){const _0x376f30={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3a16b0&&(_0x376f30['idToken']=_0x3a16b0),_0x376f30;}}function Ip(_0x1f8157){return Va(_0x1f8157['auth'],new ks(_0x1f8157),_0x1f8157['bypassAuthState']);}function wp(_0x2a07b2){const {auth:_0x47be5c,user:_0x532070}=_0x2a07b2;return m(_0x532070,_0x47be5c,'internal-error'),tp(_0x532070,new ks(_0x2a07b2),_0x2a07b2['bypassAuthState']);}async function Cp(_0x38e748){const {auth:_0xf5f7bb,user:_0x8654a1}=_0x38e748;return m(_0x8654a1,_0xf5f7bb,'internal-error'),ep(_0x8654a1,new ks(_0x38e748),_0x38e748['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x47e5ba,_0x13a226,_0x2a17be,_0x3696d7,_0x53923d=!0x1){this['auth']=_0x47e5ba,this['resolver']=_0x2a17be,this['user']=_0x3696d7,this['bypassAuthState']=_0x53923d,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x13a226)?_0x13a226:[_0x13a226];}['execute'](){return new Promise(async(_0x387f49,_0x2ceb7c)=>{this['pendingPromise']={'resolve':_0x387f49,'reject':_0x2ceb7c};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1a7ab2){this['reject'](_0x1a7ab2);}});}async['onAuthEvent'](_0x19b189){const {urlResponse:_0x29097c,sessionId:_0x5adf4f,postBody:_0x3ec62b,tenantId:_0x10c4bb,error:_0x362789,type:_0x20fc90}=_0x19b189;if(_0x362789){this['reject'](_0x362789);return;}const _0x3a37b0={'auth':this['auth'],'requestUri':_0x29097c,'sessionId':_0x5adf4f,'tenantId':_0x10c4bb||void 0x0,'postBody':_0x3ec62b||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x20fc90)(_0x3a37b0));}catch(_0x2a3565){this['reject'](_0x2a3565);}}['onError'](_0x3080ca){this['reject'](_0x3080ca);}['getIdpTask'](_0x9c0832){switch(_0x9c0832){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x48dfad){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x48dfad),this['unregisterAndCleanUp']();}['reject'](_0x83530b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x83530b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0xa49bf8,_0x4eb208,_0x4eeb34,_0x335aba,_0x455b70){super(_0xa49bf8,_0x4eb208,_0x335aba,_0x455b70),this['provider']=_0x4eeb34,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x12ca7d=await this['execute']();return m(_0x12ca7d,this['auth'],'internal-error'),_0x12ca7d;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3d660c=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3d660c),this['authWindow']['associatedEvent']=_0x3d660c,this['resolver']['_originValidation'](this['auth'])['catch'](_0x414346=>{this['reject'](_0x414346);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x405e22=>{_0x405e22||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x424db1;return((_0x424db1=this['authWindow'])==null?void 0x0:_0x424db1['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2d77b5=()=>{var _0x184036,_0x443239;if((_0x443239=(_0x184036=this['authWindow'])==null?void 0x0:_0x184036['window'])!=null&&_0x443239['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2d77b5,Tp['get']());};_0x2d77b5();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x46051c,_0x45ce0c,_0x4bd4a8=!0x1){super(_0x46051c,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x45ce0c,void 0x0,_0x4bd4a8),this['eventId']=null;}async['execute'](){let _0x50e24c=hn['get'](this['auth']['_key']());if(!_0x50e24c){try{const _0xd5ffdf=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x50e24c=()=>Promise['resolve'](_0xd5ffdf);}catch(_0x2085de){_0x50e24c=()=>Promise['reject'](_0x2085de);}hn['set'](this['auth']['_key'](),_0x50e24c);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x50e24c();}async['onAuthEvent'](_0x46cada){if(_0x46cada['type']==='signInViaRedirect')return super['onAuthEvent'](_0x46cada);if(_0x46cada['type']==='unknown'){this['resolve'](null);return;}if(_0x46cada['eventId']){const _0x534310=await this['auth']['_redirectUserForId'](_0x46cada['eventId']);if(_0x534310)return this['user']=_0x534310,super['onAuthEvent'](_0x46cada);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x25895c,_0xb03f69){const _0x2c17ca=Pp(_0xb03f69),_0x417d89=kp(_0x25895c);if(!await _0x417d89['_isAvailable']())return!0x1;const _0x582420=await _0x417d89['_get'](_0x2c17ca)==='true';return await _0x417d89['_remove'](_0x2c17ca),_0x582420;}function Ap(_0x2a8129,_0x32e8a5){hn['set'](_0x2a8129['_key'](),_0x32e8a5);}function kp(_0x498a2a){return ie(_0x498a2a['_redirectPersistence']);}function Pp(_0x128697){return ln(Sp,_0x128697['config']['apiKey'],_0x128697['name']);}async function Np(_0x4a2aa0,_0x2ec8cc,_0x334af6=!0x1){if($(_0x4a2aa0['app']))return Promise['reject'](re(_0x4a2aa0));const _0x34afa7=Ke(_0x4a2aa0),_0x4545ff=Ep(_0x34afa7,_0x2ec8cc),_0x25a71d=await new bp(_0x34afa7,_0x4545ff,_0x334af6)['execute']();return _0x25a71d&&!_0x334af6&&(delete _0x25a71d['user']['_redirectEventId'],await _0x34afa7['_persistUserIfCurrent'](_0x25a71d['user']),await _0x34afa7['_setRedirectUser'](null,_0x2ec8cc)),_0x25a71d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x1f96b6){this['auth']=_0x1f96b6,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3ad346){this['consumers']['add'](_0x3ad346),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3ad346)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3ad346),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x59c8e6){this['consumers']['delete'](_0x59c8e6);}['onEvent'](_0x43ebac){if(this['hasEventBeenHandled'](_0x43ebac))return!0x1;let _0x229a75=!0x1;return this['consumers']['forEach'](_0x3f6eaa=>{this['isEventForConsumer'](_0x43ebac,_0x3f6eaa)&&(_0x229a75=!0x0,this['sendToConsumer'](_0x43ebac,_0x3f6eaa),this['saveEventToCache'](_0x43ebac));}),this['hasHandledPotentialRedirect']||!Mp(_0x43ebac)||(this['hasHandledPotentialRedirect']=!0x0,_0x229a75||(this['queuedRedirectEvent']=_0x43ebac,_0x229a75=!0x0)),_0x229a75;}['sendToConsumer'](_0x205094,_0x943a9c){var _0x468536;if(_0x205094['error']&&!Za(_0x205094)){const _0x1208d1=((_0x468536=_0x205094['error']['code'])==null?void 0x0:_0x468536['split']('auth/')[0x1])||'internal-error';_0x943a9c['onError'](X(this['auth'],_0x1208d1));}else _0x943a9c['onAuthEvent'](_0x205094);}['isEventForConsumer'](_0xf87788,_0x30d2ea){const _0x350ca5=_0x30d2ea['eventId']===null||!!_0xf87788['eventId']&&_0xf87788['eventId']===_0x30d2ea['eventId'];return _0x30d2ea['filter']['includes'](_0xf87788['type'])&&_0x350ca5;}['hasEventBeenHandled'](_0x3fd396){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x3fd396));}['saveEventToCache'](_0x4c1ad3){this['cachedEventUids']['add'](Mr(_0x4c1ad3)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x57b559){return[_0x57b559['type'],_0x57b559['eventId'],_0x57b559['sessionId'],_0x57b559['tenantId']]['filter'](_0x5cfabc=>_0x5cfabc)['join']('-');}function Za({type:_0x479c4d,error:_0x2f9bc3}){return _0x479c4d==='unknown'&&(_0x2f9bc3==null?void 0x0:_0x2f9bc3['code'])==='auth/no-auth-event';}function Mp(_0x2d8425){switch(_0x2d8425['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x2d8425);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x15dfda,_0x333af8={}){return Pe(_0x15dfda,'GET','/v1/projects',_0x333af8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x102243){if(_0x102243['config']['emulator'])return;const {authorizedDomains:_0x5d8833}=await Lp(_0x102243);for(const _0xb9182c of _0x5d8833)try{if(Wp(_0xb9182c))return;}catch{}Y(_0x102243,'unauthorized-domain');}function Wp(_0x1cd6e6){const _0x52cf72=Mi(),{protocol:_0x19cf5c,hostname:_0x2e5fa3}=new URL(_0x52cf72);if(_0x1cd6e6['startsWith']('chrome-extension://')){const _0x1372f4=new URL(_0x1cd6e6);return _0x1372f4['hostname']===''&&_0x2e5fa3===''?_0x19cf5c==='chrome-extension:'&&_0x1cd6e6['replace']('chrome-extension://','')===_0x52cf72['replace']('chrome-extension://',''):_0x19cf5c==='chrome-extension:'&&_0x1372f4['hostname']===_0x2e5fa3;}if(!Fp['test'](_0x19cf5c))return!0x1;if(xp['test'](_0x1cd6e6))return _0x2e5fa3===_0x1cd6e6;const _0x14620a=_0x1cd6e6['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x14620a+'|'+_0x14620a+')$','i')['test'](_0x2e5fa3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x50cb16=Z()['___jsl'];if(_0x50cb16!=null&&_0x50cb16['H']){for(const _0x543629 of Object['keys'](_0x50cb16['H']))if(_0x50cb16['H'][_0x543629]['r']=_0x50cb16['H'][_0x543629]['r']||[],_0x50cb16['H'][_0x543629]['L']=_0x50cb16['H'][_0x543629]['L']||[],_0x50cb16['H'][_0x543629]['r']=[..._0x50cb16['H'][_0x543629]['L']],_0x50cb16['CP']){for(let _0x2c79f6=0x0;_0x2c79f6<_0x50cb16['CP']['length'];_0x2c79f6++)_0x50cb16['CP'][_0x2c79f6]=null;}}}function Vp(_0x2baa67){return new Promise((_0x4744d9,_0x33b506)=>{var _0x5a7e57,_0xd003cf,_0x11a837;function _0xa984c0(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4744d9(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x33b506(X(_0x2baa67,'network-request-failed'));},'timeout':Bp['get']()});}if((_0xd003cf=(_0x5a7e57=Z()['gapi'])==null?void 0x0:_0x5a7e57['iframes'])!=null&&_0xd003cf['Iframe'])_0x4744d9(gapi['iframes']['getContext']());else{if((_0x11a837=Z()['gapi'])!=null&&_0x11a837['load'])_0xa984c0();else{const _0x34b3d5=Ff('iframefcb');return Z()[_0x34b3d5]=()=>{gapi['load']?_0xa984c0():_0x33b506(X(_0x2baa67,'network-request-failed'));},xa(xf()+'?onload='+_0x34b3d5)['catch'](_0x194527=>_0x33b506(_0x194527));}}})['catch'](_0x55daf5=>{throw un=null,_0x55daf5;});}let un=null;function Hp(_0x41d1da){return un=un||Vp(_0x41d1da),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x4bbebe){const _0x38ff09=_0x4bbebe['config'];m(_0x38ff09['authDomain'],_0x4bbebe,'auth-domain-config-required');const _0x1fc5cf=_0x38ff09['emulator']?Cs(_0x38ff09,qp):'https://'+_0x4bbebe['config']['authDomain']+'/'+Gp,_0x5ff1db={'apiKey':_0x38ff09['apiKey'],'appName':_0x4bbebe['name'],'v':dt},_0x4852a3=jp['get'](_0x4bbebe['config']['apiHost']);_0x4852a3&&(_0x5ff1db['eid']=_0x4852a3);const _0x51f4ee=_0x4bbebe['_getFrameworks']();return _0x51f4ee['length']&&(_0x5ff1db['fw']=_0x51f4ee['join'](',')),_0x1fc5cf+'?'+ut(_0x5ff1db)['slice'](0x1);}async function Yp(_0x4ffc0b){const _0x3f36af=await Hp(_0x4ffc0b),_0x2e9985=Z()['gapi'];return m(_0x2e9985,_0x4ffc0b,'internal-error'),_0x3f36af['open']({'where':document['body'],'url':Kp(_0x4ffc0b),'messageHandlersFilter':_0x2e9985['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x57afa7=>new Promise(async(_0x54c641,_0x58809f)=>{await _0x57afa7['restyle']({'setHideOnLeave':!0x1});const _0x3573ad=X(_0x4ffc0b,'network-request-failed'),_0x234f8a=Z()['setTimeout'](()=>{_0x58809f(_0x3573ad);},$p['get']());function _0x1979ec(){Z()['clearTimeout'](_0x234f8a),_0x54c641(_0x57afa7);}_0x57afa7['ping'](_0x1979ec)['then'](_0x1979ec,()=>{_0x58809f(_0x3573ad);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x20c99e){this['window']=_0x20c99e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x2b5134,_0x47dab6,_0x563627,_0x421597=Jp,_0x410310=Xp){const _0x1020b5=Math['max']((window['screen']['availHeight']-_0x410310)/0x2,0x0)['toString'](),_0x3e0638=Math['max']((window['screen']['availWidth']-_0x421597)/0x2,0x0)['toString']();let _0x20734e='';const _0x33363d={...Qp,'width':_0x421597['toString'](),'height':_0x410310['toString'](),'top':_0x1020b5,'left':_0x3e0638},_0xd38f17=W()['toLowerCase']();_0x563627&&(_0x20734e=ka(_0xd38f17)?Zp:_0x563627),Ra(_0xd38f17)&&(_0x47dab6=_0x47dab6||e_,_0x33363d['scrollbars']='yes');const _0x372e7a=Object['entries'](_0x33363d)['reduce']((_0x1ee320,[_0x1ac5d1,_0x3aedd8])=>''+_0x1ee320+_0x1ac5d1+'='+_0x3aedd8+',','');if(Rf(_0xd38f17)&&_0x20734e!=='_self')return n_(_0x47dab6||'',_0x20734e),new xr(null);const _0x16006f=window['open'](_0x47dab6||'',_0x20734e,_0x372e7a);m(_0x16006f,_0x2b5134,'popup-blocked');try{_0x16006f['focus']();}catch{}return new xr(_0x16006f);}function n_(_0x23c7e7,_0x50b285){const _0x2e8835=document['createElement']('a');_0x2e8835['href']=_0x23c7e7,_0x2e8835['target']=_0x50b285;const _0xc16175=document['createEvent']('MouseEvent');_0xc16175['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x2e8835['dispatchEvent'](_0xc16175);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x53a67e,_0x30018d,_0x2a97dc,_0x560c5d,_0x1ec047,_0x573c49){m(_0x53a67e['config']['authDomain'],_0x53a67e,'auth-domain-config-required'),m(_0x53a67e['config']['apiKey'],_0x53a67e,'invalid-api-key');const _0x26e52b={'apiKey':_0x53a67e['config']['apiKey'],'appName':_0x53a67e['name'],'authType':_0x2a97dc,'redirectUrl':_0x560c5d,'v':dt,'eventId':_0x1ec047};if(_0x30018d instanceof Wa){_0x30018d['setDefaultLanguage'](_0x53a67e['languageCode']),_0x26e52b['providerId']=_0x30018d['providerId']||'',pn(_0x30018d['getCustomParameters']())||(_0x26e52b['customParameters']=JSON['stringify'](_0x30018d['getCustomParameters']()));for(const [_0x473e50,_0x205a38]of Object['entries']({}))_0x26e52b[_0x473e50]=_0x205a38;}if(_0x30018d instanceof tn){const _0x5e0e2f=_0x30018d['getScopes']()['filter'](_0x41d4ba=>_0x41d4ba!=='');_0x5e0e2f['length']>0x0&&(_0x26e52b['scopes']=_0x5e0e2f['join'](','));}_0x53a67e['tenantId']&&(_0x26e52b['tid']=_0x53a67e['tenantId']);const _0x4bfb58=_0x26e52b;for(const _0x5d95a5 of Object['keys'](_0x4bfb58))_0x4bfb58[_0x5d95a5]===void 0x0&&delete _0x4bfb58[_0x5d95a5];const _0x524cef=await _0x53a67e['_getAppCheckToken'](),_0x9c35a8=_0x524cef?'#'+r_+'='+encodeURIComponent(_0x524cef):'';return o_(_0x53a67e)+'?'+ut(_0x4bfb58)['slice'](0x1)+_0x9c35a8;}function o_({config:_0x5aebc1}){return _0x5aebc1['emulator']?Cs(_0x5aebc1,s_):'https://'+_0x5aebc1['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x321ab4,_0x23b1a3,_0x315963,_0x16e33c){var _0x25dd4b;ce((_0x25dd4b=this['eventManagers'][_0x321ab4['_key']()])==null?void 0x0:_0x25dd4b['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x261908=await Fr(_0x321ab4,_0x23b1a3,_0x315963,Mi(),_0x16e33c);return t_(_0x321ab4,_0x261908,As());}async['_openRedirect'](_0x594d22,_0x413564,_0x3e46d,_0x356f45){await this['_originValidation'](_0x594d22);const _0x5e3e95=await Fr(_0x594d22,_0x413564,_0x3e46d,Mi(),_0x356f45);return hp(_0x5e3e95),new Promise(()=>{});}['_initialize'](_0x4328ea){const _0x1a4acf=_0x4328ea['_key']();if(this['eventManagers'][_0x1a4acf]){const {manager:_0x45c855,promise:_0x5c23b5}=this['eventManagers'][_0x1a4acf];return _0x45c855?Promise['resolve'](_0x45c855):(ce(_0x5c23b5,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5c23b5);}const _0x1fda7b=this['initAndGetManager'](_0x4328ea);return this['eventManagers'][_0x1a4acf]={'promise':_0x1fda7b},_0x1fda7b['catch'](()=>{delete this['eventManagers'][_0x1a4acf];}),_0x1fda7b;}async['initAndGetManager'](_0x184231){const _0x28ac87=await Yp(_0x184231),_0x422529=new Dp(_0x184231);return _0x28ac87['register']('authEvent',_0x1a027f=>(m(_0x1a027f==null?void 0x0:_0x1a027f['authEvent'],_0x184231,'invalid-auth-event'),{'status':_0x422529['onEvent'](_0x1a027f['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x184231['_key']()]={'manager':_0x422529},this['iframes'][_0x184231['_key']()]=_0x28ac87,_0x422529;}['_isIframeWebStorageSupported'](_0x50625b,_0x115702){this['iframes'][_0x50625b['_key']()]['send'](pi,{'type':pi},_0x2438c9=>{var _0x230808;const _0x37a6d3=(_0x230808=_0x2438c9==null?void 0x0:_0x2438c9[0x0])==null?void 0x0:_0x230808[pi];_0x37a6d3!==void 0x0&&_0x115702(!!_0x37a6d3),Y(_0x50625b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5c6675){const _0x44d780=_0x5c6675['_key']();return this['originValidationPromises'][_0x44d780]||(this['originValidationPromises'][_0x44d780]=Up(_0x5c6675)),this['originValidationPromises'][_0x44d780];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x2e89e5){this['auth']=_0x2e89e5,this['internalListeners']=new Map();}['getUid'](){var _0x44c2db;return this['assertAuthConfigured'](),((_0x44c2db=this['auth']['currentUser'])==null?void 0x0:_0x44c2db['uid'])||null;}async['getToken'](_0x33c1a5){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x33c1a5)}:null;}['addAuthTokenListener'](_0x465237){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x465237))return;const _0x28ac9e=this['auth']['onIdTokenChanged'](_0xf1ac1=>{_0x465237((_0xf1ac1==null?void 0x0:_0xf1ac1['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x465237,_0x28ac9e),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xf0cb04){this['assertAuthConfigured']();const _0x305f9a=this['internalListeners']['get'](_0xf0cb04);_0x305f9a&&(this['internalListeners']['delete'](_0xf0cb04),_0x305f9a(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x4ea8dc){switch(_0x4ea8dc){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4933a9){st(new Fe('auth',(_0x112561,{options:_0x5692e8})=>{const _0xf06151=_0x112561['getProvider']('app')['getImmediate'](),_0x19124d=_0x112561['getProvider']('heartbeat'),_0x685b22=_0x112561['getProvider']('app-check-internal'),{apiKey:_0x2e0b84,authDomain:_0x4042b1}=_0xf06151['options'];m(_0x2e0b84&&!_0x2e0b84['includes'](':'),'invalid-api-key',{'appName':_0xf06151['name']});const _0x1892bb={'apiKey':_0x2e0b84,'authDomain':_0x4042b1,'clientPlatform':_0x4933a9,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4933a9)},_0x4b70d4=new Df(_0xf06151,_0x19124d,_0x685b22,_0x1892bb);return Hf(_0x4b70d4,_0x5692e8),_0x4b70d4;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x5bd39d,_0x2a884a,_0x461b24)=>{_0x5bd39d['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x3fdfcf=>{const _0x3692c4=Ke(_0x3fdfcf['getProvider']('auth')['getImmediate']());return(_0x553540=>new l_(_0x553540))(_0x3692c4);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4933a9)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x24c197=>async _0x2c54a1=>{const _0x5267ee=_0x2c54a1&&await _0x2c54a1['getIdTokenResult'](),_0x1af99a=_0x5267ee&&(new Date()['getTime']()-Date['parse'](_0x5267ee['issuedAtTime']))/0x3e8;if(_0x1af99a&&_0x1af99a>f_)return;const _0x2be026=_0x5267ee==null?void 0x0:_0x5267ee['token'];Br!==_0x2be026&&(Br=_0x2be026,await fetch(_0x24c197,{'method':_0x2be026?'POST':'DELETE','headers':_0x2be026?{'Authorization':'Bearer\x20'+_0x2be026}:{}}));};function B_(_0x12a315=Zr()){const _0x2875b3=Hi(_0x12a315,'auth');if(_0x2875b3['isInitialized']())return _0x2875b3['getImmediate']();const _0x222bf7=Vf(_0x12a315,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x22c7d6=jr('authTokenSyncURL');if(_0x22c7d6&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1f4c35=new URL(_0x22c7d6,location['origin']);if(location['origin']===_0x1f4c35['origin']){const _0x187b64=p_(_0x1f4c35['toString']());sp(_0x222bf7,_0x187b64,()=>_0x187b64(_0x222bf7['currentUser'])),ip(_0x222bf7,_0x43ba61=>_0x187b64(_0x43ba61));}}const _0x4964ad=qr('auth');return _0x4964ad&&$f(_0x222bf7,'http://'+_0x4964ad),_0x222bf7;}function __(){var _0x340119;return((_0x340119=document['getElementsByTagName']('head'))==null?void 0x0:_0x340119[0x0])??document;}Mf({'loadJS'(_0x249c54){return new Promise((_0x45028e,_0x3612cb)=>{const _0x5231e1=document['createElement']('script');_0x5231e1['setAttribute']('src',_0x249c54),_0x5231e1['onload']=_0x45028e,_0x5231e1['onerror']=_0x1c8913=>{const _0x103846=X('internal-error');_0x103846['customData']=_0x1c8913,_0x3612cb(_0x103846);},_0x5231e1['type']='text/javascript',_0x5231e1['charset']='UTF-8',__()['appendChild'](_0x5231e1);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};