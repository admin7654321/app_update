const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5bd860,_0xf9ea31){if(!_0x5bd860)throw ht(_0xf9ea31);},ht=function(_0x12ac63){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x12ac63);},Hr=function(_0x431737){const _0x2405b8=[];let _0x50ca3f=0x0;for(let _0x48b2f3=0x0;_0x48b2f3<_0x431737['length'];_0x48b2f3++){let _0x2459ed=_0x431737['charCodeAt'](_0x48b2f3);_0x2459ed<0x80?_0x2405b8[_0x50ca3f++]=_0x2459ed:_0x2459ed<0x800?(_0x2405b8[_0x50ca3f++]=_0x2459ed>>0x6|0xc0,_0x2405b8[_0x50ca3f++]=_0x2459ed&0x3f|0x80):(_0x2459ed&0xfc00)===0xd800&&_0x48b2f3+0x1<_0x431737['length']&&(_0x431737['charCodeAt'](_0x48b2f3+0x1)&0xfc00)===0xdc00?(_0x2459ed=0x10000+((_0x2459ed&0x3ff)<<0xa)+(_0x431737['charCodeAt'](++_0x48b2f3)&0x3ff),_0x2405b8[_0x50ca3f++]=_0x2459ed>>0x12|0xf0,_0x2405b8[_0x50ca3f++]=_0x2459ed>>0xc&0x3f|0x80,_0x2405b8[_0x50ca3f++]=_0x2459ed>>0x6&0x3f|0x80,_0x2405b8[_0x50ca3f++]=_0x2459ed&0x3f|0x80):(_0x2405b8[_0x50ca3f++]=_0x2459ed>>0xc|0xe0,_0x2405b8[_0x50ca3f++]=_0x2459ed>>0x6&0x3f|0x80,_0x2405b8[_0x50ca3f++]=_0x2459ed&0x3f|0x80);}return _0x2405b8;},nc=function(_0x47d91c){const _0x40dcc5=[];let _0x46995e=0x0,_0x111bb9=0x0;for(;_0x46995e<_0x47d91c['length'];){const _0xbdebff=_0x47d91c[_0x46995e++];if(_0xbdebff<0x80)_0x40dcc5[_0x111bb9++]=String['fromCharCode'](_0xbdebff);else{if(_0xbdebff>0xbf&&_0xbdebff<0xe0){const _0x499cdd=_0x47d91c[_0x46995e++];_0x40dcc5[_0x111bb9++]=String['fromCharCode']((_0xbdebff&0x1f)<<0x6|_0x499cdd&0x3f);}else{if(_0xbdebff>0xef&&_0xbdebff<0x16d){const _0x28c23b=_0x47d91c[_0x46995e++],_0x9fc24c=_0x47d91c[_0x46995e++],_0x5f180c=_0x47d91c[_0x46995e++],_0x182c17=((_0xbdebff&0x7)<<0x12|(_0x28c23b&0x3f)<<0xc|(_0x9fc24c&0x3f)<<0x6|_0x5f180c&0x3f)-0x10000;_0x40dcc5[_0x111bb9++]=String['fromCharCode'](0xd800+(_0x182c17>>0xa)),_0x40dcc5[_0x111bb9++]=String['fromCharCode'](0xdc00+(_0x182c17&0x3ff));}else{const _0x2051cd=_0x47d91c[_0x46995e++],_0x16bae3=_0x47d91c[_0x46995e++];_0x40dcc5[_0x111bb9++]=String['fromCharCode']((_0xbdebff&0xf)<<0xc|(_0x2051cd&0x3f)<<0x6|_0x16bae3&0x3f);}}}}return _0x40dcc5['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x57a822,_0x5cf19f){if(!Array['isArray'](_0x57a822))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x137814=_0x5cf19f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x11cb34=[];for(let _0x38ec66=0x0;_0x38ec66<_0x57a822['length'];_0x38ec66+=0x3){const _0x4453c8=_0x57a822[_0x38ec66],_0x3f4483=_0x38ec66+0x1<_0x57a822['length'],_0x54bb6b=_0x3f4483?_0x57a822[_0x38ec66+0x1]:0x0,_0x54735f=_0x38ec66+0x2<_0x57a822['length'],_0x539388=_0x54735f?_0x57a822[_0x38ec66+0x2]:0x0,_0x259426=_0x4453c8>>0x2,_0x97a736=(_0x4453c8&0x3)<<0x4|_0x54bb6b>>0x4;let _0x14108f=(_0x54bb6b&0xf)<<0x2|_0x539388>>0x6,_0x4258cf=_0x539388&0x3f;_0x54735f||(_0x4258cf=0x40,_0x3f4483||(_0x14108f=0x40)),_0x11cb34['push'](_0x137814[_0x259426],_0x137814[_0x97a736],_0x137814[_0x14108f],_0x137814[_0x4258cf]);}return _0x11cb34['join']('');},'encodeString'(_0x576460,_0xb6d019){return this['HAS_NATIVE_SUPPORT']&&!_0xb6d019?btoa(_0x576460):this['encodeByteArray'](Hr(_0x576460),_0xb6d019);},'decodeString'(_0x143eaa,_0x484771){return this['HAS_NATIVE_SUPPORT']&&!_0x484771?atob(_0x143eaa):nc(this['decodeStringToByteArray'](_0x143eaa,_0x484771));},'decodeStringToByteArray'(_0xc6c94c,_0x2ac339){this['init_']();const _0x284dea=_0x2ac339?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x47bce1=[];for(let _0x4c5938=0x0;_0x4c5938<_0xc6c94c['length'];){const _0x5010cc=_0x284dea[_0xc6c94c['charAt'](_0x4c5938++)],_0x3948da=_0x4c5938<_0xc6c94c['length']?_0x284dea[_0xc6c94c['charAt'](_0x4c5938)]:0x0;++_0x4c5938;const _0x515161=_0x4c5938<_0xc6c94c['length']?_0x284dea[_0xc6c94c['charAt'](_0x4c5938)]:0x40;++_0x4c5938;const _0x98c004=_0x4c5938<_0xc6c94c['length']?_0x284dea[_0xc6c94c['charAt'](_0x4c5938)]:0x40;if(++_0x4c5938,_0x5010cc==null||_0x3948da==null||_0x515161==null||_0x98c004==null)throw new ic();const _0x1fdc66=_0x5010cc<<0x2|_0x3948da>>0x4;if(_0x47bce1['push'](_0x1fdc66),_0x515161!==0x40){const _0x371274=_0x3948da<<0x4&0xf0|_0x515161>>0x2;if(_0x47bce1['push'](_0x371274),_0x98c004!==0x40){const _0x1208c8=_0x515161<<0x6&0xc0|_0x98c004;_0x47bce1['push'](_0x1208c8);}}}return _0x47bce1;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x76fe2d=0x0;_0x76fe2d<this['ENCODED_VALS']['length'];_0x76fe2d++)this['byteToCharMap_'][_0x76fe2d]=this['ENCODED_VALS']['charAt'](_0x76fe2d),this['charToByteMap_'][this['byteToCharMap_'][_0x76fe2d]]=_0x76fe2d,this['byteToCharMapWebSafe_'][_0x76fe2d]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x76fe2d),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x76fe2d]]=_0x76fe2d,_0x76fe2d>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x76fe2d)]=_0x76fe2d,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x76fe2d)]=_0x76fe2d);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x500be0){const _0x5e25ab=Hr(_0x500be0);return Fi['encodeByteArray'](_0x5e25ab,!0x0);},dn=function(_0x5a0544){return $r(_0x5a0544)['replace'](/\./g,'');},fn=function(_0x60118){try{return Fi['decodeString'](_0x60118,!0x0);}catch(_0x256490){console['error']('base64Decode\x20failed:\x20',_0x256490);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x4c9a30){return Gr(void 0x0,_0x4c9a30);}function Gr(_0x49238b,_0x1b5024){if(!(_0x1b5024 instanceof Object))return _0x1b5024;switch(_0x1b5024['constructor']){case Date:const _0x77583a=_0x1b5024;return new Date(_0x77583a['getTime']());case Object:_0x49238b===void 0x0&&(_0x49238b={});break;case Array:_0x49238b=[];break;default:return _0x1b5024;}for(const _0x268513 in _0x1b5024)!_0x1b5024['hasOwnProperty'](_0x268513)||!rc(_0x268513)||(_0x49238b[_0x268513]=Gr(_0x49238b[_0x268513],_0x1b5024[_0x268513]));return _0x49238b;}function rc(_0x547481){return _0x547481!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x14e44e=Ps['__FIREBASE_DEFAULTS__'];if(_0x14e44e)return JSON['parse'](_0x14e44e);},lc=()=>{if(typeof document>'u')return;let _0x4f149e;try{_0x4f149e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1fadd1=_0x4f149e&&fn(_0x4f149e[0x1]);return _0x1fadd1&&JSON['parse'](_0x1fadd1);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x1562ea){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1562ea);return;}},qr=_0x51039d=>{var _0x4a3f23,_0xb8bc7f;return(_0xb8bc7f=(_0x4a3f23=Ui())==null?void 0x0:_0x4a3f23['emulatorHosts'])==null?void 0x0:_0xb8bc7f[_0x51039d];},hc=_0x165fce=>{const _0xea9dd5=qr(_0x165fce);if(!_0xea9dd5)return;const _0xd5384=_0xea9dd5['lastIndexOf'](':');if(_0xd5384<=0x0||_0xd5384+0x1===_0xea9dd5['length'])throw new Error('Invalid\x20host\x20'+_0xea9dd5+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x313ae4=parseInt(_0xea9dd5['substring'](_0xd5384+0x1),0xa);return _0xea9dd5[0x0]==='['?[_0xea9dd5['substring'](0x1,_0xd5384-0x1),_0x313ae4]:[_0xea9dd5['substring'](0x0,_0xd5384),_0x313ae4];},zr=()=>{var _0x3f855b;return(_0x3f855b=Ui())==null?void 0x0:_0x3f855b['config'];},jr=_0x12e126=>{var _0x4702ff;return(_0x4702ff=Ui())==null?void 0x0:_0x4702ff['_'+_0x12e126];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3af584,_0x2e2d7b)=>{this['resolve']=_0x3af584,this['reject']=_0x2e2d7b;});}['wrapCallback'](_0x57819e){return(_0x2e65e3,_0x1e74d1)=>{_0x2e65e3?this['reject'](_0x2e65e3):this['resolve'](_0x1e74d1),typeof _0x57819e=='function'&&(this['promise']['catch'](()=>{}),_0x57819e['length']===0x1?_0x57819e(_0x2e65e3):_0x57819e(_0x2e65e3,_0x1e74d1));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x43ff13,_0x2f5923){if(_0x43ff13['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xbf487d={'alg':'none','type':'JWT'},_0x219bd7=_0x2f5923||'demo-project',_0x4a701b=_0x43ff13['iat']||0x0,_0x4df193=_0x43ff13['sub']||_0x43ff13['user_id'];if(!_0x4df193)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5142d7={'iss':'https://securetoken.google.com/'+_0x219bd7,'aud':_0x219bd7,'iat':_0x4a701b,'exp':_0x4a701b+0xe10,'auth_time':_0x4a701b,'sub':_0x4df193,'user_id':_0x4df193,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x43ff13};return[dn(JSON['stringify'](_0xbf487d)),dn(JSON['stringify'](_0x5142d7)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5794ba=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5794ba=='object'&&_0x5794ba['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x18c220=W();return _0x18c220['indexOf']('MSIE\x20')>=0x0||_0x18c220['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3e27cb,_0x5ba7be)=>{try{let _0x371043=!0x0;const _0x3f34fb='validate-browser-context-for-indexeddb-analytics-module',_0x549b19=self['indexedDB']['open'](_0x3f34fb);_0x549b19['onsuccess']=()=>{_0x549b19['result']['close'](),_0x371043||self['indexedDB']['deleteDatabase'](_0x3f34fb),_0x3e27cb(!0x0);},_0x549b19['onupgradeneeded']=()=>{_0x371043=!0x1;},_0x549b19['onerror']=()=>{var _0xac4957;_0x5ba7be(((_0xac4957=_0x549b19['error'])==null?void 0x0:_0xac4957['message'])||'');};}catch(_0x584366){_0x5ba7be(_0x584366);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x39b415,_0x499d18,_0x1f5087){super(_0x499d18),this['code']=_0x39b415,this['customData']=_0x1f5087,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x16ed62,_0x1fff8,_0x188d9){this['service']=_0x16ed62,this['serviceName']=_0x1fff8,this['errors']=_0x188d9;}['create'](_0x3b157a,..._0x147ccb){const _0x5c0405=_0x147ccb[0x0]||{},_0x41f0c4=this['service']+'/'+_0x3b157a,_0x27aefd=this['errors'][_0x3b157a],_0x3db70b=_0x27aefd?vc(_0x27aefd,_0x5c0405):'Error',_0x543386=this['serviceName']+':\x20'+_0x3db70b+'\x20('+_0x41f0c4+').';return new Re(_0x41f0c4,_0x543386,_0x5c0405);}}function vc(_0x17301f,_0x27eacc){return _0x17301f['replace'](Ec,(_0x232ebb,_0x6fef60)=>{const _0x2d890b=_0x27eacc[_0x6fef60];return _0x2d890b!=null?String(_0x2d890b):'<'+_0x6fef60+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x34b849){return JSON['parse'](_0x34b849);}function O(_0x39c855){return JSON['stringify'](_0x39c855);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x228dd5){let _0x2a4aff={},_0x3fd928={},_0x3fcea8={},_0x2d610b='';try{const _0x220f04=_0x228dd5['split']('.');_0x2a4aff=Nt(fn(_0x220f04[0x0])||''),_0x3fd928=Nt(fn(_0x220f04[0x1])||''),_0x2d610b=_0x220f04[0x2],_0x3fcea8=_0x3fd928['d']||{},delete _0x3fd928['d'];}catch{}return{'header':_0x2a4aff,'claims':_0x3fd928,'data':_0x3fcea8,'signature':_0x2d610b};},Ic=function(_0x54a185){const _0x56df0b=Yr(_0x54a185),_0xc5c25a=_0x56df0b['claims'];return!!_0xc5c25a&&typeof _0xc5c25a=='object'&&_0xc5c25a['hasOwnProperty']('iat');},wc=function(_0x2bce32){const _0x591fab=Yr(_0x2bce32)['claims'];return typeof _0x591fab=='object'&&_0x591fab['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x47ea5c,_0x27d05d){return Object['prototype']['hasOwnProperty']['call'](_0x47ea5c,_0x27d05d);}function Le(_0x176ca4,_0x55cdc3){if(Object['prototype']['hasOwnProperty']['call'](_0x176ca4,_0x55cdc3))return _0x176ca4[_0x55cdc3];}function pn(_0x359208){for(const _0x22b41d in _0x359208)if(Object['prototype']['hasOwnProperty']['call'](_0x359208,_0x22b41d))return!0x1;return!0x0;}function _n(_0x348a9e,_0x95f172,_0x49f9c7){const _0x588a31={};for(const _0x34a17f in _0x348a9e)Object['prototype']['hasOwnProperty']['call'](_0x348a9e,_0x34a17f)&&(_0x588a31[_0x34a17f]=_0x95f172['call'](_0x49f9c7,_0x348a9e[_0x34a17f],_0x34a17f,_0x348a9e));return _0x588a31;}function xe(_0x469f66,_0xd905d){if(_0x469f66===_0xd905d)return!0x0;const _0x2f6c88=Object['keys'](_0x469f66),_0x42d9e2=Object['keys'](_0xd905d);for(const _0x37c265 of _0x2f6c88){if(!_0x42d9e2['includes'](_0x37c265))return!0x1;const _0x110fdb=_0x469f66[_0x37c265],_0x2db163=_0xd905d[_0x37c265];if(Ns(_0x110fdb)&&Ns(_0x2db163)){if(!xe(_0x110fdb,_0x2db163))return!0x1;}else{if(_0x110fdb!==_0x2db163)return!0x1;}}for(const _0x33240f of _0x42d9e2)if(!_0x2f6c88['includes'](_0x33240f))return!0x1;return!0x0;}function Ns(_0x144069){return _0x144069!==null&&typeof _0x144069=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x17fba8){const _0x10185a=[];for(const [_0x240d66,_0x2326e0]of Object['entries'](_0x17fba8))Array['isArray'](_0x2326e0)?_0x2326e0['forEach'](_0x345ea8=>{_0x10185a['push'](encodeURIComponent(_0x240d66)+'='+encodeURIComponent(_0x345ea8));}):_0x10185a['push'](encodeURIComponent(_0x240d66)+'='+encodeURIComponent(_0x2326e0));return _0x10185a['length']?'&'+_0x10185a['join']('&'):'';}function Ct(_0x2a450c){const _0x3f3f8a={};return _0x2a450c['replace'](/^\?/,'')['split']('&')['forEach'](_0x115dc3=>{if(_0x115dc3){const [_0xdbe5de,_0x1d7c54]=_0x115dc3['split']('=');_0x3f3f8a[decodeURIComponent(_0xdbe5de)]=decodeURIComponent(_0x1d7c54);}}),_0x3f3f8a;}function Tt(_0x22f588){const _0x36fa2d=_0x22f588['indexOf']('?');if(!_0x36fa2d)return'';const _0x6ac247=_0x22f588['indexOf']('#',_0x36fa2d);return _0x22f588['substring'](_0x36fa2d,_0x6ac247>0x0?_0x6ac247:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x45ce6e=0x1;_0x45ce6e<this['blockSize'];++_0x45ce6e)this['pad_'][_0x45ce6e]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x503094,_0x35a71d){_0x35a71d||(_0x35a71d=0x0);const _0x59fad0=this['W_'];if(typeof _0x503094=='string'){for(let _0x1b8896=0x0;_0x1b8896<0x10;_0x1b8896++)_0x59fad0[_0x1b8896]=_0x503094['charCodeAt'](_0x35a71d)<<0x18|_0x503094['charCodeAt'](_0x35a71d+0x1)<<0x10|_0x503094['charCodeAt'](_0x35a71d+0x2)<<0x8|_0x503094['charCodeAt'](_0x35a71d+0x3),_0x35a71d+=0x4;}else{for(let _0x5d1872=0x0;_0x5d1872<0x10;_0x5d1872++)_0x59fad0[_0x5d1872]=_0x503094[_0x35a71d]<<0x18|_0x503094[_0x35a71d+0x1]<<0x10|_0x503094[_0x35a71d+0x2]<<0x8|_0x503094[_0x35a71d+0x3],_0x35a71d+=0x4;}for(let _0x4845a0=0x10;_0x4845a0<0x50;_0x4845a0++){const _0x5648d4=_0x59fad0[_0x4845a0-0x3]^_0x59fad0[_0x4845a0-0x8]^_0x59fad0[_0x4845a0-0xe]^_0x59fad0[_0x4845a0-0x10];_0x59fad0[_0x4845a0]=(_0x5648d4<<0x1|_0x5648d4>>>0x1f)&0xffffffff;}let _0x502fc5=this['chain_'][0x0],_0xd70d81=this['chain_'][0x1],_0x4babf6=this['chain_'][0x2],_0x56907d=this['chain_'][0x3],_0xc89c20=this['chain_'][0x4],_0x4031c2,_0x352645;for(let _0x40e03c=0x0;_0x40e03c<0x50;_0x40e03c++){_0x40e03c<0x28?_0x40e03c<0x14?(_0x4031c2=_0x56907d^_0xd70d81&(_0x4babf6^_0x56907d),_0x352645=0x5a827999):(_0x4031c2=_0xd70d81^_0x4babf6^_0x56907d,_0x352645=0x6ed9eba1):_0x40e03c<0x3c?(_0x4031c2=_0xd70d81&_0x4babf6|_0x56907d&(_0xd70d81|_0x4babf6),_0x352645=0x8f1bbcdc):(_0x4031c2=_0xd70d81^_0x4babf6^_0x56907d,_0x352645=0xca62c1d6);const _0x793200=(_0x502fc5<<0x5|_0x502fc5>>>0x1b)+_0x4031c2+_0xc89c20+_0x352645+_0x59fad0[_0x40e03c]&0xffffffff;_0xc89c20=_0x56907d,_0x56907d=_0x4babf6,_0x4babf6=(_0xd70d81<<0x1e|_0xd70d81>>>0x2)&0xffffffff,_0xd70d81=_0x502fc5,_0x502fc5=_0x793200;}this['chain_'][0x0]=this['chain_'][0x0]+_0x502fc5&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xd70d81&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4babf6&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x56907d&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xc89c20&0xffffffff;}['update'](_0x24abc1,_0x171e8d){if(_0x24abc1==null)return;_0x171e8d===void 0x0&&(_0x171e8d=_0x24abc1['length']);const _0x49b7d3=_0x171e8d-this['blockSize'];let _0x1da5c7=0x0;const _0x3e3d26=this['buf_'];let _0x427dfd=this['inbuf_'];for(;_0x1da5c7<_0x171e8d;){if(_0x427dfd===0x0){for(;_0x1da5c7<=_0x49b7d3;)this['compress_'](_0x24abc1,_0x1da5c7),_0x1da5c7+=this['blockSize'];}if(typeof _0x24abc1=='string'){for(;_0x1da5c7<_0x171e8d;)if(_0x3e3d26[_0x427dfd]=_0x24abc1['charCodeAt'](_0x1da5c7),++_0x427dfd,++_0x1da5c7,_0x427dfd===this['blockSize']){this['compress_'](_0x3e3d26),_0x427dfd=0x0;break;}}else{for(;_0x1da5c7<_0x171e8d;)if(_0x3e3d26[_0x427dfd]=_0x24abc1[_0x1da5c7],++_0x427dfd,++_0x1da5c7,_0x427dfd===this['blockSize']){this['compress_'](_0x3e3d26),_0x427dfd=0x0;break;}}}this['inbuf_']=_0x427dfd,this['total_']+=_0x171e8d;}['digest'](){const _0x299401=[];let _0xd0d589=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x8d49c1=this['blockSize']-0x1;_0x8d49c1>=0x38;_0x8d49c1--)this['buf_'][_0x8d49c1]=_0xd0d589&0xff,_0xd0d589/=0x100;this['compress_'](this['buf_']);let _0x166c3e=0x0;for(let _0x426ede=0x0;_0x426ede<0x5;_0x426ede++)for(let _0xdef1d0=0x18;_0xdef1d0>=0x0;_0xdef1d0-=0x8)_0x299401[_0x166c3e]=this['chain_'][_0x426ede]>>_0xdef1d0&0xff,++_0x166c3e;return _0x299401;}}function Tc(_0x55546b,_0x164ca9){const _0x5dc260=new Sc(_0x55546b,_0x164ca9);return _0x5dc260['subscribe']['bind'](_0x5dc260);}class Sc{constructor(_0x11a500,_0x30f10e){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x30f10e,this['task']['then'](()=>{_0x11a500(this);})['catch'](_0x4b47d7=>{this['error'](_0x4b47d7);});}['next'](_0x19082d){this['forEachObserver'](_0x2348dd=>{_0x2348dd['next'](_0x19082d);});}['error'](_0x5a9963){this['forEachObserver'](_0x83249c=>{_0x83249c['error'](_0x5a9963);}),this['close'](_0x5a9963);}['complete'](){this['forEachObserver'](_0x4b0a07=>{_0x4b0a07['complete']();}),this['close']();}['subscribe'](_0x1a07b3,_0x6608e2,_0x593656){let _0x3374bb;if(_0x1a07b3===void 0x0&&_0x6608e2===void 0x0&&_0x593656===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1a07b3,['next','error','complete'])?_0x3374bb=_0x1a07b3:_0x3374bb={'next':_0x1a07b3,'error':_0x6608e2,'complete':_0x593656},_0x3374bb['next']===void 0x0&&(_0x3374bb['next']=ti),_0x3374bb['error']===void 0x0&&(_0x3374bb['error']=ti),_0x3374bb['complete']===void 0x0&&(_0x3374bb['complete']=ti);const _0xbd0b05=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3374bb['error'](this['finalError']):_0x3374bb['complete']();}catch{}}),this['observers']['push'](_0x3374bb),_0xbd0b05;}['unsubscribeOne'](_0x5389a6){this['observers']===void 0x0||this['observers'][_0x5389a6]===void 0x0||(delete this['observers'][_0x5389a6],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1de6f5){if(!this['finalized']){for(let _0x4cab82=0x0;_0x4cab82<this['observers']['length'];_0x4cab82++)this['sendOne'](_0x4cab82,_0x1de6f5);}}['sendOne'](_0x2f504f,_0x42303e){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2f504f]!==void 0x0)try{_0x42303e(this['observers'][_0x2f504f]);}catch(_0x3a42bf){typeof console<'u'&&console['error']&&console['error'](_0x3a42bf);}});}['close'](_0x2d50fa){this['finalized']||(this['finalized']=!0x0,_0x2d50fa!==void 0x0&&(this['finalError']=_0x2d50fa),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x2b8e34,_0xa0f51d){if(typeof _0x2b8e34!='object'||_0x2b8e34===null)return!0x1;for(const _0x3255b6 of _0xa0f51d)if(_0x3255b6 in _0x2b8e34&&typeof _0x2b8e34[_0x3255b6]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x2dab30,_0x204ec1){return _0x2dab30+'\x20failed:\x20'+_0x204ec1+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x45d6b8){const _0x733664=[];let _0x22ff62=0x0;for(let _0x43a4bf=0x0;_0x43a4bf<_0x45d6b8['length'];_0x43a4bf++){let _0x53a52d=_0x45d6b8['charCodeAt'](_0x43a4bf);if(_0x53a52d>=0xd800&&_0x53a52d<=0xdbff){const _0x191638=_0x53a52d-0xd800;_0x43a4bf++,f(_0x43a4bf<_0x45d6b8['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2d412e=_0x45d6b8['charCodeAt'](_0x43a4bf)-0xdc00;_0x53a52d=0x10000+(_0x191638<<0xa)+_0x2d412e;}_0x53a52d<0x80?_0x733664[_0x22ff62++]=_0x53a52d:_0x53a52d<0x800?(_0x733664[_0x22ff62++]=_0x53a52d>>0x6|0xc0,_0x733664[_0x22ff62++]=_0x53a52d&0x3f|0x80):_0x53a52d<0x10000?(_0x733664[_0x22ff62++]=_0x53a52d>>0xc|0xe0,_0x733664[_0x22ff62++]=_0x53a52d>>0x6&0x3f|0x80,_0x733664[_0x22ff62++]=_0x53a52d&0x3f|0x80):(_0x733664[_0x22ff62++]=_0x53a52d>>0x12|0xf0,_0x733664[_0x22ff62++]=_0x53a52d>>0xc&0x3f|0x80,_0x733664[_0x22ff62++]=_0x53a52d>>0x6&0x3f|0x80,_0x733664[_0x22ff62++]=_0x53a52d&0x3f|0x80);}return _0x733664;},Ln=function(_0x49537f){let _0x27f05b=0x0;for(let _0x4667e1=0x0;_0x4667e1<_0x49537f['length'];_0x4667e1++){const _0x20f8fb=_0x49537f['charCodeAt'](_0x4667e1);_0x20f8fb<0x80?_0x27f05b++:_0x20f8fb<0x800?_0x27f05b+=0x2:_0x20f8fb>=0xd800&&_0x20f8fb<=0xdbff?(_0x27f05b+=0x4,_0x4667e1++):_0x27f05b+=0x3;}return _0x27f05b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0xcfb646){return _0xcfb646&&_0xcfb646['_delegate']?_0xcfb646['_delegate']:_0xcfb646;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x1a53b4){try{return(_0x1a53b4['startsWith']('http://')||_0x1a53b4['startsWith']('https://')?new URL(_0x1a53b4)['hostname']:_0x1a53b4)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x21e6f9){return(await fetch(_0x21e6f9,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x28b3ac,_0x3162f9,_0x5c41d6){this['name']=_0x28b3ac,this['instanceFactory']=_0x3162f9,this['type']=_0x5c41d6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x24f805){return this['instantiationMode']=_0x24f805,this;}['setMultipleInstances'](_0x56e627){return this['multipleInstances']=_0x56e627,this;}['setServiceProps'](_0x301c86){return this['serviceProps']=_0x301c86,this;}['setInstanceCreatedCallback'](_0x21d050){return this['onInstanceCreated']=_0x21d050,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x118dca,_0x1e6aea){this['name']=_0x118dca,this['container']=_0x1e6aea,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x510460){const _0x1e72b3=this['normalizeInstanceIdentifier'](_0x510460);if(!this['instancesDeferred']['has'](_0x1e72b3)){const _0x338b17=new H();if(this['instancesDeferred']['set'](_0x1e72b3,_0x338b17),this['isInitialized'](_0x1e72b3)||this['shouldAutoInitialize']())try{const _0x2ded12=this['getOrInitializeService']({'instanceIdentifier':_0x1e72b3});_0x2ded12&&_0x338b17['resolve'](_0x2ded12);}catch{}}return this['instancesDeferred']['get'](_0x1e72b3)['promise'];}['getImmediate'](_0x610937){const _0x26d9ab=this['normalizeInstanceIdentifier'](_0x610937==null?void 0x0:_0x610937['identifier']),_0x57496a=(_0x610937==null?void 0x0:_0x610937['optional'])??!0x1;if(this['isInitialized'](_0x26d9ab)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x26d9ab});}catch(_0x3e567b){if(_0x57496a)return null;throw _0x3e567b;}else{if(_0x57496a)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x290f09){if(_0x290f09['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x290f09['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x290f09,!!this['shouldAutoInitialize']()){if(Pc(_0x290f09))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4e1bee,_0x85683d]of this['instancesDeferred']['entries']()){const _0x27ef99=this['normalizeInstanceIdentifier'](_0x4e1bee);try{const _0x3e22c9=this['getOrInitializeService']({'instanceIdentifier':_0x27ef99});_0x85683d['resolve'](_0x3e22c9);}catch{}}}}['clearInstance'](_0xb60135=Ne){this['instancesDeferred']['delete'](_0xb60135),this['instancesOptions']['delete'](_0xb60135),this['instances']['delete'](_0xb60135);}async['delete'](){const _0x2fbdee=Array['from'](this['instances']['values']());await Promise['all']([..._0x2fbdee['filter'](_0x4e89f8=>'INTERNAL'in _0x4e89f8)['map'](_0x2a4355=>_0x2a4355['INTERNAL']['delete']()),..._0x2fbdee['filter'](_0x14df60=>'_delete'in _0x14df60)['map'](_0x4353ce=>_0x4353ce['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x420c6d=Ne){return this['instances']['has'](_0x420c6d);}['getOptions'](_0x11fab2=Ne){return this['instancesOptions']['get'](_0x11fab2)||{};}['initialize'](_0x9f59cf={}){const {options:_0x173279={}}=_0x9f59cf,_0x4b0a96=this['normalizeInstanceIdentifier'](_0x9f59cf['instanceIdentifier']);if(this['isInitialized'](_0x4b0a96))throw Error(this['name']+'('+_0x4b0a96+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5d11b6=this['getOrInitializeService']({'instanceIdentifier':_0x4b0a96,'options':_0x173279});for(const [_0x10a74d,_0xaec011]of this['instancesDeferred']['entries']()){const _0xb08554=this['normalizeInstanceIdentifier'](_0x10a74d);_0x4b0a96===_0xb08554&&_0xaec011['resolve'](_0x5d11b6);}return _0x5d11b6;}['onInit'](_0x3d93e4,_0x1c3ae4){const _0xc5516a=this['normalizeInstanceIdentifier'](_0x1c3ae4),_0x30fbae=this['onInitCallbacks']['get'](_0xc5516a)??new Set();_0x30fbae['add'](_0x3d93e4),this['onInitCallbacks']['set'](_0xc5516a,_0x30fbae);const _0x4258a4=this['instances']['get'](_0xc5516a);return _0x4258a4&&_0x3d93e4(_0x4258a4,_0xc5516a),()=>{_0x30fbae['delete'](_0x3d93e4);};}['invokeOnInitCallbacks'](_0x12ac38,_0x19043e){const _0x4b70a5=this['onInitCallbacks']['get'](_0x19043e);if(_0x4b70a5){for(const _0x10a193 of _0x4b70a5)try{_0x10a193(_0x12ac38,_0x19043e);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4380ec,options:_0x221e3b={}}){let _0x350737=this['instances']['get'](_0x4380ec);if(!_0x350737&&this['component']&&(_0x350737=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4380ec),'options':_0x221e3b}),this['instances']['set'](_0x4380ec,_0x350737),this['instancesOptions']['set'](_0x4380ec,_0x221e3b),this['invokeOnInitCallbacks'](_0x350737,_0x4380ec),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4380ec,_0x350737);}catch{}return _0x350737||null;}['normalizeInstanceIdentifier'](_0x2cc9f9=Ne){return this['component']?this['component']['multipleInstances']?_0x2cc9f9:Ne:_0x2cc9f9;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x4ca709){return _0x4ca709===Ne?void 0x0:_0x4ca709;}function Pc(_0x5713e7){return _0x5713e7['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x4a309c){this['name']=_0x4a309c,this['providers']=new Map();}['addComponent'](_0x195122){const _0x1ac760=this['getProvider'](_0x195122['name']);if(_0x1ac760['isComponentSet']())throw new Error('Component\x20'+_0x195122['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1ac760['setComponent'](_0x195122);}['addOrOverwriteComponent'](_0x260596){this['getProvider'](_0x260596['name'])['isComponentSet']()&&this['providers']['delete'](_0x260596['name']),this['addComponent'](_0x260596);}['getProvider'](_0x474cf6){if(this['providers']['has'](_0x474cf6))return this['providers']['get'](_0x474cf6);const _0x31299c=new Ac(_0x474cf6,this);return this['providers']['set'](_0x474cf6,_0x31299c),_0x31299c;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x366787){_0x366787[_0x366787['DEBUG']=0x0]='DEBUG',_0x366787[_0x366787['VERBOSE']=0x1]='VERBOSE',_0x366787[_0x366787['INFO']=0x2]='INFO',_0x366787[_0x366787['WARN']=0x3]='WARN',_0x366787[_0x366787['ERROR']=0x4]='ERROR',_0x366787[_0x366787['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x589a73,_0x3cd752,..._0x41d70e)=>{if(_0x3cd752<_0x589a73['logLevel'])return;const _0x59435e=new Date()['toISOString'](),_0x1db5d2=Mc[_0x3cd752];if(_0x1db5d2)console[_0x1db5d2]('['+_0x59435e+']\x20\x20'+_0x589a73['name']+':',..._0x41d70e);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3cd752+')');};class Bi{constructor(_0x12e4f9){this['name']=_0x12e4f9,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xe69dcd){if(!(_0xe69dcd in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xe69dcd+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xe69dcd;}['setLogLevel'](_0x520261){this['_logLevel']=typeof _0x520261=='string'?Oc[_0x520261]:_0x520261;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x196933){if(typeof _0x196933!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x196933;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x672612){this['_userLogHandler']=_0x672612;}['debug'](..._0x47070c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x47070c),this['_logHandler'](this,T['DEBUG'],..._0x47070c);}['log'](..._0x5f3003){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5f3003),this['_logHandler'](this,T['VERBOSE'],..._0x5f3003);}['info'](..._0x1702d8){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1702d8),this['_logHandler'](this,T['INFO'],..._0x1702d8);}['warn'](..._0x199533){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x199533),this['_logHandler'](this,T['WARN'],..._0x199533);}['error'](..._0x415984){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x415984),this['_logHandler'](this,T['ERROR'],..._0x415984);}}const xc=(_0x544f4e,_0x45bc2e)=>_0x45bc2e['some'](_0x3ed613=>_0x544f4e instanceof _0x3ed613);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4d3691){const _0x311aeb=new Promise((_0x397978,_0x313ca9)=>{const _0x683104=()=>{_0x4d3691['removeEventListener']('success',_0x595106),_0x4d3691['removeEventListener']('error',_0x1908ee);},_0x595106=()=>{_0x397978(ge(_0x4d3691['result'])),_0x683104();},_0x1908ee=()=>{_0x313ca9(_0x4d3691['error']),_0x683104();};_0x4d3691['addEventListener']('success',_0x595106),_0x4d3691['addEventListener']('error',_0x1908ee);});return _0x311aeb['then'](_0x4e0cbc=>{_0x4e0cbc instanceof IDBCursor&&Jr['set'](_0x4e0cbc,_0x4d3691);})['catch'](()=>{}),Vi['set'](_0x311aeb,_0x4d3691),_0x311aeb;}function Bc(_0x28aeb9){if(_i['has'](_0x28aeb9))return;const _0x2170f3=new Promise((_0xa49988,_0xa93b8c)=>{const _0x54c1ae=()=>{_0x28aeb9['removeEventListener']('complete',_0xa30b4d),_0x28aeb9['removeEventListener']('error',_0x2a48b1),_0x28aeb9['removeEventListener']('abort',_0x2a48b1);},_0xa30b4d=()=>{_0xa49988(),_0x54c1ae();},_0x2a48b1=()=>{_0xa93b8c(_0x28aeb9['error']||new DOMException('AbortError','AbortError')),_0x54c1ae();};_0x28aeb9['addEventListener']('complete',_0xa30b4d),_0x28aeb9['addEventListener']('error',_0x2a48b1),_0x28aeb9['addEventListener']('abort',_0x2a48b1);});_i['set'](_0x28aeb9,_0x2170f3);}let gi={'get'(_0x47911e,_0x27f38a,_0x42ea91){if(_0x47911e instanceof IDBTransaction){if(_0x27f38a==='done')return _i['get'](_0x47911e);if(_0x27f38a==='objectStoreNames')return _0x47911e['objectStoreNames']||Xr['get'](_0x47911e);if(_0x27f38a==='store')return _0x42ea91['objectStoreNames'][0x1]?void 0x0:_0x42ea91['objectStore'](_0x42ea91['objectStoreNames'][0x0]);}return ge(_0x47911e[_0x27f38a]);},'set'(_0x18779a,_0x325eed,_0x4d37ec){return _0x18779a[_0x325eed]=_0x4d37ec,!0x0;},'has'(_0x2cee30,_0x33e018){return _0x2cee30 instanceof IDBTransaction&&(_0x33e018==='done'||_0x33e018==='store')?!0x0:_0x33e018 in _0x2cee30;}};function Vc(_0x246a3b){gi=_0x246a3b(gi);}function Hc(_0xead690){return _0xead690===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xe7b733,..._0x5e3885){const _0x597065=_0xead690['call'](ii(this),_0xe7b733,..._0x5e3885);return Xr['set'](_0x597065,_0xe7b733['sort']?_0xe7b733['sort']():[_0xe7b733]),ge(_0x597065);}:Uc()['includes'](_0xead690)?function(..._0x224ee7){return _0xead690['apply'](ii(this),_0x224ee7),ge(Jr['get'](this));}:function(..._0x5e8762){return ge(_0xead690['apply'](ii(this),_0x5e8762));};}function $c(_0x396d29){return typeof _0x396d29=='function'?Hc(_0x396d29):(_0x396d29 instanceof IDBTransaction&&Bc(_0x396d29),xc(_0x396d29,Fc())?new Proxy(_0x396d29,gi):_0x396d29);}function ge(_0xeb6bcc){if(_0xeb6bcc instanceof IDBRequest)return Wc(_0xeb6bcc);if(ni['has'](_0xeb6bcc))return ni['get'](_0xeb6bcc);const _0x412007=$c(_0xeb6bcc);return _0x412007!==_0xeb6bcc&&(ni['set'](_0xeb6bcc,_0x412007),Vi['set'](_0x412007,_0xeb6bcc)),_0x412007;}const ii=_0x3a5e9f=>Vi['get'](_0x3a5e9f);function Gc(_0x2d7231,_0x36e744,{blocked:_0x258b75,upgrade:_0x181575,blocking:_0x33afde,terminated:_0x121a9b}={}){const _0x83ee66=indexedDB['open'](_0x2d7231,_0x36e744),_0x400c0a=ge(_0x83ee66);return _0x181575&&_0x83ee66['addEventListener']('upgradeneeded',_0x2d755e=>{_0x181575(ge(_0x83ee66['result']),_0x2d755e['oldVersion'],_0x2d755e['newVersion'],ge(_0x83ee66['transaction']),_0x2d755e);}),_0x258b75&&_0x83ee66['addEventListener']('blocked',_0x13abdd=>_0x258b75(_0x13abdd['oldVersion'],_0x13abdd['newVersion'],_0x13abdd)),_0x400c0a['then'](_0x34c63b=>{_0x121a9b&&_0x34c63b['addEventListener']('close',()=>_0x121a9b()),_0x33afde&&_0x34c63b['addEventListener']('versionchange',_0x255bec=>_0x33afde(_0x255bec['oldVersion'],_0x255bec['newVersion'],_0x255bec));})['catch'](()=>{}),_0x400c0a;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x5a0715,_0x4e557d){if(!(_0x5a0715 instanceof IDBDatabase&&!(_0x4e557d in _0x5a0715)&&typeof _0x4e557d=='string'))return;if(si['get'](_0x4e557d))return si['get'](_0x4e557d);const _0x10a3b2=_0x4e557d['replace'](/FromIndex$/,''),_0x46bc48=_0x4e557d!==_0x10a3b2,_0x210336=zc['includes'](_0x10a3b2);if(!(_0x10a3b2 in(_0x46bc48?IDBIndex:IDBObjectStore)['prototype'])||!(_0x210336||qc['includes'](_0x10a3b2)))return;const _0x23993b=async function(_0x3458fc,..._0x2db45c){const _0x30e2cb=this['transaction'](_0x3458fc,_0x210336?'readwrite':'readonly');let _0x51f0d1=_0x30e2cb['store'];return _0x46bc48&&(_0x51f0d1=_0x51f0d1['index'](_0x2db45c['shift']())),(await Promise['all']([_0x51f0d1[_0x10a3b2](..._0x2db45c),_0x210336&&_0x30e2cb['done']]))[0x0];};return si['set'](_0x4e557d,_0x23993b),_0x23993b;}Vc(_0x36d2ee=>({..._0x36d2ee,'get':(_0x174eca,_0x408635,_0x2cd356)=>Ms(_0x174eca,_0x408635)||_0x36d2ee['get'](_0x174eca,_0x408635,_0x2cd356),'has':(_0x47afa3,_0x59f040)=>!!Ms(_0x47afa3,_0x59f040)||_0x36d2ee['has'](_0x47afa3,_0x59f040)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x14d51f){this['container']=_0x14d51f;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x45236d=>{if(Kc(_0x45236d)){const _0x28eec0=_0x45236d['getImmediate']();return _0x28eec0['library']+'/'+_0x28eec0['version'];}else return null;})['filter'](_0x2c9b3e=>_0x2c9b3e)['join']('\x20');}}function Kc(_0x694791){const _0x5eb9db=_0x694791['getComponent']();return(_0x5eb9db==null?void 0x0:_0x5eb9db['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xcc448b,_0x458c61){try{_0xcc448b['container']['addComponent'](_0x458c61);}catch(_0x308a80){oe['debug']('Component\x20'+_0x458c61['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xcc448b['name'],_0x308a80);}}function st(_0x2fddd0){const _0x5aab81=_0x2fddd0['name'];if(Ei['has'](_0x5aab81))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5aab81+'.'),!0x1;Ei['set'](_0x5aab81,_0x2fddd0);for(const _0x38d7e8 of Ue['values']())xs(_0x38d7e8,_0x2fddd0);for(const _0x2c357c of vi['values']())xs(_0x2c357c,_0x2fddd0);return!0x0;}function Hi(_0x5e8265,_0x16641){const _0x3a6797=_0x5e8265['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3a6797&&_0x3a6797['triggerHeartbeat'](),_0x5e8265['container']['getProvider'](_0x16641);}function $(_0x10c28c){return _0x10c28c==null?!0x1:_0x10c28c['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x300dbe,_0x983a18,_0x2c42d5){this['_isDeleted']=!0x1,this['_options']={..._0x300dbe},this['_config']={..._0x983a18},this['_name']=_0x983a18['name'],this['_automaticDataCollectionEnabled']=_0x983a18['automaticDataCollectionEnabled'],this['_container']=_0x2c42d5,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x407623){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x407623;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1dfcc1){this['_isDeleted']=_0x1dfcc1;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x41ae6d,_0x84365c={}){let _0x3c2e43=_0x41ae6d;typeof _0x84365c!='object'&&(_0x84365c={'name':_0x84365c});const _0x14badd={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x84365c},_0xb6a492=_0x14badd['name'];if(typeof _0xb6a492!='string'||!_0xb6a492)throw me['create']('bad-app-name',{'appName':String(_0xb6a492)});if(_0x3c2e43||(_0x3c2e43=zr()),!_0x3c2e43)throw me['create']('no-options');const _0xfc9c6f=Ue['get'](_0xb6a492);if(_0xfc9c6f){if(xe(_0x3c2e43,_0xfc9c6f['options'])&&xe(_0x14badd,_0xfc9c6f['config']))return _0xfc9c6f;throw me['create']('duplicate-app',{'appName':_0xb6a492});}const _0x36d38b=new Nc(_0xb6a492);for(const _0x5a985c of Ei['values']())_0x36d38b['addComponent'](_0x5a985c);const _0x23e2d5=new Tl(_0x3c2e43,_0x14badd,_0x36d38b);return Ue['set'](_0xb6a492,_0x23e2d5),_0x23e2d5;}function Zr(_0x4f2948=yi){const _0x344bcc=Ue['get'](_0x4f2948);if(!_0x344bcc&&_0x4f2948===yi&&zr())return Sl();if(!_0x344bcc)throw me['create']('no-app',{'appName':_0x4f2948});return _0x344bcc;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x34e622){let _0x3d5202=!0x1;const _0x362e1f=_0x34e622['name'];Ue['has'](_0x362e1f)?(_0x3d5202=!0x0,Ue['delete'](_0x362e1f)):vi['has'](_0x362e1f)&&_0x34e622['decRefCount']()<=0x0&&(vi['delete'](_0x362e1f),_0x3d5202=!0x0),_0x3d5202&&(await Promise['all'](_0x34e622['container']['getProviders']()['map'](_0x24e3ce=>_0x24e3ce['delete']())),_0x34e622['isDeleted']=!0x0);}function ye(_0x4ccd23,_0x1bc52d,_0x55e959){let _0x145f59=wl[_0x4ccd23]??_0x4ccd23;_0x55e959&&(_0x145f59+='-'+_0x55e959);const _0xc1931a=_0x145f59['match'](/\s|\//),_0x10c771=_0x1bc52d['match'](/\s|\//);if(_0xc1931a||_0x10c771){const _0x314b47=['Unable\x20to\x20register\x20library\x20\x22'+_0x145f59+'\x22\x20with\x20version\x20\x22'+_0x1bc52d+'\x22:'];_0xc1931a&&_0x314b47['push']('library\x20name\x20\x22'+_0x145f59+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xc1931a&&_0x10c771&&_0x314b47['push']('and'),_0x10c771&&_0x314b47['push']('version\x20name\x20\x22'+_0x1bc52d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x314b47['join']('\x20'));return;}st(new Fe(_0x145f59+'-version',()=>({'library':_0x145f59,'version':_0x1bc52d}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x6346b6,_0x297673)=>{switch(_0x297673){case 0x0:try{_0x6346b6['createObjectStore'](Ot);}catch(_0x5a32ea){console['warn'](_0x5a32ea);}}}})['catch'](_0x50b3b9=>{throw me['create']('idb-open',{'originalErrorMessage':_0x50b3b9['message']});})),ri;}async function Al(_0x318191){try{const _0x3c1a23=(await eo())['transaction'](Ot),_0x1fd4ac=await _0x3c1a23['objectStore'](Ot)['get'](to(_0x318191));return await _0x3c1a23['done'],_0x1fd4ac;}catch(_0x3f8a78){if(_0x3f8a78 instanceof Re)oe['warn'](_0x3f8a78['message']);else{const _0x5ada54=me['create']('idb-get',{'originalErrorMessage':_0x3f8a78==null?void 0x0:_0x3f8a78['message']});oe['warn'](_0x5ada54['message']);}}}async function Fs(_0x5108bb,_0x2f4bdd){try{const _0x11a508=(await eo())['transaction'](Ot,'readwrite');await _0x11a508['objectStore'](Ot)['put'](_0x2f4bdd,to(_0x5108bb)),await _0x11a508['done'];}catch(_0x3f313a){if(_0x3f313a instanceof Re)oe['warn'](_0x3f313a['message']);else{const _0x1bfbd3=me['create']('idb-set',{'originalErrorMessage':_0x3f313a==null?void 0x0:_0x3f313a['message']});oe['warn'](_0x1bfbd3['message']);}}}function to(_0x2a84f6){return _0x2a84f6['name']+'!'+_0x2a84f6['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x44d2f9){this['container']=_0x44d2f9,this['_heartbeatsCache']=null;const _0x3f1475=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3f1475),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x183f01=>(this['_heartbeatsCache']=_0x183f01,_0x183f01));}async['triggerHeartbeat'](){var _0x49fb49,_0x443a76;try{const _0x1cb16b=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4436a5=Us();if(((_0x49fb49=this['_heartbeatsCache'])==null?void 0x0:_0x49fb49['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x443a76=this['_heartbeatsCache'])==null?void 0x0:_0x443a76['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4436a5||this['_heartbeatsCache']['heartbeats']['some'](_0x2f20f9=>_0x2f20f9['date']===_0x4436a5))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4436a5,'agent':_0x1cb16b}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x46ab94=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x46ab94,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x23b170){oe['warn'](_0x23b170);}}async['getHeartbeatsHeader'](){var _0x576823;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x576823=this['_heartbeatsCache'])==null?void 0x0:_0x576823['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x89b22b=Us(),{heartbeatsToSend:_0x52845d,unsentEntries:_0x28937c}=Ol(this['_heartbeatsCache']['heartbeats']),_0x28d985=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x52845d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x89b22b,_0x28937c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x28937c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x28d985;}catch(_0x40ec6e){return oe['warn'](_0x40ec6e),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x544a4c,_0x17ac68=kl){const _0x264651=[];let _0x47de33=_0x544a4c['slice']();for(const _0x572a3d of _0x544a4c){const _0x3c9755=_0x264651['find'](_0x789a99=>_0x789a99['agent']===_0x572a3d['agent']);if(_0x3c9755){if(_0x3c9755['dates']['push'](_0x572a3d['date']),Ws(_0x264651)>_0x17ac68){_0x3c9755['dates']['pop']();break;}}else{if(_0x264651['push']({'agent':_0x572a3d['agent'],'dates':[_0x572a3d['date']]}),Ws(_0x264651)>_0x17ac68){_0x264651['pop']();break;}}_0x47de33=_0x47de33['slice'](0x1);}return{'heartbeatsToSend':_0x264651,'unsentEntries':_0x47de33};}class Dl{constructor(_0x4c1a83){this['app']=_0x4c1a83,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x39d33d=await Al(this['app']);return _0x39d33d!=null&&_0x39d33d['heartbeats']?_0x39d33d:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x298fdc){if(await this['_canUseIndexedDBPromise']){const _0x56bcff=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x298fdc['lastSentHeartbeatDate']??_0x56bcff['lastSentHeartbeatDate'],'heartbeats':_0x298fdc['heartbeats']});}else return;}async['add'](_0x563701){if(await this['_canUseIndexedDBPromise']){const _0x1a989d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x563701['lastSentHeartbeatDate']??_0x1a989d['lastSentHeartbeatDate'],'heartbeats':[..._0x1a989d['heartbeats'],..._0x563701['heartbeats']]});}else return;}}function Ws(_0x4238dc){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4238dc}))['length'];}function Ml(_0x57e869){if(_0x57e869['length']===0x0)return-0x1;let _0x44942c=0x0,_0x3f13c9=_0x57e869[0x0]['date'];for(let _0x357ce0=0x1;_0x357ce0<_0x57e869['length'];_0x357ce0++)_0x57e869[_0x357ce0]['date']<_0x3f13c9&&(_0x3f13c9=_0x57e869[_0x357ce0]['date'],_0x44942c=_0x357ce0);return _0x44942c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x385383){st(new Fe('platform-logger',_0x467896=>new jc(_0x467896),'PRIVATE')),st(new Fe('heartbeat',_0x1bc73b=>new Nl(_0x1bc73b),'PRIVATE')),ye(mi,Ls,_0x385383),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5e70a2){no=_0x5e70a2;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5676d2){this['domStorage_']=_0x5676d2,this['prefix_']='firebase:';}['set'](_0xc65548,_0x45a2c){_0x45a2c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xc65548)):this['domStorage_']['setItem'](this['prefixedName_'](_0xc65548),O(_0x45a2c));}['get'](_0x3f97d5){const _0x4b2b32=this['domStorage_']['getItem'](this['prefixedName_'](_0x3f97d5));return _0x4b2b32==null?null:Nt(_0x4b2b32);}['remove'](_0x13cf1b){this['domStorage_']['removeItem'](this['prefixedName_'](_0x13cf1b));}['prefixedName_'](_0x242e30){return this['prefix_']+_0x242e30;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x48b110,_0x88091b){_0x88091b==null?delete this['cache_'][_0x48b110]:this['cache_'][_0x48b110]=_0x88091b;}['get'](_0x49d498){return Q(this['cache_'],_0x49d498)?this['cache_'][_0x49d498]:null;}['remove'](_0x4af9c0){delete this['cache_'][_0x4af9c0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x16c406){try{if(typeof window<'u'&&typeof window[_0x16c406]<'u'){const _0x15a1c1=window[_0x16c406];return _0x15a1c1['setItem']('firebase:sentinel','cache'),_0x15a1c1['removeItem']('firebase:sentinel'),new Wl(_0x15a1c1);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x86f874=0x1;return function(){return _0x86f874++;};}()),ro=function(_0x38e08d){const _0x52b0a7=Rc(_0x38e08d),_0x2c327b=new Cc();_0x2c327b['update'](_0x52b0a7);const _0x581279=_0x2c327b['digest']();return Fi['encodeByteArray'](_0x581279);},zt=function(..._0xf041c4){let _0x45a511='';for(let _0x41c449=0x0;_0x41c449<_0xf041c4['length'];_0x41c449++){const _0x5026c5=_0xf041c4[_0x41c449];Array['isArray'](_0x5026c5)||_0x5026c5&&typeof _0x5026c5=='object'&&typeof _0x5026c5['length']=='number'?_0x45a511+=zt['apply'](null,_0x5026c5):typeof _0x5026c5=='object'?_0x45a511+=O(_0x5026c5):_0x45a511+=_0x5026c5,_0x45a511+='\x20';}return _0x45a511;};let St=null,$s=!0x0;const Hl=function(_0x53f041,_0x3e9131){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x2a5841){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x33e0b6=zt['apply'](null,_0x2a5841);St(_0x33e0b6);}},jt=function(_0x322cda){return function(..._0x56cca9){L(_0x322cda,..._0x56cca9);};},Ii=function(..._0x2124fa){const _0x5f2e88='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2124fa);Ze['error'](_0x5f2e88);},ae=function(..._0x1ff337){const _0x412057='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x1ff337);throw Ze['error'](_0x412057),new Error(_0x412057);},U=function(..._0x318e18){const _0x1987be='FIREBASE\x20WARNING:\x20'+zt(..._0x318e18);Ze['warn'](_0x1987be);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2b72a5){return typeof _0x2b72a5=='number'&&(_0x2b72a5!==_0x2b72a5||_0x2b72a5===Number['POSITIVE_INFINITY']||_0x2b72a5===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3673fa){if(document['readyState']==='complete')_0x3673fa();else{let _0x296b2e=!0x1;const _0x4c4bdb=function(){if(!document['body']){setTimeout(_0x4c4bdb,Math['floor'](0xa));return;}_0x296b2e||(_0x296b2e=!0x0,_0x3673fa());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4c4bdb,!0x1),window['addEventListener']('load',_0x4c4bdb,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4c4bdb();}),window['attachEvent']('onload',_0x4c4bdb));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x221edf,_0x145f90){if(_0x221edf===_0x145f90)return 0x0;if(_0x221edf===We||_0x145f90===we)return-0x1;if(_0x145f90===We||_0x221edf===we)return 0x1;{const _0x350859=Gs(_0x221edf),_0x2e9eee=Gs(_0x145f90);return _0x350859!==null?_0x2e9eee!==null?_0x350859-_0x2e9eee===0x0?_0x221edf['length']-_0x145f90['length']:_0x350859-_0x2e9eee:-0x1:_0x2e9eee!==null?0x1:_0x221edf<_0x145f90?-0x1:0x1;}},ql=function(_0x4a8e76,_0xbd7e10){return _0x4a8e76===_0xbd7e10?0x0:_0x4a8e76<_0xbd7e10?-0x1:0x1;},vt=function(_0x432766,_0x59eec3){if(_0x59eec3&&_0x432766 in _0x59eec3)return _0x59eec3[_0x432766];throw new Error('Missing\x20required\x20key\x20('+_0x432766+')\x20in\x20object:\x20'+O(_0x59eec3));},$i=function(_0x2569f0){if(typeof _0x2569f0!='object'||_0x2569f0===null)return O(_0x2569f0);const _0x3a97cf=[];for(const _0x3785e3 in _0x2569f0)_0x3a97cf['push'](_0x3785e3);_0x3a97cf['sort']();let _0x56c6e5='{';for(let _0x3f5f40=0x0;_0x3f5f40<_0x3a97cf['length'];_0x3f5f40++)_0x3f5f40!==0x0&&(_0x56c6e5+=','),_0x56c6e5+=O(_0x3a97cf[_0x3f5f40]),_0x56c6e5+=':',_0x56c6e5+=$i(_0x2569f0[_0x3a97cf[_0x3f5f40]]);return _0x56c6e5+='}',_0x56c6e5;},oo=function(_0x5a4cda,_0x4cac68){const _0x3edaca=_0x5a4cda['length'];if(_0x3edaca<=_0x4cac68)return[_0x5a4cda];const _0x37da14=[];for(let _0x5902a8=0x0;_0x5902a8<_0x3edaca;_0x5902a8+=_0x4cac68)_0x5902a8+_0x4cac68>_0x3edaca?_0x37da14['push'](_0x5a4cda['substring'](_0x5902a8,_0x3edaca)):_0x37da14['push'](_0x5a4cda['substring'](_0x5902a8,_0x5902a8+_0x4cac68));return _0x37da14;};function x(_0x30df31,_0x94a955){for(const _0x9054b0 in _0x30df31)_0x30df31['hasOwnProperty'](_0x9054b0)&&_0x94a955(_0x9054b0,_0x30df31[_0x9054b0]);}const ao=function(_0x3809ef){f(!xn(_0x3809ef),'Invalid\x20JSON\x20number');const _0x3dc8d4=0xb,_0x1798b2=0x34,_0x1c91ef=(0x1<<_0x3dc8d4-0x1)-0x1;let _0x2f74ec,_0x551214,_0x31a5c9,_0x5e65a8,_0x16e456;_0x3809ef===0x0?(_0x551214=0x0,_0x31a5c9=0x0,_0x2f74ec=0x1/_0x3809ef===-0x1/0x0?0x1:0x0):(_0x2f74ec=_0x3809ef<0x0,_0x3809ef=Math['abs'](_0x3809ef),_0x3809ef>=Math['pow'](0x2,0x1-_0x1c91ef)?(_0x5e65a8=Math['min'](Math['floor'](Math['log'](_0x3809ef)/Math['LN2']),_0x1c91ef),_0x551214=_0x5e65a8+_0x1c91ef,_0x31a5c9=Math['round'](_0x3809ef*Math['pow'](0x2,_0x1798b2-_0x5e65a8)-Math['pow'](0x2,_0x1798b2))):(_0x551214=0x0,_0x31a5c9=Math['round'](_0x3809ef/Math['pow'](0x2,0x1-_0x1c91ef-_0x1798b2))));const _0x32a3ac=[];for(_0x16e456=_0x1798b2;_0x16e456;_0x16e456-=0x1)_0x32a3ac['push'](_0x31a5c9%0x2?0x1:0x0),_0x31a5c9=Math['floor'](_0x31a5c9/0x2);for(_0x16e456=_0x3dc8d4;_0x16e456;_0x16e456-=0x1)_0x32a3ac['push'](_0x551214%0x2?0x1:0x0),_0x551214=Math['floor'](_0x551214/0x2);_0x32a3ac['push'](_0x2f74ec?0x1:0x0),_0x32a3ac['reverse']();const _0x5f572f=_0x32a3ac['join']('');let _0x37a1b7='';for(_0x16e456=0x0;_0x16e456<0x40;_0x16e456+=0x8){let _0x15d658=parseInt(_0x5f572f['substr'](_0x16e456,0x8),0x2)['toString'](0x10);_0x15d658['length']===0x1&&(_0x15d658='0'+_0x15d658),_0x37a1b7=_0x37a1b7+_0x15d658;}return _0x37a1b7['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x522d4f,_0xc691d7){let _0x7a8bff='Unknown\x20Error';_0x522d4f==='too_big'?_0x7a8bff='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x522d4f==='permission_denied'?_0x7a8bff='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x522d4f==='unavailable'&&(_0x7a8bff='The\x20service\x20is\x20unavailable');const _0x42fc2a=new Error(_0x522d4f+'\x20at\x20'+_0xc691d7['_path']['toString']()+':\x20'+_0x7a8bff);return _0x42fc2a['code']=_0x522d4f['toUpperCase'](),_0x42fc2a;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x219c14){if(Yl['test'](_0x219c14)){const _0xa89536=Number(_0x219c14);if(_0xa89536>=Ql&&_0xa89536<=Jl)return _0xa89536;}return null;},ft=function(_0x47d645){try{_0x47d645();}catch(_0x1302f3){setTimeout(()=>{const _0x59b33a=_0x1302f3['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x59b33a),_0x1302f3;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x1aab26,_0x1148b0){const _0x429ffd=setTimeout(_0x1aab26,_0x1148b0);return typeof _0x429ffd=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x429ffd):typeof _0x429ffd=='object'&&_0x429ffd['unref']&&_0x429ffd['unref'](),_0x429ffd;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x4a2ab1,_0x1ffc05){this['appCheckProvider']=_0x1ffc05,this['appName']=_0x4a2ab1['name'],$(_0x4a2ab1)&&_0x4a2ab1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4a2ab1['settings']['appCheckToken']),this['appCheck']=_0x1ffc05==null?void 0x0:_0x1ffc05['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1ffc05==null||_0x1ffc05['get']()['then'](_0x573470=>this['appCheck']=_0x573470);}['getToken'](_0x2a123f){if(this['serverAppAppCheckToken']){if(_0x2a123f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2a123f):new Promise((_0x34affd,_0x5622de)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2a123f)['then'](_0x34affd,_0x5622de):_0x34affd(null);},0x0);});}['addTokenChangeListener'](_0x5b01a2){var _0x25e8f3;(_0x25e8f3=this['appCheckProvider'])==null||_0x25e8f3['get']()['then'](_0x1631b6=>_0x1631b6['addTokenListener'](_0x5b01a2));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x41d061,_0x436a6b,_0xcb37da){this['appName_']=_0x41d061,this['firebaseOptions_']=_0x436a6b,this['authProvider_']=_0xcb37da,this['auth_']=null,this['auth_']=_0xcb37da['getImmediate']({'optional':!0x0}),this['auth_']||_0xcb37da['onInit'](_0x44321c=>this['auth_']=_0x44321c);}['getToken'](_0x5bd627){return this['auth_']?this['auth_']['getToken'](_0x5bd627)['catch'](_0x22467b=>_0x22467b&&_0x22467b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x22467b)):new Promise((_0x5bd54a,_0x9ce95e)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x5bd627)['then'](_0x5bd54a,_0x9ce95e):_0x5bd54a(null);},0x0);});}['addTokenChangeListener'](_0x2ed8b8){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2ed8b8):this['authProvider_']['get']()['then'](_0x12cd2c=>_0x12cd2c['addAuthTokenListener'](_0x2ed8b8));}['removeTokenChangeListener'](_0x3c9b70){this['authProvider_']['get']()['then'](_0x162d48=>_0x162d48['removeAuthTokenListener'](_0x3c9b70));}['notifyForInvalidToken'](){let _0x1975c3='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1975c3+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1975c3+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1975c3+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1975c3);}}class an{constructor(_0x2a9100){this['accessToken']=_0x2a9100;}['getToken'](_0x32e8b6){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x757666){_0x757666(this['accessToken']);}['removeTokenChangeListener'](_0x534b74){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x544175,_0x5c3b4a,_0x521de0,_0x3974b5,_0x34540b=!0x1,_0x38c1b0='',_0x908477=!0x1,_0x5c2b9e=!0x1,_0x2a8cc9=null){this['secure']=_0x5c3b4a,this['namespace']=_0x521de0,this['webSocketOnly']=_0x3974b5,this['nodeAdmin']=_0x34540b,this['persistenceKey']=_0x38c1b0,this['includeNamespaceInQueryParams']=_0x908477,this['isUsingEmulator']=_0x5c2b9e,this['emulatorOptions']=_0x2a8cc9,this['_host']=_0x544175['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x544175)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x47688d){_0x47688d!==this['internalHost']&&(this['internalHost']=_0x47688d,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xedcfff=this['toURLString']();return this['persistenceKey']&&(_0xedcfff+='<'+this['persistenceKey']+'>'),_0xedcfff;}['toURLString'](){const _0x30f903=this['secure']?'https://':'http://',_0x3f9003=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x30f903+this['host']+'/'+_0x3f9003;}}function th(_0x3b4f67){return _0x3b4f67['host']!==_0x3b4f67['internalHost']||_0x3b4f67['isCustomHost']()||_0x3b4f67['includeNamespaceInQueryParams'];}function vo(_0x29197d,_0x420c0d,_0x7c073b){f(typeof _0x420c0d=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x7c073b=='object','typeof\x20params\x20must\x20==\x20object');let _0x1200c5;if(_0x420c0d===go)_0x1200c5=(_0x29197d['secure']?'wss://':'ws://')+_0x29197d['internalHost']+'/.ws?';else{if(_0x420c0d===mo)_0x1200c5=(_0x29197d['secure']?'https://':'http://')+_0x29197d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x420c0d);}th(_0x29197d)&&(_0x7c073b['ns']=_0x29197d['namespace']);const _0x341ef6=[];return x(_0x7c073b,(_0x56226f,_0x70606d)=>{_0x341ef6['push'](_0x56226f+'='+_0x70606d);}),_0x1200c5+_0x341ef6['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x4b7012,_0x4446e4=0x1){Q(this['counters_'],_0x4b7012)||(this['counters_'][_0x4b7012]=0x0),this['counters_'][_0x4b7012]+=_0x4446e4;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x4d85dd){const _0x4fde6e=_0x4d85dd['toString']();return oi[_0x4fde6e]||(oi[_0x4fde6e]=new nh()),oi[_0x4fde6e];}function ih(_0x4803ac,_0x3125a3){const _0x56b22f=_0x4803ac['toString']();return ai[_0x56b22f]||(ai[_0x56b22f]=_0x3125a3()),ai[_0x56b22f];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4a896a){this['onMessage_']=_0x4a896a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3572f6,_0x192932){this['closeAfterResponse']=_0x3572f6,this['onClose']=_0x192932,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2bc217,_0x3e5313){for(this['pendingResponses'][_0x2bc217]=_0x3e5313;this['pendingResponses'][this['currentResponseNum']];){const _0x230eca=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x383ab9=0x0;_0x383ab9<_0x230eca['length'];++_0x383ab9)_0x230eca[_0x383ab9]&&ft(()=>{this['onMessage_'](_0x230eca[_0x383ab9]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x102af4,_0x33486d,_0x31ccdf,_0x4a0327,_0x210882,_0x2b5a03,_0x5d0a53){this['connId']=_0x102af4,this['repoInfo']=_0x33486d,this['applicationId']=_0x31ccdf,this['appCheckToken']=_0x4a0327,this['authToken']=_0x210882,this['transportSessionId']=_0x2b5a03,this['lastSessionId']=_0x5d0a53,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x102af4),this['stats_']=qi(_0x33486d),this['urlFn']=_0x2a28cd=>(this['appCheckToken']&&(_0x2a28cd[wi]=this['appCheckToken']),vo(_0x33486d,mo,_0x2a28cd));}['open'](_0x310547,_0x198160){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x198160,this['myPacketOrderer']=new sh(_0x310547),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0xbf0d15)=>{const [_0x32873a,_0x1174e6,_0x3ec727,_0x21878b,_0x101325]=_0xbf0d15;if(this['incrementIncomingBytes_'](_0xbf0d15),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x32873a===qs)this['id']=_0x1174e6,this['password']=_0x3ec727;else{if(_0x32873a===rh)_0x1174e6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1174e6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x32873a);}}},(..._0x217646)=>{const [_0x5d5879,_0x2410e0]=_0x217646;this['incrementIncomingBytes_'](_0x217646),this['myPacketOrderer']['handleResponse'](_0x5d5879,_0x2410e0);},()=>{this['onClosed_']();},this['urlFn']);const _0x3ef533={};_0x3ef533[qs]='t',_0x3ef533[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3ef533[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3ef533[co]=Gi,this['transportSessionId']&&(_0x3ef533[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3ef533[po]=this['lastSessionId']),this['applicationId']&&(_0x3ef533[_o]=this['applicationId']),this['appCheckToken']&&(_0x3ef533[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3ef533[ho]=uo);const _0x3f7f59=this['urlFn'](_0x3ef533);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3f7f59),this['scriptTagHolder']['addTag'](_0x3f7f59,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3d3a5b){const _0x1a3148=O(_0x3d3a5b);this['bytesSent']+=_0x1a3148['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1a3148['length']);const _0x5c8b9f=$r(_0x1a3148),_0x4b44c3=oo(_0x5c8b9f,fh);for(let _0x108e0f=0x0;_0x108e0f<_0x4b44c3['length'];_0x108e0f++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4b44c3['length'],_0x4b44c3[_0x108e0f]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xc21671,_0x4a989b){this['myDisconnFrame']=document['createElement']('iframe');const _0x3c0e06={};_0x3c0e06[dh]='t',_0x3c0e06[Eo]=_0xc21671,_0x3c0e06[Io]=_0x4a989b,this['myDisconnFrame']['src']=this['urlFn'](_0x3c0e06),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1d45a9){const _0x5987d3=O(_0x1d45a9)['length'];this['bytesReceived']+=_0x5987d3,this['stats_']['incrementCounter']('bytes_received',_0x5987d3);}}class zi{constructor(_0x8e9d82,_0x4e4438,_0x78cf36,_0x513a8c){this['onDisconnect']=_0x78cf36,this['urlFn']=_0x513a8c,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x8e9d82,window[ah+this['uniqueCallbackIdentifier']]=_0x4e4438,this['myIFrame']=zi['createIFrame_']();let _0xa3190c='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0xa3190c='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x33a974='<html><body>'+_0xa3190c+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x33a974),this['myIFrame']['doc']['close']();}catch(_0x5e5d5d){L('frame\x20writing\x20exception'),_0x5e5d5d['stack']&&L(_0x5e5d5d['stack']),L(_0x5e5d5d);}}}static['createIFrame_'](){const _0x964c94=document['createElement']('iframe');if(_0x964c94['style']['display']='none',document['body']){document['body']['appendChild'](_0x964c94);try{_0x964c94['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x272eed=document['domain'];_0x964c94['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x272eed+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x964c94['contentDocument']?_0x964c94['doc']=_0x964c94['contentDocument']:_0x964c94['contentWindow']?_0x964c94['doc']=_0x964c94['contentWindow']['document']:_0x964c94['document']&&(_0x964c94['doc']=_0x964c94['document']),_0x964c94;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2272c3=this['onDisconnect'];_0x2272c3&&(this['onDisconnect']=null,_0x2272c3());}['startLongPoll'](_0x54340a,_0x5058bb){for(this['myID']=_0x54340a,this['myPW']=_0x5058bb,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5499c5={};_0x5499c5[Eo]=this['myID'],_0x5499c5[Io]=this['myPW'],_0x5499c5[wo]=this['currentSerial'];let _0x4085de=this['urlFn'](_0x5499c5),_0x5acede='',_0x1879be=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5acede['length']<=Co;){const _0x4ce386=this['pendingSegs']['shift']();_0x5acede=_0x5acede+'&'+lh+_0x1879be+'='+_0x4ce386['seg']+'&'+hh+_0x1879be+'='+_0x4ce386['ts']+'&'+uh+_0x1879be+'='+_0x4ce386['d'],_0x1879be++;}return _0x4085de=_0x4085de+_0x5acede,this['addLongPollTag_'](_0x4085de,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x403519,_0xec1698,_0x564a9c){this['pendingSegs']['push']({'seg':_0x403519,'ts':_0xec1698,'d':_0x564a9c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x44f912,_0x5f58bc){this['outstandingRequests']['add'](_0x5f58bc);const _0x4dcbdb=()=>{this['outstandingRequests']['delete'](_0x5f58bc),this['newRequest_']();},_0x4965a8=setTimeout(_0x4dcbdb,Math['floor'](ph)),_0x369fde=()=>{clearTimeout(_0x4965a8),_0x4dcbdb();};this['addTag'](_0x44f912,_0x369fde);}['addTag'](_0x5cf409,_0x37d804){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xf39866=this['myIFrame']['doc']['createElement']('script');_0xf39866['type']='text/javascript',_0xf39866['async']=!0x0,_0xf39866['src']=_0x5cf409,_0xf39866['onload']=_0xf39866['onreadystatechange']=function(){const _0x1d8bbd=_0xf39866['readyState'];(!_0x1d8bbd||_0x1d8bbd==='loaded'||_0x1d8bbd==='complete')&&(_0xf39866['onload']=_0xf39866['onreadystatechange']=null,_0xf39866['parentNode']&&_0xf39866['parentNode']['removeChild'](_0xf39866),_0x37d804());},_0xf39866['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x5cf409),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xf39866);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x150dbe,_0x40721e,_0x4a08d6,_0x1651b3,_0x9ebbd6,_0x25bd49,_0x20d04e){this['connId']=_0x150dbe,this['applicationId']=_0x4a08d6,this['appCheckToken']=_0x1651b3,this['authToken']=_0x9ebbd6,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x40721e),this['connURL']=q['connectionURL_'](_0x40721e,_0x25bd49,_0x20d04e,_0x1651b3,_0x4a08d6),this['nodeAdmin']=_0x40721e['nodeAdmin'];}static['connectionURL_'](_0x146b55,_0x354ab8,_0x1be17c,_0x55de09,_0x5b2160){const _0x25612c={};return _0x25612c[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x25612c[ho]=uo),_0x354ab8&&(_0x25612c[lo]=_0x354ab8),_0x1be17c&&(_0x25612c[po]=_0x1be17c),_0x55de09&&(_0x25612c[wi]=_0x55de09),_0x5b2160&&(_0x25612c[_o]=_0x5b2160),vo(_0x146b55,go,_0x25612c);}['open'](_0xf87cc7,_0x56d24d){this['onDisconnect']=_0x56d24d,this['onMessage']=_0xf87cc7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x2fa776;_c(),this['mySock']=new gn(this['connURL'],[],_0x2fa776);}catch(_0x169eb9){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x3d1b1=_0x169eb9['message']||_0x169eb9['data'];_0x3d1b1&&this['log_'](_0x3d1b1),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xf0dbbf=>{this['handleIncomingFrame'](_0xf0dbbf);},this['mySock']['onerror']=_0xcd91e=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2f44cd=_0xcd91e['message']||_0xcd91e['data'];_0x2f44cd&&this['log_'](_0x2f44cd),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2ff93f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x983dc0=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1fc6dc=navigator['userAgent']['match'](_0x983dc0);_0x1fc6dc&&_0x1fc6dc['length']>0x1&&parseFloat(_0x1fc6dc[0x1])<4.4&&(_0x2ff93f=!0x0);}return!_0x2ff93f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x4e5286){if(this['frames']['push'](_0x4e5286),this['frames']['length']===this['totalFrames']){const _0x36c5de=this['frames']['join']('');this['frames']=null;const _0x328418=Nt(_0x36c5de);this['onMessage'](_0x328418);}}['handleNewFrameCount_'](_0x155935){this['totalFrames']=_0x155935,this['frames']=[];}['extractFrameCount_'](_0x1a1902){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1a1902['length']<=0x6){const _0x5d7ea1=Number(_0x1a1902);if(!isNaN(_0x5d7ea1))return this['handleNewFrameCount_'](_0x5d7ea1),null;}return this['handleNewFrameCount_'](0x1),_0x1a1902;}['handleIncomingFrame'](_0x180a9b){if(this['mySock']===null)return;const _0x5111=_0x180a9b['data'];if(this['bytesReceived']+=_0x5111['length'],this['stats_']['incrementCounter']('bytes_received',_0x5111['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5111);else{const _0x2c76f5=this['extractFrameCount_'](_0x5111);_0x2c76f5!==null&&this['appendFrame_'](_0x2c76f5);}}['send'](_0x54d788){this['resetKeepAlive']();const _0x2e563b=O(_0x54d788);this['bytesSent']+=_0x2e563b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2e563b['length']);const _0x2c2bf3=oo(_0x2e563b,gh);_0x2c2bf3['length']>0x1&&this['sendString_'](String(_0x2c2bf3['length']));for(let _0x4ccb88=0x0;_0x4ccb88<_0x2c2bf3['length'];_0x4ccb88++)this['sendString_'](_0x2c2bf3[_0x4ccb88]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x30e278){try{this['mySock']['send'](_0x30e278);}catch(_0x46dea1){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x46dea1['message']||_0x46dea1['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2faa25){this['initTransports_'](_0x2faa25);}['initTransports_'](_0x505dd0){const _0x7423d0=q&&q['isAvailable']();let _0x220c68=_0x7423d0&&!q['previouslyFailed']();if(_0x505dd0['webSocketOnly']&&(_0x7423d0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x220c68=!0x0),_0x220c68)this['transports_']=[q];else{const _0x37e6cd=this['transports_']=[];for(const _0x38406d of Dt['ALL_TRANSPORTS'])_0x38406d&&_0x38406d['isAvailable']()&&_0x37e6cd['push'](_0x38406d);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x52634c,_0x5ae43a,_0x594f63,_0x293c43,_0x3bebdf,_0x591655,_0x1f0420,_0x36e0cf,_0x53c07e,_0x126d4d){this['id']=_0x52634c,this['repoInfo_']=_0x5ae43a,this['applicationId_']=_0x594f63,this['appCheckToken_']=_0x293c43,this['authToken_']=_0x3bebdf,this['onMessage_']=_0x591655,this['onReady_']=_0x1f0420,this['onDisconnect_']=_0x36e0cf,this['onKill_']=_0x53c07e,this['lastSessionId']=_0x126d4d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x5ae43a),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4696aa=this['transportManager_']['initialTransport']();this['conn_']=new _0x4696aa(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4696aa['responsesRequiredToBeHealthy']||0x0;const _0x205e24=this['connReceiver_'](this['conn_']),_0x193130=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x205e24,_0x193130);},Math['floor'](0x0));const _0x427eb=_0x4696aa['healthyTimeout']||0x0;_0x427eb>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x427eb)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x5dbafe){return _0xa48f0e=>{_0x5dbafe===this['conn_']?this['onConnectionLost_'](_0xa48f0e):_0x5dbafe===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4461a9){return _0x2a6c88=>{this['state_']!==0x2&&(_0x4461a9===this['rx_']?this['onPrimaryMessageReceived_'](_0x2a6c88):_0x4461a9===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2a6c88):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x47c1ad){const _0x500c49={'t':'d','d':_0x47c1ad};this['sendData_'](_0x500c49);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4c88fd){if(ci in _0x4c88fd){const _0x30f726=_0x4c88fd[ci];_0x30f726===Ys?this['upgradeIfSecondaryHealthy_']():_0x30f726===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x30f726===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xf272c7){const _0x54eece=vt('t',_0xf272c7),_0x4ecb4f=vt('d',_0xf272c7);if(_0x54eece==='c')this['onSecondaryControl_'](_0x4ecb4f);else{if(_0x54eece==='d')this['pendingDataMessages']['push'](_0x4ecb4f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x54eece);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x17ceb2){const _0x513221=vt('t',_0x17ceb2),_0x22b3c5=vt('d',_0x17ceb2);_0x513221==='c'?this['onControl_'](_0x22b3c5):_0x513221==='d'&&this['onDataMessage_'](_0x22b3c5);}['onDataMessage_'](_0x45dd3d){this['onPrimaryResponse_'](),this['onMessage_'](_0x45dd3d);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x45c64e){const _0x141a87=vt(ci,_0x45c64e);if(zs in _0x45c64e){const _0x3f79e6=_0x45c64e[zs];if(_0x141a87===Th){const _0x1ccacd={..._0x3f79e6};this['repoInfo_']['isUsingEmulator']&&(_0x1ccacd['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x1ccacd);}else{if(_0x141a87===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1e6811=0x0;_0x1e6811<this['pendingDataMessages']['length'];++_0x1e6811)this['onDataMessage_'](this['pendingDataMessages'][_0x1e6811]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x141a87===wh?this['onConnectionShutdown_'](_0x3f79e6):_0x141a87===js?this['onReset_'](_0x3f79e6):_0x141a87===Ch?Ii('Server\x20Error:\x20'+_0x3f79e6):_0x141a87===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x141a87);}}}['onHandshake_'](_0x2e688a){const _0x4f146c=_0x2e688a['ts'],_0x260c11=_0x2e688a['v'],_0x4c66bd=_0x2e688a['h'];this['sessionId']=_0x2e688a['s'],this['repoInfo_']['host']=_0x4c66bd,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4f146c),Gi!==_0x260c11&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xdbad78=this['transportManager_']['upgradeTransport']();_0xdbad78&&this['startUpgrade_'](_0xdbad78);}['startUpgrade_'](_0x33614b){this['secondaryConn_']=new _0x33614b(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x33614b['responsesRequiredToBeHealthy']||0x0;const _0x36ebdf=this['connReceiver_'](this['secondaryConn_']),_0x3de6a6=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x36ebdf,_0x3de6a6),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x20773c){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x20773c),this['repoInfo_']['host']=_0x20773c,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4bfeba,_0x5897fa){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4bfeba,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5897fa,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x14d6c5=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x14d6c5||this['rx_']===_0x14d6c5)&&this['close']();}['onConnectionLost_'](_0x484946){this['conn_']=null,!_0x484946&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2c8f16){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2c8f16),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3fdb5f){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3fdb5f);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4e6b18,_0x481579,_0x405a5b,_0x12bd3e){}['merge'](_0x3e9e0b,_0x1b5642,_0x583609,_0xf791ab){}['refreshAuthToken'](_0x286afc){}['refreshAppCheckToken'](_0x381a7b){}['onDisconnectPut'](_0x489e69,_0x287c12,_0x522d55){}['onDisconnectMerge'](_0xdf4f9d,_0x24340c,_0x561bf9){}['onDisconnectCancel'](_0x40062e,_0x53e69a){}['reportStats'](_0x182fa8){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xebbe8d){this['allowedEvents_']=_0xebbe8d,this['listeners_']={},f(Array['isArray'](_0xebbe8d)&&_0xebbe8d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x553970,..._0x3545cc){if(Array['isArray'](this['listeners_'][_0x553970])){const _0x478b3d=[...this['listeners_'][_0x553970]];for(let _0x1353c3=0x0;_0x1353c3<_0x478b3d['length'];_0x1353c3++)_0x478b3d[_0x1353c3]['callback']['apply'](_0x478b3d[_0x1353c3]['context'],_0x3545cc);}}['on'](_0x4c32d4,_0x323897,_0x2e6899){this['validateEventType_'](_0x4c32d4),this['listeners_'][_0x4c32d4]=this['listeners_'][_0x4c32d4]||[],this['listeners_'][_0x4c32d4]['push']({'callback':_0x323897,'context':_0x2e6899});const _0xf479e5=this['getInitialEvent'](_0x4c32d4);_0xf479e5&&_0x323897['apply'](_0x2e6899,_0xf479e5);}['off'](_0x16e786,_0x5cc3aa,_0x3f058f){this['validateEventType_'](_0x16e786);const _0x5c0b01=this['listeners_'][_0x16e786]||[];for(let _0x39f0a5=0x0;_0x39f0a5<_0x5c0b01['length'];_0x39f0a5++)if(_0x5c0b01[_0x39f0a5]['callback']===_0x5cc3aa&&(!_0x3f058f||_0x3f058f===_0x5c0b01[_0x39f0a5]['context'])){_0x5c0b01['splice'](_0x39f0a5,0x1);return;}}['validateEventType_'](_0x7a4ebd){f(this['allowedEvents_']['find'](_0x3d67d1=>_0x3d67d1===_0x7a4ebd),'Unknown\x20event:\x20'+_0x7a4ebd);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x7126a7){return f(_0x7126a7==='online','Unknown\x20event\x20type:\x20'+_0x7126a7),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x344314,_0x222e48){if(_0x222e48===void 0x0){this['pieces_']=_0x344314['split']('/');let _0x21fcd9=0x0;for(let _0x32e9ef=0x0;_0x32e9ef<this['pieces_']['length'];_0x32e9ef++)this['pieces_'][_0x32e9ef]['length']>0x0&&(this['pieces_'][_0x21fcd9]=this['pieces_'][_0x32e9ef],_0x21fcd9++);this['pieces_']['length']=_0x21fcd9,this['pieceNum_']=0x0;}else this['pieces_']=_0x344314,this['pieceNum_']=_0x222e48;}['toString'](){let _0x5d09c0='';for(let _0x120843=this['pieceNum_'];_0x120843<this['pieces_']['length'];_0x120843++)this['pieces_'][_0x120843]!==''&&(_0x5d09c0+='/'+this['pieces_'][_0x120843]);return _0x5d09c0||'/';}}function w(){return new C('');}function y(_0x5d3b95){return _0x5d3b95['pieceNum_']>=_0x5d3b95['pieces_']['length']?null:_0x5d3b95['pieces_'][_0x5d3b95['pieceNum_']];}function Ce(_0x57335e){return _0x57335e['pieces_']['length']-_0x57335e['pieceNum_'];}function S(_0x3c33d4){let _0x3e9e9f=_0x3c33d4['pieceNum_'];return _0x3e9e9f<_0x3c33d4['pieces_']['length']&&_0x3e9e9f++,new C(_0x3c33d4['pieces_'],_0x3e9e9f);}function ji(_0x4dfc1){return _0x4dfc1['pieceNum_']<_0x4dfc1['pieces_']['length']?_0x4dfc1['pieces_'][_0x4dfc1['pieces_']['length']-0x1]:null;}function bh(_0x3e0d48){let _0x1f45cf='';for(let _0x6c8870=_0x3e0d48['pieceNum_'];_0x6c8870<_0x3e0d48['pieces_']['length'];_0x6c8870++)_0x3e0d48['pieces_'][_0x6c8870]!==''&&(_0x1f45cf+='/'+encodeURIComponent(String(_0x3e0d48['pieces_'][_0x6c8870])));return _0x1f45cf||'/';}function Mt(_0x5a9d30,_0x52d6a9=0x0){return _0x5a9d30['pieces_']['slice'](_0x5a9d30['pieceNum_']+_0x52d6a9);}function Ro(_0x42ceda){if(_0x42ceda['pieceNum_']>=_0x42ceda['pieces_']['length'])return null;const _0x2d5a53=[];for(let _0x1acaaa=_0x42ceda['pieceNum_'];_0x1acaaa<_0x42ceda['pieces_']['length']-0x1;_0x1acaaa++)_0x2d5a53['push'](_0x42ceda['pieces_'][_0x1acaaa]);return new C(_0x2d5a53,0x0);}function k(_0x23b700,_0x4387e8){const _0x2c9449=[];for(let _0x3b9078=_0x23b700['pieceNum_'];_0x3b9078<_0x23b700['pieces_']['length'];_0x3b9078++)_0x2c9449['push'](_0x23b700['pieces_'][_0x3b9078]);if(_0x4387e8 instanceof C){for(let _0x209c95=_0x4387e8['pieceNum_'];_0x209c95<_0x4387e8['pieces_']['length'];_0x209c95++)_0x2c9449['push'](_0x4387e8['pieces_'][_0x209c95]);}else{const _0x596261=_0x4387e8['split']('/');for(let _0x57da08=0x0;_0x57da08<_0x596261['length'];_0x57da08++)_0x596261[_0x57da08]['length']>0x0&&_0x2c9449['push'](_0x596261[_0x57da08]);}return new C(_0x2c9449,0x0);}function v(_0x465eb8){return _0x465eb8['pieceNum_']>=_0x465eb8['pieces_']['length'];}function F(_0x4d7a77,_0x33b415){const _0x1faa4e=y(_0x4d7a77),_0x20a243=y(_0x33b415);if(_0x1faa4e===null)return _0x33b415;if(_0x1faa4e===_0x20a243)return F(S(_0x4d7a77),S(_0x33b415));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x33b415+')\x20is\x20not\x20within\x20outerPath\x20('+_0x4d7a77+')');}function Rh(_0x51fff2,_0x24297f){const _0x34fa22=Mt(_0x51fff2,0x0),_0x3475bd=Mt(_0x24297f,0x0);for(let _0x53ca74=0x0;_0x53ca74<_0x34fa22['length']&&_0x53ca74<_0x3475bd['length'];_0x53ca74++){const _0x2ab510=qe(_0x34fa22[_0x53ca74],_0x3475bd[_0x53ca74]);if(_0x2ab510!==0x0)return _0x2ab510;}return _0x34fa22['length']===_0x3475bd['length']?0x0:_0x34fa22['length']<_0x3475bd['length']?-0x1:0x1;}function Ki(_0x15f079,_0x1e8ac4){if(Ce(_0x15f079)!==Ce(_0x1e8ac4))return!0x1;for(let _0x19db53=_0x15f079['pieceNum_'],_0x3bd7c7=_0x1e8ac4['pieceNum_'];_0x19db53<=_0x15f079['pieces_']['length'];_0x19db53++,_0x3bd7c7++)if(_0x15f079['pieces_'][_0x19db53]!==_0x1e8ac4['pieces_'][_0x3bd7c7])return!0x1;return!0x0;}function G(_0x1240c8,_0x4a3615){let _0x5f3cc8=_0x1240c8['pieceNum_'],_0x534a61=_0x4a3615['pieceNum_'];if(Ce(_0x1240c8)>Ce(_0x4a3615))return!0x1;for(;_0x5f3cc8<_0x1240c8['pieces_']['length'];){if(_0x1240c8['pieces_'][_0x5f3cc8]!==_0x4a3615['pieces_'][_0x534a61])return!0x1;++_0x5f3cc8,++_0x534a61;}return!0x0;}class Ah{constructor(_0x2a8f67,_0x39dd42){this['errorPrefix_']=_0x39dd42,this['parts_']=Mt(_0x2a8f67,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xd3ae02=0x0;_0xd3ae02<this['parts_']['length'];_0xd3ae02++)this['byteLength_']+=Ln(this['parts_'][_0xd3ae02]);Ao(this);}}function kh(_0x5efdc8,_0x4720c6){_0x5efdc8['parts_']['length']>0x0&&(_0x5efdc8['byteLength_']+=0x1),_0x5efdc8['parts_']['push'](_0x4720c6),_0x5efdc8['byteLength_']+=Ln(_0x4720c6),Ao(_0x5efdc8);}function Ph(_0x16e0ed){const _0x3fc12a=_0x16e0ed['parts_']['pop']();_0x16e0ed['byteLength_']-=Ln(_0x3fc12a),_0x16e0ed['parts_']['length']>0x0&&(_0x16e0ed['byteLength_']-=0x1);}function Ao(_0x19e32f){if(_0x19e32f['byteLength_']>Zs)throw new Error(_0x19e32f['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x19e32f['byteLength_']+').');if(_0x19e32f['parts_']['length']>Xs)throw new Error(_0x19e32f['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x19e32f));}function Oe(_0x4e72c0){return _0x4e72c0['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4e72c0['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0xcd84e4,_0x441dd1;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x441dd1='visibilitychange',_0xcd84e4='hidden'):typeof document['mozHidden']<'u'?(_0x441dd1='mozvisibilitychange',_0xcd84e4='mozHidden'):typeof document['msHidden']<'u'?(_0x441dd1='msvisibilitychange',_0xcd84e4='msHidden'):typeof document['webkitHidden']<'u'&&(_0x441dd1='webkitvisibilitychange',_0xcd84e4='webkitHidden')),this['visible_']=!0x0,_0x441dd1&&document['addEventListener'](_0x441dd1,()=>{const _0x4eb8c6=!document[_0xcd84e4];_0x4eb8c6!==this['visible_']&&(this['visible_']=_0x4eb8c6,this['trigger']('visible',_0x4eb8c6));},!0x1);}['getInitialEvent'](_0x16cc08){return f(_0x16cc08==='visible','Unknown\x20event\x20type:\x20'+_0x16cc08),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4e2399,_0x2ad2ba,_0x4ff8ab,_0x45761f,_0x3690f5,_0x1a1db8,_0x42ce6a,_0x2441a2){if(super(),this['repoInfo_']=_0x4e2399,this['applicationId_']=_0x2ad2ba,this['onDataUpdate_']=_0x4ff8ab,this['onConnectStatus_']=_0x45761f,this['onServerInfoUpdate_']=_0x3690f5,this['authTokenProvider_']=_0x1a1db8,this['appCheckTokenProvider_']=_0x42ce6a,this['authOverride_']=_0x2441a2,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x2441a2)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4e2399['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x183597,_0x48e40b,_0x201fb8){const _0x5c2949=++this['requestNumber_'],_0x1564f0={'r':_0x5c2949,'a':_0x183597,'b':_0x48e40b};this['log_'](O(_0x1564f0)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1564f0),_0x201fb8&&(this['requestCBHash_'][_0x5c2949]=_0x201fb8);}['get'](_0x411237){this['initConnection_']();const _0x50499c=new H(),_0x31fe95={'action':'g','request':{'p':_0x411237['_path']['toString'](),'q':_0x411237['_queryObject']},'onComplete':_0x5fedee=>{const _0x26e860=_0x5fedee['d'];_0x5fedee['s']==='ok'?_0x50499c['resolve'](_0x26e860):_0x50499c['reject'](_0x26e860);}};this['outstandingGets_']['push'](_0x31fe95),this['outstandingGetCount_']++;const _0x1acd0e=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1acd0e),_0x50499c['promise'];}['listen'](_0x56ccbb,_0x4af1a1,_0x215ea5,_0x1bcaa8){this['initConnection_']();const _0x1f7220=_0x56ccbb['_queryIdentifier'],_0x556181=_0x56ccbb['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x556181+'\x20'+_0x1f7220),this['listens']['has'](_0x556181)||this['listens']['set'](_0x556181,new Map()),f(_0x56ccbb['_queryParams']['isDefault']()||!_0x56ccbb['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x556181)['has'](_0x1f7220),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1ac10b={'onComplete':_0x1bcaa8,'hashFn':_0x4af1a1,'query':_0x56ccbb,'tag':_0x215ea5};this['listens']['get'](_0x556181)['set'](_0x1f7220,_0x1ac10b),this['connected_']&&this['sendListen_'](_0x1ac10b);}['sendGet_'](_0x17f3eb){const _0x1a8a78=this['outstandingGets_'][_0x17f3eb];this['sendRequest']('g',_0x1a8a78['request'],_0x5f45be=>{delete this['outstandingGets_'][_0x17f3eb],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1a8a78['onComplete']&&_0x1a8a78['onComplete'](_0x5f45be);});}['sendListen_'](_0x569f41){const _0x59c8be=_0x569f41['query'],_0x4ecb9f=_0x59c8be['_path']['toString'](),_0x331de9=_0x59c8be['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x4ecb9f+'\x20for\x20'+_0x331de9);const _0x4ec078={'p':_0x4ecb9f},_0x2bee65='q';_0x569f41['tag']&&(_0x4ec078['q']=_0x59c8be['_queryObject'],_0x4ec078['t']=_0x569f41['tag']),_0x4ec078['h']=_0x569f41['hashFn'](),this['sendRequest'](_0x2bee65,_0x4ec078,_0x57f85e=>{const _0x628f8b=_0x57f85e['d'],_0x202f26=_0x57f85e['s'];se['warnOnListenWarnings_'](_0x628f8b,_0x59c8be),(this['listens']['get'](_0x4ecb9f)&&this['listens']['get'](_0x4ecb9f)['get'](_0x331de9))===_0x569f41&&(this['log_']('listen\x20response',_0x57f85e),_0x202f26!=='ok'&&this['removeListen_'](_0x4ecb9f,_0x331de9),_0x569f41['onComplete']&&_0x569f41['onComplete'](_0x202f26,_0x628f8b));});}static['warnOnListenWarnings_'](_0x1cd828,_0x31526c){if(_0x1cd828&&typeof _0x1cd828=='object'&&Q(_0x1cd828,'w')){const _0x414702=Le(_0x1cd828,'w');if(Array['isArray'](_0x414702)&&~_0x414702['indexOf']('no_index')){const _0x1314ca='\x22.indexOn\x22:\x20\x22'+_0x31526c['_queryParams']['getIndex']()['toString']()+'\x22',_0x529915=_0x31526c['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1314ca+'\x20at\x20'+_0x529915+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3665ef){this['authToken_']=_0x3665ef,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3665ef);}['reduceReconnectDelayIfAdminCredential_'](_0x5766f3){(_0x5766f3&&_0x5766f3['length']===0x28||wc(_0x5766f3))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x299e86){this['appCheckToken_']=_0x299e86,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5d2467=this['authToken_'],_0x258d34=Ic(_0x5d2467)?'auth':'gauth',_0xeec36={'cred':_0x5d2467};this['authOverride_']===null?_0xeec36['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xeec36['authvar']=this['authOverride_']),this['sendRequest'](_0x258d34,_0xeec36,_0x1a5f96=>{const _0x594708=_0x1a5f96['s'],_0x3166f7=_0x1a5f96['d']||'error';this['authToken_']===_0x5d2467&&(_0x594708==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x594708,_0x3166f7));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xdfd2d=>{const _0x47f096=_0xdfd2d['s'],_0x20c37f=_0xdfd2d['d']||'error';_0x47f096==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x47f096,_0x20c37f);});}['unlisten'](_0x1c44ea,_0x7db19a){const _0x38cd17=_0x1c44ea['_path']['toString'](),_0x73741c=_0x1c44ea['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x38cd17+'\x20'+_0x73741c),f(_0x1c44ea['_queryParams']['isDefault']()||!_0x1c44ea['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x38cd17,_0x73741c)&&this['connected_']&&this['sendUnlisten_'](_0x38cd17,_0x73741c,_0x1c44ea['_queryObject'],_0x7db19a);}['sendUnlisten_'](_0x38563d,_0x1c798c,_0x586f1f,_0x185c0e){this['log_']('Unlisten\x20on\x20'+_0x38563d+'\x20for\x20'+_0x1c798c);const _0x83e94b={'p':_0x38563d},_0x81d129='n';_0x185c0e&&(_0x83e94b['q']=_0x586f1f,_0x83e94b['t']=_0x185c0e),this['sendRequest'](_0x81d129,_0x83e94b);}['onDisconnectPut'](_0x53a1c2,_0x4331a9,_0x550af6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x53a1c2,_0x4331a9,_0x550af6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x53a1c2,'action':'o','data':_0x4331a9,'onComplete':_0x550af6});}['onDisconnectMerge'](_0x662d9a,_0x2422e8,_0x13b9f0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x662d9a,_0x2422e8,_0x13b9f0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x662d9a,'action':'om','data':_0x2422e8,'onComplete':_0x13b9f0});}['onDisconnectCancel'](_0x2054a9,_0x1c70c2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2054a9,null,_0x1c70c2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2054a9,'action':'oc','data':null,'onComplete':_0x1c70c2});}['sendOnDisconnect_'](_0x5040d4,_0x3ba3be,_0x157423,_0x4302c7){const _0x4e7036={'p':_0x3ba3be,'d':_0x157423};this['log_']('onDisconnect\x20'+_0x5040d4,_0x4e7036),this['sendRequest'](_0x5040d4,_0x4e7036,_0x1bc507=>{_0x4302c7&&setTimeout(()=>{_0x4302c7(_0x1bc507['s'],_0x1bc507['d']);},Math['floor'](0x0));});}['put'](_0x59e3f8,_0xbc15e3,_0x1c1df8,_0x5775cb){this['putInternal']('p',_0x59e3f8,_0xbc15e3,_0x1c1df8,_0x5775cb);}['merge'](_0x245a79,_0x4dbbcf,_0x46dd75,_0x521e4b){this['putInternal']('m',_0x245a79,_0x4dbbcf,_0x46dd75,_0x521e4b);}['putInternal'](_0x2ce01a,_0x2229f4,_0x17509b,_0x175f26,_0xb16c81){this['initConnection_']();const _0x22e25e={'p':_0x2229f4,'d':_0x17509b};_0xb16c81!==void 0x0&&(_0x22e25e['h']=_0xb16c81),this['outstandingPuts_']['push']({'action':_0x2ce01a,'request':_0x22e25e,'onComplete':_0x175f26}),this['outstandingPutCount_']++;const _0x307183=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x307183):this['log_']('Buffering\x20put:\x20'+_0x2229f4);}['sendPut_'](_0x47e465){const _0x1f3b00=this['outstandingPuts_'][_0x47e465]['action'],_0x240279=this['outstandingPuts_'][_0x47e465]['request'],_0x125184=this['outstandingPuts_'][_0x47e465]['onComplete'];this['outstandingPuts_'][_0x47e465]['queued']=this['connected_'],this['sendRequest'](_0x1f3b00,_0x240279,_0xfac429=>{this['log_'](_0x1f3b00+'\x20response',_0xfac429),delete this['outstandingPuts_'][_0x47e465],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x125184&&_0x125184(_0xfac429['s'],_0xfac429['d']);});}['reportStats'](_0xb7bc38){if(this['connected_']){const _0x169438={'c':_0xb7bc38};this['log_']('reportStats',_0x169438),this['sendRequest']('s',_0x169438,_0x3941b4=>{if(_0x3941b4['s']!=='ok'){const _0x78594f=_0x3941b4['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x78594f);}});}}['onDataMessage_'](_0x1ee7d8){if('r'in _0x1ee7d8){this['log_']('from\x20server:\x20'+O(_0x1ee7d8));const _0x31b2a4=_0x1ee7d8['r'],_0x22c6c1=this['requestCBHash_'][_0x31b2a4];_0x22c6c1&&(delete this['requestCBHash_'][_0x31b2a4],_0x22c6c1(_0x1ee7d8['b']));}else{if('error'in _0x1ee7d8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1ee7d8['error'];'a'in _0x1ee7d8&&this['onDataPush_'](_0x1ee7d8['a'],_0x1ee7d8['b']);}}['onDataPush_'](_0x790dcd,_0xe4593){this['log_']('handleServerMessage',_0x790dcd,_0xe4593),_0x790dcd==='d'?this['onDataUpdate_'](_0xe4593['p'],_0xe4593['d'],!0x1,_0xe4593['t']):_0x790dcd==='m'?this['onDataUpdate_'](_0xe4593['p'],_0xe4593['d'],!0x0,_0xe4593['t']):_0x790dcd==='c'?this['onListenRevoked_'](_0xe4593['p'],_0xe4593['q']):_0x790dcd==='ac'?this['onAuthRevoked_'](_0xe4593['s'],_0xe4593['d']):_0x790dcd==='apc'?this['onAppCheckRevoked_'](_0xe4593['s'],_0xe4593['d']):_0x790dcd==='sd'?this['onSecurityDebugPacket_'](_0xe4593):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x790dcd)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x262fcc,_0x350425){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x262fcc),this['lastSessionId']=_0x350425,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x43bf93){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x43bf93));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1ee650){_0x1ee650&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1ee650;}['onOnline_'](_0x1fd71d){_0x1fd71d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2a9fbd=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3b603c=Math['max'](0x0,this['reconnectDelay_']-_0x2a9fbd);_0x3b603c=Math['random']()*_0x3b603c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3b603c+'ms'),this['scheduleConnect_'](_0x3b603c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x2c43f0=this['onDataMessage_']['bind'](this),_0x3bc4bc=this['onReady_']['bind'](this),_0x16b1d7=this['onRealtimeDisconnect_']['bind'](this),_0x55bb16=this['id']+':'+se['nextConnectionId_']++,_0x4d2000=this['lastSessionId'];let _0x173059=!0x1,_0x106663=null;const _0x371893=function(){_0x106663?_0x106663['close']():(_0x173059=!0x0,_0x16b1d7());},_0x19e39d=function(_0x157aaa){f(_0x106663,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x106663['sendRequest'](_0x157aaa);};this['realtime_']={'close':_0x371893,'sendRequest':_0x19e39d};const _0x451059=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x43dbdc,_0x233296]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x451059),this['appCheckTokenProvider_']['getToken'](_0x451059)]);_0x173059?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x43dbdc&&_0x43dbdc['accessToken'],this['appCheckToken_']=_0x233296&&_0x233296['token'],_0x106663=new Sh(_0x55bb16,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x2c43f0,_0x3bc4bc,_0x16b1d7,_0x46b12e=>{U(_0x46b12e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x4d2000));}catch(_0x41460b){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x41460b),_0x173059||(this['repoInfo_']['nodeAdmin']&&U(_0x41460b),_0x371893());}}}['interrupt'](_0x18ffca){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x18ffca),this['interruptReasons_'][_0x18ffca]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5e6957){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5e6957),delete this['interruptReasons_'][_0x5e6957],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x204542){const _0x2e2982=_0x204542-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2e2982});}['cancelSentTransactions_'](){for(let _0x3d7320=0x0;_0x3d7320<this['outstandingPuts_']['length'];_0x3d7320++){const _0xd83e4e=this['outstandingPuts_'][_0x3d7320];_0xd83e4e&&'h'in _0xd83e4e['request']&&_0xd83e4e['queued']&&(_0xd83e4e['onComplete']&&_0xd83e4e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3d7320],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4a33ea,_0x359598){let _0x12179f;_0x359598?_0x12179f=_0x359598['map'](_0x342295=>$i(_0x342295))['join']('$'):_0x12179f='default';const _0x3c61ae=this['removeListen_'](_0x4a33ea,_0x12179f);_0x3c61ae&&_0x3c61ae['onComplete']&&_0x3c61ae['onComplete']('permission_denied');}['removeListen_'](_0xf6843,_0xf9ec02){const _0x3051fc=new C(_0xf6843)['toString']();let _0xfbd123;if(this['listens']['has'](_0x3051fc)){const _0x18a182=this['listens']['get'](_0x3051fc);_0xfbd123=_0x18a182['get'](_0xf9ec02),_0x18a182['delete'](_0xf9ec02),_0x18a182['size']===0x0&&this['listens']['delete'](_0x3051fc);}else _0xfbd123=void 0x0;return _0xfbd123;}['onAuthRevoked_'](_0x3ae274,_0x5a36d6){L('Auth\x20token\x20revoked:\x20'+_0x3ae274+'/'+_0x5a36d6),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3ae274==='invalid_token'||_0x3ae274==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1b41c4,_0x30862f){L('App\x20check\x20token\x20revoked:\x20'+_0x1b41c4+'/'+_0x30862f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1b41c4==='invalid_token'||_0x1b41c4==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5c7a8d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5c7a8d):'msg'in _0x5c7a8d&&console['log']('FIREBASE:\x20'+_0x5c7a8d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0xced83 of this['listens']['values']())for(const _0x4b696d of _0xced83['values']())this['sendListen_'](_0x4b696d);for(let _0x4bf814=0x0;_0x4bf814<this['outstandingPuts_']['length'];_0x4bf814++)this['outstandingPuts_'][_0x4bf814]&&this['sendPut_'](_0x4bf814);for(;this['onDisconnectRequestQueue_']['length'];){const _0x37b149=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x37b149['action'],_0x37b149['pathString'],_0x37b149['data'],_0x37b149['onComplete']);}for(let _0x3b579a=0x0;_0x3b579a<this['outstandingGets_']['length'];_0x3b579a++)this['outstandingGets_'][_0x3b579a]&&this['sendGet_'](_0x3b579a);}['sendConnectStats_'](){const _0xb9229f={};let _0x449c02='js';_0xb9229f['sdk.'+_0x449c02+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xb9229f['framework.cordova']=0x1:Kr()&&(_0xb9229f['framework.reactnative']=0x1),this['reportStats'](_0xb9229f);}['shouldReconnect_'](){const _0x195136=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x195136;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x481f22,_0x4894c2){this['name']=_0x481f22,this['node']=_0x4894c2;}static['Wrap'](_0x219b8f,_0x1f64e9){return new E(_0x219b8f,_0x1f64e9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x76dc44,_0xb05829){const _0x49284e=new E(We,_0x76dc44),_0x5ddfe3=new E(We,_0xb05829);return this['compare'](_0x49284e,_0x5ddfe3)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x499398){sn=_0x499398;}['compare'](_0xc3b9cc,_0x485055){return qe(_0xc3b9cc['name'],_0x485055['name']);}['isDefinedOn'](_0x5c2465){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x54c1ac,_0x534cbe){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x56756f,_0x42b41a){return f(typeof _0x56756f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x56756f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x42b2c9,_0x28473f,_0x3beb44,_0x27bba4,_0x15455a=null){this['isReverse_']=_0x27bba4,this['resultGenerator_']=_0x15455a,this['nodeStack_']=[];let _0x5f5c12=0x1;for(;!_0x42b2c9['isEmpty']();)if(_0x42b2c9=_0x42b2c9,_0x5f5c12=_0x28473f?_0x3beb44(_0x42b2c9['key'],_0x28473f):0x1,_0x27bba4&&(_0x5f5c12*=-0x1),_0x5f5c12<0x0)this['isReverse_']?_0x42b2c9=_0x42b2c9['left']:_0x42b2c9=_0x42b2c9['right'];else{if(_0x5f5c12===0x0){this['nodeStack_']['push'](_0x42b2c9);break;}else this['nodeStack_']['push'](_0x42b2c9),this['isReverse_']?_0x42b2c9=_0x42b2c9['right']:_0x42b2c9=_0x42b2c9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4b8998=this['nodeStack_']['pop'](),_0x5782e8;if(this['resultGenerator_']?_0x5782e8=this['resultGenerator_'](_0x4b8998['key'],_0x4b8998['value']):_0x5782e8={'key':_0x4b8998['key'],'value':_0x4b8998['value']},this['isReverse_']){for(_0x4b8998=_0x4b8998['left'];!_0x4b8998['isEmpty']();)this['nodeStack_']['push'](_0x4b8998),_0x4b8998=_0x4b8998['right'];}else{for(_0x4b8998=_0x4b8998['right'];!_0x4b8998['isEmpty']();)this['nodeStack_']['push'](_0x4b8998),_0x4b8998=_0x4b8998['left'];}return _0x5782e8;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x45bc54=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x45bc54['key'],_0x45bc54['value']):{'key':_0x45bc54['key'],'value':_0x45bc54['value']};}}class M{constructor(_0x301d3f,_0x8a3c85,_0x162477,_0x16a568,_0x5d1c17){this['key']=_0x301d3f,this['value']=_0x8a3c85,this['color']=_0x162477??M['RED'],this['left']=_0x16a568??B['EMPTY_NODE'],this['right']=_0x5d1c17??B['EMPTY_NODE'];}['copy'](_0x1574e4,_0xa556ca,_0x2b04a8,_0x3472eb,_0x188e3b){return new M(_0x1574e4??this['key'],_0xa556ca??this['value'],_0x2b04a8??this['color'],_0x3472eb??this['left'],_0x188e3b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x403387){return this['left']['inorderTraversal'](_0x403387)||!!_0x403387(this['key'],this['value'])||this['right']['inorderTraversal'](_0x403387);}['reverseTraversal'](_0x4b8742){return this['right']['reverseTraversal'](_0x4b8742)||_0x4b8742(this['key'],this['value'])||this['left']['reverseTraversal'](_0x4b8742);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x2e188b,_0x2bbf28,_0x595ca5){let _0x1f0955=this;const _0x4acf96=_0x595ca5(_0x2e188b,_0x1f0955['key']);return _0x4acf96<0x0?_0x1f0955=_0x1f0955['copy'](null,null,null,_0x1f0955['left']['insert'](_0x2e188b,_0x2bbf28,_0x595ca5),null):_0x4acf96===0x0?_0x1f0955=_0x1f0955['copy'](null,_0x2bbf28,null,null,null):_0x1f0955=_0x1f0955['copy'](null,null,null,null,_0x1f0955['right']['insert'](_0x2e188b,_0x2bbf28,_0x595ca5)),_0x1f0955['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x18ea88=this;return!_0x18ea88['left']['isRed_']()&&!_0x18ea88['left']['left']['isRed_']()&&(_0x18ea88=_0x18ea88['moveRedLeft_']()),_0x18ea88=_0x18ea88['copy'](null,null,null,_0x18ea88['left']['removeMin_'](),null),_0x18ea88['fixUp_']();}['remove'](_0x4ac33e,_0x248ed7){let _0x3faf0e,_0x4124e2;if(_0x3faf0e=this,_0x248ed7(_0x4ac33e,_0x3faf0e['key'])<0x0)!_0x3faf0e['left']['isEmpty']()&&!_0x3faf0e['left']['isRed_']()&&!_0x3faf0e['left']['left']['isRed_']()&&(_0x3faf0e=_0x3faf0e['moveRedLeft_']()),_0x3faf0e=_0x3faf0e['copy'](null,null,null,_0x3faf0e['left']['remove'](_0x4ac33e,_0x248ed7),null);else{if(_0x3faf0e['left']['isRed_']()&&(_0x3faf0e=_0x3faf0e['rotateRight_']()),!_0x3faf0e['right']['isEmpty']()&&!_0x3faf0e['right']['isRed_']()&&!_0x3faf0e['right']['left']['isRed_']()&&(_0x3faf0e=_0x3faf0e['moveRedRight_']()),_0x248ed7(_0x4ac33e,_0x3faf0e['key'])===0x0){if(_0x3faf0e['right']['isEmpty']())return B['EMPTY_NODE'];_0x4124e2=_0x3faf0e['right']['min_'](),_0x3faf0e=_0x3faf0e['copy'](_0x4124e2['key'],_0x4124e2['value'],null,null,_0x3faf0e['right']['removeMin_']());}_0x3faf0e=_0x3faf0e['copy'](null,null,null,null,_0x3faf0e['right']['remove'](_0x4ac33e,_0x248ed7));}return _0x3faf0e['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2c5a61=this;return _0x2c5a61['right']['isRed_']()&&!_0x2c5a61['left']['isRed_']()&&(_0x2c5a61=_0x2c5a61['rotateLeft_']()),_0x2c5a61['left']['isRed_']()&&_0x2c5a61['left']['left']['isRed_']()&&(_0x2c5a61=_0x2c5a61['rotateRight_']()),_0x2c5a61['left']['isRed_']()&&_0x2c5a61['right']['isRed_']()&&(_0x2c5a61=_0x2c5a61['colorFlip_']()),_0x2c5a61;}['moveRedLeft_'](){let _0x43fdb5=this['colorFlip_']();return _0x43fdb5['right']['left']['isRed_']()&&(_0x43fdb5=_0x43fdb5['copy'](null,null,null,null,_0x43fdb5['right']['rotateRight_']()),_0x43fdb5=_0x43fdb5['rotateLeft_'](),_0x43fdb5=_0x43fdb5['colorFlip_']()),_0x43fdb5;}['moveRedRight_'](){let _0x2c5278=this['colorFlip_']();return _0x2c5278['left']['left']['isRed_']()&&(_0x2c5278=_0x2c5278['rotateRight_'](),_0x2c5278=_0x2c5278['colorFlip_']()),_0x2c5278;}['rotateLeft_'](){const _0x338b01=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x338b01,null);}['rotateRight_'](){const _0x2cce19=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2cce19);}['colorFlip_'](){const _0x3d934a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x552c3c=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3d934a,_0x552c3c);}['checkMaxDepth_'](){const _0x3a384a=this['check_']();return Math['pow'](0x2,_0x3a384a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x50402b=this['left']['check_']();if(_0x50402b!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x50402b+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1cf27a,_0x465ccc,_0x2ba95f,_0x446e1a,_0x18f0b5){return this;}['insert'](_0x577206,_0x4f6e84,_0x50d763){return new M(_0x577206,_0x4f6e84,null);}['remove'](_0xc4dfeb,_0x842854){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x47300b){return!0x1;}['reverseTraversal'](_0x5b70d9){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x50a9a8,_0x433a09=B['EMPTY_NODE']){this['comparator_']=_0x50a9a8,this['root_']=_0x433a09;}['insert'](_0x35000b,_0x2c86b1){return new B(this['comparator_'],this['root_']['insert'](_0x35000b,_0x2c86b1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x20c736){return new B(this['comparator_'],this['root_']['remove'](_0x20c736,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x6773ef){let _0x2b862e,_0x1622b5=this['root_'];for(;!_0x1622b5['isEmpty']();){if(_0x2b862e=this['comparator_'](_0x6773ef,_0x1622b5['key']),_0x2b862e===0x0)return _0x1622b5['value'];_0x2b862e<0x0?_0x1622b5=_0x1622b5['left']:_0x2b862e>0x0&&(_0x1622b5=_0x1622b5['right']);}return null;}['getPredecessorKey'](_0x24e38e){let _0x40669c,_0x5defd5=this['root_'],_0x44e7b1=null;for(;!_0x5defd5['isEmpty']();)if(_0x40669c=this['comparator_'](_0x24e38e,_0x5defd5['key']),_0x40669c===0x0){if(_0x5defd5['left']['isEmpty']())return _0x44e7b1?_0x44e7b1['key']:null;for(_0x5defd5=_0x5defd5['left'];!_0x5defd5['right']['isEmpty']();)_0x5defd5=_0x5defd5['right'];return _0x5defd5['key'];}else _0x40669c<0x0?_0x5defd5=_0x5defd5['left']:_0x40669c>0x0&&(_0x44e7b1=_0x5defd5,_0x5defd5=_0x5defd5['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2f2ac4){return this['root_']['inorderTraversal'](_0x2f2ac4);}['reverseTraversal'](_0x326bb6){return this['root_']['reverseTraversal'](_0x326bb6);}['getIterator'](_0x22121b){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x22121b);}['getIteratorFrom'](_0x27db25,_0x5e6841){return new rn(this['root_'],_0x27db25,this['comparator_'],!0x1,_0x5e6841);}['getReverseIteratorFrom'](_0x238ef,_0x4dad72){return new rn(this['root_'],_0x238ef,this['comparator_'],!0x0,_0x4dad72);}['getReverseIterator'](_0x3faf46){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3faf46);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5457f8,_0x223388){return qe(_0x5457f8['name'],_0x223388['name']);}function Qi(_0x3d0104,_0x3a94d8){return qe(_0x3d0104,_0x3a94d8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2be8f0){Ci=_0x2be8f0;}const Po=function(_0x3b2e26){return typeof _0x3b2e26=='number'?'number:'+ao(_0x3b2e26):'string:'+_0x3b2e26;},No=function(_0x20cbb2){if(_0x20cbb2['isLeafNode']()){const _0x246d9c=_0x20cbb2['val']();f(typeof _0x246d9c=='string'||typeof _0x246d9c=='number'||typeof _0x246d9c=='object'&&Q(_0x246d9c,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x20cbb2===Ci||_0x20cbb2['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x20cbb2===Ci||_0x20cbb2['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x519c81){nr=_0x519c81;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0xbcda84,_0x310bdb=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xbcda84,this['priorityNode_']=_0x310bdb,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x18cd51){return new D(this['value_'],_0x18cd51);}['getImmediateChild'](_0x599f29){return _0x599f29==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x236765){return v(_0x236765)?this:y(_0x236765)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5190d4,_0x5ea744){return null;}['updateImmediateChild'](_0x85f1d2,_0x564e9d){return _0x85f1d2==='.priority'?this['updatePriority'](_0x564e9d):_0x564e9d['isEmpty']()&&_0x85f1d2!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x85f1d2,_0x564e9d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x12a8a6,_0x33859d){const _0x50f586=y(_0x12a8a6);return _0x50f586===null?_0x33859d:_0x33859d['isEmpty']()&&_0x50f586!=='.priority'?this:(f(_0x50f586!=='.priority'||Ce(_0x12a8a6)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x50f586,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x12a8a6),_0x33859d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x574aa8,_0x53ecb6){return!0x1;}['val'](_0x3c6914){return _0x3c6914&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x130ec1='';this['priorityNode_']['isEmpty']()||(_0x130ec1+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x2329c9=typeof this['value_'];_0x130ec1+=_0x2329c9+':',_0x2329c9==='number'?_0x130ec1+=ao(this['value_']):_0x130ec1+=this['value_'],this['lazyHash_']=ro(_0x130ec1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x477302){return _0x477302===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x477302 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x477302['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x477302));}['compareToLeafNode_'](_0x233fcb){const _0x397fe1=typeof _0x233fcb['value_'],_0x2d397a=typeof this['value_'],_0x1d0101=D['VALUE_TYPE_ORDER']['indexOf'](_0x397fe1),_0x2879c5=D['VALUE_TYPE_ORDER']['indexOf'](_0x2d397a);return f(_0x1d0101>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x397fe1),f(_0x2879c5>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2d397a),_0x1d0101===_0x2879c5?_0x2d397a==='object'?0x0:this['value_']<_0x233fcb['value_']?-0x1:this['value_']===_0x233fcb['value_']?0x0:0x1:_0x2879c5-_0x1d0101;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x21ad13){if(_0x21ad13===this)return!0x0;if(_0x21ad13['isLeafNode']()){const _0x4ca37a=_0x21ad13;return this['value_']===_0x4ca37a['value_']&&this['priorityNode_']['equals'](_0x4ca37a['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x4294b6){Oo=_0x4294b6;}function Wh(_0x1fceb1){Do=_0x1fceb1;}class Bh extends Fn{['compare'](_0x3f7af6,_0x3dc48a){const _0x2e2f7b=_0x3f7af6['node']['getPriority'](),_0x517d34=_0x3dc48a['node']['getPriority'](),_0xa9dead=_0x2e2f7b['compareTo'](_0x517d34);return _0xa9dead===0x0?qe(_0x3f7af6['name'],_0x3dc48a['name']):_0xa9dead;}['isDefinedOn'](_0x3d292){return!_0x3d292['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3b7ac5,_0x22a6e3){return!_0x3b7ac5['getPriority']()['equals'](_0x22a6e3['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x26e0ec,_0x5a5c70){const _0x46a22d=Oo(_0x26e0ec);return new E(_0x5a5c70,new D('[PRIORITY-POST]',_0x46a22d));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1b0cc6){const _0x12787a=_0x11bb14=>parseInt(Math['log'](_0x11bb14)/Vh,0xa),_0x550802=_0x4109f4=>parseInt(Array(_0x4109f4+0x1)['join']('1'),0x2);this['count']=_0x12787a(_0x1b0cc6+0x1),this['current_']=this['count']-0x1;const _0x1ee202=_0x550802(this['count']);this['bits_']=_0x1b0cc6+0x1&_0x1ee202;}['nextBitIsOne'](){const _0x4eafdf=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4eafdf;}}const yn=function(_0x30149b,_0x4e2a1f,_0x47bf38,_0x370a4a){_0x30149b['sort'](_0x4e2a1f);const _0x462615=function(_0x1e0e91,_0x52fb88){const _0x35052b=_0x52fb88-_0x1e0e91;let _0x46e606,_0x1077f3;if(_0x35052b===0x0)return null;if(_0x35052b===0x1)return _0x46e606=_0x30149b[_0x1e0e91],_0x1077f3=_0x47bf38?_0x47bf38(_0x46e606):_0x46e606,new M(_0x1077f3,_0x46e606['node'],M['BLACK'],null,null);{const _0x51c21d=parseInt(_0x35052b/0x2,0xa)+_0x1e0e91,_0x50d924=_0x462615(_0x1e0e91,_0x51c21d),_0xbb414e=_0x462615(_0x51c21d+0x1,_0x52fb88);return _0x46e606=_0x30149b[_0x51c21d],_0x1077f3=_0x47bf38?_0x47bf38(_0x46e606):_0x46e606,new M(_0x1077f3,_0x46e606['node'],M['BLACK'],_0x50d924,_0xbb414e);}},_0x2d3619=function(_0x5d0e88){let _0x37913c=null,_0x7bcf77=null,_0x441905=_0x30149b['length'];const _0x35a476=function(_0x5fc4a8,_0x18c2a5){const _0x410054=_0x441905-_0x5fc4a8,_0x1cf0ad=_0x441905;_0x441905-=_0x5fc4a8;const _0x4eeb2f=_0x462615(_0x410054+0x1,_0x1cf0ad),_0x561a76=_0x30149b[_0x410054],_0x3ab353=_0x47bf38?_0x47bf38(_0x561a76):_0x561a76;_0x5bbf46(new M(_0x3ab353,_0x561a76['node'],_0x18c2a5,null,_0x4eeb2f));},_0x5bbf46=function(_0x307306){_0x37913c?(_0x37913c['left']=_0x307306,_0x37913c=_0x307306):(_0x7bcf77=_0x307306,_0x37913c=_0x307306);};for(let _0x13376e=0x0;_0x13376e<_0x5d0e88['count'];++_0x13376e){const _0x2cada4=_0x5d0e88['nextBitIsOne'](),_0x19f8f4=Math['pow'](0x2,_0x5d0e88['count']-(_0x13376e+0x1));_0x2cada4?_0x35a476(_0x19f8f4,M['BLACK']):(_0x35a476(_0x19f8f4,M['BLACK']),_0x35a476(_0x19f8f4,M['RED']));}return _0x7bcf77;},_0x39e845=new Hh(_0x30149b['length']),_0x27c51b=_0x2d3619(_0x39e845);return new B(_0x370a4a||_0x4e2a1f,_0x27c51b);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x76ec65,_0x1e0a05){this['indexes_']=_0x76ec65,this['indexSet_']=_0x1e0a05;}['get'](_0x3b850f){const _0x56b950=Le(this['indexes_'],_0x3b850f);if(!_0x56b950)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3b850f);return _0x56b950 instanceof B?_0x56b950:null;}['hasIndex'](_0x153c9f){return Q(this['indexSet_'],_0x153c9f['toString']());}['addIndex'](_0x2d9a45,_0x5cff1a){f(_0x2d9a45!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x510183=[];let _0x32820c=!0x1;const _0x3e620c=_0x5cff1a['getIterator'](E['Wrap']);let _0x5528f5=_0x3e620c['getNext']();for(;_0x5528f5;)_0x32820c=_0x32820c||_0x2d9a45['isDefinedOn'](_0x5528f5['node']),_0x510183['push'](_0x5528f5),_0x5528f5=_0x3e620c['getNext']();let _0x2203be;_0x32820c?_0x2203be=yn(_0x510183,_0x2d9a45['getCompare']()):_0x2203be=Qe;const _0x217640=_0x2d9a45['toString'](),_0xd32126={...this['indexSet_']};_0xd32126[_0x217640]=_0x2d9a45;const _0x3b4b16={...this['indexes_']};return _0x3b4b16[_0x217640]=_0x2203be,new te(_0x3b4b16,_0xd32126);}['addToIndexes'](_0x3aff28,_0x28fda5){const _0x190e04=_n(this['indexes_'],(_0x5c4427,_0x2a9f2c)=>{const _0x8996e4=Le(this['indexSet_'],_0x2a9f2c);if(f(_0x8996e4,'Missing\x20index\x20implementation\x20for\x20'+_0x2a9f2c),_0x5c4427===Qe){if(_0x8996e4['isDefinedOn'](_0x3aff28['node'])){const _0x368c4b=[],_0x21e7ae=_0x28fda5['getIterator'](E['Wrap']);let _0x84fdbf=_0x21e7ae['getNext']();for(;_0x84fdbf;)_0x84fdbf['name']!==_0x3aff28['name']&&_0x368c4b['push'](_0x84fdbf),_0x84fdbf=_0x21e7ae['getNext']();return _0x368c4b['push'](_0x3aff28),yn(_0x368c4b,_0x8996e4['getCompare']());}else return Qe;}else{const _0x5f5df1=_0x28fda5['get'](_0x3aff28['name']);let _0x35cf11=_0x5c4427;return _0x5f5df1&&(_0x35cf11=_0x35cf11['remove'](new E(_0x3aff28['name'],_0x5f5df1))),_0x35cf11['insert'](_0x3aff28,_0x3aff28['node']);}});return new te(_0x190e04,this['indexSet_']);}['removeFromIndexes'](_0x54781a,_0x3f2087){const _0x464f77=_n(this['indexes_'],_0x395d83=>{if(_0x395d83===Qe)return _0x395d83;{const _0x4b493a=_0x3f2087['get'](_0x54781a['name']);return _0x4b493a?_0x395d83['remove'](new E(_0x54781a['name'],_0x4b493a)):_0x395d83;}});return new te(_0x464f77,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x93322,_0x2fd830,_0x1e06c9){this['children_']=_0x93322,this['priorityNode_']=_0x2fd830,this['indexMap_']=_0x1e06c9,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0xcc6a9f){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xcc6a9f,this['indexMap_']);}['getImmediateChild'](_0x1e2008){if(_0x1e2008==='.priority')return this['getPriority']();{const _0x7512b8=this['children_']['get'](_0x1e2008);return _0x7512b8===null?It:_0x7512b8;}}['getChild'](_0x6e36d5){const _0xd1c7b7=y(_0x6e36d5);return _0xd1c7b7===null?this:this['getImmediateChild'](_0xd1c7b7)['getChild'](S(_0x6e36d5));}['hasChild'](_0x18047e){return this['children_']['get'](_0x18047e)!==null;}['updateImmediateChild'](_0x1d68be,_0x43cb6e){if(f(_0x43cb6e,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1d68be==='.priority')return this['updatePriority'](_0x43cb6e);{const _0x22ba9a=new E(_0x1d68be,_0x43cb6e);let _0x4856cb,_0x1c8a11;_0x43cb6e['isEmpty']()?(_0x4856cb=this['children_']['remove'](_0x1d68be),_0x1c8a11=this['indexMap_']['removeFromIndexes'](_0x22ba9a,this['children_'])):(_0x4856cb=this['children_']['insert'](_0x1d68be,_0x43cb6e),_0x1c8a11=this['indexMap_']['addToIndexes'](_0x22ba9a,this['children_']));const _0x3b9b9a=_0x4856cb['isEmpty']()?It:this['priorityNode_'];return new g(_0x4856cb,_0x3b9b9a,_0x1c8a11);}}['updateChild'](_0x2fd756,_0x3a1304){const _0x4abca7=y(_0x2fd756);if(_0x4abca7===null)return _0x3a1304;{f(y(_0x2fd756)!=='.priority'||Ce(_0x2fd756)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x30927f=this['getImmediateChild'](_0x4abca7)['updateChild'](S(_0x2fd756),_0x3a1304);return this['updateImmediateChild'](_0x4abca7,_0x30927f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1f98f3){if(this['isEmpty']())return null;const _0x2a48f5={};let _0x17ab96=0x0,_0x27ecc5=0x0,_0x536b67=!0x0;if(this['forEachChild'](R,(_0x4731ea,_0xd77166)=>{_0x2a48f5[_0x4731ea]=_0xd77166['val'](_0x1f98f3),_0x17ab96++,_0x536b67&&g['INTEGER_REGEXP_']['test'](_0x4731ea)?_0x27ecc5=Math['max'](_0x27ecc5,Number(_0x4731ea)):_0x536b67=!0x1;}),!_0x1f98f3&&_0x536b67&&_0x27ecc5<0x2*_0x17ab96){const _0x128612=[];for(const _0x84217c in _0x2a48f5)_0x128612[_0x84217c]=_0x2a48f5[_0x84217c];return _0x128612;}else return _0x1f98f3&&!this['getPriority']()['isEmpty']()&&(_0x2a48f5['.priority']=this['getPriority']()['val']()),_0x2a48f5;}['hash'](){if(this['lazyHash_']===null){let _0x68309d='';this['getPriority']()['isEmpty']()||(_0x68309d+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x15b1dc,_0x38eada)=>{const _0x3ad885=_0x38eada['hash']();_0x3ad885!==''&&(_0x68309d+=':'+_0x15b1dc+':'+_0x3ad885);}),this['lazyHash_']=_0x68309d===''?'':ro(_0x68309d);}return this['lazyHash_'];}['getPredecessorChildName'](_0x55d851,_0x1d0287,_0x200d91){const _0x21f3bd=this['resolveIndex_'](_0x200d91);if(_0x21f3bd){const _0x2c2fc2=_0x21f3bd['getPredecessorKey'](new E(_0x55d851,_0x1d0287));return _0x2c2fc2?_0x2c2fc2['name']:null;}else return this['children_']['getPredecessorKey'](_0x55d851);}['getFirstChildName'](_0xe0dd6c){const _0x45c8f3=this['resolveIndex_'](_0xe0dd6c);if(_0x45c8f3){const _0x49ffda=_0x45c8f3['minKey']();return _0x49ffda&&_0x49ffda['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x29d19d){const _0x162f9e=this['getFirstChildName'](_0x29d19d);return _0x162f9e?new E(_0x162f9e,this['children_']['get'](_0x162f9e)):null;}['getLastChildName'](_0x6ce4fd){const _0x1d1902=this['resolveIndex_'](_0x6ce4fd);if(_0x1d1902){const _0x2508f0=_0x1d1902['maxKey']();return _0x2508f0&&_0x2508f0['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3e8e17){const _0x12876b=this['getLastChildName'](_0x3e8e17);return _0x12876b?new E(_0x12876b,this['children_']['get'](_0x12876b)):null;}['forEachChild'](_0xe52c98,_0x9e6f32){const _0x1f7aa1=this['resolveIndex_'](_0xe52c98);return _0x1f7aa1?_0x1f7aa1['inorderTraversal'](_0x2bcf51=>_0x9e6f32(_0x2bcf51['name'],_0x2bcf51['node'])):this['children_']['inorderTraversal'](_0x9e6f32);}['getIterator'](_0x3ba80a){return this['getIteratorFrom'](_0x3ba80a['minPost'](),_0x3ba80a);}['getIteratorFrom'](_0x2a602c,_0x5ea9a0){const _0x259988=this['resolveIndex_'](_0x5ea9a0);if(_0x259988)return _0x259988['getIteratorFrom'](_0x2a602c,_0x2ba4de=>_0x2ba4de);{const _0x13e1d6=this['children_']['getIteratorFrom'](_0x2a602c['name'],E['Wrap']);let _0x3cef99=_0x13e1d6['peek']();for(;_0x3cef99!=null&&_0x5ea9a0['compare'](_0x3cef99,_0x2a602c)<0x0;)_0x13e1d6['getNext'](),_0x3cef99=_0x13e1d6['peek']();return _0x13e1d6;}}['getReverseIterator'](_0x1075d1){return this['getReverseIteratorFrom'](_0x1075d1['maxPost'](),_0x1075d1);}['getReverseIteratorFrom'](_0x161338,_0x18ed2d){const _0xba9d03=this['resolveIndex_'](_0x18ed2d);if(_0xba9d03)return _0xba9d03['getReverseIteratorFrom'](_0x161338,_0x37cbca=>_0x37cbca);{const _0x32595d=this['children_']['getReverseIteratorFrom'](_0x161338['name'],E['Wrap']);let _0x41559b=_0x32595d['peek']();for(;_0x41559b!=null&&_0x18ed2d['compare'](_0x41559b,_0x161338)>0x0;)_0x32595d['getNext'](),_0x41559b=_0x32595d['peek']();return _0x32595d;}}['compareTo'](_0x2099e1){return this['isEmpty']()?_0x2099e1['isEmpty']()?0x0:-0x1:_0x2099e1['isLeafNode']()||_0x2099e1['isEmpty']()?0x1:_0x2099e1===Kt?-0x1:0x0;}['withIndex'](_0x4ecb86){if(_0x4ecb86===ve||this['indexMap_']['hasIndex'](_0x4ecb86))return this;{const _0x4ae917=this['indexMap_']['addIndex'](_0x4ecb86,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x4ae917);}}['isIndexed'](_0x15ca32){return _0x15ca32===ve||this['indexMap_']['hasIndex'](_0x15ca32);}['equals'](_0xae68bd){if(_0xae68bd===this)return!0x0;if(_0xae68bd['isLeafNode']())return!0x1;{const _0x37fef1=_0xae68bd;if(this['getPriority']()['equals'](_0x37fef1['getPriority']())){if(this['children_']['count']()===_0x37fef1['children_']['count']()){const _0x3fb1dc=this['getIterator'](R),_0xcd4c59=_0x37fef1['getIterator'](R);let _0x3b241d=_0x3fb1dc['getNext'](),_0x3b25df=_0xcd4c59['getNext']();for(;_0x3b241d&&_0x3b25df;){if(_0x3b241d['name']!==_0x3b25df['name']||!_0x3b241d['node']['equals'](_0x3b25df['node']))return!0x1;_0x3b241d=_0x3fb1dc['getNext'](),_0x3b25df=_0xcd4c59['getNext']();}return _0x3b241d===null&&_0x3b25df===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x389616){return _0x389616===ve?null:this['indexMap_']['get'](_0x389616['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x826662){return _0x826662===this?0x0:0x1;}['equals'](_0x22a62d){return _0x22a62d===this;}['getPriority'](){return this;}['getImmediateChild'](_0x302f12){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x9d37f3,_0x34d7a2=null){if(_0x9d37f3===null)return g['EMPTY_NODE'];if(typeof _0x9d37f3=='object'&&'.priority'in _0x9d37f3&&(_0x34d7a2=_0x9d37f3['.priority']),f(_0x34d7a2===null||typeof _0x34d7a2=='string'||typeof _0x34d7a2=='number'||typeof _0x34d7a2=='object'&&'.sv'in _0x34d7a2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x34d7a2),typeof _0x9d37f3=='object'&&'.value'in _0x9d37f3&&_0x9d37f3['.value']!==null&&(_0x9d37f3=_0x9d37f3['.value']),typeof _0x9d37f3!='object'||'.sv'in _0x9d37f3){const _0x440a48=_0x9d37f3;return new D(_0x440a48,A(_0x34d7a2));}if(!(_0x9d37f3 instanceof Array)&&Gh){const _0x138a69=[];let _0x46ca4a=!0x1;if(x(_0x9d37f3,(_0x131e0f,_0x116f52)=>{if(_0x131e0f['substring'](0x0,0x1)!=='.'){const _0x3e1ccc=A(_0x116f52);_0x3e1ccc['isEmpty']()||(_0x46ca4a=_0x46ca4a||!_0x3e1ccc['getPriority']()['isEmpty'](),_0x138a69['push'](new E(_0x131e0f,_0x3e1ccc)));}}),_0x138a69['length']===0x0)return g['EMPTY_NODE'];const _0x1b9c2a=yn(_0x138a69,xh,_0x31b9d2=>_0x31b9d2['name'],Qi);if(_0x46ca4a){const _0x31bfd3=yn(_0x138a69,R['getCompare']());return new g(_0x1b9c2a,A(_0x34d7a2),new te({'.priority':_0x31bfd3},{'.priority':R}));}else return new g(_0x1b9c2a,A(_0x34d7a2),te['Default']);}else{let _0x8ea2c3=g['EMPTY_NODE'];return x(_0x9d37f3,(_0x330e1f,_0x5d5d37)=>{if(Q(_0x9d37f3,_0x330e1f)&&_0x330e1f['substring'](0x0,0x1)!=='.'){const _0x32387f=A(_0x5d5d37);(_0x32387f['isLeafNode']()||!_0x32387f['isEmpty']())&&(_0x8ea2c3=_0x8ea2c3['updateImmediateChild'](_0x330e1f,_0x32387f));}}),_0x8ea2c3['updatePriority'](A(_0x34d7a2));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x277cb1){super(),this['indexPath_']=_0x277cb1,f(!v(_0x277cb1)&&y(_0x277cb1)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3d4bc4){return _0x3d4bc4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x564a0a){return!_0x564a0a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x251428,_0x445a43){const _0x5f5901=this['extractChild'](_0x251428['node']),_0x4ff4cd=this['extractChild'](_0x445a43['node']),_0x419359=_0x5f5901['compareTo'](_0x4ff4cd);return _0x419359===0x0?qe(_0x251428['name'],_0x445a43['name']):_0x419359;}['makePost'](_0x20aa79,_0x54bbeb){const _0x599440=A(_0x20aa79),_0x1a709a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x599440);return new E(_0x54bbeb,_0x1a709a);}['maxPost'](){const _0x132553=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x132553);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x53b5b5,_0x311c65){const _0x2ccea0=_0x53b5b5['node']['compareTo'](_0x311c65['node']);return _0x2ccea0===0x0?qe(_0x53b5b5['name'],_0x311c65['name']):_0x2ccea0;}['isDefinedOn'](_0x488ede){return!0x0;}['indexedValueChanged'](_0x2a2672,_0x17a83a){return!_0x2a2672['equals'](_0x17a83a);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x24ac1b,_0x44f8e9){const _0x2b5c6a=A(_0x24ac1b);return new E(_0x44f8e9,_0x2b5c6a);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x51713f){return{'type':'value','snapshotNode':_0x51713f};}function rt(_0xbd0276,_0x3d3778){return{'type':'child_added','snapshotNode':_0x3d3778,'childName':_0xbd0276};}function Lt(_0x125409,_0x4135a4){return{'type':'child_removed','snapshotNode':_0x4135a4,'childName':_0x125409};}function xt(_0x7fc04f,_0x211cd1,_0x32f01e){return{'type':'child_changed','snapshotNode':_0x211cd1,'childName':_0x7fc04f,'oldSnap':_0x32f01e};}function zh(_0x25e355,_0xc56c96){return{'type':'child_moved','snapshotNode':_0xc56c96,'childName':_0x25e355};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4d2226){this['index_']=_0x4d2226;}['updateChild'](_0x23012e,_0x39dbe9,_0x2b85f3,_0x1f51af,_0x5308ec,_0x5c7723){f(_0x23012e['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4bfb0e=_0x23012e['getImmediateChild'](_0x39dbe9);return _0x4bfb0e['getChild'](_0x1f51af)['equals'](_0x2b85f3['getChild'](_0x1f51af))&&_0x4bfb0e['isEmpty']()===_0x2b85f3['isEmpty']()||(_0x5c7723!=null&&(_0x2b85f3['isEmpty']()?_0x23012e['hasChild'](_0x39dbe9)?_0x5c7723['trackChildChange'](Lt(_0x39dbe9,_0x4bfb0e)):f(_0x23012e['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4bfb0e['isEmpty']()?_0x5c7723['trackChildChange'](rt(_0x39dbe9,_0x2b85f3)):_0x5c7723['trackChildChange'](xt(_0x39dbe9,_0x2b85f3,_0x4bfb0e))),_0x23012e['isLeafNode']()&&_0x2b85f3['isEmpty']())?_0x23012e:_0x23012e['updateImmediateChild'](_0x39dbe9,_0x2b85f3)['withIndex'](this['index_']);}['updateFullNode'](_0x39c005,_0xfbff6,_0x12d5a7){return _0x12d5a7!=null&&(_0x39c005['isLeafNode']()||_0x39c005['forEachChild'](R,(_0x3e4074,_0x56dcf0)=>{_0xfbff6['hasChild'](_0x3e4074)||_0x12d5a7['trackChildChange'](Lt(_0x3e4074,_0x56dcf0));}),_0xfbff6['isLeafNode']()||_0xfbff6['forEachChild'](R,(_0x3ff08f,_0x4fd35f)=>{if(_0x39c005['hasChild'](_0x3ff08f)){const _0x1454a6=_0x39c005['getImmediateChild'](_0x3ff08f);_0x1454a6['equals'](_0x4fd35f)||_0x12d5a7['trackChildChange'](xt(_0x3ff08f,_0x4fd35f,_0x1454a6));}else _0x12d5a7['trackChildChange'](rt(_0x3ff08f,_0x4fd35f));})),_0xfbff6['withIndex'](this['index_']);}['updatePriority'](_0x1c5445,_0x531268){return _0x1c5445['isEmpty']()?g['EMPTY_NODE']:_0x1c5445['updatePriority'](_0x531268);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x5b9469){this['indexedFilter_']=new Xi(_0x5b9469['getIndex']()),this['index_']=_0x5b9469['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x5b9469),this['endPost_']=Ft['getEndPost_'](_0x5b9469),this['startIsInclusive_']=!_0x5b9469['startAfterSet_'],this['endIsInclusive_']=!_0x5b9469['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xc151f2){const _0x328e59=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xc151f2)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xc151f2)<0x0,_0x236e93=this['endIsInclusive_']?this['index_']['compare'](_0xc151f2,this['getEndPost']())<=0x0:this['index_']['compare'](_0xc151f2,this['getEndPost']())<0x0;return _0x328e59&&_0x236e93;}['updateChild'](_0x3fcfe5,_0x442d52,_0x484870,_0x22bcf5,_0xb49490,_0x164c11){return this['matches'](new E(_0x442d52,_0x484870))||(_0x484870=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3fcfe5,_0x442d52,_0x484870,_0x22bcf5,_0xb49490,_0x164c11);}['updateFullNode'](_0x1bdadf,_0x5ded8c,_0x35f34d){_0x5ded8c['isLeafNode']()&&(_0x5ded8c=g['EMPTY_NODE']);let _0x476d54=_0x5ded8c['withIndex'](this['index_']);_0x476d54=_0x476d54['updatePriority'](g['EMPTY_NODE']);const _0x2be91a=this;return _0x5ded8c['forEachChild'](R,(_0x1bf6c5,_0x1ecef5)=>{_0x2be91a['matches'](new E(_0x1bf6c5,_0x1ecef5))||(_0x476d54=_0x476d54['updateImmediateChild'](_0x1bf6c5,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1bdadf,_0x476d54,_0x35f34d);}['updatePriority'](_0x4f655f,_0x269ae4){return _0x4f655f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x77cc7c){if(_0x77cc7c['hasStart']()){const _0x2fb917=_0x77cc7c['getIndexStartName']();return _0x77cc7c['getIndex']()['makePost'](_0x77cc7c['getIndexStartValue'](),_0x2fb917);}else return _0x77cc7c['getIndex']()['minPost']();}static['getEndPost_'](_0x378c97){if(_0x378c97['hasEnd']()){const _0x49a152=_0x378c97['getIndexEndName']();return _0x378c97['getIndex']()['makePost'](_0x378c97['getIndexEndValue'](),_0x49a152);}else return _0x378c97['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2e6110){this['withinDirectionalStart']=_0x435a2b=>this['reverse_']?this['withinEndPost'](_0x435a2b):this['withinStartPost'](_0x435a2b),this['withinDirectionalEnd']=_0x33ddc7=>this['reverse_']?this['withinStartPost'](_0x33ddc7):this['withinEndPost'](_0x33ddc7),this['withinStartPost']=_0x1e0769=>{const _0x551f17=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1e0769);return this['startIsInclusive_']?_0x551f17<=0x0:_0x551f17<0x0;},this['withinEndPost']=_0x2c2fc3=>{const _0x2fb089=this['index_']['compare'](_0x2c2fc3,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2fb089<=0x0:_0x2fb089<0x0;},this['rangedFilter_']=new Ft(_0x2e6110),this['index_']=_0x2e6110['getIndex'](),this['limit_']=_0x2e6110['getLimit'](),this['reverse_']=!_0x2e6110['isViewFromLeft'](),this['startIsInclusive_']=!_0x2e6110['startAfterSet_'],this['endIsInclusive_']=!_0x2e6110['endBeforeSet_'];}['updateChild'](_0x4c6202,_0x127898,_0x3ade44,_0x1216a4,_0x45755a,_0x2afea9){return this['rangedFilter_']['matches'](new E(_0x127898,_0x3ade44))||(_0x3ade44=g['EMPTY_NODE']),_0x4c6202['getImmediateChild'](_0x127898)['equals'](_0x3ade44)?_0x4c6202:_0x4c6202['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x4c6202,_0x127898,_0x3ade44,_0x1216a4,_0x45755a,_0x2afea9):this['fullLimitUpdateChild_'](_0x4c6202,_0x127898,_0x3ade44,_0x45755a,_0x2afea9);}['updateFullNode'](_0x557f9c,_0x4989dd,_0x3c5dd7){let _0x3dfb2b;if(_0x4989dd['isLeafNode']()||_0x4989dd['isEmpty']())_0x3dfb2b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4989dd['numChildren']()&&_0x4989dd['isIndexed'](this['index_'])){_0x3dfb2b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x368cf5;this['reverse_']?_0x368cf5=_0x4989dd['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x368cf5=_0x4989dd['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x55611a=0x0;for(;_0x368cf5['hasNext']()&&_0x55611a<this['limit_'];){const _0x217391=_0x368cf5['getNext']();if(this['withinDirectionalStart'](_0x217391)){if(this['withinDirectionalEnd'](_0x217391))_0x3dfb2b=_0x3dfb2b['updateImmediateChild'](_0x217391['name'],_0x217391['node']),_0x55611a++;else break;}else continue;}}else{_0x3dfb2b=_0x4989dd['withIndex'](this['index_']),_0x3dfb2b=_0x3dfb2b['updatePriority'](g['EMPTY_NODE']);let _0x3a6689;this['reverse_']?_0x3a6689=_0x3dfb2b['getReverseIterator'](this['index_']):_0x3a6689=_0x3dfb2b['getIterator'](this['index_']);let _0x49dc38=0x0;for(;_0x3a6689['hasNext']();){const _0x1aa1c8=_0x3a6689['getNext']();_0x49dc38<this['limit_']&&this['withinDirectionalStart'](_0x1aa1c8)&&this['withinDirectionalEnd'](_0x1aa1c8)?_0x49dc38++:_0x3dfb2b=_0x3dfb2b['updateImmediateChild'](_0x1aa1c8['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x557f9c,_0x3dfb2b,_0x3c5dd7);}['updatePriority'](_0x43e598,_0x4495b6){return _0x43e598;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4e5e1b,_0x15f2a8,_0x29f6ac,_0xc7b8e7,_0x3c6721){let _0x5d9d14;if(this['reverse_']){const _0x3262f5=this['index_']['getCompare']();_0x5d9d14=(_0x32713d,_0xceeac4)=>_0x3262f5(_0xceeac4,_0x32713d);}else _0x5d9d14=this['index_']['getCompare']();const _0x2da3bf=_0x4e5e1b;f(_0x2da3bf['numChildren']()===this['limit_'],'');const _0x3f15c7=new E(_0x15f2a8,_0x29f6ac),_0x297c01=this['reverse_']?_0x2da3bf['getFirstChild'](this['index_']):_0x2da3bf['getLastChild'](this['index_']),_0x20fa60=this['rangedFilter_']['matches'](_0x3f15c7);if(_0x2da3bf['hasChild'](_0x15f2a8)){const _0x5147c9=_0x2da3bf['getImmediateChild'](_0x15f2a8);let _0x5e0ef8=_0xc7b8e7['getChildAfterChild'](this['index_'],_0x297c01,this['reverse_']);for(;_0x5e0ef8!=null&&(_0x5e0ef8['name']===_0x15f2a8||_0x2da3bf['hasChild'](_0x5e0ef8['name']));)_0x5e0ef8=_0xc7b8e7['getChildAfterChild'](this['index_'],_0x5e0ef8,this['reverse_']);const _0x1a5155=_0x5e0ef8==null?0x1:_0x5d9d14(_0x5e0ef8,_0x3f15c7);if(_0x20fa60&&!_0x29f6ac['isEmpty']()&&_0x1a5155>=0x0)return _0x3c6721!=null&&_0x3c6721['trackChildChange'](xt(_0x15f2a8,_0x29f6ac,_0x5147c9)),_0x2da3bf['updateImmediateChild'](_0x15f2a8,_0x29f6ac);{_0x3c6721!=null&&_0x3c6721['trackChildChange'](Lt(_0x15f2a8,_0x5147c9));const _0x1a9aab=_0x2da3bf['updateImmediateChild'](_0x15f2a8,g['EMPTY_NODE']);return _0x5e0ef8!=null&&this['rangedFilter_']['matches'](_0x5e0ef8)?(_0x3c6721!=null&&_0x3c6721['trackChildChange'](rt(_0x5e0ef8['name'],_0x5e0ef8['node'])),_0x1a9aab['updateImmediateChild'](_0x5e0ef8['name'],_0x5e0ef8['node'])):_0x1a9aab;}}else return _0x29f6ac['isEmpty']()?_0x4e5e1b:_0x20fa60&&_0x5d9d14(_0x297c01,_0x3f15c7)>=0x0?(_0x3c6721!=null&&(_0x3c6721['trackChildChange'](Lt(_0x297c01['name'],_0x297c01['node'])),_0x3c6721['trackChildChange'](rt(_0x15f2a8,_0x29f6ac))),_0x2da3bf['updateImmediateChild'](_0x15f2a8,_0x29f6ac)['updateImmediateChild'](_0x297c01['name'],g['EMPTY_NODE'])):_0x4e5e1b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2bfda4=new Zi();return _0x2bfda4['limitSet_']=this['limitSet_'],_0x2bfda4['limit_']=this['limit_'],_0x2bfda4['startSet_']=this['startSet_'],_0x2bfda4['startAfterSet_']=this['startAfterSet_'],_0x2bfda4['indexStartValue_']=this['indexStartValue_'],_0x2bfda4['startNameSet_']=this['startNameSet_'],_0x2bfda4['indexStartName_']=this['indexStartName_'],_0x2bfda4['endSet_']=this['endSet_'],_0x2bfda4['endBeforeSet_']=this['endBeforeSet_'],_0x2bfda4['indexEndValue_']=this['indexEndValue_'],_0x2bfda4['endNameSet_']=this['endNameSet_'],_0x2bfda4['indexEndName_']=this['indexEndName_'],_0x2bfda4['index_']=this['index_'],_0x2bfda4['viewFrom_']=this['viewFrom_'],_0x2bfda4;}}function Kh(_0x5133d1){return _0x5133d1['loadsAllData']()?new Xi(_0x5133d1['getIndex']()):_0x5133d1['hasLimit']()?new jh(_0x5133d1):new Ft(_0x5133d1);}function Yh(_0x506830,_0x362f3b){const _0x131af1=_0x506830['copy']();return _0x131af1['limitSet_']=!0x0,_0x131af1['limit_']=_0x362f3b,_0x131af1['viewFrom_']='l',_0x131af1;}function Qh(_0x6d74cb,_0x2bd32a,_0x3ac21c){const _0x21c677=_0x6d74cb['copy']();return _0x21c677['startSet_']=!0x0,_0x2bd32a===void 0x0&&(_0x2bd32a=null),_0x21c677['indexStartValue_']=_0x2bd32a,_0x3ac21c!=null?(_0x21c677['startNameSet_']=!0x0,_0x21c677['indexStartName_']=_0x3ac21c):(_0x21c677['startNameSet_']=!0x1,_0x21c677['indexStartName_']=''),_0x21c677;}function Jh(_0x535e96,_0xf310e8,_0x224b5e){const _0x32df4d=_0x535e96['copy']();return _0x32df4d['endSet_']=!0x0,_0xf310e8===void 0x0&&(_0xf310e8=null),_0x32df4d['indexEndValue_']=_0xf310e8,_0x224b5e!==void 0x0?(_0x32df4d['endNameSet_']=!0x0,_0x32df4d['indexEndName_']=_0x224b5e):(_0x32df4d['endNameSet_']=!0x1,_0x32df4d['indexEndName_']=''),_0x32df4d;}function xo(_0x165318,_0x204840){const _0x404cbe=_0x165318['copy']();return _0x404cbe['index_']=_0x204840,_0x404cbe;}function ir(_0x46eb9b){const _0x49f1d1={};if(_0x46eb9b['isDefault']())return _0x49f1d1;let _0x2b2d72;if(_0x46eb9b['index_']===R?_0x2b2d72='$priority':_0x46eb9b['index_']===Mo?_0x2b2d72='$value':_0x46eb9b['index_']===ve?_0x2b2d72='$key':(f(_0x46eb9b['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x2b2d72=_0x46eb9b['index_']['toString']()),_0x49f1d1['orderBy']=O(_0x2b2d72),_0x46eb9b['startSet_']){const _0x27ef0a=_0x46eb9b['startAfterSet_']?'startAfter':'startAt';_0x49f1d1[_0x27ef0a]=O(_0x46eb9b['indexStartValue_']),_0x46eb9b['startNameSet_']&&(_0x49f1d1[_0x27ef0a]+=','+O(_0x46eb9b['indexStartName_']));}if(_0x46eb9b['endSet_']){const _0x443074=_0x46eb9b['endBeforeSet_']?'endBefore':'endAt';_0x49f1d1[_0x443074]=O(_0x46eb9b['indexEndValue_']),_0x46eb9b['endNameSet_']&&(_0x49f1d1[_0x443074]+=','+O(_0x46eb9b['indexEndName_']));}return _0x46eb9b['limitSet_']&&(_0x46eb9b['isViewFromLeft']()?_0x49f1d1['limitToFirst']=_0x46eb9b['limit_']:_0x49f1d1['limitToLast']=_0x46eb9b['limit_']),_0x49f1d1;}function sr(_0x4d1510){const _0x1960cd={};if(_0x4d1510['startSet_']&&(_0x1960cd['sp']=_0x4d1510['indexStartValue_'],_0x4d1510['startNameSet_']&&(_0x1960cd['sn']=_0x4d1510['indexStartName_']),_0x1960cd['sin']=!_0x4d1510['startAfterSet_']),_0x4d1510['endSet_']&&(_0x1960cd['ep']=_0x4d1510['indexEndValue_'],_0x4d1510['endNameSet_']&&(_0x1960cd['en']=_0x4d1510['indexEndName_']),_0x1960cd['ein']=!_0x4d1510['endBeforeSet_']),_0x4d1510['limitSet_']){_0x1960cd['l']=_0x4d1510['limit_'];let _0x521666=_0x4d1510['viewFrom_'];_0x521666===''&&(_0x4d1510['isViewFromLeft']()?_0x521666='l':_0x521666='r'),_0x1960cd['vf']=_0x521666;}return _0x4d1510['index_']!==R&&(_0x1960cd['i']=_0x4d1510['index_']['toString']()),_0x1960cd;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x2a2c83){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x232da9,_0x1f4b8e){return _0x1f4b8e!==void 0x0?'tag$'+_0x1f4b8e:(f(_0x232da9['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x232da9['_path']['toString']());}constructor(_0x5c2ffd,_0x1703ab,_0x1e0367,_0x4307e0){super(),this['repoInfo_']=_0x5c2ffd,this['onDataUpdate_']=_0x1703ab,this['authTokenProvider_']=_0x1e0367,this['appCheckTokenProvider_']=_0x4307e0,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x240e0b,_0x3cce33,_0x5c7889,_0x49fa60){const _0x9c45fd=_0x240e0b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x9c45fd+'\x20'+_0x240e0b['_queryIdentifier']);const _0x6bebc2=vn['getListenId_'](_0x240e0b,_0x5c7889),_0x4f084c={};this['listens_'][_0x6bebc2]=_0x4f084c;const _0x5c3415=ir(_0x240e0b['_queryParams']);this['restRequest_'](_0x9c45fd+'.json',_0x5c3415,(_0x24824d,_0x26ddc3)=>{let _0x4089dd=_0x26ddc3;if(_0x24824d===0x194&&(_0x4089dd=null,_0x24824d=null),_0x24824d===null&&this['onDataUpdate_'](_0x9c45fd,_0x4089dd,!0x1,_0x5c7889),Le(this['listens_'],_0x6bebc2)===_0x4f084c){let _0x54715d;_0x24824d?_0x24824d===0x191?_0x54715d='permission_denied':_0x54715d='rest_error:'+_0x24824d:_0x54715d='ok',_0x49fa60(_0x54715d,null);}});}['unlisten'](_0x20af71,_0x57debf){const _0x464475=vn['getListenId_'](_0x20af71,_0x57debf);delete this['listens_'][_0x464475];}['get'](_0x2c5258){const _0x1ce6ce=ir(_0x2c5258['_queryParams']),_0x15cf81=_0x2c5258['_path']['toString'](),_0x4676fa=new H();return this['restRequest_'](_0x15cf81+'.json',_0x1ce6ce,(_0x54cc65,_0x250aba)=>{let _0x4d8a5f=_0x250aba;_0x54cc65===0x194&&(_0x4d8a5f=null,_0x54cc65=null),_0x54cc65===null?(this['onDataUpdate_'](_0x15cf81,_0x4d8a5f,!0x1,null),_0x4676fa['resolve'](_0x4d8a5f)):_0x4676fa['reject'](new Error(_0x4d8a5f));}),_0x4676fa['promise'];}['refreshAuthToken'](_0x175806){}['restRequest_'](_0x511ec3,_0x66a891={},_0x527f94){return _0x66a891['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x255a2f,_0x3e1598])=>{_0x255a2f&&_0x255a2f['accessToken']&&(_0x66a891['auth']=_0x255a2f['accessToken']),_0x3e1598&&_0x3e1598['token']&&(_0x66a891['ac']=_0x3e1598['token']);const _0x15f358=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x511ec3+'?ns='+this['repoInfo_']['namespace']+ut(_0x66a891);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x15f358);const _0x56f605=new XMLHttpRequest();_0x56f605['onreadystatechange']=()=>{if(_0x527f94&&_0x56f605['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x15f358+'\x20received.\x20status:',_0x56f605['status'],'response:',_0x56f605['responseText']);let _0x5beb98=null;if(_0x56f605['status']>=0xc8&&_0x56f605['status']<0x12c){try{_0x5beb98=Nt(_0x56f605['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x15f358+':\x20'+_0x56f605['responseText']);}_0x527f94(null,_0x5beb98);}else _0x56f605['status']!==0x191&&_0x56f605['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x15f358+'\x20Status:\x20'+_0x56f605['status']),_0x527f94(_0x56f605['status']);_0x527f94=null;}},_0x56f605['open']('GET',_0x15f358,!0x0),_0x56f605['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x33d1e0){return this['rootNode_']['getChild'](_0x33d1e0);}['updateSnapshot'](_0x5233f1,_0x42c4df){this['rootNode_']=this['rootNode_']['updateChild'](_0x5233f1,_0x42c4df);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x36f69e,_0x413673,_0x53dc15){if(v(_0x413673))_0x36f69e['value']=_0x53dc15,_0x36f69e['children']['clear']();else{if(_0x36f69e['value']!==null)_0x36f69e['value']=_0x36f69e['value']['updateChild'](_0x413673,_0x53dc15);else{const _0x1ded84=y(_0x413673);_0x36f69e['children']['has'](_0x1ded84)||_0x36f69e['children']['set'](_0x1ded84,En());const _0xc33375=_0x36f69e['children']['get'](_0x1ded84);_0x413673=S(_0x413673),pt(_0xc33375,_0x413673,_0x53dc15);}}}function Ti(_0x409886,_0x477645){if(v(_0x477645))return _0x409886['value']=null,_0x409886['children']['clear'](),!0x0;if(_0x409886['value']!==null){if(_0x409886['value']['isLeafNode']())return!0x1;{const _0x41d928=_0x409886['value'];return _0x409886['value']=null,_0x41d928['forEachChild'](R,(_0x2d3813,_0x4f785f)=>{pt(_0x409886,new C(_0x2d3813),_0x4f785f);}),Ti(_0x409886,_0x477645);}}else{if(_0x409886['children']['size']>0x0){const _0x44f479=y(_0x477645);return _0x477645=S(_0x477645),_0x409886['children']['has'](_0x44f479)&&Ti(_0x409886['children']['get'](_0x44f479),_0x477645)&&_0x409886['children']['delete'](_0x44f479),_0x409886['children']['size']===0x0;}else return!0x0;}}function Si(_0x2b2a45,_0x4fac6a,_0x3df9bb){_0x2b2a45['value']!==null?_0x3df9bb(_0x4fac6a,_0x2b2a45['value']):Zh(_0x2b2a45,(_0x4ecfb6,_0x1bda87)=>{const _0xaf764a=new C(_0x4fac6a['toString']()+'/'+_0x4ecfb6);Si(_0x1bda87,_0xaf764a,_0x3df9bb);});}function Zh(_0x5186ed,_0x29c584){_0x5186ed['children']['forEach']((_0xa2d9ad,_0x23fde8)=>{_0x29c584(_0x23fde8,_0xa2d9ad);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4831e1){this['collection_']=_0x4831e1,this['last_']=null;}['get'](){const _0x335b38=this['collection_']['get'](),_0x1e4bbc={..._0x335b38};return this['last_']&&x(this['last_'],(_0x1e0835,_0x182c4f)=>{_0x1e4bbc[_0x1e0835]=_0x1e4bbc[_0x1e0835]-_0x182c4f;}),this['last_']=_0x335b38,_0x1e4bbc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x20b284,_0x43e4c9){this['server_']=_0x43e4c9,this['statsToReport_']={},this['statsListener_']=new eu(_0x20b284);const _0xf3d9f0=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0xf3d9f0));}['reportStats_'](){const _0x1645b0=this['statsListener_']['get'](),_0x2fd14a={};let _0x54706a=!0x1;x(_0x1645b0,(_0x5038e0,_0x4225a0)=>{_0x4225a0>0x0&&Q(this['statsToReport_'],_0x5038e0)&&(_0x2fd14a[_0x5038e0]=_0x4225a0,_0x54706a=!0x0);}),_0x54706a&&this['server_']['reportStats'](_0x2fd14a),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x48d5d9){_0x48d5d9[_0x48d5d9['OVERWRITE']=0x0]='OVERWRITE',_0x48d5d9[_0x48d5d9['MERGE']=0x1]='MERGE',_0x48d5d9[_0x48d5d9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x48d5d9[_0x48d5d9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x580491){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x580491,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x101527,_0x43708f,_0x46b247){this['path']=_0x101527,this['affectedTree']=_0x43708f,this['revert']=_0x46b247,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x38afcd){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x537cb5=this['affectedTree']['subtree'](new C(_0x38afcd));return new In(w(),_0x537cb5,this['revert']);}}else return f(y(this['path'])===_0x38afcd,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x2fd3fb,_0x153ad7){this['source']=_0x2fd3fb,this['path']=_0x153ad7,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x412055){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xed289b,_0x5c271c,_0x216746){this['source']=_0xed289b,this['path']=_0x5c271c,this['snap']=_0x216746,this['type']=z['OVERWRITE'];}['operationForChild'](_0x1a69d8){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x1a69d8)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4f13cc,_0x17d5c6,_0x2431bf){this['source']=_0x4f13cc,this['path']=_0x17d5c6,this['children']=_0x2431bf,this['type']=z['MERGE'];}['operationForChild'](_0x15e9a9){if(v(this['path'])){const _0x49a109=this['children']['subtree'](new C(_0x15e9a9));return _0x49a109['isEmpty']()?null:_0x49a109['value']?new Be(this['source'],w(),_0x49a109['value']):new ot(this['source'],w(),_0x49a109);}else return f(y(this['path'])===_0x15e9a9,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x20adc1,_0xac2cad,_0x2ef3a2){this['node_']=_0x20adc1,this['fullyInitialized_']=_0xac2cad,this['filtered_']=_0x2ef3a2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5e7c4b){if(v(_0x5e7c4b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3edc86=y(_0x5e7c4b);return this['isCompleteForChild'](_0x3edc86);}['isCompleteForChild'](_0x28f1cd){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x28f1cd);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x2618b4){this['query_']=_0x2618b4,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x13397e,_0x1a029d,_0x2cb928,_0x2b5c53){const _0x18f4b9=[],_0x578a68=[];return _0x1a029d['forEach'](_0x48bc65=>{_0x48bc65['type']==='child_changed'&&_0x13397e['index_']['indexedValueChanged'](_0x48bc65['oldSnap'],_0x48bc65['snapshotNode'])&&_0x578a68['push'](zh(_0x48bc65['childName'],_0x48bc65['snapshotNode']));}),wt(_0x13397e,_0x18f4b9,'child_removed',_0x1a029d,_0x2b5c53,_0x2cb928),wt(_0x13397e,_0x18f4b9,'child_added',_0x1a029d,_0x2b5c53,_0x2cb928),wt(_0x13397e,_0x18f4b9,'child_moved',_0x578a68,_0x2b5c53,_0x2cb928),wt(_0x13397e,_0x18f4b9,'child_changed',_0x1a029d,_0x2b5c53,_0x2cb928),wt(_0x13397e,_0x18f4b9,'value',_0x1a029d,_0x2b5c53,_0x2cb928),_0x18f4b9;}function wt(_0x22db06,_0x29b585,_0x7079f6,_0x41ab84,_0x531a99,_0x2eeb49){const _0x22ace8=_0x41ab84['filter'](_0x1f3f20=>_0x1f3f20['type']===_0x7079f6);_0x22ace8['sort']((_0x228821,_0xc87b38)=>au(_0x22db06,_0x228821,_0xc87b38)),_0x22ace8['forEach'](_0x8384e3=>{const _0x5e788a=ou(_0x22db06,_0x8384e3,_0x2eeb49);_0x531a99['forEach'](_0x3d750e=>{_0x3d750e['respondsTo'](_0x8384e3['type'])&&_0x29b585['push'](_0x3d750e['createEvent'](_0x5e788a,_0x22db06['query_']));});});}function ou(_0x959007,_0x7368c,_0x52cc6b){return _0x7368c['type']==='value'||_0x7368c['type']==='child_removed'||(_0x7368c['prevName']=_0x52cc6b['getPredecessorChildName'](_0x7368c['childName'],_0x7368c['snapshotNode'],_0x959007['index_'])),_0x7368c;}function au(_0x2a42a7,_0x45e961,_0xc22d0b){if(_0x45e961['childName']==null||_0xc22d0b['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1c861e=new E(_0x45e961['childName'],_0x45e961['snapshotNode']),_0x483921=new E(_0xc22d0b['childName'],_0xc22d0b['snapshotNode']);return _0x2a42a7['index_']['compare'](_0x1c861e,_0x483921);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x21adca,_0x3ee69f){return{'eventCache':_0x21adca,'serverCache':_0x3ee69f};}function Rt(_0x425f93,_0x1be4af,_0x11fded,_0x15e4fb){return Un(new Te(_0x1be4af,_0x11fded,_0x15e4fb),_0x425f93['serverCache']);}function Fo(_0x128f50,_0x15df46,_0x5e3f54,_0x3ca235){return Un(_0x128f50['eventCache'],new Te(_0x15df46,_0x5e3f54,_0x3ca235));}function wn(_0x1f8dbc){return _0x1f8dbc['eventCache']['isFullyInitialized']()?_0x1f8dbc['eventCache']['getNode']():null;}function Ve(_0x3599ed){return _0x3599ed['serverCache']['isFullyInitialized']()?_0x3599ed['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x48ad61){let _0x231e21=new b(null);return x(_0x48ad61,(_0x520a3a,_0x213300)=>{_0x231e21=_0x231e21['set'](new C(_0x520a3a),_0x213300);}),_0x231e21;}constructor(_0x58bbff,_0x237fa1=cu()){this['value']=_0x58bbff,this['children']=_0x237fa1;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x5129f7,_0x5ddfe8){if(this['value']!=null&&_0x5ddfe8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x5129f7))return null;{const _0x2b4a81=y(_0x5129f7),_0x48c045=this['children']['get'](_0x2b4a81);if(_0x48c045!==null){const _0x219e39=_0x48c045['findRootMostMatchingPathAndValue'](S(_0x5129f7),_0x5ddfe8);return _0x219e39!=null?{'path':k(new C(_0x2b4a81),_0x219e39['path']),'value':_0x219e39['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x28972e){return this['findRootMostMatchingPathAndValue'](_0x28972e,()=>!0x0);}['subtree'](_0x14297c){if(v(_0x14297c))return this;{const _0x4fad00=y(_0x14297c),_0x17d8a0=this['children']['get'](_0x4fad00);return _0x17d8a0!==null?_0x17d8a0['subtree'](S(_0x14297c)):new b(null);}}['set'](_0x51a295,_0x3677d1){if(v(_0x51a295))return new b(_0x3677d1,this['children']);{const _0x11e5db=y(_0x51a295),_0x4e1bfc=(this['children']['get'](_0x11e5db)||new b(null))['set'](S(_0x51a295),_0x3677d1),_0x234b67=this['children']['insert'](_0x11e5db,_0x4e1bfc);return new b(this['value'],_0x234b67);}}['remove'](_0x4c9622){if(v(_0x4c9622))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x4d33fd=y(_0x4c9622),_0x4777d5=this['children']['get'](_0x4d33fd);if(_0x4777d5){const _0x50d998=_0x4777d5['remove'](S(_0x4c9622));let _0x55e46e;return _0x50d998['isEmpty']()?_0x55e46e=this['children']['remove'](_0x4d33fd):_0x55e46e=this['children']['insert'](_0x4d33fd,_0x50d998),this['value']===null&&_0x55e46e['isEmpty']()?new b(null):new b(this['value'],_0x55e46e);}else return this;}}['get'](_0x3fa0ad){if(v(_0x3fa0ad))return this['value'];{const _0xd7852e=y(_0x3fa0ad),_0x43cc8e=this['children']['get'](_0xd7852e);return _0x43cc8e?_0x43cc8e['get'](S(_0x3fa0ad)):null;}}['setTree'](_0x21c81b,_0x5b2b9c){if(v(_0x21c81b))return _0x5b2b9c;{const _0x5266c1=y(_0x21c81b),_0x220462=(this['children']['get'](_0x5266c1)||new b(null))['setTree'](S(_0x21c81b),_0x5b2b9c);let _0x52280e;return _0x220462['isEmpty']()?_0x52280e=this['children']['remove'](_0x5266c1):_0x52280e=this['children']['insert'](_0x5266c1,_0x220462),new b(this['value'],_0x52280e);}}['fold'](_0xf7b711){return this['fold_'](w(),_0xf7b711);}['fold_'](_0x1d8a4e,_0xc11cb8){const _0x57dbac={};return this['children']['inorderTraversal']((_0x39fce8,_0x418ec1)=>{_0x57dbac[_0x39fce8]=_0x418ec1['fold_'](k(_0x1d8a4e,_0x39fce8),_0xc11cb8);}),_0xc11cb8(_0x1d8a4e,this['value'],_0x57dbac);}['findOnPath'](_0x36c4bd,_0x1d7774){return this['findOnPath_'](_0x36c4bd,w(),_0x1d7774);}['findOnPath_'](_0x43fdd5,_0x1328a8,_0x4967f7){const _0x5c3219=this['value']?_0x4967f7(_0x1328a8,this['value']):!0x1;if(_0x5c3219)return _0x5c3219;if(v(_0x43fdd5))return null;{const _0x15ece7=y(_0x43fdd5),_0x4d3f0f=this['children']['get'](_0x15ece7);return _0x4d3f0f?_0x4d3f0f['findOnPath_'](S(_0x43fdd5),k(_0x1328a8,_0x15ece7),_0x4967f7):null;}}['foreachOnPath'](_0x333003,_0x8c1c3d){return this['foreachOnPath_'](_0x333003,w(),_0x8c1c3d);}['foreachOnPath_'](_0x2bc0aa,_0x4ff02a,_0xc0ce83){if(v(_0x2bc0aa))return this;{this['value']&&_0xc0ce83(_0x4ff02a,this['value']);const _0x2fba26=y(_0x2bc0aa),_0x2ac886=this['children']['get'](_0x2fba26);return _0x2ac886?_0x2ac886['foreachOnPath_'](S(_0x2bc0aa),k(_0x4ff02a,_0x2fba26),_0xc0ce83):new b(null);}}['foreach'](_0x2c0265){this['foreach_'](w(),_0x2c0265);}['foreach_'](_0x9b509c,_0x1ffd3b){this['children']['inorderTraversal']((_0x1e3d71,_0x1f4b95)=>{_0x1f4b95['foreach_'](k(_0x9b509c,_0x1e3d71),_0x1ffd3b);}),this['value']&&_0x1ffd3b(_0x9b509c,this['value']);}['foreachChild'](_0x3008aa){this['children']['inorderTraversal']((_0x4156f5,_0x29c61f)=>{_0x29c61f['value']&&_0x3008aa(_0x4156f5,_0x29c61f['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0xa6494e){this['writeTree_']=_0xa6494e;}static['empty'](){return new K(new b(null));}}function At(_0x4671e3,_0x161099,_0x1472ec){if(v(_0x161099))return new K(new b(_0x1472ec));{const _0x55b44b=_0x4671e3['writeTree_']['findRootMostValueAndPath'](_0x161099);if(_0x55b44b!=null){const _0x2fc0dc=_0x55b44b['path'];let _0x5701d8=_0x55b44b['value'];const _0x30a904=F(_0x2fc0dc,_0x161099);return _0x5701d8=_0x5701d8['updateChild'](_0x30a904,_0x1472ec),new K(_0x4671e3['writeTree_']['set'](_0x2fc0dc,_0x5701d8));}else{const _0x2f402e=new b(_0x1472ec),_0x9e1a4b=_0x4671e3['writeTree_']['setTree'](_0x161099,_0x2f402e);return new K(_0x9e1a4b);}}}function bi(_0x496f90,_0x445beb,_0x4c6718){let _0x3ca379=_0x496f90;return x(_0x4c6718,(_0x1c1b24,_0x153e92)=>{_0x3ca379=At(_0x3ca379,k(_0x445beb,_0x1c1b24),_0x153e92);}),_0x3ca379;}function or(_0xa7746e,_0x10e914){if(v(_0x10e914))return K['empty']();{const _0x36906f=_0xa7746e['writeTree_']['setTree'](_0x10e914,new b(null));return new K(_0x36906f);}}function Ri(_0x491ce0,_0x2b44e7){return ze(_0x491ce0,_0x2b44e7)!=null;}function ze(_0x359227,_0x172d38){const _0x4d2b57=_0x359227['writeTree_']['findRootMostValueAndPath'](_0x172d38);return _0x4d2b57!=null?_0x359227['writeTree_']['get'](_0x4d2b57['path'])['getChild'](F(_0x4d2b57['path'],_0x172d38)):null;}function ar(_0x17c118){const _0x41938d=[],_0x390e29=_0x17c118['writeTree_']['value'];return _0x390e29!=null?_0x390e29['isLeafNode']()||_0x390e29['forEachChild'](R,(_0x13adf3,_0x4a25a4)=>{_0x41938d['push'](new E(_0x13adf3,_0x4a25a4));}):_0x17c118['writeTree_']['children']['inorderTraversal']((_0x5a0eb6,_0x4773c9)=>{_0x4773c9['value']!=null&&_0x41938d['push'](new E(_0x5a0eb6,_0x4773c9['value']));}),_0x41938d;}function Ee(_0x5dd75c,_0x4cb70d){if(v(_0x4cb70d))return _0x5dd75c;{const _0x2a564e=ze(_0x5dd75c,_0x4cb70d);return _0x2a564e!=null?new K(new b(_0x2a564e)):new K(_0x5dd75c['writeTree_']['subtree'](_0x4cb70d));}}function Ai(_0x303710){return _0x303710['writeTree_']['isEmpty']();}function at(_0x107f6a,_0x71d5f7){return Uo(w(),_0x107f6a['writeTree_'],_0x71d5f7);}function Uo(_0x3f5541,_0x281ebd,_0x5d6753){if(_0x281ebd['value']!=null)return _0x5d6753['updateChild'](_0x3f5541,_0x281ebd['value']);{let _0x42caf7=null;return _0x281ebd['children']['inorderTraversal']((_0x21efba,_0x5e83f7)=>{_0x21efba==='.priority'?(f(_0x5e83f7['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x42caf7=_0x5e83f7['value']):_0x5d6753=Uo(k(_0x3f5541,_0x21efba),_0x5e83f7,_0x5d6753);}),!_0x5d6753['getChild'](_0x3f5541)['isEmpty']()&&_0x42caf7!==null&&(_0x5d6753=_0x5d6753['updateChild'](k(_0x3f5541,'.priority'),_0x42caf7)),_0x5d6753;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1b6d08,_0x8dd4a1){return Ho(_0x8dd4a1,_0x1b6d08);}function lu(_0x584a63,_0x243d81,_0x36ae3a,_0x4646ec,_0x154d19){f(_0x4646ec>_0x584a63['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x154d19===void 0x0&&(_0x154d19=!0x0),_0x584a63['allWrites']['push']({'path':_0x243d81,'snap':_0x36ae3a,'writeId':_0x4646ec,'visible':_0x154d19}),_0x154d19&&(_0x584a63['visibleWrites']=At(_0x584a63['visibleWrites'],_0x243d81,_0x36ae3a)),_0x584a63['lastWriteId']=_0x4646ec;}function hu(_0x19f3c8,_0x2f05ca,_0x29b47c,_0x649355){f(_0x649355>_0x19f3c8['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x19f3c8['allWrites']['push']({'path':_0x2f05ca,'children':_0x29b47c,'writeId':_0x649355,'visible':!0x0}),_0x19f3c8['visibleWrites']=bi(_0x19f3c8['visibleWrites'],_0x2f05ca,_0x29b47c),_0x19f3c8['lastWriteId']=_0x649355;}function uu(_0xc49bbb,_0x2e608a){for(let _0x53eb98=0x0;_0x53eb98<_0xc49bbb['allWrites']['length'];_0x53eb98++){const _0x38c975=_0xc49bbb['allWrites'][_0x53eb98];if(_0x38c975['writeId']===_0x2e608a)return _0x38c975;}return null;}function du(_0x313bd0,_0x2bad48){const _0x5777de=_0x313bd0['allWrites']['findIndex'](_0x14a50f=>_0x14a50f['writeId']===_0x2bad48);f(_0x5777de>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x32bce4=_0x313bd0['allWrites'][_0x5777de];_0x313bd0['allWrites']['splice'](_0x5777de,0x1);let _0x38bffb=_0x32bce4['visible'],_0x377f4e=!0x1,_0x345770=_0x313bd0['allWrites']['length']-0x1;for(;_0x38bffb&&_0x345770>=0x0;){const _0x250559=_0x313bd0['allWrites'][_0x345770];_0x250559['visible']&&(_0x345770>=_0x5777de&&fu(_0x250559,_0x32bce4['path'])?_0x38bffb=!0x1:G(_0x32bce4['path'],_0x250559['path'])&&(_0x377f4e=!0x0)),_0x345770--;}if(_0x38bffb){if(_0x377f4e)return pu(_0x313bd0),!0x0;if(_0x32bce4['snap'])_0x313bd0['visibleWrites']=or(_0x313bd0['visibleWrites'],_0x32bce4['path']);else{const _0x267a4f=_0x32bce4['children'];x(_0x267a4f,_0x7d7b4e=>{_0x313bd0['visibleWrites']=or(_0x313bd0['visibleWrites'],k(_0x32bce4['path'],_0x7d7b4e));});}return!0x0;}else return!0x1;}function fu(_0xdbc99a,_0xde33c7){if(_0xdbc99a['snap'])return G(_0xdbc99a['path'],_0xde33c7);for(const _0x38dc99 in _0xdbc99a['children'])if(_0xdbc99a['children']['hasOwnProperty'](_0x38dc99)&&G(k(_0xdbc99a['path'],_0x38dc99),_0xde33c7))return!0x0;return!0x1;}function pu(_0x2dd67f){_0x2dd67f['visibleWrites']=Wo(_0x2dd67f['allWrites'],_u,w()),_0x2dd67f['allWrites']['length']>0x0?_0x2dd67f['lastWriteId']=_0x2dd67f['allWrites'][_0x2dd67f['allWrites']['length']-0x1]['writeId']:_0x2dd67f['lastWriteId']=-0x1;}function _u(_0x2787b1){return _0x2787b1['visible'];}function Wo(_0x11746b,_0x959ccf,_0x5712e3){let _0x38819c=K['empty']();for(let _0x10266c=0x0;_0x10266c<_0x11746b['length'];++_0x10266c){const _0x48d7c0=_0x11746b[_0x10266c];if(_0x959ccf(_0x48d7c0)){const _0xd86b19=_0x48d7c0['path'];let _0x47ed54;if(_0x48d7c0['snap'])G(_0x5712e3,_0xd86b19)?(_0x47ed54=F(_0x5712e3,_0xd86b19),_0x38819c=At(_0x38819c,_0x47ed54,_0x48d7c0['snap'])):G(_0xd86b19,_0x5712e3)&&(_0x47ed54=F(_0xd86b19,_0x5712e3),_0x38819c=At(_0x38819c,w(),_0x48d7c0['snap']['getChild'](_0x47ed54)));else{if(_0x48d7c0['children']){if(G(_0x5712e3,_0xd86b19))_0x47ed54=F(_0x5712e3,_0xd86b19),_0x38819c=bi(_0x38819c,_0x47ed54,_0x48d7c0['children']);else{if(G(_0xd86b19,_0x5712e3)){if(_0x47ed54=F(_0xd86b19,_0x5712e3),v(_0x47ed54))_0x38819c=bi(_0x38819c,w(),_0x48d7c0['children']);else{const _0x14d361=Le(_0x48d7c0['children'],y(_0x47ed54));if(_0x14d361){const _0x36a160=_0x14d361['getChild'](S(_0x47ed54));_0x38819c=At(_0x38819c,w(),_0x36a160);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x38819c;}function Bo(_0x270d81,_0x79afae,_0x30e53f,_0x52e0a8,_0x5be8e5){if(!_0x52e0a8&&!_0x5be8e5){const _0x456132=ze(_0x270d81['visibleWrites'],_0x79afae);if(_0x456132!=null)return _0x456132;{const _0x965fc6=Ee(_0x270d81['visibleWrites'],_0x79afae);if(Ai(_0x965fc6))return _0x30e53f;if(_0x30e53f==null&&!Ri(_0x965fc6,w()))return null;{const _0x51ae1a=_0x30e53f||g['EMPTY_NODE'];return at(_0x965fc6,_0x51ae1a);}}}else{const _0x498ed1=Ee(_0x270d81['visibleWrites'],_0x79afae);if(!_0x5be8e5&&Ai(_0x498ed1))return _0x30e53f;if(!_0x5be8e5&&_0x30e53f==null&&!Ri(_0x498ed1,w()))return null;{const _0x5d855e=function(_0x552188){return(_0x552188['visible']||_0x5be8e5)&&(!_0x52e0a8||!~_0x52e0a8['indexOf'](_0x552188['writeId']))&&(G(_0x552188['path'],_0x79afae)||G(_0x79afae,_0x552188['path']));},_0x556667=Wo(_0x270d81['allWrites'],_0x5d855e,_0x79afae),_0x49b7f1=_0x30e53f||g['EMPTY_NODE'];return at(_0x556667,_0x49b7f1);}}}function gu(_0x143488,_0xb78699,_0x40c1eb){let _0x599f72=g['EMPTY_NODE'];const _0xa7223b=ze(_0x143488['visibleWrites'],_0xb78699);if(_0xa7223b)return _0xa7223b['isLeafNode']()||_0xa7223b['forEachChild'](R,(_0x3a9c89,_0x350b27)=>{_0x599f72=_0x599f72['updateImmediateChild'](_0x3a9c89,_0x350b27);}),_0x599f72;if(_0x40c1eb){const _0x19bc1e=Ee(_0x143488['visibleWrites'],_0xb78699);return _0x40c1eb['forEachChild'](R,(_0x5031ab,_0x22b67a)=>{const _0x260d9b=at(Ee(_0x19bc1e,new C(_0x5031ab)),_0x22b67a);_0x599f72=_0x599f72['updateImmediateChild'](_0x5031ab,_0x260d9b);}),ar(_0x19bc1e)['forEach'](_0x42527d=>{_0x599f72=_0x599f72['updateImmediateChild'](_0x42527d['name'],_0x42527d['node']);}),_0x599f72;}else{const _0x2913cd=Ee(_0x143488['visibleWrites'],_0xb78699);return ar(_0x2913cd)['forEach'](_0x34a8bb=>{_0x599f72=_0x599f72['updateImmediateChild'](_0x34a8bb['name'],_0x34a8bb['node']);}),_0x599f72;}}function mu(_0x4a8d47,_0x414dc3,_0x34abe8,_0xf0c09b,_0x439a4a){f(_0xf0c09b||_0x439a4a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x36696f=k(_0x414dc3,_0x34abe8);if(Ri(_0x4a8d47['visibleWrites'],_0x36696f))return null;{const _0x3b2cb2=Ee(_0x4a8d47['visibleWrites'],_0x36696f);return Ai(_0x3b2cb2)?_0x439a4a['getChild'](_0x34abe8):at(_0x3b2cb2,_0x439a4a['getChild'](_0x34abe8));}}function yu(_0x1bb8bc,_0x482e5a,_0x4968ec,_0x35fe96){const _0x40453a=k(_0x482e5a,_0x4968ec),_0x6a1c32=ze(_0x1bb8bc['visibleWrites'],_0x40453a);if(_0x6a1c32!=null)return _0x6a1c32;if(_0x35fe96['isCompleteForChild'](_0x4968ec)){const _0x3b0417=Ee(_0x1bb8bc['visibleWrites'],_0x40453a);return at(_0x3b0417,_0x35fe96['getNode']()['getImmediateChild'](_0x4968ec));}else return null;}function vu(_0x45e31b,_0xc851f2){return ze(_0x45e31b['visibleWrites'],_0xc851f2);}function Eu(_0x8a24f6,_0x46668c,_0x527e98,_0x5aa2a3,_0x2cb09a,_0x2a0e1c,_0x206ace){let _0x55fe4e;const _0x1a114b=Ee(_0x8a24f6['visibleWrites'],_0x46668c),_0x2fc66a=ze(_0x1a114b,w());if(_0x2fc66a!=null)_0x55fe4e=_0x2fc66a;else{if(_0x527e98!=null)_0x55fe4e=at(_0x1a114b,_0x527e98);else return[];}if(_0x55fe4e=_0x55fe4e['withIndex'](_0x206ace),!_0x55fe4e['isEmpty']()&&!_0x55fe4e['isLeafNode']()){const _0x5f1cd9=[],_0x516cc5=_0x206ace['getCompare'](),_0x3a52b3=_0x2a0e1c?_0x55fe4e['getReverseIteratorFrom'](_0x5aa2a3,_0x206ace):_0x55fe4e['getIteratorFrom'](_0x5aa2a3,_0x206ace);let _0x1c68ca=_0x3a52b3['getNext']();for(;_0x1c68ca&&_0x5f1cd9['length']<_0x2cb09a;)_0x516cc5(_0x1c68ca,_0x5aa2a3)!==0x0&&_0x5f1cd9['push'](_0x1c68ca),_0x1c68ca=_0x3a52b3['getNext']();return _0x5f1cd9;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x479c29,_0x39736d,_0x467dc5,_0x4b4a13){return Bo(_0x479c29['writeTree'],_0x479c29['treePath'],_0x39736d,_0x467dc5,_0x4b4a13);}function is(_0x4e0bdd,_0x243663){return gu(_0x4e0bdd['writeTree'],_0x4e0bdd['treePath'],_0x243663);}function cr(_0x326714,_0x526086,_0x10c5b7,_0x8d18af){return mu(_0x326714['writeTree'],_0x326714['treePath'],_0x526086,_0x10c5b7,_0x8d18af);}function Tn(_0x21d10b,_0x173f0c){return vu(_0x21d10b['writeTree'],k(_0x21d10b['treePath'],_0x173f0c));}function wu(_0x26ad03,_0x5db15f,_0x4f3732,_0x14832d,_0x4d6e2c,_0x539452){return Eu(_0x26ad03['writeTree'],_0x26ad03['treePath'],_0x5db15f,_0x4f3732,_0x14832d,_0x4d6e2c,_0x539452);}function ss(_0x666063,_0x13c998,_0x35e0b3){return yu(_0x666063['writeTree'],_0x666063['treePath'],_0x13c998,_0x35e0b3);}function Vo(_0x95c412,_0x532d19){return Ho(k(_0x95c412['treePath'],_0x532d19),_0x95c412['writeTree']);}function Ho(_0x34e99b,_0x274912){return{'treePath':_0x34e99b,'writeTree':_0x274912};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x48048b){const _0x1bbe7e=_0x48048b['type'],_0x502985=_0x48048b['childName'];f(_0x1bbe7e==='child_added'||_0x1bbe7e==='child_changed'||_0x1bbe7e==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x502985!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0xf33ede=this['changeMap']['get'](_0x502985);if(_0xf33ede){const _0x1cbba6=_0xf33ede['type'];if(_0x1bbe7e==='child_added'&&_0x1cbba6==='child_removed')this['changeMap']['set'](_0x502985,xt(_0x502985,_0x48048b['snapshotNode'],_0xf33ede['snapshotNode']));else{if(_0x1bbe7e==='child_removed'&&_0x1cbba6==='child_added')this['changeMap']['delete'](_0x502985);else{if(_0x1bbe7e==='child_removed'&&_0x1cbba6==='child_changed')this['changeMap']['set'](_0x502985,Lt(_0x502985,_0xf33ede['oldSnap']));else{if(_0x1bbe7e==='child_changed'&&_0x1cbba6==='child_added')this['changeMap']['set'](_0x502985,rt(_0x502985,_0x48048b['snapshotNode']));else{if(_0x1bbe7e==='child_changed'&&_0x1cbba6==='child_changed')this['changeMap']['set'](_0x502985,xt(_0x502985,_0x48048b['snapshotNode'],_0xf33ede['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x48048b+'\x20occurred\x20after\x20'+_0xf33ede);}}}}}else this['changeMap']['set'](_0x502985,_0x48048b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5f2d9c){return null;}['getChildAfterChild'](_0x85c4,_0x447b18,_0x59716f){return null;}}const $o=new Tu();class rs{constructor(_0x5d29d2,_0x3dc436,_0x2d7b60=null){this['writes_']=_0x5d29d2,this['viewCache_']=_0x3dc436,this['optCompleteServerCache_']=_0x2d7b60;}['getCompleteChild'](_0xd7cdf6){const _0x1cd1b1=this['viewCache_']['eventCache'];if(_0x1cd1b1['isCompleteForChild'](_0xd7cdf6))return _0x1cd1b1['getNode']()['getImmediateChild'](_0xd7cdf6);{const _0x22108b=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0xd7cdf6,_0x22108b);}}['getChildAfterChild'](_0x47c45d,_0x4aa8ff,_0x411c35){const _0x2cd021=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x4ce1af=wu(this['writes_'],_0x2cd021,_0x4aa8ff,0x1,_0x411c35,_0x47c45d);return _0x4ce1af['length']===0x0?null:_0x4ce1af[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x162bb5){return{'filter':_0x162bb5};}function bu(_0x49a485,_0xeaba0e){f(_0xeaba0e['eventCache']['getNode']()['isIndexed'](_0x49a485['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xeaba0e['serverCache']['getNode']()['isIndexed'](_0x49a485['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x106137,_0xdb0e0e,_0x5d484e,_0x29cd6a,_0x34d4b8){const _0x4ea847=new Cu();let _0x37fe58,_0x14b17a;if(_0x5d484e['type']===z['OVERWRITE']){const _0x28b1b1=_0x5d484e;_0x28b1b1['source']['fromUser']?_0x37fe58=ki(_0x106137,_0xdb0e0e,_0x28b1b1['path'],_0x28b1b1['snap'],_0x29cd6a,_0x34d4b8,_0x4ea847):(f(_0x28b1b1['source']['fromServer'],'Unknown\x20source.'),_0x14b17a=_0x28b1b1['source']['tagged']||_0xdb0e0e['serverCache']['isFiltered']()&&!v(_0x28b1b1['path']),_0x37fe58=Sn(_0x106137,_0xdb0e0e,_0x28b1b1['path'],_0x28b1b1['snap'],_0x29cd6a,_0x34d4b8,_0x14b17a,_0x4ea847));}else{if(_0x5d484e['type']===z['MERGE']){const _0x5f2204=_0x5d484e;_0x5f2204['source']['fromUser']?_0x37fe58=ku(_0x106137,_0xdb0e0e,_0x5f2204['path'],_0x5f2204['children'],_0x29cd6a,_0x34d4b8,_0x4ea847):(f(_0x5f2204['source']['fromServer'],'Unknown\x20source.'),_0x14b17a=_0x5f2204['source']['tagged']||_0xdb0e0e['serverCache']['isFiltered'](),_0x37fe58=Pi(_0x106137,_0xdb0e0e,_0x5f2204['path'],_0x5f2204['children'],_0x29cd6a,_0x34d4b8,_0x14b17a,_0x4ea847));}else{if(_0x5d484e['type']===z['ACK_USER_WRITE']){const _0x1a4daa=_0x5d484e;_0x1a4daa['revert']?_0x37fe58=Ou(_0x106137,_0xdb0e0e,_0x1a4daa['path'],_0x29cd6a,_0x34d4b8,_0x4ea847):_0x37fe58=Pu(_0x106137,_0xdb0e0e,_0x1a4daa['path'],_0x1a4daa['affectedTree'],_0x29cd6a,_0x34d4b8,_0x4ea847);}else{if(_0x5d484e['type']===z['LISTEN_COMPLETE'])_0x37fe58=Nu(_0x106137,_0xdb0e0e,_0x5d484e['path'],_0x29cd6a,_0x4ea847);else throw ht('Unknown\x20operation\x20type:\x20'+_0x5d484e['type']);}}}const _0x58db1e=_0x4ea847['getChanges']();return Au(_0xdb0e0e,_0x37fe58,_0x58db1e),{'viewCache':_0x37fe58,'changes':_0x58db1e};}function Au(_0x22b2aa,_0x5e956d,_0x2e725f){const _0x2ba65e=_0x5e956d['eventCache'];if(_0x2ba65e['isFullyInitialized']()){const _0x42e76e=_0x2ba65e['getNode']()['isLeafNode']()||_0x2ba65e['getNode']()['isEmpty'](),_0x248967=wn(_0x22b2aa);(_0x2e725f['length']>0x0||!_0x22b2aa['eventCache']['isFullyInitialized']()||_0x42e76e&&!_0x2ba65e['getNode']()['equals'](_0x248967)||!_0x2ba65e['getNode']()['getPriority']()['equals'](_0x248967['getPriority']()))&&_0x2e725f['push'](Lo(wn(_0x5e956d)));}}function Go(_0x1fb86c,_0x3f348a,_0x48bb15,_0x8cddf1,_0x536fb8,_0x5c3194){const _0x1939f4=_0x3f348a['eventCache'];if(Tn(_0x8cddf1,_0x48bb15)!=null)return _0x3f348a;{let _0x139705,_0x1b9fbe;if(v(_0x48bb15)){if(f(_0x3f348a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3f348a['serverCache']['isFiltered']()){const _0x3ca9b3=Ve(_0x3f348a),_0x17a30c=_0x3ca9b3 instanceof g?_0x3ca9b3:g['EMPTY_NODE'],_0x13a5f0=is(_0x8cddf1,_0x17a30c);_0x139705=_0x1fb86c['filter']['updateFullNode'](_0x3f348a['eventCache']['getNode'](),_0x13a5f0,_0x5c3194);}else{const _0x21bc4c=Cn(_0x8cddf1,Ve(_0x3f348a));_0x139705=_0x1fb86c['filter']['updateFullNode'](_0x3f348a['eventCache']['getNode'](),_0x21bc4c,_0x5c3194);}}else{const _0xc14d69=y(_0x48bb15);if(_0xc14d69==='.priority'){f(Ce(_0x48bb15)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x394f66=_0x1939f4['getNode']();_0x1b9fbe=_0x3f348a['serverCache']['getNode']();const _0x9ee8b2=cr(_0x8cddf1,_0x48bb15,_0x394f66,_0x1b9fbe);_0x9ee8b2!=null?_0x139705=_0x1fb86c['filter']['updatePriority'](_0x394f66,_0x9ee8b2):_0x139705=_0x1939f4['getNode']();}else{const _0x5217bc=S(_0x48bb15);let _0xcf4661;if(_0x1939f4['isCompleteForChild'](_0xc14d69)){_0x1b9fbe=_0x3f348a['serverCache']['getNode']();const _0x29cd8f=cr(_0x8cddf1,_0x48bb15,_0x1939f4['getNode'](),_0x1b9fbe);_0x29cd8f!=null?_0xcf4661=_0x1939f4['getNode']()['getImmediateChild'](_0xc14d69)['updateChild'](_0x5217bc,_0x29cd8f):_0xcf4661=_0x1939f4['getNode']()['getImmediateChild'](_0xc14d69);}else _0xcf4661=ss(_0x8cddf1,_0xc14d69,_0x3f348a['serverCache']);_0xcf4661!=null?_0x139705=_0x1fb86c['filter']['updateChild'](_0x1939f4['getNode'](),_0xc14d69,_0xcf4661,_0x5217bc,_0x536fb8,_0x5c3194):_0x139705=_0x1939f4['getNode']();}}return Rt(_0x3f348a,_0x139705,_0x1939f4['isFullyInitialized']()||v(_0x48bb15),_0x1fb86c['filter']['filtersNodes']());}}function Sn(_0x169dd9,_0x29e339,_0x2c6188,_0x12acc7,_0x4a235f,_0x50f948,_0x3a733f,_0x14fcf2){const _0x11ed34=_0x29e339['serverCache'];let _0x5295f2;const _0x3871d4=_0x3a733f?_0x169dd9['filter']:_0x169dd9['filter']['getIndexedFilter']();if(v(_0x2c6188))_0x5295f2=_0x3871d4['updateFullNode'](_0x11ed34['getNode'](),_0x12acc7,null);else{if(_0x3871d4['filtersNodes']()&&!_0x11ed34['isFiltered']()){const _0x25546e=_0x11ed34['getNode']()['updateChild'](_0x2c6188,_0x12acc7);_0x5295f2=_0x3871d4['updateFullNode'](_0x11ed34['getNode'](),_0x25546e,null);}else{const _0x4ee362=y(_0x2c6188);if(!_0x11ed34['isCompleteForPath'](_0x2c6188)&&Ce(_0x2c6188)>0x1)return _0x29e339;const _0xecb39c=S(_0x2c6188),_0x4fcc2e=_0x11ed34['getNode']()['getImmediateChild'](_0x4ee362)['updateChild'](_0xecb39c,_0x12acc7);_0x4ee362==='.priority'?_0x5295f2=_0x3871d4['updatePriority'](_0x11ed34['getNode'](),_0x4fcc2e):_0x5295f2=_0x3871d4['updateChild'](_0x11ed34['getNode'](),_0x4ee362,_0x4fcc2e,_0xecb39c,$o,null);}}const _0x509d17=Fo(_0x29e339,_0x5295f2,_0x11ed34['isFullyInitialized']()||v(_0x2c6188),_0x3871d4['filtersNodes']()),_0x321f86=new rs(_0x4a235f,_0x509d17,_0x50f948);return Go(_0x169dd9,_0x509d17,_0x2c6188,_0x4a235f,_0x321f86,_0x14fcf2);}function ki(_0x36b1fc,_0x44ca45,_0x26f0b3,_0x4e2975,_0xbe49a2,_0x5af1b7,_0x1bc1de){const _0x1473e9=_0x44ca45['eventCache'];let _0x292468,_0x461953;const _0xd96b54=new rs(_0xbe49a2,_0x44ca45,_0x5af1b7);if(v(_0x26f0b3))_0x461953=_0x36b1fc['filter']['updateFullNode'](_0x44ca45['eventCache']['getNode'](),_0x4e2975,_0x1bc1de),_0x292468=Rt(_0x44ca45,_0x461953,!0x0,_0x36b1fc['filter']['filtersNodes']());else{const _0x293d51=y(_0x26f0b3);if(_0x293d51==='.priority')_0x461953=_0x36b1fc['filter']['updatePriority'](_0x44ca45['eventCache']['getNode'](),_0x4e2975),_0x292468=Rt(_0x44ca45,_0x461953,_0x1473e9['isFullyInitialized'](),_0x1473e9['isFiltered']());else{const _0xfb971b=S(_0x26f0b3),_0x47e88e=_0x1473e9['getNode']()['getImmediateChild'](_0x293d51);let _0x3bd237;if(v(_0xfb971b))_0x3bd237=_0x4e2975;else{const _0xf1ca40=_0xd96b54['getCompleteChild'](_0x293d51);_0xf1ca40!=null?ji(_0xfb971b)==='.priority'&&_0xf1ca40['getChild'](Ro(_0xfb971b))['isEmpty']()?_0x3bd237=_0xf1ca40:_0x3bd237=_0xf1ca40['updateChild'](_0xfb971b,_0x4e2975):_0x3bd237=g['EMPTY_NODE'];}if(_0x47e88e['equals'](_0x3bd237))_0x292468=_0x44ca45;else{const _0x4bf423=_0x36b1fc['filter']['updateChild'](_0x1473e9['getNode'](),_0x293d51,_0x3bd237,_0xfb971b,_0xd96b54,_0x1bc1de);_0x292468=Rt(_0x44ca45,_0x4bf423,_0x1473e9['isFullyInitialized'](),_0x36b1fc['filter']['filtersNodes']());}}}return _0x292468;}function lr(_0xa7f5e1,_0x9903e5){return _0xa7f5e1['eventCache']['isCompleteForChild'](_0x9903e5);}function ku(_0x4d3ac3,_0x572ffe,_0x43da93,_0x3635dd,_0xc9c0d0,_0x4acc48,_0x2f6c16){let _0xec2085=_0x572ffe;return _0x3635dd['foreach']((_0xf2b883,_0x203973)=>{const _0x28a1f6=k(_0x43da93,_0xf2b883);lr(_0x572ffe,y(_0x28a1f6))&&(_0xec2085=ki(_0x4d3ac3,_0xec2085,_0x28a1f6,_0x203973,_0xc9c0d0,_0x4acc48,_0x2f6c16));}),_0x3635dd['foreach']((_0x33119a,_0x22c5c9)=>{const _0x43b84f=k(_0x43da93,_0x33119a);lr(_0x572ffe,y(_0x43b84f))||(_0xec2085=ki(_0x4d3ac3,_0xec2085,_0x43b84f,_0x22c5c9,_0xc9c0d0,_0x4acc48,_0x2f6c16));}),_0xec2085;}function hr(_0x55ceeb,_0x389b3c,_0x3f6b58){return _0x3f6b58['foreach']((_0x5cd538,_0x25729e)=>{_0x389b3c=_0x389b3c['updateChild'](_0x5cd538,_0x25729e);}),_0x389b3c;}function Pi(_0xe089f6,_0x38b289,_0x38f122,_0x4dd90b,_0xa24b92,_0x13e70c,_0x1e573d,_0x2c8ef0){if(_0x38b289['serverCache']['getNode']()['isEmpty']()&&!_0x38b289['serverCache']['isFullyInitialized']())return _0x38b289;let _0x43c2d9=_0x38b289,_0x26c6bb;v(_0x38f122)?_0x26c6bb=_0x4dd90b:_0x26c6bb=new b(null)['setTree'](_0x38f122,_0x4dd90b);const _0x3af258=_0x38b289['serverCache']['getNode']();return _0x26c6bb['children']['inorderTraversal']((_0xb9162a,_0x341ec0)=>{if(_0x3af258['hasChild'](_0xb9162a)){const _0x39b6e4=_0x38b289['serverCache']['getNode']()['getImmediateChild'](_0xb9162a),_0x4ad378=hr(_0xe089f6,_0x39b6e4,_0x341ec0);_0x43c2d9=Sn(_0xe089f6,_0x43c2d9,new C(_0xb9162a),_0x4ad378,_0xa24b92,_0x13e70c,_0x1e573d,_0x2c8ef0);}}),_0x26c6bb['children']['inorderTraversal']((_0x199704,_0x224057)=>{const _0xef1e8e=!_0x38b289['serverCache']['isCompleteForChild'](_0x199704)&&_0x224057['value']===null;if(!_0x3af258['hasChild'](_0x199704)&&!_0xef1e8e){const _0x291024=_0x38b289['serverCache']['getNode']()['getImmediateChild'](_0x199704),_0xf2a79=hr(_0xe089f6,_0x291024,_0x224057);_0x43c2d9=Sn(_0xe089f6,_0x43c2d9,new C(_0x199704),_0xf2a79,_0xa24b92,_0x13e70c,_0x1e573d,_0x2c8ef0);}}),_0x43c2d9;}function Pu(_0x415880,_0x4c43e6,_0x23c542,_0xb7536,_0x574ba2,_0x3abab4,_0xace418){if(Tn(_0x574ba2,_0x23c542)!=null)return _0x4c43e6;const _0x259332=_0x4c43e6['serverCache']['isFiltered'](),_0x4786a2=_0x4c43e6['serverCache'];if(_0xb7536['value']!=null){if(v(_0x23c542)&&_0x4786a2['isFullyInitialized']()||_0x4786a2['isCompleteForPath'](_0x23c542))return Sn(_0x415880,_0x4c43e6,_0x23c542,_0x4786a2['getNode']()['getChild'](_0x23c542),_0x574ba2,_0x3abab4,_0x259332,_0xace418);if(v(_0x23c542)){let _0x4da3fa=new b(null);return _0x4786a2['getNode']()['forEachChild'](ve,(_0x495944,_0x7b2eb4)=>{_0x4da3fa=_0x4da3fa['set'](new C(_0x495944),_0x7b2eb4);}),Pi(_0x415880,_0x4c43e6,_0x23c542,_0x4da3fa,_0x574ba2,_0x3abab4,_0x259332,_0xace418);}else return _0x4c43e6;}else{let _0x56e280=new b(null);return _0xb7536['foreach']((_0x12d7f4,_0x44604d)=>{const _0x36292f=k(_0x23c542,_0x12d7f4);_0x4786a2['isCompleteForPath'](_0x36292f)&&(_0x56e280=_0x56e280['set'](_0x12d7f4,_0x4786a2['getNode']()['getChild'](_0x36292f)));}),Pi(_0x415880,_0x4c43e6,_0x23c542,_0x56e280,_0x574ba2,_0x3abab4,_0x259332,_0xace418);}}function Nu(_0x515e43,_0x37b1dc,_0x1c4f38,_0x9c2fd5,_0x314573){const _0x9c28b4=_0x37b1dc['serverCache'],_0xe0a146=Fo(_0x37b1dc,_0x9c28b4['getNode'](),_0x9c28b4['isFullyInitialized']()||v(_0x1c4f38),_0x9c28b4['isFiltered']());return Go(_0x515e43,_0xe0a146,_0x1c4f38,_0x9c2fd5,$o,_0x314573);}function Ou(_0x29570c,_0xe64872,_0x5bb54f,_0x3c61d9,_0xe4501,_0x43a21b){let _0x258d0b;if(Tn(_0x3c61d9,_0x5bb54f)!=null)return _0xe64872;{const _0x1b7647=new rs(_0x3c61d9,_0xe64872,_0xe4501),_0x1b2554=_0xe64872['eventCache']['getNode']();let _0x48fc4c;if(v(_0x5bb54f)||y(_0x5bb54f)==='.priority'){let _0x211b7a;if(_0xe64872['serverCache']['isFullyInitialized']())_0x211b7a=Cn(_0x3c61d9,Ve(_0xe64872));else{const _0x1079b9=_0xe64872['serverCache']['getNode']();f(_0x1079b9 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x211b7a=is(_0x3c61d9,_0x1079b9);}_0x211b7a=_0x211b7a,_0x48fc4c=_0x29570c['filter']['updateFullNode'](_0x1b2554,_0x211b7a,_0x43a21b);}else{const _0x2e4412=y(_0x5bb54f);let _0x4a930e=ss(_0x3c61d9,_0x2e4412,_0xe64872['serverCache']);_0x4a930e==null&&_0xe64872['serverCache']['isCompleteForChild'](_0x2e4412)&&(_0x4a930e=_0x1b2554['getImmediateChild'](_0x2e4412)),_0x4a930e!=null?_0x48fc4c=_0x29570c['filter']['updateChild'](_0x1b2554,_0x2e4412,_0x4a930e,S(_0x5bb54f),_0x1b7647,_0x43a21b):_0xe64872['eventCache']['getNode']()['hasChild'](_0x2e4412)?_0x48fc4c=_0x29570c['filter']['updateChild'](_0x1b2554,_0x2e4412,g['EMPTY_NODE'],S(_0x5bb54f),_0x1b7647,_0x43a21b):_0x48fc4c=_0x1b2554,_0x48fc4c['isEmpty']()&&_0xe64872['serverCache']['isFullyInitialized']()&&(_0x258d0b=Cn(_0x3c61d9,Ve(_0xe64872)),_0x258d0b['isLeafNode']()&&(_0x48fc4c=_0x29570c['filter']['updateFullNode'](_0x48fc4c,_0x258d0b,_0x43a21b)));}return _0x258d0b=_0xe64872['serverCache']['isFullyInitialized']()||Tn(_0x3c61d9,w())!=null,Rt(_0xe64872,_0x48fc4c,_0x258d0b,_0x29570c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x517a52,_0x26d6b9){this['query_']=_0x517a52,this['eventRegistrations_']=[];const _0x17fcf7=this['query_']['_queryParams'],_0x747a5d=new Xi(_0x17fcf7['getIndex']()),_0x23d165=Kh(_0x17fcf7);this['processor_']=Su(_0x23d165);const _0x23c313=_0x26d6b9['serverCache'],_0x18747d=_0x26d6b9['eventCache'],_0xef5869=_0x747a5d['updateFullNode'](g['EMPTY_NODE'],_0x23c313['getNode'](),null),_0x4db4c8=_0x23d165['updateFullNode'](g['EMPTY_NODE'],_0x18747d['getNode'](),null),_0x555ffa=new Te(_0xef5869,_0x23c313['isFullyInitialized'](),_0x747a5d['filtersNodes']()),_0x11f106=new Te(_0x4db4c8,_0x18747d['isFullyInitialized'](),_0x23d165['filtersNodes']());this['viewCache_']=Un(_0x11f106,_0x555ffa),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x225ebb){return _0x225ebb['viewCache_']['serverCache']['getNode']();}function Lu(_0x49e3a1){return wn(_0x49e3a1['viewCache_']);}function xu(_0x30b089,_0xdf98f7){const _0x3c57f2=Ve(_0x30b089['viewCache_']);return _0x3c57f2&&(_0x30b089['query']['_queryParams']['loadsAllData']()||!v(_0xdf98f7)&&!_0x3c57f2['getImmediateChild'](y(_0xdf98f7))['isEmpty']())?_0x3c57f2['getChild'](_0xdf98f7):null;}function ur(_0x2134e0){return _0x2134e0['eventRegistrations_']['length']===0x0;}function Fu(_0x32b902,_0x75873e){_0x32b902['eventRegistrations_']['push'](_0x75873e);}function dr(_0x138b02,_0x471aac,_0x4fb304){const _0x1ab808=[];if(_0x4fb304){f(_0x471aac==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x77dc6f=_0x138b02['query']['_path'];_0x138b02['eventRegistrations_']['forEach'](_0x42ac8c=>{const _0x1c44b0=_0x42ac8c['createCancelEvent'](_0x4fb304,_0x77dc6f);_0x1c44b0&&_0x1ab808['push'](_0x1c44b0);});}if(_0x471aac){let _0x3dd19a=[];for(let _0x1a8043=0x0;_0x1a8043<_0x138b02['eventRegistrations_']['length'];++_0x1a8043){const _0x134b47=_0x138b02['eventRegistrations_'][_0x1a8043];if(!_0x134b47['matches'](_0x471aac))_0x3dd19a['push'](_0x134b47);else{if(_0x471aac['hasAnyCallback']()){_0x3dd19a=_0x3dd19a['concat'](_0x138b02['eventRegistrations_']['slice'](_0x1a8043+0x1));break;}}}_0x138b02['eventRegistrations_']=_0x3dd19a;}else _0x138b02['eventRegistrations_']=[];return _0x1ab808;}function fr(_0x785057,_0x536585,_0xb8c6f6,_0x1c30b5){_0x536585['type']===z['MERGE']&&_0x536585['source']['queryId']!==null&&(f(Ve(_0x785057['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x785057['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x59d5eb=_0x785057['viewCache_'],_0x841e1d=Ru(_0x785057['processor_'],_0x59d5eb,_0x536585,_0xb8c6f6,_0x1c30b5);return bu(_0x785057['processor_'],_0x841e1d['viewCache']),f(_0x841e1d['viewCache']['serverCache']['isFullyInitialized']()||!_0x59d5eb['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x785057['viewCache_']=_0x841e1d['viewCache'],qo(_0x785057,_0x841e1d['changes'],_0x841e1d['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x4153fb,_0x5ccaf4){const _0x54dd3a=_0x4153fb['viewCache_']['eventCache'],_0x3d6bad=[];return _0x54dd3a['getNode']()['isLeafNode']()||_0x54dd3a['getNode']()['forEachChild'](R,(_0x6df4a,_0x87ec6)=>{_0x3d6bad['push'](rt(_0x6df4a,_0x87ec6));}),_0x54dd3a['isFullyInitialized']()&&_0x3d6bad['push'](Lo(_0x54dd3a['getNode']())),qo(_0x4153fb,_0x3d6bad,_0x54dd3a['getNode'](),_0x5ccaf4);}function qo(_0x33feeb,_0x51b441,_0x3407f9,_0x55b4c9){const _0x10322b=_0x55b4c9?[_0x55b4c9]:_0x33feeb['eventRegistrations_'];return ru(_0x33feeb['eventGenerator_'],_0x51b441,_0x3407f9,_0x10322b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x214b97){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x214b97;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x4a185d){return _0x4a185d['views']['size']===0x0;}function os(_0x1eb56e,_0x33a547,_0x425298,_0x3cfa1a){const _0x47180e=_0x33a547['source']['queryId'];if(_0x47180e!==null){const _0x3bd0bb=_0x1eb56e['views']['get'](_0x47180e);return f(_0x3bd0bb!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x3bd0bb,_0x33a547,_0x425298,_0x3cfa1a);}else{let _0x1e8456=[];for(const _0x1c516e of _0x1eb56e['views']['values']())_0x1e8456=_0x1e8456['concat'](fr(_0x1c516e,_0x33a547,_0x425298,_0x3cfa1a));return _0x1e8456;}}function jo(_0x166813,_0xf29a50,_0x2c8d47,_0x56db75,_0xbf88d0){const _0x5f04c5=_0xf29a50['_queryIdentifier'],_0x1a4342=_0x166813['views']['get'](_0x5f04c5);if(!_0x1a4342){let _0x412c10=Cn(_0x2c8d47,_0xbf88d0?_0x56db75:null),_0x4f81da=!0x1;_0x412c10?_0x4f81da=!0x0:_0x56db75 instanceof g?(_0x412c10=is(_0x2c8d47,_0x56db75),_0x4f81da=!0x1):(_0x412c10=g['EMPTY_NODE'],_0x4f81da=!0x1);const _0xe3ff0e=Un(new Te(_0x412c10,_0x4f81da,!0x1),new Te(_0x56db75,_0xbf88d0,!0x1));return new Du(_0xf29a50,_0xe3ff0e);}return _0x1a4342;}function Hu(_0xa76918,_0x2d78af,_0x27fa6c,_0x10d005,_0x4c821b,_0x41db7d){const _0x2ee3b0=jo(_0xa76918,_0x2d78af,_0x10d005,_0x4c821b,_0x41db7d);return _0xa76918['views']['has'](_0x2d78af['_queryIdentifier'])||_0xa76918['views']['set'](_0x2d78af['_queryIdentifier'],_0x2ee3b0),Fu(_0x2ee3b0,_0x27fa6c),Uu(_0x2ee3b0,_0x27fa6c);}function $u(_0x182331,_0x493148,_0x3a534b,_0x2d9728){const _0x27d52d=_0x493148['_queryIdentifier'],_0x251af6=[];let _0xc28825=[];const _0x84eb1e=Se(_0x182331);if(_0x27d52d==='default'){for(const [_0x350dac,_0x523cd3]of _0x182331['views']['entries']())_0xc28825=_0xc28825['concat'](dr(_0x523cd3,_0x3a534b,_0x2d9728)),ur(_0x523cd3)&&(_0x182331['views']['delete'](_0x350dac),_0x523cd3['query']['_queryParams']['loadsAllData']()||_0x251af6['push'](_0x523cd3['query']));}else{const _0xd43cf3=_0x182331['views']['get'](_0x27d52d);_0xd43cf3&&(_0xc28825=_0xc28825['concat'](dr(_0xd43cf3,_0x3a534b,_0x2d9728)),ur(_0xd43cf3)&&(_0x182331['views']['delete'](_0x27d52d),_0xd43cf3['query']['_queryParams']['loadsAllData']()||_0x251af6['push'](_0xd43cf3['query'])));}return _0x84eb1e&&!Se(_0x182331)&&_0x251af6['push'](new(Bu())(_0x493148['_repo'],_0x493148['_path'])),{'removed':_0x251af6,'events':_0xc28825};}function Ko(_0x54c66e){const _0x473a4d=[];for(const _0xdfc289 of _0x54c66e['views']['values']())_0xdfc289['query']['_queryParams']['loadsAllData']()||_0x473a4d['push'](_0xdfc289);return _0x473a4d;}function Ie(_0x541908,_0x36a6b7){let _0x3ec678=null;for(const _0x1bb6d1 of _0x541908['views']['values']())_0x3ec678=_0x3ec678||xu(_0x1bb6d1,_0x36a6b7);return _0x3ec678;}function Yo(_0x5ca383,_0x15adf7){if(_0x15adf7['_queryParams']['loadsAllData']())return Bn(_0x5ca383);{const _0x281505=_0x15adf7['_queryIdentifier'];return _0x5ca383['views']['get'](_0x281505);}}function Qo(_0x4f3347,_0x2fd999){return Yo(_0x4f3347,_0x2fd999)!=null;}function Se(_0x36e214){return Bn(_0x36e214)!=null;}function Bn(_0x34acf3){for(const _0x3b68e8 of _0x34acf3['views']['values']())if(_0x3b68e8['query']['_queryParams']['loadsAllData']())return _0x3b68e8;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2187b5){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2187b5;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x5a0ba2){this['listenProvider_']=_0x5a0ba2,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x360357,_0x42c72b,_0x4440f3,_0x48b570,_0x5d9b3e){return lu(_0x360357['pendingWriteTree_'],_0x42c72b,_0x4440f3,_0x48b570,_0x5d9b3e),_0x5d9b3e?_t(_0x360357,new Be(es(),_0x42c72b,_0x4440f3)):[];}function ju(_0x1e9c69,_0x4346ae,_0x3e8218,_0x312d6a){hu(_0x1e9c69['pendingWriteTree_'],_0x4346ae,_0x3e8218,_0x312d6a);const _0x2f44ac=b['fromObject'](_0x3e8218);return _t(_0x1e9c69,new ot(es(),_0x4346ae,_0x2f44ac));}function _e(_0x98166f,_0x5f0644,_0x266093=!0x1){const _0x53bf5c=uu(_0x98166f['pendingWriteTree_'],_0x5f0644);if(du(_0x98166f['pendingWriteTree_'],_0x5f0644)){let _0x49fadb=new b(null);return _0x53bf5c['snap']!=null?_0x49fadb=_0x49fadb['set'](w(),!0x0):x(_0x53bf5c['children'],_0x429753=>{_0x49fadb=_0x49fadb['set'](new C(_0x429753),!0x0);}),_t(_0x98166f,new In(_0x53bf5c['path'],_0x49fadb,_0x266093));}else return[];}function Yt(_0x1254a3,_0x391873,_0x58448d){return _t(_0x1254a3,new Be(ts(),_0x391873,_0x58448d));}function Ku(_0x444fc7,_0x10125e,_0x1fc1af){const _0x4b4ef1=b['fromObject'](_0x1fc1af);return _t(_0x444fc7,new ot(ts(),_0x10125e,_0x4b4ef1));}function Yu(_0x242871,_0xa554dc){return _t(_0x242871,new Ut(ts(),_0xa554dc));}function Qu(_0x13d940,_0xeb05d,_0x13cf52){const _0x9c8a94=cs(_0x13d940,_0x13cf52);if(_0x9c8a94){const _0xd0a73b=ls(_0x9c8a94),_0x26ee3c=_0xd0a73b['path'],_0x58bfa4=_0xd0a73b['queryId'],_0x5ba542=F(_0x26ee3c,_0xeb05d),_0x389f71=new Ut(ns(_0x58bfa4),_0x5ba542);return hs(_0x13d940,_0x26ee3c,_0x389f71);}else return[];}function An(_0x43e4f4,_0x19cb24,_0x431adb,_0x3f22b7,_0xc1cb0a=!0x1){const _0x1aeb39=_0x19cb24['_path'],_0x48c60a=_0x43e4f4['syncPointTree_']['get'](_0x1aeb39);let _0x1aa6e2=[];if(_0x48c60a&&(_0x19cb24['_queryIdentifier']==='default'||Qo(_0x48c60a,_0x19cb24))){const _0x13cf32=$u(_0x48c60a,_0x19cb24,_0x431adb,_0x3f22b7);Vu(_0x48c60a)&&(_0x43e4f4['syncPointTree_']=_0x43e4f4['syncPointTree_']['remove'](_0x1aeb39));const _0x58b00f=_0x13cf32['removed'];if(_0x1aa6e2=_0x13cf32['events'],!_0xc1cb0a){const _0x5d60a4=_0x58b00f['findIndex'](_0x23b460=>_0x23b460['_queryParams']['loadsAllData']())!==-0x1,_0x2c2d99=_0x43e4f4['syncPointTree_']['findOnPath'](_0x1aeb39,(_0x35cd58,_0x228944)=>Se(_0x228944));if(_0x5d60a4&&!_0x2c2d99){const _0x24c08c=_0x43e4f4['syncPointTree_']['subtree'](_0x1aeb39);if(!_0x24c08c['isEmpty']()){const _0x267a79=Zu(_0x24c08c);for(let _0x1cdf7d=0x0;_0x1cdf7d<_0x267a79['length'];++_0x1cdf7d){const _0x5a4750=_0x267a79[_0x1cdf7d],_0x9df37e=_0x5a4750['query'],_0x88c4f2=ea(_0x43e4f4,_0x5a4750);_0x43e4f4['listenProvider_']['startListening'](kt(_0x9df37e),Wt(_0x43e4f4,_0x9df37e),_0x88c4f2['hashFn'],_0x88c4f2['onComplete']);}}}!_0x2c2d99&&_0x58b00f['length']>0x0&&!_0x3f22b7&&(_0x5d60a4?_0x43e4f4['listenProvider_']['stopListening'](kt(_0x19cb24),null):_0x58b00f['forEach'](_0x9f5fe3=>{const _0x2f172d=_0x43e4f4['queryToTagMap']['get'](Hn(_0x9f5fe3));_0x43e4f4['listenProvider_']['stopListening'](kt(_0x9f5fe3),_0x2f172d);}));}ed(_0x43e4f4,_0x58b00f);}return _0x1aa6e2;}function Jo(_0x445c9d,_0x4ed049,_0x283cb7,_0x1db8aa){const _0x3fd70a=cs(_0x445c9d,_0x1db8aa);if(_0x3fd70a!=null){const _0x44f22a=ls(_0x3fd70a),_0x431a6a=_0x44f22a['path'],_0x1e6699=_0x44f22a['queryId'],_0x2b8c63=F(_0x431a6a,_0x4ed049),_0x4c7da2=new Be(ns(_0x1e6699),_0x2b8c63,_0x283cb7);return hs(_0x445c9d,_0x431a6a,_0x4c7da2);}else return[];}function Ju(_0x2ac340,_0xadc4a1,_0x3bdef1,_0x161d32){const _0x97b650=cs(_0x2ac340,_0x161d32);if(_0x97b650){const _0x1bb24a=ls(_0x97b650),_0x3fb948=_0x1bb24a['path'],_0x3d0790=_0x1bb24a['queryId'],_0x580974=F(_0x3fb948,_0xadc4a1),_0x1a51ea=b['fromObject'](_0x3bdef1),_0x1a874=new ot(ns(_0x3d0790),_0x580974,_0x1a51ea);return hs(_0x2ac340,_0x3fb948,_0x1a874);}else return[];}function Ni(_0x518a15,_0x805a21,_0x4e2020,_0x65f4c=!0x1){const _0x1440ea=_0x805a21['_path'];let _0x2f9550=null,_0x2f2542=!0x1;_0x518a15['syncPointTree_']['foreachOnPath'](_0x1440ea,(_0x5771e4,_0x3b03bf)=>{const _0x32ee9e=F(_0x5771e4,_0x1440ea);_0x2f9550=_0x2f9550||Ie(_0x3b03bf,_0x32ee9e),_0x2f2542=_0x2f2542||Se(_0x3b03bf);});let _0xcc3732=_0x518a15['syncPointTree_']['get'](_0x1440ea);_0xcc3732?(_0x2f2542=_0x2f2542||Se(_0xcc3732),_0x2f9550=_0x2f9550||Ie(_0xcc3732,w())):(_0xcc3732=new zo(),_0x518a15['syncPointTree_']=_0x518a15['syncPointTree_']['set'](_0x1440ea,_0xcc3732));let _0x46d79c;_0x2f9550!=null?_0x46d79c=!0x0:(_0x46d79c=!0x1,_0x2f9550=g['EMPTY_NODE'],_0x518a15['syncPointTree_']['subtree'](_0x1440ea)['foreachChild']((_0x39dc2b,_0x36e8d1)=>{const _0x3fe87f=Ie(_0x36e8d1,w());_0x3fe87f&&(_0x2f9550=_0x2f9550['updateImmediateChild'](_0x39dc2b,_0x3fe87f));}));const _0x1fe82e=Qo(_0xcc3732,_0x805a21);if(!_0x1fe82e&&!_0x805a21['_queryParams']['loadsAllData']()){const _0x8c8203=Hn(_0x805a21);f(!_0x518a15['queryToTagMap']['has'](_0x8c8203),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x4eb79b=td();_0x518a15['queryToTagMap']['set'](_0x8c8203,_0x4eb79b),_0x518a15['tagToQueryMap']['set'](_0x4eb79b,_0x8c8203);}const _0x30aa03=Wn(_0x518a15['pendingWriteTree_'],_0x1440ea);let _0x3ffd16=Hu(_0xcc3732,_0x805a21,_0x4e2020,_0x30aa03,_0x2f9550,_0x46d79c);if(!_0x1fe82e&&!_0x2f2542&&!_0x65f4c){const _0x57f401=Yo(_0xcc3732,_0x805a21);_0x3ffd16=_0x3ffd16['concat'](nd(_0x518a15,_0x805a21,_0x57f401));}return _0x3ffd16;}function Vn(_0x4a0220,_0x3cb0fd,_0x432d5d){const _0x487f2b=_0x4a0220['pendingWriteTree_'],_0x442b7b=_0x4a0220['syncPointTree_']['findOnPath'](_0x3cb0fd,(_0x584afa,_0x437195)=>{const _0x15f07b=F(_0x584afa,_0x3cb0fd),_0x4653a7=Ie(_0x437195,_0x15f07b);if(_0x4653a7)return _0x4653a7;});return Bo(_0x487f2b,_0x3cb0fd,_0x442b7b,_0x432d5d,!0x0);}function Xu(_0x53db4c,_0x5eec82){const _0x23f5c2=_0x5eec82['_path'];let _0x1ebe68=null;_0x53db4c['syncPointTree_']['foreachOnPath'](_0x23f5c2,(_0x46bb52,_0x344d55)=>{const _0x1899da=F(_0x46bb52,_0x23f5c2);_0x1ebe68=_0x1ebe68||Ie(_0x344d55,_0x1899da);});let _0x55123e=_0x53db4c['syncPointTree_']['get'](_0x23f5c2);_0x55123e?_0x1ebe68=_0x1ebe68||Ie(_0x55123e,w()):(_0x55123e=new zo(),_0x53db4c['syncPointTree_']=_0x53db4c['syncPointTree_']['set'](_0x23f5c2,_0x55123e));const _0x23b941=_0x1ebe68!=null,_0x205095=_0x23b941?new Te(_0x1ebe68,!0x0,!0x1):null,_0x4f94a9=Wn(_0x53db4c['pendingWriteTree_'],_0x5eec82['_path']),_0x2ccb51=jo(_0x55123e,_0x5eec82,_0x4f94a9,_0x23b941?_0x205095['getNode']():g['EMPTY_NODE'],_0x23b941);return Lu(_0x2ccb51);}function _t(_0xc8ab5e,_0x167ce9){return Xo(_0x167ce9,_0xc8ab5e['syncPointTree_'],null,Wn(_0xc8ab5e['pendingWriteTree_'],w()));}function Xo(_0x28d611,_0x37d1fe,_0x535681,_0x1acd62){if(v(_0x28d611['path']))return Zo(_0x28d611,_0x37d1fe,_0x535681,_0x1acd62);{const _0x52f44a=_0x37d1fe['get'](w());_0x535681==null&&_0x52f44a!=null&&(_0x535681=Ie(_0x52f44a,w()));let _0xd61bb7=[];const _0x1e8c12=y(_0x28d611['path']),_0x2af0dd=_0x28d611['operationForChild'](_0x1e8c12),_0x26b942=_0x37d1fe['children']['get'](_0x1e8c12);if(_0x26b942&&_0x2af0dd){const _0x5256ea=_0x535681?_0x535681['getImmediateChild'](_0x1e8c12):null,_0x3cfe1b=Vo(_0x1acd62,_0x1e8c12);_0xd61bb7=_0xd61bb7['concat'](Xo(_0x2af0dd,_0x26b942,_0x5256ea,_0x3cfe1b));}return _0x52f44a&&(_0xd61bb7=_0xd61bb7['concat'](os(_0x52f44a,_0x28d611,_0x1acd62,_0x535681))),_0xd61bb7;}}function Zo(_0x1f1c46,_0x50e7f3,_0x12b9ce,_0x1bfb29){const _0x33de08=_0x50e7f3['get'](w());_0x12b9ce==null&&_0x33de08!=null&&(_0x12b9ce=Ie(_0x33de08,w()));let _0x16e9bd=[];return _0x50e7f3['children']['inorderTraversal']((_0x374c1a,_0x15b68d)=>{const _0x355e45=_0x12b9ce?_0x12b9ce['getImmediateChild'](_0x374c1a):null,_0x165a85=Vo(_0x1bfb29,_0x374c1a),_0x3ced5d=_0x1f1c46['operationForChild'](_0x374c1a);_0x3ced5d&&(_0x16e9bd=_0x16e9bd['concat'](Zo(_0x3ced5d,_0x15b68d,_0x355e45,_0x165a85)));}),_0x33de08&&(_0x16e9bd=_0x16e9bd['concat'](os(_0x33de08,_0x1f1c46,_0x1bfb29,_0x12b9ce))),_0x16e9bd;}function ea(_0xbf5825,_0x39417d){const _0x3a0010=_0x39417d['query'],_0x358c68=Wt(_0xbf5825,_0x3a0010);return{'hashFn':()=>(Mu(_0x39417d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x46f86f=>{if(_0x46f86f==='ok')return _0x358c68?Qu(_0xbf5825,_0x3a0010['_path'],_0x358c68):Yu(_0xbf5825,_0x3a0010['_path']);{const _0x13c038=Kl(_0x46f86f,_0x3a0010);return An(_0xbf5825,_0x3a0010,null,_0x13c038);}}};}function Wt(_0x2c96cb,_0x240afe){const _0x513189=Hn(_0x240afe);return _0x2c96cb['queryToTagMap']['get'](_0x513189);}function Hn(_0x182b46){return _0x182b46['_path']['toString']()+'$'+_0x182b46['_queryIdentifier'];}function cs(_0x8f44f7,_0x473f07){return _0x8f44f7['tagToQueryMap']['get'](_0x473f07);}function ls(_0x3f3141){const _0x3e6ce8=_0x3f3141['indexOf']('$');return f(_0x3e6ce8!==-0x1&&_0x3e6ce8<_0x3f3141['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3f3141['substr'](_0x3e6ce8+0x1),'path':new C(_0x3f3141['substr'](0x0,_0x3e6ce8))};}function hs(_0x3a4021,_0x16de12,_0x117996){const _0x55fe67=_0x3a4021['syncPointTree_']['get'](_0x16de12);f(_0x55fe67,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3a33ac=Wn(_0x3a4021['pendingWriteTree_'],_0x16de12);return os(_0x55fe67,_0x117996,_0x3a33ac,null);}function Zu(_0x30bb52){return _0x30bb52['fold']((_0x474421,_0x258cd9,_0x11b8f4)=>{if(_0x258cd9&&Se(_0x258cd9))return[Bn(_0x258cd9)];{let _0x37f423=[];return _0x258cd9&&(_0x37f423=Ko(_0x258cd9)),x(_0x11b8f4,(_0x370567,_0xf7a74c)=>{_0x37f423=_0x37f423['concat'](_0xf7a74c);}),_0x37f423;}});}function kt(_0x23d63b){return _0x23d63b['_queryParams']['loadsAllData']()&&!_0x23d63b['_queryParams']['isDefault']()?new(qu())(_0x23d63b['_repo'],_0x23d63b['_path']):_0x23d63b;}function ed(_0x1a2dfd,_0x370abc){for(let _0x384cff=0x0;_0x384cff<_0x370abc['length'];++_0x384cff){const _0x946c65=_0x370abc[_0x384cff];if(!_0x946c65['_queryParams']['loadsAllData']()){const _0x3cff02=Hn(_0x946c65),_0x14b836=_0x1a2dfd['queryToTagMap']['get'](_0x3cff02);_0x1a2dfd['queryToTagMap']['delete'](_0x3cff02),_0x1a2dfd['tagToQueryMap']['delete'](_0x14b836);}}}function td(){return zu++;}function nd(_0x1df98a,_0x3144ce,_0x5c911d){const _0x15f519=_0x3144ce['_path'],_0x236207=Wt(_0x1df98a,_0x3144ce),_0x366d62=ea(_0x1df98a,_0x5c911d),_0x14b9ca=_0x1df98a['listenProvider_']['startListening'](kt(_0x3144ce),_0x236207,_0x366d62['hashFn'],_0x366d62['onComplete']),_0x539922=_0x1df98a['syncPointTree_']['subtree'](_0x15f519);if(_0x236207)f(!Se(_0x539922['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xe3d44a=_0x539922['fold']((_0x1351eb,_0x25eba1,_0xb6e1d0)=>{if(!v(_0x1351eb)&&_0x25eba1&&Se(_0x25eba1))return[Bn(_0x25eba1)['query']];{let _0xd9d6ea=[];return _0x25eba1&&(_0xd9d6ea=_0xd9d6ea['concat'](Ko(_0x25eba1)['map'](_0x497e9b=>_0x497e9b['query']))),x(_0xb6e1d0,(_0x53b3d4,_0x43eee1)=>{_0xd9d6ea=_0xd9d6ea['concat'](_0x43eee1);}),_0xd9d6ea;}});for(let _0x39cf73=0x0;_0x39cf73<_0xe3d44a['length'];++_0x39cf73){const _0xdca0a3=_0xe3d44a[_0x39cf73];_0x1df98a['listenProvider_']['stopListening'](kt(_0xdca0a3),Wt(_0x1df98a,_0xdca0a3));}}return _0x14b9ca;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x55e43b){this['node_']=_0x55e43b;}['getImmediateChild'](_0x53c988){const _0x34038a=this['node_']['getImmediateChild'](_0x53c988);return new us(_0x34038a);}['node'](){return this['node_'];}}class ds{constructor(_0x6cab52,_0x338fbb){this['syncTree_']=_0x6cab52,this['path_']=_0x338fbb;}['getImmediateChild'](_0x3602b8){const _0x3edb02=k(this['path_'],_0x3602b8);return new ds(this['syncTree_'],_0x3edb02);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x36f04b){return _0x36f04b=_0x36f04b||{},_0x36f04b['timestamp']=_0x36f04b['timestamp']||new Date()['getTime'](),_0x36f04b;},_r=function(_0x58c852,_0x3390e9,_0x591588){if(!_0x58c852||typeof _0x58c852!='object')return _0x58c852;if(f('.sv'in _0x58c852,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x58c852['.sv']=='string')return sd(_0x58c852['.sv'],_0x3390e9,_0x591588);if(typeof _0x58c852['.sv']=='object')return rd(_0x58c852['.sv'],_0x3390e9);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x58c852,null,0x2));},sd=function(_0x283dfa,_0x3c1d05,_0xc7cdbb){switch(_0x283dfa){case'timestamp':return _0xc7cdbb['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x283dfa);}},rd=function(_0x280401,_0x52cf46,_0x591a2e){_0x280401['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x280401,null,0x2));const _0x19ae78=_0x280401['increment'];typeof _0x19ae78!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x19ae78);const _0x3429bf=_0x52cf46['node']();if(f(_0x3429bf!==null&&typeof _0x3429bf<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3429bf['isLeafNode']())return _0x19ae78;const _0xd2af44=_0x3429bf['getValue']();return typeof _0xd2af44!='number'?_0x19ae78:_0xd2af44+_0x19ae78;},ta=function(_0x1f2092,_0x1933e5,_0x485f43,_0x31c226){return ps(_0x1933e5,new ds(_0x485f43,_0x1f2092),_0x31c226);},fs=function(_0x2a9eb5,_0x4f29ed,_0x1af2b8){return ps(_0x2a9eb5,new us(_0x4f29ed),_0x1af2b8);};function ps(_0x2a1948,_0xf6a5b7,_0x192b01){const _0x5de0f9=_0x2a1948['getPriority']()['val'](),_0x28ead9=_r(_0x5de0f9,_0xf6a5b7['getImmediateChild']('.priority'),_0x192b01);let _0x3aeaf1;if(_0x2a1948['isLeafNode']()){const _0x50fc35=_0x2a1948,_0x5dc6eb=_r(_0x50fc35['getValue'](),_0xf6a5b7,_0x192b01);return _0x5dc6eb!==_0x50fc35['getValue']()||_0x28ead9!==_0x50fc35['getPriority']()['val']()?new D(_0x5dc6eb,A(_0x28ead9)):_0x2a1948;}else{const _0x48baed=_0x2a1948;return _0x3aeaf1=_0x48baed,_0x28ead9!==_0x48baed['getPriority']()['val']()&&(_0x3aeaf1=_0x3aeaf1['updatePriority'](new D(_0x28ead9))),_0x48baed['forEachChild'](R,(_0x2919aa,_0x4d9683)=>{const _0x17c18c=ps(_0x4d9683,_0xf6a5b7['getImmediateChild'](_0x2919aa),_0x192b01);_0x17c18c!==_0x4d9683&&(_0x3aeaf1=_0x3aeaf1['updateImmediateChild'](_0x2919aa,_0x17c18c));}),_0x3aeaf1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x10b664='',_0x199e80=null,_0x3b36ef={'children':{},'childCount':0x0}){this['name']=_0x10b664,this['parent']=_0x199e80,this['node']=_0x3b36ef;}}function $n(_0x349664,_0x2a92a9){let _0x391170=_0x2a92a9 instanceof C?_0x2a92a9:new C(_0x2a92a9),_0x1aa711=_0x349664,_0x39c12f=y(_0x391170);for(;_0x39c12f!==null;){const _0x2944cc=Le(_0x1aa711['node']['children'],_0x39c12f)||{'children':{},'childCount':0x0};_0x1aa711=new _s(_0x39c12f,_0x1aa711,_0x2944cc),_0x391170=S(_0x391170),_0x39c12f=y(_0x391170);}return _0x1aa711;}function je(_0x52b8a8){return _0x52b8a8['node']['value'];}function gs(_0x1778b7,_0x2bda8e){_0x1778b7['node']['value']=_0x2bda8e,Oi(_0x1778b7);}function na(_0x3f677f){return _0x3f677f['node']['childCount']>0x0;}function od(_0x4da9d8){return je(_0x4da9d8)===void 0x0&&!na(_0x4da9d8);}function Gn(_0x2916a5,_0x30b96a){x(_0x2916a5['node']['children'],(_0x14e751,_0x12a36d)=>{_0x30b96a(new _s(_0x14e751,_0x2916a5,_0x12a36d));});}function ia(_0x4516f0,_0x510a65,_0x156400,_0x1136bb){_0x156400&&_0x510a65(_0x4516f0),Gn(_0x4516f0,_0x4b3a85=>{ia(_0x4b3a85,_0x510a65,!0x0);});}function ad(_0x44619c,_0x5358b6,_0x7f4171){let _0x10d77b=_0x44619c['parent'];for(;_0x10d77b!==null;){if(_0x5358b6(_0x10d77b))return!0x0;_0x10d77b=_0x10d77b['parent'];}return!0x1;}function Qt(_0x4d55aa){return new C(_0x4d55aa['parent']===null?_0x4d55aa['name']:Qt(_0x4d55aa['parent'])+'/'+_0x4d55aa['name']);}function Oi(_0x5ca074){_0x5ca074['parent']!==null&&cd(_0x5ca074['parent'],_0x5ca074['name'],_0x5ca074);}function cd(_0x64d452,_0x34be6c,_0x1fe02e){const _0x5f2e6d=od(_0x1fe02e),_0x33574e=Q(_0x64d452['node']['children'],_0x34be6c);_0x5f2e6d&&_0x33574e?(delete _0x64d452['node']['children'][_0x34be6c],_0x64d452['node']['childCount']--,Oi(_0x64d452)):!_0x5f2e6d&&!_0x33574e&&(_0x64d452['node']['children'][_0x34be6c]=_0x1fe02e['node'],_0x64d452['node']['childCount']++,Oi(_0x64d452));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x48fa62){return typeof _0x48fa62=='string'&&_0x48fa62['length']!==0x0&&!ld['test'](_0x48fa62);},sa=function(_0x270a37){return typeof _0x270a37=='string'&&_0x270a37['length']!==0x0&&!hd['test'](_0x270a37);},ud=function(_0x319850){return _0x319850&&(_0x319850=_0x319850['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x319850);},Bt=function(_0x4374c4){return _0x4374c4===null||typeof _0x4374c4=='string'||typeof _0x4374c4=='number'&&!xn(_0x4374c4)||_0x4374c4&&typeof _0x4374c4=='object'&&Q(_0x4374c4,'.sv');},He=function(_0x22fe4d,_0x5a85f6,_0x1ac8a0,_0xd01295){_0xd01295&&_0x5a85f6===void 0x0||Jt(it(_0x22fe4d,'value'),_0x5a85f6,_0x1ac8a0);},Jt=function(_0x35cbf1,_0x2fadf1,_0x515134){const _0x482996=_0x515134 instanceof C?new Ah(_0x515134,_0x35cbf1):_0x515134;if(_0x2fadf1===void 0x0)throw new Error(_0x35cbf1+'contains\x20undefined\x20'+Oe(_0x482996));if(typeof _0x2fadf1=='function')throw new Error(_0x35cbf1+'contains\x20a\x20function\x20'+Oe(_0x482996)+'\x20with\x20contents\x20=\x20'+_0x2fadf1['toString']());if(xn(_0x2fadf1))throw new Error(_0x35cbf1+'contains\x20'+_0x2fadf1['toString']()+'\x20'+Oe(_0x482996));if(typeof _0x2fadf1=='string'&&_0x2fadf1['length']>ui/0x3&&Ln(_0x2fadf1)>ui)throw new Error(_0x35cbf1+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x482996)+'\x20(\x27'+_0x2fadf1['substring'](0x0,0x32)+'...\x27)');if(_0x2fadf1&&typeof _0x2fadf1=='object'){let _0x317aaa=!0x1,_0x5b72cd=!0x1;if(x(_0x2fadf1,(_0x574bbd,_0x44cbeb)=>{if(_0x574bbd==='.value')_0x317aaa=!0x0;else{if(_0x574bbd!=='.priority'&&_0x574bbd!=='.sv'&&(_0x5b72cd=!0x0,!ms(_0x574bbd)))throw new Error(_0x35cbf1+'\x20contains\x20an\x20invalid\x20key\x20('+_0x574bbd+')\x20'+Oe(_0x482996)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x482996,_0x574bbd),Jt(_0x35cbf1,_0x44cbeb,_0x482996),Ph(_0x482996);}),_0x317aaa&&_0x5b72cd)throw new Error(_0x35cbf1+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x482996)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x243e79,_0x4d826c){let _0x469905,_0x25a6d1;for(_0x469905=0x0;_0x469905<_0x4d826c['length'];_0x469905++){_0x25a6d1=_0x4d826c[_0x469905];const _0x5e5a62=Mt(_0x25a6d1);for(let _0x410c51=0x0;_0x410c51<_0x5e5a62['length'];_0x410c51++)if(!(_0x5e5a62[_0x410c51]==='.priority'&&_0x410c51===_0x5e5a62['length']-0x1)){if(!ms(_0x5e5a62[_0x410c51]))throw new Error(_0x243e79+'contains\x20an\x20invalid\x20key\x20('+_0x5e5a62[_0x410c51]+')\x20in\x20path\x20'+_0x25a6d1['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4d826c['sort'](Rh);let _0x28301b=null;for(_0x469905=0x0;_0x469905<_0x4d826c['length'];_0x469905++){if(_0x25a6d1=_0x4d826c[_0x469905],_0x28301b!==null&&G(_0x28301b,_0x25a6d1))throw new Error(_0x243e79+'contains\x20a\x20path\x20'+_0x28301b['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x25a6d1['toString']());_0x28301b=_0x25a6d1;}},ra=function(_0x442e8b,_0x4240e2,_0x282261,_0x390923){const _0xf99118=it(_0x442e8b,'values');if(!(_0x4240e2&&typeof _0x4240e2=='object')||Array['isArray'](_0x4240e2))throw new Error(_0xf99118+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x10e763=[];x(_0x4240e2,(_0x2e76f5,_0x382a35)=>{const _0x5089b0=new C(_0x2e76f5);if(Jt(_0xf99118,_0x382a35,k(_0x282261,_0x5089b0)),ji(_0x5089b0)==='.priority'&&!Bt(_0x382a35))throw new Error(_0xf99118+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5089b0['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x10e763['push'](_0x5089b0);}),dd(_0xf99118,_0x10e763);},fd=function(_0x2d7275,_0x229aeb,_0x2a83e2){if(xn(_0x229aeb))throw new Error(it(_0x2d7275,'priority')+'is\x20'+_0x229aeb['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x229aeb))throw new Error(it(_0x2d7275,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x5bc5d1,_0xa7dcff,_0x30b269,_0x47b8ed){if(!sa(_0x30b269))throw new Error(it(_0x5bc5d1,_0xa7dcff)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x30b269+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x108176,_0x3a4528,_0x3c3f87,_0xebd22c){_0x3c3f87&&(_0x3c3f87=_0x3c3f87['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x108176,_0x3a4528,_0x3c3f87);},Me=function(_0x503843,_0x60800f){if(y(_0x60800f)==='.info')throw new Error(_0x503843+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x25c6d9,_0x2c1728){const _0xe7f0a3=_0x2c1728['path']['toString']();if(typeof _0x2c1728['repoInfo']['host']!='string'||_0x2c1728['repoInfo']['host']['length']===0x0||!ms(_0x2c1728['repoInfo']['namespace'])&&_0x2c1728['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xe7f0a3['length']!==0x0&&!ud(_0xe7f0a3))throw new Error(it(_0x25c6d9,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x5d9b9a,_0x362ab5){let _0x43becd=null;for(let _0x1c46b4=0x0;_0x1c46b4<_0x362ab5['length'];_0x1c46b4++){const _0x52f94b=_0x362ab5[_0x1c46b4],_0x4b74ba=_0x52f94b['getPath']();_0x43becd!==null&&!Ki(_0x4b74ba,_0x43becd['path'])&&(_0x5d9b9a['eventLists_']['push'](_0x43becd),_0x43becd=null),_0x43becd===null&&(_0x43becd={'events':[],'path':_0x4b74ba}),_0x43becd['events']['push'](_0x52f94b);}_0x43becd&&_0x5d9b9a['eventLists_']['push'](_0x43becd);}function oa(_0x2507cb,_0x3a6301,_0x357a50){qn(_0x2507cb,_0x357a50),aa(_0x2507cb,_0x2eb306=>Ki(_0x2eb306,_0x3a6301));}function V(_0x3a7fc1,_0x46f409,_0x188924){qn(_0x3a7fc1,_0x188924),aa(_0x3a7fc1,_0x40e884=>G(_0x40e884,_0x46f409)||G(_0x46f409,_0x40e884));}function aa(_0x58fca8,_0x42d991){_0x58fca8['recursionDepth_']++;let _0x566e2a=!0x0;for(let _0x2dee80=0x0;_0x2dee80<_0x58fca8['eventLists_']['length'];_0x2dee80++){const _0x40d607=_0x58fca8['eventLists_'][_0x2dee80];if(_0x40d607){const _0x5180a2=_0x40d607['path'];_0x42d991(_0x5180a2)?(md(_0x58fca8['eventLists_'][_0x2dee80]),_0x58fca8['eventLists_'][_0x2dee80]=null):_0x566e2a=!0x1;}}_0x566e2a&&(_0x58fca8['eventLists_']=[]),_0x58fca8['recursionDepth_']--;}function md(_0x3adf49){for(let _0x16e9ee=0x0;_0x16e9ee<_0x3adf49['events']['length'];_0x16e9ee++){const _0x3c60c5=_0x3adf49['events'][_0x16e9ee];if(_0x3c60c5!==null){_0x3adf49['events'][_0x16e9ee]=null;const _0x214060=_0x3c60c5['getEventRunner']();St&&L('event:\x20'+_0x3c60c5['toString']()),ft(_0x214060);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x160d92,_0x4d822b,_0xe197be,_0x102121){this['repoInfo_']=_0x160d92,this['forceRestClient_']=_0x4d822b,this['authTokenProvider_']=_0xe197be,this['appCheckProvider_']=_0x102121,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x12fc80,_0xaa5f62,_0x417b7b){if(_0x12fc80['stats_']=qi(_0x12fc80['repoInfo_']),_0x12fc80['forceRestClient_']||Xl())_0x12fc80['server_']=new vn(_0x12fc80['repoInfo_'],(_0x491fca,_0x569853,_0x32e320,_0x2b4c5f)=>{gr(_0x12fc80,_0x491fca,_0x569853,_0x32e320,_0x2b4c5f);},_0x12fc80['authTokenProvider_'],_0x12fc80['appCheckProvider_']),setTimeout(()=>mr(_0x12fc80,!0x0),0x0);else{if(typeof _0x417b7b<'u'&&_0x417b7b!==null){if(typeof _0x417b7b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x417b7b);}catch(_0x2f0cd5){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2f0cd5);}}_0x12fc80['persistentConnection_']=new se(_0x12fc80['repoInfo_'],_0xaa5f62,(_0x3bc8e1,_0x1179f6,_0x56eecc,_0x513b98)=>{gr(_0x12fc80,_0x3bc8e1,_0x1179f6,_0x56eecc,_0x513b98);},_0x36b4aa=>{mr(_0x12fc80,_0x36b4aa);},_0x28bbce=>{Id(_0x12fc80,_0x28bbce);},_0x12fc80['authTokenProvider_'],_0x12fc80['appCheckProvider_'],_0x417b7b),_0x12fc80['server_']=_0x12fc80['persistentConnection_'];}_0x12fc80['authTokenProvider_']['addTokenChangeListener'](_0xe01019=>{_0x12fc80['server_']['refreshAuthToken'](_0xe01019);}),_0x12fc80['appCheckProvider_']['addTokenChangeListener'](_0x20138e=>{_0x12fc80['server_']['refreshAppCheckToken'](_0x20138e['token']);}),_0x12fc80['statsReporter_']=ih(_0x12fc80['repoInfo_'],()=>new iu(_0x12fc80['stats_'],_0x12fc80['server_'])),_0x12fc80['infoData_']=new Xh(),_0x12fc80['infoSyncTree_']=new pr({'startListening':(_0x234eee,_0x306101,_0x1e9dfb,_0x1d75cc)=>{let _0x46b5af=[];const _0xe62d18=_0x12fc80['infoData_']['getNode'](_0x234eee['_path']);return _0xe62d18['isEmpty']()||(_0x46b5af=Yt(_0x12fc80['infoSyncTree_'],_0x234eee['_path'],_0xe62d18),setTimeout(()=>{_0x1d75cc('ok');},0x0)),_0x46b5af;},'stopListening':()=>{}}),vs(_0x12fc80,'connected',!0x1),_0x12fc80['serverSyncTree_']=new pr({'startListening':(_0x1365b0,_0x1dd31b,_0x39665d,_0x10973)=>(_0x12fc80['server_']['listen'](_0x1365b0,_0x39665d,_0x1dd31b,(_0x40e41d,_0x275e3c)=>{const _0x35b900=_0x10973(_0x40e41d,_0x275e3c);V(_0x12fc80['eventQueue_'],_0x1365b0['_path'],_0x35b900);}),[]),'stopListening':(_0x22a2da,_0x276b4e)=>{_0x12fc80['server_']['unlisten'](_0x22a2da,_0x276b4e);}});}function la(_0x4240c4){const _0x23efc9=_0x4240c4['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x23efc9;}function Xt(_0x359161){return id({'timestamp':la(_0x359161)});}function gr(_0x37f823,_0x44fe60,_0x2a6a65,_0x50a827,_0x392ca6){_0x37f823['dataUpdateCount']++;const _0x57cf58=new C(_0x44fe60);_0x2a6a65=_0x37f823['interceptServerDataCallback_']?_0x37f823['interceptServerDataCallback_'](_0x44fe60,_0x2a6a65):_0x2a6a65;let _0x37c23e=[];if(_0x392ca6){if(_0x50a827){const _0x227014=_n(_0x2a6a65,_0x109419=>A(_0x109419));_0x37c23e=Ju(_0x37f823['serverSyncTree_'],_0x57cf58,_0x227014,_0x392ca6);}else{const _0x5e170e=A(_0x2a6a65);_0x37c23e=Jo(_0x37f823['serverSyncTree_'],_0x57cf58,_0x5e170e,_0x392ca6);}}else{if(_0x50a827){const _0x136124=_n(_0x2a6a65,_0xacefd2=>A(_0xacefd2));_0x37c23e=Ku(_0x37f823['serverSyncTree_'],_0x57cf58,_0x136124);}else{const _0x438671=A(_0x2a6a65);_0x37c23e=Yt(_0x37f823['serverSyncTree_'],_0x57cf58,_0x438671);}}let _0x4344c8=_0x57cf58;_0x37c23e['length']>0x0&&(_0x4344c8=ct(_0x37f823,_0x57cf58)),V(_0x37f823['eventQueue_'],_0x4344c8,_0x37c23e);}function mr(_0x30bf41,_0x104649){vs(_0x30bf41,'connected',_0x104649),_0x104649===!0x1&&Sd(_0x30bf41);}function Id(_0x3c09ca,_0x5b5a28){x(_0x5b5a28,(_0x2e46c5,_0x322931)=>{vs(_0x3c09ca,_0x2e46c5,_0x322931);});}function vs(_0x813977,_0x2b3c6b,_0x1188bb){const _0xff5cc=new C('/.info/'+_0x2b3c6b),_0x38bfe2=A(_0x1188bb);_0x813977['infoData_']['updateSnapshot'](_0xff5cc,_0x38bfe2);const _0x36efb4=Yt(_0x813977['infoSyncTree_'],_0xff5cc,_0x38bfe2);V(_0x813977['eventQueue_'],_0xff5cc,_0x36efb4);}function zn(_0x1b5723){return _0x1b5723['nextWriteId_']++;}function wd(_0x1fa012,_0x177d74,_0x34bc42){const _0x5e98f4=Xu(_0x1fa012['serverSyncTree_'],_0x177d74);return _0x5e98f4!=null?Promise['resolve'](_0x5e98f4):_0x1fa012['server_']['get'](_0x177d74)['then'](_0x4dd442=>{const _0x1ed04e=A(_0x4dd442)['withIndex'](_0x177d74['_queryParams']['getIndex']());Ni(_0x1fa012['serverSyncTree_'],_0x177d74,_0x34bc42,!0x0);let _0x31b4d2;if(_0x177d74['_queryParams']['loadsAllData']())_0x31b4d2=Yt(_0x1fa012['serverSyncTree_'],_0x177d74['_path'],_0x1ed04e);else{const _0x45cd1f=Wt(_0x1fa012['serverSyncTree_'],_0x177d74);_0x31b4d2=Jo(_0x1fa012['serverSyncTree_'],_0x177d74['_path'],_0x1ed04e,_0x45cd1f);}return V(_0x1fa012['eventQueue_'],_0x177d74['_path'],_0x31b4d2),An(_0x1fa012['serverSyncTree_'],_0x177d74,_0x34bc42,null,!0x0),_0x1ed04e;},_0xeda69f=>(gt(_0x1fa012,'get\x20for\x20query\x20'+O(_0x177d74)+'\x20failed:\x20'+_0xeda69f),Promise['reject'](new Error(_0xeda69f))));}function Cd(_0x38b850,_0x19dcc8,_0x381e09,_0x143d44,_0x2b45d8){gt(_0x38b850,'set',{'path':_0x19dcc8['toString'](),'value':_0x381e09,'priority':_0x143d44});const _0x233fdb=Xt(_0x38b850),_0xf54937=A(_0x381e09,_0x143d44),_0x2869c7=Vn(_0x38b850['serverSyncTree_'],_0x19dcc8),_0x883082=fs(_0xf54937,_0x2869c7,_0x233fdb),_0x529506=zn(_0x38b850),_0x26000c=as(_0x38b850['serverSyncTree_'],_0x19dcc8,_0x883082,_0x529506,!0x0);qn(_0x38b850['eventQueue_'],_0x26000c),_0x38b850['server_']['put'](_0x19dcc8['toString'](),_0xf54937['val'](!0x0),(_0x187226,_0x1f0928)=>{const _0x1222a5=_0x187226==='ok';_0x1222a5||U('set\x20at\x20'+_0x19dcc8+'\x20failed:\x20'+_0x187226);const _0x2589c9=_e(_0x38b850['serverSyncTree_'],_0x529506,!_0x1222a5);V(_0x38b850['eventQueue_'],_0x19dcc8,_0x2589c9),be(_0x38b850,_0x2b45d8,_0x187226,_0x1f0928);});const _0x34f79f=Is(_0x38b850,_0x19dcc8);ct(_0x38b850,_0x34f79f),V(_0x38b850['eventQueue_'],_0x34f79f,[]);}function Td(_0x54ffe2,_0x1fab79,_0x52fd58,_0x4a0b5d){gt(_0x54ffe2,'update',{'path':_0x1fab79['toString'](),'value':_0x52fd58});let _0x26a25c=!0x0;const _0x43aff=Xt(_0x54ffe2),_0x49be5c={};if(x(_0x52fd58,(_0x16fb26,_0xc7d8bf)=>{_0x26a25c=!0x1,_0x49be5c[_0x16fb26]=ta(k(_0x1fab79,_0x16fb26),A(_0xc7d8bf),_0x54ffe2['serverSyncTree_'],_0x43aff);}),_0x26a25c)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x54ffe2,_0x4a0b5d,'ok',void 0x0);else{const _0x6fb396=zn(_0x54ffe2),_0xadd66b=ju(_0x54ffe2['serverSyncTree_'],_0x1fab79,_0x49be5c,_0x6fb396);qn(_0x54ffe2['eventQueue_'],_0xadd66b),_0x54ffe2['server_']['merge'](_0x1fab79['toString'](),_0x52fd58,(_0x347276,_0x517b74)=>{const _0x19ac37=_0x347276==='ok';_0x19ac37||U('update\x20at\x20'+_0x1fab79+'\x20failed:\x20'+_0x347276);const _0xc33843=_e(_0x54ffe2['serverSyncTree_'],_0x6fb396,!_0x19ac37),_0xfd03ea=_0xc33843['length']>0x0?ct(_0x54ffe2,_0x1fab79):_0x1fab79;V(_0x54ffe2['eventQueue_'],_0xfd03ea,_0xc33843),be(_0x54ffe2,_0x4a0b5d,_0x347276,_0x517b74);}),x(_0x52fd58,_0x119af9=>{const _0x40d6f1=Is(_0x54ffe2,k(_0x1fab79,_0x119af9));ct(_0x54ffe2,_0x40d6f1);}),V(_0x54ffe2['eventQueue_'],_0x1fab79,[]);}}function Sd(_0x36d1e9){gt(_0x36d1e9,'onDisconnectEvents');const _0x55f1ef=Xt(_0x36d1e9),_0x405441=En();Si(_0x36d1e9['onDisconnect_'],w(),(_0xe16553,_0x2d0f7c)=>{const _0xa18b7f=ta(_0xe16553,_0x2d0f7c,_0x36d1e9['serverSyncTree_'],_0x55f1ef);pt(_0x405441,_0xe16553,_0xa18b7f);});let _0x1d875f=[];Si(_0x405441,w(),(_0x744681,_0x59ec5b)=>{_0x1d875f=_0x1d875f['concat'](Yt(_0x36d1e9['serverSyncTree_'],_0x744681,_0x59ec5b));const _0x559d4c=Is(_0x36d1e9,_0x744681);ct(_0x36d1e9,_0x559d4c);}),_0x36d1e9['onDisconnect_']=En(),V(_0x36d1e9['eventQueue_'],w(),_0x1d875f);}function bd(_0x294a8a,_0x1bb2cb,_0x2ee950){_0x294a8a['server_']['onDisconnectCancel'](_0x1bb2cb['toString'](),(_0x3cb170,_0x2c7450)=>{_0x3cb170==='ok'&&Ti(_0x294a8a['onDisconnect_'],_0x1bb2cb),be(_0x294a8a,_0x2ee950,_0x3cb170,_0x2c7450);});}function yr(_0x3b6f11,_0x194eed,_0x6b7b9f,_0x1a1f38){const _0x33f11f=A(_0x6b7b9f);_0x3b6f11['server_']['onDisconnectPut'](_0x194eed['toString'](),_0x33f11f['val'](!0x0),(_0x3be49c,_0x4efb69)=>{_0x3be49c==='ok'&&pt(_0x3b6f11['onDisconnect_'],_0x194eed,_0x33f11f),be(_0x3b6f11,_0x1a1f38,_0x3be49c,_0x4efb69);});}function Rd(_0x160240,_0x51eda9,_0x42c696,_0x542f70,_0x45dbda){const _0x31fd19=A(_0x42c696,_0x542f70);_0x160240['server_']['onDisconnectPut'](_0x51eda9['toString'](),_0x31fd19['val'](!0x0),(_0x2d47f0,_0x257b2f)=>{_0x2d47f0==='ok'&&pt(_0x160240['onDisconnect_'],_0x51eda9,_0x31fd19),be(_0x160240,_0x45dbda,_0x2d47f0,_0x257b2f);});}function Ad(_0x4e5af4,_0x3b2fda,_0x9a1c0f,_0x4795ca){if(pn(_0x9a1c0f)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4e5af4,_0x4795ca,'ok',void 0x0);return;}_0x4e5af4['server_']['onDisconnectMerge'](_0x3b2fda['toString'](),_0x9a1c0f,(_0x12c0c0,_0x133f0d)=>{_0x12c0c0==='ok'&&x(_0x9a1c0f,(_0x3231c9,_0x3bbf2c)=>{const _0x254996=A(_0x3bbf2c);pt(_0x4e5af4['onDisconnect_'],k(_0x3b2fda,_0x3231c9),_0x254996);}),be(_0x4e5af4,_0x4795ca,_0x12c0c0,_0x133f0d);});}function kd(_0x1289c6,_0x1ce5e2,_0x2b3835){let _0x38bccd;y(_0x1ce5e2['_path'])==='.info'?_0x38bccd=Ni(_0x1289c6['infoSyncTree_'],_0x1ce5e2,_0x2b3835):_0x38bccd=Ni(_0x1289c6['serverSyncTree_'],_0x1ce5e2,_0x2b3835),oa(_0x1289c6['eventQueue_'],_0x1ce5e2['_path'],_0x38bccd);}function Pd(_0x193a28,_0x706857,_0x5af4fc){let _0x112e1d;y(_0x706857['_path'])==='.info'?_0x112e1d=An(_0x193a28['infoSyncTree_'],_0x706857,_0x5af4fc):_0x112e1d=An(_0x193a28['serverSyncTree_'],_0x706857,_0x5af4fc),oa(_0x193a28['eventQueue_'],_0x706857['_path'],_0x112e1d);}function ha(_0x3e3d2b){_0x3e3d2b['persistentConnection_']&&_0x3e3d2b['persistentConnection_']['interrupt'](ca);}function Nd(_0xabc776){_0xabc776['persistentConnection_']&&_0xabc776['persistentConnection_']['resume'](ca);}function gt(_0x1eef79,..._0xda598b){let _0x4ce59e='';_0x1eef79['persistentConnection_']&&(_0x4ce59e=_0x1eef79['persistentConnection_']['id']+':'),L(_0x4ce59e,..._0xda598b);}function be(_0x53e8f4,_0x4a7977,_0x545713,_0x55ca96){_0x4a7977&&ft(()=>{if(_0x545713==='ok')_0x4a7977(null);else{const _0x3bac76=(_0x545713||'error')['toUpperCase']();let _0x216199=_0x3bac76;_0x55ca96&&(_0x216199+=':\x20'+_0x55ca96);const _0x1ff9ea=new Error(_0x216199);_0x1ff9ea['code']=_0x3bac76,_0x4a7977(_0x1ff9ea);}});}function Od(_0x1b2cb9,_0x47b6d1,_0x177e84,_0x19fc53,_0x4f08b9,_0x40a69c){gt(_0x1b2cb9,'transaction\x20on\x20'+_0x47b6d1);const _0x44c4ef={'path':_0x47b6d1,'update':_0x177e84,'onComplete':_0x19fc53,'status':null,'order':so(),'applyLocally':_0x40a69c,'retryCount':0x0,'unwatcher':_0x4f08b9,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x326239=Es(_0x1b2cb9,_0x47b6d1,void 0x0);_0x44c4ef['currentInputSnapshot']=_0x326239;const _0x53c429=_0x44c4ef['update'](_0x326239['val']());if(_0x53c429===void 0x0)_0x44c4ef['unwatcher'](),_0x44c4ef['currentOutputSnapshotRaw']=null,_0x44c4ef['currentOutputSnapshotResolved']=null,_0x44c4ef['onComplete']&&_0x44c4ef['onComplete'](null,!0x1,_0x44c4ef['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x53c429,_0x44c4ef['path']),_0x44c4ef['status']=0x0;const _0x2f31e9=$n(_0x1b2cb9['transactionQueueTree_'],_0x47b6d1),_0x59dcb2=je(_0x2f31e9)||[];_0x59dcb2['push'](_0x44c4ef),gs(_0x2f31e9,_0x59dcb2);let _0x1495cd;typeof _0x53c429=='object'&&_0x53c429!==null&&Q(_0x53c429,'.priority')?(_0x1495cd=Le(_0x53c429,'.priority'),f(Bt(_0x1495cd),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1495cd=(Vn(_0x1b2cb9['serverSyncTree_'],_0x47b6d1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x393121=Xt(_0x1b2cb9),_0x393fcf=A(_0x53c429,_0x1495cd),_0x334f5e=fs(_0x393fcf,_0x326239,_0x393121);_0x44c4ef['currentOutputSnapshotRaw']=_0x393fcf,_0x44c4ef['currentOutputSnapshotResolved']=_0x334f5e,_0x44c4ef['currentWriteId']=zn(_0x1b2cb9);const _0x32a822=as(_0x1b2cb9['serverSyncTree_'],_0x47b6d1,_0x334f5e,_0x44c4ef['currentWriteId'],_0x44c4ef['applyLocally']);V(_0x1b2cb9['eventQueue_'],_0x47b6d1,_0x32a822),jn(_0x1b2cb9,_0x1b2cb9['transactionQueueTree_']);}}function Es(_0x36e537,_0x1cf668,_0x1c1672){return Vn(_0x36e537['serverSyncTree_'],_0x1cf668,_0x1c1672)||g['EMPTY_NODE'];}function jn(_0x4a8eef,_0x5b2c5b=_0x4a8eef['transactionQueueTree_']){if(_0x5b2c5b||Kn(_0x4a8eef,_0x5b2c5b),je(_0x5b2c5b)){const _0x292a02=da(_0x4a8eef,_0x5b2c5b);f(_0x292a02['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x292a02['every'](_0x3a0909=>_0x3a0909['status']===0x0)&&Dd(_0x4a8eef,Qt(_0x5b2c5b),_0x292a02);}else na(_0x5b2c5b)&&Gn(_0x5b2c5b,_0x33896c=>{jn(_0x4a8eef,_0x33896c);});}function Dd(_0x31991d,_0x35f7b1,_0x34d328){const _0x3802d0=_0x34d328['map'](_0x1b952b=>_0x1b952b['currentWriteId']),_0x25e1d8=Es(_0x31991d,_0x35f7b1,_0x3802d0);let _0x4c7a1a=_0x25e1d8;const _0x11df79=_0x25e1d8['hash']();for(let _0x42ab5c=0x0;_0x42ab5c<_0x34d328['length'];_0x42ab5c++){const _0x4d4d05=_0x34d328[_0x42ab5c];f(_0x4d4d05['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4d4d05['status']=0x1,_0x4d4d05['retryCount']++;const _0xc20c08=F(_0x35f7b1,_0x4d4d05['path']);_0x4c7a1a=_0x4c7a1a['updateChild'](_0xc20c08,_0x4d4d05['currentOutputSnapshotRaw']);}const _0x255300=_0x4c7a1a['val'](!0x0),_0x5aed32=_0x35f7b1;_0x31991d['server_']['put'](_0x5aed32['toString'](),_0x255300,_0x1d0a77=>{gt(_0x31991d,'transaction\x20put\x20response',{'path':_0x5aed32['toString'](),'status':_0x1d0a77});let _0x1d51d5=[];if(_0x1d0a77==='ok'){const _0x55fce7=[];for(let _0x802abf=0x0;_0x802abf<_0x34d328['length'];_0x802abf++)_0x34d328[_0x802abf]['status']=0x2,_0x1d51d5=_0x1d51d5['concat'](_e(_0x31991d['serverSyncTree_'],_0x34d328[_0x802abf]['currentWriteId'])),_0x34d328[_0x802abf]['onComplete']&&_0x55fce7['push'](()=>_0x34d328[_0x802abf]['onComplete'](null,!0x0,_0x34d328[_0x802abf]['currentOutputSnapshotResolved'])),_0x34d328[_0x802abf]['unwatcher']();Kn(_0x31991d,$n(_0x31991d['transactionQueueTree_'],_0x35f7b1)),jn(_0x31991d,_0x31991d['transactionQueueTree_']),V(_0x31991d['eventQueue_'],_0x35f7b1,_0x1d51d5);for(let _0x4bd025=0x0;_0x4bd025<_0x55fce7['length'];_0x4bd025++)ft(_0x55fce7[_0x4bd025]);}else{if(_0x1d0a77==='datastale'){for(let _0x2b60a0=0x0;_0x2b60a0<_0x34d328['length'];_0x2b60a0++)_0x34d328[_0x2b60a0]['status']===0x3?_0x34d328[_0x2b60a0]['status']=0x4:_0x34d328[_0x2b60a0]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5aed32['toString']()+'\x20failed:\x20'+_0x1d0a77);for(let _0x3f5973=0x0;_0x3f5973<_0x34d328['length'];_0x3f5973++)_0x34d328[_0x3f5973]['status']=0x4,_0x34d328[_0x3f5973]['abortReason']=_0x1d0a77;}ct(_0x31991d,_0x35f7b1);}},_0x11df79);}function ct(_0x25d019,_0x24a0ce){const _0x3af7de=ua(_0x25d019,_0x24a0ce),_0xb481bf=Qt(_0x3af7de),_0x336f65=da(_0x25d019,_0x3af7de);return Md(_0x25d019,_0x336f65,_0xb481bf),_0xb481bf;}function Md(_0x144f73,_0x119f67,_0x48072a){if(_0x119f67['length']===0x0)return;const _0x6712bc=[];let _0x2e79c7=[];const _0x15ee38=_0x119f67['filter'](_0x15952e=>_0x15952e['status']===0x0)['map'](_0x74dd31=>_0x74dd31['currentWriteId']);for(let _0x50e3d3=0x0;_0x50e3d3<_0x119f67['length'];_0x50e3d3++){const _0x205afa=_0x119f67[_0x50e3d3],_0x44825d=F(_0x48072a,_0x205afa['path']);let _0x4b6f76=!0x1,_0x4b6002;if(f(_0x44825d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x205afa['status']===0x4)_0x4b6f76=!0x0,_0x4b6002=_0x205afa['abortReason'],_0x2e79c7=_0x2e79c7['concat'](_e(_0x144f73['serverSyncTree_'],_0x205afa['currentWriteId'],!0x0));else{if(_0x205afa['status']===0x0){if(_0x205afa['retryCount']>=yd)_0x4b6f76=!0x0,_0x4b6002='maxretry',_0x2e79c7=_0x2e79c7['concat'](_e(_0x144f73['serverSyncTree_'],_0x205afa['currentWriteId'],!0x0));else{const _0x3916fe=Es(_0x144f73,_0x205afa['path'],_0x15ee38);_0x205afa['currentInputSnapshot']=_0x3916fe;const _0x141598=_0x119f67[_0x50e3d3]['update'](_0x3916fe['val']());if(_0x141598!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x141598,_0x205afa['path']);let _0x2d8d68=A(_0x141598);typeof _0x141598=='object'&&_0x141598!=null&&Q(_0x141598,'.priority')||(_0x2d8d68=_0x2d8d68['updatePriority'](_0x3916fe['getPriority']()));const _0x136868=_0x205afa['currentWriteId'],_0x28f91e=Xt(_0x144f73),_0x1d175a=fs(_0x2d8d68,_0x3916fe,_0x28f91e);_0x205afa['currentOutputSnapshotRaw']=_0x2d8d68,_0x205afa['currentOutputSnapshotResolved']=_0x1d175a,_0x205afa['currentWriteId']=zn(_0x144f73),_0x15ee38['splice'](_0x15ee38['indexOf'](_0x136868),0x1),_0x2e79c7=_0x2e79c7['concat'](as(_0x144f73['serverSyncTree_'],_0x205afa['path'],_0x1d175a,_0x205afa['currentWriteId'],_0x205afa['applyLocally'])),_0x2e79c7=_0x2e79c7['concat'](_e(_0x144f73['serverSyncTree_'],_0x136868,!0x0));}else _0x4b6f76=!0x0,_0x4b6002='nodata',_0x2e79c7=_0x2e79c7['concat'](_e(_0x144f73['serverSyncTree_'],_0x205afa['currentWriteId'],!0x0));}}}V(_0x144f73['eventQueue_'],_0x48072a,_0x2e79c7),_0x2e79c7=[],_0x4b6f76&&(_0x119f67[_0x50e3d3]['status']=0x2,function(_0x46b5fc){setTimeout(_0x46b5fc,Math['floor'](0x0));}(_0x119f67[_0x50e3d3]['unwatcher']),_0x119f67[_0x50e3d3]['onComplete']&&(_0x4b6002==='nodata'?_0x6712bc['push'](()=>_0x119f67[_0x50e3d3]['onComplete'](null,!0x1,_0x119f67[_0x50e3d3]['currentInputSnapshot'])):_0x6712bc['push'](()=>_0x119f67[_0x50e3d3]['onComplete'](new Error(_0x4b6002),!0x1,null))));}Kn(_0x144f73,_0x144f73['transactionQueueTree_']);for(let _0x1574f8=0x0;_0x1574f8<_0x6712bc['length'];_0x1574f8++)ft(_0x6712bc[_0x1574f8]);jn(_0x144f73,_0x144f73['transactionQueueTree_']);}function ua(_0x23d413,_0xebb2bc){let _0x4120bb,_0x24cf01=_0x23d413['transactionQueueTree_'];for(_0x4120bb=y(_0xebb2bc);_0x4120bb!==null&&je(_0x24cf01)===void 0x0;)_0x24cf01=$n(_0x24cf01,_0x4120bb),_0xebb2bc=S(_0xebb2bc),_0x4120bb=y(_0xebb2bc);return _0x24cf01;}function da(_0xcc75c3,_0x1bb80b){const _0x4dd081=[];return fa(_0xcc75c3,_0x1bb80b,_0x4dd081),_0x4dd081['sort']((_0xc78b31,_0x3ebe1c)=>_0xc78b31['order']-_0x3ebe1c['order']),_0x4dd081;}function fa(_0x341ae2,_0x4d72fe,_0x22cc6d){const _0x42658c=je(_0x4d72fe);if(_0x42658c){for(let _0x1e6447=0x0;_0x1e6447<_0x42658c['length'];_0x1e6447++)_0x22cc6d['push'](_0x42658c[_0x1e6447]);}Gn(_0x4d72fe,_0xd4b001=>{fa(_0x341ae2,_0xd4b001,_0x22cc6d);});}function Kn(_0x3ee54b,_0x4ffdbe){const _0x7c8c8c=je(_0x4ffdbe);if(_0x7c8c8c){let _0x14aaa4=0x0;for(let _0x283137=0x0;_0x283137<_0x7c8c8c['length'];_0x283137++)_0x7c8c8c[_0x283137]['status']!==0x2&&(_0x7c8c8c[_0x14aaa4]=_0x7c8c8c[_0x283137],_0x14aaa4++);_0x7c8c8c['length']=_0x14aaa4,gs(_0x4ffdbe,_0x7c8c8c['length']>0x0?_0x7c8c8c:void 0x0);}Gn(_0x4ffdbe,_0xcb89a3=>{Kn(_0x3ee54b,_0xcb89a3);});}function Is(_0xef1a5d,_0x373ee7){const _0x43297a=Qt(ua(_0xef1a5d,_0x373ee7)),_0x27d01b=$n(_0xef1a5d['transactionQueueTree_'],_0x373ee7);return ad(_0x27d01b,_0x43ed33=>{di(_0xef1a5d,_0x43ed33);}),di(_0xef1a5d,_0x27d01b),ia(_0x27d01b,_0xfe7839=>{di(_0xef1a5d,_0xfe7839);}),_0x43297a;}function di(_0x465478,_0x2de215){const _0x551758=je(_0x2de215);if(_0x551758){const _0x375fce=[];let _0x195023=[],_0x537109=-0x1;for(let _0x2c6c85=0x0;_0x2c6c85<_0x551758['length'];_0x2c6c85++)_0x551758[_0x2c6c85]['status']===0x3||(_0x551758[_0x2c6c85]['status']===0x1?(f(_0x537109===_0x2c6c85-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x537109=_0x2c6c85,_0x551758[_0x2c6c85]['status']=0x3,_0x551758[_0x2c6c85]['abortReason']='set'):(f(_0x551758[_0x2c6c85]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x551758[_0x2c6c85]['unwatcher'](),_0x195023=_0x195023['concat'](_e(_0x465478['serverSyncTree_'],_0x551758[_0x2c6c85]['currentWriteId'],!0x0)),_0x551758[_0x2c6c85]['onComplete']&&_0x375fce['push'](_0x551758[_0x2c6c85]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x537109===-0x1?gs(_0x2de215,void 0x0):_0x551758['length']=_0x537109+0x1,V(_0x465478['eventQueue_'],Qt(_0x2de215),_0x195023);for(let _0x38a111=0x0;_0x38a111<_0x375fce['length'];_0x38a111++)ft(_0x375fce[_0x38a111]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x571787){let _0x121dfc='';const _0x23cd5d=_0x571787['split']('/');for(let _0x1c3dcb=0x0;_0x1c3dcb<_0x23cd5d['length'];_0x1c3dcb++)if(_0x23cd5d[_0x1c3dcb]['length']>0x0){let _0x2bd79b=_0x23cd5d[_0x1c3dcb];try{_0x2bd79b=decodeURIComponent(_0x2bd79b['replace'](/\+/g,'\x20'));}catch{}_0x121dfc+='/'+_0x2bd79b;}return _0x121dfc;}function xd(_0x2ebe96){const _0x49ea49={};_0x2ebe96['charAt'](0x0)==='?'&&(_0x2ebe96=_0x2ebe96['substring'](0x1));for(const _0x3b4473 of _0x2ebe96['split']('&')){if(_0x3b4473['length']===0x0)continue;const _0x2b8e0=_0x3b4473['split']('=');_0x2b8e0['length']===0x2?_0x49ea49[decodeURIComponent(_0x2b8e0[0x0])]=decodeURIComponent(_0x2b8e0[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3b4473+'\x27\x20in\x20query\x20\x27'+_0x2ebe96+'\x27');}return _0x49ea49;}const vr=function(_0x696e81,_0x334a18){const _0x20956c=Fd(_0x696e81),_0x488b22=_0x20956c['namespace'];_0x20956c['domain']==='firebase.com'&&ae(_0x20956c['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x488b22||_0x488b22==='undefined')&&_0x20956c['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x20956c['secure']||$l();const _0xc5731b=_0x20956c['scheme']==='ws'||_0x20956c['scheme']==='wss';return{'repoInfo':new yo(_0x20956c['host'],_0x20956c['secure'],_0x488b22,_0xc5731b,_0x334a18,'',_0x488b22!==_0x20956c['subdomain']),'path':new C(_0x20956c['pathString'])};},Fd=function(_0x150d94){let _0xe6030b='',_0x49c541='',_0x43a33f='',_0x2a29fe='',_0x23e92f='',_0x10b10c=!0x0,_0x5a9f20='https',_0xc1b45f=0x1bb;if(typeof _0x150d94=='string'){let _0x58d812=_0x150d94['indexOf']('//');_0x58d812>=0x0&&(_0x5a9f20=_0x150d94['substring'](0x0,_0x58d812-0x1),_0x150d94=_0x150d94['substring'](_0x58d812+0x2));let _0x83c0bd=_0x150d94['indexOf']('/');_0x83c0bd===-0x1&&(_0x83c0bd=_0x150d94['length']);let _0x3a84a5=_0x150d94['indexOf']('?');_0x3a84a5===-0x1&&(_0x3a84a5=_0x150d94['length']),_0xe6030b=_0x150d94['substring'](0x0,Math['min'](_0x83c0bd,_0x3a84a5)),_0x83c0bd<_0x3a84a5&&(_0x2a29fe=Ld(_0x150d94['substring'](_0x83c0bd,_0x3a84a5)));const _0x442743=xd(_0x150d94['substring'](Math['min'](_0x150d94['length'],_0x3a84a5)));_0x58d812=_0xe6030b['indexOf'](':'),_0x58d812>=0x0?(_0x10b10c=_0x5a9f20==='https'||_0x5a9f20==='wss',_0xc1b45f=parseInt(_0xe6030b['substring'](_0x58d812+0x1),0xa)):_0x58d812=_0xe6030b['length'];const _0x235691=_0xe6030b['slice'](0x0,_0x58d812);if(_0x235691['toLowerCase']()==='localhost')_0x49c541='localhost';else{if(_0x235691['split']('.')['length']<=0x2)_0x49c541=_0x235691;else{const _0x4e14f3=_0xe6030b['indexOf']('.');_0x43a33f=_0xe6030b['substring'](0x0,_0x4e14f3)['toLowerCase'](),_0x49c541=_0xe6030b['substring'](_0x4e14f3+0x1),_0x23e92f=_0x43a33f;}}'ns'in _0x442743&&(_0x23e92f=_0x442743['ns']);}return{'host':_0xe6030b,'port':_0xc1b45f,'domain':_0x49c541,'subdomain':_0x43a33f,'secure':_0x10b10c,'scheme':_0x5a9f20,'pathString':_0x2a29fe,'namespace':_0x23e92f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x25e853=0x0;const _0x4e7148=[];return function(_0x461c12){const _0x545166=_0x461c12===_0x25e853;_0x25e853=_0x461c12;let _0x3fecf0;const _0x504cbc=new Array(0x8);for(_0x3fecf0=0x7;_0x3fecf0>=0x0;_0x3fecf0--)_0x504cbc[_0x3fecf0]=Er['charAt'](_0x461c12%0x40),_0x461c12=Math['floor'](_0x461c12/0x40);f(_0x461c12===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2301a4=_0x504cbc['join']('');if(_0x545166){for(_0x3fecf0=0xb;_0x3fecf0>=0x0&&_0x4e7148[_0x3fecf0]===0x3f;_0x3fecf0--)_0x4e7148[_0x3fecf0]=0x0;_0x4e7148[_0x3fecf0]++;}else{for(_0x3fecf0=0x0;_0x3fecf0<0xc;_0x3fecf0++)_0x4e7148[_0x3fecf0]=Math['floor'](Math['random']()*0x40);}for(_0x3fecf0=0x0;_0x3fecf0<0xc;_0x3fecf0++)_0x2301a4+=Er['charAt'](_0x4e7148[_0x3fecf0]);return f(_0x2301a4['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2301a4;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x2145d8,_0x57af89,_0x3f27cd,_0x36d4c3){this['eventType']=_0x2145d8,this['eventRegistration']=_0x57af89,this['snapshot']=_0x3f27cd,this['prevName']=_0x36d4c3;}['getPath'](){const _0x4ad3ac=this['snapshot']['ref'];return this['eventType']==='value'?_0x4ad3ac['_path']:_0x4ad3ac['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x5975d5,_0x53878f,_0x247677){this['eventRegistration']=_0x5975d5,this['error']=_0x53878f,this['path']=_0x247677;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x29b8ef,_0x1d3a78){this['snapshotCallback']=_0x29b8ef,this['cancelCallback']=_0x1d3a78;}['onValue'](_0xb13531,_0x3470cf){this['snapshotCallback']['call'](null,_0xb13531,_0x3470cf);}['onCancel'](_0x3555a3){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3555a3);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1ceec0){return this['snapshotCallback']===_0x1ceec0['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1ceec0['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1ceec0['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x4791ab,_0x1b1825){this['_repo']=_0x4791ab,this['_path']=_0x1b1825;}['cancel'](){const _0x2e2958=new H();return bd(this['_repo'],this['_path'],_0x2e2958['wrapCallback'](()=>{})),_0x2e2958['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x25767b=new H();return yr(this['_repo'],this['_path'],null,_0x25767b['wrapCallback'](()=>{})),_0x25767b['promise'];}['set'](_0xd31664){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0xd31664,this['_path'],!0x1);const _0x245beb=new H();return yr(this['_repo'],this['_path'],_0xd31664,_0x245beb['wrapCallback'](()=>{})),_0x245beb['promise'];}['setWithPriority'](_0x515ade,_0x596d5a){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x515ade,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x596d5a);const _0x1c63f7=new H();return Rd(this['_repo'],this['_path'],_0x515ade,_0x596d5a,_0x1c63f7['wrapCallback'](()=>{})),_0x1c63f7['promise'];}['update'](_0x2ae5be){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x2ae5be,this['_path']);const _0x4ce30b=new H();return Ad(this['_repo'],this['_path'],_0x2ae5be,_0x4ce30b['wrapCallback'](()=>{})),_0x4ce30b['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4b8917,_0x3e4369,_0xb508d2,_0x359687){this['_repo']=_0x4b8917,this['_path']=_0x3e4369,this['_queryParams']=_0xb508d2,this['_orderByCalled']=_0x359687;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x58a55a=sr(this['_queryParams']),_0x5d6cf4=$i(_0x58a55a);return _0x5d6cf4==='{}'?'default':_0x5d6cf4;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xb1c154){if(_0xb1c154=P(_0xb1c154),!(_0xb1c154 instanceof Ae))return!0x1;const _0x5ef46c=this['_repo']===_0xb1c154['_repo'],_0x5c1eff=Ki(this['_path'],_0xb1c154['_path']),_0x1dd14d=this['_queryIdentifier']===_0xb1c154['_queryIdentifier'];return _0x5ef46c&&_0x5c1eff&&_0x1dd14d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x36d805,_0x37d20c){if(_0x36d805['_orderByCalled']===!0x0)throw new Error(_0x37d20c+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x3b6291){let _0x420247=null,_0x2a7220=null;if(_0x3b6291['hasStart']()&&(_0x420247=_0x3b6291['getIndexStartValue']()),_0x3b6291['hasEnd']()&&(_0x2a7220=_0x3b6291['getIndexEndValue']()),_0x3b6291['getIndex']()===ve){const _0x51adff='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x7f328d='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3b6291['hasStart']()){if(_0x3b6291['getIndexStartName']()!==We)throw new Error(_0x51adff);if(typeof _0x420247!='string')throw new Error(_0x7f328d);}if(_0x3b6291['hasEnd']()){if(_0x3b6291['getIndexEndName']()!==we)throw new Error(_0x51adff);if(typeof _0x2a7220!='string')throw new Error(_0x7f328d);}}else{if(_0x3b6291['getIndex']()===R){if(_0x420247!=null&&!Bt(_0x420247)||_0x2a7220!=null&&!Bt(_0x2a7220))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3b6291['getIndex']()instanceof Ji||_0x3b6291['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x420247!=null&&typeof _0x420247=='object'||_0x2a7220!=null&&typeof _0x2a7220=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x103c77){if(_0x103c77['hasStart']()&&_0x103c77['hasEnd']()&&_0x103c77['hasLimit']()&&!_0x103c77['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5ad4e9,_0x42c893){super(_0x5ad4e9,_0x42c893,new Zi(),!0x1);}get['parent'](){const _0x46d48c=Ro(this['_path']);return _0x46d48c===null?null:new ee(this['_repo'],_0x46d48c);}get['root'](){let _0x21097c=this;for(;_0x21097c['parent']!==null;)_0x21097c=_0x21097c['parent'];return _0x21097c;}}class lt{constructor(_0xa52ea9,_0x14a34e,_0x3c9195){this['_node']=_0xa52ea9,this['ref']=_0x14a34e,this['_index']=_0x3c9195;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x47cfd7){const _0x1d98db=new C(_0x47cfd7),_0x1a897c=Vt(this['ref'],_0x47cfd7);return new lt(this['_node']['getChild'](_0x1d98db),_0x1a897c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x574734){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x452463,_0x102f4f)=>_0x574734(new lt(_0x102f4f,Vt(this['ref'],_0x452463),R)));}['hasChild'](_0x49e7a1){const _0x1eb91d=new C(_0x49e7a1);return!this['_node']['getChild'](_0x1eb91d)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x2419ec,_0x295eb1){return _0x2419ec=P(_0x2419ec),_0x2419ec['_checkNotDeleted']('ref'),_0x295eb1!==void 0x0?Vt(_0x2419ec['_root'],_0x295eb1):_0x2419ec['_root'];}function Vt(_0x4c4e99,_0x4af1fa){return _0x4c4e99=P(_0x4c4e99),y(_0x4c4e99['_path'])===null?pd('child','path',_0x4af1fa):ys('child','path',_0x4af1fa),new ee(_0x4c4e99['_repo'],k(_0x4c4e99['_path'],_0x4af1fa));}function v_(_0x2991b0){return _0x2991b0=P(_0x2991b0),new Vd(_0x2991b0['_repo'],_0x2991b0['_path']);}function E_(_0x27daac,_0x5d37f9){_0x27daac=P(_0x27daac),Me('push',_0x27daac['_path']),He('push',_0x5d37f9,_0x27daac['_path'],!0x0);const _0x862115=la(_0x27daac['_repo']),_0x1d4d0e=Ud(_0x862115),_0x38ccf7=Vt(_0x27daac,_0x1d4d0e),_0x592473=Vt(_0x27daac,_0x1d4d0e);let _0x5d6e81;return _0x5d37f9!=null?_0x5d6e81=Hd(_0x592473,_0x5d37f9)['then'](()=>_0x592473):_0x5d6e81=Promise['resolve'](_0x592473),_0x38ccf7['then']=_0x5d6e81['then']['bind'](_0x5d6e81),_0x38ccf7['catch']=_0x5d6e81['then']['bind'](_0x5d6e81,void 0x0),_0x38ccf7;}function Hd(_0xcf94b8,_0x56f61d){_0xcf94b8=P(_0xcf94b8),Me('set',_0xcf94b8['_path']),He('set',_0x56f61d,_0xcf94b8['_path'],!0x1);const _0x48db1f=new H();return Cd(_0xcf94b8['_repo'],_0xcf94b8['_path'],_0x56f61d,null,_0x48db1f['wrapCallback'](()=>{})),_0x48db1f['promise'];}function I_(_0x5463ca,_0x697844){ra('update',_0x697844,_0x5463ca['_path']);const _0x463f84=new H();return Td(_0x5463ca['_repo'],_0x5463ca['_path'],_0x697844,_0x463f84['wrapCallback'](()=>{})),_0x463f84['promise'];}function w_(_0x2d9f89){_0x2d9f89=P(_0x2d9f89);const _0x58373b=new pa(()=>{}),_0x63d758=new Qn(_0x58373b);return wd(_0x2d9f89['_repo'],_0x2d9f89,_0x63d758)['then'](_0x2bcd73=>new lt(_0x2bcd73,new ee(_0x2d9f89['_repo'],_0x2d9f89['_path']),_0x2d9f89['_queryParams']['getIndex']()));}class Qn{constructor(_0x1471dc){this['callbackContext']=_0x1471dc;}['respondsTo'](_0x52ab6b){return _0x52ab6b==='value';}['createEvent'](_0x17566e,_0x4252f8){const _0x1cb32a=_0x4252f8['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x17566e['snapshotNode'],new ee(_0x4252f8['_repo'],_0x4252f8['_path']),_0x1cb32a));}['getEventRunner'](_0xcdb1dc){return _0xcdb1dc['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xcdb1dc['error']):()=>this['callbackContext']['onValue'](_0xcdb1dc['snapshot'],null);}['createCancelEvent'](_0x1aedcb,_0x25d5cf){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x1aedcb,_0x25d5cf):null;}['matches'](_0x429cd5){return _0x429cd5 instanceof Qn?!_0x429cd5['callbackContext']||!this['callbackContext']?!0x0:_0x429cd5['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x970fac,_0x51f642,_0x3a3851,_0xc07b58,_0xb9bc3a){const _0x36aa36=new pa(_0x3a3851,void 0x0),_0x171c00=new Qn(_0x36aa36);return kd(_0x970fac['_repo'],_0x970fac,_0x171c00),()=>Pd(_0x970fac['_repo'],_0x970fac,_0x171c00);}function Gd(_0x2a0d1c,_0x421fc3,_0x5453c1,_0x14bdc3){return $d(_0x2a0d1c,'value',_0x421fc3);}class mt{}class ma extends mt{constructor(_0x326837,_0x23e65d){super(),this['_value']=_0x326837,this['_key']=_0x23e65d,this['type']='endAt';}['_apply'](_0x516457){He('endAt',this['_value'],_0x516457['_path'],!0x0);const _0x1388cd=Jh(_0x516457['_queryParams'],this['_value'],this['_key']);if(ga(_0x1388cd),Yn(_0x1388cd),_0x516457['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x516457['_repo'],_0x516457['_path'],_0x1388cd,_0x516457['_orderByCalled']);}}function C_(_0x13da2b,_0xdc600e){return new ma(_0x13da2b,_0xdc600e);}class ya extends mt{constructor(_0x276e11,_0x372f3d){super(),this['_value']=_0x276e11,this['_key']=_0x372f3d,this['type']='startAt';}['_apply'](_0x54630f){He('startAt',this['_value'],_0x54630f['_path'],!0x0);const _0x293488=Qh(_0x54630f['_queryParams'],this['_value'],this['_key']);if(ga(_0x293488),Yn(_0x293488),_0x54630f['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x54630f['_repo'],_0x54630f['_path'],_0x293488,_0x54630f['_orderByCalled']);}}function T_(_0x1097fb=null,_0x518330){return new ya(_0x1097fb,_0x518330);}class qd extends mt{constructor(_0x260e0a){super(),this['_limit']=_0x260e0a,this['type']='limitToFirst';}['_apply'](_0x25eb4b){if(_0x25eb4b['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x25eb4b['_repo'],_0x25eb4b['_path'],Yh(_0x25eb4b['_queryParams'],this['_limit']),_0x25eb4b['_orderByCalled']);}}function S_(_0x57cd8b){if(Math['floor'](_0x57cd8b)!==_0x57cd8b||_0x57cd8b<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x57cd8b);}class zd extends mt{constructor(_0x2e35e4){super(),this['_path']=_0x2e35e4,this['type']='orderByChild';}['_apply'](_0x3c693c){_a(_0x3c693c,'orderByChild');const _0x5e06dc=new C(this['_path']);if(v(_0x5e06dc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x19e6ad=new Ji(_0x5e06dc),_0x4b39dc=xo(_0x3c693c['_queryParams'],_0x19e6ad);return Yn(_0x4b39dc),new Ae(_0x3c693c['_repo'],_0x3c693c['_path'],_0x4b39dc,!0x0);}}function b_(_0x28b8af){if(_0x28b8af==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x28b8af==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x28b8af==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x28b8af),new zd(_0x28b8af);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x49b53f){_a(_0x49b53f,'orderByKey');const _0x5f3728=xo(_0x49b53f['_queryParams'],ve);return Yn(_0x5f3728),new Ae(_0x49b53f['_repo'],_0x49b53f['_path'],_0x5f3728,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x149d80,_0x2b3fcc){super(),this['_value']=_0x149d80,this['_key']=_0x2b3fcc,this['type']='equalTo';}['_apply'](_0x4edfb8){if(He('equalTo',this['_value'],_0x4edfb8['_path'],!0x1),_0x4edfb8['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4edfb8['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4edfb8));}}function A_(_0x412992,_0x376562){return new Kd(_0x412992,_0x376562);}function k_(_0x25ee34,..._0x8c8225){let _0x1df2b6=P(_0x25ee34);for(const _0x41b5f8 of _0x8c8225)_0x1df2b6=_0x41b5f8['_apply'](_0x1df2b6);return _0x1df2b6;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x3012f0,_0x17c598,_0xaea982,_0x5dbec9){const _0x373795=_0x17c598['lastIndexOf'](':'),_0x192258=_0x17c598['substring'](0x0,_0x373795),_0x5e9f23=qt(_0x192258);_0x3012f0['repoInfo_']=new yo(_0x17c598,_0x5e9f23,_0x3012f0['repoInfo_']['namespace'],_0x3012f0['repoInfo_']['webSocketOnly'],_0x3012f0['repoInfo_']['nodeAdmin'],_0x3012f0['repoInfo_']['persistenceKey'],_0x3012f0['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0xaea982),_0x5dbec9&&(_0x3012f0['authTokenProvider_']=_0x5dbec9);}function Xd(_0x4dd2c7,_0x52fde0,_0x44159f,_0x26f73d,_0x25749d){let _0x1d7c02=_0x26f73d||_0x4dd2c7['options']['databaseURL'];_0x1d7c02===void 0x0&&(_0x4dd2c7['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4dd2c7['options']['projectId']),_0x1d7c02=_0x4dd2c7['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1dec80=vr(_0x1d7c02,_0x25749d),_0x293249=_0x1dec80['repoInfo'],_0x161e67;typeof process<'u'&&Bs&&(_0x161e67=Bs[Yd]),_0x161e67?(_0x1d7c02='http://'+_0x161e67+'?ns='+_0x293249['namespace'],_0x1dec80=vr(_0x1d7c02,_0x25749d),_0x293249=_0x1dec80['repoInfo']):_0x1dec80['repoInfo']['secure'];const _0x469638=new eh(_0x4dd2c7['name'],_0x4dd2c7['options'],_0x52fde0);_d('Invalid\x20Firebase\x20Database\x20URL',_0x1dec80),v(_0x1dec80['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4b5a32=ef(_0x293249,_0x4dd2c7,_0x469638,new Zl(_0x4dd2c7,_0x44159f));return new tf(_0x4b5a32,_0x4dd2c7);}function Zd(_0x2af114,_0x3f1937){const _0x366124=Di[_0x3f1937];(!_0x366124||_0x366124[_0x2af114['key']]!==_0x2af114)&&ae('Database\x20'+_0x3f1937+'('+_0x2af114['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2af114),delete _0x366124[_0x2af114['key']];}function ef(_0x3152a7,_0x53f768,_0x3c5c9e,_0x49c023){let _0xf37f17=Di[_0x53f768['name']];_0xf37f17||(_0xf37f17={},Di[_0x53f768['name']]=_0xf37f17);let _0x1efd65=_0xf37f17[_0x3152a7['toURLString']()];return _0x1efd65&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1efd65=new vd(_0x3152a7,Qd,_0x3c5c9e,_0x49c023),_0xf37f17[_0x3152a7['toURLString']()]=_0x1efd65,_0x1efd65;}class tf{constructor(_0x7c5860,_0x1361e6){this['_repoInternal']=_0x7c5860,this['app']=_0x1361e6,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x11397d){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x11397d+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3f1697=Zr(),_0x3e62c7){const _0x4dcff4=Hi(_0x3f1697,'database')['getImmediate']({'identifier':_0x3e62c7});if(!_0x4dcff4['_instanceStarted']){const _0x538cb7=hc('database');_0x538cb7&&nf(_0x4dcff4,..._0x538cb7);}return _0x4dcff4;}function nf(_0x62f639,_0xe2f3b0,_0x5eb18e,_0x28149d={}){_0x62f639=P(_0x62f639),_0x62f639['_checkNotDeleted']('useEmulator');const _0x3e8348=_0xe2f3b0+':'+_0x5eb18e,_0xfd829e=_0x62f639['_repoInternal'];if(_0x62f639['_instanceStarted']){if(_0x3e8348===_0x62f639['_repoInternal']['repoInfo_']['host']&&xe(_0x28149d,_0xfd829e['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xce4753;if(_0xfd829e['repoInfo_']['nodeAdmin'])_0x28149d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xce4753=new an(an['OWNER']);else{if(_0x28149d['mockUserToken']){const _0x1b173c=typeof _0x28149d['mockUserToken']=='string'?_0x28149d['mockUserToken']:uc(_0x28149d['mockUserToken'],_0x62f639['app']['options']['projectId']);_0xce4753=new an(_0x1b173c);}}qt(_0xe2f3b0)&&Qr(_0xe2f3b0),Jd(_0xfd829e,_0x3e8348,_0x28149d,_0xce4753);}function N_(_0x17292a){_0x17292a=P(_0x17292a),_0x17292a['_checkNotDeleted']('goOffline'),ha(_0x17292a['_repo']);}function O_(_0x2596f5){_0x2596f5=P(_0x2596f5),_0x2596f5['_checkNotDeleted']('goOnline'),Nd(_0x2596f5['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x514ce3){Ul(dt),st(new Fe('database',(_0xf8482c,{instanceIdentifier:_0x1b8747})=>{const _0x27a297=_0xf8482c['getProvider']('app')['getImmediate'](),_0xc33571=_0xf8482c['getProvider']('auth-internal'),_0x33e89a=_0xf8482c['getProvider']('app-check-internal');return Xd(_0x27a297,_0xc33571,_0x33e89a,_0x1b8747);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x514ce3),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x6033b4,_0x226869){this['committed']=_0x6033b4,this['snapshot']=_0x226869;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x17f1a9,_0x340c2e,_0x9095ee){if(_0x17f1a9=P(_0x17f1a9),Me('Reference.transaction',_0x17f1a9['_path']),_0x17f1a9['key']==='.length'||_0x17f1a9['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x17f1a9['key']+'\x20is\x20a\x20read-only\x20object.';const _0x41372b=!0x0,_0x1cca70=new H(),_0x397afd=(_0x1a7f4f,_0x32b65a,_0xf7690b)=>{let _0x24f540=null;_0x1a7f4f?_0x1cca70['reject'](_0x1a7f4f):(_0x24f540=new lt(_0xf7690b,new ee(_0x17f1a9['_repo'],_0x17f1a9['_path']),R),_0x1cca70['resolve'](new of(_0x32b65a,_0x24f540)));},_0x31bcb2=Gd(_0x17f1a9,()=>{});return Od(_0x17f1a9['_repo'],_0x17f1a9['_path'],_0x340c2e,_0x397afd,_0x31bcb2,_0x41372b),_0x1cca70['promise'];}se['prototype']['simpleListen']=function(_0x594c40,_0x3526b0){this['sendRequest']('q',{'p':_0x594c40},_0x3526b0);},se['prototype']['echo']=function(_0xb9e4cd,_0x5c589d){this['sendRequest']('echo',{'d':_0xb9e4cd},_0x5c589d);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x36f68c,..._0x2761d1){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x36f68c,..._0x2761d1);}function cn(_0x312cd4,..._0x2cfc42){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x312cd4,..._0x2cfc42);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x79243c,..._0x540802){throw ws(_0x79243c,..._0x540802);}function X(_0x2abe69,..._0x53909b){return ws(_0x2abe69,..._0x53909b);}function Ia(_0x26c74a,_0x23e37a,_0x2ae087){const _0x22b6bd={...af(),[_0x23e37a]:_0x2ae087};return new Gt('auth','Firebase',_0x22b6bd)['create'](_0x23e37a,{'appName':_0x26c74a['name']});}function re(_0x584af2){return Ia(_0x584af2,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1d4594,..._0x5bedf0){if(typeof _0x1d4594!='string'){const _0x543373=_0x5bedf0[0x0],_0x16181=[..._0x5bedf0['slice'](0x1)];return _0x16181[0x0]&&(_0x16181[0x0]['appName']=_0x1d4594['name']),_0x1d4594['_errorFactory']['create'](_0x543373,..._0x16181);}return Ea['create'](_0x1d4594,..._0x5bedf0);}function m(_0x1a0474,_0x11d5d7,..._0x3f3257){if(!_0x1a0474)throw ws(_0x11d5d7,..._0x3f3257);}function ne(_0x496854){const _0x3d3faf='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x496854;throw cn(_0x3d3faf),new Error(_0x3d3faf);}function ce(_0xd9c301,_0x2d12d8){_0xd9c301||ne(_0x2d12d8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x5a4445;return typeof self<'u'&&((_0x5a4445=self['location'])==null?void 0x0:_0x5a4445['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3621d2;return typeof self<'u'&&((_0x3621d2=self['location'])==null?void 0x0:_0x3621d2['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1a0703=navigator;return _0x1a0703['languages']&&_0x1a0703['languages'][0x0]||_0x1a0703['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2134ca,_0x40e5dd){this['shortDelay']=_0x2134ca,this['longDelay']=_0x40e5dd,ce(_0x40e5dd>_0x2134ca,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x52de58,_0x2ea8aa){ce(_0x52de58['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2d6bf1}=_0x52de58['emulator'];return _0x2ea8aa?''+_0x2d6bf1+(_0x2ea8aa['startsWith']('/')?_0x2ea8aa['slice'](0x1):_0x2ea8aa):_0x2d6bf1;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x1d81af,_0x4b78ea,_0x4b7c8d){this['fetchImpl']=_0x1d81af,_0x4b78ea&&(this['headersImpl']=_0x4b78ea),_0x4b7c8d&&(this['responseImpl']=_0x4b7c8d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4881fd,_0x43e312){return _0x4881fd['tenantId']&&!_0x43e312['tenantId']?{..._0x43e312,'tenantId':_0x4881fd['tenantId']}:_0x43e312;}async function Pe(_0x4adb9f,_0x2b9b3d,_0x2c8db6,_0x2d0075,_0xd7254={}){return Ca(_0x4adb9f,_0xd7254,async()=>{let _0x1de209={},_0x344113={};_0x2d0075&&(_0x2b9b3d==='GET'?_0x344113=_0x2d0075:_0x1de209={'body':JSON['stringify'](_0x2d0075)});const _0x3e9b7f=ut({..._0x344113,'key':_0x4adb9f['config']['apiKey']})['slice'](0x1),_0x5627a7=await _0x4adb9f['_getAdditionalHeaders']();_0x5627a7['Content-Type']='application/json',_0x4adb9f['languageCode']&&(_0x5627a7['X-Firebase-Locale']=_0x4adb9f['languageCode']);const _0x201fba={'method':_0x2b9b3d,'headers':_0x5627a7,..._0x1de209};return dc()||(_0x201fba['referrerPolicy']='strict-origin-when-cross-origin'),_0x4adb9f['emulatorConfig']&&qt(_0x4adb9f['emulatorConfig']['host'])&&(_0x201fba['credentials']='include'),wa['fetch']()(await Ta(_0x4adb9f,_0x4adb9f['config']['apiHost'],_0x2c8db6,_0x3e9b7f),_0x201fba);});}async function Ca(_0x51ae83,_0x158b94,_0x55dd3a){_0x51ae83['_canInitEmulator']=!0x1;const _0x1168c0={...df,..._0x158b94};try{const _0x3dfa54=new gf(_0x51ae83),_0x4ab4d1=await Promise['race']([_0x55dd3a(),_0x3dfa54['promise']]);_0x3dfa54['clearNetworkTimeout']();const _0xe01d6c=await _0x4ab4d1['json']();if('needConfirmation'in _0xe01d6c)throw on(_0x51ae83,'account-exists-with-different-credential',_0xe01d6c);if(_0x4ab4d1['ok']&&!('errorMessage'in _0xe01d6c))return _0xe01d6c;{const _0x5d5c34=_0x4ab4d1['ok']?_0xe01d6c['errorMessage']:_0xe01d6c['error']['message'],[_0x5a35fa,_0x2db614]=_0x5d5c34['split']('\x20:\x20');if(_0x5a35fa==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x51ae83,'credential-already-in-use',_0xe01d6c);if(_0x5a35fa==='EMAIL_EXISTS')throw on(_0x51ae83,'email-already-in-use',_0xe01d6c);if(_0x5a35fa==='USER_DISABLED')throw on(_0x51ae83,'user-disabled',_0xe01d6c);const _0x4b871f=_0x1168c0[_0x5a35fa]||_0x5a35fa['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2db614)throw Ia(_0x51ae83,_0x4b871f,_0x2db614);Y(_0x51ae83,_0x4b871f);}}catch(_0x2c1e7c){if(_0x2c1e7c instanceof Re)throw _0x2c1e7c;Y(_0x51ae83,'network-request-failed',{'message':String(_0x2c1e7c)});}}async function en(_0x36301a,_0x39db12,_0x4f4398,_0x54d52f,_0x5705e8={}){const _0x5490a4=await Pe(_0x36301a,_0x39db12,_0x4f4398,_0x54d52f,_0x5705e8);return'mfaPendingCredential'in _0x5490a4&&Y(_0x36301a,'multi-factor-auth-required',{'_serverResponse':_0x5490a4}),_0x5490a4;}async function Ta(_0x43e5b9,_0x55529f,_0x572187,_0x11057d){const _0x1bb63f=''+_0x55529f+_0x572187+'?'+_0x11057d,_0x101350=_0x43e5b9,_0x3d403f=_0x101350['config']['emulator']?Cs(_0x43e5b9['config'],_0x1bb63f):_0x43e5b9['config']['apiScheme']+'://'+_0x1bb63f;return ff['includes'](_0x572187)&&(await _0x101350['_persistenceManagerAvailable'],_0x101350['_getPersistenceType']()==='COOKIE')?_0x101350['_getPersistence']()['_getFinalTarget'](_0x3d403f)['toString']():_0x3d403f;}function _f(_0x607f4a){switch(_0x607f4a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x578d0a){this['auth']=_0x578d0a,this['timer']=null,this['promise']=new Promise((_0x1d55fd,_0x1a4c92)=>{this['timer']=setTimeout(()=>_0x1a4c92(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x1d2fa5,_0x3736f7,_0x23eed6){const _0x3905a1={'appName':_0x1d2fa5['name']};_0x23eed6['email']&&(_0x3905a1['email']=_0x23eed6['email']),_0x23eed6['phoneNumber']&&(_0x3905a1['phoneNumber']=_0x23eed6['phoneNumber']);const _0x54ee2c=X(_0x1d2fa5,_0x3736f7,_0x3905a1);return _0x54ee2c['customData']['_tokenResponse']=_0x23eed6,_0x54ee2c;}function wr(_0x401593){return _0x401593!==void 0x0&&_0x401593['enterprise']!==void 0x0;}class mf{constructor(_0x5dfe2a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5dfe2a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5dfe2a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5dfe2a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5d3313){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x205c77 of this['recaptchaEnforcementState'])if(_0x205c77['provider']&&_0x205c77['provider']===_0x5d3313)return _f(_0x205c77['enforcementState']);return null;}['isProviderEnabled'](_0x22a124){return this['getProviderEnforcementState'](_0x22a124)==='ENFORCE'||this['getProviderEnforcementState'](_0x22a124)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x179674,_0x453a3a){return Pe(_0x179674,'GET','/v2/recaptchaConfig',ke(_0x179674,_0x453a3a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x4b2bb5,_0x17ef0c){return Pe(_0x4b2bb5,'POST','/v1/accounts:delete',_0x17ef0c);}async function Pn(_0x5c25a1,_0x3d9e3b){return Pe(_0x5c25a1,'POST','/v1/accounts:lookup',_0x3d9e3b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x37cd27){if(_0x37cd27)try{const _0x57ef01=new Date(Number(_0x37cd27));if(!isNaN(_0x57ef01['getTime']()))return _0x57ef01['toUTCString']();}catch{}}async function Ef(_0x109c1c,_0x3622d9=!0x1){const _0x3e1592=P(_0x109c1c),_0x110ccc=await _0x3e1592['getIdToken'](_0x3622d9),_0x4ed1de=Ts(_0x110ccc);m(_0x4ed1de&&_0x4ed1de['exp']&&_0x4ed1de['auth_time']&&_0x4ed1de['iat'],_0x3e1592['auth'],'internal-error');const _0x59df05=typeof _0x4ed1de['firebase']=='object'?_0x4ed1de['firebase']:void 0x0,_0x5cca98=_0x59df05==null?void 0x0:_0x59df05['sign_in_provider'];return{'claims':_0x4ed1de,'token':_0x110ccc,'authTime':Pt(fi(_0x4ed1de['auth_time'])),'issuedAtTime':Pt(fi(_0x4ed1de['iat'])),'expirationTime':Pt(fi(_0x4ed1de['exp'])),'signInProvider':_0x5cca98||null,'signInSecondFactor':(_0x59df05==null?void 0x0:_0x59df05['sign_in_second_factor'])||null};}function fi(_0x8deaa){return Number(_0x8deaa)*0x3e8;}function Ts(_0x2f496c){const [_0x950cbb,_0x1cf765,_0x36db1a]=_0x2f496c['split']('.');if(_0x950cbb===void 0x0||_0x1cf765===void 0x0||_0x36db1a===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3a1c9f=fn(_0x1cf765);return _0x3a1c9f?JSON['parse'](_0x3a1c9f):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4bbe30){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4bbe30==null?void 0x0:_0x4bbe30['toString']()),null;}}function Cr(_0x1366ca){const _0x4dd03d=Ts(_0x1366ca);return m(_0x4dd03d,'internal-error'),m(typeof _0x4dd03d['exp']<'u','internal-error'),m(typeof _0x4dd03d['iat']<'u','internal-error'),Number(_0x4dd03d['exp'])-Number(_0x4dd03d['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x18d616,_0x3ab536,_0x1df0b8=!0x1){if(_0x1df0b8)return _0x3ab536;try{return await _0x3ab536;}catch(_0x5e312f){throw _0x5e312f instanceof Re&&If(_0x5e312f)&&_0x18d616['auth']['currentUser']===_0x18d616&&await _0x18d616['auth']['signOut'](),_0x5e312f;}}function If({code:_0x18bbe0}){return _0x18bbe0==='auth/user-disabled'||_0x18bbe0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x3cb4a4){this['user']=_0x3cb4a4,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x5756be){if(_0x5756be){const _0x1db40b=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1db40b;}else{this['errorBackoff']=0x7530;const _0x3c855b=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3c855b);}}['schedule'](_0x28f771=!0x1){if(!this['isRunning'])return;const _0x4c7c80=this['getInterval'](_0x28f771);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4c7c80);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x13ec2f){(_0x13ec2f==null?void 0x0:_0x13ec2f['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x557b86,_0x25b8c7){this['createdAt']=_0x557b86,this['lastLoginAt']=_0x25b8c7,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x374f0f){this['createdAt']=_0x374f0f['createdAt'],this['lastLoginAt']=_0x374f0f['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x38d03c){var _0xded9fd;const _0x580ff5=_0x38d03c['auth'],_0x176c4c=await _0x38d03c['getIdToken'](),_0x13a9eb=await Ht(_0x38d03c,Pn(_0x580ff5,{'idToken':_0x176c4c}));m(_0x13a9eb==null?void 0x0:_0x13a9eb['users']['length'],_0x580ff5,'internal-error');const _0x545eaa=_0x13a9eb['users'][0x0];_0x38d03c['_notifyReloadListener'](_0x545eaa);const _0x1a78bd=(_0xded9fd=_0x545eaa['providerUserInfo'])!=null&&_0xded9fd['length']?Sa(_0x545eaa['providerUserInfo']):[],_0x325f5b=Tf(_0x38d03c['providerData'],_0x1a78bd),_0x2537b4=_0x38d03c['isAnonymous'],_0x178166=!(_0x38d03c['email']&&_0x545eaa['passwordHash'])&&!(_0x325f5b!=null&&_0x325f5b['length']),_0x58db88=_0x2537b4?_0x178166:!0x1,_0x15be03={'uid':_0x545eaa['localId'],'displayName':_0x545eaa['displayName']||null,'photoURL':_0x545eaa['photoUrl']||null,'email':_0x545eaa['email']||null,'emailVerified':_0x545eaa['emailVerified']||!0x1,'phoneNumber':_0x545eaa['phoneNumber']||null,'tenantId':_0x545eaa['tenantId']||null,'providerData':_0x325f5b,'metadata':new Li(_0x545eaa['createdAt'],_0x545eaa['lastLoginAt']),'isAnonymous':_0x58db88};Object['assign'](_0x38d03c,_0x15be03);}async function Cf(_0x584e3b){const _0x4e8066=P(_0x584e3b);await Nn(_0x4e8066),await _0x4e8066['auth']['_persistUserIfCurrent'](_0x4e8066),_0x4e8066['auth']['_notifyListenersIfCurrent'](_0x4e8066);}function Tf(_0x4e89e3,_0x3bc6e8){return[..._0x4e89e3['filter'](_0x3a0b76=>!_0x3bc6e8['some'](_0x168b76=>_0x168b76['providerId']===_0x3a0b76['providerId'])),..._0x3bc6e8];}function Sa(_0x3aad42){return _0x3aad42['map'](({providerId:_0x538496,..._0xfc7a39})=>({'providerId':_0x538496,'uid':_0xfc7a39['rawId']||'','displayName':_0xfc7a39['displayName']||null,'email':_0xfc7a39['email']||null,'phoneNumber':_0xfc7a39['phoneNumber']||null,'photoURL':_0xfc7a39['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4358a8,_0x56de1b){const _0x10b8fa=await Ca(_0x4358a8,{},async()=>{const _0x5925b6=ut({'grant_type':'refresh_token','refresh_token':_0x56de1b})['slice'](0x1),{tokenApiHost:_0x4240b5,apiKey:_0x12fd08}=_0x4358a8['config'],_0x39bd21=await Ta(_0x4358a8,_0x4240b5,'/v1/token','key='+_0x12fd08),_0x1b80d2=await _0x4358a8['_getAdditionalHeaders']();_0x1b80d2['Content-Type']='application/x-www-form-urlencoded';const _0x1c9ac2={'method':'POST','headers':_0x1b80d2,'body':_0x5925b6};return _0x4358a8['emulatorConfig']&&qt(_0x4358a8['emulatorConfig']['host'])&&(_0x1c9ac2['credentials']='include'),wa['fetch']()(_0x39bd21,_0x1c9ac2);});return{'accessToken':_0x10b8fa['access_token'],'expiresIn':_0x10b8fa['expires_in'],'refreshToken':_0x10b8fa['refresh_token']};}async function bf(_0x212cd9,_0xaec089){return Pe(_0x212cd9,'POST','/v2/accounts:revokeToken',ke(_0x212cd9,_0xaec089));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x98b8bc){m(_0x98b8bc['idToken'],'internal-error'),m(typeof _0x98b8bc['idToken']<'u','internal-error'),m(typeof _0x98b8bc['refreshToken']<'u','internal-error');const _0x447881='expiresIn'in _0x98b8bc&&typeof _0x98b8bc['expiresIn']<'u'?Number(_0x98b8bc['expiresIn']):Cr(_0x98b8bc['idToken']);this['updateTokensAndExpiration'](_0x98b8bc['idToken'],_0x98b8bc['refreshToken'],_0x447881);}['updateFromIdToken'](_0x112756){m(_0x112756['length']!==0x0,'internal-error');const _0x244ed5=Cr(_0x112756);this['updateTokensAndExpiration'](_0x112756,null,_0x244ed5);}async['getToken'](_0x333eeb,_0x1a8f55=!0x1){return!_0x1a8f55&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x333eeb,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x333eeb,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x336b44,_0x32d766){const {accessToken:_0xb22561,refreshToken:_0x2cb7b0,expiresIn:_0x1e1073}=await Sf(_0x336b44,_0x32d766);this['updateTokensAndExpiration'](_0xb22561,_0x2cb7b0,Number(_0x1e1073));}['updateTokensAndExpiration'](_0x53009e,_0x11a084,_0x53a9f3){this['refreshToken']=_0x11a084||null,this['accessToken']=_0x53009e||null,this['expirationTime']=Date['now']()+_0x53a9f3*0x3e8;}static['fromJSON'](_0x31f282,_0x2e7962){const {refreshToken:_0x152d60,accessToken:_0x41dc95,expirationTime:_0x671758}=_0x2e7962,_0x292464=new et();return _0x152d60&&(m(typeof _0x152d60=='string','internal-error',{'appName':_0x31f282}),_0x292464['refreshToken']=_0x152d60),_0x41dc95&&(m(typeof _0x41dc95=='string','internal-error',{'appName':_0x31f282}),_0x292464['accessToken']=_0x41dc95),_0x671758&&(m(typeof _0x671758=='number','internal-error',{'appName':_0x31f282}),_0x292464['expirationTime']=_0x671758),_0x292464;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xf1ee95){this['accessToken']=_0xf1ee95['accessToken'],this['refreshToken']=_0xf1ee95['refreshToken'],this['expirationTime']=_0xf1ee95['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1decc9,_0x485d50){m(typeof _0x1decc9=='string'||typeof _0x1decc9>'u','internal-error',{'appName':_0x485d50});}class j{constructor({uid:_0x281bec,auth:_0x48f99b,stsTokenManager:_0x447c53,..._0xac323e}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x281bec,this['auth']=_0x48f99b,this['stsTokenManager']=_0x447c53,this['accessToken']=_0x447c53['accessToken'],this['displayName']=_0xac323e['displayName']||null,this['email']=_0xac323e['email']||null,this['emailVerified']=_0xac323e['emailVerified']||!0x1,this['phoneNumber']=_0xac323e['phoneNumber']||null,this['photoURL']=_0xac323e['photoURL']||null,this['isAnonymous']=_0xac323e['isAnonymous']||!0x1,this['tenantId']=_0xac323e['tenantId']||null,this['providerData']=_0xac323e['providerData']?[..._0xac323e['providerData']]:[],this['metadata']=new Li(_0xac323e['createdAt']||void 0x0,_0xac323e['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5b2ced){const _0x182b05=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x5b2ced));return m(_0x182b05,this['auth'],'internal-error'),this['accessToken']!==_0x182b05&&(this['accessToken']=_0x182b05,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x182b05;}['getIdTokenResult'](_0x3738b3){return Ef(this,_0x3738b3);}['reload'](){return Cf(this);}['_assign'](_0x53b45e){this!==_0x53b45e&&(m(this['uid']===_0x53b45e['uid'],this['auth'],'internal-error'),this['displayName']=_0x53b45e['displayName'],this['photoURL']=_0x53b45e['photoURL'],this['email']=_0x53b45e['email'],this['emailVerified']=_0x53b45e['emailVerified'],this['phoneNumber']=_0x53b45e['phoneNumber'],this['isAnonymous']=_0x53b45e['isAnonymous'],this['tenantId']=_0x53b45e['tenantId'],this['providerData']=_0x53b45e['providerData']['map'](_0x28e347=>({..._0x28e347})),this['metadata']['_copy'](_0x53b45e['metadata']),this['stsTokenManager']['_assign'](_0x53b45e['stsTokenManager']));}['_clone'](_0x15c8f1){const _0x420b12=new j({...this,'auth':_0x15c8f1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x420b12['metadata']['_copy'](this['metadata']),_0x420b12;}['_onReload'](_0x56f2ff){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x56f2ff,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x48a4a6){this['reloadListener']?this['reloadListener'](_0x48a4a6):this['reloadUserInfo']=_0x48a4a6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x356195,_0x580a35=!0x1){let _0x370686=!0x1;_0x356195['idToken']&&_0x356195['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x356195),_0x370686=!0x0),_0x580a35&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x370686&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x171b5c=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x171b5c})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x291487=>({..._0x291487})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x322165,_0x2b8b51){const _0x4580a1=_0x2b8b51['displayName']??void 0x0,_0x307cc0=_0x2b8b51['email']??void 0x0,_0x193bc9=_0x2b8b51['phoneNumber']??void 0x0,_0x5af806=_0x2b8b51['photoURL']??void 0x0,_0x2ae423=_0x2b8b51['tenantId']??void 0x0,_0x2ae1df=_0x2b8b51['_redirectEventId']??void 0x0,_0x4ed98c=_0x2b8b51['createdAt']??void 0x0,_0x4c0a37=_0x2b8b51['lastLoginAt']??void 0x0,{uid:_0x4dcfdc,emailVerified:_0xd44514,isAnonymous:_0x113ecf,providerData:_0x4ce1c6,stsTokenManager:_0x32bde4}=_0x2b8b51;m(_0x4dcfdc&&_0x32bde4,_0x322165,'internal-error');const _0x3e5a10=et['fromJSON'](this['name'],_0x32bde4);m(typeof _0x4dcfdc=='string',_0x322165,'internal-error'),le(_0x4580a1,_0x322165['name']),le(_0x307cc0,_0x322165['name']),m(typeof _0xd44514=='boolean',_0x322165,'internal-error'),m(typeof _0x113ecf=='boolean',_0x322165,'internal-error'),le(_0x193bc9,_0x322165['name']),le(_0x5af806,_0x322165['name']),le(_0x2ae423,_0x322165['name']),le(_0x2ae1df,_0x322165['name']),le(_0x4ed98c,_0x322165['name']),le(_0x4c0a37,_0x322165['name']);const _0x39d817=new j({'uid':_0x4dcfdc,'auth':_0x322165,'email':_0x307cc0,'emailVerified':_0xd44514,'displayName':_0x4580a1,'isAnonymous':_0x113ecf,'photoURL':_0x5af806,'phoneNumber':_0x193bc9,'tenantId':_0x2ae423,'stsTokenManager':_0x3e5a10,'createdAt':_0x4ed98c,'lastLoginAt':_0x4c0a37});return _0x4ce1c6&&Array['isArray'](_0x4ce1c6)&&(_0x39d817['providerData']=_0x4ce1c6['map'](_0x622f5f=>({..._0x622f5f}))),_0x2ae1df&&(_0x39d817['_redirectEventId']=_0x2ae1df),_0x39d817;}static async['_fromIdTokenResponse'](_0x32458e,_0xe67c7,_0x2df16a=!0x1){const _0x2c55af=new et();_0x2c55af['updateFromServerResponse'](_0xe67c7);const _0x3dbdd0=new j({'uid':_0xe67c7['localId'],'auth':_0x32458e,'stsTokenManager':_0x2c55af,'isAnonymous':_0x2df16a});return await Nn(_0x3dbdd0),_0x3dbdd0;}static async['_fromGetAccountInfoResponse'](_0x316639,_0x5aca9a,_0x3319e6){const _0x141a8e=_0x5aca9a['users'][0x0];m(_0x141a8e['localId']!==void 0x0,'internal-error');const _0x4280e6=_0x141a8e['providerUserInfo']!==void 0x0?Sa(_0x141a8e['providerUserInfo']):[],_0x5a806e=!(_0x141a8e['email']&&_0x141a8e['passwordHash'])&&!(_0x4280e6!=null&&_0x4280e6['length']),_0x16038d=new et();_0x16038d['updateFromIdToken'](_0x3319e6);const _0x3c112b=new j({'uid':_0x141a8e['localId'],'auth':_0x316639,'stsTokenManager':_0x16038d,'isAnonymous':_0x5a806e}),_0x13c47a={'uid':_0x141a8e['localId'],'displayName':_0x141a8e['displayName']||null,'photoURL':_0x141a8e['photoUrl']||null,'email':_0x141a8e['email']||null,'emailVerified':_0x141a8e['emailVerified']||!0x1,'phoneNumber':_0x141a8e['phoneNumber']||null,'tenantId':_0x141a8e['tenantId']||null,'providerData':_0x4280e6,'metadata':new Li(_0x141a8e['createdAt'],_0x141a8e['lastLoginAt']),'isAnonymous':!(_0x141a8e['email']&&_0x141a8e['passwordHash'])&&!(_0x4280e6!=null&&_0x4280e6['length'])};return Object['assign'](_0x3c112b,_0x13c47a),_0x3c112b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4ed7ed){ce(_0x4ed7ed instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2ef5be=Tr['get'](_0x4ed7ed);return _0x2ef5be?(ce(_0x2ef5be instanceof _0x4ed7ed,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2ef5be):(_0x2ef5be=new _0x4ed7ed(),Tr['set'](_0x4ed7ed,_0x2ef5be),_0x2ef5be);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x30f673,_0x5756c2){this['storage'][_0x30f673]=_0x5756c2;}async['_get'](_0x42b98f){const _0x562520=this['storage'][_0x42b98f];return _0x562520===void 0x0?null:_0x562520;}async['_remove'](_0x463270){delete this['storage'][_0x463270];}['_addListener'](_0x52759e,_0x22e37f){}['_removeListener'](_0x581695,_0x9a621b){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x5830d2,_0x1ca19b,_0x132402){return'firebase:'+_0x5830d2+':'+_0x1ca19b+':'+_0x132402;}class tt{constructor(_0x19bb24,_0xb17a95,_0x554e1b){this['persistence']=_0x19bb24,this['auth']=_0xb17a95,this['userKey']=_0x554e1b;const {config:_0x4eaf91,name:_0x5e7b5e}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x4eaf91['apiKey'],_0x5e7b5e),this['fullPersistenceKey']=ln('persistence',_0x4eaf91['apiKey'],_0x5e7b5e),this['boundEventHandler']=_0xb17a95['_onStorageEvent']['bind'](_0xb17a95),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x14d062){return this['persistence']['_set'](this['fullUserKey'],_0x14d062['toJSON']());}async['getCurrentUser'](){const _0x4d2a2c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4d2a2c)return null;if(typeof _0x4d2a2c=='string'){const _0x22035a=await Pn(this['auth'],{'idToken':_0x4d2a2c})['catch'](()=>{});return _0x22035a?j['_fromGetAccountInfoResponse'](this['auth'],_0x22035a,_0x4d2a2c):null;}return j['_fromJSON'](this['auth'],_0x4d2a2c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x238393){if(this['persistence']===_0x238393)return;const _0x5d93e4=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x238393,_0x5d93e4)return this['setCurrentUser'](_0x5d93e4);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x43c61b,_0x5a821f,_0x3b1c71='authUser'){if(!_0x5a821f['length'])return new tt(ie(Sr),_0x43c61b,_0x3b1c71);const _0x1bb660=(await Promise['all'](_0x5a821f['map'](async _0xf06000=>{if(await _0xf06000['_isAvailable']())return _0xf06000;})))['filter'](_0x233639=>_0x233639);let _0x4f958a=_0x1bb660[0x0]||ie(Sr);const _0x1aaa92=ln(_0x3b1c71,_0x43c61b['config']['apiKey'],_0x43c61b['name']);let _0x185fc9=null;for(const _0x26ece4 of _0x5a821f)try{const _0x4ab6a3=await _0x26ece4['_get'](_0x1aaa92);if(_0x4ab6a3){let _0x3af573;if(typeof _0x4ab6a3=='string'){const _0x3b63bb=await Pn(_0x43c61b,{'idToken':_0x4ab6a3})['catch'](()=>{});if(!_0x3b63bb)break;_0x3af573=await j['_fromGetAccountInfoResponse'](_0x43c61b,_0x3b63bb,_0x4ab6a3);}else _0x3af573=j['_fromJSON'](_0x43c61b,_0x4ab6a3);_0x26ece4!==_0x4f958a&&(_0x185fc9=_0x3af573),_0x4f958a=_0x26ece4;break;}}catch{}const _0x5df36d=_0x1bb660['filter'](_0x547c42=>_0x547c42['_shouldAllowMigration']);return!_0x4f958a['_shouldAllowMigration']||!_0x5df36d['length']?new tt(_0x4f958a,_0x43c61b,_0x3b1c71):(_0x4f958a=_0x5df36d[0x0],_0x185fc9&&await _0x4f958a['_set'](_0x1aaa92,_0x185fc9['toJSON']()),await Promise['all'](_0x5a821f['map'](async _0xacee0d=>{if(_0xacee0d!==_0x4f958a)try{await _0xacee0d['_remove'](_0x1aaa92);}catch{}})),new tt(_0x4f958a,_0x43c61b,_0x3b1c71));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4899ce){const _0x1fbfeb=_0x4899ce['toLowerCase']();if(_0x1fbfeb['includes']('opera/')||_0x1fbfeb['includes']('opr/')||_0x1fbfeb['includes']('opios/'))return'Opera';if(Pa(_0x1fbfeb))return'IEMobile';if(_0x1fbfeb['includes']('msie')||_0x1fbfeb['includes']('trident/'))return'IE';if(_0x1fbfeb['includes']('edge/'))return'Edge';if(Ra(_0x1fbfeb))return'Firefox';if(_0x1fbfeb['includes']('silk/'))return'Silk';if(Oa(_0x1fbfeb))return'Blackberry';if(Da(_0x1fbfeb))return'Webos';if(Aa(_0x1fbfeb))return'Safari';if((_0x1fbfeb['includes']('chrome/')||ka(_0x1fbfeb))&&!_0x1fbfeb['includes']('edge/'))return'Chrome';if(Na(_0x1fbfeb))return'Android';{const _0x31ee8f=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3bfe8d=_0x4899ce['match'](_0x31ee8f);if((_0x3bfe8d==null?void 0x0:_0x3bfe8d['length'])===0x2)return _0x3bfe8d[0x1];}return'Other';}function Ra(_0x910f68=W()){return/firefox\//i['test'](_0x910f68);}function Aa(_0x2318ae=W()){const _0x10a851=_0x2318ae['toLowerCase']();return _0x10a851['includes']('safari/')&&!_0x10a851['includes']('chrome/')&&!_0x10a851['includes']('crios/')&&!_0x10a851['includes']('android');}function ka(_0x570764=W()){return/crios\//i['test'](_0x570764);}function Pa(_0x2400af=W()){return/iemobile/i['test'](_0x2400af);}function Na(_0x27d267=W()){return/android/i['test'](_0x27d267);}function Oa(_0x86ca1f=W()){return/blackberry/i['test'](_0x86ca1f);}function Da(_0x1a7a30=W()){return/webos/i['test'](_0x1a7a30);}function Ss(_0x1ddb1a=W()){return/iphone|ipad|ipod/i['test'](_0x1ddb1a)||/macintosh/i['test'](_0x1ddb1a)&&/mobile/i['test'](_0x1ddb1a);}function Rf(_0x23d18f=W()){var _0x44f0ec;return Ss(_0x23d18f)&&!!((_0x44f0ec=window['navigator'])!=null&&_0x44f0ec['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x538eb6=W()){return Ss(_0x538eb6)||Na(_0x538eb6)||Da(_0x538eb6)||Oa(_0x538eb6)||/windows phone/i['test'](_0x538eb6)||Pa(_0x538eb6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0xc426fb,_0x4928b9=[]){let _0x497186;switch(_0xc426fb){case'Browser':_0x497186=br(W());break;case'Worker':_0x497186=br(W())+'-'+_0xc426fb;break;default:_0x497186=_0xc426fb;}const _0x38004d=_0x4928b9['length']?_0x4928b9['join'](','):'FirebaseCore-web';return _0x497186+'/JsCore/'+dt+'/'+_0x38004d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4532c8){this['auth']=_0x4532c8,this['queue']=[];}['pushCallback'](_0x9d8b89,_0x2a0abf){const _0x4912c8=_0x30f4a6=>new Promise((_0x164d24,_0x10e2b4)=>{try{const _0xfcb8ad=_0x9d8b89(_0x30f4a6);_0x164d24(_0xfcb8ad);}catch(_0x1c5fee){_0x10e2b4(_0x1c5fee);}});_0x4912c8['onAbort']=_0x2a0abf,this['queue']['push'](_0x4912c8);const _0xb5cbce=this['queue']['length']-0x1;return()=>{this['queue'][_0xb5cbce]=()=>Promise['resolve']();};}async['runMiddleware'](_0x36e453){if(this['auth']['currentUser']===_0x36e453)return;const _0x22cfa2=[];try{for(const _0x128725 of this['queue'])await _0x128725(_0x36e453),_0x128725['onAbort']&&_0x22cfa2['push'](_0x128725['onAbort']);}catch(_0x29ca7f){_0x22cfa2['reverse']();for(const _0x5f546f of _0x22cfa2)try{_0x5f546f();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x29ca7f==null?void 0x0:_0x29ca7f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x518f49,_0x487e9e={}){return Pe(_0x518f49,'GET','/v2/passwordPolicy',ke(_0x518f49,_0x487e9e));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x26627c){var _0x5cf0d6;const _0x13b9fc=_0x26627c['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x13b9fc['minPasswordLength']??Nf,_0x13b9fc['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x13b9fc['maxPasswordLength']),_0x13b9fc['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x13b9fc['containsLowercaseCharacter']),_0x13b9fc['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x13b9fc['containsUppercaseCharacter']),_0x13b9fc['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x13b9fc['containsNumericCharacter']),_0x13b9fc['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x13b9fc['containsNonAlphanumericCharacter']),this['enforcementState']=_0x26627c['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x5cf0d6=_0x26627c['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x5cf0d6['join'](''))??'',this['forceUpgradeOnSignin']=_0x26627c['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x26627c['schemaVersion'];}['validatePassword'](_0x11aac3){const _0x4bcaee={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x11aac3,_0x4bcaee),this['validatePasswordCharacterOptions'](_0x11aac3,_0x4bcaee),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['meetsMinPasswordLength']??!0x0),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['meetsMaxPasswordLength']??!0x0),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['containsLowercaseLetter']??!0x0),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['containsUppercaseLetter']??!0x0),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['containsNumericCharacter']??!0x0),_0x4bcaee['isValid']&&(_0x4bcaee['isValid']=_0x4bcaee['containsNonAlphanumericCharacter']??!0x0),_0x4bcaee;}['validatePasswordLengthOptions'](_0x16ff28,_0x49d8de){const _0x1479f5=this['customStrengthOptions']['minPasswordLength'],_0x5b2604=this['customStrengthOptions']['maxPasswordLength'];_0x1479f5&&(_0x49d8de['meetsMinPasswordLength']=_0x16ff28['length']>=_0x1479f5),_0x5b2604&&(_0x49d8de['meetsMaxPasswordLength']=_0x16ff28['length']<=_0x5b2604);}['validatePasswordCharacterOptions'](_0x129210,_0x305324){this['updatePasswordCharacterOptionsStatuses'](_0x305324,!0x1,!0x1,!0x1,!0x1);let _0x3f9280;for(let _0x2d670a=0x0;_0x2d670a<_0x129210['length'];_0x2d670a++)_0x3f9280=_0x129210['charAt'](_0x2d670a),this['updatePasswordCharacterOptionsStatuses'](_0x305324,_0x3f9280>='a'&&_0x3f9280<='z',_0x3f9280>='A'&&_0x3f9280<='Z',_0x3f9280>='0'&&_0x3f9280<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3f9280));}['updatePasswordCharacterOptionsStatuses'](_0x175b93,_0x14f144,_0x373f27,_0x3d2e1b,_0x409a54){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x175b93['containsLowercaseLetter']||(_0x175b93['containsLowercaseLetter']=_0x14f144)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x175b93['containsUppercaseLetter']||(_0x175b93['containsUppercaseLetter']=_0x373f27)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x175b93['containsNumericCharacter']||(_0x175b93['containsNumericCharacter']=_0x3d2e1b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x175b93['containsNonAlphanumericCharacter']||(_0x175b93['containsNonAlphanumericCharacter']=_0x409a54));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x3ac2c5,_0x37cdcb,_0x165f46,_0x17cb40){this['app']=_0x3ac2c5,this['heartbeatServiceProvider']=_0x37cdcb,this['appCheckServiceProvider']=_0x165f46,this['config']=_0x17cb40,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3ac2c5['name'],this['clientVersion']=_0x17cb40['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x41aea5=>this['_resolvePersistenceManagerAvailable']=_0x41aea5);}['_initializeWithPersistence'](_0x1fdc6f,_0x24a8ae){return _0x24a8ae&&(this['_popupRedirectResolver']=ie(_0x24a8ae)),this['_initializationPromise']=this['queue'](async()=>{var _0x34113a,_0x571abe,_0x20d5d5;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x1fdc6f),(_0x34113a=this['_resolvePersistenceManagerAvailable'])==null||_0x34113a['call'](this),!this['_deleted'])){if((_0x571abe=this['_popupRedirectResolver'])!=null&&_0x571abe['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x24a8ae),this['lastNotifiedUid']=((_0x20d5d5=this['currentUser'])==null?void 0x0:_0x20d5d5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x58caff=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x58caff)){if(this['currentUser']&&_0x58caff&&this['currentUser']['uid']===_0x58caff['uid']){this['_currentUser']['_assign'](_0x58caff),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x58caff,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x29d8a0){try{const _0x3a301a=await Pn(this,{'idToken':_0x29d8a0}),_0x13d0c9=await j['_fromGetAccountInfoResponse'](this,_0x3a301a,_0x29d8a0);await this['directlySetCurrentUser'](_0x13d0c9);}catch(_0x46756f){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x46756f),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5f4aba){var _0x3442fe;if($(this['app'])){const _0x2195bb=this['app']['settings']['authIdToken'];return _0x2195bb?new Promise(_0x172891=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2195bb)['then'](_0x172891,_0x172891));}):this['directlySetCurrentUser'](null);}const _0x419d2d=await this['assertedPersistence']['getCurrentUser']();let _0x2f00c2=_0x419d2d,_0xf76e10=!0x1;if(_0x5f4aba&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3bfe52=(_0x3442fe=this['redirectUser'])==null?void 0x0:_0x3442fe['_redirectEventId'],_0x3ae564=_0x2f00c2==null?void 0x0:_0x2f00c2['_redirectEventId'],_0x27b5a7=await this['tryRedirectSignIn'](_0x5f4aba);(!_0x3bfe52||_0x3bfe52===_0x3ae564)&&(_0x27b5a7!=null&&_0x27b5a7['user'])&&(_0x2f00c2=_0x27b5a7['user'],_0xf76e10=!0x0);}if(!_0x2f00c2)return this['directlySetCurrentUser'](null);if(!_0x2f00c2['_redirectEventId']){if(_0xf76e10)try{await this['beforeStateQueue']['runMiddleware'](_0x2f00c2);}catch(_0x53eefd){_0x2f00c2=_0x419d2d,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x53eefd));}return _0x2f00c2?this['reloadAndSetCurrentUserOrClear'](_0x2f00c2):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2f00c2['_redirectEventId']?this['directlySetCurrentUser'](_0x2f00c2):this['reloadAndSetCurrentUserOrClear'](_0x2f00c2);}async['tryRedirectSignIn'](_0x22da59){let _0x42d81b=null;try{_0x42d81b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x22da59,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x42d81b;}async['reloadAndSetCurrentUserOrClear'](_0x88fde1){try{await Nn(_0x88fde1);}catch(_0x4bdc6b){if((_0x4bdc6b==null?void 0x0:_0x4bdc6b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x88fde1);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x33c276){if($(this['app']))return Promise['reject'](re(this));const _0x44969e=_0x33c276?P(_0x33c276):null;return _0x44969e&&m(_0x44969e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x44969e&&_0x44969e['_clone'](this));}async['_updateCurrentUser'](_0x1d816a,_0x117dc6=!0x1){if(!this['_deleted'])return _0x1d816a&&m(this['tenantId']===_0x1d816a['tenantId'],this,'tenant-id-mismatch'),_0x117dc6||await this['beforeStateQueue']['runMiddleware'](_0x1d816a),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1d816a),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xe0e2a9){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xe0e2a9));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x24d2fb){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x54c766=this['_getPasswordPolicyInternal']();return _0x54c766['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x54c766['validatePassword'](_0x24d2fb);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2ec25c=await Pf(this),_0x10f7c8=new Of(_0x2ec25c);this['tenantId']===null?this['_projectPasswordPolicy']=_0x10f7c8:this['_tenantPasswordPolicies'][this['tenantId']]=_0x10f7c8;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x1ea86d){this['_errorFactory']=new Gt('auth','Firebase',_0x1ea86d());}['onAuthStateChanged'](_0x2c595b,_0x59fcf1,_0x2c80a8){return this['registerStateListener'](this['authStateSubscription'],_0x2c595b,_0x59fcf1,_0x2c80a8);}['beforeAuthStateChanged'](_0xb88049,_0x40203a){return this['beforeStateQueue']['pushCallback'](_0xb88049,_0x40203a);}['onIdTokenChanged'](_0x367032,_0x5d8b84,_0x4e727c){return this['registerStateListener'](this['idTokenSubscription'],_0x367032,_0x5d8b84,_0x4e727c);}['authStateReady'](){return new Promise((_0x1a21d1,_0x3f457b)=>{if(this['currentUser'])_0x1a21d1();else{const _0x530e5e=this['onAuthStateChanged'](()=>{_0x530e5e(),_0x1a21d1();},_0x3f457b);}});}async['revokeAccessToken'](_0x2970cd){if(this['currentUser']){const _0x12894c=await this['currentUser']['getIdToken'](),_0x3383d5={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2970cd,'idToken':_0x12894c};this['tenantId']!=null&&(_0x3383d5['tenantId']=this['tenantId']),await bf(this,_0x3383d5);}}['toJSON'](){var _0x51a153;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x51a153=this['_currentUser'])==null?void 0x0:_0x51a153['toJSON']()};}async['_setRedirectUser'](_0x4d8662,_0x3efefa){const _0x175f84=await this['getOrInitRedirectPersistenceManager'](_0x3efefa);return _0x4d8662===null?_0x175f84['removeCurrentUser']():_0x175f84['setCurrentUser'](_0x4d8662);}async['getOrInitRedirectPersistenceManager'](_0x18a164){if(!this['redirectPersistenceManager']){const _0x3404d4=_0x18a164&&ie(_0x18a164)||this['_popupRedirectResolver'];m(_0x3404d4,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3404d4['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5e1a8a){var _0x2e3a6e,_0x5d8d82;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2e3a6e=this['_currentUser'])==null?void 0x0:_0x2e3a6e['_redirectEventId'])===_0x5e1a8a?this['_currentUser']:((_0x5d8d82=this['redirectUser'])==null?void 0x0:_0x5d8d82['_redirectEventId'])===_0x5e1a8a?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x556d73){if(_0x556d73===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x556d73));}['_notifyListenersIfCurrent'](_0x4ac5cf){_0x4ac5cf===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x512669;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x826586=((_0x512669=this['currentUser'])==null?void 0x0:_0x512669['uid'])??null;this['lastNotifiedUid']!==_0x826586&&(this['lastNotifiedUid']=_0x826586,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1d3986,_0x1eb695,_0xcc4f15,_0x58e6bc){if(this['_deleted'])return()=>{};const _0x4f2e52=typeof _0x1eb695=='function'?_0x1eb695:_0x1eb695['next']['bind'](_0x1eb695);let _0x54a1e2=!0x1;const _0x2d9bb2=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2d9bb2,this,'internal-error'),_0x2d9bb2['then'](()=>{_0x54a1e2||_0x4f2e52(this['currentUser']);}),typeof _0x1eb695=='function'){const _0x3d8b7e=_0x1d3986['addObserver'](_0x1eb695,_0xcc4f15,_0x58e6bc);return()=>{_0x54a1e2=!0x0,_0x3d8b7e();};}else{const _0x2e352c=_0x1d3986['addObserver'](_0x1eb695);return()=>{_0x54a1e2=!0x0,_0x2e352c();};}}async['directlySetCurrentUser'](_0x4807bd){this['currentUser']&&this['currentUser']!==_0x4807bd&&this['_currentUser']['_stopProactiveRefresh'](),_0x4807bd&&this['isProactiveRefreshEnabled']&&_0x4807bd['_startProactiveRefresh'](),this['currentUser']=_0x4807bd,_0x4807bd?await this['assertedPersistence']['setCurrentUser'](_0x4807bd):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x6a0c8c){return this['operations']=this['operations']['then'](_0x6a0c8c,_0x6a0c8c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x2bdcf0){!_0x2bdcf0||this['frameworks']['includes'](_0x2bdcf0)||(this['frameworks']['push'](_0x2bdcf0),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x507d19;const _0x423388={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x423388['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x34f3a0=await((_0x507d19=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x507d19['getHeartbeatsHeader']());_0x34f3a0&&(_0x423388['X-Firebase-Client']=_0x34f3a0);const _0x51c7d2=await this['_getAppCheckToken']();return _0x51c7d2&&(_0x423388['X-Firebase-AppCheck']=_0x51c7d2),_0x423388;}async['_getAppCheckToken'](){var _0x43714a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5ecd7c=await((_0x43714a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x43714a['getToken']());return _0x5ecd7c!=null&&_0x5ecd7c['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5ecd7c['error']),_0x5ecd7c==null?void 0x0:_0x5ecd7c['token'];}}function Ke(_0x5d07fb){return P(_0x5d07fb);}class Rr{constructor(_0x110f5b){this['auth']=_0x110f5b,this['observer']=null,this['addObserver']=Tc(_0x5c8099=>this['observer']=_0x5c8099);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x3ddb3c){Jn=_0x3ddb3c;}function xa(_0xe13745){return Jn['loadJS'](_0xe13745);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x4a1361){return'__'+_0x4a1361+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x12df0e){_0x12df0e();}['execute'](_0x711334,_0x14ff58){return Promise['resolve']('token');}['render'](_0x31e5ae,_0x2d9f9e){return'';}}class Wf{['ready'](_0x39a07f){_0x39a07f();}['execute'](_0x2c0124,_0x5b7aa4){return Promise['resolve']('token');}['render'](_0x69035b,_0x4eaac5){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x578630){this['type']=Bf,this['auth']=Ke(_0x578630);}async['verify'](_0x3a0879='verify',_0x3cfd15=!0x1){async function _0x180dcd(_0x29463c){if(!_0x3cfd15){if(_0x29463c['tenantId']==null&&_0x29463c['_agentRecaptchaConfig']!=null)return _0x29463c['_agentRecaptchaConfig']['siteKey'];if(_0x29463c['tenantId']!=null&&_0x29463c['_tenantRecaptchaConfigs'][_0x29463c['tenantId']]!==void 0x0)return _0x29463c['_tenantRecaptchaConfigs'][_0x29463c['tenantId']]['siteKey'];}return new Promise(async(_0xd4317a,_0x5f063a)=>{yf(_0x29463c,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x28c408=>{if(_0x28c408['recaptchaKey']===void 0x0)_0x5f063a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2c4f04=new mf(_0x28c408);return _0x29463c['tenantId']==null?_0x29463c['_agentRecaptchaConfig']=_0x2c4f04:_0x29463c['_tenantRecaptchaConfigs'][_0x29463c['tenantId']]=_0x2c4f04,_0xd4317a(_0x2c4f04['siteKey']);}})['catch'](_0x1382bb=>{_0x5f063a(_0x1382bb);});});}function _0x9b3ac6(_0x56a32f,_0x18f875,_0xdc2e69){const _0x34f10d=window['grecaptcha'];wr(_0x34f10d)?_0x34f10d['enterprise']['ready'](()=>{_0x34f10d['enterprise']['execute'](_0x56a32f,{'action':_0x3a0879})['then'](_0x4ab1d7=>{_0x18f875(_0x4ab1d7);})['catch'](()=>{_0x18f875(Fa);});}):_0xdc2e69(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x18c127,_0x304154)=>{_0x180dcd(this['auth'])['then'](async _0x56b3a4=>{if(!_0x3cfd15&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x9b3ac6(_0x56b3a4,_0x18c127,_0x304154);else{if(typeof window>'u'){_0x304154(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5dbfe5=Lf();_0x5dbfe5['length']!==0x0&&(_0x5dbfe5+=_0x56b3a4+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x1193b3;(_0x1193b3=he['scriptInjectionDeferred'])==null||_0x1193b3['resolve']();},xa(_0x5dbfe5)['then'](()=>{var _0x1c137e;return(_0x1c137e=he['scriptInjectionDeferred'])==null?void 0x0:_0x1c137e['promise'];})['then'](()=>{_0x9b3ac6(_0x56b3a4,_0x18c127,_0x304154);})['catch'](_0x6e4b48=>{_0x304154(_0x6e4b48);});}})['catch'](_0x2d7347=>{_0x304154(_0x2d7347);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x4bd691,_0xbc5dc8,_0x2016e8,_0x3cd3c8=!0x1,_0x4913a0=!0x1){const _0x14a196=new he(_0x4bd691);let _0x37a02d;if(_0x4913a0)_0x37a02d=Fa;else try{_0x37a02d=await _0x14a196['verify'](_0x2016e8);}catch{_0x37a02d=await _0x14a196['verify'](_0x2016e8,!0x0);}const _0x15391f={..._0xbc5dc8};if(_0x2016e8==='mfaSmsEnrollment'||_0x2016e8==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x15391f){const _0x448d60=_0x15391f['phoneEnrollmentInfo']['phoneNumber'],_0x45ac1d=_0x15391f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x15391f,{'phoneEnrollmentInfo':{'phoneNumber':_0x448d60,'recaptchaToken':_0x45ac1d,'captchaResponse':_0x37a02d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x15391f){const _0x1753ad=_0x15391f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x15391f,{'phoneSignInInfo':{'recaptchaToken':_0x1753ad,'captchaResponse':_0x37a02d,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x15391f;}return _0x3cd3c8?Object['assign'](_0x15391f,{'captchaResp':_0x37a02d}):Object['assign'](_0x15391f,{'captchaResponse':_0x37a02d}),Object['assign'](_0x15391f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x15391f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x15391f;}async function xi(_0x4e273b,_0x3381f9,_0x1c0e16,_0x2b60a1,_0x59979c){var _0x1eb29d;if((_0x1eb29d=_0x4e273b['_getRecaptchaConfig']())!=null&&_0x1eb29d['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0xc9e5c2=await kr(_0x4e273b,_0x3381f9,_0x1c0e16,_0x1c0e16==='getOobCode');return _0x2b60a1(_0x4e273b,_0xc9e5c2);}else return _0x2b60a1(_0x4e273b,_0x3381f9)['catch'](async _0x490c59=>{if(_0x490c59['code']==='auth/missing-recaptcha-token'){console['log'](_0x1c0e16+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x35c506=await kr(_0x4e273b,_0x3381f9,_0x1c0e16,_0x1c0e16==='getOobCode');return _0x2b60a1(_0x4e273b,_0x35c506);}else return Promise['reject'](_0x490c59);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x20b175,_0x528908){const _0x36942b=Hi(_0x20b175,'auth');if(_0x36942b['isInitialized']()){const _0x455142=_0x36942b['getImmediate'](),_0x549ea2=_0x36942b['getOptions']();if(xe(_0x549ea2,_0x528908??{}))return _0x455142;Y(_0x455142,'already-initialized');}return _0x36942b['initialize']({'options':_0x528908});}function Hf(_0x439e9d,_0x171975){const _0x228d27=(_0x171975==null?void 0x0:_0x171975['persistence'])||[],_0x864ea8=(Array['isArray'](_0x228d27)?_0x228d27:[_0x228d27])['map'](ie);_0x171975!=null&&_0x171975['errorMap']&&_0x439e9d['_updateErrorMap'](_0x171975['errorMap']),_0x439e9d['_initializeWithPersistence'](_0x864ea8,_0x171975==null?void 0x0:_0x171975['popupRedirectResolver']);}function $f(_0x3de147,_0x426ff0,_0x3d8113){const _0x389e9e=Ke(_0x3de147);m(/^https?:\/\//['test'](_0x426ff0),_0x389e9e,'invalid-emulator-scheme');const _0x4af96c=!0x1,_0x33a7e4=Ua(_0x426ff0),{host:_0x4b3d07,port:_0x6baf18}=Gf(_0x426ff0),_0x21a721=_0x6baf18===null?'':':'+_0x6baf18,_0x48c02d={'url':_0x33a7e4+'//'+_0x4b3d07+_0x21a721+'/'},_0x7756e1=Object['freeze']({'host':_0x4b3d07,'port':_0x6baf18,'protocol':_0x33a7e4['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4af96c})});if(!_0x389e9e['_canInitEmulator']){m(_0x389e9e['config']['emulator']&&_0x389e9e['emulatorConfig'],_0x389e9e,'emulator-config-failed'),m(xe(_0x48c02d,_0x389e9e['config']['emulator'])&&xe(_0x7756e1,_0x389e9e['emulatorConfig']),_0x389e9e,'emulator-config-failed');return;}_0x389e9e['config']['emulator']=_0x48c02d,_0x389e9e['emulatorConfig']=_0x7756e1,_0x389e9e['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x4b3d07)?Qr(_0x33a7e4+'//'+_0x4b3d07+_0x21a721):qf();}function Ua(_0x203abc){const _0x191c63=_0x203abc['indexOf'](':');return _0x191c63<0x0?'':_0x203abc['substr'](0x0,_0x191c63+0x1);}function Gf(_0x352005){const _0x436d0e=Ua(_0x352005),_0x17e622=/(\/\/)?([^?#/]+)/['exec'](_0x352005['substr'](_0x436d0e['length']));if(!_0x17e622)return{'host':'','port':null};const _0x3ed6a8=_0x17e622[0x2]['split']('@')['pop']()||'',_0x44064e=/^(\[[^\]]+\])(:|$)/['exec'](_0x3ed6a8);if(_0x44064e){const _0x1c414f=_0x44064e[0x1];return{'host':_0x1c414f,'port':Pr(_0x3ed6a8['substr'](_0x1c414f['length']+0x1))};}else{const [_0x56c315,_0x4fa7ff]=_0x3ed6a8['split'](':');return{'host':_0x56c315,'port':Pr(_0x4fa7ff)};}}function Pr(_0x3e75a2){if(!_0x3e75a2)return null;const _0x5b10b1=Number(_0x3e75a2);return isNaN(_0x5b10b1)?null:_0x5b10b1;}function qf(){function _0x18c008(){const _0x45565a=document['createElement']('p'),_0xb23710=_0x45565a['style'];_0x45565a['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xb23710['position']='fixed',_0xb23710['width']='100%',_0xb23710['backgroundColor']='#ffffff',_0xb23710['border']='.1em\x20solid\x20#000000',_0xb23710['color']='#b50000',_0xb23710['bottom']='0px',_0xb23710['left']='0px',_0xb23710['margin']='0px',_0xb23710['zIndex']='10000',_0xb23710['textAlign']='center',_0x45565a['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x45565a);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x18c008):_0x18c008());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x438326,_0x45be9b){this['providerId']=_0x438326,this['signInMethod']=_0x45be9b;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4e3d14){return ne('not\x20implemented');}['_linkToIdToken'](_0x3bb041,_0x3fa783){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x17ffdb){return ne('not\x20implemented');}}async function zf(_0x1d1894,_0x5f1f53){return Pe(_0x1d1894,'POST','/v1/accounts:signUp',_0x5f1f53);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x33c257,_0x52e8cd){return en(_0x33c257,'POST','/v1/accounts:signInWithPassword',ke(_0x33c257,_0x52e8cd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x29dd7f,_0x5de920){return en(_0x29dd7f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x29dd7f,_0x5de920));}async function Yf(_0x3e5194,_0xe852b3){return en(_0x3e5194,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3e5194,_0xe852b3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x3da695,_0x5bc5ec,_0x4dc7f1,_0x4e994b=null){super('password',_0x4dc7f1),this['_email']=_0x3da695,this['_password']=_0x5bc5ec,this['_tenantId']=_0x4e994b;}static['_fromEmailAndPassword'](_0x193401,_0x7c5c15){return new $t(_0x193401,_0x7c5c15,'password');}static['_fromEmailAndCode'](_0xad7060,_0x23e7fb,_0x590e38=null){return new $t(_0xad7060,_0x23e7fb,'emailLink',_0x590e38);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x34126a){const _0x4881f6=typeof _0x34126a=='string'?JSON['parse'](_0x34126a):_0x34126a;if(_0x4881f6!=null&&_0x4881f6['email']&&(_0x4881f6!=null&&_0x4881f6['password'])){if(_0x4881f6['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4881f6['email'],_0x4881f6['password']);if(_0x4881f6['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4881f6['email'],_0x4881f6['password'],_0x4881f6['tenantId']);}return null;}async['_getIdTokenResponse'](_0x28bf8d){switch(this['signInMethod']){case'password':const _0x2844e8={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x28bf8d,_0x2844e8,'signInWithPassword',jf);case'emailLink':return Kf(_0x28bf8d,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x28bf8d,'internal-error');}}async['_linkToIdToken'](_0x2a77a1,_0x11aa9f){switch(this['signInMethod']){case'password':const _0x13ce95={'idToken':_0x11aa9f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2a77a1,_0x13ce95,'signUpPassword',zf);case'emailLink':return Yf(_0x2a77a1,{'idToken':_0x11aa9f,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2a77a1,'internal-error');}}['_getReauthenticationResolver'](_0x57a397){return this['_getIdTokenResponse'](_0x57a397);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2a99ab,_0xc2d51d){return en(_0x2a99ab,'POST','/v1/accounts:signInWithIdp',ke(_0x2a99ab,_0xc2d51d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3f0545){const _0x30770d=new $e(_0x3f0545['providerId'],_0x3f0545['signInMethod']);return _0x3f0545['idToken']||_0x3f0545['accessToken']?(_0x3f0545['idToken']&&(_0x30770d['idToken']=_0x3f0545['idToken']),_0x3f0545['accessToken']&&(_0x30770d['accessToken']=_0x3f0545['accessToken']),_0x3f0545['nonce']&&!_0x3f0545['pendingToken']&&(_0x30770d['nonce']=_0x3f0545['nonce']),_0x3f0545['pendingToken']&&(_0x30770d['pendingToken']=_0x3f0545['pendingToken'])):_0x3f0545['oauthToken']&&_0x3f0545['oauthTokenSecret']?(_0x30770d['accessToken']=_0x3f0545['oauthToken'],_0x30770d['secret']=_0x3f0545['oauthTokenSecret']):Y('argument-error'),_0x30770d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x592fa7){const _0x294fd8=typeof _0x592fa7=='string'?JSON['parse'](_0x592fa7):_0x592fa7,{providerId:_0x127e30,signInMethod:_0x144850,..._0x1a2b99}=_0x294fd8;if(!_0x127e30||!_0x144850)return null;const _0x1f0ae4=new $e(_0x127e30,_0x144850);return _0x1f0ae4['idToken']=_0x1a2b99['idToken']||void 0x0,_0x1f0ae4['accessToken']=_0x1a2b99['accessToken']||void 0x0,_0x1f0ae4['secret']=_0x1a2b99['secret'],_0x1f0ae4['nonce']=_0x1a2b99['nonce'],_0x1f0ae4['pendingToken']=_0x1a2b99['pendingToken']||null,_0x1f0ae4;}['_getIdTokenResponse'](_0x3035d9){const _0x2179e3=this['buildRequest']();return nt(_0x3035d9,_0x2179e3);}['_linkToIdToken'](_0x3767b7,_0x19e7d9){const _0x48c4cb=this['buildRequest']();return _0x48c4cb['idToken']=_0x19e7d9,nt(_0x3767b7,_0x48c4cb);}['_getReauthenticationResolver'](_0x1b61ea){const _0x3f9be1=this['buildRequest']();return _0x3f9be1['autoCreate']=!0x1,nt(_0x1b61ea,_0x3f9be1);}['buildRequest'](){const _0xcda97b={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0xcda97b['pendingToken']=this['pendingToken'];else{const _0x36e578={};this['idToken']&&(_0x36e578['id_token']=this['idToken']),this['accessToken']&&(_0x36e578['access_token']=this['accessToken']),this['secret']&&(_0x36e578['oauth_token_secret']=this['secret']),_0x36e578['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x36e578['nonce']=this['nonce']),_0xcda97b['postBody']=ut(_0x36e578);}return _0xcda97b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x7e1097){switch(_0x7e1097){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x5bce7a){const _0x1de722=Ct(Tt(_0x5bce7a))['link'],_0x57c101=_0x1de722?Ct(Tt(_0x1de722))['deep_link_id']:null,_0x1417ac=Ct(Tt(_0x5bce7a))['deep_link_id'];return(_0x1417ac?Ct(Tt(_0x1417ac))['link']:null)||_0x1417ac||_0x57c101||_0x1de722||_0x5bce7a;}class Rs{constructor(_0x3c3ee9){const _0x2f5172=Ct(Tt(_0x3c3ee9)),_0x33ea0f=_0x2f5172['apiKey']??null,_0x537f5f=_0x2f5172['oobCode']??null,_0x5923e2=Jf(_0x2f5172['mode']??null);m(_0x33ea0f&&_0x537f5f&&_0x5923e2,'argument-error'),this['apiKey']=_0x33ea0f,this['operation']=_0x5923e2,this['code']=_0x537f5f,this['continueUrl']=_0x2f5172['continueUrl']??null,this['languageCode']=_0x2f5172['lang']??null,this['tenantId']=_0x2f5172['tenantId']??null;}static['parseLink'](_0x5db2c8){const _0x14420f=Xf(_0x5db2c8);try{return new Rs(_0x14420f);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x26d4f,_0x2452b6){return $t['_fromEmailAndPassword'](_0x26d4f,_0x2452b6);}static['credentialWithLink'](_0x362a11,_0x54f2a8){const _0x4fa9c8=Rs['parseLink'](_0x54f2a8);return m(_0x4fa9c8,'argument-error'),$t['_fromEmailAndCode'](_0x362a11,_0x4fa9c8['code'],_0x4fa9c8['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x56cff5){this['providerId']=_0x56cff5,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x507332){this['defaultLanguageCode']=_0x507332;}['setCustomParameters'](_0x513d62){return this['customParameters']=_0x513d62,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x539b77){return this['scopes']['includes'](_0x539b77)||this['scopes']['push'](_0x539b77),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2cdaf3){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2cdaf3});}static['credentialFromResult'](_0xbfb4d){return ue['credentialFromTaggedObject'](_0xbfb4d);}static['credentialFromError'](_0x5c3768){return ue['credentialFromTaggedObject'](_0x5c3768['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xddd664}){if(!_0xddd664||!('oauthAccessToken'in _0xddd664)||!_0xddd664['oauthAccessToken'])return null;try{return ue['credential'](_0xddd664['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x26bb5f,_0x46f875){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x26bb5f,'accessToken':_0x46f875});}static['credentialFromResult'](_0x251945){return de['credentialFromTaggedObject'](_0x251945);}static['credentialFromError'](_0x3ad43e){return de['credentialFromTaggedObject'](_0x3ad43e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3a4c07}){if(!_0x3a4c07)return null;const {oauthIdToken:_0x2c5054,oauthAccessToken:_0x4d2447}=_0x3a4c07;if(!_0x2c5054&&!_0x4d2447)return null;try{return de['credential'](_0x2c5054,_0x4d2447);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x34d7fb){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x34d7fb});}static['credentialFromResult'](_0x4535aa){return fe['credentialFromTaggedObject'](_0x4535aa);}static['credentialFromError'](_0x2879b4){return fe['credentialFromTaggedObject'](_0x2879b4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5564c8}){if(!_0x5564c8||!('oauthAccessToken'in _0x5564c8)||!_0x5564c8['oauthAccessToken'])return null;try{return fe['credential'](_0x5564c8['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3b748f,_0xe0dd4b){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3b748f,'oauthTokenSecret':_0xe0dd4b});}static['credentialFromResult'](_0x12d384){return pe['credentialFromTaggedObject'](_0x12d384);}static['credentialFromError'](_0x132b5e){return pe['credentialFromTaggedObject'](_0x132b5e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2e496f}){if(!_0x2e496f)return null;const {oauthAccessToken:_0x2e6226,oauthTokenSecret:_0x2a950d}=_0x2e496f;if(!_0x2e6226||!_0x2a950d)return null;try{return pe['credential'](_0x2e6226,_0x2a950d);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x182c84,_0x3a043b){return en(_0x182c84,'POST','/v1/accounts:signUp',ke(_0x182c84,_0x3a043b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x3e9eee){this['user']=_0x3e9eee['user'],this['providerId']=_0x3e9eee['providerId'],this['_tokenResponse']=_0x3e9eee['_tokenResponse'],this['operationType']=_0x3e9eee['operationType'];}static async['_fromIdTokenResponse'](_0x11fa04,_0xf54412,_0x22f091,_0x5d74c1=!0x1){const _0x2f6ed0=await j['_fromIdTokenResponse'](_0x11fa04,_0x22f091,_0x5d74c1),_0x42463f=Nr(_0x22f091);return new Ge({'user':_0x2f6ed0,'providerId':_0x42463f,'_tokenResponse':_0x22f091,'operationType':_0xf54412});}static async['_forOperation'](_0x478ac7,_0x50ddbd,_0xb112ee){await _0x478ac7['_updateTokensIfNecessary'](_0xb112ee,!0x0);const _0x30f707=Nr(_0xb112ee);return new Ge({'user':_0x478ac7,'providerId':_0x30f707,'_tokenResponse':_0xb112ee,'operationType':_0x50ddbd});}}function Nr(_0x673cee){return _0x673cee['providerId']?_0x673cee['providerId']:'phoneNumber'in _0x673cee?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x3cf8fe,_0x2a0213,_0x253cd4,_0x55d8f5){super(_0x2a0213['code'],_0x2a0213['message']),this['operationType']=_0x253cd4,this['user']=_0x55d8f5,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x3cf8fe['name'],'tenantId':_0x3cf8fe['tenantId']??void 0x0,'_serverResponse':_0x2a0213['customData']['_serverResponse'],'operationType':_0x253cd4};}static['_fromErrorAndOperation'](_0x3d0577,_0x5754c2,_0x337acb,_0x4fd8f1){return new On(_0x3d0577,_0x5754c2,_0x337acb,_0x4fd8f1);}}function Ba(_0x17a1f5,_0x17ba00,_0x476044,_0x3a3c07){return(_0x17ba00==='reauthenticate'?_0x476044['_getReauthenticationResolver'](_0x17a1f5):_0x476044['_getIdTokenResponse'](_0x17a1f5))['catch'](_0xaf2aaf=>{throw _0xaf2aaf['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x17a1f5,_0xaf2aaf,_0x17ba00,_0x3a3c07):_0xaf2aaf;});}async function ep(_0x3d1a4d,_0x19ace0,_0x17c78e=!0x1){const _0x1958c6=await Ht(_0x3d1a4d,_0x19ace0['_linkToIdToken'](_0x3d1a4d['auth'],await _0x3d1a4d['getIdToken']()),_0x17c78e);return Ge['_forOperation'](_0x3d1a4d,'link',_0x1958c6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3d0e81,_0x2c562c,_0x5158cf=!0x1){const {auth:_0x11f957}=_0x3d0e81;if($(_0x11f957['app']))return Promise['reject'](re(_0x11f957));const _0xa86e86='reauthenticate';try{const _0x205c16=await Ht(_0x3d0e81,Ba(_0x11f957,_0xa86e86,_0x2c562c,_0x3d0e81),_0x5158cf);m(_0x205c16['idToken'],_0x11f957,'internal-error');const _0x3de8a3=Ts(_0x205c16['idToken']);m(_0x3de8a3,_0x11f957,'internal-error');const {sub:_0x272c3e}=_0x3de8a3;return m(_0x3d0e81['uid']===_0x272c3e,_0x11f957,'user-mismatch'),Ge['_forOperation'](_0x3d0e81,_0xa86e86,_0x205c16);}catch(_0x44582e){throw(_0x44582e==null?void 0x0:_0x44582e['code'])==='auth/user-not-found'&&Y(_0x11f957,'user-mismatch'),_0x44582e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0xde11b1,_0x177d9c,_0x2d0cdb=!0x1){if($(_0xde11b1['app']))return Promise['reject'](re(_0xde11b1));const _0x235e08='signIn',_0x50a6d3=await Ba(_0xde11b1,_0x235e08,_0x177d9c),_0x419a6c=await Ge['_fromIdTokenResponse'](_0xde11b1,_0x235e08,_0x50a6d3);return _0x2d0cdb||await _0xde11b1['_updateCurrentUser'](_0x419a6c['user']),_0x419a6c;}async function np(_0x5a37a4,_0xf815f4){return Va(Ke(_0x5a37a4),_0xf815f4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4074af){const _0x53f86c=Ke(_0x4074af);_0x53f86c['_getPasswordPolicyInternal']()&&await _0x53f86c['_updatePasswordPolicy']();}async function L_(_0x11f0f0,_0x59c8fa,_0x506059){if($(_0x11f0f0['app']))return Promise['reject'](re(_0x11f0f0));const _0x593307=Ke(_0x11f0f0),_0x2a02a1=await xi(_0x593307,{'returnSecureToken':!0x0,'email':_0x59c8fa,'password':_0x506059,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x9589a6=>{throw _0x9589a6['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x11f0f0),_0x9589a6;}),_0x35b437=await Ge['_fromIdTokenResponse'](_0x593307,'signIn',_0x2a02a1);return await _0x593307['_updateCurrentUser'](_0x35b437['user']),_0x35b437;}function x_(_0x522e60,_0x158bb7,_0x17fc09){return $(_0x522e60['app'])?Promise['reject'](re(_0x522e60)):np(P(_0x522e60),yt['credential'](_0x158bb7,_0x17fc09))['catch'](async _0x59a9d0=>{throw _0x59a9d0['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x522e60),_0x59a9d0;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2326d3,_0x5af757){return P(_0x2326d3)['setPersistence'](_0x5af757);}function ip(_0x3c28bd,_0x2bd079,_0x23076e,_0x457e6d){return P(_0x3c28bd)['onIdTokenChanged'](_0x2bd079,_0x23076e,_0x457e6d);}function sp(_0x5bacb8,_0x1bb659,_0x8936d7){return P(_0x5bacb8)['beforeAuthStateChanged'](_0x1bb659,_0x8936d7);}function U_(_0x574abf,_0x5240a7,_0x19d902,_0x38fc05){return P(_0x574abf)['onAuthStateChanged'](_0x5240a7,_0x19d902,_0x38fc05);}function W_(_0x39913e){return P(_0x39913e)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x17eed8,_0x50c828){this['storageRetriever']=_0x17eed8,this['type']=_0x50c828;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1ab2d6,_0x42a5fa){return this['storage']['setItem'](_0x1ab2d6,JSON['stringify'](_0x42a5fa)),Promise['resolve']();}['_get'](_0x52f173){const _0x7f7573=this['storage']['getItem'](_0x52f173);return Promise['resolve'](_0x7f7573?JSON['parse'](_0x7f7573):null);}['_remove'](_0x14c9cd){return this['storage']['removeItem'](_0x14c9cd),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4b812e,_0x5000e7)=>this['onStorageEvent'](_0x4b812e,_0x5000e7),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x360897){for(const _0x381b5b of Object['keys'](this['listeners'])){const _0xba520a=this['storage']['getItem'](_0x381b5b),_0xbdf99f=this['localCache'][_0x381b5b];_0xba520a!==_0xbdf99f&&_0x360897(_0x381b5b,_0xbdf99f,_0xba520a);}}['onStorageEvent'](_0x228654,_0x23c851=!0x1){if(!_0x228654['key']){this['forAllChangedKeys']((_0x4399ba,_0x355b1f,_0x5a8c5e)=>{this['notifyListeners'](_0x4399ba,_0x5a8c5e);});return;}const _0x5e5e79=_0x228654['key'];_0x23c851?this['detachListener']():this['stopPolling']();const _0x3f6385=()=>{const _0x4e62ab=this['storage']['getItem'](_0x5e5e79);!_0x23c851&&this['localCache'][_0x5e5e79]===_0x4e62ab||this['notifyListeners'](_0x5e5e79,_0x4e62ab);},_0x3bf1f5=this['storage']['getItem'](_0x5e5e79);Af()&&_0x3bf1f5!==_0x228654['newValue']&&_0x228654['newValue']!==_0x228654['oldValue']?setTimeout(_0x3f6385,op):_0x3f6385();}['notifyListeners'](_0xd75170,_0x409260){this['localCache'][_0xd75170]=_0x409260;const _0x3290aa=this['listeners'][_0xd75170];if(_0x3290aa){for(const _0x5a65dc of Array['from'](_0x3290aa))_0x5a65dc(_0x409260&&JSON['parse'](_0x409260));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3bcef2,_0x2e1bae,_0x56ccca)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3bcef2,'oldValue':_0x2e1bae,'newValue':_0x56ccca}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4caa68,_0x5cf291){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4caa68]||(this['listeners'][_0x4caa68]=new Set(),this['localCache'][_0x4caa68]=this['storage']['getItem'](_0x4caa68)),this['listeners'][_0x4caa68]['add'](_0x5cf291);}['_removeListener'](_0xe6efb4,_0x5ca2ab){this['listeners'][_0xe6efb4]&&(this['listeners'][_0xe6efb4]['delete'](_0x5ca2ab),this['listeners'][_0xe6efb4]['size']===0x0&&delete this['listeners'][_0xe6efb4]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x439c3f,_0x2216de){await super['_set'](_0x439c3f,_0x2216de),this['localCache'][_0x439c3f]=JSON['stringify'](_0x2216de);}async['_get'](_0x29b0ed){const _0x3f5eb4=await super['_get'](_0x29b0ed);return this['localCache'][_0x29b0ed]=JSON['stringify'](_0x3f5eb4),_0x3f5eb4;}async['_remove'](_0x3c0fd2){await super['_remove'](_0x3c0fd2),delete this['localCache'][_0x3c0fd2];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x571711,_0x2088de){}['_removeListener'](_0x5ba927,_0x5804d1){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x331aa0){return Promise['all'](_0x331aa0['map'](async _0x471ce2=>{try{return{'fulfilled':!0x0,'value':await _0x471ce2};}catch(_0x3af843){return{'fulfilled':!0x1,'reason':_0x3af843};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x5adef7){this['eventTarget']=_0x5adef7,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x437860){const _0x4ef81a=this['receivers']['find'](_0x1bef16=>_0x1bef16['isListeningto'](_0x437860));if(_0x4ef81a)return _0x4ef81a;const _0x49c864=new Xn(_0x437860);return this['receivers']['push'](_0x49c864),_0x49c864;}['isListeningto'](_0x45bc4e){return this['eventTarget']===_0x45bc4e;}async['handleEvent'](_0x4c5407){const _0x4b94bc=_0x4c5407,{eventId:_0x5862c4,eventType:_0x3d69ae,data:_0x639fcd}=_0x4b94bc['data'],_0x4127d4=this['handlersMap'][_0x3d69ae];if(!(_0x4127d4!=null&&_0x4127d4['size']))return;_0x4b94bc['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5862c4,'eventType':_0x3d69ae});const _0x14b4d1=Array['from'](_0x4127d4)['map'](async _0x33b67a=>_0x33b67a(_0x4b94bc['origin'],_0x639fcd)),_0x8247af=await cp(_0x14b4d1);_0x4b94bc['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5862c4,'eventType':_0x3d69ae,'response':_0x8247af});}['_subscribe'](_0x5ad2e4,_0x28fcd5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5ad2e4]||(this['handlersMap'][_0x5ad2e4]=new Set()),this['handlersMap'][_0x5ad2e4]['add'](_0x28fcd5);}['_unsubscribe'](_0x1dc272,_0x5951da){this['handlersMap'][_0x1dc272]&&_0x5951da&&this['handlersMap'][_0x1dc272]['delete'](_0x5951da),(!_0x5951da||this['handlersMap'][_0x1dc272]['size']===0x0)&&delete this['handlersMap'][_0x1dc272],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3ca53d='',_0x450397=0xa){let _0x3bca67='';for(let _0x582340=0x0;_0x582340<_0x450397;_0x582340++)_0x3bca67+=Math['floor'](Math['random']()*0xa);return _0x3ca53d+_0x3bca67;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x179285){this['target']=_0x179285,this['handlers']=new Set();}['removeMessageHandler'](_0x55dacf){_0x55dacf['messageChannel']&&(_0x55dacf['messageChannel']['port1']['removeEventListener']('message',_0x55dacf['onMessage']),_0x55dacf['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x55dacf);}async['_send'](_0x36ad89,_0xb74fb0,_0x112c26=0x32){const _0xad0c44=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xad0c44)throw new Error('connection_unavailable');let _0x14e027,_0x1d0444;return new Promise((_0x5ea167,_0x3045fb)=>{const _0x2a1e06=As('',0x14);_0xad0c44['port1']['start']();const _0x5db7a5=setTimeout(()=>{_0x3045fb(new Error('unsupported_event'));},_0x112c26);_0x1d0444={'messageChannel':_0xad0c44,'onMessage'(_0x6a4472){const _0x65352e=_0x6a4472;if(_0x65352e['data']['eventId']===_0x2a1e06)switch(_0x65352e['data']['status']){case'ack':clearTimeout(_0x5db7a5),_0x14e027=setTimeout(()=>{_0x3045fb(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x14e027),_0x5ea167(_0x65352e['data']['response']);break;default:clearTimeout(_0x5db7a5),clearTimeout(_0x14e027),_0x3045fb(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x1d0444),_0xad0c44['port1']['addEventListener']('message',_0x1d0444['onMessage']),this['target']['postMessage']({'eventType':_0x36ad89,'eventId':_0x2a1e06,'data':_0xb74fb0},[_0xad0c44['port2']]);})['finally'](()=>{_0x1d0444&&this['removeMessageHandler'](_0x1d0444);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0xad1fe8){Z()['location']['href']=_0xad1fe8;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x146bf2;return((_0x146bf2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x146bf2['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x5be6f4){this['request']=_0x5be6f4;}['toPromise'](){return new Promise((_0x58116f,_0x375caf)=>{this['request']['addEventListener']('success',()=>{_0x58116f(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x375caf(this['request']['error']);});});}}function Zn(_0x14dc60,_0x1c1d3d){return _0x14dc60['transaction']([Mn],_0x1c1d3d?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x42c95f=indexedDB['deleteDatabase'](Ka);return new nn(_0x42c95f)['toPromise']();}function Qa(){const _0x5e9fec=indexedDB['open'](Ka,pp);return new Promise((_0x5dbb19,_0x381174)=>{_0x5e9fec['addEventListener']('error',()=>{_0x381174(_0x5e9fec['error']);}),_0x5e9fec['addEventListener']('upgradeneeded',()=>{const _0x537895=_0x5e9fec['result'];try{_0x537895['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4ef59e){_0x381174(_0x4ef59e);}}),_0x5e9fec['addEventListener']('success',async()=>{const _0x44a6fc=_0x5e9fec['result'];_0x44a6fc['objectStoreNames']['contains'](Mn)?_0x5dbb19(_0x44a6fc):(_0x44a6fc['close'](),await _p(),_0x5dbb19(await Qa()));});});}async function Or(_0x26a3cf,_0x38f285,_0x16a79d){const _0x153741=Zn(_0x26a3cf,!0x0)['put']({[Ya]:_0x38f285,'value':_0x16a79d});return new nn(_0x153741)['toPromise']();}async function gp(_0x20c533,_0x553855){const _0x3788ef=Zn(_0x20c533,!0x1)['get'](_0x553855),_0x1acc47=await new nn(_0x3788ef)['toPromise']();return _0x1acc47===void 0x0?null:_0x1acc47['value'];}function Dr(_0x33f1b9,_0x52b581){const _0x34d1c1=Zn(_0x33f1b9,!0x0)['delete'](_0x52b581);return new nn(_0x34d1c1)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x190527){let _0x3cbfe7=0x0;for(;;)try{const _0x26ac16=await this['_openDb']();return await _0x190527(_0x26ac16);}catch(_0x18997d){if(_0x3cbfe7++>yp)throw _0x18997d;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x982c16,_0xa0e28e)=>({'keyProcessed':(await this['_poll']())['includes'](_0xa0e28e['key'])})),this['receiver']['_subscribe']('ping',async(_0x255f23,_0x2ef322)=>['keyChanged']);}async['initializeSender'](){var _0x2a8125,_0x2f2b4c;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x28ca5e=await this['sender']['_send']('ping',{},0x320);_0x28ca5e&&(_0x2a8125=_0x28ca5e[0x0])!=null&&_0x2a8125['fulfilled']&&(_0x2f2b4c=_0x28ca5e[0x0])!=null&&_0x2f2b4c['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xe848fa){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xe848fa},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x21a48b=>{await Or(_0x21a48b,Dn,'1'),await Dr(_0x21a48b,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x18a5a0){this['pendingWrites']++;try{await _0x18a5a0();}finally{this['pendingWrites']--;}}async['_set'](_0x2f41c9,_0x26299d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xfe741f=>Or(_0xfe741f,_0x2f41c9,_0x26299d)),this['localCache'][_0x2f41c9]=_0x26299d,this['notifyServiceWorker'](_0x2f41c9)));}async['_get'](_0x8d250){const _0x3de223=await this['_withRetries'](_0x898330=>gp(_0x898330,_0x8d250));return this['localCache'][_0x8d250]=_0x3de223,_0x3de223;}async['_remove'](_0x251080){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2f2c2a=>Dr(_0x2f2c2a,_0x251080)),delete this['localCache'][_0x251080],this['notifyServiceWorker'](_0x251080)));}async['_poll'](){const _0x3dab57=await this['_withRetries'](_0x5f4186=>{const _0x10dac1=Zn(_0x5f4186,!0x1)['getAll']();return new nn(_0x10dac1)['toPromise']();});if(!_0x3dab57)return[];if(this['pendingWrites']!==0x0)return[];const _0x460798=[],_0x218f94=new Set();if(_0x3dab57['length']!==0x0){for(const {fbase_key:_0x3d1e94,value:_0x5e8d51}of _0x3dab57)_0x218f94['add'](_0x3d1e94),JSON['stringify'](this['localCache'][_0x3d1e94])!==JSON['stringify'](_0x5e8d51)&&(this['notifyListeners'](_0x3d1e94,_0x5e8d51),_0x460798['push'](_0x3d1e94));}for(const _0x4dda53 of Object['keys'](this['localCache']))this['localCache'][_0x4dda53]&&!_0x218f94['has'](_0x4dda53)&&(this['notifyListeners'](_0x4dda53,null),_0x460798['push'](_0x4dda53));return _0x460798;}['notifyListeners'](_0x2d71dd,_0x56e322){this['localCache'][_0x2d71dd]=_0x56e322;const _0x2fc100=this['listeners'][_0x2d71dd];if(_0x2fc100){for(const _0x1232dd of Array['from'](_0x2fc100))_0x1232dd(_0x56e322);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1870db,_0x3cb983){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1870db]||(this['listeners'][_0x1870db]=new Set(),this['_get'](_0x1870db)),this['listeners'][_0x1870db]['add'](_0x3cb983);}['_removeListener'](_0x4f2ba2,_0x552dbd){this['listeners'][_0x4f2ba2]&&(this['listeners'][_0x4f2ba2]['delete'](_0x552dbd),this['listeners'][_0x4f2ba2]['size']===0x0&&delete this['listeners'][_0x4f2ba2]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5d8aa6,_0xc61160){return _0xc61160?ie(_0xc61160):(m(_0x5d8aa6['_popupRedirectResolver'],_0x5d8aa6,'argument-error'),_0x5d8aa6['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x5affa6){super('custom','custom'),this['params']=_0x5affa6;}['_getIdTokenResponse'](_0x21d59f){return nt(_0x21d59f,this['_buildIdpRequest']());}['_linkToIdToken'](_0x48c7de,_0x21d775){return nt(_0x48c7de,this['_buildIdpRequest'](_0x21d775));}['_getReauthenticationResolver'](_0xefe0b7){return nt(_0xefe0b7,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x58489e){const _0xeab5f5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x58489e&&(_0xeab5f5['idToken']=_0x58489e),_0xeab5f5;}}function Ip(_0x22d7d0){return Va(_0x22d7d0['auth'],new ks(_0x22d7d0),_0x22d7d0['bypassAuthState']);}function wp(_0x2c46d1){const {auth:_0x3b25cf,user:_0x26e1e9}=_0x2c46d1;return m(_0x26e1e9,_0x3b25cf,'internal-error'),tp(_0x26e1e9,new ks(_0x2c46d1),_0x2c46d1['bypassAuthState']);}async function Cp(_0xdde2fd){const {auth:_0x5db213,user:_0x34556b}=_0xdde2fd;return m(_0x34556b,_0x5db213,'internal-error'),ep(_0x34556b,new ks(_0xdde2fd),_0xdde2fd['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x1e2058,_0x4d8062,_0x408c9e,_0x15ebf1,_0x37723c=!0x1){this['auth']=_0x1e2058,this['resolver']=_0x408c9e,this['user']=_0x15ebf1,this['bypassAuthState']=_0x37723c,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4d8062)?_0x4d8062:[_0x4d8062];}['execute'](){return new Promise(async(_0x4eceb0,_0x85b0c5)=>{this['pendingPromise']={'resolve':_0x4eceb0,'reject':_0x85b0c5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1f493a){this['reject'](_0x1f493a);}});}async['onAuthEvent'](_0x166128){const {urlResponse:_0x12b47c,sessionId:_0xb63d59,postBody:_0x54f4fa,tenantId:_0x667907,error:_0x32bef1,type:_0x5bebaa}=_0x166128;if(_0x32bef1){this['reject'](_0x32bef1);return;}const _0x348f20={'auth':this['auth'],'requestUri':_0x12b47c,'sessionId':_0xb63d59,'tenantId':_0x667907||void 0x0,'postBody':_0x54f4fa||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5bebaa)(_0x348f20));}catch(_0x40b6f5){this['reject'](_0x40b6f5);}}['onError'](_0x5a23a8){this['reject'](_0x5a23a8);}['getIdpTask'](_0x10dcc8){switch(_0x10dcc8){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x52b980){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x52b980),this['unregisterAndCleanUp']();}['reject'](_0x3319fc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3319fc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4995f3,_0x2a1902,_0x2282ef,_0x4c473f,_0x434444){super(_0x4995f3,_0x2a1902,_0x4c473f,_0x434444),this['provider']=_0x2282ef,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x46e732=await this['execute']();return m(_0x46e732,this['auth'],'internal-error'),_0x46e732;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x139151=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x139151),this['authWindow']['associatedEvent']=_0x139151,this['resolver']['_originValidation'](this['auth'])['catch'](_0x197f36=>{this['reject'](_0x197f36);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x46ddee=>{_0x46ddee||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x9f7b17;return((_0x9f7b17=this['authWindow'])==null?void 0x0:_0x9f7b17['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x499cab=()=>{var _0xad287a,_0x277561;if((_0x277561=(_0xad287a=this['authWindow'])==null?void 0x0:_0xad287a['window'])!=null&&_0x277561['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x499cab,Tp['get']());};_0x499cab();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x20d278,_0x405b08,_0x58cbd6=!0x1){super(_0x20d278,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x405b08,void 0x0,_0x58cbd6),this['eventId']=null;}async['execute'](){let _0x4885cd=hn['get'](this['auth']['_key']());if(!_0x4885cd){try{const _0xde8862=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4885cd=()=>Promise['resolve'](_0xde8862);}catch(_0x3f1e5f){_0x4885cd=()=>Promise['reject'](_0x3f1e5f);}hn['set'](this['auth']['_key'](),_0x4885cd);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4885cd();}async['onAuthEvent'](_0x4b1c14){if(_0x4b1c14['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4b1c14);if(_0x4b1c14['type']==='unknown'){this['resolve'](null);return;}if(_0x4b1c14['eventId']){const _0x41ae3c=await this['auth']['_redirectUserForId'](_0x4b1c14['eventId']);if(_0x41ae3c)return this['user']=_0x41ae3c,super['onAuthEvent'](_0x4b1c14);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x546df5,_0x1e3069){const _0xa08536=Pp(_0x1e3069),_0x21401c=kp(_0x546df5);if(!await _0x21401c['_isAvailable']())return!0x1;const _0xc1636a=await _0x21401c['_get'](_0xa08536)==='true';return await _0x21401c['_remove'](_0xa08536),_0xc1636a;}function Ap(_0x5e60df,_0x553a95){hn['set'](_0x5e60df['_key'](),_0x553a95);}function kp(_0x1642ce){return ie(_0x1642ce['_redirectPersistence']);}function Pp(_0xc7f97d){return ln(Sp,_0xc7f97d['config']['apiKey'],_0xc7f97d['name']);}async function Np(_0x313ab8,_0x51af9b,_0x2f8716=!0x1){if($(_0x313ab8['app']))return Promise['reject'](re(_0x313ab8));const _0x5bd6c0=Ke(_0x313ab8),_0x2f4c4e=Ep(_0x5bd6c0,_0x51af9b),_0x1f550c=await new bp(_0x5bd6c0,_0x2f4c4e,_0x2f8716)['execute']();return _0x1f550c&&!_0x2f8716&&(delete _0x1f550c['user']['_redirectEventId'],await _0x5bd6c0['_persistUserIfCurrent'](_0x1f550c['user']),await _0x5bd6c0['_setRedirectUser'](null,_0x51af9b)),_0x1f550c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3d0edc){this['auth']=_0x3d0edc,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x560a04){this['consumers']['add'](_0x560a04),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x560a04)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x560a04),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xc7258b){this['consumers']['delete'](_0xc7258b);}['onEvent'](_0x3f4cbe){if(this['hasEventBeenHandled'](_0x3f4cbe))return!0x1;let _0x435f7a=!0x1;return this['consumers']['forEach'](_0x33ecd3=>{this['isEventForConsumer'](_0x3f4cbe,_0x33ecd3)&&(_0x435f7a=!0x0,this['sendToConsumer'](_0x3f4cbe,_0x33ecd3),this['saveEventToCache'](_0x3f4cbe));}),this['hasHandledPotentialRedirect']||!Mp(_0x3f4cbe)||(this['hasHandledPotentialRedirect']=!0x0,_0x435f7a||(this['queuedRedirectEvent']=_0x3f4cbe,_0x435f7a=!0x0)),_0x435f7a;}['sendToConsumer'](_0xbcba25,_0x258c11){var _0x2a09c9;if(_0xbcba25['error']&&!Za(_0xbcba25)){const _0x333423=((_0x2a09c9=_0xbcba25['error']['code'])==null?void 0x0:_0x2a09c9['split']('auth/')[0x1])||'internal-error';_0x258c11['onError'](X(this['auth'],_0x333423));}else _0x258c11['onAuthEvent'](_0xbcba25);}['isEventForConsumer'](_0x15bab4,_0x1e0adb){const _0x522a1b=_0x1e0adb['eventId']===null||!!_0x15bab4['eventId']&&_0x15bab4['eventId']===_0x1e0adb['eventId'];return _0x1e0adb['filter']['includes'](_0x15bab4['type'])&&_0x522a1b;}['hasEventBeenHandled'](_0x2237bd){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2237bd));}['saveEventToCache'](_0x5b3269){this['cachedEventUids']['add'](Mr(_0x5b3269)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x348afd){return[_0x348afd['type'],_0x348afd['eventId'],_0x348afd['sessionId'],_0x348afd['tenantId']]['filter'](_0x5efdc5=>_0x5efdc5)['join']('-');}function Za({type:_0x37f735,error:_0x1015c0}){return _0x37f735==='unknown'&&(_0x1015c0==null?void 0x0:_0x1015c0['code'])==='auth/no-auth-event';}function Mp(_0x1d6a47){switch(_0x1d6a47['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1d6a47);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1ea2c9,_0x2c26d7={}){return Pe(_0x1ea2c9,'GET','/v1/projects',_0x2c26d7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x20edfe){if(_0x20edfe['config']['emulator'])return;const {authorizedDomains:_0x2c50ef}=await Lp(_0x20edfe);for(const _0x31f490 of _0x2c50ef)try{if(Wp(_0x31f490))return;}catch{}Y(_0x20edfe,'unauthorized-domain');}function Wp(_0x37e4d9){const _0x132906=Mi(),{protocol:_0x2bb576,hostname:_0x46d867}=new URL(_0x132906);if(_0x37e4d9['startsWith']('chrome-extension://')){const _0x3531d0=new URL(_0x37e4d9);return _0x3531d0['hostname']===''&&_0x46d867===''?_0x2bb576==='chrome-extension:'&&_0x37e4d9['replace']('chrome-extension://','')===_0x132906['replace']('chrome-extension://',''):_0x2bb576==='chrome-extension:'&&_0x3531d0['hostname']===_0x46d867;}if(!Fp['test'](_0x2bb576))return!0x1;if(xp['test'](_0x37e4d9))return _0x46d867===_0x37e4d9;const _0x44aca7=_0x37e4d9['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x44aca7+'|'+_0x44aca7+')$','i')['test'](_0x46d867);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x32ffac=Z()['___jsl'];if(_0x32ffac!=null&&_0x32ffac['H']){for(const _0x68544b of Object['keys'](_0x32ffac['H']))if(_0x32ffac['H'][_0x68544b]['r']=_0x32ffac['H'][_0x68544b]['r']||[],_0x32ffac['H'][_0x68544b]['L']=_0x32ffac['H'][_0x68544b]['L']||[],_0x32ffac['H'][_0x68544b]['r']=[..._0x32ffac['H'][_0x68544b]['L']],_0x32ffac['CP']){for(let _0x42da55=0x0;_0x42da55<_0x32ffac['CP']['length'];_0x42da55++)_0x32ffac['CP'][_0x42da55]=null;}}}function Vp(_0x3c014b){return new Promise((_0xc79d49,_0x390349)=>{var _0x1620e2,_0x522ec0,_0x59678f;function _0x3350c7(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xc79d49(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x390349(X(_0x3c014b,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x522ec0=(_0x1620e2=Z()['gapi'])==null?void 0x0:_0x1620e2['iframes'])!=null&&_0x522ec0['Iframe'])_0xc79d49(gapi['iframes']['getContext']());else{if((_0x59678f=Z()['gapi'])!=null&&_0x59678f['load'])_0x3350c7();else{const _0x249335=Ff('iframefcb');return Z()[_0x249335]=()=>{gapi['load']?_0x3350c7():_0x390349(X(_0x3c014b,'network-request-failed'));},xa(xf()+'?onload='+_0x249335)['catch'](_0x3b121c=>_0x390349(_0x3b121c));}}})['catch'](_0x17692d=>{throw un=null,_0x17692d;});}let un=null;function Hp(_0x1699ee){return un=un||Vp(_0x1699ee),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x39edb7){const _0x2af141=_0x39edb7['config'];m(_0x2af141['authDomain'],_0x39edb7,'auth-domain-config-required');const _0x1077ee=_0x2af141['emulator']?Cs(_0x2af141,qp):'https://'+_0x39edb7['config']['authDomain']+'/'+Gp,_0x387623={'apiKey':_0x2af141['apiKey'],'appName':_0x39edb7['name'],'v':dt},_0x58226f=jp['get'](_0x39edb7['config']['apiHost']);_0x58226f&&(_0x387623['eid']=_0x58226f);const _0x44199c=_0x39edb7['_getFrameworks']();return _0x44199c['length']&&(_0x387623['fw']=_0x44199c['join'](',')),_0x1077ee+'?'+ut(_0x387623)['slice'](0x1);}async function Yp(_0x20e2d8){const _0x105e63=await Hp(_0x20e2d8),_0x2b872e=Z()['gapi'];return m(_0x2b872e,_0x20e2d8,'internal-error'),_0x105e63['open']({'where':document['body'],'url':Kp(_0x20e2d8),'messageHandlersFilter':_0x2b872e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x559ecc=>new Promise(async(_0x39c5b4,_0x4e063b)=>{await _0x559ecc['restyle']({'setHideOnLeave':!0x1});const _0x5d2fee=X(_0x20e2d8,'network-request-failed'),_0x1d7358=Z()['setTimeout'](()=>{_0x4e063b(_0x5d2fee);},$p['get']());function _0x4fbd10(){Z()['clearTimeout'](_0x1d7358),_0x39c5b4(_0x559ecc);}_0x559ecc['ping'](_0x4fbd10)['then'](_0x4fbd10,()=>{_0x4e063b(_0x5d2fee);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3d0d06){this['window']=_0x3d0d06,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x272d8a,_0x5a309d,_0x3af17b,_0x11736a=Jp,_0x543900=Xp){const _0x487723=Math['max']((window['screen']['availHeight']-_0x543900)/0x2,0x0)['toString'](),_0x33a8bc=Math['max']((window['screen']['availWidth']-_0x11736a)/0x2,0x0)['toString']();let _0x44df40='';const _0x3600a8={...Qp,'width':_0x11736a['toString'](),'height':_0x543900['toString'](),'top':_0x487723,'left':_0x33a8bc},_0x1cfc8f=W()['toLowerCase']();_0x3af17b&&(_0x44df40=ka(_0x1cfc8f)?Zp:_0x3af17b),Ra(_0x1cfc8f)&&(_0x5a309d=_0x5a309d||e_,_0x3600a8['scrollbars']='yes');const _0x46ce06=Object['entries'](_0x3600a8)['reduce']((_0x4d18d0,[_0x6453bd,_0x53054c])=>''+_0x4d18d0+_0x6453bd+'='+_0x53054c+',','');if(Rf(_0x1cfc8f)&&_0x44df40!=='_self')return n_(_0x5a309d||'',_0x44df40),new xr(null);const _0x446d21=window['open'](_0x5a309d||'',_0x44df40,_0x46ce06);m(_0x446d21,_0x272d8a,'popup-blocked');try{_0x446d21['focus']();}catch{}return new xr(_0x446d21);}function n_(_0x309077,_0x5dc9f3){const _0x1f8f42=document['createElement']('a');_0x1f8f42['href']=_0x309077,_0x1f8f42['target']=_0x5dc9f3;const _0x11d9fa=document['createEvent']('MouseEvent');_0x11d9fa['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1f8f42['dispatchEvent'](_0x11d9fa);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x8f6c7f,_0x27c07f,_0x9b735c,_0x342444,_0x837560,_0x44208c){m(_0x8f6c7f['config']['authDomain'],_0x8f6c7f,'auth-domain-config-required'),m(_0x8f6c7f['config']['apiKey'],_0x8f6c7f,'invalid-api-key');const _0x27daa3={'apiKey':_0x8f6c7f['config']['apiKey'],'appName':_0x8f6c7f['name'],'authType':_0x9b735c,'redirectUrl':_0x342444,'v':dt,'eventId':_0x837560};if(_0x27c07f instanceof Wa){_0x27c07f['setDefaultLanguage'](_0x8f6c7f['languageCode']),_0x27daa3['providerId']=_0x27c07f['providerId']||'',pn(_0x27c07f['getCustomParameters']())||(_0x27daa3['customParameters']=JSON['stringify'](_0x27c07f['getCustomParameters']()));for(const [_0x302640,_0x209541]of Object['entries']({}))_0x27daa3[_0x302640]=_0x209541;}if(_0x27c07f instanceof tn){const _0x543cd1=_0x27c07f['getScopes']()['filter'](_0x50c644=>_0x50c644!=='');_0x543cd1['length']>0x0&&(_0x27daa3['scopes']=_0x543cd1['join'](','));}_0x8f6c7f['tenantId']&&(_0x27daa3['tid']=_0x8f6c7f['tenantId']);const _0x14df4c=_0x27daa3;for(const _0x466ab4 of Object['keys'](_0x14df4c))_0x14df4c[_0x466ab4]===void 0x0&&delete _0x14df4c[_0x466ab4];const _0x11d509=await _0x8f6c7f['_getAppCheckToken'](),_0x10a705=_0x11d509?'#'+r_+'='+encodeURIComponent(_0x11d509):'';return o_(_0x8f6c7f)+'?'+ut(_0x14df4c)['slice'](0x1)+_0x10a705;}function o_({config:_0x1cfdd0}){return _0x1cfdd0['emulator']?Cs(_0x1cfdd0,s_):'https://'+_0x1cfdd0['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x30b083,_0x5eb040,_0x2507a9,_0xc49cfc){var _0x39b88e;ce((_0x39b88e=this['eventManagers'][_0x30b083['_key']()])==null?void 0x0:_0x39b88e['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x5abe13=await Fr(_0x30b083,_0x5eb040,_0x2507a9,Mi(),_0xc49cfc);return t_(_0x30b083,_0x5abe13,As());}async['_openRedirect'](_0x197ce4,_0x1881bc,_0x261d05,_0x419bce){await this['_originValidation'](_0x197ce4);const _0x562596=await Fr(_0x197ce4,_0x1881bc,_0x261d05,Mi(),_0x419bce);return hp(_0x562596),new Promise(()=>{});}['_initialize'](_0x2d2674){const _0x182c45=_0x2d2674['_key']();if(this['eventManagers'][_0x182c45]){const {manager:_0x1a838d,promise:_0x4a9130}=this['eventManagers'][_0x182c45];return _0x1a838d?Promise['resolve'](_0x1a838d):(ce(_0x4a9130,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4a9130);}const _0x5e9595=this['initAndGetManager'](_0x2d2674);return this['eventManagers'][_0x182c45]={'promise':_0x5e9595},_0x5e9595['catch'](()=>{delete this['eventManagers'][_0x182c45];}),_0x5e9595;}async['initAndGetManager'](_0x346c55){const _0x4e1523=await Yp(_0x346c55),_0x13c747=new Dp(_0x346c55);return _0x4e1523['register']('authEvent',_0x162525=>(m(_0x162525==null?void 0x0:_0x162525['authEvent'],_0x346c55,'invalid-auth-event'),{'status':_0x13c747['onEvent'](_0x162525['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x346c55['_key']()]={'manager':_0x13c747},this['iframes'][_0x346c55['_key']()]=_0x4e1523,_0x13c747;}['_isIframeWebStorageSupported'](_0x245b20,_0x1e50ac){this['iframes'][_0x245b20['_key']()]['send'](pi,{'type':pi},_0x3eedec=>{var _0x1a2937;const _0x29fb45=(_0x1a2937=_0x3eedec==null?void 0x0:_0x3eedec[0x0])==null?void 0x0:_0x1a2937[pi];_0x29fb45!==void 0x0&&_0x1e50ac(!!_0x29fb45),Y(_0x245b20,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3222b7){const _0x445961=_0x3222b7['_key']();return this['originValidationPromises'][_0x445961]||(this['originValidationPromises'][_0x445961]=Up(_0x3222b7)),this['originValidationPromises'][_0x445961];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0xf80658){this['auth']=_0xf80658,this['internalListeners']=new Map();}['getUid'](){var _0x3158a9;return this['assertAuthConfigured'](),((_0x3158a9=this['auth']['currentUser'])==null?void 0x0:_0x3158a9['uid'])||null;}async['getToken'](_0x2a5ad4){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2a5ad4)}:null;}['addAuthTokenListener'](_0x256f3d){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x256f3d))return;const _0x13a5a0=this['auth']['onIdTokenChanged'](_0x4828b1=>{_0x256f3d((_0x4828b1==null?void 0x0:_0x4828b1['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x256f3d,_0x13a5a0),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2b1647){this['assertAuthConfigured']();const _0x33462e=this['internalListeners']['get'](_0x2b1647);_0x33462e&&(this['internalListeners']['delete'](_0x2b1647),_0x33462e(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3e1380){switch(_0x3e1380){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4643c6){st(new Fe('auth',(_0x18fac6,{options:_0x4ea5c8})=>{const _0x417cde=_0x18fac6['getProvider']('app')['getImmediate'](),_0x1b2b1e=_0x18fac6['getProvider']('heartbeat'),_0x1f67b1=_0x18fac6['getProvider']('app-check-internal'),{apiKey:_0x35753a,authDomain:_0x2d7887}=_0x417cde['options'];m(_0x35753a&&!_0x35753a['includes'](':'),'invalid-api-key',{'appName':_0x417cde['name']});const _0x5b9a1d={'apiKey':_0x35753a,'authDomain':_0x2d7887,'clientPlatform':_0x4643c6,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4643c6)},_0x540511=new Df(_0x417cde,_0x1b2b1e,_0x1f67b1,_0x5b9a1d);return Hf(_0x540511,_0x4ea5c8),_0x540511;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x46ee48,_0xb1ad06,_0xd979a3)=>{_0x46ee48['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x2a4e06=>{const _0x17576c=Ke(_0x2a4e06['getProvider']('auth')['getImmediate']());return(_0x3503e3=>new l_(_0x3503e3))(_0x17576c);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4643c6)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x382c24=>async _0x1e1061=>{const _0x43ab52=_0x1e1061&&await _0x1e1061['getIdTokenResult'](),_0x297aa8=_0x43ab52&&(new Date()['getTime']()-Date['parse'](_0x43ab52['issuedAtTime']))/0x3e8;if(_0x297aa8&&_0x297aa8>f_)return;const _0x4b9ed0=_0x43ab52==null?void 0x0:_0x43ab52['token'];Br!==_0x4b9ed0&&(Br=_0x4b9ed0,await fetch(_0x382c24,{'method':_0x4b9ed0?'POST':'DELETE','headers':_0x4b9ed0?{'Authorization':'Bearer\x20'+_0x4b9ed0}:{}}));};function B_(_0x3663bc=Zr()){const _0x394ed0=Hi(_0x3663bc,'auth');if(_0x394ed0['isInitialized']())return _0x394ed0['getImmediate']();const _0x3459ad=Vf(_0x3663bc,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x1ad2a6=jr('authTokenSyncURL');if(_0x1ad2a6&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x209b6c=new URL(_0x1ad2a6,location['origin']);if(location['origin']===_0x209b6c['origin']){const _0x1bd466=p_(_0x209b6c['toString']());sp(_0x3459ad,_0x1bd466,()=>_0x1bd466(_0x3459ad['currentUser'])),ip(_0x3459ad,_0x3986db=>_0x1bd466(_0x3986db));}}const _0x2a217a=qr('auth');return _0x2a217a&&$f(_0x3459ad,'http://'+_0x2a217a),_0x3459ad;}function __(){var _0x4cb7c2;return((_0x4cb7c2=document['getElementsByTagName']('head'))==null?void 0x0:_0x4cb7c2[0x0])??document;}Mf({'loadJS'(_0x4936c1){return new Promise((_0x25a883,_0x333ae7)=>{const _0x2e0c14=document['createElement']('script');_0x2e0c14['setAttribute']('src',_0x4936c1),_0x2e0c14['onload']=_0x25a883,_0x2e0c14['onerror']=_0x31554d=>{const _0x3d942a=X('internal-error');_0x3d942a['customData']=_0x31554d,_0x333ae7(_0x3d942a);},_0x2e0c14['type']='text/javascript',_0x2e0c14['charset']='UTF-8',__()['appendChild'](_0x2e0c14);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};