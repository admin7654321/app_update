const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x14e115,_0x1d3d0e){if(!_0x14e115)throw ht(_0x1d3d0e);},ht=function(_0x2e3faa){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2e3faa);},Hr=function(_0x1fa59f){const _0x13824e=[];let _0x423faa=0x0;for(let _0x5d9966=0x0;_0x5d9966<_0x1fa59f['length'];_0x5d9966++){let _0x17ac86=_0x1fa59f['charCodeAt'](_0x5d9966);_0x17ac86<0x80?_0x13824e[_0x423faa++]=_0x17ac86:_0x17ac86<0x800?(_0x13824e[_0x423faa++]=_0x17ac86>>0x6|0xc0,_0x13824e[_0x423faa++]=_0x17ac86&0x3f|0x80):(_0x17ac86&0xfc00)===0xd800&&_0x5d9966+0x1<_0x1fa59f['length']&&(_0x1fa59f['charCodeAt'](_0x5d9966+0x1)&0xfc00)===0xdc00?(_0x17ac86=0x10000+((_0x17ac86&0x3ff)<<0xa)+(_0x1fa59f['charCodeAt'](++_0x5d9966)&0x3ff),_0x13824e[_0x423faa++]=_0x17ac86>>0x12|0xf0,_0x13824e[_0x423faa++]=_0x17ac86>>0xc&0x3f|0x80,_0x13824e[_0x423faa++]=_0x17ac86>>0x6&0x3f|0x80,_0x13824e[_0x423faa++]=_0x17ac86&0x3f|0x80):(_0x13824e[_0x423faa++]=_0x17ac86>>0xc|0xe0,_0x13824e[_0x423faa++]=_0x17ac86>>0x6&0x3f|0x80,_0x13824e[_0x423faa++]=_0x17ac86&0x3f|0x80);}return _0x13824e;},nc=function(_0x43a561){const _0x583bff=[];let _0xad965d=0x0,_0x8c75ce=0x0;for(;_0xad965d<_0x43a561['length'];){const _0x4ca9ee=_0x43a561[_0xad965d++];if(_0x4ca9ee<0x80)_0x583bff[_0x8c75ce++]=String['fromCharCode'](_0x4ca9ee);else{if(_0x4ca9ee>0xbf&&_0x4ca9ee<0xe0){const _0xc7d32e=_0x43a561[_0xad965d++];_0x583bff[_0x8c75ce++]=String['fromCharCode']((_0x4ca9ee&0x1f)<<0x6|_0xc7d32e&0x3f);}else{if(_0x4ca9ee>0xef&&_0x4ca9ee<0x16d){const _0x45c44f=_0x43a561[_0xad965d++],_0x477bc0=_0x43a561[_0xad965d++],_0xc70e8e=_0x43a561[_0xad965d++],_0xd9be22=((_0x4ca9ee&0x7)<<0x12|(_0x45c44f&0x3f)<<0xc|(_0x477bc0&0x3f)<<0x6|_0xc70e8e&0x3f)-0x10000;_0x583bff[_0x8c75ce++]=String['fromCharCode'](0xd800+(_0xd9be22>>0xa)),_0x583bff[_0x8c75ce++]=String['fromCharCode'](0xdc00+(_0xd9be22&0x3ff));}else{const _0x3e794e=_0x43a561[_0xad965d++],_0x3b0245=_0x43a561[_0xad965d++];_0x583bff[_0x8c75ce++]=String['fromCharCode']((_0x4ca9ee&0xf)<<0xc|(_0x3e794e&0x3f)<<0x6|_0x3b0245&0x3f);}}}}return _0x583bff['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x21ea9f,_0xd24562){if(!Array['isArray'](_0x21ea9f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x42985b=_0xd24562?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x264109=[];for(let _0x51e858=0x0;_0x51e858<_0x21ea9f['length'];_0x51e858+=0x3){const _0x1aea7a=_0x21ea9f[_0x51e858],_0x2413b9=_0x51e858+0x1<_0x21ea9f['length'],_0x2dd38f=_0x2413b9?_0x21ea9f[_0x51e858+0x1]:0x0,_0x410e6b=_0x51e858+0x2<_0x21ea9f['length'],_0x55f7e1=_0x410e6b?_0x21ea9f[_0x51e858+0x2]:0x0,_0xf81fb8=_0x1aea7a>>0x2,_0x40405e=(_0x1aea7a&0x3)<<0x4|_0x2dd38f>>0x4;let _0x2ca9af=(_0x2dd38f&0xf)<<0x2|_0x55f7e1>>0x6,_0x1b57e2=_0x55f7e1&0x3f;_0x410e6b||(_0x1b57e2=0x40,_0x2413b9||(_0x2ca9af=0x40)),_0x264109['push'](_0x42985b[_0xf81fb8],_0x42985b[_0x40405e],_0x42985b[_0x2ca9af],_0x42985b[_0x1b57e2]);}return _0x264109['join']('');},'encodeString'(_0x421361,_0x253e12){return this['HAS_NATIVE_SUPPORT']&&!_0x253e12?btoa(_0x421361):this['encodeByteArray'](Hr(_0x421361),_0x253e12);},'decodeString'(_0x241884,_0x5ef10b){return this['HAS_NATIVE_SUPPORT']&&!_0x5ef10b?atob(_0x241884):nc(this['decodeStringToByteArray'](_0x241884,_0x5ef10b));},'decodeStringToByteArray'(_0x570960,_0x162154){this['init_']();const _0x4b4be5=_0x162154?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4593c=[];for(let _0x2aa3fa=0x0;_0x2aa3fa<_0x570960['length'];){const _0x162de3=_0x4b4be5[_0x570960['charAt'](_0x2aa3fa++)],_0x42c3ae=_0x2aa3fa<_0x570960['length']?_0x4b4be5[_0x570960['charAt'](_0x2aa3fa)]:0x0;++_0x2aa3fa;const _0x5ced49=_0x2aa3fa<_0x570960['length']?_0x4b4be5[_0x570960['charAt'](_0x2aa3fa)]:0x40;++_0x2aa3fa;const _0x170b44=_0x2aa3fa<_0x570960['length']?_0x4b4be5[_0x570960['charAt'](_0x2aa3fa)]:0x40;if(++_0x2aa3fa,_0x162de3==null||_0x42c3ae==null||_0x5ced49==null||_0x170b44==null)throw new ic();const _0x2be656=_0x162de3<<0x2|_0x42c3ae>>0x4;if(_0x4593c['push'](_0x2be656),_0x5ced49!==0x40){const _0x37eb5f=_0x42c3ae<<0x4&0xf0|_0x5ced49>>0x2;if(_0x4593c['push'](_0x37eb5f),_0x170b44!==0x40){const _0x4a4cd5=_0x5ced49<<0x6&0xc0|_0x170b44;_0x4593c['push'](_0x4a4cd5);}}}return _0x4593c;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2a760c=0x0;_0x2a760c<this['ENCODED_VALS']['length'];_0x2a760c++)this['byteToCharMap_'][_0x2a760c]=this['ENCODED_VALS']['charAt'](_0x2a760c),this['charToByteMap_'][this['byteToCharMap_'][_0x2a760c]]=_0x2a760c,this['byteToCharMapWebSafe_'][_0x2a760c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2a760c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2a760c]]=_0x2a760c,_0x2a760c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2a760c)]=_0x2a760c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2a760c)]=_0x2a760c);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3f85bd){const _0x237fea=Hr(_0x3f85bd);return Fi['encodeByteArray'](_0x237fea,!0x0);},dn=function(_0xbfeb14){return $r(_0xbfeb14)['replace'](/\./g,'');},fn=function(_0x4f4eb4){try{return Fi['decodeString'](_0x4f4eb4,!0x0);}catch(_0x23f8ca){console['error']('base64Decode\x20failed:\x20',_0x23f8ca);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x42753f){return Gr(void 0x0,_0x42753f);}function Gr(_0x4ab0d0,_0x5c4cdb){if(!(_0x5c4cdb instanceof Object))return _0x5c4cdb;switch(_0x5c4cdb['constructor']){case Date:const _0x55c94c=_0x5c4cdb;return new Date(_0x55c94c['getTime']());case Object:_0x4ab0d0===void 0x0&&(_0x4ab0d0={});break;case Array:_0x4ab0d0=[];break;default:return _0x5c4cdb;}for(const _0x5cc270 in _0x5c4cdb)!_0x5c4cdb['hasOwnProperty'](_0x5cc270)||!rc(_0x5cc270)||(_0x4ab0d0[_0x5cc270]=Gr(_0x4ab0d0[_0x5cc270],_0x5c4cdb[_0x5cc270]));return _0x4ab0d0;}function rc(_0x501664){return _0x501664!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x2a33fc=Ps['__FIREBASE_DEFAULTS__'];if(_0x2a33fc)return JSON['parse'](_0x2a33fc);},lc=()=>{if(typeof document>'u')return;let _0x2a9361;try{_0x2a9361=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xc11282=_0x2a9361&&fn(_0x2a9361[0x1]);return _0xc11282&&JSON['parse'](_0xc11282);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x6cb45a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x6cb45a);return;}},qr=_0x2a316e=>{var _0x5bf10c,_0x232041;return(_0x232041=(_0x5bf10c=Ui())==null?void 0x0:_0x5bf10c['emulatorHosts'])==null?void 0x0:_0x232041[_0x2a316e];},hc=_0x4d36ec=>{const _0x58bba=qr(_0x4d36ec);if(!_0x58bba)return;const _0x5c090e=_0x58bba['lastIndexOf'](':');if(_0x5c090e<=0x0||_0x5c090e+0x1===_0x58bba['length'])throw new Error('Invalid\x20host\x20'+_0x58bba+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x415abb=parseInt(_0x58bba['substring'](_0x5c090e+0x1),0xa);return _0x58bba[0x0]==='['?[_0x58bba['substring'](0x1,_0x5c090e-0x1),_0x415abb]:[_0x58bba['substring'](0x0,_0x5c090e),_0x415abb];},zr=()=>{var _0x3481ae;return(_0x3481ae=Ui())==null?void 0x0:_0x3481ae['config'];},jr=_0x48b36f=>{var _0x5c37ab;return(_0x5c37ab=Ui())==null?void 0x0:_0x5c37ab['_'+_0x48b36f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x10c4c2,_0x1bd9e5)=>{this['resolve']=_0x10c4c2,this['reject']=_0x1bd9e5;});}['wrapCallback'](_0x9f367d){return(_0x3ca4e3,_0x12c6cd)=>{_0x3ca4e3?this['reject'](_0x3ca4e3):this['resolve'](_0x12c6cd),typeof _0x9f367d=='function'&&(this['promise']['catch'](()=>{}),_0x9f367d['length']===0x1?_0x9f367d(_0x3ca4e3):_0x9f367d(_0x3ca4e3,_0x12c6cd));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x559820,_0x38f4b3){if(_0x559820['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x1296d3={'alg':'none','type':'JWT'},_0x1b5d16=_0x38f4b3||'demo-project',_0x21f13d=_0x559820['iat']||0x0,_0x4ae9d9=_0x559820['sub']||_0x559820['user_id'];if(!_0x4ae9d9)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2390fe={'iss':'https://securetoken.google.com/'+_0x1b5d16,'aud':_0x1b5d16,'iat':_0x21f13d,'exp':_0x21f13d+0xe10,'auth_time':_0x21f13d,'sub':_0x4ae9d9,'user_id':_0x4ae9d9,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x559820};return[dn(JSON['stringify'](_0x1296d3)),dn(JSON['stringify'](_0x2390fe)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x15c923=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x15c923=='object'&&_0x15c923['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x658cff=W();return _0x658cff['indexOf']('MSIE\x20')>=0x0||_0x658cff['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2ce749,_0x464537)=>{try{let _0x1fc87c=!0x0;const _0x1bb294='validate-browser-context-for-indexeddb-analytics-module',_0x3542d7=self['indexedDB']['open'](_0x1bb294);_0x3542d7['onsuccess']=()=>{_0x3542d7['result']['close'](),_0x1fc87c||self['indexedDB']['deleteDatabase'](_0x1bb294),_0x2ce749(!0x0);},_0x3542d7['onupgradeneeded']=()=>{_0x1fc87c=!0x1;},_0x3542d7['onerror']=()=>{var _0x3217f5;_0x464537(((_0x3217f5=_0x3542d7['error'])==null?void 0x0:_0x3217f5['message'])||'');};}catch(_0x11ebcd){_0x464537(_0x11ebcd);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x36167c,_0x1b0ccd,_0x19f83e){super(_0x1b0ccd),this['code']=_0x36167c,this['customData']=_0x19f83e,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x1e5c7c,_0x409671,_0x3f22c0){this['service']=_0x1e5c7c,this['serviceName']=_0x409671,this['errors']=_0x3f22c0;}['create'](_0x160f70,..._0x1abaf6){const _0x3991b6=_0x1abaf6[0x0]||{},_0x2a8492=this['service']+'/'+_0x160f70,_0x3248fe=this['errors'][_0x160f70],_0x334cb3=_0x3248fe?vc(_0x3248fe,_0x3991b6):'Error',_0x24f00f=this['serviceName']+':\x20'+_0x334cb3+'\x20('+_0x2a8492+').';return new Re(_0x2a8492,_0x24f00f,_0x3991b6);}}function vc(_0x377ea5,_0x1bf6f9){return _0x377ea5['replace'](Ec,(_0x1556ee,_0x12838f)=>{const _0x15511f=_0x1bf6f9[_0x12838f];return _0x15511f!=null?String(_0x15511f):'<'+_0x12838f+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x36f607){return JSON['parse'](_0x36f607);}function O(_0x466c7f){return JSON['stringify'](_0x466c7f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x40f4cd){let _0x3d9bbb={},_0x32ce66={},_0x332cbd={},_0x24752c='';try{const _0x2199e2=_0x40f4cd['split']('.');_0x3d9bbb=Nt(fn(_0x2199e2[0x0])||''),_0x32ce66=Nt(fn(_0x2199e2[0x1])||''),_0x24752c=_0x2199e2[0x2],_0x332cbd=_0x32ce66['d']||{},delete _0x32ce66['d'];}catch{}return{'header':_0x3d9bbb,'claims':_0x32ce66,'data':_0x332cbd,'signature':_0x24752c};},Ic=function(_0x415fae){const _0x59d7d4=Yr(_0x415fae),_0x438153=_0x59d7d4['claims'];return!!_0x438153&&typeof _0x438153=='object'&&_0x438153['hasOwnProperty']('iat');},wc=function(_0x5c1871){const _0x2bef23=Yr(_0x5c1871)['claims'];return typeof _0x2bef23=='object'&&_0x2bef23['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1e0ec6,_0x429ce9){return Object['prototype']['hasOwnProperty']['call'](_0x1e0ec6,_0x429ce9);}function Le(_0xa85d1e,_0x333b29){if(Object['prototype']['hasOwnProperty']['call'](_0xa85d1e,_0x333b29))return _0xa85d1e[_0x333b29];}function pn(_0x425354){for(const _0x2bba07 in _0x425354)if(Object['prototype']['hasOwnProperty']['call'](_0x425354,_0x2bba07))return!0x1;return!0x0;}function _n(_0x866166,_0x1d768d,_0x468245){const _0x4cf66d={};for(const _0x10bd90 in _0x866166)Object['prototype']['hasOwnProperty']['call'](_0x866166,_0x10bd90)&&(_0x4cf66d[_0x10bd90]=_0x1d768d['call'](_0x468245,_0x866166[_0x10bd90],_0x10bd90,_0x866166));return _0x4cf66d;}function xe(_0x37eb35,_0x3e18d0){if(_0x37eb35===_0x3e18d0)return!0x0;const _0x8b1e89=Object['keys'](_0x37eb35),_0x28f9d5=Object['keys'](_0x3e18d0);for(const _0x104c16 of _0x8b1e89){if(!_0x28f9d5['includes'](_0x104c16))return!0x1;const _0x2e5df7=_0x37eb35[_0x104c16],_0x40bf85=_0x3e18d0[_0x104c16];if(Ns(_0x2e5df7)&&Ns(_0x40bf85)){if(!xe(_0x2e5df7,_0x40bf85))return!0x1;}else{if(_0x2e5df7!==_0x40bf85)return!0x1;}}for(const _0x1c9608 of _0x28f9d5)if(!_0x8b1e89['includes'](_0x1c9608))return!0x1;return!0x0;}function Ns(_0x3d93ba){return _0x3d93ba!==null&&typeof _0x3d93ba=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x476825){const _0x45926a=[];for(const [_0x5b09be,_0x4b92c0]of Object['entries'](_0x476825))Array['isArray'](_0x4b92c0)?_0x4b92c0['forEach'](_0x302a34=>{_0x45926a['push'](encodeURIComponent(_0x5b09be)+'='+encodeURIComponent(_0x302a34));}):_0x45926a['push'](encodeURIComponent(_0x5b09be)+'='+encodeURIComponent(_0x4b92c0));return _0x45926a['length']?'&'+_0x45926a['join']('&'):'';}function Ct(_0x49d4bf){const _0x561640={};return _0x49d4bf['replace'](/^\?/,'')['split']('&')['forEach'](_0x506e56=>{if(_0x506e56){const [_0x2f9e8a,_0x3361cb]=_0x506e56['split']('=');_0x561640[decodeURIComponent(_0x2f9e8a)]=decodeURIComponent(_0x3361cb);}}),_0x561640;}function Tt(_0x1c19ed){const _0x37160d=_0x1c19ed['indexOf']('?');if(!_0x37160d)return'';const _0x4f04be=_0x1c19ed['indexOf']('#',_0x37160d);return _0x1c19ed['substring'](_0x37160d,_0x4f04be>0x0?_0x4f04be:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x203796=0x1;_0x203796<this['blockSize'];++_0x203796)this['pad_'][_0x203796]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x293221,_0xfec47e){_0xfec47e||(_0xfec47e=0x0);const _0x24ce55=this['W_'];if(typeof _0x293221=='string'){for(let _0x2912c9=0x0;_0x2912c9<0x10;_0x2912c9++)_0x24ce55[_0x2912c9]=_0x293221['charCodeAt'](_0xfec47e)<<0x18|_0x293221['charCodeAt'](_0xfec47e+0x1)<<0x10|_0x293221['charCodeAt'](_0xfec47e+0x2)<<0x8|_0x293221['charCodeAt'](_0xfec47e+0x3),_0xfec47e+=0x4;}else{for(let _0x5e05c2=0x0;_0x5e05c2<0x10;_0x5e05c2++)_0x24ce55[_0x5e05c2]=_0x293221[_0xfec47e]<<0x18|_0x293221[_0xfec47e+0x1]<<0x10|_0x293221[_0xfec47e+0x2]<<0x8|_0x293221[_0xfec47e+0x3],_0xfec47e+=0x4;}for(let _0x1fc28d=0x10;_0x1fc28d<0x50;_0x1fc28d++){const _0x45cb31=_0x24ce55[_0x1fc28d-0x3]^_0x24ce55[_0x1fc28d-0x8]^_0x24ce55[_0x1fc28d-0xe]^_0x24ce55[_0x1fc28d-0x10];_0x24ce55[_0x1fc28d]=(_0x45cb31<<0x1|_0x45cb31>>>0x1f)&0xffffffff;}let _0x3a36ea=this['chain_'][0x0],_0x5eee2a=this['chain_'][0x1],_0xa9319e=this['chain_'][0x2],_0x2bac34=this['chain_'][0x3],_0xaf4e00=this['chain_'][0x4],_0x2c37d1,_0x545ae4;for(let _0x3ea23a=0x0;_0x3ea23a<0x50;_0x3ea23a++){_0x3ea23a<0x28?_0x3ea23a<0x14?(_0x2c37d1=_0x2bac34^_0x5eee2a&(_0xa9319e^_0x2bac34),_0x545ae4=0x5a827999):(_0x2c37d1=_0x5eee2a^_0xa9319e^_0x2bac34,_0x545ae4=0x6ed9eba1):_0x3ea23a<0x3c?(_0x2c37d1=_0x5eee2a&_0xa9319e|_0x2bac34&(_0x5eee2a|_0xa9319e),_0x545ae4=0x8f1bbcdc):(_0x2c37d1=_0x5eee2a^_0xa9319e^_0x2bac34,_0x545ae4=0xca62c1d6);const _0x1980b6=(_0x3a36ea<<0x5|_0x3a36ea>>>0x1b)+_0x2c37d1+_0xaf4e00+_0x545ae4+_0x24ce55[_0x3ea23a]&0xffffffff;_0xaf4e00=_0x2bac34,_0x2bac34=_0xa9319e,_0xa9319e=(_0x5eee2a<<0x1e|_0x5eee2a>>>0x2)&0xffffffff,_0x5eee2a=_0x3a36ea,_0x3a36ea=_0x1980b6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3a36ea&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5eee2a&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xa9319e&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2bac34&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xaf4e00&0xffffffff;}['update'](_0xe3ce80,_0x5b5c5e){if(_0xe3ce80==null)return;_0x5b5c5e===void 0x0&&(_0x5b5c5e=_0xe3ce80['length']);const _0x1ebc8c=_0x5b5c5e-this['blockSize'];let _0x4ec147=0x0;const _0x36451a=this['buf_'];let _0x56eeb2=this['inbuf_'];for(;_0x4ec147<_0x5b5c5e;){if(_0x56eeb2===0x0){for(;_0x4ec147<=_0x1ebc8c;)this['compress_'](_0xe3ce80,_0x4ec147),_0x4ec147+=this['blockSize'];}if(typeof _0xe3ce80=='string'){for(;_0x4ec147<_0x5b5c5e;)if(_0x36451a[_0x56eeb2]=_0xe3ce80['charCodeAt'](_0x4ec147),++_0x56eeb2,++_0x4ec147,_0x56eeb2===this['blockSize']){this['compress_'](_0x36451a),_0x56eeb2=0x0;break;}}else{for(;_0x4ec147<_0x5b5c5e;)if(_0x36451a[_0x56eeb2]=_0xe3ce80[_0x4ec147],++_0x56eeb2,++_0x4ec147,_0x56eeb2===this['blockSize']){this['compress_'](_0x36451a),_0x56eeb2=0x0;break;}}}this['inbuf_']=_0x56eeb2,this['total_']+=_0x5b5c5e;}['digest'](){const _0x949946=[];let _0x1934d0=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0xdbe0e9=this['blockSize']-0x1;_0xdbe0e9>=0x38;_0xdbe0e9--)this['buf_'][_0xdbe0e9]=_0x1934d0&0xff,_0x1934d0/=0x100;this['compress_'](this['buf_']);let _0x233c0a=0x0;for(let _0xe56a5e=0x0;_0xe56a5e<0x5;_0xe56a5e++)for(let _0x26754b=0x18;_0x26754b>=0x0;_0x26754b-=0x8)_0x949946[_0x233c0a]=this['chain_'][_0xe56a5e]>>_0x26754b&0xff,++_0x233c0a;return _0x949946;}}function Tc(_0x1eef47,_0x46a190){const _0x10b2ff=new Sc(_0x1eef47,_0x46a190);return _0x10b2ff['subscribe']['bind'](_0x10b2ff);}class Sc{constructor(_0x53d9e1,_0x28a60c){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x28a60c,this['task']['then'](()=>{_0x53d9e1(this);})['catch'](_0x236c5a=>{this['error'](_0x236c5a);});}['next'](_0x16564e){this['forEachObserver'](_0x4156ac=>{_0x4156ac['next'](_0x16564e);});}['error'](_0x2f2da4){this['forEachObserver'](_0x22ab77=>{_0x22ab77['error'](_0x2f2da4);}),this['close'](_0x2f2da4);}['complete'](){this['forEachObserver'](_0x2390f9=>{_0x2390f9['complete']();}),this['close']();}['subscribe'](_0x57139b,_0x1efa90,_0x410627){let _0x45960c;if(_0x57139b===void 0x0&&_0x1efa90===void 0x0&&_0x410627===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x57139b,['next','error','complete'])?_0x45960c=_0x57139b:_0x45960c={'next':_0x57139b,'error':_0x1efa90,'complete':_0x410627},_0x45960c['next']===void 0x0&&(_0x45960c['next']=ti),_0x45960c['error']===void 0x0&&(_0x45960c['error']=ti),_0x45960c['complete']===void 0x0&&(_0x45960c['complete']=ti);const _0x2898b9=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x45960c['error'](this['finalError']):_0x45960c['complete']();}catch{}}),this['observers']['push'](_0x45960c),_0x2898b9;}['unsubscribeOne'](_0x448389){this['observers']===void 0x0||this['observers'][_0x448389]===void 0x0||(delete this['observers'][_0x448389],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4e8495){if(!this['finalized']){for(let _0x179c12=0x0;_0x179c12<this['observers']['length'];_0x179c12++)this['sendOne'](_0x179c12,_0x4e8495);}}['sendOne'](_0xdd6aec,_0x482fb8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xdd6aec]!==void 0x0)try{_0x482fb8(this['observers'][_0xdd6aec]);}catch(_0x3d2830){typeof console<'u'&&console['error']&&console['error'](_0x3d2830);}});}['close'](_0x4524af){this['finalized']||(this['finalized']=!0x0,_0x4524af!==void 0x0&&(this['finalError']=_0x4524af),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x219c42,_0x2af3f7){if(typeof _0x219c42!='object'||_0x219c42===null)return!0x1;for(const _0x500019 of _0x2af3f7)if(_0x500019 in _0x219c42&&typeof _0x219c42[_0x500019]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x56299a,_0x857a24){return _0x56299a+'\x20failed:\x20'+_0x857a24+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2c4d27){const _0x297deb=[];let _0x507cf9=0x0;for(let _0x5c1572=0x0;_0x5c1572<_0x2c4d27['length'];_0x5c1572++){let _0x268822=_0x2c4d27['charCodeAt'](_0x5c1572);if(_0x268822>=0xd800&&_0x268822<=0xdbff){const _0x40289e=_0x268822-0xd800;_0x5c1572++,f(_0x5c1572<_0x2c4d27['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1f3dc1=_0x2c4d27['charCodeAt'](_0x5c1572)-0xdc00;_0x268822=0x10000+(_0x40289e<<0xa)+_0x1f3dc1;}_0x268822<0x80?_0x297deb[_0x507cf9++]=_0x268822:_0x268822<0x800?(_0x297deb[_0x507cf9++]=_0x268822>>0x6|0xc0,_0x297deb[_0x507cf9++]=_0x268822&0x3f|0x80):_0x268822<0x10000?(_0x297deb[_0x507cf9++]=_0x268822>>0xc|0xe0,_0x297deb[_0x507cf9++]=_0x268822>>0x6&0x3f|0x80,_0x297deb[_0x507cf9++]=_0x268822&0x3f|0x80):(_0x297deb[_0x507cf9++]=_0x268822>>0x12|0xf0,_0x297deb[_0x507cf9++]=_0x268822>>0xc&0x3f|0x80,_0x297deb[_0x507cf9++]=_0x268822>>0x6&0x3f|0x80,_0x297deb[_0x507cf9++]=_0x268822&0x3f|0x80);}return _0x297deb;},Ln=function(_0x2682e3){let _0x288e7b=0x0;for(let _0x139f80=0x0;_0x139f80<_0x2682e3['length'];_0x139f80++){const _0x27645f=_0x2682e3['charCodeAt'](_0x139f80);_0x27645f<0x80?_0x288e7b++:_0x27645f<0x800?_0x288e7b+=0x2:_0x27645f>=0xd800&&_0x27645f<=0xdbff?(_0x288e7b+=0x4,_0x139f80++):_0x288e7b+=0x3;}return _0x288e7b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x26c76b){return _0x26c76b&&_0x26c76b['_delegate']?_0x26c76b['_delegate']:_0x26c76b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x51f506){try{return(_0x51f506['startsWith']('http://')||_0x51f506['startsWith']('https://')?new URL(_0x51f506)['hostname']:_0x51f506)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x473e5c){return(await fetch(_0x473e5c,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x321ef6,_0x4b236e,_0x2fad70){this['name']=_0x321ef6,this['instanceFactory']=_0x4b236e,this['type']=_0x2fad70,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0xb1dc1f){return this['instantiationMode']=_0xb1dc1f,this;}['setMultipleInstances'](_0x1f0715){return this['multipleInstances']=_0x1f0715,this;}['setServiceProps'](_0x2d4e25){return this['serviceProps']=_0x2d4e25,this;}['setInstanceCreatedCallback'](_0x50e350){return this['onInstanceCreated']=_0x50e350,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x58f9f0,_0x3859a1){this['name']=_0x58f9f0,this['container']=_0x3859a1,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1136c6){const _0x149f37=this['normalizeInstanceIdentifier'](_0x1136c6);if(!this['instancesDeferred']['has'](_0x149f37)){const _0x4cbdc0=new H();if(this['instancesDeferred']['set'](_0x149f37,_0x4cbdc0),this['isInitialized'](_0x149f37)||this['shouldAutoInitialize']())try{const _0x33967f=this['getOrInitializeService']({'instanceIdentifier':_0x149f37});_0x33967f&&_0x4cbdc0['resolve'](_0x33967f);}catch{}}return this['instancesDeferred']['get'](_0x149f37)['promise'];}['getImmediate'](_0x5704fd){const _0x55d9ac=this['normalizeInstanceIdentifier'](_0x5704fd==null?void 0x0:_0x5704fd['identifier']),_0x3f1b3f=(_0x5704fd==null?void 0x0:_0x5704fd['optional'])??!0x1;if(this['isInitialized'](_0x55d9ac)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x55d9ac});}catch(_0x164c9e){if(_0x3f1b3f)return null;throw _0x164c9e;}else{if(_0x3f1b3f)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x436f78){if(_0x436f78['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x436f78['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x436f78,!!this['shouldAutoInitialize']()){if(Pc(_0x436f78))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x245cdd,_0x290c03]of this['instancesDeferred']['entries']()){const _0xe0e2e8=this['normalizeInstanceIdentifier'](_0x245cdd);try{const _0x42e2be=this['getOrInitializeService']({'instanceIdentifier':_0xe0e2e8});_0x290c03['resolve'](_0x42e2be);}catch{}}}}['clearInstance'](_0xb2ae16=Ne){this['instancesDeferred']['delete'](_0xb2ae16),this['instancesOptions']['delete'](_0xb2ae16),this['instances']['delete'](_0xb2ae16);}async['delete'](){const _0x2b1901=Array['from'](this['instances']['values']());await Promise['all']([..._0x2b1901['filter'](_0x58f582=>'INTERNAL'in _0x58f582)['map'](_0x1648c7=>_0x1648c7['INTERNAL']['delete']()),..._0x2b1901['filter'](_0x42768e=>'_delete'in _0x42768e)['map'](_0x309540=>_0x309540['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x353f6d=Ne){return this['instances']['has'](_0x353f6d);}['getOptions'](_0x23ea4f=Ne){return this['instancesOptions']['get'](_0x23ea4f)||{};}['initialize'](_0x4a6f46={}){const {options:_0x4be3f3={}}=_0x4a6f46,_0x199b57=this['normalizeInstanceIdentifier'](_0x4a6f46['instanceIdentifier']);if(this['isInitialized'](_0x199b57))throw Error(this['name']+'('+_0x199b57+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x393bcf=this['getOrInitializeService']({'instanceIdentifier':_0x199b57,'options':_0x4be3f3});for(const [_0x53b776,_0x18e864]of this['instancesDeferred']['entries']()){const _0x597056=this['normalizeInstanceIdentifier'](_0x53b776);_0x199b57===_0x597056&&_0x18e864['resolve'](_0x393bcf);}return _0x393bcf;}['onInit'](_0xce6e40,_0x2b03fa){const _0x27fdfc=this['normalizeInstanceIdentifier'](_0x2b03fa),_0x450438=this['onInitCallbacks']['get'](_0x27fdfc)??new Set();_0x450438['add'](_0xce6e40),this['onInitCallbacks']['set'](_0x27fdfc,_0x450438);const _0x169fc0=this['instances']['get'](_0x27fdfc);return _0x169fc0&&_0xce6e40(_0x169fc0,_0x27fdfc),()=>{_0x450438['delete'](_0xce6e40);};}['invokeOnInitCallbacks'](_0x37e20e,_0x73b800){const _0x3afe61=this['onInitCallbacks']['get'](_0x73b800);if(_0x3afe61){for(const _0x196006 of _0x3afe61)try{_0x196006(_0x37e20e,_0x73b800);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1d7941,options:_0x5a40cc={}}){let _0x4275d8=this['instances']['get'](_0x1d7941);if(!_0x4275d8&&this['component']&&(_0x4275d8=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1d7941),'options':_0x5a40cc}),this['instances']['set'](_0x1d7941,_0x4275d8),this['instancesOptions']['set'](_0x1d7941,_0x5a40cc),this['invokeOnInitCallbacks'](_0x4275d8,_0x1d7941),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1d7941,_0x4275d8);}catch{}return _0x4275d8||null;}['normalizeInstanceIdentifier'](_0x1586b7=Ne){return this['component']?this['component']['multipleInstances']?_0x1586b7:Ne:_0x1586b7;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x526fb9){return _0x526fb9===Ne?void 0x0:_0x526fb9;}function Pc(_0x2ed229){return _0x2ed229['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x225a29){this['name']=_0x225a29,this['providers']=new Map();}['addComponent'](_0x26f7c7){const _0x107a09=this['getProvider'](_0x26f7c7['name']);if(_0x107a09['isComponentSet']())throw new Error('Component\x20'+_0x26f7c7['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x107a09['setComponent'](_0x26f7c7);}['addOrOverwriteComponent'](_0x402a55){this['getProvider'](_0x402a55['name'])['isComponentSet']()&&this['providers']['delete'](_0x402a55['name']),this['addComponent'](_0x402a55);}['getProvider'](_0x1bb82b){if(this['providers']['has'](_0x1bb82b))return this['providers']['get'](_0x1bb82b);const _0x3fb123=new Ac(_0x1bb82b,this);return this['providers']['set'](_0x1bb82b,_0x3fb123),_0x3fb123;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4d8592){_0x4d8592[_0x4d8592['DEBUG']=0x0]='DEBUG',_0x4d8592[_0x4d8592['VERBOSE']=0x1]='VERBOSE',_0x4d8592[_0x4d8592['INFO']=0x2]='INFO',_0x4d8592[_0x4d8592['WARN']=0x3]='WARN',_0x4d8592[_0x4d8592['ERROR']=0x4]='ERROR',_0x4d8592[_0x4d8592['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x182dc8,_0x21a079,..._0x2f1509)=>{if(_0x21a079<_0x182dc8['logLevel'])return;const _0x286ea9=new Date()['toISOString'](),_0x1adc0d=Mc[_0x21a079];if(_0x1adc0d)console[_0x1adc0d]('['+_0x286ea9+']\x20\x20'+_0x182dc8['name']+':',..._0x2f1509);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x21a079+')');};class Bi{constructor(_0x2b9048){this['name']=_0x2b9048,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x97c4c7){if(!(_0x97c4c7 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x97c4c7+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x97c4c7;}['setLogLevel'](_0x225787){this['_logLevel']=typeof _0x225787=='string'?Oc[_0x225787]:_0x225787;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x217000){if(typeof _0x217000!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x217000;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5be4d6){this['_userLogHandler']=_0x5be4d6;}['debug'](..._0x58b037){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x58b037),this['_logHandler'](this,T['DEBUG'],..._0x58b037);}['log'](..._0x40d2a4){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x40d2a4),this['_logHandler'](this,T['VERBOSE'],..._0x40d2a4);}['info'](..._0x3488cf){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3488cf),this['_logHandler'](this,T['INFO'],..._0x3488cf);}['warn'](..._0x3ab66f){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3ab66f),this['_logHandler'](this,T['WARN'],..._0x3ab66f);}['error'](..._0x414ad5){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x414ad5),this['_logHandler'](this,T['ERROR'],..._0x414ad5);}}const xc=(_0x5a5e23,_0x953f5)=>_0x953f5['some'](_0x2877e4=>_0x5a5e23 instanceof _0x2877e4);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x445f2b){const _0x3a8936=new Promise((_0x16805c,_0x3d0eeb)=>{const _0x31c40d=()=>{_0x445f2b['removeEventListener']('success',_0x5b0b9d),_0x445f2b['removeEventListener']('error',_0x404ce7);},_0x5b0b9d=()=>{_0x16805c(ge(_0x445f2b['result'])),_0x31c40d();},_0x404ce7=()=>{_0x3d0eeb(_0x445f2b['error']),_0x31c40d();};_0x445f2b['addEventListener']('success',_0x5b0b9d),_0x445f2b['addEventListener']('error',_0x404ce7);});return _0x3a8936['then'](_0x4f1acc=>{_0x4f1acc instanceof IDBCursor&&Jr['set'](_0x4f1acc,_0x445f2b);})['catch'](()=>{}),Vi['set'](_0x3a8936,_0x445f2b),_0x3a8936;}function Bc(_0xaf98c4){if(_i['has'](_0xaf98c4))return;const _0x377ff0=new Promise((_0x50ea11,_0x5adc3e)=>{const _0xf6233f=()=>{_0xaf98c4['removeEventListener']('complete',_0x3e68c0),_0xaf98c4['removeEventListener']('error',_0x4e946d),_0xaf98c4['removeEventListener']('abort',_0x4e946d);},_0x3e68c0=()=>{_0x50ea11(),_0xf6233f();},_0x4e946d=()=>{_0x5adc3e(_0xaf98c4['error']||new DOMException('AbortError','AbortError')),_0xf6233f();};_0xaf98c4['addEventListener']('complete',_0x3e68c0),_0xaf98c4['addEventListener']('error',_0x4e946d),_0xaf98c4['addEventListener']('abort',_0x4e946d);});_i['set'](_0xaf98c4,_0x377ff0);}let gi={'get'(_0x3f72c9,_0x3c6bf0,_0x23f205){if(_0x3f72c9 instanceof IDBTransaction){if(_0x3c6bf0==='done')return _i['get'](_0x3f72c9);if(_0x3c6bf0==='objectStoreNames')return _0x3f72c9['objectStoreNames']||Xr['get'](_0x3f72c9);if(_0x3c6bf0==='store')return _0x23f205['objectStoreNames'][0x1]?void 0x0:_0x23f205['objectStore'](_0x23f205['objectStoreNames'][0x0]);}return ge(_0x3f72c9[_0x3c6bf0]);},'set'(_0x2164d8,_0x53e863,_0xdbbb0e){return _0x2164d8[_0x53e863]=_0xdbbb0e,!0x0;},'has'(_0x395a54,_0x13bfbd){return _0x395a54 instanceof IDBTransaction&&(_0x13bfbd==='done'||_0x13bfbd==='store')?!0x0:_0x13bfbd in _0x395a54;}};function Vc(_0x414c45){gi=_0x414c45(gi);}function Hc(_0x3fa5a6){return _0x3fa5a6===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x10e75d,..._0x3fdea4){const _0xa31bd3=_0x3fa5a6['call'](ii(this),_0x10e75d,..._0x3fdea4);return Xr['set'](_0xa31bd3,_0x10e75d['sort']?_0x10e75d['sort']():[_0x10e75d]),ge(_0xa31bd3);}:Uc()['includes'](_0x3fa5a6)?function(..._0x2ae0fb){return _0x3fa5a6['apply'](ii(this),_0x2ae0fb),ge(Jr['get'](this));}:function(..._0x1961ec){return ge(_0x3fa5a6['apply'](ii(this),_0x1961ec));};}function $c(_0x1430a4){return typeof _0x1430a4=='function'?Hc(_0x1430a4):(_0x1430a4 instanceof IDBTransaction&&Bc(_0x1430a4),xc(_0x1430a4,Fc())?new Proxy(_0x1430a4,gi):_0x1430a4);}function ge(_0x2889c3){if(_0x2889c3 instanceof IDBRequest)return Wc(_0x2889c3);if(ni['has'](_0x2889c3))return ni['get'](_0x2889c3);const _0x44bcdd=$c(_0x2889c3);return _0x44bcdd!==_0x2889c3&&(ni['set'](_0x2889c3,_0x44bcdd),Vi['set'](_0x44bcdd,_0x2889c3)),_0x44bcdd;}const ii=_0x64dc0=>Vi['get'](_0x64dc0);function Gc(_0x3f50f7,_0x474098,{blocked:_0x54e5f2,upgrade:_0x3d3b48,blocking:_0x39dfdf,terminated:_0x35eca6}={}){const _0x1edd65=indexedDB['open'](_0x3f50f7,_0x474098),_0x446e76=ge(_0x1edd65);return _0x3d3b48&&_0x1edd65['addEventListener']('upgradeneeded',_0x2c6425=>{_0x3d3b48(ge(_0x1edd65['result']),_0x2c6425['oldVersion'],_0x2c6425['newVersion'],ge(_0x1edd65['transaction']),_0x2c6425);}),_0x54e5f2&&_0x1edd65['addEventListener']('blocked',_0x1d1101=>_0x54e5f2(_0x1d1101['oldVersion'],_0x1d1101['newVersion'],_0x1d1101)),_0x446e76['then'](_0x28b10b=>{_0x35eca6&&_0x28b10b['addEventListener']('close',()=>_0x35eca6()),_0x39dfdf&&_0x28b10b['addEventListener']('versionchange',_0x3075b8=>_0x39dfdf(_0x3075b8['oldVersion'],_0x3075b8['newVersion'],_0x3075b8));})['catch'](()=>{}),_0x446e76;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x23cc53,_0x585369){if(!(_0x23cc53 instanceof IDBDatabase&&!(_0x585369 in _0x23cc53)&&typeof _0x585369=='string'))return;if(si['get'](_0x585369))return si['get'](_0x585369);const _0x20bb2b=_0x585369['replace'](/FromIndex$/,''),_0x5eb2a7=_0x585369!==_0x20bb2b,_0x11d9f5=zc['includes'](_0x20bb2b);if(!(_0x20bb2b in(_0x5eb2a7?IDBIndex:IDBObjectStore)['prototype'])||!(_0x11d9f5||qc['includes'](_0x20bb2b)))return;const _0x447765=async function(_0xd8ec3f,..._0x1334d9){const _0x44e31=this['transaction'](_0xd8ec3f,_0x11d9f5?'readwrite':'readonly');let _0x500832=_0x44e31['store'];return _0x5eb2a7&&(_0x500832=_0x500832['index'](_0x1334d9['shift']())),(await Promise['all']([_0x500832[_0x20bb2b](..._0x1334d9),_0x11d9f5&&_0x44e31['done']]))[0x0];};return si['set'](_0x585369,_0x447765),_0x447765;}Vc(_0x15ceed=>({..._0x15ceed,'get':(_0x54aaaa,_0x4eee63,_0x439a3f)=>Ms(_0x54aaaa,_0x4eee63)||_0x15ceed['get'](_0x54aaaa,_0x4eee63,_0x439a3f),'has':(_0x5f568c,_0x5e60bc)=>!!Ms(_0x5f568c,_0x5e60bc)||_0x15ceed['has'](_0x5f568c,_0x5e60bc)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x62b9b8){this['container']=_0x62b9b8;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x11fd22=>{if(Kc(_0x11fd22)){const _0x1ff0a0=_0x11fd22['getImmediate']();return _0x1ff0a0['library']+'/'+_0x1ff0a0['version'];}else return null;})['filter'](_0x3c110b=>_0x3c110b)['join']('\x20');}}function Kc(_0x2cdc85){const _0x69fced=_0x2cdc85['getComponent']();return(_0x69fced==null?void 0x0:_0x69fced['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x448c44,_0x22b512){try{_0x448c44['container']['addComponent'](_0x22b512);}catch(_0x328baa){oe['debug']('Component\x20'+_0x22b512['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x448c44['name'],_0x328baa);}}function st(_0x3d96af){const _0x1dfa71=_0x3d96af['name'];if(Ei['has'](_0x1dfa71))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1dfa71+'.'),!0x1;Ei['set'](_0x1dfa71,_0x3d96af);for(const _0x1ad152 of Ue['values']())xs(_0x1ad152,_0x3d96af);for(const _0x36f6b6 of vi['values']())xs(_0x36f6b6,_0x3d96af);return!0x0;}function Hi(_0x24aec,_0x4fb3fe){const _0x543bfd=_0x24aec['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x543bfd&&_0x543bfd['triggerHeartbeat'](),_0x24aec['container']['getProvider'](_0x4fb3fe);}function $(_0x342193){return _0x342193==null?!0x1:_0x342193['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x221763,_0x132955,_0x10db70){this['_isDeleted']=!0x1,this['_options']={..._0x221763},this['_config']={..._0x132955},this['_name']=_0x132955['name'],this['_automaticDataCollectionEnabled']=_0x132955['automaticDataCollectionEnabled'],this['_container']=_0x10db70,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x30e913){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x30e913;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5a3f52){this['_isDeleted']=_0x5a3f52;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x202b25,_0x173b0d={}){let _0x12cc19=_0x202b25;typeof _0x173b0d!='object'&&(_0x173b0d={'name':_0x173b0d});const _0x4dfbe6={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x173b0d},_0x58f18f=_0x4dfbe6['name'];if(typeof _0x58f18f!='string'||!_0x58f18f)throw me['create']('bad-app-name',{'appName':String(_0x58f18f)});if(_0x12cc19||(_0x12cc19=zr()),!_0x12cc19)throw me['create']('no-options');const _0x65422b=Ue['get'](_0x58f18f);if(_0x65422b){if(xe(_0x12cc19,_0x65422b['options'])&&xe(_0x4dfbe6,_0x65422b['config']))return _0x65422b;throw me['create']('duplicate-app',{'appName':_0x58f18f});}const _0xa3d902=new Nc(_0x58f18f);for(const _0x511581 of Ei['values']())_0xa3d902['addComponent'](_0x511581);const _0x308089=new Tl(_0x12cc19,_0x4dfbe6,_0xa3d902);return Ue['set'](_0x58f18f,_0x308089),_0x308089;}function Zr(_0xb018b9=yi){const _0x192b98=Ue['get'](_0xb018b9);if(!_0x192b98&&_0xb018b9===yi&&zr())return Sl();if(!_0x192b98)throw me['create']('no-app',{'appName':_0xb018b9});return _0x192b98;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x7a95c9){let _0x5d4c2e=!0x1;const _0x2ff9ba=_0x7a95c9['name'];Ue['has'](_0x2ff9ba)?(_0x5d4c2e=!0x0,Ue['delete'](_0x2ff9ba)):vi['has'](_0x2ff9ba)&&_0x7a95c9['decRefCount']()<=0x0&&(vi['delete'](_0x2ff9ba),_0x5d4c2e=!0x0),_0x5d4c2e&&(await Promise['all'](_0x7a95c9['container']['getProviders']()['map'](_0x2c1e78=>_0x2c1e78['delete']())),_0x7a95c9['isDeleted']=!0x0);}function ye(_0x20518c,_0x50c523,_0x55a176){let _0xcc5f48=wl[_0x20518c]??_0x20518c;_0x55a176&&(_0xcc5f48+='-'+_0x55a176);const _0x4eb035=_0xcc5f48['match'](/\s|\//),_0x10fb47=_0x50c523['match'](/\s|\//);if(_0x4eb035||_0x10fb47){const _0x5be6ff=['Unable\x20to\x20register\x20library\x20\x22'+_0xcc5f48+'\x22\x20with\x20version\x20\x22'+_0x50c523+'\x22:'];_0x4eb035&&_0x5be6ff['push']('library\x20name\x20\x22'+_0xcc5f48+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4eb035&&_0x10fb47&&_0x5be6ff['push']('and'),_0x10fb47&&_0x5be6ff['push']('version\x20name\x20\x22'+_0x50c523+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x5be6ff['join']('\x20'));return;}st(new Fe(_0xcc5f48+'-version',()=>({'library':_0xcc5f48,'version':_0x50c523}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0xc337d3,_0x54e825)=>{switch(_0x54e825){case 0x0:try{_0xc337d3['createObjectStore'](Ot);}catch(_0xe62b27){console['warn'](_0xe62b27);}}}})['catch'](_0x57a4f1=>{throw me['create']('idb-open',{'originalErrorMessage':_0x57a4f1['message']});})),ri;}async function Al(_0x418201){try{const _0x54877a=(await eo())['transaction'](Ot),_0x51acb4=await _0x54877a['objectStore'](Ot)['get'](to(_0x418201));return await _0x54877a['done'],_0x51acb4;}catch(_0x1b4502){if(_0x1b4502 instanceof Re)oe['warn'](_0x1b4502['message']);else{const _0x207a21=me['create']('idb-get',{'originalErrorMessage':_0x1b4502==null?void 0x0:_0x1b4502['message']});oe['warn'](_0x207a21['message']);}}}async function Fs(_0xde0768,_0x1b4fa5){try{const _0x21b7ae=(await eo())['transaction'](Ot,'readwrite');await _0x21b7ae['objectStore'](Ot)['put'](_0x1b4fa5,to(_0xde0768)),await _0x21b7ae['done'];}catch(_0xee02fb){if(_0xee02fb instanceof Re)oe['warn'](_0xee02fb['message']);else{const _0xdc1656=me['create']('idb-set',{'originalErrorMessage':_0xee02fb==null?void 0x0:_0xee02fb['message']});oe['warn'](_0xdc1656['message']);}}}function to(_0x32ee4c){return _0x32ee4c['name']+'!'+_0x32ee4c['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x52b686){this['container']=_0x52b686,this['_heartbeatsCache']=null;const _0x25820a=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x25820a),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x13d816=>(this['_heartbeatsCache']=_0x13d816,_0x13d816));}async['triggerHeartbeat'](){var _0x5dcdda,_0x27be25;try{const _0x56dc1b=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3d4584=Us();if(((_0x5dcdda=this['_heartbeatsCache'])==null?void 0x0:_0x5dcdda['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x27be25=this['_heartbeatsCache'])==null?void 0x0:_0x27be25['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3d4584||this['_heartbeatsCache']['heartbeats']['some'](_0xbf1bac=>_0xbf1bac['date']===_0x3d4584))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3d4584,'agent':_0x56dc1b}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x233c5b=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x233c5b,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1061dd){oe['warn'](_0x1061dd);}}async['getHeartbeatsHeader'](){var _0x47cbb5;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x47cbb5=this['_heartbeatsCache'])==null?void 0x0:_0x47cbb5['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x413e57=Us(),{heartbeatsToSend:_0x3d66c2,unsentEntries:_0x43f0b7}=Ol(this['_heartbeatsCache']['heartbeats']),_0x4edd46=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3d66c2}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x413e57,_0x43f0b7['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x43f0b7,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x4edd46;}catch(_0x1d3af4){return oe['warn'](_0x1d3af4),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x16e474,_0x53f8c2=kl){const _0x36074d=[];let _0x5b3762=_0x16e474['slice']();for(const _0x43078e of _0x16e474){const _0x4ba670=_0x36074d['find'](_0x1fdbd4=>_0x1fdbd4['agent']===_0x43078e['agent']);if(_0x4ba670){if(_0x4ba670['dates']['push'](_0x43078e['date']),Ws(_0x36074d)>_0x53f8c2){_0x4ba670['dates']['pop']();break;}}else{if(_0x36074d['push']({'agent':_0x43078e['agent'],'dates':[_0x43078e['date']]}),Ws(_0x36074d)>_0x53f8c2){_0x36074d['pop']();break;}}_0x5b3762=_0x5b3762['slice'](0x1);}return{'heartbeatsToSend':_0x36074d,'unsentEntries':_0x5b3762};}class Dl{constructor(_0x35b505){this['app']=_0x35b505,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x35e0ef=await Al(this['app']);return _0x35e0ef!=null&&_0x35e0ef['heartbeats']?_0x35e0ef:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1490d3){if(await this['_canUseIndexedDBPromise']){const _0x2ea0fd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1490d3['lastSentHeartbeatDate']??_0x2ea0fd['lastSentHeartbeatDate'],'heartbeats':_0x1490d3['heartbeats']});}else return;}async['add'](_0x517665){if(await this['_canUseIndexedDBPromise']){const _0x1c62b7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x517665['lastSentHeartbeatDate']??_0x1c62b7['lastSentHeartbeatDate'],'heartbeats':[..._0x1c62b7['heartbeats'],..._0x517665['heartbeats']]});}else return;}}function Ws(_0x55ed36){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x55ed36}))['length'];}function Ml(_0x20aa75){if(_0x20aa75['length']===0x0)return-0x1;let _0x1a9f96=0x0,_0xa91b5e=_0x20aa75[0x0]['date'];for(let _0x303bfd=0x1;_0x303bfd<_0x20aa75['length'];_0x303bfd++)_0x20aa75[_0x303bfd]['date']<_0xa91b5e&&(_0xa91b5e=_0x20aa75[_0x303bfd]['date'],_0x1a9f96=_0x303bfd);return _0x1a9f96;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2434a3){st(new Fe('platform-logger',_0x262e26=>new jc(_0x262e26),'PRIVATE')),st(new Fe('heartbeat',_0x1d146b=>new Nl(_0x1d146b),'PRIVATE')),ye(mi,Ls,_0x2434a3),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x796555){no=_0x796555;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x420b4d){this['domStorage_']=_0x420b4d,this['prefix_']='firebase:';}['set'](_0x4d9d60,_0x4a471c){_0x4a471c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x4d9d60)):this['domStorage_']['setItem'](this['prefixedName_'](_0x4d9d60),O(_0x4a471c));}['get'](_0x4a4565){const _0x1f3eab=this['domStorage_']['getItem'](this['prefixedName_'](_0x4a4565));return _0x1f3eab==null?null:Nt(_0x1f3eab);}['remove'](_0x9f26f9){this['domStorage_']['removeItem'](this['prefixedName_'](_0x9f26f9));}['prefixedName_'](_0x19de27){return this['prefix_']+_0x19de27;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2f8035,_0x1db694){_0x1db694==null?delete this['cache_'][_0x2f8035]:this['cache_'][_0x2f8035]=_0x1db694;}['get'](_0x296039){return Q(this['cache_'],_0x296039)?this['cache_'][_0x296039]:null;}['remove'](_0x2c2836){delete this['cache_'][_0x2c2836];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x810396){try{if(typeof window<'u'&&typeof window[_0x810396]<'u'){const _0x18a1a6=window[_0x810396];return _0x18a1a6['setItem']('firebase:sentinel','cache'),_0x18a1a6['removeItem']('firebase:sentinel'),new Wl(_0x18a1a6);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4040ba=0x1;return function(){return _0x4040ba++;};}()),ro=function(_0x3aa855){const _0x3e3808=Rc(_0x3aa855),_0x2354a0=new Cc();_0x2354a0['update'](_0x3e3808);const _0x2438a3=_0x2354a0['digest']();return Fi['encodeByteArray'](_0x2438a3);},zt=function(..._0x52ef7e){let _0xf9d370='';for(let _0x33d1d1=0x0;_0x33d1d1<_0x52ef7e['length'];_0x33d1d1++){const _0x983b9c=_0x52ef7e[_0x33d1d1];Array['isArray'](_0x983b9c)||_0x983b9c&&typeof _0x983b9c=='object'&&typeof _0x983b9c['length']=='number'?_0xf9d370+=zt['apply'](null,_0x983b9c):typeof _0x983b9c=='object'?_0xf9d370+=O(_0x983b9c):_0xf9d370+=_0x983b9c,_0xf9d370+='\x20';}return _0xf9d370;};let St=null,$s=!0x0;const Hl=function(_0xc40fa5,_0x3672a7){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x3c6904){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x55b02d=zt['apply'](null,_0x3c6904);St(_0x55b02d);}},jt=function(_0x270e2e){return function(..._0xf7c98b){L(_0x270e2e,..._0xf7c98b);};},Ii=function(..._0x2aa820){const _0x276313='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2aa820);Ze['error'](_0x276313);},ae=function(..._0x5ae4f3){const _0x1f84e4='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x5ae4f3);throw Ze['error'](_0x1f84e4),new Error(_0x1f84e4);},U=function(..._0x3b5a79){const _0x435df0='FIREBASE\x20WARNING:\x20'+zt(..._0x3b5a79);Ze['warn'](_0x435df0);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x2d75a3){return typeof _0x2d75a3=='number'&&(_0x2d75a3!==_0x2d75a3||_0x2d75a3===Number['POSITIVE_INFINITY']||_0x2d75a3===Number['NEGATIVE_INFINITY']);},Gl=function(_0x440aed){if(document['readyState']==='complete')_0x440aed();else{let _0x1e7a27=!0x1;const _0x4d227d=function(){if(!document['body']){setTimeout(_0x4d227d,Math['floor'](0xa));return;}_0x1e7a27||(_0x1e7a27=!0x0,_0x440aed());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4d227d,!0x1),window['addEventListener']('load',_0x4d227d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4d227d();}),window['attachEvent']('onload',_0x4d227d));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5cf330,_0x517cad){if(_0x5cf330===_0x517cad)return 0x0;if(_0x5cf330===We||_0x517cad===we)return-0x1;if(_0x517cad===We||_0x5cf330===we)return 0x1;{const _0x2070ac=Gs(_0x5cf330),_0x2bf867=Gs(_0x517cad);return _0x2070ac!==null?_0x2bf867!==null?_0x2070ac-_0x2bf867===0x0?_0x5cf330['length']-_0x517cad['length']:_0x2070ac-_0x2bf867:-0x1:_0x2bf867!==null?0x1:_0x5cf330<_0x517cad?-0x1:0x1;}},ql=function(_0x1ffe16,_0x11fc56){return _0x1ffe16===_0x11fc56?0x0:_0x1ffe16<_0x11fc56?-0x1:0x1;},vt=function(_0x2a8acc,_0x1a17c1){if(_0x1a17c1&&_0x2a8acc in _0x1a17c1)return _0x1a17c1[_0x2a8acc];throw new Error('Missing\x20required\x20key\x20('+_0x2a8acc+')\x20in\x20object:\x20'+O(_0x1a17c1));},$i=function(_0x4e619d){if(typeof _0x4e619d!='object'||_0x4e619d===null)return O(_0x4e619d);const _0x207c62=[];for(const _0xe84cb8 in _0x4e619d)_0x207c62['push'](_0xe84cb8);_0x207c62['sort']();let _0xc4b826='{';for(let _0x271c3d=0x0;_0x271c3d<_0x207c62['length'];_0x271c3d++)_0x271c3d!==0x0&&(_0xc4b826+=','),_0xc4b826+=O(_0x207c62[_0x271c3d]),_0xc4b826+=':',_0xc4b826+=$i(_0x4e619d[_0x207c62[_0x271c3d]]);return _0xc4b826+='}',_0xc4b826;},oo=function(_0x1da343,_0x3a2eb8){const _0x443f2a=_0x1da343['length'];if(_0x443f2a<=_0x3a2eb8)return[_0x1da343];const _0x4aabf1=[];for(let _0x33f4bc=0x0;_0x33f4bc<_0x443f2a;_0x33f4bc+=_0x3a2eb8)_0x33f4bc+_0x3a2eb8>_0x443f2a?_0x4aabf1['push'](_0x1da343['substring'](_0x33f4bc,_0x443f2a)):_0x4aabf1['push'](_0x1da343['substring'](_0x33f4bc,_0x33f4bc+_0x3a2eb8));return _0x4aabf1;};function x(_0x7bb8fa,_0x5862b9){for(const _0x572f5b in _0x7bb8fa)_0x7bb8fa['hasOwnProperty'](_0x572f5b)&&_0x5862b9(_0x572f5b,_0x7bb8fa[_0x572f5b]);}const ao=function(_0x29cfc3){f(!xn(_0x29cfc3),'Invalid\x20JSON\x20number');const _0x5281d3=0xb,_0x2aa2dd=0x34,_0x5a2935=(0x1<<_0x5281d3-0x1)-0x1;let _0x64bec5,_0x28d55a,_0x43731,_0x5cca14,_0x5317c5;_0x29cfc3===0x0?(_0x28d55a=0x0,_0x43731=0x0,_0x64bec5=0x1/_0x29cfc3===-0x1/0x0?0x1:0x0):(_0x64bec5=_0x29cfc3<0x0,_0x29cfc3=Math['abs'](_0x29cfc3),_0x29cfc3>=Math['pow'](0x2,0x1-_0x5a2935)?(_0x5cca14=Math['min'](Math['floor'](Math['log'](_0x29cfc3)/Math['LN2']),_0x5a2935),_0x28d55a=_0x5cca14+_0x5a2935,_0x43731=Math['round'](_0x29cfc3*Math['pow'](0x2,_0x2aa2dd-_0x5cca14)-Math['pow'](0x2,_0x2aa2dd))):(_0x28d55a=0x0,_0x43731=Math['round'](_0x29cfc3/Math['pow'](0x2,0x1-_0x5a2935-_0x2aa2dd))));const _0x210652=[];for(_0x5317c5=_0x2aa2dd;_0x5317c5;_0x5317c5-=0x1)_0x210652['push'](_0x43731%0x2?0x1:0x0),_0x43731=Math['floor'](_0x43731/0x2);for(_0x5317c5=_0x5281d3;_0x5317c5;_0x5317c5-=0x1)_0x210652['push'](_0x28d55a%0x2?0x1:0x0),_0x28d55a=Math['floor'](_0x28d55a/0x2);_0x210652['push'](_0x64bec5?0x1:0x0),_0x210652['reverse']();const _0x516f9c=_0x210652['join']('');let _0x386a7='';for(_0x5317c5=0x0;_0x5317c5<0x40;_0x5317c5+=0x8){let _0x53d0d7=parseInt(_0x516f9c['substr'](_0x5317c5,0x8),0x2)['toString'](0x10);_0x53d0d7['length']===0x1&&(_0x53d0d7='0'+_0x53d0d7),_0x386a7=_0x386a7+_0x53d0d7;}return _0x386a7['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x96639c,_0x38e13a){let _0x51becb='Unknown\x20Error';_0x96639c==='too_big'?_0x51becb='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x96639c==='permission_denied'?_0x51becb='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x96639c==='unavailable'&&(_0x51becb='The\x20service\x20is\x20unavailable');const _0x1971e1=new Error(_0x96639c+'\x20at\x20'+_0x38e13a['_path']['toString']()+':\x20'+_0x51becb);return _0x1971e1['code']=_0x96639c['toUpperCase'](),_0x1971e1;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x468c47){if(Yl['test'](_0x468c47)){const _0xffc2c4=Number(_0x468c47);if(_0xffc2c4>=Ql&&_0xffc2c4<=Jl)return _0xffc2c4;}return null;},ft=function(_0x4389dd){try{_0x4389dd();}catch(_0x2a62eb){setTimeout(()=>{const _0x5d0cf8=_0x2a62eb['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5d0cf8),_0x2a62eb;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x164ddc,_0x44500b){const _0x493f27=setTimeout(_0x164ddc,_0x44500b);return typeof _0x493f27=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x493f27):typeof _0x493f27=='object'&&_0x493f27['unref']&&_0x493f27['unref'](),_0x493f27;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x5b6d44,_0x1a8917){this['appCheckProvider']=_0x1a8917,this['appName']=_0x5b6d44['name'],$(_0x5b6d44)&&_0x5b6d44['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5b6d44['settings']['appCheckToken']),this['appCheck']=_0x1a8917==null?void 0x0:_0x1a8917['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1a8917==null||_0x1a8917['get']()['then'](_0x370a3c=>this['appCheck']=_0x370a3c);}['getToken'](_0x23f0ea){if(this['serverAppAppCheckToken']){if(_0x23f0ea)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x23f0ea):new Promise((_0x6170f7,_0x2f34b3)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x23f0ea)['then'](_0x6170f7,_0x2f34b3):_0x6170f7(null);},0x0);});}['addTokenChangeListener'](_0x2f91d4){var _0x13133b;(_0x13133b=this['appCheckProvider'])==null||_0x13133b['get']()['then'](_0x29f96b=>_0x29f96b['addTokenListener'](_0x2f91d4));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x23719e,_0x5f4776,_0x513f58){this['appName_']=_0x23719e,this['firebaseOptions_']=_0x5f4776,this['authProvider_']=_0x513f58,this['auth_']=null,this['auth_']=_0x513f58['getImmediate']({'optional':!0x0}),this['auth_']||_0x513f58['onInit'](_0x68e261=>this['auth_']=_0x68e261);}['getToken'](_0x177f13){return this['auth_']?this['auth_']['getToken'](_0x177f13)['catch'](_0x480547=>_0x480547&&_0x480547['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x480547)):new Promise((_0x11d19c,_0x3431a8)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x177f13)['then'](_0x11d19c,_0x3431a8):_0x11d19c(null);},0x0);});}['addTokenChangeListener'](_0x46bf70){this['auth_']?this['auth_']['addAuthTokenListener'](_0x46bf70):this['authProvider_']['get']()['then'](_0x8e12e3=>_0x8e12e3['addAuthTokenListener'](_0x46bf70));}['removeTokenChangeListener'](_0x4476e9){this['authProvider_']['get']()['then'](_0x53fcb0=>_0x53fcb0['removeAuthTokenListener'](_0x4476e9));}['notifyForInvalidToken'](){let _0x421341='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x421341+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x421341+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x421341+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x421341);}}class an{constructor(_0x84f839){this['accessToken']=_0x84f839;}['getToken'](_0x1ef9c3){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x412fae){_0x412fae(this['accessToken']);}['removeTokenChangeListener'](_0x2952d0){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0xefae71,_0x220033,_0x5d805c,_0x159af1,_0x50e6a9=!0x1,_0x4a0dff='',_0x393f6b=!0x1,_0x376587=!0x1,_0x45f52f=null){this['secure']=_0x220033,this['namespace']=_0x5d805c,this['webSocketOnly']=_0x159af1,this['nodeAdmin']=_0x50e6a9,this['persistenceKey']=_0x4a0dff,this['includeNamespaceInQueryParams']=_0x393f6b,this['isUsingEmulator']=_0x376587,this['emulatorOptions']=_0x45f52f,this['_host']=_0xefae71['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0xefae71)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2c1a24){_0x2c1a24!==this['internalHost']&&(this['internalHost']=_0x2c1a24,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3c25fc=this['toURLString']();return this['persistenceKey']&&(_0x3c25fc+='<'+this['persistenceKey']+'>'),_0x3c25fc;}['toURLString'](){const _0xdd51a9=this['secure']?'https://':'http://',_0x594c0a=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xdd51a9+this['host']+'/'+_0x594c0a;}}function th(_0x75eb7a){return _0x75eb7a['host']!==_0x75eb7a['internalHost']||_0x75eb7a['isCustomHost']()||_0x75eb7a['includeNamespaceInQueryParams'];}function vo(_0x7a2d13,_0x2bd7d0,_0x5a83dc){f(typeof _0x2bd7d0=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5a83dc=='object','typeof\x20params\x20must\x20==\x20object');let _0x283724;if(_0x2bd7d0===go)_0x283724=(_0x7a2d13['secure']?'wss://':'ws://')+_0x7a2d13['internalHost']+'/.ws?';else{if(_0x2bd7d0===mo)_0x283724=(_0x7a2d13['secure']?'https://':'http://')+_0x7a2d13['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2bd7d0);}th(_0x7a2d13)&&(_0x5a83dc['ns']=_0x7a2d13['namespace']);const _0x4b3225=[];return x(_0x5a83dc,(_0x402680,_0x3af61e)=>{_0x4b3225['push'](_0x402680+'='+_0x3af61e);}),_0x283724+_0x4b3225['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xfc24e3,_0xce72d6=0x1){Q(this['counters_'],_0xfc24e3)||(this['counters_'][_0xfc24e3]=0x0),this['counters_'][_0xfc24e3]+=_0xce72d6;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3fee77){const _0x57f233=_0x3fee77['toString']();return oi[_0x57f233]||(oi[_0x57f233]=new nh()),oi[_0x57f233];}function ih(_0xa46b39,_0x217cc4){const _0x2138a5=_0xa46b39['toString']();return ai[_0x2138a5]||(ai[_0x2138a5]=_0x217cc4()),ai[_0x2138a5];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x218870){this['onMessage_']=_0x218870,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x321e65,_0x38c031){this['closeAfterResponse']=_0x321e65,this['onClose']=_0x38c031,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x370b0c,_0x4102cc){for(this['pendingResponses'][_0x370b0c]=_0x4102cc;this['pendingResponses'][this['currentResponseNum']];){const _0x4ce63d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5b2905=0x0;_0x5b2905<_0x4ce63d['length'];++_0x5b2905)_0x4ce63d[_0x5b2905]&&ft(()=>{this['onMessage_'](_0x4ce63d[_0x5b2905]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x10c7b7,_0x2fc0ea,_0x191541,_0x5eb6f7,_0x17adde,_0x2826cc,_0x4ec156){this['connId']=_0x10c7b7,this['repoInfo']=_0x2fc0ea,this['applicationId']=_0x191541,this['appCheckToken']=_0x5eb6f7,this['authToken']=_0x17adde,this['transportSessionId']=_0x2826cc,this['lastSessionId']=_0x4ec156,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x10c7b7),this['stats_']=qi(_0x2fc0ea),this['urlFn']=_0x3833ee=>(this['appCheckToken']&&(_0x3833ee[wi]=this['appCheckToken']),vo(_0x2fc0ea,mo,_0x3833ee));}['open'](_0x20e081,_0x3ca1fe){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3ca1fe,this['myPacketOrderer']=new sh(_0x20e081),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x1c49ec)=>{const [_0x1ed6fe,_0x4c75c1,_0x313630,_0x4ec5f4,_0x40670e]=_0x1c49ec;if(this['incrementIncomingBytes_'](_0x1c49ec),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1ed6fe===qs)this['id']=_0x4c75c1,this['password']=_0x313630;else{if(_0x1ed6fe===rh)_0x4c75c1?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4c75c1,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1ed6fe);}}},(..._0x119d0a)=>{const [_0x3b05f1,_0x8292c5]=_0x119d0a;this['incrementIncomingBytes_'](_0x119d0a),this['myPacketOrderer']['handleResponse'](_0x3b05f1,_0x8292c5);},()=>{this['onClosed_']();},this['urlFn']);const _0x272e6e={};_0x272e6e[qs]='t',_0x272e6e[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x272e6e[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x272e6e[co]=Gi,this['transportSessionId']&&(_0x272e6e[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x272e6e[po]=this['lastSessionId']),this['applicationId']&&(_0x272e6e[_o]=this['applicationId']),this['appCheckToken']&&(_0x272e6e[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x272e6e[ho]=uo);const _0x37d006=this['urlFn'](_0x272e6e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x37d006),this['scriptTagHolder']['addTag'](_0x37d006,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1919a7){const _0x179a6a=O(_0x1919a7);this['bytesSent']+=_0x179a6a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x179a6a['length']);const _0x2a6ef2=$r(_0x179a6a),_0x52e2c3=oo(_0x2a6ef2,fh);for(let _0x28490a=0x0;_0x28490a<_0x52e2c3['length'];_0x28490a++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x52e2c3['length'],_0x52e2c3[_0x28490a]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2373e8,_0x2bc9e1){this['myDisconnFrame']=document['createElement']('iframe');const _0x18324f={};_0x18324f[dh]='t',_0x18324f[Eo]=_0x2373e8,_0x18324f[Io]=_0x2bc9e1,this['myDisconnFrame']['src']=this['urlFn'](_0x18324f),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x38f182){const _0x275f85=O(_0x38f182)['length'];this['bytesReceived']+=_0x275f85,this['stats_']['incrementCounter']('bytes_received',_0x275f85);}}class zi{constructor(_0x7a2fe4,_0x4e92f8,_0x549319,_0x1acbaf){this['onDisconnect']=_0x549319,this['urlFn']=_0x1acbaf,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x7a2fe4,window[ah+this['uniqueCallbackIdentifier']]=_0x4e92f8,this['myIFrame']=zi['createIFrame_']();let _0x3bc157='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3bc157='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x253068='<html><body>'+_0x3bc157+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x253068),this['myIFrame']['doc']['close']();}catch(_0x2b1543){L('frame\x20writing\x20exception'),_0x2b1543['stack']&&L(_0x2b1543['stack']),L(_0x2b1543);}}}static['createIFrame_'](){const _0x49d8f5=document['createElement']('iframe');if(_0x49d8f5['style']['display']='none',document['body']){document['body']['appendChild'](_0x49d8f5);try{_0x49d8f5['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x359c91=document['domain'];_0x49d8f5['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x359c91+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x49d8f5['contentDocument']?_0x49d8f5['doc']=_0x49d8f5['contentDocument']:_0x49d8f5['contentWindow']?_0x49d8f5['doc']=_0x49d8f5['contentWindow']['document']:_0x49d8f5['document']&&(_0x49d8f5['doc']=_0x49d8f5['document']),_0x49d8f5;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x362efa=this['onDisconnect'];_0x362efa&&(this['onDisconnect']=null,_0x362efa());}['startLongPoll'](_0x386612,_0x5c46bf){for(this['myID']=_0x386612,this['myPW']=_0x5c46bf,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3ff24a={};_0x3ff24a[Eo]=this['myID'],_0x3ff24a[Io]=this['myPW'],_0x3ff24a[wo]=this['currentSerial'];let _0x250c12=this['urlFn'](_0x3ff24a),_0x54f0e4='',_0x4ac59f=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x54f0e4['length']<=Co;){const _0x2e8f89=this['pendingSegs']['shift']();_0x54f0e4=_0x54f0e4+'&'+lh+_0x4ac59f+'='+_0x2e8f89['seg']+'&'+hh+_0x4ac59f+'='+_0x2e8f89['ts']+'&'+uh+_0x4ac59f+'='+_0x2e8f89['d'],_0x4ac59f++;}return _0x250c12=_0x250c12+_0x54f0e4,this['addLongPollTag_'](_0x250c12,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3438c9,_0x752da2,_0x434ba3){this['pendingSegs']['push']({'seg':_0x3438c9,'ts':_0x752da2,'d':_0x434ba3}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x285931,_0x44f672){this['outstandingRequests']['add'](_0x44f672);const _0x466f89=()=>{this['outstandingRequests']['delete'](_0x44f672),this['newRequest_']();},_0x40bd3e=setTimeout(_0x466f89,Math['floor'](ph)),_0x26ef44=()=>{clearTimeout(_0x40bd3e),_0x466f89();};this['addTag'](_0x285931,_0x26ef44);}['addTag'](_0x221958,_0xab64af){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x258f02=this['myIFrame']['doc']['createElement']('script');_0x258f02['type']='text/javascript',_0x258f02['async']=!0x0,_0x258f02['src']=_0x221958,_0x258f02['onload']=_0x258f02['onreadystatechange']=function(){const _0x2d67cf=_0x258f02['readyState'];(!_0x2d67cf||_0x2d67cf==='loaded'||_0x2d67cf==='complete')&&(_0x258f02['onload']=_0x258f02['onreadystatechange']=null,_0x258f02['parentNode']&&_0x258f02['parentNode']['removeChild'](_0x258f02),_0xab64af());},_0x258f02['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x221958),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x258f02);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x4b25bb,_0x482176,_0xf5e058,_0x159488,_0x349d91,_0x27690f,_0x378a3){this['connId']=_0x4b25bb,this['applicationId']=_0xf5e058,this['appCheckToken']=_0x159488,this['authToken']=_0x349d91,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x482176),this['connURL']=q['connectionURL_'](_0x482176,_0x27690f,_0x378a3,_0x159488,_0xf5e058),this['nodeAdmin']=_0x482176['nodeAdmin'];}static['connectionURL_'](_0x4e93ac,_0x1ec698,_0x469b05,_0x1fefad,_0x50b471){const _0x29e078={};return _0x29e078[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x29e078[ho]=uo),_0x1ec698&&(_0x29e078[lo]=_0x1ec698),_0x469b05&&(_0x29e078[po]=_0x469b05),_0x1fefad&&(_0x29e078[wi]=_0x1fefad),_0x50b471&&(_0x29e078[_o]=_0x50b471),vo(_0x4e93ac,go,_0x29e078);}['open'](_0x43e2b8,_0x5f39db){this['onDisconnect']=_0x5f39db,this['onMessage']=_0x43e2b8,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x256f5e;_c(),this['mySock']=new gn(this['connURL'],[],_0x256f5e);}catch(_0x464049){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x33f023=_0x464049['message']||_0x464049['data'];_0x33f023&&this['log_'](_0x33f023),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3cef2f=>{this['handleIncomingFrame'](_0x3cef2f);},this['mySock']['onerror']=_0x15d4bf=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x43be68=_0x15d4bf['message']||_0x15d4bf['data'];_0x43be68&&this['log_'](_0x43be68),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x33ca2e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5c85d9=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x23e903=navigator['userAgent']['match'](_0x5c85d9);_0x23e903&&_0x23e903['length']>0x1&&parseFloat(_0x23e903[0x1])<4.4&&(_0x33ca2e=!0x0);}return!_0x33ca2e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x434b37){if(this['frames']['push'](_0x434b37),this['frames']['length']===this['totalFrames']){const _0x55d401=this['frames']['join']('');this['frames']=null;const _0x26757b=Nt(_0x55d401);this['onMessage'](_0x26757b);}}['handleNewFrameCount_'](_0x2ef08d){this['totalFrames']=_0x2ef08d,this['frames']=[];}['extractFrameCount_'](_0xf6534c){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xf6534c['length']<=0x6){const _0x5df0f9=Number(_0xf6534c);if(!isNaN(_0x5df0f9))return this['handleNewFrameCount_'](_0x5df0f9),null;}return this['handleNewFrameCount_'](0x1),_0xf6534c;}['handleIncomingFrame'](_0x1fcdef){if(this['mySock']===null)return;const _0x2bb9bb=_0x1fcdef['data'];if(this['bytesReceived']+=_0x2bb9bb['length'],this['stats_']['incrementCounter']('bytes_received',_0x2bb9bb['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2bb9bb);else{const _0x1e1b73=this['extractFrameCount_'](_0x2bb9bb);_0x1e1b73!==null&&this['appendFrame_'](_0x1e1b73);}}['send'](_0x58b575){this['resetKeepAlive']();const _0x7914fe=O(_0x58b575);this['bytesSent']+=_0x7914fe['length'],this['stats_']['incrementCounter']('bytes_sent',_0x7914fe['length']);const _0x215a94=oo(_0x7914fe,gh);_0x215a94['length']>0x1&&this['sendString_'](String(_0x215a94['length']));for(let _0x42eea1=0x0;_0x42eea1<_0x215a94['length'];_0x42eea1++)this['sendString_'](_0x215a94[_0x42eea1]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x51d2a4){try{this['mySock']['send'](_0x51d2a4);}catch(_0x89d2ff){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x89d2ff['message']||_0x89d2ff['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1312f2){this['initTransports_'](_0x1312f2);}['initTransports_'](_0x42e0fb){const _0x53a95d=q&&q['isAvailable']();let _0x3bd35a=_0x53a95d&&!q['previouslyFailed']();if(_0x42e0fb['webSocketOnly']&&(_0x53a95d||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x3bd35a=!0x0),_0x3bd35a)this['transports_']=[q];else{const _0x42e6b0=this['transports_']=[];for(const _0x2d70b7 of Dt['ALL_TRANSPORTS'])_0x2d70b7&&_0x2d70b7['isAvailable']()&&_0x42e6b0['push'](_0x2d70b7);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x291dd3,_0x9bea17,_0x4b7f53,_0x2d0187,_0x3ac162,_0x2a0807,_0x57a0de,_0xeeee33,_0x392c5f,_0x16965b){this['id']=_0x291dd3,this['repoInfo_']=_0x9bea17,this['applicationId_']=_0x4b7f53,this['appCheckToken_']=_0x2d0187,this['authToken_']=_0x3ac162,this['onMessage_']=_0x2a0807,this['onReady_']=_0x57a0de,this['onDisconnect_']=_0xeeee33,this['onKill_']=_0x392c5f,this['lastSessionId']=_0x16965b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x9bea17),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x19c176=this['transportManager_']['initialTransport']();this['conn_']=new _0x19c176(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x19c176['responsesRequiredToBeHealthy']||0x0;const _0x4636cb=this['connReceiver_'](this['conn_']),_0x17e4db=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4636cb,_0x17e4db);},Math['floor'](0x0));const _0x4e5b82=_0x19c176['healthyTimeout']||0x0;_0x4e5b82>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4e5b82)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xd8bb5f){return _0x595475=>{_0xd8bb5f===this['conn_']?this['onConnectionLost_'](_0x595475):_0xd8bb5f===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1f6e84){return _0x148a26=>{this['state_']!==0x2&&(_0x1f6e84===this['rx_']?this['onPrimaryMessageReceived_'](_0x148a26):_0x1f6e84===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x148a26):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x457a35){const _0x3fda83={'t':'d','d':_0x457a35};this['sendData_'](_0x3fda83);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3046fe){if(ci in _0x3046fe){const _0x5db242=_0x3046fe[ci];_0x5db242===Ys?this['upgradeIfSecondaryHealthy_']():_0x5db242===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5db242===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x58bac1){const _0x50c7c6=vt('t',_0x58bac1),_0x40b482=vt('d',_0x58bac1);if(_0x50c7c6==='c')this['onSecondaryControl_'](_0x40b482);else{if(_0x50c7c6==='d')this['pendingDataMessages']['push'](_0x40b482);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x50c7c6);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x50a81f){const _0x30bd12=vt('t',_0x50a81f),_0x4a42e3=vt('d',_0x50a81f);_0x30bd12==='c'?this['onControl_'](_0x4a42e3):_0x30bd12==='d'&&this['onDataMessage_'](_0x4a42e3);}['onDataMessage_'](_0x9a94e2){this['onPrimaryResponse_'](),this['onMessage_'](_0x9a94e2);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2a2cb9){const _0x5d5093=vt(ci,_0x2a2cb9);if(zs in _0x2a2cb9){const _0x8eee92=_0x2a2cb9[zs];if(_0x5d5093===Th){const _0x4e896e={..._0x8eee92};this['repoInfo_']['isUsingEmulator']&&(_0x4e896e['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x4e896e);}else{if(_0x5d5093===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x21d244=0x0;_0x21d244<this['pendingDataMessages']['length'];++_0x21d244)this['onDataMessage_'](this['pendingDataMessages'][_0x21d244]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5d5093===wh?this['onConnectionShutdown_'](_0x8eee92):_0x5d5093===js?this['onReset_'](_0x8eee92):_0x5d5093===Ch?Ii('Server\x20Error:\x20'+_0x8eee92):_0x5d5093===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x5d5093);}}}['onHandshake_'](_0x1be70d){const _0x10af10=_0x1be70d['ts'],_0xb4ff74=_0x1be70d['v'],_0x57e73d=_0x1be70d['h'];this['sessionId']=_0x1be70d['s'],this['repoInfo_']['host']=_0x57e73d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x10af10),Gi!==_0xb4ff74&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5b78ff=this['transportManager_']['upgradeTransport']();_0x5b78ff&&this['startUpgrade_'](_0x5b78ff);}['startUpgrade_'](_0x504246){this['secondaryConn_']=new _0x504246(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x504246['responsesRequiredToBeHealthy']||0x0;const _0x28d97c=this['connReceiver_'](this['secondaryConn_']),_0x5317b8=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x28d97c,_0x5317b8),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x972fac){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x972fac),this['repoInfo_']['host']=_0x972fac,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x57cb0c,_0x1f9fc3){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x57cb0c,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1f9fc3,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0xbb242f=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0xbb242f||this['rx_']===_0xbb242f)&&this['close']();}['onConnectionLost_'](_0x4c1745){this['conn_']=null,!_0x4c1745&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5a659b){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5a659b),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5808b4){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5808b4);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1b92e4,_0x1ac8c8,_0x233b2f,_0x4e5188){}['merge'](_0x39e417,_0x556008,_0x1ef697,_0x546ef8){}['refreshAuthToken'](_0x27688b){}['refreshAppCheckToken'](_0x8f1619){}['onDisconnectPut'](_0x5c5afc,_0x39100d,_0x433242){}['onDisconnectMerge'](_0x11e1f8,_0x31af8b,_0x1e75fc){}['onDisconnectCancel'](_0x38301d,_0x11f31b){}['reportStats'](_0x1fd365){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xc93a68){this['allowedEvents_']=_0xc93a68,this['listeners_']={},f(Array['isArray'](_0xc93a68)&&_0xc93a68['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x17037c,..._0x214b81){if(Array['isArray'](this['listeners_'][_0x17037c])){const _0x56a22c=[...this['listeners_'][_0x17037c]];for(let _0x18a4f3=0x0;_0x18a4f3<_0x56a22c['length'];_0x18a4f3++)_0x56a22c[_0x18a4f3]['callback']['apply'](_0x56a22c[_0x18a4f3]['context'],_0x214b81);}}['on'](_0x295904,_0x90dbf4,_0x4630ff){this['validateEventType_'](_0x295904),this['listeners_'][_0x295904]=this['listeners_'][_0x295904]||[],this['listeners_'][_0x295904]['push']({'callback':_0x90dbf4,'context':_0x4630ff});const _0x2a2feb=this['getInitialEvent'](_0x295904);_0x2a2feb&&_0x90dbf4['apply'](_0x4630ff,_0x2a2feb);}['off'](_0x2ecd0d,_0x2937c7,_0x3738ff){this['validateEventType_'](_0x2ecd0d);const _0x24af4e=this['listeners_'][_0x2ecd0d]||[];for(let _0x59b33b=0x0;_0x59b33b<_0x24af4e['length'];_0x59b33b++)if(_0x24af4e[_0x59b33b]['callback']===_0x2937c7&&(!_0x3738ff||_0x3738ff===_0x24af4e[_0x59b33b]['context'])){_0x24af4e['splice'](_0x59b33b,0x1);return;}}['validateEventType_'](_0x1a5b52){f(this['allowedEvents_']['find'](_0x4f8d32=>_0x4f8d32===_0x1a5b52),'Unknown\x20event:\x20'+_0x1a5b52);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x449174){return f(_0x449174==='online','Unknown\x20event\x20type:\x20'+_0x449174),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x37e39a,_0x25e778){if(_0x25e778===void 0x0){this['pieces_']=_0x37e39a['split']('/');let _0x3b7905=0x0;for(let _0xb7909f=0x0;_0xb7909f<this['pieces_']['length'];_0xb7909f++)this['pieces_'][_0xb7909f]['length']>0x0&&(this['pieces_'][_0x3b7905]=this['pieces_'][_0xb7909f],_0x3b7905++);this['pieces_']['length']=_0x3b7905,this['pieceNum_']=0x0;}else this['pieces_']=_0x37e39a,this['pieceNum_']=_0x25e778;}['toString'](){let _0x2a8d0c='';for(let _0x2d4a87=this['pieceNum_'];_0x2d4a87<this['pieces_']['length'];_0x2d4a87++)this['pieces_'][_0x2d4a87]!==''&&(_0x2a8d0c+='/'+this['pieces_'][_0x2d4a87]);return _0x2a8d0c||'/';}}function w(){return new C('');}function y(_0x1ff4f0){return _0x1ff4f0['pieceNum_']>=_0x1ff4f0['pieces_']['length']?null:_0x1ff4f0['pieces_'][_0x1ff4f0['pieceNum_']];}function Ce(_0x3fe0f0){return _0x3fe0f0['pieces_']['length']-_0x3fe0f0['pieceNum_'];}function S(_0x1d45e9){let _0xb5c8f4=_0x1d45e9['pieceNum_'];return _0xb5c8f4<_0x1d45e9['pieces_']['length']&&_0xb5c8f4++,new C(_0x1d45e9['pieces_'],_0xb5c8f4);}function ji(_0xc30ecb){return _0xc30ecb['pieceNum_']<_0xc30ecb['pieces_']['length']?_0xc30ecb['pieces_'][_0xc30ecb['pieces_']['length']-0x1]:null;}function bh(_0x5c55df){let _0x302528='';for(let _0x6ecb4d=_0x5c55df['pieceNum_'];_0x6ecb4d<_0x5c55df['pieces_']['length'];_0x6ecb4d++)_0x5c55df['pieces_'][_0x6ecb4d]!==''&&(_0x302528+='/'+encodeURIComponent(String(_0x5c55df['pieces_'][_0x6ecb4d])));return _0x302528||'/';}function Mt(_0x645c03,_0x226945=0x0){return _0x645c03['pieces_']['slice'](_0x645c03['pieceNum_']+_0x226945);}function Ro(_0x1a1d8d){if(_0x1a1d8d['pieceNum_']>=_0x1a1d8d['pieces_']['length'])return null;const _0x1b4bff=[];for(let _0x3da37d=_0x1a1d8d['pieceNum_'];_0x3da37d<_0x1a1d8d['pieces_']['length']-0x1;_0x3da37d++)_0x1b4bff['push'](_0x1a1d8d['pieces_'][_0x3da37d]);return new C(_0x1b4bff,0x0);}function k(_0x14b1a0,_0x2fbb63){const _0x14f3ae=[];for(let _0x5c52f3=_0x14b1a0['pieceNum_'];_0x5c52f3<_0x14b1a0['pieces_']['length'];_0x5c52f3++)_0x14f3ae['push'](_0x14b1a0['pieces_'][_0x5c52f3]);if(_0x2fbb63 instanceof C){for(let _0x239c02=_0x2fbb63['pieceNum_'];_0x239c02<_0x2fbb63['pieces_']['length'];_0x239c02++)_0x14f3ae['push'](_0x2fbb63['pieces_'][_0x239c02]);}else{const _0x345dce=_0x2fbb63['split']('/');for(let _0x312394=0x0;_0x312394<_0x345dce['length'];_0x312394++)_0x345dce[_0x312394]['length']>0x0&&_0x14f3ae['push'](_0x345dce[_0x312394]);}return new C(_0x14f3ae,0x0);}function v(_0x2c3526){return _0x2c3526['pieceNum_']>=_0x2c3526['pieces_']['length'];}function F(_0x29beb6,_0x27a4e7){const _0x2f9dc0=y(_0x29beb6),_0x1bc93a=y(_0x27a4e7);if(_0x2f9dc0===null)return _0x27a4e7;if(_0x2f9dc0===_0x1bc93a)return F(S(_0x29beb6),S(_0x27a4e7));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x27a4e7+')\x20is\x20not\x20within\x20outerPath\x20('+_0x29beb6+')');}function Rh(_0x5bea10,_0x51fae){const _0x554429=Mt(_0x5bea10,0x0),_0x5c319d=Mt(_0x51fae,0x0);for(let _0xeabc60=0x0;_0xeabc60<_0x554429['length']&&_0xeabc60<_0x5c319d['length'];_0xeabc60++){const _0x3c26ac=qe(_0x554429[_0xeabc60],_0x5c319d[_0xeabc60]);if(_0x3c26ac!==0x0)return _0x3c26ac;}return _0x554429['length']===_0x5c319d['length']?0x0:_0x554429['length']<_0x5c319d['length']?-0x1:0x1;}function Ki(_0x2cf3d1,_0x7bd4a){if(Ce(_0x2cf3d1)!==Ce(_0x7bd4a))return!0x1;for(let _0x34c37b=_0x2cf3d1['pieceNum_'],_0x89f354=_0x7bd4a['pieceNum_'];_0x34c37b<=_0x2cf3d1['pieces_']['length'];_0x34c37b++,_0x89f354++)if(_0x2cf3d1['pieces_'][_0x34c37b]!==_0x7bd4a['pieces_'][_0x89f354])return!0x1;return!0x0;}function G(_0x4868a6,_0x3077dd){let _0x5d19b7=_0x4868a6['pieceNum_'],_0x11299a=_0x3077dd['pieceNum_'];if(Ce(_0x4868a6)>Ce(_0x3077dd))return!0x1;for(;_0x5d19b7<_0x4868a6['pieces_']['length'];){if(_0x4868a6['pieces_'][_0x5d19b7]!==_0x3077dd['pieces_'][_0x11299a])return!0x1;++_0x5d19b7,++_0x11299a;}return!0x0;}class Ah{constructor(_0x14f3e0,_0x260394){this['errorPrefix_']=_0x260394,this['parts_']=Mt(_0x14f3e0,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x284132=0x0;_0x284132<this['parts_']['length'];_0x284132++)this['byteLength_']+=Ln(this['parts_'][_0x284132]);Ao(this);}}function kh(_0x558113,_0x1929d3){_0x558113['parts_']['length']>0x0&&(_0x558113['byteLength_']+=0x1),_0x558113['parts_']['push'](_0x1929d3),_0x558113['byteLength_']+=Ln(_0x1929d3),Ao(_0x558113);}function Ph(_0x1d3927){const _0xe27422=_0x1d3927['parts_']['pop']();_0x1d3927['byteLength_']-=Ln(_0xe27422),_0x1d3927['parts_']['length']>0x0&&(_0x1d3927['byteLength_']-=0x1);}function Ao(_0x5cd046){if(_0x5cd046['byteLength_']>Zs)throw new Error(_0x5cd046['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x5cd046['byteLength_']+').');if(_0x5cd046['parts_']['length']>Xs)throw new Error(_0x5cd046['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x5cd046));}function Oe(_0x2fd179){return _0x2fd179['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2fd179['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x3deffa,_0x3ae284;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3ae284='visibilitychange',_0x3deffa='hidden'):typeof document['mozHidden']<'u'?(_0x3ae284='mozvisibilitychange',_0x3deffa='mozHidden'):typeof document['msHidden']<'u'?(_0x3ae284='msvisibilitychange',_0x3deffa='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3ae284='webkitvisibilitychange',_0x3deffa='webkitHidden')),this['visible_']=!0x0,_0x3ae284&&document['addEventListener'](_0x3ae284,()=>{const _0x14d1e7=!document[_0x3deffa];_0x14d1e7!==this['visible_']&&(this['visible_']=_0x14d1e7,this['trigger']('visible',_0x14d1e7));},!0x1);}['getInitialEvent'](_0x58c8c5){return f(_0x58c8c5==='visible','Unknown\x20event\x20type:\x20'+_0x58c8c5),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2207d4,_0x39bf51,_0x497eea,_0x5496f0,_0x28b628,_0x254cdd,_0x26d602,_0x211cd6){if(super(),this['repoInfo_']=_0x2207d4,this['applicationId_']=_0x39bf51,this['onDataUpdate_']=_0x497eea,this['onConnectStatus_']=_0x5496f0,this['onServerInfoUpdate_']=_0x28b628,this['authTokenProvider_']=_0x254cdd,this['appCheckTokenProvider_']=_0x26d602,this['authOverride_']=_0x211cd6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x211cd6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2207d4['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3f499f,_0x207cff,_0x46bd6e){const _0x4ea0f3=++this['requestNumber_'],_0x25f8c9={'r':_0x4ea0f3,'a':_0x3f499f,'b':_0x207cff};this['log_'](O(_0x25f8c9)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x25f8c9),_0x46bd6e&&(this['requestCBHash_'][_0x4ea0f3]=_0x46bd6e);}['get'](_0x32e808){this['initConnection_']();const _0x2a6f65=new H(),_0x114372={'action':'g','request':{'p':_0x32e808['_path']['toString'](),'q':_0x32e808['_queryObject']},'onComplete':_0x413eaf=>{const _0xc88041=_0x413eaf['d'];_0x413eaf['s']==='ok'?_0x2a6f65['resolve'](_0xc88041):_0x2a6f65['reject'](_0xc88041);}};this['outstandingGets_']['push'](_0x114372),this['outstandingGetCount_']++;const _0x27b96a=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x27b96a),_0x2a6f65['promise'];}['listen'](_0x2a0f0c,_0x55c961,_0x54fb94,_0x327be9){this['initConnection_']();const _0x4f1ab5=_0x2a0f0c['_queryIdentifier'],_0x806087=_0x2a0f0c['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x806087+'\x20'+_0x4f1ab5),this['listens']['has'](_0x806087)||this['listens']['set'](_0x806087,new Map()),f(_0x2a0f0c['_queryParams']['isDefault']()||!_0x2a0f0c['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x806087)['has'](_0x4f1ab5),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x373ac8={'onComplete':_0x327be9,'hashFn':_0x55c961,'query':_0x2a0f0c,'tag':_0x54fb94};this['listens']['get'](_0x806087)['set'](_0x4f1ab5,_0x373ac8),this['connected_']&&this['sendListen_'](_0x373ac8);}['sendGet_'](_0x39c034){const _0xeb49ac=this['outstandingGets_'][_0x39c034];this['sendRequest']('g',_0xeb49ac['request'],_0x1a158c=>{delete this['outstandingGets_'][_0x39c034],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xeb49ac['onComplete']&&_0xeb49ac['onComplete'](_0x1a158c);});}['sendListen_'](_0xd53e8c){const _0x112c8d=_0xd53e8c['query'],_0x3fc6e1=_0x112c8d['_path']['toString'](),_0xba658d=_0x112c8d['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x3fc6e1+'\x20for\x20'+_0xba658d);const _0x3dc3d6={'p':_0x3fc6e1},_0x3c8b9c='q';_0xd53e8c['tag']&&(_0x3dc3d6['q']=_0x112c8d['_queryObject'],_0x3dc3d6['t']=_0xd53e8c['tag']),_0x3dc3d6['h']=_0xd53e8c['hashFn'](),this['sendRequest'](_0x3c8b9c,_0x3dc3d6,_0x66ec3e=>{const _0x335bed=_0x66ec3e['d'],_0x40ec0c=_0x66ec3e['s'];se['warnOnListenWarnings_'](_0x335bed,_0x112c8d),(this['listens']['get'](_0x3fc6e1)&&this['listens']['get'](_0x3fc6e1)['get'](_0xba658d))===_0xd53e8c&&(this['log_']('listen\x20response',_0x66ec3e),_0x40ec0c!=='ok'&&this['removeListen_'](_0x3fc6e1,_0xba658d),_0xd53e8c['onComplete']&&_0xd53e8c['onComplete'](_0x40ec0c,_0x335bed));});}static['warnOnListenWarnings_'](_0x5030ed,_0x160a24){if(_0x5030ed&&typeof _0x5030ed=='object'&&Q(_0x5030ed,'w')){const _0x2f0cf0=Le(_0x5030ed,'w');if(Array['isArray'](_0x2f0cf0)&&~_0x2f0cf0['indexOf']('no_index')){const _0x25bb5c='\x22.indexOn\x22:\x20\x22'+_0x160a24['_queryParams']['getIndex']()['toString']()+'\x22',_0x271dfb=_0x160a24['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x25bb5c+'\x20at\x20'+_0x271dfb+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x15243b){this['authToken_']=_0x15243b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x15243b);}['reduceReconnectDelayIfAdminCredential_'](_0x44b82a){(_0x44b82a&&_0x44b82a['length']===0x28||wc(_0x44b82a))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x27a044){this['appCheckToken_']=_0x27a044,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x7d56ba=this['authToken_'],_0x56fc81=Ic(_0x7d56ba)?'auth':'gauth',_0x2754f1={'cred':_0x7d56ba};this['authOverride_']===null?_0x2754f1['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x2754f1['authvar']=this['authOverride_']),this['sendRequest'](_0x56fc81,_0x2754f1,_0x1f667e=>{const _0x382d16=_0x1f667e['s'],_0x7ee635=_0x1f667e['d']||'error';this['authToken_']===_0x7d56ba&&(_0x382d16==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x382d16,_0x7ee635));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x40160d=>{const _0x46772c=_0x40160d['s'],_0x5009ad=_0x40160d['d']||'error';_0x46772c==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x46772c,_0x5009ad);});}['unlisten'](_0x2799f7,_0x6a9787){const _0x210ceb=_0x2799f7['_path']['toString'](),_0x55e02d=_0x2799f7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x210ceb+'\x20'+_0x55e02d),f(_0x2799f7['_queryParams']['isDefault']()||!_0x2799f7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x210ceb,_0x55e02d)&&this['connected_']&&this['sendUnlisten_'](_0x210ceb,_0x55e02d,_0x2799f7['_queryObject'],_0x6a9787);}['sendUnlisten_'](_0x496c4b,_0x148fb5,_0x490f21,_0x6e0c61){this['log_']('Unlisten\x20on\x20'+_0x496c4b+'\x20for\x20'+_0x148fb5);const _0x5a0dfc={'p':_0x496c4b},_0x56b2f5='n';_0x6e0c61&&(_0x5a0dfc['q']=_0x490f21,_0x5a0dfc['t']=_0x6e0c61),this['sendRequest'](_0x56b2f5,_0x5a0dfc);}['onDisconnectPut'](_0x20fffe,_0x1b91b5,_0xbc369f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x20fffe,_0x1b91b5,_0xbc369f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x20fffe,'action':'o','data':_0x1b91b5,'onComplete':_0xbc369f});}['onDisconnectMerge'](_0x354dbf,_0x292c7b,_0xd6f5b3){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x354dbf,_0x292c7b,_0xd6f5b3):this['onDisconnectRequestQueue_']['push']({'pathString':_0x354dbf,'action':'om','data':_0x292c7b,'onComplete':_0xd6f5b3});}['onDisconnectCancel'](_0xed9295,_0x273e7e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xed9295,null,_0x273e7e):this['onDisconnectRequestQueue_']['push']({'pathString':_0xed9295,'action':'oc','data':null,'onComplete':_0x273e7e});}['sendOnDisconnect_'](_0x514780,_0x245154,_0x199b45,_0x53dea6){const _0xe83813={'p':_0x245154,'d':_0x199b45};this['log_']('onDisconnect\x20'+_0x514780,_0xe83813),this['sendRequest'](_0x514780,_0xe83813,_0x138298=>{_0x53dea6&&setTimeout(()=>{_0x53dea6(_0x138298['s'],_0x138298['d']);},Math['floor'](0x0));});}['put'](_0x2d793d,_0x51ad32,_0x378777,_0x154e94){this['putInternal']('p',_0x2d793d,_0x51ad32,_0x378777,_0x154e94);}['merge'](_0x408c73,_0x362a35,_0x555df7,_0x4cca30){this['putInternal']('m',_0x408c73,_0x362a35,_0x555df7,_0x4cca30);}['putInternal'](_0x2778e6,_0x1f47b5,_0x4114e6,_0x14c257,_0x249c2c){this['initConnection_']();const _0x5191e6={'p':_0x1f47b5,'d':_0x4114e6};_0x249c2c!==void 0x0&&(_0x5191e6['h']=_0x249c2c),this['outstandingPuts_']['push']({'action':_0x2778e6,'request':_0x5191e6,'onComplete':_0x14c257}),this['outstandingPutCount_']++;const _0x318367=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x318367):this['log_']('Buffering\x20put:\x20'+_0x1f47b5);}['sendPut_'](_0x31e424){const _0x451d39=this['outstandingPuts_'][_0x31e424]['action'],_0x3166c1=this['outstandingPuts_'][_0x31e424]['request'],_0x424ca7=this['outstandingPuts_'][_0x31e424]['onComplete'];this['outstandingPuts_'][_0x31e424]['queued']=this['connected_'],this['sendRequest'](_0x451d39,_0x3166c1,_0x1ca2c1=>{this['log_'](_0x451d39+'\x20response',_0x1ca2c1),delete this['outstandingPuts_'][_0x31e424],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x424ca7&&_0x424ca7(_0x1ca2c1['s'],_0x1ca2c1['d']);});}['reportStats'](_0xb12d2f){if(this['connected_']){const _0x63ce06={'c':_0xb12d2f};this['log_']('reportStats',_0x63ce06),this['sendRequest']('s',_0x63ce06,_0x2e778c=>{if(_0x2e778c['s']!=='ok'){const _0xe979e1=_0x2e778c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xe979e1);}});}}['onDataMessage_'](_0x1cca7b){if('r'in _0x1cca7b){this['log_']('from\x20server:\x20'+O(_0x1cca7b));const _0x239be3=_0x1cca7b['r'],_0x3f1104=this['requestCBHash_'][_0x239be3];_0x3f1104&&(delete this['requestCBHash_'][_0x239be3],_0x3f1104(_0x1cca7b['b']));}else{if('error'in _0x1cca7b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1cca7b['error'];'a'in _0x1cca7b&&this['onDataPush_'](_0x1cca7b['a'],_0x1cca7b['b']);}}['onDataPush_'](_0x18615f,_0x1a100d){this['log_']('handleServerMessage',_0x18615f,_0x1a100d),_0x18615f==='d'?this['onDataUpdate_'](_0x1a100d['p'],_0x1a100d['d'],!0x1,_0x1a100d['t']):_0x18615f==='m'?this['onDataUpdate_'](_0x1a100d['p'],_0x1a100d['d'],!0x0,_0x1a100d['t']):_0x18615f==='c'?this['onListenRevoked_'](_0x1a100d['p'],_0x1a100d['q']):_0x18615f==='ac'?this['onAuthRevoked_'](_0x1a100d['s'],_0x1a100d['d']):_0x18615f==='apc'?this['onAppCheckRevoked_'](_0x1a100d['s'],_0x1a100d['d']):_0x18615f==='sd'?this['onSecurityDebugPacket_'](_0x1a100d):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x18615f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4e3a73,_0x9a6ae0){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4e3a73),this['lastSessionId']=_0x9a6ae0,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x34c990){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x34c990));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x3036c7){_0x3036c7&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x3036c7;}['onOnline_'](_0x293696){_0x293696?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x31e5e0=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xdd9203=Math['max'](0x0,this['reconnectDelay_']-_0x31e5e0);_0xdd9203=Math['random']()*_0xdd9203,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xdd9203+'ms'),this['scheduleConnect_'](_0xdd9203),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x130b00=this['onDataMessage_']['bind'](this),_0x280cf4=this['onReady_']['bind'](this),_0x103e2f=this['onRealtimeDisconnect_']['bind'](this),_0x339910=this['id']+':'+se['nextConnectionId_']++,_0x10dc93=this['lastSessionId'];let _0x1c3b1f=!0x1,_0x230ef3=null;const _0x54c753=function(){_0x230ef3?_0x230ef3['close']():(_0x1c3b1f=!0x0,_0x103e2f());},_0xfa4b94=function(_0x5c5b91){f(_0x230ef3,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x230ef3['sendRequest'](_0x5c5b91);};this['realtime_']={'close':_0x54c753,'sendRequest':_0xfa4b94};const _0x4de12b=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x47259a,_0x533d1d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4de12b),this['appCheckTokenProvider_']['getToken'](_0x4de12b)]);_0x1c3b1f?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x47259a&&_0x47259a['accessToken'],this['appCheckToken_']=_0x533d1d&&_0x533d1d['token'],_0x230ef3=new Sh(_0x339910,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x130b00,_0x280cf4,_0x103e2f,_0x63fea9=>{U(_0x63fea9+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x10dc93));}catch(_0x44470f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x44470f),_0x1c3b1f||(this['repoInfo_']['nodeAdmin']&&U(_0x44470f),_0x54c753());}}}['interrupt'](_0x293ace){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x293ace),this['interruptReasons_'][_0x293ace]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4416ad){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4416ad),delete this['interruptReasons_'][_0x4416ad],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5b04e3){const _0x1171b3=_0x5b04e3-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1171b3});}['cancelSentTransactions_'](){for(let _0x11f223=0x0;_0x11f223<this['outstandingPuts_']['length'];_0x11f223++){const _0xf9de2f=this['outstandingPuts_'][_0x11f223];_0xf9de2f&&'h'in _0xf9de2f['request']&&_0xf9de2f['queued']&&(_0xf9de2f['onComplete']&&_0xf9de2f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x11f223],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x23c2de,_0x591924){let _0x1f2c46;_0x591924?_0x1f2c46=_0x591924['map'](_0x3b2254=>$i(_0x3b2254))['join']('$'):_0x1f2c46='default';const _0x37b2dd=this['removeListen_'](_0x23c2de,_0x1f2c46);_0x37b2dd&&_0x37b2dd['onComplete']&&_0x37b2dd['onComplete']('permission_denied');}['removeListen_'](_0xe704f4,_0x23e976){const _0x5ec5ce=new C(_0xe704f4)['toString']();let _0x38ce4;if(this['listens']['has'](_0x5ec5ce)){const _0x35d1ec=this['listens']['get'](_0x5ec5ce);_0x38ce4=_0x35d1ec['get'](_0x23e976),_0x35d1ec['delete'](_0x23e976),_0x35d1ec['size']===0x0&&this['listens']['delete'](_0x5ec5ce);}else _0x38ce4=void 0x0;return _0x38ce4;}['onAuthRevoked_'](_0x494efd,_0x3da804){L('Auth\x20token\x20revoked:\x20'+_0x494efd+'/'+_0x3da804),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x494efd==='invalid_token'||_0x494efd==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4c01a8,_0x3ba666){L('App\x20check\x20token\x20revoked:\x20'+_0x4c01a8+'/'+_0x3ba666),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4c01a8==='invalid_token'||_0x4c01a8==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x5c4d35){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x5c4d35):'msg'in _0x5c4d35&&console['log']('FIREBASE:\x20'+_0x5c4d35['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3dbbe1 of this['listens']['values']())for(const _0x21a279 of _0x3dbbe1['values']())this['sendListen_'](_0x21a279);for(let _0xaf56f1=0x0;_0xaf56f1<this['outstandingPuts_']['length'];_0xaf56f1++)this['outstandingPuts_'][_0xaf56f1]&&this['sendPut_'](_0xaf56f1);for(;this['onDisconnectRequestQueue_']['length'];){const _0x33bd89=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x33bd89['action'],_0x33bd89['pathString'],_0x33bd89['data'],_0x33bd89['onComplete']);}for(let _0x17b414=0x0;_0x17b414<this['outstandingGets_']['length'];_0x17b414++)this['outstandingGets_'][_0x17b414]&&this['sendGet_'](_0x17b414);}['sendConnectStats_'](){const _0x27f524={};let _0x337d86='js';_0x27f524['sdk.'+_0x337d86+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x27f524['framework.cordova']=0x1:Kr()&&(_0x27f524['framework.reactnative']=0x1),this['reportStats'](_0x27f524);}['shouldReconnect_'](){const _0x377366=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x377366;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x1da46a,_0x446a23){this['name']=_0x1da46a,this['node']=_0x446a23;}static['Wrap'](_0x4354bc,_0x479798){return new E(_0x4354bc,_0x479798);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x42316a,_0x222b8b){const _0x3459fa=new E(We,_0x42316a),_0x16bdf9=new E(We,_0x222b8b);return this['compare'](_0x3459fa,_0x16bdf9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x46ce33){sn=_0x46ce33;}['compare'](_0x3063ac,_0xed4856){return qe(_0x3063ac['name'],_0xed4856['name']);}['isDefinedOn'](_0x422358){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3266b9,_0x507edb){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x2fbd75,_0x4c71ce){return f(typeof _0x2fbd75=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2fbd75,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x529240,_0x464428,_0x3733e7,_0xfb872b,_0x5839d2=null){this['isReverse_']=_0xfb872b,this['resultGenerator_']=_0x5839d2,this['nodeStack_']=[];let _0x52c508=0x1;for(;!_0x529240['isEmpty']();)if(_0x529240=_0x529240,_0x52c508=_0x464428?_0x3733e7(_0x529240['key'],_0x464428):0x1,_0xfb872b&&(_0x52c508*=-0x1),_0x52c508<0x0)this['isReverse_']?_0x529240=_0x529240['left']:_0x529240=_0x529240['right'];else{if(_0x52c508===0x0){this['nodeStack_']['push'](_0x529240);break;}else this['nodeStack_']['push'](_0x529240),this['isReverse_']?_0x529240=_0x529240['right']:_0x529240=_0x529240['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3affd3=this['nodeStack_']['pop'](),_0x18a559;if(this['resultGenerator_']?_0x18a559=this['resultGenerator_'](_0x3affd3['key'],_0x3affd3['value']):_0x18a559={'key':_0x3affd3['key'],'value':_0x3affd3['value']},this['isReverse_']){for(_0x3affd3=_0x3affd3['left'];!_0x3affd3['isEmpty']();)this['nodeStack_']['push'](_0x3affd3),_0x3affd3=_0x3affd3['right'];}else{for(_0x3affd3=_0x3affd3['right'];!_0x3affd3['isEmpty']();)this['nodeStack_']['push'](_0x3affd3),_0x3affd3=_0x3affd3['left'];}return _0x18a559;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x594576=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x594576['key'],_0x594576['value']):{'key':_0x594576['key'],'value':_0x594576['value']};}}class M{constructor(_0x5c24bd,_0x470d29,_0x3f588f,_0x68ecf2,_0x429e7c){this['key']=_0x5c24bd,this['value']=_0x470d29,this['color']=_0x3f588f??M['RED'],this['left']=_0x68ecf2??B['EMPTY_NODE'],this['right']=_0x429e7c??B['EMPTY_NODE'];}['copy'](_0x6298ad,_0x3010ff,_0x561fe7,_0xf5bda0,_0x40318f){return new M(_0x6298ad??this['key'],_0x3010ff??this['value'],_0x561fe7??this['color'],_0xf5bda0??this['left'],_0x40318f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x25bd71){return this['left']['inorderTraversal'](_0x25bd71)||!!_0x25bd71(this['key'],this['value'])||this['right']['inorderTraversal'](_0x25bd71);}['reverseTraversal'](_0x2137a0){return this['right']['reverseTraversal'](_0x2137a0)||_0x2137a0(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2137a0);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x158911,_0x8d16b0,_0x15d7d5){let _0x2a296d=this;const _0x4e251b=_0x15d7d5(_0x158911,_0x2a296d['key']);return _0x4e251b<0x0?_0x2a296d=_0x2a296d['copy'](null,null,null,_0x2a296d['left']['insert'](_0x158911,_0x8d16b0,_0x15d7d5),null):_0x4e251b===0x0?_0x2a296d=_0x2a296d['copy'](null,_0x8d16b0,null,null,null):_0x2a296d=_0x2a296d['copy'](null,null,null,null,_0x2a296d['right']['insert'](_0x158911,_0x8d16b0,_0x15d7d5)),_0x2a296d['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x5dca2d=this;return!_0x5dca2d['left']['isRed_']()&&!_0x5dca2d['left']['left']['isRed_']()&&(_0x5dca2d=_0x5dca2d['moveRedLeft_']()),_0x5dca2d=_0x5dca2d['copy'](null,null,null,_0x5dca2d['left']['removeMin_'](),null),_0x5dca2d['fixUp_']();}['remove'](_0x4c7b97,_0xca982){let _0x35ddc9,_0x5c2d06;if(_0x35ddc9=this,_0xca982(_0x4c7b97,_0x35ddc9['key'])<0x0)!_0x35ddc9['left']['isEmpty']()&&!_0x35ddc9['left']['isRed_']()&&!_0x35ddc9['left']['left']['isRed_']()&&(_0x35ddc9=_0x35ddc9['moveRedLeft_']()),_0x35ddc9=_0x35ddc9['copy'](null,null,null,_0x35ddc9['left']['remove'](_0x4c7b97,_0xca982),null);else{if(_0x35ddc9['left']['isRed_']()&&(_0x35ddc9=_0x35ddc9['rotateRight_']()),!_0x35ddc9['right']['isEmpty']()&&!_0x35ddc9['right']['isRed_']()&&!_0x35ddc9['right']['left']['isRed_']()&&(_0x35ddc9=_0x35ddc9['moveRedRight_']()),_0xca982(_0x4c7b97,_0x35ddc9['key'])===0x0){if(_0x35ddc9['right']['isEmpty']())return B['EMPTY_NODE'];_0x5c2d06=_0x35ddc9['right']['min_'](),_0x35ddc9=_0x35ddc9['copy'](_0x5c2d06['key'],_0x5c2d06['value'],null,null,_0x35ddc9['right']['removeMin_']());}_0x35ddc9=_0x35ddc9['copy'](null,null,null,null,_0x35ddc9['right']['remove'](_0x4c7b97,_0xca982));}return _0x35ddc9['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2dd927=this;return _0x2dd927['right']['isRed_']()&&!_0x2dd927['left']['isRed_']()&&(_0x2dd927=_0x2dd927['rotateLeft_']()),_0x2dd927['left']['isRed_']()&&_0x2dd927['left']['left']['isRed_']()&&(_0x2dd927=_0x2dd927['rotateRight_']()),_0x2dd927['left']['isRed_']()&&_0x2dd927['right']['isRed_']()&&(_0x2dd927=_0x2dd927['colorFlip_']()),_0x2dd927;}['moveRedLeft_'](){let _0x176c0d=this['colorFlip_']();return _0x176c0d['right']['left']['isRed_']()&&(_0x176c0d=_0x176c0d['copy'](null,null,null,null,_0x176c0d['right']['rotateRight_']()),_0x176c0d=_0x176c0d['rotateLeft_'](),_0x176c0d=_0x176c0d['colorFlip_']()),_0x176c0d;}['moveRedRight_'](){let _0xe54a04=this['colorFlip_']();return _0xe54a04['left']['left']['isRed_']()&&(_0xe54a04=_0xe54a04['rotateRight_'](),_0xe54a04=_0xe54a04['colorFlip_']()),_0xe54a04;}['rotateLeft_'](){const _0x2c5b5c=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2c5b5c,null);}['rotateRight_'](){const _0x5d4a8b=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5d4a8b);}['colorFlip_'](){const _0x4478b0=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x168f75=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x4478b0,_0x168f75);}['checkMaxDepth_'](){const _0x15c02a=this['check_']();return Math['pow'](0x2,_0x15c02a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x411be5=this['left']['check_']();if(_0x411be5!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x411be5+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x2fc065,_0x308bf9,_0x59c874,_0x5a9b4a,_0x34b2ef){return this;}['insert'](_0x1abc2a,_0x21a82b,_0x586f01){return new M(_0x1abc2a,_0x21a82b,null);}['remove'](_0x1c8a45,_0x13cd28){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x520ae8){return!0x1;}['reverseTraversal'](_0x3a4450){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1ea8e2,_0x36a3d2=B['EMPTY_NODE']){this['comparator_']=_0x1ea8e2,this['root_']=_0x36a3d2;}['insert'](_0x1a8552,_0x5e9537){return new B(this['comparator_'],this['root_']['insert'](_0x1a8552,_0x5e9537,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x526499){return new B(this['comparator_'],this['root_']['remove'](_0x526499,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x55c0e0){let _0x487403,_0x1117bd=this['root_'];for(;!_0x1117bd['isEmpty']();){if(_0x487403=this['comparator_'](_0x55c0e0,_0x1117bd['key']),_0x487403===0x0)return _0x1117bd['value'];_0x487403<0x0?_0x1117bd=_0x1117bd['left']:_0x487403>0x0&&(_0x1117bd=_0x1117bd['right']);}return null;}['getPredecessorKey'](_0x65a592){let _0x214986,_0x29f298=this['root_'],_0x5ee652=null;for(;!_0x29f298['isEmpty']();)if(_0x214986=this['comparator_'](_0x65a592,_0x29f298['key']),_0x214986===0x0){if(_0x29f298['left']['isEmpty']())return _0x5ee652?_0x5ee652['key']:null;for(_0x29f298=_0x29f298['left'];!_0x29f298['right']['isEmpty']();)_0x29f298=_0x29f298['right'];return _0x29f298['key'];}else _0x214986<0x0?_0x29f298=_0x29f298['left']:_0x214986>0x0&&(_0x5ee652=_0x29f298,_0x29f298=_0x29f298['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x259498){return this['root_']['inorderTraversal'](_0x259498);}['reverseTraversal'](_0x16974a){return this['root_']['reverseTraversal'](_0x16974a);}['getIterator'](_0x28afa9){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x28afa9);}['getIteratorFrom'](_0x384247,_0xe21a49){return new rn(this['root_'],_0x384247,this['comparator_'],!0x1,_0xe21a49);}['getReverseIteratorFrom'](_0x5ce992,_0xd28c04){return new rn(this['root_'],_0x5ce992,this['comparator_'],!0x0,_0xd28c04);}['getReverseIterator'](_0x1ad3ed){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1ad3ed);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x403c59,_0x5e0567){return qe(_0x403c59['name'],_0x5e0567['name']);}function Qi(_0x722a21,_0x467ac9){return qe(_0x722a21,_0x467ac9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x549a5b){Ci=_0x549a5b;}const Po=function(_0x53ecbf){return typeof _0x53ecbf=='number'?'number:'+ao(_0x53ecbf):'string:'+_0x53ecbf;},No=function(_0x23b498){if(_0x23b498['isLeafNode']()){const _0x20ec76=_0x23b498['val']();f(typeof _0x20ec76=='string'||typeof _0x20ec76=='number'||typeof _0x20ec76=='object'&&Q(_0x20ec76,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x23b498===Ci||_0x23b498['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x23b498===Ci||_0x23b498['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x4ec74a){nr=_0x4ec74a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x3c5cd9,_0x25d984=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x3c5cd9,this['priorityNode_']=_0x25d984,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x400d33){return new D(this['value_'],_0x400d33);}['getImmediateChild'](_0x57871b){return _0x57871b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4e2273){return v(_0x4e2273)?this:y(_0x4e2273)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0xd813b8,_0x39613b){return null;}['updateImmediateChild'](_0x21cbe3,_0x1b64ee){return _0x21cbe3==='.priority'?this['updatePriority'](_0x1b64ee):_0x1b64ee['isEmpty']()&&_0x21cbe3!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x21cbe3,_0x1b64ee)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2b9af3,_0x46ea35){const _0x45a83f=y(_0x2b9af3);return _0x45a83f===null?_0x46ea35:_0x46ea35['isEmpty']()&&_0x45a83f!=='.priority'?this:(f(_0x45a83f!=='.priority'||Ce(_0x2b9af3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x45a83f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2b9af3),_0x46ea35)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x63d67,_0x792dab){return!0x1;}['val'](_0x23f1a5){return _0x23f1a5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1020d9='';this['priorityNode_']['isEmpty']()||(_0x1020d9+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x4a40ea=typeof this['value_'];_0x1020d9+=_0x4a40ea+':',_0x4a40ea==='number'?_0x1020d9+=ao(this['value_']):_0x1020d9+=this['value_'],this['lazyHash_']=ro(_0x1020d9);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1d8b78){return _0x1d8b78===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1d8b78 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1d8b78['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1d8b78));}['compareToLeafNode_'](_0x54e24e){const _0x526bf8=typeof _0x54e24e['value_'],_0x47f09c=typeof this['value_'],_0x2babfb=D['VALUE_TYPE_ORDER']['indexOf'](_0x526bf8),_0x14a462=D['VALUE_TYPE_ORDER']['indexOf'](_0x47f09c);return f(_0x2babfb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x526bf8),f(_0x14a462>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x47f09c),_0x2babfb===_0x14a462?_0x47f09c==='object'?0x0:this['value_']<_0x54e24e['value_']?-0x1:this['value_']===_0x54e24e['value_']?0x0:0x1:_0x14a462-_0x2babfb;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x527597){if(_0x527597===this)return!0x0;if(_0x527597['isLeafNode']()){const _0x576bfc=_0x527597;return this['value_']===_0x576bfc['value_']&&this['priorityNode_']['equals'](_0x576bfc['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x14f721){Oo=_0x14f721;}function Wh(_0x46608e){Do=_0x46608e;}class Bh extends Fn{['compare'](_0x2640c4,_0x370eeb){const _0x1518a8=_0x2640c4['node']['getPriority'](),_0x12a070=_0x370eeb['node']['getPriority'](),_0x3a3f0c=_0x1518a8['compareTo'](_0x12a070);return _0x3a3f0c===0x0?qe(_0x2640c4['name'],_0x370eeb['name']):_0x3a3f0c;}['isDefinedOn'](_0x187623){return!_0x187623['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x13e3b7,_0x460937){return!_0x13e3b7['getPriority']()['equals'](_0x460937['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x3e8900,_0x5246bc){const _0x1c8854=Oo(_0x3e8900);return new E(_0x5246bc,new D('[PRIORITY-POST]',_0x1c8854));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x419e49){const _0x43b8cb=_0x543aca=>parseInt(Math['log'](_0x543aca)/Vh,0xa),_0x5236c8=_0x3747c9=>parseInt(Array(_0x3747c9+0x1)['join']('1'),0x2);this['count']=_0x43b8cb(_0x419e49+0x1),this['current_']=this['count']-0x1;const _0x3ec85e=_0x5236c8(this['count']);this['bits_']=_0x419e49+0x1&_0x3ec85e;}['nextBitIsOne'](){const _0x4eb19b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4eb19b;}}const yn=function(_0x2487b8,_0x403281,_0x588398,_0x35d4c0){_0x2487b8['sort'](_0x403281);const _0x2370bb=function(_0x2597cf,_0x525edc){const _0x2c8ded=_0x525edc-_0x2597cf;let _0x1fd5c0,_0x4f547c;if(_0x2c8ded===0x0)return null;if(_0x2c8ded===0x1)return _0x1fd5c0=_0x2487b8[_0x2597cf],_0x4f547c=_0x588398?_0x588398(_0x1fd5c0):_0x1fd5c0,new M(_0x4f547c,_0x1fd5c0['node'],M['BLACK'],null,null);{const _0x37eca3=parseInt(_0x2c8ded/0x2,0xa)+_0x2597cf,_0x1c6683=_0x2370bb(_0x2597cf,_0x37eca3),_0x928786=_0x2370bb(_0x37eca3+0x1,_0x525edc);return _0x1fd5c0=_0x2487b8[_0x37eca3],_0x4f547c=_0x588398?_0x588398(_0x1fd5c0):_0x1fd5c0,new M(_0x4f547c,_0x1fd5c0['node'],M['BLACK'],_0x1c6683,_0x928786);}},_0x16d482=function(_0x40355){let _0x33bc33=null,_0x251cc6=null,_0x18425a=_0x2487b8['length'];const _0x262615=function(_0x563f3b,_0x27f1ef){const _0x3acf1d=_0x18425a-_0x563f3b,_0x461d44=_0x18425a;_0x18425a-=_0x563f3b;const _0x2d4bff=_0x2370bb(_0x3acf1d+0x1,_0x461d44),_0x5eb317=_0x2487b8[_0x3acf1d],_0x3cad37=_0x588398?_0x588398(_0x5eb317):_0x5eb317;_0x480b4c(new M(_0x3cad37,_0x5eb317['node'],_0x27f1ef,null,_0x2d4bff));},_0x480b4c=function(_0x249749){_0x33bc33?(_0x33bc33['left']=_0x249749,_0x33bc33=_0x249749):(_0x251cc6=_0x249749,_0x33bc33=_0x249749);};for(let _0x2b7d6f=0x0;_0x2b7d6f<_0x40355['count'];++_0x2b7d6f){const _0x136c43=_0x40355['nextBitIsOne'](),_0x497b36=Math['pow'](0x2,_0x40355['count']-(_0x2b7d6f+0x1));_0x136c43?_0x262615(_0x497b36,M['BLACK']):(_0x262615(_0x497b36,M['BLACK']),_0x262615(_0x497b36,M['RED']));}return _0x251cc6;},_0x33f5d1=new Hh(_0x2487b8['length']),_0x56e8af=_0x16d482(_0x33f5d1);return new B(_0x35d4c0||_0x403281,_0x56e8af);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x7a8100,_0x5d359f){this['indexes_']=_0x7a8100,this['indexSet_']=_0x5d359f;}['get'](_0x3ee680){const _0x8963cf=Le(this['indexes_'],_0x3ee680);if(!_0x8963cf)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3ee680);return _0x8963cf instanceof B?_0x8963cf:null;}['hasIndex'](_0x143e83){return Q(this['indexSet_'],_0x143e83['toString']());}['addIndex'](_0x57e86b,_0x166bda){f(_0x57e86b!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x54e88c=[];let _0x5f420b=!0x1;const _0x1f56dc=_0x166bda['getIterator'](E['Wrap']);let _0x27a11b=_0x1f56dc['getNext']();for(;_0x27a11b;)_0x5f420b=_0x5f420b||_0x57e86b['isDefinedOn'](_0x27a11b['node']),_0x54e88c['push'](_0x27a11b),_0x27a11b=_0x1f56dc['getNext']();let _0x342b1e;_0x5f420b?_0x342b1e=yn(_0x54e88c,_0x57e86b['getCompare']()):_0x342b1e=Qe;const _0x14a1a0=_0x57e86b['toString'](),_0x45e42a={...this['indexSet_']};_0x45e42a[_0x14a1a0]=_0x57e86b;const _0x2f5a63={...this['indexes_']};return _0x2f5a63[_0x14a1a0]=_0x342b1e,new te(_0x2f5a63,_0x45e42a);}['addToIndexes'](_0x50303b,_0x29c173){const _0xdada3e=_n(this['indexes_'],(_0x9508c3,_0x168e4f)=>{const _0x27eebb=Le(this['indexSet_'],_0x168e4f);if(f(_0x27eebb,'Missing\x20index\x20implementation\x20for\x20'+_0x168e4f),_0x9508c3===Qe){if(_0x27eebb['isDefinedOn'](_0x50303b['node'])){const _0x2c1c01=[],_0x3dda65=_0x29c173['getIterator'](E['Wrap']);let _0x45f833=_0x3dda65['getNext']();for(;_0x45f833;)_0x45f833['name']!==_0x50303b['name']&&_0x2c1c01['push'](_0x45f833),_0x45f833=_0x3dda65['getNext']();return _0x2c1c01['push'](_0x50303b),yn(_0x2c1c01,_0x27eebb['getCompare']());}else return Qe;}else{const _0x40df0f=_0x29c173['get'](_0x50303b['name']);let _0xcbb4f6=_0x9508c3;return _0x40df0f&&(_0xcbb4f6=_0xcbb4f6['remove'](new E(_0x50303b['name'],_0x40df0f))),_0xcbb4f6['insert'](_0x50303b,_0x50303b['node']);}});return new te(_0xdada3e,this['indexSet_']);}['removeFromIndexes'](_0xb4b77f,_0x49ee02){const _0x5a27e5=_n(this['indexes_'],_0x43981d=>{if(_0x43981d===Qe)return _0x43981d;{const _0x518423=_0x49ee02['get'](_0xb4b77f['name']);return _0x518423?_0x43981d['remove'](new E(_0xb4b77f['name'],_0x518423)):_0x43981d;}});return new te(_0x5a27e5,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x196d90,_0x23f430,_0x5a33fc){this['children_']=_0x196d90,this['priorityNode_']=_0x23f430,this['indexMap_']=_0x5a33fc,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0xdf9fbf){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xdf9fbf,this['indexMap_']);}['getImmediateChild'](_0x47534b){if(_0x47534b==='.priority')return this['getPriority']();{const _0x2bbc3c=this['children_']['get'](_0x47534b);return _0x2bbc3c===null?It:_0x2bbc3c;}}['getChild'](_0x1b17d6){const _0x671c5f=y(_0x1b17d6);return _0x671c5f===null?this:this['getImmediateChild'](_0x671c5f)['getChild'](S(_0x1b17d6));}['hasChild'](_0xfb8c56){return this['children_']['get'](_0xfb8c56)!==null;}['updateImmediateChild'](_0x1aa565,_0x50aad6){if(f(_0x50aad6,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1aa565==='.priority')return this['updatePriority'](_0x50aad6);{const _0x1a505b=new E(_0x1aa565,_0x50aad6);let _0x507da9,_0xf97a89;_0x50aad6['isEmpty']()?(_0x507da9=this['children_']['remove'](_0x1aa565),_0xf97a89=this['indexMap_']['removeFromIndexes'](_0x1a505b,this['children_'])):(_0x507da9=this['children_']['insert'](_0x1aa565,_0x50aad6),_0xf97a89=this['indexMap_']['addToIndexes'](_0x1a505b,this['children_']));const _0xb100e2=_0x507da9['isEmpty']()?It:this['priorityNode_'];return new g(_0x507da9,_0xb100e2,_0xf97a89);}}['updateChild'](_0x4111f9,_0x1a2224){const _0x306ef2=y(_0x4111f9);if(_0x306ef2===null)return _0x1a2224;{f(y(_0x4111f9)!=='.priority'||Ce(_0x4111f9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x356086=this['getImmediateChild'](_0x306ef2)['updateChild'](S(_0x4111f9),_0x1a2224);return this['updateImmediateChild'](_0x306ef2,_0x356086);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4d40d5){if(this['isEmpty']())return null;const _0x3ac164={};let _0x9ff346=0x0,_0x3e9b70=0x0,_0x1a0eb9=!0x0;if(this['forEachChild'](R,(_0x1809a3,_0x2940df)=>{_0x3ac164[_0x1809a3]=_0x2940df['val'](_0x4d40d5),_0x9ff346++,_0x1a0eb9&&g['INTEGER_REGEXP_']['test'](_0x1809a3)?_0x3e9b70=Math['max'](_0x3e9b70,Number(_0x1809a3)):_0x1a0eb9=!0x1;}),!_0x4d40d5&&_0x1a0eb9&&_0x3e9b70<0x2*_0x9ff346){const _0xb096f4=[];for(const _0x430154 in _0x3ac164)_0xb096f4[_0x430154]=_0x3ac164[_0x430154];return _0xb096f4;}else return _0x4d40d5&&!this['getPriority']()['isEmpty']()&&(_0x3ac164['.priority']=this['getPriority']()['val']()),_0x3ac164;}['hash'](){if(this['lazyHash_']===null){let _0x153641='';this['getPriority']()['isEmpty']()||(_0x153641+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x23f033,_0x3a8ab7)=>{const _0x273454=_0x3a8ab7['hash']();_0x273454!==''&&(_0x153641+=':'+_0x23f033+':'+_0x273454);}),this['lazyHash_']=_0x153641===''?'':ro(_0x153641);}return this['lazyHash_'];}['getPredecessorChildName'](_0x38879c,_0x4ee11d,_0x790aa6){const _0x5b0cfa=this['resolveIndex_'](_0x790aa6);if(_0x5b0cfa){const _0x43b3ef=_0x5b0cfa['getPredecessorKey'](new E(_0x38879c,_0x4ee11d));return _0x43b3ef?_0x43b3ef['name']:null;}else return this['children_']['getPredecessorKey'](_0x38879c);}['getFirstChildName'](_0x16c8a5){const _0x33fad1=this['resolveIndex_'](_0x16c8a5);if(_0x33fad1){const _0x299ae4=_0x33fad1['minKey']();return _0x299ae4&&_0x299ae4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5135c4){const _0x337d23=this['getFirstChildName'](_0x5135c4);return _0x337d23?new E(_0x337d23,this['children_']['get'](_0x337d23)):null;}['getLastChildName'](_0x1d6f7f){const _0x5c40f3=this['resolveIndex_'](_0x1d6f7f);if(_0x5c40f3){const _0x2fd223=_0x5c40f3['maxKey']();return _0x2fd223&&_0x2fd223['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x587063){const _0x2d2f0f=this['getLastChildName'](_0x587063);return _0x2d2f0f?new E(_0x2d2f0f,this['children_']['get'](_0x2d2f0f)):null;}['forEachChild'](_0x92a35c,_0x150181){const _0x47f54c=this['resolveIndex_'](_0x92a35c);return _0x47f54c?_0x47f54c['inorderTraversal'](_0x2b71e3=>_0x150181(_0x2b71e3['name'],_0x2b71e3['node'])):this['children_']['inorderTraversal'](_0x150181);}['getIterator'](_0x46a02c){return this['getIteratorFrom'](_0x46a02c['minPost'](),_0x46a02c);}['getIteratorFrom'](_0x5a51b0,_0xe0190c){const _0x538892=this['resolveIndex_'](_0xe0190c);if(_0x538892)return _0x538892['getIteratorFrom'](_0x5a51b0,_0x225222=>_0x225222);{const _0x329c85=this['children_']['getIteratorFrom'](_0x5a51b0['name'],E['Wrap']);let _0x5aa7f8=_0x329c85['peek']();for(;_0x5aa7f8!=null&&_0xe0190c['compare'](_0x5aa7f8,_0x5a51b0)<0x0;)_0x329c85['getNext'](),_0x5aa7f8=_0x329c85['peek']();return _0x329c85;}}['getReverseIterator'](_0x36877d){return this['getReverseIteratorFrom'](_0x36877d['maxPost'](),_0x36877d);}['getReverseIteratorFrom'](_0x44dd77,_0x4c78b4){const _0xe4ed69=this['resolveIndex_'](_0x4c78b4);if(_0xe4ed69)return _0xe4ed69['getReverseIteratorFrom'](_0x44dd77,_0x1c977a=>_0x1c977a);{const _0x409f47=this['children_']['getReverseIteratorFrom'](_0x44dd77['name'],E['Wrap']);let _0x40789a=_0x409f47['peek']();for(;_0x40789a!=null&&_0x4c78b4['compare'](_0x40789a,_0x44dd77)>0x0;)_0x409f47['getNext'](),_0x40789a=_0x409f47['peek']();return _0x409f47;}}['compareTo'](_0x3088ce){return this['isEmpty']()?_0x3088ce['isEmpty']()?0x0:-0x1:_0x3088ce['isLeafNode']()||_0x3088ce['isEmpty']()?0x1:_0x3088ce===Kt?-0x1:0x0;}['withIndex'](_0x5855ab){if(_0x5855ab===ve||this['indexMap_']['hasIndex'](_0x5855ab))return this;{const _0x191173=this['indexMap_']['addIndex'](_0x5855ab,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x191173);}}['isIndexed'](_0x21685a){return _0x21685a===ve||this['indexMap_']['hasIndex'](_0x21685a);}['equals'](_0x555f27){if(_0x555f27===this)return!0x0;if(_0x555f27['isLeafNode']())return!0x1;{const _0x330b14=_0x555f27;if(this['getPriority']()['equals'](_0x330b14['getPriority']())){if(this['children_']['count']()===_0x330b14['children_']['count']()){const _0x3c2220=this['getIterator'](R),_0x46612b=_0x330b14['getIterator'](R);let _0x48cce2=_0x3c2220['getNext'](),_0x185727=_0x46612b['getNext']();for(;_0x48cce2&&_0x185727;){if(_0x48cce2['name']!==_0x185727['name']||!_0x48cce2['node']['equals'](_0x185727['node']))return!0x1;_0x48cce2=_0x3c2220['getNext'](),_0x185727=_0x46612b['getNext']();}return _0x48cce2===null&&_0x185727===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3bb731){return _0x3bb731===ve?null:this['indexMap_']['get'](_0x3bb731['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4a59c5){return _0x4a59c5===this?0x0:0x1;}['equals'](_0xfad9d2){return _0xfad9d2===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2ff90b){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x33f067,_0x14732e=null){if(_0x33f067===null)return g['EMPTY_NODE'];if(typeof _0x33f067=='object'&&'.priority'in _0x33f067&&(_0x14732e=_0x33f067['.priority']),f(_0x14732e===null||typeof _0x14732e=='string'||typeof _0x14732e=='number'||typeof _0x14732e=='object'&&'.sv'in _0x14732e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x14732e),typeof _0x33f067=='object'&&'.value'in _0x33f067&&_0x33f067['.value']!==null&&(_0x33f067=_0x33f067['.value']),typeof _0x33f067!='object'||'.sv'in _0x33f067){const _0x95e600=_0x33f067;return new D(_0x95e600,A(_0x14732e));}if(!(_0x33f067 instanceof Array)&&Gh){const _0xd1907d=[];let _0x35edf6=!0x1;if(x(_0x33f067,(_0x14f301,_0x4d342b)=>{if(_0x14f301['substring'](0x0,0x1)!=='.'){const _0x6c426a=A(_0x4d342b);_0x6c426a['isEmpty']()||(_0x35edf6=_0x35edf6||!_0x6c426a['getPriority']()['isEmpty'](),_0xd1907d['push'](new E(_0x14f301,_0x6c426a)));}}),_0xd1907d['length']===0x0)return g['EMPTY_NODE'];const _0x2f0829=yn(_0xd1907d,xh,_0x2f636e=>_0x2f636e['name'],Qi);if(_0x35edf6){const _0x59d5f2=yn(_0xd1907d,R['getCompare']());return new g(_0x2f0829,A(_0x14732e),new te({'.priority':_0x59d5f2},{'.priority':R}));}else return new g(_0x2f0829,A(_0x14732e),te['Default']);}else{let _0x2b5807=g['EMPTY_NODE'];return x(_0x33f067,(_0x2aa892,_0x3e8f24)=>{if(Q(_0x33f067,_0x2aa892)&&_0x2aa892['substring'](0x0,0x1)!=='.'){const _0x45f53e=A(_0x3e8f24);(_0x45f53e['isLeafNode']()||!_0x45f53e['isEmpty']())&&(_0x2b5807=_0x2b5807['updateImmediateChild'](_0x2aa892,_0x45f53e));}}),_0x2b5807['updatePriority'](A(_0x14732e));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x3098d3){super(),this['indexPath_']=_0x3098d3,f(!v(_0x3098d3)&&y(_0x3098d3)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x3f1a41){return _0x3f1a41['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2c9d3d){return!_0x2c9d3d['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x25616d,_0x2f1721){const _0x28a3e2=this['extractChild'](_0x25616d['node']),_0x495cec=this['extractChild'](_0x2f1721['node']),_0x50c046=_0x28a3e2['compareTo'](_0x495cec);return _0x50c046===0x0?qe(_0x25616d['name'],_0x2f1721['name']):_0x50c046;}['makePost'](_0x1210b4,_0x22ac42){const _0x444811=A(_0x1210b4),_0x1d31fa=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x444811);return new E(_0x22ac42,_0x1d31fa);}['maxPost'](){const _0x20ad05=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x20ad05);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x5d257f,_0x58ae5e){const _0x523c3a=_0x5d257f['node']['compareTo'](_0x58ae5e['node']);return _0x523c3a===0x0?qe(_0x5d257f['name'],_0x58ae5e['name']):_0x523c3a;}['isDefinedOn'](_0x3bffa1){return!0x0;}['indexedValueChanged'](_0x314b8c,_0x1661c2){return!_0x314b8c['equals'](_0x1661c2);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x266188,_0x4158c2){const _0x452a57=A(_0x266188);return new E(_0x4158c2,_0x452a57);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x254f4b){return{'type':'value','snapshotNode':_0x254f4b};}function rt(_0x1e3e39,_0x3fc027){return{'type':'child_added','snapshotNode':_0x3fc027,'childName':_0x1e3e39};}function Lt(_0x4bd611,_0x2516ea){return{'type':'child_removed','snapshotNode':_0x2516ea,'childName':_0x4bd611};}function xt(_0x904092,_0x1ae66e,_0x1e0710){return{'type':'child_changed','snapshotNode':_0x1ae66e,'childName':_0x904092,'oldSnap':_0x1e0710};}function zh(_0x1ee0a8,_0x4479dd){return{'type':'child_moved','snapshotNode':_0x4479dd,'childName':_0x1ee0a8};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1687ec){this['index_']=_0x1687ec;}['updateChild'](_0xabef08,_0x1eb8c2,_0xcd3033,_0x1e9c19,_0x23266f,_0x4a6a1f){f(_0xabef08['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x562599=_0xabef08['getImmediateChild'](_0x1eb8c2);return _0x562599['getChild'](_0x1e9c19)['equals'](_0xcd3033['getChild'](_0x1e9c19))&&_0x562599['isEmpty']()===_0xcd3033['isEmpty']()||(_0x4a6a1f!=null&&(_0xcd3033['isEmpty']()?_0xabef08['hasChild'](_0x1eb8c2)?_0x4a6a1f['trackChildChange'](Lt(_0x1eb8c2,_0x562599)):f(_0xabef08['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x562599['isEmpty']()?_0x4a6a1f['trackChildChange'](rt(_0x1eb8c2,_0xcd3033)):_0x4a6a1f['trackChildChange'](xt(_0x1eb8c2,_0xcd3033,_0x562599))),_0xabef08['isLeafNode']()&&_0xcd3033['isEmpty']())?_0xabef08:_0xabef08['updateImmediateChild'](_0x1eb8c2,_0xcd3033)['withIndex'](this['index_']);}['updateFullNode'](_0x5a4848,_0xa03ac0,_0x3ebfbd){return _0x3ebfbd!=null&&(_0x5a4848['isLeafNode']()||_0x5a4848['forEachChild'](R,(_0x1fe285,_0x46cbb7)=>{_0xa03ac0['hasChild'](_0x1fe285)||_0x3ebfbd['trackChildChange'](Lt(_0x1fe285,_0x46cbb7));}),_0xa03ac0['isLeafNode']()||_0xa03ac0['forEachChild'](R,(_0x163f7d,_0x13924d)=>{if(_0x5a4848['hasChild'](_0x163f7d)){const _0x3a0e2e=_0x5a4848['getImmediateChild'](_0x163f7d);_0x3a0e2e['equals'](_0x13924d)||_0x3ebfbd['trackChildChange'](xt(_0x163f7d,_0x13924d,_0x3a0e2e));}else _0x3ebfbd['trackChildChange'](rt(_0x163f7d,_0x13924d));})),_0xa03ac0['withIndex'](this['index_']);}['updatePriority'](_0x267524,_0x270e23){return _0x267524['isEmpty']()?g['EMPTY_NODE']:_0x267524['updatePriority'](_0x270e23);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x47ab33){this['indexedFilter_']=new Xi(_0x47ab33['getIndex']()),this['index_']=_0x47ab33['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x47ab33),this['endPost_']=Ft['getEndPost_'](_0x47ab33),this['startIsInclusive_']=!_0x47ab33['startAfterSet_'],this['endIsInclusive_']=!_0x47ab33['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3dcd47){const _0x545f22=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3dcd47)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3dcd47)<0x0,_0xf4f69b=this['endIsInclusive_']?this['index_']['compare'](_0x3dcd47,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3dcd47,this['getEndPost']())<0x0;return _0x545f22&&_0xf4f69b;}['updateChild'](_0x34c56c,_0x4e7fbe,_0x58ce42,_0x21e0f7,_0x5f5155,_0x5a2136){return this['matches'](new E(_0x4e7fbe,_0x58ce42))||(_0x58ce42=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x34c56c,_0x4e7fbe,_0x58ce42,_0x21e0f7,_0x5f5155,_0x5a2136);}['updateFullNode'](_0x4a75e2,_0x5b805d,_0x4285b1){_0x5b805d['isLeafNode']()&&(_0x5b805d=g['EMPTY_NODE']);let _0x4aaf9e=_0x5b805d['withIndex'](this['index_']);_0x4aaf9e=_0x4aaf9e['updatePriority'](g['EMPTY_NODE']);const _0x3a03f8=this;return _0x5b805d['forEachChild'](R,(_0x4ccf91,_0x2f2376)=>{_0x3a03f8['matches'](new E(_0x4ccf91,_0x2f2376))||(_0x4aaf9e=_0x4aaf9e['updateImmediateChild'](_0x4ccf91,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x4a75e2,_0x4aaf9e,_0x4285b1);}['updatePriority'](_0x5cd9d8,_0x4a76c4){return _0x5cd9d8;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x20ac19){if(_0x20ac19['hasStart']()){const _0x5de374=_0x20ac19['getIndexStartName']();return _0x20ac19['getIndex']()['makePost'](_0x20ac19['getIndexStartValue'](),_0x5de374);}else return _0x20ac19['getIndex']()['minPost']();}static['getEndPost_'](_0x3ee4d6){if(_0x3ee4d6['hasEnd']()){const _0x3ac569=_0x3ee4d6['getIndexEndName']();return _0x3ee4d6['getIndex']()['makePost'](_0x3ee4d6['getIndexEndValue'](),_0x3ac569);}else return _0x3ee4d6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2f069f){this['withinDirectionalStart']=_0x4ddfbb=>this['reverse_']?this['withinEndPost'](_0x4ddfbb):this['withinStartPost'](_0x4ddfbb),this['withinDirectionalEnd']=_0xfed5c3=>this['reverse_']?this['withinStartPost'](_0xfed5c3):this['withinEndPost'](_0xfed5c3),this['withinStartPost']=_0xfc0a2c=>{const _0xb568e5=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xfc0a2c);return this['startIsInclusive_']?_0xb568e5<=0x0:_0xb568e5<0x0;},this['withinEndPost']=_0x34c4b9=>{const _0x3a04c4=this['index_']['compare'](_0x34c4b9,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3a04c4<=0x0:_0x3a04c4<0x0;},this['rangedFilter_']=new Ft(_0x2f069f),this['index_']=_0x2f069f['getIndex'](),this['limit_']=_0x2f069f['getLimit'](),this['reverse_']=!_0x2f069f['isViewFromLeft'](),this['startIsInclusive_']=!_0x2f069f['startAfterSet_'],this['endIsInclusive_']=!_0x2f069f['endBeforeSet_'];}['updateChild'](_0x574a06,_0x494ac5,_0x2b1f50,_0x45d016,_0x3fd41d,_0x22fd36){return this['rangedFilter_']['matches'](new E(_0x494ac5,_0x2b1f50))||(_0x2b1f50=g['EMPTY_NODE']),_0x574a06['getImmediateChild'](_0x494ac5)['equals'](_0x2b1f50)?_0x574a06:_0x574a06['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x574a06,_0x494ac5,_0x2b1f50,_0x45d016,_0x3fd41d,_0x22fd36):this['fullLimitUpdateChild_'](_0x574a06,_0x494ac5,_0x2b1f50,_0x3fd41d,_0x22fd36);}['updateFullNode'](_0x248580,_0x464ffc,_0xdc59c1){let _0x27b2d3;if(_0x464ffc['isLeafNode']()||_0x464ffc['isEmpty']())_0x27b2d3=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x464ffc['numChildren']()&&_0x464ffc['isIndexed'](this['index_'])){_0x27b2d3=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x790fed;this['reverse_']?_0x790fed=_0x464ffc['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x790fed=_0x464ffc['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4de4a2=0x0;for(;_0x790fed['hasNext']()&&_0x4de4a2<this['limit_'];){const _0x249434=_0x790fed['getNext']();if(this['withinDirectionalStart'](_0x249434)){if(this['withinDirectionalEnd'](_0x249434))_0x27b2d3=_0x27b2d3['updateImmediateChild'](_0x249434['name'],_0x249434['node']),_0x4de4a2++;else break;}else continue;}}else{_0x27b2d3=_0x464ffc['withIndex'](this['index_']),_0x27b2d3=_0x27b2d3['updatePriority'](g['EMPTY_NODE']);let _0x510f7b;this['reverse_']?_0x510f7b=_0x27b2d3['getReverseIterator'](this['index_']):_0x510f7b=_0x27b2d3['getIterator'](this['index_']);let _0x1a12b1=0x0;for(;_0x510f7b['hasNext']();){const _0x29f45a=_0x510f7b['getNext']();_0x1a12b1<this['limit_']&&this['withinDirectionalStart'](_0x29f45a)&&this['withinDirectionalEnd'](_0x29f45a)?_0x1a12b1++:_0x27b2d3=_0x27b2d3['updateImmediateChild'](_0x29f45a['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x248580,_0x27b2d3,_0xdc59c1);}['updatePriority'](_0x113ff6,_0x532138){return _0x113ff6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x20f949,_0x3cd988,_0x268b20,_0x3393db,_0x2576bd){let _0x3cfb5a;if(this['reverse_']){const _0x41c2aa=this['index_']['getCompare']();_0x3cfb5a=(_0x244788,_0x1165c4)=>_0x41c2aa(_0x1165c4,_0x244788);}else _0x3cfb5a=this['index_']['getCompare']();const _0x4f081b=_0x20f949;f(_0x4f081b['numChildren']()===this['limit_'],'');const _0x3b0724=new E(_0x3cd988,_0x268b20),_0x108989=this['reverse_']?_0x4f081b['getFirstChild'](this['index_']):_0x4f081b['getLastChild'](this['index_']),_0x4b5d=this['rangedFilter_']['matches'](_0x3b0724);if(_0x4f081b['hasChild'](_0x3cd988)){const _0x2f7e7e=_0x4f081b['getImmediateChild'](_0x3cd988);let _0x19c3ce=_0x3393db['getChildAfterChild'](this['index_'],_0x108989,this['reverse_']);for(;_0x19c3ce!=null&&(_0x19c3ce['name']===_0x3cd988||_0x4f081b['hasChild'](_0x19c3ce['name']));)_0x19c3ce=_0x3393db['getChildAfterChild'](this['index_'],_0x19c3ce,this['reverse_']);const _0x371e3b=_0x19c3ce==null?0x1:_0x3cfb5a(_0x19c3ce,_0x3b0724);if(_0x4b5d&&!_0x268b20['isEmpty']()&&_0x371e3b>=0x0)return _0x2576bd!=null&&_0x2576bd['trackChildChange'](xt(_0x3cd988,_0x268b20,_0x2f7e7e)),_0x4f081b['updateImmediateChild'](_0x3cd988,_0x268b20);{_0x2576bd!=null&&_0x2576bd['trackChildChange'](Lt(_0x3cd988,_0x2f7e7e));const _0x510983=_0x4f081b['updateImmediateChild'](_0x3cd988,g['EMPTY_NODE']);return _0x19c3ce!=null&&this['rangedFilter_']['matches'](_0x19c3ce)?(_0x2576bd!=null&&_0x2576bd['trackChildChange'](rt(_0x19c3ce['name'],_0x19c3ce['node'])),_0x510983['updateImmediateChild'](_0x19c3ce['name'],_0x19c3ce['node'])):_0x510983;}}else return _0x268b20['isEmpty']()?_0x20f949:_0x4b5d&&_0x3cfb5a(_0x108989,_0x3b0724)>=0x0?(_0x2576bd!=null&&(_0x2576bd['trackChildChange'](Lt(_0x108989['name'],_0x108989['node'])),_0x2576bd['trackChildChange'](rt(_0x3cd988,_0x268b20))),_0x4f081b['updateImmediateChild'](_0x3cd988,_0x268b20)['updateImmediateChild'](_0x108989['name'],g['EMPTY_NODE'])):_0x20f949;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3db6a8=new Zi();return _0x3db6a8['limitSet_']=this['limitSet_'],_0x3db6a8['limit_']=this['limit_'],_0x3db6a8['startSet_']=this['startSet_'],_0x3db6a8['startAfterSet_']=this['startAfterSet_'],_0x3db6a8['indexStartValue_']=this['indexStartValue_'],_0x3db6a8['startNameSet_']=this['startNameSet_'],_0x3db6a8['indexStartName_']=this['indexStartName_'],_0x3db6a8['endSet_']=this['endSet_'],_0x3db6a8['endBeforeSet_']=this['endBeforeSet_'],_0x3db6a8['indexEndValue_']=this['indexEndValue_'],_0x3db6a8['endNameSet_']=this['endNameSet_'],_0x3db6a8['indexEndName_']=this['indexEndName_'],_0x3db6a8['index_']=this['index_'],_0x3db6a8['viewFrom_']=this['viewFrom_'],_0x3db6a8;}}function Kh(_0x180a7d){return _0x180a7d['loadsAllData']()?new Xi(_0x180a7d['getIndex']()):_0x180a7d['hasLimit']()?new jh(_0x180a7d):new Ft(_0x180a7d);}function Yh(_0x1ab033,_0x11191f){const _0x1284f1=_0x1ab033['copy']();return _0x1284f1['limitSet_']=!0x0,_0x1284f1['limit_']=_0x11191f,_0x1284f1['viewFrom_']='l',_0x1284f1;}function Qh(_0x58ae10,_0x4b3080,_0x5e1265){const _0x3a48dc=_0x58ae10['copy']();return _0x3a48dc['startSet_']=!0x0,_0x4b3080===void 0x0&&(_0x4b3080=null),_0x3a48dc['indexStartValue_']=_0x4b3080,_0x5e1265!=null?(_0x3a48dc['startNameSet_']=!0x0,_0x3a48dc['indexStartName_']=_0x5e1265):(_0x3a48dc['startNameSet_']=!0x1,_0x3a48dc['indexStartName_']=''),_0x3a48dc;}function Jh(_0x265f1b,_0x271ffa,_0x40fef6){const _0x20b6ef=_0x265f1b['copy']();return _0x20b6ef['endSet_']=!0x0,_0x271ffa===void 0x0&&(_0x271ffa=null),_0x20b6ef['indexEndValue_']=_0x271ffa,_0x40fef6!==void 0x0?(_0x20b6ef['endNameSet_']=!0x0,_0x20b6ef['indexEndName_']=_0x40fef6):(_0x20b6ef['endNameSet_']=!0x1,_0x20b6ef['indexEndName_']=''),_0x20b6ef;}function xo(_0xde9087,_0x47cb76){const _0x1a17a7=_0xde9087['copy']();return _0x1a17a7['index_']=_0x47cb76,_0x1a17a7;}function ir(_0x22e3b8){const _0x1c97c2={};if(_0x22e3b8['isDefault']())return _0x1c97c2;let _0x1d2672;if(_0x22e3b8['index_']===R?_0x1d2672='$priority':_0x22e3b8['index_']===Mo?_0x1d2672='$value':_0x22e3b8['index_']===ve?_0x1d2672='$key':(f(_0x22e3b8['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1d2672=_0x22e3b8['index_']['toString']()),_0x1c97c2['orderBy']=O(_0x1d2672),_0x22e3b8['startSet_']){const _0x52250e=_0x22e3b8['startAfterSet_']?'startAfter':'startAt';_0x1c97c2[_0x52250e]=O(_0x22e3b8['indexStartValue_']),_0x22e3b8['startNameSet_']&&(_0x1c97c2[_0x52250e]+=','+O(_0x22e3b8['indexStartName_']));}if(_0x22e3b8['endSet_']){const _0x59a2f6=_0x22e3b8['endBeforeSet_']?'endBefore':'endAt';_0x1c97c2[_0x59a2f6]=O(_0x22e3b8['indexEndValue_']),_0x22e3b8['endNameSet_']&&(_0x1c97c2[_0x59a2f6]+=','+O(_0x22e3b8['indexEndName_']));}return _0x22e3b8['limitSet_']&&(_0x22e3b8['isViewFromLeft']()?_0x1c97c2['limitToFirst']=_0x22e3b8['limit_']:_0x1c97c2['limitToLast']=_0x22e3b8['limit_']),_0x1c97c2;}function sr(_0x430e79){const _0x4f0dfb={};if(_0x430e79['startSet_']&&(_0x4f0dfb['sp']=_0x430e79['indexStartValue_'],_0x430e79['startNameSet_']&&(_0x4f0dfb['sn']=_0x430e79['indexStartName_']),_0x4f0dfb['sin']=!_0x430e79['startAfterSet_']),_0x430e79['endSet_']&&(_0x4f0dfb['ep']=_0x430e79['indexEndValue_'],_0x430e79['endNameSet_']&&(_0x4f0dfb['en']=_0x430e79['indexEndName_']),_0x4f0dfb['ein']=!_0x430e79['endBeforeSet_']),_0x430e79['limitSet_']){_0x4f0dfb['l']=_0x430e79['limit_'];let _0x250b0a=_0x430e79['viewFrom_'];_0x250b0a===''&&(_0x430e79['isViewFromLeft']()?_0x250b0a='l':_0x250b0a='r'),_0x4f0dfb['vf']=_0x250b0a;}return _0x430e79['index_']!==R&&(_0x4f0dfb['i']=_0x430e79['index_']['toString']()),_0x4f0dfb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x386401){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x59ebe8,_0x328a5a){return _0x328a5a!==void 0x0?'tag$'+_0x328a5a:(f(_0x59ebe8['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x59ebe8['_path']['toString']());}constructor(_0x57b643,_0x3d4ee6,_0x350742,_0x2414d1){super(),this['repoInfo_']=_0x57b643,this['onDataUpdate_']=_0x3d4ee6,this['authTokenProvider_']=_0x350742,this['appCheckTokenProvider_']=_0x2414d1,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1d3422,_0x571098,_0x10f1e5,_0x5a4c91){const _0x22bc68=_0x1d3422['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x22bc68+'\x20'+_0x1d3422['_queryIdentifier']);const _0x14ef07=vn['getListenId_'](_0x1d3422,_0x10f1e5),_0x5f0028={};this['listens_'][_0x14ef07]=_0x5f0028;const _0x5aa3ee=ir(_0x1d3422['_queryParams']);this['restRequest_'](_0x22bc68+'.json',_0x5aa3ee,(_0x50d68c,_0x1dd65c)=>{let _0x39bf47=_0x1dd65c;if(_0x50d68c===0x194&&(_0x39bf47=null,_0x50d68c=null),_0x50d68c===null&&this['onDataUpdate_'](_0x22bc68,_0x39bf47,!0x1,_0x10f1e5),Le(this['listens_'],_0x14ef07)===_0x5f0028){let _0x496e4e;_0x50d68c?_0x50d68c===0x191?_0x496e4e='permission_denied':_0x496e4e='rest_error:'+_0x50d68c:_0x496e4e='ok',_0x5a4c91(_0x496e4e,null);}});}['unlisten'](_0x41c6b2,_0x42f9cd){const _0x3c09bc=vn['getListenId_'](_0x41c6b2,_0x42f9cd);delete this['listens_'][_0x3c09bc];}['get'](_0x111af7){const _0x455844=ir(_0x111af7['_queryParams']),_0x33b195=_0x111af7['_path']['toString'](),_0x26d654=new H();return this['restRequest_'](_0x33b195+'.json',_0x455844,(_0x1b3909,_0x2d5b09)=>{let _0xeda28c=_0x2d5b09;_0x1b3909===0x194&&(_0xeda28c=null,_0x1b3909=null),_0x1b3909===null?(this['onDataUpdate_'](_0x33b195,_0xeda28c,!0x1,null),_0x26d654['resolve'](_0xeda28c)):_0x26d654['reject'](new Error(_0xeda28c));}),_0x26d654['promise'];}['refreshAuthToken'](_0x2cc68e){}['restRequest_'](_0x2eb450,_0x33e1f2={},_0x4316bc){return _0x33e1f2['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5aebe3,_0x10574b])=>{_0x5aebe3&&_0x5aebe3['accessToken']&&(_0x33e1f2['auth']=_0x5aebe3['accessToken']),_0x10574b&&_0x10574b['token']&&(_0x33e1f2['ac']=_0x10574b['token']);const _0x2a991a=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2eb450+'?ns='+this['repoInfo_']['namespace']+ut(_0x33e1f2);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2a991a);const _0x161cbd=new XMLHttpRequest();_0x161cbd['onreadystatechange']=()=>{if(_0x4316bc&&_0x161cbd['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2a991a+'\x20received.\x20status:',_0x161cbd['status'],'response:',_0x161cbd['responseText']);let _0x301a66=null;if(_0x161cbd['status']>=0xc8&&_0x161cbd['status']<0x12c){try{_0x301a66=Nt(_0x161cbd['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2a991a+':\x20'+_0x161cbd['responseText']);}_0x4316bc(null,_0x301a66);}else _0x161cbd['status']!==0x191&&_0x161cbd['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2a991a+'\x20Status:\x20'+_0x161cbd['status']),_0x4316bc(_0x161cbd['status']);_0x4316bc=null;}},_0x161cbd['open']('GET',_0x2a991a,!0x0),_0x161cbd['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2c834e){return this['rootNode_']['getChild'](_0x2c834e);}['updateSnapshot'](_0x27da58,_0x87f002){this['rootNode_']=this['rootNode_']['updateChild'](_0x27da58,_0x87f002);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x143863,_0x5ae0d4,_0x4833c9){if(v(_0x5ae0d4))_0x143863['value']=_0x4833c9,_0x143863['children']['clear']();else{if(_0x143863['value']!==null)_0x143863['value']=_0x143863['value']['updateChild'](_0x5ae0d4,_0x4833c9);else{const _0x19bbb1=y(_0x5ae0d4);_0x143863['children']['has'](_0x19bbb1)||_0x143863['children']['set'](_0x19bbb1,En());const _0x2a3c87=_0x143863['children']['get'](_0x19bbb1);_0x5ae0d4=S(_0x5ae0d4),pt(_0x2a3c87,_0x5ae0d4,_0x4833c9);}}}function Ti(_0x6419ae,_0x1c94a4){if(v(_0x1c94a4))return _0x6419ae['value']=null,_0x6419ae['children']['clear'](),!0x0;if(_0x6419ae['value']!==null){if(_0x6419ae['value']['isLeafNode']())return!0x1;{const _0x21f6f4=_0x6419ae['value'];return _0x6419ae['value']=null,_0x21f6f4['forEachChild'](R,(_0x3d7979,_0x2df36b)=>{pt(_0x6419ae,new C(_0x3d7979),_0x2df36b);}),Ti(_0x6419ae,_0x1c94a4);}}else{if(_0x6419ae['children']['size']>0x0){const _0x45350e=y(_0x1c94a4);return _0x1c94a4=S(_0x1c94a4),_0x6419ae['children']['has'](_0x45350e)&&Ti(_0x6419ae['children']['get'](_0x45350e),_0x1c94a4)&&_0x6419ae['children']['delete'](_0x45350e),_0x6419ae['children']['size']===0x0;}else return!0x0;}}function Si(_0x17678b,_0x2020f9,_0x142c5a){_0x17678b['value']!==null?_0x142c5a(_0x2020f9,_0x17678b['value']):Zh(_0x17678b,(_0x21ded7,_0x26ba0c)=>{const _0x344f75=new C(_0x2020f9['toString']()+'/'+_0x21ded7);Si(_0x26ba0c,_0x344f75,_0x142c5a);});}function Zh(_0x906847,_0x2e7a3e){_0x906847['children']['forEach']((_0x464f67,_0x828cb0)=>{_0x2e7a3e(_0x828cb0,_0x464f67);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x302ede){this['collection_']=_0x302ede,this['last_']=null;}['get'](){const _0x5eb3ee=this['collection_']['get'](),_0x38e0c1={..._0x5eb3ee};return this['last_']&&x(this['last_'],(_0x2d86fc,_0x25b1ab)=>{_0x38e0c1[_0x2d86fc]=_0x38e0c1[_0x2d86fc]-_0x25b1ab;}),this['last_']=_0x5eb3ee,_0x38e0c1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0xdae87b,_0xc2e852){this['server_']=_0xc2e852,this['statsToReport_']={},this['statsListener_']=new eu(_0xdae87b);const _0x3ec10c=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3ec10c));}['reportStats_'](){const _0xf82adf=this['statsListener_']['get'](),_0x5a43d7={};let _0x305657=!0x1;x(_0xf82adf,(_0x1b07c8,_0x43a7d0)=>{_0x43a7d0>0x0&&Q(this['statsToReport_'],_0x1b07c8)&&(_0x5a43d7[_0x1b07c8]=_0x43a7d0,_0x305657=!0x0);}),_0x305657&&this['server_']['reportStats'](_0x5a43d7),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x547194){_0x547194[_0x547194['OVERWRITE']=0x0]='OVERWRITE',_0x547194[_0x547194['MERGE']=0x1]='MERGE',_0x547194[_0x547194['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x547194[_0x547194['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x129b45){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x129b45,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0xa4b707,_0x4c9be7,_0x23d4dd){this['path']=_0xa4b707,this['affectedTree']=_0x4c9be7,this['revert']=_0x23d4dd,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x263738){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3d97cb=this['affectedTree']['subtree'](new C(_0x263738));return new In(w(),_0x3d97cb,this['revert']);}}else return f(y(this['path'])===_0x263738,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4838da,_0x5254c4){this['source']=_0x4838da,this['path']=_0x5254c4,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3998c5){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x582347,_0x3e0ba9,_0x997783){this['source']=_0x582347,this['path']=_0x3e0ba9,this['snap']=_0x997783,this['type']=z['OVERWRITE'];}['operationForChild'](_0xf2abd4){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xf2abd4)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x56c778,_0x525162,_0x56bea2){this['source']=_0x56c778,this['path']=_0x525162,this['children']=_0x56bea2,this['type']=z['MERGE'];}['operationForChild'](_0x5c01ac){if(v(this['path'])){const _0x5daf34=this['children']['subtree'](new C(_0x5c01ac));return _0x5daf34['isEmpty']()?null:_0x5daf34['value']?new Be(this['source'],w(),_0x5daf34['value']):new ot(this['source'],w(),_0x5daf34);}else return f(y(this['path'])===_0x5c01ac,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x5a0929,_0x306567,_0x130aa7){this['node_']=_0x5a0929,this['fullyInitialized_']=_0x306567,this['filtered_']=_0x130aa7;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1f1ee1){if(v(_0x1f1ee1))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1b8af7=y(_0x1f1ee1);return this['isCompleteForChild'](_0x1b8af7);}['isCompleteForChild'](_0x2696e3){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2696e3);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x48aed9){this['query_']=_0x48aed9,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x2a8cf0,_0x422d36,_0xf0f7df,_0x3ce619){const _0x289a25=[],_0x42d1e4=[];return _0x422d36['forEach'](_0xd29964=>{_0xd29964['type']==='child_changed'&&_0x2a8cf0['index_']['indexedValueChanged'](_0xd29964['oldSnap'],_0xd29964['snapshotNode'])&&_0x42d1e4['push'](zh(_0xd29964['childName'],_0xd29964['snapshotNode']));}),wt(_0x2a8cf0,_0x289a25,'child_removed',_0x422d36,_0x3ce619,_0xf0f7df),wt(_0x2a8cf0,_0x289a25,'child_added',_0x422d36,_0x3ce619,_0xf0f7df),wt(_0x2a8cf0,_0x289a25,'child_moved',_0x42d1e4,_0x3ce619,_0xf0f7df),wt(_0x2a8cf0,_0x289a25,'child_changed',_0x422d36,_0x3ce619,_0xf0f7df),wt(_0x2a8cf0,_0x289a25,'value',_0x422d36,_0x3ce619,_0xf0f7df),_0x289a25;}function wt(_0x349e08,_0x3473f5,_0x1d3267,_0x17364f,_0x32d226,_0x1ca10d){const _0x41b407=_0x17364f['filter'](_0xc402ce=>_0xc402ce['type']===_0x1d3267);_0x41b407['sort']((_0x464f55,_0x2ac060)=>au(_0x349e08,_0x464f55,_0x2ac060)),_0x41b407['forEach'](_0x25d83e=>{const _0x441451=ou(_0x349e08,_0x25d83e,_0x1ca10d);_0x32d226['forEach'](_0x23e12f=>{_0x23e12f['respondsTo'](_0x25d83e['type'])&&_0x3473f5['push'](_0x23e12f['createEvent'](_0x441451,_0x349e08['query_']));});});}function ou(_0x375ccd,_0x43fbe8,_0x563754){return _0x43fbe8['type']==='value'||_0x43fbe8['type']==='child_removed'||(_0x43fbe8['prevName']=_0x563754['getPredecessorChildName'](_0x43fbe8['childName'],_0x43fbe8['snapshotNode'],_0x375ccd['index_'])),_0x43fbe8;}function au(_0x33cd30,_0x107023,_0x355067){if(_0x107023['childName']==null||_0x355067['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1328e3=new E(_0x107023['childName'],_0x107023['snapshotNode']),_0x659f4c=new E(_0x355067['childName'],_0x355067['snapshotNode']);return _0x33cd30['index_']['compare'](_0x1328e3,_0x659f4c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0xbc0448,_0x484c66){return{'eventCache':_0xbc0448,'serverCache':_0x484c66};}function Rt(_0x51374f,_0x8fa041,_0x5e57b8,_0x5a7b52){return Un(new Te(_0x8fa041,_0x5e57b8,_0x5a7b52),_0x51374f['serverCache']);}function Fo(_0x39966c,_0x5c5599,_0x16673a,_0x54336d){return Un(_0x39966c['eventCache'],new Te(_0x5c5599,_0x16673a,_0x54336d));}function wn(_0x159d2b){return _0x159d2b['eventCache']['isFullyInitialized']()?_0x159d2b['eventCache']['getNode']():null;}function Ve(_0x28a9e5){return _0x28a9e5['serverCache']['isFullyInitialized']()?_0x28a9e5['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2cf752){let _0x3645b5=new b(null);return x(_0x2cf752,(_0x386da0,_0x5ef9b3)=>{_0x3645b5=_0x3645b5['set'](new C(_0x386da0),_0x5ef9b3);}),_0x3645b5;}constructor(_0x490619,_0x383dff=cu()){this['value']=_0x490619,this['children']=_0x383dff;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xe73e5b,_0x28bbda){if(this['value']!=null&&_0x28bbda(this['value']))return{'path':w(),'value':this['value']};if(v(_0xe73e5b))return null;{const _0x1afac5=y(_0xe73e5b),_0x3af2e5=this['children']['get'](_0x1afac5);if(_0x3af2e5!==null){const _0x5d9f54=_0x3af2e5['findRootMostMatchingPathAndValue'](S(_0xe73e5b),_0x28bbda);return _0x5d9f54!=null?{'path':k(new C(_0x1afac5),_0x5d9f54['path']),'value':_0x5d9f54['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x171f3c){return this['findRootMostMatchingPathAndValue'](_0x171f3c,()=>!0x0);}['subtree'](_0x3eff5d){if(v(_0x3eff5d))return this;{const _0x212b24=y(_0x3eff5d),_0x2ede8c=this['children']['get'](_0x212b24);return _0x2ede8c!==null?_0x2ede8c['subtree'](S(_0x3eff5d)):new b(null);}}['set'](_0xb2da36,_0x2b0ee1){if(v(_0xb2da36))return new b(_0x2b0ee1,this['children']);{const _0x5c2c1c=y(_0xb2da36),_0x2e878c=(this['children']['get'](_0x5c2c1c)||new b(null))['set'](S(_0xb2da36),_0x2b0ee1),_0x342dd8=this['children']['insert'](_0x5c2c1c,_0x2e878c);return new b(this['value'],_0x342dd8);}}['remove'](_0x515dea){if(v(_0x515dea))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x15397e=y(_0x515dea),_0xc42cf2=this['children']['get'](_0x15397e);if(_0xc42cf2){const _0x39ca70=_0xc42cf2['remove'](S(_0x515dea));let _0x4cea91;return _0x39ca70['isEmpty']()?_0x4cea91=this['children']['remove'](_0x15397e):_0x4cea91=this['children']['insert'](_0x15397e,_0x39ca70),this['value']===null&&_0x4cea91['isEmpty']()?new b(null):new b(this['value'],_0x4cea91);}else return this;}}['get'](_0x1a7697){if(v(_0x1a7697))return this['value'];{const _0x5bd5b8=y(_0x1a7697),_0x262365=this['children']['get'](_0x5bd5b8);return _0x262365?_0x262365['get'](S(_0x1a7697)):null;}}['setTree'](_0x4d11d5,_0x59eb52){if(v(_0x4d11d5))return _0x59eb52;{const _0x3ed3f1=y(_0x4d11d5),_0x28dd54=(this['children']['get'](_0x3ed3f1)||new b(null))['setTree'](S(_0x4d11d5),_0x59eb52);let _0x31160d;return _0x28dd54['isEmpty']()?_0x31160d=this['children']['remove'](_0x3ed3f1):_0x31160d=this['children']['insert'](_0x3ed3f1,_0x28dd54),new b(this['value'],_0x31160d);}}['fold'](_0x1cac14){return this['fold_'](w(),_0x1cac14);}['fold_'](_0xa12f62,_0x5aaf6d){const _0x5d6c20={};return this['children']['inorderTraversal']((_0x1df6a7,_0x5c55cb)=>{_0x5d6c20[_0x1df6a7]=_0x5c55cb['fold_'](k(_0xa12f62,_0x1df6a7),_0x5aaf6d);}),_0x5aaf6d(_0xa12f62,this['value'],_0x5d6c20);}['findOnPath'](_0x13d00f,_0x1dbb22){return this['findOnPath_'](_0x13d00f,w(),_0x1dbb22);}['findOnPath_'](_0x330d57,_0x16d164,_0x4c3c90){const _0x408288=this['value']?_0x4c3c90(_0x16d164,this['value']):!0x1;if(_0x408288)return _0x408288;if(v(_0x330d57))return null;{const _0x59d173=y(_0x330d57),_0x15a9f5=this['children']['get'](_0x59d173);return _0x15a9f5?_0x15a9f5['findOnPath_'](S(_0x330d57),k(_0x16d164,_0x59d173),_0x4c3c90):null;}}['foreachOnPath'](_0x185736,_0x2e4bb6){return this['foreachOnPath_'](_0x185736,w(),_0x2e4bb6);}['foreachOnPath_'](_0x199557,_0x358bd2,_0x5bc1b9){if(v(_0x199557))return this;{this['value']&&_0x5bc1b9(_0x358bd2,this['value']);const _0x1f58f1=y(_0x199557),_0x2c0ec1=this['children']['get'](_0x1f58f1);return _0x2c0ec1?_0x2c0ec1['foreachOnPath_'](S(_0x199557),k(_0x358bd2,_0x1f58f1),_0x5bc1b9):new b(null);}}['foreach'](_0x6dccc2){this['foreach_'](w(),_0x6dccc2);}['foreach_'](_0x475b6b,_0x18c50c){this['children']['inorderTraversal']((_0x38d0a0,_0x4d7370)=>{_0x4d7370['foreach_'](k(_0x475b6b,_0x38d0a0),_0x18c50c);}),this['value']&&_0x18c50c(_0x475b6b,this['value']);}['foreachChild'](_0x102ea6){this['children']['inorderTraversal']((_0x5491a6,_0x30aac7)=>{_0x30aac7['value']&&_0x102ea6(_0x5491a6,_0x30aac7['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x11d884){this['writeTree_']=_0x11d884;}static['empty'](){return new K(new b(null));}}function At(_0x1cc0d1,_0x162db1,_0x524fa5){if(v(_0x162db1))return new K(new b(_0x524fa5));{const _0x117561=_0x1cc0d1['writeTree_']['findRootMostValueAndPath'](_0x162db1);if(_0x117561!=null){const _0x13f01a=_0x117561['path'];let _0x1cb3af=_0x117561['value'];const _0x40d4fd=F(_0x13f01a,_0x162db1);return _0x1cb3af=_0x1cb3af['updateChild'](_0x40d4fd,_0x524fa5),new K(_0x1cc0d1['writeTree_']['set'](_0x13f01a,_0x1cb3af));}else{const _0x32f7b3=new b(_0x524fa5),_0x1b1870=_0x1cc0d1['writeTree_']['setTree'](_0x162db1,_0x32f7b3);return new K(_0x1b1870);}}}function bi(_0x4f97db,_0x29eaab,_0x5aa7e2){let _0x567e8e=_0x4f97db;return x(_0x5aa7e2,(_0x49e42a,_0x9cce7d)=>{_0x567e8e=At(_0x567e8e,k(_0x29eaab,_0x49e42a),_0x9cce7d);}),_0x567e8e;}function or(_0x375e29,_0x371539){if(v(_0x371539))return K['empty']();{const _0x22a77e=_0x375e29['writeTree_']['setTree'](_0x371539,new b(null));return new K(_0x22a77e);}}function Ri(_0x25d658,_0x37903f){return ze(_0x25d658,_0x37903f)!=null;}function ze(_0x59b209,_0x417fd0){const _0x4f7939=_0x59b209['writeTree_']['findRootMostValueAndPath'](_0x417fd0);return _0x4f7939!=null?_0x59b209['writeTree_']['get'](_0x4f7939['path'])['getChild'](F(_0x4f7939['path'],_0x417fd0)):null;}function ar(_0x2874f9){const _0x2a1630=[],_0x2d9e56=_0x2874f9['writeTree_']['value'];return _0x2d9e56!=null?_0x2d9e56['isLeafNode']()||_0x2d9e56['forEachChild'](R,(_0x4681ea,_0x85770e)=>{_0x2a1630['push'](new E(_0x4681ea,_0x85770e));}):_0x2874f9['writeTree_']['children']['inorderTraversal']((_0x2bdc27,_0x50e930)=>{_0x50e930['value']!=null&&_0x2a1630['push'](new E(_0x2bdc27,_0x50e930['value']));}),_0x2a1630;}function Ee(_0x5525eb,_0x5bda4e){if(v(_0x5bda4e))return _0x5525eb;{const _0x4769bf=ze(_0x5525eb,_0x5bda4e);return _0x4769bf!=null?new K(new b(_0x4769bf)):new K(_0x5525eb['writeTree_']['subtree'](_0x5bda4e));}}function Ai(_0x17d57e){return _0x17d57e['writeTree_']['isEmpty']();}function at(_0x6b2235,_0x5bd03a){return Uo(w(),_0x6b2235['writeTree_'],_0x5bd03a);}function Uo(_0x40cf7c,_0x5ad391,_0x39eda1){if(_0x5ad391['value']!=null)return _0x39eda1['updateChild'](_0x40cf7c,_0x5ad391['value']);{let _0x6f8007=null;return _0x5ad391['children']['inorderTraversal']((_0x4801bf,_0x4d4930)=>{_0x4801bf==='.priority'?(f(_0x4d4930['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x6f8007=_0x4d4930['value']):_0x39eda1=Uo(k(_0x40cf7c,_0x4801bf),_0x4d4930,_0x39eda1);}),!_0x39eda1['getChild'](_0x40cf7c)['isEmpty']()&&_0x6f8007!==null&&(_0x39eda1=_0x39eda1['updateChild'](k(_0x40cf7c,'.priority'),_0x6f8007)),_0x39eda1;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x393d31,_0x5914d8){return Ho(_0x5914d8,_0x393d31);}function lu(_0x2a7f4a,_0x244ef4,_0x281ede,_0x3a8fc4,_0x5c55ea){f(_0x3a8fc4>_0x2a7f4a['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5c55ea===void 0x0&&(_0x5c55ea=!0x0),_0x2a7f4a['allWrites']['push']({'path':_0x244ef4,'snap':_0x281ede,'writeId':_0x3a8fc4,'visible':_0x5c55ea}),_0x5c55ea&&(_0x2a7f4a['visibleWrites']=At(_0x2a7f4a['visibleWrites'],_0x244ef4,_0x281ede)),_0x2a7f4a['lastWriteId']=_0x3a8fc4;}function hu(_0x269b75,_0x5794da,_0xa4e3f1,_0x260323){f(_0x260323>_0x269b75['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x269b75['allWrites']['push']({'path':_0x5794da,'children':_0xa4e3f1,'writeId':_0x260323,'visible':!0x0}),_0x269b75['visibleWrites']=bi(_0x269b75['visibleWrites'],_0x5794da,_0xa4e3f1),_0x269b75['lastWriteId']=_0x260323;}function uu(_0x129d8d,_0x30601a){for(let _0x58eae6=0x0;_0x58eae6<_0x129d8d['allWrites']['length'];_0x58eae6++){const _0x2b2627=_0x129d8d['allWrites'][_0x58eae6];if(_0x2b2627['writeId']===_0x30601a)return _0x2b2627;}return null;}function du(_0x59656c,_0x11dcd0){const _0x2b0873=_0x59656c['allWrites']['findIndex'](_0x5e8c90=>_0x5e8c90['writeId']===_0x11dcd0);f(_0x2b0873>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xe3eeed=_0x59656c['allWrites'][_0x2b0873];_0x59656c['allWrites']['splice'](_0x2b0873,0x1);let _0x579fde=_0xe3eeed['visible'],_0x137580=!0x1,_0x3467bd=_0x59656c['allWrites']['length']-0x1;for(;_0x579fde&&_0x3467bd>=0x0;){const _0x164c10=_0x59656c['allWrites'][_0x3467bd];_0x164c10['visible']&&(_0x3467bd>=_0x2b0873&&fu(_0x164c10,_0xe3eeed['path'])?_0x579fde=!0x1:G(_0xe3eeed['path'],_0x164c10['path'])&&(_0x137580=!0x0)),_0x3467bd--;}if(_0x579fde){if(_0x137580)return pu(_0x59656c),!0x0;if(_0xe3eeed['snap'])_0x59656c['visibleWrites']=or(_0x59656c['visibleWrites'],_0xe3eeed['path']);else{const _0x299961=_0xe3eeed['children'];x(_0x299961,_0x3cb5fb=>{_0x59656c['visibleWrites']=or(_0x59656c['visibleWrites'],k(_0xe3eeed['path'],_0x3cb5fb));});}return!0x0;}else return!0x1;}function fu(_0x2b05dd,_0x4aa935){if(_0x2b05dd['snap'])return G(_0x2b05dd['path'],_0x4aa935);for(const _0x4308b0 in _0x2b05dd['children'])if(_0x2b05dd['children']['hasOwnProperty'](_0x4308b0)&&G(k(_0x2b05dd['path'],_0x4308b0),_0x4aa935))return!0x0;return!0x1;}function pu(_0x411f82){_0x411f82['visibleWrites']=Wo(_0x411f82['allWrites'],_u,w()),_0x411f82['allWrites']['length']>0x0?_0x411f82['lastWriteId']=_0x411f82['allWrites'][_0x411f82['allWrites']['length']-0x1]['writeId']:_0x411f82['lastWriteId']=-0x1;}function _u(_0x459988){return _0x459988['visible'];}function Wo(_0x2b4884,_0x488b61,_0x1b6c97){let _0x35ddda=K['empty']();for(let _0x3284a7=0x0;_0x3284a7<_0x2b4884['length'];++_0x3284a7){const _0x3b010d=_0x2b4884[_0x3284a7];if(_0x488b61(_0x3b010d)){const _0x41bfb5=_0x3b010d['path'];let _0x5ad671;if(_0x3b010d['snap'])G(_0x1b6c97,_0x41bfb5)?(_0x5ad671=F(_0x1b6c97,_0x41bfb5),_0x35ddda=At(_0x35ddda,_0x5ad671,_0x3b010d['snap'])):G(_0x41bfb5,_0x1b6c97)&&(_0x5ad671=F(_0x41bfb5,_0x1b6c97),_0x35ddda=At(_0x35ddda,w(),_0x3b010d['snap']['getChild'](_0x5ad671)));else{if(_0x3b010d['children']){if(G(_0x1b6c97,_0x41bfb5))_0x5ad671=F(_0x1b6c97,_0x41bfb5),_0x35ddda=bi(_0x35ddda,_0x5ad671,_0x3b010d['children']);else{if(G(_0x41bfb5,_0x1b6c97)){if(_0x5ad671=F(_0x41bfb5,_0x1b6c97),v(_0x5ad671))_0x35ddda=bi(_0x35ddda,w(),_0x3b010d['children']);else{const _0x523fc4=Le(_0x3b010d['children'],y(_0x5ad671));if(_0x523fc4){const _0x5251f6=_0x523fc4['getChild'](S(_0x5ad671));_0x35ddda=At(_0x35ddda,w(),_0x5251f6);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x35ddda;}function Bo(_0x50fa12,_0x4e07ae,_0x422a03,_0x13772a,_0x1c46f5){if(!_0x13772a&&!_0x1c46f5){const _0x2574c3=ze(_0x50fa12['visibleWrites'],_0x4e07ae);if(_0x2574c3!=null)return _0x2574c3;{const _0x1dd285=Ee(_0x50fa12['visibleWrites'],_0x4e07ae);if(Ai(_0x1dd285))return _0x422a03;if(_0x422a03==null&&!Ri(_0x1dd285,w()))return null;{const _0x3b13b6=_0x422a03||g['EMPTY_NODE'];return at(_0x1dd285,_0x3b13b6);}}}else{const _0x463108=Ee(_0x50fa12['visibleWrites'],_0x4e07ae);if(!_0x1c46f5&&Ai(_0x463108))return _0x422a03;if(!_0x1c46f5&&_0x422a03==null&&!Ri(_0x463108,w()))return null;{const _0x268dd7=function(_0x456453){return(_0x456453['visible']||_0x1c46f5)&&(!_0x13772a||!~_0x13772a['indexOf'](_0x456453['writeId']))&&(G(_0x456453['path'],_0x4e07ae)||G(_0x4e07ae,_0x456453['path']));},_0x2aed13=Wo(_0x50fa12['allWrites'],_0x268dd7,_0x4e07ae),_0x12f5c3=_0x422a03||g['EMPTY_NODE'];return at(_0x2aed13,_0x12f5c3);}}}function gu(_0x3722c6,_0x214f15,_0x568744){let _0x2b3dee=g['EMPTY_NODE'];const _0x6cb35c=ze(_0x3722c6['visibleWrites'],_0x214f15);if(_0x6cb35c)return _0x6cb35c['isLeafNode']()||_0x6cb35c['forEachChild'](R,(_0x1f918d,_0x27d173)=>{_0x2b3dee=_0x2b3dee['updateImmediateChild'](_0x1f918d,_0x27d173);}),_0x2b3dee;if(_0x568744){const _0x338d83=Ee(_0x3722c6['visibleWrites'],_0x214f15);return _0x568744['forEachChild'](R,(_0x40c06a,_0x69fbfe)=>{const _0x2a0583=at(Ee(_0x338d83,new C(_0x40c06a)),_0x69fbfe);_0x2b3dee=_0x2b3dee['updateImmediateChild'](_0x40c06a,_0x2a0583);}),ar(_0x338d83)['forEach'](_0x1925c0=>{_0x2b3dee=_0x2b3dee['updateImmediateChild'](_0x1925c0['name'],_0x1925c0['node']);}),_0x2b3dee;}else{const _0x2ca09c=Ee(_0x3722c6['visibleWrites'],_0x214f15);return ar(_0x2ca09c)['forEach'](_0x429eb9=>{_0x2b3dee=_0x2b3dee['updateImmediateChild'](_0x429eb9['name'],_0x429eb9['node']);}),_0x2b3dee;}}function mu(_0x277c50,_0x3fb0ad,_0x5148f9,_0x22598b,_0x32eae2){f(_0x22598b||_0x32eae2,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x2d64c2=k(_0x3fb0ad,_0x5148f9);if(Ri(_0x277c50['visibleWrites'],_0x2d64c2))return null;{const _0x4b63ff=Ee(_0x277c50['visibleWrites'],_0x2d64c2);return Ai(_0x4b63ff)?_0x32eae2['getChild'](_0x5148f9):at(_0x4b63ff,_0x32eae2['getChild'](_0x5148f9));}}function yu(_0x3b1dcc,_0x31ebe9,_0x990a0d,_0x1d2b7e){const _0x2d59cb=k(_0x31ebe9,_0x990a0d),_0x164517=ze(_0x3b1dcc['visibleWrites'],_0x2d59cb);if(_0x164517!=null)return _0x164517;if(_0x1d2b7e['isCompleteForChild'](_0x990a0d)){const _0x5259cc=Ee(_0x3b1dcc['visibleWrites'],_0x2d59cb);return at(_0x5259cc,_0x1d2b7e['getNode']()['getImmediateChild'](_0x990a0d));}else return null;}function vu(_0x1d0773,_0x1ad96d){return ze(_0x1d0773['visibleWrites'],_0x1ad96d);}function Eu(_0x36142e,_0x3443df,_0x37575e,_0x49b7f5,_0x162eb1,_0x54cc6d,_0x34e50b){let _0x527d06;const _0x1f211b=Ee(_0x36142e['visibleWrites'],_0x3443df),_0x382785=ze(_0x1f211b,w());if(_0x382785!=null)_0x527d06=_0x382785;else{if(_0x37575e!=null)_0x527d06=at(_0x1f211b,_0x37575e);else return[];}if(_0x527d06=_0x527d06['withIndex'](_0x34e50b),!_0x527d06['isEmpty']()&&!_0x527d06['isLeafNode']()){const _0x2aff14=[],_0x3116a2=_0x34e50b['getCompare'](),_0x1c7eab=_0x54cc6d?_0x527d06['getReverseIteratorFrom'](_0x49b7f5,_0x34e50b):_0x527d06['getIteratorFrom'](_0x49b7f5,_0x34e50b);let _0x44c935=_0x1c7eab['getNext']();for(;_0x44c935&&_0x2aff14['length']<_0x162eb1;)_0x3116a2(_0x44c935,_0x49b7f5)!==0x0&&_0x2aff14['push'](_0x44c935),_0x44c935=_0x1c7eab['getNext']();return _0x2aff14;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0xfbdaa2,_0x14088c,_0x52e71e,_0x4345df){return Bo(_0xfbdaa2['writeTree'],_0xfbdaa2['treePath'],_0x14088c,_0x52e71e,_0x4345df);}function is(_0x251570,_0x1b638e){return gu(_0x251570['writeTree'],_0x251570['treePath'],_0x1b638e);}function cr(_0x4dbbdc,_0x526a6a,_0x570124,_0x2c028b){return mu(_0x4dbbdc['writeTree'],_0x4dbbdc['treePath'],_0x526a6a,_0x570124,_0x2c028b);}function Tn(_0x46c40a,_0x293918){return vu(_0x46c40a['writeTree'],k(_0x46c40a['treePath'],_0x293918));}function wu(_0x23a2eb,_0x5a50f1,_0x4d8c3a,_0x51f01d,_0x55feee,_0x5048a8){return Eu(_0x23a2eb['writeTree'],_0x23a2eb['treePath'],_0x5a50f1,_0x4d8c3a,_0x51f01d,_0x55feee,_0x5048a8);}function ss(_0x1e01c5,_0x1a00ea,_0x3d3c96){return yu(_0x1e01c5['writeTree'],_0x1e01c5['treePath'],_0x1a00ea,_0x3d3c96);}function Vo(_0x102463,_0xa03b5a){return Ho(k(_0x102463['treePath'],_0xa03b5a),_0x102463['writeTree']);}function Ho(_0x5d4226,_0x222d4e){return{'treePath':_0x5d4226,'writeTree':_0x222d4e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x36784b){const _0x2c3b1a=_0x36784b['type'],_0x45131e=_0x36784b['childName'];f(_0x2c3b1a==='child_added'||_0x2c3b1a==='child_changed'||_0x2c3b1a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x45131e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5d9c60=this['changeMap']['get'](_0x45131e);if(_0x5d9c60){const _0x2ec50e=_0x5d9c60['type'];if(_0x2c3b1a==='child_added'&&_0x2ec50e==='child_removed')this['changeMap']['set'](_0x45131e,xt(_0x45131e,_0x36784b['snapshotNode'],_0x5d9c60['snapshotNode']));else{if(_0x2c3b1a==='child_removed'&&_0x2ec50e==='child_added')this['changeMap']['delete'](_0x45131e);else{if(_0x2c3b1a==='child_removed'&&_0x2ec50e==='child_changed')this['changeMap']['set'](_0x45131e,Lt(_0x45131e,_0x5d9c60['oldSnap']));else{if(_0x2c3b1a==='child_changed'&&_0x2ec50e==='child_added')this['changeMap']['set'](_0x45131e,rt(_0x45131e,_0x36784b['snapshotNode']));else{if(_0x2c3b1a==='child_changed'&&_0x2ec50e==='child_changed')this['changeMap']['set'](_0x45131e,xt(_0x45131e,_0x36784b['snapshotNode'],_0x5d9c60['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x36784b+'\x20occurred\x20after\x20'+_0x5d9c60);}}}}}else this['changeMap']['set'](_0x45131e,_0x36784b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x356a1c){return null;}['getChildAfterChild'](_0x47bfd6,_0x11e478,_0x57b34e){return null;}}const $o=new Tu();class rs{constructor(_0x388b59,_0x56c9d0,_0x5a8d89=null){this['writes_']=_0x388b59,this['viewCache_']=_0x56c9d0,this['optCompleteServerCache_']=_0x5a8d89;}['getCompleteChild'](_0x53e1c3){const _0x393e80=this['viewCache_']['eventCache'];if(_0x393e80['isCompleteForChild'](_0x53e1c3))return _0x393e80['getNode']()['getImmediateChild'](_0x53e1c3);{const _0x156b82=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x53e1c3,_0x156b82);}}['getChildAfterChild'](_0x1da0cb,_0x3e5edf,_0x635e67){const _0x25e91f=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x3a12a0=wu(this['writes_'],_0x25e91f,_0x3e5edf,0x1,_0x635e67,_0x1da0cb);return _0x3a12a0['length']===0x0?null:_0x3a12a0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5c8812){return{'filter':_0x5c8812};}function bu(_0x61f41e,_0x53e4f6){f(_0x53e4f6['eventCache']['getNode']()['isIndexed'](_0x61f41e['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x53e4f6['serverCache']['getNode']()['isIndexed'](_0x61f41e['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x407585,_0x5a4a43,_0xc4f46a,_0x40063b,_0x90bdba){const _0x21b5a4=new Cu();let _0x3109a1,_0x2439c1;if(_0xc4f46a['type']===z['OVERWRITE']){const _0x222ed6=_0xc4f46a;_0x222ed6['source']['fromUser']?_0x3109a1=ki(_0x407585,_0x5a4a43,_0x222ed6['path'],_0x222ed6['snap'],_0x40063b,_0x90bdba,_0x21b5a4):(f(_0x222ed6['source']['fromServer'],'Unknown\x20source.'),_0x2439c1=_0x222ed6['source']['tagged']||_0x5a4a43['serverCache']['isFiltered']()&&!v(_0x222ed6['path']),_0x3109a1=Sn(_0x407585,_0x5a4a43,_0x222ed6['path'],_0x222ed6['snap'],_0x40063b,_0x90bdba,_0x2439c1,_0x21b5a4));}else{if(_0xc4f46a['type']===z['MERGE']){const _0x33adc9=_0xc4f46a;_0x33adc9['source']['fromUser']?_0x3109a1=ku(_0x407585,_0x5a4a43,_0x33adc9['path'],_0x33adc9['children'],_0x40063b,_0x90bdba,_0x21b5a4):(f(_0x33adc9['source']['fromServer'],'Unknown\x20source.'),_0x2439c1=_0x33adc9['source']['tagged']||_0x5a4a43['serverCache']['isFiltered'](),_0x3109a1=Pi(_0x407585,_0x5a4a43,_0x33adc9['path'],_0x33adc9['children'],_0x40063b,_0x90bdba,_0x2439c1,_0x21b5a4));}else{if(_0xc4f46a['type']===z['ACK_USER_WRITE']){const _0x113c8b=_0xc4f46a;_0x113c8b['revert']?_0x3109a1=Ou(_0x407585,_0x5a4a43,_0x113c8b['path'],_0x40063b,_0x90bdba,_0x21b5a4):_0x3109a1=Pu(_0x407585,_0x5a4a43,_0x113c8b['path'],_0x113c8b['affectedTree'],_0x40063b,_0x90bdba,_0x21b5a4);}else{if(_0xc4f46a['type']===z['LISTEN_COMPLETE'])_0x3109a1=Nu(_0x407585,_0x5a4a43,_0xc4f46a['path'],_0x40063b,_0x21b5a4);else throw ht('Unknown\x20operation\x20type:\x20'+_0xc4f46a['type']);}}}const _0x451e0e=_0x21b5a4['getChanges']();return Au(_0x5a4a43,_0x3109a1,_0x451e0e),{'viewCache':_0x3109a1,'changes':_0x451e0e};}function Au(_0x43ffbc,_0x18641a,_0x3f28b3){const _0x51cc94=_0x18641a['eventCache'];if(_0x51cc94['isFullyInitialized']()){const _0x3b9c2a=_0x51cc94['getNode']()['isLeafNode']()||_0x51cc94['getNode']()['isEmpty'](),_0x297a6b=wn(_0x43ffbc);(_0x3f28b3['length']>0x0||!_0x43ffbc['eventCache']['isFullyInitialized']()||_0x3b9c2a&&!_0x51cc94['getNode']()['equals'](_0x297a6b)||!_0x51cc94['getNode']()['getPriority']()['equals'](_0x297a6b['getPriority']()))&&_0x3f28b3['push'](Lo(wn(_0x18641a)));}}function Go(_0x30ff6b,_0x230908,_0x434878,_0x302a2b,_0x3ee2a6,_0x386d26){const _0x2390fc=_0x230908['eventCache'];if(Tn(_0x302a2b,_0x434878)!=null)return _0x230908;{let _0x11e1de,_0x430641;if(v(_0x434878)){if(f(_0x230908['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x230908['serverCache']['isFiltered']()){const _0x44ab65=Ve(_0x230908),_0xa4a976=_0x44ab65 instanceof g?_0x44ab65:g['EMPTY_NODE'],_0x263efb=is(_0x302a2b,_0xa4a976);_0x11e1de=_0x30ff6b['filter']['updateFullNode'](_0x230908['eventCache']['getNode'](),_0x263efb,_0x386d26);}else{const _0x3fb630=Cn(_0x302a2b,Ve(_0x230908));_0x11e1de=_0x30ff6b['filter']['updateFullNode'](_0x230908['eventCache']['getNode'](),_0x3fb630,_0x386d26);}}else{const _0x2bd15d=y(_0x434878);if(_0x2bd15d==='.priority'){f(Ce(_0x434878)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x30d844=_0x2390fc['getNode']();_0x430641=_0x230908['serverCache']['getNode']();const _0x379032=cr(_0x302a2b,_0x434878,_0x30d844,_0x430641);_0x379032!=null?_0x11e1de=_0x30ff6b['filter']['updatePriority'](_0x30d844,_0x379032):_0x11e1de=_0x2390fc['getNode']();}else{const _0x5efb85=S(_0x434878);let _0x31eae0;if(_0x2390fc['isCompleteForChild'](_0x2bd15d)){_0x430641=_0x230908['serverCache']['getNode']();const _0x23fd15=cr(_0x302a2b,_0x434878,_0x2390fc['getNode'](),_0x430641);_0x23fd15!=null?_0x31eae0=_0x2390fc['getNode']()['getImmediateChild'](_0x2bd15d)['updateChild'](_0x5efb85,_0x23fd15):_0x31eae0=_0x2390fc['getNode']()['getImmediateChild'](_0x2bd15d);}else _0x31eae0=ss(_0x302a2b,_0x2bd15d,_0x230908['serverCache']);_0x31eae0!=null?_0x11e1de=_0x30ff6b['filter']['updateChild'](_0x2390fc['getNode'](),_0x2bd15d,_0x31eae0,_0x5efb85,_0x3ee2a6,_0x386d26):_0x11e1de=_0x2390fc['getNode']();}}return Rt(_0x230908,_0x11e1de,_0x2390fc['isFullyInitialized']()||v(_0x434878),_0x30ff6b['filter']['filtersNodes']());}}function Sn(_0x468968,_0x116278,_0x2c2bde,_0x5cf5cf,_0x76a71d,_0x469af8,_0x4b2892,_0x2e6622){const _0x233b9d=_0x116278['serverCache'];let _0x4df921;const _0x11cf7b=_0x4b2892?_0x468968['filter']:_0x468968['filter']['getIndexedFilter']();if(v(_0x2c2bde))_0x4df921=_0x11cf7b['updateFullNode'](_0x233b9d['getNode'](),_0x5cf5cf,null);else{if(_0x11cf7b['filtersNodes']()&&!_0x233b9d['isFiltered']()){const _0x1edcaa=_0x233b9d['getNode']()['updateChild'](_0x2c2bde,_0x5cf5cf);_0x4df921=_0x11cf7b['updateFullNode'](_0x233b9d['getNode'](),_0x1edcaa,null);}else{const _0x325381=y(_0x2c2bde);if(!_0x233b9d['isCompleteForPath'](_0x2c2bde)&&Ce(_0x2c2bde)>0x1)return _0x116278;const _0x435922=S(_0x2c2bde),_0x3ffe78=_0x233b9d['getNode']()['getImmediateChild'](_0x325381)['updateChild'](_0x435922,_0x5cf5cf);_0x325381==='.priority'?_0x4df921=_0x11cf7b['updatePriority'](_0x233b9d['getNode'](),_0x3ffe78):_0x4df921=_0x11cf7b['updateChild'](_0x233b9d['getNode'](),_0x325381,_0x3ffe78,_0x435922,$o,null);}}const _0x4f0c4b=Fo(_0x116278,_0x4df921,_0x233b9d['isFullyInitialized']()||v(_0x2c2bde),_0x11cf7b['filtersNodes']()),_0xdb8cba=new rs(_0x76a71d,_0x4f0c4b,_0x469af8);return Go(_0x468968,_0x4f0c4b,_0x2c2bde,_0x76a71d,_0xdb8cba,_0x2e6622);}function ki(_0x2c98c4,_0x5d16b0,_0x905ea7,_0x332351,_0x52667c,_0x4ca5be,_0x54b8b8){const _0x2f479a=_0x5d16b0['eventCache'];let _0xe456e8,_0x4189d3;const _0x4cc6c2=new rs(_0x52667c,_0x5d16b0,_0x4ca5be);if(v(_0x905ea7))_0x4189d3=_0x2c98c4['filter']['updateFullNode'](_0x5d16b0['eventCache']['getNode'](),_0x332351,_0x54b8b8),_0xe456e8=Rt(_0x5d16b0,_0x4189d3,!0x0,_0x2c98c4['filter']['filtersNodes']());else{const _0x5c3572=y(_0x905ea7);if(_0x5c3572==='.priority')_0x4189d3=_0x2c98c4['filter']['updatePriority'](_0x5d16b0['eventCache']['getNode'](),_0x332351),_0xe456e8=Rt(_0x5d16b0,_0x4189d3,_0x2f479a['isFullyInitialized'](),_0x2f479a['isFiltered']());else{const _0x3ec4f9=S(_0x905ea7),_0x653c8a=_0x2f479a['getNode']()['getImmediateChild'](_0x5c3572);let _0x1e1e94;if(v(_0x3ec4f9))_0x1e1e94=_0x332351;else{const _0x145661=_0x4cc6c2['getCompleteChild'](_0x5c3572);_0x145661!=null?ji(_0x3ec4f9)==='.priority'&&_0x145661['getChild'](Ro(_0x3ec4f9))['isEmpty']()?_0x1e1e94=_0x145661:_0x1e1e94=_0x145661['updateChild'](_0x3ec4f9,_0x332351):_0x1e1e94=g['EMPTY_NODE'];}if(_0x653c8a['equals'](_0x1e1e94))_0xe456e8=_0x5d16b0;else{const _0x331ba6=_0x2c98c4['filter']['updateChild'](_0x2f479a['getNode'](),_0x5c3572,_0x1e1e94,_0x3ec4f9,_0x4cc6c2,_0x54b8b8);_0xe456e8=Rt(_0x5d16b0,_0x331ba6,_0x2f479a['isFullyInitialized'](),_0x2c98c4['filter']['filtersNodes']());}}}return _0xe456e8;}function lr(_0x1ca6a4,_0x583c03){return _0x1ca6a4['eventCache']['isCompleteForChild'](_0x583c03);}function ku(_0x259d10,_0x117e06,_0x2cea61,_0x36dff7,_0x354331,_0x171f99,_0x464b10){let _0x1bd95b=_0x117e06;return _0x36dff7['foreach']((_0x273c13,_0x32afcb)=>{const _0x1a67bb=k(_0x2cea61,_0x273c13);lr(_0x117e06,y(_0x1a67bb))&&(_0x1bd95b=ki(_0x259d10,_0x1bd95b,_0x1a67bb,_0x32afcb,_0x354331,_0x171f99,_0x464b10));}),_0x36dff7['foreach']((_0x5b6c04,_0x4d5baf)=>{const _0x119dad=k(_0x2cea61,_0x5b6c04);lr(_0x117e06,y(_0x119dad))||(_0x1bd95b=ki(_0x259d10,_0x1bd95b,_0x119dad,_0x4d5baf,_0x354331,_0x171f99,_0x464b10));}),_0x1bd95b;}function hr(_0x28a1e6,_0x555e82,_0x5049bc){return _0x5049bc['foreach']((_0x4125bc,_0x1f8c02)=>{_0x555e82=_0x555e82['updateChild'](_0x4125bc,_0x1f8c02);}),_0x555e82;}function Pi(_0x4593ac,_0x2ecbfe,_0x458ea2,_0x1f072b,_0x5e1d6a,_0x4601f2,_0x8b7f1d,_0x192a43){if(_0x2ecbfe['serverCache']['getNode']()['isEmpty']()&&!_0x2ecbfe['serverCache']['isFullyInitialized']())return _0x2ecbfe;let _0x480714=_0x2ecbfe,_0x1f2747;v(_0x458ea2)?_0x1f2747=_0x1f072b:_0x1f2747=new b(null)['setTree'](_0x458ea2,_0x1f072b);const _0x348399=_0x2ecbfe['serverCache']['getNode']();return _0x1f2747['children']['inorderTraversal']((_0x5488a5,_0x520dbe)=>{if(_0x348399['hasChild'](_0x5488a5)){const _0x4055ca=_0x2ecbfe['serverCache']['getNode']()['getImmediateChild'](_0x5488a5),_0x465b9b=hr(_0x4593ac,_0x4055ca,_0x520dbe);_0x480714=Sn(_0x4593ac,_0x480714,new C(_0x5488a5),_0x465b9b,_0x5e1d6a,_0x4601f2,_0x8b7f1d,_0x192a43);}}),_0x1f2747['children']['inorderTraversal']((_0x2e74c5,_0x4c9d77)=>{const _0x5ca1ed=!_0x2ecbfe['serverCache']['isCompleteForChild'](_0x2e74c5)&&_0x4c9d77['value']===null;if(!_0x348399['hasChild'](_0x2e74c5)&&!_0x5ca1ed){const _0x45f864=_0x2ecbfe['serverCache']['getNode']()['getImmediateChild'](_0x2e74c5),_0x47c525=hr(_0x4593ac,_0x45f864,_0x4c9d77);_0x480714=Sn(_0x4593ac,_0x480714,new C(_0x2e74c5),_0x47c525,_0x5e1d6a,_0x4601f2,_0x8b7f1d,_0x192a43);}}),_0x480714;}function Pu(_0x1487ef,_0x38fc1f,_0x1f33a7,_0x256f8a,_0x1f01ac,_0x44898f,_0x412d3e){if(Tn(_0x1f01ac,_0x1f33a7)!=null)return _0x38fc1f;const _0x1fc51a=_0x38fc1f['serverCache']['isFiltered'](),_0x2d82db=_0x38fc1f['serverCache'];if(_0x256f8a['value']!=null){if(v(_0x1f33a7)&&_0x2d82db['isFullyInitialized']()||_0x2d82db['isCompleteForPath'](_0x1f33a7))return Sn(_0x1487ef,_0x38fc1f,_0x1f33a7,_0x2d82db['getNode']()['getChild'](_0x1f33a7),_0x1f01ac,_0x44898f,_0x1fc51a,_0x412d3e);if(v(_0x1f33a7)){let _0xf998cd=new b(null);return _0x2d82db['getNode']()['forEachChild'](ve,(_0x2d171c,_0x104aa0)=>{_0xf998cd=_0xf998cd['set'](new C(_0x2d171c),_0x104aa0);}),Pi(_0x1487ef,_0x38fc1f,_0x1f33a7,_0xf998cd,_0x1f01ac,_0x44898f,_0x1fc51a,_0x412d3e);}else return _0x38fc1f;}else{let _0x54e95b=new b(null);return _0x256f8a['foreach']((_0x478405,_0x5eeabd)=>{const _0x1089f5=k(_0x1f33a7,_0x478405);_0x2d82db['isCompleteForPath'](_0x1089f5)&&(_0x54e95b=_0x54e95b['set'](_0x478405,_0x2d82db['getNode']()['getChild'](_0x1089f5)));}),Pi(_0x1487ef,_0x38fc1f,_0x1f33a7,_0x54e95b,_0x1f01ac,_0x44898f,_0x1fc51a,_0x412d3e);}}function Nu(_0x2a5e8f,_0x57f7c1,_0x22b382,_0x2210ef,_0xca0893){const _0x525065=_0x57f7c1['serverCache'],_0x349dd4=Fo(_0x57f7c1,_0x525065['getNode'](),_0x525065['isFullyInitialized']()||v(_0x22b382),_0x525065['isFiltered']());return Go(_0x2a5e8f,_0x349dd4,_0x22b382,_0x2210ef,$o,_0xca0893);}function Ou(_0x41ff27,_0x46abb5,_0x27fb1e,_0x394f79,_0x5520b1,_0x2d5f72){let _0x36ed81;if(Tn(_0x394f79,_0x27fb1e)!=null)return _0x46abb5;{const _0x1217ce=new rs(_0x394f79,_0x46abb5,_0x5520b1),_0x37fc1c=_0x46abb5['eventCache']['getNode']();let _0x5a5f62;if(v(_0x27fb1e)||y(_0x27fb1e)==='.priority'){let _0x3c78a7;if(_0x46abb5['serverCache']['isFullyInitialized']())_0x3c78a7=Cn(_0x394f79,Ve(_0x46abb5));else{const _0x31a689=_0x46abb5['serverCache']['getNode']();f(_0x31a689 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3c78a7=is(_0x394f79,_0x31a689);}_0x3c78a7=_0x3c78a7,_0x5a5f62=_0x41ff27['filter']['updateFullNode'](_0x37fc1c,_0x3c78a7,_0x2d5f72);}else{const _0x18026b=y(_0x27fb1e);let _0x3e2264=ss(_0x394f79,_0x18026b,_0x46abb5['serverCache']);_0x3e2264==null&&_0x46abb5['serverCache']['isCompleteForChild'](_0x18026b)&&(_0x3e2264=_0x37fc1c['getImmediateChild'](_0x18026b)),_0x3e2264!=null?_0x5a5f62=_0x41ff27['filter']['updateChild'](_0x37fc1c,_0x18026b,_0x3e2264,S(_0x27fb1e),_0x1217ce,_0x2d5f72):_0x46abb5['eventCache']['getNode']()['hasChild'](_0x18026b)?_0x5a5f62=_0x41ff27['filter']['updateChild'](_0x37fc1c,_0x18026b,g['EMPTY_NODE'],S(_0x27fb1e),_0x1217ce,_0x2d5f72):_0x5a5f62=_0x37fc1c,_0x5a5f62['isEmpty']()&&_0x46abb5['serverCache']['isFullyInitialized']()&&(_0x36ed81=Cn(_0x394f79,Ve(_0x46abb5)),_0x36ed81['isLeafNode']()&&(_0x5a5f62=_0x41ff27['filter']['updateFullNode'](_0x5a5f62,_0x36ed81,_0x2d5f72)));}return _0x36ed81=_0x46abb5['serverCache']['isFullyInitialized']()||Tn(_0x394f79,w())!=null,Rt(_0x46abb5,_0x5a5f62,_0x36ed81,_0x41ff27['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x43ef33,_0x18dacc){this['query_']=_0x43ef33,this['eventRegistrations_']=[];const _0x55feb1=this['query_']['_queryParams'],_0x5a8a11=new Xi(_0x55feb1['getIndex']()),_0x3979be=Kh(_0x55feb1);this['processor_']=Su(_0x3979be);const _0x424e20=_0x18dacc['serverCache'],_0x4b233c=_0x18dacc['eventCache'],_0x58ba69=_0x5a8a11['updateFullNode'](g['EMPTY_NODE'],_0x424e20['getNode'](),null),_0x594b2a=_0x3979be['updateFullNode'](g['EMPTY_NODE'],_0x4b233c['getNode'](),null),_0x3b1b1b=new Te(_0x58ba69,_0x424e20['isFullyInitialized'](),_0x5a8a11['filtersNodes']()),_0x362b40=new Te(_0x594b2a,_0x4b233c['isFullyInitialized'](),_0x3979be['filtersNodes']());this['viewCache_']=Un(_0x362b40,_0x3b1b1b),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x127248){return _0x127248['viewCache_']['serverCache']['getNode']();}function Lu(_0xd01f48){return wn(_0xd01f48['viewCache_']);}function xu(_0x341fe2,_0x22870c){const _0x4c5e91=Ve(_0x341fe2['viewCache_']);return _0x4c5e91&&(_0x341fe2['query']['_queryParams']['loadsAllData']()||!v(_0x22870c)&&!_0x4c5e91['getImmediateChild'](y(_0x22870c))['isEmpty']())?_0x4c5e91['getChild'](_0x22870c):null;}function ur(_0x242194){return _0x242194['eventRegistrations_']['length']===0x0;}function Fu(_0x4c9bc0,_0x42f30c){_0x4c9bc0['eventRegistrations_']['push'](_0x42f30c);}function dr(_0x4957f2,_0x2f0d0b,_0x18c933){const _0x3da476=[];if(_0x18c933){f(_0x2f0d0b==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x18ce8b=_0x4957f2['query']['_path'];_0x4957f2['eventRegistrations_']['forEach'](_0x47c08f=>{const _0x21cff8=_0x47c08f['createCancelEvent'](_0x18c933,_0x18ce8b);_0x21cff8&&_0x3da476['push'](_0x21cff8);});}if(_0x2f0d0b){let _0x1c620c=[];for(let _0x173ee7=0x0;_0x173ee7<_0x4957f2['eventRegistrations_']['length'];++_0x173ee7){const _0x3a0aba=_0x4957f2['eventRegistrations_'][_0x173ee7];if(!_0x3a0aba['matches'](_0x2f0d0b))_0x1c620c['push'](_0x3a0aba);else{if(_0x2f0d0b['hasAnyCallback']()){_0x1c620c=_0x1c620c['concat'](_0x4957f2['eventRegistrations_']['slice'](_0x173ee7+0x1));break;}}}_0x4957f2['eventRegistrations_']=_0x1c620c;}else _0x4957f2['eventRegistrations_']=[];return _0x3da476;}function fr(_0x3783fc,_0x577d31,_0x40a78c,_0x461329){_0x577d31['type']===z['MERGE']&&_0x577d31['source']['queryId']!==null&&(f(Ve(_0x3783fc['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x3783fc['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x4838e4=_0x3783fc['viewCache_'],_0x10a279=Ru(_0x3783fc['processor_'],_0x4838e4,_0x577d31,_0x40a78c,_0x461329);return bu(_0x3783fc['processor_'],_0x10a279['viewCache']),f(_0x10a279['viewCache']['serverCache']['isFullyInitialized']()||!_0x4838e4['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x3783fc['viewCache_']=_0x10a279['viewCache'],qo(_0x3783fc,_0x10a279['changes'],_0x10a279['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x8ddc6d,_0x1dff74){const _0x1671e9=_0x8ddc6d['viewCache_']['eventCache'],_0x4548a9=[];return _0x1671e9['getNode']()['isLeafNode']()||_0x1671e9['getNode']()['forEachChild'](R,(_0x2ad6d2,_0x116ed7)=>{_0x4548a9['push'](rt(_0x2ad6d2,_0x116ed7));}),_0x1671e9['isFullyInitialized']()&&_0x4548a9['push'](Lo(_0x1671e9['getNode']())),qo(_0x8ddc6d,_0x4548a9,_0x1671e9['getNode'](),_0x1dff74);}function qo(_0x3e6475,_0x179c40,_0x42342e,_0x4aea78){const _0x2a699f=_0x4aea78?[_0x4aea78]:_0x3e6475['eventRegistrations_'];return ru(_0x3e6475['eventGenerator_'],_0x179c40,_0x42342e,_0x2a699f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x1361cf){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x1361cf;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3f7533){return _0x3f7533['views']['size']===0x0;}function os(_0x1dd34d,_0x3da57f,_0x42badf,_0x12388a){const _0x5e4822=_0x3da57f['source']['queryId'];if(_0x5e4822!==null){const _0x453192=_0x1dd34d['views']['get'](_0x5e4822);return f(_0x453192!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x453192,_0x3da57f,_0x42badf,_0x12388a);}else{let _0x2fea57=[];for(const _0x4e6e14 of _0x1dd34d['views']['values']())_0x2fea57=_0x2fea57['concat'](fr(_0x4e6e14,_0x3da57f,_0x42badf,_0x12388a));return _0x2fea57;}}function jo(_0x3d25df,_0x3b235c,_0x29b9c9,_0x4dae9,_0x5cdb1e){const _0x1c0f65=_0x3b235c['_queryIdentifier'],_0x3960bd=_0x3d25df['views']['get'](_0x1c0f65);if(!_0x3960bd){let _0x52f950=Cn(_0x29b9c9,_0x5cdb1e?_0x4dae9:null),_0x2de92d=!0x1;_0x52f950?_0x2de92d=!0x0:_0x4dae9 instanceof g?(_0x52f950=is(_0x29b9c9,_0x4dae9),_0x2de92d=!0x1):(_0x52f950=g['EMPTY_NODE'],_0x2de92d=!0x1);const _0x3cc0cd=Un(new Te(_0x52f950,_0x2de92d,!0x1),new Te(_0x4dae9,_0x5cdb1e,!0x1));return new Du(_0x3b235c,_0x3cc0cd);}return _0x3960bd;}function Hu(_0x205f86,_0x412f01,_0x3ed11c,_0x1232f4,_0x33c838,_0x106831){const _0x26b77e=jo(_0x205f86,_0x412f01,_0x1232f4,_0x33c838,_0x106831);return _0x205f86['views']['has'](_0x412f01['_queryIdentifier'])||_0x205f86['views']['set'](_0x412f01['_queryIdentifier'],_0x26b77e),Fu(_0x26b77e,_0x3ed11c),Uu(_0x26b77e,_0x3ed11c);}function $u(_0x2eac58,_0x5300aa,_0x26f295,_0x30cdfd){const _0x3eee3e=_0x5300aa['_queryIdentifier'],_0x3f4c34=[];let _0x1613f8=[];const _0x332a26=Se(_0x2eac58);if(_0x3eee3e==='default'){for(const [_0x500738,_0x42b405]of _0x2eac58['views']['entries']())_0x1613f8=_0x1613f8['concat'](dr(_0x42b405,_0x26f295,_0x30cdfd)),ur(_0x42b405)&&(_0x2eac58['views']['delete'](_0x500738),_0x42b405['query']['_queryParams']['loadsAllData']()||_0x3f4c34['push'](_0x42b405['query']));}else{const _0x5d727e=_0x2eac58['views']['get'](_0x3eee3e);_0x5d727e&&(_0x1613f8=_0x1613f8['concat'](dr(_0x5d727e,_0x26f295,_0x30cdfd)),ur(_0x5d727e)&&(_0x2eac58['views']['delete'](_0x3eee3e),_0x5d727e['query']['_queryParams']['loadsAllData']()||_0x3f4c34['push'](_0x5d727e['query'])));}return _0x332a26&&!Se(_0x2eac58)&&_0x3f4c34['push'](new(Bu())(_0x5300aa['_repo'],_0x5300aa['_path'])),{'removed':_0x3f4c34,'events':_0x1613f8};}function Ko(_0x1ccf41){const _0x5ddb85=[];for(const _0x19f0b8 of _0x1ccf41['views']['values']())_0x19f0b8['query']['_queryParams']['loadsAllData']()||_0x5ddb85['push'](_0x19f0b8);return _0x5ddb85;}function Ie(_0x33baf9,_0x34c553){let _0x553a71=null;for(const _0x275e8a of _0x33baf9['views']['values']())_0x553a71=_0x553a71||xu(_0x275e8a,_0x34c553);return _0x553a71;}function Yo(_0x43ba28,_0x391f62){if(_0x391f62['_queryParams']['loadsAllData']())return Bn(_0x43ba28);{const _0x4c5421=_0x391f62['_queryIdentifier'];return _0x43ba28['views']['get'](_0x4c5421);}}function Qo(_0xdd402,_0x36f7e0){return Yo(_0xdd402,_0x36f7e0)!=null;}function Se(_0x1e391b){return Bn(_0x1e391b)!=null;}function Bn(_0x206b77){for(const _0x144bc4 of _0x206b77['views']['values']())if(_0x144bc4['query']['_queryParams']['loadsAllData']())return _0x144bc4;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x5832ee){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x5832ee;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xcf6b73){this['listenProvider_']=_0xcf6b73,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x4f2347,_0x4b43e5,_0x56ac0c,_0x47c3c6,_0x572323){return lu(_0x4f2347['pendingWriteTree_'],_0x4b43e5,_0x56ac0c,_0x47c3c6,_0x572323),_0x572323?_t(_0x4f2347,new Be(es(),_0x4b43e5,_0x56ac0c)):[];}function ju(_0x10eb7d,_0x2a0fb1,_0x27f42c,_0x41fb27){hu(_0x10eb7d['pendingWriteTree_'],_0x2a0fb1,_0x27f42c,_0x41fb27);const _0x15b3fe=b['fromObject'](_0x27f42c);return _t(_0x10eb7d,new ot(es(),_0x2a0fb1,_0x15b3fe));}function _e(_0x24865f,_0x238706,_0x1fb0a4=!0x1){const _0x374935=uu(_0x24865f['pendingWriteTree_'],_0x238706);if(du(_0x24865f['pendingWriteTree_'],_0x238706)){let _0x4e41d2=new b(null);return _0x374935['snap']!=null?_0x4e41d2=_0x4e41d2['set'](w(),!0x0):x(_0x374935['children'],_0x5db49b=>{_0x4e41d2=_0x4e41d2['set'](new C(_0x5db49b),!0x0);}),_t(_0x24865f,new In(_0x374935['path'],_0x4e41d2,_0x1fb0a4));}else return[];}function Yt(_0x11e24f,_0x184175,_0x4ebde7){return _t(_0x11e24f,new Be(ts(),_0x184175,_0x4ebde7));}function Ku(_0xc1efcb,_0x3634a5,_0x5cc95a){const _0x14f459=b['fromObject'](_0x5cc95a);return _t(_0xc1efcb,new ot(ts(),_0x3634a5,_0x14f459));}function Yu(_0x32ca47,_0x50ffae){return _t(_0x32ca47,new Ut(ts(),_0x50ffae));}function Qu(_0x2df07f,_0x20cc52,_0x55b2c1){const _0x521272=cs(_0x2df07f,_0x55b2c1);if(_0x521272){const _0x4680f0=ls(_0x521272),_0x5bda66=_0x4680f0['path'],_0x3da268=_0x4680f0['queryId'],_0x49327a=F(_0x5bda66,_0x20cc52),_0x1d4641=new Ut(ns(_0x3da268),_0x49327a);return hs(_0x2df07f,_0x5bda66,_0x1d4641);}else return[];}function An(_0x12ec5a,_0x210e3b,_0x455a3e,_0x19e01f,_0x320c5c=!0x1){const _0x4acb92=_0x210e3b['_path'],_0x45a740=_0x12ec5a['syncPointTree_']['get'](_0x4acb92);let _0x398a0a=[];if(_0x45a740&&(_0x210e3b['_queryIdentifier']==='default'||Qo(_0x45a740,_0x210e3b))){const _0x272e88=$u(_0x45a740,_0x210e3b,_0x455a3e,_0x19e01f);Vu(_0x45a740)&&(_0x12ec5a['syncPointTree_']=_0x12ec5a['syncPointTree_']['remove'](_0x4acb92));const _0x5a2855=_0x272e88['removed'];if(_0x398a0a=_0x272e88['events'],!_0x320c5c){const _0x2d2132=_0x5a2855['findIndex'](_0x375f1f=>_0x375f1f['_queryParams']['loadsAllData']())!==-0x1,_0x474bd9=_0x12ec5a['syncPointTree_']['findOnPath'](_0x4acb92,(_0x463466,_0x2ea171)=>Se(_0x2ea171));if(_0x2d2132&&!_0x474bd9){const _0x22f805=_0x12ec5a['syncPointTree_']['subtree'](_0x4acb92);if(!_0x22f805['isEmpty']()){const _0x1b3f5d=Zu(_0x22f805);for(let _0x24d839=0x0;_0x24d839<_0x1b3f5d['length'];++_0x24d839){const _0x562a10=_0x1b3f5d[_0x24d839],_0x52d976=_0x562a10['query'],_0x40ca40=ea(_0x12ec5a,_0x562a10);_0x12ec5a['listenProvider_']['startListening'](kt(_0x52d976),Wt(_0x12ec5a,_0x52d976),_0x40ca40['hashFn'],_0x40ca40['onComplete']);}}}!_0x474bd9&&_0x5a2855['length']>0x0&&!_0x19e01f&&(_0x2d2132?_0x12ec5a['listenProvider_']['stopListening'](kt(_0x210e3b),null):_0x5a2855['forEach'](_0x40dd5a=>{const _0x64d44f=_0x12ec5a['queryToTagMap']['get'](Hn(_0x40dd5a));_0x12ec5a['listenProvider_']['stopListening'](kt(_0x40dd5a),_0x64d44f);}));}ed(_0x12ec5a,_0x5a2855);}return _0x398a0a;}function Jo(_0x358d19,_0x592789,_0x368304,_0x2d54bf){const _0x1de3cb=cs(_0x358d19,_0x2d54bf);if(_0x1de3cb!=null){const _0x451eb7=ls(_0x1de3cb),_0x204a51=_0x451eb7['path'],_0x32a5d3=_0x451eb7['queryId'],_0x183fcc=F(_0x204a51,_0x592789),_0x1cfc4c=new Be(ns(_0x32a5d3),_0x183fcc,_0x368304);return hs(_0x358d19,_0x204a51,_0x1cfc4c);}else return[];}function Ju(_0x3a5c34,_0x49ff47,_0x4a1005,_0x2dc28e){const _0x4ccd2a=cs(_0x3a5c34,_0x2dc28e);if(_0x4ccd2a){const _0x42feb5=ls(_0x4ccd2a),_0x53dec3=_0x42feb5['path'],_0x5c68eb=_0x42feb5['queryId'],_0x5b287e=F(_0x53dec3,_0x49ff47),_0x4be3fc=b['fromObject'](_0x4a1005),_0x2483df=new ot(ns(_0x5c68eb),_0x5b287e,_0x4be3fc);return hs(_0x3a5c34,_0x53dec3,_0x2483df);}else return[];}function Ni(_0x5c9a70,_0x4999b7,_0x432b1f,_0x14f1b0=!0x1){const _0x54db74=_0x4999b7['_path'];let _0x5d43f3=null,_0x19437c=!0x1;_0x5c9a70['syncPointTree_']['foreachOnPath'](_0x54db74,(_0x3cadd8,_0x2b18c7)=>{const _0x5a0263=F(_0x3cadd8,_0x54db74);_0x5d43f3=_0x5d43f3||Ie(_0x2b18c7,_0x5a0263),_0x19437c=_0x19437c||Se(_0x2b18c7);});let _0x3337d4=_0x5c9a70['syncPointTree_']['get'](_0x54db74);_0x3337d4?(_0x19437c=_0x19437c||Se(_0x3337d4),_0x5d43f3=_0x5d43f3||Ie(_0x3337d4,w())):(_0x3337d4=new zo(),_0x5c9a70['syncPointTree_']=_0x5c9a70['syncPointTree_']['set'](_0x54db74,_0x3337d4));let _0x24d9ee;_0x5d43f3!=null?_0x24d9ee=!0x0:(_0x24d9ee=!0x1,_0x5d43f3=g['EMPTY_NODE'],_0x5c9a70['syncPointTree_']['subtree'](_0x54db74)['foreachChild']((_0x26dde2,_0x335444)=>{const _0x23d171=Ie(_0x335444,w());_0x23d171&&(_0x5d43f3=_0x5d43f3['updateImmediateChild'](_0x26dde2,_0x23d171));}));const _0x5dfa78=Qo(_0x3337d4,_0x4999b7);if(!_0x5dfa78&&!_0x4999b7['_queryParams']['loadsAllData']()){const _0xfc65aa=Hn(_0x4999b7);f(!_0x5c9a70['queryToTagMap']['has'](_0xfc65aa),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x185569=td();_0x5c9a70['queryToTagMap']['set'](_0xfc65aa,_0x185569),_0x5c9a70['tagToQueryMap']['set'](_0x185569,_0xfc65aa);}const _0x227861=Wn(_0x5c9a70['pendingWriteTree_'],_0x54db74);let _0x2773e7=Hu(_0x3337d4,_0x4999b7,_0x432b1f,_0x227861,_0x5d43f3,_0x24d9ee);if(!_0x5dfa78&&!_0x19437c&&!_0x14f1b0){const _0x351321=Yo(_0x3337d4,_0x4999b7);_0x2773e7=_0x2773e7['concat'](nd(_0x5c9a70,_0x4999b7,_0x351321));}return _0x2773e7;}function Vn(_0x8ac4c8,_0x24503b,_0x1cfc50){const _0x4859c2=_0x8ac4c8['pendingWriteTree_'],_0x38d059=_0x8ac4c8['syncPointTree_']['findOnPath'](_0x24503b,(_0x108fed,_0x2a0459)=>{const _0x1694db=F(_0x108fed,_0x24503b),_0x17bc20=Ie(_0x2a0459,_0x1694db);if(_0x17bc20)return _0x17bc20;});return Bo(_0x4859c2,_0x24503b,_0x38d059,_0x1cfc50,!0x0);}function Xu(_0x59d919,_0x379566){const _0x1a4d3c=_0x379566['_path'];let _0x273f7d=null;_0x59d919['syncPointTree_']['foreachOnPath'](_0x1a4d3c,(_0x152975,_0x44ab69)=>{const _0xb1da42=F(_0x152975,_0x1a4d3c);_0x273f7d=_0x273f7d||Ie(_0x44ab69,_0xb1da42);});let _0x37f5de=_0x59d919['syncPointTree_']['get'](_0x1a4d3c);_0x37f5de?_0x273f7d=_0x273f7d||Ie(_0x37f5de,w()):(_0x37f5de=new zo(),_0x59d919['syncPointTree_']=_0x59d919['syncPointTree_']['set'](_0x1a4d3c,_0x37f5de));const _0x1d5098=_0x273f7d!=null,_0x22774d=_0x1d5098?new Te(_0x273f7d,!0x0,!0x1):null,_0x803bbf=Wn(_0x59d919['pendingWriteTree_'],_0x379566['_path']),_0xf1cbb5=jo(_0x37f5de,_0x379566,_0x803bbf,_0x1d5098?_0x22774d['getNode']():g['EMPTY_NODE'],_0x1d5098);return Lu(_0xf1cbb5);}function _t(_0x3ab381,_0x584c47){return Xo(_0x584c47,_0x3ab381['syncPointTree_'],null,Wn(_0x3ab381['pendingWriteTree_'],w()));}function Xo(_0x24f932,_0x2c6fab,_0x4dca43,_0x225efe){if(v(_0x24f932['path']))return Zo(_0x24f932,_0x2c6fab,_0x4dca43,_0x225efe);{const _0x556b85=_0x2c6fab['get'](w());_0x4dca43==null&&_0x556b85!=null&&(_0x4dca43=Ie(_0x556b85,w()));let _0x49824b=[];const _0x57e378=y(_0x24f932['path']),_0x281daf=_0x24f932['operationForChild'](_0x57e378),_0x358ed8=_0x2c6fab['children']['get'](_0x57e378);if(_0x358ed8&&_0x281daf){const _0x41e1ff=_0x4dca43?_0x4dca43['getImmediateChild'](_0x57e378):null,_0x47d7c5=Vo(_0x225efe,_0x57e378);_0x49824b=_0x49824b['concat'](Xo(_0x281daf,_0x358ed8,_0x41e1ff,_0x47d7c5));}return _0x556b85&&(_0x49824b=_0x49824b['concat'](os(_0x556b85,_0x24f932,_0x225efe,_0x4dca43))),_0x49824b;}}function Zo(_0xe40078,_0x1464f0,_0x55aed1,_0x24d0bd){const _0xbf3e05=_0x1464f0['get'](w());_0x55aed1==null&&_0xbf3e05!=null&&(_0x55aed1=Ie(_0xbf3e05,w()));let _0x86368=[];return _0x1464f0['children']['inorderTraversal']((_0x865fd6,_0x3755e4)=>{const _0xeb2659=_0x55aed1?_0x55aed1['getImmediateChild'](_0x865fd6):null,_0x3efbf1=Vo(_0x24d0bd,_0x865fd6),_0x1268c3=_0xe40078['operationForChild'](_0x865fd6);_0x1268c3&&(_0x86368=_0x86368['concat'](Zo(_0x1268c3,_0x3755e4,_0xeb2659,_0x3efbf1)));}),_0xbf3e05&&(_0x86368=_0x86368['concat'](os(_0xbf3e05,_0xe40078,_0x24d0bd,_0x55aed1))),_0x86368;}function ea(_0x3575e6,_0x4df836){const _0x2d803c=_0x4df836['query'],_0x28d462=Wt(_0x3575e6,_0x2d803c);return{'hashFn':()=>(Mu(_0x4df836)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x4e50d7=>{if(_0x4e50d7==='ok')return _0x28d462?Qu(_0x3575e6,_0x2d803c['_path'],_0x28d462):Yu(_0x3575e6,_0x2d803c['_path']);{const _0x51356f=Kl(_0x4e50d7,_0x2d803c);return An(_0x3575e6,_0x2d803c,null,_0x51356f);}}};}function Wt(_0x49c5cc,_0x5fe980){const _0x5eda68=Hn(_0x5fe980);return _0x49c5cc['queryToTagMap']['get'](_0x5eda68);}function Hn(_0x2b1ed1){return _0x2b1ed1['_path']['toString']()+'$'+_0x2b1ed1['_queryIdentifier'];}function cs(_0x55a582,_0x4e016f){return _0x55a582['tagToQueryMap']['get'](_0x4e016f);}function ls(_0x1f3d9a){const _0x4b22a2=_0x1f3d9a['indexOf']('$');return f(_0x4b22a2!==-0x1&&_0x4b22a2<_0x1f3d9a['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1f3d9a['substr'](_0x4b22a2+0x1),'path':new C(_0x1f3d9a['substr'](0x0,_0x4b22a2))};}function hs(_0x14fadb,_0x392481,_0x1f1f35){const _0x5a4481=_0x14fadb['syncPointTree_']['get'](_0x392481);f(_0x5a4481,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3a87e=Wn(_0x14fadb['pendingWriteTree_'],_0x392481);return os(_0x5a4481,_0x1f1f35,_0x3a87e,null);}function Zu(_0x38fc7d){return _0x38fc7d['fold']((_0x37050a,_0x50f469,_0x55ad89)=>{if(_0x50f469&&Se(_0x50f469))return[Bn(_0x50f469)];{let _0x53ea94=[];return _0x50f469&&(_0x53ea94=Ko(_0x50f469)),x(_0x55ad89,(_0x4f3129,_0x3a1235)=>{_0x53ea94=_0x53ea94['concat'](_0x3a1235);}),_0x53ea94;}});}function kt(_0x2c1f17){return _0x2c1f17['_queryParams']['loadsAllData']()&&!_0x2c1f17['_queryParams']['isDefault']()?new(qu())(_0x2c1f17['_repo'],_0x2c1f17['_path']):_0x2c1f17;}function ed(_0x4c1616,_0x9a1f33){for(let _0x12614a=0x0;_0x12614a<_0x9a1f33['length'];++_0x12614a){const _0x347bbd=_0x9a1f33[_0x12614a];if(!_0x347bbd['_queryParams']['loadsAllData']()){const _0x1bc544=Hn(_0x347bbd),_0x4ca514=_0x4c1616['queryToTagMap']['get'](_0x1bc544);_0x4c1616['queryToTagMap']['delete'](_0x1bc544),_0x4c1616['tagToQueryMap']['delete'](_0x4ca514);}}}function td(){return zu++;}function nd(_0x55294c,_0x20c044,_0x56eb68){const _0x5d16e6=_0x20c044['_path'],_0x5cb747=Wt(_0x55294c,_0x20c044),_0x55001b=ea(_0x55294c,_0x56eb68),_0x46928a=_0x55294c['listenProvider_']['startListening'](kt(_0x20c044),_0x5cb747,_0x55001b['hashFn'],_0x55001b['onComplete']),_0x4ef18d=_0x55294c['syncPointTree_']['subtree'](_0x5d16e6);if(_0x5cb747)f(!Se(_0x4ef18d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x35cddd=_0x4ef18d['fold']((_0x344854,_0x109847,_0xfc927e)=>{if(!v(_0x344854)&&_0x109847&&Se(_0x109847))return[Bn(_0x109847)['query']];{let _0x17773c=[];return _0x109847&&(_0x17773c=_0x17773c['concat'](Ko(_0x109847)['map'](_0x566cc5=>_0x566cc5['query']))),x(_0xfc927e,(_0x3d235f,_0xea5da8)=>{_0x17773c=_0x17773c['concat'](_0xea5da8);}),_0x17773c;}});for(let _0x331ebc=0x0;_0x331ebc<_0x35cddd['length'];++_0x331ebc){const _0x52f948=_0x35cddd[_0x331ebc];_0x55294c['listenProvider_']['stopListening'](kt(_0x52f948),Wt(_0x55294c,_0x52f948));}}return _0x46928a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x366a3b){this['node_']=_0x366a3b;}['getImmediateChild'](_0x5a6070){const _0x2344c0=this['node_']['getImmediateChild'](_0x5a6070);return new us(_0x2344c0);}['node'](){return this['node_'];}}class ds{constructor(_0x42f467,_0x196a2c){this['syncTree_']=_0x42f467,this['path_']=_0x196a2c;}['getImmediateChild'](_0x8fda30){const _0x1e8ef2=k(this['path_'],_0x8fda30);return new ds(this['syncTree_'],_0x1e8ef2);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x8024f6){return _0x8024f6=_0x8024f6||{},_0x8024f6['timestamp']=_0x8024f6['timestamp']||new Date()['getTime'](),_0x8024f6;},_r=function(_0x89aa6f,_0x41e95e,_0x533597){if(!_0x89aa6f||typeof _0x89aa6f!='object')return _0x89aa6f;if(f('.sv'in _0x89aa6f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x89aa6f['.sv']=='string')return sd(_0x89aa6f['.sv'],_0x41e95e,_0x533597);if(typeof _0x89aa6f['.sv']=='object')return rd(_0x89aa6f['.sv'],_0x41e95e);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x89aa6f,null,0x2));},sd=function(_0x9d2cfa,_0xea6b54,_0x29fdbe){switch(_0x9d2cfa){case'timestamp':return _0x29fdbe['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x9d2cfa);}},rd=function(_0x20406b,_0x6aa6a,_0x48f27f){_0x20406b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x20406b,null,0x2));const _0x51ec31=_0x20406b['increment'];typeof _0x51ec31!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x51ec31);const _0x5ea8ec=_0x6aa6a['node']();if(f(_0x5ea8ec!==null&&typeof _0x5ea8ec<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5ea8ec['isLeafNode']())return _0x51ec31;const _0x522504=_0x5ea8ec['getValue']();return typeof _0x522504!='number'?_0x51ec31:_0x522504+_0x51ec31;},ta=function(_0x4f5881,_0x1a703d,_0x346ed7,_0x28f76d){return ps(_0x1a703d,new ds(_0x346ed7,_0x4f5881),_0x28f76d);},fs=function(_0x539de6,_0x48458e,_0x1fe166){return ps(_0x539de6,new us(_0x48458e),_0x1fe166);};function ps(_0xcf7e61,_0x31fa49,_0x28547a){const _0x3cb269=_0xcf7e61['getPriority']()['val'](),_0x275ba4=_r(_0x3cb269,_0x31fa49['getImmediateChild']('.priority'),_0x28547a);let _0x1072fe;if(_0xcf7e61['isLeafNode']()){const _0x3c949a=_0xcf7e61,_0x36a15e=_r(_0x3c949a['getValue'](),_0x31fa49,_0x28547a);return _0x36a15e!==_0x3c949a['getValue']()||_0x275ba4!==_0x3c949a['getPriority']()['val']()?new D(_0x36a15e,A(_0x275ba4)):_0xcf7e61;}else{const _0x4bc686=_0xcf7e61;return _0x1072fe=_0x4bc686,_0x275ba4!==_0x4bc686['getPriority']()['val']()&&(_0x1072fe=_0x1072fe['updatePriority'](new D(_0x275ba4))),_0x4bc686['forEachChild'](R,(_0x549dc6,_0x1d4650)=>{const _0x4523a7=ps(_0x1d4650,_0x31fa49['getImmediateChild'](_0x549dc6),_0x28547a);_0x4523a7!==_0x1d4650&&(_0x1072fe=_0x1072fe['updateImmediateChild'](_0x549dc6,_0x4523a7));}),_0x1072fe;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x2196ef='',_0x4662b9=null,_0x2cabc0={'children':{},'childCount':0x0}){this['name']=_0x2196ef,this['parent']=_0x4662b9,this['node']=_0x2cabc0;}}function $n(_0x3101b5,_0x6a5726){let _0x3aa65b=_0x6a5726 instanceof C?_0x6a5726:new C(_0x6a5726),_0xf16b79=_0x3101b5,_0x32629c=y(_0x3aa65b);for(;_0x32629c!==null;){const _0x54897f=Le(_0xf16b79['node']['children'],_0x32629c)||{'children':{},'childCount':0x0};_0xf16b79=new _s(_0x32629c,_0xf16b79,_0x54897f),_0x3aa65b=S(_0x3aa65b),_0x32629c=y(_0x3aa65b);}return _0xf16b79;}function je(_0x3e107b){return _0x3e107b['node']['value'];}function gs(_0x2cbde4,_0x2a2cba){_0x2cbde4['node']['value']=_0x2a2cba,Oi(_0x2cbde4);}function na(_0x40b949){return _0x40b949['node']['childCount']>0x0;}function od(_0x10bee3){return je(_0x10bee3)===void 0x0&&!na(_0x10bee3);}function Gn(_0x3fb794,_0x26b9c2){x(_0x3fb794['node']['children'],(_0x5f00e7,_0x2fd924)=>{_0x26b9c2(new _s(_0x5f00e7,_0x3fb794,_0x2fd924));});}function ia(_0x66c2e1,_0x3f1e2e,_0x6de6ce,_0x191d10){_0x6de6ce&&_0x3f1e2e(_0x66c2e1),Gn(_0x66c2e1,_0x166517=>{ia(_0x166517,_0x3f1e2e,!0x0);});}function ad(_0x3ed956,_0x1e6b25,_0x3c48a6){let _0x578b10=_0x3ed956['parent'];for(;_0x578b10!==null;){if(_0x1e6b25(_0x578b10))return!0x0;_0x578b10=_0x578b10['parent'];}return!0x1;}function Qt(_0x28725f){return new C(_0x28725f['parent']===null?_0x28725f['name']:Qt(_0x28725f['parent'])+'/'+_0x28725f['name']);}function Oi(_0x3fd0b0){_0x3fd0b0['parent']!==null&&cd(_0x3fd0b0['parent'],_0x3fd0b0['name'],_0x3fd0b0);}function cd(_0x102834,_0x5592ec,_0x282e3b){const _0xf60ff=od(_0x282e3b),_0x167a08=Q(_0x102834['node']['children'],_0x5592ec);_0xf60ff&&_0x167a08?(delete _0x102834['node']['children'][_0x5592ec],_0x102834['node']['childCount']--,Oi(_0x102834)):!_0xf60ff&&!_0x167a08&&(_0x102834['node']['children'][_0x5592ec]=_0x282e3b['node'],_0x102834['node']['childCount']++,Oi(_0x102834));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x2711f0){return typeof _0x2711f0=='string'&&_0x2711f0['length']!==0x0&&!ld['test'](_0x2711f0);},sa=function(_0x1d6010){return typeof _0x1d6010=='string'&&_0x1d6010['length']!==0x0&&!hd['test'](_0x1d6010);},ud=function(_0xf2a73a){return _0xf2a73a&&(_0xf2a73a=_0xf2a73a['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xf2a73a);},Bt=function(_0x4e1b11){return _0x4e1b11===null||typeof _0x4e1b11=='string'||typeof _0x4e1b11=='number'&&!xn(_0x4e1b11)||_0x4e1b11&&typeof _0x4e1b11=='object'&&Q(_0x4e1b11,'.sv');},He=function(_0x58fcf1,_0xd006c0,_0x5dd9dc,_0x46845a){_0x46845a&&_0xd006c0===void 0x0||Jt(it(_0x58fcf1,'value'),_0xd006c0,_0x5dd9dc);},Jt=function(_0x1afd90,_0x522f06,_0x23bac1){const _0x5a5561=_0x23bac1 instanceof C?new Ah(_0x23bac1,_0x1afd90):_0x23bac1;if(_0x522f06===void 0x0)throw new Error(_0x1afd90+'contains\x20undefined\x20'+Oe(_0x5a5561));if(typeof _0x522f06=='function')throw new Error(_0x1afd90+'contains\x20a\x20function\x20'+Oe(_0x5a5561)+'\x20with\x20contents\x20=\x20'+_0x522f06['toString']());if(xn(_0x522f06))throw new Error(_0x1afd90+'contains\x20'+_0x522f06['toString']()+'\x20'+Oe(_0x5a5561));if(typeof _0x522f06=='string'&&_0x522f06['length']>ui/0x3&&Ln(_0x522f06)>ui)throw new Error(_0x1afd90+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x5a5561)+'\x20(\x27'+_0x522f06['substring'](0x0,0x32)+'...\x27)');if(_0x522f06&&typeof _0x522f06=='object'){let _0x17aa75=!0x1,_0x3c2ae3=!0x1;if(x(_0x522f06,(_0x58c4cf,_0x4d6018)=>{if(_0x58c4cf==='.value')_0x17aa75=!0x0;else{if(_0x58c4cf!=='.priority'&&_0x58c4cf!=='.sv'&&(_0x3c2ae3=!0x0,!ms(_0x58c4cf)))throw new Error(_0x1afd90+'\x20contains\x20an\x20invalid\x20key\x20('+_0x58c4cf+')\x20'+Oe(_0x5a5561)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x5a5561,_0x58c4cf),Jt(_0x1afd90,_0x4d6018,_0x5a5561),Ph(_0x5a5561);}),_0x17aa75&&_0x3c2ae3)throw new Error(_0x1afd90+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x5a5561)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4354f9,_0x5e517d){let _0x4a171f,_0x5f1cf5;for(_0x4a171f=0x0;_0x4a171f<_0x5e517d['length'];_0x4a171f++){_0x5f1cf5=_0x5e517d[_0x4a171f];const _0x7184d3=Mt(_0x5f1cf5);for(let _0x17de74=0x0;_0x17de74<_0x7184d3['length'];_0x17de74++)if(!(_0x7184d3[_0x17de74]==='.priority'&&_0x17de74===_0x7184d3['length']-0x1)){if(!ms(_0x7184d3[_0x17de74]))throw new Error(_0x4354f9+'contains\x20an\x20invalid\x20key\x20('+_0x7184d3[_0x17de74]+')\x20in\x20path\x20'+_0x5f1cf5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5e517d['sort'](Rh);let _0x1d591d=null;for(_0x4a171f=0x0;_0x4a171f<_0x5e517d['length'];_0x4a171f++){if(_0x5f1cf5=_0x5e517d[_0x4a171f],_0x1d591d!==null&&G(_0x1d591d,_0x5f1cf5))throw new Error(_0x4354f9+'contains\x20a\x20path\x20'+_0x1d591d['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5f1cf5['toString']());_0x1d591d=_0x5f1cf5;}},ra=function(_0x4dc532,_0x2e07a4,_0x23c22c,_0x2f3729){const _0xaf5c61=it(_0x4dc532,'values');if(!(_0x2e07a4&&typeof _0x2e07a4=='object')||Array['isArray'](_0x2e07a4))throw new Error(_0xaf5c61+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x357f6c=[];x(_0x2e07a4,(_0x51ef00,_0x517bbe)=>{const _0x383992=new C(_0x51ef00);if(Jt(_0xaf5c61,_0x517bbe,k(_0x23c22c,_0x383992)),ji(_0x383992)==='.priority'&&!Bt(_0x517bbe))throw new Error(_0xaf5c61+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x383992['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x357f6c['push'](_0x383992);}),dd(_0xaf5c61,_0x357f6c);},fd=function(_0x1250ed,_0x4f4e84,_0x5a3f03){if(xn(_0x4f4e84))throw new Error(it(_0x1250ed,'priority')+'is\x20'+_0x4f4e84['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4f4e84))throw new Error(it(_0x1250ed,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x481f37,_0xd49a8d,_0x2de2b0,_0x28f8a2){if(!sa(_0x2de2b0))throw new Error(it(_0x481f37,_0xd49a8d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2de2b0+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x207313,_0x3be2f5,_0x5ceb70,_0x40f35c){_0x5ceb70&&(_0x5ceb70=_0x5ceb70['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x207313,_0x3be2f5,_0x5ceb70);},Me=function(_0x4a8a75,_0x3cf8f5){if(y(_0x3cf8f5)==='.info')throw new Error(_0x4a8a75+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x226d0f,_0x1a0498){const _0x414aaf=_0x1a0498['path']['toString']();if(typeof _0x1a0498['repoInfo']['host']!='string'||_0x1a0498['repoInfo']['host']['length']===0x0||!ms(_0x1a0498['repoInfo']['namespace'])&&_0x1a0498['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x414aaf['length']!==0x0&&!ud(_0x414aaf))throw new Error(it(_0x226d0f,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x87b345,_0x119171){let _0xf787ac=null;for(let _0x54cba5=0x0;_0x54cba5<_0x119171['length'];_0x54cba5++){const _0x160a2a=_0x119171[_0x54cba5],_0x444ee7=_0x160a2a['getPath']();_0xf787ac!==null&&!Ki(_0x444ee7,_0xf787ac['path'])&&(_0x87b345['eventLists_']['push'](_0xf787ac),_0xf787ac=null),_0xf787ac===null&&(_0xf787ac={'events':[],'path':_0x444ee7}),_0xf787ac['events']['push'](_0x160a2a);}_0xf787ac&&_0x87b345['eventLists_']['push'](_0xf787ac);}function oa(_0x143d87,_0x1f743d,_0x26f4aa){qn(_0x143d87,_0x26f4aa),aa(_0x143d87,_0x566ce3=>Ki(_0x566ce3,_0x1f743d));}function V(_0x1ec7e2,_0x2b0fe0,_0x13ad0d){qn(_0x1ec7e2,_0x13ad0d),aa(_0x1ec7e2,_0x49bfaf=>G(_0x49bfaf,_0x2b0fe0)||G(_0x2b0fe0,_0x49bfaf));}function aa(_0x3da947,_0x2fa894){_0x3da947['recursionDepth_']++;let _0x1223b9=!0x0;for(let _0x176aca=0x0;_0x176aca<_0x3da947['eventLists_']['length'];_0x176aca++){const _0xe16dc8=_0x3da947['eventLists_'][_0x176aca];if(_0xe16dc8){const _0x3d7c4d=_0xe16dc8['path'];_0x2fa894(_0x3d7c4d)?(md(_0x3da947['eventLists_'][_0x176aca]),_0x3da947['eventLists_'][_0x176aca]=null):_0x1223b9=!0x1;}}_0x1223b9&&(_0x3da947['eventLists_']=[]),_0x3da947['recursionDepth_']--;}function md(_0x2ebe9e){for(let _0x29aeea=0x0;_0x29aeea<_0x2ebe9e['events']['length'];_0x29aeea++){const _0x2a69ef=_0x2ebe9e['events'][_0x29aeea];if(_0x2a69ef!==null){_0x2ebe9e['events'][_0x29aeea]=null;const _0x242641=_0x2a69ef['getEventRunner']();St&&L('event:\x20'+_0x2a69ef['toString']()),ft(_0x242641);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x51780a,_0x4517ac,_0x690252,_0x5cce3f){this['repoInfo_']=_0x51780a,this['forceRestClient_']=_0x4517ac,this['authTokenProvider_']=_0x690252,this['appCheckProvider_']=_0x5cce3f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x1e1083,_0x397d47,_0x5a61e8){if(_0x1e1083['stats_']=qi(_0x1e1083['repoInfo_']),_0x1e1083['forceRestClient_']||Xl())_0x1e1083['server_']=new vn(_0x1e1083['repoInfo_'],(_0x4fa769,_0x282f1f,_0x2d6df0,_0x2e7ff8)=>{gr(_0x1e1083,_0x4fa769,_0x282f1f,_0x2d6df0,_0x2e7ff8);},_0x1e1083['authTokenProvider_'],_0x1e1083['appCheckProvider_']),setTimeout(()=>mr(_0x1e1083,!0x0),0x0);else{if(typeof _0x5a61e8<'u'&&_0x5a61e8!==null){if(typeof _0x5a61e8!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5a61e8);}catch(_0x41f327){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x41f327);}}_0x1e1083['persistentConnection_']=new se(_0x1e1083['repoInfo_'],_0x397d47,(_0x4dcd93,_0x3e7c3e,_0x193fd5,_0x5278eb)=>{gr(_0x1e1083,_0x4dcd93,_0x3e7c3e,_0x193fd5,_0x5278eb);},_0x4f3334=>{mr(_0x1e1083,_0x4f3334);},_0x1adf56=>{Id(_0x1e1083,_0x1adf56);},_0x1e1083['authTokenProvider_'],_0x1e1083['appCheckProvider_'],_0x5a61e8),_0x1e1083['server_']=_0x1e1083['persistentConnection_'];}_0x1e1083['authTokenProvider_']['addTokenChangeListener'](_0x539473=>{_0x1e1083['server_']['refreshAuthToken'](_0x539473);}),_0x1e1083['appCheckProvider_']['addTokenChangeListener'](_0x52892b=>{_0x1e1083['server_']['refreshAppCheckToken'](_0x52892b['token']);}),_0x1e1083['statsReporter_']=ih(_0x1e1083['repoInfo_'],()=>new iu(_0x1e1083['stats_'],_0x1e1083['server_'])),_0x1e1083['infoData_']=new Xh(),_0x1e1083['infoSyncTree_']=new pr({'startListening':(_0x4bb280,_0x926d53,_0x2e69af,_0x3f1382)=>{let _0x3af1de=[];const _0x7d182f=_0x1e1083['infoData_']['getNode'](_0x4bb280['_path']);return _0x7d182f['isEmpty']()||(_0x3af1de=Yt(_0x1e1083['infoSyncTree_'],_0x4bb280['_path'],_0x7d182f),setTimeout(()=>{_0x3f1382('ok');},0x0)),_0x3af1de;},'stopListening':()=>{}}),vs(_0x1e1083,'connected',!0x1),_0x1e1083['serverSyncTree_']=new pr({'startListening':(_0x4924ea,_0x228734,_0x365fe0,_0x1684e1)=>(_0x1e1083['server_']['listen'](_0x4924ea,_0x365fe0,_0x228734,(_0x2b4b3d,_0x595275)=>{const _0x324303=_0x1684e1(_0x2b4b3d,_0x595275);V(_0x1e1083['eventQueue_'],_0x4924ea['_path'],_0x324303);}),[]),'stopListening':(_0xe4774e,_0x38e952)=>{_0x1e1083['server_']['unlisten'](_0xe4774e,_0x38e952);}});}function la(_0x5b3ec2){const _0x23ca7c=_0x5b3ec2['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x23ca7c;}function Xt(_0x137652){return id({'timestamp':la(_0x137652)});}function gr(_0x95b1da,_0x1025f5,_0x19851c,_0x569412,_0x1adacf){_0x95b1da['dataUpdateCount']++;const _0x1a8e28=new C(_0x1025f5);_0x19851c=_0x95b1da['interceptServerDataCallback_']?_0x95b1da['interceptServerDataCallback_'](_0x1025f5,_0x19851c):_0x19851c;let _0x15454d=[];if(_0x1adacf){if(_0x569412){const _0xcf9c37=_n(_0x19851c,_0x310448=>A(_0x310448));_0x15454d=Ju(_0x95b1da['serverSyncTree_'],_0x1a8e28,_0xcf9c37,_0x1adacf);}else{const _0x41e56a=A(_0x19851c);_0x15454d=Jo(_0x95b1da['serverSyncTree_'],_0x1a8e28,_0x41e56a,_0x1adacf);}}else{if(_0x569412){const _0x4f882c=_n(_0x19851c,_0x362cdb=>A(_0x362cdb));_0x15454d=Ku(_0x95b1da['serverSyncTree_'],_0x1a8e28,_0x4f882c);}else{const _0x1e8e9a=A(_0x19851c);_0x15454d=Yt(_0x95b1da['serverSyncTree_'],_0x1a8e28,_0x1e8e9a);}}let _0x4560eb=_0x1a8e28;_0x15454d['length']>0x0&&(_0x4560eb=ct(_0x95b1da,_0x1a8e28)),V(_0x95b1da['eventQueue_'],_0x4560eb,_0x15454d);}function mr(_0x1db0f1,_0x159825){vs(_0x1db0f1,'connected',_0x159825),_0x159825===!0x1&&Sd(_0x1db0f1);}function Id(_0x4f5731,_0x590363){x(_0x590363,(_0x53a47b,_0x20ecbb)=>{vs(_0x4f5731,_0x53a47b,_0x20ecbb);});}function vs(_0x4a2eb8,_0x5c31db,_0x48e6fb){const _0x51dfc2=new C('/.info/'+_0x5c31db),_0x427bd2=A(_0x48e6fb);_0x4a2eb8['infoData_']['updateSnapshot'](_0x51dfc2,_0x427bd2);const _0x1ef891=Yt(_0x4a2eb8['infoSyncTree_'],_0x51dfc2,_0x427bd2);V(_0x4a2eb8['eventQueue_'],_0x51dfc2,_0x1ef891);}function zn(_0x9a0b4c){return _0x9a0b4c['nextWriteId_']++;}function wd(_0x366a4b,_0x4ffb84,_0xfe60b){const _0x5316dc=Xu(_0x366a4b['serverSyncTree_'],_0x4ffb84);return _0x5316dc!=null?Promise['resolve'](_0x5316dc):_0x366a4b['server_']['get'](_0x4ffb84)['then'](_0x134211=>{const _0x28cd00=A(_0x134211)['withIndex'](_0x4ffb84['_queryParams']['getIndex']());Ni(_0x366a4b['serverSyncTree_'],_0x4ffb84,_0xfe60b,!0x0);let _0x19da08;if(_0x4ffb84['_queryParams']['loadsAllData']())_0x19da08=Yt(_0x366a4b['serverSyncTree_'],_0x4ffb84['_path'],_0x28cd00);else{const _0x5dcee7=Wt(_0x366a4b['serverSyncTree_'],_0x4ffb84);_0x19da08=Jo(_0x366a4b['serverSyncTree_'],_0x4ffb84['_path'],_0x28cd00,_0x5dcee7);}return V(_0x366a4b['eventQueue_'],_0x4ffb84['_path'],_0x19da08),An(_0x366a4b['serverSyncTree_'],_0x4ffb84,_0xfe60b,null,!0x0),_0x28cd00;},_0x30fd71=>(gt(_0x366a4b,'get\x20for\x20query\x20'+O(_0x4ffb84)+'\x20failed:\x20'+_0x30fd71),Promise['reject'](new Error(_0x30fd71))));}function Cd(_0x389f63,_0x279b7e,_0x284dd2,_0x383f30,_0x5ed23c){gt(_0x389f63,'set',{'path':_0x279b7e['toString'](),'value':_0x284dd2,'priority':_0x383f30});const _0x3b6440=Xt(_0x389f63),_0x4de1e4=A(_0x284dd2,_0x383f30),_0x1e4565=Vn(_0x389f63['serverSyncTree_'],_0x279b7e),_0x50f172=fs(_0x4de1e4,_0x1e4565,_0x3b6440),_0x7cf7d5=zn(_0x389f63),_0x2933ba=as(_0x389f63['serverSyncTree_'],_0x279b7e,_0x50f172,_0x7cf7d5,!0x0);qn(_0x389f63['eventQueue_'],_0x2933ba),_0x389f63['server_']['put'](_0x279b7e['toString'](),_0x4de1e4['val'](!0x0),(_0x4923f5,_0x469a07)=>{const _0x185214=_0x4923f5==='ok';_0x185214||U('set\x20at\x20'+_0x279b7e+'\x20failed:\x20'+_0x4923f5);const _0x34a558=_e(_0x389f63['serverSyncTree_'],_0x7cf7d5,!_0x185214);V(_0x389f63['eventQueue_'],_0x279b7e,_0x34a558),be(_0x389f63,_0x5ed23c,_0x4923f5,_0x469a07);});const _0x1994d7=Is(_0x389f63,_0x279b7e);ct(_0x389f63,_0x1994d7),V(_0x389f63['eventQueue_'],_0x1994d7,[]);}function Td(_0x4284b4,_0x57cbe7,_0x21158c,_0x3643c2){gt(_0x4284b4,'update',{'path':_0x57cbe7['toString'](),'value':_0x21158c});let _0x18565f=!0x0;const _0x1c84f7=Xt(_0x4284b4),_0x21fae0={};if(x(_0x21158c,(_0x3adebd,_0xe4ff6c)=>{_0x18565f=!0x1,_0x21fae0[_0x3adebd]=ta(k(_0x57cbe7,_0x3adebd),A(_0xe4ff6c),_0x4284b4['serverSyncTree_'],_0x1c84f7);}),_0x18565f)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4284b4,_0x3643c2,'ok',void 0x0);else{const _0x1d1a33=zn(_0x4284b4),_0x4cab60=ju(_0x4284b4['serverSyncTree_'],_0x57cbe7,_0x21fae0,_0x1d1a33);qn(_0x4284b4['eventQueue_'],_0x4cab60),_0x4284b4['server_']['merge'](_0x57cbe7['toString'](),_0x21158c,(_0x52b44b,_0x3b2d24)=>{const _0x5d58f3=_0x52b44b==='ok';_0x5d58f3||U('update\x20at\x20'+_0x57cbe7+'\x20failed:\x20'+_0x52b44b);const _0x5f5199=_e(_0x4284b4['serverSyncTree_'],_0x1d1a33,!_0x5d58f3),_0x53735f=_0x5f5199['length']>0x0?ct(_0x4284b4,_0x57cbe7):_0x57cbe7;V(_0x4284b4['eventQueue_'],_0x53735f,_0x5f5199),be(_0x4284b4,_0x3643c2,_0x52b44b,_0x3b2d24);}),x(_0x21158c,_0x2b3117=>{const _0x1582dc=Is(_0x4284b4,k(_0x57cbe7,_0x2b3117));ct(_0x4284b4,_0x1582dc);}),V(_0x4284b4['eventQueue_'],_0x57cbe7,[]);}}function Sd(_0x1cfa25){gt(_0x1cfa25,'onDisconnectEvents');const _0x5c6856=Xt(_0x1cfa25),_0x1f5aee=En();Si(_0x1cfa25['onDisconnect_'],w(),(_0x331ace,_0x5534af)=>{const _0x208389=ta(_0x331ace,_0x5534af,_0x1cfa25['serverSyncTree_'],_0x5c6856);pt(_0x1f5aee,_0x331ace,_0x208389);});let _0x1c87ec=[];Si(_0x1f5aee,w(),(_0x4cdf28,_0x101d39)=>{_0x1c87ec=_0x1c87ec['concat'](Yt(_0x1cfa25['serverSyncTree_'],_0x4cdf28,_0x101d39));const _0x580d63=Is(_0x1cfa25,_0x4cdf28);ct(_0x1cfa25,_0x580d63);}),_0x1cfa25['onDisconnect_']=En(),V(_0x1cfa25['eventQueue_'],w(),_0x1c87ec);}function bd(_0x4d4169,_0xd49e46,_0x86cfe4){_0x4d4169['server_']['onDisconnectCancel'](_0xd49e46['toString'](),(_0xf77da9,_0x2a576b)=>{_0xf77da9==='ok'&&Ti(_0x4d4169['onDisconnect_'],_0xd49e46),be(_0x4d4169,_0x86cfe4,_0xf77da9,_0x2a576b);});}function yr(_0x1e2a94,_0x3cd192,_0x297d64,_0x3cf168){const _0x575cac=A(_0x297d64);_0x1e2a94['server_']['onDisconnectPut'](_0x3cd192['toString'](),_0x575cac['val'](!0x0),(_0x13859d,_0x270fa8)=>{_0x13859d==='ok'&&pt(_0x1e2a94['onDisconnect_'],_0x3cd192,_0x575cac),be(_0x1e2a94,_0x3cf168,_0x13859d,_0x270fa8);});}function Rd(_0x49a933,_0x155a85,_0xbce12,_0x3f11c4,_0xe9f7a6){const _0x30aa37=A(_0xbce12,_0x3f11c4);_0x49a933['server_']['onDisconnectPut'](_0x155a85['toString'](),_0x30aa37['val'](!0x0),(_0xde3d0f,_0x18c32a)=>{_0xde3d0f==='ok'&&pt(_0x49a933['onDisconnect_'],_0x155a85,_0x30aa37),be(_0x49a933,_0xe9f7a6,_0xde3d0f,_0x18c32a);});}function Ad(_0x246bdc,_0x241d04,_0x25897b,_0x5b4fd1){if(pn(_0x25897b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x246bdc,_0x5b4fd1,'ok',void 0x0);return;}_0x246bdc['server_']['onDisconnectMerge'](_0x241d04['toString'](),_0x25897b,(_0x3ae12e,_0x2318fd)=>{_0x3ae12e==='ok'&&x(_0x25897b,(_0xd03a0e,_0x21a989)=>{const _0x29d397=A(_0x21a989);pt(_0x246bdc['onDisconnect_'],k(_0x241d04,_0xd03a0e),_0x29d397);}),be(_0x246bdc,_0x5b4fd1,_0x3ae12e,_0x2318fd);});}function kd(_0x15cf19,_0x46e762,_0x3fac46){let _0x55fc85;y(_0x46e762['_path'])==='.info'?_0x55fc85=Ni(_0x15cf19['infoSyncTree_'],_0x46e762,_0x3fac46):_0x55fc85=Ni(_0x15cf19['serverSyncTree_'],_0x46e762,_0x3fac46),oa(_0x15cf19['eventQueue_'],_0x46e762['_path'],_0x55fc85);}function Pd(_0x2979a7,_0x1a4bd2,_0x31cfbd){let _0xc21af7;y(_0x1a4bd2['_path'])==='.info'?_0xc21af7=An(_0x2979a7['infoSyncTree_'],_0x1a4bd2,_0x31cfbd):_0xc21af7=An(_0x2979a7['serverSyncTree_'],_0x1a4bd2,_0x31cfbd),oa(_0x2979a7['eventQueue_'],_0x1a4bd2['_path'],_0xc21af7);}function ha(_0x2adc00){_0x2adc00['persistentConnection_']&&_0x2adc00['persistentConnection_']['interrupt'](ca);}function Nd(_0x40cd5e){_0x40cd5e['persistentConnection_']&&_0x40cd5e['persistentConnection_']['resume'](ca);}function gt(_0x55da9d,..._0x479918){let _0x4e16c2='';_0x55da9d['persistentConnection_']&&(_0x4e16c2=_0x55da9d['persistentConnection_']['id']+':'),L(_0x4e16c2,..._0x479918);}function be(_0x420f26,_0x258320,_0x5c72b7,_0x51e289){_0x258320&&ft(()=>{if(_0x5c72b7==='ok')_0x258320(null);else{const _0x440f2e=(_0x5c72b7||'error')['toUpperCase']();let _0x27ebf1=_0x440f2e;_0x51e289&&(_0x27ebf1+=':\x20'+_0x51e289);const _0x546f1d=new Error(_0x27ebf1);_0x546f1d['code']=_0x440f2e,_0x258320(_0x546f1d);}});}function Od(_0x19fc95,_0x5c678f,_0x454167,_0x4b6671,_0x149536,_0x198be1){gt(_0x19fc95,'transaction\x20on\x20'+_0x5c678f);const _0x2305f2={'path':_0x5c678f,'update':_0x454167,'onComplete':_0x4b6671,'status':null,'order':so(),'applyLocally':_0x198be1,'retryCount':0x0,'unwatcher':_0x149536,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x45bcd8=Es(_0x19fc95,_0x5c678f,void 0x0);_0x2305f2['currentInputSnapshot']=_0x45bcd8;const _0x4d2c33=_0x2305f2['update'](_0x45bcd8['val']());if(_0x4d2c33===void 0x0)_0x2305f2['unwatcher'](),_0x2305f2['currentOutputSnapshotRaw']=null,_0x2305f2['currentOutputSnapshotResolved']=null,_0x2305f2['onComplete']&&_0x2305f2['onComplete'](null,!0x1,_0x2305f2['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4d2c33,_0x2305f2['path']),_0x2305f2['status']=0x0;const _0x55bff0=$n(_0x19fc95['transactionQueueTree_'],_0x5c678f),_0x52c505=je(_0x55bff0)||[];_0x52c505['push'](_0x2305f2),gs(_0x55bff0,_0x52c505);let _0x46728c;typeof _0x4d2c33=='object'&&_0x4d2c33!==null&&Q(_0x4d2c33,'.priority')?(_0x46728c=Le(_0x4d2c33,'.priority'),f(Bt(_0x46728c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x46728c=(Vn(_0x19fc95['serverSyncTree_'],_0x5c678f)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x113efe=Xt(_0x19fc95),_0x177127=A(_0x4d2c33,_0x46728c),_0x30d2cd=fs(_0x177127,_0x45bcd8,_0x113efe);_0x2305f2['currentOutputSnapshotRaw']=_0x177127,_0x2305f2['currentOutputSnapshotResolved']=_0x30d2cd,_0x2305f2['currentWriteId']=zn(_0x19fc95);const _0x22a240=as(_0x19fc95['serverSyncTree_'],_0x5c678f,_0x30d2cd,_0x2305f2['currentWriteId'],_0x2305f2['applyLocally']);V(_0x19fc95['eventQueue_'],_0x5c678f,_0x22a240),jn(_0x19fc95,_0x19fc95['transactionQueueTree_']);}}function Es(_0x4264ed,_0x2eb82d,_0x481306){return Vn(_0x4264ed['serverSyncTree_'],_0x2eb82d,_0x481306)||g['EMPTY_NODE'];}function jn(_0x1bc22e,_0x26a56d=_0x1bc22e['transactionQueueTree_']){if(_0x26a56d||Kn(_0x1bc22e,_0x26a56d),je(_0x26a56d)){const _0x137795=da(_0x1bc22e,_0x26a56d);f(_0x137795['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x137795['every'](_0x11a128=>_0x11a128['status']===0x0)&&Dd(_0x1bc22e,Qt(_0x26a56d),_0x137795);}else na(_0x26a56d)&&Gn(_0x26a56d,_0x5844d6=>{jn(_0x1bc22e,_0x5844d6);});}function Dd(_0x385d9e,_0x399b51,_0xf59d9b){const _0x10612f=_0xf59d9b['map'](_0x4330e7=>_0x4330e7['currentWriteId']),_0x36514a=Es(_0x385d9e,_0x399b51,_0x10612f);let _0x1a9969=_0x36514a;const _0x5ced03=_0x36514a['hash']();for(let _0x1d0eb8=0x0;_0x1d0eb8<_0xf59d9b['length'];_0x1d0eb8++){const _0x10ec28=_0xf59d9b[_0x1d0eb8];f(_0x10ec28['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x10ec28['status']=0x1,_0x10ec28['retryCount']++;const _0x195e69=F(_0x399b51,_0x10ec28['path']);_0x1a9969=_0x1a9969['updateChild'](_0x195e69,_0x10ec28['currentOutputSnapshotRaw']);}const _0xf025ec=_0x1a9969['val'](!0x0),_0x196489=_0x399b51;_0x385d9e['server_']['put'](_0x196489['toString'](),_0xf025ec,_0x293d5a=>{gt(_0x385d9e,'transaction\x20put\x20response',{'path':_0x196489['toString'](),'status':_0x293d5a});let _0x3c913e=[];if(_0x293d5a==='ok'){const _0x99fd63=[];for(let _0x17438e=0x0;_0x17438e<_0xf59d9b['length'];_0x17438e++)_0xf59d9b[_0x17438e]['status']=0x2,_0x3c913e=_0x3c913e['concat'](_e(_0x385d9e['serverSyncTree_'],_0xf59d9b[_0x17438e]['currentWriteId'])),_0xf59d9b[_0x17438e]['onComplete']&&_0x99fd63['push'](()=>_0xf59d9b[_0x17438e]['onComplete'](null,!0x0,_0xf59d9b[_0x17438e]['currentOutputSnapshotResolved'])),_0xf59d9b[_0x17438e]['unwatcher']();Kn(_0x385d9e,$n(_0x385d9e['transactionQueueTree_'],_0x399b51)),jn(_0x385d9e,_0x385d9e['transactionQueueTree_']),V(_0x385d9e['eventQueue_'],_0x399b51,_0x3c913e);for(let _0x5ce138=0x0;_0x5ce138<_0x99fd63['length'];_0x5ce138++)ft(_0x99fd63[_0x5ce138]);}else{if(_0x293d5a==='datastale'){for(let _0x3f88f8=0x0;_0x3f88f8<_0xf59d9b['length'];_0x3f88f8++)_0xf59d9b[_0x3f88f8]['status']===0x3?_0xf59d9b[_0x3f88f8]['status']=0x4:_0xf59d9b[_0x3f88f8]['status']=0x0;}else{U('transaction\x20at\x20'+_0x196489['toString']()+'\x20failed:\x20'+_0x293d5a);for(let _0x353808=0x0;_0x353808<_0xf59d9b['length'];_0x353808++)_0xf59d9b[_0x353808]['status']=0x4,_0xf59d9b[_0x353808]['abortReason']=_0x293d5a;}ct(_0x385d9e,_0x399b51);}},_0x5ced03);}function ct(_0x2609fc,_0x2059bd){const _0x252535=ua(_0x2609fc,_0x2059bd),_0x50c982=Qt(_0x252535),_0xdbac65=da(_0x2609fc,_0x252535);return Md(_0x2609fc,_0xdbac65,_0x50c982),_0x50c982;}function Md(_0x359034,_0x32f2fe,_0x1bc9e8){if(_0x32f2fe['length']===0x0)return;const _0x5cc232=[];let _0x104f32=[];const _0xfb805e=_0x32f2fe['filter'](_0x4f50e4=>_0x4f50e4['status']===0x0)['map'](_0x1c1796=>_0x1c1796['currentWriteId']);for(let _0x4004d7=0x0;_0x4004d7<_0x32f2fe['length'];_0x4004d7++){const _0x361c62=_0x32f2fe[_0x4004d7],_0x3e31f9=F(_0x1bc9e8,_0x361c62['path']);let _0x3493cb=!0x1,_0x2ea8c5;if(f(_0x3e31f9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x361c62['status']===0x4)_0x3493cb=!0x0,_0x2ea8c5=_0x361c62['abortReason'],_0x104f32=_0x104f32['concat'](_e(_0x359034['serverSyncTree_'],_0x361c62['currentWriteId'],!0x0));else{if(_0x361c62['status']===0x0){if(_0x361c62['retryCount']>=yd)_0x3493cb=!0x0,_0x2ea8c5='maxretry',_0x104f32=_0x104f32['concat'](_e(_0x359034['serverSyncTree_'],_0x361c62['currentWriteId'],!0x0));else{const _0x27f714=Es(_0x359034,_0x361c62['path'],_0xfb805e);_0x361c62['currentInputSnapshot']=_0x27f714;const _0x243aba=_0x32f2fe[_0x4004d7]['update'](_0x27f714['val']());if(_0x243aba!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x243aba,_0x361c62['path']);let _0x7cecbd=A(_0x243aba);typeof _0x243aba=='object'&&_0x243aba!=null&&Q(_0x243aba,'.priority')||(_0x7cecbd=_0x7cecbd['updatePriority'](_0x27f714['getPriority']()));const _0x1b0a48=_0x361c62['currentWriteId'],_0x227093=Xt(_0x359034),_0x40d68d=fs(_0x7cecbd,_0x27f714,_0x227093);_0x361c62['currentOutputSnapshotRaw']=_0x7cecbd,_0x361c62['currentOutputSnapshotResolved']=_0x40d68d,_0x361c62['currentWriteId']=zn(_0x359034),_0xfb805e['splice'](_0xfb805e['indexOf'](_0x1b0a48),0x1),_0x104f32=_0x104f32['concat'](as(_0x359034['serverSyncTree_'],_0x361c62['path'],_0x40d68d,_0x361c62['currentWriteId'],_0x361c62['applyLocally'])),_0x104f32=_0x104f32['concat'](_e(_0x359034['serverSyncTree_'],_0x1b0a48,!0x0));}else _0x3493cb=!0x0,_0x2ea8c5='nodata',_0x104f32=_0x104f32['concat'](_e(_0x359034['serverSyncTree_'],_0x361c62['currentWriteId'],!0x0));}}}V(_0x359034['eventQueue_'],_0x1bc9e8,_0x104f32),_0x104f32=[],_0x3493cb&&(_0x32f2fe[_0x4004d7]['status']=0x2,function(_0x530f7f){setTimeout(_0x530f7f,Math['floor'](0x0));}(_0x32f2fe[_0x4004d7]['unwatcher']),_0x32f2fe[_0x4004d7]['onComplete']&&(_0x2ea8c5==='nodata'?_0x5cc232['push'](()=>_0x32f2fe[_0x4004d7]['onComplete'](null,!0x1,_0x32f2fe[_0x4004d7]['currentInputSnapshot'])):_0x5cc232['push'](()=>_0x32f2fe[_0x4004d7]['onComplete'](new Error(_0x2ea8c5),!0x1,null))));}Kn(_0x359034,_0x359034['transactionQueueTree_']);for(let _0x4c97b2=0x0;_0x4c97b2<_0x5cc232['length'];_0x4c97b2++)ft(_0x5cc232[_0x4c97b2]);jn(_0x359034,_0x359034['transactionQueueTree_']);}function ua(_0x265539,_0x13559f){let _0x437ae3,_0x9911ec=_0x265539['transactionQueueTree_'];for(_0x437ae3=y(_0x13559f);_0x437ae3!==null&&je(_0x9911ec)===void 0x0;)_0x9911ec=$n(_0x9911ec,_0x437ae3),_0x13559f=S(_0x13559f),_0x437ae3=y(_0x13559f);return _0x9911ec;}function da(_0x42b950,_0x1ed06b){const _0x1b5332=[];return fa(_0x42b950,_0x1ed06b,_0x1b5332),_0x1b5332['sort']((_0x829476,_0x2c1b32)=>_0x829476['order']-_0x2c1b32['order']),_0x1b5332;}function fa(_0x4b2189,_0x3089cc,_0x1ffe84){const _0x3cc110=je(_0x3089cc);if(_0x3cc110){for(let _0x4ab38d=0x0;_0x4ab38d<_0x3cc110['length'];_0x4ab38d++)_0x1ffe84['push'](_0x3cc110[_0x4ab38d]);}Gn(_0x3089cc,_0x3cb393=>{fa(_0x4b2189,_0x3cb393,_0x1ffe84);});}function Kn(_0x2b495e,_0x1c5192){const _0xedd48d=je(_0x1c5192);if(_0xedd48d){let _0x4e05e5=0x0;for(let _0x365915=0x0;_0x365915<_0xedd48d['length'];_0x365915++)_0xedd48d[_0x365915]['status']!==0x2&&(_0xedd48d[_0x4e05e5]=_0xedd48d[_0x365915],_0x4e05e5++);_0xedd48d['length']=_0x4e05e5,gs(_0x1c5192,_0xedd48d['length']>0x0?_0xedd48d:void 0x0);}Gn(_0x1c5192,_0x56aa8=>{Kn(_0x2b495e,_0x56aa8);});}function Is(_0x403348,_0x4efe20){const _0x452662=Qt(ua(_0x403348,_0x4efe20)),_0x42eb5c=$n(_0x403348['transactionQueueTree_'],_0x4efe20);return ad(_0x42eb5c,_0x2d21eb=>{di(_0x403348,_0x2d21eb);}),di(_0x403348,_0x42eb5c),ia(_0x42eb5c,_0x5c935b=>{di(_0x403348,_0x5c935b);}),_0x452662;}function di(_0x3e8aa8,_0x17fd82){const _0x280a64=je(_0x17fd82);if(_0x280a64){const _0x28d44c=[];let _0x3049cd=[],_0x5f36d8=-0x1;for(let _0x1880ce=0x0;_0x1880ce<_0x280a64['length'];_0x1880ce++)_0x280a64[_0x1880ce]['status']===0x3||(_0x280a64[_0x1880ce]['status']===0x1?(f(_0x5f36d8===_0x1880ce-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5f36d8=_0x1880ce,_0x280a64[_0x1880ce]['status']=0x3,_0x280a64[_0x1880ce]['abortReason']='set'):(f(_0x280a64[_0x1880ce]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x280a64[_0x1880ce]['unwatcher'](),_0x3049cd=_0x3049cd['concat'](_e(_0x3e8aa8['serverSyncTree_'],_0x280a64[_0x1880ce]['currentWriteId'],!0x0)),_0x280a64[_0x1880ce]['onComplete']&&_0x28d44c['push'](_0x280a64[_0x1880ce]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5f36d8===-0x1?gs(_0x17fd82,void 0x0):_0x280a64['length']=_0x5f36d8+0x1,V(_0x3e8aa8['eventQueue_'],Qt(_0x17fd82),_0x3049cd);for(let _0x4408f7=0x0;_0x4408f7<_0x28d44c['length'];_0x4408f7++)ft(_0x28d44c[_0x4408f7]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x39d46a){let _0x2b0cb5='';const _0x1704c5=_0x39d46a['split']('/');for(let _0x176176=0x0;_0x176176<_0x1704c5['length'];_0x176176++)if(_0x1704c5[_0x176176]['length']>0x0){let _0x558f3d=_0x1704c5[_0x176176];try{_0x558f3d=decodeURIComponent(_0x558f3d['replace'](/\+/g,'\x20'));}catch{}_0x2b0cb5+='/'+_0x558f3d;}return _0x2b0cb5;}function xd(_0x1f5e45){const _0x1e7123={};_0x1f5e45['charAt'](0x0)==='?'&&(_0x1f5e45=_0x1f5e45['substring'](0x1));for(const _0x499eef of _0x1f5e45['split']('&')){if(_0x499eef['length']===0x0)continue;const _0x383c76=_0x499eef['split']('=');_0x383c76['length']===0x2?_0x1e7123[decodeURIComponent(_0x383c76[0x0])]=decodeURIComponent(_0x383c76[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x499eef+'\x27\x20in\x20query\x20\x27'+_0x1f5e45+'\x27');}return _0x1e7123;}const vr=function(_0x58bc64,_0x289e38){const _0x1e2db7=Fd(_0x58bc64),_0xecb3e3=_0x1e2db7['namespace'];_0x1e2db7['domain']==='firebase.com'&&ae(_0x1e2db7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xecb3e3||_0xecb3e3==='undefined')&&_0x1e2db7['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1e2db7['secure']||$l();const _0x1615fa=_0x1e2db7['scheme']==='ws'||_0x1e2db7['scheme']==='wss';return{'repoInfo':new yo(_0x1e2db7['host'],_0x1e2db7['secure'],_0xecb3e3,_0x1615fa,_0x289e38,'',_0xecb3e3!==_0x1e2db7['subdomain']),'path':new C(_0x1e2db7['pathString'])};},Fd=function(_0x107e19){let _0x1209ee='',_0x4d271c='',_0x482495='',_0x555c1e='',_0x161cc6='',_0x24ae10=!0x0,_0x4345a3='https',_0x1971dc=0x1bb;if(typeof _0x107e19=='string'){let _0x49cb35=_0x107e19['indexOf']('//');_0x49cb35>=0x0&&(_0x4345a3=_0x107e19['substring'](0x0,_0x49cb35-0x1),_0x107e19=_0x107e19['substring'](_0x49cb35+0x2));let _0xae00c8=_0x107e19['indexOf']('/');_0xae00c8===-0x1&&(_0xae00c8=_0x107e19['length']);let _0x2a00eb=_0x107e19['indexOf']('?');_0x2a00eb===-0x1&&(_0x2a00eb=_0x107e19['length']),_0x1209ee=_0x107e19['substring'](0x0,Math['min'](_0xae00c8,_0x2a00eb)),_0xae00c8<_0x2a00eb&&(_0x555c1e=Ld(_0x107e19['substring'](_0xae00c8,_0x2a00eb)));const _0x1b65ca=xd(_0x107e19['substring'](Math['min'](_0x107e19['length'],_0x2a00eb)));_0x49cb35=_0x1209ee['indexOf'](':'),_0x49cb35>=0x0?(_0x24ae10=_0x4345a3==='https'||_0x4345a3==='wss',_0x1971dc=parseInt(_0x1209ee['substring'](_0x49cb35+0x1),0xa)):_0x49cb35=_0x1209ee['length'];const _0x5752b7=_0x1209ee['slice'](0x0,_0x49cb35);if(_0x5752b7['toLowerCase']()==='localhost')_0x4d271c='localhost';else{if(_0x5752b7['split']('.')['length']<=0x2)_0x4d271c=_0x5752b7;else{const _0x3dbc0b=_0x1209ee['indexOf']('.');_0x482495=_0x1209ee['substring'](0x0,_0x3dbc0b)['toLowerCase'](),_0x4d271c=_0x1209ee['substring'](_0x3dbc0b+0x1),_0x161cc6=_0x482495;}}'ns'in _0x1b65ca&&(_0x161cc6=_0x1b65ca['ns']);}return{'host':_0x1209ee,'port':_0x1971dc,'domain':_0x4d271c,'subdomain':_0x482495,'secure':_0x24ae10,'scheme':_0x4345a3,'pathString':_0x555c1e,'namespace':_0x161cc6};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x2421ad=0x0;const _0x1f23c1=[];return function(_0x235ea3){const _0x25ab65=_0x235ea3===_0x2421ad;_0x2421ad=_0x235ea3;let _0x12d5ec;const _0x37ef49=new Array(0x8);for(_0x12d5ec=0x7;_0x12d5ec>=0x0;_0x12d5ec--)_0x37ef49[_0x12d5ec]=Er['charAt'](_0x235ea3%0x40),_0x235ea3=Math['floor'](_0x235ea3/0x40);f(_0x235ea3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x437f50=_0x37ef49['join']('');if(_0x25ab65){for(_0x12d5ec=0xb;_0x12d5ec>=0x0&&_0x1f23c1[_0x12d5ec]===0x3f;_0x12d5ec--)_0x1f23c1[_0x12d5ec]=0x0;_0x1f23c1[_0x12d5ec]++;}else{for(_0x12d5ec=0x0;_0x12d5ec<0xc;_0x12d5ec++)_0x1f23c1[_0x12d5ec]=Math['floor'](Math['random']()*0x40);}for(_0x12d5ec=0x0;_0x12d5ec<0xc;_0x12d5ec++)_0x437f50+=Er['charAt'](_0x1f23c1[_0x12d5ec]);return f(_0x437f50['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x437f50;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1409e6,_0x20ace1,_0xd0bdb9,_0x18f3f9){this['eventType']=_0x1409e6,this['eventRegistration']=_0x20ace1,this['snapshot']=_0xd0bdb9,this['prevName']=_0x18f3f9;}['getPath'](){const _0x1fe2ff=this['snapshot']['ref'];return this['eventType']==='value'?_0x1fe2ff['_path']:_0x1fe2ff['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x5bb6e2,_0x5baa7e,_0x2a7081){this['eventRegistration']=_0x5bb6e2,this['error']=_0x5baa7e,this['path']=_0x2a7081;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x329804,_0x218d8c){this['snapshotCallback']=_0x329804,this['cancelCallback']=_0x218d8c;}['onValue'](_0x5b1e44,_0x38c274){this['snapshotCallback']['call'](null,_0x5b1e44,_0x38c274);}['onCancel'](_0x52a800){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x52a800);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1b922c){return this['snapshotCallback']===_0x1b922c['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1b922c['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1b922c['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x1d6ff3,_0x5e8137){this['_repo']=_0x1d6ff3,this['_path']=_0x5e8137;}['cancel'](){const _0x5d725f=new H();return bd(this['_repo'],this['_path'],_0x5d725f['wrapCallback'](()=>{})),_0x5d725f['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x25a65e=new H();return yr(this['_repo'],this['_path'],null,_0x25a65e['wrapCallback'](()=>{})),_0x25a65e['promise'];}['set'](_0x500908){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x500908,this['_path'],!0x1);const _0x8ff0df=new H();return yr(this['_repo'],this['_path'],_0x500908,_0x8ff0df['wrapCallback'](()=>{})),_0x8ff0df['promise'];}['setWithPriority'](_0x1e2b9f,_0x36b891){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x1e2b9f,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x36b891);const _0x245676=new H();return Rd(this['_repo'],this['_path'],_0x1e2b9f,_0x36b891,_0x245676['wrapCallback'](()=>{})),_0x245676['promise'];}['update'](_0x12b52f){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x12b52f,this['_path']);const _0x3dc65f=new H();return Ad(this['_repo'],this['_path'],_0x12b52f,_0x3dc65f['wrapCallback'](()=>{})),_0x3dc65f['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x102895,_0x42c089,_0x1b4b7d,_0x39fa5c){this['_repo']=_0x102895,this['_path']=_0x42c089,this['_queryParams']=_0x1b4b7d,this['_orderByCalled']=_0x39fa5c;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x29d3d6=sr(this['_queryParams']),_0x4d7f99=$i(_0x29d3d6);return _0x4d7f99==='{}'?'default':_0x4d7f99;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x80cf30){if(_0x80cf30=P(_0x80cf30),!(_0x80cf30 instanceof Ae))return!0x1;const _0x492c47=this['_repo']===_0x80cf30['_repo'],_0x7ae859=Ki(this['_path'],_0x80cf30['_path']),_0x52b92d=this['_queryIdentifier']===_0x80cf30['_queryIdentifier'];return _0x492c47&&_0x7ae859&&_0x52b92d;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x57988f,_0x2dee75){if(_0x57988f['_orderByCalled']===!0x0)throw new Error(_0x2dee75+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x31c3c5){let _0x42914b=null,_0x17855f=null;if(_0x31c3c5['hasStart']()&&(_0x42914b=_0x31c3c5['getIndexStartValue']()),_0x31c3c5['hasEnd']()&&(_0x17855f=_0x31c3c5['getIndexEndValue']()),_0x31c3c5['getIndex']()===ve){const _0x2bb545='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x294c61='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x31c3c5['hasStart']()){if(_0x31c3c5['getIndexStartName']()!==We)throw new Error(_0x2bb545);if(typeof _0x42914b!='string')throw new Error(_0x294c61);}if(_0x31c3c5['hasEnd']()){if(_0x31c3c5['getIndexEndName']()!==we)throw new Error(_0x2bb545);if(typeof _0x17855f!='string')throw new Error(_0x294c61);}}else{if(_0x31c3c5['getIndex']()===R){if(_0x42914b!=null&&!Bt(_0x42914b)||_0x17855f!=null&&!Bt(_0x17855f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x31c3c5['getIndex']()instanceof Ji||_0x31c3c5['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x42914b!=null&&typeof _0x42914b=='object'||_0x17855f!=null&&typeof _0x17855f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x533268){if(_0x533268['hasStart']()&&_0x533268['hasEnd']()&&_0x533268['hasLimit']()&&!_0x533268['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x186c07,_0x168927){super(_0x186c07,_0x168927,new Zi(),!0x1);}get['parent'](){const _0xe89df5=Ro(this['_path']);return _0xe89df5===null?null:new ee(this['_repo'],_0xe89df5);}get['root'](){let _0x1ddb93=this;for(;_0x1ddb93['parent']!==null;)_0x1ddb93=_0x1ddb93['parent'];return _0x1ddb93;}}class lt{constructor(_0x1a3c6d,_0x436623,_0x84d544){this['_node']=_0x1a3c6d,this['ref']=_0x436623,this['_index']=_0x84d544;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x468299){const _0x2c14e3=new C(_0x468299),_0x4b42a9=Vt(this['ref'],_0x468299);return new lt(this['_node']['getChild'](_0x2c14e3),_0x4b42a9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x399db9){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x444b26,_0x1cb17c)=>_0x399db9(new lt(_0x1cb17c,Vt(this['ref'],_0x444b26),R)));}['hasChild'](_0x380cb2){const _0x24bad=new C(_0x380cb2);return!this['_node']['getChild'](_0x24bad)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x194361,_0x36a5df){return _0x194361=P(_0x194361),_0x194361['_checkNotDeleted']('ref'),_0x36a5df!==void 0x0?Vt(_0x194361['_root'],_0x36a5df):_0x194361['_root'];}function Vt(_0x57831e,_0x5f1f2f){return _0x57831e=P(_0x57831e),y(_0x57831e['_path'])===null?pd('child','path',_0x5f1f2f):ys('child','path',_0x5f1f2f),new ee(_0x57831e['_repo'],k(_0x57831e['_path'],_0x5f1f2f));}function v_(_0x1472d4){return _0x1472d4=P(_0x1472d4),new Vd(_0x1472d4['_repo'],_0x1472d4['_path']);}function E_(_0x539f6c,_0x467c4b){_0x539f6c=P(_0x539f6c),Me('push',_0x539f6c['_path']),He('push',_0x467c4b,_0x539f6c['_path'],!0x0);const _0x3c4df7=la(_0x539f6c['_repo']),_0x136262=Ud(_0x3c4df7),_0x59f85d=Vt(_0x539f6c,_0x136262),_0x10e96e=Vt(_0x539f6c,_0x136262);let _0x5ce5bd;return _0x467c4b!=null?_0x5ce5bd=Hd(_0x10e96e,_0x467c4b)['then'](()=>_0x10e96e):_0x5ce5bd=Promise['resolve'](_0x10e96e),_0x59f85d['then']=_0x5ce5bd['then']['bind'](_0x5ce5bd),_0x59f85d['catch']=_0x5ce5bd['then']['bind'](_0x5ce5bd,void 0x0),_0x59f85d;}function Hd(_0x543e26,_0x2cb855){_0x543e26=P(_0x543e26),Me('set',_0x543e26['_path']),He('set',_0x2cb855,_0x543e26['_path'],!0x1);const _0xfd972b=new H();return Cd(_0x543e26['_repo'],_0x543e26['_path'],_0x2cb855,null,_0xfd972b['wrapCallback'](()=>{})),_0xfd972b['promise'];}function I_(_0x3c6ea2,_0x2f3052){ra('update',_0x2f3052,_0x3c6ea2['_path']);const _0x3df98d=new H();return Td(_0x3c6ea2['_repo'],_0x3c6ea2['_path'],_0x2f3052,_0x3df98d['wrapCallback'](()=>{})),_0x3df98d['promise'];}function w_(_0x210946){_0x210946=P(_0x210946);const _0x3a5885=new pa(()=>{}),_0x518699=new Qn(_0x3a5885);return wd(_0x210946['_repo'],_0x210946,_0x518699)['then'](_0x4fef8b=>new lt(_0x4fef8b,new ee(_0x210946['_repo'],_0x210946['_path']),_0x210946['_queryParams']['getIndex']()));}class Qn{constructor(_0x275e46){this['callbackContext']=_0x275e46;}['respondsTo'](_0x23867b){return _0x23867b==='value';}['createEvent'](_0x4e5c74,_0x11b93b){const _0x35c800=_0x11b93b['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4e5c74['snapshotNode'],new ee(_0x11b93b['_repo'],_0x11b93b['_path']),_0x35c800));}['getEventRunner'](_0x477c7e){return _0x477c7e['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x477c7e['error']):()=>this['callbackContext']['onValue'](_0x477c7e['snapshot'],null);}['createCancelEvent'](_0x16b532,_0x16da96){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x16b532,_0x16da96):null;}['matches'](_0x2772f9){return _0x2772f9 instanceof Qn?!_0x2772f9['callbackContext']||!this['callbackContext']?!0x0:_0x2772f9['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x471102,_0x5d50f0,_0xaf7664,_0x22650d,_0x21ddfe){const _0x44abdd=new pa(_0xaf7664,void 0x0),_0x16be9d=new Qn(_0x44abdd);return kd(_0x471102['_repo'],_0x471102,_0x16be9d),()=>Pd(_0x471102['_repo'],_0x471102,_0x16be9d);}function Gd(_0x4e39be,_0x496221,_0x4e8bd0,_0x3213c0){return $d(_0x4e39be,'value',_0x496221);}class mt{}class ma extends mt{constructor(_0x24a6e8,_0x2cb050){super(),this['_value']=_0x24a6e8,this['_key']=_0x2cb050,this['type']='endAt';}['_apply'](_0x4fc7e0){He('endAt',this['_value'],_0x4fc7e0['_path'],!0x0);const _0xd878ed=Jh(_0x4fc7e0['_queryParams'],this['_value'],this['_key']);if(ga(_0xd878ed),Yn(_0xd878ed),_0x4fc7e0['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x4fc7e0['_repo'],_0x4fc7e0['_path'],_0xd878ed,_0x4fc7e0['_orderByCalled']);}}function C_(_0x3b55ab,_0x588d1e){return new ma(_0x3b55ab,_0x588d1e);}class ya extends mt{constructor(_0x4d62ce,_0x3a2401){super(),this['_value']=_0x4d62ce,this['_key']=_0x3a2401,this['type']='startAt';}['_apply'](_0x158b06){He('startAt',this['_value'],_0x158b06['_path'],!0x0);const _0x5e0d67=Qh(_0x158b06['_queryParams'],this['_value'],this['_key']);if(ga(_0x5e0d67),Yn(_0x5e0d67),_0x158b06['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x158b06['_repo'],_0x158b06['_path'],_0x5e0d67,_0x158b06['_orderByCalled']);}}function T_(_0x27b7fa=null,_0xd09d9f){return new ya(_0x27b7fa,_0xd09d9f);}class qd extends mt{constructor(_0x4e48fe){super(),this['_limit']=_0x4e48fe,this['type']='limitToFirst';}['_apply'](_0x258b99){if(_0x258b99['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x258b99['_repo'],_0x258b99['_path'],Yh(_0x258b99['_queryParams'],this['_limit']),_0x258b99['_orderByCalled']);}}function S_(_0x2a1a23){if(Math['floor'](_0x2a1a23)!==_0x2a1a23||_0x2a1a23<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x2a1a23);}class zd extends mt{constructor(_0x3c2fc6){super(),this['_path']=_0x3c2fc6,this['type']='orderByChild';}['_apply'](_0x1a2674){_a(_0x1a2674,'orderByChild');const _0x4be29e=new C(this['_path']);if(v(_0x4be29e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x3d604b=new Ji(_0x4be29e),_0x5822a4=xo(_0x1a2674['_queryParams'],_0x3d604b);return Yn(_0x5822a4),new Ae(_0x1a2674['_repo'],_0x1a2674['_path'],_0x5822a4,!0x0);}}function b_(_0x14b642){if(_0x14b642==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x14b642==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x14b642==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x14b642),new zd(_0x14b642);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1c8414){_a(_0x1c8414,'orderByKey');const _0x3282cc=xo(_0x1c8414['_queryParams'],ve);return Yn(_0x3282cc),new Ae(_0x1c8414['_repo'],_0x1c8414['_path'],_0x3282cc,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x24fd96,_0x1209ef){super(),this['_value']=_0x24fd96,this['_key']=_0x1209ef,this['type']='equalTo';}['_apply'](_0x22d8c2){if(He('equalTo',this['_value'],_0x22d8c2['_path'],!0x1),_0x22d8c2['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x22d8c2['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x22d8c2));}}function A_(_0x11b11c,_0x2ee444){return new Kd(_0x11b11c,_0x2ee444);}function k_(_0x1707cc,..._0x282084){let _0x48af24=P(_0x1707cc);for(const _0x923ff6 of _0x282084)_0x48af24=_0x923ff6['_apply'](_0x48af24);return _0x48af24;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x1a78a8,_0x18be7b,_0x19dd61,_0x4034cd){const _0x3493e2=_0x18be7b['lastIndexOf'](':'),_0x42ac31=_0x18be7b['substring'](0x0,_0x3493e2),_0x379408=qt(_0x42ac31);_0x1a78a8['repoInfo_']=new yo(_0x18be7b,_0x379408,_0x1a78a8['repoInfo_']['namespace'],_0x1a78a8['repoInfo_']['webSocketOnly'],_0x1a78a8['repoInfo_']['nodeAdmin'],_0x1a78a8['repoInfo_']['persistenceKey'],_0x1a78a8['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x19dd61),_0x4034cd&&(_0x1a78a8['authTokenProvider_']=_0x4034cd);}function Xd(_0x529d8d,_0x31cb7f,_0x4bbbcc,_0x530097,_0x34fdbe){let _0x25100d=_0x530097||_0x529d8d['options']['databaseURL'];_0x25100d===void 0x0&&(_0x529d8d['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x529d8d['options']['projectId']),_0x25100d=_0x529d8d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x39f235=vr(_0x25100d,_0x34fdbe),_0x104985=_0x39f235['repoInfo'],_0x255ede;typeof process<'u'&&Bs&&(_0x255ede=Bs[Yd]),_0x255ede?(_0x25100d='http://'+_0x255ede+'?ns='+_0x104985['namespace'],_0x39f235=vr(_0x25100d,_0x34fdbe),_0x104985=_0x39f235['repoInfo']):_0x39f235['repoInfo']['secure'];const _0x491928=new eh(_0x529d8d['name'],_0x529d8d['options'],_0x31cb7f);_d('Invalid\x20Firebase\x20Database\x20URL',_0x39f235),v(_0x39f235['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x40076c=ef(_0x104985,_0x529d8d,_0x491928,new Zl(_0x529d8d,_0x4bbbcc));return new tf(_0x40076c,_0x529d8d);}function Zd(_0x330257,_0x522949){const _0xa9a96b=Di[_0x522949];(!_0xa9a96b||_0xa9a96b[_0x330257['key']]!==_0x330257)&&ae('Database\x20'+_0x522949+'('+_0x330257['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x330257),delete _0xa9a96b[_0x330257['key']];}function ef(_0x3de189,_0x45bc62,_0x52d072,_0x37f2a6){let _0x45e783=Di[_0x45bc62['name']];_0x45e783||(_0x45e783={},Di[_0x45bc62['name']]=_0x45e783);let _0x248b37=_0x45e783[_0x3de189['toURLString']()];return _0x248b37&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x248b37=new vd(_0x3de189,Qd,_0x52d072,_0x37f2a6),_0x45e783[_0x3de189['toURLString']()]=_0x248b37,_0x248b37;}class tf{constructor(_0x430696,_0x2ea90b){this['_repoInternal']=_0x430696,this['app']=_0x2ea90b,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5d352c){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5d352c+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x428f7d=Zr(),_0x45931a){const _0x3cbd9a=Hi(_0x428f7d,'database')['getImmediate']({'identifier':_0x45931a});if(!_0x3cbd9a['_instanceStarted']){const _0x417bd4=hc('database');_0x417bd4&&nf(_0x3cbd9a,..._0x417bd4);}return _0x3cbd9a;}function nf(_0x4dd987,_0x5d602a,_0x521351,_0xd373ec={}){_0x4dd987=P(_0x4dd987),_0x4dd987['_checkNotDeleted']('useEmulator');const _0x44a7e5=_0x5d602a+':'+_0x521351,_0x1d2efb=_0x4dd987['_repoInternal'];if(_0x4dd987['_instanceStarted']){if(_0x44a7e5===_0x4dd987['_repoInternal']['repoInfo_']['host']&&xe(_0xd373ec,_0x1d2efb['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5eb1bf;if(_0x1d2efb['repoInfo_']['nodeAdmin'])_0xd373ec['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5eb1bf=new an(an['OWNER']);else{if(_0xd373ec['mockUserToken']){const _0x396d0c=typeof _0xd373ec['mockUserToken']=='string'?_0xd373ec['mockUserToken']:uc(_0xd373ec['mockUserToken'],_0x4dd987['app']['options']['projectId']);_0x5eb1bf=new an(_0x396d0c);}}qt(_0x5d602a)&&Qr(_0x5d602a),Jd(_0x1d2efb,_0x44a7e5,_0xd373ec,_0x5eb1bf);}function N_(_0x5bf639){_0x5bf639=P(_0x5bf639),_0x5bf639['_checkNotDeleted']('goOffline'),ha(_0x5bf639['_repo']);}function O_(_0x521ead){_0x521ead=P(_0x521ead),_0x521ead['_checkNotDeleted']('goOnline'),Nd(_0x521ead['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x5a19be){Ul(dt),st(new Fe('database',(_0x5cfe91,{instanceIdentifier:_0x183547})=>{const _0x2bb476=_0x5cfe91['getProvider']('app')['getImmediate'](),_0x15efa3=_0x5cfe91['getProvider']('auth-internal'),_0x21d4f9=_0x5cfe91['getProvider']('app-check-internal');return Xd(_0x2bb476,_0x15efa3,_0x21d4f9,_0x183547);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x5a19be),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x278493,_0x2deb3f){this['committed']=_0x278493,this['snapshot']=_0x2deb3f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x3231b5,_0x90cdb7,_0x2b845a){if(_0x3231b5=P(_0x3231b5),Me('Reference.transaction',_0x3231b5['_path']),_0x3231b5['key']==='.length'||_0x3231b5['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3231b5['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3ebbf0=!0x0,_0x3984cc=new H(),_0x1a557a=(_0x2bc95b,_0x2ad45f,_0x18761a)=>{let _0x4a3f34=null;_0x2bc95b?_0x3984cc['reject'](_0x2bc95b):(_0x4a3f34=new lt(_0x18761a,new ee(_0x3231b5['_repo'],_0x3231b5['_path']),R),_0x3984cc['resolve'](new of(_0x2ad45f,_0x4a3f34)));},_0x18f249=Gd(_0x3231b5,()=>{});return Od(_0x3231b5['_repo'],_0x3231b5['_path'],_0x90cdb7,_0x1a557a,_0x18f249,_0x3ebbf0),_0x3984cc['promise'];}se['prototype']['simpleListen']=function(_0x535b14,_0x388818){this['sendRequest']('q',{'p':_0x535b14},_0x388818);},se['prototype']['echo']=function(_0x377a10,_0x330f7b){this['sendRequest']('echo',{'d':_0x377a10},_0x330f7b);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x240def,..._0x427a57){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x240def,..._0x427a57);}function cn(_0x582d47,..._0x21d511){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x582d47,..._0x21d511);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x28ae0f,..._0x20f20d){throw ws(_0x28ae0f,..._0x20f20d);}function X(_0x122d22,..._0x829747){return ws(_0x122d22,..._0x829747);}function Ia(_0x31e67a,_0x4d01ca,_0x2e2f91){const _0x3b9041={...af(),[_0x4d01ca]:_0x2e2f91};return new Gt('auth','Firebase',_0x3b9041)['create'](_0x4d01ca,{'appName':_0x31e67a['name']});}function re(_0x31c946){return Ia(_0x31c946,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x18c833,..._0x4e7d38){if(typeof _0x18c833!='string'){const _0x3f9257=_0x4e7d38[0x0],_0x567eef=[..._0x4e7d38['slice'](0x1)];return _0x567eef[0x0]&&(_0x567eef[0x0]['appName']=_0x18c833['name']),_0x18c833['_errorFactory']['create'](_0x3f9257,..._0x567eef);}return Ea['create'](_0x18c833,..._0x4e7d38);}function m(_0x573694,_0x5cf9ae,..._0x52e3c3){if(!_0x573694)throw ws(_0x5cf9ae,..._0x52e3c3);}function ne(_0x3b8cb4){const _0x5eda51='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3b8cb4;throw cn(_0x5eda51),new Error(_0x5eda51);}function ce(_0x124568,_0x5e76c4){_0x124568||ne(_0x5e76c4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x30e149;return typeof self<'u'&&((_0x30e149=self['location'])==null?void 0x0:_0x30e149['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xcf95c5;return typeof self<'u'&&((_0xcf95c5=self['location'])==null?void 0x0:_0xcf95c5['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5432e6=navigator;return _0x5432e6['languages']&&_0x5432e6['languages'][0x0]||_0x5432e6['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x38cff5,_0x41f154){this['shortDelay']=_0x38cff5,this['longDelay']=_0x41f154,ce(_0x41f154>_0x38cff5,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3ecb8a,_0x7f546f){ce(_0x3ecb8a['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x367a50}=_0x3ecb8a['emulator'];return _0x7f546f?''+_0x367a50+(_0x7f546f['startsWith']('/')?_0x7f546f['slice'](0x1):_0x7f546f):_0x367a50;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x28fde1,_0x3de8bf,_0x6710f2){this['fetchImpl']=_0x28fde1,_0x3de8bf&&(this['headersImpl']=_0x3de8bf),_0x6710f2&&(this['responseImpl']=_0x6710f2);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x2a855a,_0x13fb73){return _0x2a855a['tenantId']&&!_0x13fb73['tenantId']?{..._0x13fb73,'tenantId':_0x2a855a['tenantId']}:_0x13fb73;}async function Pe(_0x37795d,_0x560955,_0x41b819,_0x3c1c6c,_0x44b0c5={}){return Ca(_0x37795d,_0x44b0c5,async()=>{let _0x52cda9={},_0x12ef99={};_0x3c1c6c&&(_0x560955==='GET'?_0x12ef99=_0x3c1c6c:_0x52cda9={'body':JSON['stringify'](_0x3c1c6c)});const _0x235f00=ut({..._0x12ef99,'key':_0x37795d['config']['apiKey']})['slice'](0x1),_0x5d9818=await _0x37795d['_getAdditionalHeaders']();_0x5d9818['Content-Type']='application/json',_0x37795d['languageCode']&&(_0x5d9818['X-Firebase-Locale']=_0x37795d['languageCode']);const _0xe88e02={'method':_0x560955,'headers':_0x5d9818,..._0x52cda9};return dc()||(_0xe88e02['referrerPolicy']='strict-origin-when-cross-origin'),_0x37795d['emulatorConfig']&&qt(_0x37795d['emulatorConfig']['host'])&&(_0xe88e02['credentials']='include'),wa['fetch']()(await Ta(_0x37795d,_0x37795d['config']['apiHost'],_0x41b819,_0x235f00),_0xe88e02);});}async function Ca(_0x2c89e2,_0x438345,_0x242f1f){_0x2c89e2['_canInitEmulator']=!0x1;const _0x432c1e={...df,..._0x438345};try{const _0x1d5206=new gf(_0x2c89e2),_0x29cf4f=await Promise['race']([_0x242f1f(),_0x1d5206['promise']]);_0x1d5206['clearNetworkTimeout']();const _0x5a61af=await _0x29cf4f['json']();if('needConfirmation'in _0x5a61af)throw on(_0x2c89e2,'account-exists-with-different-credential',_0x5a61af);if(_0x29cf4f['ok']&&!('errorMessage'in _0x5a61af))return _0x5a61af;{const _0x30235=_0x29cf4f['ok']?_0x5a61af['errorMessage']:_0x5a61af['error']['message'],[_0x4ae832,_0x51fb39]=_0x30235['split']('\x20:\x20');if(_0x4ae832==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2c89e2,'credential-already-in-use',_0x5a61af);if(_0x4ae832==='EMAIL_EXISTS')throw on(_0x2c89e2,'email-already-in-use',_0x5a61af);if(_0x4ae832==='USER_DISABLED')throw on(_0x2c89e2,'user-disabled',_0x5a61af);const _0x13f1ed=_0x432c1e[_0x4ae832]||_0x4ae832['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x51fb39)throw Ia(_0x2c89e2,_0x13f1ed,_0x51fb39);Y(_0x2c89e2,_0x13f1ed);}}catch(_0x3c1708){if(_0x3c1708 instanceof Re)throw _0x3c1708;Y(_0x2c89e2,'network-request-failed',{'message':String(_0x3c1708)});}}async function en(_0x260d1a,_0x39edb0,_0x353a47,_0xd94e89,_0xeb534f={}){const _0x3242e0=await Pe(_0x260d1a,_0x39edb0,_0x353a47,_0xd94e89,_0xeb534f);return'mfaPendingCredential'in _0x3242e0&&Y(_0x260d1a,'multi-factor-auth-required',{'_serverResponse':_0x3242e0}),_0x3242e0;}async function Ta(_0x568164,_0x2658fa,_0x1950b2,_0x2f5539){const _0x359b01=''+_0x2658fa+_0x1950b2+'?'+_0x2f5539,_0x28c949=_0x568164,_0x57ea16=_0x28c949['config']['emulator']?Cs(_0x568164['config'],_0x359b01):_0x568164['config']['apiScheme']+'://'+_0x359b01;return ff['includes'](_0x1950b2)&&(await _0x28c949['_persistenceManagerAvailable'],_0x28c949['_getPersistenceType']()==='COOKIE')?_0x28c949['_getPersistence']()['_getFinalTarget'](_0x57ea16)['toString']():_0x57ea16;}function _f(_0x22e082){switch(_0x22e082){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x44e384){this['auth']=_0x44e384,this['timer']=null,this['promise']=new Promise((_0x32a8bc,_0x1bb31b)=>{this['timer']=setTimeout(()=>_0x1bb31b(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x3e4312,_0x31eb0a,_0x124bd5){const _0x92563e={'appName':_0x3e4312['name']};_0x124bd5['email']&&(_0x92563e['email']=_0x124bd5['email']),_0x124bd5['phoneNumber']&&(_0x92563e['phoneNumber']=_0x124bd5['phoneNumber']);const _0x87868c=X(_0x3e4312,_0x31eb0a,_0x92563e);return _0x87868c['customData']['_tokenResponse']=_0x124bd5,_0x87868c;}function wr(_0x47bdaa){return _0x47bdaa!==void 0x0&&_0x47bdaa['enterprise']!==void 0x0;}class mf{constructor(_0x6bae1f){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x6bae1f['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x6bae1f['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x6bae1f['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x12f361){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x28ebfc of this['recaptchaEnforcementState'])if(_0x28ebfc['provider']&&_0x28ebfc['provider']===_0x12f361)return _f(_0x28ebfc['enforcementState']);return null;}['isProviderEnabled'](_0x530312){return this['getProviderEnforcementState'](_0x530312)==='ENFORCE'||this['getProviderEnforcementState'](_0x530312)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5a7244,_0x540b29){return Pe(_0x5a7244,'GET','/v2/recaptchaConfig',ke(_0x5a7244,_0x540b29));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x443380,_0x3bade2){return Pe(_0x443380,'POST','/v1/accounts:delete',_0x3bade2);}async function Pn(_0x3c6b4d,_0x39b828){return Pe(_0x3c6b4d,'POST','/v1/accounts:lookup',_0x39b828);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x392897){if(_0x392897)try{const _0x1a81cc=new Date(Number(_0x392897));if(!isNaN(_0x1a81cc['getTime']()))return _0x1a81cc['toUTCString']();}catch{}}async function Ef(_0x98f7c2,_0x342740=!0x1){const _0x480675=P(_0x98f7c2),_0x4d77ab=await _0x480675['getIdToken'](_0x342740),_0x56843d=Ts(_0x4d77ab);m(_0x56843d&&_0x56843d['exp']&&_0x56843d['auth_time']&&_0x56843d['iat'],_0x480675['auth'],'internal-error');const _0x24bcda=typeof _0x56843d['firebase']=='object'?_0x56843d['firebase']:void 0x0,_0x565294=_0x24bcda==null?void 0x0:_0x24bcda['sign_in_provider'];return{'claims':_0x56843d,'token':_0x4d77ab,'authTime':Pt(fi(_0x56843d['auth_time'])),'issuedAtTime':Pt(fi(_0x56843d['iat'])),'expirationTime':Pt(fi(_0x56843d['exp'])),'signInProvider':_0x565294||null,'signInSecondFactor':(_0x24bcda==null?void 0x0:_0x24bcda['sign_in_second_factor'])||null};}function fi(_0x47412b){return Number(_0x47412b)*0x3e8;}function Ts(_0x369e69){const [_0x4747ae,_0x5d727f,_0x3f8f7f]=_0x369e69['split']('.');if(_0x4747ae===void 0x0||_0x5d727f===void 0x0||_0x3f8f7f===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x49d6ee=fn(_0x5d727f);return _0x49d6ee?JSON['parse'](_0x49d6ee):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x4d92df){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x4d92df==null?void 0x0:_0x4d92df['toString']()),null;}}function Cr(_0x577e1c){const _0x3d6a14=Ts(_0x577e1c);return m(_0x3d6a14,'internal-error'),m(typeof _0x3d6a14['exp']<'u','internal-error'),m(typeof _0x3d6a14['iat']<'u','internal-error'),Number(_0x3d6a14['exp'])-Number(_0x3d6a14['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x34ee49,_0x5001cd,_0x16a4a6=!0x1){if(_0x16a4a6)return _0x5001cd;try{return await _0x5001cd;}catch(_0x42fa18){throw _0x42fa18 instanceof Re&&If(_0x42fa18)&&_0x34ee49['auth']['currentUser']===_0x34ee49&&await _0x34ee49['auth']['signOut'](),_0x42fa18;}}function If({code:_0xc68da7}){return _0xc68da7==='auth/user-disabled'||_0xc68da7==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5f0ec5){this['user']=_0x5f0ec5,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x346867){if(_0x346867){const _0x3835d6=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x3835d6;}else{this['errorBackoff']=0x7530;const _0x2073e3=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x2073e3);}}['schedule'](_0x478b25=!0x1){if(!this['isRunning'])return;const _0x1a47d3=this['getInterval'](_0x478b25);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1a47d3);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5afad6){(_0x5afad6==null?void 0x0:_0x5afad6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x5a64f8,_0x40ac50){this['createdAt']=_0x5a64f8,this['lastLoginAt']=_0x40ac50,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x11d703){this['createdAt']=_0x11d703['createdAt'],this['lastLoginAt']=_0x11d703['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x439adc){var _0x9e6b2a;const _0x3f0bd2=_0x439adc['auth'],_0x22e419=await _0x439adc['getIdToken'](),_0x39328a=await Ht(_0x439adc,Pn(_0x3f0bd2,{'idToken':_0x22e419}));m(_0x39328a==null?void 0x0:_0x39328a['users']['length'],_0x3f0bd2,'internal-error');const _0x3f6787=_0x39328a['users'][0x0];_0x439adc['_notifyReloadListener'](_0x3f6787);const _0x2f74aa=(_0x9e6b2a=_0x3f6787['providerUserInfo'])!=null&&_0x9e6b2a['length']?Sa(_0x3f6787['providerUserInfo']):[],_0x2b6eb7=Tf(_0x439adc['providerData'],_0x2f74aa),_0x1566eb=_0x439adc['isAnonymous'],_0x15ecf9=!(_0x439adc['email']&&_0x3f6787['passwordHash'])&&!(_0x2b6eb7!=null&&_0x2b6eb7['length']),_0x52b447=_0x1566eb?_0x15ecf9:!0x1,_0x41520e={'uid':_0x3f6787['localId'],'displayName':_0x3f6787['displayName']||null,'photoURL':_0x3f6787['photoUrl']||null,'email':_0x3f6787['email']||null,'emailVerified':_0x3f6787['emailVerified']||!0x1,'phoneNumber':_0x3f6787['phoneNumber']||null,'tenantId':_0x3f6787['tenantId']||null,'providerData':_0x2b6eb7,'metadata':new Li(_0x3f6787['createdAt'],_0x3f6787['lastLoginAt']),'isAnonymous':_0x52b447};Object['assign'](_0x439adc,_0x41520e);}async function Cf(_0x47c1ff){const _0xb6098e=P(_0x47c1ff);await Nn(_0xb6098e),await _0xb6098e['auth']['_persistUserIfCurrent'](_0xb6098e),_0xb6098e['auth']['_notifyListenersIfCurrent'](_0xb6098e);}function Tf(_0x3cb48c,_0x23e03c){return[..._0x3cb48c['filter'](_0x356572=>!_0x23e03c['some'](_0x1f3de3=>_0x1f3de3['providerId']===_0x356572['providerId'])),..._0x23e03c];}function Sa(_0x5e3ac0){return _0x5e3ac0['map'](({providerId:_0x1db82c,..._0x536a24})=>({'providerId':_0x1db82c,'uid':_0x536a24['rawId']||'','displayName':_0x536a24['displayName']||null,'email':_0x536a24['email']||null,'phoneNumber':_0x536a24['phoneNumber']||null,'photoURL':_0x536a24['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x2d4713,_0x237644){const _0x48f796=await Ca(_0x2d4713,{},async()=>{const _0x95c79f=ut({'grant_type':'refresh_token','refresh_token':_0x237644})['slice'](0x1),{tokenApiHost:_0x192097,apiKey:_0x2c63df}=_0x2d4713['config'],_0x3895d5=await Ta(_0x2d4713,_0x192097,'/v1/token','key='+_0x2c63df),_0x1e1390=await _0x2d4713['_getAdditionalHeaders']();_0x1e1390['Content-Type']='application/x-www-form-urlencoded';const _0x49e629={'method':'POST','headers':_0x1e1390,'body':_0x95c79f};return _0x2d4713['emulatorConfig']&&qt(_0x2d4713['emulatorConfig']['host'])&&(_0x49e629['credentials']='include'),wa['fetch']()(_0x3895d5,_0x49e629);});return{'accessToken':_0x48f796['access_token'],'expiresIn':_0x48f796['expires_in'],'refreshToken':_0x48f796['refresh_token']};}async function bf(_0xa618bc,_0x1b6269){return Pe(_0xa618bc,'POST','/v2/accounts:revokeToken',ke(_0xa618bc,_0x1b6269));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x40e841){m(_0x40e841['idToken'],'internal-error'),m(typeof _0x40e841['idToken']<'u','internal-error'),m(typeof _0x40e841['refreshToken']<'u','internal-error');const _0x45c6db='expiresIn'in _0x40e841&&typeof _0x40e841['expiresIn']<'u'?Number(_0x40e841['expiresIn']):Cr(_0x40e841['idToken']);this['updateTokensAndExpiration'](_0x40e841['idToken'],_0x40e841['refreshToken'],_0x45c6db);}['updateFromIdToken'](_0x97943a){m(_0x97943a['length']!==0x0,'internal-error');const _0xef3df4=Cr(_0x97943a);this['updateTokensAndExpiration'](_0x97943a,null,_0xef3df4);}async['getToken'](_0x2f11d,_0x5d2486=!0x1){return!_0x5d2486&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2f11d,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2f11d,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3a061a,_0x163d20){const {accessToken:_0x5c617e,refreshToken:_0x55f1b1,expiresIn:_0xda5b69}=await Sf(_0x3a061a,_0x163d20);this['updateTokensAndExpiration'](_0x5c617e,_0x55f1b1,Number(_0xda5b69));}['updateTokensAndExpiration'](_0x468d7a,_0x191af9,_0xb28e68){this['refreshToken']=_0x191af9||null,this['accessToken']=_0x468d7a||null,this['expirationTime']=Date['now']()+_0xb28e68*0x3e8;}static['fromJSON'](_0x1511db,_0x1ebc2f){const {refreshToken:_0x771ad5,accessToken:_0x40edaf,expirationTime:_0x179f5b}=_0x1ebc2f,_0x245439=new et();return _0x771ad5&&(m(typeof _0x771ad5=='string','internal-error',{'appName':_0x1511db}),_0x245439['refreshToken']=_0x771ad5),_0x40edaf&&(m(typeof _0x40edaf=='string','internal-error',{'appName':_0x1511db}),_0x245439['accessToken']=_0x40edaf),_0x179f5b&&(m(typeof _0x179f5b=='number','internal-error',{'appName':_0x1511db}),_0x245439['expirationTime']=_0x179f5b),_0x245439;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4b45d5){this['accessToken']=_0x4b45d5['accessToken'],this['refreshToken']=_0x4b45d5['refreshToken'],this['expirationTime']=_0x4b45d5['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x408cdf,_0x3c9163){m(typeof _0x408cdf=='string'||typeof _0x408cdf>'u','internal-error',{'appName':_0x3c9163});}class j{constructor({uid:_0x339872,auth:_0x2acb20,stsTokenManager:_0xd0dade,..._0x123674}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x339872,this['auth']=_0x2acb20,this['stsTokenManager']=_0xd0dade,this['accessToken']=_0xd0dade['accessToken'],this['displayName']=_0x123674['displayName']||null,this['email']=_0x123674['email']||null,this['emailVerified']=_0x123674['emailVerified']||!0x1,this['phoneNumber']=_0x123674['phoneNumber']||null,this['photoURL']=_0x123674['photoURL']||null,this['isAnonymous']=_0x123674['isAnonymous']||!0x1,this['tenantId']=_0x123674['tenantId']||null,this['providerData']=_0x123674['providerData']?[..._0x123674['providerData']]:[],this['metadata']=new Li(_0x123674['createdAt']||void 0x0,_0x123674['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2fb2a5){const _0x1e98a2=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x2fb2a5));return m(_0x1e98a2,this['auth'],'internal-error'),this['accessToken']!==_0x1e98a2&&(this['accessToken']=_0x1e98a2,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1e98a2;}['getIdTokenResult'](_0x532616){return Ef(this,_0x532616);}['reload'](){return Cf(this);}['_assign'](_0x5be497){this!==_0x5be497&&(m(this['uid']===_0x5be497['uid'],this['auth'],'internal-error'),this['displayName']=_0x5be497['displayName'],this['photoURL']=_0x5be497['photoURL'],this['email']=_0x5be497['email'],this['emailVerified']=_0x5be497['emailVerified'],this['phoneNumber']=_0x5be497['phoneNumber'],this['isAnonymous']=_0x5be497['isAnonymous'],this['tenantId']=_0x5be497['tenantId'],this['providerData']=_0x5be497['providerData']['map'](_0x3fdf59=>({..._0x3fdf59})),this['metadata']['_copy'](_0x5be497['metadata']),this['stsTokenManager']['_assign'](_0x5be497['stsTokenManager']));}['_clone'](_0x392668){const _0x534964=new j({...this,'auth':_0x392668,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x534964['metadata']['_copy'](this['metadata']),_0x534964;}['_onReload'](_0x16284b){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x16284b,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x12a44b){this['reloadListener']?this['reloadListener'](_0x12a44b):this['reloadUserInfo']=_0x12a44b;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x51912f,_0x51f157=!0x1){let _0x3b9142=!0x1;_0x51912f['idToken']&&_0x51912f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x51912f),_0x3b9142=!0x0),_0x51f157&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x3b9142&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x269402=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x269402})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x15f19d=>({..._0x15f19d})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x10b9d3,_0x500c8d){const _0x4b2d3f=_0x500c8d['displayName']??void 0x0,_0x535e21=_0x500c8d['email']??void 0x0,_0x215afb=_0x500c8d['phoneNumber']??void 0x0,_0x57e31f=_0x500c8d['photoURL']??void 0x0,_0x3f2748=_0x500c8d['tenantId']??void 0x0,_0x36449c=_0x500c8d['_redirectEventId']??void 0x0,_0x1c06ba=_0x500c8d['createdAt']??void 0x0,_0x4aaf70=_0x500c8d['lastLoginAt']??void 0x0,{uid:_0x5bf844,emailVerified:_0x28b020,isAnonymous:_0x194128,providerData:_0x5afac6,stsTokenManager:_0x2f9060}=_0x500c8d;m(_0x5bf844&&_0x2f9060,_0x10b9d3,'internal-error');const _0x1c0952=et['fromJSON'](this['name'],_0x2f9060);m(typeof _0x5bf844=='string',_0x10b9d3,'internal-error'),le(_0x4b2d3f,_0x10b9d3['name']),le(_0x535e21,_0x10b9d3['name']),m(typeof _0x28b020=='boolean',_0x10b9d3,'internal-error'),m(typeof _0x194128=='boolean',_0x10b9d3,'internal-error'),le(_0x215afb,_0x10b9d3['name']),le(_0x57e31f,_0x10b9d3['name']),le(_0x3f2748,_0x10b9d3['name']),le(_0x36449c,_0x10b9d3['name']),le(_0x1c06ba,_0x10b9d3['name']),le(_0x4aaf70,_0x10b9d3['name']);const _0x5a4974=new j({'uid':_0x5bf844,'auth':_0x10b9d3,'email':_0x535e21,'emailVerified':_0x28b020,'displayName':_0x4b2d3f,'isAnonymous':_0x194128,'photoURL':_0x57e31f,'phoneNumber':_0x215afb,'tenantId':_0x3f2748,'stsTokenManager':_0x1c0952,'createdAt':_0x1c06ba,'lastLoginAt':_0x4aaf70});return _0x5afac6&&Array['isArray'](_0x5afac6)&&(_0x5a4974['providerData']=_0x5afac6['map'](_0xad88df=>({..._0xad88df}))),_0x36449c&&(_0x5a4974['_redirectEventId']=_0x36449c),_0x5a4974;}static async['_fromIdTokenResponse'](_0x5af4e1,_0x1ab5b0,_0x506a8a=!0x1){const _0x47a413=new et();_0x47a413['updateFromServerResponse'](_0x1ab5b0);const _0x3c6838=new j({'uid':_0x1ab5b0['localId'],'auth':_0x5af4e1,'stsTokenManager':_0x47a413,'isAnonymous':_0x506a8a});return await Nn(_0x3c6838),_0x3c6838;}static async['_fromGetAccountInfoResponse'](_0xdc1886,_0x56603e,_0x23068f){const _0x53690f=_0x56603e['users'][0x0];m(_0x53690f['localId']!==void 0x0,'internal-error');const _0x2e3501=_0x53690f['providerUserInfo']!==void 0x0?Sa(_0x53690f['providerUserInfo']):[],_0x521e84=!(_0x53690f['email']&&_0x53690f['passwordHash'])&&!(_0x2e3501!=null&&_0x2e3501['length']),_0x4be770=new et();_0x4be770['updateFromIdToken'](_0x23068f);const _0xa58c1c=new j({'uid':_0x53690f['localId'],'auth':_0xdc1886,'stsTokenManager':_0x4be770,'isAnonymous':_0x521e84}),_0x108607={'uid':_0x53690f['localId'],'displayName':_0x53690f['displayName']||null,'photoURL':_0x53690f['photoUrl']||null,'email':_0x53690f['email']||null,'emailVerified':_0x53690f['emailVerified']||!0x1,'phoneNumber':_0x53690f['phoneNumber']||null,'tenantId':_0x53690f['tenantId']||null,'providerData':_0x2e3501,'metadata':new Li(_0x53690f['createdAt'],_0x53690f['lastLoginAt']),'isAnonymous':!(_0x53690f['email']&&_0x53690f['passwordHash'])&&!(_0x2e3501!=null&&_0x2e3501['length'])};return Object['assign'](_0xa58c1c,_0x108607),_0xa58c1c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5b9ea4){ce(_0x5b9ea4 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x12bc09=Tr['get'](_0x5b9ea4);return _0x12bc09?(ce(_0x12bc09 instanceof _0x5b9ea4,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x12bc09):(_0x12bc09=new _0x5b9ea4(),Tr['set'](_0x5b9ea4,_0x12bc09),_0x12bc09);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2b675c,_0xced2e0){this['storage'][_0x2b675c]=_0xced2e0;}async['_get'](_0x3595f6){const _0x5c042f=this['storage'][_0x3595f6];return _0x5c042f===void 0x0?null:_0x5c042f;}async['_remove'](_0x20f0be){delete this['storage'][_0x20f0be];}['_addListener'](_0x442a40,_0x3be411){}['_removeListener'](_0x44d27c,_0x412ba4){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4d176a,_0x34d93f,_0x3036d3){return'firebase:'+_0x4d176a+':'+_0x34d93f+':'+_0x3036d3;}class tt{constructor(_0x53b366,_0x31e35a,_0x3f4899){this['persistence']=_0x53b366,this['auth']=_0x31e35a,this['userKey']=_0x3f4899;const {config:_0x7c876a,name:_0xbf562a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x7c876a['apiKey'],_0xbf562a),this['fullPersistenceKey']=ln('persistence',_0x7c876a['apiKey'],_0xbf562a),this['boundEventHandler']=_0x31e35a['_onStorageEvent']['bind'](_0x31e35a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x41d326){return this['persistence']['_set'](this['fullUserKey'],_0x41d326['toJSON']());}async['getCurrentUser'](){const _0x1c769a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1c769a)return null;if(typeof _0x1c769a=='string'){const _0x1f83c1=await Pn(this['auth'],{'idToken':_0x1c769a})['catch'](()=>{});return _0x1f83c1?j['_fromGetAccountInfoResponse'](this['auth'],_0x1f83c1,_0x1c769a):null;}return j['_fromJSON'](this['auth'],_0x1c769a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1b1cc4){if(this['persistence']===_0x1b1cc4)return;const _0x337380=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1b1cc4,_0x337380)return this['setCurrentUser'](_0x337380);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xd3784d,_0x2f61d4,_0x49211c='authUser'){if(!_0x2f61d4['length'])return new tt(ie(Sr),_0xd3784d,_0x49211c);const _0x5e73fd=(await Promise['all'](_0x2f61d4['map'](async _0x4f9854=>{if(await _0x4f9854['_isAvailable']())return _0x4f9854;})))['filter'](_0x404246=>_0x404246);let _0x4de82e=_0x5e73fd[0x0]||ie(Sr);const _0x480b2c=ln(_0x49211c,_0xd3784d['config']['apiKey'],_0xd3784d['name']);let _0x57f778=null;for(const _0x1aaa66 of _0x2f61d4)try{const _0xc005cd=await _0x1aaa66['_get'](_0x480b2c);if(_0xc005cd){let _0x551f61;if(typeof _0xc005cd=='string'){const _0x1b91fe=await Pn(_0xd3784d,{'idToken':_0xc005cd})['catch'](()=>{});if(!_0x1b91fe)break;_0x551f61=await j['_fromGetAccountInfoResponse'](_0xd3784d,_0x1b91fe,_0xc005cd);}else _0x551f61=j['_fromJSON'](_0xd3784d,_0xc005cd);_0x1aaa66!==_0x4de82e&&(_0x57f778=_0x551f61),_0x4de82e=_0x1aaa66;break;}}catch{}const _0x3e768f=_0x5e73fd['filter'](_0x3d34df=>_0x3d34df['_shouldAllowMigration']);return!_0x4de82e['_shouldAllowMigration']||!_0x3e768f['length']?new tt(_0x4de82e,_0xd3784d,_0x49211c):(_0x4de82e=_0x3e768f[0x0],_0x57f778&&await _0x4de82e['_set'](_0x480b2c,_0x57f778['toJSON']()),await Promise['all'](_0x2f61d4['map'](async _0x2f1298=>{if(_0x2f1298!==_0x4de82e)try{await _0x2f1298['_remove'](_0x480b2c);}catch{}})),new tt(_0x4de82e,_0xd3784d,_0x49211c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x86462e){const _0x54009a=_0x86462e['toLowerCase']();if(_0x54009a['includes']('opera/')||_0x54009a['includes']('opr/')||_0x54009a['includes']('opios/'))return'Opera';if(Pa(_0x54009a))return'IEMobile';if(_0x54009a['includes']('msie')||_0x54009a['includes']('trident/'))return'IE';if(_0x54009a['includes']('edge/'))return'Edge';if(Ra(_0x54009a))return'Firefox';if(_0x54009a['includes']('silk/'))return'Silk';if(Oa(_0x54009a))return'Blackberry';if(Da(_0x54009a))return'Webos';if(Aa(_0x54009a))return'Safari';if((_0x54009a['includes']('chrome/')||ka(_0x54009a))&&!_0x54009a['includes']('edge/'))return'Chrome';if(Na(_0x54009a))return'Android';{const _0x2f0cbd=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xa0258b=_0x86462e['match'](_0x2f0cbd);if((_0xa0258b==null?void 0x0:_0xa0258b['length'])===0x2)return _0xa0258b[0x1];}return'Other';}function Ra(_0x589ddc=W()){return/firefox\//i['test'](_0x589ddc);}function Aa(_0x11ff8b=W()){const _0x498e2e=_0x11ff8b['toLowerCase']();return _0x498e2e['includes']('safari/')&&!_0x498e2e['includes']('chrome/')&&!_0x498e2e['includes']('crios/')&&!_0x498e2e['includes']('android');}function ka(_0x372bac=W()){return/crios\//i['test'](_0x372bac);}function Pa(_0xe8c184=W()){return/iemobile/i['test'](_0xe8c184);}function Na(_0x2fc490=W()){return/android/i['test'](_0x2fc490);}function Oa(_0x1a3f1d=W()){return/blackberry/i['test'](_0x1a3f1d);}function Da(_0x7ab661=W()){return/webos/i['test'](_0x7ab661);}function Ss(_0x5693f8=W()){return/iphone|ipad|ipod/i['test'](_0x5693f8)||/macintosh/i['test'](_0x5693f8)&&/mobile/i['test'](_0x5693f8);}function Rf(_0x3975af=W()){var _0x35c7f6;return Ss(_0x3975af)&&!!((_0x35c7f6=window['navigator'])!=null&&_0x35c7f6['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2ad458=W()){return Ss(_0x2ad458)||Na(_0x2ad458)||Da(_0x2ad458)||Oa(_0x2ad458)||/windows phone/i['test'](_0x2ad458)||Pa(_0x2ad458);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4af644,_0x1b5342=[]){let _0x20a956;switch(_0x4af644){case'Browser':_0x20a956=br(W());break;case'Worker':_0x20a956=br(W())+'-'+_0x4af644;break;default:_0x20a956=_0x4af644;}const _0x44196b=_0x1b5342['length']?_0x1b5342['join'](','):'FirebaseCore-web';return _0x20a956+'/JsCore/'+dt+'/'+_0x44196b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x50c0d2){this['auth']=_0x50c0d2,this['queue']=[];}['pushCallback'](_0x5aa8ff,_0x553d8a){const _0x7ae703=_0x35b1a1=>new Promise((_0x4d3cdf,_0x59ba12)=>{try{const _0x593578=_0x5aa8ff(_0x35b1a1);_0x4d3cdf(_0x593578);}catch(_0x4b26c9){_0x59ba12(_0x4b26c9);}});_0x7ae703['onAbort']=_0x553d8a,this['queue']['push'](_0x7ae703);const _0x36244d=this['queue']['length']-0x1;return()=>{this['queue'][_0x36244d]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4da84e){if(this['auth']['currentUser']===_0x4da84e)return;const _0x180605=[];try{for(const _0xa6e5de of this['queue'])await _0xa6e5de(_0x4da84e),_0xa6e5de['onAbort']&&_0x180605['push'](_0xa6e5de['onAbort']);}catch(_0xe60302){_0x180605['reverse']();for(const _0x299f57 of _0x180605)try{_0x299f57();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xe60302==null?void 0x0:_0xe60302['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x401f06,_0x17cb74={}){return Pe(_0x401f06,'GET','/v2/passwordPolicy',ke(_0x401f06,_0x17cb74));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3a4eb4){var _0x289515;const _0x27b9d3=_0x3a4eb4['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x27b9d3['minPasswordLength']??Nf,_0x27b9d3['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x27b9d3['maxPasswordLength']),_0x27b9d3['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x27b9d3['containsLowercaseCharacter']),_0x27b9d3['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x27b9d3['containsUppercaseCharacter']),_0x27b9d3['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x27b9d3['containsNumericCharacter']),_0x27b9d3['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x27b9d3['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3a4eb4['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x289515=_0x3a4eb4['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x289515['join'](''))??'',this['forceUpgradeOnSignin']=_0x3a4eb4['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3a4eb4['schemaVersion'];}['validatePassword'](_0x263f14){const _0x11329d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x263f14,_0x11329d),this['validatePasswordCharacterOptions'](_0x263f14,_0x11329d),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['meetsMinPasswordLength']??!0x0),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['meetsMaxPasswordLength']??!0x0),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['containsLowercaseLetter']??!0x0),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['containsUppercaseLetter']??!0x0),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['containsNumericCharacter']??!0x0),_0x11329d['isValid']&&(_0x11329d['isValid']=_0x11329d['containsNonAlphanumericCharacter']??!0x0),_0x11329d;}['validatePasswordLengthOptions'](_0x4df1f4,_0x41b47a){const _0x578355=this['customStrengthOptions']['minPasswordLength'],_0x5d7797=this['customStrengthOptions']['maxPasswordLength'];_0x578355&&(_0x41b47a['meetsMinPasswordLength']=_0x4df1f4['length']>=_0x578355),_0x5d7797&&(_0x41b47a['meetsMaxPasswordLength']=_0x4df1f4['length']<=_0x5d7797);}['validatePasswordCharacterOptions'](_0x32e7e5,_0x1c1d62){this['updatePasswordCharacterOptionsStatuses'](_0x1c1d62,!0x1,!0x1,!0x1,!0x1);let _0x7f1837;for(let _0x434ede=0x0;_0x434ede<_0x32e7e5['length'];_0x434ede++)_0x7f1837=_0x32e7e5['charAt'](_0x434ede),this['updatePasswordCharacterOptionsStatuses'](_0x1c1d62,_0x7f1837>='a'&&_0x7f1837<='z',_0x7f1837>='A'&&_0x7f1837<='Z',_0x7f1837>='0'&&_0x7f1837<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x7f1837));}['updatePasswordCharacterOptionsStatuses'](_0x178030,_0x2a7c83,_0x5489b2,_0xf1a9c2,_0x3c3a17){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x178030['containsLowercaseLetter']||(_0x178030['containsLowercaseLetter']=_0x2a7c83)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x178030['containsUppercaseLetter']||(_0x178030['containsUppercaseLetter']=_0x5489b2)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x178030['containsNumericCharacter']||(_0x178030['containsNumericCharacter']=_0xf1a9c2)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x178030['containsNonAlphanumericCharacter']||(_0x178030['containsNonAlphanumericCharacter']=_0x3c3a17));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x265425,_0x4dff69,_0x60ab7,_0x14f3f5){this['app']=_0x265425,this['heartbeatServiceProvider']=_0x4dff69,this['appCheckServiceProvider']=_0x60ab7,this['config']=_0x14f3f5,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x265425['name'],this['clientVersion']=_0x14f3f5['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3eadd3=>this['_resolvePersistenceManagerAvailable']=_0x3eadd3);}['_initializeWithPersistence'](_0x4993c8,_0x5559fd){return _0x5559fd&&(this['_popupRedirectResolver']=ie(_0x5559fd)),this['_initializationPromise']=this['queue'](async()=>{var _0x36e524,_0x4b658d,_0x44bdcd;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4993c8),(_0x36e524=this['_resolvePersistenceManagerAvailable'])==null||_0x36e524['call'](this),!this['_deleted'])){if((_0x4b658d=this['_popupRedirectResolver'])!=null&&_0x4b658d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5559fd),this['lastNotifiedUid']=((_0x44bdcd=this['currentUser'])==null?void 0x0:_0x44bdcd['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x13da86=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x13da86)){if(this['currentUser']&&_0x13da86&&this['currentUser']['uid']===_0x13da86['uid']){this['_currentUser']['_assign'](_0x13da86),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x13da86,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x67b1de){try{const _0x22155f=await Pn(this,{'idToken':_0x67b1de}),_0x4fbd52=await j['_fromGetAccountInfoResponse'](this,_0x22155f,_0x67b1de);await this['directlySetCurrentUser'](_0x4fbd52);}catch(_0x197dd2){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x197dd2),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2ae7f0){var _0x24a884;if($(this['app'])){const _0x356a6a=this['app']['settings']['authIdToken'];return _0x356a6a?new Promise(_0x5b506a=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x356a6a)['then'](_0x5b506a,_0x5b506a));}):this['directlySetCurrentUser'](null);}const _0x811b0f=await this['assertedPersistence']['getCurrentUser']();let _0x1df2e1=_0x811b0f,_0x267bdd=!0x1;if(_0x2ae7f0&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3ae7a8=(_0x24a884=this['redirectUser'])==null?void 0x0:_0x24a884['_redirectEventId'],_0x5471b4=_0x1df2e1==null?void 0x0:_0x1df2e1['_redirectEventId'],_0xf938e2=await this['tryRedirectSignIn'](_0x2ae7f0);(!_0x3ae7a8||_0x3ae7a8===_0x5471b4)&&(_0xf938e2!=null&&_0xf938e2['user'])&&(_0x1df2e1=_0xf938e2['user'],_0x267bdd=!0x0);}if(!_0x1df2e1)return this['directlySetCurrentUser'](null);if(!_0x1df2e1['_redirectEventId']){if(_0x267bdd)try{await this['beforeStateQueue']['runMiddleware'](_0x1df2e1);}catch(_0x5488a1){_0x1df2e1=_0x811b0f,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5488a1));}return _0x1df2e1?this['reloadAndSetCurrentUserOrClear'](_0x1df2e1):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1df2e1['_redirectEventId']?this['directlySetCurrentUser'](_0x1df2e1):this['reloadAndSetCurrentUserOrClear'](_0x1df2e1);}async['tryRedirectSignIn'](_0x40c358){let _0x5047d3=null;try{_0x5047d3=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x40c358,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5047d3;}async['reloadAndSetCurrentUserOrClear'](_0x154d7c){try{await Nn(_0x154d7c);}catch(_0x106123){if((_0x106123==null?void 0x0:_0x106123['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x154d7c);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x15275f){if($(this['app']))return Promise['reject'](re(this));const _0x223859=_0x15275f?P(_0x15275f):null;return _0x223859&&m(_0x223859['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x223859&&_0x223859['_clone'](this));}async['_updateCurrentUser'](_0x21f06e,_0x35901b=!0x1){if(!this['_deleted'])return _0x21f06e&&m(this['tenantId']===_0x21f06e['tenantId'],this,'tenant-id-mismatch'),_0x35901b||await this['beforeStateQueue']['runMiddleware'](_0x21f06e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x21f06e),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x323d1b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x323d1b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x30b7d6){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3912ea=this['_getPasswordPolicyInternal']();return _0x3912ea['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3912ea['validatePassword'](_0x30b7d6);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1937fa=await Pf(this),_0x3950bc=new Of(_0x1937fa);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3950bc:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3950bc;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x50a2bf){this['_errorFactory']=new Gt('auth','Firebase',_0x50a2bf());}['onAuthStateChanged'](_0x100ac1,_0x3d4dd7,_0x4ef3df){return this['registerStateListener'](this['authStateSubscription'],_0x100ac1,_0x3d4dd7,_0x4ef3df);}['beforeAuthStateChanged'](_0x36590e,_0xaf6cb5){return this['beforeStateQueue']['pushCallback'](_0x36590e,_0xaf6cb5);}['onIdTokenChanged'](_0x1f2dd3,_0x3cace9,_0x1c73fb){return this['registerStateListener'](this['idTokenSubscription'],_0x1f2dd3,_0x3cace9,_0x1c73fb);}['authStateReady'](){return new Promise((_0x468a49,_0x8d0f5a)=>{if(this['currentUser'])_0x468a49();else{const _0x537367=this['onAuthStateChanged'](()=>{_0x537367(),_0x468a49();},_0x8d0f5a);}});}async['revokeAccessToken'](_0x1753cf){if(this['currentUser']){const _0x61e426=await this['currentUser']['getIdToken'](),_0x324215={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1753cf,'idToken':_0x61e426};this['tenantId']!=null&&(_0x324215['tenantId']=this['tenantId']),await bf(this,_0x324215);}}['toJSON'](){var _0x29d3a7;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x29d3a7=this['_currentUser'])==null?void 0x0:_0x29d3a7['toJSON']()};}async['_setRedirectUser'](_0x5aea82,_0x2481ec){const _0x178331=await this['getOrInitRedirectPersistenceManager'](_0x2481ec);return _0x5aea82===null?_0x178331['removeCurrentUser']():_0x178331['setCurrentUser'](_0x5aea82);}async['getOrInitRedirectPersistenceManager'](_0x50700d){if(!this['redirectPersistenceManager']){const _0x19f66e=_0x50700d&&ie(_0x50700d)||this['_popupRedirectResolver'];m(_0x19f66e,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x19f66e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1e8bc3){var _0x504366,_0x4a5b55;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x504366=this['_currentUser'])==null?void 0x0:_0x504366['_redirectEventId'])===_0x1e8bc3?this['_currentUser']:((_0x4a5b55=this['redirectUser'])==null?void 0x0:_0x4a5b55['_redirectEventId'])===_0x1e8bc3?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x4f7875){if(_0x4f7875===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x4f7875));}['_notifyListenersIfCurrent'](_0x15acb9){_0x15acb9===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x53ef5a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x439167=((_0x53ef5a=this['currentUser'])==null?void 0x0:_0x53ef5a['uid'])??null;this['lastNotifiedUid']!==_0x439167&&(this['lastNotifiedUid']=_0x439167,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x1c19f3,_0x54117c,_0x40f970,_0x6b8ef2){if(this['_deleted'])return()=>{};const _0x15c742=typeof _0x54117c=='function'?_0x54117c:_0x54117c['next']['bind'](_0x54117c);let _0xa49a26=!0x1;const _0x17cf04=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x17cf04,this,'internal-error'),_0x17cf04['then'](()=>{_0xa49a26||_0x15c742(this['currentUser']);}),typeof _0x54117c=='function'){const _0x3e6e2b=_0x1c19f3['addObserver'](_0x54117c,_0x40f970,_0x6b8ef2);return()=>{_0xa49a26=!0x0,_0x3e6e2b();};}else{const _0x417d47=_0x1c19f3['addObserver'](_0x54117c);return()=>{_0xa49a26=!0x0,_0x417d47();};}}async['directlySetCurrentUser'](_0x258630){this['currentUser']&&this['currentUser']!==_0x258630&&this['_currentUser']['_stopProactiveRefresh'](),_0x258630&&this['isProactiveRefreshEnabled']&&_0x258630['_startProactiveRefresh'](),this['currentUser']=_0x258630,_0x258630?await this['assertedPersistence']['setCurrentUser'](_0x258630):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4518fd){return this['operations']=this['operations']['then'](_0x4518fd,_0x4518fd),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1e8817){!_0x1e8817||this['frameworks']['includes'](_0x1e8817)||(this['frameworks']['push'](_0x1e8817),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4902bc;const _0x56a364={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x56a364['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xac2f9d=await((_0x4902bc=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4902bc['getHeartbeatsHeader']());_0xac2f9d&&(_0x56a364['X-Firebase-Client']=_0xac2f9d);const _0x7bac0f=await this['_getAppCheckToken']();return _0x7bac0f&&(_0x56a364['X-Firebase-AppCheck']=_0x7bac0f),_0x56a364;}async['_getAppCheckToken'](){var _0x407da3;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3949c0=await((_0x407da3=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x407da3['getToken']());return _0x3949c0!=null&&_0x3949c0['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3949c0['error']),_0x3949c0==null?void 0x0:_0x3949c0['token'];}}function Ke(_0x22e4f0){return P(_0x22e4f0);}class Rr{constructor(_0xc67405){this['auth']=_0xc67405,this['observer']=null,this['addObserver']=Tc(_0x39e4dd=>this['observer']=_0x39e4dd);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2d6181){Jn=_0x2d6181;}function xa(_0xd42baa){return Jn['loadJS'](_0xd42baa);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x2fea94){return'__'+_0x2fea94+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xaa6354){_0xaa6354();}['execute'](_0x810695,_0x6b0900){return Promise['resolve']('token');}['render'](_0x46feed,_0x11d4fd){return'';}}class Wf{['ready'](_0x54adc1){_0x54adc1();}['execute'](_0x345a0f,_0x5d0a9f){return Promise['resolve']('token');}['render'](_0x12d76c,_0x5acca8){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x81c0f){this['type']=Bf,this['auth']=Ke(_0x81c0f);}async['verify'](_0x418484='verify',_0x76ed3c=!0x1){async function _0x28813e(_0x57805f){if(!_0x76ed3c){if(_0x57805f['tenantId']==null&&_0x57805f['_agentRecaptchaConfig']!=null)return _0x57805f['_agentRecaptchaConfig']['siteKey'];if(_0x57805f['tenantId']!=null&&_0x57805f['_tenantRecaptchaConfigs'][_0x57805f['tenantId']]!==void 0x0)return _0x57805f['_tenantRecaptchaConfigs'][_0x57805f['tenantId']]['siteKey'];}return new Promise(async(_0x518c34,_0x575a84)=>{yf(_0x57805f,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x9661ae=>{if(_0x9661ae['recaptchaKey']===void 0x0)_0x575a84(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2175b4=new mf(_0x9661ae);return _0x57805f['tenantId']==null?_0x57805f['_agentRecaptchaConfig']=_0x2175b4:_0x57805f['_tenantRecaptchaConfigs'][_0x57805f['tenantId']]=_0x2175b4,_0x518c34(_0x2175b4['siteKey']);}})['catch'](_0x29e9df=>{_0x575a84(_0x29e9df);});});}function _0x447997(_0x2c6555,_0x5e8f7e,_0x274096){const _0x1b147b=window['grecaptcha'];wr(_0x1b147b)?_0x1b147b['enterprise']['ready'](()=>{_0x1b147b['enterprise']['execute'](_0x2c6555,{'action':_0x418484})['then'](_0x25f0bc=>{_0x5e8f7e(_0x25f0bc);})['catch'](()=>{_0x5e8f7e(Fa);});}):_0x274096(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x594f6c,_0x191bd7)=>{_0x28813e(this['auth'])['then'](async _0x54a31f=>{if(!_0x76ed3c&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x447997(_0x54a31f,_0x594f6c,_0x191bd7);else{if(typeof window>'u'){_0x191bd7(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x21a387=Lf();_0x21a387['length']!==0x0&&(_0x21a387+=_0x54a31f+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x44ebee;(_0x44ebee=he['scriptInjectionDeferred'])==null||_0x44ebee['resolve']();},xa(_0x21a387)['then'](()=>{var _0x348f37;return(_0x348f37=he['scriptInjectionDeferred'])==null?void 0x0:_0x348f37['promise'];})['then'](()=>{_0x447997(_0x54a31f,_0x594f6c,_0x191bd7);})['catch'](_0x322a48=>{_0x191bd7(_0x322a48);});}})['catch'](_0x4a6c2b=>{_0x191bd7(_0x4a6c2b);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5c8d09,_0x5b0e1b,_0x3f0d18,_0x5eb3b6=!0x1,_0x303143=!0x1){const _0x186f9c=new he(_0x5c8d09);let _0x2c40b6;if(_0x303143)_0x2c40b6=Fa;else try{_0x2c40b6=await _0x186f9c['verify'](_0x3f0d18);}catch{_0x2c40b6=await _0x186f9c['verify'](_0x3f0d18,!0x0);}const _0x20fc4a={..._0x5b0e1b};if(_0x3f0d18==='mfaSmsEnrollment'||_0x3f0d18==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x20fc4a){const _0x410331=_0x20fc4a['phoneEnrollmentInfo']['phoneNumber'],_0x24bcc9=_0x20fc4a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x20fc4a,{'phoneEnrollmentInfo':{'phoneNumber':_0x410331,'recaptchaToken':_0x24bcc9,'captchaResponse':_0x2c40b6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x20fc4a){const _0x2060f3=_0x20fc4a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x20fc4a,{'phoneSignInInfo':{'recaptchaToken':_0x2060f3,'captchaResponse':_0x2c40b6,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x20fc4a;}return _0x5eb3b6?Object['assign'](_0x20fc4a,{'captchaResp':_0x2c40b6}):Object['assign'](_0x20fc4a,{'captchaResponse':_0x2c40b6}),Object['assign'](_0x20fc4a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x20fc4a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x20fc4a;}async function xi(_0x3dea00,_0x7f81cd,_0x1145ba,_0x1b75fc,_0x2dcbb1){var _0x47eaac;if((_0x47eaac=_0x3dea00['_getRecaptchaConfig']())!=null&&_0x47eaac['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3bd0cb=await kr(_0x3dea00,_0x7f81cd,_0x1145ba,_0x1145ba==='getOobCode');return _0x1b75fc(_0x3dea00,_0x3bd0cb);}else return _0x1b75fc(_0x3dea00,_0x7f81cd)['catch'](async _0x1ada0c=>{if(_0x1ada0c['code']==='auth/missing-recaptcha-token'){console['log'](_0x1145ba+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x41762a=await kr(_0x3dea00,_0x7f81cd,_0x1145ba,_0x1145ba==='getOobCode');return _0x1b75fc(_0x3dea00,_0x41762a);}else return Promise['reject'](_0x1ada0c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x3e3212,_0x3edec2){const _0x1426c0=Hi(_0x3e3212,'auth');if(_0x1426c0['isInitialized']()){const _0x3cbb63=_0x1426c0['getImmediate'](),_0x360299=_0x1426c0['getOptions']();if(xe(_0x360299,_0x3edec2??{}))return _0x3cbb63;Y(_0x3cbb63,'already-initialized');}return _0x1426c0['initialize']({'options':_0x3edec2});}function Hf(_0x1a8464,_0x553b24){const _0xf24619=(_0x553b24==null?void 0x0:_0x553b24['persistence'])||[],_0x3b87bf=(Array['isArray'](_0xf24619)?_0xf24619:[_0xf24619])['map'](ie);_0x553b24!=null&&_0x553b24['errorMap']&&_0x1a8464['_updateErrorMap'](_0x553b24['errorMap']),_0x1a8464['_initializeWithPersistence'](_0x3b87bf,_0x553b24==null?void 0x0:_0x553b24['popupRedirectResolver']);}function $f(_0x583672,_0x548c07,_0x6bd760){const _0x59f27d=Ke(_0x583672);m(/^https?:\/\//['test'](_0x548c07),_0x59f27d,'invalid-emulator-scheme');const _0x1a8971=!0x1,_0x5da615=Ua(_0x548c07),{host:_0x4469b3,port:_0x5be51c}=Gf(_0x548c07),_0x5b53b8=_0x5be51c===null?'':':'+_0x5be51c,_0x4d3978={'url':_0x5da615+'//'+_0x4469b3+_0x5b53b8+'/'},_0x1d3592=Object['freeze']({'host':_0x4469b3,'port':_0x5be51c,'protocol':_0x5da615['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1a8971})});if(!_0x59f27d['_canInitEmulator']){m(_0x59f27d['config']['emulator']&&_0x59f27d['emulatorConfig'],_0x59f27d,'emulator-config-failed'),m(xe(_0x4d3978,_0x59f27d['config']['emulator'])&&xe(_0x1d3592,_0x59f27d['emulatorConfig']),_0x59f27d,'emulator-config-failed');return;}_0x59f27d['config']['emulator']=_0x4d3978,_0x59f27d['emulatorConfig']=_0x1d3592,_0x59f27d['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x4469b3)?Qr(_0x5da615+'//'+_0x4469b3+_0x5b53b8):qf();}function Ua(_0x5c4de5){const _0xf9214f=_0x5c4de5['indexOf'](':');return _0xf9214f<0x0?'':_0x5c4de5['substr'](0x0,_0xf9214f+0x1);}function Gf(_0x4b6091){const _0x569522=Ua(_0x4b6091),_0x390931=/(\/\/)?([^?#/]+)/['exec'](_0x4b6091['substr'](_0x569522['length']));if(!_0x390931)return{'host':'','port':null};const _0x24fcbe=_0x390931[0x2]['split']('@')['pop']()||'',_0x147c13=/^(\[[^\]]+\])(:|$)/['exec'](_0x24fcbe);if(_0x147c13){const _0x4c145d=_0x147c13[0x1];return{'host':_0x4c145d,'port':Pr(_0x24fcbe['substr'](_0x4c145d['length']+0x1))};}else{const [_0x454007,_0x58500d]=_0x24fcbe['split'](':');return{'host':_0x454007,'port':Pr(_0x58500d)};}}function Pr(_0x13e0ed){if(!_0x13e0ed)return null;const _0x32e659=Number(_0x13e0ed);return isNaN(_0x32e659)?null:_0x32e659;}function qf(){function _0x1e09c2(){const _0x4c2e34=document['createElement']('p'),_0x44ec86=_0x4c2e34['style'];_0x4c2e34['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x44ec86['position']='fixed',_0x44ec86['width']='100%',_0x44ec86['backgroundColor']='#ffffff',_0x44ec86['border']='.1em\x20solid\x20#000000',_0x44ec86['color']='#b50000',_0x44ec86['bottom']='0px',_0x44ec86['left']='0px',_0x44ec86['margin']='0px',_0x44ec86['zIndex']='10000',_0x44ec86['textAlign']='center',_0x4c2e34['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4c2e34);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1e09c2):_0x1e09c2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5bd343,_0x434f59){this['providerId']=_0x5bd343,this['signInMethod']=_0x434f59;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2956db){return ne('not\x20implemented');}['_linkToIdToken'](_0xd8ae2b,_0x1a825b){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x471cfd){return ne('not\x20implemented');}}async function zf(_0x38b808,_0x3e9f43){return Pe(_0x38b808,'POST','/v1/accounts:signUp',_0x3e9f43);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x1c89d8,_0x291e46){return en(_0x1c89d8,'POST','/v1/accounts:signInWithPassword',ke(_0x1c89d8,_0x291e46));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x23e3e9,_0xd6b33b){return en(_0x23e3e9,'POST','/v1/accounts:signInWithEmailLink',ke(_0x23e3e9,_0xd6b33b));}async function Yf(_0x3a4db0,_0x29ac55){return en(_0x3a4db0,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3a4db0,_0x29ac55));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0xcf6b36,_0x201e29,_0x3c624c,_0x3bccd9=null){super('password',_0x3c624c),this['_email']=_0xcf6b36,this['_password']=_0x201e29,this['_tenantId']=_0x3bccd9;}static['_fromEmailAndPassword'](_0x4e7e15,_0x4e1153){return new $t(_0x4e7e15,_0x4e1153,'password');}static['_fromEmailAndCode'](_0x208a09,_0x2fd866,_0x15ccbc=null){return new $t(_0x208a09,_0x2fd866,'emailLink',_0x15ccbc);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x719984){const _0x4ce84f=typeof _0x719984=='string'?JSON['parse'](_0x719984):_0x719984;if(_0x4ce84f!=null&&_0x4ce84f['email']&&(_0x4ce84f!=null&&_0x4ce84f['password'])){if(_0x4ce84f['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4ce84f['email'],_0x4ce84f['password']);if(_0x4ce84f['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4ce84f['email'],_0x4ce84f['password'],_0x4ce84f['tenantId']);}return null;}async['_getIdTokenResponse'](_0x5a59cf){switch(this['signInMethod']){case'password':const _0x4cc178={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5a59cf,_0x4cc178,'signInWithPassword',jf);case'emailLink':return Kf(_0x5a59cf,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5a59cf,'internal-error');}}async['_linkToIdToken'](_0x164386,_0x374089){switch(this['signInMethod']){case'password':const _0x1fa9de={'idToken':_0x374089,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x164386,_0x1fa9de,'signUpPassword',zf);case'emailLink':return Yf(_0x164386,{'idToken':_0x374089,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x164386,'internal-error');}}['_getReauthenticationResolver'](_0x251623){return this['_getIdTokenResponse'](_0x251623);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x13145e,_0x7592cd){return en(_0x13145e,'POST','/v1/accounts:signInWithIdp',ke(_0x13145e,_0x7592cd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0xcecfa5){const _0x13a10e=new $e(_0xcecfa5['providerId'],_0xcecfa5['signInMethod']);return _0xcecfa5['idToken']||_0xcecfa5['accessToken']?(_0xcecfa5['idToken']&&(_0x13a10e['idToken']=_0xcecfa5['idToken']),_0xcecfa5['accessToken']&&(_0x13a10e['accessToken']=_0xcecfa5['accessToken']),_0xcecfa5['nonce']&&!_0xcecfa5['pendingToken']&&(_0x13a10e['nonce']=_0xcecfa5['nonce']),_0xcecfa5['pendingToken']&&(_0x13a10e['pendingToken']=_0xcecfa5['pendingToken'])):_0xcecfa5['oauthToken']&&_0xcecfa5['oauthTokenSecret']?(_0x13a10e['accessToken']=_0xcecfa5['oauthToken'],_0x13a10e['secret']=_0xcecfa5['oauthTokenSecret']):Y('argument-error'),_0x13a10e;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1402d3){const _0x4dd43c=typeof _0x1402d3=='string'?JSON['parse'](_0x1402d3):_0x1402d3,{providerId:_0x1246e8,signInMethod:_0x5c3110,..._0x23c679}=_0x4dd43c;if(!_0x1246e8||!_0x5c3110)return null;const _0x2dcea3=new $e(_0x1246e8,_0x5c3110);return _0x2dcea3['idToken']=_0x23c679['idToken']||void 0x0,_0x2dcea3['accessToken']=_0x23c679['accessToken']||void 0x0,_0x2dcea3['secret']=_0x23c679['secret'],_0x2dcea3['nonce']=_0x23c679['nonce'],_0x2dcea3['pendingToken']=_0x23c679['pendingToken']||null,_0x2dcea3;}['_getIdTokenResponse'](_0x4f9c7f){const _0x523b30=this['buildRequest']();return nt(_0x4f9c7f,_0x523b30);}['_linkToIdToken'](_0xc85536,_0xa79fb9){const _0xa823aa=this['buildRequest']();return _0xa823aa['idToken']=_0xa79fb9,nt(_0xc85536,_0xa823aa);}['_getReauthenticationResolver'](_0x3601dd){const _0x1727a3=this['buildRequest']();return _0x1727a3['autoCreate']=!0x1,nt(_0x3601dd,_0x1727a3);}['buildRequest'](){const _0x56431d={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x56431d['pendingToken']=this['pendingToken'];else{const _0x5955f9={};this['idToken']&&(_0x5955f9['id_token']=this['idToken']),this['accessToken']&&(_0x5955f9['access_token']=this['accessToken']),this['secret']&&(_0x5955f9['oauth_token_secret']=this['secret']),_0x5955f9['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5955f9['nonce']=this['nonce']),_0x56431d['postBody']=ut(_0x5955f9);}return _0x56431d;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x341e4c){switch(_0x341e4c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x3354f2){const _0x56e8b4=Ct(Tt(_0x3354f2))['link'],_0x449fb5=_0x56e8b4?Ct(Tt(_0x56e8b4))['deep_link_id']:null,_0x178eb9=Ct(Tt(_0x3354f2))['deep_link_id'];return(_0x178eb9?Ct(Tt(_0x178eb9))['link']:null)||_0x178eb9||_0x449fb5||_0x56e8b4||_0x3354f2;}class Rs{constructor(_0x3cfa20){const _0x11064e=Ct(Tt(_0x3cfa20)),_0x58b35b=_0x11064e['apiKey']??null,_0x2f21dc=_0x11064e['oobCode']??null,_0x416931=Jf(_0x11064e['mode']??null);m(_0x58b35b&&_0x2f21dc&&_0x416931,'argument-error'),this['apiKey']=_0x58b35b,this['operation']=_0x416931,this['code']=_0x2f21dc,this['continueUrl']=_0x11064e['continueUrl']??null,this['languageCode']=_0x11064e['lang']??null,this['tenantId']=_0x11064e['tenantId']??null;}static['parseLink'](_0x49cb79){const _0x3b2126=Xf(_0x49cb79);try{return new Rs(_0x3b2126);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x45520e,_0x39170c){return $t['_fromEmailAndPassword'](_0x45520e,_0x39170c);}static['credentialWithLink'](_0x4ed887,_0x2672e3){const _0x152451=Rs['parseLink'](_0x2672e3);return m(_0x152451,'argument-error'),$t['_fromEmailAndCode'](_0x4ed887,_0x152451['code'],_0x152451['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x413a35){this['providerId']=_0x413a35,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x260172){this['defaultLanguageCode']=_0x260172;}['setCustomParameters'](_0x3065ec){return this['customParameters']=_0x3065ec,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x24f6b8){return this['scopes']['includes'](_0x24f6b8)||this['scopes']['push'](_0x24f6b8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x59531f){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x59531f});}static['credentialFromResult'](_0x44db38){return ue['credentialFromTaggedObject'](_0x44db38);}static['credentialFromError'](_0x18b9ea){return ue['credentialFromTaggedObject'](_0x18b9ea['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2f0b48}){if(!_0x2f0b48||!('oauthAccessToken'in _0x2f0b48)||!_0x2f0b48['oauthAccessToken'])return null;try{return ue['credential'](_0x2f0b48['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x2134f3,_0x433d90){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x2134f3,'accessToken':_0x433d90});}static['credentialFromResult'](_0x550a2b){return de['credentialFromTaggedObject'](_0x550a2b);}static['credentialFromError'](_0x1c90e8){return de['credentialFromTaggedObject'](_0x1c90e8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x382c64}){if(!_0x382c64)return null;const {oauthIdToken:_0x52c43f,oauthAccessToken:_0x4af6fa}=_0x382c64;if(!_0x52c43f&&!_0x4af6fa)return null;try{return de['credential'](_0x52c43f,_0x4af6fa);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x38a784){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x38a784});}static['credentialFromResult'](_0x5a50f4){return fe['credentialFromTaggedObject'](_0x5a50f4);}static['credentialFromError'](_0x3dffe8){return fe['credentialFromTaggedObject'](_0x3dffe8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x34ac39}){if(!_0x34ac39||!('oauthAccessToken'in _0x34ac39)||!_0x34ac39['oauthAccessToken'])return null;try{return fe['credential'](_0x34ac39['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x5546d4,_0x5af95a){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x5546d4,'oauthTokenSecret':_0x5af95a});}static['credentialFromResult'](_0x3fffda){return pe['credentialFromTaggedObject'](_0x3fffda);}static['credentialFromError'](_0x35ab59){return pe['credentialFromTaggedObject'](_0x35ab59['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x195204}){if(!_0x195204)return null;const {oauthAccessToken:_0x31eb3e,oauthTokenSecret:_0x123f95}=_0x195204;if(!_0x31eb3e||!_0x123f95)return null;try{return pe['credential'](_0x31eb3e,_0x123f95);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3a09f8,_0x37957d){return en(_0x3a09f8,'POST','/v1/accounts:signUp',ke(_0x3a09f8,_0x37957d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x50a153){this['user']=_0x50a153['user'],this['providerId']=_0x50a153['providerId'],this['_tokenResponse']=_0x50a153['_tokenResponse'],this['operationType']=_0x50a153['operationType'];}static async['_fromIdTokenResponse'](_0x539e42,_0x21e850,_0x27a598,_0x51847c=!0x1){const _0x267c28=await j['_fromIdTokenResponse'](_0x539e42,_0x27a598,_0x51847c),_0x448a5a=Nr(_0x27a598);return new Ge({'user':_0x267c28,'providerId':_0x448a5a,'_tokenResponse':_0x27a598,'operationType':_0x21e850});}static async['_forOperation'](_0xb5ef7,_0x1d4022,_0x1573af){await _0xb5ef7['_updateTokensIfNecessary'](_0x1573af,!0x0);const _0x2104a0=Nr(_0x1573af);return new Ge({'user':_0xb5ef7,'providerId':_0x2104a0,'_tokenResponse':_0x1573af,'operationType':_0x1d4022});}}function Nr(_0x4fdf78){return _0x4fdf78['providerId']?_0x4fdf78['providerId']:'phoneNumber'in _0x4fdf78?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x225966,_0x487025,_0x234833,_0x343822){super(_0x487025['code'],_0x487025['message']),this['operationType']=_0x234833,this['user']=_0x343822,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x225966['name'],'tenantId':_0x225966['tenantId']??void 0x0,'_serverResponse':_0x487025['customData']['_serverResponse'],'operationType':_0x234833};}static['_fromErrorAndOperation'](_0x55acf9,_0x292bd6,_0x13060e,_0x50a0ae){return new On(_0x55acf9,_0x292bd6,_0x13060e,_0x50a0ae);}}function Ba(_0x3bbb18,_0x503d2f,_0x4e41d3,_0x23e02e){return(_0x503d2f==='reauthenticate'?_0x4e41d3['_getReauthenticationResolver'](_0x3bbb18):_0x4e41d3['_getIdTokenResponse'](_0x3bbb18))['catch'](_0x52ee7a=>{throw _0x52ee7a['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3bbb18,_0x52ee7a,_0x503d2f,_0x23e02e):_0x52ee7a;});}async function ep(_0x32957f,_0x3f54e4,_0x16c712=!0x1){const _0x5a006d=await Ht(_0x32957f,_0x3f54e4['_linkToIdToken'](_0x32957f['auth'],await _0x32957f['getIdToken']()),_0x16c712);return Ge['_forOperation'](_0x32957f,'link',_0x5a006d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x53d918,_0x147ef9,_0x532b82=!0x1){const {auth:_0x29b7a6}=_0x53d918;if($(_0x29b7a6['app']))return Promise['reject'](re(_0x29b7a6));const _0x49c073='reauthenticate';try{const _0x1012e7=await Ht(_0x53d918,Ba(_0x29b7a6,_0x49c073,_0x147ef9,_0x53d918),_0x532b82);m(_0x1012e7['idToken'],_0x29b7a6,'internal-error');const _0x2bbbc2=Ts(_0x1012e7['idToken']);m(_0x2bbbc2,_0x29b7a6,'internal-error');const {sub:_0x295ac1}=_0x2bbbc2;return m(_0x53d918['uid']===_0x295ac1,_0x29b7a6,'user-mismatch'),Ge['_forOperation'](_0x53d918,_0x49c073,_0x1012e7);}catch(_0x58d957){throw(_0x58d957==null?void 0x0:_0x58d957['code'])==='auth/user-not-found'&&Y(_0x29b7a6,'user-mismatch'),_0x58d957;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x19d3e0,_0x471689,_0x18ede1=!0x1){if($(_0x19d3e0['app']))return Promise['reject'](re(_0x19d3e0));const _0x3cd4ab='signIn',_0x5230d6=await Ba(_0x19d3e0,_0x3cd4ab,_0x471689),_0x4de7d2=await Ge['_fromIdTokenResponse'](_0x19d3e0,_0x3cd4ab,_0x5230d6);return _0x18ede1||await _0x19d3e0['_updateCurrentUser'](_0x4de7d2['user']),_0x4de7d2;}async function np(_0x255572,_0x4f009f){return Va(Ke(_0x255572),_0x4f009f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4def4c){const _0x7ba586=Ke(_0x4def4c);_0x7ba586['_getPasswordPolicyInternal']()&&await _0x7ba586['_updatePasswordPolicy']();}async function L_(_0x4aa559,_0x31a9c4,_0x294d77){if($(_0x4aa559['app']))return Promise['reject'](re(_0x4aa559));const _0xf7c209=Ke(_0x4aa559),_0x4d96f1=await xi(_0xf7c209,{'returnSecureToken':!0x0,'email':_0x31a9c4,'password':_0x294d77,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x302e9c=>{throw _0x302e9c['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4aa559),_0x302e9c;}),_0x57929f=await Ge['_fromIdTokenResponse'](_0xf7c209,'signIn',_0x4d96f1);return await _0xf7c209['_updateCurrentUser'](_0x57929f['user']),_0x57929f;}function x_(_0x43ac24,_0x1d17b2,_0x4f4040){return $(_0x43ac24['app'])?Promise['reject'](re(_0x43ac24)):np(P(_0x43ac24),yt['credential'](_0x1d17b2,_0x4f4040))['catch'](async _0x38682a=>{throw _0x38682a['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x43ac24),_0x38682a;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x11ec7d,_0x22f399){return P(_0x11ec7d)['setPersistence'](_0x22f399);}function ip(_0x121e3c,_0x20a317,_0x122756,_0x37c51a){return P(_0x121e3c)['onIdTokenChanged'](_0x20a317,_0x122756,_0x37c51a);}function sp(_0x7c8356,_0x5ca502,_0x2d613d){return P(_0x7c8356)['beforeAuthStateChanged'](_0x5ca502,_0x2d613d);}function U_(_0x4b20e1,_0x54c999,_0x2f86d0,_0x2c6b12){return P(_0x4b20e1)['onAuthStateChanged'](_0x54c999,_0x2f86d0,_0x2c6b12);}function W_(_0x16a6ad){return P(_0x16a6ad)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4a7f73,_0x465fca){this['storageRetriever']=_0x4a7f73,this['type']=_0x465fca;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x29e1fa,_0x441395){return this['storage']['setItem'](_0x29e1fa,JSON['stringify'](_0x441395)),Promise['resolve']();}['_get'](_0xeebef4){const _0x41abeb=this['storage']['getItem'](_0xeebef4);return Promise['resolve'](_0x41abeb?JSON['parse'](_0x41abeb):null);}['_remove'](_0x896bba){return this['storage']['removeItem'](_0x896bba),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1851af,_0x146691)=>this['onStorageEvent'](_0x1851af,_0x146691),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x25b772){for(const _0x562958 of Object['keys'](this['listeners'])){const _0x1a289e=this['storage']['getItem'](_0x562958),_0x41e089=this['localCache'][_0x562958];_0x1a289e!==_0x41e089&&_0x25b772(_0x562958,_0x41e089,_0x1a289e);}}['onStorageEvent'](_0x3309b0,_0x1988b5=!0x1){if(!_0x3309b0['key']){this['forAllChangedKeys']((_0x32a455,_0x9c616b,_0x433159)=>{this['notifyListeners'](_0x32a455,_0x433159);});return;}const _0x117607=_0x3309b0['key'];_0x1988b5?this['detachListener']():this['stopPolling']();const _0x1bc8cf=()=>{const _0x3202d8=this['storage']['getItem'](_0x117607);!_0x1988b5&&this['localCache'][_0x117607]===_0x3202d8||this['notifyListeners'](_0x117607,_0x3202d8);},_0x575ffb=this['storage']['getItem'](_0x117607);Af()&&_0x575ffb!==_0x3309b0['newValue']&&_0x3309b0['newValue']!==_0x3309b0['oldValue']?setTimeout(_0x1bc8cf,op):_0x1bc8cf();}['notifyListeners'](_0x225437,_0x451b50){this['localCache'][_0x225437]=_0x451b50;const _0x25b7ee=this['listeners'][_0x225437];if(_0x25b7ee){for(const _0x43728a of Array['from'](_0x25b7ee))_0x43728a(_0x451b50&&JSON['parse'](_0x451b50));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2f3bda,_0x59f787,_0x225f33)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2f3bda,'oldValue':_0x59f787,'newValue':_0x225f33}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x5e0521,_0x20e0ea){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x5e0521]||(this['listeners'][_0x5e0521]=new Set(),this['localCache'][_0x5e0521]=this['storage']['getItem'](_0x5e0521)),this['listeners'][_0x5e0521]['add'](_0x20e0ea);}['_removeListener'](_0x44c604,_0x5e7890){this['listeners'][_0x44c604]&&(this['listeners'][_0x44c604]['delete'](_0x5e7890),this['listeners'][_0x44c604]['size']===0x0&&delete this['listeners'][_0x44c604]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3f25a0,_0x2c551b){await super['_set'](_0x3f25a0,_0x2c551b),this['localCache'][_0x3f25a0]=JSON['stringify'](_0x2c551b);}async['_get'](_0x41a16d){const _0x1d25f6=await super['_get'](_0x41a16d);return this['localCache'][_0x41a16d]=JSON['stringify'](_0x1d25f6),_0x1d25f6;}async['_remove'](_0x1b3cae){await super['_remove'](_0x1b3cae),delete this['localCache'][_0x1b3cae];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4b92d7,_0x49bb23){}['_removeListener'](_0x569985,_0x241cd6){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x79e17f){return Promise['all'](_0x79e17f['map'](async _0x56f66d=>{try{return{'fulfilled':!0x0,'value':await _0x56f66d};}catch(_0x736256){return{'fulfilled':!0x1,'reason':_0x736256};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x477f80){this['eventTarget']=_0x477f80,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x531e2b){const _0x3258e9=this['receivers']['find'](_0x5135b9=>_0x5135b9['isListeningto'](_0x531e2b));if(_0x3258e9)return _0x3258e9;const _0x369b43=new Xn(_0x531e2b);return this['receivers']['push'](_0x369b43),_0x369b43;}['isListeningto'](_0x24ed40){return this['eventTarget']===_0x24ed40;}async['handleEvent'](_0x17343e){const _0x18f662=_0x17343e,{eventId:_0x59e159,eventType:_0x21a0a8,data:_0x4b74f8}=_0x18f662['data'],_0x481581=this['handlersMap'][_0x21a0a8];if(!(_0x481581!=null&&_0x481581['size']))return;_0x18f662['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x59e159,'eventType':_0x21a0a8});const _0x46b8dc=Array['from'](_0x481581)['map'](async _0x41bca5=>_0x41bca5(_0x18f662['origin'],_0x4b74f8)),_0x19c3f5=await cp(_0x46b8dc);_0x18f662['ports'][0x0]['postMessage']({'status':'done','eventId':_0x59e159,'eventType':_0x21a0a8,'response':_0x19c3f5});}['_subscribe'](_0x641c66,_0x51def7){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x641c66]||(this['handlersMap'][_0x641c66]=new Set()),this['handlersMap'][_0x641c66]['add'](_0x51def7);}['_unsubscribe'](_0x1adf00,_0x25324d){this['handlersMap'][_0x1adf00]&&_0x25324d&&this['handlersMap'][_0x1adf00]['delete'](_0x25324d),(!_0x25324d||this['handlersMap'][_0x1adf00]['size']===0x0)&&delete this['handlersMap'][_0x1adf00],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x222271='',_0x453953=0xa){let _0x1aed2d='';for(let _0xd2cbd8=0x0;_0xd2cbd8<_0x453953;_0xd2cbd8++)_0x1aed2d+=Math['floor'](Math['random']()*0xa);return _0x222271+_0x1aed2d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x3f2e0a){this['target']=_0x3f2e0a,this['handlers']=new Set();}['removeMessageHandler'](_0x380dd6){_0x380dd6['messageChannel']&&(_0x380dd6['messageChannel']['port1']['removeEventListener']('message',_0x380dd6['onMessage']),_0x380dd6['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x380dd6);}async['_send'](_0x53f6a2,_0x6edfa2,_0x261134=0x32){const _0x4bd228=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4bd228)throw new Error('connection_unavailable');let _0x1e0ee8,_0x6c640f;return new Promise((_0x2596f4,_0x111c17)=>{const _0x38882d=As('',0x14);_0x4bd228['port1']['start']();const _0x10ec47=setTimeout(()=>{_0x111c17(new Error('unsupported_event'));},_0x261134);_0x6c640f={'messageChannel':_0x4bd228,'onMessage'(_0x38134f){const _0x85ff02=_0x38134f;if(_0x85ff02['data']['eventId']===_0x38882d)switch(_0x85ff02['data']['status']){case'ack':clearTimeout(_0x10ec47),_0x1e0ee8=setTimeout(()=>{_0x111c17(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1e0ee8),_0x2596f4(_0x85ff02['data']['response']);break;default:clearTimeout(_0x10ec47),clearTimeout(_0x1e0ee8),_0x111c17(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x6c640f),_0x4bd228['port1']['addEventListener']('message',_0x6c640f['onMessage']),this['target']['postMessage']({'eventType':_0x53f6a2,'eventId':_0x38882d,'data':_0x6edfa2},[_0x4bd228['port2']]);})['finally'](()=>{_0x6c640f&&this['removeMessageHandler'](_0x6c640f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x120177){Z()['location']['href']=_0x120177;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1cc2f6;return((_0x1cc2f6=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1cc2f6['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0xac18d6){this['request']=_0xac18d6;}['toPromise'](){return new Promise((_0x3eb842,_0x27113b)=>{this['request']['addEventListener']('success',()=>{_0x3eb842(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x27113b(this['request']['error']);});});}}function Zn(_0x414913,_0x3b9c15){return _0x414913['transaction']([Mn],_0x3b9c15?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x54a8d0=indexedDB['deleteDatabase'](Ka);return new nn(_0x54a8d0)['toPromise']();}function Qa(){const _0x2a8620=indexedDB['open'](Ka,pp);return new Promise((_0x5ca914,_0x5f3b89)=>{_0x2a8620['addEventListener']('error',()=>{_0x5f3b89(_0x2a8620['error']);}),_0x2a8620['addEventListener']('upgradeneeded',()=>{const _0x23374e=_0x2a8620['result'];try{_0x23374e['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x31e497){_0x5f3b89(_0x31e497);}}),_0x2a8620['addEventListener']('success',async()=>{const _0x2e3e6d=_0x2a8620['result'];_0x2e3e6d['objectStoreNames']['contains'](Mn)?_0x5ca914(_0x2e3e6d):(_0x2e3e6d['close'](),await _p(),_0x5ca914(await Qa()));});});}async function Or(_0x1fd29c,_0x4bce0d,_0x321b11){const _0x3beeab=Zn(_0x1fd29c,!0x0)['put']({[Ya]:_0x4bce0d,'value':_0x321b11});return new nn(_0x3beeab)['toPromise']();}async function gp(_0x2ca326,_0x22ab34){const _0x3525cc=Zn(_0x2ca326,!0x1)['get'](_0x22ab34),_0x2da443=await new nn(_0x3525cc)['toPromise']();return _0x2da443===void 0x0?null:_0x2da443['value'];}function Dr(_0x59cdd4,_0x243b7d){const _0x38014e=Zn(_0x59cdd4,!0x0)['delete'](_0x243b7d);return new nn(_0x38014e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5e922a){let _0x4f53c2=0x0;for(;;)try{const _0x16146b=await this['_openDb']();return await _0x5e922a(_0x16146b);}catch(_0x1ec014){if(_0x4f53c2++>yp)throw _0x1ec014;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x45500b,_0x7e1fec)=>({'keyProcessed':(await this['_poll']())['includes'](_0x7e1fec['key'])})),this['receiver']['_subscribe']('ping',async(_0x22961,_0x275a1d)=>['keyChanged']);}async['initializeSender'](){var _0x5995fa,_0x5933df;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x33e175=await this['sender']['_send']('ping',{},0x320);_0x33e175&&(_0x5995fa=_0x33e175[0x0])!=null&&_0x5995fa['fulfilled']&&(_0x5933df=_0x33e175[0x0])!=null&&_0x5933df['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2a89a6){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2a89a6},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x43b311=>{await Or(_0x43b311,Dn,'1'),await Dr(_0x43b311,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x47e01e){this['pendingWrites']++;try{await _0x47e01e();}finally{this['pendingWrites']--;}}async['_set'](_0x3aaf86,_0x28aa4f){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1903a5=>Or(_0x1903a5,_0x3aaf86,_0x28aa4f)),this['localCache'][_0x3aaf86]=_0x28aa4f,this['notifyServiceWorker'](_0x3aaf86)));}async['_get'](_0x252f60){const _0x30d69c=await this['_withRetries'](_0x49cdb6=>gp(_0x49cdb6,_0x252f60));return this['localCache'][_0x252f60]=_0x30d69c,_0x30d69c;}async['_remove'](_0x2ed0ea){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x212e5a=>Dr(_0x212e5a,_0x2ed0ea)),delete this['localCache'][_0x2ed0ea],this['notifyServiceWorker'](_0x2ed0ea)));}async['_poll'](){const _0x2afddc=await this['_withRetries'](_0x155cdb=>{const _0x312ca9=Zn(_0x155cdb,!0x1)['getAll']();return new nn(_0x312ca9)['toPromise']();});if(!_0x2afddc)return[];if(this['pendingWrites']!==0x0)return[];const _0x169c32=[],_0x5b6d7c=new Set();if(_0x2afddc['length']!==0x0){for(const {fbase_key:_0x3da2c9,value:_0x559040}of _0x2afddc)_0x5b6d7c['add'](_0x3da2c9),JSON['stringify'](this['localCache'][_0x3da2c9])!==JSON['stringify'](_0x559040)&&(this['notifyListeners'](_0x3da2c9,_0x559040),_0x169c32['push'](_0x3da2c9));}for(const _0x458ccc of Object['keys'](this['localCache']))this['localCache'][_0x458ccc]&&!_0x5b6d7c['has'](_0x458ccc)&&(this['notifyListeners'](_0x458ccc,null),_0x169c32['push'](_0x458ccc));return _0x169c32;}['notifyListeners'](_0x103592,_0x1ec7ee){this['localCache'][_0x103592]=_0x1ec7ee;const _0x300c2c=this['listeners'][_0x103592];if(_0x300c2c){for(const _0x8b1b92 of Array['from'](_0x300c2c))_0x8b1b92(_0x1ec7ee);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2e1b65,_0x5b3598){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2e1b65]||(this['listeners'][_0x2e1b65]=new Set(),this['_get'](_0x2e1b65)),this['listeners'][_0x2e1b65]['add'](_0x5b3598);}['_removeListener'](_0x4d0d44,_0x2d776a){this['listeners'][_0x4d0d44]&&(this['listeners'][_0x4d0d44]['delete'](_0x2d776a),this['listeners'][_0x4d0d44]['size']===0x0&&delete this['listeners'][_0x4d0d44]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x594dfa,_0x40fb35){return _0x40fb35?ie(_0x40fb35):(m(_0x594dfa['_popupRedirectResolver'],_0x594dfa,'argument-error'),_0x594dfa['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x21dac2){super('custom','custom'),this['params']=_0x21dac2;}['_getIdTokenResponse'](_0x5b60d0){return nt(_0x5b60d0,this['_buildIdpRequest']());}['_linkToIdToken'](_0x3182bf,_0x2b5900){return nt(_0x3182bf,this['_buildIdpRequest'](_0x2b5900));}['_getReauthenticationResolver'](_0x36e8b9){return nt(_0x36e8b9,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x64a275){const _0x5a6bb7={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x64a275&&(_0x5a6bb7['idToken']=_0x64a275),_0x5a6bb7;}}function Ip(_0x1cc2fd){return Va(_0x1cc2fd['auth'],new ks(_0x1cc2fd),_0x1cc2fd['bypassAuthState']);}function wp(_0x25fa8f){const {auth:_0x274f19,user:_0x573dfc}=_0x25fa8f;return m(_0x573dfc,_0x274f19,'internal-error'),tp(_0x573dfc,new ks(_0x25fa8f),_0x25fa8f['bypassAuthState']);}async function Cp(_0xe3bccb){const {auth:_0x3a56c0,user:_0x1b31e9}=_0xe3bccb;return m(_0x1b31e9,_0x3a56c0,'internal-error'),ep(_0x1b31e9,new ks(_0xe3bccb),_0xe3bccb['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x2dff33,_0x272ddb,_0x14e9f3,_0x1ec7d4,_0x16db46=!0x1){this['auth']=_0x2dff33,this['resolver']=_0x14e9f3,this['user']=_0x1ec7d4,this['bypassAuthState']=_0x16db46,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x272ddb)?_0x272ddb:[_0x272ddb];}['execute'](){return new Promise(async(_0x3dd398,_0x414361)=>{this['pendingPromise']={'resolve':_0x3dd398,'reject':_0x414361};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4caa80){this['reject'](_0x4caa80);}});}async['onAuthEvent'](_0x51cd9e){const {urlResponse:_0x13a153,sessionId:_0x14b6ee,postBody:_0x195c87,tenantId:_0x5698cd,error:_0x228e80,type:_0x32a36a}=_0x51cd9e;if(_0x228e80){this['reject'](_0x228e80);return;}const _0x1123c1={'auth':this['auth'],'requestUri':_0x13a153,'sessionId':_0x14b6ee,'tenantId':_0x5698cd||void 0x0,'postBody':_0x195c87||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x32a36a)(_0x1123c1));}catch(_0x2bd6d6){this['reject'](_0x2bd6d6);}}['onError'](_0x428484){this['reject'](_0x428484);}['getIdpTask'](_0x1b9b9c){switch(_0x1b9b9c){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x25ef23){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x25ef23),this['unregisterAndCleanUp']();}['reject'](_0x5c8a2c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5c8a2c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x288fdb,_0x244410,_0x11a0a2,_0x4c7619,_0x4d7a08){super(_0x288fdb,_0x244410,_0x4c7619,_0x4d7a08),this['provider']=_0x11a0a2,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1b584a=await this['execute']();return m(_0x1b584a,this['auth'],'internal-error'),_0x1b584a;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5eb486=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5eb486),this['authWindow']['associatedEvent']=_0x5eb486,this['resolver']['_originValidation'](this['auth'])['catch'](_0x580c69=>{this['reject'](_0x580c69);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3f4904=>{_0x3f4904||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xefc5e6;return((_0xefc5e6=this['authWindow'])==null?void 0x0:_0xefc5e6['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x143311=()=>{var _0x313255,_0x194410;if((_0x194410=(_0x313255=this['authWindow'])==null?void 0x0:_0x313255['window'])!=null&&_0x194410['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x143311,Tp['get']());};_0x143311();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x39faf1,_0x2d64c4,_0x499cf4=!0x1){super(_0x39faf1,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2d64c4,void 0x0,_0x499cf4),this['eventId']=null;}async['execute'](){let _0x23c837=hn['get'](this['auth']['_key']());if(!_0x23c837){try{const _0x497920=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x23c837=()=>Promise['resolve'](_0x497920);}catch(_0x4aa703){_0x23c837=()=>Promise['reject'](_0x4aa703);}hn['set'](this['auth']['_key'](),_0x23c837);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x23c837();}async['onAuthEvent'](_0x5b8f11){if(_0x5b8f11['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5b8f11);if(_0x5b8f11['type']==='unknown'){this['resolve'](null);return;}if(_0x5b8f11['eventId']){const _0x5f0275=await this['auth']['_redirectUserForId'](_0x5b8f11['eventId']);if(_0x5f0275)return this['user']=_0x5f0275,super['onAuthEvent'](_0x5b8f11);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x30907c,_0x1cd4d6){const _0x3ba75a=Pp(_0x1cd4d6),_0x2d2919=kp(_0x30907c);if(!await _0x2d2919['_isAvailable']())return!0x1;const _0x152dcd=await _0x2d2919['_get'](_0x3ba75a)==='true';return await _0x2d2919['_remove'](_0x3ba75a),_0x152dcd;}function Ap(_0x1717b8,_0x310e6e){hn['set'](_0x1717b8['_key'](),_0x310e6e);}function kp(_0x33af6c){return ie(_0x33af6c['_redirectPersistence']);}function Pp(_0x2d3fa8){return ln(Sp,_0x2d3fa8['config']['apiKey'],_0x2d3fa8['name']);}async function Np(_0x1ca317,_0xb5aa5b,_0x3c01c9=!0x1){if($(_0x1ca317['app']))return Promise['reject'](re(_0x1ca317));const _0x2dac3c=Ke(_0x1ca317),_0x48e191=Ep(_0x2dac3c,_0xb5aa5b),_0x2cbfe2=await new bp(_0x2dac3c,_0x48e191,_0x3c01c9)['execute']();return _0x2cbfe2&&!_0x3c01c9&&(delete _0x2cbfe2['user']['_redirectEventId'],await _0x2dac3c['_persistUserIfCurrent'](_0x2cbfe2['user']),await _0x2dac3c['_setRedirectUser'](null,_0xb5aa5b)),_0x2cbfe2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x13aca7){this['auth']=_0x13aca7,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x498ad4){this['consumers']['add'](_0x498ad4),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x498ad4)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x498ad4),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5c154e){this['consumers']['delete'](_0x5c154e);}['onEvent'](_0x100d5d){if(this['hasEventBeenHandled'](_0x100d5d))return!0x1;let _0x3ced23=!0x1;return this['consumers']['forEach'](_0x3c0665=>{this['isEventForConsumer'](_0x100d5d,_0x3c0665)&&(_0x3ced23=!0x0,this['sendToConsumer'](_0x100d5d,_0x3c0665),this['saveEventToCache'](_0x100d5d));}),this['hasHandledPotentialRedirect']||!Mp(_0x100d5d)||(this['hasHandledPotentialRedirect']=!0x0,_0x3ced23||(this['queuedRedirectEvent']=_0x100d5d,_0x3ced23=!0x0)),_0x3ced23;}['sendToConsumer'](_0x501bb8,_0x5685e6){var _0x222012;if(_0x501bb8['error']&&!Za(_0x501bb8)){const _0x2b1843=((_0x222012=_0x501bb8['error']['code'])==null?void 0x0:_0x222012['split']('auth/')[0x1])||'internal-error';_0x5685e6['onError'](X(this['auth'],_0x2b1843));}else _0x5685e6['onAuthEvent'](_0x501bb8);}['isEventForConsumer'](_0x1b88db,_0x52135a){const _0x1d5823=_0x52135a['eventId']===null||!!_0x1b88db['eventId']&&_0x1b88db['eventId']===_0x52135a['eventId'];return _0x52135a['filter']['includes'](_0x1b88db['type'])&&_0x1d5823;}['hasEventBeenHandled'](_0xfd7398){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0xfd7398));}['saveEventToCache'](_0x25f51){this['cachedEventUids']['add'](Mr(_0x25f51)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x2d1f49){return[_0x2d1f49['type'],_0x2d1f49['eventId'],_0x2d1f49['sessionId'],_0x2d1f49['tenantId']]['filter'](_0x52129d=>_0x52129d)['join']('-');}function Za({type:_0x1a399c,error:_0x570af9}){return _0x1a399c==='unknown'&&(_0x570af9==null?void 0x0:_0x570af9['code'])==='auth/no-auth-event';}function Mp(_0x59ae59){switch(_0x59ae59['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x59ae59);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x56fd10,_0x5dd5d6={}){return Pe(_0x56fd10,'GET','/v1/projects',_0x5dd5d6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x58b3cb){if(_0x58b3cb['config']['emulator'])return;const {authorizedDomains:_0x4308d2}=await Lp(_0x58b3cb);for(const _0x3cd451 of _0x4308d2)try{if(Wp(_0x3cd451))return;}catch{}Y(_0x58b3cb,'unauthorized-domain');}function Wp(_0x427b11){const _0x1ff34b=Mi(),{protocol:_0x54994c,hostname:_0x155f14}=new URL(_0x1ff34b);if(_0x427b11['startsWith']('chrome-extension://')){const _0xf5bcf3=new URL(_0x427b11);return _0xf5bcf3['hostname']===''&&_0x155f14===''?_0x54994c==='chrome-extension:'&&_0x427b11['replace']('chrome-extension://','')===_0x1ff34b['replace']('chrome-extension://',''):_0x54994c==='chrome-extension:'&&_0xf5bcf3['hostname']===_0x155f14;}if(!Fp['test'](_0x54994c))return!0x1;if(xp['test'](_0x427b11))return _0x155f14===_0x427b11;const _0x26c709=_0x427b11['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x26c709+'|'+_0x26c709+')$','i')['test'](_0x155f14);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0xe78f5=Z()['___jsl'];if(_0xe78f5!=null&&_0xe78f5['H']){for(const _0x19e1f6 of Object['keys'](_0xe78f5['H']))if(_0xe78f5['H'][_0x19e1f6]['r']=_0xe78f5['H'][_0x19e1f6]['r']||[],_0xe78f5['H'][_0x19e1f6]['L']=_0xe78f5['H'][_0x19e1f6]['L']||[],_0xe78f5['H'][_0x19e1f6]['r']=[..._0xe78f5['H'][_0x19e1f6]['L']],_0xe78f5['CP']){for(let _0x413f73=0x0;_0x413f73<_0xe78f5['CP']['length'];_0x413f73++)_0xe78f5['CP'][_0x413f73]=null;}}}function Vp(_0x226bc7){return new Promise((_0x283b47,_0x512f52)=>{var _0x57f3f6,_0x57e376,_0x431647;function _0x216a66(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x283b47(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x512f52(X(_0x226bc7,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x57e376=(_0x57f3f6=Z()['gapi'])==null?void 0x0:_0x57f3f6['iframes'])!=null&&_0x57e376['Iframe'])_0x283b47(gapi['iframes']['getContext']());else{if((_0x431647=Z()['gapi'])!=null&&_0x431647['load'])_0x216a66();else{const _0x1cffd6=Ff('iframefcb');return Z()[_0x1cffd6]=()=>{gapi['load']?_0x216a66():_0x512f52(X(_0x226bc7,'network-request-failed'));},xa(xf()+'?onload='+_0x1cffd6)['catch'](_0x244d85=>_0x512f52(_0x244d85));}}})['catch'](_0x8bf49a=>{throw un=null,_0x8bf49a;});}let un=null;function Hp(_0x13bb9e){return un=un||Vp(_0x13bb9e),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x2bf6c2){const _0x3944d9=_0x2bf6c2['config'];m(_0x3944d9['authDomain'],_0x2bf6c2,'auth-domain-config-required');const _0x3b40e2=_0x3944d9['emulator']?Cs(_0x3944d9,qp):'https://'+_0x2bf6c2['config']['authDomain']+'/'+Gp,_0x34b0c7={'apiKey':_0x3944d9['apiKey'],'appName':_0x2bf6c2['name'],'v':dt},_0x3034b1=jp['get'](_0x2bf6c2['config']['apiHost']);_0x3034b1&&(_0x34b0c7['eid']=_0x3034b1);const _0x2338ba=_0x2bf6c2['_getFrameworks']();return _0x2338ba['length']&&(_0x34b0c7['fw']=_0x2338ba['join'](',')),_0x3b40e2+'?'+ut(_0x34b0c7)['slice'](0x1);}async function Yp(_0x1339a2){const _0x5d4c8a=await Hp(_0x1339a2),_0x1d6976=Z()['gapi'];return m(_0x1d6976,_0x1339a2,'internal-error'),_0x5d4c8a['open']({'where':document['body'],'url':Kp(_0x1339a2),'messageHandlersFilter':_0x1d6976['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x10b9e7=>new Promise(async(_0xcce1e3,_0x5b3972)=>{await _0x10b9e7['restyle']({'setHideOnLeave':!0x1});const _0x4414da=X(_0x1339a2,'network-request-failed'),_0x59992e=Z()['setTimeout'](()=>{_0x5b3972(_0x4414da);},$p['get']());function _0x201a6e(){Z()['clearTimeout'](_0x59992e),_0xcce1e3(_0x10b9e7);}_0x10b9e7['ping'](_0x201a6e)['then'](_0x201a6e,()=>{_0x5b3972(_0x4414da);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x197e72){this['window']=_0x197e72,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x1d463b,_0x3590b6,_0xbdd268,_0x5a4cbe=Jp,_0x2de494=Xp){const _0x48b583=Math['max']((window['screen']['availHeight']-_0x2de494)/0x2,0x0)['toString'](),_0x4756d4=Math['max']((window['screen']['availWidth']-_0x5a4cbe)/0x2,0x0)['toString']();let _0x585f70='';const _0x4b0a5f={...Qp,'width':_0x5a4cbe['toString'](),'height':_0x2de494['toString'](),'top':_0x48b583,'left':_0x4756d4},_0x79e2ab=W()['toLowerCase']();_0xbdd268&&(_0x585f70=ka(_0x79e2ab)?Zp:_0xbdd268),Ra(_0x79e2ab)&&(_0x3590b6=_0x3590b6||e_,_0x4b0a5f['scrollbars']='yes');const _0x393dc6=Object['entries'](_0x4b0a5f)['reduce']((_0x1947df,[_0x35f753,_0x1c042a])=>''+_0x1947df+_0x35f753+'='+_0x1c042a+',','');if(Rf(_0x79e2ab)&&_0x585f70!=='_self')return n_(_0x3590b6||'',_0x585f70),new xr(null);const _0x529153=window['open'](_0x3590b6||'',_0x585f70,_0x393dc6);m(_0x529153,_0x1d463b,'popup-blocked');try{_0x529153['focus']();}catch{}return new xr(_0x529153);}function n_(_0x2c456d,_0x2e4370){const _0x4a87fb=document['createElement']('a');_0x4a87fb['href']=_0x2c456d,_0x4a87fb['target']=_0x2e4370;const _0x276018=document['createEvent']('MouseEvent');_0x276018['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x4a87fb['dispatchEvent'](_0x276018);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x26adac,_0x2c4dee,_0x113fe3,_0x186fec,_0x410349,_0xb6ac76){m(_0x26adac['config']['authDomain'],_0x26adac,'auth-domain-config-required'),m(_0x26adac['config']['apiKey'],_0x26adac,'invalid-api-key');const _0x470169={'apiKey':_0x26adac['config']['apiKey'],'appName':_0x26adac['name'],'authType':_0x113fe3,'redirectUrl':_0x186fec,'v':dt,'eventId':_0x410349};if(_0x2c4dee instanceof Wa){_0x2c4dee['setDefaultLanguage'](_0x26adac['languageCode']),_0x470169['providerId']=_0x2c4dee['providerId']||'',pn(_0x2c4dee['getCustomParameters']())||(_0x470169['customParameters']=JSON['stringify'](_0x2c4dee['getCustomParameters']()));for(const [_0x445d4c,_0x143b09]of Object['entries']({}))_0x470169[_0x445d4c]=_0x143b09;}if(_0x2c4dee instanceof tn){const _0x12fad4=_0x2c4dee['getScopes']()['filter'](_0x3077f2=>_0x3077f2!=='');_0x12fad4['length']>0x0&&(_0x470169['scopes']=_0x12fad4['join'](','));}_0x26adac['tenantId']&&(_0x470169['tid']=_0x26adac['tenantId']);const _0x5263e6=_0x470169;for(const _0x5b33d4 of Object['keys'](_0x5263e6))_0x5263e6[_0x5b33d4]===void 0x0&&delete _0x5263e6[_0x5b33d4];const _0x1f62a6=await _0x26adac['_getAppCheckToken'](),_0x2bfe17=_0x1f62a6?'#'+r_+'='+encodeURIComponent(_0x1f62a6):'';return o_(_0x26adac)+'?'+ut(_0x5263e6)['slice'](0x1)+_0x2bfe17;}function o_({config:_0x3c18d3}){return _0x3c18d3['emulator']?Cs(_0x3c18d3,s_):'https://'+_0x3c18d3['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x4ed82e,_0x193754,_0x39e785,_0x10b871){var _0x42221b;ce((_0x42221b=this['eventManagers'][_0x4ed82e['_key']()])==null?void 0x0:_0x42221b['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x6347bc=await Fr(_0x4ed82e,_0x193754,_0x39e785,Mi(),_0x10b871);return t_(_0x4ed82e,_0x6347bc,As());}async['_openRedirect'](_0x42a125,_0x2667ed,_0x125cc8,_0xc2c06f){await this['_originValidation'](_0x42a125);const _0x250b2c=await Fr(_0x42a125,_0x2667ed,_0x125cc8,Mi(),_0xc2c06f);return hp(_0x250b2c),new Promise(()=>{});}['_initialize'](_0x379ca8){const _0x4d4eb3=_0x379ca8['_key']();if(this['eventManagers'][_0x4d4eb3]){const {manager:_0xeed886,promise:_0x4b3330}=this['eventManagers'][_0x4d4eb3];return _0xeed886?Promise['resolve'](_0xeed886):(ce(_0x4b3330,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4b3330);}const _0x3b8e3e=this['initAndGetManager'](_0x379ca8);return this['eventManagers'][_0x4d4eb3]={'promise':_0x3b8e3e},_0x3b8e3e['catch'](()=>{delete this['eventManagers'][_0x4d4eb3];}),_0x3b8e3e;}async['initAndGetManager'](_0xb033b2){const _0x7dd071=await Yp(_0xb033b2),_0x3c13c0=new Dp(_0xb033b2);return _0x7dd071['register']('authEvent',_0x235795=>(m(_0x235795==null?void 0x0:_0x235795['authEvent'],_0xb033b2,'invalid-auth-event'),{'status':_0x3c13c0['onEvent'](_0x235795['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xb033b2['_key']()]={'manager':_0x3c13c0},this['iframes'][_0xb033b2['_key']()]=_0x7dd071,_0x3c13c0;}['_isIframeWebStorageSupported'](_0x5dbc2b,_0x3ac421){this['iframes'][_0x5dbc2b['_key']()]['send'](pi,{'type':pi},_0x38650f=>{var _0x3c6c00;const _0x2b0409=(_0x3c6c00=_0x38650f==null?void 0x0:_0x38650f[0x0])==null?void 0x0:_0x3c6c00[pi];_0x2b0409!==void 0x0&&_0x3ac421(!!_0x2b0409),Y(_0x5dbc2b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5b369e){const _0x20cb33=_0x5b369e['_key']();return this['originValidationPromises'][_0x20cb33]||(this['originValidationPromises'][_0x20cb33]=Up(_0x5b369e)),this['originValidationPromises'][_0x20cb33];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x40bbdb){this['auth']=_0x40bbdb,this['internalListeners']=new Map();}['getUid'](){var _0x10195e;return this['assertAuthConfigured'](),((_0x10195e=this['auth']['currentUser'])==null?void 0x0:_0x10195e['uid'])||null;}async['getToken'](_0x167d25){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x167d25)}:null;}['addAuthTokenListener'](_0x33a796){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x33a796))return;const _0x197ffa=this['auth']['onIdTokenChanged'](_0x21d55c=>{_0x33a796((_0x21d55c==null?void 0x0:_0x21d55c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x33a796,_0x197ffa),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2296bb){this['assertAuthConfigured']();const _0x290cd7=this['internalListeners']['get'](_0x2296bb);_0x290cd7&&(this['internalListeners']['delete'](_0x2296bb),_0x290cd7(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x131e5b){switch(_0x131e5b){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2cc542){st(new Fe('auth',(_0x2f202e,{options:_0x5a7ac4})=>{const _0x1f19f2=_0x2f202e['getProvider']('app')['getImmediate'](),_0x36e017=_0x2f202e['getProvider']('heartbeat'),_0x4a01e2=_0x2f202e['getProvider']('app-check-internal'),{apiKey:_0x4781bf,authDomain:_0x305bbe}=_0x1f19f2['options'];m(_0x4781bf&&!_0x4781bf['includes'](':'),'invalid-api-key',{'appName':_0x1f19f2['name']});const _0x406845={'apiKey':_0x4781bf,'authDomain':_0x305bbe,'clientPlatform':_0x2cc542,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2cc542)},_0x33201c=new Df(_0x1f19f2,_0x36e017,_0x4a01e2,_0x406845);return Hf(_0x33201c,_0x5a7ac4),_0x33201c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x15cf72,_0x3e9507,_0x30a56d)=>{_0x15cf72['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x17509d=>{const _0x11c302=Ke(_0x17509d['getProvider']('auth')['getImmediate']());return(_0x4f1108=>new l_(_0x4f1108))(_0x11c302);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2cc542)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x280cb5=>async _0x272206=>{const _0x388b89=_0x272206&&await _0x272206['getIdTokenResult'](),_0x5c0ec5=_0x388b89&&(new Date()['getTime']()-Date['parse'](_0x388b89['issuedAtTime']))/0x3e8;if(_0x5c0ec5&&_0x5c0ec5>f_)return;const _0x4d146e=_0x388b89==null?void 0x0:_0x388b89['token'];Br!==_0x4d146e&&(Br=_0x4d146e,await fetch(_0x280cb5,{'method':_0x4d146e?'POST':'DELETE','headers':_0x4d146e?{'Authorization':'Bearer\x20'+_0x4d146e}:{}}));};function B_(_0x14256c=Zr()){const _0x2102f5=Hi(_0x14256c,'auth');if(_0x2102f5['isInitialized']())return _0x2102f5['getImmediate']();const _0x16103d=Vf(_0x14256c,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x7d55d8=jr('authTokenSyncURL');if(_0x7d55d8&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x273311=new URL(_0x7d55d8,location['origin']);if(location['origin']===_0x273311['origin']){const _0xfc1d27=p_(_0x273311['toString']());sp(_0x16103d,_0xfc1d27,()=>_0xfc1d27(_0x16103d['currentUser'])),ip(_0x16103d,_0x3144c8=>_0xfc1d27(_0x3144c8));}}const _0x120ab8=qr('auth');return _0x120ab8&&$f(_0x16103d,'http://'+_0x120ab8),_0x16103d;}function __(){var _0x5bb505;return((_0x5bb505=document['getElementsByTagName']('head'))==null?void 0x0:_0x5bb505[0x0])??document;}Mf({'loadJS'(_0x5dab2f){return new Promise((_0xbfd7f1,_0x22c1e9)=>{const _0x2ac07b=document['createElement']('script');_0x2ac07b['setAttribute']('src',_0x5dab2f),_0x2ac07b['onload']=_0xbfd7f1,_0x2ac07b['onerror']=_0x4643a6=>{const _0x10ac4f=X('internal-error');_0x10ac4f['customData']=_0x4643a6,_0x22c1e9(_0x10ac4f);},_0x2ac07b['type']='text/javascript',_0x2ac07b['charset']='UTF-8',__()['appendChild'](_0x2ac07b);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};