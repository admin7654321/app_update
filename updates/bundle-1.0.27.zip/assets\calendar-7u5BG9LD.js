import{c as a6_0x578293}from'./index-Cg2v-83s.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const t=[['path',{'d':'M8\x202v4','key':'1cmpym'}],['path',{'d':'M16\x202v4','key':'4m81vk'}],['rect',{'width':'18','height':'18','x':'3','y':'4','rx':'2','key':'1hopcy'}],['path',{'d':'M3\x2010h18','key':'8toen8'}]],a=a6_0x578293('calendar',t);export{a as C};