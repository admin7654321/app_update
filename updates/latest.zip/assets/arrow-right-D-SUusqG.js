import{c as a3_0xb73a71}from'./index-Ick1AuSd.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const r=[['path',{'d':'M5\x2012h14','key':'1ays0h'}],['path',{'d':'m12\x205\x207\x207-7\x207','key':'xquz4c'}]],c=a3_0xb73a71('arrow-right',r);export{c as A};