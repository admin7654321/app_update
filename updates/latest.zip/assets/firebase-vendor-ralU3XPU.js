const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xa48f3f,_0x5e2280){if(!_0xa48f3f)throw ht(_0x5e2280);},ht=function(_0x1ae25a){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1ae25a);},Hr=function(_0x401107){const _0x308b00=[];let _0x29efe0=0x0;for(let _0x382fed=0x0;_0x382fed<_0x401107['length'];_0x382fed++){let _0x243237=_0x401107['charCodeAt'](_0x382fed);_0x243237<0x80?_0x308b00[_0x29efe0++]=_0x243237:_0x243237<0x800?(_0x308b00[_0x29efe0++]=_0x243237>>0x6|0xc0,_0x308b00[_0x29efe0++]=_0x243237&0x3f|0x80):(_0x243237&0xfc00)===0xd800&&_0x382fed+0x1<_0x401107['length']&&(_0x401107['charCodeAt'](_0x382fed+0x1)&0xfc00)===0xdc00?(_0x243237=0x10000+((_0x243237&0x3ff)<<0xa)+(_0x401107['charCodeAt'](++_0x382fed)&0x3ff),_0x308b00[_0x29efe0++]=_0x243237>>0x12|0xf0,_0x308b00[_0x29efe0++]=_0x243237>>0xc&0x3f|0x80,_0x308b00[_0x29efe0++]=_0x243237>>0x6&0x3f|0x80,_0x308b00[_0x29efe0++]=_0x243237&0x3f|0x80):(_0x308b00[_0x29efe0++]=_0x243237>>0xc|0xe0,_0x308b00[_0x29efe0++]=_0x243237>>0x6&0x3f|0x80,_0x308b00[_0x29efe0++]=_0x243237&0x3f|0x80);}return _0x308b00;},nc=function(_0x530ea3){const _0x273947=[];let _0x5e4123=0x0,_0x5124a5=0x0;for(;_0x5e4123<_0x530ea3['length'];){const _0xac7daa=_0x530ea3[_0x5e4123++];if(_0xac7daa<0x80)_0x273947[_0x5124a5++]=String['fromCharCode'](_0xac7daa);else{if(_0xac7daa>0xbf&&_0xac7daa<0xe0){const _0x255451=_0x530ea3[_0x5e4123++];_0x273947[_0x5124a5++]=String['fromCharCode']((_0xac7daa&0x1f)<<0x6|_0x255451&0x3f);}else{if(_0xac7daa>0xef&&_0xac7daa<0x16d){const _0x14bd45=_0x530ea3[_0x5e4123++],_0x535037=_0x530ea3[_0x5e4123++],_0x17e9f8=_0x530ea3[_0x5e4123++],_0xe846d6=((_0xac7daa&0x7)<<0x12|(_0x14bd45&0x3f)<<0xc|(_0x535037&0x3f)<<0x6|_0x17e9f8&0x3f)-0x10000;_0x273947[_0x5124a5++]=String['fromCharCode'](0xd800+(_0xe846d6>>0xa)),_0x273947[_0x5124a5++]=String['fromCharCode'](0xdc00+(_0xe846d6&0x3ff));}else{const _0x50d2d9=_0x530ea3[_0x5e4123++],_0x31114c=_0x530ea3[_0x5e4123++];_0x273947[_0x5124a5++]=String['fromCharCode']((_0xac7daa&0xf)<<0xc|(_0x50d2d9&0x3f)<<0x6|_0x31114c&0x3f);}}}}return _0x273947['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x1e3924,_0x9457b7){if(!Array['isArray'](_0x1e3924))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x314f04=_0x9457b7?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1b217f=[];for(let _0x43a2e9=0x0;_0x43a2e9<_0x1e3924['length'];_0x43a2e9+=0x3){const _0x10e5e0=_0x1e3924[_0x43a2e9],_0x2c4be6=_0x43a2e9+0x1<_0x1e3924['length'],_0x349263=_0x2c4be6?_0x1e3924[_0x43a2e9+0x1]:0x0,_0x116e1b=_0x43a2e9+0x2<_0x1e3924['length'],_0x40c0e9=_0x116e1b?_0x1e3924[_0x43a2e9+0x2]:0x0,_0x282195=_0x10e5e0>>0x2,_0x4e38e9=(_0x10e5e0&0x3)<<0x4|_0x349263>>0x4;let _0x35b9af=(_0x349263&0xf)<<0x2|_0x40c0e9>>0x6,_0x3cbb68=_0x40c0e9&0x3f;_0x116e1b||(_0x3cbb68=0x40,_0x2c4be6||(_0x35b9af=0x40)),_0x1b217f['push'](_0x314f04[_0x282195],_0x314f04[_0x4e38e9],_0x314f04[_0x35b9af],_0x314f04[_0x3cbb68]);}return _0x1b217f['join']('');},'encodeString'(_0x339e89,_0x3a5543){return this['HAS_NATIVE_SUPPORT']&&!_0x3a5543?btoa(_0x339e89):this['encodeByteArray'](Hr(_0x339e89),_0x3a5543);},'decodeString'(_0x141abb,_0xb4250b){return this['HAS_NATIVE_SUPPORT']&&!_0xb4250b?atob(_0x141abb):nc(this['decodeStringToByteArray'](_0x141abb,_0xb4250b));},'decodeStringToByteArray'(_0x112ada,_0x7e2583){this['init_']();const _0x556d8b=_0x7e2583?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x46ae19=[];for(let _0xc0b48e=0x0;_0xc0b48e<_0x112ada['length'];){const _0x2fad8f=_0x556d8b[_0x112ada['charAt'](_0xc0b48e++)],_0x3eed9f=_0xc0b48e<_0x112ada['length']?_0x556d8b[_0x112ada['charAt'](_0xc0b48e)]:0x0;++_0xc0b48e;const _0x19e5e2=_0xc0b48e<_0x112ada['length']?_0x556d8b[_0x112ada['charAt'](_0xc0b48e)]:0x40;++_0xc0b48e;const _0x4a3099=_0xc0b48e<_0x112ada['length']?_0x556d8b[_0x112ada['charAt'](_0xc0b48e)]:0x40;if(++_0xc0b48e,_0x2fad8f==null||_0x3eed9f==null||_0x19e5e2==null||_0x4a3099==null)throw new ic();const _0x3bb849=_0x2fad8f<<0x2|_0x3eed9f>>0x4;if(_0x46ae19['push'](_0x3bb849),_0x19e5e2!==0x40){const _0x292a66=_0x3eed9f<<0x4&0xf0|_0x19e5e2>>0x2;if(_0x46ae19['push'](_0x292a66),_0x4a3099!==0x40){const _0x2eca26=_0x19e5e2<<0x6&0xc0|_0x4a3099;_0x46ae19['push'](_0x2eca26);}}}return _0x46ae19;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x72ba1=0x0;_0x72ba1<this['ENCODED_VALS']['length'];_0x72ba1++)this['byteToCharMap_'][_0x72ba1]=this['ENCODED_VALS']['charAt'](_0x72ba1),this['charToByteMap_'][this['byteToCharMap_'][_0x72ba1]]=_0x72ba1,this['byteToCharMapWebSafe_'][_0x72ba1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x72ba1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x72ba1]]=_0x72ba1,_0x72ba1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x72ba1)]=_0x72ba1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x72ba1)]=_0x72ba1);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x3cd3bd){const _0x1d0e5=Hr(_0x3cd3bd);return Fi['encodeByteArray'](_0x1d0e5,!0x0);},dn=function(_0x35a811){return $r(_0x35a811)['replace'](/\./g,'');},fn=function(_0x32b750){try{return Fi['decodeString'](_0x32b750,!0x0);}catch(_0x2bafba){console['error']('base64Decode\x20failed:\x20',_0x2bafba);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0xc25788){return Gr(void 0x0,_0xc25788);}function Gr(_0x3d6c1a,_0x1f55ce){if(!(_0x1f55ce instanceof Object))return _0x1f55ce;switch(_0x1f55ce['constructor']){case Date:const _0xbc9cb6=_0x1f55ce;return new Date(_0xbc9cb6['getTime']());case Object:_0x3d6c1a===void 0x0&&(_0x3d6c1a={});break;case Array:_0x3d6c1a=[];break;default:return _0x1f55ce;}for(const _0x53b3c2 in _0x1f55ce)!_0x1f55ce['hasOwnProperty'](_0x53b3c2)||!rc(_0x53b3c2)||(_0x3d6c1a[_0x53b3c2]=Gr(_0x3d6c1a[_0x53b3c2],_0x1f55ce[_0x53b3c2]));return _0x3d6c1a;}function rc(_0x58157e){return _0x58157e!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xf24342=Ps['__FIREBASE_DEFAULTS__'];if(_0xf24342)return JSON['parse'](_0xf24342);},lc=()=>{if(typeof document>'u')return;let _0x255c52;try{_0x255c52=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1b9807=_0x255c52&&fn(_0x255c52[0x1]);return _0x1b9807&&JSON['parse'](_0x1b9807);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3aa03a){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3aa03a);return;}},qr=_0x332b16=>{var _0x264964,_0x2c31c3;return(_0x2c31c3=(_0x264964=Ui())==null?void 0x0:_0x264964['emulatorHosts'])==null?void 0x0:_0x2c31c3[_0x332b16];},hc=_0x22a72e=>{const _0x205120=qr(_0x22a72e);if(!_0x205120)return;const _0x263711=_0x205120['lastIndexOf'](':');if(_0x263711<=0x0||_0x263711+0x1===_0x205120['length'])throw new Error('Invalid\x20host\x20'+_0x205120+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5327f0=parseInt(_0x205120['substring'](_0x263711+0x1),0xa);return _0x205120[0x0]==='['?[_0x205120['substring'](0x1,_0x263711-0x1),_0x5327f0]:[_0x205120['substring'](0x0,_0x263711),_0x5327f0];},zr=()=>{var _0x225dfe;return(_0x225dfe=Ui())==null?void 0x0:_0x225dfe['config'];},jr=_0x14e321=>{var _0x326365;return(_0x326365=Ui())==null?void 0x0:_0x326365['_'+_0x14e321];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2c64c3,_0x22f9ef)=>{this['resolve']=_0x2c64c3,this['reject']=_0x22f9ef;});}['wrapCallback'](_0x2aa228){return(_0x2d2d18,_0x9df08c)=>{_0x2d2d18?this['reject'](_0x2d2d18):this['resolve'](_0x9df08c),typeof _0x2aa228=='function'&&(this['promise']['catch'](()=>{}),_0x2aa228['length']===0x1?_0x2aa228(_0x2d2d18):_0x2aa228(_0x2d2d18,_0x9df08c));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x543255,_0x5a967a){if(_0x543255['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x537d48={'alg':'none','type':'JWT'},_0x294252=_0x5a967a||'demo-project',_0x3e5853=_0x543255['iat']||0x0,_0x5f0e93=_0x543255['sub']||_0x543255['user_id'];if(!_0x5f0e93)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x3b27ab={'iss':'https://securetoken.google.com/'+_0x294252,'aud':_0x294252,'iat':_0x3e5853,'exp':_0x3e5853+0xe10,'auth_time':_0x3e5853,'sub':_0x5f0e93,'user_id':_0x5f0e93,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x543255};return[dn(JSON['stringify'](_0x537d48)),dn(JSON['stringify'](_0x3b27ab)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x344f49=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x344f49=='object'&&_0x344f49['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x22a221=W();return _0x22a221['indexOf']('MSIE\x20')>=0x0||_0x22a221['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3064f5,_0x461c6d)=>{try{let _0x31e419=!0x0;const _0x261423='validate-browser-context-for-indexeddb-analytics-module',_0xcfaf19=self['indexedDB']['open'](_0x261423);_0xcfaf19['onsuccess']=()=>{_0xcfaf19['result']['close'](),_0x31e419||self['indexedDB']['deleteDatabase'](_0x261423),_0x3064f5(!0x0);},_0xcfaf19['onupgradeneeded']=()=>{_0x31e419=!0x1;},_0xcfaf19['onerror']=()=>{var _0x4d7b56;_0x461c6d(((_0x4d7b56=_0xcfaf19['error'])==null?void 0x0:_0x4d7b56['message'])||'');};}catch(_0x5b29c0){_0x461c6d(_0x5b29c0);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x3fbea8,_0x854bc0,_0x1e02d7){super(_0x854bc0),this['code']=_0x3fbea8,this['customData']=_0x1e02d7,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x55ae82,_0x305d5f,_0x13b0d2){this['service']=_0x55ae82,this['serviceName']=_0x305d5f,this['errors']=_0x13b0d2;}['create'](_0xe1e58b,..._0x1fe9c6){const _0x814712=_0x1fe9c6[0x0]||{},_0x240d00=this['service']+'/'+_0xe1e58b,_0x7ac853=this['errors'][_0xe1e58b],_0xb6c9a2=_0x7ac853?vc(_0x7ac853,_0x814712):'Error',_0x2d52f0=this['serviceName']+':\x20'+_0xb6c9a2+'\x20('+_0x240d00+').';return new Re(_0x240d00,_0x2d52f0,_0x814712);}}function vc(_0x332831,_0x23b698){return _0x332831['replace'](Ec,(_0x12ff96,_0x1af6aa)=>{const _0x5b40d1=_0x23b698[_0x1af6aa];return _0x5b40d1!=null?String(_0x5b40d1):'<'+_0x1af6aa+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x52cb81){return JSON['parse'](_0x52cb81);}function O(_0x5b044a){return JSON['stringify'](_0x5b044a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2ea750){let _0x1424cd={},_0x1a0b51={},_0x507335={},_0x13f285='';try{const _0x55186a=_0x2ea750['split']('.');_0x1424cd=Nt(fn(_0x55186a[0x0])||''),_0x1a0b51=Nt(fn(_0x55186a[0x1])||''),_0x13f285=_0x55186a[0x2],_0x507335=_0x1a0b51['d']||{},delete _0x1a0b51['d'];}catch{}return{'header':_0x1424cd,'claims':_0x1a0b51,'data':_0x507335,'signature':_0x13f285};},Ic=function(_0x5638f7){const _0x196a83=Yr(_0x5638f7),_0x317140=_0x196a83['claims'];return!!_0x317140&&typeof _0x317140=='object'&&_0x317140['hasOwnProperty']('iat');},wc=function(_0x6cd5a8){const _0x2b5e82=Yr(_0x6cd5a8)['claims'];return typeof _0x2b5e82=='object'&&_0x2b5e82['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x1ce156,_0x3fa066){return Object['prototype']['hasOwnProperty']['call'](_0x1ce156,_0x3fa066);}function Le(_0x501c47,_0x5688c9){if(Object['prototype']['hasOwnProperty']['call'](_0x501c47,_0x5688c9))return _0x501c47[_0x5688c9];}function pn(_0x436dae){for(const _0x48ad30 in _0x436dae)if(Object['prototype']['hasOwnProperty']['call'](_0x436dae,_0x48ad30))return!0x1;return!0x0;}function _n(_0x3af3ed,_0x46b34c,_0x2d5662){const _0x59ef3b={};for(const _0x5d3f8f in _0x3af3ed)Object['prototype']['hasOwnProperty']['call'](_0x3af3ed,_0x5d3f8f)&&(_0x59ef3b[_0x5d3f8f]=_0x46b34c['call'](_0x2d5662,_0x3af3ed[_0x5d3f8f],_0x5d3f8f,_0x3af3ed));return _0x59ef3b;}function xe(_0x429a06,_0x57d04f){if(_0x429a06===_0x57d04f)return!0x0;const _0x1ce4c2=Object['keys'](_0x429a06),_0x20660f=Object['keys'](_0x57d04f);for(const _0x27400f of _0x1ce4c2){if(!_0x20660f['includes'](_0x27400f))return!0x1;const _0x1ada4e=_0x429a06[_0x27400f],_0x110256=_0x57d04f[_0x27400f];if(Ns(_0x1ada4e)&&Ns(_0x110256)){if(!xe(_0x1ada4e,_0x110256))return!0x1;}else{if(_0x1ada4e!==_0x110256)return!0x1;}}for(const _0xb8f3c4 of _0x20660f)if(!_0x1ce4c2['includes'](_0xb8f3c4))return!0x1;return!0x0;}function Ns(_0x4d4896){return _0x4d4896!==null&&typeof _0x4d4896=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x1f7ac8){const _0x5089d2=[];for(const [_0x325eef,_0x1fc8eb]of Object['entries'](_0x1f7ac8))Array['isArray'](_0x1fc8eb)?_0x1fc8eb['forEach'](_0x2cd806=>{_0x5089d2['push'](encodeURIComponent(_0x325eef)+'='+encodeURIComponent(_0x2cd806));}):_0x5089d2['push'](encodeURIComponent(_0x325eef)+'='+encodeURIComponent(_0x1fc8eb));return _0x5089d2['length']?'&'+_0x5089d2['join']('&'):'';}function Ct(_0x32d793){const _0x452ad2={};return _0x32d793['replace'](/^\?/,'')['split']('&')['forEach'](_0x3fe33d=>{if(_0x3fe33d){const [_0x2475d5,_0x383dc9]=_0x3fe33d['split']('=');_0x452ad2[decodeURIComponent(_0x2475d5)]=decodeURIComponent(_0x383dc9);}}),_0x452ad2;}function Tt(_0x755556){const _0x5506c4=_0x755556['indexOf']('?');if(!_0x5506c4)return'';const _0x198e65=_0x755556['indexOf']('#',_0x5506c4);return _0x755556['substring'](_0x5506c4,_0x198e65>0x0?_0x198e65:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x4c3969=0x1;_0x4c3969<this['blockSize'];++_0x4c3969)this['pad_'][_0x4c3969]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0xf007ee,_0x3e966f){_0x3e966f||(_0x3e966f=0x0);const _0x263dbf=this['W_'];if(typeof _0xf007ee=='string'){for(let _0xb97bd9=0x0;_0xb97bd9<0x10;_0xb97bd9++)_0x263dbf[_0xb97bd9]=_0xf007ee['charCodeAt'](_0x3e966f)<<0x18|_0xf007ee['charCodeAt'](_0x3e966f+0x1)<<0x10|_0xf007ee['charCodeAt'](_0x3e966f+0x2)<<0x8|_0xf007ee['charCodeAt'](_0x3e966f+0x3),_0x3e966f+=0x4;}else{for(let _0x2d5dda=0x0;_0x2d5dda<0x10;_0x2d5dda++)_0x263dbf[_0x2d5dda]=_0xf007ee[_0x3e966f]<<0x18|_0xf007ee[_0x3e966f+0x1]<<0x10|_0xf007ee[_0x3e966f+0x2]<<0x8|_0xf007ee[_0x3e966f+0x3],_0x3e966f+=0x4;}for(let _0x13fa32=0x10;_0x13fa32<0x50;_0x13fa32++){const _0x351e8d=_0x263dbf[_0x13fa32-0x3]^_0x263dbf[_0x13fa32-0x8]^_0x263dbf[_0x13fa32-0xe]^_0x263dbf[_0x13fa32-0x10];_0x263dbf[_0x13fa32]=(_0x351e8d<<0x1|_0x351e8d>>>0x1f)&0xffffffff;}let _0x21d464=this['chain_'][0x0],_0x5891ab=this['chain_'][0x1],_0x191087=this['chain_'][0x2],_0x2b88a8=this['chain_'][0x3],_0x4db982=this['chain_'][0x4],_0x2f9674,_0x4ea1f5;for(let _0x34e60c=0x0;_0x34e60c<0x50;_0x34e60c++){_0x34e60c<0x28?_0x34e60c<0x14?(_0x2f9674=_0x2b88a8^_0x5891ab&(_0x191087^_0x2b88a8),_0x4ea1f5=0x5a827999):(_0x2f9674=_0x5891ab^_0x191087^_0x2b88a8,_0x4ea1f5=0x6ed9eba1):_0x34e60c<0x3c?(_0x2f9674=_0x5891ab&_0x191087|_0x2b88a8&(_0x5891ab|_0x191087),_0x4ea1f5=0x8f1bbcdc):(_0x2f9674=_0x5891ab^_0x191087^_0x2b88a8,_0x4ea1f5=0xca62c1d6);const _0x23e04e=(_0x21d464<<0x5|_0x21d464>>>0x1b)+_0x2f9674+_0x4db982+_0x4ea1f5+_0x263dbf[_0x34e60c]&0xffffffff;_0x4db982=_0x2b88a8,_0x2b88a8=_0x191087,_0x191087=(_0x5891ab<<0x1e|_0x5891ab>>>0x2)&0xffffffff,_0x5891ab=_0x21d464,_0x21d464=_0x23e04e;}this['chain_'][0x0]=this['chain_'][0x0]+_0x21d464&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5891ab&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x191087&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2b88a8&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x4db982&0xffffffff;}['update'](_0x2d20a3,_0x26a4bc){if(_0x2d20a3==null)return;_0x26a4bc===void 0x0&&(_0x26a4bc=_0x2d20a3['length']);const _0x1fc156=_0x26a4bc-this['blockSize'];let _0x2e5662=0x0;const _0x1f3918=this['buf_'];let _0xd44cfe=this['inbuf_'];for(;_0x2e5662<_0x26a4bc;){if(_0xd44cfe===0x0){for(;_0x2e5662<=_0x1fc156;)this['compress_'](_0x2d20a3,_0x2e5662),_0x2e5662+=this['blockSize'];}if(typeof _0x2d20a3=='string'){for(;_0x2e5662<_0x26a4bc;)if(_0x1f3918[_0xd44cfe]=_0x2d20a3['charCodeAt'](_0x2e5662),++_0xd44cfe,++_0x2e5662,_0xd44cfe===this['blockSize']){this['compress_'](_0x1f3918),_0xd44cfe=0x0;break;}}else{for(;_0x2e5662<_0x26a4bc;)if(_0x1f3918[_0xd44cfe]=_0x2d20a3[_0x2e5662],++_0xd44cfe,++_0x2e5662,_0xd44cfe===this['blockSize']){this['compress_'](_0x1f3918),_0xd44cfe=0x0;break;}}}this['inbuf_']=_0xd44cfe,this['total_']+=_0x26a4bc;}['digest'](){const _0x30d717=[];let _0x9e300=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x89d01d=this['blockSize']-0x1;_0x89d01d>=0x38;_0x89d01d--)this['buf_'][_0x89d01d]=_0x9e300&0xff,_0x9e300/=0x100;this['compress_'](this['buf_']);let _0x2b123b=0x0;for(let _0x54802d=0x0;_0x54802d<0x5;_0x54802d++)for(let _0xfcc09d=0x18;_0xfcc09d>=0x0;_0xfcc09d-=0x8)_0x30d717[_0x2b123b]=this['chain_'][_0x54802d]>>_0xfcc09d&0xff,++_0x2b123b;return _0x30d717;}}function Tc(_0x1cb78b,_0x25ed10){const _0x174d51=new Sc(_0x1cb78b,_0x25ed10);return _0x174d51['subscribe']['bind'](_0x174d51);}class Sc{constructor(_0x4721f1,_0x15d623){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x15d623,this['task']['then'](()=>{_0x4721f1(this);})['catch'](_0x31dc17=>{this['error'](_0x31dc17);});}['next'](_0x3efb26){this['forEachObserver'](_0x3beadb=>{_0x3beadb['next'](_0x3efb26);});}['error'](_0x3d2774){this['forEachObserver'](_0x118f68=>{_0x118f68['error'](_0x3d2774);}),this['close'](_0x3d2774);}['complete'](){this['forEachObserver'](_0x331d00=>{_0x331d00['complete']();}),this['close']();}['subscribe'](_0x1ffc2e,_0x53ff7f,_0xfa16cb){let _0x2e0dea;if(_0x1ffc2e===void 0x0&&_0x53ff7f===void 0x0&&_0xfa16cb===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1ffc2e,['next','error','complete'])?_0x2e0dea=_0x1ffc2e:_0x2e0dea={'next':_0x1ffc2e,'error':_0x53ff7f,'complete':_0xfa16cb},_0x2e0dea['next']===void 0x0&&(_0x2e0dea['next']=ti),_0x2e0dea['error']===void 0x0&&(_0x2e0dea['error']=ti),_0x2e0dea['complete']===void 0x0&&(_0x2e0dea['complete']=ti);const _0x1abfb4=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2e0dea['error'](this['finalError']):_0x2e0dea['complete']();}catch{}}),this['observers']['push'](_0x2e0dea),_0x1abfb4;}['unsubscribeOne'](_0x3c0559){this['observers']===void 0x0||this['observers'][_0x3c0559]===void 0x0||(delete this['observers'][_0x3c0559],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x8474dc){if(!this['finalized']){for(let _0x2fd783=0x0;_0x2fd783<this['observers']['length'];_0x2fd783++)this['sendOne'](_0x2fd783,_0x8474dc);}}['sendOne'](_0x21457a,_0x4fccc2){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x21457a]!==void 0x0)try{_0x4fccc2(this['observers'][_0x21457a]);}catch(_0x575242){typeof console<'u'&&console['error']&&console['error'](_0x575242);}});}['close'](_0x43c6a4){this['finalized']||(this['finalized']=!0x0,_0x43c6a4!==void 0x0&&(this['finalError']=_0x43c6a4),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x2934b8,_0x5059c5){if(typeof _0x2934b8!='object'||_0x2934b8===null)return!0x1;for(const _0x4d5673 of _0x5059c5)if(_0x4d5673 in _0x2934b8&&typeof _0x2934b8[_0x4d5673]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x23fa18,_0x1db918){return _0x23fa18+'\x20failed:\x20'+_0x1db918+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4b1068){const _0x59a15e=[];let _0x35984c=0x0;for(let _0x25f36d=0x0;_0x25f36d<_0x4b1068['length'];_0x25f36d++){let _0x49a7ab=_0x4b1068['charCodeAt'](_0x25f36d);if(_0x49a7ab>=0xd800&&_0x49a7ab<=0xdbff){const _0x54871b=_0x49a7ab-0xd800;_0x25f36d++,f(_0x25f36d<_0x4b1068['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x356423=_0x4b1068['charCodeAt'](_0x25f36d)-0xdc00;_0x49a7ab=0x10000+(_0x54871b<<0xa)+_0x356423;}_0x49a7ab<0x80?_0x59a15e[_0x35984c++]=_0x49a7ab:_0x49a7ab<0x800?(_0x59a15e[_0x35984c++]=_0x49a7ab>>0x6|0xc0,_0x59a15e[_0x35984c++]=_0x49a7ab&0x3f|0x80):_0x49a7ab<0x10000?(_0x59a15e[_0x35984c++]=_0x49a7ab>>0xc|0xe0,_0x59a15e[_0x35984c++]=_0x49a7ab>>0x6&0x3f|0x80,_0x59a15e[_0x35984c++]=_0x49a7ab&0x3f|0x80):(_0x59a15e[_0x35984c++]=_0x49a7ab>>0x12|0xf0,_0x59a15e[_0x35984c++]=_0x49a7ab>>0xc&0x3f|0x80,_0x59a15e[_0x35984c++]=_0x49a7ab>>0x6&0x3f|0x80,_0x59a15e[_0x35984c++]=_0x49a7ab&0x3f|0x80);}return _0x59a15e;},Ln=function(_0x55515e){let _0x29ddf5=0x0;for(let _0x4bfc4e=0x0;_0x4bfc4e<_0x55515e['length'];_0x4bfc4e++){const _0x54e8b9=_0x55515e['charCodeAt'](_0x4bfc4e);_0x54e8b9<0x80?_0x29ddf5++:_0x54e8b9<0x800?_0x29ddf5+=0x2:_0x54e8b9>=0xd800&&_0x54e8b9<=0xdbff?(_0x29ddf5+=0x4,_0x4bfc4e++):_0x29ddf5+=0x3;}return _0x29ddf5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x111645){return _0x111645&&_0x111645['_delegate']?_0x111645['_delegate']:_0x111645;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3d3bc1){try{return(_0x3d3bc1['startsWith']('http://')||_0x3d3bc1['startsWith']('https://')?new URL(_0x3d3bc1)['hostname']:_0x3d3bc1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x538dbb){return(await fetch(_0x538dbb,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x292f82,_0x2d35ae,_0x50f894){this['name']=_0x292f82,this['instanceFactory']=_0x2d35ae,this['type']=_0x50f894,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x269def){return this['instantiationMode']=_0x269def,this;}['setMultipleInstances'](_0x4414c9){return this['multipleInstances']=_0x4414c9,this;}['setServiceProps'](_0x41789c){return this['serviceProps']=_0x41789c,this;}['setInstanceCreatedCallback'](_0x5e0a2f){return this['onInstanceCreated']=_0x5e0a2f,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3a0d94,_0x2e3088){this['name']=_0x3a0d94,this['container']=_0x2e3088,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x12ac44){const _0x4e6c1d=this['normalizeInstanceIdentifier'](_0x12ac44);if(!this['instancesDeferred']['has'](_0x4e6c1d)){const _0x1f3c17=new H();if(this['instancesDeferred']['set'](_0x4e6c1d,_0x1f3c17),this['isInitialized'](_0x4e6c1d)||this['shouldAutoInitialize']())try{const _0x4eea1a=this['getOrInitializeService']({'instanceIdentifier':_0x4e6c1d});_0x4eea1a&&_0x1f3c17['resolve'](_0x4eea1a);}catch{}}return this['instancesDeferred']['get'](_0x4e6c1d)['promise'];}['getImmediate'](_0x262ac7){const _0x2f6364=this['normalizeInstanceIdentifier'](_0x262ac7==null?void 0x0:_0x262ac7['identifier']),_0x1a6499=(_0x262ac7==null?void 0x0:_0x262ac7['optional'])??!0x1;if(this['isInitialized'](_0x2f6364)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2f6364});}catch(_0xd1b7e7){if(_0x1a6499)return null;throw _0xd1b7e7;}else{if(_0x1a6499)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x36275c){if(_0x36275c['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x36275c['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x36275c,!!this['shouldAutoInitialize']()){if(Pc(_0x36275c))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1c4334,_0x2300b2]of this['instancesDeferred']['entries']()){const _0xb46063=this['normalizeInstanceIdentifier'](_0x1c4334);try{const _0x505b2b=this['getOrInitializeService']({'instanceIdentifier':_0xb46063});_0x2300b2['resolve'](_0x505b2b);}catch{}}}}['clearInstance'](_0xc0f09a=Ne){this['instancesDeferred']['delete'](_0xc0f09a),this['instancesOptions']['delete'](_0xc0f09a),this['instances']['delete'](_0xc0f09a);}async['delete'](){const _0x183691=Array['from'](this['instances']['values']());await Promise['all']([..._0x183691['filter'](_0x5c1e36=>'INTERNAL'in _0x5c1e36)['map'](_0x255adc=>_0x255adc['INTERNAL']['delete']()),..._0x183691['filter'](_0xedf73a=>'_delete'in _0xedf73a)['map'](_0x114355=>_0x114355['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x34439e=Ne){return this['instances']['has'](_0x34439e);}['getOptions'](_0x58d783=Ne){return this['instancesOptions']['get'](_0x58d783)||{};}['initialize'](_0x550006={}){const {options:_0x2e1061={}}=_0x550006,_0x5c6740=this['normalizeInstanceIdentifier'](_0x550006['instanceIdentifier']);if(this['isInitialized'](_0x5c6740))throw Error(this['name']+'('+_0x5c6740+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5ee673=this['getOrInitializeService']({'instanceIdentifier':_0x5c6740,'options':_0x2e1061});for(const [_0x4ead79,_0x16f57c]of this['instancesDeferred']['entries']()){const _0x3d3571=this['normalizeInstanceIdentifier'](_0x4ead79);_0x5c6740===_0x3d3571&&_0x16f57c['resolve'](_0x5ee673);}return _0x5ee673;}['onInit'](_0x47e1bf,_0x518394){const _0x3bcb59=this['normalizeInstanceIdentifier'](_0x518394),_0x20ab06=this['onInitCallbacks']['get'](_0x3bcb59)??new Set();_0x20ab06['add'](_0x47e1bf),this['onInitCallbacks']['set'](_0x3bcb59,_0x20ab06);const _0xd59e6a=this['instances']['get'](_0x3bcb59);return _0xd59e6a&&_0x47e1bf(_0xd59e6a,_0x3bcb59),()=>{_0x20ab06['delete'](_0x47e1bf);};}['invokeOnInitCallbacks'](_0x15c462,_0x1cf7fd){const _0xc18a75=this['onInitCallbacks']['get'](_0x1cf7fd);if(_0xc18a75){for(const _0x5ee6a7 of _0xc18a75)try{_0x5ee6a7(_0x15c462,_0x1cf7fd);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5bd2a8,options:_0x18760b={}}){let _0x319d67=this['instances']['get'](_0x5bd2a8);if(!_0x319d67&&this['component']&&(_0x319d67=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5bd2a8),'options':_0x18760b}),this['instances']['set'](_0x5bd2a8,_0x319d67),this['instancesOptions']['set'](_0x5bd2a8,_0x18760b),this['invokeOnInitCallbacks'](_0x319d67,_0x5bd2a8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5bd2a8,_0x319d67);}catch{}return _0x319d67||null;}['normalizeInstanceIdentifier'](_0x561954=Ne){return this['component']?this['component']['multipleInstances']?_0x561954:Ne:_0x561954;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5d1f7f){return _0x5d1f7f===Ne?void 0x0:_0x5d1f7f;}function Pc(_0x1798d8){return _0x1798d8['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x394285){this['name']=_0x394285,this['providers']=new Map();}['addComponent'](_0x2984af){const _0x177357=this['getProvider'](_0x2984af['name']);if(_0x177357['isComponentSet']())throw new Error('Component\x20'+_0x2984af['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x177357['setComponent'](_0x2984af);}['addOrOverwriteComponent'](_0x7eaffc){this['getProvider'](_0x7eaffc['name'])['isComponentSet']()&&this['providers']['delete'](_0x7eaffc['name']),this['addComponent'](_0x7eaffc);}['getProvider'](_0x3dbbf6){if(this['providers']['has'](_0x3dbbf6))return this['providers']['get'](_0x3dbbf6);const _0x508120=new Ac(_0x3dbbf6,this);return this['providers']['set'](_0x3dbbf6,_0x508120),_0x508120;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x384d10){_0x384d10[_0x384d10['DEBUG']=0x0]='DEBUG',_0x384d10[_0x384d10['VERBOSE']=0x1]='VERBOSE',_0x384d10[_0x384d10['INFO']=0x2]='INFO',_0x384d10[_0x384d10['WARN']=0x3]='WARN',_0x384d10[_0x384d10['ERROR']=0x4]='ERROR',_0x384d10[_0x384d10['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x3c76ff,_0x13957d,..._0x17c99f)=>{if(_0x13957d<_0x3c76ff['logLevel'])return;const _0x45aa98=new Date()['toISOString'](),_0x5a2ddf=Mc[_0x13957d];if(_0x5a2ddf)console[_0x5a2ddf]('['+_0x45aa98+']\x20\x20'+_0x3c76ff['name']+':',..._0x17c99f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x13957d+')');};class Bi{constructor(_0x4d9c77){this['name']=_0x4d9c77,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x209da3){if(!(_0x209da3 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x209da3+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x209da3;}['setLogLevel'](_0x1d7c4f){this['_logLevel']=typeof _0x1d7c4f=='string'?Oc[_0x1d7c4f]:_0x1d7c4f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2153f7){if(typeof _0x2153f7!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2153f7;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x3be311){this['_userLogHandler']=_0x3be311;}['debug'](..._0x4af1b3){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4af1b3),this['_logHandler'](this,T['DEBUG'],..._0x4af1b3);}['log'](..._0x429dbf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x429dbf),this['_logHandler'](this,T['VERBOSE'],..._0x429dbf);}['info'](..._0x1219c4){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1219c4),this['_logHandler'](this,T['INFO'],..._0x1219c4);}['warn'](..._0x262d6c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x262d6c),this['_logHandler'](this,T['WARN'],..._0x262d6c);}['error'](..._0x3c146e){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3c146e),this['_logHandler'](this,T['ERROR'],..._0x3c146e);}}const xc=(_0x3e29a9,_0x4d7856)=>_0x4d7856['some'](_0x4d9f93=>_0x3e29a9 instanceof _0x4d9f93);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x581a25){const _0x4d0ee0=new Promise((_0x3446eb,_0xdfe0d5)=>{const _0x2a2fe8=()=>{_0x581a25['removeEventListener']('success',_0x639605),_0x581a25['removeEventListener']('error',_0x4c6ae);},_0x639605=()=>{_0x3446eb(ge(_0x581a25['result'])),_0x2a2fe8();},_0x4c6ae=()=>{_0xdfe0d5(_0x581a25['error']),_0x2a2fe8();};_0x581a25['addEventListener']('success',_0x639605),_0x581a25['addEventListener']('error',_0x4c6ae);});return _0x4d0ee0['then'](_0x1ac942=>{_0x1ac942 instanceof IDBCursor&&Jr['set'](_0x1ac942,_0x581a25);})['catch'](()=>{}),Vi['set'](_0x4d0ee0,_0x581a25),_0x4d0ee0;}function Bc(_0x1aa39d){if(_i['has'](_0x1aa39d))return;const _0x164bc9=new Promise((_0x3b9b0e,_0x441afb)=>{const _0x177fb6=()=>{_0x1aa39d['removeEventListener']('complete',_0x3b49aa),_0x1aa39d['removeEventListener']('error',_0x3102f4),_0x1aa39d['removeEventListener']('abort',_0x3102f4);},_0x3b49aa=()=>{_0x3b9b0e(),_0x177fb6();},_0x3102f4=()=>{_0x441afb(_0x1aa39d['error']||new DOMException('AbortError','AbortError')),_0x177fb6();};_0x1aa39d['addEventListener']('complete',_0x3b49aa),_0x1aa39d['addEventListener']('error',_0x3102f4),_0x1aa39d['addEventListener']('abort',_0x3102f4);});_i['set'](_0x1aa39d,_0x164bc9);}let gi={'get'(_0x230397,_0x392811,_0x17f685){if(_0x230397 instanceof IDBTransaction){if(_0x392811==='done')return _i['get'](_0x230397);if(_0x392811==='objectStoreNames')return _0x230397['objectStoreNames']||Xr['get'](_0x230397);if(_0x392811==='store')return _0x17f685['objectStoreNames'][0x1]?void 0x0:_0x17f685['objectStore'](_0x17f685['objectStoreNames'][0x0]);}return ge(_0x230397[_0x392811]);},'set'(_0x53269f,_0x2c156f,_0x8d1f3b){return _0x53269f[_0x2c156f]=_0x8d1f3b,!0x0;},'has'(_0x44c442,_0x12ae21){return _0x44c442 instanceof IDBTransaction&&(_0x12ae21==='done'||_0x12ae21==='store')?!0x0:_0x12ae21 in _0x44c442;}};function Vc(_0x264cb1){gi=_0x264cb1(gi);}function Hc(_0x35f30a){return _0x35f30a===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x59cbac,..._0x2b4b14){const _0x13351f=_0x35f30a['call'](ii(this),_0x59cbac,..._0x2b4b14);return Xr['set'](_0x13351f,_0x59cbac['sort']?_0x59cbac['sort']():[_0x59cbac]),ge(_0x13351f);}:Uc()['includes'](_0x35f30a)?function(..._0xaab17c){return _0x35f30a['apply'](ii(this),_0xaab17c),ge(Jr['get'](this));}:function(..._0x4c5b87){return ge(_0x35f30a['apply'](ii(this),_0x4c5b87));};}function $c(_0x59776f){return typeof _0x59776f=='function'?Hc(_0x59776f):(_0x59776f instanceof IDBTransaction&&Bc(_0x59776f),xc(_0x59776f,Fc())?new Proxy(_0x59776f,gi):_0x59776f);}function ge(_0x30d094){if(_0x30d094 instanceof IDBRequest)return Wc(_0x30d094);if(ni['has'](_0x30d094))return ni['get'](_0x30d094);const _0x462c21=$c(_0x30d094);return _0x462c21!==_0x30d094&&(ni['set'](_0x30d094,_0x462c21),Vi['set'](_0x462c21,_0x30d094)),_0x462c21;}const ii=_0x452293=>Vi['get'](_0x452293);function Gc(_0x3a3735,_0x994b7c,{blocked:_0x1e6c92,upgrade:_0x1d9925,blocking:_0x9a7593,terminated:_0x5c366c}={}){const _0x151132=indexedDB['open'](_0x3a3735,_0x994b7c),_0x2f8a7e=ge(_0x151132);return _0x1d9925&&_0x151132['addEventListener']('upgradeneeded',_0x4112e7=>{_0x1d9925(ge(_0x151132['result']),_0x4112e7['oldVersion'],_0x4112e7['newVersion'],ge(_0x151132['transaction']),_0x4112e7);}),_0x1e6c92&&_0x151132['addEventListener']('blocked',_0x42a8f4=>_0x1e6c92(_0x42a8f4['oldVersion'],_0x42a8f4['newVersion'],_0x42a8f4)),_0x2f8a7e['then'](_0x2bce47=>{_0x5c366c&&_0x2bce47['addEventListener']('close',()=>_0x5c366c()),_0x9a7593&&_0x2bce47['addEventListener']('versionchange',_0x57433a=>_0x9a7593(_0x57433a['oldVersion'],_0x57433a['newVersion'],_0x57433a));})['catch'](()=>{}),_0x2f8a7e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x35fb74,_0x3afd6c){if(!(_0x35fb74 instanceof IDBDatabase&&!(_0x3afd6c in _0x35fb74)&&typeof _0x3afd6c=='string'))return;if(si['get'](_0x3afd6c))return si['get'](_0x3afd6c);const _0x279b31=_0x3afd6c['replace'](/FromIndex$/,''),_0x2799f4=_0x3afd6c!==_0x279b31,_0x1615e7=zc['includes'](_0x279b31);if(!(_0x279b31 in(_0x2799f4?IDBIndex:IDBObjectStore)['prototype'])||!(_0x1615e7||qc['includes'](_0x279b31)))return;const _0x293f36=async function(_0x3d1259,..._0x49ef92){const _0x451eed=this['transaction'](_0x3d1259,_0x1615e7?'readwrite':'readonly');let _0x2fcee0=_0x451eed['store'];return _0x2799f4&&(_0x2fcee0=_0x2fcee0['index'](_0x49ef92['shift']())),(await Promise['all']([_0x2fcee0[_0x279b31](..._0x49ef92),_0x1615e7&&_0x451eed['done']]))[0x0];};return si['set'](_0x3afd6c,_0x293f36),_0x293f36;}Vc(_0x3a423b=>({..._0x3a423b,'get':(_0x56aa38,_0x4b2e9f,_0x1f51df)=>Ms(_0x56aa38,_0x4b2e9f)||_0x3a423b['get'](_0x56aa38,_0x4b2e9f,_0x1f51df),'has':(_0x454390,_0x139531)=>!!Ms(_0x454390,_0x139531)||_0x3a423b['has'](_0x454390,_0x139531)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1747b6){this['container']=_0x1747b6;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2c9a12=>{if(Kc(_0x2c9a12)){const _0x232df5=_0x2c9a12['getImmediate']();return _0x232df5['library']+'/'+_0x232df5['version'];}else return null;})['filter'](_0xcdefdd=>_0xcdefdd)['join']('\x20');}}function Kc(_0x39749f){const _0x5ac775=_0x39749f['getComponent']();return(_0x5ac775==null?void 0x0:_0x5ac775['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x1ca1a4,_0xb1bfb8){try{_0x1ca1a4['container']['addComponent'](_0xb1bfb8);}catch(_0x2953f8){oe['debug']('Component\x20'+_0xb1bfb8['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1ca1a4['name'],_0x2953f8);}}function st(_0x43b153){const _0x350f80=_0x43b153['name'];if(Ei['has'](_0x350f80))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x350f80+'.'),!0x1;Ei['set'](_0x350f80,_0x43b153);for(const _0x53215f of Ue['values']())xs(_0x53215f,_0x43b153);for(const _0xe9897e of vi['values']())xs(_0xe9897e,_0x43b153);return!0x0;}function Hi(_0x4aa38f,_0x1094ed){const _0x5778ba=_0x4aa38f['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5778ba&&_0x5778ba['triggerHeartbeat'](),_0x4aa38f['container']['getProvider'](_0x1094ed);}function $(_0x1fc342){return _0x1fc342==null?!0x1:_0x1fc342['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x3d061e,_0xdc22c2,_0x5129a0){this['_isDeleted']=!0x1,this['_options']={..._0x3d061e},this['_config']={..._0xdc22c2},this['_name']=_0xdc22c2['name'],this['_automaticDataCollectionEnabled']=_0xdc22c2['automaticDataCollectionEnabled'],this['_container']=_0x5129a0,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4801f6){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4801f6;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x55d037){this['_isDeleted']=_0x55d037;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x59358e,_0xef874d={}){let _0x10cc3a=_0x59358e;typeof _0xef874d!='object'&&(_0xef874d={'name':_0xef874d});const _0x5c6961={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0xef874d},_0x39fd78=_0x5c6961['name'];if(typeof _0x39fd78!='string'||!_0x39fd78)throw me['create']('bad-app-name',{'appName':String(_0x39fd78)});if(_0x10cc3a||(_0x10cc3a=zr()),!_0x10cc3a)throw me['create']('no-options');const _0x1ae1b2=Ue['get'](_0x39fd78);if(_0x1ae1b2){if(xe(_0x10cc3a,_0x1ae1b2['options'])&&xe(_0x5c6961,_0x1ae1b2['config']))return _0x1ae1b2;throw me['create']('duplicate-app',{'appName':_0x39fd78});}const _0x47bfd6=new Nc(_0x39fd78);for(const _0x22d14b of Ei['values']())_0x47bfd6['addComponent'](_0x22d14b);const _0x24f2ec=new Tl(_0x10cc3a,_0x5c6961,_0x47bfd6);return Ue['set'](_0x39fd78,_0x24f2ec),_0x24f2ec;}function Zr(_0x5ac139=yi){const _0x4562f1=Ue['get'](_0x5ac139);if(!_0x4562f1&&_0x5ac139===yi&&zr())return Sl();if(!_0x4562f1)throw me['create']('no-app',{'appName':_0x5ac139});return _0x4562f1;}function g_(){return Array['from'](Ue['values']());}async function m_(_0xcc3088){let _0x28a475=!0x1;const _0x2f3798=_0xcc3088['name'];Ue['has'](_0x2f3798)?(_0x28a475=!0x0,Ue['delete'](_0x2f3798)):vi['has'](_0x2f3798)&&_0xcc3088['decRefCount']()<=0x0&&(vi['delete'](_0x2f3798),_0x28a475=!0x0),_0x28a475&&(await Promise['all'](_0xcc3088['container']['getProviders']()['map'](_0x248e1c=>_0x248e1c['delete']())),_0xcc3088['isDeleted']=!0x0);}function ye(_0x36ab94,_0x2ee14c,_0x82d5a){let _0x11d540=wl[_0x36ab94]??_0x36ab94;_0x82d5a&&(_0x11d540+='-'+_0x82d5a);const _0x330a31=_0x11d540['match'](/\s|\//),_0x55f500=_0x2ee14c['match'](/\s|\//);if(_0x330a31||_0x55f500){const _0x1a4fc7=['Unable\x20to\x20register\x20library\x20\x22'+_0x11d540+'\x22\x20with\x20version\x20\x22'+_0x2ee14c+'\x22:'];_0x330a31&&_0x1a4fc7['push']('library\x20name\x20\x22'+_0x11d540+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x330a31&&_0x55f500&&_0x1a4fc7['push']('and'),_0x55f500&&_0x1a4fc7['push']('version\x20name\x20\x22'+_0x2ee14c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1a4fc7['join']('\x20'));return;}st(new Fe(_0x11d540+'-version',()=>({'library':_0x11d540,'version':_0x2ee14c}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3dcf80,_0x584491)=>{switch(_0x584491){case 0x0:try{_0x3dcf80['createObjectStore'](Ot);}catch(_0x4e1d6c){console['warn'](_0x4e1d6c);}}}})['catch'](_0x58154c=>{throw me['create']('idb-open',{'originalErrorMessage':_0x58154c['message']});})),ri;}async function Al(_0x28ab76){try{const _0x141419=(await eo())['transaction'](Ot),_0x5ed3ac=await _0x141419['objectStore'](Ot)['get'](to(_0x28ab76));return await _0x141419['done'],_0x5ed3ac;}catch(_0x4203cd){if(_0x4203cd instanceof Re)oe['warn'](_0x4203cd['message']);else{const _0x397b6e=me['create']('idb-get',{'originalErrorMessage':_0x4203cd==null?void 0x0:_0x4203cd['message']});oe['warn'](_0x397b6e['message']);}}}async function Fs(_0x287c88,_0x26eaf9){try{const _0x3c3872=(await eo())['transaction'](Ot,'readwrite');await _0x3c3872['objectStore'](Ot)['put'](_0x26eaf9,to(_0x287c88)),await _0x3c3872['done'];}catch(_0x1faee0){if(_0x1faee0 instanceof Re)oe['warn'](_0x1faee0['message']);else{const _0x49009c=me['create']('idb-set',{'originalErrorMessage':_0x1faee0==null?void 0x0:_0x1faee0['message']});oe['warn'](_0x49009c['message']);}}}function to(_0x3ed674){return _0x3ed674['name']+'!'+_0x3ed674['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x11f981){this['container']=_0x11f981,this['_heartbeatsCache']=null;const _0x475f80=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x475f80),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x19d133=>(this['_heartbeatsCache']=_0x19d133,_0x19d133));}async['triggerHeartbeat'](){var _0x9d46d2,_0x3b90f6;try{const _0x168c26=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xba0c19=Us();if(((_0x9d46d2=this['_heartbeatsCache'])==null?void 0x0:_0x9d46d2['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3b90f6=this['_heartbeatsCache'])==null?void 0x0:_0x3b90f6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xba0c19||this['_heartbeatsCache']['heartbeats']['some'](_0x2a2479=>_0x2a2479['date']===_0xba0c19))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xba0c19,'agent':_0x168c26}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x9cfca8=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x9cfca8,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3f8c03){oe['warn'](_0x3f8c03);}}async['getHeartbeatsHeader'](){var _0x4452c3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4452c3=this['_heartbeatsCache'])==null?void 0x0:_0x4452c3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x150a4e=Us(),{heartbeatsToSend:_0x460cb5,unsentEntries:_0x550599}=Ol(this['_heartbeatsCache']['heartbeats']),_0x28e78c=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x460cb5}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x150a4e,_0x550599['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x550599,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x28e78c;}catch(_0x3dd20a){return oe['warn'](_0x3dd20a),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2decd6,_0x9951ad=kl){const _0x2f0748=[];let _0x15f906=_0x2decd6['slice']();for(const _0x1a11b7 of _0x2decd6){const _0x1d0cdd=_0x2f0748['find'](_0x4da80f=>_0x4da80f['agent']===_0x1a11b7['agent']);if(_0x1d0cdd){if(_0x1d0cdd['dates']['push'](_0x1a11b7['date']),Ws(_0x2f0748)>_0x9951ad){_0x1d0cdd['dates']['pop']();break;}}else{if(_0x2f0748['push']({'agent':_0x1a11b7['agent'],'dates':[_0x1a11b7['date']]}),Ws(_0x2f0748)>_0x9951ad){_0x2f0748['pop']();break;}}_0x15f906=_0x15f906['slice'](0x1);}return{'heartbeatsToSend':_0x2f0748,'unsentEntries':_0x15f906};}class Dl{constructor(_0x481279){this['app']=_0x481279,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x367aff=await Al(this['app']);return _0x367aff!=null&&_0x367aff['heartbeats']?_0x367aff:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x2e7c47){if(await this['_canUseIndexedDBPromise']){const _0x20f706=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x2e7c47['lastSentHeartbeatDate']??_0x20f706['lastSentHeartbeatDate'],'heartbeats':_0x2e7c47['heartbeats']});}else return;}async['add'](_0x354620){if(await this['_canUseIndexedDBPromise']){const _0x24bccd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x354620['lastSentHeartbeatDate']??_0x24bccd['lastSentHeartbeatDate'],'heartbeats':[..._0x24bccd['heartbeats'],..._0x354620['heartbeats']]});}else return;}}function Ws(_0x39b736){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x39b736}))['length'];}function Ml(_0x2199d1){if(_0x2199d1['length']===0x0)return-0x1;let _0x143726=0x0,_0x4945cb=_0x2199d1[0x0]['date'];for(let _0x701713=0x1;_0x701713<_0x2199d1['length'];_0x701713++)_0x2199d1[_0x701713]['date']<_0x4945cb&&(_0x4945cb=_0x2199d1[_0x701713]['date'],_0x143726=_0x701713);return _0x143726;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1a0947){st(new Fe('platform-logger',_0x358053=>new jc(_0x358053),'PRIVATE')),st(new Fe('heartbeat',_0x2bdd75=>new Nl(_0x2bdd75),'PRIVATE')),ye(mi,Ls,_0x1a0947),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x28beb5){no=_0x28beb5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x54ddfa){this['domStorage_']=_0x54ddfa,this['prefix_']='firebase:';}['set'](_0xa7e7ca,_0x1a4019){_0x1a4019==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xa7e7ca)):this['domStorage_']['setItem'](this['prefixedName_'](_0xa7e7ca),O(_0x1a4019));}['get'](_0x6b885b){const _0x174c7d=this['domStorage_']['getItem'](this['prefixedName_'](_0x6b885b));return _0x174c7d==null?null:Nt(_0x174c7d);}['remove'](_0x213637){this['domStorage_']['removeItem'](this['prefixedName_'](_0x213637));}['prefixedName_'](_0x188696){return this['prefix_']+_0x188696;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1e9235,_0x4c300e){_0x4c300e==null?delete this['cache_'][_0x1e9235]:this['cache_'][_0x1e9235]=_0x4c300e;}['get'](_0x3621bc){return Q(this['cache_'],_0x3621bc)?this['cache_'][_0x3621bc]:null;}['remove'](_0x54f734){delete this['cache_'][_0x54f734];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x474adf){try{if(typeof window<'u'&&typeof window[_0x474adf]<'u'){const _0x345c36=window[_0x474adf];return _0x345c36['setItem']('firebase:sentinel','cache'),_0x345c36['removeItem']('firebase:sentinel'),new Wl(_0x345c36);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x2b3d2a=0x1;return function(){return _0x2b3d2a++;};}()),ro=function(_0x961874){const _0x54c205=Rc(_0x961874),_0x5595d0=new Cc();_0x5595d0['update'](_0x54c205);const _0x573455=_0x5595d0['digest']();return Fi['encodeByteArray'](_0x573455);},zt=function(..._0x11259f){let _0x5be838='';for(let _0x22aab3=0x0;_0x22aab3<_0x11259f['length'];_0x22aab3++){const _0xdc3f46=_0x11259f[_0x22aab3];Array['isArray'](_0xdc3f46)||_0xdc3f46&&typeof _0xdc3f46=='object'&&typeof _0xdc3f46['length']=='number'?_0x5be838+=zt['apply'](null,_0xdc3f46):typeof _0xdc3f46=='object'?_0x5be838+=O(_0xdc3f46):_0x5be838+=_0xdc3f46,_0x5be838+='\x20';}return _0x5be838;};let St=null,$s=!0x0;const Hl=function(_0x269009,_0xd4d421){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x2d335b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x2c72aa=zt['apply'](null,_0x2d335b);St(_0x2c72aa);}},jt=function(_0xf67899){return function(..._0x367bee){L(_0xf67899,..._0x367bee);};},Ii=function(..._0x3eda29){const _0x158d1b='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x3eda29);Ze['error'](_0x158d1b);},ae=function(..._0x2ce53d){const _0x41e446='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x2ce53d);throw Ze['error'](_0x41e446),new Error(_0x41e446);},U=function(..._0x13a1d6){const _0xdec465='FIREBASE\x20WARNING:\x20'+zt(..._0x13a1d6);Ze['warn'](_0xdec465);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3c1498){return typeof _0x3c1498=='number'&&(_0x3c1498!==_0x3c1498||_0x3c1498===Number['POSITIVE_INFINITY']||_0x3c1498===Number['NEGATIVE_INFINITY']);},Gl=function(_0x1649ab){if(document['readyState']==='complete')_0x1649ab();else{let _0x57bf84=!0x1;const _0x10d26d=function(){if(!document['body']){setTimeout(_0x10d26d,Math['floor'](0xa));return;}_0x57bf84||(_0x57bf84=!0x0,_0x1649ab());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x10d26d,!0x1),window['addEventListener']('load',_0x10d26d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x10d26d();}),window['attachEvent']('onload',_0x10d26d));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5e9815,_0x794a0b){if(_0x5e9815===_0x794a0b)return 0x0;if(_0x5e9815===We||_0x794a0b===we)return-0x1;if(_0x794a0b===We||_0x5e9815===we)return 0x1;{const _0x26b264=Gs(_0x5e9815),_0x5bf515=Gs(_0x794a0b);return _0x26b264!==null?_0x5bf515!==null?_0x26b264-_0x5bf515===0x0?_0x5e9815['length']-_0x794a0b['length']:_0x26b264-_0x5bf515:-0x1:_0x5bf515!==null?0x1:_0x5e9815<_0x794a0b?-0x1:0x1;}},ql=function(_0x57b571,_0x518812){return _0x57b571===_0x518812?0x0:_0x57b571<_0x518812?-0x1:0x1;},vt=function(_0x363185,_0x960fe7){if(_0x960fe7&&_0x363185 in _0x960fe7)return _0x960fe7[_0x363185];throw new Error('Missing\x20required\x20key\x20('+_0x363185+')\x20in\x20object:\x20'+O(_0x960fe7));},$i=function(_0x28a7c0){if(typeof _0x28a7c0!='object'||_0x28a7c0===null)return O(_0x28a7c0);const _0x2fc6fc=[];for(const _0x37c33b in _0x28a7c0)_0x2fc6fc['push'](_0x37c33b);_0x2fc6fc['sort']();let _0x4a4103='{';for(let _0x435669=0x0;_0x435669<_0x2fc6fc['length'];_0x435669++)_0x435669!==0x0&&(_0x4a4103+=','),_0x4a4103+=O(_0x2fc6fc[_0x435669]),_0x4a4103+=':',_0x4a4103+=$i(_0x28a7c0[_0x2fc6fc[_0x435669]]);return _0x4a4103+='}',_0x4a4103;},oo=function(_0x3a90d2,_0x45c8a1){const _0x2455f8=_0x3a90d2['length'];if(_0x2455f8<=_0x45c8a1)return[_0x3a90d2];const _0x5dc201=[];for(let _0x49d922=0x0;_0x49d922<_0x2455f8;_0x49d922+=_0x45c8a1)_0x49d922+_0x45c8a1>_0x2455f8?_0x5dc201['push'](_0x3a90d2['substring'](_0x49d922,_0x2455f8)):_0x5dc201['push'](_0x3a90d2['substring'](_0x49d922,_0x49d922+_0x45c8a1));return _0x5dc201;};function x(_0x174fd1,_0x4154c1){for(const _0x71818e in _0x174fd1)_0x174fd1['hasOwnProperty'](_0x71818e)&&_0x4154c1(_0x71818e,_0x174fd1[_0x71818e]);}const ao=function(_0x3ffaed){f(!xn(_0x3ffaed),'Invalid\x20JSON\x20number');const _0x27f3e1=0xb,_0x24c7a5=0x34,_0x45f676=(0x1<<_0x27f3e1-0x1)-0x1;let _0x11ecb9,_0x5a7adb,_0x1015e3,_0x2f6ff9,_0x2ec35e;_0x3ffaed===0x0?(_0x5a7adb=0x0,_0x1015e3=0x0,_0x11ecb9=0x1/_0x3ffaed===-0x1/0x0?0x1:0x0):(_0x11ecb9=_0x3ffaed<0x0,_0x3ffaed=Math['abs'](_0x3ffaed),_0x3ffaed>=Math['pow'](0x2,0x1-_0x45f676)?(_0x2f6ff9=Math['min'](Math['floor'](Math['log'](_0x3ffaed)/Math['LN2']),_0x45f676),_0x5a7adb=_0x2f6ff9+_0x45f676,_0x1015e3=Math['round'](_0x3ffaed*Math['pow'](0x2,_0x24c7a5-_0x2f6ff9)-Math['pow'](0x2,_0x24c7a5))):(_0x5a7adb=0x0,_0x1015e3=Math['round'](_0x3ffaed/Math['pow'](0x2,0x1-_0x45f676-_0x24c7a5))));const _0x9de1d5=[];for(_0x2ec35e=_0x24c7a5;_0x2ec35e;_0x2ec35e-=0x1)_0x9de1d5['push'](_0x1015e3%0x2?0x1:0x0),_0x1015e3=Math['floor'](_0x1015e3/0x2);for(_0x2ec35e=_0x27f3e1;_0x2ec35e;_0x2ec35e-=0x1)_0x9de1d5['push'](_0x5a7adb%0x2?0x1:0x0),_0x5a7adb=Math['floor'](_0x5a7adb/0x2);_0x9de1d5['push'](_0x11ecb9?0x1:0x0),_0x9de1d5['reverse']();const _0x544f14=_0x9de1d5['join']('');let _0x56870d='';for(_0x2ec35e=0x0;_0x2ec35e<0x40;_0x2ec35e+=0x8){let _0x426d20=parseInt(_0x544f14['substr'](_0x2ec35e,0x8),0x2)['toString'](0x10);_0x426d20['length']===0x1&&(_0x426d20='0'+_0x426d20),_0x56870d=_0x56870d+_0x426d20;}return _0x56870d['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x493005,_0x104fc3){let _0x13db43='Unknown\x20Error';_0x493005==='too_big'?_0x13db43='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x493005==='permission_denied'?_0x13db43='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x493005==='unavailable'&&(_0x13db43='The\x20service\x20is\x20unavailable');const _0x3d33ef=new Error(_0x493005+'\x20at\x20'+_0x104fc3['_path']['toString']()+':\x20'+_0x13db43);return _0x3d33ef['code']=_0x493005['toUpperCase'](),_0x3d33ef;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x4a104a){if(Yl['test'](_0x4a104a)){const _0x222f8b=Number(_0x4a104a);if(_0x222f8b>=Ql&&_0x222f8b<=Jl)return _0x222f8b;}return null;},ft=function(_0x27cfde){try{_0x27cfde();}catch(_0x1748b8){setTimeout(()=>{const _0xf7fad2=_0x1748b8['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xf7fad2),_0x1748b8;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xae5b6,_0x4e3231){const _0x342fd8=setTimeout(_0xae5b6,_0x4e3231);return typeof _0x342fd8=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x342fd8):typeof _0x342fd8=='object'&&_0x342fd8['unref']&&_0x342fd8['unref'](),_0x342fd8;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x52c4b0,_0x113dcb){this['appCheckProvider']=_0x113dcb,this['appName']=_0x52c4b0['name'],$(_0x52c4b0)&&_0x52c4b0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x52c4b0['settings']['appCheckToken']),this['appCheck']=_0x113dcb==null?void 0x0:_0x113dcb['getImmediate']({'optional':!0x0}),this['appCheck']||_0x113dcb==null||_0x113dcb['get']()['then'](_0xdd59eb=>this['appCheck']=_0xdd59eb);}['getToken'](_0x4e6d26){if(this['serverAppAppCheckToken']){if(_0x4e6d26)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x4e6d26):new Promise((_0x561518,_0x48f95e)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x4e6d26)['then'](_0x561518,_0x48f95e):_0x561518(null);},0x0);});}['addTokenChangeListener'](_0x33fefa){var _0x67d12d;(_0x67d12d=this['appCheckProvider'])==null||_0x67d12d['get']()['then'](_0x42664e=>_0x42664e['addTokenListener'](_0x33fefa));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1bfbc2,_0x347823,_0x4830a6){this['appName_']=_0x1bfbc2,this['firebaseOptions_']=_0x347823,this['authProvider_']=_0x4830a6,this['auth_']=null,this['auth_']=_0x4830a6['getImmediate']({'optional':!0x0}),this['auth_']||_0x4830a6['onInit'](_0x31b5fe=>this['auth_']=_0x31b5fe);}['getToken'](_0x181bda){return this['auth_']?this['auth_']['getToken'](_0x181bda)['catch'](_0x33c800=>_0x33c800&&_0x33c800['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x33c800)):new Promise((_0x5bef74,_0x4b5427)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x181bda)['then'](_0x5bef74,_0x4b5427):_0x5bef74(null);},0x0);});}['addTokenChangeListener'](_0x239fb9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x239fb9):this['authProvider_']['get']()['then'](_0x2a3f3c=>_0x2a3f3c['addAuthTokenListener'](_0x239fb9));}['removeTokenChangeListener'](_0x2a39e2){this['authProvider_']['get']()['then'](_0x39fdb5=>_0x39fdb5['removeAuthTokenListener'](_0x2a39e2));}['notifyForInvalidToken'](){let _0xeab742='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0xeab742+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0xeab742+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0xeab742+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0xeab742);}}class an{constructor(_0xf689df){this['accessToken']=_0xf689df;}['getToken'](_0x5dcabf){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x461222){_0x461222(this['accessToken']);}['removeTokenChangeListener'](_0x1883a7){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x15824b,_0x5df992,_0x13bd02,_0x180ddd,_0x3cd3e9=!0x1,_0x19c775='',_0x253529=!0x1,_0x4871fe=!0x1,_0x1906b1=null){this['secure']=_0x5df992,this['namespace']=_0x13bd02,this['webSocketOnly']=_0x180ddd,this['nodeAdmin']=_0x3cd3e9,this['persistenceKey']=_0x19c775,this['includeNamespaceInQueryParams']=_0x253529,this['isUsingEmulator']=_0x4871fe,this['emulatorOptions']=_0x1906b1,this['_host']=_0x15824b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x15824b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x5cdeb1){_0x5cdeb1!==this['internalHost']&&(this['internalHost']=_0x5cdeb1,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x546e6e=this['toURLString']();return this['persistenceKey']&&(_0x546e6e+='<'+this['persistenceKey']+'>'),_0x546e6e;}['toURLString'](){const _0x52c95c=this['secure']?'https://':'http://',_0x912ac1=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x52c95c+this['host']+'/'+_0x912ac1;}}function th(_0x408f22){return _0x408f22['host']!==_0x408f22['internalHost']||_0x408f22['isCustomHost']()||_0x408f22['includeNamespaceInQueryParams'];}function vo(_0x1f2515,_0x3b7a87,_0x4cdb96){f(typeof _0x3b7a87=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4cdb96=='object','typeof\x20params\x20must\x20==\x20object');let _0x11dfcd;if(_0x3b7a87===go)_0x11dfcd=(_0x1f2515['secure']?'wss://':'ws://')+_0x1f2515['internalHost']+'/.ws?';else{if(_0x3b7a87===mo)_0x11dfcd=(_0x1f2515['secure']?'https://':'http://')+_0x1f2515['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3b7a87);}th(_0x1f2515)&&(_0x4cdb96['ns']=_0x1f2515['namespace']);const _0x346958=[];return x(_0x4cdb96,(_0x46f838,_0x4c8003)=>{_0x346958['push'](_0x46f838+'='+_0x4c8003);}),_0x11dfcd+_0x346958['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3c4af9,_0x16d97a=0x1){Q(this['counters_'],_0x3c4af9)||(this['counters_'][_0x3c4af9]=0x0),this['counters_'][_0x3c4af9]+=_0x16d97a;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x390c6c){const _0x5b552d=_0x390c6c['toString']();return oi[_0x5b552d]||(oi[_0x5b552d]=new nh()),oi[_0x5b552d];}function ih(_0x38e078,_0x4fe4e1){const _0x5ecc24=_0x38e078['toString']();return ai[_0x5ecc24]||(ai[_0x5ecc24]=_0x4fe4e1()),ai[_0x5ecc24];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x396920){this['onMessage_']=_0x396920,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5414f0,_0x2637a2){this['closeAfterResponse']=_0x5414f0,this['onClose']=_0x2637a2,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x135152,_0x479100){for(this['pendingResponses'][_0x135152]=_0x479100;this['pendingResponses'][this['currentResponseNum']];){const _0x76ece2=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4d5bd1=0x0;_0x4d5bd1<_0x76ece2['length'];++_0x4d5bd1)_0x76ece2[_0x4d5bd1]&&ft(()=>{this['onMessage_'](_0x76ece2[_0x4d5bd1]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0xc5f8d5,_0x18b927,_0x448098,_0x18f079,_0x1fc6b0,_0x4f970f,_0x5da78b){this['connId']=_0xc5f8d5,this['repoInfo']=_0x18b927,this['applicationId']=_0x448098,this['appCheckToken']=_0x18f079,this['authToken']=_0x1fc6b0,this['transportSessionId']=_0x4f970f,this['lastSessionId']=_0x5da78b,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0xc5f8d5),this['stats_']=qi(_0x18b927),this['urlFn']=_0x3294b8=>(this['appCheckToken']&&(_0x3294b8[wi]=this['appCheckToken']),vo(_0x18b927,mo,_0x3294b8));}['open'](_0x51ee94,_0x3b60b8){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3b60b8,this['myPacketOrderer']=new sh(_0x51ee94),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x51db8c)=>{const [_0x593220,_0x454318,_0x536509,_0x73d770,_0x16d1b9]=_0x51db8c;if(this['incrementIncomingBytes_'](_0x51db8c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x593220===qs)this['id']=_0x454318,this['password']=_0x536509;else{if(_0x593220===rh)_0x454318?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x454318,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x593220);}}},(..._0x569f94)=>{const [_0x108649,_0x32eb06]=_0x569f94;this['incrementIncomingBytes_'](_0x569f94),this['myPacketOrderer']['handleResponse'](_0x108649,_0x32eb06);},()=>{this['onClosed_']();},this['urlFn']);const _0xd6582d={};_0xd6582d[qs]='t',_0xd6582d[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0xd6582d[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0xd6582d[co]=Gi,this['transportSessionId']&&(_0xd6582d[lo]=this['transportSessionId']),this['lastSessionId']&&(_0xd6582d[po]=this['lastSessionId']),this['applicationId']&&(_0xd6582d[_o]=this['applicationId']),this['appCheckToken']&&(_0xd6582d[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xd6582d[ho]=uo);const _0x447b06=this['urlFn'](_0xd6582d);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x447b06),this['scriptTagHolder']['addTag'](_0x447b06,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5bac89){const _0x1c17fa=O(_0x5bac89);this['bytesSent']+=_0x1c17fa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1c17fa['length']);const _0x558b20=$r(_0x1c17fa),_0x32e31d=oo(_0x558b20,fh);for(let _0x1b1b90=0x0;_0x1b1b90<_0x32e31d['length'];_0x1b1b90++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x32e31d['length'],_0x32e31d[_0x1b1b90]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x52b859,_0x5edb18){this['myDisconnFrame']=document['createElement']('iframe');const _0x52a468={};_0x52a468[dh]='t',_0x52a468[Eo]=_0x52b859,_0x52a468[Io]=_0x5edb18,this['myDisconnFrame']['src']=this['urlFn'](_0x52a468),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x22f864){const _0x151a1d=O(_0x22f864)['length'];this['bytesReceived']+=_0x151a1d,this['stats_']['incrementCounter']('bytes_received',_0x151a1d);}}class zi{constructor(_0x547403,_0x2081a9,_0x15c09f,_0x27e2a7){this['onDisconnect']=_0x15c09f,this['urlFn']=_0x27e2a7,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x547403,window[ah+this['uniqueCallbackIdentifier']]=_0x2081a9,this['myIFrame']=zi['createIFrame_']();let _0x29085f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x29085f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x371896='<html><body>'+_0x29085f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x371896),this['myIFrame']['doc']['close']();}catch(_0x3d33a1){L('frame\x20writing\x20exception'),_0x3d33a1['stack']&&L(_0x3d33a1['stack']),L(_0x3d33a1);}}}static['createIFrame_'](){const _0x7a91f3=document['createElement']('iframe');if(_0x7a91f3['style']['display']='none',document['body']){document['body']['appendChild'](_0x7a91f3);try{_0x7a91f3['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2f1483=document['domain'];_0x7a91f3['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2f1483+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x7a91f3['contentDocument']?_0x7a91f3['doc']=_0x7a91f3['contentDocument']:_0x7a91f3['contentWindow']?_0x7a91f3['doc']=_0x7a91f3['contentWindow']['document']:_0x7a91f3['document']&&(_0x7a91f3['doc']=_0x7a91f3['document']),_0x7a91f3;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x50b6ac=this['onDisconnect'];_0x50b6ac&&(this['onDisconnect']=null,_0x50b6ac());}['startLongPoll'](_0x4be0f1,_0x2c078f){for(this['myID']=_0x4be0f1,this['myPW']=_0x2c078f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x143bfb={};_0x143bfb[Eo]=this['myID'],_0x143bfb[Io]=this['myPW'],_0x143bfb[wo]=this['currentSerial'];let _0x430c8c=this['urlFn'](_0x143bfb),_0x25a56f='',_0x221ec8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x25a56f['length']<=Co;){const _0x1f3c3a=this['pendingSegs']['shift']();_0x25a56f=_0x25a56f+'&'+lh+_0x221ec8+'='+_0x1f3c3a['seg']+'&'+hh+_0x221ec8+'='+_0x1f3c3a['ts']+'&'+uh+_0x221ec8+'='+_0x1f3c3a['d'],_0x221ec8++;}return _0x430c8c=_0x430c8c+_0x25a56f,this['addLongPollTag_'](_0x430c8c,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x421347,_0x584fe4,_0x386c1c){this['pendingSegs']['push']({'seg':_0x421347,'ts':_0x584fe4,'d':_0x386c1c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4be634,_0x96e785){this['outstandingRequests']['add'](_0x96e785);const _0x115fe2=()=>{this['outstandingRequests']['delete'](_0x96e785),this['newRequest_']();},_0x5fb1ab=setTimeout(_0x115fe2,Math['floor'](ph)),_0x78d86d=()=>{clearTimeout(_0x5fb1ab),_0x115fe2();};this['addTag'](_0x4be634,_0x78d86d);}['addTag'](_0x155df9,_0x47bbd1){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x398d91=this['myIFrame']['doc']['createElement']('script');_0x398d91['type']='text/javascript',_0x398d91['async']=!0x0,_0x398d91['src']=_0x155df9,_0x398d91['onload']=_0x398d91['onreadystatechange']=function(){const _0x398aca=_0x398d91['readyState'];(!_0x398aca||_0x398aca==='loaded'||_0x398aca==='complete')&&(_0x398d91['onload']=_0x398d91['onreadystatechange']=null,_0x398d91['parentNode']&&_0x398d91['parentNode']['removeChild'](_0x398d91),_0x47bbd1());},_0x398d91['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x155df9),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x398d91);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x585b1a,_0x33c53a,_0x58c8af,_0x3b045c,_0x449977,_0x128a50,_0x34d19e){this['connId']=_0x585b1a,this['applicationId']=_0x58c8af,this['appCheckToken']=_0x3b045c,this['authToken']=_0x449977,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x33c53a),this['connURL']=q['connectionURL_'](_0x33c53a,_0x128a50,_0x34d19e,_0x3b045c,_0x58c8af),this['nodeAdmin']=_0x33c53a['nodeAdmin'];}static['connectionURL_'](_0x5d33a6,_0x5854f3,_0x1b2d31,_0x4eacb1,_0x226880){const _0x3c3c85={};return _0x3c3c85[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3c3c85[ho]=uo),_0x5854f3&&(_0x3c3c85[lo]=_0x5854f3),_0x1b2d31&&(_0x3c3c85[po]=_0x1b2d31),_0x4eacb1&&(_0x3c3c85[wi]=_0x4eacb1),_0x226880&&(_0x3c3c85[_o]=_0x226880),vo(_0x5d33a6,go,_0x3c3c85);}['open'](_0x315952,_0x26cee1){this['onDisconnect']=_0x26cee1,this['onMessage']=_0x315952,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x29c61f;_c(),this['mySock']=new gn(this['connURL'],[],_0x29c61f);}catch(_0x468572){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x236a12=_0x468572['message']||_0x468572['data'];_0x236a12&&this['log_'](_0x236a12),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x94c6bd=>{this['handleIncomingFrame'](_0x94c6bd);},this['mySock']['onerror']=_0x87e471=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x58e445=_0x87e471['message']||_0x87e471['data'];_0x58e445&&this['log_'](_0x58e445),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x39ca2e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3e3ac0=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2f5609=navigator['userAgent']['match'](_0x3e3ac0);_0x2f5609&&_0x2f5609['length']>0x1&&parseFloat(_0x2f5609[0x1])<4.4&&(_0x39ca2e=!0x0);}return!_0x39ca2e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0xd9f57b){if(this['frames']['push'](_0xd9f57b),this['frames']['length']===this['totalFrames']){const _0x28a1e0=this['frames']['join']('');this['frames']=null;const _0x2daf14=Nt(_0x28a1e0);this['onMessage'](_0x2daf14);}}['handleNewFrameCount_'](_0x1eedb0){this['totalFrames']=_0x1eedb0,this['frames']=[];}['extractFrameCount_'](_0x51e6e0){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x51e6e0['length']<=0x6){const _0x689da3=Number(_0x51e6e0);if(!isNaN(_0x689da3))return this['handleNewFrameCount_'](_0x689da3),null;}return this['handleNewFrameCount_'](0x1),_0x51e6e0;}['handleIncomingFrame'](_0x3f6dae){if(this['mySock']===null)return;const _0x2aeb24=_0x3f6dae['data'];if(this['bytesReceived']+=_0x2aeb24['length'],this['stats_']['incrementCounter']('bytes_received',_0x2aeb24['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2aeb24);else{const _0x3c9157=this['extractFrameCount_'](_0x2aeb24);_0x3c9157!==null&&this['appendFrame_'](_0x3c9157);}}['send'](_0x515107){this['resetKeepAlive']();const _0x20e62a=O(_0x515107);this['bytesSent']+=_0x20e62a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x20e62a['length']);const _0x474a1b=oo(_0x20e62a,gh);_0x474a1b['length']>0x1&&this['sendString_'](String(_0x474a1b['length']));for(let _0x465cfa=0x0;_0x465cfa<_0x474a1b['length'];_0x465cfa++)this['sendString_'](_0x474a1b[_0x465cfa]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1db396){try{this['mySock']['send'](_0x1db396);}catch(_0xc55b6a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0xc55b6a['message']||_0xc55b6a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x573a46){this['initTransports_'](_0x573a46);}['initTransports_'](_0x236795){const _0x3c27c0=q&&q['isAvailable']();let _0xda2808=_0x3c27c0&&!q['previouslyFailed']();if(_0x236795['webSocketOnly']&&(_0x3c27c0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0xda2808=!0x0),_0xda2808)this['transports_']=[q];else{const _0x4a558c=this['transports_']=[];for(const _0x232d5f of Dt['ALL_TRANSPORTS'])_0x232d5f&&_0x232d5f['isAvailable']()&&_0x4a558c['push'](_0x232d5f);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x1f1d1a,_0x18fbd7,_0x5120a6,_0x286938,_0x12e6e7,_0x1cb82f,_0x5b67a4,_0x21b0f0,_0x4a94c1,_0x3386ba){this['id']=_0x1f1d1a,this['repoInfo_']=_0x18fbd7,this['applicationId_']=_0x5120a6,this['appCheckToken_']=_0x286938,this['authToken_']=_0x12e6e7,this['onMessage_']=_0x1cb82f,this['onReady_']=_0x5b67a4,this['onDisconnect_']=_0x21b0f0,this['onKill_']=_0x4a94c1,this['lastSessionId']=_0x3386ba,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x18fbd7),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2db522=this['transportManager_']['initialTransport']();this['conn_']=new _0x2db522(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2db522['responsesRequiredToBeHealthy']||0x0;const _0x43d7b2=this['connReceiver_'](this['conn_']),_0x586963=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x43d7b2,_0x586963);},Math['floor'](0x0));const _0x31d4d6=_0x2db522['healthyTimeout']||0x0;_0x31d4d6>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x31d4d6)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3b76ef){return _0x5761f8=>{_0x3b76ef===this['conn_']?this['onConnectionLost_'](_0x5761f8):_0x3b76ef===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x4dcf03){return _0x41f580=>{this['state_']!==0x2&&(_0x4dcf03===this['rx_']?this['onPrimaryMessageReceived_'](_0x41f580):_0x4dcf03===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x41f580):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x166109){const _0x1ca1a6={'t':'d','d':_0x166109};this['sendData_'](_0x1ca1a6);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x320417){if(ci in _0x320417){const _0x5836cd=_0x320417[ci];_0x5836cd===Ys?this['upgradeIfSecondaryHealthy_']():_0x5836cd===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5836cd===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x32c1b7){const _0x112ac2=vt('t',_0x32c1b7),_0x411bd8=vt('d',_0x32c1b7);if(_0x112ac2==='c')this['onSecondaryControl_'](_0x411bd8);else{if(_0x112ac2==='d')this['pendingDataMessages']['push'](_0x411bd8);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x112ac2);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x4a320d){const _0x18a91e=vt('t',_0x4a320d),_0xa7e24c=vt('d',_0x4a320d);_0x18a91e==='c'?this['onControl_'](_0xa7e24c):_0x18a91e==='d'&&this['onDataMessage_'](_0xa7e24c);}['onDataMessage_'](_0x39a2e5){this['onPrimaryResponse_'](),this['onMessage_'](_0x39a2e5);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x517378){const _0xaa1025=vt(ci,_0x517378);if(zs in _0x517378){const _0x40b06c=_0x517378[zs];if(_0xaa1025===Th){const _0x2890fc={..._0x40b06c};this['repoInfo_']['isUsingEmulator']&&(_0x2890fc['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2890fc);}else{if(_0xaa1025===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x13e25d=0x0;_0x13e25d<this['pendingDataMessages']['length'];++_0x13e25d)this['onDataMessage_'](this['pendingDataMessages'][_0x13e25d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xaa1025===wh?this['onConnectionShutdown_'](_0x40b06c):_0xaa1025===js?this['onReset_'](_0x40b06c):_0xaa1025===Ch?Ii('Server\x20Error:\x20'+_0x40b06c):_0xaa1025===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xaa1025);}}}['onHandshake_'](_0x99f949){const _0x25fee5=_0x99f949['ts'],_0x45983d=_0x99f949['v'],_0x84c1fb=_0x99f949['h'];this['sessionId']=_0x99f949['s'],this['repoInfo_']['host']=_0x84c1fb,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x25fee5),Gi!==_0x45983d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4382bc=this['transportManager_']['upgradeTransport']();_0x4382bc&&this['startUpgrade_'](_0x4382bc);}['startUpgrade_'](_0x4ab913){this['secondaryConn_']=new _0x4ab913(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x4ab913['responsesRequiredToBeHealthy']||0x0;const _0x4fa196=this['connReceiver_'](this['secondaryConn_']),_0x5e24cc=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4fa196,_0x5e24cc),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x566c9e){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x566c9e),this['repoInfo_']['host']=_0x566c9e,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5c7716,_0x1cffea){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5c7716,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1cffea,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x175a16=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x175a16||this['rx_']===_0x175a16)&&this['close']();}['onConnectionLost_'](_0x181cc9){this['conn_']=null,!_0x181cc9&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2e7940){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2e7940),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0xffefee){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0xffefee);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xdc933e,_0x570a0b,_0x5bcf7d,_0x48dbcd){}['merge'](_0x3001c8,_0x3adbf0,_0xbd9118,_0x17dc84){}['refreshAuthToken'](_0x3b846f){}['refreshAppCheckToken'](_0x10d322){}['onDisconnectPut'](_0x2115ce,_0x547785,_0x267f6b){}['onDisconnectMerge'](_0x382aa7,_0x32ece6,_0x258f91){}['onDisconnectCancel'](_0x2d2d1c,_0x4d0076){}['reportStats'](_0x17c682){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x522f1c){this['allowedEvents_']=_0x522f1c,this['listeners_']={},f(Array['isArray'](_0x522f1c)&&_0x522f1c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x279a32,..._0x11684d){if(Array['isArray'](this['listeners_'][_0x279a32])){const _0x20d552=[...this['listeners_'][_0x279a32]];for(let _0x15b33c=0x0;_0x15b33c<_0x20d552['length'];_0x15b33c++)_0x20d552[_0x15b33c]['callback']['apply'](_0x20d552[_0x15b33c]['context'],_0x11684d);}}['on'](_0x5d82a0,_0x4de32d,_0x3e5b0e){this['validateEventType_'](_0x5d82a0),this['listeners_'][_0x5d82a0]=this['listeners_'][_0x5d82a0]||[],this['listeners_'][_0x5d82a0]['push']({'callback':_0x4de32d,'context':_0x3e5b0e});const _0x2e437f=this['getInitialEvent'](_0x5d82a0);_0x2e437f&&_0x4de32d['apply'](_0x3e5b0e,_0x2e437f);}['off'](_0x455991,_0x5eff3a,_0x219292){this['validateEventType_'](_0x455991);const _0x195ed9=this['listeners_'][_0x455991]||[];for(let _0x5eaa5a=0x0;_0x5eaa5a<_0x195ed9['length'];_0x5eaa5a++)if(_0x195ed9[_0x5eaa5a]['callback']===_0x5eff3a&&(!_0x219292||_0x219292===_0x195ed9[_0x5eaa5a]['context'])){_0x195ed9['splice'](_0x5eaa5a,0x1);return;}}['validateEventType_'](_0x3646f5){f(this['allowedEvents_']['find'](_0x1bde2f=>_0x1bde2f===_0x3646f5),'Unknown\x20event:\x20'+_0x3646f5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xb6ed7){return f(_0xb6ed7==='online','Unknown\x20event\x20type:\x20'+_0xb6ed7),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1f6af7,_0x55c965){if(_0x55c965===void 0x0){this['pieces_']=_0x1f6af7['split']('/');let _0x343c84=0x0;for(let _0x6a1958=0x0;_0x6a1958<this['pieces_']['length'];_0x6a1958++)this['pieces_'][_0x6a1958]['length']>0x0&&(this['pieces_'][_0x343c84]=this['pieces_'][_0x6a1958],_0x343c84++);this['pieces_']['length']=_0x343c84,this['pieceNum_']=0x0;}else this['pieces_']=_0x1f6af7,this['pieceNum_']=_0x55c965;}['toString'](){let _0x474d48='';for(let _0x22fb90=this['pieceNum_'];_0x22fb90<this['pieces_']['length'];_0x22fb90++)this['pieces_'][_0x22fb90]!==''&&(_0x474d48+='/'+this['pieces_'][_0x22fb90]);return _0x474d48||'/';}}function w(){return new C('');}function y(_0x1d8d45){return _0x1d8d45['pieceNum_']>=_0x1d8d45['pieces_']['length']?null:_0x1d8d45['pieces_'][_0x1d8d45['pieceNum_']];}function Ce(_0x568c5d){return _0x568c5d['pieces_']['length']-_0x568c5d['pieceNum_'];}function S(_0x2a0a26){let _0xd7d696=_0x2a0a26['pieceNum_'];return _0xd7d696<_0x2a0a26['pieces_']['length']&&_0xd7d696++,new C(_0x2a0a26['pieces_'],_0xd7d696);}function ji(_0x3223bc){return _0x3223bc['pieceNum_']<_0x3223bc['pieces_']['length']?_0x3223bc['pieces_'][_0x3223bc['pieces_']['length']-0x1]:null;}function bh(_0xf5b537){let _0x433035='';for(let _0x4a047e=_0xf5b537['pieceNum_'];_0x4a047e<_0xf5b537['pieces_']['length'];_0x4a047e++)_0xf5b537['pieces_'][_0x4a047e]!==''&&(_0x433035+='/'+encodeURIComponent(String(_0xf5b537['pieces_'][_0x4a047e])));return _0x433035||'/';}function Mt(_0x3873d0,_0xcfec3f=0x0){return _0x3873d0['pieces_']['slice'](_0x3873d0['pieceNum_']+_0xcfec3f);}function Ro(_0x5d9de4){if(_0x5d9de4['pieceNum_']>=_0x5d9de4['pieces_']['length'])return null;const _0x5a1ec2=[];for(let _0x5ec5f9=_0x5d9de4['pieceNum_'];_0x5ec5f9<_0x5d9de4['pieces_']['length']-0x1;_0x5ec5f9++)_0x5a1ec2['push'](_0x5d9de4['pieces_'][_0x5ec5f9]);return new C(_0x5a1ec2,0x0);}function k(_0x3f9650,_0x2ea0de){const _0x5a0f34=[];for(let _0x181009=_0x3f9650['pieceNum_'];_0x181009<_0x3f9650['pieces_']['length'];_0x181009++)_0x5a0f34['push'](_0x3f9650['pieces_'][_0x181009]);if(_0x2ea0de instanceof C){for(let _0x5496f7=_0x2ea0de['pieceNum_'];_0x5496f7<_0x2ea0de['pieces_']['length'];_0x5496f7++)_0x5a0f34['push'](_0x2ea0de['pieces_'][_0x5496f7]);}else{const _0x186c44=_0x2ea0de['split']('/');for(let _0x3f2630=0x0;_0x3f2630<_0x186c44['length'];_0x3f2630++)_0x186c44[_0x3f2630]['length']>0x0&&_0x5a0f34['push'](_0x186c44[_0x3f2630]);}return new C(_0x5a0f34,0x0);}function v(_0xa4429d){return _0xa4429d['pieceNum_']>=_0xa4429d['pieces_']['length'];}function F(_0x2d28da,_0x1e1086){const _0x32e2ae=y(_0x2d28da),_0x91154=y(_0x1e1086);if(_0x32e2ae===null)return _0x1e1086;if(_0x32e2ae===_0x91154)return F(S(_0x2d28da),S(_0x1e1086));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1e1086+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2d28da+')');}function Rh(_0xec5072,_0x1ca618){const _0x28aedc=Mt(_0xec5072,0x0),_0x32977b=Mt(_0x1ca618,0x0);for(let _0x220fa=0x0;_0x220fa<_0x28aedc['length']&&_0x220fa<_0x32977b['length'];_0x220fa++){const _0x4d2785=qe(_0x28aedc[_0x220fa],_0x32977b[_0x220fa]);if(_0x4d2785!==0x0)return _0x4d2785;}return _0x28aedc['length']===_0x32977b['length']?0x0:_0x28aedc['length']<_0x32977b['length']?-0x1:0x1;}function Ki(_0x27e212,_0x170ee1){if(Ce(_0x27e212)!==Ce(_0x170ee1))return!0x1;for(let _0x2c1f79=_0x27e212['pieceNum_'],_0x1aa6b4=_0x170ee1['pieceNum_'];_0x2c1f79<=_0x27e212['pieces_']['length'];_0x2c1f79++,_0x1aa6b4++)if(_0x27e212['pieces_'][_0x2c1f79]!==_0x170ee1['pieces_'][_0x1aa6b4])return!0x1;return!0x0;}function G(_0x569d45,_0x405b65){let _0x414826=_0x569d45['pieceNum_'],_0x3aecd9=_0x405b65['pieceNum_'];if(Ce(_0x569d45)>Ce(_0x405b65))return!0x1;for(;_0x414826<_0x569d45['pieces_']['length'];){if(_0x569d45['pieces_'][_0x414826]!==_0x405b65['pieces_'][_0x3aecd9])return!0x1;++_0x414826,++_0x3aecd9;}return!0x0;}class Ah{constructor(_0x20dc61,_0x365585){this['errorPrefix_']=_0x365585,this['parts_']=Mt(_0x20dc61,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x450940=0x0;_0x450940<this['parts_']['length'];_0x450940++)this['byteLength_']+=Ln(this['parts_'][_0x450940]);Ao(this);}}function kh(_0x316059,_0x5abff6){_0x316059['parts_']['length']>0x0&&(_0x316059['byteLength_']+=0x1),_0x316059['parts_']['push'](_0x5abff6),_0x316059['byteLength_']+=Ln(_0x5abff6),Ao(_0x316059);}function Ph(_0x5bded6){const _0x4e4982=_0x5bded6['parts_']['pop']();_0x5bded6['byteLength_']-=Ln(_0x4e4982),_0x5bded6['parts_']['length']>0x0&&(_0x5bded6['byteLength_']-=0x1);}function Ao(_0x4b4396){if(_0x4b4396['byteLength_']>Zs)throw new Error(_0x4b4396['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4b4396['byteLength_']+').');if(_0x4b4396['parts_']['length']>Xs)throw new Error(_0x4b4396['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4b4396));}function Oe(_0x38bb7e){return _0x38bb7e['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x38bb7e['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x55e457,_0x482859;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x482859='visibilitychange',_0x55e457='hidden'):typeof document['mozHidden']<'u'?(_0x482859='mozvisibilitychange',_0x55e457='mozHidden'):typeof document['msHidden']<'u'?(_0x482859='msvisibilitychange',_0x55e457='msHidden'):typeof document['webkitHidden']<'u'&&(_0x482859='webkitvisibilitychange',_0x55e457='webkitHidden')),this['visible_']=!0x0,_0x482859&&document['addEventListener'](_0x482859,()=>{const _0x93f63a=!document[_0x55e457];_0x93f63a!==this['visible_']&&(this['visible_']=_0x93f63a,this['trigger']('visible',_0x93f63a));},!0x1);}['getInitialEvent'](_0x38a5c2){return f(_0x38a5c2==='visible','Unknown\x20event\x20type:\x20'+_0x38a5c2),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3a4bb3,_0x1779cc,_0x1d1993,_0x58051f,_0x26841b,_0x3abce7,_0x5d1cf8,_0x489e9e){if(super(),this['repoInfo_']=_0x3a4bb3,this['applicationId_']=_0x1779cc,this['onDataUpdate_']=_0x1d1993,this['onConnectStatus_']=_0x58051f,this['onServerInfoUpdate_']=_0x26841b,this['authTokenProvider_']=_0x3abce7,this['appCheckTokenProvider_']=_0x5d1cf8,this['authOverride_']=_0x489e9e,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x489e9e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3a4bb3['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5ef2ee,_0x1d69d2,_0x1db8c1){const _0x545f89=++this['requestNumber_'],_0x48c846={'r':_0x545f89,'a':_0x5ef2ee,'b':_0x1d69d2};this['log_'](O(_0x48c846)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x48c846),_0x1db8c1&&(this['requestCBHash_'][_0x545f89]=_0x1db8c1);}['get'](_0x197ed5){this['initConnection_']();const _0x39f3bf=new H(),_0x4c0953={'action':'g','request':{'p':_0x197ed5['_path']['toString'](),'q':_0x197ed5['_queryObject']},'onComplete':_0x3e9d6d=>{const _0x2333cc=_0x3e9d6d['d'];_0x3e9d6d['s']==='ok'?_0x39f3bf['resolve'](_0x2333cc):_0x39f3bf['reject'](_0x2333cc);}};this['outstandingGets_']['push'](_0x4c0953),this['outstandingGetCount_']++;const _0x11fdca=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x11fdca),_0x39f3bf['promise'];}['listen'](_0x662340,_0x56bc04,_0x39bed2,_0xe8b423){this['initConnection_']();const _0x37e475=_0x662340['_queryIdentifier'],_0x531552=_0x662340['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x531552+'\x20'+_0x37e475),this['listens']['has'](_0x531552)||this['listens']['set'](_0x531552,new Map()),f(_0x662340['_queryParams']['isDefault']()||!_0x662340['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x531552)['has'](_0x37e475),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1f81f8={'onComplete':_0xe8b423,'hashFn':_0x56bc04,'query':_0x662340,'tag':_0x39bed2};this['listens']['get'](_0x531552)['set'](_0x37e475,_0x1f81f8),this['connected_']&&this['sendListen_'](_0x1f81f8);}['sendGet_'](_0x9a7045){const _0x32baec=this['outstandingGets_'][_0x9a7045];this['sendRequest']('g',_0x32baec['request'],_0x1bb5ae=>{delete this['outstandingGets_'][_0x9a7045],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x32baec['onComplete']&&_0x32baec['onComplete'](_0x1bb5ae);});}['sendListen_'](_0x4a2868){const _0x3d38dc=_0x4a2868['query'],_0x5ec4bc=_0x3d38dc['_path']['toString'](),_0x2f8b18=_0x3d38dc['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5ec4bc+'\x20for\x20'+_0x2f8b18);const _0x40a2a7={'p':_0x5ec4bc},_0x307871='q';_0x4a2868['tag']&&(_0x40a2a7['q']=_0x3d38dc['_queryObject'],_0x40a2a7['t']=_0x4a2868['tag']),_0x40a2a7['h']=_0x4a2868['hashFn'](),this['sendRequest'](_0x307871,_0x40a2a7,_0x428fc7=>{const _0x1c728a=_0x428fc7['d'],_0x16b38e=_0x428fc7['s'];se['warnOnListenWarnings_'](_0x1c728a,_0x3d38dc),(this['listens']['get'](_0x5ec4bc)&&this['listens']['get'](_0x5ec4bc)['get'](_0x2f8b18))===_0x4a2868&&(this['log_']('listen\x20response',_0x428fc7),_0x16b38e!=='ok'&&this['removeListen_'](_0x5ec4bc,_0x2f8b18),_0x4a2868['onComplete']&&_0x4a2868['onComplete'](_0x16b38e,_0x1c728a));});}static['warnOnListenWarnings_'](_0x117bc4,_0x5a34a1){if(_0x117bc4&&typeof _0x117bc4=='object'&&Q(_0x117bc4,'w')){const _0x3950c3=Le(_0x117bc4,'w');if(Array['isArray'](_0x3950c3)&&~_0x3950c3['indexOf']('no_index')){const _0x403228='\x22.indexOn\x22:\x20\x22'+_0x5a34a1['_queryParams']['getIndex']()['toString']()+'\x22',_0x1749fa=_0x5a34a1['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x403228+'\x20at\x20'+_0x1749fa+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1005fa){this['authToken_']=_0x1005fa,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1005fa);}['reduceReconnectDelayIfAdminCredential_'](_0x4b1639){(_0x4b1639&&_0x4b1639['length']===0x28||wc(_0x4b1639))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x433d33){this['appCheckToken_']=_0x433d33,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x28ab7d=this['authToken_'],_0x346b1a=Ic(_0x28ab7d)?'auth':'gauth',_0xc0e90d={'cred':_0x28ab7d};this['authOverride_']===null?_0xc0e90d['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xc0e90d['authvar']=this['authOverride_']),this['sendRequest'](_0x346b1a,_0xc0e90d,_0x87e55d=>{const _0x3cac0=_0x87e55d['s'],_0x157526=_0x87e55d['d']||'error';this['authToken_']===_0x28ab7d&&(_0x3cac0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3cac0,_0x157526));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x31438e=>{const _0x313e93=_0x31438e['s'],_0x508d5f=_0x31438e['d']||'error';_0x313e93==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x313e93,_0x508d5f);});}['unlisten'](_0x15415c,_0x27814a){const _0x13f7b3=_0x15415c['_path']['toString'](),_0x1974f6=_0x15415c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x13f7b3+'\x20'+_0x1974f6),f(_0x15415c['_queryParams']['isDefault']()||!_0x15415c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x13f7b3,_0x1974f6)&&this['connected_']&&this['sendUnlisten_'](_0x13f7b3,_0x1974f6,_0x15415c['_queryObject'],_0x27814a);}['sendUnlisten_'](_0x264353,_0x12ed7a,_0x159276,_0x3e54e3){this['log_']('Unlisten\x20on\x20'+_0x264353+'\x20for\x20'+_0x12ed7a);const _0x1cd9ef={'p':_0x264353},_0x3c58a3='n';_0x3e54e3&&(_0x1cd9ef['q']=_0x159276,_0x1cd9ef['t']=_0x3e54e3),this['sendRequest'](_0x3c58a3,_0x1cd9ef);}['onDisconnectPut'](_0x242446,_0xca2d63,_0x31c90b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x242446,_0xca2d63,_0x31c90b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x242446,'action':'o','data':_0xca2d63,'onComplete':_0x31c90b});}['onDisconnectMerge'](_0x21e852,_0x182bb1,_0x1ddd69){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x21e852,_0x182bb1,_0x1ddd69):this['onDisconnectRequestQueue_']['push']({'pathString':_0x21e852,'action':'om','data':_0x182bb1,'onComplete':_0x1ddd69});}['onDisconnectCancel'](_0x3afee5,_0x436579){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3afee5,null,_0x436579):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3afee5,'action':'oc','data':null,'onComplete':_0x436579});}['sendOnDisconnect_'](_0x1b9706,_0x3d5328,_0x76687,_0x27ad9d){const _0x375d5b={'p':_0x3d5328,'d':_0x76687};this['log_']('onDisconnect\x20'+_0x1b9706,_0x375d5b),this['sendRequest'](_0x1b9706,_0x375d5b,_0x301808=>{_0x27ad9d&&setTimeout(()=>{_0x27ad9d(_0x301808['s'],_0x301808['d']);},Math['floor'](0x0));});}['put'](_0x3aa146,_0x180a06,_0x4e85d5,_0x226497){this['putInternal']('p',_0x3aa146,_0x180a06,_0x4e85d5,_0x226497);}['merge'](_0x433b6f,_0x374d0f,_0x552cd9,_0x110868){this['putInternal']('m',_0x433b6f,_0x374d0f,_0x552cd9,_0x110868);}['putInternal'](_0x315bbe,_0x4dc1fb,_0x7b419e,_0x46dab7,_0x512804){this['initConnection_']();const _0x5aee37={'p':_0x4dc1fb,'d':_0x7b419e};_0x512804!==void 0x0&&(_0x5aee37['h']=_0x512804),this['outstandingPuts_']['push']({'action':_0x315bbe,'request':_0x5aee37,'onComplete':_0x46dab7}),this['outstandingPutCount_']++;const _0x33914a=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x33914a):this['log_']('Buffering\x20put:\x20'+_0x4dc1fb);}['sendPut_'](_0x265698){const _0x5f4f59=this['outstandingPuts_'][_0x265698]['action'],_0x12a8fb=this['outstandingPuts_'][_0x265698]['request'],_0x9eb1b1=this['outstandingPuts_'][_0x265698]['onComplete'];this['outstandingPuts_'][_0x265698]['queued']=this['connected_'],this['sendRequest'](_0x5f4f59,_0x12a8fb,_0x4af26e=>{this['log_'](_0x5f4f59+'\x20response',_0x4af26e),delete this['outstandingPuts_'][_0x265698],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x9eb1b1&&_0x9eb1b1(_0x4af26e['s'],_0x4af26e['d']);});}['reportStats'](_0x35f172){if(this['connected_']){const _0xce4347={'c':_0x35f172};this['log_']('reportStats',_0xce4347),this['sendRequest']('s',_0xce4347,_0x2d77ca=>{if(_0x2d77ca['s']!=='ok'){const _0xd39659=_0x2d77ca['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xd39659);}});}}['onDataMessage_'](_0x497a07){if('r'in _0x497a07){this['log_']('from\x20server:\x20'+O(_0x497a07));const _0x1adce5=_0x497a07['r'],_0x58c3ec=this['requestCBHash_'][_0x1adce5];_0x58c3ec&&(delete this['requestCBHash_'][_0x1adce5],_0x58c3ec(_0x497a07['b']));}else{if('error'in _0x497a07)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x497a07['error'];'a'in _0x497a07&&this['onDataPush_'](_0x497a07['a'],_0x497a07['b']);}}['onDataPush_'](_0x2e96ee,_0x5e294c){this['log_']('handleServerMessage',_0x2e96ee,_0x5e294c),_0x2e96ee==='d'?this['onDataUpdate_'](_0x5e294c['p'],_0x5e294c['d'],!0x1,_0x5e294c['t']):_0x2e96ee==='m'?this['onDataUpdate_'](_0x5e294c['p'],_0x5e294c['d'],!0x0,_0x5e294c['t']):_0x2e96ee==='c'?this['onListenRevoked_'](_0x5e294c['p'],_0x5e294c['q']):_0x2e96ee==='ac'?this['onAuthRevoked_'](_0x5e294c['s'],_0x5e294c['d']):_0x2e96ee==='apc'?this['onAppCheckRevoked_'](_0x5e294c['s'],_0x5e294c['d']):_0x2e96ee==='sd'?this['onSecurityDebugPacket_'](_0x5e294c):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2e96ee)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x530a16,_0x39e4d4){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x530a16),this['lastSessionId']=_0x39e4d4,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x32a87b){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x32a87b));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x17368c){_0x17368c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x17368c;}['onOnline_'](_0x2f8f4d){_0x2f8f4d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x4ea410=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x30c0dd=Math['max'](0x0,this['reconnectDelay_']-_0x4ea410);_0x30c0dd=Math['random']()*_0x30c0dd,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x30c0dd+'ms'),this['scheduleConnect_'](_0x30c0dd),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4d5a4c=this['onDataMessage_']['bind'](this),_0x173c4c=this['onReady_']['bind'](this),_0x2e5d83=this['onRealtimeDisconnect_']['bind'](this),_0x519221=this['id']+':'+se['nextConnectionId_']++,_0x6f152e=this['lastSessionId'];let _0x5d7113=!0x1,_0x917b19=null;const _0x2db4c2=function(){_0x917b19?_0x917b19['close']():(_0x5d7113=!0x0,_0x2e5d83());},_0x2f132b=function(_0x4e2b49){f(_0x917b19,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x917b19['sendRequest'](_0x4e2b49);};this['realtime_']={'close':_0x2db4c2,'sendRequest':_0x2f132b};const _0x97103e=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5a67f1,_0x3b1bdb]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x97103e),this['appCheckTokenProvider_']['getToken'](_0x97103e)]);_0x5d7113?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5a67f1&&_0x5a67f1['accessToken'],this['appCheckToken_']=_0x3b1bdb&&_0x3b1bdb['token'],_0x917b19=new Sh(_0x519221,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4d5a4c,_0x173c4c,_0x2e5d83,_0x3393ed=>{U(_0x3393ed+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x6f152e));}catch(_0x340bcc){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x340bcc),_0x5d7113||(this['repoInfo_']['nodeAdmin']&&U(_0x340bcc),_0x2db4c2());}}}['interrupt'](_0x6815c2){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x6815c2),this['interruptReasons_'][_0x6815c2]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3cedbf){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3cedbf),delete this['interruptReasons_'][_0x3cedbf],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x344c15){const _0x5523ae=_0x344c15-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5523ae});}['cancelSentTransactions_'](){for(let _0x38f094=0x0;_0x38f094<this['outstandingPuts_']['length'];_0x38f094++){const _0x96b81a=this['outstandingPuts_'][_0x38f094];_0x96b81a&&'h'in _0x96b81a['request']&&_0x96b81a['queued']&&(_0x96b81a['onComplete']&&_0x96b81a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x38f094],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2ce187,_0x19b365){let _0x253381;_0x19b365?_0x253381=_0x19b365['map'](_0x2f19e9=>$i(_0x2f19e9))['join']('$'):_0x253381='default';const _0xb25639=this['removeListen_'](_0x2ce187,_0x253381);_0xb25639&&_0xb25639['onComplete']&&_0xb25639['onComplete']('permission_denied');}['removeListen_'](_0xb6343,_0x5edb7d){const _0x5425c7=new C(_0xb6343)['toString']();let _0x3c8182;if(this['listens']['has'](_0x5425c7)){const _0xf06abf=this['listens']['get'](_0x5425c7);_0x3c8182=_0xf06abf['get'](_0x5edb7d),_0xf06abf['delete'](_0x5edb7d),_0xf06abf['size']===0x0&&this['listens']['delete'](_0x5425c7);}else _0x3c8182=void 0x0;return _0x3c8182;}['onAuthRevoked_'](_0x5e5039,_0x43573d){L('Auth\x20token\x20revoked:\x20'+_0x5e5039+'/'+_0x43573d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5e5039==='invalid_token'||_0x5e5039==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x36e960,_0x205c5c){L('App\x20check\x20token\x20revoked:\x20'+_0x36e960+'/'+_0x205c5c),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x36e960==='invalid_token'||_0x36e960==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x365227){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x365227):'msg'in _0x365227&&console['log']('FIREBASE:\x20'+_0x365227['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2175ce of this['listens']['values']())for(const _0x9ffc9c of _0x2175ce['values']())this['sendListen_'](_0x9ffc9c);for(let _0x55b6cc=0x0;_0x55b6cc<this['outstandingPuts_']['length'];_0x55b6cc++)this['outstandingPuts_'][_0x55b6cc]&&this['sendPut_'](_0x55b6cc);for(;this['onDisconnectRequestQueue_']['length'];){const _0x266e6b=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x266e6b['action'],_0x266e6b['pathString'],_0x266e6b['data'],_0x266e6b['onComplete']);}for(let _0x2ee40c=0x0;_0x2ee40c<this['outstandingGets_']['length'];_0x2ee40c++)this['outstandingGets_'][_0x2ee40c]&&this['sendGet_'](_0x2ee40c);}['sendConnectStats_'](){const _0x1e807b={};let _0x45441c='js';_0x1e807b['sdk.'+_0x45441c+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x1e807b['framework.cordova']=0x1:Kr()&&(_0x1e807b['framework.reactnative']=0x1),this['reportStats'](_0x1e807b);}['shouldReconnect_'](){const _0x2bf250=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x2bf250;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x34575f,_0xe0e270){this['name']=_0x34575f,this['node']=_0xe0e270;}static['Wrap'](_0x1a3dee,_0x688cdf){return new E(_0x1a3dee,_0x688cdf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x3974c2,_0xf2ef31){const _0x23edf7=new E(We,_0x3974c2),_0x14f5e5=new E(We,_0xf2ef31);return this['compare'](_0x23edf7,_0x14f5e5)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x516cfe){sn=_0x516cfe;}['compare'](_0x4ac9dd,_0x2abe44){return qe(_0x4ac9dd['name'],_0x2abe44['name']);}['isDefinedOn'](_0x36ef6a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x29af62,_0x188d52){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x9ce065,_0x49199d){return f(typeof _0x9ce065=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x9ce065,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x62ca3a,_0x34c108,_0x4d470e,_0x491499,_0x18c5f5=null){this['isReverse_']=_0x491499,this['resultGenerator_']=_0x18c5f5,this['nodeStack_']=[];let _0x3ea98d=0x1;for(;!_0x62ca3a['isEmpty']();)if(_0x62ca3a=_0x62ca3a,_0x3ea98d=_0x34c108?_0x4d470e(_0x62ca3a['key'],_0x34c108):0x1,_0x491499&&(_0x3ea98d*=-0x1),_0x3ea98d<0x0)this['isReverse_']?_0x62ca3a=_0x62ca3a['left']:_0x62ca3a=_0x62ca3a['right'];else{if(_0x3ea98d===0x0){this['nodeStack_']['push'](_0x62ca3a);break;}else this['nodeStack_']['push'](_0x62ca3a),this['isReverse_']?_0x62ca3a=_0x62ca3a['right']:_0x62ca3a=_0x62ca3a['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1edb7d=this['nodeStack_']['pop'](),_0x59cd5e;if(this['resultGenerator_']?_0x59cd5e=this['resultGenerator_'](_0x1edb7d['key'],_0x1edb7d['value']):_0x59cd5e={'key':_0x1edb7d['key'],'value':_0x1edb7d['value']},this['isReverse_']){for(_0x1edb7d=_0x1edb7d['left'];!_0x1edb7d['isEmpty']();)this['nodeStack_']['push'](_0x1edb7d),_0x1edb7d=_0x1edb7d['right'];}else{for(_0x1edb7d=_0x1edb7d['right'];!_0x1edb7d['isEmpty']();)this['nodeStack_']['push'](_0x1edb7d),_0x1edb7d=_0x1edb7d['left'];}return _0x59cd5e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3f01b1=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3f01b1['key'],_0x3f01b1['value']):{'key':_0x3f01b1['key'],'value':_0x3f01b1['value']};}}class M{constructor(_0x595f78,_0x588966,_0x234041,_0x451070,_0x325014){this['key']=_0x595f78,this['value']=_0x588966,this['color']=_0x234041??M['RED'],this['left']=_0x451070??B['EMPTY_NODE'],this['right']=_0x325014??B['EMPTY_NODE'];}['copy'](_0x3ce654,_0x14dee4,_0x1fd786,_0xae04f5,_0x4f4488){return new M(_0x3ce654??this['key'],_0x14dee4??this['value'],_0x1fd786??this['color'],_0xae04f5??this['left'],_0x4f4488??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x15348c){return this['left']['inorderTraversal'](_0x15348c)||!!_0x15348c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x15348c);}['reverseTraversal'](_0x572e8a){return this['right']['reverseTraversal'](_0x572e8a)||_0x572e8a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x572e8a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x133502,_0x3f444e,_0xb3ef1f){let _0x1ff39b=this;const _0x4efde2=_0xb3ef1f(_0x133502,_0x1ff39b['key']);return _0x4efde2<0x0?_0x1ff39b=_0x1ff39b['copy'](null,null,null,_0x1ff39b['left']['insert'](_0x133502,_0x3f444e,_0xb3ef1f),null):_0x4efde2===0x0?_0x1ff39b=_0x1ff39b['copy'](null,_0x3f444e,null,null,null):_0x1ff39b=_0x1ff39b['copy'](null,null,null,null,_0x1ff39b['right']['insert'](_0x133502,_0x3f444e,_0xb3ef1f)),_0x1ff39b['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2b8878=this;return!_0x2b8878['left']['isRed_']()&&!_0x2b8878['left']['left']['isRed_']()&&(_0x2b8878=_0x2b8878['moveRedLeft_']()),_0x2b8878=_0x2b8878['copy'](null,null,null,_0x2b8878['left']['removeMin_'](),null),_0x2b8878['fixUp_']();}['remove'](_0x36b29b,_0x48747b){let _0x202478,_0x12aa91;if(_0x202478=this,_0x48747b(_0x36b29b,_0x202478['key'])<0x0)!_0x202478['left']['isEmpty']()&&!_0x202478['left']['isRed_']()&&!_0x202478['left']['left']['isRed_']()&&(_0x202478=_0x202478['moveRedLeft_']()),_0x202478=_0x202478['copy'](null,null,null,_0x202478['left']['remove'](_0x36b29b,_0x48747b),null);else{if(_0x202478['left']['isRed_']()&&(_0x202478=_0x202478['rotateRight_']()),!_0x202478['right']['isEmpty']()&&!_0x202478['right']['isRed_']()&&!_0x202478['right']['left']['isRed_']()&&(_0x202478=_0x202478['moveRedRight_']()),_0x48747b(_0x36b29b,_0x202478['key'])===0x0){if(_0x202478['right']['isEmpty']())return B['EMPTY_NODE'];_0x12aa91=_0x202478['right']['min_'](),_0x202478=_0x202478['copy'](_0x12aa91['key'],_0x12aa91['value'],null,null,_0x202478['right']['removeMin_']());}_0x202478=_0x202478['copy'](null,null,null,null,_0x202478['right']['remove'](_0x36b29b,_0x48747b));}return _0x202478['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x798929=this;return _0x798929['right']['isRed_']()&&!_0x798929['left']['isRed_']()&&(_0x798929=_0x798929['rotateLeft_']()),_0x798929['left']['isRed_']()&&_0x798929['left']['left']['isRed_']()&&(_0x798929=_0x798929['rotateRight_']()),_0x798929['left']['isRed_']()&&_0x798929['right']['isRed_']()&&(_0x798929=_0x798929['colorFlip_']()),_0x798929;}['moveRedLeft_'](){let _0x24a112=this['colorFlip_']();return _0x24a112['right']['left']['isRed_']()&&(_0x24a112=_0x24a112['copy'](null,null,null,null,_0x24a112['right']['rotateRight_']()),_0x24a112=_0x24a112['rotateLeft_'](),_0x24a112=_0x24a112['colorFlip_']()),_0x24a112;}['moveRedRight_'](){let _0x19183c=this['colorFlip_']();return _0x19183c['left']['left']['isRed_']()&&(_0x19183c=_0x19183c['rotateRight_'](),_0x19183c=_0x19183c['colorFlip_']()),_0x19183c;}['rotateLeft_'](){const _0x55efba=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x55efba,null);}['rotateRight_'](){const _0x2aa8a1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x2aa8a1);}['colorFlip_'](){const _0x34d0f0=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x1bb2ad=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x34d0f0,_0x1bb2ad);}['checkMaxDepth_'](){const _0x3b3431=this['check_']();return Math['pow'](0x2,_0x3b3431)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x362546=this['left']['check_']();if(_0x362546!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x362546+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5d3535,_0x2b5eae,_0xade724,_0x580730,_0x239a6b){return this;}['insert'](_0x14423c,_0x45fd93,_0x459a33){return new M(_0x14423c,_0x45fd93,null);}['remove'](_0x3c33c2,_0x5c6c86){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5a580a){return!0x1;}['reverseTraversal'](_0xa94371){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x597cd1,_0x68901b=B['EMPTY_NODE']){this['comparator_']=_0x597cd1,this['root_']=_0x68901b;}['insert'](_0x1eab3d,_0x4284c7){return new B(this['comparator_'],this['root_']['insert'](_0x1eab3d,_0x4284c7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1e443a){return new B(this['comparator_'],this['root_']['remove'](_0x1e443a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x135c4f){let _0x5a73a5,_0xdbc6cb=this['root_'];for(;!_0xdbc6cb['isEmpty']();){if(_0x5a73a5=this['comparator_'](_0x135c4f,_0xdbc6cb['key']),_0x5a73a5===0x0)return _0xdbc6cb['value'];_0x5a73a5<0x0?_0xdbc6cb=_0xdbc6cb['left']:_0x5a73a5>0x0&&(_0xdbc6cb=_0xdbc6cb['right']);}return null;}['getPredecessorKey'](_0x91f3c3){let _0x1dea92,_0x2febda=this['root_'],_0x2b5964=null;for(;!_0x2febda['isEmpty']();)if(_0x1dea92=this['comparator_'](_0x91f3c3,_0x2febda['key']),_0x1dea92===0x0){if(_0x2febda['left']['isEmpty']())return _0x2b5964?_0x2b5964['key']:null;for(_0x2febda=_0x2febda['left'];!_0x2febda['right']['isEmpty']();)_0x2febda=_0x2febda['right'];return _0x2febda['key'];}else _0x1dea92<0x0?_0x2febda=_0x2febda['left']:_0x1dea92>0x0&&(_0x2b5964=_0x2febda,_0x2febda=_0x2febda['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xc88a5b){return this['root_']['inorderTraversal'](_0xc88a5b);}['reverseTraversal'](_0x71710){return this['root_']['reverseTraversal'](_0x71710);}['getIterator'](_0x1f6a77){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x1f6a77);}['getIteratorFrom'](_0x4a1f41,_0x2c4560){return new rn(this['root_'],_0x4a1f41,this['comparator_'],!0x1,_0x2c4560);}['getReverseIteratorFrom'](_0x152728,_0x1d3eab){return new rn(this['root_'],_0x152728,this['comparator_'],!0x0,_0x1d3eab);}['getReverseIterator'](_0x8d0291){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x8d0291);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x37600d,_0x28f243){return qe(_0x37600d['name'],_0x28f243['name']);}function Qi(_0x41cf30,_0xc73e2){return qe(_0x41cf30,_0xc73e2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x170328){Ci=_0x170328;}const Po=function(_0x12b658){return typeof _0x12b658=='number'?'number:'+ao(_0x12b658):'string:'+_0x12b658;},No=function(_0x12feaf){if(_0x12feaf['isLeafNode']()){const _0xf7a074=_0x12feaf['val']();f(typeof _0xf7a074=='string'||typeof _0xf7a074=='number'||typeof _0xf7a074=='object'&&Q(_0xf7a074,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x12feaf===Ci||_0x12feaf['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x12feaf===Ci||_0x12feaf['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x23166c){nr=_0x23166c;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x185174,_0x22bbe8=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x185174,this['priorityNode_']=_0x22bbe8,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xccdbde){return new D(this['value_'],_0xccdbde);}['getImmediateChild'](_0x4598d6){return _0x4598d6==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x101dbf){return v(_0x101dbf)?this:y(_0x101dbf)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2d0a64,_0x14544c){return null;}['updateImmediateChild'](_0x587287,_0x3cc024){return _0x587287==='.priority'?this['updatePriority'](_0x3cc024):_0x3cc024['isEmpty']()&&_0x587287!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x587287,_0x3cc024)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x72ef69,_0x1d1aa7){const _0x1e0579=y(_0x72ef69);return _0x1e0579===null?_0x1d1aa7:_0x1d1aa7['isEmpty']()&&_0x1e0579!=='.priority'?this:(f(_0x1e0579!=='.priority'||Ce(_0x72ef69)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x1e0579,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x72ef69),_0x1d1aa7)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2d7803,_0x11f230){return!0x1;}['val'](_0x2cb468){return _0x2cb468&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x7114b7='';this['priorityNode_']['isEmpty']()||(_0x7114b7+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x5b9d7c=typeof this['value_'];_0x7114b7+=_0x5b9d7c+':',_0x5b9d7c==='number'?_0x7114b7+=ao(this['value_']):_0x7114b7+=this['value_'],this['lazyHash_']=ro(_0x7114b7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x93d1ad){return _0x93d1ad===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x93d1ad instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x93d1ad['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x93d1ad));}['compareToLeafNode_'](_0xa297da){const _0x38ace2=typeof _0xa297da['value_'],_0x341f28=typeof this['value_'],_0x759a95=D['VALUE_TYPE_ORDER']['indexOf'](_0x38ace2),_0x4cc23a=D['VALUE_TYPE_ORDER']['indexOf'](_0x341f28);return f(_0x759a95>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x38ace2),f(_0x4cc23a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x341f28),_0x759a95===_0x4cc23a?_0x341f28==='object'?0x0:this['value_']<_0xa297da['value_']?-0x1:this['value_']===_0xa297da['value_']?0x0:0x1:_0x4cc23a-_0x759a95;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x51862d){if(_0x51862d===this)return!0x0;if(_0x51862d['isLeafNode']()){const _0x3f0193=_0x51862d;return this['value_']===_0x3f0193['value_']&&this['priorityNode_']['equals'](_0x3f0193['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2181b4){Oo=_0x2181b4;}function Wh(_0x20694b){Do=_0x20694b;}class Bh extends Fn{['compare'](_0x3da0a9,_0x3c0578){const _0x24459a=_0x3da0a9['node']['getPriority'](),_0x142ef3=_0x3c0578['node']['getPriority'](),_0x506689=_0x24459a['compareTo'](_0x142ef3);return _0x506689===0x0?qe(_0x3da0a9['name'],_0x3c0578['name']):_0x506689;}['isDefinedOn'](_0x54d11e){return!_0x54d11e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4e3eaa,_0x589053){return!_0x4e3eaa['getPriority']()['equals'](_0x589053['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x49c2e4,_0x571a1d){const _0x4475ec=Oo(_0x49c2e4);return new E(_0x571a1d,new D('[PRIORITY-POST]',_0x4475ec));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1f6d23){const _0x49a037=_0x3c148b=>parseInt(Math['log'](_0x3c148b)/Vh,0xa),_0x288482=_0x28faec=>parseInt(Array(_0x28faec+0x1)['join']('1'),0x2);this['count']=_0x49a037(_0x1f6d23+0x1),this['current_']=this['count']-0x1;const _0xeeb49f=_0x288482(this['count']);this['bits_']=_0x1f6d23+0x1&_0xeeb49f;}['nextBitIsOne'](){const _0xf468ec=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0xf468ec;}}const yn=function(_0x5a7902,_0x590e48,_0x689a1,_0x52804f){_0x5a7902['sort'](_0x590e48);const _0x15c310=function(_0x18d79e,_0x2a2cc5){const _0x53426a=_0x2a2cc5-_0x18d79e;let _0x533f7c,_0x140919;if(_0x53426a===0x0)return null;if(_0x53426a===0x1)return _0x533f7c=_0x5a7902[_0x18d79e],_0x140919=_0x689a1?_0x689a1(_0x533f7c):_0x533f7c,new M(_0x140919,_0x533f7c['node'],M['BLACK'],null,null);{const _0xfe04ca=parseInt(_0x53426a/0x2,0xa)+_0x18d79e,_0xa157d8=_0x15c310(_0x18d79e,_0xfe04ca),_0x1d0cea=_0x15c310(_0xfe04ca+0x1,_0x2a2cc5);return _0x533f7c=_0x5a7902[_0xfe04ca],_0x140919=_0x689a1?_0x689a1(_0x533f7c):_0x533f7c,new M(_0x140919,_0x533f7c['node'],M['BLACK'],_0xa157d8,_0x1d0cea);}},_0x469cbb=function(_0x427b0c){let _0x2f1c5a=null,_0x5590a6=null,_0x1cbcac=_0x5a7902['length'];const _0x3c8a27=function(_0x118cc1,_0x832e10){const _0x33397b=_0x1cbcac-_0x118cc1,_0x2cfcbe=_0x1cbcac;_0x1cbcac-=_0x118cc1;const _0x5036f6=_0x15c310(_0x33397b+0x1,_0x2cfcbe),_0x498a2f=_0x5a7902[_0x33397b],_0x1734bd=_0x689a1?_0x689a1(_0x498a2f):_0x498a2f;_0x3114db(new M(_0x1734bd,_0x498a2f['node'],_0x832e10,null,_0x5036f6));},_0x3114db=function(_0x54c46d){_0x2f1c5a?(_0x2f1c5a['left']=_0x54c46d,_0x2f1c5a=_0x54c46d):(_0x5590a6=_0x54c46d,_0x2f1c5a=_0x54c46d);};for(let _0x362a74=0x0;_0x362a74<_0x427b0c['count'];++_0x362a74){const _0x240dc2=_0x427b0c['nextBitIsOne'](),_0x470968=Math['pow'](0x2,_0x427b0c['count']-(_0x362a74+0x1));_0x240dc2?_0x3c8a27(_0x470968,M['BLACK']):(_0x3c8a27(_0x470968,M['BLACK']),_0x3c8a27(_0x470968,M['RED']));}return _0x5590a6;},_0x4b1fbb=new Hh(_0x5a7902['length']),_0x32cc6c=_0x469cbb(_0x4b1fbb);return new B(_0x52804f||_0x590e48,_0x32cc6c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x1c1261,_0x4a3225){this['indexes_']=_0x1c1261,this['indexSet_']=_0x4a3225;}['get'](_0x7ac58e){const _0x426b17=Le(this['indexes_'],_0x7ac58e);if(!_0x426b17)throw new Error('No\x20index\x20defined\x20for\x20'+_0x7ac58e);return _0x426b17 instanceof B?_0x426b17:null;}['hasIndex'](_0x1d3034){return Q(this['indexSet_'],_0x1d3034['toString']());}['addIndex'](_0x4fd088,_0x296052){f(_0x4fd088!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2288b1=[];let _0x45f80c=!0x1;const _0x20d592=_0x296052['getIterator'](E['Wrap']);let _0x3cab48=_0x20d592['getNext']();for(;_0x3cab48;)_0x45f80c=_0x45f80c||_0x4fd088['isDefinedOn'](_0x3cab48['node']),_0x2288b1['push'](_0x3cab48),_0x3cab48=_0x20d592['getNext']();let _0x24270c;_0x45f80c?_0x24270c=yn(_0x2288b1,_0x4fd088['getCompare']()):_0x24270c=Qe;const _0x1628fc=_0x4fd088['toString'](),_0x2cdbb9={...this['indexSet_']};_0x2cdbb9[_0x1628fc]=_0x4fd088;const _0x280af1={...this['indexes_']};return _0x280af1[_0x1628fc]=_0x24270c,new te(_0x280af1,_0x2cdbb9);}['addToIndexes'](_0x4fc372,_0x841d6e){const _0x263e25=_n(this['indexes_'],(_0x4db6c6,_0x20f4a0)=>{const _0x2fde16=Le(this['indexSet_'],_0x20f4a0);if(f(_0x2fde16,'Missing\x20index\x20implementation\x20for\x20'+_0x20f4a0),_0x4db6c6===Qe){if(_0x2fde16['isDefinedOn'](_0x4fc372['node'])){const _0x588c5c=[],_0x31027b=_0x841d6e['getIterator'](E['Wrap']);let _0x2022b8=_0x31027b['getNext']();for(;_0x2022b8;)_0x2022b8['name']!==_0x4fc372['name']&&_0x588c5c['push'](_0x2022b8),_0x2022b8=_0x31027b['getNext']();return _0x588c5c['push'](_0x4fc372),yn(_0x588c5c,_0x2fde16['getCompare']());}else return Qe;}else{const _0x5cbddf=_0x841d6e['get'](_0x4fc372['name']);let _0x45e6cb=_0x4db6c6;return _0x5cbddf&&(_0x45e6cb=_0x45e6cb['remove'](new E(_0x4fc372['name'],_0x5cbddf))),_0x45e6cb['insert'](_0x4fc372,_0x4fc372['node']);}});return new te(_0x263e25,this['indexSet_']);}['removeFromIndexes'](_0x30cd77,_0x38ea04){const _0x3fddb3=_n(this['indexes_'],_0x559f32=>{if(_0x559f32===Qe)return _0x559f32;{const _0x2b951d=_0x38ea04['get'](_0x30cd77['name']);return _0x2b951d?_0x559f32['remove'](new E(_0x30cd77['name'],_0x2b951d)):_0x559f32;}});return new te(_0x3fddb3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x297c59,_0x2af05a,_0x5887ef){this['children_']=_0x297c59,this['priorityNode_']=_0x2af05a,this['indexMap_']=_0x5887ef,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1ff194){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1ff194,this['indexMap_']);}['getImmediateChild'](_0x3e5054){if(_0x3e5054==='.priority')return this['getPriority']();{const _0x164176=this['children_']['get'](_0x3e5054);return _0x164176===null?It:_0x164176;}}['getChild'](_0x1cfea0){const _0xb082de=y(_0x1cfea0);return _0xb082de===null?this:this['getImmediateChild'](_0xb082de)['getChild'](S(_0x1cfea0));}['hasChild'](_0x5a83ef){return this['children_']['get'](_0x5a83ef)!==null;}['updateImmediateChild'](_0x2b5ec5,_0xc07b86){if(f(_0xc07b86,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2b5ec5==='.priority')return this['updatePriority'](_0xc07b86);{const _0x12cd3d=new E(_0x2b5ec5,_0xc07b86);let _0x2b2e1c,_0x2d087f;_0xc07b86['isEmpty']()?(_0x2b2e1c=this['children_']['remove'](_0x2b5ec5),_0x2d087f=this['indexMap_']['removeFromIndexes'](_0x12cd3d,this['children_'])):(_0x2b2e1c=this['children_']['insert'](_0x2b5ec5,_0xc07b86),_0x2d087f=this['indexMap_']['addToIndexes'](_0x12cd3d,this['children_']));const _0x2e92cd=_0x2b2e1c['isEmpty']()?It:this['priorityNode_'];return new g(_0x2b2e1c,_0x2e92cd,_0x2d087f);}}['updateChild'](_0xe764c3,_0x5403a5){const _0x7d2dc8=y(_0xe764c3);if(_0x7d2dc8===null)return _0x5403a5;{f(y(_0xe764c3)!=='.priority'||Ce(_0xe764c3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1e2b89=this['getImmediateChild'](_0x7d2dc8)['updateChild'](S(_0xe764c3),_0x5403a5);return this['updateImmediateChild'](_0x7d2dc8,_0x1e2b89);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4831e6){if(this['isEmpty']())return null;const _0x5a1702={};let _0x244708=0x0,_0x1d0693=0x0,_0x1c3f24=!0x0;if(this['forEachChild'](R,(_0x9d7ef0,_0x1607c1)=>{_0x5a1702[_0x9d7ef0]=_0x1607c1['val'](_0x4831e6),_0x244708++,_0x1c3f24&&g['INTEGER_REGEXP_']['test'](_0x9d7ef0)?_0x1d0693=Math['max'](_0x1d0693,Number(_0x9d7ef0)):_0x1c3f24=!0x1;}),!_0x4831e6&&_0x1c3f24&&_0x1d0693<0x2*_0x244708){const _0xcb6fae=[];for(const _0x389364 in _0x5a1702)_0xcb6fae[_0x389364]=_0x5a1702[_0x389364];return _0xcb6fae;}else return _0x4831e6&&!this['getPriority']()['isEmpty']()&&(_0x5a1702['.priority']=this['getPriority']()['val']()),_0x5a1702;}['hash'](){if(this['lazyHash_']===null){let _0x339a79='';this['getPriority']()['isEmpty']()||(_0x339a79+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3d70eb,_0xe1b170)=>{const _0x4766af=_0xe1b170['hash']();_0x4766af!==''&&(_0x339a79+=':'+_0x3d70eb+':'+_0x4766af);}),this['lazyHash_']=_0x339a79===''?'':ro(_0x339a79);}return this['lazyHash_'];}['getPredecessorChildName'](_0x284f12,_0x142a22,_0x259f20){const _0x1cbec5=this['resolveIndex_'](_0x259f20);if(_0x1cbec5){const _0x2d6102=_0x1cbec5['getPredecessorKey'](new E(_0x284f12,_0x142a22));return _0x2d6102?_0x2d6102['name']:null;}else return this['children_']['getPredecessorKey'](_0x284f12);}['getFirstChildName'](_0xafcfc1){const _0x2b6b1a=this['resolveIndex_'](_0xafcfc1);if(_0x2b6b1a){const _0x5e1d76=_0x2b6b1a['minKey']();return _0x5e1d76&&_0x5e1d76['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1020c4){const _0x2c0250=this['getFirstChildName'](_0x1020c4);return _0x2c0250?new E(_0x2c0250,this['children_']['get'](_0x2c0250)):null;}['getLastChildName'](_0x108683){const _0x46d594=this['resolveIndex_'](_0x108683);if(_0x46d594){const _0x5c46d5=_0x46d594['maxKey']();return _0x5c46d5&&_0x5c46d5['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x534344){const _0x22be6f=this['getLastChildName'](_0x534344);return _0x22be6f?new E(_0x22be6f,this['children_']['get'](_0x22be6f)):null;}['forEachChild'](_0x5ec4fc,_0x4128ae){const _0x179a28=this['resolveIndex_'](_0x5ec4fc);return _0x179a28?_0x179a28['inorderTraversal'](_0x3acdcc=>_0x4128ae(_0x3acdcc['name'],_0x3acdcc['node'])):this['children_']['inorderTraversal'](_0x4128ae);}['getIterator'](_0x303ed0){return this['getIteratorFrom'](_0x303ed0['minPost'](),_0x303ed0);}['getIteratorFrom'](_0x8ede05,_0x317a64){const _0x2fcf2e=this['resolveIndex_'](_0x317a64);if(_0x2fcf2e)return _0x2fcf2e['getIteratorFrom'](_0x8ede05,_0x75e3a5=>_0x75e3a5);{const _0x16a365=this['children_']['getIteratorFrom'](_0x8ede05['name'],E['Wrap']);let _0x449ca8=_0x16a365['peek']();for(;_0x449ca8!=null&&_0x317a64['compare'](_0x449ca8,_0x8ede05)<0x0;)_0x16a365['getNext'](),_0x449ca8=_0x16a365['peek']();return _0x16a365;}}['getReverseIterator'](_0x1eea47){return this['getReverseIteratorFrom'](_0x1eea47['maxPost'](),_0x1eea47);}['getReverseIteratorFrom'](_0x50c771,_0x366265){const _0xe17188=this['resolveIndex_'](_0x366265);if(_0xe17188)return _0xe17188['getReverseIteratorFrom'](_0x50c771,_0x1681af=>_0x1681af);{const _0x19060b=this['children_']['getReverseIteratorFrom'](_0x50c771['name'],E['Wrap']);let _0x170f19=_0x19060b['peek']();for(;_0x170f19!=null&&_0x366265['compare'](_0x170f19,_0x50c771)>0x0;)_0x19060b['getNext'](),_0x170f19=_0x19060b['peek']();return _0x19060b;}}['compareTo'](_0x224620){return this['isEmpty']()?_0x224620['isEmpty']()?0x0:-0x1:_0x224620['isLeafNode']()||_0x224620['isEmpty']()?0x1:_0x224620===Kt?-0x1:0x0;}['withIndex'](_0x5aee8c){if(_0x5aee8c===ve||this['indexMap_']['hasIndex'](_0x5aee8c))return this;{const _0x131501=this['indexMap_']['addIndex'](_0x5aee8c,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x131501);}}['isIndexed'](_0x5aea7a){return _0x5aea7a===ve||this['indexMap_']['hasIndex'](_0x5aea7a);}['equals'](_0x295eb1){if(_0x295eb1===this)return!0x0;if(_0x295eb1['isLeafNode']())return!0x1;{const _0x4d3f31=_0x295eb1;if(this['getPriority']()['equals'](_0x4d3f31['getPriority']())){if(this['children_']['count']()===_0x4d3f31['children_']['count']()){const _0x5e0942=this['getIterator'](R),_0x40fbce=_0x4d3f31['getIterator'](R);let _0x67c341=_0x5e0942['getNext'](),_0x5370d1=_0x40fbce['getNext']();for(;_0x67c341&&_0x5370d1;){if(_0x67c341['name']!==_0x5370d1['name']||!_0x67c341['node']['equals'](_0x5370d1['node']))return!0x1;_0x67c341=_0x5e0942['getNext'](),_0x5370d1=_0x40fbce['getNext']();}return _0x67c341===null&&_0x5370d1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x50b4d2){return _0x50b4d2===ve?null:this['indexMap_']['get'](_0x50b4d2['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x55963b){return _0x55963b===this?0x0:0x1;}['equals'](_0x384757){return _0x384757===this;}['getPriority'](){return this;}['getImmediateChild'](_0x47bec3){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x4a99ca,_0x54c231=null){if(_0x4a99ca===null)return g['EMPTY_NODE'];if(typeof _0x4a99ca=='object'&&'.priority'in _0x4a99ca&&(_0x54c231=_0x4a99ca['.priority']),f(_0x54c231===null||typeof _0x54c231=='string'||typeof _0x54c231=='number'||typeof _0x54c231=='object'&&'.sv'in _0x54c231,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x54c231),typeof _0x4a99ca=='object'&&'.value'in _0x4a99ca&&_0x4a99ca['.value']!==null&&(_0x4a99ca=_0x4a99ca['.value']),typeof _0x4a99ca!='object'||'.sv'in _0x4a99ca){const _0x4b4dd7=_0x4a99ca;return new D(_0x4b4dd7,A(_0x54c231));}if(!(_0x4a99ca instanceof Array)&&Gh){const _0x322c5e=[];let _0x4428b8=!0x1;if(x(_0x4a99ca,(_0x2a5e78,_0x47a172)=>{if(_0x2a5e78['substring'](0x0,0x1)!=='.'){const _0x2c8195=A(_0x47a172);_0x2c8195['isEmpty']()||(_0x4428b8=_0x4428b8||!_0x2c8195['getPriority']()['isEmpty'](),_0x322c5e['push'](new E(_0x2a5e78,_0x2c8195)));}}),_0x322c5e['length']===0x0)return g['EMPTY_NODE'];const _0xf6111=yn(_0x322c5e,xh,_0x411a1d=>_0x411a1d['name'],Qi);if(_0x4428b8){const _0x5bd92a=yn(_0x322c5e,R['getCompare']());return new g(_0xf6111,A(_0x54c231),new te({'.priority':_0x5bd92a},{'.priority':R}));}else return new g(_0xf6111,A(_0x54c231),te['Default']);}else{let _0xf468f5=g['EMPTY_NODE'];return x(_0x4a99ca,(_0x2fe600,_0x175e24)=>{if(Q(_0x4a99ca,_0x2fe600)&&_0x2fe600['substring'](0x0,0x1)!=='.'){const _0x3bb716=A(_0x175e24);(_0x3bb716['isLeafNode']()||!_0x3bb716['isEmpty']())&&(_0xf468f5=_0xf468f5['updateImmediateChild'](_0x2fe600,_0x3bb716));}}),_0xf468f5['updatePriority'](A(_0x54c231));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x2a27b3){super(),this['indexPath_']=_0x2a27b3,f(!v(_0x2a27b3)&&y(_0x2a27b3)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x14a98e){return _0x14a98e['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2112ac){return!_0x2112ac['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2e2b06,_0x17520e){const _0x243682=this['extractChild'](_0x2e2b06['node']),_0x2fe299=this['extractChild'](_0x17520e['node']),_0x467898=_0x243682['compareTo'](_0x2fe299);return _0x467898===0x0?qe(_0x2e2b06['name'],_0x17520e['name']):_0x467898;}['makePost'](_0x167b56,_0x518cd4){const _0x568867=A(_0x167b56),_0x4b136a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x568867);return new E(_0x518cd4,_0x4b136a);}['maxPost'](){const _0x4362fb=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4362fb);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x362357,_0x4627da){const _0x422bbb=_0x362357['node']['compareTo'](_0x4627da['node']);return _0x422bbb===0x0?qe(_0x362357['name'],_0x4627da['name']):_0x422bbb;}['isDefinedOn'](_0x121b8e){return!0x0;}['indexedValueChanged'](_0x1e85e1,_0x206c03){return!_0x1e85e1['equals'](_0x206c03);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2a9846,_0x1c7a19){const _0x13b5c1=A(_0x2a9846);return new E(_0x1c7a19,_0x13b5c1);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x45d407){return{'type':'value','snapshotNode':_0x45d407};}function rt(_0x3f3e5c,_0x321ba1){return{'type':'child_added','snapshotNode':_0x321ba1,'childName':_0x3f3e5c};}function Lt(_0x1b4ad3,_0x828702){return{'type':'child_removed','snapshotNode':_0x828702,'childName':_0x1b4ad3};}function xt(_0x4e3913,_0x9d0bbb,_0x34dad0){return{'type':'child_changed','snapshotNode':_0x9d0bbb,'childName':_0x4e3913,'oldSnap':_0x34dad0};}function zh(_0x25deb7,_0x989de7){return{'type':'child_moved','snapshotNode':_0x989de7,'childName':_0x25deb7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x487399){this['index_']=_0x487399;}['updateChild'](_0x3f52e6,_0x4e6830,_0x3baaa2,_0x50d2e0,_0x504c21,_0x3c5832){f(_0x3f52e6['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x38f441=_0x3f52e6['getImmediateChild'](_0x4e6830);return _0x38f441['getChild'](_0x50d2e0)['equals'](_0x3baaa2['getChild'](_0x50d2e0))&&_0x38f441['isEmpty']()===_0x3baaa2['isEmpty']()||(_0x3c5832!=null&&(_0x3baaa2['isEmpty']()?_0x3f52e6['hasChild'](_0x4e6830)?_0x3c5832['trackChildChange'](Lt(_0x4e6830,_0x38f441)):f(_0x3f52e6['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x38f441['isEmpty']()?_0x3c5832['trackChildChange'](rt(_0x4e6830,_0x3baaa2)):_0x3c5832['trackChildChange'](xt(_0x4e6830,_0x3baaa2,_0x38f441))),_0x3f52e6['isLeafNode']()&&_0x3baaa2['isEmpty']())?_0x3f52e6:_0x3f52e6['updateImmediateChild'](_0x4e6830,_0x3baaa2)['withIndex'](this['index_']);}['updateFullNode'](_0x4b9b73,_0x5a4660,_0x3d3ee7){return _0x3d3ee7!=null&&(_0x4b9b73['isLeafNode']()||_0x4b9b73['forEachChild'](R,(_0x320391,_0x33d655)=>{_0x5a4660['hasChild'](_0x320391)||_0x3d3ee7['trackChildChange'](Lt(_0x320391,_0x33d655));}),_0x5a4660['isLeafNode']()||_0x5a4660['forEachChild'](R,(_0x30672b,_0x1ff463)=>{if(_0x4b9b73['hasChild'](_0x30672b)){const _0x3bec5c=_0x4b9b73['getImmediateChild'](_0x30672b);_0x3bec5c['equals'](_0x1ff463)||_0x3d3ee7['trackChildChange'](xt(_0x30672b,_0x1ff463,_0x3bec5c));}else _0x3d3ee7['trackChildChange'](rt(_0x30672b,_0x1ff463));})),_0x5a4660['withIndex'](this['index_']);}['updatePriority'](_0xe3d5fd,_0x5731ec){return _0xe3d5fd['isEmpty']()?g['EMPTY_NODE']:_0xe3d5fd['updatePriority'](_0x5731ec);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x36bf74){this['indexedFilter_']=new Xi(_0x36bf74['getIndex']()),this['index_']=_0x36bf74['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x36bf74),this['endPost_']=Ft['getEndPost_'](_0x36bf74),this['startIsInclusive_']=!_0x36bf74['startAfterSet_'],this['endIsInclusive_']=!_0x36bf74['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x130d4b){const _0x190729=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x130d4b)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x130d4b)<0x0,_0x43b0e1=this['endIsInclusive_']?this['index_']['compare'](_0x130d4b,this['getEndPost']())<=0x0:this['index_']['compare'](_0x130d4b,this['getEndPost']())<0x0;return _0x190729&&_0x43b0e1;}['updateChild'](_0x687205,_0x597e57,_0xd73a41,_0x41b547,_0x3ce59c,_0x2056e3){return this['matches'](new E(_0x597e57,_0xd73a41))||(_0xd73a41=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x687205,_0x597e57,_0xd73a41,_0x41b547,_0x3ce59c,_0x2056e3);}['updateFullNode'](_0x2fff8c,_0x1d40d5,_0x3ac1c5){_0x1d40d5['isLeafNode']()&&(_0x1d40d5=g['EMPTY_NODE']);let _0x5730fe=_0x1d40d5['withIndex'](this['index_']);_0x5730fe=_0x5730fe['updatePriority'](g['EMPTY_NODE']);const _0x36f12a=this;return _0x1d40d5['forEachChild'](R,(_0x114cac,_0x2aee7f)=>{_0x36f12a['matches'](new E(_0x114cac,_0x2aee7f))||(_0x5730fe=_0x5730fe['updateImmediateChild'](_0x114cac,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2fff8c,_0x5730fe,_0x3ac1c5);}['updatePriority'](_0x135f44,_0x20e170){return _0x135f44;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x748de){if(_0x748de['hasStart']()){const _0x50d077=_0x748de['getIndexStartName']();return _0x748de['getIndex']()['makePost'](_0x748de['getIndexStartValue'](),_0x50d077);}else return _0x748de['getIndex']()['minPost']();}static['getEndPost_'](_0x5c4aad){if(_0x5c4aad['hasEnd']()){const _0x45286b=_0x5c4aad['getIndexEndName']();return _0x5c4aad['getIndex']()['makePost'](_0x5c4aad['getIndexEndValue'](),_0x45286b);}else return _0x5c4aad['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x5164a2){this['withinDirectionalStart']=_0x593890=>this['reverse_']?this['withinEndPost'](_0x593890):this['withinStartPost'](_0x593890),this['withinDirectionalEnd']=_0x186d67=>this['reverse_']?this['withinStartPost'](_0x186d67):this['withinEndPost'](_0x186d67),this['withinStartPost']=_0x5ebc22=>{const _0x49aa5c=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5ebc22);return this['startIsInclusive_']?_0x49aa5c<=0x0:_0x49aa5c<0x0;},this['withinEndPost']=_0x26d450=>{const _0x47cbd1=this['index_']['compare'](_0x26d450,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x47cbd1<=0x0:_0x47cbd1<0x0;},this['rangedFilter_']=new Ft(_0x5164a2),this['index_']=_0x5164a2['getIndex'](),this['limit_']=_0x5164a2['getLimit'](),this['reverse_']=!_0x5164a2['isViewFromLeft'](),this['startIsInclusive_']=!_0x5164a2['startAfterSet_'],this['endIsInclusive_']=!_0x5164a2['endBeforeSet_'];}['updateChild'](_0x54d4f9,_0x31fde2,_0x1b9f31,_0x14e72e,_0x5625e7,_0xfbcec1){return this['rangedFilter_']['matches'](new E(_0x31fde2,_0x1b9f31))||(_0x1b9f31=g['EMPTY_NODE']),_0x54d4f9['getImmediateChild'](_0x31fde2)['equals'](_0x1b9f31)?_0x54d4f9:_0x54d4f9['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x54d4f9,_0x31fde2,_0x1b9f31,_0x14e72e,_0x5625e7,_0xfbcec1):this['fullLimitUpdateChild_'](_0x54d4f9,_0x31fde2,_0x1b9f31,_0x5625e7,_0xfbcec1);}['updateFullNode'](_0x848f88,_0x552ff4,_0x3e630c){let _0x956f43;if(_0x552ff4['isLeafNode']()||_0x552ff4['isEmpty']())_0x956f43=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x552ff4['numChildren']()&&_0x552ff4['isIndexed'](this['index_'])){_0x956f43=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5c23b0;this['reverse_']?_0x5c23b0=_0x552ff4['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5c23b0=_0x552ff4['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x7b93be=0x0;for(;_0x5c23b0['hasNext']()&&_0x7b93be<this['limit_'];){const _0x2f09ed=_0x5c23b0['getNext']();if(this['withinDirectionalStart'](_0x2f09ed)){if(this['withinDirectionalEnd'](_0x2f09ed))_0x956f43=_0x956f43['updateImmediateChild'](_0x2f09ed['name'],_0x2f09ed['node']),_0x7b93be++;else break;}else continue;}}else{_0x956f43=_0x552ff4['withIndex'](this['index_']),_0x956f43=_0x956f43['updatePriority'](g['EMPTY_NODE']);let _0x592f38;this['reverse_']?_0x592f38=_0x956f43['getReverseIterator'](this['index_']):_0x592f38=_0x956f43['getIterator'](this['index_']);let _0x2e6874=0x0;for(;_0x592f38['hasNext']();){const _0xe5523=_0x592f38['getNext']();_0x2e6874<this['limit_']&&this['withinDirectionalStart'](_0xe5523)&&this['withinDirectionalEnd'](_0xe5523)?_0x2e6874++:_0x956f43=_0x956f43['updateImmediateChild'](_0xe5523['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x848f88,_0x956f43,_0x3e630c);}['updatePriority'](_0x314e44,_0x592dd8){return _0x314e44;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5cffbc,_0x42eb3a,_0xcbffd,_0x2b2a46,_0xe8b262){let _0x11d76b;if(this['reverse_']){const _0x4efbaf=this['index_']['getCompare']();_0x11d76b=(_0x3b5584,_0x30f7df)=>_0x4efbaf(_0x30f7df,_0x3b5584);}else _0x11d76b=this['index_']['getCompare']();const _0xacd5b7=_0x5cffbc;f(_0xacd5b7['numChildren']()===this['limit_'],'');const _0x4e4ea8=new E(_0x42eb3a,_0xcbffd),_0x51fe8e=this['reverse_']?_0xacd5b7['getFirstChild'](this['index_']):_0xacd5b7['getLastChild'](this['index_']),_0x5d3ea4=this['rangedFilter_']['matches'](_0x4e4ea8);if(_0xacd5b7['hasChild'](_0x42eb3a)){const _0x5b351f=_0xacd5b7['getImmediateChild'](_0x42eb3a);let _0x5b5186=_0x2b2a46['getChildAfterChild'](this['index_'],_0x51fe8e,this['reverse_']);for(;_0x5b5186!=null&&(_0x5b5186['name']===_0x42eb3a||_0xacd5b7['hasChild'](_0x5b5186['name']));)_0x5b5186=_0x2b2a46['getChildAfterChild'](this['index_'],_0x5b5186,this['reverse_']);const _0x31543b=_0x5b5186==null?0x1:_0x11d76b(_0x5b5186,_0x4e4ea8);if(_0x5d3ea4&&!_0xcbffd['isEmpty']()&&_0x31543b>=0x0)return _0xe8b262!=null&&_0xe8b262['trackChildChange'](xt(_0x42eb3a,_0xcbffd,_0x5b351f)),_0xacd5b7['updateImmediateChild'](_0x42eb3a,_0xcbffd);{_0xe8b262!=null&&_0xe8b262['trackChildChange'](Lt(_0x42eb3a,_0x5b351f));const _0x421cee=_0xacd5b7['updateImmediateChild'](_0x42eb3a,g['EMPTY_NODE']);return _0x5b5186!=null&&this['rangedFilter_']['matches'](_0x5b5186)?(_0xe8b262!=null&&_0xe8b262['trackChildChange'](rt(_0x5b5186['name'],_0x5b5186['node'])),_0x421cee['updateImmediateChild'](_0x5b5186['name'],_0x5b5186['node'])):_0x421cee;}}else return _0xcbffd['isEmpty']()?_0x5cffbc:_0x5d3ea4&&_0x11d76b(_0x51fe8e,_0x4e4ea8)>=0x0?(_0xe8b262!=null&&(_0xe8b262['trackChildChange'](Lt(_0x51fe8e['name'],_0x51fe8e['node'])),_0xe8b262['trackChildChange'](rt(_0x42eb3a,_0xcbffd))),_0xacd5b7['updateImmediateChild'](_0x42eb3a,_0xcbffd)['updateImmediateChild'](_0x51fe8e['name'],g['EMPTY_NODE'])):_0x5cffbc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5b5c61=new Zi();return _0x5b5c61['limitSet_']=this['limitSet_'],_0x5b5c61['limit_']=this['limit_'],_0x5b5c61['startSet_']=this['startSet_'],_0x5b5c61['startAfterSet_']=this['startAfterSet_'],_0x5b5c61['indexStartValue_']=this['indexStartValue_'],_0x5b5c61['startNameSet_']=this['startNameSet_'],_0x5b5c61['indexStartName_']=this['indexStartName_'],_0x5b5c61['endSet_']=this['endSet_'],_0x5b5c61['endBeforeSet_']=this['endBeforeSet_'],_0x5b5c61['indexEndValue_']=this['indexEndValue_'],_0x5b5c61['endNameSet_']=this['endNameSet_'],_0x5b5c61['indexEndName_']=this['indexEndName_'],_0x5b5c61['index_']=this['index_'],_0x5b5c61['viewFrom_']=this['viewFrom_'],_0x5b5c61;}}function Kh(_0x26e987){return _0x26e987['loadsAllData']()?new Xi(_0x26e987['getIndex']()):_0x26e987['hasLimit']()?new jh(_0x26e987):new Ft(_0x26e987);}function Yh(_0x963ba9,_0x5b9e86){const _0x240640=_0x963ba9['copy']();return _0x240640['limitSet_']=!0x0,_0x240640['limit_']=_0x5b9e86,_0x240640['viewFrom_']='l',_0x240640;}function Qh(_0x5d3ff4,_0x126007,_0x3dbe5f){const _0x1a2c62=_0x5d3ff4['copy']();return _0x1a2c62['startSet_']=!0x0,_0x126007===void 0x0&&(_0x126007=null),_0x1a2c62['indexStartValue_']=_0x126007,_0x3dbe5f!=null?(_0x1a2c62['startNameSet_']=!0x0,_0x1a2c62['indexStartName_']=_0x3dbe5f):(_0x1a2c62['startNameSet_']=!0x1,_0x1a2c62['indexStartName_']=''),_0x1a2c62;}function Jh(_0x39e8c4,_0x674575,_0x292983){const _0xbcc616=_0x39e8c4['copy']();return _0xbcc616['endSet_']=!0x0,_0x674575===void 0x0&&(_0x674575=null),_0xbcc616['indexEndValue_']=_0x674575,_0x292983!==void 0x0?(_0xbcc616['endNameSet_']=!0x0,_0xbcc616['indexEndName_']=_0x292983):(_0xbcc616['endNameSet_']=!0x1,_0xbcc616['indexEndName_']=''),_0xbcc616;}function xo(_0x41c80e,_0x5a4fd6){const _0x4e8570=_0x41c80e['copy']();return _0x4e8570['index_']=_0x5a4fd6,_0x4e8570;}function ir(_0x5d9785){const _0x36daea={};if(_0x5d9785['isDefault']())return _0x36daea;let _0x3445d2;if(_0x5d9785['index_']===R?_0x3445d2='$priority':_0x5d9785['index_']===Mo?_0x3445d2='$value':_0x5d9785['index_']===ve?_0x3445d2='$key':(f(_0x5d9785['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x3445d2=_0x5d9785['index_']['toString']()),_0x36daea['orderBy']=O(_0x3445d2),_0x5d9785['startSet_']){const _0x881ee0=_0x5d9785['startAfterSet_']?'startAfter':'startAt';_0x36daea[_0x881ee0]=O(_0x5d9785['indexStartValue_']),_0x5d9785['startNameSet_']&&(_0x36daea[_0x881ee0]+=','+O(_0x5d9785['indexStartName_']));}if(_0x5d9785['endSet_']){const _0x30fe20=_0x5d9785['endBeforeSet_']?'endBefore':'endAt';_0x36daea[_0x30fe20]=O(_0x5d9785['indexEndValue_']),_0x5d9785['endNameSet_']&&(_0x36daea[_0x30fe20]+=','+O(_0x5d9785['indexEndName_']));}return _0x5d9785['limitSet_']&&(_0x5d9785['isViewFromLeft']()?_0x36daea['limitToFirst']=_0x5d9785['limit_']:_0x36daea['limitToLast']=_0x5d9785['limit_']),_0x36daea;}function sr(_0x538d65){const _0x2d684a={};if(_0x538d65['startSet_']&&(_0x2d684a['sp']=_0x538d65['indexStartValue_'],_0x538d65['startNameSet_']&&(_0x2d684a['sn']=_0x538d65['indexStartName_']),_0x2d684a['sin']=!_0x538d65['startAfterSet_']),_0x538d65['endSet_']&&(_0x2d684a['ep']=_0x538d65['indexEndValue_'],_0x538d65['endNameSet_']&&(_0x2d684a['en']=_0x538d65['indexEndName_']),_0x2d684a['ein']=!_0x538d65['endBeforeSet_']),_0x538d65['limitSet_']){_0x2d684a['l']=_0x538d65['limit_'];let _0x2600c0=_0x538d65['viewFrom_'];_0x2600c0===''&&(_0x538d65['isViewFromLeft']()?_0x2600c0='l':_0x2600c0='r'),_0x2d684a['vf']=_0x2600c0;}return _0x538d65['index_']!==R&&(_0x2d684a['i']=_0x538d65['index_']['toString']()),_0x2d684a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x436465){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xd1e0e7,_0x2584cd){return _0x2584cd!==void 0x0?'tag$'+_0x2584cd:(f(_0xd1e0e7['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xd1e0e7['_path']['toString']());}constructor(_0x219d65,_0x540aa7,_0x144f82,_0x52712a){super(),this['repoInfo_']=_0x219d65,this['onDataUpdate_']=_0x540aa7,this['authTokenProvider_']=_0x144f82,this['appCheckTokenProvider_']=_0x52712a,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x165d65,_0x42e6fc,_0x6540ce,_0x2f2f57){const _0x250006=_0x165d65['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x250006+'\x20'+_0x165d65['_queryIdentifier']);const _0x483d48=vn['getListenId_'](_0x165d65,_0x6540ce),_0x235100={};this['listens_'][_0x483d48]=_0x235100;const _0x827c5b=ir(_0x165d65['_queryParams']);this['restRequest_'](_0x250006+'.json',_0x827c5b,(_0x34cef4,_0x323a5e)=>{let _0x2380c9=_0x323a5e;if(_0x34cef4===0x194&&(_0x2380c9=null,_0x34cef4=null),_0x34cef4===null&&this['onDataUpdate_'](_0x250006,_0x2380c9,!0x1,_0x6540ce),Le(this['listens_'],_0x483d48)===_0x235100){let _0x52912b;_0x34cef4?_0x34cef4===0x191?_0x52912b='permission_denied':_0x52912b='rest_error:'+_0x34cef4:_0x52912b='ok',_0x2f2f57(_0x52912b,null);}});}['unlisten'](_0x1a3702,_0x2bbb87){const _0x4039fe=vn['getListenId_'](_0x1a3702,_0x2bbb87);delete this['listens_'][_0x4039fe];}['get'](_0x35b84e){const _0x22b284=ir(_0x35b84e['_queryParams']),_0x27563c=_0x35b84e['_path']['toString'](),_0x3ab145=new H();return this['restRequest_'](_0x27563c+'.json',_0x22b284,(_0x304c09,_0x22a737)=>{let _0x33b1f6=_0x22a737;_0x304c09===0x194&&(_0x33b1f6=null,_0x304c09=null),_0x304c09===null?(this['onDataUpdate_'](_0x27563c,_0x33b1f6,!0x1,null),_0x3ab145['resolve'](_0x33b1f6)):_0x3ab145['reject'](new Error(_0x33b1f6));}),_0x3ab145['promise'];}['refreshAuthToken'](_0x4fdc72){}['restRequest_'](_0x49a085,_0x4355d8={},_0x37fc85){return _0x4355d8['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x528bbf,_0x2418bb])=>{_0x528bbf&&_0x528bbf['accessToken']&&(_0x4355d8['auth']=_0x528bbf['accessToken']),_0x2418bb&&_0x2418bb['token']&&(_0x4355d8['ac']=_0x2418bb['token']);const _0x3b83a5=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x49a085+'?ns='+this['repoInfo_']['namespace']+ut(_0x4355d8);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x3b83a5);const _0x3e5575=new XMLHttpRequest();_0x3e5575['onreadystatechange']=()=>{if(_0x37fc85&&_0x3e5575['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x3b83a5+'\x20received.\x20status:',_0x3e5575['status'],'response:',_0x3e5575['responseText']);let _0x5838ad=null;if(_0x3e5575['status']>=0xc8&&_0x3e5575['status']<0x12c){try{_0x5838ad=Nt(_0x3e5575['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x3b83a5+':\x20'+_0x3e5575['responseText']);}_0x37fc85(null,_0x5838ad);}else _0x3e5575['status']!==0x191&&_0x3e5575['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x3b83a5+'\x20Status:\x20'+_0x3e5575['status']),_0x37fc85(_0x3e5575['status']);_0x37fc85=null;}},_0x3e5575['open']('GET',_0x3b83a5,!0x0),_0x3e5575['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3ae70c){return this['rootNode_']['getChild'](_0x3ae70c);}['updateSnapshot'](_0xbf74f4,_0x2f4cd6){this['rootNode_']=this['rootNode_']['updateChild'](_0xbf74f4,_0x2f4cd6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x5e8328,_0x5a1d27,_0x213afb){if(v(_0x5a1d27))_0x5e8328['value']=_0x213afb,_0x5e8328['children']['clear']();else{if(_0x5e8328['value']!==null)_0x5e8328['value']=_0x5e8328['value']['updateChild'](_0x5a1d27,_0x213afb);else{const _0x5e490f=y(_0x5a1d27);_0x5e8328['children']['has'](_0x5e490f)||_0x5e8328['children']['set'](_0x5e490f,En());const _0x53392d=_0x5e8328['children']['get'](_0x5e490f);_0x5a1d27=S(_0x5a1d27),pt(_0x53392d,_0x5a1d27,_0x213afb);}}}function Ti(_0x59abe8,_0x12ebd8){if(v(_0x12ebd8))return _0x59abe8['value']=null,_0x59abe8['children']['clear'](),!0x0;if(_0x59abe8['value']!==null){if(_0x59abe8['value']['isLeafNode']())return!0x1;{const _0x2293e2=_0x59abe8['value'];return _0x59abe8['value']=null,_0x2293e2['forEachChild'](R,(_0x518bf8,_0xe67ce0)=>{pt(_0x59abe8,new C(_0x518bf8),_0xe67ce0);}),Ti(_0x59abe8,_0x12ebd8);}}else{if(_0x59abe8['children']['size']>0x0){const _0x5384e1=y(_0x12ebd8);return _0x12ebd8=S(_0x12ebd8),_0x59abe8['children']['has'](_0x5384e1)&&Ti(_0x59abe8['children']['get'](_0x5384e1),_0x12ebd8)&&_0x59abe8['children']['delete'](_0x5384e1),_0x59abe8['children']['size']===0x0;}else return!0x0;}}function Si(_0x4ed86f,_0x2c4086,_0x268304){_0x4ed86f['value']!==null?_0x268304(_0x2c4086,_0x4ed86f['value']):Zh(_0x4ed86f,(_0x356729,_0x28c149)=>{const _0x4e2286=new C(_0x2c4086['toString']()+'/'+_0x356729);Si(_0x28c149,_0x4e2286,_0x268304);});}function Zh(_0x4868ca,_0x5d86aa){_0x4868ca['children']['forEach']((_0x4ab14d,_0x5c73eb)=>{_0x5d86aa(_0x5c73eb,_0x4ab14d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x497b9a){this['collection_']=_0x497b9a,this['last_']=null;}['get'](){const _0x2a2826=this['collection_']['get'](),_0x31ca9b={..._0x2a2826};return this['last_']&&x(this['last_'],(_0x578457,_0x3b0d64)=>{_0x31ca9b[_0x578457]=_0x31ca9b[_0x578457]-_0x3b0d64;}),this['last_']=_0x2a2826,_0x31ca9b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x51504d,_0x2606f5){this['server_']=_0x2606f5,this['statsToReport_']={},this['statsListener_']=new eu(_0x51504d);const _0x33085c=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x33085c));}['reportStats_'](){const _0x18fc5b=this['statsListener_']['get'](),_0x196b47={};let _0x45d5e8=!0x1;x(_0x18fc5b,(_0x383c09,_0x53355b)=>{_0x53355b>0x0&&Q(this['statsToReport_'],_0x383c09)&&(_0x196b47[_0x383c09]=_0x53355b,_0x45d5e8=!0x0);}),_0x45d5e8&&this['server_']['reportStats'](_0x196b47),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x3d82eb){_0x3d82eb[_0x3d82eb['OVERWRITE']=0x0]='OVERWRITE',_0x3d82eb[_0x3d82eb['MERGE']=0x1]='MERGE',_0x3d82eb[_0x3d82eb['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3d82eb[_0x3d82eb['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x32441a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x32441a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x49ff13,_0x49dd1d,_0x4e75e3){this['path']=_0x49ff13,this['affectedTree']=_0x49dd1d,this['revert']=_0x4e75e3,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x397096){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x198d10=this['affectedTree']['subtree'](new C(_0x397096));return new In(w(),_0x198d10,this['revert']);}}else return f(y(this['path'])===_0x397096,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0xc70a0a,_0x55ef70){this['source']=_0xc70a0a,this['path']=_0x55ef70,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x30c7c0){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x1b2e4d,_0x2e47bd,_0x245c79){this['source']=_0x1b2e4d,this['path']=_0x2e47bd,this['snap']=_0x245c79,this['type']=z['OVERWRITE'];}['operationForChild'](_0x4f9d37){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x4f9d37)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x29aa01,_0x27992b,_0x19623c){this['source']=_0x29aa01,this['path']=_0x27992b,this['children']=_0x19623c,this['type']=z['MERGE'];}['operationForChild'](_0x512e50){if(v(this['path'])){const _0x1b043d=this['children']['subtree'](new C(_0x512e50));return _0x1b043d['isEmpty']()?null:_0x1b043d['value']?new Be(this['source'],w(),_0x1b043d['value']):new ot(this['source'],w(),_0x1b043d);}else return f(y(this['path'])===_0x512e50,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2cb2a5,_0xddde3a,_0x192ef5){this['node_']=_0x2cb2a5,this['fullyInitialized_']=_0xddde3a,this['filtered_']=_0x192ef5;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2e2020){if(v(_0x2e2020))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5c50c9=y(_0x2e2020);return this['isCompleteForChild'](_0x5c50c9);}['isCompleteForChild'](_0x558fb8){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x558fb8);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x359781){this['query_']=_0x359781,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x4cead8,_0x20f283,_0x4a39dd,_0x1fde81){const _0x3e0e31=[],_0x3ca2ad=[];return _0x20f283['forEach'](_0x533d63=>{_0x533d63['type']==='child_changed'&&_0x4cead8['index_']['indexedValueChanged'](_0x533d63['oldSnap'],_0x533d63['snapshotNode'])&&_0x3ca2ad['push'](zh(_0x533d63['childName'],_0x533d63['snapshotNode']));}),wt(_0x4cead8,_0x3e0e31,'child_removed',_0x20f283,_0x1fde81,_0x4a39dd),wt(_0x4cead8,_0x3e0e31,'child_added',_0x20f283,_0x1fde81,_0x4a39dd),wt(_0x4cead8,_0x3e0e31,'child_moved',_0x3ca2ad,_0x1fde81,_0x4a39dd),wt(_0x4cead8,_0x3e0e31,'child_changed',_0x20f283,_0x1fde81,_0x4a39dd),wt(_0x4cead8,_0x3e0e31,'value',_0x20f283,_0x1fde81,_0x4a39dd),_0x3e0e31;}function wt(_0x4dcfbf,_0x53a222,_0x16e1c5,_0x2c6ee1,_0x18eec4,_0x22dc3d){const _0xfe5ab8=_0x2c6ee1['filter'](_0x2d2aef=>_0x2d2aef['type']===_0x16e1c5);_0xfe5ab8['sort']((_0x3bafbd,_0x3dec29)=>au(_0x4dcfbf,_0x3bafbd,_0x3dec29)),_0xfe5ab8['forEach'](_0x3b42cf=>{const _0x1fab83=ou(_0x4dcfbf,_0x3b42cf,_0x22dc3d);_0x18eec4['forEach'](_0x202ac1=>{_0x202ac1['respondsTo'](_0x3b42cf['type'])&&_0x53a222['push'](_0x202ac1['createEvent'](_0x1fab83,_0x4dcfbf['query_']));});});}function ou(_0x12933a,_0x298ac5,_0xb6d199){return _0x298ac5['type']==='value'||_0x298ac5['type']==='child_removed'||(_0x298ac5['prevName']=_0xb6d199['getPredecessorChildName'](_0x298ac5['childName'],_0x298ac5['snapshotNode'],_0x12933a['index_'])),_0x298ac5;}function au(_0x3b9aac,_0xd338a6,_0xe11fb9){if(_0xd338a6['childName']==null||_0xe11fb9['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x21c73f=new E(_0xd338a6['childName'],_0xd338a6['snapshotNode']),_0xb684ed=new E(_0xe11fb9['childName'],_0xe11fb9['snapshotNode']);return _0x3b9aac['index_']['compare'](_0x21c73f,_0xb684ed);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x39ef82,_0x4b686e){return{'eventCache':_0x39ef82,'serverCache':_0x4b686e};}function Rt(_0x1464e3,_0x3d43bd,_0x4b081a,_0x4ce59b){return Un(new Te(_0x3d43bd,_0x4b081a,_0x4ce59b),_0x1464e3['serverCache']);}function Fo(_0x494d9b,_0x5c1ec4,_0x1d1820,_0x342c05){return Un(_0x494d9b['eventCache'],new Te(_0x5c1ec4,_0x1d1820,_0x342c05));}function wn(_0x1ea880){return _0x1ea880['eventCache']['isFullyInitialized']()?_0x1ea880['eventCache']['getNode']():null;}function Ve(_0x37bbdb){return _0x37bbdb['serverCache']['isFullyInitialized']()?_0x37bbdb['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x1181c6){let _0x40debc=new b(null);return x(_0x1181c6,(_0x4ba08b,_0x5c3353)=>{_0x40debc=_0x40debc['set'](new C(_0x4ba08b),_0x5c3353);}),_0x40debc;}constructor(_0x57a81a,_0x4b6f0d=cu()){this['value']=_0x57a81a,this['children']=_0x4b6f0d;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2669ba,_0x26d61a){if(this['value']!=null&&_0x26d61a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2669ba))return null;{const _0x5e904c=y(_0x2669ba),_0x507cdf=this['children']['get'](_0x5e904c);if(_0x507cdf!==null){const _0x1edaa0=_0x507cdf['findRootMostMatchingPathAndValue'](S(_0x2669ba),_0x26d61a);return _0x1edaa0!=null?{'path':k(new C(_0x5e904c),_0x1edaa0['path']),'value':_0x1edaa0['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5148fd){return this['findRootMostMatchingPathAndValue'](_0x5148fd,()=>!0x0);}['subtree'](_0x26ec51){if(v(_0x26ec51))return this;{const _0x106ffd=y(_0x26ec51),_0x3ec466=this['children']['get'](_0x106ffd);return _0x3ec466!==null?_0x3ec466['subtree'](S(_0x26ec51)):new b(null);}}['set'](_0x299e89,_0x136df1){if(v(_0x299e89))return new b(_0x136df1,this['children']);{const _0x9de81b=y(_0x299e89),_0x5ad11f=(this['children']['get'](_0x9de81b)||new b(null))['set'](S(_0x299e89),_0x136df1),_0x536686=this['children']['insert'](_0x9de81b,_0x5ad11f);return new b(this['value'],_0x536686);}}['remove'](_0x456d18){if(v(_0x456d18))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x13f370=y(_0x456d18),_0x2cc02e=this['children']['get'](_0x13f370);if(_0x2cc02e){const _0x54b5fd=_0x2cc02e['remove'](S(_0x456d18));let _0xdeeaad;return _0x54b5fd['isEmpty']()?_0xdeeaad=this['children']['remove'](_0x13f370):_0xdeeaad=this['children']['insert'](_0x13f370,_0x54b5fd),this['value']===null&&_0xdeeaad['isEmpty']()?new b(null):new b(this['value'],_0xdeeaad);}else return this;}}['get'](_0x237f1c){if(v(_0x237f1c))return this['value'];{const _0x5aba72=y(_0x237f1c),_0x3feed4=this['children']['get'](_0x5aba72);return _0x3feed4?_0x3feed4['get'](S(_0x237f1c)):null;}}['setTree'](_0x4b70ec,_0x1616ab){if(v(_0x4b70ec))return _0x1616ab;{const _0x253d7c=y(_0x4b70ec),_0x5f4e0a=(this['children']['get'](_0x253d7c)||new b(null))['setTree'](S(_0x4b70ec),_0x1616ab);let _0x32bd26;return _0x5f4e0a['isEmpty']()?_0x32bd26=this['children']['remove'](_0x253d7c):_0x32bd26=this['children']['insert'](_0x253d7c,_0x5f4e0a),new b(this['value'],_0x32bd26);}}['fold'](_0x549ac4){return this['fold_'](w(),_0x549ac4);}['fold_'](_0x343a23,_0x4c770a){const _0x4e1f0e={};return this['children']['inorderTraversal']((_0x34d2e0,_0x120c6f)=>{_0x4e1f0e[_0x34d2e0]=_0x120c6f['fold_'](k(_0x343a23,_0x34d2e0),_0x4c770a);}),_0x4c770a(_0x343a23,this['value'],_0x4e1f0e);}['findOnPath'](_0xa16441,_0x551223){return this['findOnPath_'](_0xa16441,w(),_0x551223);}['findOnPath_'](_0x58f9c4,_0x3bb65e,_0x37f906){const _0x401c87=this['value']?_0x37f906(_0x3bb65e,this['value']):!0x1;if(_0x401c87)return _0x401c87;if(v(_0x58f9c4))return null;{const _0x3a9606=y(_0x58f9c4),_0x331d14=this['children']['get'](_0x3a9606);return _0x331d14?_0x331d14['findOnPath_'](S(_0x58f9c4),k(_0x3bb65e,_0x3a9606),_0x37f906):null;}}['foreachOnPath'](_0x2465af,_0x333ab6){return this['foreachOnPath_'](_0x2465af,w(),_0x333ab6);}['foreachOnPath_'](_0xcc4f9c,_0x131ecd,_0x4685f4){if(v(_0xcc4f9c))return this;{this['value']&&_0x4685f4(_0x131ecd,this['value']);const _0x2fb8bf=y(_0xcc4f9c),_0x4489d1=this['children']['get'](_0x2fb8bf);return _0x4489d1?_0x4489d1['foreachOnPath_'](S(_0xcc4f9c),k(_0x131ecd,_0x2fb8bf),_0x4685f4):new b(null);}}['foreach'](_0x36acd9){this['foreach_'](w(),_0x36acd9);}['foreach_'](_0x491b73,_0x254da8){this['children']['inorderTraversal']((_0x388df0,_0x4f2a5b)=>{_0x4f2a5b['foreach_'](k(_0x491b73,_0x388df0),_0x254da8);}),this['value']&&_0x254da8(_0x491b73,this['value']);}['foreachChild'](_0x4ec341){this['children']['inorderTraversal']((_0x3d9343,_0x149b15)=>{_0x149b15['value']&&_0x4ec341(_0x3d9343,_0x149b15['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x55bbd1){this['writeTree_']=_0x55bbd1;}static['empty'](){return new K(new b(null));}}function At(_0x1aa426,_0x1c623c,_0x306cee){if(v(_0x1c623c))return new K(new b(_0x306cee));{const _0x4d055e=_0x1aa426['writeTree_']['findRootMostValueAndPath'](_0x1c623c);if(_0x4d055e!=null){const _0x3a731a=_0x4d055e['path'];let _0x4ba714=_0x4d055e['value'];const _0x2ea139=F(_0x3a731a,_0x1c623c);return _0x4ba714=_0x4ba714['updateChild'](_0x2ea139,_0x306cee),new K(_0x1aa426['writeTree_']['set'](_0x3a731a,_0x4ba714));}else{const _0x1e2d1a=new b(_0x306cee),_0x557f93=_0x1aa426['writeTree_']['setTree'](_0x1c623c,_0x1e2d1a);return new K(_0x557f93);}}}function bi(_0x165313,_0x59b132,_0x582c77){let _0x50a641=_0x165313;return x(_0x582c77,(_0x244a38,_0x52a1d4)=>{_0x50a641=At(_0x50a641,k(_0x59b132,_0x244a38),_0x52a1d4);}),_0x50a641;}function or(_0x2b7c6a,_0x222313){if(v(_0x222313))return K['empty']();{const _0x2be074=_0x2b7c6a['writeTree_']['setTree'](_0x222313,new b(null));return new K(_0x2be074);}}function Ri(_0x193d63,_0x20882d){return ze(_0x193d63,_0x20882d)!=null;}function ze(_0x20a674,_0x334759){const _0x1c35fb=_0x20a674['writeTree_']['findRootMostValueAndPath'](_0x334759);return _0x1c35fb!=null?_0x20a674['writeTree_']['get'](_0x1c35fb['path'])['getChild'](F(_0x1c35fb['path'],_0x334759)):null;}function ar(_0x573ce3){const _0x15d08d=[],_0x5ad68f=_0x573ce3['writeTree_']['value'];return _0x5ad68f!=null?_0x5ad68f['isLeafNode']()||_0x5ad68f['forEachChild'](R,(_0x30d4c1,_0x5185d4)=>{_0x15d08d['push'](new E(_0x30d4c1,_0x5185d4));}):_0x573ce3['writeTree_']['children']['inorderTraversal']((_0x578299,_0x1176f2)=>{_0x1176f2['value']!=null&&_0x15d08d['push'](new E(_0x578299,_0x1176f2['value']));}),_0x15d08d;}function Ee(_0x263d49,_0x1bc303){if(v(_0x1bc303))return _0x263d49;{const _0x2d343b=ze(_0x263d49,_0x1bc303);return _0x2d343b!=null?new K(new b(_0x2d343b)):new K(_0x263d49['writeTree_']['subtree'](_0x1bc303));}}function Ai(_0x131925){return _0x131925['writeTree_']['isEmpty']();}function at(_0x4cb82b,_0x1f8091){return Uo(w(),_0x4cb82b['writeTree_'],_0x1f8091);}function Uo(_0x37ba78,_0x394391,_0x102f55){if(_0x394391['value']!=null)return _0x102f55['updateChild'](_0x37ba78,_0x394391['value']);{let _0x3e882a=null;return _0x394391['children']['inorderTraversal']((_0x5dc623,_0x44d027)=>{_0x5dc623==='.priority'?(f(_0x44d027['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3e882a=_0x44d027['value']):_0x102f55=Uo(k(_0x37ba78,_0x5dc623),_0x44d027,_0x102f55);}),!_0x102f55['getChild'](_0x37ba78)['isEmpty']()&&_0x3e882a!==null&&(_0x102f55=_0x102f55['updateChild'](k(_0x37ba78,'.priority'),_0x3e882a)),_0x102f55;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x102012,_0x40d943){return Ho(_0x40d943,_0x102012);}function lu(_0x5e291b,_0x2552bd,_0x1ceef6,_0x49daf5,_0x257c02){f(_0x49daf5>_0x5e291b['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x257c02===void 0x0&&(_0x257c02=!0x0),_0x5e291b['allWrites']['push']({'path':_0x2552bd,'snap':_0x1ceef6,'writeId':_0x49daf5,'visible':_0x257c02}),_0x257c02&&(_0x5e291b['visibleWrites']=At(_0x5e291b['visibleWrites'],_0x2552bd,_0x1ceef6)),_0x5e291b['lastWriteId']=_0x49daf5;}function hu(_0x3e6746,_0x29aba0,_0x30b0c3,_0x511b7){f(_0x511b7>_0x3e6746['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3e6746['allWrites']['push']({'path':_0x29aba0,'children':_0x30b0c3,'writeId':_0x511b7,'visible':!0x0}),_0x3e6746['visibleWrites']=bi(_0x3e6746['visibleWrites'],_0x29aba0,_0x30b0c3),_0x3e6746['lastWriteId']=_0x511b7;}function uu(_0x606f02,_0x3f7c52){for(let _0x1aa194=0x0;_0x1aa194<_0x606f02['allWrites']['length'];_0x1aa194++){const _0x37b218=_0x606f02['allWrites'][_0x1aa194];if(_0x37b218['writeId']===_0x3f7c52)return _0x37b218;}return null;}function du(_0x4e75cc,_0xcb0b5f){const _0x4e1735=_0x4e75cc['allWrites']['findIndex'](_0x4d41e9=>_0x4d41e9['writeId']===_0xcb0b5f);f(_0x4e1735>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x12af0e=_0x4e75cc['allWrites'][_0x4e1735];_0x4e75cc['allWrites']['splice'](_0x4e1735,0x1);let _0x55b22e=_0x12af0e['visible'],_0x455271=!0x1,_0x3b4e7d=_0x4e75cc['allWrites']['length']-0x1;for(;_0x55b22e&&_0x3b4e7d>=0x0;){const _0x14562e=_0x4e75cc['allWrites'][_0x3b4e7d];_0x14562e['visible']&&(_0x3b4e7d>=_0x4e1735&&fu(_0x14562e,_0x12af0e['path'])?_0x55b22e=!0x1:G(_0x12af0e['path'],_0x14562e['path'])&&(_0x455271=!0x0)),_0x3b4e7d--;}if(_0x55b22e){if(_0x455271)return pu(_0x4e75cc),!0x0;if(_0x12af0e['snap'])_0x4e75cc['visibleWrites']=or(_0x4e75cc['visibleWrites'],_0x12af0e['path']);else{const _0x2908db=_0x12af0e['children'];x(_0x2908db,_0x5183a6=>{_0x4e75cc['visibleWrites']=or(_0x4e75cc['visibleWrites'],k(_0x12af0e['path'],_0x5183a6));});}return!0x0;}else return!0x1;}function fu(_0x1166f1,_0xa4ceb){if(_0x1166f1['snap'])return G(_0x1166f1['path'],_0xa4ceb);for(const _0x302579 in _0x1166f1['children'])if(_0x1166f1['children']['hasOwnProperty'](_0x302579)&&G(k(_0x1166f1['path'],_0x302579),_0xa4ceb))return!0x0;return!0x1;}function pu(_0xc28e36){_0xc28e36['visibleWrites']=Wo(_0xc28e36['allWrites'],_u,w()),_0xc28e36['allWrites']['length']>0x0?_0xc28e36['lastWriteId']=_0xc28e36['allWrites'][_0xc28e36['allWrites']['length']-0x1]['writeId']:_0xc28e36['lastWriteId']=-0x1;}function _u(_0x391d89){return _0x391d89['visible'];}function Wo(_0x1d3084,_0x56f52d,_0x7eb2d0){let _0x555be2=K['empty']();for(let _0x1e6e45=0x0;_0x1e6e45<_0x1d3084['length'];++_0x1e6e45){const _0x4482e5=_0x1d3084[_0x1e6e45];if(_0x56f52d(_0x4482e5)){const _0x5bf494=_0x4482e5['path'];let _0x5e849a;if(_0x4482e5['snap'])G(_0x7eb2d0,_0x5bf494)?(_0x5e849a=F(_0x7eb2d0,_0x5bf494),_0x555be2=At(_0x555be2,_0x5e849a,_0x4482e5['snap'])):G(_0x5bf494,_0x7eb2d0)&&(_0x5e849a=F(_0x5bf494,_0x7eb2d0),_0x555be2=At(_0x555be2,w(),_0x4482e5['snap']['getChild'](_0x5e849a)));else{if(_0x4482e5['children']){if(G(_0x7eb2d0,_0x5bf494))_0x5e849a=F(_0x7eb2d0,_0x5bf494),_0x555be2=bi(_0x555be2,_0x5e849a,_0x4482e5['children']);else{if(G(_0x5bf494,_0x7eb2d0)){if(_0x5e849a=F(_0x5bf494,_0x7eb2d0),v(_0x5e849a))_0x555be2=bi(_0x555be2,w(),_0x4482e5['children']);else{const _0xb0f4c9=Le(_0x4482e5['children'],y(_0x5e849a));if(_0xb0f4c9){const _0x3ad005=_0xb0f4c9['getChild'](S(_0x5e849a));_0x555be2=At(_0x555be2,w(),_0x3ad005);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x555be2;}function Bo(_0x21a915,_0x743840,_0x2640d2,_0x43346d,_0x4d303b){if(!_0x43346d&&!_0x4d303b){const _0x464e08=ze(_0x21a915['visibleWrites'],_0x743840);if(_0x464e08!=null)return _0x464e08;{const _0xac1433=Ee(_0x21a915['visibleWrites'],_0x743840);if(Ai(_0xac1433))return _0x2640d2;if(_0x2640d2==null&&!Ri(_0xac1433,w()))return null;{const _0x3618c3=_0x2640d2||g['EMPTY_NODE'];return at(_0xac1433,_0x3618c3);}}}else{const _0x7fbe4b=Ee(_0x21a915['visibleWrites'],_0x743840);if(!_0x4d303b&&Ai(_0x7fbe4b))return _0x2640d2;if(!_0x4d303b&&_0x2640d2==null&&!Ri(_0x7fbe4b,w()))return null;{const _0x2b08c2=function(_0x331f8e){return(_0x331f8e['visible']||_0x4d303b)&&(!_0x43346d||!~_0x43346d['indexOf'](_0x331f8e['writeId']))&&(G(_0x331f8e['path'],_0x743840)||G(_0x743840,_0x331f8e['path']));},_0x1785da=Wo(_0x21a915['allWrites'],_0x2b08c2,_0x743840),_0x3c95fc=_0x2640d2||g['EMPTY_NODE'];return at(_0x1785da,_0x3c95fc);}}}function gu(_0x192277,_0x4a244b,_0x3e272b){let _0x3b971e=g['EMPTY_NODE'];const _0x2d8251=ze(_0x192277['visibleWrites'],_0x4a244b);if(_0x2d8251)return _0x2d8251['isLeafNode']()||_0x2d8251['forEachChild'](R,(_0x1ddf2b,_0x17e7d6)=>{_0x3b971e=_0x3b971e['updateImmediateChild'](_0x1ddf2b,_0x17e7d6);}),_0x3b971e;if(_0x3e272b){const _0x5e7bd7=Ee(_0x192277['visibleWrites'],_0x4a244b);return _0x3e272b['forEachChild'](R,(_0x5a0faa,_0x58ec6e)=>{const _0x3396f0=at(Ee(_0x5e7bd7,new C(_0x5a0faa)),_0x58ec6e);_0x3b971e=_0x3b971e['updateImmediateChild'](_0x5a0faa,_0x3396f0);}),ar(_0x5e7bd7)['forEach'](_0x17ed0a=>{_0x3b971e=_0x3b971e['updateImmediateChild'](_0x17ed0a['name'],_0x17ed0a['node']);}),_0x3b971e;}else{const _0x4ed597=Ee(_0x192277['visibleWrites'],_0x4a244b);return ar(_0x4ed597)['forEach'](_0x50fc0e=>{_0x3b971e=_0x3b971e['updateImmediateChild'](_0x50fc0e['name'],_0x50fc0e['node']);}),_0x3b971e;}}function mu(_0x4e15d5,_0x10ae8a,_0x3f4683,_0x21a871,_0x44b69d){f(_0x21a871||_0x44b69d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x18ff19=k(_0x10ae8a,_0x3f4683);if(Ri(_0x4e15d5['visibleWrites'],_0x18ff19))return null;{const _0x1769ca=Ee(_0x4e15d5['visibleWrites'],_0x18ff19);return Ai(_0x1769ca)?_0x44b69d['getChild'](_0x3f4683):at(_0x1769ca,_0x44b69d['getChild'](_0x3f4683));}}function yu(_0x34afff,_0x24e1fa,_0x41a7b5,_0x53c7ca){const _0xce9bb=k(_0x24e1fa,_0x41a7b5),_0x3532c2=ze(_0x34afff['visibleWrites'],_0xce9bb);if(_0x3532c2!=null)return _0x3532c2;if(_0x53c7ca['isCompleteForChild'](_0x41a7b5)){const _0x354979=Ee(_0x34afff['visibleWrites'],_0xce9bb);return at(_0x354979,_0x53c7ca['getNode']()['getImmediateChild'](_0x41a7b5));}else return null;}function vu(_0x27b58d,_0x5556fb){return ze(_0x27b58d['visibleWrites'],_0x5556fb);}function Eu(_0x3df512,_0x531610,_0x1c4801,_0x290bd1,_0x3b8ccb,_0x356c85,_0x834f9e){let _0x46e519;const _0x5114a2=Ee(_0x3df512['visibleWrites'],_0x531610),_0x5ced5b=ze(_0x5114a2,w());if(_0x5ced5b!=null)_0x46e519=_0x5ced5b;else{if(_0x1c4801!=null)_0x46e519=at(_0x5114a2,_0x1c4801);else return[];}if(_0x46e519=_0x46e519['withIndex'](_0x834f9e),!_0x46e519['isEmpty']()&&!_0x46e519['isLeafNode']()){const _0x36fe5c=[],_0x5bb2cc=_0x834f9e['getCompare'](),_0x3fb361=_0x356c85?_0x46e519['getReverseIteratorFrom'](_0x290bd1,_0x834f9e):_0x46e519['getIteratorFrom'](_0x290bd1,_0x834f9e);let _0x47ac94=_0x3fb361['getNext']();for(;_0x47ac94&&_0x36fe5c['length']<_0x3b8ccb;)_0x5bb2cc(_0x47ac94,_0x290bd1)!==0x0&&_0x36fe5c['push'](_0x47ac94),_0x47ac94=_0x3fb361['getNext']();return _0x36fe5c;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x4be6df,_0x43eb4c,_0x442e68,_0x5e10b9){return Bo(_0x4be6df['writeTree'],_0x4be6df['treePath'],_0x43eb4c,_0x442e68,_0x5e10b9);}function is(_0x4086e7,_0x323b0f){return gu(_0x4086e7['writeTree'],_0x4086e7['treePath'],_0x323b0f);}function cr(_0x2a28b5,_0x1aa68a,_0x467d93,_0x5734e5){return mu(_0x2a28b5['writeTree'],_0x2a28b5['treePath'],_0x1aa68a,_0x467d93,_0x5734e5);}function Tn(_0x40d9c6,_0x53fc95){return vu(_0x40d9c6['writeTree'],k(_0x40d9c6['treePath'],_0x53fc95));}function wu(_0x3dcdd0,_0x3aeb2d,_0x308378,_0x5b77b9,_0x4b5ad0,_0x42bae4){return Eu(_0x3dcdd0['writeTree'],_0x3dcdd0['treePath'],_0x3aeb2d,_0x308378,_0x5b77b9,_0x4b5ad0,_0x42bae4);}function ss(_0x4118fb,_0x1ad3d1,_0x3b4fa2){return yu(_0x4118fb['writeTree'],_0x4118fb['treePath'],_0x1ad3d1,_0x3b4fa2);}function Vo(_0x249be1,_0xc74332){return Ho(k(_0x249be1['treePath'],_0xc74332),_0x249be1['writeTree']);}function Ho(_0x31d734,_0xa557b1){return{'treePath':_0x31d734,'writeTree':_0xa557b1};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5da9d2){const _0x27c27c=_0x5da9d2['type'],_0x1bceee=_0x5da9d2['childName'];f(_0x27c27c==='child_added'||_0x27c27c==='child_changed'||_0x27c27c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1bceee!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x359729=this['changeMap']['get'](_0x1bceee);if(_0x359729){const _0x30d286=_0x359729['type'];if(_0x27c27c==='child_added'&&_0x30d286==='child_removed')this['changeMap']['set'](_0x1bceee,xt(_0x1bceee,_0x5da9d2['snapshotNode'],_0x359729['snapshotNode']));else{if(_0x27c27c==='child_removed'&&_0x30d286==='child_added')this['changeMap']['delete'](_0x1bceee);else{if(_0x27c27c==='child_removed'&&_0x30d286==='child_changed')this['changeMap']['set'](_0x1bceee,Lt(_0x1bceee,_0x359729['oldSnap']));else{if(_0x27c27c==='child_changed'&&_0x30d286==='child_added')this['changeMap']['set'](_0x1bceee,rt(_0x1bceee,_0x5da9d2['snapshotNode']));else{if(_0x27c27c==='child_changed'&&_0x30d286==='child_changed')this['changeMap']['set'](_0x1bceee,xt(_0x1bceee,_0x5da9d2['snapshotNode'],_0x359729['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x5da9d2+'\x20occurred\x20after\x20'+_0x359729);}}}}}else this['changeMap']['set'](_0x1bceee,_0x5da9d2);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x14ae22){return null;}['getChildAfterChild'](_0x37e13b,_0x2b2bf8,_0x2ab02d){return null;}}const $o=new Tu();class rs{constructor(_0x2014d3,_0xc70de8,_0x2231bf=null){this['writes_']=_0x2014d3,this['viewCache_']=_0xc70de8,this['optCompleteServerCache_']=_0x2231bf;}['getCompleteChild'](_0x1a8507){const _0x4c7a18=this['viewCache_']['eventCache'];if(_0x4c7a18['isCompleteForChild'](_0x1a8507))return _0x4c7a18['getNode']()['getImmediateChild'](_0x1a8507);{const _0x2da90a=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x1a8507,_0x2da90a);}}['getChildAfterChild'](_0x109a44,_0x455357,_0x370418){const _0x1d95da=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x165cc7=wu(this['writes_'],_0x1d95da,_0x455357,0x1,_0x370418,_0x109a44);return _0x165cc7['length']===0x0?null:_0x165cc7[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x1812b1){return{'filter':_0x1812b1};}function bu(_0x2fee54,_0x547198){f(_0x547198['eventCache']['getNode']()['isIndexed'](_0x2fee54['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x547198['serverCache']['getNode']()['isIndexed'](_0x2fee54['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x337686,_0x202d40,_0x27e22f,_0x3922ec,_0x5b0f33){const _0x268f88=new Cu();let _0x4307d5,_0x49a2e8;if(_0x27e22f['type']===z['OVERWRITE']){const _0x25ad87=_0x27e22f;_0x25ad87['source']['fromUser']?_0x4307d5=ki(_0x337686,_0x202d40,_0x25ad87['path'],_0x25ad87['snap'],_0x3922ec,_0x5b0f33,_0x268f88):(f(_0x25ad87['source']['fromServer'],'Unknown\x20source.'),_0x49a2e8=_0x25ad87['source']['tagged']||_0x202d40['serverCache']['isFiltered']()&&!v(_0x25ad87['path']),_0x4307d5=Sn(_0x337686,_0x202d40,_0x25ad87['path'],_0x25ad87['snap'],_0x3922ec,_0x5b0f33,_0x49a2e8,_0x268f88));}else{if(_0x27e22f['type']===z['MERGE']){const _0x17d69b=_0x27e22f;_0x17d69b['source']['fromUser']?_0x4307d5=ku(_0x337686,_0x202d40,_0x17d69b['path'],_0x17d69b['children'],_0x3922ec,_0x5b0f33,_0x268f88):(f(_0x17d69b['source']['fromServer'],'Unknown\x20source.'),_0x49a2e8=_0x17d69b['source']['tagged']||_0x202d40['serverCache']['isFiltered'](),_0x4307d5=Pi(_0x337686,_0x202d40,_0x17d69b['path'],_0x17d69b['children'],_0x3922ec,_0x5b0f33,_0x49a2e8,_0x268f88));}else{if(_0x27e22f['type']===z['ACK_USER_WRITE']){const _0x5858f3=_0x27e22f;_0x5858f3['revert']?_0x4307d5=Ou(_0x337686,_0x202d40,_0x5858f3['path'],_0x3922ec,_0x5b0f33,_0x268f88):_0x4307d5=Pu(_0x337686,_0x202d40,_0x5858f3['path'],_0x5858f3['affectedTree'],_0x3922ec,_0x5b0f33,_0x268f88);}else{if(_0x27e22f['type']===z['LISTEN_COMPLETE'])_0x4307d5=Nu(_0x337686,_0x202d40,_0x27e22f['path'],_0x3922ec,_0x268f88);else throw ht('Unknown\x20operation\x20type:\x20'+_0x27e22f['type']);}}}const _0x5e839c=_0x268f88['getChanges']();return Au(_0x202d40,_0x4307d5,_0x5e839c),{'viewCache':_0x4307d5,'changes':_0x5e839c};}function Au(_0x115698,_0x213f7c,_0x58e925){const _0x552921=_0x213f7c['eventCache'];if(_0x552921['isFullyInitialized']()){const _0x4a50af=_0x552921['getNode']()['isLeafNode']()||_0x552921['getNode']()['isEmpty'](),_0x3b3c42=wn(_0x115698);(_0x58e925['length']>0x0||!_0x115698['eventCache']['isFullyInitialized']()||_0x4a50af&&!_0x552921['getNode']()['equals'](_0x3b3c42)||!_0x552921['getNode']()['getPriority']()['equals'](_0x3b3c42['getPriority']()))&&_0x58e925['push'](Lo(wn(_0x213f7c)));}}function Go(_0x2753fe,_0x162ccc,_0x22b1d9,_0x30b8c3,_0x1a6e40,_0x58e7b6){const _0x3dfe15=_0x162ccc['eventCache'];if(Tn(_0x30b8c3,_0x22b1d9)!=null)return _0x162ccc;{let _0x449ab7,_0x27bdfb;if(v(_0x22b1d9)){if(f(_0x162ccc['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x162ccc['serverCache']['isFiltered']()){const _0x14531e=Ve(_0x162ccc),_0x188fbd=_0x14531e instanceof g?_0x14531e:g['EMPTY_NODE'],_0x3d9e61=is(_0x30b8c3,_0x188fbd);_0x449ab7=_0x2753fe['filter']['updateFullNode'](_0x162ccc['eventCache']['getNode'](),_0x3d9e61,_0x58e7b6);}else{const _0x4944fb=Cn(_0x30b8c3,Ve(_0x162ccc));_0x449ab7=_0x2753fe['filter']['updateFullNode'](_0x162ccc['eventCache']['getNode'](),_0x4944fb,_0x58e7b6);}}else{const _0x152026=y(_0x22b1d9);if(_0x152026==='.priority'){f(Ce(_0x22b1d9)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3fc0fd=_0x3dfe15['getNode']();_0x27bdfb=_0x162ccc['serverCache']['getNode']();const _0x17392e=cr(_0x30b8c3,_0x22b1d9,_0x3fc0fd,_0x27bdfb);_0x17392e!=null?_0x449ab7=_0x2753fe['filter']['updatePriority'](_0x3fc0fd,_0x17392e):_0x449ab7=_0x3dfe15['getNode']();}else{const _0x5705ae=S(_0x22b1d9);let _0x1bb5e6;if(_0x3dfe15['isCompleteForChild'](_0x152026)){_0x27bdfb=_0x162ccc['serverCache']['getNode']();const _0x43ac7a=cr(_0x30b8c3,_0x22b1d9,_0x3dfe15['getNode'](),_0x27bdfb);_0x43ac7a!=null?_0x1bb5e6=_0x3dfe15['getNode']()['getImmediateChild'](_0x152026)['updateChild'](_0x5705ae,_0x43ac7a):_0x1bb5e6=_0x3dfe15['getNode']()['getImmediateChild'](_0x152026);}else _0x1bb5e6=ss(_0x30b8c3,_0x152026,_0x162ccc['serverCache']);_0x1bb5e6!=null?_0x449ab7=_0x2753fe['filter']['updateChild'](_0x3dfe15['getNode'](),_0x152026,_0x1bb5e6,_0x5705ae,_0x1a6e40,_0x58e7b6):_0x449ab7=_0x3dfe15['getNode']();}}return Rt(_0x162ccc,_0x449ab7,_0x3dfe15['isFullyInitialized']()||v(_0x22b1d9),_0x2753fe['filter']['filtersNodes']());}}function Sn(_0x36727f,_0x543faa,_0x5ab7b0,_0x357d76,_0x408587,_0x4ac9cf,_0x4ee4b6,_0x22fbfd){const _0x1abaaf=_0x543faa['serverCache'];let _0x50f6c2;const _0x2071d9=_0x4ee4b6?_0x36727f['filter']:_0x36727f['filter']['getIndexedFilter']();if(v(_0x5ab7b0))_0x50f6c2=_0x2071d9['updateFullNode'](_0x1abaaf['getNode'](),_0x357d76,null);else{if(_0x2071d9['filtersNodes']()&&!_0x1abaaf['isFiltered']()){const _0x2161ca=_0x1abaaf['getNode']()['updateChild'](_0x5ab7b0,_0x357d76);_0x50f6c2=_0x2071d9['updateFullNode'](_0x1abaaf['getNode'](),_0x2161ca,null);}else{const _0x1bccd6=y(_0x5ab7b0);if(!_0x1abaaf['isCompleteForPath'](_0x5ab7b0)&&Ce(_0x5ab7b0)>0x1)return _0x543faa;const _0x177a08=S(_0x5ab7b0),_0x17c7a9=_0x1abaaf['getNode']()['getImmediateChild'](_0x1bccd6)['updateChild'](_0x177a08,_0x357d76);_0x1bccd6==='.priority'?_0x50f6c2=_0x2071d9['updatePriority'](_0x1abaaf['getNode'](),_0x17c7a9):_0x50f6c2=_0x2071d9['updateChild'](_0x1abaaf['getNode'](),_0x1bccd6,_0x17c7a9,_0x177a08,$o,null);}}const _0x4c5c5d=Fo(_0x543faa,_0x50f6c2,_0x1abaaf['isFullyInitialized']()||v(_0x5ab7b0),_0x2071d9['filtersNodes']()),_0x3206c4=new rs(_0x408587,_0x4c5c5d,_0x4ac9cf);return Go(_0x36727f,_0x4c5c5d,_0x5ab7b0,_0x408587,_0x3206c4,_0x22fbfd);}function ki(_0x4d537f,_0x1b0d88,_0x8b9609,_0x474386,_0x2449d1,_0x1af990,_0x260e19){const _0x5b7261=_0x1b0d88['eventCache'];let _0x5f438b,_0x515850;const _0x14f91a=new rs(_0x2449d1,_0x1b0d88,_0x1af990);if(v(_0x8b9609))_0x515850=_0x4d537f['filter']['updateFullNode'](_0x1b0d88['eventCache']['getNode'](),_0x474386,_0x260e19),_0x5f438b=Rt(_0x1b0d88,_0x515850,!0x0,_0x4d537f['filter']['filtersNodes']());else{const _0x553c05=y(_0x8b9609);if(_0x553c05==='.priority')_0x515850=_0x4d537f['filter']['updatePriority'](_0x1b0d88['eventCache']['getNode'](),_0x474386),_0x5f438b=Rt(_0x1b0d88,_0x515850,_0x5b7261['isFullyInitialized'](),_0x5b7261['isFiltered']());else{const _0x1b89f7=S(_0x8b9609),_0x394157=_0x5b7261['getNode']()['getImmediateChild'](_0x553c05);let _0x22b6e2;if(v(_0x1b89f7))_0x22b6e2=_0x474386;else{const _0x497c44=_0x14f91a['getCompleteChild'](_0x553c05);_0x497c44!=null?ji(_0x1b89f7)==='.priority'&&_0x497c44['getChild'](Ro(_0x1b89f7))['isEmpty']()?_0x22b6e2=_0x497c44:_0x22b6e2=_0x497c44['updateChild'](_0x1b89f7,_0x474386):_0x22b6e2=g['EMPTY_NODE'];}if(_0x394157['equals'](_0x22b6e2))_0x5f438b=_0x1b0d88;else{const _0x4d8fb9=_0x4d537f['filter']['updateChild'](_0x5b7261['getNode'](),_0x553c05,_0x22b6e2,_0x1b89f7,_0x14f91a,_0x260e19);_0x5f438b=Rt(_0x1b0d88,_0x4d8fb9,_0x5b7261['isFullyInitialized'](),_0x4d537f['filter']['filtersNodes']());}}}return _0x5f438b;}function lr(_0x3082c1,_0x4532fa){return _0x3082c1['eventCache']['isCompleteForChild'](_0x4532fa);}function ku(_0x58d789,_0x3dc851,_0x8299cf,_0x1f9ab5,_0xc8c5a7,_0x22cf3d,_0x469693){let _0x1a8a56=_0x3dc851;return _0x1f9ab5['foreach']((_0xd61a5d,_0x238008)=>{const _0x4da5bf=k(_0x8299cf,_0xd61a5d);lr(_0x3dc851,y(_0x4da5bf))&&(_0x1a8a56=ki(_0x58d789,_0x1a8a56,_0x4da5bf,_0x238008,_0xc8c5a7,_0x22cf3d,_0x469693));}),_0x1f9ab5['foreach']((_0x190988,_0x46f29e)=>{const _0x53c9c5=k(_0x8299cf,_0x190988);lr(_0x3dc851,y(_0x53c9c5))||(_0x1a8a56=ki(_0x58d789,_0x1a8a56,_0x53c9c5,_0x46f29e,_0xc8c5a7,_0x22cf3d,_0x469693));}),_0x1a8a56;}function hr(_0x2bb47a,_0x50331b,_0x1c5b4a){return _0x1c5b4a['foreach']((_0x26ac49,_0x5d4384)=>{_0x50331b=_0x50331b['updateChild'](_0x26ac49,_0x5d4384);}),_0x50331b;}function Pi(_0xe6d297,_0x19c3e9,_0x53324b,_0x426a13,_0x7168e9,_0x251bcd,_0x36440a,_0x5812e0){if(_0x19c3e9['serverCache']['getNode']()['isEmpty']()&&!_0x19c3e9['serverCache']['isFullyInitialized']())return _0x19c3e9;let _0x3287a9=_0x19c3e9,_0x2be610;v(_0x53324b)?_0x2be610=_0x426a13:_0x2be610=new b(null)['setTree'](_0x53324b,_0x426a13);const _0x4e6a28=_0x19c3e9['serverCache']['getNode']();return _0x2be610['children']['inorderTraversal']((_0x2fcf16,_0x1798a9)=>{if(_0x4e6a28['hasChild'](_0x2fcf16)){const _0x371911=_0x19c3e9['serverCache']['getNode']()['getImmediateChild'](_0x2fcf16),_0x17efa4=hr(_0xe6d297,_0x371911,_0x1798a9);_0x3287a9=Sn(_0xe6d297,_0x3287a9,new C(_0x2fcf16),_0x17efa4,_0x7168e9,_0x251bcd,_0x36440a,_0x5812e0);}}),_0x2be610['children']['inorderTraversal']((_0x3a959f,_0x3f5ec9)=>{const _0x57b1e1=!_0x19c3e9['serverCache']['isCompleteForChild'](_0x3a959f)&&_0x3f5ec9['value']===null;if(!_0x4e6a28['hasChild'](_0x3a959f)&&!_0x57b1e1){const _0x13c8bc=_0x19c3e9['serverCache']['getNode']()['getImmediateChild'](_0x3a959f),_0x59f6f3=hr(_0xe6d297,_0x13c8bc,_0x3f5ec9);_0x3287a9=Sn(_0xe6d297,_0x3287a9,new C(_0x3a959f),_0x59f6f3,_0x7168e9,_0x251bcd,_0x36440a,_0x5812e0);}}),_0x3287a9;}function Pu(_0xc1e344,_0x353bb3,_0x197b0e,_0x2a3a7d,_0x3e8c70,_0x443b17,_0x1f2b49){if(Tn(_0x3e8c70,_0x197b0e)!=null)return _0x353bb3;const _0x8062cd=_0x353bb3['serverCache']['isFiltered'](),_0x221be3=_0x353bb3['serverCache'];if(_0x2a3a7d['value']!=null){if(v(_0x197b0e)&&_0x221be3['isFullyInitialized']()||_0x221be3['isCompleteForPath'](_0x197b0e))return Sn(_0xc1e344,_0x353bb3,_0x197b0e,_0x221be3['getNode']()['getChild'](_0x197b0e),_0x3e8c70,_0x443b17,_0x8062cd,_0x1f2b49);if(v(_0x197b0e)){let _0x1bdeb3=new b(null);return _0x221be3['getNode']()['forEachChild'](ve,(_0x1d94f0,_0x32730d)=>{_0x1bdeb3=_0x1bdeb3['set'](new C(_0x1d94f0),_0x32730d);}),Pi(_0xc1e344,_0x353bb3,_0x197b0e,_0x1bdeb3,_0x3e8c70,_0x443b17,_0x8062cd,_0x1f2b49);}else return _0x353bb3;}else{let _0x212683=new b(null);return _0x2a3a7d['foreach']((_0x539782,_0x22892a)=>{const _0x2da3ba=k(_0x197b0e,_0x539782);_0x221be3['isCompleteForPath'](_0x2da3ba)&&(_0x212683=_0x212683['set'](_0x539782,_0x221be3['getNode']()['getChild'](_0x2da3ba)));}),Pi(_0xc1e344,_0x353bb3,_0x197b0e,_0x212683,_0x3e8c70,_0x443b17,_0x8062cd,_0x1f2b49);}}function Nu(_0x44892e,_0x168b53,_0x5d2bef,_0x5c2186,_0x20bea5){const _0x3d0dce=_0x168b53['serverCache'],_0x4b19d2=Fo(_0x168b53,_0x3d0dce['getNode'](),_0x3d0dce['isFullyInitialized']()||v(_0x5d2bef),_0x3d0dce['isFiltered']());return Go(_0x44892e,_0x4b19d2,_0x5d2bef,_0x5c2186,$o,_0x20bea5);}function Ou(_0x3bb63f,_0x364bdd,_0x34bbbf,_0x241954,_0x1eb4f9,_0x33e7e8){let _0x9fe88a;if(Tn(_0x241954,_0x34bbbf)!=null)return _0x364bdd;{const _0x24f8f3=new rs(_0x241954,_0x364bdd,_0x1eb4f9),_0x38c286=_0x364bdd['eventCache']['getNode']();let _0x4492d0;if(v(_0x34bbbf)||y(_0x34bbbf)==='.priority'){let _0x524069;if(_0x364bdd['serverCache']['isFullyInitialized']())_0x524069=Cn(_0x241954,Ve(_0x364bdd));else{const _0x1c6579=_0x364bdd['serverCache']['getNode']();f(_0x1c6579 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x524069=is(_0x241954,_0x1c6579);}_0x524069=_0x524069,_0x4492d0=_0x3bb63f['filter']['updateFullNode'](_0x38c286,_0x524069,_0x33e7e8);}else{const _0x490094=y(_0x34bbbf);let _0x51f740=ss(_0x241954,_0x490094,_0x364bdd['serverCache']);_0x51f740==null&&_0x364bdd['serverCache']['isCompleteForChild'](_0x490094)&&(_0x51f740=_0x38c286['getImmediateChild'](_0x490094)),_0x51f740!=null?_0x4492d0=_0x3bb63f['filter']['updateChild'](_0x38c286,_0x490094,_0x51f740,S(_0x34bbbf),_0x24f8f3,_0x33e7e8):_0x364bdd['eventCache']['getNode']()['hasChild'](_0x490094)?_0x4492d0=_0x3bb63f['filter']['updateChild'](_0x38c286,_0x490094,g['EMPTY_NODE'],S(_0x34bbbf),_0x24f8f3,_0x33e7e8):_0x4492d0=_0x38c286,_0x4492d0['isEmpty']()&&_0x364bdd['serverCache']['isFullyInitialized']()&&(_0x9fe88a=Cn(_0x241954,Ve(_0x364bdd)),_0x9fe88a['isLeafNode']()&&(_0x4492d0=_0x3bb63f['filter']['updateFullNode'](_0x4492d0,_0x9fe88a,_0x33e7e8)));}return _0x9fe88a=_0x364bdd['serverCache']['isFullyInitialized']()||Tn(_0x241954,w())!=null,Rt(_0x364bdd,_0x4492d0,_0x9fe88a,_0x3bb63f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4a11c3,_0x53b270){this['query_']=_0x4a11c3,this['eventRegistrations_']=[];const _0x3df4cb=this['query_']['_queryParams'],_0x3bedfa=new Xi(_0x3df4cb['getIndex']()),_0x2a8074=Kh(_0x3df4cb);this['processor_']=Su(_0x2a8074);const _0x4f448d=_0x53b270['serverCache'],_0x5096cb=_0x53b270['eventCache'],_0x253cc3=_0x3bedfa['updateFullNode'](g['EMPTY_NODE'],_0x4f448d['getNode'](),null),_0x522e3a=_0x2a8074['updateFullNode'](g['EMPTY_NODE'],_0x5096cb['getNode'](),null),_0x256cfe=new Te(_0x253cc3,_0x4f448d['isFullyInitialized'](),_0x3bedfa['filtersNodes']()),_0x5e9d89=new Te(_0x522e3a,_0x5096cb['isFullyInitialized'](),_0x2a8074['filtersNodes']());this['viewCache_']=Un(_0x5e9d89,_0x256cfe),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2041e8){return _0x2041e8['viewCache_']['serverCache']['getNode']();}function Lu(_0x55f226){return wn(_0x55f226['viewCache_']);}function xu(_0x55e743,_0x590e31){const _0x56246e=Ve(_0x55e743['viewCache_']);return _0x56246e&&(_0x55e743['query']['_queryParams']['loadsAllData']()||!v(_0x590e31)&&!_0x56246e['getImmediateChild'](y(_0x590e31))['isEmpty']())?_0x56246e['getChild'](_0x590e31):null;}function ur(_0x47d606){return _0x47d606['eventRegistrations_']['length']===0x0;}function Fu(_0x4e33fe,_0x29ae9d){_0x4e33fe['eventRegistrations_']['push'](_0x29ae9d);}function dr(_0x2a7951,_0x28ed33,_0x17a63c){const _0x53459b=[];if(_0x17a63c){f(_0x28ed33==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x57b6d8=_0x2a7951['query']['_path'];_0x2a7951['eventRegistrations_']['forEach'](_0x4c9c3b=>{const _0x58494d=_0x4c9c3b['createCancelEvent'](_0x17a63c,_0x57b6d8);_0x58494d&&_0x53459b['push'](_0x58494d);});}if(_0x28ed33){let _0x4504c1=[];for(let _0x38e03b=0x0;_0x38e03b<_0x2a7951['eventRegistrations_']['length'];++_0x38e03b){const _0x4a650c=_0x2a7951['eventRegistrations_'][_0x38e03b];if(!_0x4a650c['matches'](_0x28ed33))_0x4504c1['push'](_0x4a650c);else{if(_0x28ed33['hasAnyCallback']()){_0x4504c1=_0x4504c1['concat'](_0x2a7951['eventRegistrations_']['slice'](_0x38e03b+0x1));break;}}}_0x2a7951['eventRegistrations_']=_0x4504c1;}else _0x2a7951['eventRegistrations_']=[];return _0x53459b;}function fr(_0x5516d6,_0x353a5d,_0x401d34,_0x4d54d9){_0x353a5d['type']===z['MERGE']&&_0x353a5d['source']['queryId']!==null&&(f(Ve(_0x5516d6['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x5516d6['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3703e3=_0x5516d6['viewCache_'],_0x520291=Ru(_0x5516d6['processor_'],_0x3703e3,_0x353a5d,_0x401d34,_0x4d54d9);return bu(_0x5516d6['processor_'],_0x520291['viewCache']),f(_0x520291['viewCache']['serverCache']['isFullyInitialized']()||!_0x3703e3['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5516d6['viewCache_']=_0x520291['viewCache'],qo(_0x5516d6,_0x520291['changes'],_0x520291['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x37ca45,_0x24c46f){const _0x5efa3e=_0x37ca45['viewCache_']['eventCache'],_0x1896bc=[];return _0x5efa3e['getNode']()['isLeafNode']()||_0x5efa3e['getNode']()['forEachChild'](R,(_0x3e8f1d,_0xaeb9b4)=>{_0x1896bc['push'](rt(_0x3e8f1d,_0xaeb9b4));}),_0x5efa3e['isFullyInitialized']()&&_0x1896bc['push'](Lo(_0x5efa3e['getNode']())),qo(_0x37ca45,_0x1896bc,_0x5efa3e['getNode'](),_0x24c46f);}function qo(_0x17599d,_0x3159c1,_0xe91e2a,_0xd54b23){const _0x1737c=_0xd54b23?[_0xd54b23]:_0x17599d['eventRegistrations_'];return ru(_0x17599d['eventGenerator_'],_0x3159c1,_0xe91e2a,_0x1737c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x3c0574){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x3c0574;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5d4b48){return _0x5d4b48['views']['size']===0x0;}function os(_0x110058,_0x22328a,_0x14bdac,_0x1ad293){const _0x146eae=_0x22328a['source']['queryId'];if(_0x146eae!==null){const _0x369013=_0x110058['views']['get'](_0x146eae);return f(_0x369013!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x369013,_0x22328a,_0x14bdac,_0x1ad293);}else{let _0x514f90=[];for(const _0x48d86d of _0x110058['views']['values']())_0x514f90=_0x514f90['concat'](fr(_0x48d86d,_0x22328a,_0x14bdac,_0x1ad293));return _0x514f90;}}function jo(_0x14f619,_0x5ecedc,_0x485816,_0x150737,_0x7989e3){const _0x42b072=_0x5ecedc['_queryIdentifier'],_0x4d3503=_0x14f619['views']['get'](_0x42b072);if(!_0x4d3503){let _0x60e010=Cn(_0x485816,_0x7989e3?_0x150737:null),_0x4e4342=!0x1;_0x60e010?_0x4e4342=!0x0:_0x150737 instanceof g?(_0x60e010=is(_0x485816,_0x150737),_0x4e4342=!0x1):(_0x60e010=g['EMPTY_NODE'],_0x4e4342=!0x1);const _0x346457=Un(new Te(_0x60e010,_0x4e4342,!0x1),new Te(_0x150737,_0x7989e3,!0x1));return new Du(_0x5ecedc,_0x346457);}return _0x4d3503;}function Hu(_0x7f367f,_0x4a477b,_0x1d33c1,_0x12e6c4,_0x3eb0a1,_0x4b1ea7){const _0x46288f=jo(_0x7f367f,_0x4a477b,_0x12e6c4,_0x3eb0a1,_0x4b1ea7);return _0x7f367f['views']['has'](_0x4a477b['_queryIdentifier'])||_0x7f367f['views']['set'](_0x4a477b['_queryIdentifier'],_0x46288f),Fu(_0x46288f,_0x1d33c1),Uu(_0x46288f,_0x1d33c1);}function $u(_0x5cd3ab,_0x335856,_0x4d0583,_0x2ee365){const _0x58e516=_0x335856['_queryIdentifier'],_0x404160=[];let _0x332033=[];const _0x33887a=Se(_0x5cd3ab);if(_0x58e516==='default'){for(const [_0x3fc668,_0x2e59ed]of _0x5cd3ab['views']['entries']())_0x332033=_0x332033['concat'](dr(_0x2e59ed,_0x4d0583,_0x2ee365)),ur(_0x2e59ed)&&(_0x5cd3ab['views']['delete'](_0x3fc668),_0x2e59ed['query']['_queryParams']['loadsAllData']()||_0x404160['push'](_0x2e59ed['query']));}else{const _0x3fb684=_0x5cd3ab['views']['get'](_0x58e516);_0x3fb684&&(_0x332033=_0x332033['concat'](dr(_0x3fb684,_0x4d0583,_0x2ee365)),ur(_0x3fb684)&&(_0x5cd3ab['views']['delete'](_0x58e516),_0x3fb684['query']['_queryParams']['loadsAllData']()||_0x404160['push'](_0x3fb684['query'])));}return _0x33887a&&!Se(_0x5cd3ab)&&_0x404160['push'](new(Bu())(_0x335856['_repo'],_0x335856['_path'])),{'removed':_0x404160,'events':_0x332033};}function Ko(_0x1fe714){const _0x373b14=[];for(const _0x31c7f2 of _0x1fe714['views']['values']())_0x31c7f2['query']['_queryParams']['loadsAllData']()||_0x373b14['push'](_0x31c7f2);return _0x373b14;}function Ie(_0x5bb26b,_0x1dadb5){let _0x1115e7=null;for(const _0x184829 of _0x5bb26b['views']['values']())_0x1115e7=_0x1115e7||xu(_0x184829,_0x1dadb5);return _0x1115e7;}function Yo(_0x19126a,_0x7d78de){if(_0x7d78de['_queryParams']['loadsAllData']())return Bn(_0x19126a);{const _0x278ea9=_0x7d78de['_queryIdentifier'];return _0x19126a['views']['get'](_0x278ea9);}}function Qo(_0x39908e,_0x4d06db){return Yo(_0x39908e,_0x4d06db)!=null;}function Se(_0x5b1579){return Bn(_0x5b1579)!=null;}function Bn(_0x694e0c){for(const _0x57eb0a of _0x694e0c['views']['values']())if(_0x57eb0a['query']['_queryParams']['loadsAllData']())return _0x57eb0a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x11ea28){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x11ea28;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3f5c38){this['listenProvider_']=_0x3f5c38,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x21ff6a,_0x1e331a,_0x11b297,_0x44df7f,_0x5eb8fa){return lu(_0x21ff6a['pendingWriteTree_'],_0x1e331a,_0x11b297,_0x44df7f,_0x5eb8fa),_0x5eb8fa?_t(_0x21ff6a,new Be(es(),_0x1e331a,_0x11b297)):[];}function ju(_0x35843d,_0x14c966,_0x55b049,_0x42ebe9){hu(_0x35843d['pendingWriteTree_'],_0x14c966,_0x55b049,_0x42ebe9);const _0x5d35fa=b['fromObject'](_0x55b049);return _t(_0x35843d,new ot(es(),_0x14c966,_0x5d35fa));}function _e(_0x73c9ec,_0x44ef01,_0xa52dc0=!0x1){const _0x8a8403=uu(_0x73c9ec['pendingWriteTree_'],_0x44ef01);if(du(_0x73c9ec['pendingWriteTree_'],_0x44ef01)){let _0x50bc75=new b(null);return _0x8a8403['snap']!=null?_0x50bc75=_0x50bc75['set'](w(),!0x0):x(_0x8a8403['children'],_0x49ec36=>{_0x50bc75=_0x50bc75['set'](new C(_0x49ec36),!0x0);}),_t(_0x73c9ec,new In(_0x8a8403['path'],_0x50bc75,_0xa52dc0));}else return[];}function Yt(_0x2fec44,_0x3e56de,_0x5415ec){return _t(_0x2fec44,new Be(ts(),_0x3e56de,_0x5415ec));}function Ku(_0x18772e,_0x335ffa,_0x552cea){const _0x497516=b['fromObject'](_0x552cea);return _t(_0x18772e,new ot(ts(),_0x335ffa,_0x497516));}function Yu(_0x39930d,_0x31c27e){return _t(_0x39930d,new Ut(ts(),_0x31c27e));}function Qu(_0x143c99,_0x309f5c,_0x119ca9){const _0x10b44f=cs(_0x143c99,_0x119ca9);if(_0x10b44f){const _0x32b5bf=ls(_0x10b44f),_0x11cf29=_0x32b5bf['path'],_0x42db0f=_0x32b5bf['queryId'],_0x368e47=F(_0x11cf29,_0x309f5c),_0xcf4b51=new Ut(ns(_0x42db0f),_0x368e47);return hs(_0x143c99,_0x11cf29,_0xcf4b51);}else return[];}function An(_0x35f62c,_0x323618,_0x2ff206,_0x29ed18,_0x3830ae=!0x1){const _0x2be6d6=_0x323618['_path'],_0x56b5e7=_0x35f62c['syncPointTree_']['get'](_0x2be6d6);let _0x55ba4d=[];if(_0x56b5e7&&(_0x323618['_queryIdentifier']==='default'||Qo(_0x56b5e7,_0x323618))){const _0x1672c8=$u(_0x56b5e7,_0x323618,_0x2ff206,_0x29ed18);Vu(_0x56b5e7)&&(_0x35f62c['syncPointTree_']=_0x35f62c['syncPointTree_']['remove'](_0x2be6d6));const _0x156325=_0x1672c8['removed'];if(_0x55ba4d=_0x1672c8['events'],!_0x3830ae){const _0x8b26f=_0x156325['findIndex'](_0x2d3b27=>_0x2d3b27['_queryParams']['loadsAllData']())!==-0x1,_0x5a23df=_0x35f62c['syncPointTree_']['findOnPath'](_0x2be6d6,(_0x433371,_0x45f721)=>Se(_0x45f721));if(_0x8b26f&&!_0x5a23df){const _0x5143d8=_0x35f62c['syncPointTree_']['subtree'](_0x2be6d6);if(!_0x5143d8['isEmpty']()){const _0x4e552f=Zu(_0x5143d8);for(let _0x29213f=0x0;_0x29213f<_0x4e552f['length'];++_0x29213f){const _0x35246f=_0x4e552f[_0x29213f],_0x126edd=_0x35246f['query'],_0x26deb7=ea(_0x35f62c,_0x35246f);_0x35f62c['listenProvider_']['startListening'](kt(_0x126edd),Wt(_0x35f62c,_0x126edd),_0x26deb7['hashFn'],_0x26deb7['onComplete']);}}}!_0x5a23df&&_0x156325['length']>0x0&&!_0x29ed18&&(_0x8b26f?_0x35f62c['listenProvider_']['stopListening'](kt(_0x323618),null):_0x156325['forEach'](_0x32dc93=>{const _0x280715=_0x35f62c['queryToTagMap']['get'](Hn(_0x32dc93));_0x35f62c['listenProvider_']['stopListening'](kt(_0x32dc93),_0x280715);}));}ed(_0x35f62c,_0x156325);}return _0x55ba4d;}function Jo(_0x2048bd,_0x5d3bf4,_0x4d7a47,_0x336b4){const _0x374d9e=cs(_0x2048bd,_0x336b4);if(_0x374d9e!=null){const _0x37c17f=ls(_0x374d9e),_0x46c0e5=_0x37c17f['path'],_0x32805c=_0x37c17f['queryId'],_0x28c3a8=F(_0x46c0e5,_0x5d3bf4),_0x54b12e=new Be(ns(_0x32805c),_0x28c3a8,_0x4d7a47);return hs(_0x2048bd,_0x46c0e5,_0x54b12e);}else return[];}function Ju(_0x110994,_0x5db11e,_0x2be9cf,_0x41940f){const _0x33523a=cs(_0x110994,_0x41940f);if(_0x33523a){const _0x326a0c=ls(_0x33523a),_0x45c6fe=_0x326a0c['path'],_0xd55507=_0x326a0c['queryId'],_0x49e3d9=F(_0x45c6fe,_0x5db11e),_0x14ea44=b['fromObject'](_0x2be9cf),_0x42d440=new ot(ns(_0xd55507),_0x49e3d9,_0x14ea44);return hs(_0x110994,_0x45c6fe,_0x42d440);}else return[];}function Ni(_0x41fdca,_0x3c9fbb,_0x1017ff,_0x2a4da7=!0x1){const _0x2fbe3b=_0x3c9fbb['_path'];let _0x393d06=null,_0x51ce48=!0x1;_0x41fdca['syncPointTree_']['foreachOnPath'](_0x2fbe3b,(_0x4181b9,_0x3ec19e)=>{const _0x531ce7=F(_0x4181b9,_0x2fbe3b);_0x393d06=_0x393d06||Ie(_0x3ec19e,_0x531ce7),_0x51ce48=_0x51ce48||Se(_0x3ec19e);});let _0x4c7965=_0x41fdca['syncPointTree_']['get'](_0x2fbe3b);_0x4c7965?(_0x51ce48=_0x51ce48||Se(_0x4c7965),_0x393d06=_0x393d06||Ie(_0x4c7965,w())):(_0x4c7965=new zo(),_0x41fdca['syncPointTree_']=_0x41fdca['syncPointTree_']['set'](_0x2fbe3b,_0x4c7965));let _0xaf5902;_0x393d06!=null?_0xaf5902=!0x0:(_0xaf5902=!0x1,_0x393d06=g['EMPTY_NODE'],_0x41fdca['syncPointTree_']['subtree'](_0x2fbe3b)['foreachChild']((_0x57926d,_0x568239)=>{const _0x41ac8d=Ie(_0x568239,w());_0x41ac8d&&(_0x393d06=_0x393d06['updateImmediateChild'](_0x57926d,_0x41ac8d));}));const _0x2c2cc0=Qo(_0x4c7965,_0x3c9fbb);if(!_0x2c2cc0&&!_0x3c9fbb['_queryParams']['loadsAllData']()){const _0xe83618=Hn(_0x3c9fbb);f(!_0x41fdca['queryToTagMap']['has'](_0xe83618),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x3103bf=td();_0x41fdca['queryToTagMap']['set'](_0xe83618,_0x3103bf),_0x41fdca['tagToQueryMap']['set'](_0x3103bf,_0xe83618);}const _0x333406=Wn(_0x41fdca['pendingWriteTree_'],_0x2fbe3b);let _0x2a8ce=Hu(_0x4c7965,_0x3c9fbb,_0x1017ff,_0x333406,_0x393d06,_0xaf5902);if(!_0x2c2cc0&&!_0x51ce48&&!_0x2a4da7){const _0x2a02c6=Yo(_0x4c7965,_0x3c9fbb);_0x2a8ce=_0x2a8ce['concat'](nd(_0x41fdca,_0x3c9fbb,_0x2a02c6));}return _0x2a8ce;}function Vn(_0x34585a,_0x58a5dd,_0x57864f){const _0x4f7892=_0x34585a['pendingWriteTree_'],_0x1e1a66=_0x34585a['syncPointTree_']['findOnPath'](_0x58a5dd,(_0xb74b89,_0x44c102)=>{const _0x2a73ef=F(_0xb74b89,_0x58a5dd),_0x444dd2=Ie(_0x44c102,_0x2a73ef);if(_0x444dd2)return _0x444dd2;});return Bo(_0x4f7892,_0x58a5dd,_0x1e1a66,_0x57864f,!0x0);}function Xu(_0x3e09ef,_0xe8cb0c){const _0x46cf2b=_0xe8cb0c['_path'];let _0x3bb1a6=null;_0x3e09ef['syncPointTree_']['foreachOnPath'](_0x46cf2b,(_0x31c67e,_0x328821)=>{const _0x3aeeb2=F(_0x31c67e,_0x46cf2b);_0x3bb1a6=_0x3bb1a6||Ie(_0x328821,_0x3aeeb2);});let _0x28e164=_0x3e09ef['syncPointTree_']['get'](_0x46cf2b);_0x28e164?_0x3bb1a6=_0x3bb1a6||Ie(_0x28e164,w()):(_0x28e164=new zo(),_0x3e09ef['syncPointTree_']=_0x3e09ef['syncPointTree_']['set'](_0x46cf2b,_0x28e164));const _0x291eda=_0x3bb1a6!=null,_0x325e69=_0x291eda?new Te(_0x3bb1a6,!0x0,!0x1):null,_0x22f9dc=Wn(_0x3e09ef['pendingWriteTree_'],_0xe8cb0c['_path']),_0x14b01e=jo(_0x28e164,_0xe8cb0c,_0x22f9dc,_0x291eda?_0x325e69['getNode']():g['EMPTY_NODE'],_0x291eda);return Lu(_0x14b01e);}function _t(_0x5a2cb6,_0x350c15){return Xo(_0x350c15,_0x5a2cb6['syncPointTree_'],null,Wn(_0x5a2cb6['pendingWriteTree_'],w()));}function Xo(_0x295d41,_0x341271,_0x3d5167,_0x296dd8){if(v(_0x295d41['path']))return Zo(_0x295d41,_0x341271,_0x3d5167,_0x296dd8);{const _0x278037=_0x341271['get'](w());_0x3d5167==null&&_0x278037!=null&&(_0x3d5167=Ie(_0x278037,w()));let _0xb9708e=[];const _0x40cae9=y(_0x295d41['path']),_0x2a86a8=_0x295d41['operationForChild'](_0x40cae9),_0x2bb3f3=_0x341271['children']['get'](_0x40cae9);if(_0x2bb3f3&&_0x2a86a8){const _0x49946e=_0x3d5167?_0x3d5167['getImmediateChild'](_0x40cae9):null,_0x1be550=Vo(_0x296dd8,_0x40cae9);_0xb9708e=_0xb9708e['concat'](Xo(_0x2a86a8,_0x2bb3f3,_0x49946e,_0x1be550));}return _0x278037&&(_0xb9708e=_0xb9708e['concat'](os(_0x278037,_0x295d41,_0x296dd8,_0x3d5167))),_0xb9708e;}}function Zo(_0x132297,_0xe55c8a,_0x7a320a,_0x393314){const _0x10c1d9=_0xe55c8a['get'](w());_0x7a320a==null&&_0x10c1d9!=null&&(_0x7a320a=Ie(_0x10c1d9,w()));let _0x2a13a2=[];return _0xe55c8a['children']['inorderTraversal']((_0x5175c4,_0x185c8a)=>{const _0x3999e1=_0x7a320a?_0x7a320a['getImmediateChild'](_0x5175c4):null,_0x33c79c=Vo(_0x393314,_0x5175c4),_0xf7f4e4=_0x132297['operationForChild'](_0x5175c4);_0xf7f4e4&&(_0x2a13a2=_0x2a13a2['concat'](Zo(_0xf7f4e4,_0x185c8a,_0x3999e1,_0x33c79c)));}),_0x10c1d9&&(_0x2a13a2=_0x2a13a2['concat'](os(_0x10c1d9,_0x132297,_0x393314,_0x7a320a))),_0x2a13a2;}function ea(_0x61b209,_0x10b554){const _0x32ce11=_0x10b554['query'],_0x1eca64=Wt(_0x61b209,_0x32ce11);return{'hashFn':()=>(Mu(_0x10b554)||g['EMPTY_NODE'])['hash'](),'onComplete':_0xc32ca9=>{if(_0xc32ca9==='ok')return _0x1eca64?Qu(_0x61b209,_0x32ce11['_path'],_0x1eca64):Yu(_0x61b209,_0x32ce11['_path']);{const _0xd40944=Kl(_0xc32ca9,_0x32ce11);return An(_0x61b209,_0x32ce11,null,_0xd40944);}}};}function Wt(_0x2c4b5c,_0x1b0634){const _0xd1b848=Hn(_0x1b0634);return _0x2c4b5c['queryToTagMap']['get'](_0xd1b848);}function Hn(_0x54ff1e){return _0x54ff1e['_path']['toString']()+'$'+_0x54ff1e['_queryIdentifier'];}function cs(_0x2b770a,_0x4c4178){return _0x2b770a['tagToQueryMap']['get'](_0x4c4178);}function ls(_0x162bd0){const _0x45465a=_0x162bd0['indexOf']('$');return f(_0x45465a!==-0x1&&_0x45465a<_0x162bd0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x162bd0['substr'](_0x45465a+0x1),'path':new C(_0x162bd0['substr'](0x0,_0x45465a))};}function hs(_0x2bcdad,_0x24a89a,_0x211987){const _0x5afd6a=_0x2bcdad['syncPointTree_']['get'](_0x24a89a);f(_0x5afd6a,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4ede70=Wn(_0x2bcdad['pendingWriteTree_'],_0x24a89a);return os(_0x5afd6a,_0x211987,_0x4ede70,null);}function Zu(_0x10af5d){return _0x10af5d['fold']((_0x2cf9ae,_0x36e6e3,_0x1ed2be)=>{if(_0x36e6e3&&Se(_0x36e6e3))return[Bn(_0x36e6e3)];{let _0x2ad306=[];return _0x36e6e3&&(_0x2ad306=Ko(_0x36e6e3)),x(_0x1ed2be,(_0x2cef6e,_0x1d8324)=>{_0x2ad306=_0x2ad306['concat'](_0x1d8324);}),_0x2ad306;}});}function kt(_0x505409){return _0x505409['_queryParams']['loadsAllData']()&&!_0x505409['_queryParams']['isDefault']()?new(qu())(_0x505409['_repo'],_0x505409['_path']):_0x505409;}function ed(_0x5b659e,_0x3167d1){for(let _0x1ba3b9=0x0;_0x1ba3b9<_0x3167d1['length'];++_0x1ba3b9){const _0x24a601=_0x3167d1[_0x1ba3b9];if(!_0x24a601['_queryParams']['loadsAllData']()){const _0x328401=Hn(_0x24a601),_0x5f3a03=_0x5b659e['queryToTagMap']['get'](_0x328401);_0x5b659e['queryToTagMap']['delete'](_0x328401),_0x5b659e['tagToQueryMap']['delete'](_0x5f3a03);}}}function td(){return zu++;}function nd(_0x2f9758,_0x51dcfe,_0x51bfa4){const _0x5e634f=_0x51dcfe['_path'],_0x435ee5=Wt(_0x2f9758,_0x51dcfe),_0x577c59=ea(_0x2f9758,_0x51bfa4),_0x3fff57=_0x2f9758['listenProvider_']['startListening'](kt(_0x51dcfe),_0x435ee5,_0x577c59['hashFn'],_0x577c59['onComplete']),_0x54c37d=_0x2f9758['syncPointTree_']['subtree'](_0x5e634f);if(_0x435ee5)f(!Se(_0x54c37d['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xf29e1c=_0x54c37d['fold']((_0xd6604e,_0x306e4c,_0x4feddd)=>{if(!v(_0xd6604e)&&_0x306e4c&&Se(_0x306e4c))return[Bn(_0x306e4c)['query']];{let _0x11f383=[];return _0x306e4c&&(_0x11f383=_0x11f383['concat'](Ko(_0x306e4c)['map'](_0x388961=>_0x388961['query']))),x(_0x4feddd,(_0x245ead,_0x1ff4fe)=>{_0x11f383=_0x11f383['concat'](_0x1ff4fe);}),_0x11f383;}});for(let _0x502731=0x0;_0x502731<_0xf29e1c['length'];++_0x502731){const _0x34dd41=_0xf29e1c[_0x502731];_0x2f9758['listenProvider_']['stopListening'](kt(_0x34dd41),Wt(_0x2f9758,_0x34dd41));}}return _0x3fff57;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x1445c5){this['node_']=_0x1445c5;}['getImmediateChild'](_0x138dc4){const _0x542570=this['node_']['getImmediateChild'](_0x138dc4);return new us(_0x542570);}['node'](){return this['node_'];}}class ds{constructor(_0x31e5fe,_0x43307b){this['syncTree_']=_0x31e5fe,this['path_']=_0x43307b;}['getImmediateChild'](_0x372d9d){const _0x56fd83=k(this['path_'],_0x372d9d);return new ds(this['syncTree_'],_0x56fd83);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x1a4117){return _0x1a4117=_0x1a4117||{},_0x1a4117['timestamp']=_0x1a4117['timestamp']||new Date()['getTime'](),_0x1a4117;},_r=function(_0x5cc0b3,_0x30b558,_0x32638c){if(!_0x5cc0b3||typeof _0x5cc0b3!='object')return _0x5cc0b3;if(f('.sv'in _0x5cc0b3,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5cc0b3['.sv']=='string')return sd(_0x5cc0b3['.sv'],_0x30b558,_0x32638c);if(typeof _0x5cc0b3['.sv']=='object')return rd(_0x5cc0b3['.sv'],_0x30b558);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5cc0b3,null,0x2));},sd=function(_0x25f57e,_0x480dfd,_0x2d58a9){switch(_0x25f57e){case'timestamp':return _0x2d58a9['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x25f57e);}},rd=function(_0x5986e6,_0x39a00c,_0x6e7527){_0x5986e6['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5986e6,null,0x2));const _0x1c3c07=_0x5986e6['increment'];typeof _0x1c3c07!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x1c3c07);const _0x1d0eb5=_0x39a00c['node']();if(f(_0x1d0eb5!==null&&typeof _0x1d0eb5<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1d0eb5['isLeafNode']())return _0x1c3c07;const _0x518652=_0x1d0eb5['getValue']();return typeof _0x518652!='number'?_0x1c3c07:_0x518652+_0x1c3c07;},ta=function(_0x33703f,_0x24bdcc,_0x658938,_0x260bb9){return ps(_0x24bdcc,new ds(_0x658938,_0x33703f),_0x260bb9);},fs=function(_0x30a912,_0x5acf5e,_0x4b53ae){return ps(_0x30a912,new us(_0x5acf5e),_0x4b53ae);};function ps(_0xef6fb,_0x38d8a1,_0x169edf){const _0x49daea=_0xef6fb['getPriority']()['val'](),_0x34e828=_r(_0x49daea,_0x38d8a1['getImmediateChild']('.priority'),_0x169edf);let _0xecdc;if(_0xef6fb['isLeafNode']()){const _0x216ac0=_0xef6fb,_0x4d9b8e=_r(_0x216ac0['getValue'](),_0x38d8a1,_0x169edf);return _0x4d9b8e!==_0x216ac0['getValue']()||_0x34e828!==_0x216ac0['getPriority']()['val']()?new D(_0x4d9b8e,A(_0x34e828)):_0xef6fb;}else{const _0x3629cb=_0xef6fb;return _0xecdc=_0x3629cb,_0x34e828!==_0x3629cb['getPriority']()['val']()&&(_0xecdc=_0xecdc['updatePriority'](new D(_0x34e828))),_0x3629cb['forEachChild'](R,(_0x521f32,_0x59dbc3)=>{const _0x14a55e=ps(_0x59dbc3,_0x38d8a1['getImmediateChild'](_0x521f32),_0x169edf);_0x14a55e!==_0x59dbc3&&(_0xecdc=_0xecdc['updateImmediateChild'](_0x521f32,_0x14a55e));}),_0xecdc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x370c39='',_0x5d9e1d=null,_0x8f53ce={'children':{},'childCount':0x0}){this['name']=_0x370c39,this['parent']=_0x5d9e1d,this['node']=_0x8f53ce;}}function $n(_0x41fb5e,_0x551a4e){let _0x22f305=_0x551a4e instanceof C?_0x551a4e:new C(_0x551a4e),_0x54bab6=_0x41fb5e,_0x43062c=y(_0x22f305);for(;_0x43062c!==null;){const _0x4bca17=Le(_0x54bab6['node']['children'],_0x43062c)||{'children':{},'childCount':0x0};_0x54bab6=new _s(_0x43062c,_0x54bab6,_0x4bca17),_0x22f305=S(_0x22f305),_0x43062c=y(_0x22f305);}return _0x54bab6;}function je(_0x41c8b2){return _0x41c8b2['node']['value'];}function gs(_0x42712b,_0x2e8152){_0x42712b['node']['value']=_0x2e8152,Oi(_0x42712b);}function na(_0x3dc7e5){return _0x3dc7e5['node']['childCount']>0x0;}function od(_0x70388f){return je(_0x70388f)===void 0x0&&!na(_0x70388f);}function Gn(_0xf8ec8f,_0xf3b6a1){x(_0xf8ec8f['node']['children'],(_0x4d0595,_0x21bf5a)=>{_0xf3b6a1(new _s(_0x4d0595,_0xf8ec8f,_0x21bf5a));});}function ia(_0x17cb66,_0x284a51,_0x4b7457,_0x306639){_0x4b7457&&_0x284a51(_0x17cb66),Gn(_0x17cb66,_0x37c786=>{ia(_0x37c786,_0x284a51,!0x0);});}function ad(_0x296770,_0x2a440b,_0x472cb9){let _0x4c5a6d=_0x296770['parent'];for(;_0x4c5a6d!==null;){if(_0x2a440b(_0x4c5a6d))return!0x0;_0x4c5a6d=_0x4c5a6d['parent'];}return!0x1;}function Qt(_0x4872ec){return new C(_0x4872ec['parent']===null?_0x4872ec['name']:Qt(_0x4872ec['parent'])+'/'+_0x4872ec['name']);}function Oi(_0xc29f2c){_0xc29f2c['parent']!==null&&cd(_0xc29f2c['parent'],_0xc29f2c['name'],_0xc29f2c);}function cd(_0x3da357,_0x2f9d1f,_0x510406){const _0xac4b41=od(_0x510406),_0x18da69=Q(_0x3da357['node']['children'],_0x2f9d1f);_0xac4b41&&_0x18da69?(delete _0x3da357['node']['children'][_0x2f9d1f],_0x3da357['node']['childCount']--,Oi(_0x3da357)):!_0xac4b41&&!_0x18da69&&(_0x3da357['node']['children'][_0x2f9d1f]=_0x510406['node'],_0x3da357['node']['childCount']++,Oi(_0x3da357));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x1fa1f5){return typeof _0x1fa1f5=='string'&&_0x1fa1f5['length']!==0x0&&!ld['test'](_0x1fa1f5);},sa=function(_0x59225f){return typeof _0x59225f=='string'&&_0x59225f['length']!==0x0&&!hd['test'](_0x59225f);},ud=function(_0x45fe26){return _0x45fe26&&(_0x45fe26=_0x45fe26['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x45fe26);},Bt=function(_0x26c23d){return _0x26c23d===null||typeof _0x26c23d=='string'||typeof _0x26c23d=='number'&&!xn(_0x26c23d)||_0x26c23d&&typeof _0x26c23d=='object'&&Q(_0x26c23d,'.sv');},He=function(_0x120e3c,_0x17ece6,_0x4aa1b3,_0x33f75){_0x33f75&&_0x17ece6===void 0x0||Jt(it(_0x120e3c,'value'),_0x17ece6,_0x4aa1b3);},Jt=function(_0x305101,_0x3bf81f,_0x12953b){const _0x2823c5=_0x12953b instanceof C?new Ah(_0x12953b,_0x305101):_0x12953b;if(_0x3bf81f===void 0x0)throw new Error(_0x305101+'contains\x20undefined\x20'+Oe(_0x2823c5));if(typeof _0x3bf81f=='function')throw new Error(_0x305101+'contains\x20a\x20function\x20'+Oe(_0x2823c5)+'\x20with\x20contents\x20=\x20'+_0x3bf81f['toString']());if(xn(_0x3bf81f))throw new Error(_0x305101+'contains\x20'+_0x3bf81f['toString']()+'\x20'+Oe(_0x2823c5));if(typeof _0x3bf81f=='string'&&_0x3bf81f['length']>ui/0x3&&Ln(_0x3bf81f)>ui)throw new Error(_0x305101+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2823c5)+'\x20(\x27'+_0x3bf81f['substring'](0x0,0x32)+'...\x27)');if(_0x3bf81f&&typeof _0x3bf81f=='object'){let _0x26be09=!0x1,_0x17c790=!0x1;if(x(_0x3bf81f,(_0x18e893,_0x2e68e8)=>{if(_0x18e893==='.value')_0x26be09=!0x0;else{if(_0x18e893!=='.priority'&&_0x18e893!=='.sv'&&(_0x17c790=!0x0,!ms(_0x18e893)))throw new Error(_0x305101+'\x20contains\x20an\x20invalid\x20key\x20('+_0x18e893+')\x20'+Oe(_0x2823c5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2823c5,_0x18e893),Jt(_0x305101,_0x2e68e8,_0x2823c5),Ph(_0x2823c5);}),_0x26be09&&_0x17c790)throw new Error(_0x305101+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2823c5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x96412a,_0x1c026f){let _0x37c476,_0x5e0e1b;for(_0x37c476=0x0;_0x37c476<_0x1c026f['length'];_0x37c476++){_0x5e0e1b=_0x1c026f[_0x37c476];const _0x5d0143=Mt(_0x5e0e1b);for(let _0x398713=0x0;_0x398713<_0x5d0143['length'];_0x398713++)if(!(_0x5d0143[_0x398713]==='.priority'&&_0x398713===_0x5d0143['length']-0x1)){if(!ms(_0x5d0143[_0x398713]))throw new Error(_0x96412a+'contains\x20an\x20invalid\x20key\x20('+_0x5d0143[_0x398713]+')\x20in\x20path\x20'+_0x5e0e1b['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1c026f['sort'](Rh);let _0x2ab667=null;for(_0x37c476=0x0;_0x37c476<_0x1c026f['length'];_0x37c476++){if(_0x5e0e1b=_0x1c026f[_0x37c476],_0x2ab667!==null&&G(_0x2ab667,_0x5e0e1b))throw new Error(_0x96412a+'contains\x20a\x20path\x20'+_0x2ab667['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5e0e1b['toString']());_0x2ab667=_0x5e0e1b;}},ra=function(_0x539dec,_0x1525a0,_0x2b87f3,_0x32b149){const _0x523bf9=it(_0x539dec,'values');if(!(_0x1525a0&&typeof _0x1525a0=='object')||Array['isArray'](_0x1525a0))throw new Error(_0x523bf9+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x41fe33=[];x(_0x1525a0,(_0xb6144b,_0x5767f3)=>{const _0x455f1b=new C(_0xb6144b);if(Jt(_0x523bf9,_0x5767f3,k(_0x2b87f3,_0x455f1b)),ji(_0x455f1b)==='.priority'&&!Bt(_0x5767f3))throw new Error(_0x523bf9+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x455f1b['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x41fe33['push'](_0x455f1b);}),dd(_0x523bf9,_0x41fe33);},fd=function(_0x10f091,_0x1a4761,_0x149f76){if(xn(_0x1a4761))throw new Error(it(_0x10f091,'priority')+'is\x20'+_0x1a4761['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1a4761))throw new Error(it(_0x10f091,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x45f036,_0x180868,_0x2aacc3,_0x5dcf92){if(!sa(_0x2aacc3))throw new Error(it(_0x45f036,_0x180868)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2aacc3+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x2c5b9c,_0x109cfa,_0x37fc81,_0x4b851d){_0x37fc81&&(_0x37fc81=_0x37fc81['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x2c5b9c,_0x109cfa,_0x37fc81);},Me=function(_0x40a322,_0x32d5dc){if(y(_0x32d5dc)==='.info')throw new Error(_0x40a322+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x39cf32,_0x5b378b){const _0x4f1385=_0x5b378b['path']['toString']();if(typeof _0x5b378b['repoInfo']['host']!='string'||_0x5b378b['repoInfo']['host']['length']===0x0||!ms(_0x5b378b['repoInfo']['namespace'])&&_0x5b378b['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4f1385['length']!==0x0&&!ud(_0x4f1385))throw new Error(it(_0x39cf32,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3af354,_0x3459e0){let _0x4e0aa2=null;for(let _0x3937b6=0x0;_0x3937b6<_0x3459e0['length'];_0x3937b6++){const _0x228eb4=_0x3459e0[_0x3937b6],_0x54fdfe=_0x228eb4['getPath']();_0x4e0aa2!==null&&!Ki(_0x54fdfe,_0x4e0aa2['path'])&&(_0x3af354['eventLists_']['push'](_0x4e0aa2),_0x4e0aa2=null),_0x4e0aa2===null&&(_0x4e0aa2={'events':[],'path':_0x54fdfe}),_0x4e0aa2['events']['push'](_0x228eb4);}_0x4e0aa2&&_0x3af354['eventLists_']['push'](_0x4e0aa2);}function oa(_0x5e7586,_0xa3a911,_0x36d215){qn(_0x5e7586,_0x36d215),aa(_0x5e7586,_0x85fa36=>Ki(_0x85fa36,_0xa3a911));}function V(_0x39b607,_0x3f2cbd,_0x4fdb3c){qn(_0x39b607,_0x4fdb3c),aa(_0x39b607,_0x2355c4=>G(_0x2355c4,_0x3f2cbd)||G(_0x3f2cbd,_0x2355c4));}function aa(_0x2b549e,_0x379a73){_0x2b549e['recursionDepth_']++;let _0x484d00=!0x0;for(let _0xa00c97=0x0;_0xa00c97<_0x2b549e['eventLists_']['length'];_0xa00c97++){const _0x5e73a0=_0x2b549e['eventLists_'][_0xa00c97];if(_0x5e73a0){const _0x2f32ff=_0x5e73a0['path'];_0x379a73(_0x2f32ff)?(md(_0x2b549e['eventLists_'][_0xa00c97]),_0x2b549e['eventLists_'][_0xa00c97]=null):_0x484d00=!0x1;}}_0x484d00&&(_0x2b549e['eventLists_']=[]),_0x2b549e['recursionDepth_']--;}function md(_0x15693f){for(let _0x59af03=0x0;_0x59af03<_0x15693f['events']['length'];_0x59af03++){const _0x225597=_0x15693f['events'][_0x59af03];if(_0x225597!==null){_0x15693f['events'][_0x59af03]=null;const _0x1784a9=_0x225597['getEventRunner']();St&&L('event:\x20'+_0x225597['toString']()),ft(_0x1784a9);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1faa8c,_0x457192,_0x3c13bd,_0x6a3646){this['repoInfo_']=_0x1faa8c,this['forceRestClient_']=_0x457192,this['authTokenProvider_']=_0x3c13bd,this['appCheckProvider_']=_0x6a3646,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x64efe3,_0x356854,_0x281e65){if(_0x64efe3['stats_']=qi(_0x64efe3['repoInfo_']),_0x64efe3['forceRestClient_']||Xl())_0x64efe3['server_']=new vn(_0x64efe3['repoInfo_'],(_0x20b643,_0x200e02,_0x569818,_0x14d0c2)=>{gr(_0x64efe3,_0x20b643,_0x200e02,_0x569818,_0x14d0c2);},_0x64efe3['authTokenProvider_'],_0x64efe3['appCheckProvider_']),setTimeout(()=>mr(_0x64efe3,!0x0),0x0);else{if(typeof _0x281e65<'u'&&_0x281e65!==null){if(typeof _0x281e65!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x281e65);}catch(_0x32f65b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x32f65b);}}_0x64efe3['persistentConnection_']=new se(_0x64efe3['repoInfo_'],_0x356854,(_0x5f07fa,_0x3baaca,_0x2f4aa0,_0x1ae95d)=>{gr(_0x64efe3,_0x5f07fa,_0x3baaca,_0x2f4aa0,_0x1ae95d);},_0x2d2961=>{mr(_0x64efe3,_0x2d2961);},_0x12596c=>{Id(_0x64efe3,_0x12596c);},_0x64efe3['authTokenProvider_'],_0x64efe3['appCheckProvider_'],_0x281e65),_0x64efe3['server_']=_0x64efe3['persistentConnection_'];}_0x64efe3['authTokenProvider_']['addTokenChangeListener'](_0x5104d9=>{_0x64efe3['server_']['refreshAuthToken'](_0x5104d9);}),_0x64efe3['appCheckProvider_']['addTokenChangeListener'](_0xb768ea=>{_0x64efe3['server_']['refreshAppCheckToken'](_0xb768ea['token']);}),_0x64efe3['statsReporter_']=ih(_0x64efe3['repoInfo_'],()=>new iu(_0x64efe3['stats_'],_0x64efe3['server_'])),_0x64efe3['infoData_']=new Xh(),_0x64efe3['infoSyncTree_']=new pr({'startListening':(_0x3f1aa1,_0x2ce3b2,_0x58da7e,_0x1fe946)=>{let _0x5a788b=[];const _0x832e4c=_0x64efe3['infoData_']['getNode'](_0x3f1aa1['_path']);return _0x832e4c['isEmpty']()||(_0x5a788b=Yt(_0x64efe3['infoSyncTree_'],_0x3f1aa1['_path'],_0x832e4c),setTimeout(()=>{_0x1fe946('ok');},0x0)),_0x5a788b;},'stopListening':()=>{}}),vs(_0x64efe3,'connected',!0x1),_0x64efe3['serverSyncTree_']=new pr({'startListening':(_0x4ed53f,_0x3a5ffa,_0x18ee0e,_0x57641f)=>(_0x64efe3['server_']['listen'](_0x4ed53f,_0x18ee0e,_0x3a5ffa,(_0x736a02,_0x29bdaa)=>{const _0x4d4302=_0x57641f(_0x736a02,_0x29bdaa);V(_0x64efe3['eventQueue_'],_0x4ed53f['_path'],_0x4d4302);}),[]),'stopListening':(_0x36063e,_0x2c7557)=>{_0x64efe3['server_']['unlisten'](_0x36063e,_0x2c7557);}});}function la(_0x5efc99){const _0x59b288=_0x5efc99['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x59b288;}function Xt(_0x11cc87){return id({'timestamp':la(_0x11cc87)});}function gr(_0x19d9b9,_0x4cebf2,_0x277b98,_0x168b25,_0x44d4c2){_0x19d9b9['dataUpdateCount']++;const _0x2cb693=new C(_0x4cebf2);_0x277b98=_0x19d9b9['interceptServerDataCallback_']?_0x19d9b9['interceptServerDataCallback_'](_0x4cebf2,_0x277b98):_0x277b98;let _0x1afb1c=[];if(_0x44d4c2){if(_0x168b25){const _0x3e592e=_n(_0x277b98,_0x3414e1=>A(_0x3414e1));_0x1afb1c=Ju(_0x19d9b9['serverSyncTree_'],_0x2cb693,_0x3e592e,_0x44d4c2);}else{const _0x3253e8=A(_0x277b98);_0x1afb1c=Jo(_0x19d9b9['serverSyncTree_'],_0x2cb693,_0x3253e8,_0x44d4c2);}}else{if(_0x168b25){const _0x2a6272=_n(_0x277b98,_0x29f20a=>A(_0x29f20a));_0x1afb1c=Ku(_0x19d9b9['serverSyncTree_'],_0x2cb693,_0x2a6272);}else{const _0x4e618e=A(_0x277b98);_0x1afb1c=Yt(_0x19d9b9['serverSyncTree_'],_0x2cb693,_0x4e618e);}}let _0x145a17=_0x2cb693;_0x1afb1c['length']>0x0&&(_0x145a17=ct(_0x19d9b9,_0x2cb693)),V(_0x19d9b9['eventQueue_'],_0x145a17,_0x1afb1c);}function mr(_0x6654bf,_0x5ec864){vs(_0x6654bf,'connected',_0x5ec864),_0x5ec864===!0x1&&Sd(_0x6654bf);}function Id(_0x18938f,_0x3e2c0f){x(_0x3e2c0f,(_0x5ece92,_0x52e125)=>{vs(_0x18938f,_0x5ece92,_0x52e125);});}function vs(_0x4c7c15,_0x366a53,_0x4ac953){const _0x22569c=new C('/.info/'+_0x366a53),_0x194cda=A(_0x4ac953);_0x4c7c15['infoData_']['updateSnapshot'](_0x22569c,_0x194cda);const _0xabc314=Yt(_0x4c7c15['infoSyncTree_'],_0x22569c,_0x194cda);V(_0x4c7c15['eventQueue_'],_0x22569c,_0xabc314);}function zn(_0x2e7763){return _0x2e7763['nextWriteId_']++;}function wd(_0x377df3,_0x5187cb,_0x4f7e6d){const _0x4ec5a7=Xu(_0x377df3['serverSyncTree_'],_0x5187cb);return _0x4ec5a7!=null?Promise['resolve'](_0x4ec5a7):_0x377df3['server_']['get'](_0x5187cb)['then'](_0x5b7bbd=>{const _0x4766d6=A(_0x5b7bbd)['withIndex'](_0x5187cb['_queryParams']['getIndex']());Ni(_0x377df3['serverSyncTree_'],_0x5187cb,_0x4f7e6d,!0x0);let _0x1791a0;if(_0x5187cb['_queryParams']['loadsAllData']())_0x1791a0=Yt(_0x377df3['serverSyncTree_'],_0x5187cb['_path'],_0x4766d6);else{const _0x3cb000=Wt(_0x377df3['serverSyncTree_'],_0x5187cb);_0x1791a0=Jo(_0x377df3['serverSyncTree_'],_0x5187cb['_path'],_0x4766d6,_0x3cb000);}return V(_0x377df3['eventQueue_'],_0x5187cb['_path'],_0x1791a0),An(_0x377df3['serverSyncTree_'],_0x5187cb,_0x4f7e6d,null,!0x0),_0x4766d6;},_0x25537c=>(gt(_0x377df3,'get\x20for\x20query\x20'+O(_0x5187cb)+'\x20failed:\x20'+_0x25537c),Promise['reject'](new Error(_0x25537c))));}function Cd(_0x41e222,_0x12e077,_0x31d2ba,_0x1501a5,_0x23815c){gt(_0x41e222,'set',{'path':_0x12e077['toString'](),'value':_0x31d2ba,'priority':_0x1501a5});const _0x2ef7f4=Xt(_0x41e222),_0x17dd25=A(_0x31d2ba,_0x1501a5),_0x1890f5=Vn(_0x41e222['serverSyncTree_'],_0x12e077),_0x46d9ca=fs(_0x17dd25,_0x1890f5,_0x2ef7f4),_0x186ab9=zn(_0x41e222),_0x5cab40=as(_0x41e222['serverSyncTree_'],_0x12e077,_0x46d9ca,_0x186ab9,!0x0);qn(_0x41e222['eventQueue_'],_0x5cab40),_0x41e222['server_']['put'](_0x12e077['toString'](),_0x17dd25['val'](!0x0),(_0x2e84d7,_0x584bea)=>{const _0x479adb=_0x2e84d7==='ok';_0x479adb||U('set\x20at\x20'+_0x12e077+'\x20failed:\x20'+_0x2e84d7);const _0x4a266c=_e(_0x41e222['serverSyncTree_'],_0x186ab9,!_0x479adb);V(_0x41e222['eventQueue_'],_0x12e077,_0x4a266c),be(_0x41e222,_0x23815c,_0x2e84d7,_0x584bea);});const _0x2963c9=Is(_0x41e222,_0x12e077);ct(_0x41e222,_0x2963c9),V(_0x41e222['eventQueue_'],_0x2963c9,[]);}function Td(_0x2d5a7e,_0x260b26,_0x292faa,_0x5bf8cb){gt(_0x2d5a7e,'update',{'path':_0x260b26['toString'](),'value':_0x292faa});let _0xbdf025=!0x0;const _0x4f3c24=Xt(_0x2d5a7e),_0x290256={};if(x(_0x292faa,(_0x534449,_0x2858f0)=>{_0xbdf025=!0x1,_0x290256[_0x534449]=ta(k(_0x260b26,_0x534449),A(_0x2858f0),_0x2d5a7e['serverSyncTree_'],_0x4f3c24);}),_0xbdf025)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2d5a7e,_0x5bf8cb,'ok',void 0x0);else{const _0x17d9d1=zn(_0x2d5a7e),_0x16718d=ju(_0x2d5a7e['serverSyncTree_'],_0x260b26,_0x290256,_0x17d9d1);qn(_0x2d5a7e['eventQueue_'],_0x16718d),_0x2d5a7e['server_']['merge'](_0x260b26['toString'](),_0x292faa,(_0x4cc311,_0x23ae08)=>{const _0x30df22=_0x4cc311==='ok';_0x30df22||U('update\x20at\x20'+_0x260b26+'\x20failed:\x20'+_0x4cc311);const _0x438bac=_e(_0x2d5a7e['serverSyncTree_'],_0x17d9d1,!_0x30df22),_0x51c29a=_0x438bac['length']>0x0?ct(_0x2d5a7e,_0x260b26):_0x260b26;V(_0x2d5a7e['eventQueue_'],_0x51c29a,_0x438bac),be(_0x2d5a7e,_0x5bf8cb,_0x4cc311,_0x23ae08);}),x(_0x292faa,_0x5b8287=>{const _0x71f912=Is(_0x2d5a7e,k(_0x260b26,_0x5b8287));ct(_0x2d5a7e,_0x71f912);}),V(_0x2d5a7e['eventQueue_'],_0x260b26,[]);}}function Sd(_0x359be8){gt(_0x359be8,'onDisconnectEvents');const _0x1d61f2=Xt(_0x359be8),_0x4bd49b=En();Si(_0x359be8['onDisconnect_'],w(),(_0x2ff496,_0x4ec414)=>{const _0x31ac5e=ta(_0x2ff496,_0x4ec414,_0x359be8['serverSyncTree_'],_0x1d61f2);pt(_0x4bd49b,_0x2ff496,_0x31ac5e);});let _0x5b6ab9=[];Si(_0x4bd49b,w(),(_0x51cdbe,_0x208e00)=>{_0x5b6ab9=_0x5b6ab9['concat'](Yt(_0x359be8['serverSyncTree_'],_0x51cdbe,_0x208e00));const _0x3d93b7=Is(_0x359be8,_0x51cdbe);ct(_0x359be8,_0x3d93b7);}),_0x359be8['onDisconnect_']=En(),V(_0x359be8['eventQueue_'],w(),_0x5b6ab9);}function bd(_0x509736,_0x180edc,_0x514298){_0x509736['server_']['onDisconnectCancel'](_0x180edc['toString'](),(_0x4c0cd7,_0x165736)=>{_0x4c0cd7==='ok'&&Ti(_0x509736['onDisconnect_'],_0x180edc),be(_0x509736,_0x514298,_0x4c0cd7,_0x165736);});}function yr(_0x4845f7,_0xcc3393,_0x5f13aa,_0x5c6277){const _0x250434=A(_0x5f13aa);_0x4845f7['server_']['onDisconnectPut'](_0xcc3393['toString'](),_0x250434['val'](!0x0),(_0x4992bf,_0x4e8d2c)=>{_0x4992bf==='ok'&&pt(_0x4845f7['onDisconnect_'],_0xcc3393,_0x250434),be(_0x4845f7,_0x5c6277,_0x4992bf,_0x4e8d2c);});}function Rd(_0x29cda9,_0x4d9d14,_0x16c2cc,_0x17fa94,_0x99b680){const _0x434522=A(_0x16c2cc,_0x17fa94);_0x29cda9['server_']['onDisconnectPut'](_0x4d9d14['toString'](),_0x434522['val'](!0x0),(_0x39d472,_0x4216d2)=>{_0x39d472==='ok'&&pt(_0x29cda9['onDisconnect_'],_0x4d9d14,_0x434522),be(_0x29cda9,_0x99b680,_0x39d472,_0x4216d2);});}function Ad(_0x2d717a,_0x15b80a,_0x582599,_0x2740c4){if(pn(_0x582599)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2d717a,_0x2740c4,'ok',void 0x0);return;}_0x2d717a['server_']['onDisconnectMerge'](_0x15b80a['toString'](),_0x582599,(_0x291244,_0x3dc5f1)=>{_0x291244==='ok'&&x(_0x582599,(_0x58a432,_0x10a253)=>{const _0x5ebcba=A(_0x10a253);pt(_0x2d717a['onDisconnect_'],k(_0x15b80a,_0x58a432),_0x5ebcba);}),be(_0x2d717a,_0x2740c4,_0x291244,_0x3dc5f1);});}function kd(_0x296c61,_0x3cc855,_0x330de4){let _0x4e2a60;y(_0x3cc855['_path'])==='.info'?_0x4e2a60=Ni(_0x296c61['infoSyncTree_'],_0x3cc855,_0x330de4):_0x4e2a60=Ni(_0x296c61['serverSyncTree_'],_0x3cc855,_0x330de4),oa(_0x296c61['eventQueue_'],_0x3cc855['_path'],_0x4e2a60);}function Pd(_0x14afc5,_0x12a9e2,_0x44434d){let _0x2f618a;y(_0x12a9e2['_path'])==='.info'?_0x2f618a=An(_0x14afc5['infoSyncTree_'],_0x12a9e2,_0x44434d):_0x2f618a=An(_0x14afc5['serverSyncTree_'],_0x12a9e2,_0x44434d),oa(_0x14afc5['eventQueue_'],_0x12a9e2['_path'],_0x2f618a);}function ha(_0x44ab44){_0x44ab44['persistentConnection_']&&_0x44ab44['persistentConnection_']['interrupt'](ca);}function Nd(_0x479f2c){_0x479f2c['persistentConnection_']&&_0x479f2c['persistentConnection_']['resume'](ca);}function gt(_0xcf0b05,..._0x31a569){let _0x5b4ad3='';_0xcf0b05['persistentConnection_']&&(_0x5b4ad3=_0xcf0b05['persistentConnection_']['id']+':'),L(_0x5b4ad3,..._0x31a569);}function be(_0x197d9f,_0x1dff9b,_0x566ac2,_0x1780e7){_0x1dff9b&&ft(()=>{if(_0x566ac2==='ok')_0x1dff9b(null);else{const _0x5301a9=(_0x566ac2||'error')['toUpperCase']();let _0x4facff=_0x5301a9;_0x1780e7&&(_0x4facff+=':\x20'+_0x1780e7);const _0x443160=new Error(_0x4facff);_0x443160['code']=_0x5301a9,_0x1dff9b(_0x443160);}});}function Od(_0x540570,_0x276be1,_0x1c5e2f,_0x4bbb6b,_0x118bf1,_0x4e3c92){gt(_0x540570,'transaction\x20on\x20'+_0x276be1);const _0x5ed03a={'path':_0x276be1,'update':_0x1c5e2f,'onComplete':_0x4bbb6b,'status':null,'order':so(),'applyLocally':_0x4e3c92,'retryCount':0x0,'unwatcher':_0x118bf1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x39049d=Es(_0x540570,_0x276be1,void 0x0);_0x5ed03a['currentInputSnapshot']=_0x39049d;const _0x3d3003=_0x5ed03a['update'](_0x39049d['val']());if(_0x3d3003===void 0x0)_0x5ed03a['unwatcher'](),_0x5ed03a['currentOutputSnapshotRaw']=null,_0x5ed03a['currentOutputSnapshotResolved']=null,_0x5ed03a['onComplete']&&_0x5ed03a['onComplete'](null,!0x1,_0x5ed03a['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3d3003,_0x5ed03a['path']),_0x5ed03a['status']=0x0;const _0x2fc5e9=$n(_0x540570['transactionQueueTree_'],_0x276be1),_0x537c2a=je(_0x2fc5e9)||[];_0x537c2a['push'](_0x5ed03a),gs(_0x2fc5e9,_0x537c2a);let _0x229dda;typeof _0x3d3003=='object'&&_0x3d3003!==null&&Q(_0x3d3003,'.priority')?(_0x229dda=Le(_0x3d3003,'.priority'),f(Bt(_0x229dda),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x229dda=(Vn(_0x540570['serverSyncTree_'],_0x276be1)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x202cbe=Xt(_0x540570),_0x1deabc=A(_0x3d3003,_0x229dda),_0x31a48a=fs(_0x1deabc,_0x39049d,_0x202cbe);_0x5ed03a['currentOutputSnapshotRaw']=_0x1deabc,_0x5ed03a['currentOutputSnapshotResolved']=_0x31a48a,_0x5ed03a['currentWriteId']=zn(_0x540570);const _0x42b242=as(_0x540570['serverSyncTree_'],_0x276be1,_0x31a48a,_0x5ed03a['currentWriteId'],_0x5ed03a['applyLocally']);V(_0x540570['eventQueue_'],_0x276be1,_0x42b242),jn(_0x540570,_0x540570['transactionQueueTree_']);}}function Es(_0x480cae,_0xe240be,_0x24cd4d){return Vn(_0x480cae['serverSyncTree_'],_0xe240be,_0x24cd4d)||g['EMPTY_NODE'];}function jn(_0x1c9e2c,_0x229f3a=_0x1c9e2c['transactionQueueTree_']){if(_0x229f3a||Kn(_0x1c9e2c,_0x229f3a),je(_0x229f3a)){const _0x7dea8c=da(_0x1c9e2c,_0x229f3a);f(_0x7dea8c['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x7dea8c['every'](_0x422673=>_0x422673['status']===0x0)&&Dd(_0x1c9e2c,Qt(_0x229f3a),_0x7dea8c);}else na(_0x229f3a)&&Gn(_0x229f3a,_0x5e7d3c=>{jn(_0x1c9e2c,_0x5e7d3c);});}function Dd(_0x8f3c35,_0x43b364,_0x40e0e7){const _0x4cd820=_0x40e0e7['map'](_0x42c73a=>_0x42c73a['currentWriteId']),_0x5bb33b=Es(_0x8f3c35,_0x43b364,_0x4cd820);let _0x274a1f=_0x5bb33b;const _0x3d0042=_0x5bb33b['hash']();for(let _0x5fd710=0x0;_0x5fd710<_0x40e0e7['length'];_0x5fd710++){const _0x956ab=_0x40e0e7[_0x5fd710];f(_0x956ab['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x956ab['status']=0x1,_0x956ab['retryCount']++;const _0xf1c4f1=F(_0x43b364,_0x956ab['path']);_0x274a1f=_0x274a1f['updateChild'](_0xf1c4f1,_0x956ab['currentOutputSnapshotRaw']);}const _0x3897fb=_0x274a1f['val'](!0x0),_0x39987d=_0x43b364;_0x8f3c35['server_']['put'](_0x39987d['toString'](),_0x3897fb,_0x4cacde=>{gt(_0x8f3c35,'transaction\x20put\x20response',{'path':_0x39987d['toString'](),'status':_0x4cacde});let _0x3133c2=[];if(_0x4cacde==='ok'){const _0x571c1f=[];for(let _0x5397b5=0x0;_0x5397b5<_0x40e0e7['length'];_0x5397b5++)_0x40e0e7[_0x5397b5]['status']=0x2,_0x3133c2=_0x3133c2['concat'](_e(_0x8f3c35['serverSyncTree_'],_0x40e0e7[_0x5397b5]['currentWriteId'])),_0x40e0e7[_0x5397b5]['onComplete']&&_0x571c1f['push'](()=>_0x40e0e7[_0x5397b5]['onComplete'](null,!0x0,_0x40e0e7[_0x5397b5]['currentOutputSnapshotResolved'])),_0x40e0e7[_0x5397b5]['unwatcher']();Kn(_0x8f3c35,$n(_0x8f3c35['transactionQueueTree_'],_0x43b364)),jn(_0x8f3c35,_0x8f3c35['transactionQueueTree_']),V(_0x8f3c35['eventQueue_'],_0x43b364,_0x3133c2);for(let _0x4e3a8b=0x0;_0x4e3a8b<_0x571c1f['length'];_0x4e3a8b++)ft(_0x571c1f[_0x4e3a8b]);}else{if(_0x4cacde==='datastale'){for(let _0x511573=0x0;_0x511573<_0x40e0e7['length'];_0x511573++)_0x40e0e7[_0x511573]['status']===0x3?_0x40e0e7[_0x511573]['status']=0x4:_0x40e0e7[_0x511573]['status']=0x0;}else{U('transaction\x20at\x20'+_0x39987d['toString']()+'\x20failed:\x20'+_0x4cacde);for(let _0xa98c10=0x0;_0xa98c10<_0x40e0e7['length'];_0xa98c10++)_0x40e0e7[_0xa98c10]['status']=0x4,_0x40e0e7[_0xa98c10]['abortReason']=_0x4cacde;}ct(_0x8f3c35,_0x43b364);}},_0x3d0042);}function ct(_0x5f05a6,_0x440f5f){const _0xfb98b1=ua(_0x5f05a6,_0x440f5f),_0x533493=Qt(_0xfb98b1),_0x1e6469=da(_0x5f05a6,_0xfb98b1);return Md(_0x5f05a6,_0x1e6469,_0x533493),_0x533493;}function Md(_0x69a306,_0x40608e,_0x3cf12b){if(_0x40608e['length']===0x0)return;const _0x1438bb=[];let _0x1fbe3c=[];const _0x327728=_0x40608e['filter'](_0x51e263=>_0x51e263['status']===0x0)['map'](_0x3e6e92=>_0x3e6e92['currentWriteId']);for(let _0x3ec9a4=0x0;_0x3ec9a4<_0x40608e['length'];_0x3ec9a4++){const _0x25b6d6=_0x40608e[_0x3ec9a4],_0x220ede=F(_0x3cf12b,_0x25b6d6['path']);let _0x3e7a5f=!0x1,_0x11e5ab;if(f(_0x220ede!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x25b6d6['status']===0x4)_0x3e7a5f=!0x0,_0x11e5ab=_0x25b6d6['abortReason'],_0x1fbe3c=_0x1fbe3c['concat'](_e(_0x69a306['serverSyncTree_'],_0x25b6d6['currentWriteId'],!0x0));else{if(_0x25b6d6['status']===0x0){if(_0x25b6d6['retryCount']>=yd)_0x3e7a5f=!0x0,_0x11e5ab='maxretry',_0x1fbe3c=_0x1fbe3c['concat'](_e(_0x69a306['serverSyncTree_'],_0x25b6d6['currentWriteId'],!0x0));else{const _0x1df815=Es(_0x69a306,_0x25b6d6['path'],_0x327728);_0x25b6d6['currentInputSnapshot']=_0x1df815;const _0x4b024f=_0x40608e[_0x3ec9a4]['update'](_0x1df815['val']());if(_0x4b024f!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4b024f,_0x25b6d6['path']);let _0x428724=A(_0x4b024f);typeof _0x4b024f=='object'&&_0x4b024f!=null&&Q(_0x4b024f,'.priority')||(_0x428724=_0x428724['updatePriority'](_0x1df815['getPriority']()));const _0x2adf46=_0x25b6d6['currentWriteId'],_0x9a2ef=Xt(_0x69a306),_0x3616cb=fs(_0x428724,_0x1df815,_0x9a2ef);_0x25b6d6['currentOutputSnapshotRaw']=_0x428724,_0x25b6d6['currentOutputSnapshotResolved']=_0x3616cb,_0x25b6d6['currentWriteId']=zn(_0x69a306),_0x327728['splice'](_0x327728['indexOf'](_0x2adf46),0x1),_0x1fbe3c=_0x1fbe3c['concat'](as(_0x69a306['serverSyncTree_'],_0x25b6d6['path'],_0x3616cb,_0x25b6d6['currentWriteId'],_0x25b6d6['applyLocally'])),_0x1fbe3c=_0x1fbe3c['concat'](_e(_0x69a306['serverSyncTree_'],_0x2adf46,!0x0));}else _0x3e7a5f=!0x0,_0x11e5ab='nodata',_0x1fbe3c=_0x1fbe3c['concat'](_e(_0x69a306['serverSyncTree_'],_0x25b6d6['currentWriteId'],!0x0));}}}V(_0x69a306['eventQueue_'],_0x3cf12b,_0x1fbe3c),_0x1fbe3c=[],_0x3e7a5f&&(_0x40608e[_0x3ec9a4]['status']=0x2,function(_0x2a684b){setTimeout(_0x2a684b,Math['floor'](0x0));}(_0x40608e[_0x3ec9a4]['unwatcher']),_0x40608e[_0x3ec9a4]['onComplete']&&(_0x11e5ab==='nodata'?_0x1438bb['push'](()=>_0x40608e[_0x3ec9a4]['onComplete'](null,!0x1,_0x40608e[_0x3ec9a4]['currentInputSnapshot'])):_0x1438bb['push'](()=>_0x40608e[_0x3ec9a4]['onComplete'](new Error(_0x11e5ab),!0x1,null))));}Kn(_0x69a306,_0x69a306['transactionQueueTree_']);for(let _0x550511=0x0;_0x550511<_0x1438bb['length'];_0x550511++)ft(_0x1438bb[_0x550511]);jn(_0x69a306,_0x69a306['transactionQueueTree_']);}function ua(_0x31b5f8,_0x49c336){let _0xe3a72,_0x2626b8=_0x31b5f8['transactionQueueTree_'];for(_0xe3a72=y(_0x49c336);_0xe3a72!==null&&je(_0x2626b8)===void 0x0;)_0x2626b8=$n(_0x2626b8,_0xe3a72),_0x49c336=S(_0x49c336),_0xe3a72=y(_0x49c336);return _0x2626b8;}function da(_0x41c961,_0x3f56d7){const _0x35def2=[];return fa(_0x41c961,_0x3f56d7,_0x35def2),_0x35def2['sort']((_0x3830de,_0x1a93d1)=>_0x3830de['order']-_0x1a93d1['order']),_0x35def2;}function fa(_0x62481e,_0x150c43,_0x3715f5){const _0x235e8a=je(_0x150c43);if(_0x235e8a){for(let _0x5722cc=0x0;_0x5722cc<_0x235e8a['length'];_0x5722cc++)_0x3715f5['push'](_0x235e8a[_0x5722cc]);}Gn(_0x150c43,_0xda2b14=>{fa(_0x62481e,_0xda2b14,_0x3715f5);});}function Kn(_0x374ba8,_0xc2c12f){const _0x31679e=je(_0xc2c12f);if(_0x31679e){let _0x3f813e=0x0;for(let _0x25c473=0x0;_0x25c473<_0x31679e['length'];_0x25c473++)_0x31679e[_0x25c473]['status']!==0x2&&(_0x31679e[_0x3f813e]=_0x31679e[_0x25c473],_0x3f813e++);_0x31679e['length']=_0x3f813e,gs(_0xc2c12f,_0x31679e['length']>0x0?_0x31679e:void 0x0);}Gn(_0xc2c12f,_0x48c95d=>{Kn(_0x374ba8,_0x48c95d);});}function Is(_0x2fd45e,_0x571178){const _0x3c7708=Qt(ua(_0x2fd45e,_0x571178)),_0xc4d185=$n(_0x2fd45e['transactionQueueTree_'],_0x571178);return ad(_0xc4d185,_0x33d4d8=>{di(_0x2fd45e,_0x33d4d8);}),di(_0x2fd45e,_0xc4d185),ia(_0xc4d185,_0x51de4a=>{di(_0x2fd45e,_0x51de4a);}),_0x3c7708;}function di(_0x43e47e,_0x522fc0){const _0x5bc81f=je(_0x522fc0);if(_0x5bc81f){const _0x968ce7=[];let _0xe92a53=[],_0x53d485=-0x1;for(let _0x3973ad=0x0;_0x3973ad<_0x5bc81f['length'];_0x3973ad++)_0x5bc81f[_0x3973ad]['status']===0x3||(_0x5bc81f[_0x3973ad]['status']===0x1?(f(_0x53d485===_0x3973ad-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x53d485=_0x3973ad,_0x5bc81f[_0x3973ad]['status']=0x3,_0x5bc81f[_0x3973ad]['abortReason']='set'):(f(_0x5bc81f[_0x3973ad]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5bc81f[_0x3973ad]['unwatcher'](),_0xe92a53=_0xe92a53['concat'](_e(_0x43e47e['serverSyncTree_'],_0x5bc81f[_0x3973ad]['currentWriteId'],!0x0)),_0x5bc81f[_0x3973ad]['onComplete']&&_0x968ce7['push'](_0x5bc81f[_0x3973ad]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x53d485===-0x1?gs(_0x522fc0,void 0x0):_0x5bc81f['length']=_0x53d485+0x1,V(_0x43e47e['eventQueue_'],Qt(_0x522fc0),_0xe92a53);for(let _0x55ffb5=0x0;_0x55ffb5<_0x968ce7['length'];_0x55ffb5++)ft(_0x968ce7[_0x55ffb5]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2603a6){let _0x35da2b='';const _0x2709cf=_0x2603a6['split']('/');for(let _0xc96a37=0x0;_0xc96a37<_0x2709cf['length'];_0xc96a37++)if(_0x2709cf[_0xc96a37]['length']>0x0){let _0x43f74d=_0x2709cf[_0xc96a37];try{_0x43f74d=decodeURIComponent(_0x43f74d['replace'](/\+/g,'\x20'));}catch{}_0x35da2b+='/'+_0x43f74d;}return _0x35da2b;}function xd(_0x1b5796){const _0x595818={};_0x1b5796['charAt'](0x0)==='?'&&(_0x1b5796=_0x1b5796['substring'](0x1));for(const _0x48659c of _0x1b5796['split']('&')){if(_0x48659c['length']===0x0)continue;const _0x5d731a=_0x48659c['split']('=');_0x5d731a['length']===0x2?_0x595818[decodeURIComponent(_0x5d731a[0x0])]=decodeURIComponent(_0x5d731a[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x48659c+'\x27\x20in\x20query\x20\x27'+_0x1b5796+'\x27');}return _0x595818;}const vr=function(_0x557088,_0xd91dc8){const _0x1bfb70=Fd(_0x557088),_0x4c18bc=_0x1bfb70['namespace'];_0x1bfb70['domain']==='firebase.com'&&ae(_0x1bfb70['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x4c18bc||_0x4c18bc==='undefined')&&_0x1bfb70['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1bfb70['secure']||$l();const _0x22a165=_0x1bfb70['scheme']==='ws'||_0x1bfb70['scheme']==='wss';return{'repoInfo':new yo(_0x1bfb70['host'],_0x1bfb70['secure'],_0x4c18bc,_0x22a165,_0xd91dc8,'',_0x4c18bc!==_0x1bfb70['subdomain']),'path':new C(_0x1bfb70['pathString'])};},Fd=function(_0x13ec26){let _0x3cd117='',_0x3fbbfc='',_0x2bc641='',_0xd5695c='',_0x2a9e05='',_0x4b8404=!0x0,_0x6294c4='https',_0x43ffca=0x1bb;if(typeof _0x13ec26=='string'){let _0x25de26=_0x13ec26['indexOf']('//');_0x25de26>=0x0&&(_0x6294c4=_0x13ec26['substring'](0x0,_0x25de26-0x1),_0x13ec26=_0x13ec26['substring'](_0x25de26+0x2));let _0x4694de=_0x13ec26['indexOf']('/');_0x4694de===-0x1&&(_0x4694de=_0x13ec26['length']);let _0x2f9b93=_0x13ec26['indexOf']('?');_0x2f9b93===-0x1&&(_0x2f9b93=_0x13ec26['length']),_0x3cd117=_0x13ec26['substring'](0x0,Math['min'](_0x4694de,_0x2f9b93)),_0x4694de<_0x2f9b93&&(_0xd5695c=Ld(_0x13ec26['substring'](_0x4694de,_0x2f9b93)));const _0x5b93c7=xd(_0x13ec26['substring'](Math['min'](_0x13ec26['length'],_0x2f9b93)));_0x25de26=_0x3cd117['indexOf'](':'),_0x25de26>=0x0?(_0x4b8404=_0x6294c4==='https'||_0x6294c4==='wss',_0x43ffca=parseInt(_0x3cd117['substring'](_0x25de26+0x1),0xa)):_0x25de26=_0x3cd117['length'];const _0x287b69=_0x3cd117['slice'](0x0,_0x25de26);if(_0x287b69['toLowerCase']()==='localhost')_0x3fbbfc='localhost';else{if(_0x287b69['split']('.')['length']<=0x2)_0x3fbbfc=_0x287b69;else{const _0x37d9b6=_0x3cd117['indexOf']('.');_0x2bc641=_0x3cd117['substring'](0x0,_0x37d9b6)['toLowerCase'](),_0x3fbbfc=_0x3cd117['substring'](_0x37d9b6+0x1),_0x2a9e05=_0x2bc641;}}'ns'in _0x5b93c7&&(_0x2a9e05=_0x5b93c7['ns']);}return{'host':_0x3cd117,'port':_0x43ffca,'domain':_0x3fbbfc,'subdomain':_0x2bc641,'secure':_0x4b8404,'scheme':_0x6294c4,'pathString':_0xd5695c,'namespace':_0x2a9e05};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x484f46=0x0;const _0x43928d=[];return function(_0x27383e){const _0x319796=_0x27383e===_0x484f46;_0x484f46=_0x27383e;let _0x4521ed;const _0x56aeb9=new Array(0x8);for(_0x4521ed=0x7;_0x4521ed>=0x0;_0x4521ed--)_0x56aeb9[_0x4521ed]=Er['charAt'](_0x27383e%0x40),_0x27383e=Math['floor'](_0x27383e/0x40);f(_0x27383e===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x54425d=_0x56aeb9['join']('');if(_0x319796){for(_0x4521ed=0xb;_0x4521ed>=0x0&&_0x43928d[_0x4521ed]===0x3f;_0x4521ed--)_0x43928d[_0x4521ed]=0x0;_0x43928d[_0x4521ed]++;}else{for(_0x4521ed=0x0;_0x4521ed<0xc;_0x4521ed++)_0x43928d[_0x4521ed]=Math['floor'](Math['random']()*0x40);}for(_0x4521ed=0x0;_0x4521ed<0xc;_0x4521ed++)_0x54425d+=Er['charAt'](_0x43928d[_0x4521ed]);return f(_0x54425d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x54425d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x266aa2,_0x6ddab5,_0x4f7daf,_0x2ca6c3){this['eventType']=_0x266aa2,this['eventRegistration']=_0x6ddab5,this['snapshot']=_0x4f7daf,this['prevName']=_0x2ca6c3;}['getPath'](){const _0x2bb300=this['snapshot']['ref'];return this['eventType']==='value'?_0x2bb300['_path']:_0x2bb300['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0xc30fc7,_0x301641,_0x9b9cbb){this['eventRegistration']=_0xc30fc7,this['error']=_0x301641,this['path']=_0x9b9cbb;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4f6ca7,_0x4b7382){this['snapshotCallback']=_0x4f6ca7,this['cancelCallback']=_0x4b7382;}['onValue'](_0x36696c,_0x646d5c){this['snapshotCallback']['call'](null,_0x36696c,_0x646d5c);}['onCancel'](_0x1c24f7){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1c24f7);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x17756b){return this['snapshotCallback']===_0x17756b['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x17756b['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x17756b['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x342342,_0x94562){this['_repo']=_0x342342,this['_path']=_0x94562;}['cancel'](){const _0x56e81e=new H();return bd(this['_repo'],this['_path'],_0x56e81e['wrapCallback'](()=>{})),_0x56e81e['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x322faa=new H();return yr(this['_repo'],this['_path'],null,_0x322faa['wrapCallback'](()=>{})),_0x322faa['promise'];}['set'](_0x55f063){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x55f063,this['_path'],!0x1);const _0x4fac8b=new H();return yr(this['_repo'],this['_path'],_0x55f063,_0x4fac8b['wrapCallback'](()=>{})),_0x4fac8b['promise'];}['setWithPriority'](_0x13046f,_0x33788f){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x13046f,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x33788f);const _0xd211dd=new H();return Rd(this['_repo'],this['_path'],_0x13046f,_0x33788f,_0xd211dd['wrapCallback'](()=>{})),_0xd211dd['promise'];}['update'](_0x31e0ce){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x31e0ce,this['_path']);const _0x367cec=new H();return Ad(this['_repo'],this['_path'],_0x31e0ce,_0x367cec['wrapCallback'](()=>{})),_0x367cec['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x15ba61,_0x24abde,_0x560744,_0x281663){this['_repo']=_0x15ba61,this['_path']=_0x24abde,this['_queryParams']=_0x560744,this['_orderByCalled']=_0x281663;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5979d8=sr(this['_queryParams']),_0x296481=$i(_0x5979d8);return _0x296481==='{}'?'default':_0x296481;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x5956a8){if(_0x5956a8=P(_0x5956a8),!(_0x5956a8 instanceof Ae))return!0x1;const _0x475aa4=this['_repo']===_0x5956a8['_repo'],_0x56fc0c=Ki(this['_path'],_0x5956a8['_path']),_0x310777=this['_queryIdentifier']===_0x5956a8['_queryIdentifier'];return _0x475aa4&&_0x56fc0c&&_0x310777;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x94ca79,_0xfde428){if(_0x94ca79['_orderByCalled']===!0x0)throw new Error(_0xfde428+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1cc44b){let _0x3c815c=null,_0xf592a5=null;if(_0x1cc44b['hasStart']()&&(_0x3c815c=_0x1cc44b['getIndexStartValue']()),_0x1cc44b['hasEnd']()&&(_0xf592a5=_0x1cc44b['getIndexEndValue']()),_0x1cc44b['getIndex']()===ve){const _0x140998='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2116a0='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1cc44b['hasStart']()){if(_0x1cc44b['getIndexStartName']()!==We)throw new Error(_0x140998);if(typeof _0x3c815c!='string')throw new Error(_0x2116a0);}if(_0x1cc44b['hasEnd']()){if(_0x1cc44b['getIndexEndName']()!==we)throw new Error(_0x140998);if(typeof _0xf592a5!='string')throw new Error(_0x2116a0);}}else{if(_0x1cc44b['getIndex']()===R){if(_0x3c815c!=null&&!Bt(_0x3c815c)||_0xf592a5!=null&&!Bt(_0xf592a5))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1cc44b['getIndex']()instanceof Ji||_0x1cc44b['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3c815c!=null&&typeof _0x3c815c=='object'||_0xf592a5!=null&&typeof _0xf592a5=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2f6dc6){if(_0x2f6dc6['hasStart']()&&_0x2f6dc6['hasEnd']()&&_0x2f6dc6['hasLimit']()&&!_0x2f6dc6['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0xbbb427,_0x1c3bfc){super(_0xbbb427,_0x1c3bfc,new Zi(),!0x1);}get['parent'](){const _0x15bba2=Ro(this['_path']);return _0x15bba2===null?null:new ee(this['_repo'],_0x15bba2);}get['root'](){let _0x960d9a=this;for(;_0x960d9a['parent']!==null;)_0x960d9a=_0x960d9a['parent'];return _0x960d9a;}}class lt{constructor(_0x3ec5ca,_0x33122b,_0x47edef){this['_node']=_0x3ec5ca,this['ref']=_0x33122b,this['_index']=_0x47edef;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2e6d6e){const _0x14f024=new C(_0x2e6d6e),_0x1b40cc=Vt(this['ref'],_0x2e6d6e);return new lt(this['_node']['getChild'](_0x14f024),_0x1b40cc,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5e97ea){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x205bc5,_0x497981)=>_0x5e97ea(new lt(_0x497981,Vt(this['ref'],_0x205bc5),R)));}['hasChild'](_0x5515d0){const _0x4bfb28=new C(_0x5515d0);return!this['_node']['getChild'](_0x4bfb28)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x5965fa,_0x3c02bf){return _0x5965fa=P(_0x5965fa),_0x5965fa['_checkNotDeleted']('ref'),_0x3c02bf!==void 0x0?Vt(_0x5965fa['_root'],_0x3c02bf):_0x5965fa['_root'];}function Vt(_0x4dda96,_0x40493b){return _0x4dda96=P(_0x4dda96),y(_0x4dda96['_path'])===null?pd('child','path',_0x40493b):ys('child','path',_0x40493b),new ee(_0x4dda96['_repo'],k(_0x4dda96['_path'],_0x40493b));}function v_(_0x259b43){return _0x259b43=P(_0x259b43),new Vd(_0x259b43['_repo'],_0x259b43['_path']);}function E_(_0x474e71,_0x21543){_0x474e71=P(_0x474e71),Me('push',_0x474e71['_path']),He('push',_0x21543,_0x474e71['_path'],!0x0);const _0x3b981b=la(_0x474e71['_repo']),_0x3855b0=Ud(_0x3b981b),_0x488524=Vt(_0x474e71,_0x3855b0),_0x4d054e=Vt(_0x474e71,_0x3855b0);let _0x2bb87b;return _0x21543!=null?_0x2bb87b=Hd(_0x4d054e,_0x21543)['then'](()=>_0x4d054e):_0x2bb87b=Promise['resolve'](_0x4d054e),_0x488524['then']=_0x2bb87b['then']['bind'](_0x2bb87b),_0x488524['catch']=_0x2bb87b['then']['bind'](_0x2bb87b,void 0x0),_0x488524;}function Hd(_0x182351,_0x374279){_0x182351=P(_0x182351),Me('set',_0x182351['_path']),He('set',_0x374279,_0x182351['_path'],!0x1);const _0x1a2c31=new H();return Cd(_0x182351['_repo'],_0x182351['_path'],_0x374279,null,_0x1a2c31['wrapCallback'](()=>{})),_0x1a2c31['promise'];}function I_(_0x4d53db,_0x3e544f){ra('update',_0x3e544f,_0x4d53db['_path']);const _0x147308=new H();return Td(_0x4d53db['_repo'],_0x4d53db['_path'],_0x3e544f,_0x147308['wrapCallback'](()=>{})),_0x147308['promise'];}function w_(_0x1e1116){_0x1e1116=P(_0x1e1116);const _0x4f0806=new pa(()=>{}),_0x4fc907=new Qn(_0x4f0806);return wd(_0x1e1116['_repo'],_0x1e1116,_0x4fc907)['then'](_0x309cf8=>new lt(_0x309cf8,new ee(_0x1e1116['_repo'],_0x1e1116['_path']),_0x1e1116['_queryParams']['getIndex']()));}class Qn{constructor(_0x15d74c){this['callbackContext']=_0x15d74c;}['respondsTo'](_0xe4a2a6){return _0xe4a2a6==='value';}['createEvent'](_0x51ec77,_0x1a8779){const _0x502c7c=_0x1a8779['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x51ec77['snapshotNode'],new ee(_0x1a8779['_repo'],_0x1a8779['_path']),_0x502c7c));}['getEventRunner'](_0x17824a){return _0x17824a['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x17824a['error']):()=>this['callbackContext']['onValue'](_0x17824a['snapshot'],null);}['createCancelEvent'](_0x39ff37,_0x232143){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x39ff37,_0x232143):null;}['matches'](_0x5b844c){return _0x5b844c instanceof Qn?!_0x5b844c['callbackContext']||!this['callbackContext']?!0x0:_0x5b844c['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x175432,_0xb7bbe7,_0x5baf57,_0x217a49,_0x583ce7){const _0xa547d9=new pa(_0x5baf57,void 0x0),_0x2322e4=new Qn(_0xa547d9);return kd(_0x175432['_repo'],_0x175432,_0x2322e4),()=>Pd(_0x175432['_repo'],_0x175432,_0x2322e4);}function Gd(_0x1ceba6,_0x48bf85,_0x20087f,_0x15dc5a){return $d(_0x1ceba6,'value',_0x48bf85);}class mt{}class ma extends mt{constructor(_0x559247,_0x232f71){super(),this['_value']=_0x559247,this['_key']=_0x232f71,this['type']='endAt';}['_apply'](_0x1ac3a5){He('endAt',this['_value'],_0x1ac3a5['_path'],!0x0);const _0x3f0406=Jh(_0x1ac3a5['_queryParams'],this['_value'],this['_key']);if(ga(_0x3f0406),Yn(_0x3f0406),_0x1ac3a5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x1ac3a5['_repo'],_0x1ac3a5['_path'],_0x3f0406,_0x1ac3a5['_orderByCalled']);}}function C_(_0x3bffe5,_0x47c133){return new ma(_0x3bffe5,_0x47c133);}class ya extends mt{constructor(_0x5674aa,_0x404a0b){super(),this['_value']=_0x5674aa,this['_key']=_0x404a0b,this['type']='startAt';}['_apply'](_0x10fa4f){He('startAt',this['_value'],_0x10fa4f['_path'],!0x0);const _0x44f1be=Qh(_0x10fa4f['_queryParams'],this['_value'],this['_key']);if(ga(_0x44f1be),Yn(_0x44f1be),_0x10fa4f['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x10fa4f['_repo'],_0x10fa4f['_path'],_0x44f1be,_0x10fa4f['_orderByCalled']);}}function T_(_0x403238=null,_0x256777){return new ya(_0x403238,_0x256777);}class qd extends mt{constructor(_0x5acd39){super(),this['_limit']=_0x5acd39,this['type']='limitToFirst';}['_apply'](_0x32c647){if(_0x32c647['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x32c647['_repo'],_0x32c647['_path'],Yh(_0x32c647['_queryParams'],this['_limit']),_0x32c647['_orderByCalled']);}}function S_(_0x1ddbd5){if(Math['floor'](_0x1ddbd5)!==_0x1ddbd5||_0x1ddbd5<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x1ddbd5);}class zd extends mt{constructor(_0xc4a372){super(),this['_path']=_0xc4a372,this['type']='orderByChild';}['_apply'](_0x594d94){_a(_0x594d94,'orderByChild');const _0x46df67=new C(this['_path']);if(v(_0x46df67))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xe27750=new Ji(_0x46df67),_0x4392da=xo(_0x594d94['_queryParams'],_0xe27750);return Yn(_0x4392da),new Ae(_0x594d94['_repo'],_0x594d94['_path'],_0x4392da,!0x0);}}function b_(_0x453200){if(_0x453200==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x453200==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x453200==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x453200),new zd(_0x453200);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1bbb27){_a(_0x1bbb27,'orderByKey');const _0x27abfb=xo(_0x1bbb27['_queryParams'],ve);return Yn(_0x27abfb),new Ae(_0x1bbb27['_repo'],_0x1bbb27['_path'],_0x27abfb,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x4dada0,_0x5ef0c2){super(),this['_value']=_0x4dada0,this['_key']=_0x5ef0c2,this['type']='equalTo';}['_apply'](_0x3bb38f){if(He('equalTo',this['_value'],_0x3bb38f['_path'],!0x1),_0x3bb38f['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3bb38f['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3bb38f));}}function A_(_0x3f5aad,_0x32c824){return new Kd(_0x3f5aad,_0x32c824);}function k_(_0x4426b8,..._0x578d45){let _0xce4c43=P(_0x4426b8);for(const _0x32e992 of _0x578d45)_0xce4c43=_0x32e992['_apply'](_0xce4c43);return _0xce4c43;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x102d98,_0x1e278e,_0x278cfb,_0x1ebc4a){const _0x53d4bf=_0x1e278e['lastIndexOf'](':'),_0x3ad096=_0x1e278e['substring'](0x0,_0x53d4bf),_0x511bfc=qt(_0x3ad096);_0x102d98['repoInfo_']=new yo(_0x1e278e,_0x511bfc,_0x102d98['repoInfo_']['namespace'],_0x102d98['repoInfo_']['webSocketOnly'],_0x102d98['repoInfo_']['nodeAdmin'],_0x102d98['repoInfo_']['persistenceKey'],_0x102d98['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x278cfb),_0x1ebc4a&&(_0x102d98['authTokenProvider_']=_0x1ebc4a);}function Xd(_0x339e37,_0x4ab5f8,_0x4d6f84,_0x1b9d32,_0x33da9a){let _0x542945=_0x1b9d32||_0x339e37['options']['databaseURL'];_0x542945===void 0x0&&(_0x339e37['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x339e37['options']['projectId']),_0x542945=_0x339e37['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x511d93=vr(_0x542945,_0x33da9a),_0xd90aa3=_0x511d93['repoInfo'],_0x4e5434;typeof process<'u'&&Bs&&(_0x4e5434=Bs[Yd]),_0x4e5434?(_0x542945='http://'+_0x4e5434+'?ns='+_0xd90aa3['namespace'],_0x511d93=vr(_0x542945,_0x33da9a),_0xd90aa3=_0x511d93['repoInfo']):_0x511d93['repoInfo']['secure'];const _0xdafd1=new eh(_0x339e37['name'],_0x339e37['options'],_0x4ab5f8);_d('Invalid\x20Firebase\x20Database\x20URL',_0x511d93),v(_0x511d93['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x33d0cd=ef(_0xd90aa3,_0x339e37,_0xdafd1,new Zl(_0x339e37,_0x4d6f84));return new tf(_0x33d0cd,_0x339e37);}function Zd(_0x31e813,_0x1d8ec9){const _0x322397=Di[_0x1d8ec9];(!_0x322397||_0x322397[_0x31e813['key']]!==_0x31e813)&&ae('Database\x20'+_0x1d8ec9+'('+_0x31e813['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x31e813),delete _0x322397[_0x31e813['key']];}function ef(_0x44209c,_0x42fb97,_0x302c55,_0x22fb7e){let _0xba315f=Di[_0x42fb97['name']];_0xba315f||(_0xba315f={},Di[_0x42fb97['name']]=_0xba315f);let _0x2908e2=_0xba315f[_0x44209c['toURLString']()];return _0x2908e2&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2908e2=new vd(_0x44209c,Qd,_0x302c55,_0x22fb7e),_0xba315f[_0x44209c['toURLString']()]=_0x2908e2,_0x2908e2;}class tf{constructor(_0x59c759,_0x447523){this['_repoInternal']=_0x59c759,this['app']=_0x447523,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x30675d){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x30675d+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x249138=Zr(),_0x330cdc){const _0x4fd198=Hi(_0x249138,'database')['getImmediate']({'identifier':_0x330cdc});if(!_0x4fd198['_instanceStarted']){const _0x20c25b=hc('database');_0x20c25b&&nf(_0x4fd198,..._0x20c25b);}return _0x4fd198;}function nf(_0x1bef7a,_0x5eb4ed,_0x1a5465,_0x590bba={}){_0x1bef7a=P(_0x1bef7a),_0x1bef7a['_checkNotDeleted']('useEmulator');const _0x36a430=_0x5eb4ed+':'+_0x1a5465,_0x1abdb9=_0x1bef7a['_repoInternal'];if(_0x1bef7a['_instanceStarted']){if(_0x36a430===_0x1bef7a['_repoInternal']['repoInfo_']['host']&&xe(_0x590bba,_0x1abdb9['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2e0334;if(_0x1abdb9['repoInfo_']['nodeAdmin'])_0x590bba['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2e0334=new an(an['OWNER']);else{if(_0x590bba['mockUserToken']){const _0x2fdd1d=typeof _0x590bba['mockUserToken']=='string'?_0x590bba['mockUserToken']:uc(_0x590bba['mockUserToken'],_0x1bef7a['app']['options']['projectId']);_0x2e0334=new an(_0x2fdd1d);}}qt(_0x5eb4ed)&&Qr(_0x5eb4ed),Jd(_0x1abdb9,_0x36a430,_0x590bba,_0x2e0334);}function N_(_0x4a288f){_0x4a288f=P(_0x4a288f),_0x4a288f['_checkNotDeleted']('goOffline'),ha(_0x4a288f['_repo']);}function O_(_0x163e1c){_0x163e1c=P(_0x163e1c),_0x163e1c['_checkNotDeleted']('goOnline'),Nd(_0x163e1c['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x268ae1){Ul(dt),st(new Fe('database',(_0x1bd3cb,{instanceIdentifier:_0x585013})=>{const _0x29c8e6=_0x1bd3cb['getProvider']('app')['getImmediate'](),_0x57a3b3=_0x1bd3cb['getProvider']('auth-internal'),_0x3568e4=_0x1bd3cb['getProvider']('app-check-internal');return Xd(_0x29c8e6,_0x57a3b3,_0x3568e4,_0x585013);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x268ae1),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x3ced77,_0x42d50f){this['committed']=_0x3ced77,this['snapshot']=_0x42d50f;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x414fae,_0x90dfa6,_0x32398f){if(_0x414fae=P(_0x414fae),Me('Reference.transaction',_0x414fae['_path']),_0x414fae['key']==='.length'||_0x414fae['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x414fae['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3668b1=!0x0,_0x2bb363=new H(),_0x1b17c9=(_0x28b9eb,_0x44fedf,_0x194437)=>{let _0x2232f2=null;_0x28b9eb?_0x2bb363['reject'](_0x28b9eb):(_0x2232f2=new lt(_0x194437,new ee(_0x414fae['_repo'],_0x414fae['_path']),R),_0x2bb363['resolve'](new of(_0x44fedf,_0x2232f2)));},_0x15f390=Gd(_0x414fae,()=>{});return Od(_0x414fae['_repo'],_0x414fae['_path'],_0x90dfa6,_0x1b17c9,_0x15f390,_0x3668b1),_0x2bb363['promise'];}se['prototype']['simpleListen']=function(_0x116a75,_0x42e691){this['sendRequest']('q',{'p':_0x116a75},_0x42e691);},se['prototype']['echo']=function(_0x24f4bd,_0x20b6a9){this['sendRequest']('echo',{'d':_0x24f4bd},_0x20b6a9);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x4fe0ad,..._0x56d7de){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x4fe0ad,..._0x56d7de);}function cn(_0x3bc73d,..._0x1b4b72){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3bc73d,..._0x1b4b72);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3dc93c,..._0x2d88b5){throw ws(_0x3dc93c,..._0x2d88b5);}function X(_0x13081d,..._0x5c85b5){return ws(_0x13081d,..._0x5c85b5);}function Ia(_0x28fc70,_0x363c57,_0x598fb9){const _0x4ea517={...af(),[_0x363c57]:_0x598fb9};return new Gt('auth','Firebase',_0x4ea517)['create'](_0x363c57,{'appName':_0x28fc70['name']});}function re(_0x324a71){return Ia(_0x324a71,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2db975,..._0x3866a5){if(typeof _0x2db975!='string'){const _0x20beeb=_0x3866a5[0x0],_0x50891a=[..._0x3866a5['slice'](0x1)];return _0x50891a[0x0]&&(_0x50891a[0x0]['appName']=_0x2db975['name']),_0x2db975['_errorFactory']['create'](_0x20beeb,..._0x50891a);}return Ea['create'](_0x2db975,..._0x3866a5);}function m(_0x4b0847,_0x5b55f4,..._0x18da0b){if(!_0x4b0847)throw ws(_0x5b55f4,..._0x18da0b);}function ne(_0x12f705){const _0xc6746a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x12f705;throw cn(_0xc6746a),new Error(_0xc6746a);}function ce(_0x5c3da9,_0x5c37f8){_0x5c3da9||ne(_0x5c37f8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x29bf79;return typeof self<'u'&&((_0x29bf79=self['location'])==null?void 0x0:_0x29bf79['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x30baf9;return typeof self<'u'&&((_0x30baf9=self['location'])==null?void 0x0:_0x30baf9['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x15051b=navigator;return _0x15051b['languages']&&_0x15051b['languages'][0x0]||_0x15051b['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x391dbf,_0x8c66ad){this['shortDelay']=_0x391dbf,this['longDelay']=_0x8c66ad,ce(_0x8c66ad>_0x391dbf,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x59c833,_0x16cfcf){ce(_0x59c833['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0xca969d}=_0x59c833['emulator'];return _0x16cfcf?''+_0xca969d+(_0x16cfcf['startsWith']('/')?_0x16cfcf['slice'](0x1):_0x16cfcf):_0xca969d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3e4b2f,_0x53ef12,_0x5ce99f){this['fetchImpl']=_0x3e4b2f,_0x53ef12&&(this['headersImpl']=_0x53ef12),_0x5ce99f&&(this['responseImpl']=_0x5ce99f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x230144,_0x17dec5){return _0x230144['tenantId']&&!_0x17dec5['tenantId']?{..._0x17dec5,'tenantId':_0x230144['tenantId']}:_0x17dec5;}async function Pe(_0x3d8d38,_0x3818bc,_0x3786f4,_0x215d4f,_0x41fabc={}){return Ca(_0x3d8d38,_0x41fabc,async()=>{let _0x184f5c={},_0x4e6135={};_0x215d4f&&(_0x3818bc==='GET'?_0x4e6135=_0x215d4f:_0x184f5c={'body':JSON['stringify'](_0x215d4f)});const _0x13c3fc=ut({..._0x4e6135,'key':_0x3d8d38['config']['apiKey']})['slice'](0x1),_0x46f543=await _0x3d8d38['_getAdditionalHeaders']();_0x46f543['Content-Type']='application/json',_0x3d8d38['languageCode']&&(_0x46f543['X-Firebase-Locale']=_0x3d8d38['languageCode']);const _0x95fd09={'method':_0x3818bc,'headers':_0x46f543,..._0x184f5c};return dc()||(_0x95fd09['referrerPolicy']='strict-origin-when-cross-origin'),_0x3d8d38['emulatorConfig']&&qt(_0x3d8d38['emulatorConfig']['host'])&&(_0x95fd09['credentials']='include'),wa['fetch']()(await Ta(_0x3d8d38,_0x3d8d38['config']['apiHost'],_0x3786f4,_0x13c3fc),_0x95fd09);});}async function Ca(_0x1ec35b,_0x4d3ee1,_0x225db6){_0x1ec35b['_canInitEmulator']=!0x1;const _0x569741={...df,..._0x4d3ee1};try{const _0x1cf389=new gf(_0x1ec35b),_0x2e4a28=await Promise['race']([_0x225db6(),_0x1cf389['promise']]);_0x1cf389['clearNetworkTimeout']();const _0x336c7c=await _0x2e4a28['json']();if('needConfirmation'in _0x336c7c)throw on(_0x1ec35b,'account-exists-with-different-credential',_0x336c7c);if(_0x2e4a28['ok']&&!('errorMessage'in _0x336c7c))return _0x336c7c;{const _0x3b98d3=_0x2e4a28['ok']?_0x336c7c['errorMessage']:_0x336c7c['error']['message'],[_0x146ca7,_0x142333]=_0x3b98d3['split']('\x20:\x20');if(_0x146ca7==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x1ec35b,'credential-already-in-use',_0x336c7c);if(_0x146ca7==='EMAIL_EXISTS')throw on(_0x1ec35b,'email-already-in-use',_0x336c7c);if(_0x146ca7==='USER_DISABLED')throw on(_0x1ec35b,'user-disabled',_0x336c7c);const _0x2613d9=_0x569741[_0x146ca7]||_0x146ca7['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x142333)throw Ia(_0x1ec35b,_0x2613d9,_0x142333);Y(_0x1ec35b,_0x2613d9);}}catch(_0x2f8c3a){if(_0x2f8c3a instanceof Re)throw _0x2f8c3a;Y(_0x1ec35b,'network-request-failed',{'message':String(_0x2f8c3a)});}}async function en(_0x1446db,_0x3f6cd9,_0x249bce,_0x610e0c,_0x38f789={}){const _0x5ab0d6=await Pe(_0x1446db,_0x3f6cd9,_0x249bce,_0x610e0c,_0x38f789);return'mfaPendingCredential'in _0x5ab0d6&&Y(_0x1446db,'multi-factor-auth-required',{'_serverResponse':_0x5ab0d6}),_0x5ab0d6;}async function Ta(_0x490c77,_0x4afeec,_0x274609,_0xb17b3f){const _0x32cc9a=''+_0x4afeec+_0x274609+'?'+_0xb17b3f,_0x371be8=_0x490c77,_0x5b04ee=_0x371be8['config']['emulator']?Cs(_0x490c77['config'],_0x32cc9a):_0x490c77['config']['apiScheme']+'://'+_0x32cc9a;return ff['includes'](_0x274609)&&(await _0x371be8['_persistenceManagerAvailable'],_0x371be8['_getPersistenceType']()==='COOKIE')?_0x371be8['_getPersistence']()['_getFinalTarget'](_0x5b04ee)['toString']():_0x5b04ee;}function _f(_0x121215){switch(_0x121215){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x45a912){this['auth']=_0x45a912,this['timer']=null,this['promise']=new Promise((_0xb3f161,_0x6dbea5)=>{this['timer']=setTimeout(()=>_0x6dbea5(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x4d7547,_0x17a770,_0x459619){const _0x5cd1b4={'appName':_0x4d7547['name']};_0x459619['email']&&(_0x5cd1b4['email']=_0x459619['email']),_0x459619['phoneNumber']&&(_0x5cd1b4['phoneNumber']=_0x459619['phoneNumber']);const _0x212699=X(_0x4d7547,_0x17a770,_0x5cd1b4);return _0x212699['customData']['_tokenResponse']=_0x459619,_0x212699;}function wr(_0x497c8c){return _0x497c8c!==void 0x0&&_0x497c8c['enterprise']!==void 0x0;}class mf{constructor(_0x3e0fdf){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3e0fdf['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3e0fdf['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3e0fdf['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2c88ba){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x279538 of this['recaptchaEnforcementState'])if(_0x279538['provider']&&_0x279538['provider']===_0x2c88ba)return _f(_0x279538['enforcementState']);return null;}['isProviderEnabled'](_0x3ce8b8){return this['getProviderEnforcementState'](_0x3ce8b8)==='ENFORCE'||this['getProviderEnforcementState'](_0x3ce8b8)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2401ed,_0x53fd98){return Pe(_0x2401ed,'GET','/v2/recaptchaConfig',ke(_0x2401ed,_0x53fd98));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3028e2,_0xefc55c){return Pe(_0x3028e2,'POST','/v1/accounts:delete',_0xefc55c);}async function Pn(_0x4a50ca,_0x2b600e){return Pe(_0x4a50ca,'POST','/v1/accounts:lookup',_0x2b600e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x155832){if(_0x155832)try{const _0x2c8dfa=new Date(Number(_0x155832));if(!isNaN(_0x2c8dfa['getTime']()))return _0x2c8dfa['toUTCString']();}catch{}}async function Ef(_0x500639,_0x577d9c=!0x1){const _0x2b6907=P(_0x500639),_0x34f6c5=await _0x2b6907['getIdToken'](_0x577d9c),_0x477ce2=Ts(_0x34f6c5);m(_0x477ce2&&_0x477ce2['exp']&&_0x477ce2['auth_time']&&_0x477ce2['iat'],_0x2b6907['auth'],'internal-error');const _0x56d839=typeof _0x477ce2['firebase']=='object'?_0x477ce2['firebase']:void 0x0,_0x7e067a=_0x56d839==null?void 0x0:_0x56d839['sign_in_provider'];return{'claims':_0x477ce2,'token':_0x34f6c5,'authTime':Pt(fi(_0x477ce2['auth_time'])),'issuedAtTime':Pt(fi(_0x477ce2['iat'])),'expirationTime':Pt(fi(_0x477ce2['exp'])),'signInProvider':_0x7e067a||null,'signInSecondFactor':(_0x56d839==null?void 0x0:_0x56d839['sign_in_second_factor'])||null};}function fi(_0x4a2c78){return Number(_0x4a2c78)*0x3e8;}function Ts(_0x412ced){const [_0x49d87b,_0x299d97,_0x21da90]=_0x412ced['split']('.');if(_0x49d87b===void 0x0||_0x299d97===void 0x0||_0x21da90===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x3f0c1c=fn(_0x299d97);return _0x3f0c1c?JSON['parse'](_0x3f0c1c):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5f22dd){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5f22dd==null?void 0x0:_0x5f22dd['toString']()),null;}}function Cr(_0xa332ad){const _0x386740=Ts(_0xa332ad);return m(_0x386740,'internal-error'),m(typeof _0x386740['exp']<'u','internal-error'),m(typeof _0x386740['iat']<'u','internal-error'),Number(_0x386740['exp'])-Number(_0x386740['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x5a258b,_0x56cd75,_0x4290f5=!0x1){if(_0x4290f5)return _0x56cd75;try{return await _0x56cd75;}catch(_0xad18a6){throw _0xad18a6 instanceof Re&&If(_0xad18a6)&&_0x5a258b['auth']['currentUser']===_0x5a258b&&await _0x5a258b['auth']['signOut'](),_0xad18a6;}}function If({code:_0x3a9278}){return _0x3a9278==='auth/user-disabled'||_0x3a9278==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x24ca3c){this['user']=_0x24ca3c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x49b7a3){if(_0x49b7a3){const _0x569d6f=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x569d6f;}else{this['errorBackoff']=0x7530;const _0x1af1fd=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1af1fd);}}['schedule'](_0x3de0be=!0x1){if(!this['isRunning'])return;const _0x49cd1f=this['getInterval'](_0x3de0be);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x49cd1f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x9177a2){(_0x9177a2==null?void 0x0:_0x9177a2['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x1c57b9,_0x39808d){this['createdAt']=_0x1c57b9,this['lastLoginAt']=_0x39808d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x18d0fe){this['createdAt']=_0x18d0fe['createdAt'],this['lastLoginAt']=_0x18d0fe['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x4a4cef){var _0x4ec1ac;const _0x2a742b=_0x4a4cef['auth'],_0x1ea5c8=await _0x4a4cef['getIdToken'](),_0x19abeb=await Ht(_0x4a4cef,Pn(_0x2a742b,{'idToken':_0x1ea5c8}));m(_0x19abeb==null?void 0x0:_0x19abeb['users']['length'],_0x2a742b,'internal-error');const _0x452690=_0x19abeb['users'][0x0];_0x4a4cef['_notifyReloadListener'](_0x452690);const _0x1fce08=(_0x4ec1ac=_0x452690['providerUserInfo'])!=null&&_0x4ec1ac['length']?Sa(_0x452690['providerUserInfo']):[],_0x5e2f0c=Tf(_0x4a4cef['providerData'],_0x1fce08),_0x3e7462=_0x4a4cef['isAnonymous'],_0x4d1119=!(_0x4a4cef['email']&&_0x452690['passwordHash'])&&!(_0x5e2f0c!=null&&_0x5e2f0c['length']),_0x22ac36=_0x3e7462?_0x4d1119:!0x1,_0x1fa082={'uid':_0x452690['localId'],'displayName':_0x452690['displayName']||null,'photoURL':_0x452690['photoUrl']||null,'email':_0x452690['email']||null,'emailVerified':_0x452690['emailVerified']||!0x1,'phoneNumber':_0x452690['phoneNumber']||null,'tenantId':_0x452690['tenantId']||null,'providerData':_0x5e2f0c,'metadata':new Li(_0x452690['createdAt'],_0x452690['lastLoginAt']),'isAnonymous':_0x22ac36};Object['assign'](_0x4a4cef,_0x1fa082);}async function Cf(_0x2d62ca){const _0x293a02=P(_0x2d62ca);await Nn(_0x293a02),await _0x293a02['auth']['_persistUserIfCurrent'](_0x293a02),_0x293a02['auth']['_notifyListenersIfCurrent'](_0x293a02);}function Tf(_0x138b47,_0x36a630){return[..._0x138b47['filter'](_0x26d5b4=>!_0x36a630['some'](_0xaf7307=>_0xaf7307['providerId']===_0x26d5b4['providerId'])),..._0x36a630];}function Sa(_0x290fa9){return _0x290fa9['map'](({providerId:_0x29d47e,..._0x80bf01})=>({'providerId':_0x29d47e,'uid':_0x80bf01['rawId']||'','displayName':_0x80bf01['displayName']||null,'email':_0x80bf01['email']||null,'phoneNumber':_0x80bf01['phoneNumber']||null,'photoURL':_0x80bf01['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4ba7c1,_0x1db7aa){const _0xe9f4b7=await Ca(_0x4ba7c1,{},async()=>{const _0x704155=ut({'grant_type':'refresh_token','refresh_token':_0x1db7aa})['slice'](0x1),{tokenApiHost:_0x4e8f6a,apiKey:_0x1b5e8e}=_0x4ba7c1['config'],_0x68389b=await Ta(_0x4ba7c1,_0x4e8f6a,'/v1/token','key='+_0x1b5e8e),_0x2d1589=await _0x4ba7c1['_getAdditionalHeaders']();_0x2d1589['Content-Type']='application/x-www-form-urlencoded';const _0x90c371={'method':'POST','headers':_0x2d1589,'body':_0x704155};return _0x4ba7c1['emulatorConfig']&&qt(_0x4ba7c1['emulatorConfig']['host'])&&(_0x90c371['credentials']='include'),wa['fetch']()(_0x68389b,_0x90c371);});return{'accessToken':_0xe9f4b7['access_token'],'expiresIn':_0xe9f4b7['expires_in'],'refreshToken':_0xe9f4b7['refresh_token']};}async function bf(_0x1b2677,_0x20b965){return Pe(_0x1b2677,'POST','/v2/accounts:revokeToken',ke(_0x1b2677,_0x20b965));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5243aa){m(_0x5243aa['idToken'],'internal-error'),m(typeof _0x5243aa['idToken']<'u','internal-error'),m(typeof _0x5243aa['refreshToken']<'u','internal-error');const _0xb624ee='expiresIn'in _0x5243aa&&typeof _0x5243aa['expiresIn']<'u'?Number(_0x5243aa['expiresIn']):Cr(_0x5243aa['idToken']);this['updateTokensAndExpiration'](_0x5243aa['idToken'],_0x5243aa['refreshToken'],_0xb624ee);}['updateFromIdToken'](_0x100d3d){m(_0x100d3d['length']!==0x0,'internal-error');const _0x2219bd=Cr(_0x100d3d);this['updateTokensAndExpiration'](_0x100d3d,null,_0x2219bd);}async['getToken'](_0x20b475,_0x5ee7b0=!0x1){return!_0x5ee7b0&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x20b475,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x20b475,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x280103,_0x58f8c8){const {accessToken:_0x196d8d,refreshToken:_0x58b4ba,expiresIn:_0x1177bb}=await Sf(_0x280103,_0x58f8c8);this['updateTokensAndExpiration'](_0x196d8d,_0x58b4ba,Number(_0x1177bb));}['updateTokensAndExpiration'](_0x3aaca6,_0x3aa3f4,_0x20a601){this['refreshToken']=_0x3aa3f4||null,this['accessToken']=_0x3aaca6||null,this['expirationTime']=Date['now']()+_0x20a601*0x3e8;}static['fromJSON'](_0x3d6a2e,_0xc4f15){const {refreshToken:_0x58ef22,accessToken:_0x4153a6,expirationTime:_0x8e3938}=_0xc4f15,_0x68edf7=new et();return _0x58ef22&&(m(typeof _0x58ef22=='string','internal-error',{'appName':_0x3d6a2e}),_0x68edf7['refreshToken']=_0x58ef22),_0x4153a6&&(m(typeof _0x4153a6=='string','internal-error',{'appName':_0x3d6a2e}),_0x68edf7['accessToken']=_0x4153a6),_0x8e3938&&(m(typeof _0x8e3938=='number','internal-error',{'appName':_0x3d6a2e}),_0x68edf7['expirationTime']=_0x8e3938),_0x68edf7;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5c36b3){this['accessToken']=_0x5c36b3['accessToken'],this['refreshToken']=_0x5c36b3['refreshToken'],this['expirationTime']=_0x5c36b3['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x5f28b9,_0x3f929d){m(typeof _0x5f28b9=='string'||typeof _0x5f28b9>'u','internal-error',{'appName':_0x3f929d});}class j{constructor({uid:_0x5e0f14,auth:_0x1f6c96,stsTokenManager:_0x291f38,..._0x46ebbc}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5e0f14,this['auth']=_0x1f6c96,this['stsTokenManager']=_0x291f38,this['accessToken']=_0x291f38['accessToken'],this['displayName']=_0x46ebbc['displayName']||null,this['email']=_0x46ebbc['email']||null,this['emailVerified']=_0x46ebbc['emailVerified']||!0x1,this['phoneNumber']=_0x46ebbc['phoneNumber']||null,this['photoURL']=_0x46ebbc['photoURL']||null,this['isAnonymous']=_0x46ebbc['isAnonymous']||!0x1,this['tenantId']=_0x46ebbc['tenantId']||null,this['providerData']=_0x46ebbc['providerData']?[..._0x46ebbc['providerData']]:[],this['metadata']=new Li(_0x46ebbc['createdAt']||void 0x0,_0x46ebbc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4fa225){const _0x5e6d8c=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x4fa225));return m(_0x5e6d8c,this['auth'],'internal-error'),this['accessToken']!==_0x5e6d8c&&(this['accessToken']=_0x5e6d8c,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5e6d8c;}['getIdTokenResult'](_0x435169){return Ef(this,_0x435169);}['reload'](){return Cf(this);}['_assign'](_0x3e4cc0){this!==_0x3e4cc0&&(m(this['uid']===_0x3e4cc0['uid'],this['auth'],'internal-error'),this['displayName']=_0x3e4cc0['displayName'],this['photoURL']=_0x3e4cc0['photoURL'],this['email']=_0x3e4cc0['email'],this['emailVerified']=_0x3e4cc0['emailVerified'],this['phoneNumber']=_0x3e4cc0['phoneNumber'],this['isAnonymous']=_0x3e4cc0['isAnonymous'],this['tenantId']=_0x3e4cc0['tenantId'],this['providerData']=_0x3e4cc0['providerData']['map'](_0x4bcff5=>({..._0x4bcff5})),this['metadata']['_copy'](_0x3e4cc0['metadata']),this['stsTokenManager']['_assign'](_0x3e4cc0['stsTokenManager']));}['_clone'](_0xe1cab1){const _0x101958=new j({...this,'auth':_0xe1cab1,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x101958['metadata']['_copy'](this['metadata']),_0x101958;}['_onReload'](_0x457ab1){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x457ab1,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4ef9df){this['reloadListener']?this['reloadListener'](_0x4ef9df):this['reloadUserInfo']=_0x4ef9df;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1e1e7c,_0x5bf9e5=!0x1){let _0x55d60=!0x1;_0x1e1e7c['idToken']&&_0x1e1e7c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1e1e7c),_0x55d60=!0x0),_0x5bf9e5&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x55d60&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4b2b85=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x4b2b85})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x35328a=>({..._0x35328a})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x578de5,_0x59d3a9){const _0x2ca0e0=_0x59d3a9['displayName']??void 0x0,_0x5974f3=_0x59d3a9['email']??void 0x0,_0x27b305=_0x59d3a9['phoneNumber']??void 0x0,_0x3dd77d=_0x59d3a9['photoURL']??void 0x0,_0x2ef11d=_0x59d3a9['tenantId']??void 0x0,_0x19d865=_0x59d3a9['_redirectEventId']??void 0x0,_0x14c893=_0x59d3a9['createdAt']??void 0x0,_0x409a0a=_0x59d3a9['lastLoginAt']??void 0x0,{uid:_0x4a2210,emailVerified:_0x1b20b6,isAnonymous:_0x2b7eca,providerData:_0x1497fd,stsTokenManager:_0x474f08}=_0x59d3a9;m(_0x4a2210&&_0x474f08,_0x578de5,'internal-error');const _0x446988=et['fromJSON'](this['name'],_0x474f08);m(typeof _0x4a2210=='string',_0x578de5,'internal-error'),le(_0x2ca0e0,_0x578de5['name']),le(_0x5974f3,_0x578de5['name']),m(typeof _0x1b20b6=='boolean',_0x578de5,'internal-error'),m(typeof _0x2b7eca=='boolean',_0x578de5,'internal-error'),le(_0x27b305,_0x578de5['name']),le(_0x3dd77d,_0x578de5['name']),le(_0x2ef11d,_0x578de5['name']),le(_0x19d865,_0x578de5['name']),le(_0x14c893,_0x578de5['name']),le(_0x409a0a,_0x578de5['name']);const _0x370877=new j({'uid':_0x4a2210,'auth':_0x578de5,'email':_0x5974f3,'emailVerified':_0x1b20b6,'displayName':_0x2ca0e0,'isAnonymous':_0x2b7eca,'photoURL':_0x3dd77d,'phoneNumber':_0x27b305,'tenantId':_0x2ef11d,'stsTokenManager':_0x446988,'createdAt':_0x14c893,'lastLoginAt':_0x409a0a});return _0x1497fd&&Array['isArray'](_0x1497fd)&&(_0x370877['providerData']=_0x1497fd['map'](_0x1c4b86=>({..._0x1c4b86}))),_0x19d865&&(_0x370877['_redirectEventId']=_0x19d865),_0x370877;}static async['_fromIdTokenResponse'](_0x1bcad7,_0x22d141,_0x2eaf09=!0x1){const _0x3d6618=new et();_0x3d6618['updateFromServerResponse'](_0x22d141);const _0x450bb4=new j({'uid':_0x22d141['localId'],'auth':_0x1bcad7,'stsTokenManager':_0x3d6618,'isAnonymous':_0x2eaf09});return await Nn(_0x450bb4),_0x450bb4;}static async['_fromGetAccountInfoResponse'](_0x170cb0,_0x4c34f4,_0x240ecd){const _0x13482b=_0x4c34f4['users'][0x0];m(_0x13482b['localId']!==void 0x0,'internal-error');const _0x2dcae7=_0x13482b['providerUserInfo']!==void 0x0?Sa(_0x13482b['providerUserInfo']):[],_0x379ac6=!(_0x13482b['email']&&_0x13482b['passwordHash'])&&!(_0x2dcae7!=null&&_0x2dcae7['length']),_0x189185=new et();_0x189185['updateFromIdToken'](_0x240ecd);const _0x186a31=new j({'uid':_0x13482b['localId'],'auth':_0x170cb0,'stsTokenManager':_0x189185,'isAnonymous':_0x379ac6}),_0xd4c0aa={'uid':_0x13482b['localId'],'displayName':_0x13482b['displayName']||null,'photoURL':_0x13482b['photoUrl']||null,'email':_0x13482b['email']||null,'emailVerified':_0x13482b['emailVerified']||!0x1,'phoneNumber':_0x13482b['phoneNumber']||null,'tenantId':_0x13482b['tenantId']||null,'providerData':_0x2dcae7,'metadata':new Li(_0x13482b['createdAt'],_0x13482b['lastLoginAt']),'isAnonymous':!(_0x13482b['email']&&_0x13482b['passwordHash'])&&!(_0x2dcae7!=null&&_0x2dcae7['length'])};return Object['assign'](_0x186a31,_0xd4c0aa),_0x186a31;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x23462f){ce(_0x23462f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x65dff2=Tr['get'](_0x23462f);return _0x65dff2?(ce(_0x65dff2 instanceof _0x23462f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x65dff2):(_0x65dff2=new _0x23462f(),Tr['set'](_0x23462f,_0x65dff2),_0x65dff2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2d443e,_0x48b7a3){this['storage'][_0x2d443e]=_0x48b7a3;}async['_get'](_0x549450){const _0xcb86f8=this['storage'][_0x549450];return _0xcb86f8===void 0x0?null:_0xcb86f8;}async['_remove'](_0x1ecbd3){delete this['storage'][_0x1ecbd3];}['_addListener'](_0x321f87,_0x28cb7e){}['_removeListener'](_0x57beb2,_0xdde67a){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x2b32b4,_0x59907f,_0x3be8d6){return'firebase:'+_0x2b32b4+':'+_0x59907f+':'+_0x3be8d6;}class tt{constructor(_0x4d8068,_0xe04797,_0xe36f51){this['persistence']=_0x4d8068,this['auth']=_0xe04797,this['userKey']=_0xe36f51;const {config:_0x2e1712,name:_0x3effcb}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2e1712['apiKey'],_0x3effcb),this['fullPersistenceKey']=ln('persistence',_0x2e1712['apiKey'],_0x3effcb),this['boundEventHandler']=_0xe04797['_onStorageEvent']['bind'](_0xe04797),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5028dc){return this['persistence']['_set'](this['fullUserKey'],_0x5028dc['toJSON']());}async['getCurrentUser'](){const _0x5816ca=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5816ca)return null;if(typeof _0x5816ca=='string'){const _0x1344c4=await Pn(this['auth'],{'idToken':_0x5816ca})['catch'](()=>{});return _0x1344c4?j['_fromGetAccountInfoResponse'](this['auth'],_0x1344c4,_0x5816ca):null;}return j['_fromJSON'](this['auth'],_0x5816ca);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x172d82){if(this['persistence']===_0x172d82)return;const _0x465004=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x172d82,_0x465004)return this['setCurrentUser'](_0x465004);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1ece57,_0x1a5002,_0x16a2de='authUser'){if(!_0x1a5002['length'])return new tt(ie(Sr),_0x1ece57,_0x16a2de);const _0x1b29df=(await Promise['all'](_0x1a5002['map'](async _0x31b309=>{if(await _0x31b309['_isAvailable']())return _0x31b309;})))['filter'](_0x575dc9=>_0x575dc9);let _0x2f2a29=_0x1b29df[0x0]||ie(Sr);const _0x4a7dcc=ln(_0x16a2de,_0x1ece57['config']['apiKey'],_0x1ece57['name']);let _0x16c5dd=null;for(const _0x4b2523 of _0x1a5002)try{const _0x5e151a=await _0x4b2523['_get'](_0x4a7dcc);if(_0x5e151a){let _0x36161a;if(typeof _0x5e151a=='string'){const _0x524237=await Pn(_0x1ece57,{'idToken':_0x5e151a})['catch'](()=>{});if(!_0x524237)break;_0x36161a=await j['_fromGetAccountInfoResponse'](_0x1ece57,_0x524237,_0x5e151a);}else _0x36161a=j['_fromJSON'](_0x1ece57,_0x5e151a);_0x4b2523!==_0x2f2a29&&(_0x16c5dd=_0x36161a),_0x2f2a29=_0x4b2523;break;}}catch{}const _0x355063=_0x1b29df['filter'](_0x5ca644=>_0x5ca644['_shouldAllowMigration']);return!_0x2f2a29['_shouldAllowMigration']||!_0x355063['length']?new tt(_0x2f2a29,_0x1ece57,_0x16a2de):(_0x2f2a29=_0x355063[0x0],_0x16c5dd&&await _0x2f2a29['_set'](_0x4a7dcc,_0x16c5dd['toJSON']()),await Promise['all'](_0x1a5002['map'](async _0x2aee1c=>{if(_0x2aee1c!==_0x2f2a29)try{await _0x2aee1c['_remove'](_0x4a7dcc);}catch{}})),new tt(_0x2f2a29,_0x1ece57,_0x16a2de));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xada63d){const _0x23a245=_0xada63d['toLowerCase']();if(_0x23a245['includes']('opera/')||_0x23a245['includes']('opr/')||_0x23a245['includes']('opios/'))return'Opera';if(Pa(_0x23a245))return'IEMobile';if(_0x23a245['includes']('msie')||_0x23a245['includes']('trident/'))return'IE';if(_0x23a245['includes']('edge/'))return'Edge';if(Ra(_0x23a245))return'Firefox';if(_0x23a245['includes']('silk/'))return'Silk';if(Oa(_0x23a245))return'Blackberry';if(Da(_0x23a245))return'Webos';if(Aa(_0x23a245))return'Safari';if((_0x23a245['includes']('chrome/')||ka(_0x23a245))&&!_0x23a245['includes']('edge/'))return'Chrome';if(Na(_0x23a245))return'Android';{const _0x19233f=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x29cee2=_0xada63d['match'](_0x19233f);if((_0x29cee2==null?void 0x0:_0x29cee2['length'])===0x2)return _0x29cee2[0x1];}return'Other';}function Ra(_0x5649e2=W()){return/firefox\//i['test'](_0x5649e2);}function Aa(_0x8dd0cc=W()){const _0x1e0da7=_0x8dd0cc['toLowerCase']();return _0x1e0da7['includes']('safari/')&&!_0x1e0da7['includes']('chrome/')&&!_0x1e0da7['includes']('crios/')&&!_0x1e0da7['includes']('android');}function ka(_0x3b6af3=W()){return/crios\//i['test'](_0x3b6af3);}function Pa(_0x530cfb=W()){return/iemobile/i['test'](_0x530cfb);}function Na(_0x5a5672=W()){return/android/i['test'](_0x5a5672);}function Oa(_0x2a866d=W()){return/blackberry/i['test'](_0x2a866d);}function Da(_0x4f7f6e=W()){return/webos/i['test'](_0x4f7f6e);}function Ss(_0x424e8b=W()){return/iphone|ipad|ipod/i['test'](_0x424e8b)||/macintosh/i['test'](_0x424e8b)&&/mobile/i['test'](_0x424e8b);}function Rf(_0x59d891=W()){var _0x587d06;return Ss(_0x59d891)&&!!((_0x587d06=window['navigator'])!=null&&_0x587d06['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x454a37=W()){return Ss(_0x454a37)||Na(_0x454a37)||Da(_0x454a37)||Oa(_0x454a37)||/windows phone/i['test'](_0x454a37)||Pa(_0x454a37);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2ea5cf,_0x277b7b=[]){let _0x39768f;switch(_0x2ea5cf){case'Browser':_0x39768f=br(W());break;case'Worker':_0x39768f=br(W())+'-'+_0x2ea5cf;break;default:_0x39768f=_0x2ea5cf;}const _0x51d5c2=_0x277b7b['length']?_0x277b7b['join'](','):'FirebaseCore-web';return _0x39768f+'/JsCore/'+dt+'/'+_0x51d5c2;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1903c1){this['auth']=_0x1903c1,this['queue']=[];}['pushCallback'](_0x43a617,_0x18cc99){const _0x13767e=_0x16cdc5=>new Promise((_0x242e64,_0x33e0a1)=>{try{const _0x4c3859=_0x43a617(_0x16cdc5);_0x242e64(_0x4c3859);}catch(_0x123a88){_0x33e0a1(_0x123a88);}});_0x13767e['onAbort']=_0x18cc99,this['queue']['push'](_0x13767e);const _0xe3ffd8=this['queue']['length']-0x1;return()=>{this['queue'][_0xe3ffd8]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4406bc){if(this['auth']['currentUser']===_0x4406bc)return;const _0x14b147=[];try{for(const _0x3af9e5 of this['queue'])await _0x3af9e5(_0x4406bc),_0x3af9e5['onAbort']&&_0x14b147['push'](_0x3af9e5['onAbort']);}catch(_0x2bf84d){_0x14b147['reverse']();for(const _0x234f02 of _0x14b147)try{_0x234f02();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2bf84d==null?void 0x0:_0x2bf84d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0xa7fb27,_0x1cfce3={}){return Pe(_0xa7fb27,'GET','/v2/passwordPolicy',ke(_0xa7fb27,_0x1cfce3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xd56a23){var _0x733721;const _0x4d9e6f=_0xd56a23['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x4d9e6f['minPasswordLength']??Nf,_0x4d9e6f['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x4d9e6f['maxPasswordLength']),_0x4d9e6f['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x4d9e6f['containsLowercaseCharacter']),_0x4d9e6f['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x4d9e6f['containsUppercaseCharacter']),_0x4d9e6f['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x4d9e6f['containsNumericCharacter']),_0x4d9e6f['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x4d9e6f['containsNonAlphanumericCharacter']),this['enforcementState']=_0xd56a23['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x733721=_0xd56a23['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x733721['join'](''))??'',this['forceUpgradeOnSignin']=_0xd56a23['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xd56a23['schemaVersion'];}['validatePassword'](_0x43e80a){const _0x4cd606={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x43e80a,_0x4cd606),this['validatePasswordCharacterOptions'](_0x43e80a,_0x4cd606),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['meetsMinPasswordLength']??!0x0),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['meetsMaxPasswordLength']??!0x0),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['containsLowercaseLetter']??!0x0),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['containsUppercaseLetter']??!0x0),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['containsNumericCharacter']??!0x0),_0x4cd606['isValid']&&(_0x4cd606['isValid']=_0x4cd606['containsNonAlphanumericCharacter']??!0x0),_0x4cd606;}['validatePasswordLengthOptions'](_0x3f29c7,_0x4a9219){const _0x266c19=this['customStrengthOptions']['minPasswordLength'],_0x51cb26=this['customStrengthOptions']['maxPasswordLength'];_0x266c19&&(_0x4a9219['meetsMinPasswordLength']=_0x3f29c7['length']>=_0x266c19),_0x51cb26&&(_0x4a9219['meetsMaxPasswordLength']=_0x3f29c7['length']<=_0x51cb26);}['validatePasswordCharacterOptions'](_0x13089e,_0x51a177){this['updatePasswordCharacterOptionsStatuses'](_0x51a177,!0x1,!0x1,!0x1,!0x1);let _0x25cb47;for(let _0x179040=0x0;_0x179040<_0x13089e['length'];_0x179040++)_0x25cb47=_0x13089e['charAt'](_0x179040),this['updatePasswordCharacterOptionsStatuses'](_0x51a177,_0x25cb47>='a'&&_0x25cb47<='z',_0x25cb47>='A'&&_0x25cb47<='Z',_0x25cb47>='0'&&_0x25cb47<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x25cb47));}['updatePasswordCharacterOptionsStatuses'](_0x40945d,_0x2cd676,_0x1cea7c,_0x4c6e98,_0x475f5f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x40945d['containsLowercaseLetter']||(_0x40945d['containsLowercaseLetter']=_0x2cd676)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x40945d['containsUppercaseLetter']||(_0x40945d['containsUppercaseLetter']=_0x1cea7c)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x40945d['containsNumericCharacter']||(_0x40945d['containsNumericCharacter']=_0x4c6e98)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x40945d['containsNonAlphanumericCharacter']||(_0x40945d['containsNonAlphanumericCharacter']=_0x475f5f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x19cf98,_0x2edb33,_0x44813a,_0x4b84bf){this['app']=_0x19cf98,this['heartbeatServiceProvider']=_0x2edb33,this['appCheckServiceProvider']=_0x44813a,this['config']=_0x4b84bf,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x19cf98['name'],this['clientVersion']=_0x4b84bf['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5725d1=>this['_resolvePersistenceManagerAvailable']=_0x5725d1);}['_initializeWithPersistence'](_0x4232d6,_0x37c83e){return _0x37c83e&&(this['_popupRedirectResolver']=ie(_0x37c83e)),this['_initializationPromise']=this['queue'](async()=>{var _0xf45104,_0x12e380,_0x5cccef;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4232d6),(_0xf45104=this['_resolvePersistenceManagerAvailable'])==null||_0xf45104['call'](this),!this['_deleted'])){if((_0x12e380=this['_popupRedirectResolver'])!=null&&_0x12e380['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x37c83e),this['lastNotifiedUid']=((_0x5cccef=this['currentUser'])==null?void 0x0:_0x5cccef['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x7582ae=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x7582ae)){if(this['currentUser']&&_0x7582ae&&this['currentUser']['uid']===_0x7582ae['uid']){this['_currentUser']['_assign'](_0x7582ae),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x7582ae,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x50c2d8){try{const _0x404ad6=await Pn(this,{'idToken':_0x50c2d8}),_0x2e1fd3=await j['_fromGetAccountInfoResponse'](this,_0x404ad6,_0x50c2d8);await this['directlySetCurrentUser'](_0x2e1fd3);}catch(_0x4178e6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4178e6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x25a218){var _0x5492dc;if($(this['app'])){const _0x45815a=this['app']['settings']['authIdToken'];return _0x45815a?new Promise(_0x342ea2=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x45815a)['then'](_0x342ea2,_0x342ea2));}):this['directlySetCurrentUser'](null);}const _0x31cdfc=await this['assertedPersistence']['getCurrentUser']();let _0x422e0b=_0x31cdfc,_0x53fd79=!0x1;if(_0x25a218&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x1a2593=(_0x5492dc=this['redirectUser'])==null?void 0x0:_0x5492dc['_redirectEventId'],_0x32a842=_0x422e0b==null?void 0x0:_0x422e0b['_redirectEventId'],_0x38a044=await this['tryRedirectSignIn'](_0x25a218);(!_0x1a2593||_0x1a2593===_0x32a842)&&(_0x38a044!=null&&_0x38a044['user'])&&(_0x422e0b=_0x38a044['user'],_0x53fd79=!0x0);}if(!_0x422e0b)return this['directlySetCurrentUser'](null);if(!_0x422e0b['_redirectEventId']){if(_0x53fd79)try{await this['beforeStateQueue']['runMiddleware'](_0x422e0b);}catch(_0x35aac1){_0x422e0b=_0x31cdfc,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x35aac1));}return _0x422e0b?this['reloadAndSetCurrentUserOrClear'](_0x422e0b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x422e0b['_redirectEventId']?this['directlySetCurrentUser'](_0x422e0b):this['reloadAndSetCurrentUserOrClear'](_0x422e0b);}async['tryRedirectSignIn'](_0x48bbb1){let _0x8d27ea=null;try{_0x8d27ea=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x48bbb1,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x8d27ea;}async['reloadAndSetCurrentUserOrClear'](_0x2b41fe){try{await Nn(_0x2b41fe);}catch(_0x11e77b){if((_0x11e77b==null?void 0x0:_0x11e77b['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2b41fe);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x4cf4fb){if($(this['app']))return Promise['reject'](re(this));const _0x53dc9c=_0x4cf4fb?P(_0x4cf4fb):null;return _0x53dc9c&&m(_0x53dc9c['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x53dc9c&&_0x53dc9c['_clone'](this));}async['_updateCurrentUser'](_0x2a6497,_0x31f40c=!0x1){if(!this['_deleted'])return _0x2a6497&&m(this['tenantId']===_0x2a6497['tenantId'],this,'tenant-id-mismatch'),_0x31f40c||await this['beforeStateQueue']['runMiddleware'](_0x2a6497),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2a6497),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3a2c10){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3a2c10));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1b7487){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4edac5=this['_getPasswordPolicyInternal']();return _0x4edac5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4edac5['validatePassword'](_0x1b7487);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3a34e6=await Pf(this),_0x151d7b=new Of(_0x3a34e6);this['tenantId']===null?this['_projectPasswordPolicy']=_0x151d7b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x151d7b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x519c68){this['_errorFactory']=new Gt('auth','Firebase',_0x519c68());}['onAuthStateChanged'](_0x5ba80f,_0x258a75,_0x517c62){return this['registerStateListener'](this['authStateSubscription'],_0x5ba80f,_0x258a75,_0x517c62);}['beforeAuthStateChanged'](_0x571916,_0x3770db){return this['beforeStateQueue']['pushCallback'](_0x571916,_0x3770db);}['onIdTokenChanged'](_0x2b1890,_0x54e15a,_0x54d91f){return this['registerStateListener'](this['idTokenSubscription'],_0x2b1890,_0x54e15a,_0x54d91f);}['authStateReady'](){return new Promise((_0x5622cc,_0x17f829)=>{if(this['currentUser'])_0x5622cc();else{const _0x287946=this['onAuthStateChanged'](()=>{_0x287946(),_0x5622cc();},_0x17f829);}});}async['revokeAccessToken'](_0x1296e6){if(this['currentUser']){const _0x4b3bec=await this['currentUser']['getIdToken'](),_0xb81517={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1296e6,'idToken':_0x4b3bec};this['tenantId']!=null&&(_0xb81517['tenantId']=this['tenantId']),await bf(this,_0xb81517);}}['toJSON'](){var _0x24d266;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x24d266=this['_currentUser'])==null?void 0x0:_0x24d266['toJSON']()};}async['_setRedirectUser'](_0x579d0b,_0x177498){const _0x221180=await this['getOrInitRedirectPersistenceManager'](_0x177498);return _0x579d0b===null?_0x221180['removeCurrentUser']():_0x221180['setCurrentUser'](_0x579d0b);}async['getOrInitRedirectPersistenceManager'](_0x1716a3){if(!this['redirectPersistenceManager']){const _0x5992ab=_0x1716a3&&ie(_0x1716a3)||this['_popupRedirectResolver'];m(_0x5992ab,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x5992ab['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xb38c66){var _0x22480b,_0x38f22e;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x22480b=this['_currentUser'])==null?void 0x0:_0x22480b['_redirectEventId'])===_0xb38c66?this['_currentUser']:((_0x38f22e=this['redirectUser'])==null?void 0x0:_0x38f22e['_redirectEventId'])===_0xb38c66?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x35a57f){if(_0x35a57f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x35a57f));}['_notifyListenersIfCurrent'](_0x47c993){_0x47c993===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x21bbee;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2615e4=((_0x21bbee=this['currentUser'])==null?void 0x0:_0x21bbee['uid'])??null;this['lastNotifiedUid']!==_0x2615e4&&(this['lastNotifiedUid']=_0x2615e4,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x185638,_0x58a75e,_0x3dd107,_0x2256f9){if(this['_deleted'])return()=>{};const _0x53ac9a=typeof _0x58a75e=='function'?_0x58a75e:_0x58a75e['next']['bind'](_0x58a75e);let _0x113d71=!0x1;const _0x9dbf2a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x9dbf2a,this,'internal-error'),_0x9dbf2a['then'](()=>{_0x113d71||_0x53ac9a(this['currentUser']);}),typeof _0x58a75e=='function'){const _0x49a1d1=_0x185638['addObserver'](_0x58a75e,_0x3dd107,_0x2256f9);return()=>{_0x113d71=!0x0,_0x49a1d1();};}else{const _0x5216d2=_0x185638['addObserver'](_0x58a75e);return()=>{_0x113d71=!0x0,_0x5216d2();};}}async['directlySetCurrentUser'](_0x8e148){this['currentUser']&&this['currentUser']!==_0x8e148&&this['_currentUser']['_stopProactiveRefresh'](),_0x8e148&&this['isProactiveRefreshEnabled']&&_0x8e148['_startProactiveRefresh'](),this['currentUser']=_0x8e148,_0x8e148?await this['assertedPersistence']['setCurrentUser'](_0x8e148):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4541fd){return this['operations']=this['operations']['then'](_0x4541fd,_0x4541fd),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x80df05){!_0x80df05||this['frameworks']['includes'](_0x80df05)||(this['frameworks']['push'](_0x80df05),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4b849e;const _0x264e12={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x264e12['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x4fc360=await((_0x4b849e=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4b849e['getHeartbeatsHeader']());_0x4fc360&&(_0x264e12['X-Firebase-Client']=_0x4fc360);const _0x3eb150=await this['_getAppCheckToken']();return _0x3eb150&&(_0x264e12['X-Firebase-AppCheck']=_0x3eb150),_0x264e12;}async['_getAppCheckToken'](){var _0x125731;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x20c0e6=await((_0x125731=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x125731['getToken']());return _0x20c0e6!=null&&_0x20c0e6['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x20c0e6['error']),_0x20c0e6==null?void 0x0:_0x20c0e6['token'];}}function Ke(_0x1601db){return P(_0x1601db);}class Rr{constructor(_0x4737f3){this['auth']=_0x4737f3,this['observer']=null,this['addObserver']=Tc(_0x45b58c=>this['observer']=_0x45b58c);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5c2f06){Jn=_0x5c2f06;}function xa(_0x4f0eee){return Jn['loadJS'](_0x4f0eee);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x3cd60a){return'__'+_0x3cd60a+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x25353b){_0x25353b();}['execute'](_0x14e430,_0x4ceef9){return Promise['resolve']('token');}['render'](_0x17ea79,_0x1d646b){return'';}}class Wf{['ready'](_0x34e648){_0x34e648();}['execute'](_0x180cf9,_0x276fd3){return Promise['resolve']('token');}['render'](_0x137d74,_0x36353a){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x164c90){this['type']=Bf,this['auth']=Ke(_0x164c90);}async['verify'](_0xb4d926='verify',_0xcf19ac=!0x1){async function _0x49854b(_0x38d1c5){if(!_0xcf19ac){if(_0x38d1c5['tenantId']==null&&_0x38d1c5['_agentRecaptchaConfig']!=null)return _0x38d1c5['_agentRecaptchaConfig']['siteKey'];if(_0x38d1c5['tenantId']!=null&&_0x38d1c5['_tenantRecaptchaConfigs'][_0x38d1c5['tenantId']]!==void 0x0)return _0x38d1c5['_tenantRecaptchaConfigs'][_0x38d1c5['tenantId']]['siteKey'];}return new Promise(async(_0x508aba,_0x445a07)=>{yf(_0x38d1c5,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x5ad096=>{if(_0x5ad096['recaptchaKey']===void 0x0)_0x445a07(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4d6591=new mf(_0x5ad096);return _0x38d1c5['tenantId']==null?_0x38d1c5['_agentRecaptchaConfig']=_0x4d6591:_0x38d1c5['_tenantRecaptchaConfigs'][_0x38d1c5['tenantId']]=_0x4d6591,_0x508aba(_0x4d6591['siteKey']);}})['catch'](_0x5e8bf0=>{_0x445a07(_0x5e8bf0);});});}function _0x32e4f0(_0xc35cd2,_0xabca05,_0x19ffba){const _0x401e90=window['grecaptcha'];wr(_0x401e90)?_0x401e90['enterprise']['ready'](()=>{_0x401e90['enterprise']['execute'](_0xc35cd2,{'action':_0xb4d926})['then'](_0x511f54=>{_0xabca05(_0x511f54);})['catch'](()=>{_0xabca05(Fa);});}):_0x19ffba(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x31441c,_0x30ceac)=>{_0x49854b(this['auth'])['then'](async _0x1616bf=>{if(!_0xcf19ac&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x32e4f0(_0x1616bf,_0x31441c,_0x30ceac);else{if(typeof window>'u'){_0x30ceac(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x76e791=Lf();_0x76e791['length']!==0x0&&(_0x76e791+=_0x1616bf+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0xa5845a;(_0xa5845a=he['scriptInjectionDeferred'])==null||_0xa5845a['resolve']();},xa(_0x76e791)['then'](()=>{var _0x5da0bb;return(_0x5da0bb=he['scriptInjectionDeferred'])==null?void 0x0:_0x5da0bb['promise'];})['then'](()=>{_0x32e4f0(_0x1616bf,_0x31441c,_0x30ceac);})['catch'](_0x3b751d=>{_0x30ceac(_0x3b751d);});}})['catch'](_0x765a0b=>{_0x30ceac(_0x765a0b);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x39b45a,_0x29dd38,_0x43815f,_0x4432ad=!0x1,_0x4a6273=!0x1){const _0xdd43d5=new he(_0x39b45a);let _0xcd8486;if(_0x4a6273)_0xcd8486=Fa;else try{_0xcd8486=await _0xdd43d5['verify'](_0x43815f);}catch{_0xcd8486=await _0xdd43d5['verify'](_0x43815f,!0x0);}const _0x312528={..._0x29dd38};if(_0x43815f==='mfaSmsEnrollment'||_0x43815f==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x312528){const _0x17702c=_0x312528['phoneEnrollmentInfo']['phoneNumber'],_0x191fd7=_0x312528['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x312528,{'phoneEnrollmentInfo':{'phoneNumber':_0x17702c,'recaptchaToken':_0x191fd7,'captchaResponse':_0xcd8486,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x312528){const _0x234741=_0x312528['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x312528,{'phoneSignInInfo':{'recaptchaToken':_0x234741,'captchaResponse':_0xcd8486,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x312528;}return _0x4432ad?Object['assign'](_0x312528,{'captchaResp':_0xcd8486}):Object['assign'](_0x312528,{'captchaResponse':_0xcd8486}),Object['assign'](_0x312528,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x312528,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x312528;}async function xi(_0x5f5c11,_0x45bf32,_0x3d3050,_0x1588eb,_0x173d8d){var _0x1958f8;if((_0x1958f8=_0x5f5c11['_getRecaptchaConfig']())!=null&&_0x1958f8['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3c1b95=await kr(_0x5f5c11,_0x45bf32,_0x3d3050,_0x3d3050==='getOobCode');return _0x1588eb(_0x5f5c11,_0x3c1b95);}else return _0x1588eb(_0x5f5c11,_0x45bf32)['catch'](async _0x590118=>{if(_0x590118['code']==='auth/missing-recaptcha-token'){console['log'](_0x3d3050+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x566f01=await kr(_0x5f5c11,_0x45bf32,_0x3d3050,_0x3d3050==='getOobCode');return _0x1588eb(_0x5f5c11,_0x566f01);}else return Promise['reject'](_0x590118);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x40be0a,_0x561888){const _0x52a82e=Hi(_0x40be0a,'auth');if(_0x52a82e['isInitialized']()){const _0x1239de=_0x52a82e['getImmediate'](),_0x41a344=_0x52a82e['getOptions']();if(xe(_0x41a344,_0x561888??{}))return _0x1239de;Y(_0x1239de,'already-initialized');}return _0x52a82e['initialize']({'options':_0x561888});}function Hf(_0x26cc23,_0x5b66a2){const _0x186595=(_0x5b66a2==null?void 0x0:_0x5b66a2['persistence'])||[],_0x2a68f5=(Array['isArray'](_0x186595)?_0x186595:[_0x186595])['map'](ie);_0x5b66a2!=null&&_0x5b66a2['errorMap']&&_0x26cc23['_updateErrorMap'](_0x5b66a2['errorMap']),_0x26cc23['_initializeWithPersistence'](_0x2a68f5,_0x5b66a2==null?void 0x0:_0x5b66a2['popupRedirectResolver']);}function $f(_0x130ae4,_0x46e7b9,_0x6769ce){const _0x5c1519=Ke(_0x130ae4);m(/^https?:\/\//['test'](_0x46e7b9),_0x5c1519,'invalid-emulator-scheme');const _0x36d435=!0x1,_0x57f49c=Ua(_0x46e7b9),{host:_0x4b41dc,port:_0x43415e}=Gf(_0x46e7b9),_0x2126d4=_0x43415e===null?'':':'+_0x43415e,_0x5ca1ca={'url':_0x57f49c+'//'+_0x4b41dc+_0x2126d4+'/'},_0x537a87=Object['freeze']({'host':_0x4b41dc,'port':_0x43415e,'protocol':_0x57f49c['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x36d435})});if(!_0x5c1519['_canInitEmulator']){m(_0x5c1519['config']['emulator']&&_0x5c1519['emulatorConfig'],_0x5c1519,'emulator-config-failed'),m(xe(_0x5ca1ca,_0x5c1519['config']['emulator'])&&xe(_0x537a87,_0x5c1519['emulatorConfig']),_0x5c1519,'emulator-config-failed');return;}_0x5c1519['config']['emulator']=_0x5ca1ca,_0x5c1519['emulatorConfig']=_0x537a87,_0x5c1519['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x4b41dc)?Qr(_0x57f49c+'//'+_0x4b41dc+_0x2126d4):qf();}function Ua(_0x33999a){const _0x285a02=_0x33999a['indexOf'](':');return _0x285a02<0x0?'':_0x33999a['substr'](0x0,_0x285a02+0x1);}function Gf(_0x45000e){const _0x1e460e=Ua(_0x45000e),_0x213e79=/(\/\/)?([^?#/]+)/['exec'](_0x45000e['substr'](_0x1e460e['length']));if(!_0x213e79)return{'host':'','port':null};const _0x1150bb=_0x213e79[0x2]['split']('@')['pop']()||'',_0x514f95=/^(\[[^\]]+\])(:|$)/['exec'](_0x1150bb);if(_0x514f95){const _0x5591e9=_0x514f95[0x1];return{'host':_0x5591e9,'port':Pr(_0x1150bb['substr'](_0x5591e9['length']+0x1))};}else{const [_0x2d3fc5,_0x3dcfb7]=_0x1150bb['split'](':');return{'host':_0x2d3fc5,'port':Pr(_0x3dcfb7)};}}function Pr(_0x1b3373){if(!_0x1b3373)return null;const _0x51aba5=Number(_0x1b3373);return isNaN(_0x51aba5)?null:_0x51aba5;}function qf(){function _0x38814b(){const _0x2411e9=document['createElement']('p'),_0x5b484e=_0x2411e9['style'];_0x2411e9['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5b484e['position']='fixed',_0x5b484e['width']='100%',_0x5b484e['backgroundColor']='#ffffff',_0x5b484e['border']='.1em\x20solid\x20#000000',_0x5b484e['color']='#b50000',_0x5b484e['bottom']='0px',_0x5b484e['left']='0px',_0x5b484e['margin']='0px',_0x5b484e['zIndex']='10000',_0x5b484e['textAlign']='center',_0x2411e9['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2411e9);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x38814b):_0x38814b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3e2849,_0x20dbce){this['providerId']=_0x3e2849,this['signInMethod']=_0x20dbce;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0xbed079){return ne('not\x20implemented');}['_linkToIdToken'](_0x2d55ca,_0x1d44d6){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x43e48a){return ne('not\x20implemented');}}async function zf(_0x1fff5a,_0x451f66){return Pe(_0x1fff5a,'POST','/v1/accounts:signUp',_0x451f66);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x11d397,_0xb72df1){return en(_0x11d397,'POST','/v1/accounts:signInWithPassword',ke(_0x11d397,_0xb72df1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x108d6a,_0x12a37e){return en(_0x108d6a,'POST','/v1/accounts:signInWithEmailLink',ke(_0x108d6a,_0x12a37e));}async function Yf(_0x22d958,_0x30e13d){return en(_0x22d958,'POST','/v1/accounts:signInWithEmailLink',ke(_0x22d958,_0x30e13d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x35f072,_0x2e5c7a,_0x2ae7d0,_0x3c5511=null){super('password',_0x2ae7d0),this['_email']=_0x35f072,this['_password']=_0x2e5c7a,this['_tenantId']=_0x3c5511;}static['_fromEmailAndPassword'](_0x1daece,_0x4763f7){return new $t(_0x1daece,_0x4763f7,'password');}static['_fromEmailAndCode'](_0x47a1fd,_0x3fad27,_0x4d94a5=null){return new $t(_0x47a1fd,_0x3fad27,'emailLink',_0x4d94a5);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x92c7c7){const _0x20a4ba=typeof _0x92c7c7=='string'?JSON['parse'](_0x92c7c7):_0x92c7c7;if(_0x20a4ba!=null&&_0x20a4ba['email']&&(_0x20a4ba!=null&&_0x20a4ba['password'])){if(_0x20a4ba['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x20a4ba['email'],_0x20a4ba['password']);if(_0x20a4ba['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x20a4ba['email'],_0x20a4ba['password'],_0x20a4ba['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4f0c9a){switch(this['signInMethod']){case'password':const _0x34faa0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x4f0c9a,_0x34faa0,'signInWithPassword',jf);case'emailLink':return Kf(_0x4f0c9a,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x4f0c9a,'internal-error');}}async['_linkToIdToken'](_0x5ebe36,_0x1010d7){switch(this['signInMethod']){case'password':const _0x17f5a9={'idToken':_0x1010d7,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x5ebe36,_0x17f5a9,'signUpPassword',zf);case'emailLink':return Yf(_0x5ebe36,{'idToken':_0x1010d7,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x5ebe36,'internal-error');}}['_getReauthenticationResolver'](_0x5b261a){return this['_getIdTokenResponse'](_0x5b261a);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x24652b,_0x53fbdd){return en(_0x24652b,'POST','/v1/accounts:signInWithIdp',ke(_0x24652b,_0x53fbdd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1df864){const _0x3e0eb8=new $e(_0x1df864['providerId'],_0x1df864['signInMethod']);return _0x1df864['idToken']||_0x1df864['accessToken']?(_0x1df864['idToken']&&(_0x3e0eb8['idToken']=_0x1df864['idToken']),_0x1df864['accessToken']&&(_0x3e0eb8['accessToken']=_0x1df864['accessToken']),_0x1df864['nonce']&&!_0x1df864['pendingToken']&&(_0x3e0eb8['nonce']=_0x1df864['nonce']),_0x1df864['pendingToken']&&(_0x3e0eb8['pendingToken']=_0x1df864['pendingToken'])):_0x1df864['oauthToken']&&_0x1df864['oauthTokenSecret']?(_0x3e0eb8['accessToken']=_0x1df864['oauthToken'],_0x3e0eb8['secret']=_0x1df864['oauthTokenSecret']):Y('argument-error'),_0x3e0eb8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3ec0e3){const _0x2a628a=typeof _0x3ec0e3=='string'?JSON['parse'](_0x3ec0e3):_0x3ec0e3,{providerId:_0x33e200,signInMethod:_0x4c507f,..._0x1eb52a}=_0x2a628a;if(!_0x33e200||!_0x4c507f)return null;const _0x1fdbed=new $e(_0x33e200,_0x4c507f);return _0x1fdbed['idToken']=_0x1eb52a['idToken']||void 0x0,_0x1fdbed['accessToken']=_0x1eb52a['accessToken']||void 0x0,_0x1fdbed['secret']=_0x1eb52a['secret'],_0x1fdbed['nonce']=_0x1eb52a['nonce'],_0x1fdbed['pendingToken']=_0x1eb52a['pendingToken']||null,_0x1fdbed;}['_getIdTokenResponse'](_0x311e28){const _0x31d472=this['buildRequest']();return nt(_0x311e28,_0x31d472);}['_linkToIdToken'](_0x3eec9d,_0x3a0e01){const _0x20b735=this['buildRequest']();return _0x20b735['idToken']=_0x3a0e01,nt(_0x3eec9d,_0x20b735);}['_getReauthenticationResolver'](_0x513612){const _0x42b6f7=this['buildRequest']();return _0x42b6f7['autoCreate']=!0x1,nt(_0x513612,_0x42b6f7);}['buildRequest'](){const _0x579898={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x579898['pendingToken']=this['pendingToken'];else{const _0x968175={};this['idToken']&&(_0x968175['id_token']=this['idToken']),this['accessToken']&&(_0x968175['access_token']=this['accessToken']),this['secret']&&(_0x968175['oauth_token_secret']=this['secret']),_0x968175['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x968175['nonce']=this['nonce']),_0x579898['postBody']=ut(_0x968175);}return _0x579898;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1b1811){switch(_0x1b1811){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x1743bb){const _0x4893aa=Ct(Tt(_0x1743bb))['link'],_0x54e7d7=_0x4893aa?Ct(Tt(_0x4893aa))['deep_link_id']:null,_0xb11270=Ct(Tt(_0x1743bb))['deep_link_id'];return(_0xb11270?Ct(Tt(_0xb11270))['link']:null)||_0xb11270||_0x54e7d7||_0x4893aa||_0x1743bb;}class Rs{constructor(_0x570e07){const _0x2fec5d=Ct(Tt(_0x570e07)),_0x20cbeb=_0x2fec5d['apiKey']??null,_0x5e5bd9=_0x2fec5d['oobCode']??null,_0x4f2926=Jf(_0x2fec5d['mode']??null);m(_0x20cbeb&&_0x5e5bd9&&_0x4f2926,'argument-error'),this['apiKey']=_0x20cbeb,this['operation']=_0x4f2926,this['code']=_0x5e5bd9,this['continueUrl']=_0x2fec5d['continueUrl']??null,this['languageCode']=_0x2fec5d['lang']??null,this['tenantId']=_0x2fec5d['tenantId']??null;}static['parseLink'](_0x209a2e){const _0x31aa93=Xf(_0x209a2e);try{return new Rs(_0x31aa93);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x31f0d7,_0x1ae170){return $t['_fromEmailAndPassword'](_0x31f0d7,_0x1ae170);}static['credentialWithLink'](_0x2194c8,_0x43c17d){const _0x3ed9c7=Rs['parseLink'](_0x43c17d);return m(_0x3ed9c7,'argument-error'),$t['_fromEmailAndCode'](_0x2194c8,_0x3ed9c7['code'],_0x3ed9c7['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x136d36){this['providerId']=_0x136d36,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x20502e){this['defaultLanguageCode']=_0x20502e;}['setCustomParameters'](_0x7b3a7a){return this['customParameters']=_0x7b3a7a,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5175f3){return this['scopes']['includes'](_0x5175f3)||this['scopes']['push'](_0x5175f3),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2695ee){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2695ee});}static['credentialFromResult'](_0x4b39cf){return ue['credentialFromTaggedObject'](_0x4b39cf);}static['credentialFromError'](_0x79e3f8){return ue['credentialFromTaggedObject'](_0x79e3f8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2a698f}){if(!_0x2a698f||!('oauthAccessToken'in _0x2a698f)||!_0x2a698f['oauthAccessToken'])return null;try{return ue['credential'](_0x2a698f['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x8adff9,_0x437231){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x8adff9,'accessToken':_0x437231});}static['credentialFromResult'](_0x11ed36){return de['credentialFromTaggedObject'](_0x11ed36);}static['credentialFromError'](_0x2a4954){return de['credentialFromTaggedObject'](_0x2a4954['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x575acd}){if(!_0x575acd)return null;const {oauthIdToken:_0x43e7d2,oauthAccessToken:_0x19a3ad}=_0x575acd;if(!_0x43e7d2&&!_0x19a3ad)return null;try{return de['credential'](_0x43e7d2,_0x19a3ad);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x468704){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x468704});}static['credentialFromResult'](_0x5c2220){return fe['credentialFromTaggedObject'](_0x5c2220);}static['credentialFromError'](_0x3c3cc8){return fe['credentialFromTaggedObject'](_0x3c3cc8['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3fa962}){if(!_0x3fa962||!('oauthAccessToken'in _0x3fa962)||!_0x3fa962['oauthAccessToken'])return null;try{return fe['credential'](_0x3fa962['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x36ab3d,_0x2d1736){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x36ab3d,'oauthTokenSecret':_0x2d1736});}static['credentialFromResult'](_0x1e999c){return pe['credentialFromTaggedObject'](_0x1e999c);}static['credentialFromError'](_0x23d472){return pe['credentialFromTaggedObject'](_0x23d472['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30af0f}){if(!_0x30af0f)return null;const {oauthAccessToken:_0x439614,oauthTokenSecret:_0x3ea5af}=_0x30af0f;if(!_0x439614||!_0x3ea5af)return null;try{return pe['credential'](_0x439614,_0x3ea5af);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x599248,_0x2ed261){return en(_0x599248,'POST','/v1/accounts:signUp',ke(_0x599248,_0x2ed261));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x991549){this['user']=_0x991549['user'],this['providerId']=_0x991549['providerId'],this['_tokenResponse']=_0x991549['_tokenResponse'],this['operationType']=_0x991549['operationType'];}static async['_fromIdTokenResponse'](_0x5c4c31,_0x4214af,_0x139bd8,_0x2b14ad=!0x1){const _0x6ee522=await j['_fromIdTokenResponse'](_0x5c4c31,_0x139bd8,_0x2b14ad),_0x2456b4=Nr(_0x139bd8);return new Ge({'user':_0x6ee522,'providerId':_0x2456b4,'_tokenResponse':_0x139bd8,'operationType':_0x4214af});}static async['_forOperation'](_0x431dbf,_0x376256,_0x104464){await _0x431dbf['_updateTokensIfNecessary'](_0x104464,!0x0);const _0x4e6c9d=Nr(_0x104464);return new Ge({'user':_0x431dbf,'providerId':_0x4e6c9d,'_tokenResponse':_0x104464,'operationType':_0x376256});}}function Nr(_0x75d9ef){return _0x75d9ef['providerId']?_0x75d9ef['providerId']:'phoneNumber'in _0x75d9ef?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x23b3f1,_0x4b8f35,_0x197bf9,_0x4714a4){super(_0x4b8f35['code'],_0x4b8f35['message']),this['operationType']=_0x197bf9,this['user']=_0x4714a4,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x23b3f1['name'],'tenantId':_0x23b3f1['tenantId']??void 0x0,'_serverResponse':_0x4b8f35['customData']['_serverResponse'],'operationType':_0x197bf9};}static['_fromErrorAndOperation'](_0x5486da,_0x23332e,_0x3662f0,_0x294d07){return new On(_0x5486da,_0x23332e,_0x3662f0,_0x294d07);}}function Ba(_0x41682b,_0x304c2f,_0x1afa17,_0xdb94f1){return(_0x304c2f==='reauthenticate'?_0x1afa17['_getReauthenticationResolver'](_0x41682b):_0x1afa17['_getIdTokenResponse'](_0x41682b))['catch'](_0x1ce0f0=>{throw _0x1ce0f0['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x41682b,_0x1ce0f0,_0x304c2f,_0xdb94f1):_0x1ce0f0;});}async function ep(_0x485663,_0x8156df,_0x4da145=!0x1){const _0x4a9329=await Ht(_0x485663,_0x8156df['_linkToIdToken'](_0x485663['auth'],await _0x485663['getIdToken']()),_0x4da145);return Ge['_forOperation'](_0x485663,'link',_0x4a9329);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x553230,_0x414b2e,_0x25030a=!0x1){const {auth:_0x59aef7}=_0x553230;if($(_0x59aef7['app']))return Promise['reject'](re(_0x59aef7));const _0x767d3f='reauthenticate';try{const _0x2b967c=await Ht(_0x553230,Ba(_0x59aef7,_0x767d3f,_0x414b2e,_0x553230),_0x25030a);m(_0x2b967c['idToken'],_0x59aef7,'internal-error');const _0x3f1e67=Ts(_0x2b967c['idToken']);m(_0x3f1e67,_0x59aef7,'internal-error');const {sub:_0x1a2bb5}=_0x3f1e67;return m(_0x553230['uid']===_0x1a2bb5,_0x59aef7,'user-mismatch'),Ge['_forOperation'](_0x553230,_0x767d3f,_0x2b967c);}catch(_0x47f70f){throw(_0x47f70f==null?void 0x0:_0x47f70f['code'])==='auth/user-not-found'&&Y(_0x59aef7,'user-mismatch'),_0x47f70f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x3f9095,_0xfa69b6,_0x4a9c8e=!0x1){if($(_0x3f9095['app']))return Promise['reject'](re(_0x3f9095));const _0xb65780='signIn',_0x30c7bd=await Ba(_0x3f9095,_0xb65780,_0xfa69b6),_0x357885=await Ge['_fromIdTokenResponse'](_0x3f9095,_0xb65780,_0x30c7bd);return _0x4a9c8e||await _0x3f9095['_updateCurrentUser'](_0x357885['user']),_0x357885;}async function np(_0x370ffe,_0x5901ca){return Va(Ke(_0x370ffe),_0x5901ca);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5f48ba){const _0x1a1f7f=Ke(_0x5f48ba);_0x1a1f7f['_getPasswordPolicyInternal']()&&await _0x1a1f7f['_updatePasswordPolicy']();}async function L_(_0x2c2186,_0x18202f,_0x27a0f5){if($(_0x2c2186['app']))return Promise['reject'](re(_0x2c2186));const _0x3e63f2=Ke(_0x2c2186),_0x536e13=await xi(_0x3e63f2,{'returnSecureToken':!0x0,'email':_0x18202f,'password':_0x27a0f5,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x4a53e3=>{throw _0x4a53e3['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x2c2186),_0x4a53e3;}),_0x2689c8=await Ge['_fromIdTokenResponse'](_0x3e63f2,'signIn',_0x536e13);return await _0x3e63f2['_updateCurrentUser'](_0x2689c8['user']),_0x2689c8;}function x_(_0x298823,_0x972193,_0x46fab2){return $(_0x298823['app'])?Promise['reject'](re(_0x298823)):np(P(_0x298823),yt['credential'](_0x972193,_0x46fab2))['catch'](async _0x13f9d8=>{throw _0x13f9d8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x298823),_0x13f9d8;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2a2f6e,_0x9dd679){return P(_0x2a2f6e)['setPersistence'](_0x9dd679);}function ip(_0xada580,_0xc37c69,_0x1c7bf1,_0x19c5e8){return P(_0xada580)['onIdTokenChanged'](_0xc37c69,_0x1c7bf1,_0x19c5e8);}function sp(_0x41476b,_0x5c6ed3,_0x4ae77b){return P(_0x41476b)['beforeAuthStateChanged'](_0x5c6ed3,_0x4ae77b);}function U_(_0x3f544b,_0x2ad3cf,_0x58048b,_0x2422ed){return P(_0x3f544b)['onAuthStateChanged'](_0x2ad3cf,_0x58048b,_0x2422ed);}function W_(_0x5306b9){return P(_0x5306b9)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2809a0,_0x4b0b32){this['storageRetriever']=_0x2809a0,this['type']=_0x4b0b32;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x16aaec,_0x2bff90){return this['storage']['setItem'](_0x16aaec,JSON['stringify'](_0x2bff90)),Promise['resolve']();}['_get'](_0x346c77){const _0x378d18=this['storage']['getItem'](_0x346c77);return Promise['resolve'](_0x378d18?JSON['parse'](_0x378d18):null);}['_remove'](_0x49044e){return this['storage']['removeItem'](_0x49044e),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x43b7ba,_0x53870d)=>this['onStorageEvent'](_0x43b7ba,_0x53870d),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x24e6f8){for(const _0x34f82b of Object['keys'](this['listeners'])){const _0xab1c69=this['storage']['getItem'](_0x34f82b),_0x444ba6=this['localCache'][_0x34f82b];_0xab1c69!==_0x444ba6&&_0x24e6f8(_0x34f82b,_0x444ba6,_0xab1c69);}}['onStorageEvent'](_0x3e432d,_0x31b000=!0x1){if(!_0x3e432d['key']){this['forAllChangedKeys']((_0x4e3888,_0x568aae,_0x5270e2)=>{this['notifyListeners'](_0x4e3888,_0x5270e2);});return;}const _0x5a863d=_0x3e432d['key'];_0x31b000?this['detachListener']():this['stopPolling']();const _0x326a47=()=>{const _0x580857=this['storage']['getItem'](_0x5a863d);!_0x31b000&&this['localCache'][_0x5a863d]===_0x580857||this['notifyListeners'](_0x5a863d,_0x580857);},_0xe5fcb5=this['storage']['getItem'](_0x5a863d);Af()&&_0xe5fcb5!==_0x3e432d['newValue']&&_0x3e432d['newValue']!==_0x3e432d['oldValue']?setTimeout(_0x326a47,op):_0x326a47();}['notifyListeners'](_0x3c507d,_0x1a04b2){this['localCache'][_0x3c507d]=_0x1a04b2;const _0x1c3bbc=this['listeners'][_0x3c507d];if(_0x1c3bbc){for(const _0x4deaa0 of Array['from'](_0x1c3bbc))_0x4deaa0(_0x1a04b2&&JSON['parse'](_0x1a04b2));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1b91c1,_0x2e7d34,_0x44630d)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1b91c1,'oldValue':_0x2e7d34,'newValue':_0x44630d}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x43276d,_0x8534aa){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x43276d]||(this['listeners'][_0x43276d]=new Set(),this['localCache'][_0x43276d]=this['storage']['getItem'](_0x43276d)),this['listeners'][_0x43276d]['add'](_0x8534aa);}['_removeListener'](_0x3afcb4,_0x1a2825){this['listeners'][_0x3afcb4]&&(this['listeners'][_0x3afcb4]['delete'](_0x1a2825),this['listeners'][_0x3afcb4]['size']===0x0&&delete this['listeners'][_0x3afcb4]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x413ed2,_0x2fc8f4){await super['_set'](_0x413ed2,_0x2fc8f4),this['localCache'][_0x413ed2]=JSON['stringify'](_0x2fc8f4);}async['_get'](_0x4f7915){const _0xbbed8a=await super['_get'](_0x4f7915);return this['localCache'][_0x4f7915]=JSON['stringify'](_0xbbed8a),_0xbbed8a;}async['_remove'](_0x44b06c){await super['_remove'](_0x44b06c),delete this['localCache'][_0x44b06c];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5e69b6,_0x1001ad){}['_removeListener'](_0x36382b,_0x307399){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x377cb7){return Promise['all'](_0x377cb7['map'](async _0x9630be=>{try{return{'fulfilled':!0x0,'value':await _0x9630be};}catch(_0x3606fc){return{'fulfilled':!0x1,'reason':_0x3606fc};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4d831c){this['eventTarget']=_0x4d831c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3963d9){const _0x24b903=this['receivers']['find'](_0x2ee1cf=>_0x2ee1cf['isListeningto'](_0x3963d9));if(_0x24b903)return _0x24b903;const _0x59a80b=new Xn(_0x3963d9);return this['receivers']['push'](_0x59a80b),_0x59a80b;}['isListeningto'](_0x29d5dd){return this['eventTarget']===_0x29d5dd;}async['handleEvent'](_0x3dbc71){const _0x3eba2f=_0x3dbc71,{eventId:_0x58c719,eventType:_0x40c50e,data:_0x130c9b}=_0x3eba2f['data'],_0x21e4b9=this['handlersMap'][_0x40c50e];if(!(_0x21e4b9!=null&&_0x21e4b9['size']))return;_0x3eba2f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x58c719,'eventType':_0x40c50e});const _0x1f0a92=Array['from'](_0x21e4b9)['map'](async _0x1cbd1a=>_0x1cbd1a(_0x3eba2f['origin'],_0x130c9b)),_0x26d030=await cp(_0x1f0a92);_0x3eba2f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x58c719,'eventType':_0x40c50e,'response':_0x26d030});}['_subscribe'](_0x2cc587,_0x1bf518){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2cc587]||(this['handlersMap'][_0x2cc587]=new Set()),this['handlersMap'][_0x2cc587]['add'](_0x1bf518);}['_unsubscribe'](_0x21242b,_0x580b0e){this['handlersMap'][_0x21242b]&&_0x580b0e&&this['handlersMap'][_0x21242b]['delete'](_0x580b0e),(!_0x580b0e||this['handlersMap'][_0x21242b]['size']===0x0)&&delete this['handlersMap'][_0x21242b],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x316da5='',_0x51ce1c=0xa){let _0x3018fd='';for(let _0x2e8276=0x0;_0x2e8276<_0x51ce1c;_0x2e8276++)_0x3018fd+=Math['floor'](Math['random']()*0xa);return _0x316da5+_0x3018fd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x506c90){this['target']=_0x506c90,this['handlers']=new Set();}['removeMessageHandler'](_0x3b30db){_0x3b30db['messageChannel']&&(_0x3b30db['messageChannel']['port1']['removeEventListener']('message',_0x3b30db['onMessage']),_0x3b30db['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3b30db);}async['_send'](_0x62c574,_0xe1e479,_0x1cc643=0x32){const _0x1a1466=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1a1466)throw new Error('connection_unavailable');let _0x76204a,_0x428281;return new Promise((_0x29156f,_0x324add)=>{const _0x57d35f=As('',0x14);_0x1a1466['port1']['start']();const _0x48ce3c=setTimeout(()=>{_0x324add(new Error('unsupported_event'));},_0x1cc643);_0x428281={'messageChannel':_0x1a1466,'onMessage'(_0x2a841f){const _0x598b13=_0x2a841f;if(_0x598b13['data']['eventId']===_0x57d35f)switch(_0x598b13['data']['status']){case'ack':clearTimeout(_0x48ce3c),_0x76204a=setTimeout(()=>{_0x324add(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x76204a),_0x29156f(_0x598b13['data']['response']);break;default:clearTimeout(_0x48ce3c),clearTimeout(_0x76204a),_0x324add(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x428281),_0x1a1466['port1']['addEventListener']('message',_0x428281['onMessage']),this['target']['postMessage']({'eventType':_0x62c574,'eventId':_0x57d35f,'data':_0xe1e479},[_0x1a1466['port2']]);})['finally'](()=>{_0x428281&&this['removeMessageHandler'](_0x428281);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x18f03b){Z()['location']['href']=_0x18f03b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1e9bd4;return((_0x1e9bd4=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1e9bd4['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4675f0){this['request']=_0x4675f0;}['toPromise'](){return new Promise((_0x4c7ee8,_0x53ea08)=>{this['request']['addEventListener']('success',()=>{_0x4c7ee8(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x53ea08(this['request']['error']);});});}}function Zn(_0x4bdc7b,_0x115aeb){return _0x4bdc7b['transaction']([Mn],_0x115aeb?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x20a900=indexedDB['deleteDatabase'](Ka);return new nn(_0x20a900)['toPromise']();}function Qa(){const _0x5bbef8=indexedDB['open'](Ka,pp);return new Promise((_0x1ccdeb,_0x87b008)=>{_0x5bbef8['addEventListener']('error',()=>{_0x87b008(_0x5bbef8['error']);}),_0x5bbef8['addEventListener']('upgradeneeded',()=>{const _0x5ba2df=_0x5bbef8['result'];try{_0x5ba2df['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0xcbaab0){_0x87b008(_0xcbaab0);}}),_0x5bbef8['addEventListener']('success',async()=>{const _0x3ed750=_0x5bbef8['result'];_0x3ed750['objectStoreNames']['contains'](Mn)?_0x1ccdeb(_0x3ed750):(_0x3ed750['close'](),await _p(),_0x1ccdeb(await Qa()));});});}async function Or(_0x4e3744,_0x4ebcce,_0xe6aa23){const _0x3f19d4=Zn(_0x4e3744,!0x0)['put']({[Ya]:_0x4ebcce,'value':_0xe6aa23});return new nn(_0x3f19d4)['toPromise']();}async function gp(_0xc8832a,_0x99cba6){const _0x5016f8=Zn(_0xc8832a,!0x1)['get'](_0x99cba6),_0x31f7cb=await new nn(_0x5016f8)['toPromise']();return _0x31f7cb===void 0x0?null:_0x31f7cb['value'];}function Dr(_0x4a7b8a,_0x72e0b6){const _0x486c26=Zn(_0x4a7b8a,!0x0)['delete'](_0x72e0b6);return new nn(_0x486c26)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5af902){let _0x3ab271=0x0;for(;;)try{const _0x3e7a0c=await this['_openDb']();return await _0x5af902(_0x3e7a0c);}catch(_0x5275bd){if(_0x3ab271++>yp)throw _0x5275bd;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x5de804,_0x2a7201)=>({'keyProcessed':(await this['_poll']())['includes'](_0x2a7201['key'])})),this['receiver']['_subscribe']('ping',async(_0x2ad92a,_0x3d8431)=>['keyChanged']);}async['initializeSender'](){var _0xc16f00,_0x4d15e1;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2e9c37=await this['sender']['_send']('ping',{},0x320);_0x2e9c37&&(_0xc16f00=_0x2e9c37[0x0])!=null&&_0xc16f00['fulfilled']&&(_0x4d15e1=_0x2e9c37[0x0])!=null&&_0x4d15e1['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x13cda8){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x13cda8},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x41ab84=>{await Or(_0x41ab84,Dn,'1'),await Dr(_0x41ab84,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x16466e){this['pendingWrites']++;try{await _0x16466e();}finally{this['pendingWrites']--;}}async['_set'](_0x378e1a,_0x1144bc){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3235cd=>Or(_0x3235cd,_0x378e1a,_0x1144bc)),this['localCache'][_0x378e1a]=_0x1144bc,this['notifyServiceWorker'](_0x378e1a)));}async['_get'](_0x4740d9){const _0x1418e3=await this['_withRetries'](_0x3845c1=>gp(_0x3845c1,_0x4740d9));return this['localCache'][_0x4740d9]=_0x1418e3,_0x1418e3;}async['_remove'](_0xd32daa){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x56a17a=>Dr(_0x56a17a,_0xd32daa)),delete this['localCache'][_0xd32daa],this['notifyServiceWorker'](_0xd32daa)));}async['_poll'](){const _0x54df5b=await this['_withRetries'](_0xef48bc=>{const _0x931d5d=Zn(_0xef48bc,!0x1)['getAll']();return new nn(_0x931d5d)['toPromise']();});if(!_0x54df5b)return[];if(this['pendingWrites']!==0x0)return[];const _0x33503d=[],_0x2894c8=new Set();if(_0x54df5b['length']!==0x0){for(const {fbase_key:_0x24995a,value:_0x6333de}of _0x54df5b)_0x2894c8['add'](_0x24995a),JSON['stringify'](this['localCache'][_0x24995a])!==JSON['stringify'](_0x6333de)&&(this['notifyListeners'](_0x24995a,_0x6333de),_0x33503d['push'](_0x24995a));}for(const _0x471e94 of Object['keys'](this['localCache']))this['localCache'][_0x471e94]&&!_0x2894c8['has'](_0x471e94)&&(this['notifyListeners'](_0x471e94,null),_0x33503d['push'](_0x471e94));return _0x33503d;}['notifyListeners'](_0x246923,_0x565b42){this['localCache'][_0x246923]=_0x565b42;const _0x539019=this['listeners'][_0x246923];if(_0x539019){for(const _0x320b9f of Array['from'](_0x539019))_0x320b9f(_0x565b42);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3a6084,_0x4a8f05){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3a6084]||(this['listeners'][_0x3a6084]=new Set(),this['_get'](_0x3a6084)),this['listeners'][_0x3a6084]['add'](_0x4a8f05);}['_removeListener'](_0x2de271,_0x51d3a6){this['listeners'][_0x2de271]&&(this['listeners'][_0x2de271]['delete'](_0x51d3a6),this['listeners'][_0x2de271]['size']===0x0&&delete this['listeners'][_0x2de271]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1d3cbc,_0x2272b4){return _0x2272b4?ie(_0x2272b4):(m(_0x1d3cbc['_popupRedirectResolver'],_0x1d3cbc,'argument-error'),_0x1d3cbc['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x416402){super('custom','custom'),this['params']=_0x416402;}['_getIdTokenResponse'](_0x127260){return nt(_0x127260,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4d1477,_0x56dc13){return nt(_0x4d1477,this['_buildIdpRequest'](_0x56dc13));}['_getReauthenticationResolver'](_0x20668b){return nt(_0x20668b,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1e5075){const _0x5bdb69={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1e5075&&(_0x5bdb69['idToken']=_0x1e5075),_0x5bdb69;}}function Ip(_0xeb6575){return Va(_0xeb6575['auth'],new ks(_0xeb6575),_0xeb6575['bypassAuthState']);}function wp(_0x1b765a){const {auth:_0x12866f,user:_0xfffcfc}=_0x1b765a;return m(_0xfffcfc,_0x12866f,'internal-error'),tp(_0xfffcfc,new ks(_0x1b765a),_0x1b765a['bypassAuthState']);}async function Cp(_0x9837c3){const {auth:_0x2bd485,user:_0x729506}=_0x9837c3;return m(_0x729506,_0x2bd485,'internal-error'),ep(_0x729506,new ks(_0x9837c3),_0x9837c3['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x4da81d,_0x485a65,_0x34d432,_0x406b70,_0x50ff4a=!0x1){this['auth']=_0x4da81d,this['resolver']=_0x34d432,this['user']=_0x406b70,this['bypassAuthState']=_0x50ff4a,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x485a65)?_0x485a65:[_0x485a65];}['execute'](){return new Promise(async(_0x4d731f,_0x2b9c00)=>{this['pendingPromise']={'resolve':_0x4d731f,'reject':_0x2b9c00};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x40f468){this['reject'](_0x40f468);}});}async['onAuthEvent'](_0x5f05e2){const {urlResponse:_0x2f3a89,sessionId:_0x85ff79,postBody:_0x49a216,tenantId:_0x39c942,error:_0x3ba86d,type:_0x354206}=_0x5f05e2;if(_0x3ba86d){this['reject'](_0x3ba86d);return;}const _0x5b0bf4={'auth':this['auth'],'requestUri':_0x2f3a89,'sessionId':_0x85ff79,'tenantId':_0x39c942||void 0x0,'postBody':_0x49a216||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x354206)(_0x5b0bf4));}catch(_0x12daf4){this['reject'](_0x12daf4);}}['onError'](_0x13c119){this['reject'](_0x13c119);}['getIdpTask'](_0x416001){switch(_0x416001){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x206395){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x206395),this['unregisterAndCleanUp']();}['reject'](_0x48eaba){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x48eaba),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0xb1339e,_0x7a0970,_0x5ba59c,_0x358beb,_0x3ff1d2){super(_0xb1339e,_0x7a0970,_0x358beb,_0x3ff1d2),this['provider']=_0x5ba59c,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3947e1=await this['execute']();return m(_0x3947e1,this['auth'],'internal-error'),_0x3947e1;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x530686=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x530686),this['authWindow']['associatedEvent']=_0x530686,this['resolver']['_originValidation'](this['auth'])['catch'](_0x5a25e3=>{this['reject'](_0x5a25e3);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x9742e8=>{_0x9742e8||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x25d249;return((_0x25d249=this['authWindow'])==null?void 0x0:_0x25d249['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2c3852=()=>{var _0x57b4cc,_0x44130b;if((_0x44130b=(_0x57b4cc=this['authWindow'])==null?void 0x0:_0x57b4cc['window'])!=null&&_0x44130b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2c3852,Tp['get']());};_0x2c3852();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x216797,_0x3f7d06,_0x218fd6=!0x1){super(_0x216797,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3f7d06,void 0x0,_0x218fd6),this['eventId']=null;}async['execute'](){let _0x45a1f0=hn['get'](this['auth']['_key']());if(!_0x45a1f0){try{const _0x25eb04=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x45a1f0=()=>Promise['resolve'](_0x25eb04);}catch(_0x124f4a){_0x45a1f0=()=>Promise['reject'](_0x124f4a);}hn['set'](this['auth']['_key'](),_0x45a1f0);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x45a1f0();}async['onAuthEvent'](_0x8d396c){if(_0x8d396c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x8d396c);if(_0x8d396c['type']==='unknown'){this['resolve'](null);return;}if(_0x8d396c['eventId']){const _0x5d5c5e=await this['auth']['_redirectUserForId'](_0x8d396c['eventId']);if(_0x5d5c5e)return this['user']=_0x5d5c5e,super['onAuthEvent'](_0x8d396c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x46c885,_0x313968){const _0x427a83=Pp(_0x313968),_0x32a588=kp(_0x46c885);if(!await _0x32a588['_isAvailable']())return!0x1;const _0x25e416=await _0x32a588['_get'](_0x427a83)==='true';return await _0x32a588['_remove'](_0x427a83),_0x25e416;}function Ap(_0x46132e,_0x4fc9ea){hn['set'](_0x46132e['_key'](),_0x4fc9ea);}function kp(_0x579d3c){return ie(_0x579d3c['_redirectPersistence']);}function Pp(_0x1267fa){return ln(Sp,_0x1267fa['config']['apiKey'],_0x1267fa['name']);}async function Np(_0x87b1f5,_0x301f71,_0x21cd7a=!0x1){if($(_0x87b1f5['app']))return Promise['reject'](re(_0x87b1f5));const _0x38afdf=Ke(_0x87b1f5),_0x3122b6=Ep(_0x38afdf,_0x301f71),_0x1b4e50=await new bp(_0x38afdf,_0x3122b6,_0x21cd7a)['execute']();return _0x1b4e50&&!_0x21cd7a&&(delete _0x1b4e50['user']['_redirectEventId'],await _0x38afdf['_persistUserIfCurrent'](_0x1b4e50['user']),await _0x38afdf['_setRedirectUser'](null,_0x301f71)),_0x1b4e50;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x10d7db){this['auth']=_0x10d7db,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3fc25f){this['consumers']['add'](_0x3fc25f),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3fc25f)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3fc25f),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5e12a7){this['consumers']['delete'](_0x5e12a7);}['onEvent'](_0x2714c7){if(this['hasEventBeenHandled'](_0x2714c7))return!0x1;let _0x16a187=!0x1;return this['consumers']['forEach'](_0x7e8de=>{this['isEventForConsumer'](_0x2714c7,_0x7e8de)&&(_0x16a187=!0x0,this['sendToConsumer'](_0x2714c7,_0x7e8de),this['saveEventToCache'](_0x2714c7));}),this['hasHandledPotentialRedirect']||!Mp(_0x2714c7)||(this['hasHandledPotentialRedirect']=!0x0,_0x16a187||(this['queuedRedirectEvent']=_0x2714c7,_0x16a187=!0x0)),_0x16a187;}['sendToConsumer'](_0x195a36,_0x2a3902){var _0x3cc702;if(_0x195a36['error']&&!Za(_0x195a36)){const _0x263fee=((_0x3cc702=_0x195a36['error']['code'])==null?void 0x0:_0x3cc702['split']('auth/')[0x1])||'internal-error';_0x2a3902['onError'](X(this['auth'],_0x263fee));}else _0x2a3902['onAuthEvent'](_0x195a36);}['isEventForConsumer'](_0x3f76ed,_0xd662cd){const _0x559da0=_0xd662cd['eventId']===null||!!_0x3f76ed['eventId']&&_0x3f76ed['eventId']===_0xd662cd['eventId'];return _0xd662cd['filter']['includes'](_0x3f76ed['type'])&&_0x559da0;}['hasEventBeenHandled'](_0x14a53d){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x14a53d));}['saveEventToCache'](_0x2dfe81){this['cachedEventUids']['add'](Mr(_0x2dfe81)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x798596){return[_0x798596['type'],_0x798596['eventId'],_0x798596['sessionId'],_0x798596['tenantId']]['filter'](_0x432071=>_0x432071)['join']('-');}function Za({type:_0x43027a,error:_0x1448b1}){return _0x43027a==='unknown'&&(_0x1448b1==null?void 0x0:_0x1448b1['code'])==='auth/no-auth-event';}function Mp(_0x36bb8b){switch(_0x36bb8b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x36bb8b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x349153,_0x530627={}){return Pe(_0x349153,'GET','/v1/projects',_0x530627);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x396a60){if(_0x396a60['config']['emulator'])return;const {authorizedDomains:_0x43f5fd}=await Lp(_0x396a60);for(const _0x41f946 of _0x43f5fd)try{if(Wp(_0x41f946))return;}catch{}Y(_0x396a60,'unauthorized-domain');}function Wp(_0x37f535){const _0x281f01=Mi(),{protocol:_0xc9723e,hostname:_0x3a06ed}=new URL(_0x281f01);if(_0x37f535['startsWith']('chrome-extension://')){const _0x51e30b=new URL(_0x37f535);return _0x51e30b['hostname']===''&&_0x3a06ed===''?_0xc9723e==='chrome-extension:'&&_0x37f535['replace']('chrome-extension://','')===_0x281f01['replace']('chrome-extension://',''):_0xc9723e==='chrome-extension:'&&_0x51e30b['hostname']===_0x3a06ed;}if(!Fp['test'](_0xc9723e))return!0x1;if(xp['test'](_0x37f535))return _0x3a06ed===_0x37f535;const _0xf9a06f=_0x37f535['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xf9a06f+'|'+_0xf9a06f+')$','i')['test'](_0x3a06ed);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x475df5=Z()['___jsl'];if(_0x475df5!=null&&_0x475df5['H']){for(const _0x1ee708 of Object['keys'](_0x475df5['H']))if(_0x475df5['H'][_0x1ee708]['r']=_0x475df5['H'][_0x1ee708]['r']||[],_0x475df5['H'][_0x1ee708]['L']=_0x475df5['H'][_0x1ee708]['L']||[],_0x475df5['H'][_0x1ee708]['r']=[..._0x475df5['H'][_0x1ee708]['L']],_0x475df5['CP']){for(let _0x59249c=0x0;_0x59249c<_0x475df5['CP']['length'];_0x59249c++)_0x475df5['CP'][_0x59249c]=null;}}}function Vp(_0x2b4d02){return new Promise((_0x2f1133,_0x4ac017)=>{var _0x11be5d,_0x5069c8,_0xf2b5b0;function _0x4f8007(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2f1133(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4ac017(X(_0x2b4d02,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5069c8=(_0x11be5d=Z()['gapi'])==null?void 0x0:_0x11be5d['iframes'])!=null&&_0x5069c8['Iframe'])_0x2f1133(gapi['iframes']['getContext']());else{if((_0xf2b5b0=Z()['gapi'])!=null&&_0xf2b5b0['load'])_0x4f8007();else{const _0x5cdeae=Ff('iframefcb');return Z()[_0x5cdeae]=()=>{gapi['load']?_0x4f8007():_0x4ac017(X(_0x2b4d02,'network-request-failed'));},xa(xf()+'?onload='+_0x5cdeae)['catch'](_0x5231b6=>_0x4ac017(_0x5231b6));}}})['catch'](_0x9111ee=>{throw un=null,_0x9111ee;});}let un=null;function Hp(_0x4d1d07){return un=un||Vp(_0x4d1d07),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1fbbf8){const _0x1d54d5=_0x1fbbf8['config'];m(_0x1d54d5['authDomain'],_0x1fbbf8,'auth-domain-config-required');const _0x3812b2=_0x1d54d5['emulator']?Cs(_0x1d54d5,qp):'https://'+_0x1fbbf8['config']['authDomain']+'/'+Gp,_0x13f0d4={'apiKey':_0x1d54d5['apiKey'],'appName':_0x1fbbf8['name'],'v':dt},_0x116056=jp['get'](_0x1fbbf8['config']['apiHost']);_0x116056&&(_0x13f0d4['eid']=_0x116056);const _0xbbc516=_0x1fbbf8['_getFrameworks']();return _0xbbc516['length']&&(_0x13f0d4['fw']=_0xbbc516['join'](',')),_0x3812b2+'?'+ut(_0x13f0d4)['slice'](0x1);}async function Yp(_0x427c71){const _0x286198=await Hp(_0x427c71),_0x405706=Z()['gapi'];return m(_0x405706,_0x427c71,'internal-error'),_0x286198['open']({'where':document['body'],'url':Kp(_0x427c71),'messageHandlersFilter':_0x405706['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x129194=>new Promise(async(_0x3c26ed,_0x395b2a)=>{await _0x129194['restyle']({'setHideOnLeave':!0x1});const _0x5cbf21=X(_0x427c71,'network-request-failed'),_0xcb25d4=Z()['setTimeout'](()=>{_0x395b2a(_0x5cbf21);},$p['get']());function _0xb968e9(){Z()['clearTimeout'](_0xcb25d4),_0x3c26ed(_0x129194);}_0x129194['ping'](_0xb968e9)['then'](_0xb968e9,()=>{_0x395b2a(_0x5cbf21);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x24d364){this['window']=_0x24d364,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x59e500,_0x16678e,_0x1ee6f3,_0x471ee8=Jp,_0x172714=Xp){const _0x57b9e5=Math['max']((window['screen']['availHeight']-_0x172714)/0x2,0x0)['toString'](),_0x302bd6=Math['max']((window['screen']['availWidth']-_0x471ee8)/0x2,0x0)['toString']();let _0x5f53de='';const _0x4e0e81={...Qp,'width':_0x471ee8['toString'](),'height':_0x172714['toString'](),'top':_0x57b9e5,'left':_0x302bd6},_0x5aeb49=W()['toLowerCase']();_0x1ee6f3&&(_0x5f53de=ka(_0x5aeb49)?Zp:_0x1ee6f3),Ra(_0x5aeb49)&&(_0x16678e=_0x16678e||e_,_0x4e0e81['scrollbars']='yes');const _0x19abdd=Object['entries'](_0x4e0e81)['reduce']((_0x32716f,[_0x252daf,_0x515ee5])=>''+_0x32716f+_0x252daf+'='+_0x515ee5+',','');if(Rf(_0x5aeb49)&&_0x5f53de!=='_self')return n_(_0x16678e||'',_0x5f53de),new xr(null);const _0x13a8e3=window['open'](_0x16678e||'',_0x5f53de,_0x19abdd);m(_0x13a8e3,_0x59e500,'popup-blocked');try{_0x13a8e3['focus']();}catch{}return new xr(_0x13a8e3);}function n_(_0x3501a1,_0x1caa95){const _0x32c75a=document['createElement']('a');_0x32c75a['href']=_0x3501a1,_0x32c75a['target']=_0x1caa95;const _0x4ba97f=document['createEvent']('MouseEvent');_0x4ba97f['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x32c75a['dispatchEvent'](_0x4ba97f);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0xe9d04e,_0x2bfbf8,_0x1938f0,_0x1353f4,_0x578211,_0x2533aa){m(_0xe9d04e['config']['authDomain'],_0xe9d04e,'auth-domain-config-required'),m(_0xe9d04e['config']['apiKey'],_0xe9d04e,'invalid-api-key');const _0x2a5f5d={'apiKey':_0xe9d04e['config']['apiKey'],'appName':_0xe9d04e['name'],'authType':_0x1938f0,'redirectUrl':_0x1353f4,'v':dt,'eventId':_0x578211};if(_0x2bfbf8 instanceof Wa){_0x2bfbf8['setDefaultLanguage'](_0xe9d04e['languageCode']),_0x2a5f5d['providerId']=_0x2bfbf8['providerId']||'',pn(_0x2bfbf8['getCustomParameters']())||(_0x2a5f5d['customParameters']=JSON['stringify'](_0x2bfbf8['getCustomParameters']()));for(const [_0xc39fd4,_0x2db283]of Object['entries']({}))_0x2a5f5d[_0xc39fd4]=_0x2db283;}if(_0x2bfbf8 instanceof tn){const _0x2347a0=_0x2bfbf8['getScopes']()['filter'](_0x5fc73c=>_0x5fc73c!=='');_0x2347a0['length']>0x0&&(_0x2a5f5d['scopes']=_0x2347a0['join'](','));}_0xe9d04e['tenantId']&&(_0x2a5f5d['tid']=_0xe9d04e['tenantId']);const _0xc0dfb=_0x2a5f5d;for(const _0x102d7d of Object['keys'](_0xc0dfb))_0xc0dfb[_0x102d7d]===void 0x0&&delete _0xc0dfb[_0x102d7d];const _0x185179=await _0xe9d04e['_getAppCheckToken'](),_0xca3430=_0x185179?'#'+r_+'='+encodeURIComponent(_0x185179):'';return o_(_0xe9d04e)+'?'+ut(_0xc0dfb)['slice'](0x1)+_0xca3430;}function o_({config:_0x4d242d}){return _0x4d242d['emulator']?Cs(_0x4d242d,s_):'https://'+_0x4d242d['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x1253d8,_0x4dabe9,_0xd43780,_0x4a09e0){var _0x566021;ce((_0x566021=this['eventManagers'][_0x1253d8['_key']()])==null?void 0x0:_0x566021['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x333bcd=await Fr(_0x1253d8,_0x4dabe9,_0xd43780,Mi(),_0x4a09e0);return t_(_0x1253d8,_0x333bcd,As());}async['_openRedirect'](_0x19fd71,_0x522c42,_0x566cd9,_0x238775){await this['_originValidation'](_0x19fd71);const _0x2806c4=await Fr(_0x19fd71,_0x522c42,_0x566cd9,Mi(),_0x238775);return hp(_0x2806c4),new Promise(()=>{});}['_initialize'](_0x2b015b){const _0xaea8b=_0x2b015b['_key']();if(this['eventManagers'][_0xaea8b]){const {manager:_0x49cc47,promise:_0x3328e9}=this['eventManagers'][_0xaea8b];return _0x49cc47?Promise['resolve'](_0x49cc47):(ce(_0x3328e9,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3328e9);}const _0x2b8411=this['initAndGetManager'](_0x2b015b);return this['eventManagers'][_0xaea8b]={'promise':_0x2b8411},_0x2b8411['catch'](()=>{delete this['eventManagers'][_0xaea8b];}),_0x2b8411;}async['initAndGetManager'](_0x326591){const _0x36cc9c=await Yp(_0x326591),_0x357d25=new Dp(_0x326591);return _0x36cc9c['register']('authEvent',_0x1702a0=>(m(_0x1702a0==null?void 0x0:_0x1702a0['authEvent'],_0x326591,'invalid-auth-event'),{'status':_0x357d25['onEvent'](_0x1702a0['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x326591['_key']()]={'manager':_0x357d25},this['iframes'][_0x326591['_key']()]=_0x36cc9c,_0x357d25;}['_isIframeWebStorageSupported'](_0x364ef4,_0x22e14d){this['iframes'][_0x364ef4['_key']()]['send'](pi,{'type':pi},_0x408eae=>{var _0x1b903c;const _0x438dec=(_0x1b903c=_0x408eae==null?void 0x0:_0x408eae[0x0])==null?void 0x0:_0x1b903c[pi];_0x438dec!==void 0x0&&_0x22e14d(!!_0x438dec),Y(_0x364ef4,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x17fbea){const _0x1b3049=_0x17fbea['_key']();return this['originValidationPromises'][_0x1b3049]||(this['originValidationPromises'][_0x1b3049]=Up(_0x17fbea)),this['originValidationPromises'][_0x1b3049];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x1bd503){this['auth']=_0x1bd503,this['internalListeners']=new Map();}['getUid'](){var _0x3b9322;return this['assertAuthConfigured'](),((_0x3b9322=this['auth']['currentUser'])==null?void 0x0:_0x3b9322['uid'])||null;}async['getToken'](_0x1aa726){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1aa726)}:null;}['addAuthTokenListener'](_0x3163e2){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3163e2))return;const _0x44d257=this['auth']['onIdTokenChanged'](_0x58ede2=>{_0x3163e2((_0x58ede2==null?void 0x0:_0x58ede2['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3163e2,_0x44d257),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1d5823){this['assertAuthConfigured']();const _0x4aaf7b=this['internalListeners']['get'](_0x1d5823);_0x4aaf7b&&(this['internalListeners']['delete'](_0x1d5823),_0x4aaf7b(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x13f622){switch(_0x13f622){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x376ab1){st(new Fe('auth',(_0xf07354,{options:_0x3df2a6})=>{const _0xaf5448=_0xf07354['getProvider']('app')['getImmediate'](),_0x2f5864=_0xf07354['getProvider']('heartbeat'),_0x60e42d=_0xf07354['getProvider']('app-check-internal'),{apiKey:_0x434bc9,authDomain:_0x13ddb1}=_0xaf5448['options'];m(_0x434bc9&&!_0x434bc9['includes'](':'),'invalid-api-key',{'appName':_0xaf5448['name']});const _0x329f0b={'apiKey':_0x434bc9,'authDomain':_0x13ddb1,'clientPlatform':_0x376ab1,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x376ab1)},_0x3dc9c3=new Df(_0xaf5448,_0x2f5864,_0x60e42d,_0x329f0b);return Hf(_0x3dc9c3,_0x3df2a6),_0x3dc9c3;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xcd34bf,_0x51a333,_0x3fe53c)=>{_0xcd34bf['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x53be5f=>{const _0x15df77=Ke(_0x53be5f['getProvider']('auth')['getImmediate']());return(_0x40fe4a=>new l_(_0x40fe4a))(_0x15df77);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x376ab1)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0xe77584=>async _0x438cc3=>{const _0x208555=_0x438cc3&&await _0x438cc3['getIdTokenResult'](),_0x1ec95e=_0x208555&&(new Date()['getTime']()-Date['parse'](_0x208555['issuedAtTime']))/0x3e8;if(_0x1ec95e&&_0x1ec95e>f_)return;const _0x53ef05=_0x208555==null?void 0x0:_0x208555['token'];Br!==_0x53ef05&&(Br=_0x53ef05,await fetch(_0xe77584,{'method':_0x53ef05?'POST':'DELETE','headers':_0x53ef05?{'Authorization':'Bearer\x20'+_0x53ef05}:{}}));};function B_(_0x513f59=Zr()){const _0x56bf29=Hi(_0x513f59,'auth');if(_0x56bf29['isInitialized']())return _0x56bf29['getImmediate']();const _0x61dedf=Vf(_0x513f59,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x1ae3f1=jr('authTokenSyncURL');if(_0x1ae3f1&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4105cd=new URL(_0x1ae3f1,location['origin']);if(location['origin']===_0x4105cd['origin']){const _0x2c8f46=p_(_0x4105cd['toString']());sp(_0x61dedf,_0x2c8f46,()=>_0x2c8f46(_0x61dedf['currentUser'])),ip(_0x61dedf,_0x50596b=>_0x2c8f46(_0x50596b));}}const _0x2b3638=qr('auth');return _0x2b3638&&$f(_0x61dedf,'http://'+_0x2b3638),_0x61dedf;}function __(){var _0x22b856;return((_0x22b856=document['getElementsByTagName']('head'))==null?void 0x0:_0x22b856[0x0])??document;}Mf({'loadJS'(_0x30cb00){return new Promise((_0x62f9f3,_0x299cc0)=>{const _0x27d9eb=document['createElement']('script');_0x27d9eb['setAttribute']('src',_0x30cb00),_0x27d9eb['onload']=_0x62f9f3,_0x27d9eb['onerror']=_0x19d65e=>{const _0x2df58e=X('internal-error');_0x2df58e['customData']=_0x19d65e,_0x299cc0(_0x2df58e);},_0x27d9eb['type']='text/javascript',_0x27d9eb['charset']='UTF-8',__()['appendChild'](_0x27d9eb);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};