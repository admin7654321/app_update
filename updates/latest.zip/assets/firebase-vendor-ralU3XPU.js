const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x468c30,_0x2ca342){if(!_0x468c30)throw ht(_0x2ca342);},ht=function(_0x3ac3b9){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x3ac3b9);},Hr=function(_0x4a035c){const _0x1472c3=[];let _0x290675=0x0;for(let _0x3d30bb=0x0;_0x3d30bb<_0x4a035c['length'];_0x3d30bb++){let _0x36e3ec=_0x4a035c['charCodeAt'](_0x3d30bb);_0x36e3ec<0x80?_0x1472c3[_0x290675++]=_0x36e3ec:_0x36e3ec<0x800?(_0x1472c3[_0x290675++]=_0x36e3ec>>0x6|0xc0,_0x1472c3[_0x290675++]=_0x36e3ec&0x3f|0x80):(_0x36e3ec&0xfc00)===0xd800&&_0x3d30bb+0x1<_0x4a035c['length']&&(_0x4a035c['charCodeAt'](_0x3d30bb+0x1)&0xfc00)===0xdc00?(_0x36e3ec=0x10000+((_0x36e3ec&0x3ff)<<0xa)+(_0x4a035c['charCodeAt'](++_0x3d30bb)&0x3ff),_0x1472c3[_0x290675++]=_0x36e3ec>>0x12|0xf0,_0x1472c3[_0x290675++]=_0x36e3ec>>0xc&0x3f|0x80,_0x1472c3[_0x290675++]=_0x36e3ec>>0x6&0x3f|0x80,_0x1472c3[_0x290675++]=_0x36e3ec&0x3f|0x80):(_0x1472c3[_0x290675++]=_0x36e3ec>>0xc|0xe0,_0x1472c3[_0x290675++]=_0x36e3ec>>0x6&0x3f|0x80,_0x1472c3[_0x290675++]=_0x36e3ec&0x3f|0x80);}return _0x1472c3;},nc=function(_0x1e6c0e){const _0x50e6e8=[];let _0x52ea95=0x0,_0x48e1f5=0x0;for(;_0x52ea95<_0x1e6c0e['length'];){const _0xa4d76b=_0x1e6c0e[_0x52ea95++];if(_0xa4d76b<0x80)_0x50e6e8[_0x48e1f5++]=String['fromCharCode'](_0xa4d76b);else{if(_0xa4d76b>0xbf&&_0xa4d76b<0xe0){const _0x452245=_0x1e6c0e[_0x52ea95++];_0x50e6e8[_0x48e1f5++]=String['fromCharCode']((_0xa4d76b&0x1f)<<0x6|_0x452245&0x3f);}else{if(_0xa4d76b>0xef&&_0xa4d76b<0x16d){const _0x577ee8=_0x1e6c0e[_0x52ea95++],_0x237111=_0x1e6c0e[_0x52ea95++],_0x40f023=_0x1e6c0e[_0x52ea95++],_0x2c6cd1=((_0xa4d76b&0x7)<<0x12|(_0x577ee8&0x3f)<<0xc|(_0x237111&0x3f)<<0x6|_0x40f023&0x3f)-0x10000;_0x50e6e8[_0x48e1f5++]=String['fromCharCode'](0xd800+(_0x2c6cd1>>0xa)),_0x50e6e8[_0x48e1f5++]=String['fromCharCode'](0xdc00+(_0x2c6cd1&0x3ff));}else{const _0x4390a2=_0x1e6c0e[_0x52ea95++],_0x21326f=_0x1e6c0e[_0x52ea95++];_0x50e6e8[_0x48e1f5++]=String['fromCharCode']((_0xa4d76b&0xf)<<0xc|(_0x4390a2&0x3f)<<0x6|_0x21326f&0x3f);}}}}return _0x50e6e8['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x368054,_0x5d08c0){if(!Array['isArray'](_0x368054))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x31f734=_0x5d08c0?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2f8a66=[];for(let _0x5e27a3=0x0;_0x5e27a3<_0x368054['length'];_0x5e27a3+=0x3){const _0x430274=_0x368054[_0x5e27a3],_0x2f432a=_0x5e27a3+0x1<_0x368054['length'],_0x17a6fd=_0x2f432a?_0x368054[_0x5e27a3+0x1]:0x0,_0x3ff66d=_0x5e27a3+0x2<_0x368054['length'],_0x5f0412=_0x3ff66d?_0x368054[_0x5e27a3+0x2]:0x0,_0x32589e=_0x430274>>0x2,_0x131105=(_0x430274&0x3)<<0x4|_0x17a6fd>>0x4;let _0x13cde4=(_0x17a6fd&0xf)<<0x2|_0x5f0412>>0x6,_0x1dc291=_0x5f0412&0x3f;_0x3ff66d||(_0x1dc291=0x40,_0x2f432a||(_0x13cde4=0x40)),_0x2f8a66['push'](_0x31f734[_0x32589e],_0x31f734[_0x131105],_0x31f734[_0x13cde4],_0x31f734[_0x1dc291]);}return _0x2f8a66['join']('');},'encodeString'(_0x56ba45,_0x3ffdcd){return this['HAS_NATIVE_SUPPORT']&&!_0x3ffdcd?btoa(_0x56ba45):this['encodeByteArray'](Hr(_0x56ba45),_0x3ffdcd);},'decodeString'(_0x59c479,_0x3a195d){return this['HAS_NATIVE_SUPPORT']&&!_0x3a195d?atob(_0x59c479):nc(this['decodeStringToByteArray'](_0x59c479,_0x3a195d));},'decodeStringToByteArray'(_0x8498c3,_0x40f069){this['init_']();const _0x18ed66=_0x40f069?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x56b33b=[];for(let _0x5cdd2e=0x0;_0x5cdd2e<_0x8498c3['length'];){const _0x3d07a3=_0x18ed66[_0x8498c3['charAt'](_0x5cdd2e++)],_0x4e265c=_0x5cdd2e<_0x8498c3['length']?_0x18ed66[_0x8498c3['charAt'](_0x5cdd2e)]:0x0;++_0x5cdd2e;const _0x57a467=_0x5cdd2e<_0x8498c3['length']?_0x18ed66[_0x8498c3['charAt'](_0x5cdd2e)]:0x40;++_0x5cdd2e;const _0x288259=_0x5cdd2e<_0x8498c3['length']?_0x18ed66[_0x8498c3['charAt'](_0x5cdd2e)]:0x40;if(++_0x5cdd2e,_0x3d07a3==null||_0x4e265c==null||_0x57a467==null||_0x288259==null)throw new ic();const _0x1be01d=_0x3d07a3<<0x2|_0x4e265c>>0x4;if(_0x56b33b['push'](_0x1be01d),_0x57a467!==0x40){const _0x2fd1e2=_0x4e265c<<0x4&0xf0|_0x57a467>>0x2;if(_0x56b33b['push'](_0x2fd1e2),_0x288259!==0x40){const _0xb04248=_0x57a467<<0x6&0xc0|_0x288259;_0x56b33b['push'](_0xb04248);}}}return _0x56b33b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x491f3a=0x0;_0x491f3a<this['ENCODED_VALS']['length'];_0x491f3a++)this['byteToCharMap_'][_0x491f3a]=this['ENCODED_VALS']['charAt'](_0x491f3a),this['charToByteMap_'][this['byteToCharMap_'][_0x491f3a]]=_0x491f3a,this['byteToCharMapWebSafe_'][_0x491f3a]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x491f3a),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x491f3a]]=_0x491f3a,_0x491f3a>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x491f3a)]=_0x491f3a,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x491f3a)]=_0x491f3a);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x4ca5ed){const _0x24bb76=Hr(_0x4ca5ed);return Fi['encodeByteArray'](_0x24bb76,!0x0);},dn=function(_0x583557){return $r(_0x583557)['replace'](/\./g,'');},fn=function(_0x1f2a34){try{return Fi['decodeString'](_0x1f2a34,!0x0);}catch(_0x3da5fa){console['error']('base64Decode\x20failed:\x20',_0x3da5fa);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2a212b){return Gr(void 0x0,_0x2a212b);}function Gr(_0x128b8a,_0x21aa6a){if(!(_0x21aa6a instanceof Object))return _0x21aa6a;switch(_0x21aa6a['constructor']){case Date:const _0x48a5e4=_0x21aa6a;return new Date(_0x48a5e4['getTime']());case Object:_0x128b8a===void 0x0&&(_0x128b8a={});break;case Array:_0x128b8a=[];break;default:return _0x21aa6a;}for(const _0x581a6f in _0x21aa6a)!_0x21aa6a['hasOwnProperty'](_0x581a6f)||!rc(_0x581a6f)||(_0x128b8a[_0x581a6f]=Gr(_0x128b8a[_0x581a6f],_0x21aa6a[_0x581a6f]));return _0x128b8a;}function rc(_0x5e3ece){return _0x5e3ece!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xb0b123=Ps['__FIREBASE_DEFAULTS__'];if(_0xb0b123)return JSON['parse'](_0xb0b123);},lc=()=>{if(typeof document>'u')return;let _0x5533ef;try{_0x5533ef=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x5eb5dc=_0x5533ef&&fn(_0x5533ef[0x1]);return _0x5eb5dc&&JSON['parse'](_0x5eb5dc);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xd4891c){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xd4891c);return;}},qr=_0x5c1414=>{var _0x3822f6,_0x59bf4b;return(_0x59bf4b=(_0x3822f6=Ui())==null?void 0x0:_0x3822f6['emulatorHosts'])==null?void 0x0:_0x59bf4b[_0x5c1414];},hc=_0x397a5c=>{const _0x357049=qr(_0x397a5c);if(!_0x357049)return;const _0x230890=_0x357049['lastIndexOf'](':');if(_0x230890<=0x0||_0x230890+0x1===_0x357049['length'])throw new Error('Invalid\x20host\x20'+_0x357049+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x54a504=parseInt(_0x357049['substring'](_0x230890+0x1),0xa);return _0x357049[0x0]==='['?[_0x357049['substring'](0x1,_0x230890-0x1),_0x54a504]:[_0x357049['substring'](0x0,_0x230890),_0x54a504];},zr=()=>{var _0x1f9fd2;return(_0x1f9fd2=Ui())==null?void 0x0:_0x1f9fd2['config'];},jr=_0x4be393=>{var _0x426076;return(_0x426076=Ui())==null?void 0x0:_0x426076['_'+_0x4be393];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x55a1d,_0x2b41ac)=>{this['resolve']=_0x55a1d,this['reject']=_0x2b41ac;});}['wrapCallback'](_0x347fb5){return(_0x3f7093,_0x3c822c)=>{_0x3f7093?this['reject'](_0x3f7093):this['resolve'](_0x3c822c),typeof _0x347fb5=='function'&&(this['promise']['catch'](()=>{}),_0x347fb5['length']===0x1?_0x347fb5(_0x3f7093):_0x347fb5(_0x3f7093,_0x3c822c));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x512288,_0x42c688){if(_0x512288['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x53066c={'alg':'none','type':'JWT'},_0x18439b=_0x42c688||'demo-project',_0x5aaeb6=_0x512288['iat']||0x0,_0x2fb242=_0x512288['sub']||_0x512288['user_id'];if(!_0x2fb242)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x18ea2f={'iss':'https://securetoken.google.com/'+_0x18439b,'aud':_0x18439b,'iat':_0x5aaeb6,'exp':_0x5aaeb6+0xe10,'auth_time':_0x5aaeb6,'sub':_0x2fb242,'user_id':_0x2fb242,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x512288};return[dn(JSON['stringify'](_0x53066c)),dn(JSON['stringify'](_0x18ea2f)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x9616bb=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x9616bb=='object'&&_0x9616bb['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2f91e8=W();return _0x2f91e8['indexOf']('MSIE\x20')>=0x0||_0x2f91e8['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2a3e6e,_0x2d919e)=>{try{let _0x4c0e50=!0x0;const _0x338773='validate-browser-context-for-indexeddb-analytics-module',_0x137673=self['indexedDB']['open'](_0x338773);_0x137673['onsuccess']=()=>{_0x137673['result']['close'](),_0x4c0e50||self['indexedDB']['deleteDatabase'](_0x338773),_0x2a3e6e(!0x0);},_0x137673['onupgradeneeded']=()=>{_0x4c0e50=!0x1;},_0x137673['onerror']=()=>{var _0xead441;_0x2d919e(((_0xead441=_0x137673['error'])==null?void 0x0:_0xead441['message'])||'');};}catch(_0x5393e2){_0x2d919e(_0x5393e2);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x5e0e04,_0x5b47f8,_0x5dd7c6){super(_0x5b47f8),this['code']=_0x5e0e04,this['customData']=_0x5dd7c6,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x410569,_0x5a0bf0,_0x408cb1){this['service']=_0x410569,this['serviceName']=_0x5a0bf0,this['errors']=_0x408cb1;}['create'](_0x54b12c,..._0x1b03f9){const _0x264a00=_0x1b03f9[0x0]||{},_0x1148a6=this['service']+'/'+_0x54b12c,_0x53ac3c=this['errors'][_0x54b12c],_0x519158=_0x53ac3c?vc(_0x53ac3c,_0x264a00):'Error',_0x4b058a=this['serviceName']+':\x20'+_0x519158+'\x20('+_0x1148a6+').';return new Re(_0x1148a6,_0x4b058a,_0x264a00);}}function vc(_0x46054c,_0x4c2392){return _0x46054c['replace'](Ec,(_0x2153e2,_0x22f093)=>{const _0x21b6c0=_0x4c2392[_0x22f093];return _0x21b6c0!=null?String(_0x21b6c0):'<'+_0x22f093+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x110b4a){return JSON['parse'](_0x110b4a);}function O(_0x2af906){return JSON['stringify'](_0x2af906);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x3dd351){let _0xfb6d97={},_0x4968f8={},_0x3afd40={},_0x4ce925='';try{const _0x279da8=_0x3dd351['split']('.');_0xfb6d97=Nt(fn(_0x279da8[0x0])||''),_0x4968f8=Nt(fn(_0x279da8[0x1])||''),_0x4ce925=_0x279da8[0x2],_0x3afd40=_0x4968f8['d']||{},delete _0x4968f8['d'];}catch{}return{'header':_0xfb6d97,'claims':_0x4968f8,'data':_0x3afd40,'signature':_0x4ce925};},Ic=function(_0xfc29be){const _0x18cff0=Yr(_0xfc29be),_0x4d1819=_0x18cff0['claims'];return!!_0x4d1819&&typeof _0x4d1819=='object'&&_0x4d1819['hasOwnProperty']('iat');},wc=function(_0x4e8eeb){const _0x28b5a9=Yr(_0x4e8eeb)['claims'];return typeof _0x28b5a9=='object'&&_0x28b5a9['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4f5f2,_0x2b049f){return Object['prototype']['hasOwnProperty']['call'](_0x4f5f2,_0x2b049f);}function Le(_0x45b265,_0x461266){if(Object['prototype']['hasOwnProperty']['call'](_0x45b265,_0x461266))return _0x45b265[_0x461266];}function pn(_0x42e18c){for(const _0x3b5ba2 in _0x42e18c)if(Object['prototype']['hasOwnProperty']['call'](_0x42e18c,_0x3b5ba2))return!0x1;return!0x0;}function _n(_0x36ac9e,_0x299834,_0x443b70){const _0x5eb690={};for(const _0x23afc1 in _0x36ac9e)Object['prototype']['hasOwnProperty']['call'](_0x36ac9e,_0x23afc1)&&(_0x5eb690[_0x23afc1]=_0x299834['call'](_0x443b70,_0x36ac9e[_0x23afc1],_0x23afc1,_0x36ac9e));return _0x5eb690;}function xe(_0x4d7375,_0x831261){if(_0x4d7375===_0x831261)return!0x0;const _0x17c8e8=Object['keys'](_0x4d7375),_0x545695=Object['keys'](_0x831261);for(const _0x57b461 of _0x17c8e8){if(!_0x545695['includes'](_0x57b461))return!0x1;const _0x97f02f=_0x4d7375[_0x57b461],_0x19db5e=_0x831261[_0x57b461];if(Ns(_0x97f02f)&&Ns(_0x19db5e)){if(!xe(_0x97f02f,_0x19db5e))return!0x1;}else{if(_0x97f02f!==_0x19db5e)return!0x1;}}for(const _0x5b0d50 of _0x545695)if(!_0x17c8e8['includes'](_0x5b0d50))return!0x1;return!0x0;}function Ns(_0x8c869a){return _0x8c869a!==null&&typeof _0x8c869a=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x335eb2){const _0x48f7b0=[];for(const [_0x4622ce,_0xd21384]of Object['entries'](_0x335eb2))Array['isArray'](_0xd21384)?_0xd21384['forEach'](_0x563d24=>{_0x48f7b0['push'](encodeURIComponent(_0x4622ce)+'='+encodeURIComponent(_0x563d24));}):_0x48f7b0['push'](encodeURIComponent(_0x4622ce)+'='+encodeURIComponent(_0xd21384));return _0x48f7b0['length']?'&'+_0x48f7b0['join']('&'):'';}function Ct(_0xe48df1){const _0x3e69b8={};return _0xe48df1['replace'](/^\?/,'')['split']('&')['forEach'](_0x34da2d=>{if(_0x34da2d){const [_0x2c8833,_0x27abe1]=_0x34da2d['split']('=');_0x3e69b8[decodeURIComponent(_0x2c8833)]=decodeURIComponent(_0x27abe1);}}),_0x3e69b8;}function Tt(_0x5183fa){const _0x34457a=_0x5183fa['indexOf']('?');if(!_0x34457a)return'';const _0x5c193d=_0x5183fa['indexOf']('#',_0x34457a);return _0x5183fa['substring'](_0x34457a,_0x5c193d>0x0?_0x5c193d:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2cd85a=0x1;_0x2cd85a<this['blockSize'];++_0x2cd85a)this['pad_'][_0x2cd85a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x26d104,_0x5a14ac){_0x5a14ac||(_0x5a14ac=0x0);const _0x1062af=this['W_'];if(typeof _0x26d104=='string'){for(let _0x647053=0x0;_0x647053<0x10;_0x647053++)_0x1062af[_0x647053]=_0x26d104['charCodeAt'](_0x5a14ac)<<0x18|_0x26d104['charCodeAt'](_0x5a14ac+0x1)<<0x10|_0x26d104['charCodeAt'](_0x5a14ac+0x2)<<0x8|_0x26d104['charCodeAt'](_0x5a14ac+0x3),_0x5a14ac+=0x4;}else{for(let _0x417c15=0x0;_0x417c15<0x10;_0x417c15++)_0x1062af[_0x417c15]=_0x26d104[_0x5a14ac]<<0x18|_0x26d104[_0x5a14ac+0x1]<<0x10|_0x26d104[_0x5a14ac+0x2]<<0x8|_0x26d104[_0x5a14ac+0x3],_0x5a14ac+=0x4;}for(let _0x957c90=0x10;_0x957c90<0x50;_0x957c90++){const _0x258a45=_0x1062af[_0x957c90-0x3]^_0x1062af[_0x957c90-0x8]^_0x1062af[_0x957c90-0xe]^_0x1062af[_0x957c90-0x10];_0x1062af[_0x957c90]=(_0x258a45<<0x1|_0x258a45>>>0x1f)&0xffffffff;}let _0x2ee1ef=this['chain_'][0x0],_0x5b0122=this['chain_'][0x1],_0x34ceb8=this['chain_'][0x2],_0xf9e7af=this['chain_'][0x3],_0x5e4356=this['chain_'][0x4],_0x50f77d,_0x55bd21;for(let _0xbd93b3=0x0;_0xbd93b3<0x50;_0xbd93b3++){_0xbd93b3<0x28?_0xbd93b3<0x14?(_0x50f77d=_0xf9e7af^_0x5b0122&(_0x34ceb8^_0xf9e7af),_0x55bd21=0x5a827999):(_0x50f77d=_0x5b0122^_0x34ceb8^_0xf9e7af,_0x55bd21=0x6ed9eba1):_0xbd93b3<0x3c?(_0x50f77d=_0x5b0122&_0x34ceb8|_0xf9e7af&(_0x5b0122|_0x34ceb8),_0x55bd21=0x8f1bbcdc):(_0x50f77d=_0x5b0122^_0x34ceb8^_0xf9e7af,_0x55bd21=0xca62c1d6);const _0x43b95d=(_0x2ee1ef<<0x5|_0x2ee1ef>>>0x1b)+_0x50f77d+_0x5e4356+_0x55bd21+_0x1062af[_0xbd93b3]&0xffffffff;_0x5e4356=_0xf9e7af,_0xf9e7af=_0x34ceb8,_0x34ceb8=(_0x5b0122<<0x1e|_0x5b0122>>>0x2)&0xffffffff,_0x5b0122=_0x2ee1ef,_0x2ee1ef=_0x43b95d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2ee1ef&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5b0122&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x34ceb8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0xf9e7af&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x5e4356&0xffffffff;}['update'](_0x1fde44,_0x11970b){if(_0x1fde44==null)return;_0x11970b===void 0x0&&(_0x11970b=_0x1fde44['length']);const _0x5cfc73=_0x11970b-this['blockSize'];let _0x1e1a93=0x0;const _0x13835b=this['buf_'];let _0xcc8aa4=this['inbuf_'];for(;_0x1e1a93<_0x11970b;){if(_0xcc8aa4===0x0){for(;_0x1e1a93<=_0x5cfc73;)this['compress_'](_0x1fde44,_0x1e1a93),_0x1e1a93+=this['blockSize'];}if(typeof _0x1fde44=='string'){for(;_0x1e1a93<_0x11970b;)if(_0x13835b[_0xcc8aa4]=_0x1fde44['charCodeAt'](_0x1e1a93),++_0xcc8aa4,++_0x1e1a93,_0xcc8aa4===this['blockSize']){this['compress_'](_0x13835b),_0xcc8aa4=0x0;break;}}else{for(;_0x1e1a93<_0x11970b;)if(_0x13835b[_0xcc8aa4]=_0x1fde44[_0x1e1a93],++_0xcc8aa4,++_0x1e1a93,_0xcc8aa4===this['blockSize']){this['compress_'](_0x13835b),_0xcc8aa4=0x0;break;}}}this['inbuf_']=_0xcc8aa4,this['total_']+=_0x11970b;}['digest'](){const _0x400af0=[];let _0x2c473e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x42d108=this['blockSize']-0x1;_0x42d108>=0x38;_0x42d108--)this['buf_'][_0x42d108]=_0x2c473e&0xff,_0x2c473e/=0x100;this['compress_'](this['buf_']);let _0x2045b0=0x0;for(let _0x1040aa=0x0;_0x1040aa<0x5;_0x1040aa++)for(let _0x7cd500=0x18;_0x7cd500>=0x0;_0x7cd500-=0x8)_0x400af0[_0x2045b0]=this['chain_'][_0x1040aa]>>_0x7cd500&0xff,++_0x2045b0;return _0x400af0;}}function Tc(_0x55457c,_0x491c2d){const _0x526876=new Sc(_0x55457c,_0x491c2d);return _0x526876['subscribe']['bind'](_0x526876);}class Sc{constructor(_0x41d5d5,_0x5ef8d6){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x5ef8d6,this['task']['then'](()=>{_0x41d5d5(this);})['catch'](_0x55bb2d=>{this['error'](_0x55bb2d);});}['next'](_0xaeab66){this['forEachObserver'](_0x5a6bd4=>{_0x5a6bd4['next'](_0xaeab66);});}['error'](_0x1a204a){this['forEachObserver'](_0x360cbb=>{_0x360cbb['error'](_0x1a204a);}),this['close'](_0x1a204a);}['complete'](){this['forEachObserver'](_0x130a60=>{_0x130a60['complete']();}),this['close']();}['subscribe'](_0x1f72df,_0x228fa8,_0x2f077e){let _0x3e5b57;if(_0x1f72df===void 0x0&&_0x228fa8===void 0x0&&_0x2f077e===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1f72df,['next','error','complete'])?_0x3e5b57=_0x1f72df:_0x3e5b57={'next':_0x1f72df,'error':_0x228fa8,'complete':_0x2f077e},_0x3e5b57['next']===void 0x0&&(_0x3e5b57['next']=ti),_0x3e5b57['error']===void 0x0&&(_0x3e5b57['error']=ti),_0x3e5b57['complete']===void 0x0&&(_0x3e5b57['complete']=ti);const _0x57c23b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3e5b57['error'](this['finalError']):_0x3e5b57['complete']();}catch{}}),this['observers']['push'](_0x3e5b57),_0x57c23b;}['unsubscribeOne'](_0x4821ac){this['observers']===void 0x0||this['observers'][_0x4821ac]===void 0x0||(delete this['observers'][_0x4821ac],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x198ee1){if(!this['finalized']){for(let _0x5daa33=0x0;_0x5daa33<this['observers']['length'];_0x5daa33++)this['sendOne'](_0x5daa33,_0x198ee1);}}['sendOne'](_0x5e7f73,_0x2d8b07){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5e7f73]!==void 0x0)try{_0x2d8b07(this['observers'][_0x5e7f73]);}catch(_0x180b86){typeof console<'u'&&console['error']&&console['error'](_0x180b86);}});}['close'](_0x3e3bcd){this['finalized']||(this['finalized']=!0x0,_0x3e3bcd!==void 0x0&&(this['finalError']=_0x3e3bcd),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x54ccb7,_0x1ee630){if(typeof _0x54ccb7!='object'||_0x54ccb7===null)return!0x1;for(const _0x461a2b of _0x1ee630)if(_0x461a2b in _0x54ccb7&&typeof _0x54ccb7[_0x461a2b]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x25d3c4,_0x1a186b){return _0x25d3c4+'\x20failed:\x20'+_0x1a186b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x58199e){const _0x9084ca=[];let _0x55fafb=0x0;for(let _0x36364b=0x0;_0x36364b<_0x58199e['length'];_0x36364b++){let _0x4fb9a3=_0x58199e['charCodeAt'](_0x36364b);if(_0x4fb9a3>=0xd800&&_0x4fb9a3<=0xdbff){const _0x3c8fe7=_0x4fb9a3-0xd800;_0x36364b++,f(_0x36364b<_0x58199e['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2be33c=_0x58199e['charCodeAt'](_0x36364b)-0xdc00;_0x4fb9a3=0x10000+(_0x3c8fe7<<0xa)+_0x2be33c;}_0x4fb9a3<0x80?_0x9084ca[_0x55fafb++]=_0x4fb9a3:_0x4fb9a3<0x800?(_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0x6|0xc0,_0x9084ca[_0x55fafb++]=_0x4fb9a3&0x3f|0x80):_0x4fb9a3<0x10000?(_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0xc|0xe0,_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0x6&0x3f|0x80,_0x9084ca[_0x55fafb++]=_0x4fb9a3&0x3f|0x80):(_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0x12|0xf0,_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0xc&0x3f|0x80,_0x9084ca[_0x55fafb++]=_0x4fb9a3>>0x6&0x3f|0x80,_0x9084ca[_0x55fafb++]=_0x4fb9a3&0x3f|0x80);}return _0x9084ca;},Ln=function(_0x486ed0){let _0x103298=0x0;for(let _0x59e617=0x0;_0x59e617<_0x486ed0['length'];_0x59e617++){const _0x831c06=_0x486ed0['charCodeAt'](_0x59e617);_0x831c06<0x80?_0x103298++:_0x831c06<0x800?_0x103298+=0x2:_0x831c06>=0xd800&&_0x831c06<=0xdbff?(_0x103298+=0x4,_0x59e617++):_0x103298+=0x3;}return _0x103298;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x68a540){return _0x68a540&&_0x68a540['_delegate']?_0x68a540['_delegate']:_0x68a540;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x517d45){try{return(_0x517d45['startsWith']('http://')||_0x517d45['startsWith']('https://')?new URL(_0x517d45)['hostname']:_0x517d45)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x11fb80){return(await fetch(_0x11fb80,{'credentials':'include'}))['ok'];}class Fe{constructor(_0xdbfaad,_0x417aae,_0x43d30e){this['name']=_0xdbfaad,this['instanceFactory']=_0x417aae,this['type']=_0x43d30e,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3afdcc){return this['instantiationMode']=_0x3afdcc,this;}['setMultipleInstances'](_0x118d21){return this['multipleInstances']=_0x118d21,this;}['setServiceProps'](_0x5d8408){return this['serviceProps']=_0x5d8408,this;}['setInstanceCreatedCallback'](_0x339f74){return this['onInstanceCreated']=_0x339f74,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3c0999,_0x259101){this['name']=_0x3c0999,this['container']=_0x259101,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x59dc38){const _0x2a5db1=this['normalizeInstanceIdentifier'](_0x59dc38);if(!this['instancesDeferred']['has'](_0x2a5db1)){const _0x279a60=new H();if(this['instancesDeferred']['set'](_0x2a5db1,_0x279a60),this['isInitialized'](_0x2a5db1)||this['shouldAutoInitialize']())try{const _0x2af62d=this['getOrInitializeService']({'instanceIdentifier':_0x2a5db1});_0x2af62d&&_0x279a60['resolve'](_0x2af62d);}catch{}}return this['instancesDeferred']['get'](_0x2a5db1)['promise'];}['getImmediate'](_0x1f26dc){const _0x31c5a5=this['normalizeInstanceIdentifier'](_0x1f26dc==null?void 0x0:_0x1f26dc['identifier']),_0x265b58=(_0x1f26dc==null?void 0x0:_0x1f26dc['optional'])??!0x1;if(this['isInitialized'](_0x31c5a5)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x31c5a5});}catch(_0x4dcdb3){if(_0x265b58)return null;throw _0x4dcdb3;}else{if(_0x265b58)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x30b0af){if(_0x30b0af['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x30b0af['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x30b0af,!!this['shouldAutoInitialize']()){if(Pc(_0x30b0af))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0xfa30f8,_0x5b1548]of this['instancesDeferred']['entries']()){const _0x539370=this['normalizeInstanceIdentifier'](_0xfa30f8);try{const _0xb63815=this['getOrInitializeService']({'instanceIdentifier':_0x539370});_0x5b1548['resolve'](_0xb63815);}catch{}}}}['clearInstance'](_0x2f3ae4=Ne){this['instancesDeferred']['delete'](_0x2f3ae4),this['instancesOptions']['delete'](_0x2f3ae4),this['instances']['delete'](_0x2f3ae4);}async['delete'](){const _0x22f43b=Array['from'](this['instances']['values']());await Promise['all']([..._0x22f43b['filter'](_0x47ca0e=>'INTERNAL'in _0x47ca0e)['map'](_0x2196d6=>_0x2196d6['INTERNAL']['delete']()),..._0x22f43b['filter'](_0x718bd5=>'_delete'in _0x718bd5)['map'](_0x4e4ca5=>_0x4e4ca5['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2ace9d=Ne){return this['instances']['has'](_0x2ace9d);}['getOptions'](_0x4f393a=Ne){return this['instancesOptions']['get'](_0x4f393a)||{};}['initialize'](_0x14c236={}){const {options:_0x303f51={}}=_0x14c236,_0x124086=this['normalizeInstanceIdentifier'](_0x14c236['instanceIdentifier']);if(this['isInitialized'](_0x124086))throw Error(this['name']+'('+_0x124086+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3b3e22=this['getOrInitializeService']({'instanceIdentifier':_0x124086,'options':_0x303f51});for(const [_0x671aa,_0x2894ff]of this['instancesDeferred']['entries']()){const _0xcac007=this['normalizeInstanceIdentifier'](_0x671aa);_0x124086===_0xcac007&&_0x2894ff['resolve'](_0x3b3e22);}return _0x3b3e22;}['onInit'](_0x61382b,_0x58679a){const _0x127004=this['normalizeInstanceIdentifier'](_0x58679a),_0x595ccc=this['onInitCallbacks']['get'](_0x127004)??new Set();_0x595ccc['add'](_0x61382b),this['onInitCallbacks']['set'](_0x127004,_0x595ccc);const _0x42d50a=this['instances']['get'](_0x127004);return _0x42d50a&&_0x61382b(_0x42d50a,_0x127004),()=>{_0x595ccc['delete'](_0x61382b);};}['invokeOnInitCallbacks'](_0x2c4f4e,_0x14db0f){const _0xe32b4a=this['onInitCallbacks']['get'](_0x14db0f);if(_0xe32b4a){for(const _0x3c4d2c of _0xe32b4a)try{_0x3c4d2c(_0x2c4f4e,_0x14db0f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5a580d,options:_0x2d9538={}}){let _0x1a6d51=this['instances']['get'](_0x5a580d);if(!_0x1a6d51&&this['component']&&(_0x1a6d51=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5a580d),'options':_0x2d9538}),this['instances']['set'](_0x5a580d,_0x1a6d51),this['instancesOptions']['set'](_0x5a580d,_0x2d9538),this['invokeOnInitCallbacks'](_0x1a6d51,_0x5a580d),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5a580d,_0x1a6d51);}catch{}return _0x1a6d51||null;}['normalizeInstanceIdentifier'](_0x409dc1=Ne){return this['component']?this['component']['multipleInstances']?_0x409dc1:Ne:_0x409dc1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x45e7d3){return _0x45e7d3===Ne?void 0x0:_0x45e7d3;}function Pc(_0x3acae3){return _0x3acae3['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x16d2a7){this['name']=_0x16d2a7,this['providers']=new Map();}['addComponent'](_0x3ac9d9){const _0x4bd524=this['getProvider'](_0x3ac9d9['name']);if(_0x4bd524['isComponentSet']())throw new Error('Component\x20'+_0x3ac9d9['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4bd524['setComponent'](_0x3ac9d9);}['addOrOverwriteComponent'](_0x3886bb){this['getProvider'](_0x3886bb['name'])['isComponentSet']()&&this['providers']['delete'](_0x3886bb['name']),this['addComponent'](_0x3886bb);}['getProvider'](_0x364fad){if(this['providers']['has'](_0x364fad))return this['providers']['get'](_0x364fad);const _0x1fe8e2=new Ac(_0x364fad,this);return this['providers']['set'](_0x364fad,_0x1fe8e2),_0x1fe8e2;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x4869c6){_0x4869c6[_0x4869c6['DEBUG']=0x0]='DEBUG',_0x4869c6[_0x4869c6['VERBOSE']=0x1]='VERBOSE',_0x4869c6[_0x4869c6['INFO']=0x2]='INFO',_0x4869c6[_0x4869c6['WARN']=0x3]='WARN',_0x4869c6[_0x4869c6['ERROR']=0x4]='ERROR',_0x4869c6[_0x4869c6['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x1ed59b,_0x2b882,..._0x25f448)=>{if(_0x2b882<_0x1ed59b['logLevel'])return;const _0x91009=new Date()['toISOString'](),_0x5b00d5=Mc[_0x2b882];if(_0x5b00d5)console[_0x5b00d5]('['+_0x91009+']\x20\x20'+_0x1ed59b['name']+':',..._0x25f448);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2b882+')');};class Bi{constructor(_0x1b4e00){this['name']=_0x1b4e00,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3c759c){if(!(_0x3c759c in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3c759c+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3c759c;}['setLogLevel'](_0x30b736){this['_logLevel']=typeof _0x30b736=='string'?Oc[_0x30b736]:_0x30b736;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1cd224){if(typeof _0x1cd224!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1cd224;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x584217){this['_userLogHandler']=_0x584217;}['debug'](..._0x55dca8){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x55dca8),this['_logHandler'](this,T['DEBUG'],..._0x55dca8);}['log'](..._0x331c14){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x331c14),this['_logHandler'](this,T['VERBOSE'],..._0x331c14);}['info'](..._0x50bcbf){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x50bcbf),this['_logHandler'](this,T['INFO'],..._0x50bcbf);}['warn'](..._0x5019b){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x5019b),this['_logHandler'](this,T['WARN'],..._0x5019b);}['error'](..._0x546844){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x546844),this['_logHandler'](this,T['ERROR'],..._0x546844);}}const xc=(_0x51f70f,_0x2fc07)=>_0x2fc07['some'](_0x5b16c3=>_0x51f70f instanceof _0x5b16c3);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x744d6a){const _0x16d04f=new Promise((_0x279698,_0x11d4b2)=>{const _0x5db439=()=>{_0x744d6a['removeEventListener']('success',_0x28eaca),_0x744d6a['removeEventListener']('error',_0x297e10);},_0x28eaca=()=>{_0x279698(ge(_0x744d6a['result'])),_0x5db439();},_0x297e10=()=>{_0x11d4b2(_0x744d6a['error']),_0x5db439();};_0x744d6a['addEventListener']('success',_0x28eaca),_0x744d6a['addEventListener']('error',_0x297e10);});return _0x16d04f['then'](_0x457446=>{_0x457446 instanceof IDBCursor&&Jr['set'](_0x457446,_0x744d6a);})['catch'](()=>{}),Vi['set'](_0x16d04f,_0x744d6a),_0x16d04f;}function Bc(_0x10f9c3){if(_i['has'](_0x10f9c3))return;const _0x46461e=new Promise((_0x1f5003,_0x270b02)=>{const _0x207551=()=>{_0x10f9c3['removeEventListener']('complete',_0x4a9cda),_0x10f9c3['removeEventListener']('error',_0xdec05d),_0x10f9c3['removeEventListener']('abort',_0xdec05d);},_0x4a9cda=()=>{_0x1f5003(),_0x207551();},_0xdec05d=()=>{_0x270b02(_0x10f9c3['error']||new DOMException('AbortError','AbortError')),_0x207551();};_0x10f9c3['addEventListener']('complete',_0x4a9cda),_0x10f9c3['addEventListener']('error',_0xdec05d),_0x10f9c3['addEventListener']('abort',_0xdec05d);});_i['set'](_0x10f9c3,_0x46461e);}let gi={'get'(_0x1640fd,_0xd20c86,_0x4a71f4){if(_0x1640fd instanceof IDBTransaction){if(_0xd20c86==='done')return _i['get'](_0x1640fd);if(_0xd20c86==='objectStoreNames')return _0x1640fd['objectStoreNames']||Xr['get'](_0x1640fd);if(_0xd20c86==='store')return _0x4a71f4['objectStoreNames'][0x1]?void 0x0:_0x4a71f4['objectStore'](_0x4a71f4['objectStoreNames'][0x0]);}return ge(_0x1640fd[_0xd20c86]);},'set'(_0x458d98,_0x48782e,_0x3ccbb6){return _0x458d98[_0x48782e]=_0x3ccbb6,!0x0;},'has'(_0x28a44d,_0x2fdb21){return _0x28a44d instanceof IDBTransaction&&(_0x2fdb21==='done'||_0x2fdb21==='store')?!0x0:_0x2fdb21 in _0x28a44d;}};function Vc(_0x4691bd){gi=_0x4691bd(gi);}function Hc(_0x466585){return _0x466585===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3ac7b9,..._0x41515a){const _0x4f5816=_0x466585['call'](ii(this),_0x3ac7b9,..._0x41515a);return Xr['set'](_0x4f5816,_0x3ac7b9['sort']?_0x3ac7b9['sort']():[_0x3ac7b9]),ge(_0x4f5816);}:Uc()['includes'](_0x466585)?function(..._0x30cfd3){return _0x466585['apply'](ii(this),_0x30cfd3),ge(Jr['get'](this));}:function(..._0x461e0a){return ge(_0x466585['apply'](ii(this),_0x461e0a));};}function $c(_0x17c929){return typeof _0x17c929=='function'?Hc(_0x17c929):(_0x17c929 instanceof IDBTransaction&&Bc(_0x17c929),xc(_0x17c929,Fc())?new Proxy(_0x17c929,gi):_0x17c929);}function ge(_0x1deb28){if(_0x1deb28 instanceof IDBRequest)return Wc(_0x1deb28);if(ni['has'](_0x1deb28))return ni['get'](_0x1deb28);const _0x289c5d=$c(_0x1deb28);return _0x289c5d!==_0x1deb28&&(ni['set'](_0x1deb28,_0x289c5d),Vi['set'](_0x289c5d,_0x1deb28)),_0x289c5d;}const ii=_0xf93a6=>Vi['get'](_0xf93a6);function Gc(_0x26c6c8,_0x820d17,{blocked:_0x17f112,upgrade:_0x3e6950,blocking:_0x46ddaf,terminated:_0x5d7e7a}={}){const _0x316f6d=indexedDB['open'](_0x26c6c8,_0x820d17),_0xfd1bf2=ge(_0x316f6d);return _0x3e6950&&_0x316f6d['addEventListener']('upgradeneeded',_0xfaf8f4=>{_0x3e6950(ge(_0x316f6d['result']),_0xfaf8f4['oldVersion'],_0xfaf8f4['newVersion'],ge(_0x316f6d['transaction']),_0xfaf8f4);}),_0x17f112&&_0x316f6d['addEventListener']('blocked',_0x38ed63=>_0x17f112(_0x38ed63['oldVersion'],_0x38ed63['newVersion'],_0x38ed63)),_0xfd1bf2['then'](_0x1e78cb=>{_0x5d7e7a&&_0x1e78cb['addEventListener']('close',()=>_0x5d7e7a()),_0x46ddaf&&_0x1e78cb['addEventListener']('versionchange',_0x886210=>_0x46ddaf(_0x886210['oldVersion'],_0x886210['newVersion'],_0x886210));})['catch'](()=>{}),_0xfd1bf2;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x1a80de,_0x5ebc34){if(!(_0x1a80de instanceof IDBDatabase&&!(_0x5ebc34 in _0x1a80de)&&typeof _0x5ebc34=='string'))return;if(si['get'](_0x5ebc34))return si['get'](_0x5ebc34);const _0x1d306a=_0x5ebc34['replace'](/FromIndex$/,''),_0x19dbe5=_0x5ebc34!==_0x1d306a,_0x58b4c0=zc['includes'](_0x1d306a);if(!(_0x1d306a in(_0x19dbe5?IDBIndex:IDBObjectStore)['prototype'])||!(_0x58b4c0||qc['includes'](_0x1d306a)))return;const _0x17d8a2=async function(_0x1bc935,..._0x5d89a9){const _0x1ca3a3=this['transaction'](_0x1bc935,_0x58b4c0?'readwrite':'readonly');let _0x5e6072=_0x1ca3a3['store'];return _0x19dbe5&&(_0x5e6072=_0x5e6072['index'](_0x5d89a9['shift']())),(await Promise['all']([_0x5e6072[_0x1d306a](..._0x5d89a9),_0x58b4c0&&_0x1ca3a3['done']]))[0x0];};return si['set'](_0x5ebc34,_0x17d8a2),_0x17d8a2;}Vc(_0x5b6727=>({..._0x5b6727,'get':(_0x55aca2,_0x1c59b1,_0xc6edc)=>Ms(_0x55aca2,_0x1c59b1)||_0x5b6727['get'](_0x55aca2,_0x1c59b1,_0xc6edc),'has':(_0x135769,_0x3b5313)=>!!Ms(_0x135769,_0x3b5313)||_0x5b6727['has'](_0x135769,_0x3b5313)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4ae578){this['container']=_0x4ae578;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2b0d81=>{if(Kc(_0x2b0d81)){const _0x15f60f=_0x2b0d81['getImmediate']();return _0x15f60f['library']+'/'+_0x15f60f['version'];}else return null;})['filter'](_0x12a3fd=>_0x12a3fd)['join']('\x20');}}function Kc(_0x5cb33f){const _0x25e8df=_0x5cb33f['getComponent']();return(_0x25e8df==null?void 0x0:_0x25e8df['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2892a7,_0x1bc327){try{_0x2892a7['container']['addComponent'](_0x1bc327);}catch(_0x7d2616){oe['debug']('Component\x20'+_0x1bc327['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2892a7['name'],_0x7d2616);}}function st(_0x53b918){const _0xff1c68=_0x53b918['name'];if(Ei['has'](_0xff1c68))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xff1c68+'.'),!0x1;Ei['set'](_0xff1c68,_0x53b918);for(const _0x2d11c8 of Ue['values']())xs(_0x2d11c8,_0x53b918);for(const _0x28a629 of vi['values']())xs(_0x28a629,_0x53b918);return!0x0;}function Hi(_0x299d4c,_0x1d772a){const _0x4f6313=_0x299d4c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4f6313&&_0x4f6313['triggerHeartbeat'](),_0x299d4c['container']['getProvider'](_0x1d772a);}function $(_0x5a8acb){return _0x5a8acb==null?!0x1:_0x5a8acb['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x33f1a2,_0x35782d,_0x26a778){this['_isDeleted']=!0x1,this['_options']={..._0x33f1a2},this['_config']={..._0x35782d},this['_name']=_0x35782d['name'],this['_automaticDataCollectionEnabled']=_0x35782d['automaticDataCollectionEnabled'],this['_container']=_0x26a778,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x43e24a){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x43e24a;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x3a7cd1){this['_isDeleted']=_0x3a7cd1;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x424191,_0x11af18={}){let _0x29cf30=_0x424191;typeof _0x11af18!='object'&&(_0x11af18={'name':_0x11af18});const _0x12652e={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x11af18},_0x5291c5=_0x12652e['name'];if(typeof _0x5291c5!='string'||!_0x5291c5)throw me['create']('bad-app-name',{'appName':String(_0x5291c5)});if(_0x29cf30||(_0x29cf30=zr()),!_0x29cf30)throw me['create']('no-options');const _0x3c6d54=Ue['get'](_0x5291c5);if(_0x3c6d54){if(xe(_0x29cf30,_0x3c6d54['options'])&&xe(_0x12652e,_0x3c6d54['config']))return _0x3c6d54;throw me['create']('duplicate-app',{'appName':_0x5291c5});}const _0x50c2d6=new Nc(_0x5291c5);for(const _0x3c6446 of Ei['values']())_0x50c2d6['addComponent'](_0x3c6446);const _0x2720cd=new Tl(_0x29cf30,_0x12652e,_0x50c2d6);return Ue['set'](_0x5291c5,_0x2720cd),_0x2720cd;}function Zr(_0x26348a=yi){const _0x1343b7=Ue['get'](_0x26348a);if(!_0x1343b7&&_0x26348a===yi&&zr())return Sl();if(!_0x1343b7)throw me['create']('no-app',{'appName':_0x26348a});return _0x1343b7;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x1f4bf4){let _0x532c15=!0x1;const _0x1142f1=_0x1f4bf4['name'];Ue['has'](_0x1142f1)?(_0x532c15=!0x0,Ue['delete'](_0x1142f1)):vi['has'](_0x1142f1)&&_0x1f4bf4['decRefCount']()<=0x0&&(vi['delete'](_0x1142f1),_0x532c15=!0x0),_0x532c15&&(await Promise['all'](_0x1f4bf4['container']['getProviders']()['map'](_0x2e01b3=>_0x2e01b3['delete']())),_0x1f4bf4['isDeleted']=!0x0);}function ye(_0x37dc15,_0x37cf2f,_0x559113){let _0xbf5dfe=wl[_0x37dc15]??_0x37dc15;_0x559113&&(_0xbf5dfe+='-'+_0x559113);const _0x66da9a=_0xbf5dfe['match'](/\s|\//),_0x257be1=_0x37cf2f['match'](/\s|\//);if(_0x66da9a||_0x257be1){const _0x24d2d0=['Unable\x20to\x20register\x20library\x20\x22'+_0xbf5dfe+'\x22\x20with\x20version\x20\x22'+_0x37cf2f+'\x22:'];_0x66da9a&&_0x24d2d0['push']('library\x20name\x20\x22'+_0xbf5dfe+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x66da9a&&_0x257be1&&_0x24d2d0['push']('and'),_0x257be1&&_0x24d2d0['push']('version\x20name\x20\x22'+_0x37cf2f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x24d2d0['join']('\x20'));return;}st(new Fe(_0xbf5dfe+'-version',()=>({'library':_0xbf5dfe,'version':_0x37cf2f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1a94bf,_0x4f5d1f)=>{switch(_0x4f5d1f){case 0x0:try{_0x1a94bf['createObjectStore'](Ot);}catch(_0x104c0c){console['warn'](_0x104c0c);}}}})['catch'](_0xa8abc9=>{throw me['create']('idb-open',{'originalErrorMessage':_0xa8abc9['message']});})),ri;}async function Al(_0x31583b){try{const _0x2596e1=(await eo())['transaction'](Ot),_0x30fa0e=await _0x2596e1['objectStore'](Ot)['get'](to(_0x31583b));return await _0x2596e1['done'],_0x30fa0e;}catch(_0x2cbd21){if(_0x2cbd21 instanceof Re)oe['warn'](_0x2cbd21['message']);else{const _0xfdb45b=me['create']('idb-get',{'originalErrorMessage':_0x2cbd21==null?void 0x0:_0x2cbd21['message']});oe['warn'](_0xfdb45b['message']);}}}async function Fs(_0x582f50,_0x147c98){try{const _0x2a1f03=(await eo())['transaction'](Ot,'readwrite');await _0x2a1f03['objectStore'](Ot)['put'](_0x147c98,to(_0x582f50)),await _0x2a1f03['done'];}catch(_0x436ad5){if(_0x436ad5 instanceof Re)oe['warn'](_0x436ad5['message']);else{const _0x5deeae=me['create']('idb-set',{'originalErrorMessage':_0x436ad5==null?void 0x0:_0x436ad5['message']});oe['warn'](_0x5deeae['message']);}}}function to(_0x1bc4a7){return _0x1bc4a7['name']+'!'+_0x1bc4a7['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x1761c3){this['container']=_0x1761c3,this['_heartbeatsCache']=null;const _0xdcb100=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0xdcb100),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5458fe=>(this['_heartbeatsCache']=_0x5458fe,_0x5458fe));}async['triggerHeartbeat'](){var _0x3148b2,_0x227623;try{const _0x5ac614=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x219cb2=Us();if(((_0x3148b2=this['_heartbeatsCache'])==null?void 0x0:_0x3148b2['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x227623=this['_heartbeatsCache'])==null?void 0x0:_0x227623['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x219cb2||this['_heartbeatsCache']['heartbeats']['some'](_0x401222=>_0x401222['date']===_0x219cb2))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x219cb2,'agent':_0x5ac614}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x28682a=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x28682a,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x1653ad){oe['warn'](_0x1653ad);}}async['getHeartbeatsHeader'](){var _0x3e3fc3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3e3fc3=this['_heartbeatsCache'])==null?void 0x0:_0x3e3fc3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x40924a=Us(),{heartbeatsToSend:_0x4cddc4,unsentEntries:_0x53c8e5}=Ol(this['_heartbeatsCache']['heartbeats']),_0x5561a3=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4cddc4}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x40924a,_0x53c8e5['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x53c8e5,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5561a3;}catch(_0x1556e8){return oe['warn'](_0x1556e8),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x504aee,_0xe9592a=kl){const _0xca7b80=[];let _0x5c5859=_0x504aee['slice']();for(const _0x43c395 of _0x504aee){const _0xf3853f=_0xca7b80['find'](_0x3a13be=>_0x3a13be['agent']===_0x43c395['agent']);if(_0xf3853f){if(_0xf3853f['dates']['push'](_0x43c395['date']),Ws(_0xca7b80)>_0xe9592a){_0xf3853f['dates']['pop']();break;}}else{if(_0xca7b80['push']({'agent':_0x43c395['agent'],'dates':[_0x43c395['date']]}),Ws(_0xca7b80)>_0xe9592a){_0xca7b80['pop']();break;}}_0x5c5859=_0x5c5859['slice'](0x1);}return{'heartbeatsToSend':_0xca7b80,'unsentEntries':_0x5c5859};}class Dl{constructor(_0x4f530d){this['app']=_0x4f530d,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2fbaa1=await Al(this['app']);return _0x2fbaa1!=null&&_0x2fbaa1['heartbeats']?_0x2fbaa1:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x284951){if(await this['_canUseIndexedDBPromise']){const _0x5f3bf4=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x284951['lastSentHeartbeatDate']??_0x5f3bf4['lastSentHeartbeatDate'],'heartbeats':_0x284951['heartbeats']});}else return;}async['add'](_0x5ab983){if(await this['_canUseIndexedDBPromise']){const _0x423894=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5ab983['lastSentHeartbeatDate']??_0x423894['lastSentHeartbeatDate'],'heartbeats':[..._0x423894['heartbeats'],..._0x5ab983['heartbeats']]});}else return;}}function Ws(_0x2936fc){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2936fc}))['length'];}function Ml(_0x4b494d){if(_0x4b494d['length']===0x0)return-0x1;let _0x492ace=0x0,_0x431419=_0x4b494d[0x0]['date'];for(let _0x11eae1=0x1;_0x11eae1<_0x4b494d['length'];_0x11eae1++)_0x4b494d[_0x11eae1]['date']<_0x431419&&(_0x431419=_0x4b494d[_0x11eae1]['date'],_0x492ace=_0x11eae1);return _0x492ace;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4e5b7f){st(new Fe('platform-logger',_0x52d345=>new jc(_0x52d345),'PRIVATE')),st(new Fe('heartbeat',_0x2faf59=>new Nl(_0x2faf59),'PRIVATE')),ye(mi,Ls,_0x4e5b7f),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x53734a){no=_0x53734a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1d0928){this['domStorage_']=_0x1d0928,this['prefix_']='firebase:';}['set'](_0x3a18e9,_0x3d5c85){_0x3d5c85==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3a18e9)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3a18e9),O(_0x3d5c85));}['get'](_0x5ba8f8){const _0x844619=this['domStorage_']['getItem'](this['prefixedName_'](_0x5ba8f8));return _0x844619==null?null:Nt(_0x844619);}['remove'](_0x2f04f7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x2f04f7));}['prefixedName_'](_0x2cf8d4){return this['prefix_']+_0x2cf8d4;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4f835c,_0x44950f){_0x44950f==null?delete this['cache_'][_0x4f835c]:this['cache_'][_0x4f835c]=_0x44950f;}['get'](_0x573f5f){return Q(this['cache_'],_0x573f5f)?this['cache_'][_0x573f5f]:null;}['remove'](_0xada97d){delete this['cache_'][_0xada97d];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1a0f84){try{if(typeof window<'u'&&typeof window[_0x1a0f84]<'u'){const _0x126fb7=window[_0x1a0f84];return _0x126fb7['setItem']('firebase:sentinel','cache'),_0x126fb7['removeItem']('firebase:sentinel'),new Wl(_0x126fb7);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4a1540=0x1;return function(){return _0x4a1540++;};}()),ro=function(_0x2e42f7){const _0x2ae5f0=Rc(_0x2e42f7),_0x1a96a9=new Cc();_0x1a96a9['update'](_0x2ae5f0);const _0x1887ec=_0x1a96a9['digest']();return Fi['encodeByteArray'](_0x1887ec);},zt=function(..._0x2e3f00){let _0x2274a2='';for(let _0x389600=0x0;_0x389600<_0x2e3f00['length'];_0x389600++){const _0x29ab02=_0x2e3f00[_0x389600];Array['isArray'](_0x29ab02)||_0x29ab02&&typeof _0x29ab02=='object'&&typeof _0x29ab02['length']=='number'?_0x2274a2+=zt['apply'](null,_0x29ab02):typeof _0x29ab02=='object'?_0x2274a2+=O(_0x29ab02):_0x2274a2+=_0x29ab02,_0x2274a2+='\x20';}return _0x2274a2;};let St=null,$s=!0x0;const Hl=function(_0x33e23c,_0x31ee5f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x191544){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x2672b7=zt['apply'](null,_0x191544);St(_0x2672b7);}},jt=function(_0x57b44e){return function(..._0xcce918){L(_0x57b44e,..._0xcce918);};},Ii=function(..._0xd6a753){const _0xdf4aae='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0xd6a753);Ze['error'](_0xdf4aae);},ae=function(..._0xe59b31){const _0x11d322='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0xe59b31);throw Ze['error'](_0x11d322),new Error(_0x11d322);},U=function(..._0x76e721){const _0x225dcb='FIREBASE\x20WARNING:\x20'+zt(..._0x76e721);Ze['warn'](_0x225dcb);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x8086bc){return typeof _0x8086bc=='number'&&(_0x8086bc!==_0x8086bc||_0x8086bc===Number['POSITIVE_INFINITY']||_0x8086bc===Number['NEGATIVE_INFINITY']);},Gl=function(_0x92457f){if(document['readyState']==='complete')_0x92457f();else{let _0x40eee5=!0x1;const _0x3db051=function(){if(!document['body']){setTimeout(_0x3db051,Math['floor'](0xa));return;}_0x40eee5||(_0x40eee5=!0x0,_0x92457f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3db051,!0x1),window['addEventListener']('load',_0x3db051,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3db051();}),window['attachEvent']('onload',_0x3db051));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x3b25bd,_0x3bc40d){if(_0x3b25bd===_0x3bc40d)return 0x0;if(_0x3b25bd===We||_0x3bc40d===we)return-0x1;if(_0x3bc40d===We||_0x3b25bd===we)return 0x1;{const _0x285fee=Gs(_0x3b25bd),_0x2456c4=Gs(_0x3bc40d);return _0x285fee!==null?_0x2456c4!==null?_0x285fee-_0x2456c4===0x0?_0x3b25bd['length']-_0x3bc40d['length']:_0x285fee-_0x2456c4:-0x1:_0x2456c4!==null?0x1:_0x3b25bd<_0x3bc40d?-0x1:0x1;}},ql=function(_0x528fc3,_0x5cbd01){return _0x528fc3===_0x5cbd01?0x0:_0x528fc3<_0x5cbd01?-0x1:0x1;},vt=function(_0x226652,_0x33dc23){if(_0x33dc23&&_0x226652 in _0x33dc23)return _0x33dc23[_0x226652];throw new Error('Missing\x20required\x20key\x20('+_0x226652+')\x20in\x20object:\x20'+O(_0x33dc23));},$i=function(_0xda9eb9){if(typeof _0xda9eb9!='object'||_0xda9eb9===null)return O(_0xda9eb9);const _0x1b63d4=[];for(const _0x1e57cf in _0xda9eb9)_0x1b63d4['push'](_0x1e57cf);_0x1b63d4['sort']();let _0x91de55='{';for(let _0x1728fc=0x0;_0x1728fc<_0x1b63d4['length'];_0x1728fc++)_0x1728fc!==0x0&&(_0x91de55+=','),_0x91de55+=O(_0x1b63d4[_0x1728fc]),_0x91de55+=':',_0x91de55+=$i(_0xda9eb9[_0x1b63d4[_0x1728fc]]);return _0x91de55+='}',_0x91de55;},oo=function(_0x26515b,_0x19293a){const _0x56bf93=_0x26515b['length'];if(_0x56bf93<=_0x19293a)return[_0x26515b];const _0x4006e8=[];for(let _0x4659ba=0x0;_0x4659ba<_0x56bf93;_0x4659ba+=_0x19293a)_0x4659ba+_0x19293a>_0x56bf93?_0x4006e8['push'](_0x26515b['substring'](_0x4659ba,_0x56bf93)):_0x4006e8['push'](_0x26515b['substring'](_0x4659ba,_0x4659ba+_0x19293a));return _0x4006e8;};function x(_0x793cdb,_0x53f117){for(const _0x2495fa in _0x793cdb)_0x793cdb['hasOwnProperty'](_0x2495fa)&&_0x53f117(_0x2495fa,_0x793cdb[_0x2495fa]);}const ao=function(_0x5b270f){f(!xn(_0x5b270f),'Invalid\x20JSON\x20number');const _0x10ce9f=0xb,_0x11a3db=0x34,_0x250cff=(0x1<<_0x10ce9f-0x1)-0x1;let _0x5529c9,_0xf9bddb,_0x54b868,_0x4791f8,_0x38be8f;_0x5b270f===0x0?(_0xf9bddb=0x0,_0x54b868=0x0,_0x5529c9=0x1/_0x5b270f===-0x1/0x0?0x1:0x0):(_0x5529c9=_0x5b270f<0x0,_0x5b270f=Math['abs'](_0x5b270f),_0x5b270f>=Math['pow'](0x2,0x1-_0x250cff)?(_0x4791f8=Math['min'](Math['floor'](Math['log'](_0x5b270f)/Math['LN2']),_0x250cff),_0xf9bddb=_0x4791f8+_0x250cff,_0x54b868=Math['round'](_0x5b270f*Math['pow'](0x2,_0x11a3db-_0x4791f8)-Math['pow'](0x2,_0x11a3db))):(_0xf9bddb=0x0,_0x54b868=Math['round'](_0x5b270f/Math['pow'](0x2,0x1-_0x250cff-_0x11a3db))));const _0x1b1fe3=[];for(_0x38be8f=_0x11a3db;_0x38be8f;_0x38be8f-=0x1)_0x1b1fe3['push'](_0x54b868%0x2?0x1:0x0),_0x54b868=Math['floor'](_0x54b868/0x2);for(_0x38be8f=_0x10ce9f;_0x38be8f;_0x38be8f-=0x1)_0x1b1fe3['push'](_0xf9bddb%0x2?0x1:0x0),_0xf9bddb=Math['floor'](_0xf9bddb/0x2);_0x1b1fe3['push'](_0x5529c9?0x1:0x0),_0x1b1fe3['reverse']();const _0x534a27=_0x1b1fe3['join']('');let _0x16a73d='';for(_0x38be8f=0x0;_0x38be8f<0x40;_0x38be8f+=0x8){let _0x40449b=parseInt(_0x534a27['substr'](_0x38be8f,0x8),0x2)['toString'](0x10);_0x40449b['length']===0x1&&(_0x40449b='0'+_0x40449b),_0x16a73d=_0x16a73d+_0x40449b;}return _0x16a73d['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x297b14,_0x2e101a){let _0x251da0='Unknown\x20Error';_0x297b14==='too_big'?_0x251da0='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x297b14==='permission_denied'?_0x251da0='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x297b14==='unavailable'&&(_0x251da0='The\x20service\x20is\x20unavailable');const _0x4184e8=new Error(_0x297b14+'\x20at\x20'+_0x2e101a['_path']['toString']()+':\x20'+_0x251da0);return _0x4184e8['code']=_0x297b14['toUpperCase'](),_0x4184e8;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x410adc){if(Yl['test'](_0x410adc)){const _0xc39d9f=Number(_0x410adc);if(_0xc39d9f>=Ql&&_0xc39d9f<=Jl)return _0xc39d9f;}return null;},ft=function(_0x169f5a){try{_0x169f5a();}catch(_0x13d908){setTimeout(()=>{const _0x3e3023=_0x13d908['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x3e3023),_0x13d908;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x99814,_0x47b306){const _0x52809e=setTimeout(_0x99814,_0x47b306);return typeof _0x52809e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x52809e):typeof _0x52809e=='object'&&_0x52809e['unref']&&_0x52809e['unref'](),_0x52809e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x539c05,_0x227d4f){this['appCheckProvider']=_0x227d4f,this['appName']=_0x539c05['name'],$(_0x539c05)&&_0x539c05['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x539c05['settings']['appCheckToken']),this['appCheck']=_0x227d4f==null?void 0x0:_0x227d4f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x227d4f==null||_0x227d4f['get']()['then'](_0x264538=>this['appCheck']=_0x264538);}['getToken'](_0x29c8d7){if(this['serverAppAppCheckToken']){if(_0x29c8d7)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x29c8d7):new Promise((_0x4ec651,_0x266b10)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x29c8d7)['then'](_0x4ec651,_0x266b10):_0x4ec651(null);},0x0);});}['addTokenChangeListener'](_0x194f61){var _0x6e79f7;(_0x6e79f7=this['appCheckProvider'])==null||_0x6e79f7['get']()['then'](_0x47d172=>_0x47d172['addTokenListener'](_0x194f61));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xa1e397,_0x14fed1,_0x666350){this['appName_']=_0xa1e397,this['firebaseOptions_']=_0x14fed1,this['authProvider_']=_0x666350,this['auth_']=null,this['auth_']=_0x666350['getImmediate']({'optional':!0x0}),this['auth_']||_0x666350['onInit'](_0x5cd32c=>this['auth_']=_0x5cd32c);}['getToken'](_0x279490){return this['auth_']?this['auth_']['getToken'](_0x279490)['catch'](_0x51ed1f=>_0x51ed1f&&_0x51ed1f['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x51ed1f)):new Promise((_0x409190,_0x4a46e0)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x279490)['then'](_0x409190,_0x4a46e0):_0x409190(null);},0x0);});}['addTokenChangeListener'](_0x4bf0a1){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4bf0a1):this['authProvider_']['get']()['then'](_0x2bc44a=>_0x2bc44a['addAuthTokenListener'](_0x4bf0a1));}['removeTokenChangeListener'](_0x31afdc){this['authProvider_']['get']()['then'](_0x533f27=>_0x533f27['removeAuthTokenListener'](_0x31afdc));}['notifyForInvalidToken'](){let _0x74d33e='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x74d33e+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x74d33e+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x74d33e+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x74d33e);}}class an{constructor(_0x47efbb){this['accessToken']=_0x47efbb;}['getToken'](_0xeda957){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x31a44f){_0x31a44f(this['accessToken']);}['removeTokenChangeListener'](_0x238c4e){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4ad8e7,_0x1a1bb3,_0x4957e9,_0x2ad88f,_0x311d2b=!0x1,_0x17620a='',_0xacfcd2=!0x1,_0x4c498f=!0x1,_0x35557a=null){this['secure']=_0x1a1bb3,this['namespace']=_0x4957e9,this['webSocketOnly']=_0x2ad88f,this['nodeAdmin']=_0x311d2b,this['persistenceKey']=_0x17620a,this['includeNamespaceInQueryParams']=_0xacfcd2,this['isUsingEmulator']=_0x4c498f,this['emulatorOptions']=_0x35557a,this['_host']=_0x4ad8e7['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4ad8e7)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3c5b45){_0x3c5b45!==this['internalHost']&&(this['internalHost']=_0x3c5b45,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x592ead=this['toURLString']();return this['persistenceKey']&&(_0x592ead+='<'+this['persistenceKey']+'>'),_0x592ead;}['toURLString'](){const _0x5138f8=this['secure']?'https://':'http://',_0x581262=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x5138f8+this['host']+'/'+_0x581262;}}function th(_0xde47ba){return _0xde47ba['host']!==_0xde47ba['internalHost']||_0xde47ba['isCustomHost']()||_0xde47ba['includeNamespaceInQueryParams'];}function vo(_0x38f7bf,_0x2d2ca6,_0x1109eb){f(typeof _0x2d2ca6=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1109eb=='object','typeof\x20params\x20must\x20==\x20object');let _0x386a3c;if(_0x2d2ca6===go)_0x386a3c=(_0x38f7bf['secure']?'wss://':'ws://')+_0x38f7bf['internalHost']+'/.ws?';else{if(_0x2d2ca6===mo)_0x386a3c=(_0x38f7bf['secure']?'https://':'http://')+_0x38f7bf['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2d2ca6);}th(_0x38f7bf)&&(_0x1109eb['ns']=_0x38f7bf['namespace']);const _0x532225=[];return x(_0x1109eb,(_0x5a94d4,_0x7c0d01)=>{_0x532225['push'](_0x5a94d4+'='+_0x7c0d01);}),_0x386a3c+_0x532225['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xaf6d21,_0x1b11a5=0x1){Q(this['counters_'],_0xaf6d21)||(this['counters_'][_0xaf6d21]=0x0),this['counters_'][_0xaf6d21]+=_0x1b11a5;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x2b4859){const _0x493132=_0x2b4859['toString']();return oi[_0x493132]||(oi[_0x493132]=new nh()),oi[_0x493132];}function ih(_0x147332,_0x1060cd){const _0x5dd150=_0x147332['toString']();return ai[_0x5dd150]||(ai[_0x5dd150]=_0x1060cd()),ai[_0x5dd150];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x33cac9){this['onMessage_']=_0x33cac9,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xf6e8b5,_0x5afcb8){this['closeAfterResponse']=_0xf6e8b5,this['onClose']=_0x5afcb8,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x41655d,_0x2e9538){for(this['pendingResponses'][_0x41655d]=_0x2e9538;this['pendingResponses'][this['currentResponseNum']];){const _0xa78b09=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5a415c=0x0;_0x5a415c<_0xa78b09['length'];++_0x5a415c)_0xa78b09[_0x5a415c]&&ft(()=>{this['onMessage_'](_0xa78b09[_0x5a415c]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x15a073,_0x20cc2b,_0x201d1c,_0x1964c7,_0x13c9d8,_0x235579,_0x26e039){this['connId']=_0x15a073,this['repoInfo']=_0x20cc2b,this['applicationId']=_0x201d1c,this['appCheckToken']=_0x1964c7,this['authToken']=_0x13c9d8,this['transportSessionId']=_0x235579,this['lastSessionId']=_0x26e039,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x15a073),this['stats_']=qi(_0x20cc2b),this['urlFn']=_0x51d675=>(this['appCheckToken']&&(_0x51d675[wi]=this['appCheckToken']),vo(_0x20cc2b,mo,_0x51d675));}['open'](_0x48f1c1,_0x4737b4){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4737b4,this['myPacketOrderer']=new sh(_0x48f1c1),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x250133)=>{const [_0x1ae749,_0x3bb80c,_0x606c6b,_0x13ff8a,_0x3a9979]=_0x250133;if(this['incrementIncomingBytes_'](_0x250133),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1ae749===qs)this['id']=_0x3bb80c,this['password']=_0x606c6b;else{if(_0x1ae749===rh)_0x3bb80c?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3bb80c,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1ae749);}}},(..._0x37a42e)=>{const [_0x469489,_0x589560]=_0x37a42e;this['incrementIncomingBytes_'](_0x37a42e),this['myPacketOrderer']['handleResponse'](_0x469489,_0x589560);},()=>{this['onClosed_']();},this['urlFn']);const _0x4f8bac={};_0x4f8bac[qs]='t',_0x4f8bac[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4f8bac[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4f8bac[co]=Gi,this['transportSessionId']&&(_0x4f8bac[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4f8bac[po]=this['lastSessionId']),this['applicationId']&&(_0x4f8bac[_o]=this['applicationId']),this['appCheckToken']&&(_0x4f8bac[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4f8bac[ho]=uo);const _0x485a69=this['urlFn'](_0x4f8bac);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x485a69),this['scriptTagHolder']['addTag'](_0x485a69,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1ca8d1){const _0x3f0479=O(_0x1ca8d1);this['bytesSent']+=_0x3f0479['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3f0479['length']);const _0x5e2be3=$r(_0x3f0479),_0x1a7afa=oo(_0x5e2be3,fh);for(let _0x2f1f3d=0x0;_0x2f1f3d<_0x1a7afa['length'];_0x2f1f3d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1a7afa['length'],_0x1a7afa[_0x2f1f3d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2fd088,_0x474431){this['myDisconnFrame']=document['createElement']('iframe');const _0x3f9699={};_0x3f9699[dh]='t',_0x3f9699[Eo]=_0x2fd088,_0x3f9699[Io]=_0x474431,this['myDisconnFrame']['src']=this['urlFn'](_0x3f9699),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x33e5e5){const _0x22b002=O(_0x33e5e5)['length'];this['bytesReceived']+=_0x22b002,this['stats_']['incrementCounter']('bytes_received',_0x22b002);}}class zi{constructor(_0x44268d,_0x37e52e,_0x4d2666,_0x48f05f){this['onDisconnect']=_0x4d2666,this['urlFn']=_0x48f05f,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x44268d,window[ah+this['uniqueCallbackIdentifier']]=_0x37e52e,this['myIFrame']=zi['createIFrame_']();let _0x81786a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x81786a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x22c541='<html><body>'+_0x81786a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x22c541),this['myIFrame']['doc']['close']();}catch(_0xd95e59){L('frame\x20writing\x20exception'),_0xd95e59['stack']&&L(_0xd95e59['stack']),L(_0xd95e59);}}}static['createIFrame_'](){const _0x3e2154=document['createElement']('iframe');if(_0x3e2154['style']['display']='none',document['body']){document['body']['appendChild'](_0x3e2154);try{_0x3e2154['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x23f28d=document['domain'];_0x3e2154['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x23f28d+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3e2154['contentDocument']?_0x3e2154['doc']=_0x3e2154['contentDocument']:_0x3e2154['contentWindow']?_0x3e2154['doc']=_0x3e2154['contentWindow']['document']:_0x3e2154['document']&&(_0x3e2154['doc']=_0x3e2154['document']),_0x3e2154;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x54985e=this['onDisconnect'];_0x54985e&&(this['onDisconnect']=null,_0x54985e());}['startLongPoll'](_0x3ad9df,_0x20f70b){for(this['myID']=_0x3ad9df,this['myPW']=_0x20f70b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1d0f92={};_0x1d0f92[Eo]=this['myID'],_0x1d0f92[Io]=this['myPW'],_0x1d0f92[wo]=this['currentSerial'];let _0x4f735a=this['urlFn'](_0x1d0f92),_0x38e233='',_0xd727bd=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x38e233['length']<=Co;){const _0x20f86=this['pendingSegs']['shift']();_0x38e233=_0x38e233+'&'+lh+_0xd727bd+'='+_0x20f86['seg']+'&'+hh+_0xd727bd+'='+_0x20f86['ts']+'&'+uh+_0xd727bd+'='+_0x20f86['d'],_0xd727bd++;}return _0x4f735a=_0x4f735a+_0x38e233,this['addLongPollTag_'](_0x4f735a,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x820d9d,_0x570fc8,_0x2618e3){this['pendingSegs']['push']({'seg':_0x820d9d,'ts':_0x570fc8,'d':_0x2618e3}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4624fd,_0x1f0dfb){this['outstandingRequests']['add'](_0x1f0dfb);const _0x20cf9d=()=>{this['outstandingRequests']['delete'](_0x1f0dfb),this['newRequest_']();},_0x6cb3=setTimeout(_0x20cf9d,Math['floor'](ph)),_0x1ad98f=()=>{clearTimeout(_0x6cb3),_0x20cf9d();};this['addTag'](_0x4624fd,_0x1ad98f);}['addTag'](_0x2cfaee,_0x34b948){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4e33a1=this['myIFrame']['doc']['createElement']('script');_0x4e33a1['type']='text/javascript',_0x4e33a1['async']=!0x0,_0x4e33a1['src']=_0x2cfaee,_0x4e33a1['onload']=_0x4e33a1['onreadystatechange']=function(){const _0x3746a8=_0x4e33a1['readyState'];(!_0x3746a8||_0x3746a8==='loaded'||_0x3746a8==='complete')&&(_0x4e33a1['onload']=_0x4e33a1['onreadystatechange']=null,_0x4e33a1['parentNode']&&_0x4e33a1['parentNode']['removeChild'](_0x4e33a1),_0x34b948());},_0x4e33a1['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2cfaee),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4e33a1);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x254a31,_0x519539,_0x1e2358,_0x4353e2,_0x52137b,_0x3bdef1,_0x2bf011){this['connId']=_0x254a31,this['applicationId']=_0x1e2358,this['appCheckToken']=_0x4353e2,this['authToken']=_0x52137b,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x519539),this['connURL']=q['connectionURL_'](_0x519539,_0x3bdef1,_0x2bf011,_0x4353e2,_0x1e2358),this['nodeAdmin']=_0x519539['nodeAdmin'];}static['connectionURL_'](_0x5c5773,_0x3d12ac,_0x2b3919,_0xd71424,_0x206d1c){const _0x2b6579={};return _0x2b6579[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2b6579[ho]=uo),_0x3d12ac&&(_0x2b6579[lo]=_0x3d12ac),_0x2b3919&&(_0x2b6579[po]=_0x2b3919),_0xd71424&&(_0x2b6579[wi]=_0xd71424),_0x206d1c&&(_0x2b6579[_o]=_0x206d1c),vo(_0x5c5773,go,_0x2b6579);}['open'](_0x27e210,_0x5c13d8){this['onDisconnect']=_0x5c13d8,this['onMessage']=_0x27e210,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x297f1d;_c(),this['mySock']=new gn(this['connURL'],[],_0x297f1d);}catch(_0x792306){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4922fb=_0x792306['message']||_0x792306['data'];_0x4922fb&&this['log_'](_0x4922fb),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2c7506=>{this['handleIncomingFrame'](_0x2c7506);},this['mySock']['onerror']=_0x13747d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1ca28b=_0x13747d['message']||_0x13747d['data'];_0x1ca28b&&this['log_'](_0x1ca28b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x49bf76=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3eec38=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x424ba7=navigator['userAgent']['match'](_0x3eec38);_0x424ba7&&_0x424ba7['length']>0x1&&parseFloat(_0x424ba7[0x1])<4.4&&(_0x49bf76=!0x0);}return!_0x49bf76&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x18c1f7){if(this['frames']['push'](_0x18c1f7),this['frames']['length']===this['totalFrames']){const _0xf6ccc0=this['frames']['join']('');this['frames']=null;const _0x584d07=Nt(_0xf6ccc0);this['onMessage'](_0x584d07);}}['handleNewFrameCount_'](_0xdc41cd){this['totalFrames']=_0xdc41cd,this['frames']=[];}['extractFrameCount_'](_0x10947e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x10947e['length']<=0x6){const _0x5a6107=Number(_0x10947e);if(!isNaN(_0x5a6107))return this['handleNewFrameCount_'](_0x5a6107),null;}return this['handleNewFrameCount_'](0x1),_0x10947e;}['handleIncomingFrame'](_0x1aeeaa){if(this['mySock']===null)return;const _0x17f5dd=_0x1aeeaa['data'];if(this['bytesReceived']+=_0x17f5dd['length'],this['stats_']['incrementCounter']('bytes_received',_0x17f5dd['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x17f5dd);else{const _0x44c9ff=this['extractFrameCount_'](_0x17f5dd);_0x44c9ff!==null&&this['appendFrame_'](_0x44c9ff);}}['send'](_0x5b05ff){this['resetKeepAlive']();const _0x1b9651=O(_0x5b05ff);this['bytesSent']+=_0x1b9651['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1b9651['length']);const _0x56f38c=oo(_0x1b9651,gh);_0x56f38c['length']>0x1&&this['sendString_'](String(_0x56f38c['length']));for(let _0x13a3d9=0x0;_0x13a3d9<_0x56f38c['length'];_0x13a3d9++)this['sendString_'](_0x56f38c[_0x13a3d9]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x38d9ec){try{this['mySock']['send'](_0x38d9ec);}catch(_0x425fce){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x425fce['message']||_0x425fce['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x14988c){this['initTransports_'](_0x14988c);}['initTransports_'](_0x236723){const _0x44bd1a=q&&q['isAvailable']();let _0x29c984=_0x44bd1a&&!q['previouslyFailed']();if(_0x236723['webSocketOnly']&&(_0x44bd1a||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x29c984=!0x0),_0x29c984)this['transports_']=[q];else{const _0x17ce2f=this['transports_']=[];for(const _0x5eb491 of Dt['ALL_TRANSPORTS'])_0x5eb491&&_0x5eb491['isAvailable']()&&_0x17ce2f['push'](_0x5eb491);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x119a75,_0x5c4fd5,_0x2e4210,_0x4bbd05,_0x5208c4,_0x3d1be7,_0x5452a8,_0x34049c,_0x5cd45d,_0x135ad5){this['id']=_0x119a75,this['repoInfo_']=_0x5c4fd5,this['applicationId_']=_0x2e4210,this['appCheckToken_']=_0x4bbd05,this['authToken_']=_0x5208c4,this['onMessage_']=_0x3d1be7,this['onReady_']=_0x5452a8,this['onDisconnect_']=_0x34049c,this['onKill_']=_0x5cd45d,this['lastSessionId']=_0x135ad5,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x5c4fd5),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x524fad=this['transportManager_']['initialTransport']();this['conn_']=new _0x524fad(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x524fad['responsesRequiredToBeHealthy']||0x0;const _0x215f13=this['connReceiver_'](this['conn_']),_0x2f34d8=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x215f13,_0x2f34d8);},Math['floor'](0x0));const _0x3179c8=_0x524fad['healthyTimeout']||0x0;_0x3179c8>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3179c8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4719d9){return _0x546de1=>{_0x4719d9===this['conn_']?this['onConnectionLost_'](_0x546de1):_0x4719d9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1bc7b8){return _0x51f571=>{this['state_']!==0x2&&(_0x1bc7b8===this['rx_']?this['onPrimaryMessageReceived_'](_0x51f571):_0x1bc7b8===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x51f571):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x6bd3a1){const _0x9581b3={'t':'d','d':_0x6bd3a1};this['sendData_'](_0x9581b3);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1c2e9c){if(ci in _0x1c2e9c){const _0x58dc2d=_0x1c2e9c[ci];_0x58dc2d===Ys?this['upgradeIfSecondaryHealthy_']():_0x58dc2d===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x58dc2d===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x43c028){const _0x5d9683=vt('t',_0x43c028),_0xf78c6d=vt('d',_0x43c028);if(_0x5d9683==='c')this['onSecondaryControl_'](_0xf78c6d);else{if(_0x5d9683==='d')this['pendingDataMessages']['push'](_0xf78c6d);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5d9683);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5e236a){const _0x9a566f=vt('t',_0x5e236a),_0x53d3a7=vt('d',_0x5e236a);_0x9a566f==='c'?this['onControl_'](_0x53d3a7):_0x9a566f==='d'&&this['onDataMessage_'](_0x53d3a7);}['onDataMessage_'](_0x387a11){this['onPrimaryResponse_'](),this['onMessage_'](_0x387a11);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x314869){const _0x47a4b6=vt(ci,_0x314869);if(zs in _0x314869){const _0x1dd6e1=_0x314869[zs];if(_0x47a4b6===Th){const _0x799a18={..._0x1dd6e1};this['repoInfo_']['isUsingEmulator']&&(_0x799a18['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x799a18);}else{if(_0x47a4b6===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x593b4d=0x0;_0x593b4d<this['pendingDataMessages']['length'];++_0x593b4d)this['onDataMessage_'](this['pendingDataMessages'][_0x593b4d]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x47a4b6===wh?this['onConnectionShutdown_'](_0x1dd6e1):_0x47a4b6===js?this['onReset_'](_0x1dd6e1):_0x47a4b6===Ch?Ii('Server\x20Error:\x20'+_0x1dd6e1):_0x47a4b6===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x47a4b6);}}}['onHandshake_'](_0x357216){const _0x22dea3=_0x357216['ts'],_0x5b5760=_0x357216['v'],_0x41b670=_0x357216['h'];this['sessionId']=_0x357216['s'],this['repoInfo_']['host']=_0x41b670,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x22dea3),Gi!==_0x5b5760&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x361c4=this['transportManager_']['upgradeTransport']();_0x361c4&&this['startUpgrade_'](_0x361c4);}['startUpgrade_'](_0x2f52a8){this['secondaryConn_']=new _0x2f52a8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2f52a8['responsesRequiredToBeHealthy']||0x0;const _0x69313c=this['connReceiver_'](this['secondaryConn_']),_0x359945=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x69313c,_0x359945),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x281756){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x281756),this['repoInfo_']['host']=_0x281756,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x323822,_0xb7f625){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x323822,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xb7f625,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3933d7=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3933d7||this['rx_']===_0x3933d7)&&this['close']();}['onConnectionLost_'](_0x4b942b){this['conn_']=null,!_0x4b942b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x395f36){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x395f36),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x12115b){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x12115b);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x9db7c0,_0x1b8525,_0x1827a3,_0xdbe12a){}['merge'](_0x244c19,_0xa54e15,_0x29f67f,_0x172224){}['refreshAuthToken'](_0x160e6e){}['refreshAppCheckToken'](_0x6508d8){}['onDisconnectPut'](_0x153a07,_0x1bc360,_0x5b07b3){}['onDisconnectMerge'](_0x962393,_0xf6a47f,_0x753749){}['onDisconnectCancel'](_0x1c859b,_0x2f14b1){}['reportStats'](_0x31ad0e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3e90cc){this['allowedEvents_']=_0x3e90cc,this['listeners_']={},f(Array['isArray'](_0x3e90cc)&&_0x3e90cc['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5e9509,..._0x323c6e){if(Array['isArray'](this['listeners_'][_0x5e9509])){const _0x14d501=[...this['listeners_'][_0x5e9509]];for(let _0x15c338=0x0;_0x15c338<_0x14d501['length'];_0x15c338++)_0x14d501[_0x15c338]['callback']['apply'](_0x14d501[_0x15c338]['context'],_0x323c6e);}}['on'](_0xbad827,_0x526c87,_0x5d78b6){this['validateEventType_'](_0xbad827),this['listeners_'][_0xbad827]=this['listeners_'][_0xbad827]||[],this['listeners_'][_0xbad827]['push']({'callback':_0x526c87,'context':_0x5d78b6});const _0x1e123f=this['getInitialEvent'](_0xbad827);_0x1e123f&&_0x526c87['apply'](_0x5d78b6,_0x1e123f);}['off'](_0x5d8b09,_0xc85e83,_0x42cde5){this['validateEventType_'](_0x5d8b09);const _0x1e69a6=this['listeners_'][_0x5d8b09]||[];for(let _0x51dd96=0x0;_0x51dd96<_0x1e69a6['length'];_0x51dd96++)if(_0x1e69a6[_0x51dd96]['callback']===_0xc85e83&&(!_0x42cde5||_0x42cde5===_0x1e69a6[_0x51dd96]['context'])){_0x1e69a6['splice'](_0x51dd96,0x1);return;}}['validateEventType_'](_0x3702fa){f(this['allowedEvents_']['find'](_0x3d65c1=>_0x3d65c1===_0x3702fa),'Unknown\x20event:\x20'+_0x3702fa);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2db5fc){return f(_0x2db5fc==='online','Unknown\x20event\x20type:\x20'+_0x2db5fc),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x4ddd94,_0xbf6a90){if(_0xbf6a90===void 0x0){this['pieces_']=_0x4ddd94['split']('/');let _0x3c6c87=0x0;for(let _0x410643=0x0;_0x410643<this['pieces_']['length'];_0x410643++)this['pieces_'][_0x410643]['length']>0x0&&(this['pieces_'][_0x3c6c87]=this['pieces_'][_0x410643],_0x3c6c87++);this['pieces_']['length']=_0x3c6c87,this['pieceNum_']=0x0;}else this['pieces_']=_0x4ddd94,this['pieceNum_']=_0xbf6a90;}['toString'](){let _0x46ff85='';for(let _0x51256c=this['pieceNum_'];_0x51256c<this['pieces_']['length'];_0x51256c++)this['pieces_'][_0x51256c]!==''&&(_0x46ff85+='/'+this['pieces_'][_0x51256c]);return _0x46ff85||'/';}}function w(){return new C('');}function y(_0x10352b){return _0x10352b['pieceNum_']>=_0x10352b['pieces_']['length']?null:_0x10352b['pieces_'][_0x10352b['pieceNum_']];}function Ce(_0x1db7c8){return _0x1db7c8['pieces_']['length']-_0x1db7c8['pieceNum_'];}function S(_0x4d30da){let _0x28018c=_0x4d30da['pieceNum_'];return _0x28018c<_0x4d30da['pieces_']['length']&&_0x28018c++,new C(_0x4d30da['pieces_'],_0x28018c);}function ji(_0x4f17be){return _0x4f17be['pieceNum_']<_0x4f17be['pieces_']['length']?_0x4f17be['pieces_'][_0x4f17be['pieces_']['length']-0x1]:null;}function bh(_0x116532){let _0x2feafb='';for(let _0x86661c=_0x116532['pieceNum_'];_0x86661c<_0x116532['pieces_']['length'];_0x86661c++)_0x116532['pieces_'][_0x86661c]!==''&&(_0x2feafb+='/'+encodeURIComponent(String(_0x116532['pieces_'][_0x86661c])));return _0x2feafb||'/';}function Mt(_0x38b00f,_0x10bee0=0x0){return _0x38b00f['pieces_']['slice'](_0x38b00f['pieceNum_']+_0x10bee0);}function Ro(_0x3d1f2a){if(_0x3d1f2a['pieceNum_']>=_0x3d1f2a['pieces_']['length'])return null;const _0x25b19f=[];for(let _0x45fd4f=_0x3d1f2a['pieceNum_'];_0x45fd4f<_0x3d1f2a['pieces_']['length']-0x1;_0x45fd4f++)_0x25b19f['push'](_0x3d1f2a['pieces_'][_0x45fd4f]);return new C(_0x25b19f,0x0);}function k(_0x3fd205,_0x17b273){const _0x45a06c=[];for(let _0x142608=_0x3fd205['pieceNum_'];_0x142608<_0x3fd205['pieces_']['length'];_0x142608++)_0x45a06c['push'](_0x3fd205['pieces_'][_0x142608]);if(_0x17b273 instanceof C){for(let _0x547748=_0x17b273['pieceNum_'];_0x547748<_0x17b273['pieces_']['length'];_0x547748++)_0x45a06c['push'](_0x17b273['pieces_'][_0x547748]);}else{const _0x36b401=_0x17b273['split']('/');for(let _0x50f7d=0x0;_0x50f7d<_0x36b401['length'];_0x50f7d++)_0x36b401[_0x50f7d]['length']>0x0&&_0x45a06c['push'](_0x36b401[_0x50f7d]);}return new C(_0x45a06c,0x0);}function v(_0x120027){return _0x120027['pieceNum_']>=_0x120027['pieces_']['length'];}function F(_0x55486d,_0xbbbc76){const _0x156c69=y(_0x55486d),_0x3f99e7=y(_0xbbbc76);if(_0x156c69===null)return _0xbbbc76;if(_0x156c69===_0x3f99e7)return F(S(_0x55486d),S(_0xbbbc76));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xbbbc76+')\x20is\x20not\x20within\x20outerPath\x20('+_0x55486d+')');}function Rh(_0x2b50bb,_0x292943){const _0x115d85=Mt(_0x2b50bb,0x0),_0x358a17=Mt(_0x292943,0x0);for(let _0x42c599=0x0;_0x42c599<_0x115d85['length']&&_0x42c599<_0x358a17['length'];_0x42c599++){const _0x19a45c=qe(_0x115d85[_0x42c599],_0x358a17[_0x42c599]);if(_0x19a45c!==0x0)return _0x19a45c;}return _0x115d85['length']===_0x358a17['length']?0x0:_0x115d85['length']<_0x358a17['length']?-0x1:0x1;}function Ki(_0x4b80e8,_0x3c10c8){if(Ce(_0x4b80e8)!==Ce(_0x3c10c8))return!0x1;for(let _0x45d99f=_0x4b80e8['pieceNum_'],_0x2d3155=_0x3c10c8['pieceNum_'];_0x45d99f<=_0x4b80e8['pieces_']['length'];_0x45d99f++,_0x2d3155++)if(_0x4b80e8['pieces_'][_0x45d99f]!==_0x3c10c8['pieces_'][_0x2d3155])return!0x1;return!0x0;}function G(_0x3fb9cb,_0x1ce748){let _0x4ff8b5=_0x3fb9cb['pieceNum_'],_0x2b10f4=_0x1ce748['pieceNum_'];if(Ce(_0x3fb9cb)>Ce(_0x1ce748))return!0x1;for(;_0x4ff8b5<_0x3fb9cb['pieces_']['length'];){if(_0x3fb9cb['pieces_'][_0x4ff8b5]!==_0x1ce748['pieces_'][_0x2b10f4])return!0x1;++_0x4ff8b5,++_0x2b10f4;}return!0x0;}class Ah{constructor(_0x327bbc,_0x16e742){this['errorPrefix_']=_0x16e742,this['parts_']=Mt(_0x327bbc,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x3b0950=0x0;_0x3b0950<this['parts_']['length'];_0x3b0950++)this['byteLength_']+=Ln(this['parts_'][_0x3b0950]);Ao(this);}}function kh(_0x32c41c,_0x3aebbf){_0x32c41c['parts_']['length']>0x0&&(_0x32c41c['byteLength_']+=0x1),_0x32c41c['parts_']['push'](_0x3aebbf),_0x32c41c['byteLength_']+=Ln(_0x3aebbf),Ao(_0x32c41c);}function Ph(_0xc3391b){const _0x1602eb=_0xc3391b['parts_']['pop']();_0xc3391b['byteLength_']-=Ln(_0x1602eb),_0xc3391b['parts_']['length']>0x0&&(_0xc3391b['byteLength_']-=0x1);}function Ao(_0x1cebf0){if(_0x1cebf0['byteLength_']>Zs)throw new Error(_0x1cebf0['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1cebf0['byteLength_']+').');if(_0x1cebf0['parts_']['length']>Xs)throw new Error(_0x1cebf0['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x1cebf0));}function Oe(_0xc0a0bf){return _0xc0a0bf['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xc0a0bf['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x2ac933,_0x503da4;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x503da4='visibilitychange',_0x2ac933='hidden'):typeof document['mozHidden']<'u'?(_0x503da4='mozvisibilitychange',_0x2ac933='mozHidden'):typeof document['msHidden']<'u'?(_0x503da4='msvisibilitychange',_0x2ac933='msHidden'):typeof document['webkitHidden']<'u'&&(_0x503da4='webkitvisibilitychange',_0x2ac933='webkitHidden')),this['visible_']=!0x0,_0x503da4&&document['addEventListener'](_0x503da4,()=>{const _0x18626f=!document[_0x2ac933];_0x18626f!==this['visible_']&&(this['visible_']=_0x18626f,this['trigger']('visible',_0x18626f));},!0x1);}['getInitialEvent'](_0x247701){return f(_0x247701==='visible','Unknown\x20event\x20type:\x20'+_0x247701),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x11d400,_0x30c701,_0x56426d,_0x5e20e0,_0x1bdd0d,_0x3420da,_0xdd984d,_0x239d57){if(super(),this['repoInfo_']=_0x11d400,this['applicationId_']=_0x30c701,this['onDataUpdate_']=_0x56426d,this['onConnectStatus_']=_0x5e20e0,this['onServerInfoUpdate_']=_0x1bdd0d,this['authTokenProvider_']=_0x3420da,this['appCheckTokenProvider_']=_0xdd984d,this['authOverride_']=_0x239d57,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x239d57)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x11d400['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x26679c,_0x25fcb1,_0x31d8c2){const _0x174594=++this['requestNumber_'],_0x2d621e={'r':_0x174594,'a':_0x26679c,'b':_0x25fcb1};this['log_'](O(_0x2d621e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2d621e),_0x31d8c2&&(this['requestCBHash_'][_0x174594]=_0x31d8c2);}['get'](_0x322a21){this['initConnection_']();const _0x300d4e=new H(),_0x33516b={'action':'g','request':{'p':_0x322a21['_path']['toString'](),'q':_0x322a21['_queryObject']},'onComplete':_0x24ec31=>{const _0x204fd5=_0x24ec31['d'];_0x24ec31['s']==='ok'?_0x300d4e['resolve'](_0x204fd5):_0x300d4e['reject'](_0x204fd5);}};this['outstandingGets_']['push'](_0x33516b),this['outstandingGetCount_']++;const _0xd899d8=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0xd899d8),_0x300d4e['promise'];}['listen'](_0x5018c9,_0x3e58bf,_0x2332a8,_0x2c48b4){this['initConnection_']();const _0x8515a6=_0x5018c9['_queryIdentifier'],_0x2348bf=_0x5018c9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2348bf+'\x20'+_0x8515a6),this['listens']['has'](_0x2348bf)||this['listens']['set'](_0x2348bf,new Map()),f(_0x5018c9['_queryParams']['isDefault']()||!_0x5018c9['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2348bf)['has'](_0x8515a6),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x29c529={'onComplete':_0x2c48b4,'hashFn':_0x3e58bf,'query':_0x5018c9,'tag':_0x2332a8};this['listens']['get'](_0x2348bf)['set'](_0x8515a6,_0x29c529),this['connected_']&&this['sendListen_'](_0x29c529);}['sendGet_'](_0x93d199){const _0xdd79a7=this['outstandingGets_'][_0x93d199];this['sendRequest']('g',_0xdd79a7['request'],_0x20b38d=>{delete this['outstandingGets_'][_0x93d199],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xdd79a7['onComplete']&&_0xdd79a7['onComplete'](_0x20b38d);});}['sendListen_'](_0x4a65f6){const _0x3deeff=_0x4a65f6['query'],_0x35e143=_0x3deeff['_path']['toString'](),_0x49e247=_0x3deeff['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x35e143+'\x20for\x20'+_0x49e247);const _0x24a44e={'p':_0x35e143},_0x4c0b07='q';_0x4a65f6['tag']&&(_0x24a44e['q']=_0x3deeff['_queryObject'],_0x24a44e['t']=_0x4a65f6['tag']),_0x24a44e['h']=_0x4a65f6['hashFn'](),this['sendRequest'](_0x4c0b07,_0x24a44e,_0x4a13c9=>{const _0x57e21e=_0x4a13c9['d'],_0x8aae53=_0x4a13c9['s'];se['warnOnListenWarnings_'](_0x57e21e,_0x3deeff),(this['listens']['get'](_0x35e143)&&this['listens']['get'](_0x35e143)['get'](_0x49e247))===_0x4a65f6&&(this['log_']('listen\x20response',_0x4a13c9),_0x8aae53!=='ok'&&this['removeListen_'](_0x35e143,_0x49e247),_0x4a65f6['onComplete']&&_0x4a65f6['onComplete'](_0x8aae53,_0x57e21e));});}static['warnOnListenWarnings_'](_0x42fe3d,_0x4589bb){if(_0x42fe3d&&typeof _0x42fe3d=='object'&&Q(_0x42fe3d,'w')){const _0x4130f8=Le(_0x42fe3d,'w');if(Array['isArray'](_0x4130f8)&&~_0x4130f8['indexOf']('no_index')){const _0x331d13='\x22.indexOn\x22:\x20\x22'+_0x4589bb['_queryParams']['getIndex']()['toString']()+'\x22',_0x42233a=_0x4589bb['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x331d13+'\x20at\x20'+_0x42233a+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2a78c7){this['authToken_']=_0x2a78c7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2a78c7);}['reduceReconnectDelayIfAdminCredential_'](_0x2e229d){(_0x2e229d&&_0x2e229d['length']===0x28||wc(_0x2e229d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x521b8c){this['appCheckToken_']=_0x521b8c,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x45970a=this['authToken_'],_0x483e71=Ic(_0x45970a)?'auth':'gauth',_0x108360={'cred':_0x45970a};this['authOverride_']===null?_0x108360['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x108360['authvar']=this['authOverride_']),this['sendRequest'](_0x483e71,_0x108360,_0x24be10=>{const _0x2a471f=_0x24be10['s'],_0x3d162f=_0x24be10['d']||'error';this['authToken_']===_0x45970a&&(_0x2a471f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2a471f,_0x3d162f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5a83e8=>{const _0x3e3ddb=_0x5a83e8['s'],_0xfb9067=_0x5a83e8['d']||'error';_0x3e3ddb==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3e3ddb,_0xfb9067);});}['unlisten'](_0x4ce3b2,_0x4c6e60){const _0x1c3a28=_0x4ce3b2['_path']['toString'](),_0x365622=_0x4ce3b2['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1c3a28+'\x20'+_0x365622),f(_0x4ce3b2['_queryParams']['isDefault']()||!_0x4ce3b2['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1c3a28,_0x365622)&&this['connected_']&&this['sendUnlisten_'](_0x1c3a28,_0x365622,_0x4ce3b2['_queryObject'],_0x4c6e60);}['sendUnlisten_'](_0x1060a8,_0x39a799,_0x22c585,_0x109827){this['log_']('Unlisten\x20on\x20'+_0x1060a8+'\x20for\x20'+_0x39a799);const _0x1f56a7={'p':_0x1060a8},_0x17660a='n';_0x109827&&(_0x1f56a7['q']=_0x22c585,_0x1f56a7['t']=_0x109827),this['sendRequest'](_0x17660a,_0x1f56a7);}['onDisconnectPut'](_0x8ff4bb,_0x251c06,_0x295ee7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x8ff4bb,_0x251c06,_0x295ee7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x8ff4bb,'action':'o','data':_0x251c06,'onComplete':_0x295ee7});}['onDisconnectMerge'](_0x4e6479,_0x4166aa,_0x399b3c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4e6479,_0x4166aa,_0x399b3c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4e6479,'action':'om','data':_0x4166aa,'onComplete':_0x399b3c});}['onDisconnectCancel'](_0xca9025,_0x152e6c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0xca9025,null,_0x152e6c):this['onDisconnectRequestQueue_']['push']({'pathString':_0xca9025,'action':'oc','data':null,'onComplete':_0x152e6c});}['sendOnDisconnect_'](_0x381fb6,_0x367127,_0x3d40b9,_0x515368){const _0x3a2699={'p':_0x367127,'d':_0x3d40b9};this['log_']('onDisconnect\x20'+_0x381fb6,_0x3a2699),this['sendRequest'](_0x381fb6,_0x3a2699,_0x448d48=>{_0x515368&&setTimeout(()=>{_0x515368(_0x448d48['s'],_0x448d48['d']);},Math['floor'](0x0));});}['put'](_0x57d5a4,_0x117cb6,_0x54dcd1,_0x237223){this['putInternal']('p',_0x57d5a4,_0x117cb6,_0x54dcd1,_0x237223);}['merge'](_0x4d462e,_0x181329,_0x49146c,_0x15137f){this['putInternal']('m',_0x4d462e,_0x181329,_0x49146c,_0x15137f);}['putInternal'](_0x1c0651,_0x16daaa,_0x130448,_0x7863e4,_0x2ef0f6){this['initConnection_']();const _0xb5e17f={'p':_0x16daaa,'d':_0x130448};_0x2ef0f6!==void 0x0&&(_0xb5e17f['h']=_0x2ef0f6),this['outstandingPuts_']['push']({'action':_0x1c0651,'request':_0xb5e17f,'onComplete':_0x7863e4}),this['outstandingPutCount_']++;const _0x47923c=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x47923c):this['log_']('Buffering\x20put:\x20'+_0x16daaa);}['sendPut_'](_0x500cc7){const _0x191c12=this['outstandingPuts_'][_0x500cc7]['action'],_0x5bbd30=this['outstandingPuts_'][_0x500cc7]['request'],_0x87f0d8=this['outstandingPuts_'][_0x500cc7]['onComplete'];this['outstandingPuts_'][_0x500cc7]['queued']=this['connected_'],this['sendRequest'](_0x191c12,_0x5bbd30,_0x3e8e4f=>{this['log_'](_0x191c12+'\x20response',_0x3e8e4f),delete this['outstandingPuts_'][_0x500cc7],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x87f0d8&&_0x87f0d8(_0x3e8e4f['s'],_0x3e8e4f['d']);});}['reportStats'](_0x3e6aaa){if(this['connected_']){const _0x35e09d={'c':_0x3e6aaa};this['log_']('reportStats',_0x35e09d),this['sendRequest']('s',_0x35e09d,_0x326d0c=>{if(_0x326d0c['s']!=='ok'){const _0xaf05f9=_0x326d0c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0xaf05f9);}});}}['onDataMessage_'](_0x1a83de){if('r'in _0x1a83de){this['log_']('from\x20server:\x20'+O(_0x1a83de));const _0x584e4a=_0x1a83de['r'],_0xd4c8d7=this['requestCBHash_'][_0x584e4a];_0xd4c8d7&&(delete this['requestCBHash_'][_0x584e4a],_0xd4c8d7(_0x1a83de['b']));}else{if('error'in _0x1a83de)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1a83de['error'];'a'in _0x1a83de&&this['onDataPush_'](_0x1a83de['a'],_0x1a83de['b']);}}['onDataPush_'](_0x3e635a,_0xed1ff7){this['log_']('handleServerMessage',_0x3e635a,_0xed1ff7),_0x3e635a==='d'?this['onDataUpdate_'](_0xed1ff7['p'],_0xed1ff7['d'],!0x1,_0xed1ff7['t']):_0x3e635a==='m'?this['onDataUpdate_'](_0xed1ff7['p'],_0xed1ff7['d'],!0x0,_0xed1ff7['t']):_0x3e635a==='c'?this['onListenRevoked_'](_0xed1ff7['p'],_0xed1ff7['q']):_0x3e635a==='ac'?this['onAuthRevoked_'](_0xed1ff7['s'],_0xed1ff7['d']):_0x3e635a==='apc'?this['onAppCheckRevoked_'](_0xed1ff7['s'],_0xed1ff7['d']):_0x3e635a==='sd'?this['onSecurityDebugPacket_'](_0xed1ff7):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3e635a)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x128a6e,_0x1c54aa){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x128a6e),this['lastSessionId']=_0x1c54aa,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0xe32aa2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0xe32aa2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x30e1ec){_0x30e1ec&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x30e1ec;}['onOnline_'](_0x1a1a50){_0x1a1a50?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2c6d3e=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x49f1bc=Math['max'](0x0,this['reconnectDelay_']-_0x2c6d3e);_0x49f1bc=Math['random']()*_0x49f1bc,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x49f1bc+'ms'),this['scheduleConnect_'](_0x49f1bc),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x12cbb6=this['onDataMessage_']['bind'](this),_0x48a2cc=this['onReady_']['bind'](this),_0x5e1f84=this['onRealtimeDisconnect_']['bind'](this),_0x48b7ff=this['id']+':'+se['nextConnectionId_']++,_0x635347=this['lastSessionId'];let _0x9684fa=!0x1,_0x3be4e4=null;const _0x1999bb=function(){_0x3be4e4?_0x3be4e4['close']():(_0x9684fa=!0x0,_0x5e1f84());},_0xe85947=function(_0x55174d){f(_0x3be4e4,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3be4e4['sendRequest'](_0x55174d);};this['realtime_']={'close':_0x1999bb,'sendRequest':_0xe85947};const _0x330c84=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2c9cd2,_0x587056]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x330c84),this['appCheckTokenProvider_']['getToken'](_0x330c84)]);_0x9684fa?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2c9cd2&&_0x2c9cd2['accessToken'],this['appCheckToken_']=_0x587056&&_0x587056['token'],_0x3be4e4=new Sh(_0x48b7ff,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x12cbb6,_0x48a2cc,_0x5e1f84,_0x9fa2f=>{U(_0x9fa2f+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x635347));}catch(_0x2bf31a){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2bf31a),_0x9684fa||(this['repoInfo_']['nodeAdmin']&&U(_0x2bf31a),_0x1999bb());}}}['interrupt'](_0x276cc2){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x276cc2),this['interruptReasons_'][_0x276cc2]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4e0b5f){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4e0b5f),delete this['interruptReasons_'][_0x4e0b5f],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x16bfb4){const _0x17a4ed=_0x16bfb4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x17a4ed});}['cancelSentTransactions_'](){for(let _0x1a51fd=0x0;_0x1a51fd<this['outstandingPuts_']['length'];_0x1a51fd++){const _0x2f2cff=this['outstandingPuts_'][_0x1a51fd];_0x2f2cff&&'h'in _0x2f2cff['request']&&_0x2f2cff['queued']&&(_0x2f2cff['onComplete']&&_0x2f2cff['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1a51fd],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2c5a5e,_0x404beb){let _0x21ab2c;_0x404beb?_0x21ab2c=_0x404beb['map'](_0x2a5000=>$i(_0x2a5000))['join']('$'):_0x21ab2c='default';const _0x5534d8=this['removeListen_'](_0x2c5a5e,_0x21ab2c);_0x5534d8&&_0x5534d8['onComplete']&&_0x5534d8['onComplete']('permission_denied');}['removeListen_'](_0x924ceb,_0x2b7380){const _0x548fdc=new C(_0x924ceb)['toString']();let _0x25a22d;if(this['listens']['has'](_0x548fdc)){const _0x3ac978=this['listens']['get'](_0x548fdc);_0x25a22d=_0x3ac978['get'](_0x2b7380),_0x3ac978['delete'](_0x2b7380),_0x3ac978['size']===0x0&&this['listens']['delete'](_0x548fdc);}else _0x25a22d=void 0x0;return _0x25a22d;}['onAuthRevoked_'](_0x454772,_0x5ba3af){L('Auth\x20token\x20revoked:\x20'+_0x454772+'/'+_0x5ba3af),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x454772==='invalid_token'||_0x454772==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x18b9da,_0x15e7cc){L('App\x20check\x20token\x20revoked:\x20'+_0x18b9da+'/'+_0x15e7cc),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x18b9da==='invalid_token'||_0x18b9da==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4ab19b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4ab19b):'msg'in _0x4ab19b&&console['log']('FIREBASE:\x20'+_0x4ab19b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x192c17 of this['listens']['values']())for(const _0x72c01 of _0x192c17['values']())this['sendListen_'](_0x72c01);for(let _0x15c9c9=0x0;_0x15c9c9<this['outstandingPuts_']['length'];_0x15c9c9++)this['outstandingPuts_'][_0x15c9c9]&&this['sendPut_'](_0x15c9c9);for(;this['onDisconnectRequestQueue_']['length'];){const _0x349534=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x349534['action'],_0x349534['pathString'],_0x349534['data'],_0x349534['onComplete']);}for(let _0x4993ff=0x0;_0x4993ff<this['outstandingGets_']['length'];_0x4993ff++)this['outstandingGets_'][_0x4993ff]&&this['sendGet_'](_0x4993ff);}['sendConnectStats_'](){const _0x8f3f1={};let _0x1fdaf6='js';_0x8f3f1['sdk.'+_0x1fdaf6+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x8f3f1['framework.cordova']=0x1:Kr()&&(_0x8f3f1['framework.reactnative']=0x1),this['reportStats'](_0x8f3f1);}['shouldReconnect_'](){const _0x33ecc6=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x33ecc6;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3ad4a0,_0x57985e){this['name']=_0x3ad4a0,this['node']=_0x57985e;}static['Wrap'](_0x337203,_0x483338){return new E(_0x337203,_0x483338);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x32a812,_0x6b90ac){const _0xae4afd=new E(We,_0x32a812),_0x5f4a4e=new E(We,_0x6b90ac);return this['compare'](_0xae4afd,_0x5f4a4e)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x3f147){sn=_0x3f147;}['compare'](_0x2a823a,_0x1a640d){return qe(_0x2a823a['name'],_0x1a640d['name']);}['isDefinedOn'](_0x56279a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0xe0d1b5,_0x478d46){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x27776a,_0x11dc3d){return f(typeof _0x27776a=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x27776a,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3883d4,_0x51b065,_0x2d30e3,_0x4fa777,_0x4a61fd=null){this['isReverse_']=_0x4fa777,this['resultGenerator_']=_0x4a61fd,this['nodeStack_']=[];let _0x10e2eb=0x1;for(;!_0x3883d4['isEmpty']();)if(_0x3883d4=_0x3883d4,_0x10e2eb=_0x51b065?_0x2d30e3(_0x3883d4['key'],_0x51b065):0x1,_0x4fa777&&(_0x10e2eb*=-0x1),_0x10e2eb<0x0)this['isReverse_']?_0x3883d4=_0x3883d4['left']:_0x3883d4=_0x3883d4['right'];else{if(_0x10e2eb===0x0){this['nodeStack_']['push'](_0x3883d4);break;}else this['nodeStack_']['push'](_0x3883d4),this['isReverse_']?_0x3883d4=_0x3883d4['right']:_0x3883d4=_0x3883d4['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x563f09=this['nodeStack_']['pop'](),_0x4fce3e;if(this['resultGenerator_']?_0x4fce3e=this['resultGenerator_'](_0x563f09['key'],_0x563f09['value']):_0x4fce3e={'key':_0x563f09['key'],'value':_0x563f09['value']},this['isReverse_']){for(_0x563f09=_0x563f09['left'];!_0x563f09['isEmpty']();)this['nodeStack_']['push'](_0x563f09),_0x563f09=_0x563f09['right'];}else{for(_0x563f09=_0x563f09['right'];!_0x563f09['isEmpty']();)this['nodeStack_']['push'](_0x563f09),_0x563f09=_0x563f09['left'];}return _0x4fce3e;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x226b11=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x226b11['key'],_0x226b11['value']):{'key':_0x226b11['key'],'value':_0x226b11['value']};}}class M{constructor(_0x3accee,_0x39e97a,_0x93113,_0x37475f,_0x11c53b){this['key']=_0x3accee,this['value']=_0x39e97a,this['color']=_0x93113??M['RED'],this['left']=_0x37475f??B['EMPTY_NODE'],this['right']=_0x11c53b??B['EMPTY_NODE'];}['copy'](_0x237b1f,_0x2d8a33,_0x512340,_0x45cf46,_0x2c6777){return new M(_0x237b1f??this['key'],_0x2d8a33??this['value'],_0x512340??this['color'],_0x45cf46??this['left'],_0x2c6777??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2525a7){return this['left']['inorderTraversal'](_0x2525a7)||!!_0x2525a7(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2525a7);}['reverseTraversal'](_0x5f1dc4){return this['right']['reverseTraversal'](_0x5f1dc4)||_0x5f1dc4(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5f1dc4);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1b6bca,_0x1a21ab,_0x153565){let _0x565495=this;const _0x237105=_0x153565(_0x1b6bca,_0x565495['key']);return _0x237105<0x0?_0x565495=_0x565495['copy'](null,null,null,_0x565495['left']['insert'](_0x1b6bca,_0x1a21ab,_0x153565),null):_0x237105===0x0?_0x565495=_0x565495['copy'](null,_0x1a21ab,null,null,null):_0x565495=_0x565495['copy'](null,null,null,null,_0x565495['right']['insert'](_0x1b6bca,_0x1a21ab,_0x153565)),_0x565495['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x401e82=this;return!_0x401e82['left']['isRed_']()&&!_0x401e82['left']['left']['isRed_']()&&(_0x401e82=_0x401e82['moveRedLeft_']()),_0x401e82=_0x401e82['copy'](null,null,null,_0x401e82['left']['removeMin_'](),null),_0x401e82['fixUp_']();}['remove'](_0x56379a,_0xd8acb3){let _0x3f91a1,_0x6e17d9;if(_0x3f91a1=this,_0xd8acb3(_0x56379a,_0x3f91a1['key'])<0x0)!_0x3f91a1['left']['isEmpty']()&&!_0x3f91a1['left']['isRed_']()&&!_0x3f91a1['left']['left']['isRed_']()&&(_0x3f91a1=_0x3f91a1['moveRedLeft_']()),_0x3f91a1=_0x3f91a1['copy'](null,null,null,_0x3f91a1['left']['remove'](_0x56379a,_0xd8acb3),null);else{if(_0x3f91a1['left']['isRed_']()&&(_0x3f91a1=_0x3f91a1['rotateRight_']()),!_0x3f91a1['right']['isEmpty']()&&!_0x3f91a1['right']['isRed_']()&&!_0x3f91a1['right']['left']['isRed_']()&&(_0x3f91a1=_0x3f91a1['moveRedRight_']()),_0xd8acb3(_0x56379a,_0x3f91a1['key'])===0x0){if(_0x3f91a1['right']['isEmpty']())return B['EMPTY_NODE'];_0x6e17d9=_0x3f91a1['right']['min_'](),_0x3f91a1=_0x3f91a1['copy'](_0x6e17d9['key'],_0x6e17d9['value'],null,null,_0x3f91a1['right']['removeMin_']());}_0x3f91a1=_0x3f91a1['copy'](null,null,null,null,_0x3f91a1['right']['remove'](_0x56379a,_0xd8acb3));}return _0x3f91a1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2e90cb=this;return _0x2e90cb['right']['isRed_']()&&!_0x2e90cb['left']['isRed_']()&&(_0x2e90cb=_0x2e90cb['rotateLeft_']()),_0x2e90cb['left']['isRed_']()&&_0x2e90cb['left']['left']['isRed_']()&&(_0x2e90cb=_0x2e90cb['rotateRight_']()),_0x2e90cb['left']['isRed_']()&&_0x2e90cb['right']['isRed_']()&&(_0x2e90cb=_0x2e90cb['colorFlip_']()),_0x2e90cb;}['moveRedLeft_'](){let _0x55813d=this['colorFlip_']();return _0x55813d['right']['left']['isRed_']()&&(_0x55813d=_0x55813d['copy'](null,null,null,null,_0x55813d['right']['rotateRight_']()),_0x55813d=_0x55813d['rotateLeft_'](),_0x55813d=_0x55813d['colorFlip_']()),_0x55813d;}['moveRedRight_'](){let _0x4db7b6=this['colorFlip_']();return _0x4db7b6['left']['left']['isRed_']()&&(_0x4db7b6=_0x4db7b6['rotateRight_'](),_0x4db7b6=_0x4db7b6['colorFlip_']()),_0x4db7b6;}['rotateLeft_'](){const _0x545b44=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x545b44,null);}['rotateRight_'](){const _0x5f23ba=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5f23ba);}['colorFlip_'](){const _0x2b7480=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5ad2f9=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2b7480,_0x5ad2f9);}['checkMaxDepth_'](){const _0x5282fe=this['check_']();return Math['pow'](0x2,_0x5282fe)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x492a07=this['left']['check_']();if(_0x492a07!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x492a07+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x409e81,_0x23a510,_0x2cf60c,_0x2c6429,_0x3f9371){return this;}['insert'](_0x45c5b7,_0x491399,_0x5999f1){return new M(_0x45c5b7,_0x491399,null);}['remove'](_0x78cede,_0x249db6){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2effd6){return!0x1;}['reverseTraversal'](_0x286c03){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x45245e,_0x11da3e=B['EMPTY_NODE']){this['comparator_']=_0x45245e,this['root_']=_0x11da3e;}['insert'](_0x2f10f4,_0x3ea8b2){return new B(this['comparator_'],this['root_']['insert'](_0x2f10f4,_0x3ea8b2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5ea721){return new B(this['comparator_'],this['root_']['remove'](_0x5ea721,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1729c2){let _0x55def2,_0x48794c=this['root_'];for(;!_0x48794c['isEmpty']();){if(_0x55def2=this['comparator_'](_0x1729c2,_0x48794c['key']),_0x55def2===0x0)return _0x48794c['value'];_0x55def2<0x0?_0x48794c=_0x48794c['left']:_0x55def2>0x0&&(_0x48794c=_0x48794c['right']);}return null;}['getPredecessorKey'](_0x2a9464){let _0x541a78,_0x385c34=this['root_'],_0x564213=null;for(;!_0x385c34['isEmpty']();)if(_0x541a78=this['comparator_'](_0x2a9464,_0x385c34['key']),_0x541a78===0x0){if(_0x385c34['left']['isEmpty']())return _0x564213?_0x564213['key']:null;for(_0x385c34=_0x385c34['left'];!_0x385c34['right']['isEmpty']();)_0x385c34=_0x385c34['right'];return _0x385c34['key'];}else _0x541a78<0x0?_0x385c34=_0x385c34['left']:_0x541a78>0x0&&(_0x564213=_0x385c34,_0x385c34=_0x385c34['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x444499){return this['root_']['inorderTraversal'](_0x444499);}['reverseTraversal'](_0x4651fe){return this['root_']['reverseTraversal'](_0x4651fe);}['getIterator'](_0x580b58){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x580b58);}['getIteratorFrom'](_0x3ec8c4,_0xb2614f){return new rn(this['root_'],_0x3ec8c4,this['comparator_'],!0x1,_0xb2614f);}['getReverseIteratorFrom'](_0x1892ae,_0x2cd05e){return new rn(this['root_'],_0x1892ae,this['comparator_'],!0x0,_0x2cd05e);}['getReverseIterator'](_0x4d3d28){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x4d3d28);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x3c629b,_0xa5ab3b){return qe(_0x3c629b['name'],_0xa5ab3b['name']);}function Qi(_0x4125f2,_0x4363c6){return qe(_0x4125f2,_0x4363c6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x3e073c){Ci=_0x3e073c;}const Po=function(_0x1ce65c){return typeof _0x1ce65c=='number'?'number:'+ao(_0x1ce65c):'string:'+_0x1ce65c;},No=function(_0x5e0a75){if(_0x5e0a75['isLeafNode']()){const _0x1ece7b=_0x5e0a75['val']();f(typeof _0x1ece7b=='string'||typeof _0x1ece7b=='number'||typeof _0x1ece7b=='object'&&Q(_0x1ece7b,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5e0a75===Ci||_0x5e0a75['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5e0a75===Ci||_0x5e0a75['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x21a15b){nr=_0x21a15b;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x1cc17c,_0x4375df=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1cc17c,this['priorityNode_']=_0x4375df,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x391a91){return new D(this['value_'],_0x391a91);}['getImmediateChild'](_0x19bd36){return _0x19bd36==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x556b97){return v(_0x556b97)?this:y(_0x556b97)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3d3702,_0x3a34eb){return null;}['updateImmediateChild'](_0x26b811,_0x1a7f2a){return _0x26b811==='.priority'?this['updatePriority'](_0x1a7f2a):_0x1a7f2a['isEmpty']()&&_0x26b811!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x26b811,_0x1a7f2a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x52fe82,_0x3924f2){const _0x2a59a1=y(_0x52fe82);return _0x2a59a1===null?_0x3924f2:_0x3924f2['isEmpty']()&&_0x2a59a1!=='.priority'?this:(f(_0x2a59a1!=='.priority'||Ce(_0x52fe82)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2a59a1,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x52fe82),_0x3924f2)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x22cdac,_0x22526d){return!0x1;}['val'](_0x2e6aa3){return _0x2e6aa3&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x296b6c='';this['priorityNode_']['isEmpty']()||(_0x296b6c+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x838200=typeof this['value_'];_0x296b6c+=_0x838200+':',_0x838200==='number'?_0x296b6c+=ao(this['value_']):_0x296b6c+=this['value_'],this['lazyHash_']=ro(_0x296b6c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x27c763){return _0x27c763===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x27c763 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x27c763['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x27c763));}['compareToLeafNode_'](_0x4f43ae){const _0x378e5c=typeof _0x4f43ae['value_'],_0x5a39da=typeof this['value_'],_0x71c7f7=D['VALUE_TYPE_ORDER']['indexOf'](_0x378e5c),_0x3ce3e2=D['VALUE_TYPE_ORDER']['indexOf'](_0x5a39da);return f(_0x71c7f7>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x378e5c),f(_0x3ce3e2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5a39da),_0x71c7f7===_0x3ce3e2?_0x5a39da==='object'?0x0:this['value_']<_0x4f43ae['value_']?-0x1:this['value_']===_0x4f43ae['value_']?0x0:0x1:_0x3ce3e2-_0x71c7f7;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5de58a){if(_0x5de58a===this)return!0x0;if(_0x5de58a['isLeafNode']()){const _0x169c94=_0x5de58a;return this['value_']===_0x169c94['value_']&&this['priorityNode_']['equals'](_0x169c94['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x1f0c0f){Oo=_0x1f0c0f;}function Wh(_0x4cf2c0){Do=_0x4cf2c0;}class Bh extends Fn{['compare'](_0x448503,_0x2c6426){const _0x4dc4c3=_0x448503['node']['getPriority'](),_0x48c862=_0x2c6426['node']['getPriority'](),_0x30f999=_0x4dc4c3['compareTo'](_0x48c862);return _0x30f999===0x0?qe(_0x448503['name'],_0x2c6426['name']):_0x30f999;}['isDefinedOn'](_0x3b61dd){return!_0x3b61dd['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2aab4a,_0x30f17f){return!_0x2aab4a['getPriority']()['equals'](_0x30f17f['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x597f67,_0x11b6fa){const _0x27e21d=Oo(_0x597f67);return new E(_0x11b6fa,new D('[PRIORITY-POST]',_0x27e21d));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x174568){const _0xc6473c=_0x55f46f=>parseInt(Math['log'](_0x55f46f)/Vh,0xa),_0x525b29=_0x2bedf1=>parseInt(Array(_0x2bedf1+0x1)['join']('1'),0x2);this['count']=_0xc6473c(_0x174568+0x1),this['current_']=this['count']-0x1;const _0x31b8fd=_0x525b29(this['count']);this['bits_']=_0x174568+0x1&_0x31b8fd;}['nextBitIsOne'](){const _0x69e1b9=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x69e1b9;}}const yn=function(_0x363e90,_0xf02cf7,_0x386f15,_0x1c0545){_0x363e90['sort'](_0xf02cf7);const _0x2c1f1d=function(_0xa85ec1,_0xdfee2e){const _0x30f874=_0xdfee2e-_0xa85ec1;let _0x3e5cb8,_0x3d087b;if(_0x30f874===0x0)return null;if(_0x30f874===0x1)return _0x3e5cb8=_0x363e90[_0xa85ec1],_0x3d087b=_0x386f15?_0x386f15(_0x3e5cb8):_0x3e5cb8,new M(_0x3d087b,_0x3e5cb8['node'],M['BLACK'],null,null);{const _0x1f436c=parseInt(_0x30f874/0x2,0xa)+_0xa85ec1,_0x3a0b0d=_0x2c1f1d(_0xa85ec1,_0x1f436c),_0x593d04=_0x2c1f1d(_0x1f436c+0x1,_0xdfee2e);return _0x3e5cb8=_0x363e90[_0x1f436c],_0x3d087b=_0x386f15?_0x386f15(_0x3e5cb8):_0x3e5cb8,new M(_0x3d087b,_0x3e5cb8['node'],M['BLACK'],_0x3a0b0d,_0x593d04);}},_0x394979=function(_0x141d0a){let _0x31ac1c=null,_0x2b3482=null,_0x15e6af=_0x363e90['length'];const _0x54434f=function(_0x24281d,_0x2ca785){const _0x4e1347=_0x15e6af-_0x24281d,_0x2eee21=_0x15e6af;_0x15e6af-=_0x24281d;const _0x818972=_0x2c1f1d(_0x4e1347+0x1,_0x2eee21),_0x175a83=_0x363e90[_0x4e1347],_0x55cfa9=_0x386f15?_0x386f15(_0x175a83):_0x175a83;_0x1c9bdb(new M(_0x55cfa9,_0x175a83['node'],_0x2ca785,null,_0x818972));},_0x1c9bdb=function(_0x3981f0){_0x31ac1c?(_0x31ac1c['left']=_0x3981f0,_0x31ac1c=_0x3981f0):(_0x2b3482=_0x3981f0,_0x31ac1c=_0x3981f0);};for(let _0x353135=0x0;_0x353135<_0x141d0a['count'];++_0x353135){const _0x58f14a=_0x141d0a['nextBitIsOne'](),_0x205655=Math['pow'](0x2,_0x141d0a['count']-(_0x353135+0x1));_0x58f14a?_0x54434f(_0x205655,M['BLACK']):(_0x54434f(_0x205655,M['BLACK']),_0x54434f(_0x205655,M['RED']));}return _0x2b3482;},_0x8e6ed1=new Hh(_0x363e90['length']),_0x1ff27c=_0x394979(_0x8e6ed1);return new B(_0x1c0545||_0xf02cf7,_0x1ff27c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4a7816,_0x52ed48){this['indexes_']=_0x4a7816,this['indexSet_']=_0x52ed48;}['get'](_0x3e15a9){const _0x158b79=Le(this['indexes_'],_0x3e15a9);if(!_0x158b79)throw new Error('No\x20index\x20defined\x20for\x20'+_0x3e15a9);return _0x158b79 instanceof B?_0x158b79:null;}['hasIndex'](_0x566c44){return Q(this['indexSet_'],_0x566c44['toString']());}['addIndex'](_0x35c0c3,_0x49c49d){f(_0x35c0c3!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x490e6a=[];let _0x58ebff=!0x1;const _0x3d1cbf=_0x49c49d['getIterator'](E['Wrap']);let _0x20dd52=_0x3d1cbf['getNext']();for(;_0x20dd52;)_0x58ebff=_0x58ebff||_0x35c0c3['isDefinedOn'](_0x20dd52['node']),_0x490e6a['push'](_0x20dd52),_0x20dd52=_0x3d1cbf['getNext']();let _0x28ba5d;_0x58ebff?_0x28ba5d=yn(_0x490e6a,_0x35c0c3['getCompare']()):_0x28ba5d=Qe;const _0xda12b6=_0x35c0c3['toString'](),_0x345e1b={...this['indexSet_']};_0x345e1b[_0xda12b6]=_0x35c0c3;const _0x5bbdce={...this['indexes_']};return _0x5bbdce[_0xda12b6]=_0x28ba5d,new te(_0x5bbdce,_0x345e1b);}['addToIndexes'](_0x4bf785,_0x1f04e7){const _0x53925f=_n(this['indexes_'],(_0x370f17,_0x4a8aed)=>{const _0x4ed5c9=Le(this['indexSet_'],_0x4a8aed);if(f(_0x4ed5c9,'Missing\x20index\x20implementation\x20for\x20'+_0x4a8aed),_0x370f17===Qe){if(_0x4ed5c9['isDefinedOn'](_0x4bf785['node'])){const _0x41e691=[],_0x1aa030=_0x1f04e7['getIterator'](E['Wrap']);let _0x5bb61f=_0x1aa030['getNext']();for(;_0x5bb61f;)_0x5bb61f['name']!==_0x4bf785['name']&&_0x41e691['push'](_0x5bb61f),_0x5bb61f=_0x1aa030['getNext']();return _0x41e691['push'](_0x4bf785),yn(_0x41e691,_0x4ed5c9['getCompare']());}else return Qe;}else{const _0x4e57cb=_0x1f04e7['get'](_0x4bf785['name']);let _0x1e6077=_0x370f17;return _0x4e57cb&&(_0x1e6077=_0x1e6077['remove'](new E(_0x4bf785['name'],_0x4e57cb))),_0x1e6077['insert'](_0x4bf785,_0x4bf785['node']);}});return new te(_0x53925f,this['indexSet_']);}['removeFromIndexes'](_0x207c21,_0x5a120c){const _0x375676=_n(this['indexes_'],_0xd48c6e=>{if(_0xd48c6e===Qe)return _0xd48c6e;{const _0x52d6e3=_0x5a120c['get'](_0x207c21['name']);return _0x52d6e3?_0xd48c6e['remove'](new E(_0x207c21['name'],_0x52d6e3)):_0xd48c6e;}});return new te(_0x375676,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x2a17f4,_0x237e9a,_0x1e6355){this['children_']=_0x2a17f4,this['priorityNode_']=_0x237e9a,this['indexMap_']=_0x1e6355,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x10fbb8){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x10fbb8,this['indexMap_']);}['getImmediateChild'](_0x4f6ab2){if(_0x4f6ab2==='.priority')return this['getPriority']();{const _0x2910f4=this['children_']['get'](_0x4f6ab2);return _0x2910f4===null?It:_0x2910f4;}}['getChild'](_0x1c0cb7){const _0xdafd1a=y(_0x1c0cb7);return _0xdafd1a===null?this:this['getImmediateChild'](_0xdafd1a)['getChild'](S(_0x1c0cb7));}['hasChild'](_0xaa6dd1){return this['children_']['get'](_0xaa6dd1)!==null;}['updateImmediateChild'](_0x3f168a,_0xf84093){if(f(_0xf84093,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3f168a==='.priority')return this['updatePriority'](_0xf84093);{const _0x7db220=new E(_0x3f168a,_0xf84093);let _0x35d33b,_0x36ad0a;_0xf84093['isEmpty']()?(_0x35d33b=this['children_']['remove'](_0x3f168a),_0x36ad0a=this['indexMap_']['removeFromIndexes'](_0x7db220,this['children_'])):(_0x35d33b=this['children_']['insert'](_0x3f168a,_0xf84093),_0x36ad0a=this['indexMap_']['addToIndexes'](_0x7db220,this['children_']));const _0x5a14b6=_0x35d33b['isEmpty']()?It:this['priorityNode_'];return new g(_0x35d33b,_0x5a14b6,_0x36ad0a);}}['updateChild'](_0x419eac,_0x41ae71){const _0x4ffc70=y(_0x419eac);if(_0x4ffc70===null)return _0x41ae71;{f(y(_0x419eac)!=='.priority'||Ce(_0x419eac)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1db545=this['getImmediateChild'](_0x4ffc70)['updateChild'](S(_0x419eac),_0x41ae71);return this['updateImmediateChild'](_0x4ffc70,_0x1db545);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2b600b){if(this['isEmpty']())return null;const _0x49b4a1={};let _0x2ce602=0x0,_0x53e36a=0x0,_0x8a3e03=!0x0;if(this['forEachChild'](R,(_0x47bcca,_0x52d923)=>{_0x49b4a1[_0x47bcca]=_0x52d923['val'](_0x2b600b),_0x2ce602++,_0x8a3e03&&g['INTEGER_REGEXP_']['test'](_0x47bcca)?_0x53e36a=Math['max'](_0x53e36a,Number(_0x47bcca)):_0x8a3e03=!0x1;}),!_0x2b600b&&_0x8a3e03&&_0x53e36a<0x2*_0x2ce602){const _0x1ac2af=[];for(const _0xa5f42f in _0x49b4a1)_0x1ac2af[_0xa5f42f]=_0x49b4a1[_0xa5f42f];return _0x1ac2af;}else return _0x2b600b&&!this['getPriority']()['isEmpty']()&&(_0x49b4a1['.priority']=this['getPriority']()['val']()),_0x49b4a1;}['hash'](){if(this['lazyHash_']===null){let _0x52be38='';this['getPriority']()['isEmpty']()||(_0x52be38+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x28f73b,_0x197355)=>{const _0x4e5ac5=_0x197355['hash']();_0x4e5ac5!==''&&(_0x52be38+=':'+_0x28f73b+':'+_0x4e5ac5);}),this['lazyHash_']=_0x52be38===''?'':ro(_0x52be38);}return this['lazyHash_'];}['getPredecessorChildName'](_0x48fc04,_0x664667,_0xf7ff32){const _0x93b7c3=this['resolveIndex_'](_0xf7ff32);if(_0x93b7c3){const _0x15dd42=_0x93b7c3['getPredecessorKey'](new E(_0x48fc04,_0x664667));return _0x15dd42?_0x15dd42['name']:null;}else return this['children_']['getPredecessorKey'](_0x48fc04);}['getFirstChildName'](_0x4e61b5){const _0x50ca2e=this['resolveIndex_'](_0x4e61b5);if(_0x50ca2e){const _0x1984ed=_0x50ca2e['minKey']();return _0x1984ed&&_0x1984ed['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x17cf6c){const _0xf4d42a=this['getFirstChildName'](_0x17cf6c);return _0xf4d42a?new E(_0xf4d42a,this['children_']['get'](_0xf4d42a)):null;}['getLastChildName'](_0x5437c6){const _0x39a073=this['resolveIndex_'](_0x5437c6);if(_0x39a073){const _0x2b389f=_0x39a073['maxKey']();return _0x2b389f&&_0x2b389f['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x594cd5){const _0x5461c2=this['getLastChildName'](_0x594cd5);return _0x5461c2?new E(_0x5461c2,this['children_']['get'](_0x5461c2)):null;}['forEachChild'](_0x5d0a7c,_0x5f543d){const _0x368699=this['resolveIndex_'](_0x5d0a7c);return _0x368699?_0x368699['inorderTraversal'](_0x330a83=>_0x5f543d(_0x330a83['name'],_0x330a83['node'])):this['children_']['inorderTraversal'](_0x5f543d);}['getIterator'](_0x43f304){return this['getIteratorFrom'](_0x43f304['minPost'](),_0x43f304);}['getIteratorFrom'](_0x33b196,_0x186d2e){const _0x12745d=this['resolveIndex_'](_0x186d2e);if(_0x12745d)return _0x12745d['getIteratorFrom'](_0x33b196,_0x3a359a=>_0x3a359a);{const _0x46384b=this['children_']['getIteratorFrom'](_0x33b196['name'],E['Wrap']);let _0x2237e8=_0x46384b['peek']();for(;_0x2237e8!=null&&_0x186d2e['compare'](_0x2237e8,_0x33b196)<0x0;)_0x46384b['getNext'](),_0x2237e8=_0x46384b['peek']();return _0x46384b;}}['getReverseIterator'](_0x153e67){return this['getReverseIteratorFrom'](_0x153e67['maxPost'](),_0x153e67);}['getReverseIteratorFrom'](_0x431e19,_0x5f47b1){const _0x524b1a=this['resolveIndex_'](_0x5f47b1);if(_0x524b1a)return _0x524b1a['getReverseIteratorFrom'](_0x431e19,_0x56cfe0=>_0x56cfe0);{const _0x2ae4a6=this['children_']['getReverseIteratorFrom'](_0x431e19['name'],E['Wrap']);let _0x1c5fc6=_0x2ae4a6['peek']();for(;_0x1c5fc6!=null&&_0x5f47b1['compare'](_0x1c5fc6,_0x431e19)>0x0;)_0x2ae4a6['getNext'](),_0x1c5fc6=_0x2ae4a6['peek']();return _0x2ae4a6;}}['compareTo'](_0x3b20df){return this['isEmpty']()?_0x3b20df['isEmpty']()?0x0:-0x1:_0x3b20df['isLeafNode']()||_0x3b20df['isEmpty']()?0x1:_0x3b20df===Kt?-0x1:0x0;}['withIndex'](_0xc588f5){if(_0xc588f5===ve||this['indexMap_']['hasIndex'](_0xc588f5))return this;{const _0x44eba7=this['indexMap_']['addIndex'](_0xc588f5,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x44eba7);}}['isIndexed'](_0x1077bf){return _0x1077bf===ve||this['indexMap_']['hasIndex'](_0x1077bf);}['equals'](_0x4e54e6){if(_0x4e54e6===this)return!0x0;if(_0x4e54e6['isLeafNode']())return!0x1;{const _0x116109=_0x4e54e6;if(this['getPriority']()['equals'](_0x116109['getPriority']())){if(this['children_']['count']()===_0x116109['children_']['count']()){const _0x32719c=this['getIterator'](R),_0x29e13d=_0x116109['getIterator'](R);let _0x4cbcaf=_0x32719c['getNext'](),_0x4e0e09=_0x29e13d['getNext']();for(;_0x4cbcaf&&_0x4e0e09;){if(_0x4cbcaf['name']!==_0x4e0e09['name']||!_0x4cbcaf['node']['equals'](_0x4e0e09['node']))return!0x1;_0x4cbcaf=_0x32719c['getNext'](),_0x4e0e09=_0x29e13d['getNext']();}return _0x4cbcaf===null&&_0x4e0e09===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x47c9a3){return _0x47c9a3===ve?null:this['indexMap_']['get'](_0x47c9a3['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4daf89){return _0x4daf89===this?0x0:0x1;}['equals'](_0x2fbf0f){return _0x2fbf0f===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2abc36){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3a7cbf,_0x243ddb=null){if(_0x3a7cbf===null)return g['EMPTY_NODE'];if(typeof _0x3a7cbf=='object'&&'.priority'in _0x3a7cbf&&(_0x243ddb=_0x3a7cbf['.priority']),f(_0x243ddb===null||typeof _0x243ddb=='string'||typeof _0x243ddb=='number'||typeof _0x243ddb=='object'&&'.sv'in _0x243ddb,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x243ddb),typeof _0x3a7cbf=='object'&&'.value'in _0x3a7cbf&&_0x3a7cbf['.value']!==null&&(_0x3a7cbf=_0x3a7cbf['.value']),typeof _0x3a7cbf!='object'||'.sv'in _0x3a7cbf){const _0x4c4548=_0x3a7cbf;return new D(_0x4c4548,A(_0x243ddb));}if(!(_0x3a7cbf instanceof Array)&&Gh){const _0x28e662=[];let _0x37d273=!0x1;if(x(_0x3a7cbf,(_0x20a46c,_0x356e02)=>{if(_0x20a46c['substring'](0x0,0x1)!=='.'){const _0x5c2059=A(_0x356e02);_0x5c2059['isEmpty']()||(_0x37d273=_0x37d273||!_0x5c2059['getPriority']()['isEmpty'](),_0x28e662['push'](new E(_0x20a46c,_0x5c2059)));}}),_0x28e662['length']===0x0)return g['EMPTY_NODE'];const _0x154964=yn(_0x28e662,xh,_0x1a8e11=>_0x1a8e11['name'],Qi);if(_0x37d273){const _0x47f6fb=yn(_0x28e662,R['getCompare']());return new g(_0x154964,A(_0x243ddb),new te({'.priority':_0x47f6fb},{'.priority':R}));}else return new g(_0x154964,A(_0x243ddb),te['Default']);}else{let _0xa4bd9f=g['EMPTY_NODE'];return x(_0x3a7cbf,(_0x15af50,_0x23e387)=>{if(Q(_0x3a7cbf,_0x15af50)&&_0x15af50['substring'](0x0,0x1)!=='.'){const _0x60e7e3=A(_0x23e387);(_0x60e7e3['isLeafNode']()||!_0x60e7e3['isEmpty']())&&(_0xa4bd9f=_0xa4bd9f['updateImmediateChild'](_0x15af50,_0x60e7e3));}}),_0xa4bd9f['updatePriority'](A(_0x243ddb));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x4ed651){super(),this['indexPath_']=_0x4ed651,f(!v(_0x4ed651)&&y(_0x4ed651)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x23ab64){return _0x23ab64['getChild'](this['indexPath_']);}['isDefinedOn'](_0x34cf4b){return!_0x34cf4b['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x47679b,_0x1a92d2){const _0x1b8efd=this['extractChild'](_0x47679b['node']),_0x4b3a5a=this['extractChild'](_0x1a92d2['node']),_0x1c0f1b=_0x1b8efd['compareTo'](_0x4b3a5a);return _0x1c0f1b===0x0?qe(_0x47679b['name'],_0x1a92d2['name']):_0x1c0f1b;}['makePost'](_0x175b4c,_0x31ee29){const _0x1f7ed0=A(_0x175b4c),_0x5a9cea=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1f7ed0);return new E(_0x31ee29,_0x5a9cea);}['maxPost'](){const _0x5a8d0a=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x5a8d0a);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x466516,_0x556097){const _0x3583f0=_0x466516['node']['compareTo'](_0x556097['node']);return _0x3583f0===0x0?qe(_0x466516['name'],_0x556097['name']):_0x3583f0;}['isDefinedOn'](_0x4b5a82){return!0x0;}['indexedValueChanged'](_0x48f9ed,_0x31ecd5){return!_0x48f9ed['equals'](_0x31ecd5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1530a7,_0x55c011){const _0x363f91=A(_0x1530a7);return new E(_0x55c011,_0x363f91);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x16eba5){return{'type':'value','snapshotNode':_0x16eba5};}function rt(_0x21544e,_0x5737d2){return{'type':'child_added','snapshotNode':_0x5737d2,'childName':_0x21544e};}function Lt(_0x4692ab,_0x2b8baf){return{'type':'child_removed','snapshotNode':_0x2b8baf,'childName':_0x4692ab};}function xt(_0x3fc9bd,_0x5f19e7,_0x21f4f4){return{'type':'child_changed','snapshotNode':_0x5f19e7,'childName':_0x3fc9bd,'oldSnap':_0x21f4f4};}function zh(_0x5635b0,_0x3efec9){return{'type':'child_moved','snapshotNode':_0x3efec9,'childName':_0x5635b0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0xcd4ce5){this['index_']=_0xcd4ce5;}['updateChild'](_0x30fc76,_0x5d1d47,_0x3a8b8d,_0x5c8178,_0x53d165,_0x108698){f(_0x30fc76['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2f9170=_0x30fc76['getImmediateChild'](_0x5d1d47);return _0x2f9170['getChild'](_0x5c8178)['equals'](_0x3a8b8d['getChild'](_0x5c8178))&&_0x2f9170['isEmpty']()===_0x3a8b8d['isEmpty']()||(_0x108698!=null&&(_0x3a8b8d['isEmpty']()?_0x30fc76['hasChild'](_0x5d1d47)?_0x108698['trackChildChange'](Lt(_0x5d1d47,_0x2f9170)):f(_0x30fc76['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2f9170['isEmpty']()?_0x108698['trackChildChange'](rt(_0x5d1d47,_0x3a8b8d)):_0x108698['trackChildChange'](xt(_0x5d1d47,_0x3a8b8d,_0x2f9170))),_0x30fc76['isLeafNode']()&&_0x3a8b8d['isEmpty']())?_0x30fc76:_0x30fc76['updateImmediateChild'](_0x5d1d47,_0x3a8b8d)['withIndex'](this['index_']);}['updateFullNode'](_0x142c3a,_0x14ddfd,_0x3e60e1){return _0x3e60e1!=null&&(_0x142c3a['isLeafNode']()||_0x142c3a['forEachChild'](R,(_0x31269f,_0x433c10)=>{_0x14ddfd['hasChild'](_0x31269f)||_0x3e60e1['trackChildChange'](Lt(_0x31269f,_0x433c10));}),_0x14ddfd['isLeafNode']()||_0x14ddfd['forEachChild'](R,(_0x4fef0c,_0x23a508)=>{if(_0x142c3a['hasChild'](_0x4fef0c)){const _0x33d1c0=_0x142c3a['getImmediateChild'](_0x4fef0c);_0x33d1c0['equals'](_0x23a508)||_0x3e60e1['trackChildChange'](xt(_0x4fef0c,_0x23a508,_0x33d1c0));}else _0x3e60e1['trackChildChange'](rt(_0x4fef0c,_0x23a508));})),_0x14ddfd['withIndex'](this['index_']);}['updatePriority'](_0x588126,_0x3cb44c){return _0x588126['isEmpty']()?g['EMPTY_NODE']:_0x588126['updatePriority'](_0x3cb44c);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x24ad82){this['indexedFilter_']=new Xi(_0x24ad82['getIndex']()),this['index_']=_0x24ad82['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x24ad82),this['endPost_']=Ft['getEndPost_'](_0x24ad82),this['startIsInclusive_']=!_0x24ad82['startAfterSet_'],this['endIsInclusive_']=!_0x24ad82['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x431528){const _0x57a038=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x431528)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x431528)<0x0,_0x20c1c7=this['endIsInclusive_']?this['index_']['compare'](_0x431528,this['getEndPost']())<=0x0:this['index_']['compare'](_0x431528,this['getEndPost']())<0x0;return _0x57a038&&_0x20c1c7;}['updateChild'](_0x1b56cb,_0x577695,_0x19aad3,_0x517c85,_0x597f61,_0x1862df){return this['matches'](new E(_0x577695,_0x19aad3))||(_0x19aad3=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1b56cb,_0x577695,_0x19aad3,_0x517c85,_0x597f61,_0x1862df);}['updateFullNode'](_0x59e0d3,_0xd1abae,_0x3f9393){_0xd1abae['isLeafNode']()&&(_0xd1abae=g['EMPTY_NODE']);let _0x4413fc=_0xd1abae['withIndex'](this['index_']);_0x4413fc=_0x4413fc['updatePriority'](g['EMPTY_NODE']);const _0x14c47a=this;return _0xd1abae['forEachChild'](R,(_0x144ba6,_0x4b7260)=>{_0x14c47a['matches'](new E(_0x144ba6,_0x4b7260))||(_0x4413fc=_0x4413fc['updateImmediateChild'](_0x144ba6,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x59e0d3,_0x4413fc,_0x3f9393);}['updatePriority'](_0x17127e,_0xf6f076){return _0x17127e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x188ef5){if(_0x188ef5['hasStart']()){const _0x542dd2=_0x188ef5['getIndexStartName']();return _0x188ef5['getIndex']()['makePost'](_0x188ef5['getIndexStartValue'](),_0x542dd2);}else return _0x188ef5['getIndex']()['minPost']();}static['getEndPost_'](_0x2a3bc6){if(_0x2a3bc6['hasEnd']()){const _0x182cbf=_0x2a3bc6['getIndexEndName']();return _0x2a3bc6['getIndex']()['makePost'](_0x2a3bc6['getIndexEndValue'](),_0x182cbf);}else return _0x2a3bc6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x471d5b){this['withinDirectionalStart']=_0xfb4936=>this['reverse_']?this['withinEndPost'](_0xfb4936):this['withinStartPost'](_0xfb4936),this['withinDirectionalEnd']=_0x37d241=>this['reverse_']?this['withinStartPost'](_0x37d241):this['withinEndPost'](_0x37d241),this['withinStartPost']=_0x45fd63=>{const _0x4bd971=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x45fd63);return this['startIsInclusive_']?_0x4bd971<=0x0:_0x4bd971<0x0;},this['withinEndPost']=_0x118a3b=>{const _0x31ab2d=this['index_']['compare'](_0x118a3b,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x31ab2d<=0x0:_0x31ab2d<0x0;},this['rangedFilter_']=new Ft(_0x471d5b),this['index_']=_0x471d5b['getIndex'](),this['limit_']=_0x471d5b['getLimit'](),this['reverse_']=!_0x471d5b['isViewFromLeft'](),this['startIsInclusive_']=!_0x471d5b['startAfterSet_'],this['endIsInclusive_']=!_0x471d5b['endBeforeSet_'];}['updateChild'](_0x5ce90f,_0xb23c55,_0x4a2120,_0x15d38b,_0x7b2698,_0x2fdd70){return this['rangedFilter_']['matches'](new E(_0xb23c55,_0x4a2120))||(_0x4a2120=g['EMPTY_NODE']),_0x5ce90f['getImmediateChild'](_0xb23c55)['equals'](_0x4a2120)?_0x5ce90f:_0x5ce90f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5ce90f,_0xb23c55,_0x4a2120,_0x15d38b,_0x7b2698,_0x2fdd70):this['fullLimitUpdateChild_'](_0x5ce90f,_0xb23c55,_0x4a2120,_0x7b2698,_0x2fdd70);}['updateFullNode'](_0x102f5b,_0x308d25,_0x1e3837){let _0x49c0de;if(_0x308d25['isLeafNode']()||_0x308d25['isEmpty']())_0x49c0de=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x308d25['numChildren']()&&_0x308d25['isIndexed'](this['index_'])){_0x49c0de=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x704b6b;this['reverse_']?_0x704b6b=_0x308d25['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x704b6b=_0x308d25['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x93d3db=0x0;for(;_0x704b6b['hasNext']()&&_0x93d3db<this['limit_'];){const _0x327403=_0x704b6b['getNext']();if(this['withinDirectionalStart'](_0x327403)){if(this['withinDirectionalEnd'](_0x327403))_0x49c0de=_0x49c0de['updateImmediateChild'](_0x327403['name'],_0x327403['node']),_0x93d3db++;else break;}else continue;}}else{_0x49c0de=_0x308d25['withIndex'](this['index_']),_0x49c0de=_0x49c0de['updatePriority'](g['EMPTY_NODE']);let _0x520164;this['reverse_']?_0x520164=_0x49c0de['getReverseIterator'](this['index_']):_0x520164=_0x49c0de['getIterator'](this['index_']);let _0x5fd767=0x0;for(;_0x520164['hasNext']();){const _0x5b100e=_0x520164['getNext']();_0x5fd767<this['limit_']&&this['withinDirectionalStart'](_0x5b100e)&&this['withinDirectionalEnd'](_0x5b100e)?_0x5fd767++:_0x49c0de=_0x49c0de['updateImmediateChild'](_0x5b100e['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x102f5b,_0x49c0de,_0x1e3837);}['updatePriority'](_0x354a6e,_0x31d838){return _0x354a6e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x9d2730,_0x844da8,_0x43104a,_0x31848b,_0x42f104){let _0xcb4790;if(this['reverse_']){const _0x557410=this['index_']['getCompare']();_0xcb4790=(_0x12c7ae,_0x2daf14)=>_0x557410(_0x2daf14,_0x12c7ae);}else _0xcb4790=this['index_']['getCompare']();const _0x2cfc0b=_0x9d2730;f(_0x2cfc0b['numChildren']()===this['limit_'],'');const _0x5c03f7=new E(_0x844da8,_0x43104a),_0x21287b=this['reverse_']?_0x2cfc0b['getFirstChild'](this['index_']):_0x2cfc0b['getLastChild'](this['index_']),_0x5e60bd=this['rangedFilter_']['matches'](_0x5c03f7);if(_0x2cfc0b['hasChild'](_0x844da8)){const _0xbabb23=_0x2cfc0b['getImmediateChild'](_0x844da8);let _0x24a0c9=_0x31848b['getChildAfterChild'](this['index_'],_0x21287b,this['reverse_']);for(;_0x24a0c9!=null&&(_0x24a0c9['name']===_0x844da8||_0x2cfc0b['hasChild'](_0x24a0c9['name']));)_0x24a0c9=_0x31848b['getChildAfterChild'](this['index_'],_0x24a0c9,this['reverse_']);const _0x265b9a=_0x24a0c9==null?0x1:_0xcb4790(_0x24a0c9,_0x5c03f7);if(_0x5e60bd&&!_0x43104a['isEmpty']()&&_0x265b9a>=0x0)return _0x42f104!=null&&_0x42f104['trackChildChange'](xt(_0x844da8,_0x43104a,_0xbabb23)),_0x2cfc0b['updateImmediateChild'](_0x844da8,_0x43104a);{_0x42f104!=null&&_0x42f104['trackChildChange'](Lt(_0x844da8,_0xbabb23));const _0x4efead=_0x2cfc0b['updateImmediateChild'](_0x844da8,g['EMPTY_NODE']);return _0x24a0c9!=null&&this['rangedFilter_']['matches'](_0x24a0c9)?(_0x42f104!=null&&_0x42f104['trackChildChange'](rt(_0x24a0c9['name'],_0x24a0c9['node'])),_0x4efead['updateImmediateChild'](_0x24a0c9['name'],_0x24a0c9['node'])):_0x4efead;}}else return _0x43104a['isEmpty']()?_0x9d2730:_0x5e60bd&&_0xcb4790(_0x21287b,_0x5c03f7)>=0x0?(_0x42f104!=null&&(_0x42f104['trackChildChange'](Lt(_0x21287b['name'],_0x21287b['node'])),_0x42f104['trackChildChange'](rt(_0x844da8,_0x43104a))),_0x2cfc0b['updateImmediateChild'](_0x844da8,_0x43104a)['updateImmediateChild'](_0x21287b['name'],g['EMPTY_NODE'])):_0x9d2730;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x1271a5=new Zi();return _0x1271a5['limitSet_']=this['limitSet_'],_0x1271a5['limit_']=this['limit_'],_0x1271a5['startSet_']=this['startSet_'],_0x1271a5['startAfterSet_']=this['startAfterSet_'],_0x1271a5['indexStartValue_']=this['indexStartValue_'],_0x1271a5['startNameSet_']=this['startNameSet_'],_0x1271a5['indexStartName_']=this['indexStartName_'],_0x1271a5['endSet_']=this['endSet_'],_0x1271a5['endBeforeSet_']=this['endBeforeSet_'],_0x1271a5['indexEndValue_']=this['indexEndValue_'],_0x1271a5['endNameSet_']=this['endNameSet_'],_0x1271a5['indexEndName_']=this['indexEndName_'],_0x1271a5['index_']=this['index_'],_0x1271a5['viewFrom_']=this['viewFrom_'],_0x1271a5;}}function Kh(_0x37c827){return _0x37c827['loadsAllData']()?new Xi(_0x37c827['getIndex']()):_0x37c827['hasLimit']()?new jh(_0x37c827):new Ft(_0x37c827);}function Yh(_0x19f180,_0x118f25){const _0xf4a915=_0x19f180['copy']();return _0xf4a915['limitSet_']=!0x0,_0xf4a915['limit_']=_0x118f25,_0xf4a915['viewFrom_']='l',_0xf4a915;}function Qh(_0x30c4a0,_0x40c08d,_0x58d349){const _0x1577a8=_0x30c4a0['copy']();return _0x1577a8['startSet_']=!0x0,_0x40c08d===void 0x0&&(_0x40c08d=null),_0x1577a8['indexStartValue_']=_0x40c08d,_0x58d349!=null?(_0x1577a8['startNameSet_']=!0x0,_0x1577a8['indexStartName_']=_0x58d349):(_0x1577a8['startNameSet_']=!0x1,_0x1577a8['indexStartName_']=''),_0x1577a8;}function Jh(_0x2be046,_0x3a1bb5,_0x24d6e8){const _0x26e4f4=_0x2be046['copy']();return _0x26e4f4['endSet_']=!0x0,_0x3a1bb5===void 0x0&&(_0x3a1bb5=null),_0x26e4f4['indexEndValue_']=_0x3a1bb5,_0x24d6e8!==void 0x0?(_0x26e4f4['endNameSet_']=!0x0,_0x26e4f4['indexEndName_']=_0x24d6e8):(_0x26e4f4['endNameSet_']=!0x1,_0x26e4f4['indexEndName_']=''),_0x26e4f4;}function xo(_0x20f28a,_0x439810){const _0x471ebe=_0x20f28a['copy']();return _0x471ebe['index_']=_0x439810,_0x471ebe;}function ir(_0x178ff6){const _0x149ad1={};if(_0x178ff6['isDefault']())return _0x149ad1;let _0x2e916d;if(_0x178ff6['index_']===R?_0x2e916d='$priority':_0x178ff6['index_']===Mo?_0x2e916d='$value':_0x178ff6['index_']===ve?_0x2e916d='$key':(f(_0x178ff6['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x2e916d=_0x178ff6['index_']['toString']()),_0x149ad1['orderBy']=O(_0x2e916d),_0x178ff6['startSet_']){const _0x28d651=_0x178ff6['startAfterSet_']?'startAfter':'startAt';_0x149ad1[_0x28d651]=O(_0x178ff6['indexStartValue_']),_0x178ff6['startNameSet_']&&(_0x149ad1[_0x28d651]+=','+O(_0x178ff6['indexStartName_']));}if(_0x178ff6['endSet_']){const _0x175ee4=_0x178ff6['endBeforeSet_']?'endBefore':'endAt';_0x149ad1[_0x175ee4]=O(_0x178ff6['indexEndValue_']),_0x178ff6['endNameSet_']&&(_0x149ad1[_0x175ee4]+=','+O(_0x178ff6['indexEndName_']));}return _0x178ff6['limitSet_']&&(_0x178ff6['isViewFromLeft']()?_0x149ad1['limitToFirst']=_0x178ff6['limit_']:_0x149ad1['limitToLast']=_0x178ff6['limit_']),_0x149ad1;}function sr(_0x556e6d){const _0x51c180={};if(_0x556e6d['startSet_']&&(_0x51c180['sp']=_0x556e6d['indexStartValue_'],_0x556e6d['startNameSet_']&&(_0x51c180['sn']=_0x556e6d['indexStartName_']),_0x51c180['sin']=!_0x556e6d['startAfterSet_']),_0x556e6d['endSet_']&&(_0x51c180['ep']=_0x556e6d['indexEndValue_'],_0x556e6d['endNameSet_']&&(_0x51c180['en']=_0x556e6d['indexEndName_']),_0x51c180['ein']=!_0x556e6d['endBeforeSet_']),_0x556e6d['limitSet_']){_0x51c180['l']=_0x556e6d['limit_'];let _0x322dc6=_0x556e6d['viewFrom_'];_0x322dc6===''&&(_0x556e6d['isViewFromLeft']()?_0x322dc6='l':_0x322dc6='r'),_0x51c180['vf']=_0x322dc6;}return _0x556e6d['index_']!==R&&(_0x51c180['i']=_0x556e6d['index_']['toString']()),_0x51c180;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xe0541d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xfaa5f5,_0x11bf80){return _0x11bf80!==void 0x0?'tag$'+_0x11bf80:(f(_0xfaa5f5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xfaa5f5['_path']['toString']());}constructor(_0x3e0250,_0x4be305,_0xd01f81,_0xa39454){super(),this['repoInfo_']=_0x3e0250,this['onDataUpdate_']=_0x4be305,this['authTokenProvider_']=_0xd01f81,this['appCheckTokenProvider_']=_0xa39454,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x138922,_0x5c8d15,_0x1e466c,_0x2ed39c){const _0x3e78e0=_0x138922['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e78e0+'\x20'+_0x138922['_queryIdentifier']);const _0xac4eb3=vn['getListenId_'](_0x138922,_0x1e466c),_0x4e9fde={};this['listens_'][_0xac4eb3]=_0x4e9fde;const _0x205016=ir(_0x138922['_queryParams']);this['restRequest_'](_0x3e78e0+'.json',_0x205016,(_0x1b8a93,_0x296d56)=>{let _0x4e74f4=_0x296d56;if(_0x1b8a93===0x194&&(_0x4e74f4=null,_0x1b8a93=null),_0x1b8a93===null&&this['onDataUpdate_'](_0x3e78e0,_0x4e74f4,!0x1,_0x1e466c),Le(this['listens_'],_0xac4eb3)===_0x4e9fde){let _0x346282;_0x1b8a93?_0x1b8a93===0x191?_0x346282='permission_denied':_0x346282='rest_error:'+_0x1b8a93:_0x346282='ok',_0x2ed39c(_0x346282,null);}});}['unlisten'](_0x3f1aba,_0x2e6412){const _0x3e87d7=vn['getListenId_'](_0x3f1aba,_0x2e6412);delete this['listens_'][_0x3e87d7];}['get'](_0x232ac5){const _0xb09105=ir(_0x232ac5['_queryParams']),_0x39b549=_0x232ac5['_path']['toString'](),_0x1290f7=new H();return this['restRequest_'](_0x39b549+'.json',_0xb09105,(_0x41f478,_0x32a197)=>{let _0x314b4b=_0x32a197;_0x41f478===0x194&&(_0x314b4b=null,_0x41f478=null),_0x41f478===null?(this['onDataUpdate_'](_0x39b549,_0x314b4b,!0x1,null),_0x1290f7['resolve'](_0x314b4b)):_0x1290f7['reject'](new Error(_0x314b4b));}),_0x1290f7['promise'];}['refreshAuthToken'](_0x2b14b5){}['restRequest_'](_0x3ed8e9,_0xf3da33={},_0x48ea74){return _0xf3da33['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x13e8ad,_0x7d1233])=>{_0x13e8ad&&_0x13e8ad['accessToken']&&(_0xf3da33['auth']=_0x13e8ad['accessToken']),_0x7d1233&&_0x7d1233['token']&&(_0xf3da33['ac']=_0x7d1233['token']);const _0x56fc74=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3ed8e9+'?ns='+this['repoInfo_']['namespace']+ut(_0xf3da33);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x56fc74);const _0x534a19=new XMLHttpRequest();_0x534a19['onreadystatechange']=()=>{if(_0x48ea74&&_0x534a19['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x56fc74+'\x20received.\x20status:',_0x534a19['status'],'response:',_0x534a19['responseText']);let _0x4c02f6=null;if(_0x534a19['status']>=0xc8&&_0x534a19['status']<0x12c){try{_0x4c02f6=Nt(_0x534a19['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x56fc74+':\x20'+_0x534a19['responseText']);}_0x48ea74(null,_0x4c02f6);}else _0x534a19['status']!==0x191&&_0x534a19['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x56fc74+'\x20Status:\x20'+_0x534a19['status']),_0x48ea74(_0x534a19['status']);_0x48ea74=null;}},_0x534a19['open']('GET',_0x56fc74,!0x0),_0x534a19['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2d32f5){return this['rootNode_']['getChild'](_0x2d32f5);}['updateSnapshot'](_0x2734d2,_0x12adf5){this['rootNode_']=this['rootNode_']['updateChild'](_0x2734d2,_0x12adf5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x41759a,_0xb98477,_0x34cdd7){if(v(_0xb98477))_0x41759a['value']=_0x34cdd7,_0x41759a['children']['clear']();else{if(_0x41759a['value']!==null)_0x41759a['value']=_0x41759a['value']['updateChild'](_0xb98477,_0x34cdd7);else{const _0x490bd5=y(_0xb98477);_0x41759a['children']['has'](_0x490bd5)||_0x41759a['children']['set'](_0x490bd5,En());const _0x526bff=_0x41759a['children']['get'](_0x490bd5);_0xb98477=S(_0xb98477),pt(_0x526bff,_0xb98477,_0x34cdd7);}}}function Ti(_0x2aaf41,_0x416598){if(v(_0x416598))return _0x2aaf41['value']=null,_0x2aaf41['children']['clear'](),!0x0;if(_0x2aaf41['value']!==null){if(_0x2aaf41['value']['isLeafNode']())return!0x1;{const _0x10575f=_0x2aaf41['value'];return _0x2aaf41['value']=null,_0x10575f['forEachChild'](R,(_0x32b2d3,_0x76a132)=>{pt(_0x2aaf41,new C(_0x32b2d3),_0x76a132);}),Ti(_0x2aaf41,_0x416598);}}else{if(_0x2aaf41['children']['size']>0x0){const _0x297b07=y(_0x416598);return _0x416598=S(_0x416598),_0x2aaf41['children']['has'](_0x297b07)&&Ti(_0x2aaf41['children']['get'](_0x297b07),_0x416598)&&_0x2aaf41['children']['delete'](_0x297b07),_0x2aaf41['children']['size']===0x0;}else return!0x0;}}function Si(_0x3e708b,_0x25bc27,_0x13a8b0){_0x3e708b['value']!==null?_0x13a8b0(_0x25bc27,_0x3e708b['value']):Zh(_0x3e708b,(_0x56e7d3,_0x4e96b7)=>{const _0x3c0e73=new C(_0x25bc27['toString']()+'/'+_0x56e7d3);Si(_0x4e96b7,_0x3c0e73,_0x13a8b0);});}function Zh(_0x1c6e8d,_0x3de5e2){_0x1c6e8d['children']['forEach']((_0x2c92c4,_0xd708c9)=>{_0x3de5e2(_0xd708c9,_0x2c92c4);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x485999){this['collection_']=_0x485999,this['last_']=null;}['get'](){const _0x44711e=this['collection_']['get'](),_0x41acc2={..._0x44711e};return this['last_']&&x(this['last_'],(_0x471987,_0x35f93d)=>{_0x41acc2[_0x471987]=_0x41acc2[_0x471987]-_0x35f93d;}),this['last_']=_0x44711e,_0x41acc2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0xcc114d,_0x5858a6){this['server_']=_0x5858a6,this['statsToReport_']={},this['statsListener_']=new eu(_0xcc114d);const _0x1dbf75=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1dbf75));}['reportStats_'](){const _0x58bf4d=this['statsListener_']['get'](),_0x16d09f={};let _0x443f2c=!0x1;x(_0x58bf4d,(_0x2036c5,_0x271026)=>{_0x271026>0x0&&Q(this['statsToReport_'],_0x2036c5)&&(_0x16d09f[_0x2036c5]=_0x271026,_0x443f2c=!0x0);}),_0x443f2c&&this['server_']['reportStats'](_0x16d09f),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4afcbf){_0x4afcbf[_0x4afcbf['OVERWRITE']=0x0]='OVERWRITE',_0x4afcbf[_0x4afcbf['MERGE']=0x1]='MERGE',_0x4afcbf[_0x4afcbf['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4afcbf[_0x4afcbf['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1aa32e){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1aa32e,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x9ddbef,_0xc3a77d,_0x122cac){this['path']=_0x9ddbef,this['affectedTree']=_0xc3a77d,this['revert']=_0x122cac,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x296179){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x5b0a56=this['affectedTree']['subtree'](new C(_0x296179));return new In(w(),_0x5b0a56,this['revert']);}}else return f(y(this['path'])===_0x296179,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x476b74,_0x1a2c4d){this['source']=_0x476b74,this['path']=_0x1a2c4d,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x90e76d){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xa31dff,_0x1dc6e1,_0x56b52a){this['source']=_0xa31dff,this['path']=_0x1dc6e1,this['snap']=_0x56b52a,this['type']=z['OVERWRITE'];}['operationForChild'](_0x45c71c){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x45c71c)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x611334,_0x250a6c,_0x4e0a58){this['source']=_0x611334,this['path']=_0x250a6c,this['children']=_0x4e0a58,this['type']=z['MERGE'];}['operationForChild'](_0x4e338e){if(v(this['path'])){const _0x6ff53b=this['children']['subtree'](new C(_0x4e338e));return _0x6ff53b['isEmpty']()?null:_0x6ff53b['value']?new Be(this['source'],w(),_0x6ff53b['value']):new ot(this['source'],w(),_0x6ff53b);}else return f(y(this['path'])===_0x4e338e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x1fbdde,_0x2d8008,_0x40db94){this['node_']=_0x1fbdde,this['fullyInitialized_']=_0x2d8008,this['filtered_']=_0x40db94;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x532c38){if(v(_0x532c38))return this['isFullyInitialized']()&&!this['filtered_'];const _0x267311=y(_0x532c38);return this['isCompleteForChild'](_0x267311);}['isCompleteForChild'](_0x2361cd){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2361cd);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x4439c0){this['query_']=_0x4439c0,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x23a850,_0x5065e8,_0x37fe7e,_0x18c185){const _0x11134e=[],_0x3d9958=[];return _0x5065e8['forEach'](_0x327993=>{_0x327993['type']==='child_changed'&&_0x23a850['index_']['indexedValueChanged'](_0x327993['oldSnap'],_0x327993['snapshotNode'])&&_0x3d9958['push'](zh(_0x327993['childName'],_0x327993['snapshotNode']));}),wt(_0x23a850,_0x11134e,'child_removed',_0x5065e8,_0x18c185,_0x37fe7e),wt(_0x23a850,_0x11134e,'child_added',_0x5065e8,_0x18c185,_0x37fe7e),wt(_0x23a850,_0x11134e,'child_moved',_0x3d9958,_0x18c185,_0x37fe7e),wt(_0x23a850,_0x11134e,'child_changed',_0x5065e8,_0x18c185,_0x37fe7e),wt(_0x23a850,_0x11134e,'value',_0x5065e8,_0x18c185,_0x37fe7e),_0x11134e;}function wt(_0x2ce604,_0x4c9e7c,_0x44819d,_0x18f0c4,_0x3f9f71,_0x2101a6){const _0x1b70fc=_0x18f0c4['filter'](_0x3ac004=>_0x3ac004['type']===_0x44819d);_0x1b70fc['sort']((_0x204e49,_0x2fff8c)=>au(_0x2ce604,_0x204e49,_0x2fff8c)),_0x1b70fc['forEach'](_0x30be9d=>{const _0x270bb0=ou(_0x2ce604,_0x30be9d,_0x2101a6);_0x3f9f71['forEach'](_0x1c5d5d=>{_0x1c5d5d['respondsTo'](_0x30be9d['type'])&&_0x4c9e7c['push'](_0x1c5d5d['createEvent'](_0x270bb0,_0x2ce604['query_']));});});}function ou(_0x5af448,_0x31dd52,_0x3f21e2){return _0x31dd52['type']==='value'||_0x31dd52['type']==='child_removed'||(_0x31dd52['prevName']=_0x3f21e2['getPredecessorChildName'](_0x31dd52['childName'],_0x31dd52['snapshotNode'],_0x5af448['index_'])),_0x31dd52;}function au(_0x9205b4,_0x36d8cb,_0x3ed0a5){if(_0x36d8cb['childName']==null||_0x3ed0a5['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x39c3e4=new E(_0x36d8cb['childName'],_0x36d8cb['snapshotNode']),_0xc3618a=new E(_0x3ed0a5['childName'],_0x3ed0a5['snapshotNode']);return _0x9205b4['index_']['compare'](_0x39c3e4,_0xc3618a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x310bbd,_0x474985){return{'eventCache':_0x310bbd,'serverCache':_0x474985};}function Rt(_0x4d9fd7,_0xb373ef,_0x4ee65a,_0x305f2d){return Un(new Te(_0xb373ef,_0x4ee65a,_0x305f2d),_0x4d9fd7['serverCache']);}function Fo(_0x43a4e2,_0x47d037,_0x31917d,_0x2b2aa2){return Un(_0x43a4e2['eventCache'],new Te(_0x47d037,_0x31917d,_0x2b2aa2));}function wn(_0x268821){return _0x268821['eventCache']['isFullyInitialized']()?_0x268821['eventCache']['getNode']():null;}function Ve(_0x4692f7){return _0x4692f7['serverCache']['isFullyInitialized']()?_0x4692f7['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x35b8be){let _0xf381d7=new b(null);return x(_0x35b8be,(_0xdd0c0b,_0xd714cb)=>{_0xf381d7=_0xf381d7['set'](new C(_0xdd0c0b),_0xd714cb);}),_0xf381d7;}constructor(_0xb4f37,_0x58a906=cu()){this['value']=_0xb4f37,this['children']=_0x58a906;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x3d6b19,_0x82b345){if(this['value']!=null&&_0x82b345(this['value']))return{'path':w(),'value':this['value']};if(v(_0x3d6b19))return null;{const _0x1c5f10=y(_0x3d6b19),_0x323d4d=this['children']['get'](_0x1c5f10);if(_0x323d4d!==null){const _0x556ccf=_0x323d4d['findRootMostMatchingPathAndValue'](S(_0x3d6b19),_0x82b345);return _0x556ccf!=null?{'path':k(new C(_0x1c5f10),_0x556ccf['path']),'value':_0x556ccf['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x103b0b){return this['findRootMostMatchingPathAndValue'](_0x103b0b,()=>!0x0);}['subtree'](_0x2e1c8d){if(v(_0x2e1c8d))return this;{const _0x5e09fc=y(_0x2e1c8d),_0x2ede30=this['children']['get'](_0x5e09fc);return _0x2ede30!==null?_0x2ede30['subtree'](S(_0x2e1c8d)):new b(null);}}['set'](_0x4de283,_0x174a7c){if(v(_0x4de283))return new b(_0x174a7c,this['children']);{const _0xd25a04=y(_0x4de283),_0x1e3c13=(this['children']['get'](_0xd25a04)||new b(null))['set'](S(_0x4de283),_0x174a7c),_0x326a53=this['children']['insert'](_0xd25a04,_0x1e3c13);return new b(this['value'],_0x326a53);}}['remove'](_0x762b1){if(v(_0x762b1))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x3dcf87=y(_0x762b1),_0xaaa5d2=this['children']['get'](_0x3dcf87);if(_0xaaa5d2){const _0x32f35f=_0xaaa5d2['remove'](S(_0x762b1));let _0x44c755;return _0x32f35f['isEmpty']()?_0x44c755=this['children']['remove'](_0x3dcf87):_0x44c755=this['children']['insert'](_0x3dcf87,_0x32f35f),this['value']===null&&_0x44c755['isEmpty']()?new b(null):new b(this['value'],_0x44c755);}else return this;}}['get'](_0xaa49b9){if(v(_0xaa49b9))return this['value'];{const _0x4eeeb7=y(_0xaa49b9),_0x23fb1a=this['children']['get'](_0x4eeeb7);return _0x23fb1a?_0x23fb1a['get'](S(_0xaa49b9)):null;}}['setTree'](_0x1276b5,_0x50e441){if(v(_0x1276b5))return _0x50e441;{const _0x28dcd0=y(_0x1276b5),_0x53c4d1=(this['children']['get'](_0x28dcd0)||new b(null))['setTree'](S(_0x1276b5),_0x50e441);let _0x2b53e5;return _0x53c4d1['isEmpty']()?_0x2b53e5=this['children']['remove'](_0x28dcd0):_0x2b53e5=this['children']['insert'](_0x28dcd0,_0x53c4d1),new b(this['value'],_0x2b53e5);}}['fold'](_0x5a5468){return this['fold_'](w(),_0x5a5468);}['fold_'](_0x23169f,_0x541d2e){const _0x2bb0ed={};return this['children']['inorderTraversal']((_0x466f01,_0x298cb8)=>{_0x2bb0ed[_0x466f01]=_0x298cb8['fold_'](k(_0x23169f,_0x466f01),_0x541d2e);}),_0x541d2e(_0x23169f,this['value'],_0x2bb0ed);}['findOnPath'](_0x26916d,_0x5e02d9){return this['findOnPath_'](_0x26916d,w(),_0x5e02d9);}['findOnPath_'](_0x7fa32f,_0x309063,_0x125dfa){const _0x24be7a=this['value']?_0x125dfa(_0x309063,this['value']):!0x1;if(_0x24be7a)return _0x24be7a;if(v(_0x7fa32f))return null;{const _0x56e9c9=y(_0x7fa32f),_0x5c92ce=this['children']['get'](_0x56e9c9);return _0x5c92ce?_0x5c92ce['findOnPath_'](S(_0x7fa32f),k(_0x309063,_0x56e9c9),_0x125dfa):null;}}['foreachOnPath'](_0x4d7f9e,_0x198ee8){return this['foreachOnPath_'](_0x4d7f9e,w(),_0x198ee8);}['foreachOnPath_'](_0x104d89,_0x3c8c84,_0x5b570c){if(v(_0x104d89))return this;{this['value']&&_0x5b570c(_0x3c8c84,this['value']);const _0x27d3d3=y(_0x104d89),_0x4e06f2=this['children']['get'](_0x27d3d3);return _0x4e06f2?_0x4e06f2['foreachOnPath_'](S(_0x104d89),k(_0x3c8c84,_0x27d3d3),_0x5b570c):new b(null);}}['foreach'](_0x24b59c){this['foreach_'](w(),_0x24b59c);}['foreach_'](_0x40c999,_0x3ac346){this['children']['inorderTraversal']((_0x4013f9,_0x56dd39)=>{_0x56dd39['foreach_'](k(_0x40c999,_0x4013f9),_0x3ac346);}),this['value']&&_0x3ac346(_0x40c999,this['value']);}['foreachChild'](_0x49d7cf){this['children']['inorderTraversal']((_0x181ac6,_0x41c08b)=>{_0x41c08b['value']&&_0x49d7cf(_0x181ac6,_0x41c08b['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4cf83c){this['writeTree_']=_0x4cf83c;}static['empty'](){return new K(new b(null));}}function At(_0x2ad211,_0xcc8d5,_0x1060b9){if(v(_0xcc8d5))return new K(new b(_0x1060b9));{const _0x1e4cc1=_0x2ad211['writeTree_']['findRootMostValueAndPath'](_0xcc8d5);if(_0x1e4cc1!=null){const _0x103841=_0x1e4cc1['path'];let _0x20da5c=_0x1e4cc1['value'];const _0x285c59=F(_0x103841,_0xcc8d5);return _0x20da5c=_0x20da5c['updateChild'](_0x285c59,_0x1060b9),new K(_0x2ad211['writeTree_']['set'](_0x103841,_0x20da5c));}else{const _0x52cdcb=new b(_0x1060b9),_0x21f063=_0x2ad211['writeTree_']['setTree'](_0xcc8d5,_0x52cdcb);return new K(_0x21f063);}}}function bi(_0x3715d0,_0x4eb654,_0x1d0a8b){let _0x183345=_0x3715d0;return x(_0x1d0a8b,(_0x45c69f,_0x516675)=>{_0x183345=At(_0x183345,k(_0x4eb654,_0x45c69f),_0x516675);}),_0x183345;}function or(_0x4a1838,_0x3b5dd2){if(v(_0x3b5dd2))return K['empty']();{const _0x569a4c=_0x4a1838['writeTree_']['setTree'](_0x3b5dd2,new b(null));return new K(_0x569a4c);}}function Ri(_0x1832e7,_0x35e996){return ze(_0x1832e7,_0x35e996)!=null;}function ze(_0x3562b2,_0x242d12){const _0x1b6f4f=_0x3562b2['writeTree_']['findRootMostValueAndPath'](_0x242d12);return _0x1b6f4f!=null?_0x3562b2['writeTree_']['get'](_0x1b6f4f['path'])['getChild'](F(_0x1b6f4f['path'],_0x242d12)):null;}function ar(_0x2e3cb0){const _0x4b5bd1=[],_0x372cd9=_0x2e3cb0['writeTree_']['value'];return _0x372cd9!=null?_0x372cd9['isLeafNode']()||_0x372cd9['forEachChild'](R,(_0x5f3b04,_0x4416d7)=>{_0x4b5bd1['push'](new E(_0x5f3b04,_0x4416d7));}):_0x2e3cb0['writeTree_']['children']['inorderTraversal']((_0x1c492d,_0x297c09)=>{_0x297c09['value']!=null&&_0x4b5bd1['push'](new E(_0x1c492d,_0x297c09['value']));}),_0x4b5bd1;}function Ee(_0x5100c5,_0x322e7c){if(v(_0x322e7c))return _0x5100c5;{const _0x14cd06=ze(_0x5100c5,_0x322e7c);return _0x14cd06!=null?new K(new b(_0x14cd06)):new K(_0x5100c5['writeTree_']['subtree'](_0x322e7c));}}function Ai(_0x3d4c99){return _0x3d4c99['writeTree_']['isEmpty']();}function at(_0x474f03,_0x53d633){return Uo(w(),_0x474f03['writeTree_'],_0x53d633);}function Uo(_0x35b2f3,_0x5969e7,_0x2092a8){if(_0x5969e7['value']!=null)return _0x2092a8['updateChild'](_0x35b2f3,_0x5969e7['value']);{let _0xd5f32e=null;return _0x5969e7['children']['inorderTraversal']((_0xaa91b8,_0x3632d0)=>{_0xaa91b8==='.priority'?(f(_0x3632d0['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0xd5f32e=_0x3632d0['value']):_0x2092a8=Uo(k(_0x35b2f3,_0xaa91b8),_0x3632d0,_0x2092a8);}),!_0x2092a8['getChild'](_0x35b2f3)['isEmpty']()&&_0xd5f32e!==null&&(_0x2092a8=_0x2092a8['updateChild'](k(_0x35b2f3,'.priority'),_0xd5f32e)),_0x2092a8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x4d908b,_0x58b611){return Ho(_0x58b611,_0x4d908b);}function lu(_0x155aef,_0x1aab41,_0x5a1f50,_0x15e9c7,_0x57b6e3){f(_0x15e9c7>_0x155aef['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x57b6e3===void 0x0&&(_0x57b6e3=!0x0),_0x155aef['allWrites']['push']({'path':_0x1aab41,'snap':_0x5a1f50,'writeId':_0x15e9c7,'visible':_0x57b6e3}),_0x57b6e3&&(_0x155aef['visibleWrites']=At(_0x155aef['visibleWrites'],_0x1aab41,_0x5a1f50)),_0x155aef['lastWriteId']=_0x15e9c7;}function hu(_0x162213,_0x4454ba,_0x2ccb20,_0x2aad8e){f(_0x2aad8e>_0x162213['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x162213['allWrites']['push']({'path':_0x4454ba,'children':_0x2ccb20,'writeId':_0x2aad8e,'visible':!0x0}),_0x162213['visibleWrites']=bi(_0x162213['visibleWrites'],_0x4454ba,_0x2ccb20),_0x162213['lastWriteId']=_0x2aad8e;}function uu(_0x388ba6,_0x588f8d){for(let _0x33fdbf=0x0;_0x33fdbf<_0x388ba6['allWrites']['length'];_0x33fdbf++){const _0x5da449=_0x388ba6['allWrites'][_0x33fdbf];if(_0x5da449['writeId']===_0x588f8d)return _0x5da449;}return null;}function du(_0x5b666f,_0x6a7292){const _0x2665fe=_0x5b666f['allWrites']['findIndex'](_0x58d6b6=>_0x58d6b6['writeId']===_0x6a7292);f(_0x2665fe>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1a4128=_0x5b666f['allWrites'][_0x2665fe];_0x5b666f['allWrites']['splice'](_0x2665fe,0x1);let _0x2310dc=_0x1a4128['visible'],_0x38a6b0=!0x1,_0x3334d1=_0x5b666f['allWrites']['length']-0x1;for(;_0x2310dc&&_0x3334d1>=0x0;){const _0x5b9d50=_0x5b666f['allWrites'][_0x3334d1];_0x5b9d50['visible']&&(_0x3334d1>=_0x2665fe&&fu(_0x5b9d50,_0x1a4128['path'])?_0x2310dc=!0x1:G(_0x1a4128['path'],_0x5b9d50['path'])&&(_0x38a6b0=!0x0)),_0x3334d1--;}if(_0x2310dc){if(_0x38a6b0)return pu(_0x5b666f),!0x0;if(_0x1a4128['snap'])_0x5b666f['visibleWrites']=or(_0x5b666f['visibleWrites'],_0x1a4128['path']);else{const _0xe4c6af=_0x1a4128['children'];x(_0xe4c6af,_0x2d6c54=>{_0x5b666f['visibleWrites']=or(_0x5b666f['visibleWrites'],k(_0x1a4128['path'],_0x2d6c54));});}return!0x0;}else return!0x1;}function fu(_0x217daf,_0x40eef6){if(_0x217daf['snap'])return G(_0x217daf['path'],_0x40eef6);for(const _0xf0a968 in _0x217daf['children'])if(_0x217daf['children']['hasOwnProperty'](_0xf0a968)&&G(k(_0x217daf['path'],_0xf0a968),_0x40eef6))return!0x0;return!0x1;}function pu(_0x249968){_0x249968['visibleWrites']=Wo(_0x249968['allWrites'],_u,w()),_0x249968['allWrites']['length']>0x0?_0x249968['lastWriteId']=_0x249968['allWrites'][_0x249968['allWrites']['length']-0x1]['writeId']:_0x249968['lastWriteId']=-0x1;}function _u(_0x2c2b55){return _0x2c2b55['visible'];}function Wo(_0x2164da,_0x588cf2,_0x27fc7d){let _0x4d3de5=K['empty']();for(let _0x1e185f=0x0;_0x1e185f<_0x2164da['length'];++_0x1e185f){const _0x420ab0=_0x2164da[_0x1e185f];if(_0x588cf2(_0x420ab0)){const _0x59ca50=_0x420ab0['path'];let _0x244e9c;if(_0x420ab0['snap'])G(_0x27fc7d,_0x59ca50)?(_0x244e9c=F(_0x27fc7d,_0x59ca50),_0x4d3de5=At(_0x4d3de5,_0x244e9c,_0x420ab0['snap'])):G(_0x59ca50,_0x27fc7d)&&(_0x244e9c=F(_0x59ca50,_0x27fc7d),_0x4d3de5=At(_0x4d3de5,w(),_0x420ab0['snap']['getChild'](_0x244e9c)));else{if(_0x420ab0['children']){if(G(_0x27fc7d,_0x59ca50))_0x244e9c=F(_0x27fc7d,_0x59ca50),_0x4d3de5=bi(_0x4d3de5,_0x244e9c,_0x420ab0['children']);else{if(G(_0x59ca50,_0x27fc7d)){if(_0x244e9c=F(_0x59ca50,_0x27fc7d),v(_0x244e9c))_0x4d3de5=bi(_0x4d3de5,w(),_0x420ab0['children']);else{const _0x3a7018=Le(_0x420ab0['children'],y(_0x244e9c));if(_0x3a7018){const _0x3126b6=_0x3a7018['getChild'](S(_0x244e9c));_0x4d3de5=At(_0x4d3de5,w(),_0x3126b6);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4d3de5;}function Bo(_0x3bd23e,_0x342cf7,_0x5a6a98,_0x2aca9b,_0x3a58c0){if(!_0x2aca9b&&!_0x3a58c0){const _0x46a0a9=ze(_0x3bd23e['visibleWrites'],_0x342cf7);if(_0x46a0a9!=null)return _0x46a0a9;{const _0x573159=Ee(_0x3bd23e['visibleWrites'],_0x342cf7);if(Ai(_0x573159))return _0x5a6a98;if(_0x5a6a98==null&&!Ri(_0x573159,w()))return null;{const _0x59ffed=_0x5a6a98||g['EMPTY_NODE'];return at(_0x573159,_0x59ffed);}}}else{const _0x44df9d=Ee(_0x3bd23e['visibleWrites'],_0x342cf7);if(!_0x3a58c0&&Ai(_0x44df9d))return _0x5a6a98;if(!_0x3a58c0&&_0x5a6a98==null&&!Ri(_0x44df9d,w()))return null;{const _0x2834c8=function(_0x59b5f1){return(_0x59b5f1['visible']||_0x3a58c0)&&(!_0x2aca9b||!~_0x2aca9b['indexOf'](_0x59b5f1['writeId']))&&(G(_0x59b5f1['path'],_0x342cf7)||G(_0x342cf7,_0x59b5f1['path']));},_0x40745e=Wo(_0x3bd23e['allWrites'],_0x2834c8,_0x342cf7),_0x5706c1=_0x5a6a98||g['EMPTY_NODE'];return at(_0x40745e,_0x5706c1);}}}function gu(_0x4750eb,_0xb8caf,_0x434eb3){let _0xe64c3e=g['EMPTY_NODE'];const _0x3f4489=ze(_0x4750eb['visibleWrites'],_0xb8caf);if(_0x3f4489)return _0x3f4489['isLeafNode']()||_0x3f4489['forEachChild'](R,(_0x2fc2b4,_0x48a49f)=>{_0xe64c3e=_0xe64c3e['updateImmediateChild'](_0x2fc2b4,_0x48a49f);}),_0xe64c3e;if(_0x434eb3){const _0x439209=Ee(_0x4750eb['visibleWrites'],_0xb8caf);return _0x434eb3['forEachChild'](R,(_0x3b3cb4,_0x219a34)=>{const _0x180254=at(Ee(_0x439209,new C(_0x3b3cb4)),_0x219a34);_0xe64c3e=_0xe64c3e['updateImmediateChild'](_0x3b3cb4,_0x180254);}),ar(_0x439209)['forEach'](_0x52285f=>{_0xe64c3e=_0xe64c3e['updateImmediateChild'](_0x52285f['name'],_0x52285f['node']);}),_0xe64c3e;}else{const _0x45b7db=Ee(_0x4750eb['visibleWrites'],_0xb8caf);return ar(_0x45b7db)['forEach'](_0x176b53=>{_0xe64c3e=_0xe64c3e['updateImmediateChild'](_0x176b53['name'],_0x176b53['node']);}),_0xe64c3e;}}function mu(_0x56d862,_0x11245a,_0x4b4276,_0x2ed086,_0x3345ab){f(_0x2ed086||_0x3345ab,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4687ce=k(_0x11245a,_0x4b4276);if(Ri(_0x56d862['visibleWrites'],_0x4687ce))return null;{const _0x142e31=Ee(_0x56d862['visibleWrites'],_0x4687ce);return Ai(_0x142e31)?_0x3345ab['getChild'](_0x4b4276):at(_0x142e31,_0x3345ab['getChild'](_0x4b4276));}}function yu(_0x714aed,_0x1b0483,_0x2642e4,_0x141254){const _0x1f931b=k(_0x1b0483,_0x2642e4),_0x3ae87c=ze(_0x714aed['visibleWrites'],_0x1f931b);if(_0x3ae87c!=null)return _0x3ae87c;if(_0x141254['isCompleteForChild'](_0x2642e4)){const _0x16595a=Ee(_0x714aed['visibleWrites'],_0x1f931b);return at(_0x16595a,_0x141254['getNode']()['getImmediateChild'](_0x2642e4));}else return null;}function vu(_0x3c614a,_0x5337a2){return ze(_0x3c614a['visibleWrites'],_0x5337a2);}function Eu(_0x2cbd53,_0x50bacc,_0x572e4c,_0x3134e7,_0x244523,_0x407d41,_0x2bb997){let _0xdc9c9a;const _0x1e3aba=Ee(_0x2cbd53['visibleWrites'],_0x50bacc),_0x35a587=ze(_0x1e3aba,w());if(_0x35a587!=null)_0xdc9c9a=_0x35a587;else{if(_0x572e4c!=null)_0xdc9c9a=at(_0x1e3aba,_0x572e4c);else return[];}if(_0xdc9c9a=_0xdc9c9a['withIndex'](_0x2bb997),!_0xdc9c9a['isEmpty']()&&!_0xdc9c9a['isLeafNode']()){const _0x5510d0=[],_0x3dbfb0=_0x2bb997['getCompare'](),_0x3a6c15=_0x407d41?_0xdc9c9a['getReverseIteratorFrom'](_0x3134e7,_0x2bb997):_0xdc9c9a['getIteratorFrom'](_0x3134e7,_0x2bb997);let _0x136e94=_0x3a6c15['getNext']();for(;_0x136e94&&_0x5510d0['length']<_0x244523;)_0x3dbfb0(_0x136e94,_0x3134e7)!==0x0&&_0x5510d0['push'](_0x136e94),_0x136e94=_0x3a6c15['getNext']();return _0x5510d0;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2a80b3,_0x307ee8,_0x310282,_0x2e30f4){return Bo(_0x2a80b3['writeTree'],_0x2a80b3['treePath'],_0x307ee8,_0x310282,_0x2e30f4);}function is(_0x1709fe,_0x2ccb3e){return gu(_0x1709fe['writeTree'],_0x1709fe['treePath'],_0x2ccb3e);}function cr(_0x5b21c7,_0x16a44a,_0x352600,_0xcb7184){return mu(_0x5b21c7['writeTree'],_0x5b21c7['treePath'],_0x16a44a,_0x352600,_0xcb7184);}function Tn(_0x2c1556,_0x465c5e){return vu(_0x2c1556['writeTree'],k(_0x2c1556['treePath'],_0x465c5e));}function wu(_0x3f53f8,_0x34171b,_0x19838b,_0x11953b,_0x28c2ee,_0x5f787e){return Eu(_0x3f53f8['writeTree'],_0x3f53f8['treePath'],_0x34171b,_0x19838b,_0x11953b,_0x28c2ee,_0x5f787e);}function ss(_0x2f4e0b,_0x8ad741,_0x1cc263){return yu(_0x2f4e0b['writeTree'],_0x2f4e0b['treePath'],_0x8ad741,_0x1cc263);}function Vo(_0x375a52,_0x503827){return Ho(k(_0x375a52['treePath'],_0x503827),_0x375a52['writeTree']);}function Ho(_0x6e0e71,_0x483afc){return{'treePath':_0x6e0e71,'writeTree':_0x483afc};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x18e898){const _0xc011fc=_0x18e898['type'],_0x37c5ae=_0x18e898['childName'];f(_0xc011fc==='child_added'||_0xc011fc==='child_changed'||_0xc011fc==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x37c5ae!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x594aa0=this['changeMap']['get'](_0x37c5ae);if(_0x594aa0){const _0x15d7d2=_0x594aa0['type'];if(_0xc011fc==='child_added'&&_0x15d7d2==='child_removed')this['changeMap']['set'](_0x37c5ae,xt(_0x37c5ae,_0x18e898['snapshotNode'],_0x594aa0['snapshotNode']));else{if(_0xc011fc==='child_removed'&&_0x15d7d2==='child_added')this['changeMap']['delete'](_0x37c5ae);else{if(_0xc011fc==='child_removed'&&_0x15d7d2==='child_changed')this['changeMap']['set'](_0x37c5ae,Lt(_0x37c5ae,_0x594aa0['oldSnap']));else{if(_0xc011fc==='child_changed'&&_0x15d7d2==='child_added')this['changeMap']['set'](_0x37c5ae,rt(_0x37c5ae,_0x18e898['snapshotNode']));else{if(_0xc011fc==='child_changed'&&_0x15d7d2==='child_changed')this['changeMap']['set'](_0x37c5ae,xt(_0x37c5ae,_0x18e898['snapshotNode'],_0x594aa0['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x18e898+'\x20occurred\x20after\x20'+_0x594aa0);}}}}}else this['changeMap']['set'](_0x37c5ae,_0x18e898);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3fd7e0){return null;}['getChildAfterChild'](_0x371ae1,_0x1f548b,_0x55006a){return null;}}const $o=new Tu();class rs{constructor(_0x4506c9,_0x19bb57,_0x110926=null){this['writes_']=_0x4506c9,this['viewCache_']=_0x19bb57,this['optCompleteServerCache_']=_0x110926;}['getCompleteChild'](_0x20bb1b){const _0x405d86=this['viewCache_']['eventCache'];if(_0x405d86['isCompleteForChild'](_0x20bb1b))return _0x405d86['getNode']()['getImmediateChild'](_0x20bb1b);{const _0x51e025=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x20bb1b,_0x51e025);}}['getChildAfterChild'](_0x230e47,_0x232bd3,_0x805c1){const _0x4c4e5d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x4616e6=wu(this['writes_'],_0x4c4e5d,_0x232bd3,0x1,_0x805c1,_0x230e47);return _0x4616e6['length']===0x0?null:_0x4616e6[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x24dc30){return{'filter':_0x24dc30};}function bu(_0x17b09b,_0x5d8ee9){f(_0x5d8ee9['eventCache']['getNode']()['isIndexed'](_0x17b09b['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5d8ee9['serverCache']['getNode']()['isIndexed'](_0x17b09b['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x510e66,_0x39b596,_0x1b630a,_0x4a7b92,_0x429ccc){const _0x36d958=new Cu();let _0x31205a,_0x2889f9;if(_0x1b630a['type']===z['OVERWRITE']){const _0x25a9d2=_0x1b630a;_0x25a9d2['source']['fromUser']?_0x31205a=ki(_0x510e66,_0x39b596,_0x25a9d2['path'],_0x25a9d2['snap'],_0x4a7b92,_0x429ccc,_0x36d958):(f(_0x25a9d2['source']['fromServer'],'Unknown\x20source.'),_0x2889f9=_0x25a9d2['source']['tagged']||_0x39b596['serverCache']['isFiltered']()&&!v(_0x25a9d2['path']),_0x31205a=Sn(_0x510e66,_0x39b596,_0x25a9d2['path'],_0x25a9d2['snap'],_0x4a7b92,_0x429ccc,_0x2889f9,_0x36d958));}else{if(_0x1b630a['type']===z['MERGE']){const _0x2e4e99=_0x1b630a;_0x2e4e99['source']['fromUser']?_0x31205a=ku(_0x510e66,_0x39b596,_0x2e4e99['path'],_0x2e4e99['children'],_0x4a7b92,_0x429ccc,_0x36d958):(f(_0x2e4e99['source']['fromServer'],'Unknown\x20source.'),_0x2889f9=_0x2e4e99['source']['tagged']||_0x39b596['serverCache']['isFiltered'](),_0x31205a=Pi(_0x510e66,_0x39b596,_0x2e4e99['path'],_0x2e4e99['children'],_0x4a7b92,_0x429ccc,_0x2889f9,_0x36d958));}else{if(_0x1b630a['type']===z['ACK_USER_WRITE']){const _0x5a35f1=_0x1b630a;_0x5a35f1['revert']?_0x31205a=Ou(_0x510e66,_0x39b596,_0x5a35f1['path'],_0x4a7b92,_0x429ccc,_0x36d958):_0x31205a=Pu(_0x510e66,_0x39b596,_0x5a35f1['path'],_0x5a35f1['affectedTree'],_0x4a7b92,_0x429ccc,_0x36d958);}else{if(_0x1b630a['type']===z['LISTEN_COMPLETE'])_0x31205a=Nu(_0x510e66,_0x39b596,_0x1b630a['path'],_0x4a7b92,_0x36d958);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1b630a['type']);}}}const _0x5813df=_0x36d958['getChanges']();return Au(_0x39b596,_0x31205a,_0x5813df),{'viewCache':_0x31205a,'changes':_0x5813df};}function Au(_0x1ec90b,_0x2da28c,_0x49ca6e){const _0x148302=_0x2da28c['eventCache'];if(_0x148302['isFullyInitialized']()){const _0x5dae57=_0x148302['getNode']()['isLeafNode']()||_0x148302['getNode']()['isEmpty'](),_0x3211f0=wn(_0x1ec90b);(_0x49ca6e['length']>0x0||!_0x1ec90b['eventCache']['isFullyInitialized']()||_0x5dae57&&!_0x148302['getNode']()['equals'](_0x3211f0)||!_0x148302['getNode']()['getPriority']()['equals'](_0x3211f0['getPriority']()))&&_0x49ca6e['push'](Lo(wn(_0x2da28c)));}}function Go(_0x31502b,_0xf98962,_0x443aab,_0x138471,_0x5765aa,_0x355faf){const _0x14f34f=_0xf98962['eventCache'];if(Tn(_0x138471,_0x443aab)!=null)return _0xf98962;{let _0x3f07dc,_0x160342;if(v(_0x443aab)){if(f(_0xf98962['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xf98962['serverCache']['isFiltered']()){const _0x28d98e=Ve(_0xf98962),_0x552450=_0x28d98e instanceof g?_0x28d98e:g['EMPTY_NODE'],_0x2f75e1=is(_0x138471,_0x552450);_0x3f07dc=_0x31502b['filter']['updateFullNode'](_0xf98962['eventCache']['getNode'](),_0x2f75e1,_0x355faf);}else{const _0x392468=Cn(_0x138471,Ve(_0xf98962));_0x3f07dc=_0x31502b['filter']['updateFullNode'](_0xf98962['eventCache']['getNode'](),_0x392468,_0x355faf);}}else{const _0xb3a013=y(_0x443aab);if(_0xb3a013==='.priority'){f(Ce(_0x443aab)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2ffe4d=_0x14f34f['getNode']();_0x160342=_0xf98962['serverCache']['getNode']();const _0x1efc06=cr(_0x138471,_0x443aab,_0x2ffe4d,_0x160342);_0x1efc06!=null?_0x3f07dc=_0x31502b['filter']['updatePriority'](_0x2ffe4d,_0x1efc06):_0x3f07dc=_0x14f34f['getNode']();}else{const _0x14148a=S(_0x443aab);let _0x187292;if(_0x14f34f['isCompleteForChild'](_0xb3a013)){_0x160342=_0xf98962['serverCache']['getNode']();const _0x7bb5e9=cr(_0x138471,_0x443aab,_0x14f34f['getNode'](),_0x160342);_0x7bb5e9!=null?_0x187292=_0x14f34f['getNode']()['getImmediateChild'](_0xb3a013)['updateChild'](_0x14148a,_0x7bb5e9):_0x187292=_0x14f34f['getNode']()['getImmediateChild'](_0xb3a013);}else _0x187292=ss(_0x138471,_0xb3a013,_0xf98962['serverCache']);_0x187292!=null?_0x3f07dc=_0x31502b['filter']['updateChild'](_0x14f34f['getNode'](),_0xb3a013,_0x187292,_0x14148a,_0x5765aa,_0x355faf):_0x3f07dc=_0x14f34f['getNode']();}}return Rt(_0xf98962,_0x3f07dc,_0x14f34f['isFullyInitialized']()||v(_0x443aab),_0x31502b['filter']['filtersNodes']());}}function Sn(_0x1905a5,_0x1f6159,_0x2cd12f,_0x3cbfd1,_0x41f511,_0x23fb16,_0x170bb7,_0x2154d3){const _0x62262=_0x1f6159['serverCache'];let _0xabf7a5;const _0x2dfc1d=_0x170bb7?_0x1905a5['filter']:_0x1905a5['filter']['getIndexedFilter']();if(v(_0x2cd12f))_0xabf7a5=_0x2dfc1d['updateFullNode'](_0x62262['getNode'](),_0x3cbfd1,null);else{if(_0x2dfc1d['filtersNodes']()&&!_0x62262['isFiltered']()){const _0x4e4108=_0x62262['getNode']()['updateChild'](_0x2cd12f,_0x3cbfd1);_0xabf7a5=_0x2dfc1d['updateFullNode'](_0x62262['getNode'](),_0x4e4108,null);}else{const _0x103b97=y(_0x2cd12f);if(!_0x62262['isCompleteForPath'](_0x2cd12f)&&Ce(_0x2cd12f)>0x1)return _0x1f6159;const _0x4dee9a=S(_0x2cd12f),_0x29b628=_0x62262['getNode']()['getImmediateChild'](_0x103b97)['updateChild'](_0x4dee9a,_0x3cbfd1);_0x103b97==='.priority'?_0xabf7a5=_0x2dfc1d['updatePriority'](_0x62262['getNode'](),_0x29b628):_0xabf7a5=_0x2dfc1d['updateChild'](_0x62262['getNode'](),_0x103b97,_0x29b628,_0x4dee9a,$o,null);}}const _0x393a8e=Fo(_0x1f6159,_0xabf7a5,_0x62262['isFullyInitialized']()||v(_0x2cd12f),_0x2dfc1d['filtersNodes']()),_0x2c52a4=new rs(_0x41f511,_0x393a8e,_0x23fb16);return Go(_0x1905a5,_0x393a8e,_0x2cd12f,_0x41f511,_0x2c52a4,_0x2154d3);}function ki(_0x3f8d97,_0x554457,_0x5e2c7e,_0x2ccd86,_0x15107f,_0xe49941,_0x22e1f0){const _0x270b44=_0x554457['eventCache'];let _0x5469ac,_0x505497;const _0x506f79=new rs(_0x15107f,_0x554457,_0xe49941);if(v(_0x5e2c7e))_0x505497=_0x3f8d97['filter']['updateFullNode'](_0x554457['eventCache']['getNode'](),_0x2ccd86,_0x22e1f0),_0x5469ac=Rt(_0x554457,_0x505497,!0x0,_0x3f8d97['filter']['filtersNodes']());else{const _0x44386a=y(_0x5e2c7e);if(_0x44386a==='.priority')_0x505497=_0x3f8d97['filter']['updatePriority'](_0x554457['eventCache']['getNode'](),_0x2ccd86),_0x5469ac=Rt(_0x554457,_0x505497,_0x270b44['isFullyInitialized'](),_0x270b44['isFiltered']());else{const _0x13e61a=S(_0x5e2c7e),_0x405d66=_0x270b44['getNode']()['getImmediateChild'](_0x44386a);let _0x48c6ba;if(v(_0x13e61a))_0x48c6ba=_0x2ccd86;else{const _0x3cf568=_0x506f79['getCompleteChild'](_0x44386a);_0x3cf568!=null?ji(_0x13e61a)==='.priority'&&_0x3cf568['getChild'](Ro(_0x13e61a))['isEmpty']()?_0x48c6ba=_0x3cf568:_0x48c6ba=_0x3cf568['updateChild'](_0x13e61a,_0x2ccd86):_0x48c6ba=g['EMPTY_NODE'];}if(_0x405d66['equals'](_0x48c6ba))_0x5469ac=_0x554457;else{const _0x16e2f6=_0x3f8d97['filter']['updateChild'](_0x270b44['getNode'](),_0x44386a,_0x48c6ba,_0x13e61a,_0x506f79,_0x22e1f0);_0x5469ac=Rt(_0x554457,_0x16e2f6,_0x270b44['isFullyInitialized'](),_0x3f8d97['filter']['filtersNodes']());}}}return _0x5469ac;}function lr(_0x17d3c1,_0x592a27){return _0x17d3c1['eventCache']['isCompleteForChild'](_0x592a27);}function ku(_0x4194d5,_0x5adae2,_0x3a97e8,_0x25ee30,_0x563242,_0x5eaa46,_0x5628d2){let _0x4f3106=_0x5adae2;return _0x25ee30['foreach']((_0x3be53b,_0x400eef)=>{const _0x3a520e=k(_0x3a97e8,_0x3be53b);lr(_0x5adae2,y(_0x3a520e))&&(_0x4f3106=ki(_0x4194d5,_0x4f3106,_0x3a520e,_0x400eef,_0x563242,_0x5eaa46,_0x5628d2));}),_0x25ee30['foreach']((_0x51fa60,_0x17fbc2)=>{const _0xf3befd=k(_0x3a97e8,_0x51fa60);lr(_0x5adae2,y(_0xf3befd))||(_0x4f3106=ki(_0x4194d5,_0x4f3106,_0xf3befd,_0x17fbc2,_0x563242,_0x5eaa46,_0x5628d2));}),_0x4f3106;}function hr(_0x225399,_0x44029c,_0x56c325){return _0x56c325['foreach']((_0x5aed67,_0x4aa013)=>{_0x44029c=_0x44029c['updateChild'](_0x5aed67,_0x4aa013);}),_0x44029c;}function Pi(_0x1da373,_0x66056,_0x52452f,_0x79368,_0x395d1b,_0x194ff7,_0x243ce3,_0x48749d){if(_0x66056['serverCache']['getNode']()['isEmpty']()&&!_0x66056['serverCache']['isFullyInitialized']())return _0x66056;let _0x3f060c=_0x66056,_0x2f40e5;v(_0x52452f)?_0x2f40e5=_0x79368:_0x2f40e5=new b(null)['setTree'](_0x52452f,_0x79368);const _0x4d8bc6=_0x66056['serverCache']['getNode']();return _0x2f40e5['children']['inorderTraversal']((_0x47a9fe,_0x23c2d1)=>{if(_0x4d8bc6['hasChild'](_0x47a9fe)){const _0x5c32af=_0x66056['serverCache']['getNode']()['getImmediateChild'](_0x47a9fe),_0x483ca5=hr(_0x1da373,_0x5c32af,_0x23c2d1);_0x3f060c=Sn(_0x1da373,_0x3f060c,new C(_0x47a9fe),_0x483ca5,_0x395d1b,_0x194ff7,_0x243ce3,_0x48749d);}}),_0x2f40e5['children']['inorderTraversal']((_0x2fbd9a,_0x4a8820)=>{const _0x4817fe=!_0x66056['serverCache']['isCompleteForChild'](_0x2fbd9a)&&_0x4a8820['value']===null;if(!_0x4d8bc6['hasChild'](_0x2fbd9a)&&!_0x4817fe){const _0x4609d4=_0x66056['serverCache']['getNode']()['getImmediateChild'](_0x2fbd9a),_0x2f16ab=hr(_0x1da373,_0x4609d4,_0x4a8820);_0x3f060c=Sn(_0x1da373,_0x3f060c,new C(_0x2fbd9a),_0x2f16ab,_0x395d1b,_0x194ff7,_0x243ce3,_0x48749d);}}),_0x3f060c;}function Pu(_0x4e36c9,_0x16ebf0,_0x5f2628,_0x1fec73,_0x1fdf20,_0x5ce913,_0x40f2ca){if(Tn(_0x1fdf20,_0x5f2628)!=null)return _0x16ebf0;const _0x121f09=_0x16ebf0['serverCache']['isFiltered'](),_0x239e06=_0x16ebf0['serverCache'];if(_0x1fec73['value']!=null){if(v(_0x5f2628)&&_0x239e06['isFullyInitialized']()||_0x239e06['isCompleteForPath'](_0x5f2628))return Sn(_0x4e36c9,_0x16ebf0,_0x5f2628,_0x239e06['getNode']()['getChild'](_0x5f2628),_0x1fdf20,_0x5ce913,_0x121f09,_0x40f2ca);if(v(_0x5f2628)){let _0x22f2d6=new b(null);return _0x239e06['getNode']()['forEachChild'](ve,(_0x222365,_0x2d3426)=>{_0x22f2d6=_0x22f2d6['set'](new C(_0x222365),_0x2d3426);}),Pi(_0x4e36c9,_0x16ebf0,_0x5f2628,_0x22f2d6,_0x1fdf20,_0x5ce913,_0x121f09,_0x40f2ca);}else return _0x16ebf0;}else{let _0x1ef259=new b(null);return _0x1fec73['foreach']((_0x1ff6f7,_0x3d2197)=>{const _0x4fb5b6=k(_0x5f2628,_0x1ff6f7);_0x239e06['isCompleteForPath'](_0x4fb5b6)&&(_0x1ef259=_0x1ef259['set'](_0x1ff6f7,_0x239e06['getNode']()['getChild'](_0x4fb5b6)));}),Pi(_0x4e36c9,_0x16ebf0,_0x5f2628,_0x1ef259,_0x1fdf20,_0x5ce913,_0x121f09,_0x40f2ca);}}function Nu(_0x4a2ce5,_0x4fb39b,_0xc6eba2,_0x521751,_0x32ef35){const _0x4b3eb9=_0x4fb39b['serverCache'],_0x251868=Fo(_0x4fb39b,_0x4b3eb9['getNode'](),_0x4b3eb9['isFullyInitialized']()||v(_0xc6eba2),_0x4b3eb9['isFiltered']());return Go(_0x4a2ce5,_0x251868,_0xc6eba2,_0x521751,$o,_0x32ef35);}function Ou(_0x2850a4,_0x2ce7a4,_0x634d10,_0x33c264,_0x5b44db,_0x4876fc){let _0x4f8acb;if(Tn(_0x33c264,_0x634d10)!=null)return _0x2ce7a4;{const _0x42d344=new rs(_0x33c264,_0x2ce7a4,_0x5b44db),_0x506167=_0x2ce7a4['eventCache']['getNode']();let _0x464b52;if(v(_0x634d10)||y(_0x634d10)==='.priority'){let _0x5ebdc4;if(_0x2ce7a4['serverCache']['isFullyInitialized']())_0x5ebdc4=Cn(_0x33c264,Ve(_0x2ce7a4));else{const _0x41f8df=_0x2ce7a4['serverCache']['getNode']();f(_0x41f8df instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5ebdc4=is(_0x33c264,_0x41f8df);}_0x5ebdc4=_0x5ebdc4,_0x464b52=_0x2850a4['filter']['updateFullNode'](_0x506167,_0x5ebdc4,_0x4876fc);}else{const _0x22a651=y(_0x634d10);let _0x5e639b=ss(_0x33c264,_0x22a651,_0x2ce7a4['serverCache']);_0x5e639b==null&&_0x2ce7a4['serverCache']['isCompleteForChild'](_0x22a651)&&(_0x5e639b=_0x506167['getImmediateChild'](_0x22a651)),_0x5e639b!=null?_0x464b52=_0x2850a4['filter']['updateChild'](_0x506167,_0x22a651,_0x5e639b,S(_0x634d10),_0x42d344,_0x4876fc):_0x2ce7a4['eventCache']['getNode']()['hasChild'](_0x22a651)?_0x464b52=_0x2850a4['filter']['updateChild'](_0x506167,_0x22a651,g['EMPTY_NODE'],S(_0x634d10),_0x42d344,_0x4876fc):_0x464b52=_0x506167,_0x464b52['isEmpty']()&&_0x2ce7a4['serverCache']['isFullyInitialized']()&&(_0x4f8acb=Cn(_0x33c264,Ve(_0x2ce7a4)),_0x4f8acb['isLeafNode']()&&(_0x464b52=_0x2850a4['filter']['updateFullNode'](_0x464b52,_0x4f8acb,_0x4876fc)));}return _0x4f8acb=_0x2ce7a4['serverCache']['isFullyInitialized']()||Tn(_0x33c264,w())!=null,Rt(_0x2ce7a4,_0x464b52,_0x4f8acb,_0x2850a4['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x382f20,_0x198c97){this['query_']=_0x382f20,this['eventRegistrations_']=[];const _0x38a549=this['query_']['_queryParams'],_0x2d10ef=new Xi(_0x38a549['getIndex']()),_0x3141b2=Kh(_0x38a549);this['processor_']=Su(_0x3141b2);const _0xc5e87e=_0x198c97['serverCache'],_0x37e77f=_0x198c97['eventCache'],_0x49e381=_0x2d10ef['updateFullNode'](g['EMPTY_NODE'],_0xc5e87e['getNode'](),null),_0x49c00f=_0x3141b2['updateFullNode'](g['EMPTY_NODE'],_0x37e77f['getNode'](),null),_0x4d7cf3=new Te(_0x49e381,_0xc5e87e['isFullyInitialized'](),_0x2d10ef['filtersNodes']()),_0xfd9f02=new Te(_0x49c00f,_0x37e77f['isFullyInitialized'](),_0x3141b2['filtersNodes']());this['viewCache_']=Un(_0xfd9f02,_0x4d7cf3),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x46fa76){return _0x46fa76['viewCache_']['serverCache']['getNode']();}function Lu(_0x4ec46f){return wn(_0x4ec46f['viewCache_']);}function xu(_0x3bcbd0,_0x21f390){const _0x19664f=Ve(_0x3bcbd0['viewCache_']);return _0x19664f&&(_0x3bcbd0['query']['_queryParams']['loadsAllData']()||!v(_0x21f390)&&!_0x19664f['getImmediateChild'](y(_0x21f390))['isEmpty']())?_0x19664f['getChild'](_0x21f390):null;}function ur(_0x1bdc9b){return _0x1bdc9b['eventRegistrations_']['length']===0x0;}function Fu(_0x2c7197,_0x419f70){_0x2c7197['eventRegistrations_']['push'](_0x419f70);}function dr(_0x5b2511,_0x4e3e8a,_0x924e50){const _0xa3f27e=[];if(_0x924e50){f(_0x4e3e8a==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1fb9e8=_0x5b2511['query']['_path'];_0x5b2511['eventRegistrations_']['forEach'](_0x314e17=>{const _0x410300=_0x314e17['createCancelEvent'](_0x924e50,_0x1fb9e8);_0x410300&&_0xa3f27e['push'](_0x410300);});}if(_0x4e3e8a){let _0x18d0a8=[];for(let _0x1fda04=0x0;_0x1fda04<_0x5b2511['eventRegistrations_']['length'];++_0x1fda04){const _0x230584=_0x5b2511['eventRegistrations_'][_0x1fda04];if(!_0x230584['matches'](_0x4e3e8a))_0x18d0a8['push'](_0x230584);else{if(_0x4e3e8a['hasAnyCallback']()){_0x18d0a8=_0x18d0a8['concat'](_0x5b2511['eventRegistrations_']['slice'](_0x1fda04+0x1));break;}}}_0x5b2511['eventRegistrations_']=_0x18d0a8;}else _0x5b2511['eventRegistrations_']=[];return _0xa3f27e;}function fr(_0x5728e8,_0x20e69a,_0x338b9b,_0x23027c){_0x20e69a['type']===z['MERGE']&&_0x20e69a['source']['queryId']!==null&&(f(Ve(_0x5728e8['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x5728e8['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x2869cb=_0x5728e8['viewCache_'],_0x4f3c43=Ru(_0x5728e8['processor_'],_0x2869cb,_0x20e69a,_0x338b9b,_0x23027c);return bu(_0x5728e8['processor_'],_0x4f3c43['viewCache']),f(_0x4f3c43['viewCache']['serverCache']['isFullyInitialized']()||!_0x2869cb['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x5728e8['viewCache_']=_0x4f3c43['viewCache'],qo(_0x5728e8,_0x4f3c43['changes'],_0x4f3c43['viewCache']['eventCache']['getNode'](),null);}function Uu(_0xb9748f,_0x4b938f){const _0x553a78=_0xb9748f['viewCache_']['eventCache'],_0x4df77d=[];return _0x553a78['getNode']()['isLeafNode']()||_0x553a78['getNode']()['forEachChild'](R,(_0x368cb5,_0x2844fb)=>{_0x4df77d['push'](rt(_0x368cb5,_0x2844fb));}),_0x553a78['isFullyInitialized']()&&_0x4df77d['push'](Lo(_0x553a78['getNode']())),qo(_0xb9748f,_0x4df77d,_0x553a78['getNode'](),_0x4b938f);}function qo(_0x5bfa5a,_0x171cdf,_0x9d3950,_0x3077e3){const _0x5c4d96=_0x3077e3?[_0x3077e3]:_0x5bfa5a['eventRegistrations_'];return ru(_0x5bfa5a['eventGenerator_'],_0x171cdf,_0x9d3950,_0x5c4d96);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0xf26c5c){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0xf26c5c;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x5cee7f){return _0x5cee7f['views']['size']===0x0;}function os(_0x48c3f4,_0x20152e,_0x9615b1,_0xc526e7){const _0x5b6363=_0x20152e['source']['queryId'];if(_0x5b6363!==null){const _0x525e40=_0x48c3f4['views']['get'](_0x5b6363);return f(_0x525e40!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x525e40,_0x20152e,_0x9615b1,_0xc526e7);}else{let _0x554006=[];for(const _0x51c16a of _0x48c3f4['views']['values']())_0x554006=_0x554006['concat'](fr(_0x51c16a,_0x20152e,_0x9615b1,_0xc526e7));return _0x554006;}}function jo(_0x399300,_0xb65638,_0x1595d5,_0x2b2abc,_0x2247be){const _0x3452e4=_0xb65638['_queryIdentifier'],_0x5d9b29=_0x399300['views']['get'](_0x3452e4);if(!_0x5d9b29){let _0x480e8e=Cn(_0x1595d5,_0x2247be?_0x2b2abc:null),_0x5b1245=!0x1;_0x480e8e?_0x5b1245=!0x0:_0x2b2abc instanceof g?(_0x480e8e=is(_0x1595d5,_0x2b2abc),_0x5b1245=!0x1):(_0x480e8e=g['EMPTY_NODE'],_0x5b1245=!0x1);const _0x596799=Un(new Te(_0x480e8e,_0x5b1245,!0x1),new Te(_0x2b2abc,_0x2247be,!0x1));return new Du(_0xb65638,_0x596799);}return _0x5d9b29;}function Hu(_0x54ddac,_0x2cd70b,_0xb134df,_0x4e4d0e,_0x12a825,_0x1be95b){const _0x462d72=jo(_0x54ddac,_0x2cd70b,_0x4e4d0e,_0x12a825,_0x1be95b);return _0x54ddac['views']['has'](_0x2cd70b['_queryIdentifier'])||_0x54ddac['views']['set'](_0x2cd70b['_queryIdentifier'],_0x462d72),Fu(_0x462d72,_0xb134df),Uu(_0x462d72,_0xb134df);}function $u(_0x595e9e,_0xc17469,_0x10a709,_0x3c268d){const _0x354e23=_0xc17469['_queryIdentifier'],_0x50ef45=[];let _0x20ab6f=[];const _0x282895=Se(_0x595e9e);if(_0x354e23==='default'){for(const [_0x52c99f,_0x1372b3]of _0x595e9e['views']['entries']())_0x20ab6f=_0x20ab6f['concat'](dr(_0x1372b3,_0x10a709,_0x3c268d)),ur(_0x1372b3)&&(_0x595e9e['views']['delete'](_0x52c99f),_0x1372b3['query']['_queryParams']['loadsAllData']()||_0x50ef45['push'](_0x1372b3['query']));}else{const _0x377071=_0x595e9e['views']['get'](_0x354e23);_0x377071&&(_0x20ab6f=_0x20ab6f['concat'](dr(_0x377071,_0x10a709,_0x3c268d)),ur(_0x377071)&&(_0x595e9e['views']['delete'](_0x354e23),_0x377071['query']['_queryParams']['loadsAllData']()||_0x50ef45['push'](_0x377071['query'])));}return _0x282895&&!Se(_0x595e9e)&&_0x50ef45['push'](new(Bu())(_0xc17469['_repo'],_0xc17469['_path'])),{'removed':_0x50ef45,'events':_0x20ab6f};}function Ko(_0x824e2f){const _0x2fd00f=[];for(const _0x341d3b of _0x824e2f['views']['values']())_0x341d3b['query']['_queryParams']['loadsAllData']()||_0x2fd00f['push'](_0x341d3b);return _0x2fd00f;}function Ie(_0x33b9b8,_0x46894c){let _0x5775f8=null;for(const _0x5dc005 of _0x33b9b8['views']['values']())_0x5775f8=_0x5775f8||xu(_0x5dc005,_0x46894c);return _0x5775f8;}function Yo(_0x5ce673,_0x3403d2){if(_0x3403d2['_queryParams']['loadsAllData']())return Bn(_0x5ce673);{const _0x2a671b=_0x3403d2['_queryIdentifier'];return _0x5ce673['views']['get'](_0x2a671b);}}function Qo(_0x4ba508,_0x5365a5){return Yo(_0x4ba508,_0x5365a5)!=null;}function Se(_0x5c1794){return Bn(_0x5c1794)!=null;}function Bn(_0x41227d){for(const _0x4840fa of _0x41227d['views']['values']())if(_0x4840fa['query']['_queryParams']['loadsAllData']())return _0x4840fa;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xf5a916){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xf5a916;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x37037c){this['listenProvider_']=_0x37037c,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0xc9ce7c,_0x22ed9b,_0x4d8d9e,_0x3a62c9,_0x569129){return lu(_0xc9ce7c['pendingWriteTree_'],_0x22ed9b,_0x4d8d9e,_0x3a62c9,_0x569129),_0x569129?_t(_0xc9ce7c,new Be(es(),_0x22ed9b,_0x4d8d9e)):[];}function ju(_0x27e5bc,_0x2fda9c,_0x38afd8,_0x2e618a){hu(_0x27e5bc['pendingWriteTree_'],_0x2fda9c,_0x38afd8,_0x2e618a);const _0xdd8915=b['fromObject'](_0x38afd8);return _t(_0x27e5bc,new ot(es(),_0x2fda9c,_0xdd8915));}function _e(_0x397e59,_0x38a88a,_0x1c82de=!0x1){const _0x47e235=uu(_0x397e59['pendingWriteTree_'],_0x38a88a);if(du(_0x397e59['pendingWriteTree_'],_0x38a88a)){let _0x5a40b0=new b(null);return _0x47e235['snap']!=null?_0x5a40b0=_0x5a40b0['set'](w(),!0x0):x(_0x47e235['children'],_0x9391b=>{_0x5a40b0=_0x5a40b0['set'](new C(_0x9391b),!0x0);}),_t(_0x397e59,new In(_0x47e235['path'],_0x5a40b0,_0x1c82de));}else return[];}function Yt(_0x267e30,_0x25bc08,_0x24620f){return _t(_0x267e30,new Be(ts(),_0x25bc08,_0x24620f));}function Ku(_0x35aa89,_0x474aa9,_0x49de1a){const _0x15a247=b['fromObject'](_0x49de1a);return _t(_0x35aa89,new ot(ts(),_0x474aa9,_0x15a247));}function Yu(_0xb9c34b,_0x441a6c){return _t(_0xb9c34b,new Ut(ts(),_0x441a6c));}function Qu(_0x5abb89,_0x59c1ac,_0x46f3b6){const _0x2742d3=cs(_0x5abb89,_0x46f3b6);if(_0x2742d3){const _0x529db7=ls(_0x2742d3),_0x5f45e6=_0x529db7['path'],_0xedf838=_0x529db7['queryId'],_0x4623c4=F(_0x5f45e6,_0x59c1ac),_0xec9486=new Ut(ns(_0xedf838),_0x4623c4);return hs(_0x5abb89,_0x5f45e6,_0xec9486);}else return[];}function An(_0x36c285,_0x412dba,_0x19e0a0,_0x2e106e,_0x3a83c9=!0x1){const _0x470397=_0x412dba['_path'],_0x31fefa=_0x36c285['syncPointTree_']['get'](_0x470397);let _0x2281e7=[];if(_0x31fefa&&(_0x412dba['_queryIdentifier']==='default'||Qo(_0x31fefa,_0x412dba))){const _0x5cbb1b=$u(_0x31fefa,_0x412dba,_0x19e0a0,_0x2e106e);Vu(_0x31fefa)&&(_0x36c285['syncPointTree_']=_0x36c285['syncPointTree_']['remove'](_0x470397));const _0x20f06e=_0x5cbb1b['removed'];if(_0x2281e7=_0x5cbb1b['events'],!_0x3a83c9){const _0x4c420a=_0x20f06e['findIndex'](_0x22cdd9=>_0x22cdd9['_queryParams']['loadsAllData']())!==-0x1,_0x4e2e21=_0x36c285['syncPointTree_']['findOnPath'](_0x470397,(_0x580a2a,_0x5b2410)=>Se(_0x5b2410));if(_0x4c420a&&!_0x4e2e21){const _0x41306a=_0x36c285['syncPointTree_']['subtree'](_0x470397);if(!_0x41306a['isEmpty']()){const _0x2df9d0=Zu(_0x41306a);for(let _0x3f3fb3=0x0;_0x3f3fb3<_0x2df9d0['length'];++_0x3f3fb3){const _0x47166d=_0x2df9d0[_0x3f3fb3],_0xc3e72d=_0x47166d['query'],_0x14e35b=ea(_0x36c285,_0x47166d);_0x36c285['listenProvider_']['startListening'](kt(_0xc3e72d),Wt(_0x36c285,_0xc3e72d),_0x14e35b['hashFn'],_0x14e35b['onComplete']);}}}!_0x4e2e21&&_0x20f06e['length']>0x0&&!_0x2e106e&&(_0x4c420a?_0x36c285['listenProvider_']['stopListening'](kt(_0x412dba),null):_0x20f06e['forEach'](_0xacd158=>{const _0x5b7050=_0x36c285['queryToTagMap']['get'](Hn(_0xacd158));_0x36c285['listenProvider_']['stopListening'](kt(_0xacd158),_0x5b7050);}));}ed(_0x36c285,_0x20f06e);}return _0x2281e7;}function Jo(_0x2e5e01,_0x4ba920,_0x45e3fb,_0x20718f){const _0x364c0e=cs(_0x2e5e01,_0x20718f);if(_0x364c0e!=null){const _0x5df3ed=ls(_0x364c0e),_0x5f72ac=_0x5df3ed['path'],_0x5ceaea=_0x5df3ed['queryId'],_0x3e048d=F(_0x5f72ac,_0x4ba920),_0x4cb936=new Be(ns(_0x5ceaea),_0x3e048d,_0x45e3fb);return hs(_0x2e5e01,_0x5f72ac,_0x4cb936);}else return[];}function Ju(_0xc626ba,_0xf1809e,_0x54df7a,_0x591ae9){const _0x236d51=cs(_0xc626ba,_0x591ae9);if(_0x236d51){const _0x357b73=ls(_0x236d51),_0x13b2c5=_0x357b73['path'],_0x26e1e2=_0x357b73['queryId'],_0x3d58e4=F(_0x13b2c5,_0xf1809e),_0x17a676=b['fromObject'](_0x54df7a),_0x2abf74=new ot(ns(_0x26e1e2),_0x3d58e4,_0x17a676);return hs(_0xc626ba,_0x13b2c5,_0x2abf74);}else return[];}function Ni(_0x441da4,_0x822595,_0x4aceac,_0x2e7869=!0x1){const _0x2121ab=_0x822595['_path'];let _0x367e92=null,_0x48b295=!0x1;_0x441da4['syncPointTree_']['foreachOnPath'](_0x2121ab,(_0x44019c,_0x354498)=>{const _0xfa05df=F(_0x44019c,_0x2121ab);_0x367e92=_0x367e92||Ie(_0x354498,_0xfa05df),_0x48b295=_0x48b295||Se(_0x354498);});let _0x3f76fb=_0x441da4['syncPointTree_']['get'](_0x2121ab);_0x3f76fb?(_0x48b295=_0x48b295||Se(_0x3f76fb),_0x367e92=_0x367e92||Ie(_0x3f76fb,w())):(_0x3f76fb=new zo(),_0x441da4['syncPointTree_']=_0x441da4['syncPointTree_']['set'](_0x2121ab,_0x3f76fb));let _0x1923f5;_0x367e92!=null?_0x1923f5=!0x0:(_0x1923f5=!0x1,_0x367e92=g['EMPTY_NODE'],_0x441da4['syncPointTree_']['subtree'](_0x2121ab)['foreachChild']((_0x4520df,_0x46e219)=>{const _0x50bded=Ie(_0x46e219,w());_0x50bded&&(_0x367e92=_0x367e92['updateImmediateChild'](_0x4520df,_0x50bded));}));const _0x1193d1=Qo(_0x3f76fb,_0x822595);if(!_0x1193d1&&!_0x822595['_queryParams']['loadsAllData']()){const _0x2163c3=Hn(_0x822595);f(!_0x441da4['queryToTagMap']['has'](_0x2163c3),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xf51332=td();_0x441da4['queryToTagMap']['set'](_0x2163c3,_0xf51332),_0x441da4['tagToQueryMap']['set'](_0xf51332,_0x2163c3);}const _0x1ef9e9=Wn(_0x441da4['pendingWriteTree_'],_0x2121ab);let _0x155513=Hu(_0x3f76fb,_0x822595,_0x4aceac,_0x1ef9e9,_0x367e92,_0x1923f5);if(!_0x1193d1&&!_0x48b295&&!_0x2e7869){const _0x49ba0b=Yo(_0x3f76fb,_0x822595);_0x155513=_0x155513['concat'](nd(_0x441da4,_0x822595,_0x49ba0b));}return _0x155513;}function Vn(_0x318921,_0xa8049c,_0x873552){const _0x68f227=_0x318921['pendingWriteTree_'],_0x4d432f=_0x318921['syncPointTree_']['findOnPath'](_0xa8049c,(_0x2174fa,_0x163d86)=>{const _0x3cc0a5=F(_0x2174fa,_0xa8049c),_0x144956=Ie(_0x163d86,_0x3cc0a5);if(_0x144956)return _0x144956;});return Bo(_0x68f227,_0xa8049c,_0x4d432f,_0x873552,!0x0);}function Xu(_0x315a97,_0x3cdef7){const _0x35d59c=_0x3cdef7['_path'];let _0x1be1bb=null;_0x315a97['syncPointTree_']['foreachOnPath'](_0x35d59c,(_0x771513,_0x15b0ef)=>{const _0x403394=F(_0x771513,_0x35d59c);_0x1be1bb=_0x1be1bb||Ie(_0x15b0ef,_0x403394);});let _0xf67c0=_0x315a97['syncPointTree_']['get'](_0x35d59c);_0xf67c0?_0x1be1bb=_0x1be1bb||Ie(_0xf67c0,w()):(_0xf67c0=new zo(),_0x315a97['syncPointTree_']=_0x315a97['syncPointTree_']['set'](_0x35d59c,_0xf67c0));const _0x24f7f8=_0x1be1bb!=null,_0x3eba1e=_0x24f7f8?new Te(_0x1be1bb,!0x0,!0x1):null,_0x599109=Wn(_0x315a97['pendingWriteTree_'],_0x3cdef7['_path']),_0xa83c85=jo(_0xf67c0,_0x3cdef7,_0x599109,_0x24f7f8?_0x3eba1e['getNode']():g['EMPTY_NODE'],_0x24f7f8);return Lu(_0xa83c85);}function _t(_0x4cd2ee,_0x36f389){return Xo(_0x36f389,_0x4cd2ee['syncPointTree_'],null,Wn(_0x4cd2ee['pendingWriteTree_'],w()));}function Xo(_0x30e19f,_0x174a80,_0x289212,_0x4bfb85){if(v(_0x30e19f['path']))return Zo(_0x30e19f,_0x174a80,_0x289212,_0x4bfb85);{const _0x527a03=_0x174a80['get'](w());_0x289212==null&&_0x527a03!=null&&(_0x289212=Ie(_0x527a03,w()));let _0x46123f=[];const _0x21b5af=y(_0x30e19f['path']),_0x20fe34=_0x30e19f['operationForChild'](_0x21b5af),_0x5a2244=_0x174a80['children']['get'](_0x21b5af);if(_0x5a2244&&_0x20fe34){const _0x491bf3=_0x289212?_0x289212['getImmediateChild'](_0x21b5af):null,_0x19c17e=Vo(_0x4bfb85,_0x21b5af);_0x46123f=_0x46123f['concat'](Xo(_0x20fe34,_0x5a2244,_0x491bf3,_0x19c17e));}return _0x527a03&&(_0x46123f=_0x46123f['concat'](os(_0x527a03,_0x30e19f,_0x4bfb85,_0x289212))),_0x46123f;}}function Zo(_0x127b9e,_0x425846,_0x173c9b,_0x128a64){const _0x300848=_0x425846['get'](w());_0x173c9b==null&&_0x300848!=null&&(_0x173c9b=Ie(_0x300848,w()));let _0x375b3b=[];return _0x425846['children']['inorderTraversal']((_0x2124a7,_0x4f5c7c)=>{const _0x5aae4b=_0x173c9b?_0x173c9b['getImmediateChild'](_0x2124a7):null,_0x3f72df=Vo(_0x128a64,_0x2124a7),_0x5a0924=_0x127b9e['operationForChild'](_0x2124a7);_0x5a0924&&(_0x375b3b=_0x375b3b['concat'](Zo(_0x5a0924,_0x4f5c7c,_0x5aae4b,_0x3f72df)));}),_0x300848&&(_0x375b3b=_0x375b3b['concat'](os(_0x300848,_0x127b9e,_0x128a64,_0x173c9b))),_0x375b3b;}function ea(_0x348ee9,_0x5d87dc){const _0xc312f1=_0x5d87dc['query'],_0x22057a=Wt(_0x348ee9,_0xc312f1);return{'hashFn':()=>(Mu(_0x5d87dc)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1bbef1=>{if(_0x1bbef1==='ok')return _0x22057a?Qu(_0x348ee9,_0xc312f1['_path'],_0x22057a):Yu(_0x348ee9,_0xc312f1['_path']);{const _0x50bbbc=Kl(_0x1bbef1,_0xc312f1);return An(_0x348ee9,_0xc312f1,null,_0x50bbbc);}}};}function Wt(_0x525aa0,_0xd13c1b){const _0x22442f=Hn(_0xd13c1b);return _0x525aa0['queryToTagMap']['get'](_0x22442f);}function Hn(_0x44597b){return _0x44597b['_path']['toString']()+'$'+_0x44597b['_queryIdentifier'];}function cs(_0x3c4dea,_0x2d137f){return _0x3c4dea['tagToQueryMap']['get'](_0x2d137f);}function ls(_0x3d606b){const _0x11c9a4=_0x3d606b['indexOf']('$');return f(_0x11c9a4!==-0x1&&_0x11c9a4<_0x3d606b['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3d606b['substr'](_0x11c9a4+0x1),'path':new C(_0x3d606b['substr'](0x0,_0x11c9a4))};}function hs(_0x1bdb1a,_0x533d9e,_0x12a588){const _0x3081a6=_0x1bdb1a['syncPointTree_']['get'](_0x533d9e);f(_0x3081a6,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1ba642=Wn(_0x1bdb1a['pendingWriteTree_'],_0x533d9e);return os(_0x3081a6,_0x12a588,_0x1ba642,null);}function Zu(_0x569230){return _0x569230['fold']((_0xfe4fbe,_0x1cdfb7,_0x177bd6)=>{if(_0x1cdfb7&&Se(_0x1cdfb7))return[Bn(_0x1cdfb7)];{let _0x57960c=[];return _0x1cdfb7&&(_0x57960c=Ko(_0x1cdfb7)),x(_0x177bd6,(_0x368016,_0x287b02)=>{_0x57960c=_0x57960c['concat'](_0x287b02);}),_0x57960c;}});}function kt(_0x2b9416){return _0x2b9416['_queryParams']['loadsAllData']()&&!_0x2b9416['_queryParams']['isDefault']()?new(qu())(_0x2b9416['_repo'],_0x2b9416['_path']):_0x2b9416;}function ed(_0x4cb93d,_0x31c875){for(let _0x1cefe0=0x0;_0x1cefe0<_0x31c875['length'];++_0x1cefe0){const _0x520980=_0x31c875[_0x1cefe0];if(!_0x520980['_queryParams']['loadsAllData']()){const _0xbb45a=Hn(_0x520980),_0x507fdf=_0x4cb93d['queryToTagMap']['get'](_0xbb45a);_0x4cb93d['queryToTagMap']['delete'](_0xbb45a),_0x4cb93d['tagToQueryMap']['delete'](_0x507fdf);}}}function td(){return zu++;}function nd(_0x17decb,_0x2690b3,_0x1f99b9){const _0x1139be=_0x2690b3['_path'],_0x49f0e2=Wt(_0x17decb,_0x2690b3),_0x2d0534=ea(_0x17decb,_0x1f99b9),_0x141462=_0x17decb['listenProvider_']['startListening'](kt(_0x2690b3),_0x49f0e2,_0x2d0534['hashFn'],_0x2d0534['onComplete']),_0x52ddf4=_0x17decb['syncPointTree_']['subtree'](_0x1139be);if(_0x49f0e2)f(!Se(_0x52ddf4['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5dafe0=_0x52ddf4['fold']((_0x571822,_0x5abec0,_0x47bd33)=>{if(!v(_0x571822)&&_0x5abec0&&Se(_0x5abec0))return[Bn(_0x5abec0)['query']];{let _0x5187ac=[];return _0x5abec0&&(_0x5187ac=_0x5187ac['concat'](Ko(_0x5abec0)['map'](_0x5bf237=>_0x5bf237['query']))),x(_0x47bd33,(_0x4c1e47,_0xabe158)=>{_0x5187ac=_0x5187ac['concat'](_0xabe158);}),_0x5187ac;}});for(let _0x59da68=0x0;_0x59da68<_0x5dafe0['length'];++_0x59da68){const _0x3bd8c2=_0x5dafe0[_0x59da68];_0x17decb['listenProvider_']['stopListening'](kt(_0x3bd8c2),Wt(_0x17decb,_0x3bd8c2));}}return _0x141462;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x3486d6){this['node_']=_0x3486d6;}['getImmediateChild'](_0x59cf9f){const _0x40235c=this['node_']['getImmediateChild'](_0x59cf9f);return new us(_0x40235c);}['node'](){return this['node_'];}}class ds{constructor(_0xafd645,_0x5f4aad){this['syncTree_']=_0xafd645,this['path_']=_0x5f4aad;}['getImmediateChild'](_0x909e95){const _0x31db58=k(this['path_'],_0x909e95);return new ds(this['syncTree_'],_0x31db58);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x21c438){return _0x21c438=_0x21c438||{},_0x21c438['timestamp']=_0x21c438['timestamp']||new Date()['getTime'](),_0x21c438;},_r=function(_0x389e96,_0x6cb079,_0x2ff151){if(!_0x389e96||typeof _0x389e96!='object')return _0x389e96;if(f('.sv'in _0x389e96,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x389e96['.sv']=='string')return sd(_0x389e96['.sv'],_0x6cb079,_0x2ff151);if(typeof _0x389e96['.sv']=='object')return rd(_0x389e96['.sv'],_0x6cb079);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x389e96,null,0x2));},sd=function(_0x1d7649,_0xc4d048,_0x2a3cc6){switch(_0x1d7649){case'timestamp':return _0x2a3cc6['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1d7649);}},rd=function(_0xf96eef,_0x4e5416,_0x41df83){_0xf96eef['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0xf96eef,null,0x2));const _0x5c35a8=_0xf96eef['increment'];typeof _0x5c35a8!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5c35a8);const _0x3bfc62=_0x4e5416['node']();if(f(_0x3bfc62!==null&&typeof _0x3bfc62<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x3bfc62['isLeafNode']())return _0x5c35a8;const _0x593967=_0x3bfc62['getValue']();return typeof _0x593967!='number'?_0x5c35a8:_0x593967+_0x5c35a8;},ta=function(_0x3fc50e,_0x48b2cc,_0x4ba321,_0x55d3a4){return ps(_0x48b2cc,new ds(_0x4ba321,_0x3fc50e),_0x55d3a4);},fs=function(_0x37c10b,_0x352b15,_0x2414bb){return ps(_0x37c10b,new us(_0x352b15),_0x2414bb);};function ps(_0x22e510,_0x2d9d81,_0x340775){const _0x169e49=_0x22e510['getPriority']()['val'](),_0x388507=_r(_0x169e49,_0x2d9d81['getImmediateChild']('.priority'),_0x340775);let _0x25942b;if(_0x22e510['isLeafNode']()){const _0xd5c62a=_0x22e510,_0x3ea9ca=_r(_0xd5c62a['getValue'](),_0x2d9d81,_0x340775);return _0x3ea9ca!==_0xd5c62a['getValue']()||_0x388507!==_0xd5c62a['getPriority']()['val']()?new D(_0x3ea9ca,A(_0x388507)):_0x22e510;}else{const _0x39fb14=_0x22e510;return _0x25942b=_0x39fb14,_0x388507!==_0x39fb14['getPriority']()['val']()&&(_0x25942b=_0x25942b['updatePriority'](new D(_0x388507))),_0x39fb14['forEachChild'](R,(_0x58c0c8,_0x4b753c)=>{const _0x58ff8f=ps(_0x4b753c,_0x2d9d81['getImmediateChild'](_0x58c0c8),_0x340775);_0x58ff8f!==_0x4b753c&&(_0x25942b=_0x25942b['updateImmediateChild'](_0x58c0c8,_0x58ff8f));}),_0x25942b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x44468f='',_0x366eed=null,_0x5a934f={'children':{},'childCount':0x0}){this['name']=_0x44468f,this['parent']=_0x366eed,this['node']=_0x5a934f;}}function $n(_0x4dfb23,_0x1baf60){let _0x489eb2=_0x1baf60 instanceof C?_0x1baf60:new C(_0x1baf60),_0x44cc10=_0x4dfb23,_0x2d4713=y(_0x489eb2);for(;_0x2d4713!==null;){const _0x3cd327=Le(_0x44cc10['node']['children'],_0x2d4713)||{'children':{},'childCount':0x0};_0x44cc10=new _s(_0x2d4713,_0x44cc10,_0x3cd327),_0x489eb2=S(_0x489eb2),_0x2d4713=y(_0x489eb2);}return _0x44cc10;}function je(_0x3f276f){return _0x3f276f['node']['value'];}function gs(_0x18b3cd,_0x336949){_0x18b3cd['node']['value']=_0x336949,Oi(_0x18b3cd);}function na(_0x4f696){return _0x4f696['node']['childCount']>0x0;}function od(_0x4679db){return je(_0x4679db)===void 0x0&&!na(_0x4679db);}function Gn(_0x369257,_0x1f8f88){x(_0x369257['node']['children'],(_0x13f245,_0x26a08b)=>{_0x1f8f88(new _s(_0x13f245,_0x369257,_0x26a08b));});}function ia(_0x226629,_0x4fa22c,_0x55c6c0,_0x28d779){_0x55c6c0&&_0x4fa22c(_0x226629),Gn(_0x226629,_0x520af5=>{ia(_0x520af5,_0x4fa22c,!0x0);});}function ad(_0x4bafd4,_0x596422,_0x2e5c3f){let _0x348aa4=_0x4bafd4['parent'];for(;_0x348aa4!==null;){if(_0x596422(_0x348aa4))return!0x0;_0x348aa4=_0x348aa4['parent'];}return!0x1;}function Qt(_0x265024){return new C(_0x265024['parent']===null?_0x265024['name']:Qt(_0x265024['parent'])+'/'+_0x265024['name']);}function Oi(_0x3a09d5){_0x3a09d5['parent']!==null&&cd(_0x3a09d5['parent'],_0x3a09d5['name'],_0x3a09d5);}function cd(_0x1e7f4,_0x437d1c,_0x4d0735){const _0x46b970=od(_0x4d0735),_0x49fc0a=Q(_0x1e7f4['node']['children'],_0x437d1c);_0x46b970&&_0x49fc0a?(delete _0x1e7f4['node']['children'][_0x437d1c],_0x1e7f4['node']['childCount']--,Oi(_0x1e7f4)):!_0x46b970&&!_0x49fc0a&&(_0x1e7f4['node']['children'][_0x437d1c]=_0x4d0735['node'],_0x1e7f4['node']['childCount']++,Oi(_0x1e7f4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x549fc4){return typeof _0x549fc4=='string'&&_0x549fc4['length']!==0x0&&!ld['test'](_0x549fc4);},sa=function(_0x2602d1){return typeof _0x2602d1=='string'&&_0x2602d1['length']!==0x0&&!hd['test'](_0x2602d1);},ud=function(_0x526c41){return _0x526c41&&(_0x526c41=_0x526c41['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x526c41);},Bt=function(_0x501faa){return _0x501faa===null||typeof _0x501faa=='string'||typeof _0x501faa=='number'&&!xn(_0x501faa)||_0x501faa&&typeof _0x501faa=='object'&&Q(_0x501faa,'.sv');},He=function(_0x48a094,_0x294fc6,_0x28a8e5,_0x483cb5){_0x483cb5&&_0x294fc6===void 0x0||Jt(it(_0x48a094,'value'),_0x294fc6,_0x28a8e5);},Jt=function(_0x30abef,_0x362308,_0x4bcb28){const _0x3d954a=_0x4bcb28 instanceof C?new Ah(_0x4bcb28,_0x30abef):_0x4bcb28;if(_0x362308===void 0x0)throw new Error(_0x30abef+'contains\x20undefined\x20'+Oe(_0x3d954a));if(typeof _0x362308=='function')throw new Error(_0x30abef+'contains\x20a\x20function\x20'+Oe(_0x3d954a)+'\x20with\x20contents\x20=\x20'+_0x362308['toString']());if(xn(_0x362308))throw new Error(_0x30abef+'contains\x20'+_0x362308['toString']()+'\x20'+Oe(_0x3d954a));if(typeof _0x362308=='string'&&_0x362308['length']>ui/0x3&&Ln(_0x362308)>ui)throw new Error(_0x30abef+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x3d954a)+'\x20(\x27'+_0x362308['substring'](0x0,0x32)+'...\x27)');if(_0x362308&&typeof _0x362308=='object'){let _0x373d78=!0x1,_0x5be46d=!0x1;if(x(_0x362308,(_0x272bc5,_0xddc8b9)=>{if(_0x272bc5==='.value')_0x373d78=!0x0;else{if(_0x272bc5!=='.priority'&&_0x272bc5!=='.sv'&&(_0x5be46d=!0x0,!ms(_0x272bc5)))throw new Error(_0x30abef+'\x20contains\x20an\x20invalid\x20key\x20('+_0x272bc5+')\x20'+Oe(_0x3d954a)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3d954a,_0x272bc5),Jt(_0x30abef,_0xddc8b9,_0x3d954a),Ph(_0x3d954a);}),_0x373d78&&_0x5be46d)throw new Error(_0x30abef+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x3d954a)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3072df,_0x452826){let _0x182744,_0x317e1d;for(_0x182744=0x0;_0x182744<_0x452826['length'];_0x182744++){_0x317e1d=_0x452826[_0x182744];const _0x1f4d08=Mt(_0x317e1d);for(let _0x37e1f2=0x0;_0x37e1f2<_0x1f4d08['length'];_0x37e1f2++)if(!(_0x1f4d08[_0x37e1f2]==='.priority'&&_0x37e1f2===_0x1f4d08['length']-0x1)){if(!ms(_0x1f4d08[_0x37e1f2]))throw new Error(_0x3072df+'contains\x20an\x20invalid\x20key\x20('+_0x1f4d08[_0x37e1f2]+')\x20in\x20path\x20'+_0x317e1d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x452826['sort'](Rh);let _0x55c3e4=null;for(_0x182744=0x0;_0x182744<_0x452826['length'];_0x182744++){if(_0x317e1d=_0x452826[_0x182744],_0x55c3e4!==null&&G(_0x55c3e4,_0x317e1d))throw new Error(_0x3072df+'contains\x20a\x20path\x20'+_0x55c3e4['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x317e1d['toString']());_0x55c3e4=_0x317e1d;}},ra=function(_0x33913b,_0xe22045,_0x1a35c8,_0x3e63c8){const _0x2819fa=it(_0x33913b,'values');if(!(_0xe22045&&typeof _0xe22045=='object')||Array['isArray'](_0xe22045))throw new Error(_0x2819fa+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x27b281=[];x(_0xe22045,(_0x3716a8,_0x217271)=>{const _0x13ffb4=new C(_0x3716a8);if(Jt(_0x2819fa,_0x217271,k(_0x1a35c8,_0x13ffb4)),ji(_0x13ffb4)==='.priority'&&!Bt(_0x217271))throw new Error(_0x2819fa+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x13ffb4['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x27b281['push'](_0x13ffb4);}),dd(_0x2819fa,_0x27b281);},fd=function(_0x2a0d5c,_0xb91532,_0x521756){if(xn(_0xb91532))throw new Error(it(_0x2a0d5c,'priority')+'is\x20'+_0xb91532['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xb91532))throw new Error(it(_0x2a0d5c,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x23bb32,_0x17dc34,_0x4377be,_0xeaf3e2){if(!sa(_0x4377be))throw new Error(it(_0x23bb32,_0x17dc34)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4377be+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4520b5,_0x564893,_0x2edd93,_0x47459f){_0x2edd93&&(_0x2edd93=_0x2edd93['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4520b5,_0x564893,_0x2edd93);},Me=function(_0x235a1e,_0xe68258){if(y(_0xe68258)==='.info')throw new Error(_0x235a1e+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x46cef0,_0x37e918){const _0xbfffe5=_0x37e918['path']['toString']();if(typeof _0x37e918['repoInfo']['host']!='string'||_0x37e918['repoInfo']['host']['length']===0x0||!ms(_0x37e918['repoInfo']['namespace'])&&_0x37e918['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xbfffe5['length']!==0x0&&!ud(_0xbfffe5))throw new Error(it(_0x46cef0,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x36f6a8,_0x229369){let _0xc8a0ab=null;for(let _0xc01b34=0x0;_0xc01b34<_0x229369['length'];_0xc01b34++){const _0x55544f=_0x229369[_0xc01b34],_0x5edd5c=_0x55544f['getPath']();_0xc8a0ab!==null&&!Ki(_0x5edd5c,_0xc8a0ab['path'])&&(_0x36f6a8['eventLists_']['push'](_0xc8a0ab),_0xc8a0ab=null),_0xc8a0ab===null&&(_0xc8a0ab={'events':[],'path':_0x5edd5c}),_0xc8a0ab['events']['push'](_0x55544f);}_0xc8a0ab&&_0x36f6a8['eventLists_']['push'](_0xc8a0ab);}function oa(_0x308da8,_0x33c3d5,_0x261c50){qn(_0x308da8,_0x261c50),aa(_0x308da8,_0x3a0452=>Ki(_0x3a0452,_0x33c3d5));}function V(_0x2cd017,_0x311e33,_0xb20548){qn(_0x2cd017,_0xb20548),aa(_0x2cd017,_0x8b7ec9=>G(_0x8b7ec9,_0x311e33)||G(_0x311e33,_0x8b7ec9));}function aa(_0x428645,_0x37445c){_0x428645['recursionDepth_']++;let _0x275ae6=!0x0;for(let _0x4601d4=0x0;_0x4601d4<_0x428645['eventLists_']['length'];_0x4601d4++){const _0x14e5d0=_0x428645['eventLists_'][_0x4601d4];if(_0x14e5d0){const _0x5e73a0=_0x14e5d0['path'];_0x37445c(_0x5e73a0)?(md(_0x428645['eventLists_'][_0x4601d4]),_0x428645['eventLists_'][_0x4601d4]=null):_0x275ae6=!0x1;}}_0x275ae6&&(_0x428645['eventLists_']=[]),_0x428645['recursionDepth_']--;}function md(_0x2c02ae){for(let _0x310328=0x0;_0x310328<_0x2c02ae['events']['length'];_0x310328++){const _0x30cad2=_0x2c02ae['events'][_0x310328];if(_0x30cad2!==null){_0x2c02ae['events'][_0x310328]=null;const _0x239e44=_0x30cad2['getEventRunner']();St&&L('event:\x20'+_0x30cad2['toString']()),ft(_0x239e44);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0xa5c66c,_0x48c1e6,_0x48b133,_0x2b6ca0){this['repoInfo_']=_0xa5c66c,this['forceRestClient_']=_0x48c1e6,this['authTokenProvider_']=_0x48b133,this['appCheckProvider_']=_0x2b6ca0,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x46f877,_0x292633,_0x1011f0){if(_0x46f877['stats_']=qi(_0x46f877['repoInfo_']),_0x46f877['forceRestClient_']||Xl())_0x46f877['server_']=new vn(_0x46f877['repoInfo_'],(_0x20d5d3,_0x183f20,_0x9ef558,_0x2565b7)=>{gr(_0x46f877,_0x20d5d3,_0x183f20,_0x9ef558,_0x2565b7);},_0x46f877['authTokenProvider_'],_0x46f877['appCheckProvider_']),setTimeout(()=>mr(_0x46f877,!0x0),0x0);else{if(typeof _0x1011f0<'u'&&_0x1011f0!==null){if(typeof _0x1011f0!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1011f0);}catch(_0x5262ce){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5262ce);}}_0x46f877['persistentConnection_']=new se(_0x46f877['repoInfo_'],_0x292633,(_0x4bd16d,_0x4176d1,_0x1d020f,_0x2682ed)=>{gr(_0x46f877,_0x4bd16d,_0x4176d1,_0x1d020f,_0x2682ed);},_0x523738=>{mr(_0x46f877,_0x523738);},_0xe7046e=>{Id(_0x46f877,_0xe7046e);},_0x46f877['authTokenProvider_'],_0x46f877['appCheckProvider_'],_0x1011f0),_0x46f877['server_']=_0x46f877['persistentConnection_'];}_0x46f877['authTokenProvider_']['addTokenChangeListener'](_0x5e57a4=>{_0x46f877['server_']['refreshAuthToken'](_0x5e57a4);}),_0x46f877['appCheckProvider_']['addTokenChangeListener'](_0x17b55f=>{_0x46f877['server_']['refreshAppCheckToken'](_0x17b55f['token']);}),_0x46f877['statsReporter_']=ih(_0x46f877['repoInfo_'],()=>new iu(_0x46f877['stats_'],_0x46f877['server_'])),_0x46f877['infoData_']=new Xh(),_0x46f877['infoSyncTree_']=new pr({'startListening':(_0x171dd1,_0x34c2a6,_0x2b6bd4,_0x2a95ce)=>{let _0x1d45bf=[];const _0x2d07c6=_0x46f877['infoData_']['getNode'](_0x171dd1['_path']);return _0x2d07c6['isEmpty']()||(_0x1d45bf=Yt(_0x46f877['infoSyncTree_'],_0x171dd1['_path'],_0x2d07c6),setTimeout(()=>{_0x2a95ce('ok');},0x0)),_0x1d45bf;},'stopListening':()=>{}}),vs(_0x46f877,'connected',!0x1),_0x46f877['serverSyncTree_']=new pr({'startListening':(_0x1a5133,_0x108ec1,_0x10f491,_0x54b676)=>(_0x46f877['server_']['listen'](_0x1a5133,_0x10f491,_0x108ec1,(_0x3f6043,_0x3f1114)=>{const _0x55aeca=_0x54b676(_0x3f6043,_0x3f1114);V(_0x46f877['eventQueue_'],_0x1a5133['_path'],_0x55aeca);}),[]),'stopListening':(_0x42d8d8,_0x227d1d)=>{_0x46f877['server_']['unlisten'](_0x42d8d8,_0x227d1d);}});}function la(_0x3cb206){const _0xa97992=_0x3cb206['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xa97992;}function Xt(_0x5da73a){return id({'timestamp':la(_0x5da73a)});}function gr(_0x15489a,_0x39f418,_0xdfbccf,_0x38d0c7,_0x4bfdc9){_0x15489a['dataUpdateCount']++;const _0x1129f8=new C(_0x39f418);_0xdfbccf=_0x15489a['interceptServerDataCallback_']?_0x15489a['interceptServerDataCallback_'](_0x39f418,_0xdfbccf):_0xdfbccf;let _0x4b406d=[];if(_0x4bfdc9){if(_0x38d0c7){const _0x47928e=_n(_0xdfbccf,_0xdabe71=>A(_0xdabe71));_0x4b406d=Ju(_0x15489a['serverSyncTree_'],_0x1129f8,_0x47928e,_0x4bfdc9);}else{const _0xd85408=A(_0xdfbccf);_0x4b406d=Jo(_0x15489a['serverSyncTree_'],_0x1129f8,_0xd85408,_0x4bfdc9);}}else{if(_0x38d0c7){const _0x432a23=_n(_0xdfbccf,_0x9b8f7=>A(_0x9b8f7));_0x4b406d=Ku(_0x15489a['serverSyncTree_'],_0x1129f8,_0x432a23);}else{const _0x3b7f16=A(_0xdfbccf);_0x4b406d=Yt(_0x15489a['serverSyncTree_'],_0x1129f8,_0x3b7f16);}}let _0x465187=_0x1129f8;_0x4b406d['length']>0x0&&(_0x465187=ct(_0x15489a,_0x1129f8)),V(_0x15489a['eventQueue_'],_0x465187,_0x4b406d);}function mr(_0x3b5541,_0x4780b4){vs(_0x3b5541,'connected',_0x4780b4),_0x4780b4===!0x1&&Sd(_0x3b5541);}function Id(_0x37bd98,_0x193c45){x(_0x193c45,(_0x574a1c,_0x4d5eea)=>{vs(_0x37bd98,_0x574a1c,_0x4d5eea);});}function vs(_0xa019ff,_0x102bb9,_0x36fd0e){const _0x1f031a=new C('/.info/'+_0x102bb9),_0x56a0dd=A(_0x36fd0e);_0xa019ff['infoData_']['updateSnapshot'](_0x1f031a,_0x56a0dd);const _0x44647c=Yt(_0xa019ff['infoSyncTree_'],_0x1f031a,_0x56a0dd);V(_0xa019ff['eventQueue_'],_0x1f031a,_0x44647c);}function zn(_0x2838aa){return _0x2838aa['nextWriteId_']++;}function wd(_0x370f6a,_0x324e22,_0x2728c2){const _0x40351a=Xu(_0x370f6a['serverSyncTree_'],_0x324e22);return _0x40351a!=null?Promise['resolve'](_0x40351a):_0x370f6a['server_']['get'](_0x324e22)['then'](_0xfe6f55=>{const _0xbfddda=A(_0xfe6f55)['withIndex'](_0x324e22['_queryParams']['getIndex']());Ni(_0x370f6a['serverSyncTree_'],_0x324e22,_0x2728c2,!0x0);let _0x251e25;if(_0x324e22['_queryParams']['loadsAllData']())_0x251e25=Yt(_0x370f6a['serverSyncTree_'],_0x324e22['_path'],_0xbfddda);else{const _0x16d9ab=Wt(_0x370f6a['serverSyncTree_'],_0x324e22);_0x251e25=Jo(_0x370f6a['serverSyncTree_'],_0x324e22['_path'],_0xbfddda,_0x16d9ab);}return V(_0x370f6a['eventQueue_'],_0x324e22['_path'],_0x251e25),An(_0x370f6a['serverSyncTree_'],_0x324e22,_0x2728c2,null,!0x0),_0xbfddda;},_0x46ad24=>(gt(_0x370f6a,'get\x20for\x20query\x20'+O(_0x324e22)+'\x20failed:\x20'+_0x46ad24),Promise['reject'](new Error(_0x46ad24))));}function Cd(_0x134eb7,_0x5ad52d,_0x524e33,_0x5cbee5,_0x11a88e){gt(_0x134eb7,'set',{'path':_0x5ad52d['toString'](),'value':_0x524e33,'priority':_0x5cbee5});const _0x3b058a=Xt(_0x134eb7),_0x36f934=A(_0x524e33,_0x5cbee5),_0x58a834=Vn(_0x134eb7['serverSyncTree_'],_0x5ad52d),_0x4f4a4b=fs(_0x36f934,_0x58a834,_0x3b058a),_0xa555ce=zn(_0x134eb7),_0x1f8447=as(_0x134eb7['serverSyncTree_'],_0x5ad52d,_0x4f4a4b,_0xa555ce,!0x0);qn(_0x134eb7['eventQueue_'],_0x1f8447),_0x134eb7['server_']['put'](_0x5ad52d['toString'](),_0x36f934['val'](!0x0),(_0x3af7bc,_0x4f8865)=>{const _0xfab386=_0x3af7bc==='ok';_0xfab386||U('set\x20at\x20'+_0x5ad52d+'\x20failed:\x20'+_0x3af7bc);const _0x41d697=_e(_0x134eb7['serverSyncTree_'],_0xa555ce,!_0xfab386);V(_0x134eb7['eventQueue_'],_0x5ad52d,_0x41d697),be(_0x134eb7,_0x11a88e,_0x3af7bc,_0x4f8865);});const _0x336c71=Is(_0x134eb7,_0x5ad52d);ct(_0x134eb7,_0x336c71),V(_0x134eb7['eventQueue_'],_0x336c71,[]);}function Td(_0x1317bb,_0xa9181f,_0x158d14,_0x4f41d8){gt(_0x1317bb,'update',{'path':_0xa9181f['toString'](),'value':_0x158d14});let _0x3d72d9=!0x0;const _0x46f7b3=Xt(_0x1317bb),_0x4ef1ce={};if(x(_0x158d14,(_0xe2bd7e,_0x2d365f)=>{_0x3d72d9=!0x1,_0x4ef1ce[_0xe2bd7e]=ta(k(_0xa9181f,_0xe2bd7e),A(_0x2d365f),_0x1317bb['serverSyncTree_'],_0x46f7b3);}),_0x3d72d9)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1317bb,_0x4f41d8,'ok',void 0x0);else{const _0x4c67ec=zn(_0x1317bb),_0x5f4135=ju(_0x1317bb['serverSyncTree_'],_0xa9181f,_0x4ef1ce,_0x4c67ec);qn(_0x1317bb['eventQueue_'],_0x5f4135),_0x1317bb['server_']['merge'](_0xa9181f['toString'](),_0x158d14,(_0x846ddf,_0x5a9f0a)=>{const _0x104fc7=_0x846ddf==='ok';_0x104fc7||U('update\x20at\x20'+_0xa9181f+'\x20failed:\x20'+_0x846ddf);const _0x439c42=_e(_0x1317bb['serverSyncTree_'],_0x4c67ec,!_0x104fc7),_0xd3ddcb=_0x439c42['length']>0x0?ct(_0x1317bb,_0xa9181f):_0xa9181f;V(_0x1317bb['eventQueue_'],_0xd3ddcb,_0x439c42),be(_0x1317bb,_0x4f41d8,_0x846ddf,_0x5a9f0a);}),x(_0x158d14,_0x20ab98=>{const _0x1e8ad0=Is(_0x1317bb,k(_0xa9181f,_0x20ab98));ct(_0x1317bb,_0x1e8ad0);}),V(_0x1317bb['eventQueue_'],_0xa9181f,[]);}}function Sd(_0x2d9e5f){gt(_0x2d9e5f,'onDisconnectEvents');const _0x4fa2c6=Xt(_0x2d9e5f),_0x6df2ba=En();Si(_0x2d9e5f['onDisconnect_'],w(),(_0x569a3b,_0x27d7a3)=>{const _0x2865a7=ta(_0x569a3b,_0x27d7a3,_0x2d9e5f['serverSyncTree_'],_0x4fa2c6);pt(_0x6df2ba,_0x569a3b,_0x2865a7);});let _0x38c7b3=[];Si(_0x6df2ba,w(),(_0x52b74d,_0xae37a8)=>{_0x38c7b3=_0x38c7b3['concat'](Yt(_0x2d9e5f['serverSyncTree_'],_0x52b74d,_0xae37a8));const _0x22ae6d=Is(_0x2d9e5f,_0x52b74d);ct(_0x2d9e5f,_0x22ae6d);}),_0x2d9e5f['onDisconnect_']=En(),V(_0x2d9e5f['eventQueue_'],w(),_0x38c7b3);}function bd(_0x3030d1,_0x1ddd55,_0x5eafca){_0x3030d1['server_']['onDisconnectCancel'](_0x1ddd55['toString'](),(_0x3d1622,_0x22faf1)=>{_0x3d1622==='ok'&&Ti(_0x3030d1['onDisconnect_'],_0x1ddd55),be(_0x3030d1,_0x5eafca,_0x3d1622,_0x22faf1);});}function yr(_0x2c30ce,_0x30e749,_0x139db2,_0x4fc285){const _0x3690c5=A(_0x139db2);_0x2c30ce['server_']['onDisconnectPut'](_0x30e749['toString'](),_0x3690c5['val'](!0x0),(_0x29d198,_0x17f324)=>{_0x29d198==='ok'&&pt(_0x2c30ce['onDisconnect_'],_0x30e749,_0x3690c5),be(_0x2c30ce,_0x4fc285,_0x29d198,_0x17f324);});}function Rd(_0x27edee,_0x1d8d88,_0xf131a3,_0x443e1c,_0x6da79d){const _0x3dff53=A(_0xf131a3,_0x443e1c);_0x27edee['server_']['onDisconnectPut'](_0x1d8d88['toString'](),_0x3dff53['val'](!0x0),(_0x5099dc,_0x1b2599)=>{_0x5099dc==='ok'&&pt(_0x27edee['onDisconnect_'],_0x1d8d88,_0x3dff53),be(_0x27edee,_0x6da79d,_0x5099dc,_0x1b2599);});}function Ad(_0x2ec73c,_0x27c792,_0xbae4ba,_0x58236d){if(pn(_0xbae4ba)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2ec73c,_0x58236d,'ok',void 0x0);return;}_0x2ec73c['server_']['onDisconnectMerge'](_0x27c792['toString'](),_0xbae4ba,(_0x2cc646,_0x62557b)=>{_0x2cc646==='ok'&&x(_0xbae4ba,(_0x549a80,_0x1edbb9)=>{const _0x42dc5c=A(_0x1edbb9);pt(_0x2ec73c['onDisconnect_'],k(_0x27c792,_0x549a80),_0x42dc5c);}),be(_0x2ec73c,_0x58236d,_0x2cc646,_0x62557b);});}function kd(_0x18db10,_0x4f9bd9,_0x4c3ec7){let _0x69270c;y(_0x4f9bd9['_path'])==='.info'?_0x69270c=Ni(_0x18db10['infoSyncTree_'],_0x4f9bd9,_0x4c3ec7):_0x69270c=Ni(_0x18db10['serverSyncTree_'],_0x4f9bd9,_0x4c3ec7),oa(_0x18db10['eventQueue_'],_0x4f9bd9['_path'],_0x69270c);}function Pd(_0x2da030,_0x2004b9,_0x51e1ed){let _0x372a23;y(_0x2004b9['_path'])==='.info'?_0x372a23=An(_0x2da030['infoSyncTree_'],_0x2004b9,_0x51e1ed):_0x372a23=An(_0x2da030['serverSyncTree_'],_0x2004b9,_0x51e1ed),oa(_0x2da030['eventQueue_'],_0x2004b9['_path'],_0x372a23);}function ha(_0x2e03f8){_0x2e03f8['persistentConnection_']&&_0x2e03f8['persistentConnection_']['interrupt'](ca);}function Nd(_0x19204c){_0x19204c['persistentConnection_']&&_0x19204c['persistentConnection_']['resume'](ca);}function gt(_0x449cdf,..._0x4072c4){let _0x7d8fd6='';_0x449cdf['persistentConnection_']&&(_0x7d8fd6=_0x449cdf['persistentConnection_']['id']+':'),L(_0x7d8fd6,..._0x4072c4);}function be(_0x2d48c1,_0x59614f,_0x320e2b,_0x53092b){_0x59614f&&ft(()=>{if(_0x320e2b==='ok')_0x59614f(null);else{const _0x34d985=(_0x320e2b||'error')['toUpperCase']();let _0x5c50c6=_0x34d985;_0x53092b&&(_0x5c50c6+=':\x20'+_0x53092b);const _0x26f1f3=new Error(_0x5c50c6);_0x26f1f3['code']=_0x34d985,_0x59614f(_0x26f1f3);}});}function Od(_0x4faee2,_0x16d572,_0x4b0c1f,_0x34689a,_0x1d1b02,_0x19c278){gt(_0x4faee2,'transaction\x20on\x20'+_0x16d572);const _0x2422c8={'path':_0x16d572,'update':_0x4b0c1f,'onComplete':_0x34689a,'status':null,'order':so(),'applyLocally':_0x19c278,'retryCount':0x0,'unwatcher':_0x1d1b02,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x456a21=Es(_0x4faee2,_0x16d572,void 0x0);_0x2422c8['currentInputSnapshot']=_0x456a21;const _0x327c88=_0x2422c8['update'](_0x456a21['val']());if(_0x327c88===void 0x0)_0x2422c8['unwatcher'](),_0x2422c8['currentOutputSnapshotRaw']=null,_0x2422c8['currentOutputSnapshotResolved']=null,_0x2422c8['onComplete']&&_0x2422c8['onComplete'](null,!0x1,_0x2422c8['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x327c88,_0x2422c8['path']),_0x2422c8['status']=0x0;const _0x3171e9=$n(_0x4faee2['transactionQueueTree_'],_0x16d572),_0x44c179=je(_0x3171e9)||[];_0x44c179['push'](_0x2422c8),gs(_0x3171e9,_0x44c179);let _0x428499;typeof _0x327c88=='object'&&_0x327c88!==null&&Q(_0x327c88,'.priority')?(_0x428499=Le(_0x327c88,'.priority'),f(Bt(_0x428499),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x428499=(Vn(_0x4faee2['serverSyncTree_'],_0x16d572)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x194a65=Xt(_0x4faee2),_0x165352=A(_0x327c88,_0x428499),_0x22bebe=fs(_0x165352,_0x456a21,_0x194a65);_0x2422c8['currentOutputSnapshotRaw']=_0x165352,_0x2422c8['currentOutputSnapshotResolved']=_0x22bebe,_0x2422c8['currentWriteId']=zn(_0x4faee2);const _0x3ab6a5=as(_0x4faee2['serverSyncTree_'],_0x16d572,_0x22bebe,_0x2422c8['currentWriteId'],_0x2422c8['applyLocally']);V(_0x4faee2['eventQueue_'],_0x16d572,_0x3ab6a5),jn(_0x4faee2,_0x4faee2['transactionQueueTree_']);}}function Es(_0x111fe1,_0x49d244,_0x361c15){return Vn(_0x111fe1['serverSyncTree_'],_0x49d244,_0x361c15)||g['EMPTY_NODE'];}function jn(_0x48e0ff,_0x4ee811=_0x48e0ff['transactionQueueTree_']){if(_0x4ee811||Kn(_0x48e0ff,_0x4ee811),je(_0x4ee811)){const _0x40f9b2=da(_0x48e0ff,_0x4ee811);f(_0x40f9b2['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x40f9b2['every'](_0x1aab26=>_0x1aab26['status']===0x0)&&Dd(_0x48e0ff,Qt(_0x4ee811),_0x40f9b2);}else na(_0x4ee811)&&Gn(_0x4ee811,_0x164502=>{jn(_0x48e0ff,_0x164502);});}function Dd(_0x1ebb2c,_0x145215,_0x43fa56){const _0x4c2659=_0x43fa56['map'](_0x284b76=>_0x284b76['currentWriteId']),_0x4d07d9=Es(_0x1ebb2c,_0x145215,_0x4c2659);let _0x19af67=_0x4d07d9;const _0x2afe1a=_0x4d07d9['hash']();for(let _0x44b6e4=0x0;_0x44b6e4<_0x43fa56['length'];_0x44b6e4++){const _0x3c3a65=_0x43fa56[_0x44b6e4];f(_0x3c3a65['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x3c3a65['status']=0x1,_0x3c3a65['retryCount']++;const _0x5db3a8=F(_0x145215,_0x3c3a65['path']);_0x19af67=_0x19af67['updateChild'](_0x5db3a8,_0x3c3a65['currentOutputSnapshotRaw']);}const _0x35ae71=_0x19af67['val'](!0x0),_0x528608=_0x145215;_0x1ebb2c['server_']['put'](_0x528608['toString'](),_0x35ae71,_0x19680f=>{gt(_0x1ebb2c,'transaction\x20put\x20response',{'path':_0x528608['toString'](),'status':_0x19680f});let _0x38da60=[];if(_0x19680f==='ok'){const _0x961d59=[];for(let _0x47a8e0=0x0;_0x47a8e0<_0x43fa56['length'];_0x47a8e0++)_0x43fa56[_0x47a8e0]['status']=0x2,_0x38da60=_0x38da60['concat'](_e(_0x1ebb2c['serverSyncTree_'],_0x43fa56[_0x47a8e0]['currentWriteId'])),_0x43fa56[_0x47a8e0]['onComplete']&&_0x961d59['push'](()=>_0x43fa56[_0x47a8e0]['onComplete'](null,!0x0,_0x43fa56[_0x47a8e0]['currentOutputSnapshotResolved'])),_0x43fa56[_0x47a8e0]['unwatcher']();Kn(_0x1ebb2c,$n(_0x1ebb2c['transactionQueueTree_'],_0x145215)),jn(_0x1ebb2c,_0x1ebb2c['transactionQueueTree_']),V(_0x1ebb2c['eventQueue_'],_0x145215,_0x38da60);for(let _0x1d83d0=0x0;_0x1d83d0<_0x961d59['length'];_0x1d83d0++)ft(_0x961d59[_0x1d83d0]);}else{if(_0x19680f==='datastale'){for(let _0x151957=0x0;_0x151957<_0x43fa56['length'];_0x151957++)_0x43fa56[_0x151957]['status']===0x3?_0x43fa56[_0x151957]['status']=0x4:_0x43fa56[_0x151957]['status']=0x0;}else{U('transaction\x20at\x20'+_0x528608['toString']()+'\x20failed:\x20'+_0x19680f);for(let _0x3f088e=0x0;_0x3f088e<_0x43fa56['length'];_0x3f088e++)_0x43fa56[_0x3f088e]['status']=0x4,_0x43fa56[_0x3f088e]['abortReason']=_0x19680f;}ct(_0x1ebb2c,_0x145215);}},_0x2afe1a);}function ct(_0xda3951,_0x10f093){const _0x103740=ua(_0xda3951,_0x10f093),_0x38323e=Qt(_0x103740),_0x43cfb4=da(_0xda3951,_0x103740);return Md(_0xda3951,_0x43cfb4,_0x38323e),_0x38323e;}function Md(_0x4d5c8a,_0x4a10fc,_0x5f04a8){if(_0x4a10fc['length']===0x0)return;const _0x801b41=[];let _0x4cc19d=[];const _0x1d018e=_0x4a10fc['filter'](_0x5d1980=>_0x5d1980['status']===0x0)['map'](_0x520c9e=>_0x520c9e['currentWriteId']);for(let _0x3f3e63=0x0;_0x3f3e63<_0x4a10fc['length'];_0x3f3e63++){const _0x55629b=_0x4a10fc[_0x3f3e63],_0x1302de=F(_0x5f04a8,_0x55629b['path']);let _0xdc1793=!0x1,_0x567b50;if(f(_0x1302de!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x55629b['status']===0x4)_0xdc1793=!0x0,_0x567b50=_0x55629b['abortReason'],_0x4cc19d=_0x4cc19d['concat'](_e(_0x4d5c8a['serverSyncTree_'],_0x55629b['currentWriteId'],!0x0));else{if(_0x55629b['status']===0x0){if(_0x55629b['retryCount']>=yd)_0xdc1793=!0x0,_0x567b50='maxretry',_0x4cc19d=_0x4cc19d['concat'](_e(_0x4d5c8a['serverSyncTree_'],_0x55629b['currentWriteId'],!0x0));else{const _0x149830=Es(_0x4d5c8a,_0x55629b['path'],_0x1d018e);_0x55629b['currentInputSnapshot']=_0x149830;const _0x2b343f=_0x4a10fc[_0x3f3e63]['update'](_0x149830['val']());if(_0x2b343f!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2b343f,_0x55629b['path']);let _0xc5746d=A(_0x2b343f);typeof _0x2b343f=='object'&&_0x2b343f!=null&&Q(_0x2b343f,'.priority')||(_0xc5746d=_0xc5746d['updatePriority'](_0x149830['getPriority']()));const _0x1dfaa9=_0x55629b['currentWriteId'],_0xd76c02=Xt(_0x4d5c8a),_0x274ff0=fs(_0xc5746d,_0x149830,_0xd76c02);_0x55629b['currentOutputSnapshotRaw']=_0xc5746d,_0x55629b['currentOutputSnapshotResolved']=_0x274ff0,_0x55629b['currentWriteId']=zn(_0x4d5c8a),_0x1d018e['splice'](_0x1d018e['indexOf'](_0x1dfaa9),0x1),_0x4cc19d=_0x4cc19d['concat'](as(_0x4d5c8a['serverSyncTree_'],_0x55629b['path'],_0x274ff0,_0x55629b['currentWriteId'],_0x55629b['applyLocally'])),_0x4cc19d=_0x4cc19d['concat'](_e(_0x4d5c8a['serverSyncTree_'],_0x1dfaa9,!0x0));}else _0xdc1793=!0x0,_0x567b50='nodata',_0x4cc19d=_0x4cc19d['concat'](_e(_0x4d5c8a['serverSyncTree_'],_0x55629b['currentWriteId'],!0x0));}}}V(_0x4d5c8a['eventQueue_'],_0x5f04a8,_0x4cc19d),_0x4cc19d=[],_0xdc1793&&(_0x4a10fc[_0x3f3e63]['status']=0x2,function(_0x1b3202){setTimeout(_0x1b3202,Math['floor'](0x0));}(_0x4a10fc[_0x3f3e63]['unwatcher']),_0x4a10fc[_0x3f3e63]['onComplete']&&(_0x567b50==='nodata'?_0x801b41['push'](()=>_0x4a10fc[_0x3f3e63]['onComplete'](null,!0x1,_0x4a10fc[_0x3f3e63]['currentInputSnapshot'])):_0x801b41['push'](()=>_0x4a10fc[_0x3f3e63]['onComplete'](new Error(_0x567b50),!0x1,null))));}Kn(_0x4d5c8a,_0x4d5c8a['transactionQueueTree_']);for(let _0x3dfade=0x0;_0x3dfade<_0x801b41['length'];_0x3dfade++)ft(_0x801b41[_0x3dfade]);jn(_0x4d5c8a,_0x4d5c8a['transactionQueueTree_']);}function ua(_0x55d28a,_0x5ddf80){let _0xf45220,_0xb0a179=_0x55d28a['transactionQueueTree_'];for(_0xf45220=y(_0x5ddf80);_0xf45220!==null&&je(_0xb0a179)===void 0x0;)_0xb0a179=$n(_0xb0a179,_0xf45220),_0x5ddf80=S(_0x5ddf80),_0xf45220=y(_0x5ddf80);return _0xb0a179;}function da(_0x249d17,_0x2d4066){const _0x4f22a2=[];return fa(_0x249d17,_0x2d4066,_0x4f22a2),_0x4f22a2['sort']((_0x34c071,_0x1f4968)=>_0x34c071['order']-_0x1f4968['order']),_0x4f22a2;}function fa(_0x37e743,_0xca312c,_0x4b1a3e){const _0x45ae8e=je(_0xca312c);if(_0x45ae8e){for(let _0x1af1f9=0x0;_0x1af1f9<_0x45ae8e['length'];_0x1af1f9++)_0x4b1a3e['push'](_0x45ae8e[_0x1af1f9]);}Gn(_0xca312c,_0x191618=>{fa(_0x37e743,_0x191618,_0x4b1a3e);});}function Kn(_0x43753c,_0x4119a5){const _0x1f231e=je(_0x4119a5);if(_0x1f231e){let _0x45074d=0x0;for(let _0x3c2f28=0x0;_0x3c2f28<_0x1f231e['length'];_0x3c2f28++)_0x1f231e[_0x3c2f28]['status']!==0x2&&(_0x1f231e[_0x45074d]=_0x1f231e[_0x3c2f28],_0x45074d++);_0x1f231e['length']=_0x45074d,gs(_0x4119a5,_0x1f231e['length']>0x0?_0x1f231e:void 0x0);}Gn(_0x4119a5,_0x2edc09=>{Kn(_0x43753c,_0x2edc09);});}function Is(_0x4de838,_0x3dc605){const _0x18a70b=Qt(ua(_0x4de838,_0x3dc605)),_0xfb34fc=$n(_0x4de838['transactionQueueTree_'],_0x3dc605);return ad(_0xfb34fc,_0x370f35=>{di(_0x4de838,_0x370f35);}),di(_0x4de838,_0xfb34fc),ia(_0xfb34fc,_0x1efe93=>{di(_0x4de838,_0x1efe93);}),_0x18a70b;}function di(_0x1e508f,_0x3e2bea){const _0x48b7e1=je(_0x3e2bea);if(_0x48b7e1){const _0x494398=[];let _0x4c0466=[],_0x5eeb6e=-0x1;for(let _0xc402b6=0x0;_0xc402b6<_0x48b7e1['length'];_0xc402b6++)_0x48b7e1[_0xc402b6]['status']===0x3||(_0x48b7e1[_0xc402b6]['status']===0x1?(f(_0x5eeb6e===_0xc402b6-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5eeb6e=_0xc402b6,_0x48b7e1[_0xc402b6]['status']=0x3,_0x48b7e1[_0xc402b6]['abortReason']='set'):(f(_0x48b7e1[_0xc402b6]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x48b7e1[_0xc402b6]['unwatcher'](),_0x4c0466=_0x4c0466['concat'](_e(_0x1e508f['serverSyncTree_'],_0x48b7e1[_0xc402b6]['currentWriteId'],!0x0)),_0x48b7e1[_0xc402b6]['onComplete']&&_0x494398['push'](_0x48b7e1[_0xc402b6]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5eeb6e===-0x1?gs(_0x3e2bea,void 0x0):_0x48b7e1['length']=_0x5eeb6e+0x1,V(_0x1e508f['eventQueue_'],Qt(_0x3e2bea),_0x4c0466);for(let _0x4ee8c1=0x0;_0x4ee8c1<_0x494398['length'];_0x4ee8c1++)ft(_0x494398[_0x4ee8c1]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4d8d24){let _0x35a7a7='';const _0x521fdd=_0x4d8d24['split']('/');for(let _0x4fcb4f=0x0;_0x4fcb4f<_0x521fdd['length'];_0x4fcb4f++)if(_0x521fdd[_0x4fcb4f]['length']>0x0){let _0x32d95e=_0x521fdd[_0x4fcb4f];try{_0x32d95e=decodeURIComponent(_0x32d95e['replace'](/\+/g,'\x20'));}catch{}_0x35a7a7+='/'+_0x32d95e;}return _0x35a7a7;}function xd(_0x17a2da){const _0x55e87c={};_0x17a2da['charAt'](0x0)==='?'&&(_0x17a2da=_0x17a2da['substring'](0x1));for(const _0xf7f794 of _0x17a2da['split']('&')){if(_0xf7f794['length']===0x0)continue;const _0x5e4875=_0xf7f794['split']('=');_0x5e4875['length']===0x2?_0x55e87c[decodeURIComponent(_0x5e4875[0x0])]=decodeURIComponent(_0x5e4875[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xf7f794+'\x27\x20in\x20query\x20\x27'+_0x17a2da+'\x27');}return _0x55e87c;}const vr=function(_0x5c40dc,_0x383a07){const _0x10429e=Fd(_0x5c40dc),_0x55c231=_0x10429e['namespace'];_0x10429e['domain']==='firebase.com'&&ae(_0x10429e['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x55c231||_0x55c231==='undefined')&&_0x10429e['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x10429e['secure']||$l();const _0x287dfc=_0x10429e['scheme']==='ws'||_0x10429e['scheme']==='wss';return{'repoInfo':new yo(_0x10429e['host'],_0x10429e['secure'],_0x55c231,_0x287dfc,_0x383a07,'',_0x55c231!==_0x10429e['subdomain']),'path':new C(_0x10429e['pathString'])};},Fd=function(_0x3d8304){let _0x34c7a1='',_0x1f68b6='',_0x3c5007='',_0x190bd4='',_0x58e9a9='',_0x2efa00=!0x0,_0x2831aa='https',_0x4e068d=0x1bb;if(typeof _0x3d8304=='string'){let _0x57cd8a=_0x3d8304['indexOf']('//');_0x57cd8a>=0x0&&(_0x2831aa=_0x3d8304['substring'](0x0,_0x57cd8a-0x1),_0x3d8304=_0x3d8304['substring'](_0x57cd8a+0x2));let _0x466380=_0x3d8304['indexOf']('/');_0x466380===-0x1&&(_0x466380=_0x3d8304['length']);let _0x5b7adc=_0x3d8304['indexOf']('?');_0x5b7adc===-0x1&&(_0x5b7adc=_0x3d8304['length']),_0x34c7a1=_0x3d8304['substring'](0x0,Math['min'](_0x466380,_0x5b7adc)),_0x466380<_0x5b7adc&&(_0x190bd4=Ld(_0x3d8304['substring'](_0x466380,_0x5b7adc)));const _0x5c593d=xd(_0x3d8304['substring'](Math['min'](_0x3d8304['length'],_0x5b7adc)));_0x57cd8a=_0x34c7a1['indexOf'](':'),_0x57cd8a>=0x0?(_0x2efa00=_0x2831aa==='https'||_0x2831aa==='wss',_0x4e068d=parseInt(_0x34c7a1['substring'](_0x57cd8a+0x1),0xa)):_0x57cd8a=_0x34c7a1['length'];const _0xfb8ba1=_0x34c7a1['slice'](0x0,_0x57cd8a);if(_0xfb8ba1['toLowerCase']()==='localhost')_0x1f68b6='localhost';else{if(_0xfb8ba1['split']('.')['length']<=0x2)_0x1f68b6=_0xfb8ba1;else{const _0x16557f=_0x34c7a1['indexOf']('.');_0x3c5007=_0x34c7a1['substring'](0x0,_0x16557f)['toLowerCase'](),_0x1f68b6=_0x34c7a1['substring'](_0x16557f+0x1),_0x58e9a9=_0x3c5007;}}'ns'in _0x5c593d&&(_0x58e9a9=_0x5c593d['ns']);}return{'host':_0x34c7a1,'port':_0x4e068d,'domain':_0x1f68b6,'subdomain':_0x3c5007,'secure':_0x2efa00,'scheme':_0x2831aa,'pathString':_0x190bd4,'namespace':_0x58e9a9};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x202a4d=0x0;const _0x325cea=[];return function(_0x10c6f5){const _0x2de709=_0x10c6f5===_0x202a4d;_0x202a4d=_0x10c6f5;let _0x2b9289;const _0x470398=new Array(0x8);for(_0x2b9289=0x7;_0x2b9289>=0x0;_0x2b9289--)_0x470398[_0x2b9289]=Er['charAt'](_0x10c6f5%0x40),_0x10c6f5=Math['floor'](_0x10c6f5/0x40);f(_0x10c6f5===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4764a5=_0x470398['join']('');if(_0x2de709){for(_0x2b9289=0xb;_0x2b9289>=0x0&&_0x325cea[_0x2b9289]===0x3f;_0x2b9289--)_0x325cea[_0x2b9289]=0x0;_0x325cea[_0x2b9289]++;}else{for(_0x2b9289=0x0;_0x2b9289<0xc;_0x2b9289++)_0x325cea[_0x2b9289]=Math['floor'](Math['random']()*0x40);}for(_0x2b9289=0x0;_0x2b9289<0xc;_0x2b9289++)_0x4764a5+=Er['charAt'](_0x325cea[_0x2b9289]);return f(_0x4764a5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4764a5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x4a26c0,_0x4b63c8,_0x363fb3,_0x4bab39){this['eventType']=_0x4a26c0,this['eventRegistration']=_0x4b63c8,this['snapshot']=_0x363fb3,this['prevName']=_0x4bab39;}['getPath'](){const _0x408c94=this['snapshot']['ref'];return this['eventType']==='value'?_0x408c94['_path']:_0x408c94['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2d493a,_0x4b6be2,_0xa728d4){this['eventRegistration']=_0x2d493a,this['error']=_0x4b6be2,this['path']=_0xa728d4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x44f4f1,_0x12bbc8){this['snapshotCallback']=_0x44f4f1,this['cancelCallback']=_0x12bbc8;}['onValue'](_0x467441,_0x11f37f){this['snapshotCallback']['call'](null,_0x467441,_0x11f37f);}['onCancel'](_0x20f5e7){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x20f5e7);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3b138c){return this['snapshotCallback']===_0x3b138c['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3b138c['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3b138c['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x421162,_0x2c544f){this['_repo']=_0x421162,this['_path']=_0x2c544f;}['cancel'](){const _0x2e40fb=new H();return bd(this['_repo'],this['_path'],_0x2e40fb['wrapCallback'](()=>{})),_0x2e40fb['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x1e2ff9=new H();return yr(this['_repo'],this['_path'],null,_0x1e2ff9['wrapCallback'](()=>{})),_0x1e2ff9['promise'];}['set'](_0x5e7ac5){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x5e7ac5,this['_path'],!0x1);const _0x48e9e8=new H();return yr(this['_repo'],this['_path'],_0x5e7ac5,_0x48e9e8['wrapCallback'](()=>{})),_0x48e9e8['promise'];}['setWithPriority'](_0x32ef33,_0x43add5){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x32ef33,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x43add5);const _0x2b8eba=new H();return Rd(this['_repo'],this['_path'],_0x32ef33,_0x43add5,_0x2b8eba['wrapCallback'](()=>{})),_0x2b8eba['promise'];}['update'](_0x87edcc){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x87edcc,this['_path']);const _0x35d21a=new H();return Ad(this['_repo'],this['_path'],_0x87edcc,_0x35d21a['wrapCallback'](()=>{})),_0x35d21a['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x48016d,_0x5db1d1,_0x5d12cb,_0x45bf6f){this['_repo']=_0x48016d,this['_path']=_0x5db1d1,this['_queryParams']=_0x5d12cb,this['_orderByCalled']=_0x45bf6f;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2a9bcf=sr(this['_queryParams']),_0xae80b7=$i(_0x2a9bcf);return _0xae80b7==='{}'?'default':_0xae80b7;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x20f640){if(_0x20f640=P(_0x20f640),!(_0x20f640 instanceof Ae))return!0x1;const _0x399561=this['_repo']===_0x20f640['_repo'],_0x3617af=Ki(this['_path'],_0x20f640['_path']),_0x5afda7=this['_queryIdentifier']===_0x20f640['_queryIdentifier'];return _0x399561&&_0x3617af&&_0x5afda7;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4563d0,_0x544d81){if(_0x4563d0['_orderByCalled']===!0x0)throw new Error(_0x544d81+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2b6284){let _0x52821c=null,_0x54e0ea=null;if(_0x2b6284['hasStart']()&&(_0x52821c=_0x2b6284['getIndexStartValue']()),_0x2b6284['hasEnd']()&&(_0x54e0ea=_0x2b6284['getIndexEndValue']()),_0x2b6284['getIndex']()===ve){const _0x828fb1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x535beb='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2b6284['hasStart']()){if(_0x2b6284['getIndexStartName']()!==We)throw new Error(_0x828fb1);if(typeof _0x52821c!='string')throw new Error(_0x535beb);}if(_0x2b6284['hasEnd']()){if(_0x2b6284['getIndexEndName']()!==we)throw new Error(_0x828fb1);if(typeof _0x54e0ea!='string')throw new Error(_0x535beb);}}else{if(_0x2b6284['getIndex']()===R){if(_0x52821c!=null&&!Bt(_0x52821c)||_0x54e0ea!=null&&!Bt(_0x54e0ea))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2b6284['getIndex']()instanceof Ji||_0x2b6284['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x52821c!=null&&typeof _0x52821c=='object'||_0x54e0ea!=null&&typeof _0x54e0ea=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x144935){if(_0x144935['hasStart']()&&_0x144935['hasEnd']()&&_0x144935['hasLimit']()&&!_0x144935['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5dabfb,_0x57c501){super(_0x5dabfb,_0x57c501,new Zi(),!0x1);}get['parent'](){const _0x58bc36=Ro(this['_path']);return _0x58bc36===null?null:new ee(this['_repo'],_0x58bc36);}get['root'](){let _0x5f0a64=this;for(;_0x5f0a64['parent']!==null;)_0x5f0a64=_0x5f0a64['parent'];return _0x5f0a64;}}class lt{constructor(_0x52b5b0,_0x1ba54a,_0x52b5d9){this['_node']=_0x52b5b0,this['ref']=_0x1ba54a,this['_index']=_0x52b5d9;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1f1339){const _0x14dafe=new C(_0x1f1339),_0x3f6661=Vt(this['ref'],_0x1f1339);return new lt(this['_node']['getChild'](_0x14dafe),_0x3f6661,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5ee061){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3f9d65,_0x29d338)=>_0x5ee061(new lt(_0x29d338,Vt(this['ref'],_0x3f9d65),R)));}['hasChild'](_0x32d3f5){const _0x13e535=new C(_0x32d3f5);return!this['_node']['getChild'](_0x13e535)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x5e7a82,_0x2a32ab){return _0x5e7a82=P(_0x5e7a82),_0x5e7a82['_checkNotDeleted']('ref'),_0x2a32ab!==void 0x0?Vt(_0x5e7a82['_root'],_0x2a32ab):_0x5e7a82['_root'];}function Vt(_0x26b8f7,_0x3b1905){return _0x26b8f7=P(_0x26b8f7),y(_0x26b8f7['_path'])===null?pd('child','path',_0x3b1905):ys('child','path',_0x3b1905),new ee(_0x26b8f7['_repo'],k(_0x26b8f7['_path'],_0x3b1905));}function v_(_0x578fca){return _0x578fca=P(_0x578fca),new Vd(_0x578fca['_repo'],_0x578fca['_path']);}function E_(_0x3261e6,_0x150e51){_0x3261e6=P(_0x3261e6),Me('push',_0x3261e6['_path']),He('push',_0x150e51,_0x3261e6['_path'],!0x0);const _0x1af9f7=la(_0x3261e6['_repo']),_0x575b0e=Ud(_0x1af9f7),_0x36b79f=Vt(_0x3261e6,_0x575b0e),_0x3ba844=Vt(_0x3261e6,_0x575b0e);let _0xbfb927;return _0x150e51!=null?_0xbfb927=Hd(_0x3ba844,_0x150e51)['then'](()=>_0x3ba844):_0xbfb927=Promise['resolve'](_0x3ba844),_0x36b79f['then']=_0xbfb927['then']['bind'](_0xbfb927),_0x36b79f['catch']=_0xbfb927['then']['bind'](_0xbfb927,void 0x0),_0x36b79f;}function Hd(_0x16bba5,_0x341693){_0x16bba5=P(_0x16bba5),Me('set',_0x16bba5['_path']),He('set',_0x341693,_0x16bba5['_path'],!0x1);const _0x37c333=new H();return Cd(_0x16bba5['_repo'],_0x16bba5['_path'],_0x341693,null,_0x37c333['wrapCallback'](()=>{})),_0x37c333['promise'];}function I_(_0x539e10,_0x25b2dd){ra('update',_0x25b2dd,_0x539e10['_path']);const _0x491806=new H();return Td(_0x539e10['_repo'],_0x539e10['_path'],_0x25b2dd,_0x491806['wrapCallback'](()=>{})),_0x491806['promise'];}function w_(_0x54f766){_0x54f766=P(_0x54f766);const _0x2e608d=new pa(()=>{}),_0x43bc9e=new Qn(_0x2e608d);return wd(_0x54f766['_repo'],_0x54f766,_0x43bc9e)['then'](_0x379419=>new lt(_0x379419,new ee(_0x54f766['_repo'],_0x54f766['_path']),_0x54f766['_queryParams']['getIndex']()));}class Qn{constructor(_0x16e3b5){this['callbackContext']=_0x16e3b5;}['respondsTo'](_0x112158){return _0x112158==='value';}['createEvent'](_0x5af700,_0x412d4d){const _0x1d44e7=_0x412d4d['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x5af700['snapshotNode'],new ee(_0x412d4d['_repo'],_0x412d4d['_path']),_0x1d44e7));}['getEventRunner'](_0x53b159){return _0x53b159['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x53b159['error']):()=>this['callbackContext']['onValue'](_0x53b159['snapshot'],null);}['createCancelEvent'](_0x37c5c4,_0x223b56){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x37c5c4,_0x223b56):null;}['matches'](_0x5ac0c9){return _0x5ac0c9 instanceof Qn?!_0x5ac0c9['callbackContext']||!this['callbackContext']?!0x0:_0x5ac0c9['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x467032,_0x50a191,_0x1657f9,_0x30d9fc,_0x2be795){const _0x2f1ce1=new pa(_0x1657f9,void 0x0),_0x30b273=new Qn(_0x2f1ce1);return kd(_0x467032['_repo'],_0x467032,_0x30b273),()=>Pd(_0x467032['_repo'],_0x467032,_0x30b273);}function Gd(_0x2af5a6,_0x18aa19,_0x30976c,_0x3f3c84){return $d(_0x2af5a6,'value',_0x18aa19);}class mt{}class ma extends mt{constructor(_0xb51d55,_0x2f1874){super(),this['_value']=_0xb51d55,this['_key']=_0x2f1874,this['type']='endAt';}['_apply'](_0x14a7b1){He('endAt',this['_value'],_0x14a7b1['_path'],!0x0);const _0x23a7fd=Jh(_0x14a7b1['_queryParams'],this['_value'],this['_key']);if(ga(_0x23a7fd),Yn(_0x23a7fd),_0x14a7b1['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x14a7b1['_repo'],_0x14a7b1['_path'],_0x23a7fd,_0x14a7b1['_orderByCalled']);}}function C_(_0x54997e,_0x4af34b){return new ma(_0x54997e,_0x4af34b);}class ya extends mt{constructor(_0x43f8e9,_0x4e009f){super(),this['_value']=_0x43f8e9,this['_key']=_0x4e009f,this['type']='startAt';}['_apply'](_0x2a8441){He('startAt',this['_value'],_0x2a8441['_path'],!0x0);const _0x287f1d=Qh(_0x2a8441['_queryParams'],this['_value'],this['_key']);if(ga(_0x287f1d),Yn(_0x287f1d),_0x2a8441['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x2a8441['_repo'],_0x2a8441['_path'],_0x287f1d,_0x2a8441['_orderByCalled']);}}function T_(_0x5b1306=null,_0x37cc5d){return new ya(_0x5b1306,_0x37cc5d);}class qd extends mt{constructor(_0x5582a4){super(),this['_limit']=_0x5582a4,this['type']='limitToFirst';}['_apply'](_0x1965dd){if(_0x1965dd['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x1965dd['_repo'],_0x1965dd['_path'],Yh(_0x1965dd['_queryParams'],this['_limit']),_0x1965dd['_orderByCalled']);}}function S_(_0x17a588){if(Math['floor'](_0x17a588)!==_0x17a588||_0x17a588<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x17a588);}class zd extends mt{constructor(_0x69e06d){super(),this['_path']=_0x69e06d,this['type']='orderByChild';}['_apply'](_0x39bb10){_a(_0x39bb10,'orderByChild');const _0x51674d=new C(this['_path']);if(v(_0x51674d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1568a5=new Ji(_0x51674d),_0x2eeead=xo(_0x39bb10['_queryParams'],_0x1568a5);return Yn(_0x2eeead),new Ae(_0x39bb10['_repo'],_0x39bb10['_path'],_0x2eeead,!0x0);}}function b_(_0x171edf){if(_0x171edf==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x171edf==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x171edf==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x171edf),new zd(_0x171edf);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xb8f96){_a(_0xb8f96,'orderByKey');const _0x1a7553=xo(_0xb8f96['_queryParams'],ve);return Yn(_0x1a7553),new Ae(_0xb8f96['_repo'],_0xb8f96['_path'],_0x1a7553,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x31acf6,_0x56e7bb){super(),this['_value']=_0x31acf6,this['_key']=_0x56e7bb,this['type']='equalTo';}['_apply'](_0x183153){if(He('equalTo',this['_value'],_0x183153['_path'],!0x1),_0x183153['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x183153['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x183153));}}function A_(_0x43ff66,_0x5efa0c){return new Kd(_0x43ff66,_0x5efa0c);}function k_(_0x5b0e21,..._0x4d9ca3){let _0x357ba9=P(_0x5b0e21);for(const _0x59eba7 of _0x4d9ca3)_0x357ba9=_0x59eba7['_apply'](_0x357ba9);return _0x357ba9;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x51a0ad,_0x29b729,_0x542046,_0x4f245d){const _0x370e1c=_0x29b729['lastIndexOf'](':'),_0x5855be=_0x29b729['substring'](0x0,_0x370e1c),_0x333fc8=qt(_0x5855be);_0x51a0ad['repoInfo_']=new yo(_0x29b729,_0x333fc8,_0x51a0ad['repoInfo_']['namespace'],_0x51a0ad['repoInfo_']['webSocketOnly'],_0x51a0ad['repoInfo_']['nodeAdmin'],_0x51a0ad['repoInfo_']['persistenceKey'],_0x51a0ad['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x542046),_0x4f245d&&(_0x51a0ad['authTokenProvider_']=_0x4f245d);}function Xd(_0x1cd56e,_0x50991b,_0x143b00,_0x3eb36a,_0x26dd61){let _0x14cccd=_0x3eb36a||_0x1cd56e['options']['databaseURL'];_0x14cccd===void 0x0&&(_0x1cd56e['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1cd56e['options']['projectId']),_0x14cccd=_0x1cd56e['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x186c7a=vr(_0x14cccd,_0x26dd61),_0x572a78=_0x186c7a['repoInfo'],_0x330b7a;typeof process<'u'&&Bs&&(_0x330b7a=Bs[Yd]),_0x330b7a?(_0x14cccd='http://'+_0x330b7a+'?ns='+_0x572a78['namespace'],_0x186c7a=vr(_0x14cccd,_0x26dd61),_0x572a78=_0x186c7a['repoInfo']):_0x186c7a['repoInfo']['secure'];const _0x311052=new eh(_0x1cd56e['name'],_0x1cd56e['options'],_0x50991b);_d('Invalid\x20Firebase\x20Database\x20URL',_0x186c7a),v(_0x186c7a['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x48b85a=ef(_0x572a78,_0x1cd56e,_0x311052,new Zl(_0x1cd56e,_0x143b00));return new tf(_0x48b85a,_0x1cd56e);}function Zd(_0x55dbf2,_0x1dae4d){const _0x5324f6=Di[_0x1dae4d];(!_0x5324f6||_0x5324f6[_0x55dbf2['key']]!==_0x55dbf2)&&ae('Database\x20'+_0x1dae4d+'('+_0x55dbf2['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x55dbf2),delete _0x5324f6[_0x55dbf2['key']];}function ef(_0x5efdc4,_0x4f8b1a,_0x1a74e3,_0x286dfc){let _0x39da19=Di[_0x4f8b1a['name']];_0x39da19||(_0x39da19={},Di[_0x4f8b1a['name']]=_0x39da19);let _0x204765=_0x39da19[_0x5efdc4['toURLString']()];return _0x204765&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x204765=new vd(_0x5efdc4,Qd,_0x1a74e3,_0x286dfc),_0x39da19[_0x5efdc4['toURLString']()]=_0x204765,_0x204765;}class tf{constructor(_0x346b5f,_0x33be18){this['_repoInternal']=_0x346b5f,this['app']=_0x33be18,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4a8f83){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4a8f83+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x22f401=Zr(),_0x25f353){const _0x35db23=Hi(_0x22f401,'database')['getImmediate']({'identifier':_0x25f353});if(!_0x35db23['_instanceStarted']){const _0xbe9352=hc('database');_0xbe9352&&nf(_0x35db23,..._0xbe9352);}return _0x35db23;}function nf(_0x141422,_0x214078,_0x52248f,_0x5af679={}){_0x141422=P(_0x141422),_0x141422['_checkNotDeleted']('useEmulator');const _0x5b8070=_0x214078+':'+_0x52248f,_0x121977=_0x141422['_repoInternal'];if(_0x141422['_instanceStarted']){if(_0x5b8070===_0x141422['_repoInternal']['repoInfo_']['host']&&xe(_0x5af679,_0x121977['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4f4f1d;if(_0x121977['repoInfo_']['nodeAdmin'])_0x5af679['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4f4f1d=new an(an['OWNER']);else{if(_0x5af679['mockUserToken']){const _0xd01933=typeof _0x5af679['mockUserToken']=='string'?_0x5af679['mockUserToken']:uc(_0x5af679['mockUserToken'],_0x141422['app']['options']['projectId']);_0x4f4f1d=new an(_0xd01933);}}qt(_0x214078)&&Qr(_0x214078),Jd(_0x121977,_0x5b8070,_0x5af679,_0x4f4f1d);}function N_(_0x354667){_0x354667=P(_0x354667),_0x354667['_checkNotDeleted']('goOffline'),ha(_0x354667['_repo']);}function O_(_0x5789c7){_0x5789c7=P(_0x5789c7),_0x5789c7['_checkNotDeleted']('goOnline'),Nd(_0x5789c7['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x5362f8){Ul(dt),st(new Fe('database',(_0x50a70b,{instanceIdentifier:_0x42f7e3})=>{const _0x3fb281=_0x50a70b['getProvider']('app')['getImmediate'](),_0x2f1b48=_0x50a70b['getProvider']('auth-internal'),_0x3f7201=_0x50a70b['getProvider']('app-check-internal');return Xd(_0x3fb281,_0x2f1b48,_0x3f7201,_0x42f7e3);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x5362f8),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x54227a,_0x43b75e){this['committed']=_0x54227a,this['snapshot']=_0x43b75e;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x4b008c,_0x380f68,_0x2ca546){if(_0x4b008c=P(_0x4b008c),Me('Reference.transaction',_0x4b008c['_path']),_0x4b008c['key']==='.length'||_0x4b008c['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4b008c['key']+'\x20is\x20a\x20read-only\x20object.';const _0xd9de24=!0x0,_0x24bf63=new H(),_0x378ecc=(_0x31ab56,_0x386636,_0x3bfd8f)=>{let _0x50aa79=null;_0x31ab56?_0x24bf63['reject'](_0x31ab56):(_0x50aa79=new lt(_0x3bfd8f,new ee(_0x4b008c['_repo'],_0x4b008c['_path']),R),_0x24bf63['resolve'](new of(_0x386636,_0x50aa79)));},_0x576edf=Gd(_0x4b008c,()=>{});return Od(_0x4b008c['_repo'],_0x4b008c['_path'],_0x380f68,_0x378ecc,_0x576edf,_0xd9de24),_0x24bf63['promise'];}se['prototype']['simpleListen']=function(_0x5dc9b8,_0x3ad638){this['sendRequest']('q',{'p':_0x5dc9b8},_0x3ad638);},se['prototype']['echo']=function(_0x4b3916,_0x473fcd){this['sendRequest']('echo',{'d':_0x4b3916},_0x473fcd);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x22ea74,..._0x4bc41c){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x22ea74,..._0x4bc41c);}function cn(_0x163c7b,..._0x59f05c){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x163c7b,..._0x59f05c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x249c10,..._0x256d09){throw ws(_0x249c10,..._0x256d09);}function X(_0x390d61,..._0x905181){return ws(_0x390d61,..._0x905181);}function Ia(_0x2437d9,_0x2a1da0,_0x4a9c13){const _0x20faa1={...af(),[_0x2a1da0]:_0x4a9c13};return new Gt('auth','Firebase',_0x20faa1)['create'](_0x2a1da0,{'appName':_0x2437d9['name']});}function re(_0x1286d4){return Ia(_0x1286d4,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2da6dc,..._0x217ad5){if(typeof _0x2da6dc!='string'){const _0x2e65d0=_0x217ad5[0x0],_0xfa4c9=[..._0x217ad5['slice'](0x1)];return _0xfa4c9[0x0]&&(_0xfa4c9[0x0]['appName']=_0x2da6dc['name']),_0x2da6dc['_errorFactory']['create'](_0x2e65d0,..._0xfa4c9);}return Ea['create'](_0x2da6dc,..._0x217ad5);}function m(_0x54c8c4,_0x3e44bd,..._0x1c88ea){if(!_0x54c8c4)throw ws(_0x3e44bd,..._0x1c88ea);}function ne(_0x2dbd95){const _0x1d55c9='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2dbd95;throw cn(_0x1d55c9),new Error(_0x1d55c9);}function ce(_0x5cc97e,_0x2773b7){_0x5cc97e||ne(_0x2773b7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x4a3d80;return typeof self<'u'&&((_0x4a3d80=self['location'])==null?void 0x0:_0x4a3d80['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x332aca;return typeof self<'u'&&((_0x332aca=self['location'])==null?void 0x0:_0x332aca['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x2618d4=navigator;return _0x2618d4['languages']&&_0x2618d4['languages'][0x0]||_0x2618d4['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x127bcc,_0x398ef9){this['shortDelay']=_0x127bcc,this['longDelay']=_0x398ef9,ce(_0x398ef9>_0x127bcc,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x9a61a1,_0x4344f2){ce(_0x9a61a1['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3ea03c}=_0x9a61a1['emulator'];return _0x4344f2?''+_0x3ea03c+(_0x4344f2['startsWith']('/')?_0x4344f2['slice'](0x1):_0x4344f2):_0x3ea03c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x4d0474,_0x48a736,_0x3df7ec){this['fetchImpl']=_0x4d0474,_0x48a736&&(this['headersImpl']=_0x48a736),_0x3df7ec&&(this['responseImpl']=_0x3df7ec);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4782bd,_0xfa7754){return _0x4782bd['tenantId']&&!_0xfa7754['tenantId']?{..._0xfa7754,'tenantId':_0x4782bd['tenantId']}:_0xfa7754;}async function Pe(_0x4e5d84,_0x1efa01,_0x2a43bb,_0x5c0cfc,_0x2077d3={}){return Ca(_0x4e5d84,_0x2077d3,async()=>{let _0x3a352f={},_0x37347a={};_0x5c0cfc&&(_0x1efa01==='GET'?_0x37347a=_0x5c0cfc:_0x3a352f={'body':JSON['stringify'](_0x5c0cfc)});const _0x1614b5=ut({..._0x37347a,'key':_0x4e5d84['config']['apiKey']})['slice'](0x1),_0x295a83=await _0x4e5d84['_getAdditionalHeaders']();_0x295a83['Content-Type']='application/json',_0x4e5d84['languageCode']&&(_0x295a83['X-Firebase-Locale']=_0x4e5d84['languageCode']);const _0x20ada2={'method':_0x1efa01,'headers':_0x295a83,..._0x3a352f};return dc()||(_0x20ada2['referrerPolicy']='strict-origin-when-cross-origin'),_0x4e5d84['emulatorConfig']&&qt(_0x4e5d84['emulatorConfig']['host'])&&(_0x20ada2['credentials']='include'),wa['fetch']()(await Ta(_0x4e5d84,_0x4e5d84['config']['apiHost'],_0x2a43bb,_0x1614b5),_0x20ada2);});}async function Ca(_0x344c6a,_0x12d83c,_0x45f74a){_0x344c6a['_canInitEmulator']=!0x1;const _0x59b42d={...df,..._0x12d83c};try{const _0x22b1a0=new gf(_0x344c6a),_0x5c2ebc=await Promise['race']([_0x45f74a(),_0x22b1a0['promise']]);_0x22b1a0['clearNetworkTimeout']();const _0x1a98e5=await _0x5c2ebc['json']();if('needConfirmation'in _0x1a98e5)throw on(_0x344c6a,'account-exists-with-different-credential',_0x1a98e5);if(_0x5c2ebc['ok']&&!('errorMessage'in _0x1a98e5))return _0x1a98e5;{const _0x1057fd=_0x5c2ebc['ok']?_0x1a98e5['errorMessage']:_0x1a98e5['error']['message'],[_0x4f0501,_0x432494]=_0x1057fd['split']('\x20:\x20');if(_0x4f0501==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x344c6a,'credential-already-in-use',_0x1a98e5);if(_0x4f0501==='EMAIL_EXISTS')throw on(_0x344c6a,'email-already-in-use',_0x1a98e5);if(_0x4f0501==='USER_DISABLED')throw on(_0x344c6a,'user-disabled',_0x1a98e5);const _0x3b4e14=_0x59b42d[_0x4f0501]||_0x4f0501['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x432494)throw Ia(_0x344c6a,_0x3b4e14,_0x432494);Y(_0x344c6a,_0x3b4e14);}}catch(_0x19c109){if(_0x19c109 instanceof Re)throw _0x19c109;Y(_0x344c6a,'network-request-failed',{'message':String(_0x19c109)});}}async function en(_0x165047,_0x1dff99,_0x2cf0e1,_0x3fa1be,_0x1c50e8={}){const _0x3054a6=await Pe(_0x165047,_0x1dff99,_0x2cf0e1,_0x3fa1be,_0x1c50e8);return'mfaPendingCredential'in _0x3054a6&&Y(_0x165047,'multi-factor-auth-required',{'_serverResponse':_0x3054a6}),_0x3054a6;}async function Ta(_0x3827e5,_0x58c994,_0x21e01e,_0x1794ea){const _0x3af068=''+_0x58c994+_0x21e01e+'?'+_0x1794ea,_0x386a5e=_0x3827e5,_0x532bbe=_0x386a5e['config']['emulator']?Cs(_0x3827e5['config'],_0x3af068):_0x3827e5['config']['apiScheme']+'://'+_0x3af068;return ff['includes'](_0x21e01e)&&(await _0x386a5e['_persistenceManagerAvailable'],_0x386a5e['_getPersistenceType']()==='COOKIE')?_0x386a5e['_getPersistence']()['_getFinalTarget'](_0x532bbe)['toString']():_0x532bbe;}function _f(_0x5986d4){switch(_0x5986d4){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x2023a2){this['auth']=_0x2023a2,this['timer']=null,this['promise']=new Promise((_0x31dece,_0x3b337a)=>{this['timer']=setTimeout(()=>_0x3b337a(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x3441be,_0xdcb593,_0xa9c1be){const _0x1a22e8={'appName':_0x3441be['name']};_0xa9c1be['email']&&(_0x1a22e8['email']=_0xa9c1be['email']),_0xa9c1be['phoneNumber']&&(_0x1a22e8['phoneNumber']=_0xa9c1be['phoneNumber']);const _0x3a644e=X(_0x3441be,_0xdcb593,_0x1a22e8);return _0x3a644e['customData']['_tokenResponse']=_0xa9c1be,_0x3a644e;}function wr(_0x54eb83){return _0x54eb83!==void 0x0&&_0x54eb83['enterprise']!==void 0x0;}class mf{constructor(_0x5546c7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5546c7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5546c7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5546c7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x458f8c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x332079 of this['recaptchaEnforcementState'])if(_0x332079['provider']&&_0x332079['provider']===_0x458f8c)return _f(_0x332079['enforcementState']);return null;}['isProviderEnabled'](_0x3dcd77){return this['getProviderEnforcementState'](_0x3dcd77)==='ENFORCE'||this['getProviderEnforcementState'](_0x3dcd77)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x599336,_0x5630d6){return Pe(_0x599336,'GET','/v2/recaptchaConfig',ke(_0x599336,_0x5630d6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x236d49,_0x38435c){return Pe(_0x236d49,'POST','/v1/accounts:delete',_0x38435c);}async function Pn(_0x21f858,_0x1be33c){return Pe(_0x21f858,'POST','/v1/accounts:lookup',_0x1be33c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x433842){if(_0x433842)try{const _0x15388e=new Date(Number(_0x433842));if(!isNaN(_0x15388e['getTime']()))return _0x15388e['toUTCString']();}catch{}}async function Ef(_0x573371,_0x66c84f=!0x1){const _0x1d412f=P(_0x573371),_0x35d884=await _0x1d412f['getIdToken'](_0x66c84f),_0x511871=Ts(_0x35d884);m(_0x511871&&_0x511871['exp']&&_0x511871['auth_time']&&_0x511871['iat'],_0x1d412f['auth'],'internal-error');const _0x3dba8d=typeof _0x511871['firebase']=='object'?_0x511871['firebase']:void 0x0,_0x56a57c=_0x3dba8d==null?void 0x0:_0x3dba8d['sign_in_provider'];return{'claims':_0x511871,'token':_0x35d884,'authTime':Pt(fi(_0x511871['auth_time'])),'issuedAtTime':Pt(fi(_0x511871['iat'])),'expirationTime':Pt(fi(_0x511871['exp'])),'signInProvider':_0x56a57c||null,'signInSecondFactor':(_0x3dba8d==null?void 0x0:_0x3dba8d['sign_in_second_factor'])||null};}function fi(_0x51c033){return Number(_0x51c033)*0x3e8;}function Ts(_0xc34349){const [_0x3bfe2d,_0x462fad,_0x32ec5e]=_0xc34349['split']('.');if(_0x3bfe2d===void 0x0||_0x462fad===void 0x0||_0x32ec5e===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5cf69f=fn(_0x462fad);return _0x5cf69f?JSON['parse'](_0x5cf69f):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x12390e){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x12390e==null?void 0x0:_0x12390e['toString']()),null;}}function Cr(_0x51e4c6){const _0x4aa91b=Ts(_0x51e4c6);return m(_0x4aa91b,'internal-error'),m(typeof _0x4aa91b['exp']<'u','internal-error'),m(typeof _0x4aa91b['iat']<'u','internal-error'),Number(_0x4aa91b['exp'])-Number(_0x4aa91b['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x486e46,_0x9fe43a,_0x387c20=!0x1){if(_0x387c20)return _0x9fe43a;try{return await _0x9fe43a;}catch(_0x513526){throw _0x513526 instanceof Re&&If(_0x513526)&&_0x486e46['auth']['currentUser']===_0x486e46&&await _0x486e46['auth']['signOut'](),_0x513526;}}function If({code:_0x18bead}){return _0x18bead==='auth/user-disabled'||_0x18bead==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x44fb46){this['user']=_0x44fb46,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xadf8ff){if(_0xadf8ff){const _0x504a79=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x504a79;}else{this['errorBackoff']=0x7530;const _0x59c92e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x59c92e);}}['schedule'](_0x6b31d4=!0x1){if(!this['isRunning'])return;const _0x107355=this['getInterval'](_0x6b31d4);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x107355);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x876fd){(_0x876fd==null?void 0x0:_0x876fd['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x1768ab,_0x31ba04){this['createdAt']=_0x1768ab,this['lastLoginAt']=_0x31ba04,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x80feb7){this['createdAt']=_0x80feb7['createdAt'],this['lastLoginAt']=_0x80feb7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x380fe8){var _0x3e34b1;const _0xbec201=_0x380fe8['auth'],_0x17d137=await _0x380fe8['getIdToken'](),_0x1e8af3=await Ht(_0x380fe8,Pn(_0xbec201,{'idToken':_0x17d137}));m(_0x1e8af3==null?void 0x0:_0x1e8af3['users']['length'],_0xbec201,'internal-error');const _0x3fb67d=_0x1e8af3['users'][0x0];_0x380fe8['_notifyReloadListener'](_0x3fb67d);const _0x116c9b=(_0x3e34b1=_0x3fb67d['providerUserInfo'])!=null&&_0x3e34b1['length']?Sa(_0x3fb67d['providerUserInfo']):[],_0x3e7b24=Tf(_0x380fe8['providerData'],_0x116c9b),_0x3e6038=_0x380fe8['isAnonymous'],_0x45be7a=!(_0x380fe8['email']&&_0x3fb67d['passwordHash'])&&!(_0x3e7b24!=null&&_0x3e7b24['length']),_0x4c8055=_0x3e6038?_0x45be7a:!0x1,_0x3dd483={'uid':_0x3fb67d['localId'],'displayName':_0x3fb67d['displayName']||null,'photoURL':_0x3fb67d['photoUrl']||null,'email':_0x3fb67d['email']||null,'emailVerified':_0x3fb67d['emailVerified']||!0x1,'phoneNumber':_0x3fb67d['phoneNumber']||null,'tenantId':_0x3fb67d['tenantId']||null,'providerData':_0x3e7b24,'metadata':new Li(_0x3fb67d['createdAt'],_0x3fb67d['lastLoginAt']),'isAnonymous':_0x4c8055};Object['assign'](_0x380fe8,_0x3dd483);}async function Cf(_0x46a0bd){const _0x5387d7=P(_0x46a0bd);await Nn(_0x5387d7),await _0x5387d7['auth']['_persistUserIfCurrent'](_0x5387d7),_0x5387d7['auth']['_notifyListenersIfCurrent'](_0x5387d7);}function Tf(_0x3fcca3,_0x5b6733){return[..._0x3fcca3['filter'](_0x557156=>!_0x5b6733['some'](_0x1c0426=>_0x1c0426['providerId']===_0x557156['providerId'])),..._0x5b6733];}function Sa(_0xb7fb80){return _0xb7fb80['map'](({providerId:_0x118ab2,..._0x158202})=>({'providerId':_0x118ab2,'uid':_0x158202['rawId']||'','displayName':_0x158202['displayName']||null,'email':_0x158202['email']||null,'phoneNumber':_0x158202['phoneNumber']||null,'photoURL':_0x158202['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x47acdc,_0x56359f){const _0x3d3b7c=await Ca(_0x47acdc,{},async()=>{const _0x5c51a8=ut({'grant_type':'refresh_token','refresh_token':_0x56359f})['slice'](0x1),{tokenApiHost:_0x27a5f5,apiKey:_0x233bcc}=_0x47acdc['config'],_0x1e28df=await Ta(_0x47acdc,_0x27a5f5,'/v1/token','key='+_0x233bcc),_0x31a5e0=await _0x47acdc['_getAdditionalHeaders']();_0x31a5e0['Content-Type']='application/x-www-form-urlencoded';const _0x3f3440={'method':'POST','headers':_0x31a5e0,'body':_0x5c51a8};return _0x47acdc['emulatorConfig']&&qt(_0x47acdc['emulatorConfig']['host'])&&(_0x3f3440['credentials']='include'),wa['fetch']()(_0x1e28df,_0x3f3440);});return{'accessToken':_0x3d3b7c['access_token'],'expiresIn':_0x3d3b7c['expires_in'],'refreshToken':_0x3d3b7c['refresh_token']};}async function bf(_0x2bb00e,_0x37896e){return Pe(_0x2bb00e,'POST','/v2/accounts:revokeToken',ke(_0x2bb00e,_0x37896e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4f33f5){m(_0x4f33f5['idToken'],'internal-error'),m(typeof _0x4f33f5['idToken']<'u','internal-error'),m(typeof _0x4f33f5['refreshToken']<'u','internal-error');const _0xbefc84='expiresIn'in _0x4f33f5&&typeof _0x4f33f5['expiresIn']<'u'?Number(_0x4f33f5['expiresIn']):Cr(_0x4f33f5['idToken']);this['updateTokensAndExpiration'](_0x4f33f5['idToken'],_0x4f33f5['refreshToken'],_0xbefc84);}['updateFromIdToken'](_0x4e4fb6){m(_0x4e4fb6['length']!==0x0,'internal-error');const _0x492a33=Cr(_0x4e4fb6);this['updateTokensAndExpiration'](_0x4e4fb6,null,_0x492a33);}async['getToken'](_0x2dd8b9,_0x3e28f6=!0x1){return!_0x3e28f6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2dd8b9,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2dd8b9,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xe27479,_0x23ea63){const {accessToken:_0x547b04,refreshToken:_0x218d21,expiresIn:_0x51d229}=await Sf(_0xe27479,_0x23ea63);this['updateTokensAndExpiration'](_0x547b04,_0x218d21,Number(_0x51d229));}['updateTokensAndExpiration'](_0x10ef15,_0xd7c9a0,_0x5e37ae){this['refreshToken']=_0xd7c9a0||null,this['accessToken']=_0x10ef15||null,this['expirationTime']=Date['now']()+_0x5e37ae*0x3e8;}static['fromJSON'](_0x2e3b28,_0xb2594a){const {refreshToken:_0x4cfc84,accessToken:_0x379990,expirationTime:_0xdf3ce1}=_0xb2594a,_0x3fa04d=new et();return _0x4cfc84&&(m(typeof _0x4cfc84=='string','internal-error',{'appName':_0x2e3b28}),_0x3fa04d['refreshToken']=_0x4cfc84),_0x379990&&(m(typeof _0x379990=='string','internal-error',{'appName':_0x2e3b28}),_0x3fa04d['accessToken']=_0x379990),_0xdf3ce1&&(m(typeof _0xdf3ce1=='number','internal-error',{'appName':_0x2e3b28}),_0x3fa04d['expirationTime']=_0xdf3ce1),_0x3fa04d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x33994c){this['accessToken']=_0x33994c['accessToken'],this['refreshToken']=_0x33994c['refreshToken'],this['expirationTime']=_0x33994c['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3d219f,_0x104fb2){m(typeof _0x3d219f=='string'||typeof _0x3d219f>'u','internal-error',{'appName':_0x104fb2});}class j{constructor({uid:_0x1d7395,auth:_0x445990,stsTokenManager:_0x5efba4,..._0x2ff032}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1d7395,this['auth']=_0x445990,this['stsTokenManager']=_0x5efba4,this['accessToken']=_0x5efba4['accessToken'],this['displayName']=_0x2ff032['displayName']||null,this['email']=_0x2ff032['email']||null,this['emailVerified']=_0x2ff032['emailVerified']||!0x1,this['phoneNumber']=_0x2ff032['phoneNumber']||null,this['photoURL']=_0x2ff032['photoURL']||null,this['isAnonymous']=_0x2ff032['isAnonymous']||!0x1,this['tenantId']=_0x2ff032['tenantId']||null,this['providerData']=_0x2ff032['providerData']?[..._0x2ff032['providerData']]:[],this['metadata']=new Li(_0x2ff032['createdAt']||void 0x0,_0x2ff032['lastLoginAt']||void 0x0);}async['getIdToken'](_0x42bbfc){const _0x3bd781=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x42bbfc));return m(_0x3bd781,this['auth'],'internal-error'),this['accessToken']!==_0x3bd781&&(this['accessToken']=_0x3bd781,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3bd781;}['getIdTokenResult'](_0x15207b){return Ef(this,_0x15207b);}['reload'](){return Cf(this);}['_assign'](_0x5577c5){this!==_0x5577c5&&(m(this['uid']===_0x5577c5['uid'],this['auth'],'internal-error'),this['displayName']=_0x5577c5['displayName'],this['photoURL']=_0x5577c5['photoURL'],this['email']=_0x5577c5['email'],this['emailVerified']=_0x5577c5['emailVerified'],this['phoneNumber']=_0x5577c5['phoneNumber'],this['isAnonymous']=_0x5577c5['isAnonymous'],this['tenantId']=_0x5577c5['tenantId'],this['providerData']=_0x5577c5['providerData']['map'](_0x147935=>({..._0x147935})),this['metadata']['_copy'](_0x5577c5['metadata']),this['stsTokenManager']['_assign'](_0x5577c5['stsTokenManager']));}['_clone'](_0x113442){const _0x3d0884=new j({...this,'auth':_0x113442,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3d0884['metadata']['_copy'](this['metadata']),_0x3d0884;}['_onReload'](_0x2849e2){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x2849e2,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x243316){this['reloadListener']?this['reloadListener'](_0x243316):this['reloadUserInfo']=_0x243316;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x28c6a8,_0x423d1b=!0x1){let _0x51aa16=!0x1;_0x28c6a8['idToken']&&_0x28c6a8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x28c6a8),_0x51aa16=!0x0),_0x423d1b&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x51aa16&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1cddcf=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x1cddcf})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3752de=>({..._0x3752de})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x522c9f,_0x40d681){const _0x35f90e=_0x40d681['displayName']??void 0x0,_0x5eddf4=_0x40d681['email']??void 0x0,_0x4f9853=_0x40d681['phoneNumber']??void 0x0,_0x5c3e53=_0x40d681['photoURL']??void 0x0,_0x4b9a63=_0x40d681['tenantId']??void 0x0,_0x3346aa=_0x40d681['_redirectEventId']??void 0x0,_0x335be4=_0x40d681['createdAt']??void 0x0,_0x5efee7=_0x40d681['lastLoginAt']??void 0x0,{uid:_0x476443,emailVerified:_0x4bc151,isAnonymous:_0x542e13,providerData:_0x4ea6fa,stsTokenManager:_0x42d41a}=_0x40d681;m(_0x476443&&_0x42d41a,_0x522c9f,'internal-error');const _0x4f401f=et['fromJSON'](this['name'],_0x42d41a);m(typeof _0x476443=='string',_0x522c9f,'internal-error'),le(_0x35f90e,_0x522c9f['name']),le(_0x5eddf4,_0x522c9f['name']),m(typeof _0x4bc151=='boolean',_0x522c9f,'internal-error'),m(typeof _0x542e13=='boolean',_0x522c9f,'internal-error'),le(_0x4f9853,_0x522c9f['name']),le(_0x5c3e53,_0x522c9f['name']),le(_0x4b9a63,_0x522c9f['name']),le(_0x3346aa,_0x522c9f['name']),le(_0x335be4,_0x522c9f['name']),le(_0x5efee7,_0x522c9f['name']);const _0x46161f=new j({'uid':_0x476443,'auth':_0x522c9f,'email':_0x5eddf4,'emailVerified':_0x4bc151,'displayName':_0x35f90e,'isAnonymous':_0x542e13,'photoURL':_0x5c3e53,'phoneNumber':_0x4f9853,'tenantId':_0x4b9a63,'stsTokenManager':_0x4f401f,'createdAt':_0x335be4,'lastLoginAt':_0x5efee7});return _0x4ea6fa&&Array['isArray'](_0x4ea6fa)&&(_0x46161f['providerData']=_0x4ea6fa['map'](_0x29be37=>({..._0x29be37}))),_0x3346aa&&(_0x46161f['_redirectEventId']=_0x3346aa),_0x46161f;}static async['_fromIdTokenResponse'](_0x452652,_0x2f7635,_0x4df866=!0x1){const _0x1c2506=new et();_0x1c2506['updateFromServerResponse'](_0x2f7635);const _0x16eb35=new j({'uid':_0x2f7635['localId'],'auth':_0x452652,'stsTokenManager':_0x1c2506,'isAnonymous':_0x4df866});return await Nn(_0x16eb35),_0x16eb35;}static async['_fromGetAccountInfoResponse'](_0xadef53,_0x58965c,_0x28ada5){const _0x30fde8=_0x58965c['users'][0x0];m(_0x30fde8['localId']!==void 0x0,'internal-error');const _0x2fee46=_0x30fde8['providerUserInfo']!==void 0x0?Sa(_0x30fde8['providerUserInfo']):[],_0x5edba9=!(_0x30fde8['email']&&_0x30fde8['passwordHash'])&&!(_0x2fee46!=null&&_0x2fee46['length']),_0x3b27d7=new et();_0x3b27d7['updateFromIdToken'](_0x28ada5);const _0x4c5845=new j({'uid':_0x30fde8['localId'],'auth':_0xadef53,'stsTokenManager':_0x3b27d7,'isAnonymous':_0x5edba9}),_0x52a428={'uid':_0x30fde8['localId'],'displayName':_0x30fde8['displayName']||null,'photoURL':_0x30fde8['photoUrl']||null,'email':_0x30fde8['email']||null,'emailVerified':_0x30fde8['emailVerified']||!0x1,'phoneNumber':_0x30fde8['phoneNumber']||null,'tenantId':_0x30fde8['tenantId']||null,'providerData':_0x2fee46,'metadata':new Li(_0x30fde8['createdAt'],_0x30fde8['lastLoginAt']),'isAnonymous':!(_0x30fde8['email']&&_0x30fde8['passwordHash'])&&!(_0x2fee46!=null&&_0x2fee46['length'])};return Object['assign'](_0x4c5845,_0x52a428),_0x4c5845;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2a11e3){ce(_0x2a11e3 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x25f5fc=Tr['get'](_0x2a11e3);return _0x25f5fc?(ce(_0x25f5fc instanceof _0x2a11e3,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x25f5fc):(_0x25f5fc=new _0x2a11e3(),Tr['set'](_0x2a11e3,_0x25f5fc),_0x25f5fc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3d976a,_0x320ae6){this['storage'][_0x3d976a]=_0x320ae6;}async['_get'](_0x2743f3){const _0x39dc15=this['storage'][_0x2743f3];return _0x39dc15===void 0x0?null:_0x39dc15;}async['_remove'](_0x59b330){delete this['storage'][_0x59b330];}['_addListener'](_0x332c5a,_0x4a183a){}['_removeListener'](_0x33a69a,_0x48e704){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0xcb12a,_0x1301ea,_0x37449){return'firebase:'+_0xcb12a+':'+_0x1301ea+':'+_0x37449;}class tt{constructor(_0x5bf501,_0x1a2ec9,_0x5af112){this['persistence']=_0x5bf501,this['auth']=_0x1a2ec9,this['userKey']=_0x5af112;const {config:_0x59e4d1,name:_0x4b8148}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x59e4d1['apiKey'],_0x4b8148),this['fullPersistenceKey']=ln('persistence',_0x59e4d1['apiKey'],_0x4b8148),this['boundEventHandler']=_0x1a2ec9['_onStorageEvent']['bind'](_0x1a2ec9),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xff4ec7){return this['persistence']['_set'](this['fullUserKey'],_0xff4ec7['toJSON']());}async['getCurrentUser'](){const _0x12d509=await this['persistence']['_get'](this['fullUserKey']);if(!_0x12d509)return null;if(typeof _0x12d509=='string'){const _0xed5d4c=await Pn(this['auth'],{'idToken':_0x12d509})['catch'](()=>{});return _0xed5d4c?j['_fromGetAccountInfoResponse'](this['auth'],_0xed5d4c,_0x12d509):null;}return j['_fromJSON'](this['auth'],_0x12d509);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x412b72){if(this['persistence']===_0x412b72)return;const _0x44fee9=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x412b72,_0x44fee9)return this['setCurrentUser'](_0x44fee9);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4bfcbc,_0x429b4a,_0x2b1776='authUser'){if(!_0x429b4a['length'])return new tt(ie(Sr),_0x4bfcbc,_0x2b1776);const _0x50d2c5=(await Promise['all'](_0x429b4a['map'](async _0x2feebf=>{if(await _0x2feebf['_isAvailable']())return _0x2feebf;})))['filter'](_0xe77d97=>_0xe77d97);let _0x37b3e1=_0x50d2c5[0x0]||ie(Sr);const _0x2632a0=ln(_0x2b1776,_0x4bfcbc['config']['apiKey'],_0x4bfcbc['name']);let _0xa843e4=null;for(const _0x57ddd3 of _0x429b4a)try{const _0x3f0833=await _0x57ddd3['_get'](_0x2632a0);if(_0x3f0833){let _0x1acc98;if(typeof _0x3f0833=='string'){const _0x47385a=await Pn(_0x4bfcbc,{'idToken':_0x3f0833})['catch'](()=>{});if(!_0x47385a)break;_0x1acc98=await j['_fromGetAccountInfoResponse'](_0x4bfcbc,_0x47385a,_0x3f0833);}else _0x1acc98=j['_fromJSON'](_0x4bfcbc,_0x3f0833);_0x57ddd3!==_0x37b3e1&&(_0xa843e4=_0x1acc98),_0x37b3e1=_0x57ddd3;break;}}catch{}const _0xa3b787=_0x50d2c5['filter'](_0x2e37b7=>_0x2e37b7['_shouldAllowMigration']);return!_0x37b3e1['_shouldAllowMigration']||!_0xa3b787['length']?new tt(_0x37b3e1,_0x4bfcbc,_0x2b1776):(_0x37b3e1=_0xa3b787[0x0],_0xa843e4&&await _0x37b3e1['_set'](_0x2632a0,_0xa843e4['toJSON']()),await Promise['all'](_0x429b4a['map'](async _0x2ab45a=>{if(_0x2ab45a!==_0x37b3e1)try{await _0x2ab45a['_remove'](_0x2632a0);}catch{}})),new tt(_0x37b3e1,_0x4bfcbc,_0x2b1776));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x3b1be4){const _0x3fcd16=_0x3b1be4['toLowerCase']();if(_0x3fcd16['includes']('opera/')||_0x3fcd16['includes']('opr/')||_0x3fcd16['includes']('opios/'))return'Opera';if(Pa(_0x3fcd16))return'IEMobile';if(_0x3fcd16['includes']('msie')||_0x3fcd16['includes']('trident/'))return'IE';if(_0x3fcd16['includes']('edge/'))return'Edge';if(Ra(_0x3fcd16))return'Firefox';if(_0x3fcd16['includes']('silk/'))return'Silk';if(Oa(_0x3fcd16))return'Blackberry';if(Da(_0x3fcd16))return'Webos';if(Aa(_0x3fcd16))return'Safari';if((_0x3fcd16['includes']('chrome/')||ka(_0x3fcd16))&&!_0x3fcd16['includes']('edge/'))return'Chrome';if(Na(_0x3fcd16))return'Android';{const _0x4d39c8=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x351eb9=_0x3b1be4['match'](_0x4d39c8);if((_0x351eb9==null?void 0x0:_0x351eb9['length'])===0x2)return _0x351eb9[0x1];}return'Other';}function Ra(_0x8ca9b0=W()){return/firefox\//i['test'](_0x8ca9b0);}function Aa(_0x572394=W()){const _0x607bb9=_0x572394['toLowerCase']();return _0x607bb9['includes']('safari/')&&!_0x607bb9['includes']('chrome/')&&!_0x607bb9['includes']('crios/')&&!_0x607bb9['includes']('android');}function ka(_0x450342=W()){return/crios\//i['test'](_0x450342);}function Pa(_0x3455d5=W()){return/iemobile/i['test'](_0x3455d5);}function Na(_0x9dcbf7=W()){return/android/i['test'](_0x9dcbf7);}function Oa(_0x10c661=W()){return/blackberry/i['test'](_0x10c661);}function Da(_0x3532c5=W()){return/webos/i['test'](_0x3532c5);}function Ss(_0x246d9f=W()){return/iphone|ipad|ipod/i['test'](_0x246d9f)||/macintosh/i['test'](_0x246d9f)&&/mobile/i['test'](_0x246d9f);}function Rf(_0x2e355e=W()){var _0x46200b;return Ss(_0x2e355e)&&!!((_0x46200b=window['navigator'])!=null&&_0x46200b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0xe227c9=W()){return Ss(_0xe227c9)||Na(_0xe227c9)||Da(_0xe227c9)||Oa(_0xe227c9)||/windows phone/i['test'](_0xe227c9)||Pa(_0xe227c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0xca387b,_0x2d535a=[]){let _0x2b3196;switch(_0xca387b){case'Browser':_0x2b3196=br(W());break;case'Worker':_0x2b3196=br(W())+'-'+_0xca387b;break;default:_0x2b3196=_0xca387b;}const _0x1da824=_0x2d535a['length']?_0x2d535a['join'](','):'FirebaseCore-web';return _0x2b3196+'/JsCore/'+dt+'/'+_0x1da824;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x330145){this['auth']=_0x330145,this['queue']=[];}['pushCallback'](_0x4ac0ac,_0x426304){const _0x485a16=_0x10baff=>new Promise((_0x1d66e3,_0xc6fb38)=>{try{const _0xca2a0e=_0x4ac0ac(_0x10baff);_0x1d66e3(_0xca2a0e);}catch(_0x4d97a4){_0xc6fb38(_0x4d97a4);}});_0x485a16['onAbort']=_0x426304,this['queue']['push'](_0x485a16);const _0x5ecdad=this['queue']['length']-0x1;return()=>{this['queue'][_0x5ecdad]=()=>Promise['resolve']();};}async['runMiddleware'](_0x152c1d){if(this['auth']['currentUser']===_0x152c1d)return;const _0x22caee=[];try{for(const _0x5e1c19 of this['queue'])await _0x5e1c19(_0x152c1d),_0x5e1c19['onAbort']&&_0x22caee['push'](_0x5e1c19['onAbort']);}catch(_0x14ba2d){_0x22caee['reverse']();for(const _0x42da39 of _0x22caee)try{_0x42da39();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x14ba2d==null?void 0x0:_0x14ba2d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x373f02,_0x991536={}){return Pe(_0x373f02,'GET','/v2/passwordPolicy',ke(_0x373f02,_0x991536));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xec4e83){var _0x4826c8;const _0x5380df=_0xec4e83['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5380df['minPasswordLength']??Nf,_0x5380df['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5380df['maxPasswordLength']),_0x5380df['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5380df['containsLowercaseCharacter']),_0x5380df['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5380df['containsUppercaseCharacter']),_0x5380df['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5380df['containsNumericCharacter']),_0x5380df['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5380df['containsNonAlphanumericCharacter']),this['enforcementState']=_0xec4e83['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4826c8=_0xec4e83['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4826c8['join'](''))??'',this['forceUpgradeOnSignin']=_0xec4e83['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xec4e83['schemaVersion'];}['validatePassword'](_0x167072){const _0x429838={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x167072,_0x429838),this['validatePasswordCharacterOptions'](_0x167072,_0x429838),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['meetsMinPasswordLength']??!0x0),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['meetsMaxPasswordLength']??!0x0),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['containsLowercaseLetter']??!0x0),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['containsUppercaseLetter']??!0x0),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['containsNumericCharacter']??!0x0),_0x429838['isValid']&&(_0x429838['isValid']=_0x429838['containsNonAlphanumericCharacter']??!0x0),_0x429838;}['validatePasswordLengthOptions'](_0x447696,_0x141ffc){const _0x3c97a0=this['customStrengthOptions']['minPasswordLength'],_0x45dcc6=this['customStrengthOptions']['maxPasswordLength'];_0x3c97a0&&(_0x141ffc['meetsMinPasswordLength']=_0x447696['length']>=_0x3c97a0),_0x45dcc6&&(_0x141ffc['meetsMaxPasswordLength']=_0x447696['length']<=_0x45dcc6);}['validatePasswordCharacterOptions'](_0x30e8f6,_0x4c11cc){this['updatePasswordCharacterOptionsStatuses'](_0x4c11cc,!0x1,!0x1,!0x1,!0x1);let _0x19fc67;for(let _0x20d72f=0x0;_0x20d72f<_0x30e8f6['length'];_0x20d72f++)_0x19fc67=_0x30e8f6['charAt'](_0x20d72f),this['updatePasswordCharacterOptionsStatuses'](_0x4c11cc,_0x19fc67>='a'&&_0x19fc67<='z',_0x19fc67>='A'&&_0x19fc67<='Z',_0x19fc67>='0'&&_0x19fc67<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x19fc67));}['updatePasswordCharacterOptionsStatuses'](_0x14890c,_0xc685c4,_0x7ec272,_0x38040e,_0x295610){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x14890c['containsLowercaseLetter']||(_0x14890c['containsLowercaseLetter']=_0xc685c4)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x14890c['containsUppercaseLetter']||(_0x14890c['containsUppercaseLetter']=_0x7ec272)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x14890c['containsNumericCharacter']||(_0x14890c['containsNumericCharacter']=_0x38040e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x14890c['containsNonAlphanumericCharacter']||(_0x14890c['containsNonAlphanumericCharacter']=_0x295610));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5e26eb,_0x53fef7,_0x5c7f7f,_0x2f628f){this['app']=_0x5e26eb,this['heartbeatServiceProvider']=_0x53fef7,this['appCheckServiceProvider']=_0x5c7f7f,this['config']=_0x2f628f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5e26eb['name'],this['clientVersion']=_0x2f628f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x564b18=>this['_resolvePersistenceManagerAvailable']=_0x564b18);}['_initializeWithPersistence'](_0x4236c5,_0x1ad12d){return _0x1ad12d&&(this['_popupRedirectResolver']=ie(_0x1ad12d)),this['_initializationPromise']=this['queue'](async()=>{var _0x49af58,_0x232326,_0x477950;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4236c5),(_0x49af58=this['_resolvePersistenceManagerAvailable'])==null||_0x49af58['call'](this),!this['_deleted'])){if((_0x232326=this['_popupRedirectResolver'])!=null&&_0x232326['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1ad12d),this['lastNotifiedUid']=((_0x477950=this['currentUser'])==null?void 0x0:_0x477950['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x58170b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x58170b)){if(this['currentUser']&&_0x58170b&&this['currentUser']['uid']===_0x58170b['uid']){this['_currentUser']['_assign'](_0x58170b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x58170b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x558cd2){try{const _0x303452=await Pn(this,{'idToken':_0x558cd2}),_0x818c2c=await j['_fromGetAccountInfoResponse'](this,_0x303452,_0x558cd2);await this['directlySetCurrentUser'](_0x818c2c);}catch(_0x4c849b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4c849b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x18a54d){var _0x214308;if($(this['app'])){const _0xb49450=this['app']['settings']['authIdToken'];return _0xb49450?new Promise(_0x57ac74=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0xb49450)['then'](_0x57ac74,_0x57ac74));}):this['directlySetCurrentUser'](null);}const _0x299479=await this['assertedPersistence']['getCurrentUser']();let _0x540590=_0x299479,_0x59e65e=!0x1;if(_0x18a54d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x565463=(_0x214308=this['redirectUser'])==null?void 0x0:_0x214308['_redirectEventId'],_0x36d032=_0x540590==null?void 0x0:_0x540590['_redirectEventId'],_0xb4335=await this['tryRedirectSignIn'](_0x18a54d);(!_0x565463||_0x565463===_0x36d032)&&(_0xb4335!=null&&_0xb4335['user'])&&(_0x540590=_0xb4335['user'],_0x59e65e=!0x0);}if(!_0x540590)return this['directlySetCurrentUser'](null);if(!_0x540590['_redirectEventId']){if(_0x59e65e)try{await this['beforeStateQueue']['runMiddleware'](_0x540590);}catch(_0x509974){_0x540590=_0x299479,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x509974));}return _0x540590?this['reloadAndSetCurrentUserOrClear'](_0x540590):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x540590['_redirectEventId']?this['directlySetCurrentUser'](_0x540590):this['reloadAndSetCurrentUserOrClear'](_0x540590);}async['tryRedirectSignIn'](_0x813adb){let _0x22f839=null;try{_0x22f839=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x813adb,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x22f839;}async['reloadAndSetCurrentUserOrClear'](_0x5a9cfb){try{await Nn(_0x5a9cfb);}catch(_0x2d3464){if((_0x2d3464==null?void 0x0:_0x2d3464['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5a9cfb);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x119857){if($(this['app']))return Promise['reject'](re(this));const _0x36a094=_0x119857?P(_0x119857):null;return _0x36a094&&m(_0x36a094['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x36a094&&_0x36a094['_clone'](this));}async['_updateCurrentUser'](_0x34e638,_0x3eaed3=!0x1){if(!this['_deleted'])return _0x34e638&&m(this['tenantId']===_0x34e638['tenantId'],this,'tenant-id-mismatch'),_0x3eaed3||await this['beforeStateQueue']['runMiddleware'](_0x34e638),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x34e638),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x93bd94){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x93bd94));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3f28b9){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5a8f16=this['_getPasswordPolicyInternal']();return _0x5a8f16['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5a8f16['validatePassword'](_0x3f28b9);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4f4854=await Pf(this),_0x3b8ca8=new Of(_0x4f4854);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3b8ca8:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3b8ca8;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4b8055){this['_errorFactory']=new Gt('auth','Firebase',_0x4b8055());}['onAuthStateChanged'](_0x2d67ca,_0x265664,_0x32a4be){return this['registerStateListener'](this['authStateSubscription'],_0x2d67ca,_0x265664,_0x32a4be);}['beforeAuthStateChanged'](_0x61a822,_0x54adbe){return this['beforeStateQueue']['pushCallback'](_0x61a822,_0x54adbe);}['onIdTokenChanged'](_0x316d7d,_0x454ca1,_0x53b0ba){return this['registerStateListener'](this['idTokenSubscription'],_0x316d7d,_0x454ca1,_0x53b0ba);}['authStateReady'](){return new Promise((_0xeb2c62,_0x483edf)=>{if(this['currentUser'])_0xeb2c62();else{const _0x53f46e=this['onAuthStateChanged'](()=>{_0x53f46e(),_0xeb2c62();},_0x483edf);}});}async['revokeAccessToken'](_0x3b2246){if(this['currentUser']){const _0x32bf68=await this['currentUser']['getIdToken'](),_0x4cd34f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3b2246,'idToken':_0x32bf68};this['tenantId']!=null&&(_0x4cd34f['tenantId']=this['tenantId']),await bf(this,_0x4cd34f);}}['toJSON'](){var _0x106919;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x106919=this['_currentUser'])==null?void 0x0:_0x106919['toJSON']()};}async['_setRedirectUser'](_0x540b4a,_0x1329fa){const _0x56a362=await this['getOrInitRedirectPersistenceManager'](_0x1329fa);return _0x540b4a===null?_0x56a362['removeCurrentUser']():_0x56a362['setCurrentUser'](_0x540b4a);}async['getOrInitRedirectPersistenceManager'](_0x5b3bc1){if(!this['redirectPersistenceManager']){const _0x1a07d5=_0x5b3bc1&&ie(_0x5b3bc1)||this['_popupRedirectResolver'];m(_0x1a07d5,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1a07d5['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2c4a0c){var _0x3f28c9,_0x5453a9;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3f28c9=this['_currentUser'])==null?void 0x0:_0x3f28c9['_redirectEventId'])===_0x2c4a0c?this['_currentUser']:((_0x5453a9=this['redirectUser'])==null?void 0x0:_0x5453a9['_redirectEventId'])===_0x2c4a0c?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x94d833){if(_0x94d833===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x94d833));}['_notifyListenersIfCurrent'](_0x31cbf9){_0x31cbf9===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x40f00b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5ae12e=((_0x40f00b=this['currentUser'])==null?void 0x0:_0x40f00b['uid'])??null;this['lastNotifiedUid']!==_0x5ae12e&&(this['lastNotifiedUid']=_0x5ae12e,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2ed76c,_0x539129,_0x286bed,_0x4b59bc){if(this['_deleted'])return()=>{};const _0x4dd4aa=typeof _0x539129=='function'?_0x539129:_0x539129['next']['bind'](_0x539129);let _0x3fbfab=!0x1;const _0x312b0d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x312b0d,this,'internal-error'),_0x312b0d['then'](()=>{_0x3fbfab||_0x4dd4aa(this['currentUser']);}),typeof _0x539129=='function'){const _0x5c1157=_0x2ed76c['addObserver'](_0x539129,_0x286bed,_0x4b59bc);return()=>{_0x3fbfab=!0x0,_0x5c1157();};}else{const _0x579ed7=_0x2ed76c['addObserver'](_0x539129);return()=>{_0x3fbfab=!0x0,_0x579ed7();};}}async['directlySetCurrentUser'](_0xf470dc){this['currentUser']&&this['currentUser']!==_0xf470dc&&this['_currentUser']['_stopProactiveRefresh'](),_0xf470dc&&this['isProactiveRefreshEnabled']&&_0xf470dc['_startProactiveRefresh'](),this['currentUser']=_0xf470dc,_0xf470dc?await this['assertedPersistence']['setCurrentUser'](_0xf470dc):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x52a02c){return this['operations']=this['operations']['then'](_0x52a02c,_0x52a02c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4b57df){!_0x4b57df||this['frameworks']['includes'](_0x4b57df)||(this['frameworks']['push'](_0x4b57df),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x4f03c1;const _0x4e169f={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x4e169f['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5d6bda=await((_0x4f03c1=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4f03c1['getHeartbeatsHeader']());_0x5d6bda&&(_0x4e169f['X-Firebase-Client']=_0x5d6bda);const _0x2aa18e=await this['_getAppCheckToken']();return _0x2aa18e&&(_0x4e169f['X-Firebase-AppCheck']=_0x2aa18e),_0x4e169f;}async['_getAppCheckToken'](){var _0x2613af;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4d1a15=await((_0x2613af=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2613af['getToken']());return _0x4d1a15!=null&&_0x4d1a15['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4d1a15['error']),_0x4d1a15==null?void 0x0:_0x4d1a15['token'];}}function Ke(_0x24e3c6){return P(_0x24e3c6);}class Rr{constructor(_0x56305f){this['auth']=_0x56305f,this['observer']=null,this['addObserver']=Tc(_0x4ea61a=>this['observer']=_0x4ea61a);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2fb759){Jn=_0x2fb759;}function xa(_0xe8290d){return Jn['loadJS'](_0xe8290d);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x55cb1e){return'__'+_0x55cb1e+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x2c1ee4){_0x2c1ee4();}['execute'](_0x2f4c7f,_0x257954){return Promise['resolve']('token');}['render'](_0x12582d,_0x489d79){return'';}}class Wf{['ready'](_0x568558){_0x568558();}['execute'](_0x23e0aa,_0x2b1f64){return Promise['resolve']('token');}['render'](_0x24a335,_0x12243b){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x56fffd){this['type']=Bf,this['auth']=Ke(_0x56fffd);}async['verify'](_0x395fd4='verify',_0x13612d=!0x1){async function _0x1afb5a(_0x3902c2){if(!_0x13612d){if(_0x3902c2['tenantId']==null&&_0x3902c2['_agentRecaptchaConfig']!=null)return _0x3902c2['_agentRecaptchaConfig']['siteKey'];if(_0x3902c2['tenantId']!=null&&_0x3902c2['_tenantRecaptchaConfigs'][_0x3902c2['tenantId']]!==void 0x0)return _0x3902c2['_tenantRecaptchaConfigs'][_0x3902c2['tenantId']]['siteKey'];}return new Promise(async(_0x5ec591,_0xc7e5f3)=>{yf(_0x3902c2,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x308588=>{if(_0x308588['recaptchaKey']===void 0x0)_0xc7e5f3(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x25e20f=new mf(_0x308588);return _0x3902c2['tenantId']==null?_0x3902c2['_agentRecaptchaConfig']=_0x25e20f:_0x3902c2['_tenantRecaptchaConfigs'][_0x3902c2['tenantId']]=_0x25e20f,_0x5ec591(_0x25e20f['siteKey']);}})['catch'](_0x695160=>{_0xc7e5f3(_0x695160);});});}function _0x1c6264(_0x432135,_0x1aaf1d,_0x4fb9df){const _0x137fbd=window['grecaptcha'];wr(_0x137fbd)?_0x137fbd['enterprise']['ready'](()=>{_0x137fbd['enterprise']['execute'](_0x432135,{'action':_0x395fd4})['then'](_0x4df94b=>{_0x1aaf1d(_0x4df94b);})['catch'](()=>{_0x1aaf1d(Fa);});}):_0x4fb9df(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x56f856,_0x1275c6)=>{_0x1afb5a(this['auth'])['then'](async _0x1fb070=>{if(!_0x13612d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x1c6264(_0x1fb070,_0x56f856,_0x1275c6);else{if(typeof window>'u'){_0x1275c6(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x34fa61=Lf();_0x34fa61['length']!==0x0&&(_0x34fa61+=_0x1fb070+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5bd98a;(_0x5bd98a=he['scriptInjectionDeferred'])==null||_0x5bd98a['resolve']();},xa(_0x34fa61)['then'](()=>{var _0x37f541;return(_0x37f541=he['scriptInjectionDeferred'])==null?void 0x0:_0x37f541['promise'];})['then'](()=>{_0x1c6264(_0x1fb070,_0x56f856,_0x1275c6);})['catch'](_0x432527=>{_0x1275c6(_0x432527);});}})['catch'](_0x2afd30=>{_0x1275c6(_0x2afd30);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5643b6,_0x48cd36,_0xbe9878,_0x702b78=!0x1,_0x48f065=!0x1){const _0x588550=new he(_0x5643b6);let _0x57aa91;if(_0x48f065)_0x57aa91=Fa;else try{_0x57aa91=await _0x588550['verify'](_0xbe9878);}catch{_0x57aa91=await _0x588550['verify'](_0xbe9878,!0x0);}const _0x5b9a52={..._0x48cd36};if(_0xbe9878==='mfaSmsEnrollment'||_0xbe9878==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5b9a52){const _0x111230=_0x5b9a52['phoneEnrollmentInfo']['phoneNumber'],_0x55c333=_0x5b9a52['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5b9a52,{'phoneEnrollmentInfo':{'phoneNumber':_0x111230,'recaptchaToken':_0x55c333,'captchaResponse':_0x57aa91,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5b9a52){const _0x5a8ff3=_0x5b9a52['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5b9a52,{'phoneSignInInfo':{'recaptchaToken':_0x5a8ff3,'captchaResponse':_0x57aa91,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5b9a52;}return _0x702b78?Object['assign'](_0x5b9a52,{'captchaResp':_0x57aa91}):Object['assign'](_0x5b9a52,{'captchaResponse':_0x57aa91}),Object['assign'](_0x5b9a52,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5b9a52,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5b9a52;}async function xi(_0x51ddcd,_0x2d97f5,_0x2c0e59,_0x266b63,_0x3763eb){var _0x5ceea1;if((_0x5ceea1=_0x51ddcd['_getRecaptchaConfig']())!=null&&_0x5ceea1['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x36d7c7=await kr(_0x51ddcd,_0x2d97f5,_0x2c0e59,_0x2c0e59==='getOobCode');return _0x266b63(_0x51ddcd,_0x36d7c7);}else return _0x266b63(_0x51ddcd,_0x2d97f5)['catch'](async _0x138e50=>{if(_0x138e50['code']==='auth/missing-recaptcha-token'){console['log'](_0x2c0e59+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3554fc=await kr(_0x51ddcd,_0x2d97f5,_0x2c0e59,_0x2c0e59==='getOobCode');return _0x266b63(_0x51ddcd,_0x3554fc);}else return Promise['reject'](_0x138e50);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0xb9e215,_0x17eea3){const _0x4cce8e=Hi(_0xb9e215,'auth');if(_0x4cce8e['isInitialized']()){const _0x4747fd=_0x4cce8e['getImmediate'](),_0x55cf82=_0x4cce8e['getOptions']();if(xe(_0x55cf82,_0x17eea3??{}))return _0x4747fd;Y(_0x4747fd,'already-initialized');}return _0x4cce8e['initialize']({'options':_0x17eea3});}function Hf(_0x138b5e,_0x568202){const _0x514648=(_0x568202==null?void 0x0:_0x568202['persistence'])||[],_0x425586=(Array['isArray'](_0x514648)?_0x514648:[_0x514648])['map'](ie);_0x568202!=null&&_0x568202['errorMap']&&_0x138b5e['_updateErrorMap'](_0x568202['errorMap']),_0x138b5e['_initializeWithPersistence'](_0x425586,_0x568202==null?void 0x0:_0x568202['popupRedirectResolver']);}function $f(_0x1fb6bd,_0x4aee84,_0x1ccb75){const _0x1f6e6f=Ke(_0x1fb6bd);m(/^https?:\/\//['test'](_0x4aee84),_0x1f6e6f,'invalid-emulator-scheme');const _0x5569d1=!0x1,_0x5c2d69=Ua(_0x4aee84),{host:_0x27849b,port:_0xb97bcb}=Gf(_0x4aee84),_0x3068ad=_0xb97bcb===null?'':':'+_0xb97bcb,_0x218943={'url':_0x5c2d69+'//'+_0x27849b+_0x3068ad+'/'},_0x158ecf=Object['freeze']({'host':_0x27849b,'port':_0xb97bcb,'protocol':_0x5c2d69['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x5569d1})});if(!_0x1f6e6f['_canInitEmulator']){m(_0x1f6e6f['config']['emulator']&&_0x1f6e6f['emulatorConfig'],_0x1f6e6f,'emulator-config-failed'),m(xe(_0x218943,_0x1f6e6f['config']['emulator'])&&xe(_0x158ecf,_0x1f6e6f['emulatorConfig']),_0x1f6e6f,'emulator-config-failed');return;}_0x1f6e6f['config']['emulator']=_0x218943,_0x1f6e6f['emulatorConfig']=_0x158ecf,_0x1f6e6f['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x27849b)?Qr(_0x5c2d69+'//'+_0x27849b+_0x3068ad):qf();}function Ua(_0x2910df){const _0x278aa7=_0x2910df['indexOf'](':');return _0x278aa7<0x0?'':_0x2910df['substr'](0x0,_0x278aa7+0x1);}function Gf(_0xfc96c5){const _0x424e7a=Ua(_0xfc96c5),_0x1f09c7=/(\/\/)?([^?#/]+)/['exec'](_0xfc96c5['substr'](_0x424e7a['length']));if(!_0x1f09c7)return{'host':'','port':null};const _0x3f1db3=_0x1f09c7[0x2]['split']('@')['pop']()||'',_0x3214ba=/^(\[[^\]]+\])(:|$)/['exec'](_0x3f1db3);if(_0x3214ba){const _0x1f3fe7=_0x3214ba[0x1];return{'host':_0x1f3fe7,'port':Pr(_0x3f1db3['substr'](_0x1f3fe7['length']+0x1))};}else{const [_0xe692d0,_0xa94b2f]=_0x3f1db3['split'](':');return{'host':_0xe692d0,'port':Pr(_0xa94b2f)};}}function Pr(_0x25e486){if(!_0x25e486)return null;const _0xe288bc=Number(_0x25e486);return isNaN(_0xe288bc)?null:_0xe288bc;}function qf(){function _0x179522(){const _0xc7af6f=document['createElement']('p'),_0x492ef4=_0xc7af6f['style'];_0xc7af6f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x492ef4['position']='fixed',_0x492ef4['width']='100%',_0x492ef4['backgroundColor']='#ffffff',_0x492ef4['border']='.1em\x20solid\x20#000000',_0x492ef4['color']='#b50000',_0x492ef4['bottom']='0px',_0x492ef4['left']='0px',_0x492ef4['margin']='0px',_0x492ef4['zIndex']='10000',_0x492ef4['textAlign']='center',_0xc7af6f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xc7af6f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x179522):_0x179522());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x14d379,_0x179d0c){this['providerId']=_0x14d379,this['signInMethod']=_0x179d0c;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x59526d){return ne('not\x20implemented');}['_linkToIdToken'](_0x1afa72,_0x5036bd){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x46e1e7){return ne('not\x20implemented');}}async function zf(_0x13d8dc,_0x1fa24e){return Pe(_0x13d8dc,'POST','/v1/accounts:signUp',_0x1fa24e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x29f343,_0x227df4){return en(_0x29f343,'POST','/v1/accounts:signInWithPassword',ke(_0x29f343,_0x227df4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x308e6f,_0x4b64e3){return en(_0x308e6f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x308e6f,_0x4b64e3));}async function Yf(_0x5cf95e,_0x2258c1){return en(_0x5cf95e,'POST','/v1/accounts:signInWithEmailLink',ke(_0x5cf95e,_0x2258c1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0xb2e0ed,_0x3bd549,_0x5d0888,_0x3b349c=null){super('password',_0x5d0888),this['_email']=_0xb2e0ed,this['_password']=_0x3bd549,this['_tenantId']=_0x3b349c;}static['_fromEmailAndPassword'](_0x3eb689,_0x320d0d){return new $t(_0x3eb689,_0x320d0d,'password');}static['_fromEmailAndCode'](_0x173947,_0x4e9631,_0xf62b8a=null){return new $t(_0x173947,_0x4e9631,'emailLink',_0xf62b8a);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x628fc2){const _0x2b7074=typeof _0x628fc2=='string'?JSON['parse'](_0x628fc2):_0x628fc2;if(_0x2b7074!=null&&_0x2b7074['email']&&(_0x2b7074!=null&&_0x2b7074['password'])){if(_0x2b7074['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x2b7074['email'],_0x2b7074['password']);if(_0x2b7074['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x2b7074['email'],_0x2b7074['password'],_0x2b7074['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1f1e6d){switch(this['signInMethod']){case'password':const _0x42934c={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1f1e6d,_0x42934c,'signInWithPassword',jf);case'emailLink':return Kf(_0x1f1e6d,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1f1e6d,'internal-error');}}async['_linkToIdToken'](_0x33d1a8,_0x4b5274){switch(this['signInMethod']){case'password':const _0xa01a6e={'idToken':_0x4b5274,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x33d1a8,_0xa01a6e,'signUpPassword',zf);case'emailLink':return Yf(_0x33d1a8,{'idToken':_0x4b5274,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x33d1a8,'internal-error');}}['_getReauthenticationResolver'](_0x585415){return this['_getIdTokenResponse'](_0x585415);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1fecab,_0x277ece){return en(_0x1fecab,'POST','/v1/accounts:signInWithIdp',ke(_0x1fecab,_0x277ece));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x18d3fc){const _0x158f68=new $e(_0x18d3fc['providerId'],_0x18d3fc['signInMethod']);return _0x18d3fc['idToken']||_0x18d3fc['accessToken']?(_0x18d3fc['idToken']&&(_0x158f68['idToken']=_0x18d3fc['idToken']),_0x18d3fc['accessToken']&&(_0x158f68['accessToken']=_0x18d3fc['accessToken']),_0x18d3fc['nonce']&&!_0x18d3fc['pendingToken']&&(_0x158f68['nonce']=_0x18d3fc['nonce']),_0x18d3fc['pendingToken']&&(_0x158f68['pendingToken']=_0x18d3fc['pendingToken'])):_0x18d3fc['oauthToken']&&_0x18d3fc['oauthTokenSecret']?(_0x158f68['accessToken']=_0x18d3fc['oauthToken'],_0x158f68['secret']=_0x18d3fc['oauthTokenSecret']):Y('argument-error'),_0x158f68;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x2731d6){const _0x570351=typeof _0x2731d6=='string'?JSON['parse'](_0x2731d6):_0x2731d6,{providerId:_0x3c45d3,signInMethod:_0x40b75c,..._0x38eb28}=_0x570351;if(!_0x3c45d3||!_0x40b75c)return null;const _0x4c0a3c=new $e(_0x3c45d3,_0x40b75c);return _0x4c0a3c['idToken']=_0x38eb28['idToken']||void 0x0,_0x4c0a3c['accessToken']=_0x38eb28['accessToken']||void 0x0,_0x4c0a3c['secret']=_0x38eb28['secret'],_0x4c0a3c['nonce']=_0x38eb28['nonce'],_0x4c0a3c['pendingToken']=_0x38eb28['pendingToken']||null,_0x4c0a3c;}['_getIdTokenResponse'](_0xc1daae){const _0x4ac43e=this['buildRequest']();return nt(_0xc1daae,_0x4ac43e);}['_linkToIdToken'](_0x4ab729,_0x4c7575){const _0x125e1e=this['buildRequest']();return _0x125e1e['idToken']=_0x4c7575,nt(_0x4ab729,_0x125e1e);}['_getReauthenticationResolver'](_0x2a931d){const _0x526a9c=this['buildRequest']();return _0x526a9c['autoCreate']=!0x1,nt(_0x2a931d,_0x526a9c);}['buildRequest'](){const _0x26bf04={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x26bf04['pendingToken']=this['pendingToken'];else{const _0x4d2d07={};this['idToken']&&(_0x4d2d07['id_token']=this['idToken']),this['accessToken']&&(_0x4d2d07['access_token']=this['accessToken']),this['secret']&&(_0x4d2d07['oauth_token_secret']=this['secret']),_0x4d2d07['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4d2d07['nonce']=this['nonce']),_0x26bf04['postBody']=ut(_0x4d2d07);}return _0x26bf04;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x14925f){switch(_0x14925f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x44764a){const _0x472167=Ct(Tt(_0x44764a))['link'],_0x587729=_0x472167?Ct(Tt(_0x472167))['deep_link_id']:null,_0x1a7b97=Ct(Tt(_0x44764a))['deep_link_id'];return(_0x1a7b97?Ct(Tt(_0x1a7b97))['link']:null)||_0x1a7b97||_0x587729||_0x472167||_0x44764a;}class Rs{constructor(_0x937744){const _0xb6b24a=Ct(Tt(_0x937744)),_0x530e50=_0xb6b24a['apiKey']??null,_0xe8064e=_0xb6b24a['oobCode']??null,_0x652e4=Jf(_0xb6b24a['mode']??null);m(_0x530e50&&_0xe8064e&&_0x652e4,'argument-error'),this['apiKey']=_0x530e50,this['operation']=_0x652e4,this['code']=_0xe8064e,this['continueUrl']=_0xb6b24a['continueUrl']??null,this['languageCode']=_0xb6b24a['lang']??null,this['tenantId']=_0xb6b24a['tenantId']??null;}static['parseLink'](_0x336c4c){const _0x451d32=Xf(_0x336c4c);try{return new Rs(_0x451d32);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x3a6378,_0x3888e6){return $t['_fromEmailAndPassword'](_0x3a6378,_0x3888e6);}static['credentialWithLink'](_0x592f48,_0x52c6a0){const _0x48fc37=Rs['parseLink'](_0x52c6a0);return m(_0x48fc37,'argument-error'),$t['_fromEmailAndCode'](_0x592f48,_0x48fc37['code'],_0x48fc37['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x3e4dd2){this['providerId']=_0x3e4dd2,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x484f6c){this['defaultLanguageCode']=_0x484f6c;}['setCustomParameters'](_0x4c0a40){return this['customParameters']=_0x4c0a40,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x37d28d){return this['scopes']['includes'](_0x37d28d)||this['scopes']['push'](_0x37d28d),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4a561c){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4a561c});}static['credentialFromResult'](_0x3a7389){return ue['credentialFromTaggedObject'](_0x3a7389);}static['credentialFromError'](_0x1a3ce0){return ue['credentialFromTaggedObject'](_0x1a3ce0['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x401738}){if(!_0x401738||!('oauthAccessToken'in _0x401738)||!_0x401738['oauthAccessToken'])return null;try{return ue['credential'](_0x401738['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x4be19c,_0x215f2b){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x4be19c,'accessToken':_0x215f2b});}static['credentialFromResult'](_0x3b415b){return de['credentialFromTaggedObject'](_0x3b415b);}static['credentialFromError'](_0x498cfe){return de['credentialFromTaggedObject'](_0x498cfe['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x46049d}){if(!_0x46049d)return null;const {oauthIdToken:_0x160429,oauthAccessToken:_0x256846}=_0x46049d;if(!_0x160429&&!_0x256846)return null;try{return de['credential'](_0x160429,_0x256846);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x54b53e){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x54b53e});}static['credentialFromResult'](_0x5aa7a2){return fe['credentialFromTaggedObject'](_0x5aa7a2);}static['credentialFromError'](_0x769868){return fe['credentialFromTaggedObject'](_0x769868['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59d8ea}){if(!_0x59d8ea||!('oauthAccessToken'in _0x59d8ea)||!_0x59d8ea['oauthAccessToken'])return null;try{return fe['credential'](_0x59d8ea['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4c8d24,_0x25222f){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4c8d24,'oauthTokenSecret':_0x25222f});}static['credentialFromResult'](_0x175b2c){return pe['credentialFromTaggedObject'](_0x175b2c);}static['credentialFromError'](_0x1fea65){return pe['credentialFromTaggedObject'](_0x1fea65['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x10059e}){if(!_0x10059e)return null;const {oauthAccessToken:_0x19c505,oauthTokenSecret:_0x2d785c}=_0x10059e;if(!_0x19c505||!_0x2d785c)return null;try{return pe['credential'](_0x19c505,_0x2d785c);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x2b37f8,_0x46ad3c){return en(_0x2b37f8,'POST','/v1/accounts:signUp',ke(_0x2b37f8,_0x46ad3c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x422efd){this['user']=_0x422efd['user'],this['providerId']=_0x422efd['providerId'],this['_tokenResponse']=_0x422efd['_tokenResponse'],this['operationType']=_0x422efd['operationType'];}static async['_fromIdTokenResponse'](_0x398f5d,_0x52a35a,_0x9e2c8c,_0x43f699=!0x1){const _0x328fc5=await j['_fromIdTokenResponse'](_0x398f5d,_0x9e2c8c,_0x43f699),_0x156257=Nr(_0x9e2c8c);return new Ge({'user':_0x328fc5,'providerId':_0x156257,'_tokenResponse':_0x9e2c8c,'operationType':_0x52a35a});}static async['_forOperation'](_0xab488,_0x5855c7,_0x1d6a95){await _0xab488['_updateTokensIfNecessary'](_0x1d6a95,!0x0);const _0x3b8f13=Nr(_0x1d6a95);return new Ge({'user':_0xab488,'providerId':_0x3b8f13,'_tokenResponse':_0x1d6a95,'operationType':_0x5855c7});}}function Nr(_0x3aa348){return _0x3aa348['providerId']?_0x3aa348['providerId']:'phoneNumber'in _0x3aa348?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x397e68,_0x267e93,_0x2cd6aa,_0x1f5588){super(_0x267e93['code'],_0x267e93['message']),this['operationType']=_0x2cd6aa,this['user']=_0x1f5588,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x397e68['name'],'tenantId':_0x397e68['tenantId']??void 0x0,'_serverResponse':_0x267e93['customData']['_serverResponse'],'operationType':_0x2cd6aa};}static['_fromErrorAndOperation'](_0x164d22,_0x274ac5,_0x33b7f6,_0x440e50){return new On(_0x164d22,_0x274ac5,_0x33b7f6,_0x440e50);}}function Ba(_0x576dbb,_0x3e5b51,_0xbee6db,_0x417860){return(_0x3e5b51==='reauthenticate'?_0xbee6db['_getReauthenticationResolver'](_0x576dbb):_0xbee6db['_getIdTokenResponse'](_0x576dbb))['catch'](_0x67f412=>{throw _0x67f412['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x576dbb,_0x67f412,_0x3e5b51,_0x417860):_0x67f412;});}async function ep(_0x23c842,_0x9e639,_0xbee566=!0x1){const _0x55f8d8=await Ht(_0x23c842,_0x9e639['_linkToIdToken'](_0x23c842['auth'],await _0x23c842['getIdToken']()),_0xbee566);return Ge['_forOperation'](_0x23c842,'link',_0x55f8d8);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0xe6b81e,_0x508396,_0x35209a=!0x1){const {auth:_0x5e9b33}=_0xe6b81e;if($(_0x5e9b33['app']))return Promise['reject'](re(_0x5e9b33));const _0x49242d='reauthenticate';try{const _0x239cc5=await Ht(_0xe6b81e,Ba(_0x5e9b33,_0x49242d,_0x508396,_0xe6b81e),_0x35209a);m(_0x239cc5['idToken'],_0x5e9b33,'internal-error');const _0x1c7331=Ts(_0x239cc5['idToken']);m(_0x1c7331,_0x5e9b33,'internal-error');const {sub:_0x44df4e}=_0x1c7331;return m(_0xe6b81e['uid']===_0x44df4e,_0x5e9b33,'user-mismatch'),Ge['_forOperation'](_0xe6b81e,_0x49242d,_0x239cc5);}catch(_0x21e5d8){throw(_0x21e5d8==null?void 0x0:_0x21e5d8['code'])==='auth/user-not-found'&&Y(_0x5e9b33,'user-mismatch'),_0x21e5d8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x10c598,_0x3ac9d4,_0x1f4a66=!0x1){if($(_0x10c598['app']))return Promise['reject'](re(_0x10c598));const _0x343b2c='signIn',_0x18f4c4=await Ba(_0x10c598,_0x343b2c,_0x3ac9d4),_0x1eff17=await Ge['_fromIdTokenResponse'](_0x10c598,_0x343b2c,_0x18f4c4);return _0x1f4a66||await _0x10c598['_updateCurrentUser'](_0x1eff17['user']),_0x1eff17;}async function np(_0x5a6ca5,_0x2c1100){return Va(Ke(_0x5a6ca5),_0x2c1100);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xc9a422){const _0x5acfc0=Ke(_0xc9a422);_0x5acfc0['_getPasswordPolicyInternal']()&&await _0x5acfc0['_updatePasswordPolicy']();}async function L_(_0x3c261d,_0x209576,_0x2f510c){if($(_0x3c261d['app']))return Promise['reject'](re(_0x3c261d));const _0x4acfd4=Ke(_0x3c261d),_0x46a14e=await xi(_0x4acfd4,{'returnSecureToken':!0x0,'email':_0x209576,'password':_0x2f510c,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xd66194=>{throw _0xd66194['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3c261d),_0xd66194;}),_0x3e74df=await Ge['_fromIdTokenResponse'](_0x4acfd4,'signIn',_0x46a14e);return await _0x4acfd4['_updateCurrentUser'](_0x3e74df['user']),_0x3e74df;}function x_(_0x568149,_0x222f76,_0xce4afe){return $(_0x568149['app'])?Promise['reject'](re(_0x568149)):np(P(_0x568149),yt['credential'](_0x222f76,_0xce4afe))['catch'](async _0x3f2646=>{throw _0x3f2646['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x568149),_0x3f2646;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x3b4a4c,_0x5f0b49){return P(_0x3b4a4c)['setPersistence'](_0x5f0b49);}function ip(_0x81c00c,_0x451ca7,_0x113128,_0x39883a){return P(_0x81c00c)['onIdTokenChanged'](_0x451ca7,_0x113128,_0x39883a);}function sp(_0x1c9b12,_0x2ffaee,_0x3e6cc2){return P(_0x1c9b12)['beforeAuthStateChanged'](_0x2ffaee,_0x3e6cc2);}function U_(_0x4d8c4e,_0x12bef5,_0x1982d1,_0x2b599f){return P(_0x4d8c4e)['onAuthStateChanged'](_0x12bef5,_0x1982d1,_0x2b599f);}function W_(_0x508206){return P(_0x508206)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x901445,_0x16c033){this['storageRetriever']=_0x901445,this['type']=_0x16c033;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x320373,_0x1285de){return this['storage']['setItem'](_0x320373,JSON['stringify'](_0x1285de)),Promise['resolve']();}['_get'](_0xca5023){const _0x46a01b=this['storage']['getItem'](_0xca5023);return Promise['resolve'](_0x46a01b?JSON['parse'](_0x46a01b):null);}['_remove'](_0x42a752){return this['storage']['removeItem'](_0x42a752),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3fcc40,_0x5d067c)=>this['onStorageEvent'](_0x3fcc40,_0x5d067c),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1da08){for(const _0x3cff54 of Object['keys'](this['listeners'])){const _0x4497cd=this['storage']['getItem'](_0x3cff54),_0x34b01a=this['localCache'][_0x3cff54];_0x4497cd!==_0x34b01a&&_0x1da08(_0x3cff54,_0x34b01a,_0x4497cd);}}['onStorageEvent'](_0x547e76,_0x6f16c7=!0x1){if(!_0x547e76['key']){this['forAllChangedKeys']((_0x2b6b2b,_0x3368d1,_0x349cd8)=>{this['notifyListeners'](_0x2b6b2b,_0x349cd8);});return;}const _0x4e5e52=_0x547e76['key'];_0x6f16c7?this['detachListener']():this['stopPolling']();const _0x4e3ead=()=>{const _0x23c1c7=this['storage']['getItem'](_0x4e5e52);!_0x6f16c7&&this['localCache'][_0x4e5e52]===_0x23c1c7||this['notifyListeners'](_0x4e5e52,_0x23c1c7);},_0xd5b3a6=this['storage']['getItem'](_0x4e5e52);Af()&&_0xd5b3a6!==_0x547e76['newValue']&&_0x547e76['newValue']!==_0x547e76['oldValue']?setTimeout(_0x4e3ead,op):_0x4e3ead();}['notifyListeners'](_0x6add95,_0x1086a3){this['localCache'][_0x6add95]=_0x1086a3;const _0x25a52e=this['listeners'][_0x6add95];if(_0x25a52e){for(const _0x39d974 of Array['from'](_0x25a52e))_0x39d974(_0x1086a3&&JSON['parse'](_0x1086a3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x110f3d,_0x251615,_0x46b456)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x110f3d,'oldValue':_0x251615,'newValue':_0x46b456}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x52022f,_0x11c4c9){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x52022f]||(this['listeners'][_0x52022f]=new Set(),this['localCache'][_0x52022f]=this['storage']['getItem'](_0x52022f)),this['listeners'][_0x52022f]['add'](_0x11c4c9);}['_removeListener'](_0x3fade9,_0x2a91dd){this['listeners'][_0x3fade9]&&(this['listeners'][_0x3fade9]['delete'](_0x2a91dd),this['listeners'][_0x3fade9]['size']===0x0&&delete this['listeners'][_0x3fade9]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3f4d7d,_0x3b1bbb){await super['_set'](_0x3f4d7d,_0x3b1bbb),this['localCache'][_0x3f4d7d]=JSON['stringify'](_0x3b1bbb);}async['_get'](_0xeea408){const _0xaee2d1=await super['_get'](_0xeea408);return this['localCache'][_0xeea408]=JSON['stringify'](_0xaee2d1),_0xaee2d1;}async['_remove'](_0x51d60a){await super['_remove'](_0x51d60a),delete this['localCache'][_0x51d60a];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x7585c,_0x3d0452){}['_removeListener'](_0x8d8a37,_0x118345){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2c88f1){return Promise['all'](_0x2c88f1['map'](async _0x2c57cb=>{try{return{'fulfilled':!0x0,'value':await _0x2c57cb};}catch(_0x5d5ee6){return{'fulfilled':!0x1,'reason':_0x5d5ee6};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x45350c){this['eventTarget']=_0x45350c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2f229e){const _0x2d83b3=this['receivers']['find'](_0x38b6eb=>_0x38b6eb['isListeningto'](_0x2f229e));if(_0x2d83b3)return _0x2d83b3;const _0x11067e=new Xn(_0x2f229e);return this['receivers']['push'](_0x11067e),_0x11067e;}['isListeningto'](_0x2ff27c){return this['eventTarget']===_0x2ff27c;}async['handleEvent'](_0x4a6b65){const _0x552a0e=_0x4a6b65,{eventId:_0x246c8c,eventType:_0xec0c43,data:_0x4c74a8}=_0x552a0e['data'],_0x34dfb1=this['handlersMap'][_0xec0c43];if(!(_0x34dfb1!=null&&_0x34dfb1['size']))return;_0x552a0e['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x246c8c,'eventType':_0xec0c43});const _0xe64ba7=Array['from'](_0x34dfb1)['map'](async _0x35d427=>_0x35d427(_0x552a0e['origin'],_0x4c74a8)),_0x113125=await cp(_0xe64ba7);_0x552a0e['ports'][0x0]['postMessage']({'status':'done','eventId':_0x246c8c,'eventType':_0xec0c43,'response':_0x113125});}['_subscribe'](_0x50e47d,_0x133ea3){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x50e47d]||(this['handlersMap'][_0x50e47d]=new Set()),this['handlersMap'][_0x50e47d]['add'](_0x133ea3);}['_unsubscribe'](_0x1b4240,_0xf99909){this['handlersMap'][_0x1b4240]&&_0xf99909&&this['handlersMap'][_0x1b4240]['delete'](_0xf99909),(!_0xf99909||this['handlersMap'][_0x1b4240]['size']===0x0)&&delete this['handlersMap'][_0x1b4240],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x246505='',_0x40d157=0xa){let _0x1d7c6a='';for(let _0x3b90cf=0x0;_0x3b90cf<_0x40d157;_0x3b90cf++)_0x1d7c6a+=Math['floor'](Math['random']()*0xa);return _0x246505+_0x1d7c6a;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1e371c){this['target']=_0x1e371c,this['handlers']=new Set();}['removeMessageHandler'](_0x4d6124){_0x4d6124['messageChannel']&&(_0x4d6124['messageChannel']['port1']['removeEventListener']('message',_0x4d6124['onMessage']),_0x4d6124['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4d6124);}async['_send'](_0xfafd1b,_0x27d254,_0x4344b6=0x32){const _0x1ad3e9=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1ad3e9)throw new Error('connection_unavailable');let _0xef08d6,_0xed07bf;return new Promise((_0x1e2b20,_0x4bdfc4)=>{const _0x3b1fd1=As('',0x14);_0x1ad3e9['port1']['start']();const _0x48812d=setTimeout(()=>{_0x4bdfc4(new Error('unsupported_event'));},_0x4344b6);_0xed07bf={'messageChannel':_0x1ad3e9,'onMessage'(_0x1b708b){const _0x3e2157=_0x1b708b;if(_0x3e2157['data']['eventId']===_0x3b1fd1)switch(_0x3e2157['data']['status']){case'ack':clearTimeout(_0x48812d),_0xef08d6=setTimeout(()=>{_0x4bdfc4(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xef08d6),_0x1e2b20(_0x3e2157['data']['response']);break;default:clearTimeout(_0x48812d),clearTimeout(_0xef08d6),_0x4bdfc4(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xed07bf),_0x1ad3e9['port1']['addEventListener']('message',_0xed07bf['onMessage']),this['target']['postMessage']({'eventType':_0xfafd1b,'eventId':_0x3b1fd1,'data':_0x27d254},[_0x1ad3e9['port2']]);})['finally'](()=>{_0xed07bf&&this['removeMessageHandler'](_0xed07bf);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x157494){Z()['location']['href']=_0x157494;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x16e782;return((_0x16e782=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x16e782['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1611f4){this['request']=_0x1611f4;}['toPromise'](){return new Promise((_0x286366,_0x2a3f0f)=>{this['request']['addEventListener']('success',()=>{_0x286366(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2a3f0f(this['request']['error']);});});}}function Zn(_0x3d8bdc,_0x106ea8){return _0x3d8bdc['transaction']([Mn],_0x106ea8?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x3129a5=indexedDB['deleteDatabase'](Ka);return new nn(_0x3129a5)['toPromise']();}function Qa(){const _0x4eac72=indexedDB['open'](Ka,pp);return new Promise((_0x1ad760,_0x136096)=>{_0x4eac72['addEventListener']('error',()=>{_0x136096(_0x4eac72['error']);}),_0x4eac72['addEventListener']('upgradeneeded',()=>{const _0x267f4a=_0x4eac72['result'];try{_0x267f4a['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x6990a0){_0x136096(_0x6990a0);}}),_0x4eac72['addEventListener']('success',async()=>{const _0x3f5aa8=_0x4eac72['result'];_0x3f5aa8['objectStoreNames']['contains'](Mn)?_0x1ad760(_0x3f5aa8):(_0x3f5aa8['close'](),await _p(),_0x1ad760(await Qa()));});});}async function Or(_0x2f0a90,_0x483c89,_0x1e50b5){const _0x672560=Zn(_0x2f0a90,!0x0)['put']({[Ya]:_0x483c89,'value':_0x1e50b5});return new nn(_0x672560)['toPromise']();}async function gp(_0x1b82ed,_0x13281c){const _0x31bdcd=Zn(_0x1b82ed,!0x1)['get'](_0x13281c),_0x2e9549=await new nn(_0x31bdcd)['toPromise']();return _0x2e9549===void 0x0?null:_0x2e9549['value'];}function Dr(_0x478fd5,_0x46fd04){const _0x35926e=Zn(_0x478fd5,!0x0)['delete'](_0x46fd04);return new nn(_0x35926e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x7e6ef6){let _0xd9c6e3=0x0;for(;;)try{const _0x33a2bf=await this['_openDb']();return await _0x7e6ef6(_0x33a2bf);}catch(_0x497a51){if(_0xd9c6e3++>yp)throw _0x497a51;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2eb789,_0x25ea36)=>({'keyProcessed':(await this['_poll']())['includes'](_0x25ea36['key'])})),this['receiver']['_subscribe']('ping',async(_0xae0d90,_0x141850)=>['keyChanged']);}async['initializeSender'](){var _0x4221e1,_0x157797;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2d7e87=await this['sender']['_send']('ping',{},0x320);_0x2d7e87&&(_0x4221e1=_0x2d7e87[0x0])!=null&&_0x4221e1['fulfilled']&&(_0x157797=_0x2d7e87[0x0])!=null&&_0x157797['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x278cf4){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x278cf4},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x155565=>{await Or(_0x155565,Dn,'1'),await Dr(_0x155565,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0xc751d5){this['pendingWrites']++;try{await _0xc751d5();}finally{this['pendingWrites']--;}}async['_set'](_0x1c688c,_0x1754ec){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x16964c=>Or(_0x16964c,_0x1c688c,_0x1754ec)),this['localCache'][_0x1c688c]=_0x1754ec,this['notifyServiceWorker'](_0x1c688c)));}async['_get'](_0x3dbb57){const _0x27f56b=await this['_withRetries'](_0x4094e4=>gp(_0x4094e4,_0x3dbb57));return this['localCache'][_0x3dbb57]=_0x27f56b,_0x27f56b;}async['_remove'](_0x327437){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3178da=>Dr(_0x3178da,_0x327437)),delete this['localCache'][_0x327437],this['notifyServiceWorker'](_0x327437)));}async['_poll'](){const _0x467c20=await this['_withRetries'](_0xd1b885=>{const _0x550e59=Zn(_0xd1b885,!0x1)['getAll']();return new nn(_0x550e59)['toPromise']();});if(!_0x467c20)return[];if(this['pendingWrites']!==0x0)return[];const _0x3ecc6f=[],_0x3c2e86=new Set();if(_0x467c20['length']!==0x0){for(const {fbase_key:_0x15a135,value:_0x3ed725}of _0x467c20)_0x3c2e86['add'](_0x15a135),JSON['stringify'](this['localCache'][_0x15a135])!==JSON['stringify'](_0x3ed725)&&(this['notifyListeners'](_0x15a135,_0x3ed725),_0x3ecc6f['push'](_0x15a135));}for(const _0x22559c of Object['keys'](this['localCache']))this['localCache'][_0x22559c]&&!_0x3c2e86['has'](_0x22559c)&&(this['notifyListeners'](_0x22559c,null),_0x3ecc6f['push'](_0x22559c));return _0x3ecc6f;}['notifyListeners'](_0x457244,_0x1e8f1b){this['localCache'][_0x457244]=_0x1e8f1b;const _0x29cf4f=this['listeners'][_0x457244];if(_0x29cf4f){for(const _0x59165f of Array['from'](_0x29cf4f))_0x59165f(_0x1e8f1b);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x489b12,_0x17ae8d){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x489b12]||(this['listeners'][_0x489b12]=new Set(),this['_get'](_0x489b12)),this['listeners'][_0x489b12]['add'](_0x17ae8d);}['_removeListener'](_0x2abcfe,_0x57b8f3){this['listeners'][_0x2abcfe]&&(this['listeners'][_0x2abcfe]['delete'](_0x57b8f3),this['listeners'][_0x2abcfe]['size']===0x0&&delete this['listeners'][_0x2abcfe]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5ee9c8,_0x5a287a){return _0x5a287a?ie(_0x5a287a):(m(_0x5ee9c8['_popupRedirectResolver'],_0x5ee9c8,'argument-error'),_0x5ee9c8['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3cc61c){super('custom','custom'),this['params']=_0x3cc61c;}['_getIdTokenResponse'](_0x17d92c){return nt(_0x17d92c,this['_buildIdpRequest']());}['_linkToIdToken'](_0x74a1b7,_0x3750d5){return nt(_0x74a1b7,this['_buildIdpRequest'](_0x3750d5));}['_getReauthenticationResolver'](_0xa6ac33){return nt(_0xa6ac33,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x11d9e2){const _0x5accff={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x11d9e2&&(_0x5accff['idToken']=_0x11d9e2),_0x5accff;}}function Ip(_0xb3afb8){return Va(_0xb3afb8['auth'],new ks(_0xb3afb8),_0xb3afb8['bypassAuthState']);}function wp(_0x1760cb){const {auth:_0x36b6d5,user:_0x4cf998}=_0x1760cb;return m(_0x4cf998,_0x36b6d5,'internal-error'),tp(_0x4cf998,new ks(_0x1760cb),_0x1760cb['bypassAuthState']);}async function Cp(_0x1c6fcd){const {auth:_0x425d38,user:_0x3c435a}=_0x1c6fcd;return m(_0x3c435a,_0x425d38,'internal-error'),ep(_0x3c435a,new ks(_0x1c6fcd),_0x1c6fcd['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x1f270b,_0x492568,_0x2f2e32,_0x17399c,_0x2cc3eb=!0x1){this['auth']=_0x1f270b,this['resolver']=_0x2f2e32,this['user']=_0x17399c,this['bypassAuthState']=_0x2cc3eb,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x492568)?_0x492568:[_0x492568];}['execute'](){return new Promise(async(_0x3c9ce,_0x27d370)=>{this['pendingPromise']={'resolve':_0x3c9ce,'reject':_0x27d370};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2dfc56){this['reject'](_0x2dfc56);}});}async['onAuthEvent'](_0x4a5f49){const {urlResponse:_0x4f30cf,sessionId:_0x48f9fd,postBody:_0x2d0763,tenantId:_0x56c985,error:_0x35e962,type:_0x43f02}=_0x4a5f49;if(_0x35e962){this['reject'](_0x35e962);return;}const _0x5885f6={'auth':this['auth'],'requestUri':_0x4f30cf,'sessionId':_0x48f9fd,'tenantId':_0x56c985||void 0x0,'postBody':_0x2d0763||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x43f02)(_0x5885f6));}catch(_0x8ec08d){this['reject'](_0x8ec08d);}}['onError'](_0x3f9ecb){this['reject'](_0x3f9ecb);}['getIdpTask'](_0x418f23){switch(_0x418f23){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x507071){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x507071),this['unregisterAndCleanUp']();}['reject'](_0x44ca8c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x44ca8c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x28b0d1,_0x49a420,_0x4f68bd,_0x1c28a6,_0x409ec5){super(_0x28b0d1,_0x49a420,_0x1c28a6,_0x409ec5),this['provider']=_0x4f68bd,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x5c1c3d=await this['execute']();return m(_0x5c1c3d,this['auth'],'internal-error'),_0x5c1c3d;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4be38e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4be38e),this['authWindow']['associatedEvent']=_0x4be38e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x449cf4=>{this['reject'](_0x449cf4);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x119f7d=>{_0x119f7d||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x313805;return((_0x313805=this['authWindow'])==null?void 0x0:_0x313805['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x32e175=()=>{var _0x2f8b0f,_0x275aa0;if((_0x275aa0=(_0x2f8b0f=this['authWindow'])==null?void 0x0:_0x2f8b0f['window'])!=null&&_0x275aa0['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x32e175,Tp['get']());};_0x32e175();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x40c2a5,_0x4b8da4,_0x552b27=!0x1){super(_0x40c2a5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4b8da4,void 0x0,_0x552b27),this['eventId']=null;}async['execute'](){let _0x202d38=hn['get'](this['auth']['_key']());if(!_0x202d38){try{const _0x331a37=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x202d38=()=>Promise['resolve'](_0x331a37);}catch(_0x5ab4f2){_0x202d38=()=>Promise['reject'](_0x5ab4f2);}hn['set'](this['auth']['_key'](),_0x202d38);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x202d38();}async['onAuthEvent'](_0x4d58f5){if(_0x4d58f5['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4d58f5);if(_0x4d58f5['type']==='unknown'){this['resolve'](null);return;}if(_0x4d58f5['eventId']){const _0x27fc32=await this['auth']['_redirectUserForId'](_0x4d58f5['eventId']);if(_0x27fc32)return this['user']=_0x27fc32,super['onAuthEvent'](_0x4d58f5);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x2124a2,_0x37d9ae){const _0x161c3c=Pp(_0x37d9ae),_0x59d571=kp(_0x2124a2);if(!await _0x59d571['_isAvailable']())return!0x1;const _0x1e772c=await _0x59d571['_get'](_0x161c3c)==='true';return await _0x59d571['_remove'](_0x161c3c),_0x1e772c;}function Ap(_0x299667,_0x5d1bdf){hn['set'](_0x299667['_key'](),_0x5d1bdf);}function kp(_0x32f229){return ie(_0x32f229['_redirectPersistence']);}function Pp(_0x36faca){return ln(Sp,_0x36faca['config']['apiKey'],_0x36faca['name']);}async function Np(_0x39f62b,_0x2b85fe,_0x1e9c24=!0x1){if($(_0x39f62b['app']))return Promise['reject'](re(_0x39f62b));const _0x47bd59=Ke(_0x39f62b),_0x1918b2=Ep(_0x47bd59,_0x2b85fe),_0x8776f5=await new bp(_0x47bd59,_0x1918b2,_0x1e9c24)['execute']();return _0x8776f5&&!_0x1e9c24&&(delete _0x8776f5['user']['_redirectEventId'],await _0x47bd59['_persistUserIfCurrent'](_0x8776f5['user']),await _0x47bd59['_setRedirectUser'](null,_0x2b85fe)),_0x8776f5;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x27cdcc){this['auth']=_0x27cdcc,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x122cd0){this['consumers']['add'](_0x122cd0),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x122cd0)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x122cd0),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x57b7cd){this['consumers']['delete'](_0x57b7cd);}['onEvent'](_0x4c461e){if(this['hasEventBeenHandled'](_0x4c461e))return!0x1;let _0x2dfc8b=!0x1;return this['consumers']['forEach'](_0xbb0541=>{this['isEventForConsumer'](_0x4c461e,_0xbb0541)&&(_0x2dfc8b=!0x0,this['sendToConsumer'](_0x4c461e,_0xbb0541),this['saveEventToCache'](_0x4c461e));}),this['hasHandledPotentialRedirect']||!Mp(_0x4c461e)||(this['hasHandledPotentialRedirect']=!0x0,_0x2dfc8b||(this['queuedRedirectEvent']=_0x4c461e,_0x2dfc8b=!0x0)),_0x2dfc8b;}['sendToConsumer'](_0x470659,_0xc7a0c1){var _0x1c0119;if(_0x470659['error']&&!Za(_0x470659)){const _0x41fc0c=((_0x1c0119=_0x470659['error']['code'])==null?void 0x0:_0x1c0119['split']('auth/')[0x1])||'internal-error';_0xc7a0c1['onError'](X(this['auth'],_0x41fc0c));}else _0xc7a0c1['onAuthEvent'](_0x470659);}['isEventForConsumer'](_0x480b6d,_0x3494c3){const _0x2c6ce7=_0x3494c3['eventId']===null||!!_0x480b6d['eventId']&&_0x480b6d['eventId']===_0x3494c3['eventId'];return _0x3494c3['filter']['includes'](_0x480b6d['type'])&&_0x2c6ce7;}['hasEventBeenHandled'](_0x59d6c7){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x59d6c7));}['saveEventToCache'](_0x1ae293){this['cachedEventUids']['add'](Mr(_0x1ae293)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x5ba4b8){return[_0x5ba4b8['type'],_0x5ba4b8['eventId'],_0x5ba4b8['sessionId'],_0x5ba4b8['tenantId']]['filter'](_0x4cb7c6=>_0x4cb7c6)['join']('-');}function Za({type:_0x4e293b,error:_0x4d5494}){return _0x4e293b==='unknown'&&(_0x4d5494==null?void 0x0:_0x4d5494['code'])==='auth/no-auth-event';}function Mp(_0x3a4c3f){switch(_0x3a4c3f['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3a4c3f);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3635e3,_0xc018f5={}){return Pe(_0x3635e3,'GET','/v1/projects',_0xc018f5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x93306b){if(_0x93306b['config']['emulator'])return;const {authorizedDomains:_0x4d5460}=await Lp(_0x93306b);for(const _0x3ea3b7 of _0x4d5460)try{if(Wp(_0x3ea3b7))return;}catch{}Y(_0x93306b,'unauthorized-domain');}function Wp(_0x47ce48){const _0x49897f=Mi(),{protocol:_0x23abcb,hostname:_0x13666d}=new URL(_0x49897f);if(_0x47ce48['startsWith']('chrome-extension://')){const _0x18cbbd=new URL(_0x47ce48);return _0x18cbbd['hostname']===''&&_0x13666d===''?_0x23abcb==='chrome-extension:'&&_0x47ce48['replace']('chrome-extension://','')===_0x49897f['replace']('chrome-extension://',''):_0x23abcb==='chrome-extension:'&&_0x18cbbd['hostname']===_0x13666d;}if(!Fp['test'](_0x23abcb))return!0x1;if(xp['test'](_0x47ce48))return _0x13666d===_0x47ce48;const _0x22d3f6=_0x47ce48['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x22d3f6+'|'+_0x22d3f6+')$','i')['test'](_0x13666d);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x2414d8=Z()['___jsl'];if(_0x2414d8!=null&&_0x2414d8['H']){for(const _0x399921 of Object['keys'](_0x2414d8['H']))if(_0x2414d8['H'][_0x399921]['r']=_0x2414d8['H'][_0x399921]['r']||[],_0x2414d8['H'][_0x399921]['L']=_0x2414d8['H'][_0x399921]['L']||[],_0x2414d8['H'][_0x399921]['r']=[..._0x2414d8['H'][_0x399921]['L']],_0x2414d8['CP']){for(let _0x3377a6=0x0;_0x3377a6<_0x2414d8['CP']['length'];_0x3377a6++)_0x2414d8['CP'][_0x3377a6]=null;}}}function Vp(_0x56860d){return new Promise((_0x42d481,_0x37c18b)=>{var _0x274f0b,_0x4b5a35,_0x32dfcc;function _0x15e36e(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x42d481(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x37c18b(X(_0x56860d,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4b5a35=(_0x274f0b=Z()['gapi'])==null?void 0x0:_0x274f0b['iframes'])!=null&&_0x4b5a35['Iframe'])_0x42d481(gapi['iframes']['getContext']());else{if((_0x32dfcc=Z()['gapi'])!=null&&_0x32dfcc['load'])_0x15e36e();else{const _0x215eea=Ff('iframefcb');return Z()[_0x215eea]=()=>{gapi['load']?_0x15e36e():_0x37c18b(X(_0x56860d,'network-request-failed'));},xa(xf()+'?onload='+_0x215eea)['catch'](_0x388f0b=>_0x37c18b(_0x388f0b));}}})['catch'](_0x5db04e=>{throw un=null,_0x5db04e;});}let un=null;function Hp(_0x448e33){return un=un||Vp(_0x448e33),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x18d138){const _0xfc203e=_0x18d138['config'];m(_0xfc203e['authDomain'],_0x18d138,'auth-domain-config-required');const _0x1840d3=_0xfc203e['emulator']?Cs(_0xfc203e,qp):'https://'+_0x18d138['config']['authDomain']+'/'+Gp,_0x113518={'apiKey':_0xfc203e['apiKey'],'appName':_0x18d138['name'],'v':dt},_0xfe6f3e=jp['get'](_0x18d138['config']['apiHost']);_0xfe6f3e&&(_0x113518['eid']=_0xfe6f3e);const _0x43fa61=_0x18d138['_getFrameworks']();return _0x43fa61['length']&&(_0x113518['fw']=_0x43fa61['join'](',')),_0x1840d3+'?'+ut(_0x113518)['slice'](0x1);}async function Yp(_0x2e7a40){const _0x1a32ad=await Hp(_0x2e7a40),_0x360e9c=Z()['gapi'];return m(_0x360e9c,_0x2e7a40,'internal-error'),_0x1a32ad['open']({'where':document['body'],'url':Kp(_0x2e7a40),'messageHandlersFilter':_0x360e9c['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x452ebd=>new Promise(async(_0x6c782c,_0x54d706)=>{await _0x452ebd['restyle']({'setHideOnLeave':!0x1});const _0x2761f2=X(_0x2e7a40,'network-request-failed'),_0x322ec1=Z()['setTimeout'](()=>{_0x54d706(_0x2761f2);},$p['get']());function _0x1aca56(){Z()['clearTimeout'](_0x322ec1),_0x6c782c(_0x452ebd);}_0x452ebd['ping'](_0x1aca56)['then'](_0x1aca56,()=>{_0x54d706(_0x2761f2);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x20bf64){this['window']=_0x20bf64,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x278005,_0x599a6c,_0x3d310e,_0x21d2f0=Jp,_0x57b124=Xp){const _0x381ffd=Math['max']((window['screen']['availHeight']-_0x57b124)/0x2,0x0)['toString'](),_0x549054=Math['max']((window['screen']['availWidth']-_0x21d2f0)/0x2,0x0)['toString']();let _0x17cf73='';const _0x4830f8={...Qp,'width':_0x21d2f0['toString'](),'height':_0x57b124['toString'](),'top':_0x381ffd,'left':_0x549054},_0x4e6e14=W()['toLowerCase']();_0x3d310e&&(_0x17cf73=ka(_0x4e6e14)?Zp:_0x3d310e),Ra(_0x4e6e14)&&(_0x599a6c=_0x599a6c||e_,_0x4830f8['scrollbars']='yes');const _0x29f83d=Object['entries'](_0x4830f8)['reduce']((_0x851a6,[_0x3812fd,_0x459f57])=>''+_0x851a6+_0x3812fd+'='+_0x459f57+',','');if(Rf(_0x4e6e14)&&_0x17cf73!=='_self')return n_(_0x599a6c||'',_0x17cf73),new xr(null);const _0x4da982=window['open'](_0x599a6c||'',_0x17cf73,_0x29f83d);m(_0x4da982,_0x278005,'popup-blocked');try{_0x4da982['focus']();}catch{}return new xr(_0x4da982);}function n_(_0xc09b81,_0x5c2e84){const _0x290903=document['createElement']('a');_0x290903['href']=_0xc09b81,_0x290903['target']=_0x5c2e84;const _0x4091f5=document['createEvent']('MouseEvent');_0x4091f5['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x290903['dispatchEvent'](_0x4091f5);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x34a66d,_0x24849b,_0x34077e,_0x5b4a37,_0x28cf86,_0x2cc169){m(_0x34a66d['config']['authDomain'],_0x34a66d,'auth-domain-config-required'),m(_0x34a66d['config']['apiKey'],_0x34a66d,'invalid-api-key');const _0x3de27f={'apiKey':_0x34a66d['config']['apiKey'],'appName':_0x34a66d['name'],'authType':_0x34077e,'redirectUrl':_0x5b4a37,'v':dt,'eventId':_0x28cf86};if(_0x24849b instanceof Wa){_0x24849b['setDefaultLanguage'](_0x34a66d['languageCode']),_0x3de27f['providerId']=_0x24849b['providerId']||'',pn(_0x24849b['getCustomParameters']())||(_0x3de27f['customParameters']=JSON['stringify'](_0x24849b['getCustomParameters']()));for(const [_0x1ca596,_0x19da13]of Object['entries']({}))_0x3de27f[_0x1ca596]=_0x19da13;}if(_0x24849b instanceof tn){const _0x3d3e4f=_0x24849b['getScopes']()['filter'](_0x576e87=>_0x576e87!=='');_0x3d3e4f['length']>0x0&&(_0x3de27f['scopes']=_0x3d3e4f['join'](','));}_0x34a66d['tenantId']&&(_0x3de27f['tid']=_0x34a66d['tenantId']);const _0x155d28=_0x3de27f;for(const _0x14fede of Object['keys'](_0x155d28))_0x155d28[_0x14fede]===void 0x0&&delete _0x155d28[_0x14fede];const _0x4f33e4=await _0x34a66d['_getAppCheckToken'](),_0xd858b9=_0x4f33e4?'#'+r_+'='+encodeURIComponent(_0x4f33e4):'';return o_(_0x34a66d)+'?'+ut(_0x155d28)['slice'](0x1)+_0xd858b9;}function o_({config:_0x56fc17}){return _0x56fc17['emulator']?Cs(_0x56fc17,s_):'https://'+_0x56fc17['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x189856,_0x4dc262,_0x258ce8,_0x417671){var _0xf9472d;ce((_0xf9472d=this['eventManagers'][_0x189856['_key']()])==null?void 0x0:_0xf9472d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x10a476=await Fr(_0x189856,_0x4dc262,_0x258ce8,Mi(),_0x417671);return t_(_0x189856,_0x10a476,As());}async['_openRedirect'](_0x4a1df2,_0x2b520a,_0x5cad5b,_0x147999){await this['_originValidation'](_0x4a1df2);const _0x14df90=await Fr(_0x4a1df2,_0x2b520a,_0x5cad5b,Mi(),_0x147999);return hp(_0x14df90),new Promise(()=>{});}['_initialize'](_0x25ee03){const _0x4cb040=_0x25ee03['_key']();if(this['eventManagers'][_0x4cb040]){const {manager:_0x3e076e,promise:_0x48b4da}=this['eventManagers'][_0x4cb040];return _0x3e076e?Promise['resolve'](_0x3e076e):(ce(_0x48b4da,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x48b4da);}const _0x398a08=this['initAndGetManager'](_0x25ee03);return this['eventManagers'][_0x4cb040]={'promise':_0x398a08},_0x398a08['catch'](()=>{delete this['eventManagers'][_0x4cb040];}),_0x398a08;}async['initAndGetManager'](_0x4221f9){const _0x3c218d=await Yp(_0x4221f9),_0x4c8dce=new Dp(_0x4221f9);return _0x3c218d['register']('authEvent',_0x222996=>(m(_0x222996==null?void 0x0:_0x222996['authEvent'],_0x4221f9,'invalid-auth-event'),{'status':_0x4c8dce['onEvent'](_0x222996['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4221f9['_key']()]={'manager':_0x4c8dce},this['iframes'][_0x4221f9['_key']()]=_0x3c218d,_0x4c8dce;}['_isIframeWebStorageSupported'](_0x39f4d7,_0xfa1b0d){this['iframes'][_0x39f4d7['_key']()]['send'](pi,{'type':pi},_0x379908=>{var _0x450e8e;const _0x4391f7=(_0x450e8e=_0x379908==null?void 0x0:_0x379908[0x0])==null?void 0x0:_0x450e8e[pi];_0x4391f7!==void 0x0&&_0xfa1b0d(!!_0x4391f7),Y(_0x39f4d7,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4003ce){const _0x4ef2a5=_0x4003ce['_key']();return this['originValidationPromises'][_0x4ef2a5]||(this['originValidationPromises'][_0x4ef2a5]=Up(_0x4003ce)),this['originValidationPromises'][_0x4ef2a5];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3787f9){this['auth']=_0x3787f9,this['internalListeners']=new Map();}['getUid'](){var _0x5a0a1b;return this['assertAuthConfigured'](),((_0x5a0a1b=this['auth']['currentUser'])==null?void 0x0:_0x5a0a1b['uid'])||null;}async['getToken'](_0x593a9f){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x593a9f)}:null;}['addAuthTokenListener'](_0x3fac04){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3fac04))return;const _0x313a39=this['auth']['onIdTokenChanged'](_0x4dd6b3=>{_0x3fac04((_0x4dd6b3==null?void 0x0:_0x4dd6b3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3fac04,_0x313a39),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3a8fd8){this['assertAuthConfigured']();const _0xe12ec3=this['internalListeners']['get'](_0x3a8fd8);_0xe12ec3&&(this['internalListeners']['delete'](_0x3a8fd8),_0xe12ec3(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5c3c33){switch(_0x5c3c33){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0xa90a4f){st(new Fe('auth',(_0x78a459,{options:_0x5b32f1})=>{const _0x4da133=_0x78a459['getProvider']('app')['getImmediate'](),_0x2e803e=_0x78a459['getProvider']('heartbeat'),_0x54bb1b=_0x78a459['getProvider']('app-check-internal'),{apiKey:_0xd018aa,authDomain:_0x3affe4}=_0x4da133['options'];m(_0xd018aa&&!_0xd018aa['includes'](':'),'invalid-api-key',{'appName':_0x4da133['name']});const _0x406dc2={'apiKey':_0xd018aa,'authDomain':_0x3affe4,'clientPlatform':_0xa90a4f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xa90a4f)},_0x2388dc=new Df(_0x4da133,_0x2e803e,_0x54bb1b,_0x406dc2);return Hf(_0x2388dc,_0x5b32f1),_0x2388dc;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x242330,_0x907465,_0x1592fa)=>{_0x242330['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x52eea1=>{const _0x5dd1bf=Ke(_0x52eea1['getProvider']('auth')['getImmediate']());return(_0x115cc8=>new l_(_0x115cc8))(_0x5dd1bf);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0xa90a4f)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1bc70a=>async _0x3f2bc9=>{const _0x5c5891=_0x3f2bc9&&await _0x3f2bc9['getIdTokenResult'](),_0xe3f43d=_0x5c5891&&(new Date()['getTime']()-Date['parse'](_0x5c5891['issuedAtTime']))/0x3e8;if(_0xe3f43d&&_0xe3f43d>f_)return;const _0x28a0c5=_0x5c5891==null?void 0x0:_0x5c5891['token'];Br!==_0x28a0c5&&(Br=_0x28a0c5,await fetch(_0x1bc70a,{'method':_0x28a0c5?'POST':'DELETE','headers':_0x28a0c5?{'Authorization':'Bearer\x20'+_0x28a0c5}:{}}));};function B_(_0xeaede0=Zr()){const _0x4ef7f5=Hi(_0xeaede0,'auth');if(_0x4ef7f5['isInitialized']())return _0x4ef7f5['getImmediate']();const _0xd117fc=Vf(_0xeaede0,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x14463f=jr('authTokenSyncURL');if(_0x14463f&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5e7836=new URL(_0x14463f,location['origin']);if(location['origin']===_0x5e7836['origin']){const _0x1d3d7c=p_(_0x5e7836['toString']());sp(_0xd117fc,_0x1d3d7c,()=>_0x1d3d7c(_0xd117fc['currentUser'])),ip(_0xd117fc,_0x1634ae=>_0x1d3d7c(_0x1634ae));}}const _0x4cd87d=qr('auth');return _0x4cd87d&&$f(_0xd117fc,'http://'+_0x4cd87d),_0xd117fc;}function __(){var _0x690a9a;return((_0x690a9a=document['getElementsByTagName']('head'))==null?void 0x0:_0x690a9a[0x0])??document;}Mf({'loadJS'(_0x5602c7){return new Promise((_0x174c94,_0x7a0e97)=>{const _0xa306ab=document['createElement']('script');_0xa306ab['setAttribute']('src',_0x5602c7),_0xa306ab['onload']=_0x174c94,_0xa306ab['onerror']=_0x1cb3c3=>{const _0x5e7089=X('internal-error');_0x5e7089['customData']=_0x1cb3c3,_0x7a0e97(_0x5e7089);},_0xa306ab['type']='text/javascript',_0xa306ab['charset']='UTF-8',__()['appendChild'](_0xa306ab);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};