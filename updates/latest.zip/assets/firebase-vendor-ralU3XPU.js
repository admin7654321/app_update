const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x20f086,_0x9ab34c){if(!_0x20f086)throw ht(_0x9ab34c);},ht=function(_0x4d8188){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4d8188);},Hr=function(_0x85d2e1){const _0x4eea2a=[];let _0x233898=0x0;for(let _0x7f7da9=0x0;_0x7f7da9<_0x85d2e1['length'];_0x7f7da9++){let _0x5bd318=_0x85d2e1['charCodeAt'](_0x7f7da9);_0x5bd318<0x80?_0x4eea2a[_0x233898++]=_0x5bd318:_0x5bd318<0x800?(_0x4eea2a[_0x233898++]=_0x5bd318>>0x6|0xc0,_0x4eea2a[_0x233898++]=_0x5bd318&0x3f|0x80):(_0x5bd318&0xfc00)===0xd800&&_0x7f7da9+0x1<_0x85d2e1['length']&&(_0x85d2e1['charCodeAt'](_0x7f7da9+0x1)&0xfc00)===0xdc00?(_0x5bd318=0x10000+((_0x5bd318&0x3ff)<<0xa)+(_0x85d2e1['charCodeAt'](++_0x7f7da9)&0x3ff),_0x4eea2a[_0x233898++]=_0x5bd318>>0x12|0xf0,_0x4eea2a[_0x233898++]=_0x5bd318>>0xc&0x3f|0x80,_0x4eea2a[_0x233898++]=_0x5bd318>>0x6&0x3f|0x80,_0x4eea2a[_0x233898++]=_0x5bd318&0x3f|0x80):(_0x4eea2a[_0x233898++]=_0x5bd318>>0xc|0xe0,_0x4eea2a[_0x233898++]=_0x5bd318>>0x6&0x3f|0x80,_0x4eea2a[_0x233898++]=_0x5bd318&0x3f|0x80);}return _0x4eea2a;},nc=function(_0xfa364b){const _0x51ec7e=[];let _0x46224d=0x0,_0x542d3c=0x0;for(;_0x46224d<_0xfa364b['length'];){const _0x75a594=_0xfa364b[_0x46224d++];if(_0x75a594<0x80)_0x51ec7e[_0x542d3c++]=String['fromCharCode'](_0x75a594);else{if(_0x75a594>0xbf&&_0x75a594<0xe0){const _0x4fb3ca=_0xfa364b[_0x46224d++];_0x51ec7e[_0x542d3c++]=String['fromCharCode']((_0x75a594&0x1f)<<0x6|_0x4fb3ca&0x3f);}else{if(_0x75a594>0xef&&_0x75a594<0x16d){const _0x156c1f=_0xfa364b[_0x46224d++],_0xe602bf=_0xfa364b[_0x46224d++],_0xf3b1c7=_0xfa364b[_0x46224d++],_0x1ecac3=((_0x75a594&0x7)<<0x12|(_0x156c1f&0x3f)<<0xc|(_0xe602bf&0x3f)<<0x6|_0xf3b1c7&0x3f)-0x10000;_0x51ec7e[_0x542d3c++]=String['fromCharCode'](0xd800+(_0x1ecac3>>0xa)),_0x51ec7e[_0x542d3c++]=String['fromCharCode'](0xdc00+(_0x1ecac3&0x3ff));}else{const _0x359c1=_0xfa364b[_0x46224d++],_0x58d352=_0xfa364b[_0x46224d++];_0x51ec7e[_0x542d3c++]=String['fromCharCode']((_0x75a594&0xf)<<0xc|(_0x359c1&0x3f)<<0x6|_0x58d352&0x3f);}}}}return _0x51ec7e['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xd62c27,_0x1cd69d){if(!Array['isArray'](_0xd62c27))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x1ddef3=_0x1cd69d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x2dd295=[];for(let _0x2442e9=0x0;_0x2442e9<_0xd62c27['length'];_0x2442e9+=0x3){const _0x41f932=_0xd62c27[_0x2442e9],_0x440528=_0x2442e9+0x1<_0xd62c27['length'],_0x403a69=_0x440528?_0xd62c27[_0x2442e9+0x1]:0x0,_0xdcd09b=_0x2442e9+0x2<_0xd62c27['length'],_0x2e591c=_0xdcd09b?_0xd62c27[_0x2442e9+0x2]:0x0,_0x533cde=_0x41f932>>0x2,_0x5de5bb=(_0x41f932&0x3)<<0x4|_0x403a69>>0x4;let _0x37a593=(_0x403a69&0xf)<<0x2|_0x2e591c>>0x6,_0x5944d4=_0x2e591c&0x3f;_0xdcd09b||(_0x5944d4=0x40,_0x440528||(_0x37a593=0x40)),_0x2dd295['push'](_0x1ddef3[_0x533cde],_0x1ddef3[_0x5de5bb],_0x1ddef3[_0x37a593],_0x1ddef3[_0x5944d4]);}return _0x2dd295['join']('');},'encodeString'(_0x2c8351,_0x507551){return this['HAS_NATIVE_SUPPORT']&&!_0x507551?btoa(_0x2c8351):this['encodeByteArray'](Hr(_0x2c8351),_0x507551);},'decodeString'(_0x1594ba,_0x14ff16){return this['HAS_NATIVE_SUPPORT']&&!_0x14ff16?atob(_0x1594ba):nc(this['decodeStringToByteArray'](_0x1594ba,_0x14ff16));},'decodeStringToByteArray'(_0x3b6544,_0x151f30){this['init_']();const _0x27175d=_0x151f30?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x342d84=[];for(let _0x3483db=0x0;_0x3483db<_0x3b6544['length'];){const _0x2c9d51=_0x27175d[_0x3b6544['charAt'](_0x3483db++)],_0x3c98e5=_0x3483db<_0x3b6544['length']?_0x27175d[_0x3b6544['charAt'](_0x3483db)]:0x0;++_0x3483db;const _0x5ece2b=_0x3483db<_0x3b6544['length']?_0x27175d[_0x3b6544['charAt'](_0x3483db)]:0x40;++_0x3483db;const _0x32cb71=_0x3483db<_0x3b6544['length']?_0x27175d[_0x3b6544['charAt'](_0x3483db)]:0x40;if(++_0x3483db,_0x2c9d51==null||_0x3c98e5==null||_0x5ece2b==null||_0x32cb71==null)throw new ic();const _0x3cdfc0=_0x2c9d51<<0x2|_0x3c98e5>>0x4;if(_0x342d84['push'](_0x3cdfc0),_0x5ece2b!==0x40){const _0x4b1524=_0x3c98e5<<0x4&0xf0|_0x5ece2b>>0x2;if(_0x342d84['push'](_0x4b1524),_0x32cb71!==0x40){const _0x3bc769=_0x5ece2b<<0x6&0xc0|_0x32cb71;_0x342d84['push'](_0x3bc769);}}}return _0x342d84;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1984e1=0x0;_0x1984e1<this['ENCODED_VALS']['length'];_0x1984e1++)this['byteToCharMap_'][_0x1984e1]=this['ENCODED_VALS']['charAt'](_0x1984e1),this['charToByteMap_'][this['byteToCharMap_'][_0x1984e1]]=_0x1984e1,this['byteToCharMapWebSafe_'][_0x1984e1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1984e1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1984e1]]=_0x1984e1,_0x1984e1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1984e1)]=_0x1984e1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1984e1)]=_0x1984e1);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x43a567){const _0x39a189=Hr(_0x43a567);return Fi['encodeByteArray'](_0x39a189,!0x0);},dn=function(_0x31b669){return $r(_0x31b669)['replace'](/\./g,'');},fn=function(_0x3090d0){try{return Fi['decodeString'](_0x3090d0,!0x0);}catch(_0x47adcb){console['error']('base64Decode\x20failed:\x20',_0x47adcb);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3f9106){return Gr(void 0x0,_0x3f9106);}function Gr(_0x3ab023,_0x205572){if(!(_0x205572 instanceof Object))return _0x205572;switch(_0x205572['constructor']){case Date:const _0x361b79=_0x205572;return new Date(_0x361b79['getTime']());case Object:_0x3ab023===void 0x0&&(_0x3ab023={});break;case Array:_0x3ab023=[];break;default:return _0x205572;}for(const _0x3cceff in _0x205572)!_0x205572['hasOwnProperty'](_0x3cceff)||!rc(_0x3cceff)||(_0x3ab023[_0x3cceff]=Gr(_0x3ab023[_0x3cceff],_0x205572[_0x3cceff]));return _0x3ab023;}function rc(_0x3f758b){return _0x3f758b!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x100dc7=Ps['__FIREBASE_DEFAULTS__'];if(_0x100dc7)return JSON['parse'](_0x100dc7);},lc=()=>{if(typeof document>'u')return;let _0x5bf6dc;try{_0x5bf6dc=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x34826c=_0x5bf6dc&&fn(_0x5bf6dc[0x1]);return _0x34826c&&JSON['parse'](_0x34826c);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x459472){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x459472);return;}},qr=_0x5b7eff=>{var _0x3ba8d4,_0x43283e;return(_0x43283e=(_0x3ba8d4=Ui())==null?void 0x0:_0x3ba8d4['emulatorHosts'])==null?void 0x0:_0x43283e[_0x5b7eff];},hc=_0x35be0d=>{const _0x29e3b5=qr(_0x35be0d);if(!_0x29e3b5)return;const _0x237614=_0x29e3b5['lastIndexOf'](':');if(_0x237614<=0x0||_0x237614+0x1===_0x29e3b5['length'])throw new Error('Invalid\x20host\x20'+_0x29e3b5+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3fd420=parseInt(_0x29e3b5['substring'](_0x237614+0x1),0xa);return _0x29e3b5[0x0]==='['?[_0x29e3b5['substring'](0x1,_0x237614-0x1),_0x3fd420]:[_0x29e3b5['substring'](0x0,_0x237614),_0x3fd420];},zr=()=>{var _0x17514d;return(_0x17514d=Ui())==null?void 0x0:_0x17514d['config'];},jr=_0x1f54f8=>{var _0x5a07ef;return(_0x5a07ef=Ui())==null?void 0x0:_0x5a07ef['_'+_0x1f54f8];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x18a462,_0x45f7af)=>{this['resolve']=_0x18a462,this['reject']=_0x45f7af;});}['wrapCallback'](_0x1a3f30){return(_0x1cf059,_0x6a5968)=>{_0x1cf059?this['reject'](_0x1cf059):this['resolve'](_0x6a5968),typeof _0x1a3f30=='function'&&(this['promise']['catch'](()=>{}),_0x1a3f30['length']===0x1?_0x1a3f30(_0x1cf059):_0x1a3f30(_0x1cf059,_0x6a5968));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0xe48678,_0x4172b5){if(_0xe48678['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x897cf4={'alg':'none','type':'JWT'},_0x121d7b=_0x4172b5||'demo-project',_0x35478e=_0xe48678['iat']||0x0,_0x12f77b=_0xe48678['sub']||_0xe48678['user_id'];if(!_0x12f77b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x10ba75={'iss':'https://securetoken.google.com/'+_0x121d7b,'aud':_0x121d7b,'iat':_0x35478e,'exp':_0x35478e+0xe10,'auth_time':_0x35478e,'sub':_0x12f77b,'user_id':_0x12f77b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0xe48678};return[dn(JSON['stringify'](_0x897cf4)),dn(JSON['stringify'](_0x10ba75)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5d6d6d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5d6d6d=='object'&&_0x5d6d6d['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x689f33=W();return _0x689f33['indexOf']('MSIE\x20')>=0x0||_0x689f33['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x24d921,_0x47e553)=>{try{let _0x4fa34b=!0x0;const _0x2390f6='validate-browser-context-for-indexeddb-analytics-module',_0x45437d=self['indexedDB']['open'](_0x2390f6);_0x45437d['onsuccess']=()=>{_0x45437d['result']['close'](),_0x4fa34b||self['indexedDB']['deleteDatabase'](_0x2390f6),_0x24d921(!0x0);},_0x45437d['onupgradeneeded']=()=>{_0x4fa34b=!0x1;},_0x45437d['onerror']=()=>{var _0x5d9fae;_0x47e553(((_0x5d9fae=_0x45437d['error'])==null?void 0x0:_0x5d9fae['message'])||'');};}catch(_0x4f64b5){_0x47e553(_0x4f64b5);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x312ff5,_0x26a1f0,_0x5698d9){super(_0x26a1f0),this['code']=_0x312ff5,this['customData']=_0x5698d9,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x42d1c7,_0x5ddc13,_0x372202){this['service']=_0x42d1c7,this['serviceName']=_0x5ddc13,this['errors']=_0x372202;}['create'](_0x3cb4dd,..._0x2f4f60){const _0x4ca683=_0x2f4f60[0x0]||{},_0x22524f=this['service']+'/'+_0x3cb4dd,_0x8d4083=this['errors'][_0x3cb4dd],_0x30d1d5=_0x8d4083?vc(_0x8d4083,_0x4ca683):'Error',_0x24f708=this['serviceName']+':\x20'+_0x30d1d5+'\x20('+_0x22524f+').';return new Re(_0x22524f,_0x24f708,_0x4ca683);}}function vc(_0x158315,_0x141ad9){return _0x158315['replace'](Ec,(_0x4af23c,_0x5591b6)=>{const _0x1e313a=_0x141ad9[_0x5591b6];return _0x1e313a!=null?String(_0x1e313a):'<'+_0x5591b6+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x28aaf4){return JSON['parse'](_0x28aaf4);}function O(_0x245232){return JSON['stringify'](_0x245232);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1bb313){let _0x5ad54d={},_0x57d6f7={},_0x482878={},_0x40d37f='';try{const _0x3dcc30=_0x1bb313['split']('.');_0x5ad54d=Nt(fn(_0x3dcc30[0x0])||''),_0x57d6f7=Nt(fn(_0x3dcc30[0x1])||''),_0x40d37f=_0x3dcc30[0x2],_0x482878=_0x57d6f7['d']||{},delete _0x57d6f7['d'];}catch{}return{'header':_0x5ad54d,'claims':_0x57d6f7,'data':_0x482878,'signature':_0x40d37f};},Ic=function(_0x1ccb87){const _0x5738a1=Yr(_0x1ccb87),_0x1f852a=_0x5738a1['claims'];return!!_0x1f852a&&typeof _0x1f852a=='object'&&_0x1f852a['hasOwnProperty']('iat');},wc=function(_0x1ad247){const _0x11fb07=Yr(_0x1ad247)['claims'];return typeof _0x11fb07=='object'&&_0x11fb07['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xe8951e,_0x1eefe4){return Object['prototype']['hasOwnProperty']['call'](_0xe8951e,_0x1eefe4);}function Le(_0x165f91,_0xdc02b4){if(Object['prototype']['hasOwnProperty']['call'](_0x165f91,_0xdc02b4))return _0x165f91[_0xdc02b4];}function pn(_0x39884c){for(const _0x2e18ef in _0x39884c)if(Object['prototype']['hasOwnProperty']['call'](_0x39884c,_0x2e18ef))return!0x1;return!0x0;}function _n(_0x306b77,_0x5e63db,_0x209eb9){const _0x291c01={};for(const _0x23ccea in _0x306b77)Object['prototype']['hasOwnProperty']['call'](_0x306b77,_0x23ccea)&&(_0x291c01[_0x23ccea]=_0x5e63db['call'](_0x209eb9,_0x306b77[_0x23ccea],_0x23ccea,_0x306b77));return _0x291c01;}function xe(_0x2dcfd9,_0xf4a90a){if(_0x2dcfd9===_0xf4a90a)return!0x0;const _0x21cd5a=Object['keys'](_0x2dcfd9),_0x33e997=Object['keys'](_0xf4a90a);for(const _0x482869 of _0x21cd5a){if(!_0x33e997['includes'](_0x482869))return!0x1;const _0x10b7aa=_0x2dcfd9[_0x482869],_0x294f74=_0xf4a90a[_0x482869];if(Ns(_0x10b7aa)&&Ns(_0x294f74)){if(!xe(_0x10b7aa,_0x294f74))return!0x1;}else{if(_0x10b7aa!==_0x294f74)return!0x1;}}for(const _0x29fd6c of _0x33e997)if(!_0x21cd5a['includes'](_0x29fd6c))return!0x1;return!0x0;}function Ns(_0x5c40f4){return _0x5c40f4!==null&&typeof _0x5c40f4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4f1bb0){const _0xcb27dd=[];for(const [_0x44fe49,_0x3fdb1e]of Object['entries'](_0x4f1bb0))Array['isArray'](_0x3fdb1e)?_0x3fdb1e['forEach'](_0xfa8d46=>{_0xcb27dd['push'](encodeURIComponent(_0x44fe49)+'='+encodeURIComponent(_0xfa8d46));}):_0xcb27dd['push'](encodeURIComponent(_0x44fe49)+'='+encodeURIComponent(_0x3fdb1e));return _0xcb27dd['length']?'&'+_0xcb27dd['join']('&'):'';}function Ct(_0x324b14){const _0x102dc5={};return _0x324b14['replace'](/^\?/,'')['split']('&')['forEach'](_0x3a6ce5=>{if(_0x3a6ce5){const [_0x164a21,_0x59e0e8]=_0x3a6ce5['split']('=');_0x102dc5[decodeURIComponent(_0x164a21)]=decodeURIComponent(_0x59e0e8);}}),_0x102dc5;}function Tt(_0x1440f7){const _0x22f39d=_0x1440f7['indexOf']('?');if(!_0x22f39d)return'';const _0x3d0776=_0x1440f7['indexOf']('#',_0x22f39d);return _0x1440f7['substring'](_0x22f39d,_0x3d0776>0x0?_0x3d0776:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xd8ae8=0x1;_0xd8ae8<this['blockSize'];++_0xd8ae8)this['pad_'][_0xd8ae8]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x51022a,_0x2f5d29){_0x2f5d29||(_0x2f5d29=0x0);const _0x1954aa=this['W_'];if(typeof _0x51022a=='string'){for(let _0x3a46b0=0x0;_0x3a46b0<0x10;_0x3a46b0++)_0x1954aa[_0x3a46b0]=_0x51022a['charCodeAt'](_0x2f5d29)<<0x18|_0x51022a['charCodeAt'](_0x2f5d29+0x1)<<0x10|_0x51022a['charCodeAt'](_0x2f5d29+0x2)<<0x8|_0x51022a['charCodeAt'](_0x2f5d29+0x3),_0x2f5d29+=0x4;}else{for(let _0x2975a7=0x0;_0x2975a7<0x10;_0x2975a7++)_0x1954aa[_0x2975a7]=_0x51022a[_0x2f5d29]<<0x18|_0x51022a[_0x2f5d29+0x1]<<0x10|_0x51022a[_0x2f5d29+0x2]<<0x8|_0x51022a[_0x2f5d29+0x3],_0x2f5d29+=0x4;}for(let _0x811439=0x10;_0x811439<0x50;_0x811439++){const _0x1defb5=_0x1954aa[_0x811439-0x3]^_0x1954aa[_0x811439-0x8]^_0x1954aa[_0x811439-0xe]^_0x1954aa[_0x811439-0x10];_0x1954aa[_0x811439]=(_0x1defb5<<0x1|_0x1defb5>>>0x1f)&0xffffffff;}let _0x1a68d6=this['chain_'][0x0],_0x1abc42=this['chain_'][0x1],_0x554a71=this['chain_'][0x2],_0x361530=this['chain_'][0x3],_0x2ebd02=this['chain_'][0x4],_0x4d9a8d,_0x3903c3;for(let _0xb850dd=0x0;_0xb850dd<0x50;_0xb850dd++){_0xb850dd<0x28?_0xb850dd<0x14?(_0x4d9a8d=_0x361530^_0x1abc42&(_0x554a71^_0x361530),_0x3903c3=0x5a827999):(_0x4d9a8d=_0x1abc42^_0x554a71^_0x361530,_0x3903c3=0x6ed9eba1):_0xb850dd<0x3c?(_0x4d9a8d=_0x1abc42&_0x554a71|_0x361530&(_0x1abc42|_0x554a71),_0x3903c3=0x8f1bbcdc):(_0x4d9a8d=_0x1abc42^_0x554a71^_0x361530,_0x3903c3=0xca62c1d6);const _0x1e0893=(_0x1a68d6<<0x5|_0x1a68d6>>>0x1b)+_0x4d9a8d+_0x2ebd02+_0x3903c3+_0x1954aa[_0xb850dd]&0xffffffff;_0x2ebd02=_0x361530,_0x361530=_0x554a71,_0x554a71=(_0x1abc42<<0x1e|_0x1abc42>>>0x2)&0xffffffff,_0x1abc42=_0x1a68d6,_0x1a68d6=_0x1e0893;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1a68d6&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1abc42&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x554a71&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x361530&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2ebd02&0xffffffff;}['update'](_0x1485cc,_0x1f8586){if(_0x1485cc==null)return;_0x1f8586===void 0x0&&(_0x1f8586=_0x1485cc['length']);const _0x37db20=_0x1f8586-this['blockSize'];let _0x343b64=0x0;const _0x3a94a8=this['buf_'];let _0x582004=this['inbuf_'];for(;_0x343b64<_0x1f8586;){if(_0x582004===0x0){for(;_0x343b64<=_0x37db20;)this['compress_'](_0x1485cc,_0x343b64),_0x343b64+=this['blockSize'];}if(typeof _0x1485cc=='string'){for(;_0x343b64<_0x1f8586;)if(_0x3a94a8[_0x582004]=_0x1485cc['charCodeAt'](_0x343b64),++_0x582004,++_0x343b64,_0x582004===this['blockSize']){this['compress_'](_0x3a94a8),_0x582004=0x0;break;}}else{for(;_0x343b64<_0x1f8586;)if(_0x3a94a8[_0x582004]=_0x1485cc[_0x343b64],++_0x582004,++_0x343b64,_0x582004===this['blockSize']){this['compress_'](_0x3a94a8),_0x582004=0x0;break;}}}this['inbuf_']=_0x582004,this['total_']+=_0x1f8586;}['digest'](){const _0x45d6ab=[];let _0x1df9f8=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1afd77=this['blockSize']-0x1;_0x1afd77>=0x38;_0x1afd77--)this['buf_'][_0x1afd77]=_0x1df9f8&0xff,_0x1df9f8/=0x100;this['compress_'](this['buf_']);let _0x434b66=0x0;for(let _0x1d3b3b=0x0;_0x1d3b3b<0x5;_0x1d3b3b++)for(let _0x31383f=0x18;_0x31383f>=0x0;_0x31383f-=0x8)_0x45d6ab[_0x434b66]=this['chain_'][_0x1d3b3b]>>_0x31383f&0xff,++_0x434b66;return _0x45d6ab;}}function Tc(_0x35c4d4,_0x2eb9cf){const _0x49e0a0=new Sc(_0x35c4d4,_0x2eb9cf);return _0x49e0a0['subscribe']['bind'](_0x49e0a0);}class Sc{constructor(_0x510eee,_0x58a225){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x58a225,this['task']['then'](()=>{_0x510eee(this);})['catch'](_0x2449c5=>{this['error'](_0x2449c5);});}['next'](_0x4c5022){this['forEachObserver'](_0x22e483=>{_0x22e483['next'](_0x4c5022);});}['error'](_0x4b35de){this['forEachObserver'](_0x1396dd=>{_0x1396dd['error'](_0x4b35de);}),this['close'](_0x4b35de);}['complete'](){this['forEachObserver'](_0x1a4c37=>{_0x1a4c37['complete']();}),this['close']();}['subscribe'](_0x383249,_0x3717d7,_0x483b5d){let _0x35188f;if(_0x383249===void 0x0&&_0x3717d7===void 0x0&&_0x483b5d===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x383249,['next','error','complete'])?_0x35188f=_0x383249:_0x35188f={'next':_0x383249,'error':_0x3717d7,'complete':_0x483b5d},_0x35188f['next']===void 0x0&&(_0x35188f['next']=ti),_0x35188f['error']===void 0x0&&(_0x35188f['error']=ti),_0x35188f['complete']===void 0x0&&(_0x35188f['complete']=ti);const _0x23289d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x35188f['error'](this['finalError']):_0x35188f['complete']();}catch{}}),this['observers']['push'](_0x35188f),_0x23289d;}['unsubscribeOne'](_0x148994){this['observers']===void 0x0||this['observers'][_0x148994]===void 0x0||(delete this['observers'][_0x148994],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4b181f){if(!this['finalized']){for(let _0x4b32c1=0x0;_0x4b32c1<this['observers']['length'];_0x4b32c1++)this['sendOne'](_0x4b32c1,_0x4b181f);}}['sendOne'](_0x8e3be5,_0x4065d2){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x8e3be5]!==void 0x0)try{_0x4065d2(this['observers'][_0x8e3be5]);}catch(_0x423c4f){typeof console<'u'&&console['error']&&console['error'](_0x423c4f);}});}['close'](_0x1c004a){this['finalized']||(this['finalized']=!0x0,_0x1c004a!==void 0x0&&(this['finalError']=_0x1c004a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xb6ff18,_0x2c53a4){if(typeof _0xb6ff18!='object'||_0xb6ff18===null)return!0x1;for(const _0x343b9e of _0x2c53a4)if(_0x343b9e in _0xb6ff18&&typeof _0xb6ff18[_0x343b9e]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x4cdd9d,_0x4b5dd0){return _0x4cdd9d+'\x20failed:\x20'+_0x4b5dd0+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x46487b){const _0x3104ef=[];let _0xb4b12a=0x0;for(let _0x214b27=0x0;_0x214b27<_0x46487b['length'];_0x214b27++){let _0x247570=_0x46487b['charCodeAt'](_0x214b27);if(_0x247570>=0xd800&&_0x247570<=0xdbff){const _0x3b486a=_0x247570-0xd800;_0x214b27++,f(_0x214b27<_0x46487b['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3e31a2=_0x46487b['charCodeAt'](_0x214b27)-0xdc00;_0x247570=0x10000+(_0x3b486a<<0xa)+_0x3e31a2;}_0x247570<0x80?_0x3104ef[_0xb4b12a++]=_0x247570:_0x247570<0x800?(_0x3104ef[_0xb4b12a++]=_0x247570>>0x6|0xc0,_0x3104ef[_0xb4b12a++]=_0x247570&0x3f|0x80):_0x247570<0x10000?(_0x3104ef[_0xb4b12a++]=_0x247570>>0xc|0xe0,_0x3104ef[_0xb4b12a++]=_0x247570>>0x6&0x3f|0x80,_0x3104ef[_0xb4b12a++]=_0x247570&0x3f|0x80):(_0x3104ef[_0xb4b12a++]=_0x247570>>0x12|0xf0,_0x3104ef[_0xb4b12a++]=_0x247570>>0xc&0x3f|0x80,_0x3104ef[_0xb4b12a++]=_0x247570>>0x6&0x3f|0x80,_0x3104ef[_0xb4b12a++]=_0x247570&0x3f|0x80);}return _0x3104ef;},Ln=function(_0x5b9d40){let _0x1e492b=0x0;for(let _0x58cd22=0x0;_0x58cd22<_0x5b9d40['length'];_0x58cd22++){const _0x18264c=_0x5b9d40['charCodeAt'](_0x58cd22);_0x18264c<0x80?_0x1e492b++:_0x18264c<0x800?_0x1e492b+=0x2:_0x18264c>=0xd800&&_0x18264c<=0xdbff?(_0x1e492b+=0x4,_0x58cd22++):_0x1e492b+=0x3;}return _0x1e492b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x581cfa){return _0x581cfa&&_0x581cfa['_delegate']?_0x581cfa['_delegate']:_0x581cfa;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x145737){try{return(_0x145737['startsWith']('http://')||_0x145737['startsWith']('https://')?new URL(_0x145737)['hostname']:_0x145737)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x27c870){return(await fetch(_0x27c870,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x192125,_0x2bd25b,_0x7c4318){this['name']=_0x192125,this['instanceFactory']=_0x2bd25b,this['type']=_0x7c4318,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2c4137){return this['instantiationMode']=_0x2c4137,this;}['setMultipleInstances'](_0x33d3ef){return this['multipleInstances']=_0x33d3ef,this;}['setServiceProps'](_0x1bfbda){return this['serviceProps']=_0x1bfbda,this;}['setInstanceCreatedCallback'](_0x396633){return this['onInstanceCreated']=_0x396633,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xe5da06,_0x11f789){this['name']=_0xe5da06,this['container']=_0x11f789,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x36cbb1){const _0x43522d=this['normalizeInstanceIdentifier'](_0x36cbb1);if(!this['instancesDeferred']['has'](_0x43522d)){const _0x4a11b3=new H();if(this['instancesDeferred']['set'](_0x43522d,_0x4a11b3),this['isInitialized'](_0x43522d)||this['shouldAutoInitialize']())try{const _0x50b83a=this['getOrInitializeService']({'instanceIdentifier':_0x43522d});_0x50b83a&&_0x4a11b3['resolve'](_0x50b83a);}catch{}}return this['instancesDeferred']['get'](_0x43522d)['promise'];}['getImmediate'](_0x2897c7){const _0xd9f30f=this['normalizeInstanceIdentifier'](_0x2897c7==null?void 0x0:_0x2897c7['identifier']),_0x2eba70=(_0x2897c7==null?void 0x0:_0x2897c7['optional'])??!0x1;if(this['isInitialized'](_0xd9f30f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0xd9f30f});}catch(_0x3ceb5e){if(_0x2eba70)return null;throw _0x3ceb5e;}else{if(_0x2eba70)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x26f929){if(_0x26f929['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x26f929['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x26f929,!!this['shouldAutoInitialize']()){if(Pc(_0x26f929))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4a0ad6,_0x4330c8]of this['instancesDeferred']['entries']()){const _0x26862e=this['normalizeInstanceIdentifier'](_0x4a0ad6);try{const _0x25e9f6=this['getOrInitializeService']({'instanceIdentifier':_0x26862e});_0x4330c8['resolve'](_0x25e9f6);}catch{}}}}['clearInstance'](_0x315664=Ne){this['instancesDeferred']['delete'](_0x315664),this['instancesOptions']['delete'](_0x315664),this['instances']['delete'](_0x315664);}async['delete'](){const _0x3143d2=Array['from'](this['instances']['values']());await Promise['all']([..._0x3143d2['filter'](_0x39a4ee=>'INTERNAL'in _0x39a4ee)['map'](_0x1251d4=>_0x1251d4['INTERNAL']['delete']()),..._0x3143d2['filter'](_0x4f61dd=>'_delete'in _0x4f61dd)['map'](_0x56dad4=>_0x56dad4['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2bec48=Ne){return this['instances']['has'](_0x2bec48);}['getOptions'](_0x1a93a8=Ne){return this['instancesOptions']['get'](_0x1a93a8)||{};}['initialize'](_0x4a5a11={}){const {options:_0x42ec23={}}=_0x4a5a11,_0x3a0f10=this['normalizeInstanceIdentifier'](_0x4a5a11['instanceIdentifier']);if(this['isInitialized'](_0x3a0f10))throw Error(this['name']+'('+_0x3a0f10+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x40035e=this['getOrInitializeService']({'instanceIdentifier':_0x3a0f10,'options':_0x42ec23});for(const [_0x35284a,_0x2326a8]of this['instancesDeferred']['entries']()){const _0x476ed3=this['normalizeInstanceIdentifier'](_0x35284a);_0x3a0f10===_0x476ed3&&_0x2326a8['resolve'](_0x40035e);}return _0x40035e;}['onInit'](_0xac4b58,_0x1e99fc){const _0x5b10ce=this['normalizeInstanceIdentifier'](_0x1e99fc),_0x5cf538=this['onInitCallbacks']['get'](_0x5b10ce)??new Set();_0x5cf538['add'](_0xac4b58),this['onInitCallbacks']['set'](_0x5b10ce,_0x5cf538);const _0x57f584=this['instances']['get'](_0x5b10ce);return _0x57f584&&_0xac4b58(_0x57f584,_0x5b10ce),()=>{_0x5cf538['delete'](_0xac4b58);};}['invokeOnInitCallbacks'](_0x13da30,_0xd035d8){const _0x1347e4=this['onInitCallbacks']['get'](_0xd035d8);if(_0x1347e4){for(const _0x44504a of _0x1347e4)try{_0x44504a(_0x13da30,_0xd035d8);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x44428e,options:_0xeb7b99={}}){let _0x90ad59=this['instances']['get'](_0x44428e);if(!_0x90ad59&&this['component']&&(_0x90ad59=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x44428e),'options':_0xeb7b99}),this['instances']['set'](_0x44428e,_0x90ad59),this['instancesOptions']['set'](_0x44428e,_0xeb7b99),this['invokeOnInitCallbacks'](_0x90ad59,_0x44428e),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x44428e,_0x90ad59);}catch{}return _0x90ad59||null;}['normalizeInstanceIdentifier'](_0x5d242a=Ne){return this['component']?this['component']['multipleInstances']?_0x5d242a:Ne:_0x5d242a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x1fd252){return _0x1fd252===Ne?void 0x0:_0x1fd252;}function Pc(_0x4bfb4){return _0x4bfb4['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x488b6b){this['name']=_0x488b6b,this['providers']=new Map();}['addComponent'](_0x3e102b){const _0x29f14c=this['getProvider'](_0x3e102b['name']);if(_0x29f14c['isComponentSet']())throw new Error('Component\x20'+_0x3e102b['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x29f14c['setComponent'](_0x3e102b);}['addOrOverwriteComponent'](_0x1d3511){this['getProvider'](_0x1d3511['name'])['isComponentSet']()&&this['providers']['delete'](_0x1d3511['name']),this['addComponent'](_0x1d3511);}['getProvider'](_0x496c58){if(this['providers']['has'](_0x496c58))return this['providers']['get'](_0x496c58);const _0x4031b1=new Ac(_0x496c58,this);return this['providers']['set'](_0x496c58,_0x4031b1),_0x4031b1;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3f554c){_0x3f554c[_0x3f554c['DEBUG']=0x0]='DEBUG',_0x3f554c[_0x3f554c['VERBOSE']=0x1]='VERBOSE',_0x3f554c[_0x3f554c['INFO']=0x2]='INFO',_0x3f554c[_0x3f554c['WARN']=0x3]='WARN',_0x3f554c[_0x3f554c['ERROR']=0x4]='ERROR',_0x3f554c[_0x3f554c['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x33b99e,_0xb63b62,..._0x1626bd)=>{if(_0xb63b62<_0x33b99e['logLevel'])return;const _0x154bc5=new Date()['toISOString'](),_0x2c38ef=Mc[_0xb63b62];if(_0x2c38ef)console[_0x2c38ef]('['+_0x154bc5+']\x20\x20'+_0x33b99e['name']+':',..._0x1626bd);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xb63b62+')');};class Bi{constructor(_0x4d6413){this['name']=_0x4d6413,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4aa424){if(!(_0x4aa424 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4aa424+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4aa424;}['setLogLevel'](_0x261e1c){this['_logLevel']=typeof _0x261e1c=='string'?Oc[_0x261e1c]:_0x261e1c;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x15a096){if(typeof _0x15a096!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x15a096;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4c0b61){this['_userLogHandler']=_0x4c0b61;}['debug'](..._0xdd05c6){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xdd05c6),this['_logHandler'](this,T['DEBUG'],..._0xdd05c6);}['log'](..._0x40f6c5){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x40f6c5),this['_logHandler'](this,T['VERBOSE'],..._0x40f6c5);}['info'](..._0xe81cf0){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xe81cf0),this['_logHandler'](this,T['INFO'],..._0xe81cf0);}['warn'](..._0x9eebf0){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x9eebf0),this['_logHandler'](this,T['WARN'],..._0x9eebf0);}['error'](..._0x52eb47){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x52eb47),this['_logHandler'](this,T['ERROR'],..._0x52eb47);}}const xc=(_0x534156,_0x50b0c8)=>_0x50b0c8['some'](_0xfb03ef=>_0x534156 instanceof _0xfb03ef);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x316f77){const _0x1a8c0d=new Promise((_0x561913,_0x2cb2a4)=>{const _0x1aed5e=()=>{_0x316f77['removeEventListener']('success',_0x754d19),_0x316f77['removeEventListener']('error',_0xf9a1f1);},_0x754d19=()=>{_0x561913(ge(_0x316f77['result'])),_0x1aed5e();},_0xf9a1f1=()=>{_0x2cb2a4(_0x316f77['error']),_0x1aed5e();};_0x316f77['addEventListener']('success',_0x754d19),_0x316f77['addEventListener']('error',_0xf9a1f1);});return _0x1a8c0d['then'](_0x166bfc=>{_0x166bfc instanceof IDBCursor&&Jr['set'](_0x166bfc,_0x316f77);})['catch'](()=>{}),Vi['set'](_0x1a8c0d,_0x316f77),_0x1a8c0d;}function Bc(_0x4e0c4e){if(_i['has'](_0x4e0c4e))return;const _0x359121=new Promise((_0x3d3d4e,_0x1b83d4)=>{const _0x4540fb=()=>{_0x4e0c4e['removeEventListener']('complete',_0xfd0d0e),_0x4e0c4e['removeEventListener']('error',_0x4406c2),_0x4e0c4e['removeEventListener']('abort',_0x4406c2);},_0xfd0d0e=()=>{_0x3d3d4e(),_0x4540fb();},_0x4406c2=()=>{_0x1b83d4(_0x4e0c4e['error']||new DOMException('AbortError','AbortError')),_0x4540fb();};_0x4e0c4e['addEventListener']('complete',_0xfd0d0e),_0x4e0c4e['addEventListener']('error',_0x4406c2),_0x4e0c4e['addEventListener']('abort',_0x4406c2);});_i['set'](_0x4e0c4e,_0x359121);}let gi={'get'(_0x2ec84e,_0x1e0ce2,_0x5ddd12){if(_0x2ec84e instanceof IDBTransaction){if(_0x1e0ce2==='done')return _i['get'](_0x2ec84e);if(_0x1e0ce2==='objectStoreNames')return _0x2ec84e['objectStoreNames']||Xr['get'](_0x2ec84e);if(_0x1e0ce2==='store')return _0x5ddd12['objectStoreNames'][0x1]?void 0x0:_0x5ddd12['objectStore'](_0x5ddd12['objectStoreNames'][0x0]);}return ge(_0x2ec84e[_0x1e0ce2]);},'set'(_0x359f02,_0x53021d,_0x40d58b){return _0x359f02[_0x53021d]=_0x40d58b,!0x0;},'has'(_0x30aae4,_0x1843a6){return _0x30aae4 instanceof IDBTransaction&&(_0x1843a6==='done'||_0x1843a6==='store')?!0x0:_0x1843a6 in _0x30aae4;}};function Vc(_0x9667a7){gi=_0x9667a7(gi);}function Hc(_0x54ed7c){return _0x54ed7c===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x322b27,..._0x1e4180){const _0x452559=_0x54ed7c['call'](ii(this),_0x322b27,..._0x1e4180);return Xr['set'](_0x452559,_0x322b27['sort']?_0x322b27['sort']():[_0x322b27]),ge(_0x452559);}:Uc()['includes'](_0x54ed7c)?function(..._0x51f605){return _0x54ed7c['apply'](ii(this),_0x51f605),ge(Jr['get'](this));}:function(..._0x344e42){return ge(_0x54ed7c['apply'](ii(this),_0x344e42));};}function $c(_0x2ef80a){return typeof _0x2ef80a=='function'?Hc(_0x2ef80a):(_0x2ef80a instanceof IDBTransaction&&Bc(_0x2ef80a),xc(_0x2ef80a,Fc())?new Proxy(_0x2ef80a,gi):_0x2ef80a);}function ge(_0x4f54bc){if(_0x4f54bc instanceof IDBRequest)return Wc(_0x4f54bc);if(ni['has'](_0x4f54bc))return ni['get'](_0x4f54bc);const _0x25dcd7=$c(_0x4f54bc);return _0x25dcd7!==_0x4f54bc&&(ni['set'](_0x4f54bc,_0x25dcd7),Vi['set'](_0x25dcd7,_0x4f54bc)),_0x25dcd7;}const ii=_0x46c82a=>Vi['get'](_0x46c82a);function Gc(_0x570ce3,_0x139ee5,{blocked:_0x25fae9,upgrade:_0x14859a,blocking:_0x2590ad,terminated:_0x42db58}={}){const _0x2407da=indexedDB['open'](_0x570ce3,_0x139ee5),_0x38799c=ge(_0x2407da);return _0x14859a&&_0x2407da['addEventListener']('upgradeneeded',_0x595ea8=>{_0x14859a(ge(_0x2407da['result']),_0x595ea8['oldVersion'],_0x595ea8['newVersion'],ge(_0x2407da['transaction']),_0x595ea8);}),_0x25fae9&&_0x2407da['addEventListener']('blocked',_0x13e68e=>_0x25fae9(_0x13e68e['oldVersion'],_0x13e68e['newVersion'],_0x13e68e)),_0x38799c['then'](_0x3d3468=>{_0x42db58&&_0x3d3468['addEventListener']('close',()=>_0x42db58()),_0x2590ad&&_0x3d3468['addEventListener']('versionchange',_0x2954ef=>_0x2590ad(_0x2954ef['oldVersion'],_0x2954ef['newVersion'],_0x2954ef));})['catch'](()=>{}),_0x38799c;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x24c5cf,_0xc6315f){if(!(_0x24c5cf instanceof IDBDatabase&&!(_0xc6315f in _0x24c5cf)&&typeof _0xc6315f=='string'))return;if(si['get'](_0xc6315f))return si['get'](_0xc6315f);const _0x64c6bc=_0xc6315f['replace'](/FromIndex$/,''),_0x26326b=_0xc6315f!==_0x64c6bc,_0x305fd0=zc['includes'](_0x64c6bc);if(!(_0x64c6bc in(_0x26326b?IDBIndex:IDBObjectStore)['prototype'])||!(_0x305fd0||qc['includes'](_0x64c6bc)))return;const _0x4280cb=async function(_0x3614fb,..._0x541a23){const _0x56fd01=this['transaction'](_0x3614fb,_0x305fd0?'readwrite':'readonly');let _0x5e5c36=_0x56fd01['store'];return _0x26326b&&(_0x5e5c36=_0x5e5c36['index'](_0x541a23['shift']())),(await Promise['all']([_0x5e5c36[_0x64c6bc](..._0x541a23),_0x305fd0&&_0x56fd01['done']]))[0x0];};return si['set'](_0xc6315f,_0x4280cb),_0x4280cb;}Vc(_0x1032d5=>({..._0x1032d5,'get':(_0x30460c,_0x54986f,_0x1710ba)=>Ms(_0x30460c,_0x54986f)||_0x1032d5['get'](_0x30460c,_0x54986f,_0x1710ba),'has':(_0x187d23,_0x52abce)=>!!Ms(_0x187d23,_0x52abce)||_0x1032d5['has'](_0x187d23,_0x52abce)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x58692a){this['container']=_0x58692a;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2285cc=>{if(Kc(_0x2285cc)){const _0x16fa04=_0x2285cc['getImmediate']();return _0x16fa04['library']+'/'+_0x16fa04['version'];}else return null;})['filter'](_0x177c36=>_0x177c36)['join']('\x20');}}function Kc(_0xae2d95){const _0x48af0a=_0xae2d95['getComponent']();return(_0x48af0a==null?void 0x0:_0x48af0a['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x1e8314,_0x20a9ea){try{_0x1e8314['container']['addComponent'](_0x20a9ea);}catch(_0x330414){oe['debug']('Component\x20'+_0x20a9ea['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1e8314['name'],_0x330414);}}function st(_0x4b22ec){const _0x592515=_0x4b22ec['name'];if(Ei['has'](_0x592515))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x592515+'.'),!0x1;Ei['set'](_0x592515,_0x4b22ec);for(const _0x1cadcc of Ue['values']())xs(_0x1cadcc,_0x4b22ec);for(const _0x4772bb of vi['values']())xs(_0x4772bb,_0x4b22ec);return!0x0;}function Hi(_0x5e95ee,_0x149f28){const _0x17681e=_0x5e95ee['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x17681e&&_0x17681e['triggerHeartbeat'](),_0x5e95ee['container']['getProvider'](_0x149f28);}function $(_0x21a6e1){return _0x21a6e1==null?!0x1:_0x21a6e1['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1876e6,_0x164fcb,_0x2a892d){this['_isDeleted']=!0x1,this['_options']={..._0x1876e6},this['_config']={..._0x164fcb},this['_name']=_0x164fcb['name'],this['_automaticDataCollectionEnabled']=_0x164fcb['automaticDataCollectionEnabled'],this['_container']=_0x2a892d,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x15ea48){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x15ea48;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1e4908){this['_isDeleted']=_0x1e4908;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x124dd8,_0x59b642={}){let _0x2d4ba3=_0x124dd8;typeof _0x59b642!='object'&&(_0x59b642={'name':_0x59b642});const _0x41f9bc={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x59b642},_0x35d143=_0x41f9bc['name'];if(typeof _0x35d143!='string'||!_0x35d143)throw me['create']('bad-app-name',{'appName':String(_0x35d143)});if(_0x2d4ba3||(_0x2d4ba3=zr()),!_0x2d4ba3)throw me['create']('no-options');const _0x2b5b8d=Ue['get'](_0x35d143);if(_0x2b5b8d){if(xe(_0x2d4ba3,_0x2b5b8d['options'])&&xe(_0x41f9bc,_0x2b5b8d['config']))return _0x2b5b8d;throw me['create']('duplicate-app',{'appName':_0x35d143});}const _0x1b9874=new Nc(_0x35d143);for(const _0x2d7dea of Ei['values']())_0x1b9874['addComponent'](_0x2d7dea);const _0x311c04=new Tl(_0x2d4ba3,_0x41f9bc,_0x1b9874);return Ue['set'](_0x35d143,_0x311c04),_0x311c04;}function Zr(_0x3ed1c8=yi){const _0x35060d=Ue['get'](_0x3ed1c8);if(!_0x35060d&&_0x3ed1c8===yi&&zr())return Sl();if(!_0x35060d)throw me['create']('no-app',{'appName':_0x3ed1c8});return _0x35060d;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x50ff42){let _0x4d21ad=!0x1;const _0x19a1f7=_0x50ff42['name'];Ue['has'](_0x19a1f7)?(_0x4d21ad=!0x0,Ue['delete'](_0x19a1f7)):vi['has'](_0x19a1f7)&&_0x50ff42['decRefCount']()<=0x0&&(vi['delete'](_0x19a1f7),_0x4d21ad=!0x0),_0x4d21ad&&(await Promise['all'](_0x50ff42['container']['getProviders']()['map'](_0x3a7bec=>_0x3a7bec['delete']())),_0x50ff42['isDeleted']=!0x0);}function ye(_0x2fa2e8,_0x15b3a6,_0x43d6a4){let _0x2e42b9=wl[_0x2fa2e8]??_0x2fa2e8;_0x43d6a4&&(_0x2e42b9+='-'+_0x43d6a4);const _0x1515fe=_0x2e42b9['match'](/\s|\//),_0x340ec7=_0x15b3a6['match'](/\s|\//);if(_0x1515fe||_0x340ec7){const _0x54442f=['Unable\x20to\x20register\x20library\x20\x22'+_0x2e42b9+'\x22\x20with\x20version\x20\x22'+_0x15b3a6+'\x22:'];_0x1515fe&&_0x54442f['push']('library\x20name\x20\x22'+_0x2e42b9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1515fe&&_0x340ec7&&_0x54442f['push']('and'),_0x340ec7&&_0x54442f['push']('version\x20name\x20\x22'+_0x15b3a6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x54442f['join']('\x20'));return;}st(new Fe(_0x2e42b9+'-version',()=>({'library':_0x2e42b9,'version':_0x15b3a6}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x10614e,_0x5370d9)=>{switch(_0x5370d9){case 0x0:try{_0x10614e['createObjectStore'](Ot);}catch(_0x319e8d){console['warn'](_0x319e8d);}}}})['catch'](_0x4714fb=>{throw me['create']('idb-open',{'originalErrorMessage':_0x4714fb['message']});})),ri;}async function Al(_0x5b5676){try{const _0x222500=(await eo())['transaction'](Ot),_0x49bfe3=await _0x222500['objectStore'](Ot)['get'](to(_0x5b5676));return await _0x222500['done'],_0x49bfe3;}catch(_0x25decf){if(_0x25decf instanceof Re)oe['warn'](_0x25decf['message']);else{const _0x3d1702=me['create']('idb-get',{'originalErrorMessage':_0x25decf==null?void 0x0:_0x25decf['message']});oe['warn'](_0x3d1702['message']);}}}async function Fs(_0x378758,_0x2b0bfc){try{const _0x52f4d9=(await eo())['transaction'](Ot,'readwrite');await _0x52f4d9['objectStore'](Ot)['put'](_0x2b0bfc,to(_0x378758)),await _0x52f4d9['done'];}catch(_0x151206){if(_0x151206 instanceof Re)oe['warn'](_0x151206['message']);else{const _0x181ab4=me['create']('idb-set',{'originalErrorMessage':_0x151206==null?void 0x0:_0x151206['message']});oe['warn'](_0x181ab4['message']);}}}function to(_0x508cc3){return _0x508cc3['name']+'!'+_0x508cc3['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x3290c1){this['container']=_0x3290c1,this['_heartbeatsCache']=null;const _0x46caac=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x46caac),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x59f5f4=>(this['_heartbeatsCache']=_0x59f5f4,_0x59f5f4));}async['triggerHeartbeat'](){var _0x36655c,_0x242579;try{const _0xc9b1fb=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x9e83a5=Us();if(((_0x36655c=this['_heartbeatsCache'])==null?void 0x0:_0x36655c['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x242579=this['_heartbeatsCache'])==null?void 0x0:_0x242579['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x9e83a5||this['_heartbeatsCache']['heartbeats']['some'](_0x1bbcae=>_0x1bbcae['date']===_0x9e83a5))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x9e83a5,'agent':_0xc9b1fb}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x218940=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x218940,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x7fb069){oe['warn'](_0x7fb069);}}async['getHeartbeatsHeader'](){var _0x21e49f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x21e49f=this['_heartbeatsCache'])==null?void 0x0:_0x21e49f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x46fd99=Us(),{heartbeatsToSend:_0x3bbb0c,unsentEntries:_0x43b256}=Ol(this['_heartbeatsCache']['heartbeats']),_0x354ee0=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3bbb0c}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x46fd99,_0x43b256['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x43b256,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x354ee0;}catch(_0x5b1950){return oe['warn'](_0x5b1950),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1f198c,_0x42ffd9=kl){const _0xdd08d3=[];let _0x118ffc=_0x1f198c['slice']();for(const _0x3c4a09 of _0x1f198c){const _0x48eb7d=_0xdd08d3['find'](_0x2b2386=>_0x2b2386['agent']===_0x3c4a09['agent']);if(_0x48eb7d){if(_0x48eb7d['dates']['push'](_0x3c4a09['date']),Ws(_0xdd08d3)>_0x42ffd9){_0x48eb7d['dates']['pop']();break;}}else{if(_0xdd08d3['push']({'agent':_0x3c4a09['agent'],'dates':[_0x3c4a09['date']]}),Ws(_0xdd08d3)>_0x42ffd9){_0xdd08d3['pop']();break;}}_0x118ffc=_0x118ffc['slice'](0x1);}return{'heartbeatsToSend':_0xdd08d3,'unsentEntries':_0x118ffc};}class Dl{constructor(_0x1852d6){this['app']=_0x1852d6,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4120eb=await Al(this['app']);return _0x4120eb!=null&&_0x4120eb['heartbeats']?_0x4120eb:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x57fb26){if(await this['_canUseIndexedDBPromise']){const _0x5890e2=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x57fb26['lastSentHeartbeatDate']??_0x5890e2['lastSentHeartbeatDate'],'heartbeats':_0x57fb26['heartbeats']});}else return;}async['add'](_0x220281){if(await this['_canUseIndexedDBPromise']){const _0x186418=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x220281['lastSentHeartbeatDate']??_0x186418['lastSentHeartbeatDate'],'heartbeats':[..._0x186418['heartbeats'],..._0x220281['heartbeats']]});}else return;}}function Ws(_0x3fa387){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3fa387}))['length'];}function Ml(_0x420fe0){if(_0x420fe0['length']===0x0)return-0x1;let _0x5180f9=0x0,_0x258d79=_0x420fe0[0x0]['date'];for(let _0x3d1a67=0x1;_0x3d1a67<_0x420fe0['length'];_0x3d1a67++)_0x420fe0[_0x3d1a67]['date']<_0x258d79&&(_0x258d79=_0x420fe0[_0x3d1a67]['date'],_0x5180f9=_0x3d1a67);return _0x5180f9;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2dbbc7){st(new Fe('platform-logger',_0x3586ef=>new jc(_0x3586ef),'PRIVATE')),st(new Fe('heartbeat',_0x2e0237=>new Nl(_0x2e0237),'PRIVATE')),ye(mi,Ls,_0x2dbbc7),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x51d6d4){no=_0x51d6d4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x548f8b){this['domStorage_']=_0x548f8b,this['prefix_']='firebase:';}['set'](_0x5e23fd,_0x517be2){_0x517be2==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5e23fd)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5e23fd),O(_0x517be2));}['get'](_0x5ce0da){const _0x589d3a=this['domStorage_']['getItem'](this['prefixedName_'](_0x5ce0da));return _0x589d3a==null?null:Nt(_0x589d3a);}['remove'](_0x455ec5){this['domStorage_']['removeItem'](this['prefixedName_'](_0x455ec5));}['prefixedName_'](_0xe375cd){return this['prefix_']+_0xe375cd;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5d6ddd,_0x54622b){_0x54622b==null?delete this['cache_'][_0x5d6ddd]:this['cache_'][_0x5d6ddd]=_0x54622b;}['get'](_0x4c80b4){return Q(this['cache_'],_0x4c80b4)?this['cache_'][_0x4c80b4]:null;}['remove'](_0x1c4db4){delete this['cache_'][_0x1c4db4];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x205f60){try{if(typeof window<'u'&&typeof window[_0x205f60]<'u'){const _0x1ffbe0=window[_0x205f60];return _0x1ffbe0['setItem']('firebase:sentinel','cache'),_0x1ffbe0['removeItem']('firebase:sentinel'),new Wl(_0x1ffbe0);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x35979d=0x1;return function(){return _0x35979d++;};}()),ro=function(_0x268a0f){const _0x3408b3=Rc(_0x268a0f),_0x5c8da0=new Cc();_0x5c8da0['update'](_0x3408b3);const _0x35ba01=_0x5c8da0['digest']();return Fi['encodeByteArray'](_0x35ba01);},zt=function(..._0x2fc14e){let _0x5b00d5='';for(let _0x25ee18=0x0;_0x25ee18<_0x2fc14e['length'];_0x25ee18++){const _0x15c659=_0x2fc14e[_0x25ee18];Array['isArray'](_0x15c659)||_0x15c659&&typeof _0x15c659=='object'&&typeof _0x15c659['length']=='number'?_0x5b00d5+=zt['apply'](null,_0x15c659):typeof _0x15c659=='object'?_0x5b00d5+=O(_0x15c659):_0x5b00d5+=_0x15c659,_0x5b00d5+='\x20';}return _0x5b00d5;};let St=null,$s=!0x0;const Hl=function(_0xbeeabc,_0x620a8f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x5302ec){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x351c81=zt['apply'](null,_0x5302ec);St(_0x351c81);}},jt=function(_0x1a239f){return function(..._0x2cd923){L(_0x1a239f,..._0x2cd923);};},Ii=function(..._0x5a4a04){const _0x11731c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x5a4a04);Ze['error'](_0x11731c);},ae=function(..._0x5ea1d4){const _0x46d979='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x5ea1d4);throw Ze['error'](_0x46d979),new Error(_0x46d979);},U=function(..._0x2052a7){const _0x338715='FIREBASE\x20WARNING:\x20'+zt(..._0x2052a7);Ze['warn'](_0x338715);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x29f7b8){return typeof _0x29f7b8=='number'&&(_0x29f7b8!==_0x29f7b8||_0x29f7b8===Number['POSITIVE_INFINITY']||_0x29f7b8===Number['NEGATIVE_INFINITY']);},Gl=function(_0x39261b){if(document['readyState']==='complete')_0x39261b();else{let _0x2c15e9=!0x1;const _0x13176b=function(){if(!document['body']){setTimeout(_0x13176b,Math['floor'](0xa));return;}_0x2c15e9||(_0x2c15e9=!0x0,_0x39261b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x13176b,!0x1),window['addEventListener']('load',_0x13176b,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x13176b();}),window['attachEvent']('onload',_0x13176b));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x30da22,_0x4f439b){if(_0x30da22===_0x4f439b)return 0x0;if(_0x30da22===We||_0x4f439b===we)return-0x1;if(_0x4f439b===We||_0x30da22===we)return 0x1;{const _0x2c6524=Gs(_0x30da22),_0x32893f=Gs(_0x4f439b);return _0x2c6524!==null?_0x32893f!==null?_0x2c6524-_0x32893f===0x0?_0x30da22['length']-_0x4f439b['length']:_0x2c6524-_0x32893f:-0x1:_0x32893f!==null?0x1:_0x30da22<_0x4f439b?-0x1:0x1;}},ql=function(_0x4a75d2,_0x483059){return _0x4a75d2===_0x483059?0x0:_0x4a75d2<_0x483059?-0x1:0x1;},vt=function(_0x2bf100,_0x504174){if(_0x504174&&_0x2bf100 in _0x504174)return _0x504174[_0x2bf100];throw new Error('Missing\x20required\x20key\x20('+_0x2bf100+')\x20in\x20object:\x20'+O(_0x504174));},$i=function(_0x375ca3){if(typeof _0x375ca3!='object'||_0x375ca3===null)return O(_0x375ca3);const _0x556a9b=[];for(const _0x5a3e91 in _0x375ca3)_0x556a9b['push'](_0x5a3e91);_0x556a9b['sort']();let _0xc76f13='{';for(let _0x5069a5=0x0;_0x5069a5<_0x556a9b['length'];_0x5069a5++)_0x5069a5!==0x0&&(_0xc76f13+=','),_0xc76f13+=O(_0x556a9b[_0x5069a5]),_0xc76f13+=':',_0xc76f13+=$i(_0x375ca3[_0x556a9b[_0x5069a5]]);return _0xc76f13+='}',_0xc76f13;},oo=function(_0x4b7683,_0x2e35a3){const _0x406ce0=_0x4b7683['length'];if(_0x406ce0<=_0x2e35a3)return[_0x4b7683];const _0xe2778d=[];for(let _0x5d7837=0x0;_0x5d7837<_0x406ce0;_0x5d7837+=_0x2e35a3)_0x5d7837+_0x2e35a3>_0x406ce0?_0xe2778d['push'](_0x4b7683['substring'](_0x5d7837,_0x406ce0)):_0xe2778d['push'](_0x4b7683['substring'](_0x5d7837,_0x5d7837+_0x2e35a3));return _0xe2778d;};function x(_0x1bda9a,_0x183533){for(const _0x24b08b in _0x1bda9a)_0x1bda9a['hasOwnProperty'](_0x24b08b)&&_0x183533(_0x24b08b,_0x1bda9a[_0x24b08b]);}const ao=function(_0x37d1c7){f(!xn(_0x37d1c7),'Invalid\x20JSON\x20number');const _0x5337b8=0xb,_0x445c5b=0x34,_0x3e3cb3=(0x1<<_0x5337b8-0x1)-0x1;let _0x45cc95,_0x46cf96,_0x598295,_0x2e9ac7,_0x226b29;_0x37d1c7===0x0?(_0x46cf96=0x0,_0x598295=0x0,_0x45cc95=0x1/_0x37d1c7===-0x1/0x0?0x1:0x0):(_0x45cc95=_0x37d1c7<0x0,_0x37d1c7=Math['abs'](_0x37d1c7),_0x37d1c7>=Math['pow'](0x2,0x1-_0x3e3cb3)?(_0x2e9ac7=Math['min'](Math['floor'](Math['log'](_0x37d1c7)/Math['LN2']),_0x3e3cb3),_0x46cf96=_0x2e9ac7+_0x3e3cb3,_0x598295=Math['round'](_0x37d1c7*Math['pow'](0x2,_0x445c5b-_0x2e9ac7)-Math['pow'](0x2,_0x445c5b))):(_0x46cf96=0x0,_0x598295=Math['round'](_0x37d1c7/Math['pow'](0x2,0x1-_0x3e3cb3-_0x445c5b))));const _0x43b713=[];for(_0x226b29=_0x445c5b;_0x226b29;_0x226b29-=0x1)_0x43b713['push'](_0x598295%0x2?0x1:0x0),_0x598295=Math['floor'](_0x598295/0x2);for(_0x226b29=_0x5337b8;_0x226b29;_0x226b29-=0x1)_0x43b713['push'](_0x46cf96%0x2?0x1:0x0),_0x46cf96=Math['floor'](_0x46cf96/0x2);_0x43b713['push'](_0x45cc95?0x1:0x0),_0x43b713['reverse']();const _0x57c235=_0x43b713['join']('');let _0x6b1c87='';for(_0x226b29=0x0;_0x226b29<0x40;_0x226b29+=0x8){let _0x5ac88b=parseInt(_0x57c235['substr'](_0x226b29,0x8),0x2)['toString'](0x10);_0x5ac88b['length']===0x1&&(_0x5ac88b='0'+_0x5ac88b),_0x6b1c87=_0x6b1c87+_0x5ac88b;}return _0x6b1c87['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x310773,_0xd31dd9){let _0x53f0a3='Unknown\x20Error';_0x310773==='too_big'?_0x53f0a3='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x310773==='permission_denied'?_0x53f0a3='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x310773==='unavailable'&&(_0x53f0a3='The\x20service\x20is\x20unavailable');const _0x550171=new Error(_0x310773+'\x20at\x20'+_0xd31dd9['_path']['toString']()+':\x20'+_0x53f0a3);return _0x550171['code']=_0x310773['toUpperCase'](),_0x550171;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0xd06671){if(Yl['test'](_0xd06671)){const _0x4c45bb=Number(_0xd06671);if(_0x4c45bb>=Ql&&_0x4c45bb<=Jl)return _0x4c45bb;}return null;},ft=function(_0x2b53d7){try{_0x2b53d7();}catch(_0x2b30ea){setTimeout(()=>{const _0x5c31dc=_0x2b30ea['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5c31dc),_0x2b30ea;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x5d7332,_0x2010a8){const _0x46a75e=setTimeout(_0x5d7332,_0x2010a8);return typeof _0x46a75e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x46a75e):typeof _0x46a75e=='object'&&_0x46a75e['unref']&&_0x46a75e['unref'](),_0x46a75e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x58afc9,_0x5985d4){this['appCheckProvider']=_0x5985d4,this['appName']=_0x58afc9['name'],$(_0x58afc9)&&_0x58afc9['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x58afc9['settings']['appCheckToken']),this['appCheck']=_0x5985d4==null?void 0x0:_0x5985d4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5985d4==null||_0x5985d4['get']()['then'](_0x57d7d3=>this['appCheck']=_0x57d7d3);}['getToken'](_0x5ab0b5){if(this['serverAppAppCheckToken']){if(_0x5ab0b5)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5ab0b5):new Promise((_0x2411f1,_0x40d75f)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5ab0b5)['then'](_0x2411f1,_0x40d75f):_0x2411f1(null);},0x0);});}['addTokenChangeListener'](_0x4cab07){var _0x437f96;(_0x437f96=this['appCheckProvider'])==null||_0x437f96['get']()['then'](_0x39ce3b=>_0x39ce3b['addTokenListener'](_0x4cab07));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x354276,_0x3972c8,_0x5d8763){this['appName_']=_0x354276,this['firebaseOptions_']=_0x3972c8,this['authProvider_']=_0x5d8763,this['auth_']=null,this['auth_']=_0x5d8763['getImmediate']({'optional':!0x0}),this['auth_']||_0x5d8763['onInit'](_0x525270=>this['auth_']=_0x525270);}['getToken'](_0x3dd019){return this['auth_']?this['auth_']['getToken'](_0x3dd019)['catch'](_0x3e21eb=>_0x3e21eb&&_0x3e21eb['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x3e21eb)):new Promise((_0x1648ad,_0x29ba03)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3dd019)['then'](_0x1648ad,_0x29ba03):_0x1648ad(null);},0x0);});}['addTokenChangeListener'](_0x4325c3){this['auth_']?this['auth_']['addAuthTokenListener'](_0x4325c3):this['authProvider_']['get']()['then'](_0x13ac40=>_0x13ac40['addAuthTokenListener'](_0x4325c3));}['removeTokenChangeListener'](_0x65d184){this['authProvider_']['get']()['then'](_0x304af3=>_0x304af3['removeAuthTokenListener'](_0x65d184));}['notifyForInvalidToken'](){let _0x692c23='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x692c23+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x692c23+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x692c23+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x692c23);}}class an{constructor(_0x7c0aff){this['accessToken']=_0x7c0aff;}['getToken'](_0x31e207){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x1eb7dc){_0x1eb7dc(this['accessToken']);}['removeTokenChangeListener'](_0x3056b9){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1ec918,_0x30443,_0xf05363,_0x42246f,_0x50b116=!0x1,_0x4618d6='',_0x515a7d=!0x1,_0x38064f=!0x1,_0x2d62f1=null){this['secure']=_0x30443,this['namespace']=_0xf05363,this['webSocketOnly']=_0x42246f,this['nodeAdmin']=_0x50b116,this['persistenceKey']=_0x4618d6,this['includeNamespaceInQueryParams']=_0x515a7d,this['isUsingEmulator']=_0x38064f,this['emulatorOptions']=_0x2d62f1,this['_host']=_0x1ec918['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x1ec918)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x557d28){_0x557d28!==this['internalHost']&&(this['internalHost']=_0x557d28,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xf1d92=this['toURLString']();return this['persistenceKey']&&(_0xf1d92+='<'+this['persistenceKey']+'>'),_0xf1d92;}['toURLString'](){const _0x434fbb=this['secure']?'https://':'http://',_0x22d7b0=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x434fbb+this['host']+'/'+_0x22d7b0;}}function th(_0x408b63){return _0x408b63['host']!==_0x408b63['internalHost']||_0x408b63['isCustomHost']()||_0x408b63['includeNamespaceInQueryParams'];}function vo(_0x33d194,_0x2f254d,_0x1aa29f){f(typeof _0x2f254d=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1aa29f=='object','typeof\x20params\x20must\x20==\x20object');let _0x386b11;if(_0x2f254d===go)_0x386b11=(_0x33d194['secure']?'wss://':'ws://')+_0x33d194['internalHost']+'/.ws?';else{if(_0x2f254d===mo)_0x386b11=(_0x33d194['secure']?'https://':'http://')+_0x33d194['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2f254d);}th(_0x33d194)&&(_0x1aa29f['ns']=_0x33d194['namespace']);const _0x4a0c4f=[];return x(_0x1aa29f,(_0x50e501,_0x5ec743)=>{_0x4a0c4f['push'](_0x50e501+'='+_0x5ec743);}),_0x386b11+_0x4a0c4f['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x15b159,_0x2498aa=0x1){Q(this['counters_'],_0x15b159)||(this['counters_'][_0x15b159]=0x0),this['counters_'][_0x15b159]+=_0x2498aa;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x5ba7fe){const _0x40ead9=_0x5ba7fe['toString']();return oi[_0x40ead9]||(oi[_0x40ead9]=new nh()),oi[_0x40ead9];}function ih(_0x171325,_0x117100){const _0x2508cd=_0x171325['toString']();return ai[_0x2508cd]||(ai[_0x2508cd]=_0x117100()),ai[_0x2508cd];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x1389b6){this['onMessage_']=_0x1389b6,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1ab403,_0x599d01){this['closeAfterResponse']=_0x1ab403,this['onClose']=_0x599d01,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x168d03,_0x328031){for(this['pendingResponses'][_0x168d03]=_0x328031;this['pendingResponses'][this['currentResponseNum']];){const _0x1544f7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x10b843=0x0;_0x10b843<_0x1544f7['length'];++_0x10b843)_0x1544f7[_0x10b843]&&ft(()=>{this['onMessage_'](_0x1544f7[_0x10b843]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x31e58c,_0x2973e1,_0x4127f6,_0x2606dc,_0x29f983,_0x426189,_0x3cd1de){this['connId']=_0x31e58c,this['repoInfo']=_0x2973e1,this['applicationId']=_0x4127f6,this['appCheckToken']=_0x2606dc,this['authToken']=_0x29f983,this['transportSessionId']=_0x426189,this['lastSessionId']=_0x3cd1de,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x31e58c),this['stats_']=qi(_0x2973e1),this['urlFn']=_0x183003=>(this['appCheckToken']&&(_0x183003[wi]=this['appCheckToken']),vo(_0x2973e1,mo,_0x183003));}['open'](_0x50e46e,_0x1e57e2){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1e57e2,this['myPacketOrderer']=new sh(_0x50e46e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5d5aa3)=>{const [_0x34d4e9,_0x4db8e6,_0x494eed,_0x5a2dce,_0x88441]=_0x5d5aa3;if(this['incrementIncomingBytes_'](_0x5d5aa3),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x34d4e9===qs)this['id']=_0x4db8e6,this['password']=_0x494eed;else{if(_0x34d4e9===rh)_0x4db8e6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x4db8e6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x34d4e9);}}},(..._0x37ca72)=>{const [_0x2ca2e8,_0x4b655f]=_0x37ca72;this['incrementIncomingBytes_'](_0x37ca72),this['myPacketOrderer']['handleResponse'](_0x2ca2e8,_0x4b655f);},()=>{this['onClosed_']();},this['urlFn']);const _0x15fd50={};_0x15fd50[qs]='t',_0x15fd50[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x15fd50[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x15fd50[co]=Gi,this['transportSessionId']&&(_0x15fd50[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x15fd50[po]=this['lastSessionId']),this['applicationId']&&(_0x15fd50[_o]=this['applicationId']),this['appCheckToken']&&(_0x15fd50[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x15fd50[ho]=uo);const _0x49d4e5=this['urlFn'](_0x15fd50);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x49d4e5),this['scriptTagHolder']['addTag'](_0x49d4e5,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x90f2b8){const _0x336926=O(_0x90f2b8);this['bytesSent']+=_0x336926['length'],this['stats_']['incrementCounter']('bytes_sent',_0x336926['length']);const _0x4fe7ff=$r(_0x336926),_0x1ce8fa=oo(_0x4fe7ff,fh);for(let _0x5d5d26=0x0;_0x5d5d26<_0x1ce8fa['length'];_0x5d5d26++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1ce8fa['length'],_0x1ce8fa[_0x5d5d26]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x531bf1,_0x20911a){this['myDisconnFrame']=document['createElement']('iframe');const _0x1254e7={};_0x1254e7[dh]='t',_0x1254e7[Eo]=_0x531bf1,_0x1254e7[Io]=_0x20911a,this['myDisconnFrame']['src']=this['urlFn'](_0x1254e7),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1b5581){const _0x330ba8=O(_0x1b5581)['length'];this['bytesReceived']+=_0x330ba8,this['stats_']['incrementCounter']('bytes_received',_0x330ba8);}}class zi{constructor(_0x21f8a2,_0x56d289,_0x446331,_0x588bcf){this['onDisconnect']=_0x446331,this['urlFn']=_0x588bcf,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x21f8a2,window[ah+this['uniqueCallbackIdentifier']]=_0x56d289,this['myIFrame']=zi['createIFrame_']();let _0x3d0eb4='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3d0eb4='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x25d7f1='<html><body>'+_0x3d0eb4+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x25d7f1),this['myIFrame']['doc']['close']();}catch(_0x418e37){L('frame\x20writing\x20exception'),_0x418e37['stack']&&L(_0x418e37['stack']),L(_0x418e37);}}}static['createIFrame_'](){const _0x3bfe00=document['createElement']('iframe');if(_0x3bfe00['style']['display']='none',document['body']){document['body']['appendChild'](_0x3bfe00);try{_0x3bfe00['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1dc983=document['domain'];_0x3bfe00['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1dc983+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3bfe00['contentDocument']?_0x3bfe00['doc']=_0x3bfe00['contentDocument']:_0x3bfe00['contentWindow']?_0x3bfe00['doc']=_0x3bfe00['contentWindow']['document']:_0x3bfe00['document']&&(_0x3bfe00['doc']=_0x3bfe00['document']),_0x3bfe00;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x281917=this['onDisconnect'];_0x281917&&(this['onDisconnect']=null,_0x281917());}['startLongPoll'](_0x17fbff,_0x1e5406){for(this['myID']=_0x17fbff,this['myPW']=_0x1e5406,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1d7e93={};_0x1d7e93[Eo]=this['myID'],_0x1d7e93[Io]=this['myPW'],_0x1d7e93[wo]=this['currentSerial'];let _0x3835f0=this['urlFn'](_0x1d7e93),_0x2e8713='',_0x1d4897=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2e8713['length']<=Co;){const _0x33cd88=this['pendingSegs']['shift']();_0x2e8713=_0x2e8713+'&'+lh+_0x1d4897+'='+_0x33cd88['seg']+'&'+hh+_0x1d4897+'='+_0x33cd88['ts']+'&'+uh+_0x1d4897+'='+_0x33cd88['d'],_0x1d4897++;}return _0x3835f0=_0x3835f0+_0x2e8713,this['addLongPollTag_'](_0x3835f0,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2d9111,_0x36864d,_0x47231c){this['pendingSegs']['push']({'seg':_0x2d9111,'ts':_0x36864d,'d':_0x47231c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x33557d,_0x5a069b){this['outstandingRequests']['add'](_0x5a069b);const _0x17ca7a=()=>{this['outstandingRequests']['delete'](_0x5a069b),this['newRequest_']();},_0x2bbb9e=setTimeout(_0x17ca7a,Math['floor'](ph)),_0x1c2ac9=()=>{clearTimeout(_0x2bbb9e),_0x17ca7a();};this['addTag'](_0x33557d,_0x1c2ac9);}['addTag'](_0x59c05e,_0x4353fe){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x105a8f=this['myIFrame']['doc']['createElement']('script');_0x105a8f['type']='text/javascript',_0x105a8f['async']=!0x0,_0x105a8f['src']=_0x59c05e,_0x105a8f['onload']=_0x105a8f['onreadystatechange']=function(){const _0x240474=_0x105a8f['readyState'];(!_0x240474||_0x240474==='loaded'||_0x240474==='complete')&&(_0x105a8f['onload']=_0x105a8f['onreadystatechange']=null,_0x105a8f['parentNode']&&_0x105a8f['parentNode']['removeChild'](_0x105a8f),_0x4353fe());},_0x105a8f['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x59c05e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x105a8f);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x43a180,_0x1bad53,_0x2fc725,_0x1ed9d2,_0x3ddd3a,_0x526078,_0x1d5450){this['connId']=_0x43a180,this['applicationId']=_0x2fc725,this['appCheckToken']=_0x1ed9d2,this['authToken']=_0x3ddd3a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x1bad53),this['connURL']=q['connectionURL_'](_0x1bad53,_0x526078,_0x1d5450,_0x1ed9d2,_0x2fc725),this['nodeAdmin']=_0x1bad53['nodeAdmin'];}static['connectionURL_'](_0x5299a9,_0x3dcaaa,_0xc7f4ab,_0x3787b6,_0x2778cd){const _0x98fc0c={};return _0x98fc0c[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x98fc0c[ho]=uo),_0x3dcaaa&&(_0x98fc0c[lo]=_0x3dcaaa),_0xc7f4ab&&(_0x98fc0c[po]=_0xc7f4ab),_0x3787b6&&(_0x98fc0c[wi]=_0x3787b6),_0x2778cd&&(_0x98fc0c[_o]=_0x2778cd),vo(_0x5299a9,go,_0x98fc0c);}['open'](_0x9c352f,_0x147116){this['onDisconnect']=_0x147116,this['onMessage']=_0x9c352f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x46ce7e;_c(),this['mySock']=new gn(this['connURL'],[],_0x46ce7e);}catch(_0x29dceb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4a6a14=_0x29dceb['message']||_0x29dceb['data'];_0x4a6a14&&this['log_'](_0x4a6a14),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xaad9d4=>{this['handleIncomingFrame'](_0xaad9d4);},this['mySock']['onerror']=_0x4befba=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1d59af=_0x4befba['message']||_0x4befba['data'];_0x1d59af&&this['log_'](_0x1d59af),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x7933ec=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x9f9114=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x13a41e=navigator['userAgent']['match'](_0x9f9114);_0x13a41e&&_0x13a41e['length']>0x1&&parseFloat(_0x13a41e[0x1])<4.4&&(_0x7933ec=!0x0);}return!_0x7933ec&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2ee752){if(this['frames']['push'](_0x2ee752),this['frames']['length']===this['totalFrames']){const _0x3b4cb8=this['frames']['join']('');this['frames']=null;const _0x585559=Nt(_0x3b4cb8);this['onMessage'](_0x585559);}}['handleNewFrameCount_'](_0x4e0e2e){this['totalFrames']=_0x4e0e2e,this['frames']=[];}['extractFrameCount_'](_0x597d98){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x597d98['length']<=0x6){const _0x51a12e=Number(_0x597d98);if(!isNaN(_0x51a12e))return this['handleNewFrameCount_'](_0x51a12e),null;}return this['handleNewFrameCount_'](0x1),_0x597d98;}['handleIncomingFrame'](_0x11e03e){if(this['mySock']===null)return;const _0x491b37=_0x11e03e['data'];if(this['bytesReceived']+=_0x491b37['length'],this['stats_']['incrementCounter']('bytes_received',_0x491b37['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x491b37);else{const _0x2d0fe9=this['extractFrameCount_'](_0x491b37);_0x2d0fe9!==null&&this['appendFrame_'](_0x2d0fe9);}}['send'](_0x3fa418){this['resetKeepAlive']();const _0x6a5632=O(_0x3fa418);this['bytesSent']+=_0x6a5632['length'],this['stats_']['incrementCounter']('bytes_sent',_0x6a5632['length']);const _0xbcb7d7=oo(_0x6a5632,gh);_0xbcb7d7['length']>0x1&&this['sendString_'](String(_0xbcb7d7['length']));for(let _0x4c2b92=0x0;_0x4c2b92<_0xbcb7d7['length'];_0x4c2b92++)this['sendString_'](_0xbcb7d7[_0x4c2b92]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1b6680){try{this['mySock']['send'](_0x1b6680);}catch(_0x546cca){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x546cca['message']||_0x546cca['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x48af0d){this['initTransports_'](_0x48af0d);}['initTransports_'](_0x3761cc){const _0x983971=q&&q['isAvailable']();let _0x31bc3d=_0x983971&&!q['previouslyFailed']();if(_0x3761cc['webSocketOnly']&&(_0x983971||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x31bc3d=!0x0),_0x31bc3d)this['transports_']=[q];else{const _0x24324d=this['transports_']=[];for(const _0x37c3f5 of Dt['ALL_TRANSPORTS'])_0x37c3f5&&_0x37c3f5['isAvailable']()&&_0x24324d['push'](_0x37c3f5);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4db468,_0x5165b5,_0x2c344c,_0x46ddaf,_0x1e51d7,_0x1a7e0a,_0x483d10,_0x44c004,_0x518c0e,_0x14f5a4){this['id']=_0x4db468,this['repoInfo_']=_0x5165b5,this['applicationId_']=_0x2c344c,this['appCheckToken_']=_0x46ddaf,this['authToken_']=_0x1e51d7,this['onMessage_']=_0x1a7e0a,this['onReady_']=_0x483d10,this['onDisconnect_']=_0x44c004,this['onKill_']=_0x518c0e,this['lastSessionId']=_0x14f5a4,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x5165b5),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xd76259=this['transportManager_']['initialTransport']();this['conn_']=new _0xd76259(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xd76259['responsesRequiredToBeHealthy']||0x0;const _0x29be0f=this['connReceiver_'](this['conn_']),_0x35f418=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x29be0f,_0x35f418);},Math['floor'](0x0));const _0x409c03=_0xd76259['healthyTimeout']||0x0;_0x409c03>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x409c03)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2ff0d9){return _0x4a4f11=>{_0x2ff0d9===this['conn_']?this['onConnectionLost_'](_0x4a4f11):_0x2ff0d9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x56d085){return _0x20615f=>{this['state_']!==0x2&&(_0x56d085===this['rx_']?this['onPrimaryMessageReceived_'](_0x20615f):_0x56d085===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x20615f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5b3378){const _0x3bb4ff={'t':'d','d':_0x5b3378};this['sendData_'](_0x3bb4ff);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2eed3f){if(ci in _0x2eed3f){const _0x1026b6=_0x2eed3f[ci];_0x1026b6===Ys?this['upgradeIfSecondaryHealthy_']():_0x1026b6===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1026b6===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x483765){const _0x527854=vt('t',_0x483765),_0x5453db=vt('d',_0x483765);if(_0x527854==='c')this['onSecondaryControl_'](_0x5453db);else{if(_0x527854==='d')this['pendingDataMessages']['push'](_0x5453db);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x527854);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x31d3ff){const _0xc9a9dc=vt('t',_0x31d3ff),_0x5ce42f=vt('d',_0x31d3ff);_0xc9a9dc==='c'?this['onControl_'](_0x5ce42f):_0xc9a9dc==='d'&&this['onDataMessage_'](_0x5ce42f);}['onDataMessage_'](_0x53aacf){this['onPrimaryResponse_'](),this['onMessage_'](_0x53aacf);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x55d1e0){const _0x36d5e1=vt(ci,_0x55d1e0);if(zs in _0x55d1e0){const _0x21aa66=_0x55d1e0[zs];if(_0x36d5e1===Th){const _0x39c5d6={..._0x21aa66};this['repoInfo_']['isUsingEmulator']&&(_0x39c5d6['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x39c5d6);}else{if(_0x36d5e1===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x327b9b=0x0;_0x327b9b<this['pendingDataMessages']['length'];++_0x327b9b)this['onDataMessage_'](this['pendingDataMessages'][_0x327b9b]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x36d5e1===wh?this['onConnectionShutdown_'](_0x21aa66):_0x36d5e1===js?this['onReset_'](_0x21aa66):_0x36d5e1===Ch?Ii('Server\x20Error:\x20'+_0x21aa66):_0x36d5e1===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x36d5e1);}}}['onHandshake_'](_0x352744){const _0x24c81c=_0x352744['ts'],_0x1aa5ee=_0x352744['v'],_0x2f1ce2=_0x352744['h'];this['sessionId']=_0x352744['s'],this['repoInfo_']['host']=_0x2f1ce2,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x24c81c),Gi!==_0x1aa5ee&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x280d5b=this['transportManager_']['upgradeTransport']();_0x280d5b&&this['startUpgrade_'](_0x280d5b);}['startUpgrade_'](_0x28dc0d){this['secondaryConn_']=new _0x28dc0d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x28dc0d['responsesRequiredToBeHealthy']||0x0;const _0x4b625b=this['connReceiver_'](this['secondaryConn_']),_0x4e84ca=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4b625b,_0x4e84ca),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x437d57){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x437d57),this['repoInfo_']['host']=_0x437d57,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1be43b,_0xb6742b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1be43b,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xb6742b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3731f1=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3731f1||this['rx_']===_0x3731f1)&&this['close']();}['onConnectionLost_'](_0x2dd6bc){this['conn_']=null,!_0x2dd6bc&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2df83d){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2df83d),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1a886){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1a886);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3e67ac,_0x3a9f2c,_0x1d01b5,_0x2a7439){}['merge'](_0x4d841d,_0x334bb9,_0x579f4f,_0x1ba159){}['refreshAuthToken'](_0xf3263b){}['refreshAppCheckToken'](_0x61c67d){}['onDisconnectPut'](_0x10e92e,_0x2b8e34,_0x38218d){}['onDisconnectMerge'](_0x4bf74b,_0xc5cd10,_0x4887b2){}['onDisconnectCancel'](_0x474752,_0x40f439){}['reportStats'](_0x2e2305){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x12fe8c){this['allowedEvents_']=_0x12fe8c,this['listeners_']={},f(Array['isArray'](_0x12fe8c)&&_0x12fe8c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x964d26,..._0x282b1f){if(Array['isArray'](this['listeners_'][_0x964d26])){const _0x54c8fe=[...this['listeners_'][_0x964d26]];for(let _0x2dc211=0x0;_0x2dc211<_0x54c8fe['length'];_0x2dc211++)_0x54c8fe[_0x2dc211]['callback']['apply'](_0x54c8fe[_0x2dc211]['context'],_0x282b1f);}}['on'](_0x21c56b,_0x202e5d,_0x22098e){this['validateEventType_'](_0x21c56b),this['listeners_'][_0x21c56b]=this['listeners_'][_0x21c56b]||[],this['listeners_'][_0x21c56b]['push']({'callback':_0x202e5d,'context':_0x22098e});const _0x4ebc37=this['getInitialEvent'](_0x21c56b);_0x4ebc37&&_0x202e5d['apply'](_0x22098e,_0x4ebc37);}['off'](_0x5a1b33,_0x3e6ad5,_0x3d6641){this['validateEventType_'](_0x5a1b33);const _0x302123=this['listeners_'][_0x5a1b33]||[];for(let _0x31e91e=0x0;_0x31e91e<_0x302123['length'];_0x31e91e++)if(_0x302123[_0x31e91e]['callback']===_0x3e6ad5&&(!_0x3d6641||_0x3d6641===_0x302123[_0x31e91e]['context'])){_0x302123['splice'](_0x31e91e,0x1);return;}}['validateEventType_'](_0x4ac4a9){f(this['allowedEvents_']['find'](_0x2d01f9=>_0x2d01f9===_0x4ac4a9),'Unknown\x20event:\x20'+_0x4ac4a9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3f9093){return f(_0x3f9093==='online','Unknown\x20event\x20type:\x20'+_0x3f9093),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x35a552,_0xa6b65e){if(_0xa6b65e===void 0x0){this['pieces_']=_0x35a552['split']('/');let _0x3c3c5b=0x0;for(let _0x23d7e2=0x0;_0x23d7e2<this['pieces_']['length'];_0x23d7e2++)this['pieces_'][_0x23d7e2]['length']>0x0&&(this['pieces_'][_0x3c3c5b]=this['pieces_'][_0x23d7e2],_0x3c3c5b++);this['pieces_']['length']=_0x3c3c5b,this['pieceNum_']=0x0;}else this['pieces_']=_0x35a552,this['pieceNum_']=_0xa6b65e;}['toString'](){let _0x3e73f0='';for(let _0x267646=this['pieceNum_'];_0x267646<this['pieces_']['length'];_0x267646++)this['pieces_'][_0x267646]!==''&&(_0x3e73f0+='/'+this['pieces_'][_0x267646]);return _0x3e73f0||'/';}}function w(){return new C('');}function y(_0x38a875){return _0x38a875['pieceNum_']>=_0x38a875['pieces_']['length']?null:_0x38a875['pieces_'][_0x38a875['pieceNum_']];}function Ce(_0x3e2688){return _0x3e2688['pieces_']['length']-_0x3e2688['pieceNum_'];}function S(_0x5a2a34){let _0x49d755=_0x5a2a34['pieceNum_'];return _0x49d755<_0x5a2a34['pieces_']['length']&&_0x49d755++,new C(_0x5a2a34['pieces_'],_0x49d755);}function ji(_0x40f17b){return _0x40f17b['pieceNum_']<_0x40f17b['pieces_']['length']?_0x40f17b['pieces_'][_0x40f17b['pieces_']['length']-0x1]:null;}function bh(_0x64d83a){let _0x36ebe7='';for(let _0x125c04=_0x64d83a['pieceNum_'];_0x125c04<_0x64d83a['pieces_']['length'];_0x125c04++)_0x64d83a['pieces_'][_0x125c04]!==''&&(_0x36ebe7+='/'+encodeURIComponent(String(_0x64d83a['pieces_'][_0x125c04])));return _0x36ebe7||'/';}function Mt(_0x53b996,_0x46e777=0x0){return _0x53b996['pieces_']['slice'](_0x53b996['pieceNum_']+_0x46e777);}function Ro(_0x53a35a){if(_0x53a35a['pieceNum_']>=_0x53a35a['pieces_']['length'])return null;const _0x358ea7=[];for(let _0x29b103=_0x53a35a['pieceNum_'];_0x29b103<_0x53a35a['pieces_']['length']-0x1;_0x29b103++)_0x358ea7['push'](_0x53a35a['pieces_'][_0x29b103]);return new C(_0x358ea7,0x0);}function k(_0x13112c,_0x4f7c13){const _0x2c3915=[];for(let _0x4c4248=_0x13112c['pieceNum_'];_0x4c4248<_0x13112c['pieces_']['length'];_0x4c4248++)_0x2c3915['push'](_0x13112c['pieces_'][_0x4c4248]);if(_0x4f7c13 instanceof C){for(let _0x4d54f7=_0x4f7c13['pieceNum_'];_0x4d54f7<_0x4f7c13['pieces_']['length'];_0x4d54f7++)_0x2c3915['push'](_0x4f7c13['pieces_'][_0x4d54f7]);}else{const _0x586d60=_0x4f7c13['split']('/');for(let _0x1eba30=0x0;_0x1eba30<_0x586d60['length'];_0x1eba30++)_0x586d60[_0x1eba30]['length']>0x0&&_0x2c3915['push'](_0x586d60[_0x1eba30]);}return new C(_0x2c3915,0x0);}function v(_0x460aa1){return _0x460aa1['pieceNum_']>=_0x460aa1['pieces_']['length'];}function F(_0xbbb876,_0x292087){const _0xc7b3a9=y(_0xbbb876),_0x4f70e9=y(_0x292087);if(_0xc7b3a9===null)return _0x292087;if(_0xc7b3a9===_0x4f70e9)return F(S(_0xbbb876),S(_0x292087));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x292087+')\x20is\x20not\x20within\x20outerPath\x20('+_0xbbb876+')');}function Rh(_0x33ac2e,_0x5bb9f1){const _0xb36ec6=Mt(_0x33ac2e,0x0),_0x578215=Mt(_0x5bb9f1,0x0);for(let _0x546d57=0x0;_0x546d57<_0xb36ec6['length']&&_0x546d57<_0x578215['length'];_0x546d57++){const _0x1faf2d=qe(_0xb36ec6[_0x546d57],_0x578215[_0x546d57]);if(_0x1faf2d!==0x0)return _0x1faf2d;}return _0xb36ec6['length']===_0x578215['length']?0x0:_0xb36ec6['length']<_0x578215['length']?-0x1:0x1;}function Ki(_0x7a754f,_0x48d3ea){if(Ce(_0x7a754f)!==Ce(_0x48d3ea))return!0x1;for(let _0x29baf1=_0x7a754f['pieceNum_'],_0x1f50ef=_0x48d3ea['pieceNum_'];_0x29baf1<=_0x7a754f['pieces_']['length'];_0x29baf1++,_0x1f50ef++)if(_0x7a754f['pieces_'][_0x29baf1]!==_0x48d3ea['pieces_'][_0x1f50ef])return!0x1;return!0x0;}function G(_0x2c6fae,_0x4c6312){let _0x23a5e8=_0x2c6fae['pieceNum_'],_0x46676b=_0x4c6312['pieceNum_'];if(Ce(_0x2c6fae)>Ce(_0x4c6312))return!0x1;for(;_0x23a5e8<_0x2c6fae['pieces_']['length'];){if(_0x2c6fae['pieces_'][_0x23a5e8]!==_0x4c6312['pieces_'][_0x46676b])return!0x1;++_0x23a5e8,++_0x46676b;}return!0x0;}class Ah{constructor(_0x296518,_0x1f185c){this['errorPrefix_']=_0x1f185c,this['parts_']=Mt(_0x296518,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x37071e=0x0;_0x37071e<this['parts_']['length'];_0x37071e++)this['byteLength_']+=Ln(this['parts_'][_0x37071e]);Ao(this);}}function kh(_0x34e2ae,_0x48e894){_0x34e2ae['parts_']['length']>0x0&&(_0x34e2ae['byteLength_']+=0x1),_0x34e2ae['parts_']['push'](_0x48e894),_0x34e2ae['byteLength_']+=Ln(_0x48e894),Ao(_0x34e2ae);}function Ph(_0x55a0ea){const _0x242997=_0x55a0ea['parts_']['pop']();_0x55a0ea['byteLength_']-=Ln(_0x242997),_0x55a0ea['parts_']['length']>0x0&&(_0x55a0ea['byteLength_']-=0x1);}function Ao(_0x34b854){if(_0x34b854['byteLength_']>Zs)throw new Error(_0x34b854['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x34b854['byteLength_']+').');if(_0x34b854['parts_']['length']>Xs)throw new Error(_0x34b854['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x34b854));}function Oe(_0x5e1add){return _0x5e1add['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5e1add['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x31dc6b,_0x1f3a08;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1f3a08='visibilitychange',_0x31dc6b='hidden'):typeof document['mozHidden']<'u'?(_0x1f3a08='mozvisibilitychange',_0x31dc6b='mozHidden'):typeof document['msHidden']<'u'?(_0x1f3a08='msvisibilitychange',_0x31dc6b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1f3a08='webkitvisibilitychange',_0x31dc6b='webkitHidden')),this['visible_']=!0x0,_0x1f3a08&&document['addEventListener'](_0x1f3a08,()=>{const _0x9d90ed=!document[_0x31dc6b];_0x9d90ed!==this['visible_']&&(this['visible_']=_0x9d90ed,this['trigger']('visible',_0x9d90ed));},!0x1);}['getInitialEvent'](_0x5b6411){return f(_0x5b6411==='visible','Unknown\x20event\x20type:\x20'+_0x5b6411),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x545a66,_0xe2d051,_0x41fbc5,_0x417036,_0x596dd8,_0x5da61e,_0x161ad6,_0x3a10bf){if(super(),this['repoInfo_']=_0x545a66,this['applicationId_']=_0xe2d051,this['onDataUpdate_']=_0x41fbc5,this['onConnectStatus_']=_0x417036,this['onServerInfoUpdate_']=_0x596dd8,this['authTokenProvider_']=_0x5da61e,this['appCheckTokenProvider_']=_0x161ad6,this['authOverride_']=_0x3a10bf,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3a10bf)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x545a66['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x35ba04,_0x427ddf,_0x4b0ce9){const _0x1ee110=++this['requestNumber_'],_0x4ffa07={'r':_0x1ee110,'a':_0x35ba04,'b':_0x427ddf};this['log_'](O(_0x4ffa07)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4ffa07),_0x4b0ce9&&(this['requestCBHash_'][_0x1ee110]=_0x4b0ce9);}['get'](_0x4ab7de){this['initConnection_']();const _0x4bf25c=new H(),_0x57b8ba={'action':'g','request':{'p':_0x4ab7de['_path']['toString'](),'q':_0x4ab7de['_queryObject']},'onComplete':_0x9942b9=>{const _0x2f5cb9=_0x9942b9['d'];_0x9942b9['s']==='ok'?_0x4bf25c['resolve'](_0x2f5cb9):_0x4bf25c['reject'](_0x2f5cb9);}};this['outstandingGets_']['push'](_0x57b8ba),this['outstandingGetCount_']++;const _0x1fd873=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1fd873),_0x4bf25c['promise'];}['listen'](_0x41556e,_0xd1a65f,_0x57d548,_0x134f44){this['initConnection_']();const _0x13a45b=_0x41556e['_queryIdentifier'],_0x4595d0=_0x41556e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4595d0+'\x20'+_0x13a45b),this['listens']['has'](_0x4595d0)||this['listens']['set'](_0x4595d0,new Map()),f(_0x41556e['_queryParams']['isDefault']()||!_0x41556e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4595d0)['has'](_0x13a45b),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5b7996={'onComplete':_0x134f44,'hashFn':_0xd1a65f,'query':_0x41556e,'tag':_0x57d548};this['listens']['get'](_0x4595d0)['set'](_0x13a45b,_0x5b7996),this['connected_']&&this['sendListen_'](_0x5b7996);}['sendGet_'](_0x1929fb){const _0x3f4338=this['outstandingGets_'][_0x1929fb];this['sendRequest']('g',_0x3f4338['request'],_0x3d1336=>{delete this['outstandingGets_'][_0x1929fb],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x3f4338['onComplete']&&_0x3f4338['onComplete'](_0x3d1336);});}['sendListen_'](_0x6b683f){const _0x131794=_0x6b683f['query'],_0x15e16f=_0x131794['_path']['toString'](),_0x480b05=_0x131794['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x15e16f+'\x20for\x20'+_0x480b05);const _0x5d0d03={'p':_0x15e16f},_0x1b4a40='q';_0x6b683f['tag']&&(_0x5d0d03['q']=_0x131794['_queryObject'],_0x5d0d03['t']=_0x6b683f['tag']),_0x5d0d03['h']=_0x6b683f['hashFn'](),this['sendRequest'](_0x1b4a40,_0x5d0d03,_0x4dfd83=>{const _0xd77452=_0x4dfd83['d'],_0x4471a2=_0x4dfd83['s'];se['warnOnListenWarnings_'](_0xd77452,_0x131794),(this['listens']['get'](_0x15e16f)&&this['listens']['get'](_0x15e16f)['get'](_0x480b05))===_0x6b683f&&(this['log_']('listen\x20response',_0x4dfd83),_0x4471a2!=='ok'&&this['removeListen_'](_0x15e16f,_0x480b05),_0x6b683f['onComplete']&&_0x6b683f['onComplete'](_0x4471a2,_0xd77452));});}static['warnOnListenWarnings_'](_0x3c440f,_0x50f953){if(_0x3c440f&&typeof _0x3c440f=='object'&&Q(_0x3c440f,'w')){const _0x27903e=Le(_0x3c440f,'w');if(Array['isArray'](_0x27903e)&&~_0x27903e['indexOf']('no_index')){const _0x3c24a3='\x22.indexOn\x22:\x20\x22'+_0x50f953['_queryParams']['getIndex']()['toString']()+'\x22',_0xc43398=_0x50f953['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3c24a3+'\x20at\x20'+_0xc43398+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x48a326){this['authToken_']=_0x48a326,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x48a326);}['reduceReconnectDelayIfAdminCredential_'](_0x442206){(_0x442206&&_0x442206['length']===0x28||wc(_0x442206))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x4869c1){this['appCheckToken_']=_0x4869c1,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3fea1c=this['authToken_'],_0x37fce7=Ic(_0x3fea1c)?'auth':'gauth',_0x15d4aa={'cred':_0x3fea1c};this['authOverride_']===null?_0x15d4aa['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x15d4aa['authvar']=this['authOverride_']),this['sendRequest'](_0x37fce7,_0x15d4aa,_0x3e0c5f=>{const _0x2545a8=_0x3e0c5f['s'],_0x41d233=_0x3e0c5f['d']||'error';this['authToken_']===_0x3fea1c&&(_0x2545a8==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2545a8,_0x41d233));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x41f5c1=>{const _0x3214e0=_0x41f5c1['s'],_0x72281e=_0x41f5c1['d']||'error';_0x3214e0==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3214e0,_0x72281e);});}['unlisten'](_0x4d9a5c,_0x524695){const _0x2e52f3=_0x4d9a5c['_path']['toString'](),_0x40e274=_0x4d9a5c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2e52f3+'\x20'+_0x40e274),f(_0x4d9a5c['_queryParams']['isDefault']()||!_0x4d9a5c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2e52f3,_0x40e274)&&this['connected_']&&this['sendUnlisten_'](_0x2e52f3,_0x40e274,_0x4d9a5c['_queryObject'],_0x524695);}['sendUnlisten_'](_0x2cda5b,_0x4129c0,_0x2ae35a,_0x41d944){this['log_']('Unlisten\x20on\x20'+_0x2cda5b+'\x20for\x20'+_0x4129c0);const _0x5b07e4={'p':_0x2cda5b},_0x487f25='n';_0x41d944&&(_0x5b07e4['q']=_0x2ae35a,_0x5b07e4['t']=_0x41d944),this['sendRequest'](_0x487f25,_0x5b07e4);}['onDisconnectPut'](_0x45457b,_0x44e873,_0x5557b6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x45457b,_0x44e873,_0x5557b6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x45457b,'action':'o','data':_0x44e873,'onComplete':_0x5557b6});}['onDisconnectMerge'](_0x445722,_0x196d49,_0x13528a){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x445722,_0x196d49,_0x13528a):this['onDisconnectRequestQueue_']['push']({'pathString':_0x445722,'action':'om','data':_0x196d49,'onComplete':_0x13528a});}['onDisconnectCancel'](_0x193844,_0x183d34){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x193844,null,_0x183d34):this['onDisconnectRequestQueue_']['push']({'pathString':_0x193844,'action':'oc','data':null,'onComplete':_0x183d34});}['sendOnDisconnect_'](_0x18fecf,_0x1d4458,_0x21206c,_0x5a40ab){const _0xda1ead={'p':_0x1d4458,'d':_0x21206c};this['log_']('onDisconnect\x20'+_0x18fecf,_0xda1ead),this['sendRequest'](_0x18fecf,_0xda1ead,_0x18c9cb=>{_0x5a40ab&&setTimeout(()=>{_0x5a40ab(_0x18c9cb['s'],_0x18c9cb['d']);},Math['floor'](0x0));});}['put'](_0x185a62,_0x5d8289,_0x5a4d0d,_0x1aaae9){this['putInternal']('p',_0x185a62,_0x5d8289,_0x5a4d0d,_0x1aaae9);}['merge'](_0x1e8bde,_0x316cd5,_0x7e0525,_0x51ad83){this['putInternal']('m',_0x1e8bde,_0x316cd5,_0x7e0525,_0x51ad83);}['putInternal'](_0x9acea,_0x8f900c,_0x38137e,_0x4c8d13,_0x28d7a6){this['initConnection_']();const _0x49b380={'p':_0x8f900c,'d':_0x38137e};_0x28d7a6!==void 0x0&&(_0x49b380['h']=_0x28d7a6),this['outstandingPuts_']['push']({'action':_0x9acea,'request':_0x49b380,'onComplete':_0x4c8d13}),this['outstandingPutCount_']++;const _0x2e8bcf=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2e8bcf):this['log_']('Buffering\x20put:\x20'+_0x8f900c);}['sendPut_'](_0x8cfce5){const _0x3f60f4=this['outstandingPuts_'][_0x8cfce5]['action'],_0x2aea5f=this['outstandingPuts_'][_0x8cfce5]['request'],_0x1cefd0=this['outstandingPuts_'][_0x8cfce5]['onComplete'];this['outstandingPuts_'][_0x8cfce5]['queued']=this['connected_'],this['sendRequest'](_0x3f60f4,_0x2aea5f,_0x4ce07a=>{this['log_'](_0x3f60f4+'\x20response',_0x4ce07a),delete this['outstandingPuts_'][_0x8cfce5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1cefd0&&_0x1cefd0(_0x4ce07a['s'],_0x4ce07a['d']);});}['reportStats'](_0x408d6d){if(this['connected_']){const _0x1d8bc6={'c':_0x408d6d};this['log_']('reportStats',_0x1d8bc6),this['sendRequest']('s',_0x1d8bc6,_0x343f13=>{if(_0x343f13['s']!=='ok'){const _0x53a571=_0x343f13['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x53a571);}});}}['onDataMessage_'](_0x1acbd8){if('r'in _0x1acbd8){this['log_']('from\x20server:\x20'+O(_0x1acbd8));const _0x297e5a=_0x1acbd8['r'],_0x1e7e1d=this['requestCBHash_'][_0x297e5a];_0x1e7e1d&&(delete this['requestCBHash_'][_0x297e5a],_0x1e7e1d(_0x1acbd8['b']));}else{if('error'in _0x1acbd8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x1acbd8['error'];'a'in _0x1acbd8&&this['onDataPush_'](_0x1acbd8['a'],_0x1acbd8['b']);}}['onDataPush_'](_0x59d573,_0x577699){this['log_']('handleServerMessage',_0x59d573,_0x577699),_0x59d573==='d'?this['onDataUpdate_'](_0x577699['p'],_0x577699['d'],!0x1,_0x577699['t']):_0x59d573==='m'?this['onDataUpdate_'](_0x577699['p'],_0x577699['d'],!0x0,_0x577699['t']):_0x59d573==='c'?this['onListenRevoked_'](_0x577699['p'],_0x577699['q']):_0x59d573==='ac'?this['onAuthRevoked_'](_0x577699['s'],_0x577699['d']):_0x59d573==='apc'?this['onAppCheckRevoked_'](_0x577699['s'],_0x577699['d']):_0x59d573==='sd'?this['onSecurityDebugPacket_'](_0x577699):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x59d573)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x10ee5d,_0x21c62a){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x10ee5d),this['lastSessionId']=_0x21c62a,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2b81fe){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2b81fe));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x43f586){_0x43f586&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x43f586;}['onOnline_'](_0x44fc1f){_0x44fc1f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x297ea8=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x468811=Math['max'](0x0,this['reconnectDelay_']-_0x297ea8);_0x468811=Math['random']()*_0x468811,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x468811+'ms'),this['scheduleConnect_'](_0x468811),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x471888=this['onDataMessage_']['bind'](this),_0x16d27f=this['onReady_']['bind'](this),_0x3cdfb7=this['onRealtimeDisconnect_']['bind'](this),_0xc35dce=this['id']+':'+se['nextConnectionId_']++,_0x5973c0=this['lastSessionId'];let _0x55ed65=!0x1,_0x1566d=null;const _0x3f1b2b=function(){_0x1566d?_0x1566d['close']():(_0x55ed65=!0x0,_0x3cdfb7());},_0x272505=function(_0x247774){f(_0x1566d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1566d['sendRequest'](_0x247774);};this['realtime_']={'close':_0x3f1b2b,'sendRequest':_0x272505};const _0x4a7d44=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x50815f,_0x2df35f]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4a7d44),this['appCheckTokenProvider_']['getToken'](_0x4a7d44)]);_0x55ed65?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x50815f&&_0x50815f['accessToken'],this['appCheckToken_']=_0x2df35f&&_0x2df35f['token'],_0x1566d=new Sh(_0xc35dce,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x471888,_0x16d27f,_0x3cdfb7,_0x3652db=>{U(_0x3652db+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x5973c0));}catch(_0x459156){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x459156),_0x55ed65||(this['repoInfo_']['nodeAdmin']&&U(_0x459156),_0x3f1b2b());}}}['interrupt'](_0x22b42f){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x22b42f),this['interruptReasons_'][_0x22b42f]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x634ef9){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x634ef9),delete this['interruptReasons_'][_0x634ef9],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1eb163){const _0xc5a1ee=_0x1eb163-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0xc5a1ee});}['cancelSentTransactions_'](){for(let _0x4019f2=0x0;_0x4019f2<this['outstandingPuts_']['length'];_0x4019f2++){const _0x1a77b1=this['outstandingPuts_'][_0x4019f2];_0x1a77b1&&'h'in _0x1a77b1['request']&&_0x1a77b1['queued']&&(_0x1a77b1['onComplete']&&_0x1a77b1['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4019f2],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x55dfa4,_0x2858d3){let _0x4d82f7;_0x2858d3?_0x4d82f7=_0x2858d3['map'](_0x135445=>$i(_0x135445))['join']('$'):_0x4d82f7='default';const _0x7bbe37=this['removeListen_'](_0x55dfa4,_0x4d82f7);_0x7bbe37&&_0x7bbe37['onComplete']&&_0x7bbe37['onComplete']('permission_denied');}['removeListen_'](_0x4fbca9,_0x1078ff){const _0x38ed39=new C(_0x4fbca9)['toString']();let _0x5aa67d;if(this['listens']['has'](_0x38ed39)){const _0x28e879=this['listens']['get'](_0x38ed39);_0x5aa67d=_0x28e879['get'](_0x1078ff),_0x28e879['delete'](_0x1078ff),_0x28e879['size']===0x0&&this['listens']['delete'](_0x38ed39);}else _0x5aa67d=void 0x0;return _0x5aa67d;}['onAuthRevoked_'](_0x5088ca,_0x2afee1){L('Auth\x20token\x20revoked:\x20'+_0x5088ca+'/'+_0x2afee1),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5088ca==='invalid_token'||_0x5088ca==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x45d0fa,_0x128146){L('App\x20check\x20token\x20revoked:\x20'+_0x45d0fa+'/'+_0x128146),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x45d0fa==='invalid_token'||_0x45d0fa==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x7a81d9){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x7a81d9):'msg'in _0x7a81d9&&console['log']('FIREBASE:\x20'+_0x7a81d9['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4fa4ad of this['listens']['values']())for(const _0x137a5e of _0x4fa4ad['values']())this['sendListen_'](_0x137a5e);for(let _0xcba530=0x0;_0xcba530<this['outstandingPuts_']['length'];_0xcba530++)this['outstandingPuts_'][_0xcba530]&&this['sendPut_'](_0xcba530);for(;this['onDisconnectRequestQueue_']['length'];){const _0xbfd495=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xbfd495['action'],_0xbfd495['pathString'],_0xbfd495['data'],_0xbfd495['onComplete']);}for(let _0x1e5dd1=0x0;_0x1e5dd1<this['outstandingGets_']['length'];_0x1e5dd1++)this['outstandingGets_'][_0x1e5dd1]&&this['sendGet_'](_0x1e5dd1);}['sendConnectStats_'](){const _0x111998={};let _0x360cdc='js';_0x111998['sdk.'+_0x360cdc+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x111998['framework.cordova']=0x1:Kr()&&(_0x111998['framework.reactnative']=0x1),this['reportStats'](_0x111998);}['shouldReconnect_'](){const _0x222f79=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x222f79;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4c14a6,_0x1a9412){this['name']=_0x4c14a6,this['node']=_0x1a9412;}static['Wrap'](_0x46b490,_0x41b8d6){return new E(_0x46b490,_0x41b8d6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x40c241,_0x500e19){const _0x3d80e3=new E(We,_0x40c241),_0x39ea58=new E(We,_0x500e19);return this['compare'](_0x3d80e3,_0x39ea58)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x407c8b){sn=_0x407c8b;}['compare'](_0x2fac87,_0x503e1d){return qe(_0x2fac87['name'],_0x503e1d['name']);}['isDefinedOn'](_0x35f9d5){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x45fedf,_0x2e8052){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x431e6b,_0x10f4b4){return f(typeof _0x431e6b=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x431e6b,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x18f6d9,_0x363071,_0x559e40,_0xf77fde,_0x3c4277=null){this['isReverse_']=_0xf77fde,this['resultGenerator_']=_0x3c4277,this['nodeStack_']=[];let _0x499d65=0x1;for(;!_0x18f6d9['isEmpty']();)if(_0x18f6d9=_0x18f6d9,_0x499d65=_0x363071?_0x559e40(_0x18f6d9['key'],_0x363071):0x1,_0xf77fde&&(_0x499d65*=-0x1),_0x499d65<0x0)this['isReverse_']?_0x18f6d9=_0x18f6d9['left']:_0x18f6d9=_0x18f6d9['right'];else{if(_0x499d65===0x0){this['nodeStack_']['push'](_0x18f6d9);break;}else this['nodeStack_']['push'](_0x18f6d9),this['isReverse_']?_0x18f6d9=_0x18f6d9['right']:_0x18f6d9=_0x18f6d9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x46cd53=this['nodeStack_']['pop'](),_0x1dbe41;if(this['resultGenerator_']?_0x1dbe41=this['resultGenerator_'](_0x46cd53['key'],_0x46cd53['value']):_0x1dbe41={'key':_0x46cd53['key'],'value':_0x46cd53['value']},this['isReverse_']){for(_0x46cd53=_0x46cd53['left'];!_0x46cd53['isEmpty']();)this['nodeStack_']['push'](_0x46cd53),_0x46cd53=_0x46cd53['right'];}else{for(_0x46cd53=_0x46cd53['right'];!_0x46cd53['isEmpty']();)this['nodeStack_']['push'](_0x46cd53),_0x46cd53=_0x46cd53['left'];}return _0x1dbe41;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x37decf=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x37decf['key'],_0x37decf['value']):{'key':_0x37decf['key'],'value':_0x37decf['value']};}}class M{constructor(_0x13168,_0x34c72a,_0x224cdd,_0x47eb89,_0x355ae3){this['key']=_0x13168,this['value']=_0x34c72a,this['color']=_0x224cdd??M['RED'],this['left']=_0x47eb89??B['EMPTY_NODE'],this['right']=_0x355ae3??B['EMPTY_NODE'];}['copy'](_0x5934ab,_0xe8a655,_0x3dc727,_0x3740f2,_0x297633){return new M(_0x5934ab??this['key'],_0xe8a655??this['value'],_0x3dc727??this['color'],_0x3740f2??this['left'],_0x297633??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x30918a){return this['left']['inorderTraversal'](_0x30918a)||!!_0x30918a(this['key'],this['value'])||this['right']['inorderTraversal'](_0x30918a);}['reverseTraversal'](_0x15d950){return this['right']['reverseTraversal'](_0x15d950)||_0x15d950(this['key'],this['value'])||this['left']['reverseTraversal'](_0x15d950);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x494344,_0x453304,_0xe727f2){let _0x135a59=this;const _0xef2c27=_0xe727f2(_0x494344,_0x135a59['key']);return _0xef2c27<0x0?_0x135a59=_0x135a59['copy'](null,null,null,_0x135a59['left']['insert'](_0x494344,_0x453304,_0xe727f2),null):_0xef2c27===0x0?_0x135a59=_0x135a59['copy'](null,_0x453304,null,null,null):_0x135a59=_0x135a59['copy'](null,null,null,null,_0x135a59['right']['insert'](_0x494344,_0x453304,_0xe727f2)),_0x135a59['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x334b6d=this;return!_0x334b6d['left']['isRed_']()&&!_0x334b6d['left']['left']['isRed_']()&&(_0x334b6d=_0x334b6d['moveRedLeft_']()),_0x334b6d=_0x334b6d['copy'](null,null,null,_0x334b6d['left']['removeMin_'](),null),_0x334b6d['fixUp_']();}['remove'](_0x48c25c,_0x50784a){let _0x1b1dff,_0x3ee946;if(_0x1b1dff=this,_0x50784a(_0x48c25c,_0x1b1dff['key'])<0x0)!_0x1b1dff['left']['isEmpty']()&&!_0x1b1dff['left']['isRed_']()&&!_0x1b1dff['left']['left']['isRed_']()&&(_0x1b1dff=_0x1b1dff['moveRedLeft_']()),_0x1b1dff=_0x1b1dff['copy'](null,null,null,_0x1b1dff['left']['remove'](_0x48c25c,_0x50784a),null);else{if(_0x1b1dff['left']['isRed_']()&&(_0x1b1dff=_0x1b1dff['rotateRight_']()),!_0x1b1dff['right']['isEmpty']()&&!_0x1b1dff['right']['isRed_']()&&!_0x1b1dff['right']['left']['isRed_']()&&(_0x1b1dff=_0x1b1dff['moveRedRight_']()),_0x50784a(_0x48c25c,_0x1b1dff['key'])===0x0){if(_0x1b1dff['right']['isEmpty']())return B['EMPTY_NODE'];_0x3ee946=_0x1b1dff['right']['min_'](),_0x1b1dff=_0x1b1dff['copy'](_0x3ee946['key'],_0x3ee946['value'],null,null,_0x1b1dff['right']['removeMin_']());}_0x1b1dff=_0x1b1dff['copy'](null,null,null,null,_0x1b1dff['right']['remove'](_0x48c25c,_0x50784a));}return _0x1b1dff['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2fe366=this;return _0x2fe366['right']['isRed_']()&&!_0x2fe366['left']['isRed_']()&&(_0x2fe366=_0x2fe366['rotateLeft_']()),_0x2fe366['left']['isRed_']()&&_0x2fe366['left']['left']['isRed_']()&&(_0x2fe366=_0x2fe366['rotateRight_']()),_0x2fe366['left']['isRed_']()&&_0x2fe366['right']['isRed_']()&&(_0x2fe366=_0x2fe366['colorFlip_']()),_0x2fe366;}['moveRedLeft_'](){let _0x15dea5=this['colorFlip_']();return _0x15dea5['right']['left']['isRed_']()&&(_0x15dea5=_0x15dea5['copy'](null,null,null,null,_0x15dea5['right']['rotateRight_']()),_0x15dea5=_0x15dea5['rotateLeft_'](),_0x15dea5=_0x15dea5['colorFlip_']()),_0x15dea5;}['moveRedRight_'](){let _0x2ffa0a=this['colorFlip_']();return _0x2ffa0a['left']['left']['isRed_']()&&(_0x2ffa0a=_0x2ffa0a['rotateRight_'](),_0x2ffa0a=_0x2ffa0a['colorFlip_']()),_0x2ffa0a;}['rotateLeft_'](){const _0x3d9132=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3d9132,null);}['rotateRight_'](){const _0x20125f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x20125f);}['colorFlip_'](){const _0x22cfb2=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2aec91=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x22cfb2,_0x2aec91);}['checkMaxDepth_'](){const _0x366da6=this['check_']();return Math['pow'](0x2,_0x366da6)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4178a8=this['left']['check_']();if(_0x4178a8!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4178a8+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x31d993,_0x5c509d,_0x38a448,_0x1fbb69,_0x48bb8f){return this;}['insert'](_0x4ca63c,_0x24be6c,_0xeaabfb){return new M(_0x4ca63c,_0x24be6c,null);}['remove'](_0x23ef50,_0x480f0a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x39aaee){return!0x1;}['reverseTraversal'](_0x42cf17){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5a3df0,_0x3c95cd=B['EMPTY_NODE']){this['comparator_']=_0x5a3df0,this['root_']=_0x3c95cd;}['insert'](_0x3a0ee0,_0x5b8c2e){return new B(this['comparator_'],this['root_']['insert'](_0x3a0ee0,_0x5b8c2e,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x50cdc0){return new B(this['comparator_'],this['root_']['remove'](_0x50cdc0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x4c16e7){let _0x539baf,_0x335392=this['root_'];for(;!_0x335392['isEmpty']();){if(_0x539baf=this['comparator_'](_0x4c16e7,_0x335392['key']),_0x539baf===0x0)return _0x335392['value'];_0x539baf<0x0?_0x335392=_0x335392['left']:_0x539baf>0x0&&(_0x335392=_0x335392['right']);}return null;}['getPredecessorKey'](_0x1ac97a){let _0xf4c2f4,_0x5c0600=this['root_'],_0x5d6b93=null;for(;!_0x5c0600['isEmpty']();)if(_0xf4c2f4=this['comparator_'](_0x1ac97a,_0x5c0600['key']),_0xf4c2f4===0x0){if(_0x5c0600['left']['isEmpty']())return _0x5d6b93?_0x5d6b93['key']:null;for(_0x5c0600=_0x5c0600['left'];!_0x5c0600['right']['isEmpty']();)_0x5c0600=_0x5c0600['right'];return _0x5c0600['key'];}else _0xf4c2f4<0x0?_0x5c0600=_0x5c0600['left']:_0xf4c2f4>0x0&&(_0x5d6b93=_0x5c0600,_0x5c0600=_0x5c0600['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x16616b){return this['root_']['inorderTraversal'](_0x16616b);}['reverseTraversal'](_0x4836ac){return this['root_']['reverseTraversal'](_0x4836ac);}['getIterator'](_0x41f488){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x41f488);}['getIteratorFrom'](_0x32c0cc,_0x4a0658){return new rn(this['root_'],_0x32c0cc,this['comparator_'],!0x1,_0x4a0658);}['getReverseIteratorFrom'](_0x5829b7,_0x48ab32){return new rn(this['root_'],_0x5829b7,this['comparator_'],!0x0,_0x48ab32);}['getReverseIterator'](_0x5ef12a){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5ef12a);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x404368,_0x109f8c){return qe(_0x404368['name'],_0x109f8c['name']);}function Qi(_0x4bf6d9,_0xb9d0b){return qe(_0x4bf6d9,_0xb9d0b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x41741f){Ci=_0x41741f;}const Po=function(_0x2d54ab){return typeof _0x2d54ab=='number'?'number:'+ao(_0x2d54ab):'string:'+_0x2d54ab;},No=function(_0x212b4a){if(_0x212b4a['isLeafNode']()){const _0x1ebd78=_0x212b4a['val']();f(typeof _0x1ebd78=='string'||typeof _0x1ebd78=='number'||typeof _0x1ebd78=='object'&&Q(_0x1ebd78,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x212b4a===Ci||_0x212b4a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x212b4a===Ci||_0x212b4a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1a01be){nr=_0x1a01be;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x24b1fc,_0x2efc78=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x24b1fc,this['priorityNode_']=_0x2efc78,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x39cd75){return new D(this['value_'],_0x39cd75);}['getImmediateChild'](_0x325139){return _0x325139==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4a21b4){return v(_0x4a21b4)?this:y(_0x4a21b4)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x306b6b,_0x3666be){return null;}['updateImmediateChild'](_0x1c28e9,_0x15266d){return _0x1c28e9==='.priority'?this['updatePriority'](_0x15266d):_0x15266d['isEmpty']()&&_0x1c28e9!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1c28e9,_0x15266d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0xfcd6ef,_0x2a72f2){const _0x542b3d=y(_0xfcd6ef);return _0x542b3d===null?_0x2a72f2:_0x2a72f2['isEmpty']()&&_0x542b3d!=='.priority'?this:(f(_0x542b3d!=='.priority'||Ce(_0xfcd6ef)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x542b3d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0xfcd6ef),_0x2a72f2)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x287548,_0x573a59){return!0x1;}['val'](_0x4e5425){return _0x4e5425&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x53d4dd='';this['priorityNode_']['isEmpty']()||(_0x53d4dd+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x22e6a0=typeof this['value_'];_0x53d4dd+=_0x22e6a0+':',_0x22e6a0==='number'?_0x53d4dd+=ao(this['value_']):_0x53d4dd+=this['value_'],this['lazyHash_']=ro(_0x53d4dd);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x442d8e){return _0x442d8e===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x442d8e instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x442d8e['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x442d8e));}['compareToLeafNode_'](_0x179da8){const _0x31ddfc=typeof _0x179da8['value_'],_0x536d6a=typeof this['value_'],_0x45405a=D['VALUE_TYPE_ORDER']['indexOf'](_0x31ddfc),_0x43504e=D['VALUE_TYPE_ORDER']['indexOf'](_0x536d6a);return f(_0x45405a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x31ddfc),f(_0x43504e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x536d6a),_0x45405a===_0x43504e?_0x536d6a==='object'?0x0:this['value_']<_0x179da8['value_']?-0x1:this['value_']===_0x179da8['value_']?0x0:0x1:_0x43504e-_0x45405a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x42ad79){if(_0x42ad79===this)return!0x0;if(_0x42ad79['isLeafNode']()){const _0xcb2d28=_0x42ad79;return this['value_']===_0xcb2d28['value_']&&this['priorityNode_']['equals'](_0xcb2d28['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x30df75){Oo=_0x30df75;}function Wh(_0x4b46ac){Do=_0x4b46ac;}class Bh extends Fn{['compare'](_0x4bfb2d,_0x514da1){const _0x7acb4e=_0x4bfb2d['node']['getPriority'](),_0x208195=_0x514da1['node']['getPriority'](),_0x2e72c7=_0x7acb4e['compareTo'](_0x208195);return _0x2e72c7===0x0?qe(_0x4bfb2d['name'],_0x514da1['name']):_0x2e72c7;}['isDefinedOn'](_0x2d48e0){return!_0x2d48e0['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4b6ee5,_0x37c131){return!_0x4b6ee5['getPriority']()['equals'](_0x37c131['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x208b5f,_0x9ea98e){const _0x575878=Oo(_0x208b5f);return new E(_0x9ea98e,new D('[PRIORITY-POST]',_0x575878));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x2a3553){const _0x5d8663=_0x278037=>parseInt(Math['log'](_0x278037)/Vh,0xa),_0x47fa56=_0x286e94=>parseInt(Array(_0x286e94+0x1)['join']('1'),0x2);this['count']=_0x5d8663(_0x2a3553+0x1),this['current_']=this['count']-0x1;const _0xc325f1=_0x47fa56(this['count']);this['bits_']=_0x2a3553+0x1&_0xc325f1;}['nextBitIsOne'](){const _0x33b141=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x33b141;}}const yn=function(_0x424495,_0x433875,_0x461406,_0x5a4a9a){_0x424495['sort'](_0x433875);const _0x300711=function(_0x53e693,_0x17c149){const _0x4db30a=_0x17c149-_0x53e693;let _0x14ae3e,_0x45bf25;if(_0x4db30a===0x0)return null;if(_0x4db30a===0x1)return _0x14ae3e=_0x424495[_0x53e693],_0x45bf25=_0x461406?_0x461406(_0x14ae3e):_0x14ae3e,new M(_0x45bf25,_0x14ae3e['node'],M['BLACK'],null,null);{const _0x11b5ce=parseInt(_0x4db30a/0x2,0xa)+_0x53e693,_0x113653=_0x300711(_0x53e693,_0x11b5ce),_0x1e0d23=_0x300711(_0x11b5ce+0x1,_0x17c149);return _0x14ae3e=_0x424495[_0x11b5ce],_0x45bf25=_0x461406?_0x461406(_0x14ae3e):_0x14ae3e,new M(_0x45bf25,_0x14ae3e['node'],M['BLACK'],_0x113653,_0x1e0d23);}},_0x313b5e=function(_0x2410a8){let _0x55e2d9=null,_0x206a3c=null,_0xd57cbb=_0x424495['length'];const _0x455849=function(_0xec81c3,_0x3cbd86){const _0xb66113=_0xd57cbb-_0xec81c3,_0x57d7e9=_0xd57cbb;_0xd57cbb-=_0xec81c3;const _0x204044=_0x300711(_0xb66113+0x1,_0x57d7e9),_0x133cf5=_0x424495[_0xb66113],_0x2a77e0=_0x461406?_0x461406(_0x133cf5):_0x133cf5;_0x56ad6a(new M(_0x2a77e0,_0x133cf5['node'],_0x3cbd86,null,_0x204044));},_0x56ad6a=function(_0x806ebc){_0x55e2d9?(_0x55e2d9['left']=_0x806ebc,_0x55e2d9=_0x806ebc):(_0x206a3c=_0x806ebc,_0x55e2d9=_0x806ebc);};for(let _0x2b8c9a=0x0;_0x2b8c9a<_0x2410a8['count'];++_0x2b8c9a){const _0xa20181=_0x2410a8['nextBitIsOne'](),_0x52be37=Math['pow'](0x2,_0x2410a8['count']-(_0x2b8c9a+0x1));_0xa20181?_0x455849(_0x52be37,M['BLACK']):(_0x455849(_0x52be37,M['BLACK']),_0x455849(_0x52be37,M['RED']));}return _0x206a3c;},_0x10ea01=new Hh(_0x424495['length']),_0x45dbe3=_0x313b5e(_0x10ea01);return new B(_0x5a4a9a||_0x433875,_0x45dbe3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x486c7d,_0x18f445){this['indexes_']=_0x486c7d,this['indexSet_']=_0x18f445;}['get'](_0x296323){const _0x24c91a=Le(this['indexes_'],_0x296323);if(!_0x24c91a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x296323);return _0x24c91a instanceof B?_0x24c91a:null;}['hasIndex'](_0x5674b7){return Q(this['indexSet_'],_0x5674b7['toString']());}['addIndex'](_0x3ecc2b,_0x161bf8){f(_0x3ecc2b!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x21a5df=[];let _0x4ee2ec=!0x1;const _0x1dff23=_0x161bf8['getIterator'](E['Wrap']);let _0x3dc47e=_0x1dff23['getNext']();for(;_0x3dc47e;)_0x4ee2ec=_0x4ee2ec||_0x3ecc2b['isDefinedOn'](_0x3dc47e['node']),_0x21a5df['push'](_0x3dc47e),_0x3dc47e=_0x1dff23['getNext']();let _0x245348;_0x4ee2ec?_0x245348=yn(_0x21a5df,_0x3ecc2b['getCompare']()):_0x245348=Qe;const _0x430b01=_0x3ecc2b['toString'](),_0x300f97={...this['indexSet_']};_0x300f97[_0x430b01]=_0x3ecc2b;const _0x887955={...this['indexes_']};return _0x887955[_0x430b01]=_0x245348,new te(_0x887955,_0x300f97);}['addToIndexes'](_0x3040bc,_0x21b4e6){const _0xe524ca=_n(this['indexes_'],(_0xe4b8e5,_0x5e5649)=>{const _0x137d10=Le(this['indexSet_'],_0x5e5649);if(f(_0x137d10,'Missing\x20index\x20implementation\x20for\x20'+_0x5e5649),_0xe4b8e5===Qe){if(_0x137d10['isDefinedOn'](_0x3040bc['node'])){const _0x306373=[],_0x4204bb=_0x21b4e6['getIterator'](E['Wrap']);let _0x59acdc=_0x4204bb['getNext']();for(;_0x59acdc;)_0x59acdc['name']!==_0x3040bc['name']&&_0x306373['push'](_0x59acdc),_0x59acdc=_0x4204bb['getNext']();return _0x306373['push'](_0x3040bc),yn(_0x306373,_0x137d10['getCompare']());}else return Qe;}else{const _0x2f474c=_0x21b4e6['get'](_0x3040bc['name']);let _0xb1422b=_0xe4b8e5;return _0x2f474c&&(_0xb1422b=_0xb1422b['remove'](new E(_0x3040bc['name'],_0x2f474c))),_0xb1422b['insert'](_0x3040bc,_0x3040bc['node']);}});return new te(_0xe524ca,this['indexSet_']);}['removeFromIndexes'](_0x1aa8f7,_0x27f462){const _0x395b87=_n(this['indexes_'],_0x4eaa14=>{if(_0x4eaa14===Qe)return _0x4eaa14;{const _0x48d004=_0x27f462['get'](_0x1aa8f7['name']);return _0x48d004?_0x4eaa14['remove'](new E(_0x1aa8f7['name'],_0x48d004)):_0x4eaa14;}});return new te(_0x395b87,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x30850b,_0x51b3b1,_0x587608){this['children_']=_0x30850b,this['priorityNode_']=_0x51b3b1,this['indexMap_']=_0x587608,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0xa34c6a){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xa34c6a,this['indexMap_']);}['getImmediateChild'](_0x45f147){if(_0x45f147==='.priority')return this['getPriority']();{const _0x4d2431=this['children_']['get'](_0x45f147);return _0x4d2431===null?It:_0x4d2431;}}['getChild'](_0x7611ef){const _0x566cf3=y(_0x7611ef);return _0x566cf3===null?this:this['getImmediateChild'](_0x566cf3)['getChild'](S(_0x7611ef));}['hasChild'](_0x90a121){return this['children_']['get'](_0x90a121)!==null;}['updateImmediateChild'](_0x59de3d,_0x5f3720){if(f(_0x5f3720,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x59de3d==='.priority')return this['updatePriority'](_0x5f3720);{const _0x480a26=new E(_0x59de3d,_0x5f3720);let _0x152654,_0x523870;_0x5f3720['isEmpty']()?(_0x152654=this['children_']['remove'](_0x59de3d),_0x523870=this['indexMap_']['removeFromIndexes'](_0x480a26,this['children_'])):(_0x152654=this['children_']['insert'](_0x59de3d,_0x5f3720),_0x523870=this['indexMap_']['addToIndexes'](_0x480a26,this['children_']));const _0x279e6e=_0x152654['isEmpty']()?It:this['priorityNode_'];return new g(_0x152654,_0x279e6e,_0x523870);}}['updateChild'](_0x535aef,_0x4c4436){const _0x54ada8=y(_0x535aef);if(_0x54ada8===null)return _0x4c4436;{f(y(_0x535aef)!=='.priority'||Ce(_0x535aef)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1c3b4f=this['getImmediateChild'](_0x54ada8)['updateChild'](S(_0x535aef),_0x4c4436);return this['updateImmediateChild'](_0x54ada8,_0x1c3b4f);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x35b7eb){if(this['isEmpty']())return null;const _0x189544={};let _0x59e44c=0x0,_0x481495=0x0,_0x171937=!0x0;if(this['forEachChild'](R,(_0x46b7d7,_0x1847e6)=>{_0x189544[_0x46b7d7]=_0x1847e6['val'](_0x35b7eb),_0x59e44c++,_0x171937&&g['INTEGER_REGEXP_']['test'](_0x46b7d7)?_0x481495=Math['max'](_0x481495,Number(_0x46b7d7)):_0x171937=!0x1;}),!_0x35b7eb&&_0x171937&&_0x481495<0x2*_0x59e44c){const _0x4a1fa0=[];for(const _0x2cfefb in _0x189544)_0x4a1fa0[_0x2cfefb]=_0x189544[_0x2cfefb];return _0x4a1fa0;}else return _0x35b7eb&&!this['getPriority']()['isEmpty']()&&(_0x189544['.priority']=this['getPriority']()['val']()),_0x189544;}['hash'](){if(this['lazyHash_']===null){let _0x869c3f='';this['getPriority']()['isEmpty']()||(_0x869c3f+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xec92d7,_0x487155)=>{const _0x44ff66=_0x487155['hash']();_0x44ff66!==''&&(_0x869c3f+=':'+_0xec92d7+':'+_0x44ff66);}),this['lazyHash_']=_0x869c3f===''?'':ro(_0x869c3f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x308c2a,_0x1315de,_0x19cfe8){const _0x5c26e9=this['resolveIndex_'](_0x19cfe8);if(_0x5c26e9){const _0x436129=_0x5c26e9['getPredecessorKey'](new E(_0x308c2a,_0x1315de));return _0x436129?_0x436129['name']:null;}else return this['children_']['getPredecessorKey'](_0x308c2a);}['getFirstChildName'](_0x2c85e8){const _0x4c4687=this['resolveIndex_'](_0x2c85e8);if(_0x4c4687){const _0x3a9693=_0x4c4687['minKey']();return _0x3a9693&&_0x3a9693['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x5c0e2d){const _0xfa25ed=this['getFirstChildName'](_0x5c0e2d);return _0xfa25ed?new E(_0xfa25ed,this['children_']['get'](_0xfa25ed)):null;}['getLastChildName'](_0x381ae0){const _0x203009=this['resolveIndex_'](_0x381ae0);if(_0x203009){const _0x2716f4=_0x203009['maxKey']();return _0x2716f4&&_0x2716f4['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1476bd){const _0x1fef1e=this['getLastChildName'](_0x1476bd);return _0x1fef1e?new E(_0x1fef1e,this['children_']['get'](_0x1fef1e)):null;}['forEachChild'](_0x5233c4,_0x644f5a){const _0x338fe8=this['resolveIndex_'](_0x5233c4);return _0x338fe8?_0x338fe8['inorderTraversal'](_0x4567f9=>_0x644f5a(_0x4567f9['name'],_0x4567f9['node'])):this['children_']['inorderTraversal'](_0x644f5a);}['getIterator'](_0x50436e){return this['getIteratorFrom'](_0x50436e['minPost'](),_0x50436e);}['getIteratorFrom'](_0x316f2a,_0x4dd92b){const _0x1b8182=this['resolveIndex_'](_0x4dd92b);if(_0x1b8182)return _0x1b8182['getIteratorFrom'](_0x316f2a,_0x7b8462=>_0x7b8462);{const _0x5bbd95=this['children_']['getIteratorFrom'](_0x316f2a['name'],E['Wrap']);let _0x2b051a=_0x5bbd95['peek']();for(;_0x2b051a!=null&&_0x4dd92b['compare'](_0x2b051a,_0x316f2a)<0x0;)_0x5bbd95['getNext'](),_0x2b051a=_0x5bbd95['peek']();return _0x5bbd95;}}['getReverseIterator'](_0x38a631){return this['getReverseIteratorFrom'](_0x38a631['maxPost'](),_0x38a631);}['getReverseIteratorFrom'](_0x15dec2,_0x230a4a){const _0x4e5b69=this['resolveIndex_'](_0x230a4a);if(_0x4e5b69)return _0x4e5b69['getReverseIteratorFrom'](_0x15dec2,_0x17a7f3=>_0x17a7f3);{const _0xb207f2=this['children_']['getReverseIteratorFrom'](_0x15dec2['name'],E['Wrap']);let _0x53186d=_0xb207f2['peek']();for(;_0x53186d!=null&&_0x230a4a['compare'](_0x53186d,_0x15dec2)>0x0;)_0xb207f2['getNext'](),_0x53186d=_0xb207f2['peek']();return _0xb207f2;}}['compareTo'](_0x235a79){return this['isEmpty']()?_0x235a79['isEmpty']()?0x0:-0x1:_0x235a79['isLeafNode']()||_0x235a79['isEmpty']()?0x1:_0x235a79===Kt?-0x1:0x0;}['withIndex'](_0x5e4422){if(_0x5e4422===ve||this['indexMap_']['hasIndex'](_0x5e4422))return this;{const _0x430529=this['indexMap_']['addIndex'](_0x5e4422,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x430529);}}['isIndexed'](_0x5be6a7){return _0x5be6a7===ve||this['indexMap_']['hasIndex'](_0x5be6a7);}['equals'](_0x3b8596){if(_0x3b8596===this)return!0x0;if(_0x3b8596['isLeafNode']())return!0x1;{const _0xbc0a52=_0x3b8596;if(this['getPriority']()['equals'](_0xbc0a52['getPriority']())){if(this['children_']['count']()===_0xbc0a52['children_']['count']()){const _0x142c81=this['getIterator'](R),_0x335a26=_0xbc0a52['getIterator'](R);let _0x1427a9=_0x142c81['getNext'](),_0x900cc1=_0x335a26['getNext']();for(;_0x1427a9&&_0x900cc1;){if(_0x1427a9['name']!==_0x900cc1['name']||!_0x1427a9['node']['equals'](_0x900cc1['node']))return!0x1;_0x1427a9=_0x142c81['getNext'](),_0x900cc1=_0x335a26['getNext']();}return _0x1427a9===null&&_0x900cc1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x75802){return _0x75802===ve?null:this['indexMap_']['get'](_0x75802['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4b4c29){return _0x4b4c29===this?0x0:0x1;}['equals'](_0x4ed432){return _0x4ed432===this;}['getPriority'](){return this;}['getImmediateChild'](_0x56c386){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x99f1a9,_0x41c2a9=null){if(_0x99f1a9===null)return g['EMPTY_NODE'];if(typeof _0x99f1a9=='object'&&'.priority'in _0x99f1a9&&(_0x41c2a9=_0x99f1a9['.priority']),f(_0x41c2a9===null||typeof _0x41c2a9=='string'||typeof _0x41c2a9=='number'||typeof _0x41c2a9=='object'&&'.sv'in _0x41c2a9,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x41c2a9),typeof _0x99f1a9=='object'&&'.value'in _0x99f1a9&&_0x99f1a9['.value']!==null&&(_0x99f1a9=_0x99f1a9['.value']),typeof _0x99f1a9!='object'||'.sv'in _0x99f1a9){const _0x3b4737=_0x99f1a9;return new D(_0x3b4737,A(_0x41c2a9));}if(!(_0x99f1a9 instanceof Array)&&Gh){const _0x405cdf=[];let _0x34426e=!0x1;if(x(_0x99f1a9,(_0x37628f,_0x21158a)=>{if(_0x37628f['substring'](0x0,0x1)!=='.'){const _0x1e1a6e=A(_0x21158a);_0x1e1a6e['isEmpty']()||(_0x34426e=_0x34426e||!_0x1e1a6e['getPriority']()['isEmpty'](),_0x405cdf['push'](new E(_0x37628f,_0x1e1a6e)));}}),_0x405cdf['length']===0x0)return g['EMPTY_NODE'];const _0x3e1972=yn(_0x405cdf,xh,_0x239524=>_0x239524['name'],Qi);if(_0x34426e){const _0x11c149=yn(_0x405cdf,R['getCompare']());return new g(_0x3e1972,A(_0x41c2a9),new te({'.priority':_0x11c149},{'.priority':R}));}else return new g(_0x3e1972,A(_0x41c2a9),te['Default']);}else{let _0x5b2585=g['EMPTY_NODE'];return x(_0x99f1a9,(_0x25e265,_0x2fb5e5)=>{if(Q(_0x99f1a9,_0x25e265)&&_0x25e265['substring'](0x0,0x1)!=='.'){const _0x112d4e=A(_0x2fb5e5);(_0x112d4e['isLeafNode']()||!_0x112d4e['isEmpty']())&&(_0x5b2585=_0x5b2585['updateImmediateChild'](_0x25e265,_0x112d4e));}}),_0x5b2585['updatePriority'](A(_0x41c2a9));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x33a01e){super(),this['indexPath_']=_0x33a01e,f(!v(_0x33a01e)&&y(_0x33a01e)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x297f82){return _0x297f82['getChild'](this['indexPath_']);}['isDefinedOn'](_0x339a48){return!_0x339a48['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x102298,_0x151b78){const _0x5a7218=this['extractChild'](_0x102298['node']),_0x4ad563=this['extractChild'](_0x151b78['node']),_0x2a4093=_0x5a7218['compareTo'](_0x4ad563);return _0x2a4093===0x0?qe(_0x102298['name'],_0x151b78['name']):_0x2a4093;}['makePost'](_0xcf4f56,_0x281e84){const _0x35b379=A(_0xcf4f56),_0x36451f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x35b379);return new E(_0x281e84,_0x36451f);}['maxPost'](){const _0x57fedd=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x57fedd);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x2f1a1e,_0x7557d5){const _0x4dcbd0=_0x2f1a1e['node']['compareTo'](_0x7557d5['node']);return _0x4dcbd0===0x0?qe(_0x2f1a1e['name'],_0x7557d5['name']):_0x4dcbd0;}['isDefinedOn'](_0x40825a){return!0x0;}['indexedValueChanged'](_0x2db4a0,_0xf710a5){return!_0x2db4a0['equals'](_0xf710a5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1bb621,_0x9a876){const _0x40a9eb=A(_0x1bb621);return new E(_0x9a876,_0x40a9eb);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x1828f3){return{'type':'value','snapshotNode':_0x1828f3};}function rt(_0x39cb34,_0x3ce31a){return{'type':'child_added','snapshotNode':_0x3ce31a,'childName':_0x39cb34};}function Lt(_0x2e52ab,_0x47c923){return{'type':'child_removed','snapshotNode':_0x47c923,'childName':_0x2e52ab};}function xt(_0x28b145,_0x5a331a,_0xe913e8){return{'type':'child_changed','snapshotNode':_0x5a331a,'childName':_0x28b145,'oldSnap':_0xe913e8};}function zh(_0x59acc9,_0x9228f1){return{'type':'child_moved','snapshotNode':_0x9228f1,'childName':_0x59acc9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x2c2627){this['index_']=_0x2c2627;}['updateChild'](_0x49a4c1,_0x12fbca,_0x46c528,_0x23208b,_0x3a1aea,_0x1a8632){f(_0x49a4c1['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2235eb=_0x49a4c1['getImmediateChild'](_0x12fbca);return _0x2235eb['getChild'](_0x23208b)['equals'](_0x46c528['getChild'](_0x23208b))&&_0x2235eb['isEmpty']()===_0x46c528['isEmpty']()||(_0x1a8632!=null&&(_0x46c528['isEmpty']()?_0x49a4c1['hasChild'](_0x12fbca)?_0x1a8632['trackChildChange'](Lt(_0x12fbca,_0x2235eb)):f(_0x49a4c1['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2235eb['isEmpty']()?_0x1a8632['trackChildChange'](rt(_0x12fbca,_0x46c528)):_0x1a8632['trackChildChange'](xt(_0x12fbca,_0x46c528,_0x2235eb))),_0x49a4c1['isLeafNode']()&&_0x46c528['isEmpty']())?_0x49a4c1:_0x49a4c1['updateImmediateChild'](_0x12fbca,_0x46c528)['withIndex'](this['index_']);}['updateFullNode'](_0x13bfdf,_0x52a65e,_0x2f29d1){return _0x2f29d1!=null&&(_0x13bfdf['isLeafNode']()||_0x13bfdf['forEachChild'](R,(_0x226e4f,_0x559420)=>{_0x52a65e['hasChild'](_0x226e4f)||_0x2f29d1['trackChildChange'](Lt(_0x226e4f,_0x559420));}),_0x52a65e['isLeafNode']()||_0x52a65e['forEachChild'](R,(_0x3f6a15,_0x5b9516)=>{if(_0x13bfdf['hasChild'](_0x3f6a15)){const _0x59cf82=_0x13bfdf['getImmediateChild'](_0x3f6a15);_0x59cf82['equals'](_0x5b9516)||_0x2f29d1['trackChildChange'](xt(_0x3f6a15,_0x5b9516,_0x59cf82));}else _0x2f29d1['trackChildChange'](rt(_0x3f6a15,_0x5b9516));})),_0x52a65e['withIndex'](this['index_']);}['updatePriority'](_0x1634e5,_0x1f47fe){return _0x1634e5['isEmpty']()?g['EMPTY_NODE']:_0x1634e5['updatePriority'](_0x1f47fe);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x199edf){this['indexedFilter_']=new Xi(_0x199edf['getIndex']()),this['index_']=_0x199edf['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x199edf),this['endPost_']=Ft['getEndPost_'](_0x199edf),this['startIsInclusive_']=!_0x199edf['startAfterSet_'],this['endIsInclusive_']=!_0x199edf['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x13130d){const _0x4fcbe3=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x13130d)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x13130d)<0x0,_0x1079ad=this['endIsInclusive_']?this['index_']['compare'](_0x13130d,this['getEndPost']())<=0x0:this['index_']['compare'](_0x13130d,this['getEndPost']())<0x0;return _0x4fcbe3&&_0x1079ad;}['updateChild'](_0x111beb,_0x18d449,_0x13cae0,_0x3f6376,_0x59ad19,_0x514366){return this['matches'](new E(_0x18d449,_0x13cae0))||(_0x13cae0=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x111beb,_0x18d449,_0x13cae0,_0x3f6376,_0x59ad19,_0x514366);}['updateFullNode'](_0x21d538,_0x1d81d8,_0x3a5809){_0x1d81d8['isLeafNode']()&&(_0x1d81d8=g['EMPTY_NODE']);let _0x2880ce=_0x1d81d8['withIndex'](this['index_']);_0x2880ce=_0x2880ce['updatePriority'](g['EMPTY_NODE']);const _0x29f752=this;return _0x1d81d8['forEachChild'](R,(_0x29e3c6,_0x39dd54)=>{_0x29f752['matches'](new E(_0x29e3c6,_0x39dd54))||(_0x2880ce=_0x2880ce['updateImmediateChild'](_0x29e3c6,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x21d538,_0x2880ce,_0x3a5809);}['updatePriority'](_0x4bcbe1,_0x3f9cb7){return _0x4bcbe1;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x12c928){if(_0x12c928['hasStart']()){const _0x49d4cc=_0x12c928['getIndexStartName']();return _0x12c928['getIndex']()['makePost'](_0x12c928['getIndexStartValue'](),_0x49d4cc);}else return _0x12c928['getIndex']()['minPost']();}static['getEndPost_'](_0x35c47c){if(_0x35c47c['hasEnd']()){const _0x1172df=_0x35c47c['getIndexEndName']();return _0x35c47c['getIndex']()['makePost'](_0x35c47c['getIndexEndValue'](),_0x1172df);}else return _0x35c47c['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x30053f){this['withinDirectionalStart']=_0x5a20cc=>this['reverse_']?this['withinEndPost'](_0x5a20cc):this['withinStartPost'](_0x5a20cc),this['withinDirectionalEnd']=_0x255139=>this['reverse_']?this['withinStartPost'](_0x255139):this['withinEndPost'](_0x255139),this['withinStartPost']=_0x2c2e6e=>{const _0x40f1dd=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2c2e6e);return this['startIsInclusive_']?_0x40f1dd<=0x0:_0x40f1dd<0x0;},this['withinEndPost']=_0x3ecb56=>{const _0x2cd50e=this['index_']['compare'](_0x3ecb56,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2cd50e<=0x0:_0x2cd50e<0x0;},this['rangedFilter_']=new Ft(_0x30053f),this['index_']=_0x30053f['getIndex'](),this['limit_']=_0x30053f['getLimit'](),this['reverse_']=!_0x30053f['isViewFromLeft'](),this['startIsInclusive_']=!_0x30053f['startAfterSet_'],this['endIsInclusive_']=!_0x30053f['endBeforeSet_'];}['updateChild'](_0x26bfdf,_0x29c4f0,_0x307fd5,_0x41fb7e,_0x1c93b9,_0x3cb7c5){return this['rangedFilter_']['matches'](new E(_0x29c4f0,_0x307fd5))||(_0x307fd5=g['EMPTY_NODE']),_0x26bfdf['getImmediateChild'](_0x29c4f0)['equals'](_0x307fd5)?_0x26bfdf:_0x26bfdf['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x26bfdf,_0x29c4f0,_0x307fd5,_0x41fb7e,_0x1c93b9,_0x3cb7c5):this['fullLimitUpdateChild_'](_0x26bfdf,_0x29c4f0,_0x307fd5,_0x1c93b9,_0x3cb7c5);}['updateFullNode'](_0x400881,_0x2cdbc6,_0x48c159){let _0x31d78b;if(_0x2cdbc6['isLeafNode']()||_0x2cdbc6['isEmpty']())_0x31d78b=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2cdbc6['numChildren']()&&_0x2cdbc6['isIndexed'](this['index_'])){_0x31d78b=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x2f7c26;this['reverse_']?_0x2f7c26=_0x2cdbc6['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x2f7c26=_0x2cdbc6['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xfd3e64=0x0;for(;_0x2f7c26['hasNext']()&&_0xfd3e64<this['limit_'];){const _0x48f26c=_0x2f7c26['getNext']();if(this['withinDirectionalStart'](_0x48f26c)){if(this['withinDirectionalEnd'](_0x48f26c))_0x31d78b=_0x31d78b['updateImmediateChild'](_0x48f26c['name'],_0x48f26c['node']),_0xfd3e64++;else break;}else continue;}}else{_0x31d78b=_0x2cdbc6['withIndex'](this['index_']),_0x31d78b=_0x31d78b['updatePriority'](g['EMPTY_NODE']);let _0x283cab;this['reverse_']?_0x283cab=_0x31d78b['getReverseIterator'](this['index_']):_0x283cab=_0x31d78b['getIterator'](this['index_']);let _0x457862=0x0;for(;_0x283cab['hasNext']();){const _0x4dcc72=_0x283cab['getNext']();_0x457862<this['limit_']&&this['withinDirectionalStart'](_0x4dcc72)&&this['withinDirectionalEnd'](_0x4dcc72)?_0x457862++:_0x31d78b=_0x31d78b['updateImmediateChild'](_0x4dcc72['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x400881,_0x31d78b,_0x48c159);}['updatePriority'](_0x496ff9,_0x1416dd){return _0x496ff9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2d3ac6,_0x4cb9a7,_0x3dbe7c,_0x4ffc53,_0xe0e94){let _0x264e33;if(this['reverse_']){const _0x545c7b=this['index_']['getCompare']();_0x264e33=(_0x47d88c,_0x221611)=>_0x545c7b(_0x221611,_0x47d88c);}else _0x264e33=this['index_']['getCompare']();const _0x41299e=_0x2d3ac6;f(_0x41299e['numChildren']()===this['limit_'],'');const _0x9809ed=new E(_0x4cb9a7,_0x3dbe7c),_0x49b7f1=this['reverse_']?_0x41299e['getFirstChild'](this['index_']):_0x41299e['getLastChild'](this['index_']),_0x248cfe=this['rangedFilter_']['matches'](_0x9809ed);if(_0x41299e['hasChild'](_0x4cb9a7)){const _0x15f0c9=_0x41299e['getImmediateChild'](_0x4cb9a7);let _0x4d7caf=_0x4ffc53['getChildAfterChild'](this['index_'],_0x49b7f1,this['reverse_']);for(;_0x4d7caf!=null&&(_0x4d7caf['name']===_0x4cb9a7||_0x41299e['hasChild'](_0x4d7caf['name']));)_0x4d7caf=_0x4ffc53['getChildAfterChild'](this['index_'],_0x4d7caf,this['reverse_']);const _0x48e155=_0x4d7caf==null?0x1:_0x264e33(_0x4d7caf,_0x9809ed);if(_0x248cfe&&!_0x3dbe7c['isEmpty']()&&_0x48e155>=0x0)return _0xe0e94!=null&&_0xe0e94['trackChildChange'](xt(_0x4cb9a7,_0x3dbe7c,_0x15f0c9)),_0x41299e['updateImmediateChild'](_0x4cb9a7,_0x3dbe7c);{_0xe0e94!=null&&_0xe0e94['trackChildChange'](Lt(_0x4cb9a7,_0x15f0c9));const _0x1e2e40=_0x41299e['updateImmediateChild'](_0x4cb9a7,g['EMPTY_NODE']);return _0x4d7caf!=null&&this['rangedFilter_']['matches'](_0x4d7caf)?(_0xe0e94!=null&&_0xe0e94['trackChildChange'](rt(_0x4d7caf['name'],_0x4d7caf['node'])),_0x1e2e40['updateImmediateChild'](_0x4d7caf['name'],_0x4d7caf['node'])):_0x1e2e40;}}else return _0x3dbe7c['isEmpty']()?_0x2d3ac6:_0x248cfe&&_0x264e33(_0x49b7f1,_0x9809ed)>=0x0?(_0xe0e94!=null&&(_0xe0e94['trackChildChange'](Lt(_0x49b7f1['name'],_0x49b7f1['node'])),_0xe0e94['trackChildChange'](rt(_0x4cb9a7,_0x3dbe7c))),_0x41299e['updateImmediateChild'](_0x4cb9a7,_0x3dbe7c)['updateImmediateChild'](_0x49b7f1['name'],g['EMPTY_NODE'])):_0x2d3ac6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x25a741=new Zi();return _0x25a741['limitSet_']=this['limitSet_'],_0x25a741['limit_']=this['limit_'],_0x25a741['startSet_']=this['startSet_'],_0x25a741['startAfterSet_']=this['startAfterSet_'],_0x25a741['indexStartValue_']=this['indexStartValue_'],_0x25a741['startNameSet_']=this['startNameSet_'],_0x25a741['indexStartName_']=this['indexStartName_'],_0x25a741['endSet_']=this['endSet_'],_0x25a741['endBeforeSet_']=this['endBeforeSet_'],_0x25a741['indexEndValue_']=this['indexEndValue_'],_0x25a741['endNameSet_']=this['endNameSet_'],_0x25a741['indexEndName_']=this['indexEndName_'],_0x25a741['index_']=this['index_'],_0x25a741['viewFrom_']=this['viewFrom_'],_0x25a741;}}function Kh(_0x313f7d){return _0x313f7d['loadsAllData']()?new Xi(_0x313f7d['getIndex']()):_0x313f7d['hasLimit']()?new jh(_0x313f7d):new Ft(_0x313f7d);}function Yh(_0x83aa3c,_0x4b633c){const _0x25e1bf=_0x83aa3c['copy']();return _0x25e1bf['limitSet_']=!0x0,_0x25e1bf['limit_']=_0x4b633c,_0x25e1bf['viewFrom_']='l',_0x25e1bf;}function Qh(_0x55be30,_0x5d7499,_0x5d64ad){const _0x529ce2=_0x55be30['copy']();return _0x529ce2['startSet_']=!0x0,_0x5d7499===void 0x0&&(_0x5d7499=null),_0x529ce2['indexStartValue_']=_0x5d7499,_0x5d64ad!=null?(_0x529ce2['startNameSet_']=!0x0,_0x529ce2['indexStartName_']=_0x5d64ad):(_0x529ce2['startNameSet_']=!0x1,_0x529ce2['indexStartName_']=''),_0x529ce2;}function Jh(_0x31e790,_0x34eb23,_0x23c0f4){const _0x1dcde2=_0x31e790['copy']();return _0x1dcde2['endSet_']=!0x0,_0x34eb23===void 0x0&&(_0x34eb23=null),_0x1dcde2['indexEndValue_']=_0x34eb23,_0x23c0f4!==void 0x0?(_0x1dcde2['endNameSet_']=!0x0,_0x1dcde2['indexEndName_']=_0x23c0f4):(_0x1dcde2['endNameSet_']=!0x1,_0x1dcde2['indexEndName_']=''),_0x1dcde2;}function xo(_0x2853fe,_0x3b868f){const _0x26906d=_0x2853fe['copy']();return _0x26906d['index_']=_0x3b868f,_0x26906d;}function ir(_0x534fc5){const _0x50c1db={};if(_0x534fc5['isDefault']())return _0x50c1db;let _0x5a5527;if(_0x534fc5['index_']===R?_0x5a5527='$priority':_0x534fc5['index_']===Mo?_0x5a5527='$value':_0x534fc5['index_']===ve?_0x5a5527='$key':(f(_0x534fc5['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x5a5527=_0x534fc5['index_']['toString']()),_0x50c1db['orderBy']=O(_0x5a5527),_0x534fc5['startSet_']){const _0x39900c=_0x534fc5['startAfterSet_']?'startAfter':'startAt';_0x50c1db[_0x39900c]=O(_0x534fc5['indexStartValue_']),_0x534fc5['startNameSet_']&&(_0x50c1db[_0x39900c]+=','+O(_0x534fc5['indexStartName_']));}if(_0x534fc5['endSet_']){const _0x10e8cb=_0x534fc5['endBeforeSet_']?'endBefore':'endAt';_0x50c1db[_0x10e8cb]=O(_0x534fc5['indexEndValue_']),_0x534fc5['endNameSet_']&&(_0x50c1db[_0x10e8cb]+=','+O(_0x534fc5['indexEndName_']));}return _0x534fc5['limitSet_']&&(_0x534fc5['isViewFromLeft']()?_0x50c1db['limitToFirst']=_0x534fc5['limit_']:_0x50c1db['limitToLast']=_0x534fc5['limit_']),_0x50c1db;}function sr(_0x55f2b7){const _0x33f0a5={};if(_0x55f2b7['startSet_']&&(_0x33f0a5['sp']=_0x55f2b7['indexStartValue_'],_0x55f2b7['startNameSet_']&&(_0x33f0a5['sn']=_0x55f2b7['indexStartName_']),_0x33f0a5['sin']=!_0x55f2b7['startAfterSet_']),_0x55f2b7['endSet_']&&(_0x33f0a5['ep']=_0x55f2b7['indexEndValue_'],_0x55f2b7['endNameSet_']&&(_0x33f0a5['en']=_0x55f2b7['indexEndName_']),_0x33f0a5['ein']=!_0x55f2b7['endBeforeSet_']),_0x55f2b7['limitSet_']){_0x33f0a5['l']=_0x55f2b7['limit_'];let _0x113ea1=_0x55f2b7['viewFrom_'];_0x113ea1===''&&(_0x55f2b7['isViewFromLeft']()?_0x113ea1='l':_0x113ea1='r'),_0x33f0a5['vf']=_0x113ea1;}return _0x55f2b7['index_']!==R&&(_0x33f0a5['i']=_0x55f2b7['index_']['toString']()),_0x33f0a5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xca294b){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x47fd9a,_0x1d5db3){return _0x1d5db3!==void 0x0?'tag$'+_0x1d5db3:(f(_0x47fd9a['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x47fd9a['_path']['toString']());}constructor(_0x54c0a2,_0x458fd3,_0x49a30a,_0x2120d5){super(),this['repoInfo_']=_0x54c0a2,this['onDataUpdate_']=_0x458fd3,this['authTokenProvider_']=_0x49a30a,this['appCheckTokenProvider_']=_0x2120d5,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x2fb1cd,_0x4a2e22,_0x4996a7,_0xa0a56b){const _0x4817da=_0x2fb1cd['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4817da+'\x20'+_0x2fb1cd['_queryIdentifier']);const _0x852521=vn['getListenId_'](_0x2fb1cd,_0x4996a7),_0x573eb7={};this['listens_'][_0x852521]=_0x573eb7;const _0x3ec273=ir(_0x2fb1cd['_queryParams']);this['restRequest_'](_0x4817da+'.json',_0x3ec273,(_0x386a42,_0x5a4fc0)=>{let _0x47356e=_0x5a4fc0;if(_0x386a42===0x194&&(_0x47356e=null,_0x386a42=null),_0x386a42===null&&this['onDataUpdate_'](_0x4817da,_0x47356e,!0x1,_0x4996a7),Le(this['listens_'],_0x852521)===_0x573eb7){let _0x2ce4a9;_0x386a42?_0x386a42===0x191?_0x2ce4a9='permission_denied':_0x2ce4a9='rest_error:'+_0x386a42:_0x2ce4a9='ok',_0xa0a56b(_0x2ce4a9,null);}});}['unlisten'](_0x1c485c,_0x179073){const _0x3234f8=vn['getListenId_'](_0x1c485c,_0x179073);delete this['listens_'][_0x3234f8];}['get'](_0x577d8d){const _0x4b7812=ir(_0x577d8d['_queryParams']),_0x33648d=_0x577d8d['_path']['toString'](),_0xdf6fca=new H();return this['restRequest_'](_0x33648d+'.json',_0x4b7812,(_0x24c8cb,_0x4179d4)=>{let _0x4f03bc=_0x4179d4;_0x24c8cb===0x194&&(_0x4f03bc=null,_0x24c8cb=null),_0x24c8cb===null?(this['onDataUpdate_'](_0x33648d,_0x4f03bc,!0x1,null),_0xdf6fca['resolve'](_0x4f03bc)):_0xdf6fca['reject'](new Error(_0x4f03bc));}),_0xdf6fca['promise'];}['refreshAuthToken'](_0x26ac61){}['restRequest_'](_0x1fec87,_0x3e69af={},_0x4b10eb){return _0x3e69af['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x402b40,_0x3e977b])=>{_0x402b40&&_0x402b40['accessToken']&&(_0x3e69af['auth']=_0x402b40['accessToken']),_0x3e977b&&_0x3e977b['token']&&(_0x3e69af['ac']=_0x3e977b['token']);const _0x27ce0b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1fec87+'?ns='+this['repoInfo_']['namespace']+ut(_0x3e69af);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x27ce0b);const _0x21f6d2=new XMLHttpRequest();_0x21f6d2['onreadystatechange']=()=>{if(_0x4b10eb&&_0x21f6d2['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x27ce0b+'\x20received.\x20status:',_0x21f6d2['status'],'response:',_0x21f6d2['responseText']);let _0x56447a=null;if(_0x21f6d2['status']>=0xc8&&_0x21f6d2['status']<0x12c){try{_0x56447a=Nt(_0x21f6d2['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x27ce0b+':\x20'+_0x21f6d2['responseText']);}_0x4b10eb(null,_0x56447a);}else _0x21f6d2['status']!==0x191&&_0x21f6d2['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x27ce0b+'\x20Status:\x20'+_0x21f6d2['status']),_0x4b10eb(_0x21f6d2['status']);_0x4b10eb=null;}},_0x21f6d2['open']('GET',_0x27ce0b,!0x0),_0x21f6d2['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xf0e56b){return this['rootNode_']['getChild'](_0xf0e56b);}['updateSnapshot'](_0x453d84,_0x13f17c){this['rootNode_']=this['rootNode_']['updateChild'](_0x453d84,_0x13f17c);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x3a8cec,_0x5e684b,_0x152982){if(v(_0x5e684b))_0x3a8cec['value']=_0x152982,_0x3a8cec['children']['clear']();else{if(_0x3a8cec['value']!==null)_0x3a8cec['value']=_0x3a8cec['value']['updateChild'](_0x5e684b,_0x152982);else{const _0x193795=y(_0x5e684b);_0x3a8cec['children']['has'](_0x193795)||_0x3a8cec['children']['set'](_0x193795,En());const _0x215cd1=_0x3a8cec['children']['get'](_0x193795);_0x5e684b=S(_0x5e684b),pt(_0x215cd1,_0x5e684b,_0x152982);}}}function Ti(_0x1a70bc,_0xab8e73){if(v(_0xab8e73))return _0x1a70bc['value']=null,_0x1a70bc['children']['clear'](),!0x0;if(_0x1a70bc['value']!==null){if(_0x1a70bc['value']['isLeafNode']())return!0x1;{const _0x410d48=_0x1a70bc['value'];return _0x1a70bc['value']=null,_0x410d48['forEachChild'](R,(_0x2547a0,_0x3f1d59)=>{pt(_0x1a70bc,new C(_0x2547a0),_0x3f1d59);}),Ti(_0x1a70bc,_0xab8e73);}}else{if(_0x1a70bc['children']['size']>0x0){const _0x547bf3=y(_0xab8e73);return _0xab8e73=S(_0xab8e73),_0x1a70bc['children']['has'](_0x547bf3)&&Ti(_0x1a70bc['children']['get'](_0x547bf3),_0xab8e73)&&_0x1a70bc['children']['delete'](_0x547bf3),_0x1a70bc['children']['size']===0x0;}else return!0x0;}}function Si(_0x1418ca,_0x1085a2,_0x3fc419){_0x1418ca['value']!==null?_0x3fc419(_0x1085a2,_0x1418ca['value']):Zh(_0x1418ca,(_0xc08152,_0x32a143)=>{const _0xe274fb=new C(_0x1085a2['toString']()+'/'+_0xc08152);Si(_0x32a143,_0xe274fb,_0x3fc419);});}function Zh(_0x140457,_0x7aae2f){_0x140457['children']['forEach']((_0x54c46d,_0x3aa1d1)=>{_0x7aae2f(_0x3aa1d1,_0x54c46d);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x6866b4){this['collection_']=_0x6866b4,this['last_']=null;}['get'](){const _0x1affbc=this['collection_']['get'](),_0x43bf27={..._0x1affbc};return this['last_']&&x(this['last_'],(_0x482df4,_0x444f90)=>{_0x43bf27[_0x482df4]=_0x43bf27[_0x482df4]-_0x444f90;}),this['last_']=_0x1affbc,_0x43bf27;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x53d702,_0x8587fa){this['server_']=_0x8587fa,this['statsToReport_']={},this['statsListener_']=new eu(_0x53d702);const _0x5170b2=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5170b2));}['reportStats_'](){const _0x4302f5=this['statsListener_']['get'](),_0x63326e={};let _0x5e422b=!0x1;x(_0x4302f5,(_0x6beca5,_0x468b11)=>{_0x468b11>0x0&&Q(this['statsToReport_'],_0x6beca5)&&(_0x63326e[_0x6beca5]=_0x468b11,_0x5e422b=!0x0);}),_0x5e422b&&this['server_']['reportStats'](_0x63326e),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2034e7){_0x2034e7[_0x2034e7['OVERWRITE']=0x0]='OVERWRITE',_0x2034e7[_0x2034e7['MERGE']=0x1]='MERGE',_0x2034e7[_0x2034e7['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2034e7[_0x2034e7['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1900fe){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1900fe,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x3f1c4d,_0x3267c8,_0x26a6b6){this['path']=_0x3f1c4d,this['affectedTree']=_0x3267c8,this['revert']=_0x26a6b6,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x2d7ea8){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x1207c5=this['affectedTree']['subtree'](new C(_0x2d7ea8));return new In(w(),_0x1207c5,this['revert']);}}else return f(y(this['path'])===_0x2d7ea8,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4ebbd5,_0x4edf2a){this['source']=_0x4ebbd5,this['path']=_0x4edf2a,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3cee73){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x17c484,_0x28c250,_0x2d1304){this['source']=_0x17c484,this['path']=_0x28c250,this['snap']=_0x2d1304,this['type']=z['OVERWRITE'];}['operationForChild'](_0x3aee11){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x3aee11)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x204330,_0x4b8a29,_0x366565){this['source']=_0x204330,this['path']=_0x4b8a29,this['children']=_0x366565,this['type']=z['MERGE'];}['operationForChild'](_0x50d72c){if(v(this['path'])){const _0x5e85c5=this['children']['subtree'](new C(_0x50d72c));return _0x5e85c5['isEmpty']()?null:_0x5e85c5['value']?new Be(this['source'],w(),_0x5e85c5['value']):new ot(this['source'],w(),_0x5e85c5);}else return f(y(this['path'])===_0x50d72c,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x3d311e,_0xd89d86,_0x4fd82e){this['node_']=_0x3d311e,this['fullyInitialized_']=_0xd89d86,this['filtered_']=_0x4fd82e;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x278fc4){if(v(_0x278fc4))return this['isFullyInitialized']()&&!this['filtered_'];const _0x2e87ba=y(_0x278fc4);return this['isCompleteForChild'](_0x2e87ba);}['isCompleteForChild'](_0x458836){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x458836);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1dc76d){this['query_']=_0x1dc76d,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x46e883,_0x5d8f61,_0x53a2aa,_0x4b2341){const _0x2aa3e5=[],_0xbd0610=[];return _0x5d8f61['forEach'](_0x5a4810=>{_0x5a4810['type']==='child_changed'&&_0x46e883['index_']['indexedValueChanged'](_0x5a4810['oldSnap'],_0x5a4810['snapshotNode'])&&_0xbd0610['push'](zh(_0x5a4810['childName'],_0x5a4810['snapshotNode']));}),wt(_0x46e883,_0x2aa3e5,'child_removed',_0x5d8f61,_0x4b2341,_0x53a2aa),wt(_0x46e883,_0x2aa3e5,'child_added',_0x5d8f61,_0x4b2341,_0x53a2aa),wt(_0x46e883,_0x2aa3e5,'child_moved',_0xbd0610,_0x4b2341,_0x53a2aa),wt(_0x46e883,_0x2aa3e5,'child_changed',_0x5d8f61,_0x4b2341,_0x53a2aa),wt(_0x46e883,_0x2aa3e5,'value',_0x5d8f61,_0x4b2341,_0x53a2aa),_0x2aa3e5;}function wt(_0x17d490,_0x297d64,_0x74311f,_0x2b51b6,_0x161450,_0x4a5459){const _0x3a8393=_0x2b51b6['filter'](_0x72a82a=>_0x72a82a['type']===_0x74311f);_0x3a8393['sort']((_0x30844e,_0x5d325a)=>au(_0x17d490,_0x30844e,_0x5d325a)),_0x3a8393['forEach'](_0x35fa3b=>{const _0x55b327=ou(_0x17d490,_0x35fa3b,_0x4a5459);_0x161450['forEach'](_0x135e08=>{_0x135e08['respondsTo'](_0x35fa3b['type'])&&_0x297d64['push'](_0x135e08['createEvent'](_0x55b327,_0x17d490['query_']));});});}function ou(_0x5f32e4,_0x356c5f,_0x1d4728){return _0x356c5f['type']==='value'||_0x356c5f['type']==='child_removed'||(_0x356c5f['prevName']=_0x1d4728['getPredecessorChildName'](_0x356c5f['childName'],_0x356c5f['snapshotNode'],_0x5f32e4['index_'])),_0x356c5f;}function au(_0x26ac85,_0x348e14,_0x3ab825){if(_0x348e14['childName']==null||_0x3ab825['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x239853=new E(_0x348e14['childName'],_0x348e14['snapshotNode']),_0x131988=new E(_0x3ab825['childName'],_0x3ab825['snapshotNode']);return _0x26ac85['index_']['compare'](_0x239853,_0x131988);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x27141c,_0x3ee124){return{'eventCache':_0x27141c,'serverCache':_0x3ee124};}function Rt(_0xfd3ef2,_0x2777f1,_0x2aa092,_0x4a87cd){return Un(new Te(_0x2777f1,_0x2aa092,_0x4a87cd),_0xfd3ef2['serverCache']);}function Fo(_0x1ece19,_0x25e349,_0x3d43d5,_0x95e3b7){return Un(_0x1ece19['eventCache'],new Te(_0x25e349,_0x3d43d5,_0x95e3b7));}function wn(_0x3d457b){return _0x3d457b['eventCache']['isFullyInitialized']()?_0x3d457b['eventCache']['getNode']():null;}function Ve(_0x36312e){return _0x36312e['serverCache']['isFullyInitialized']()?_0x36312e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x3fef15){let _0x33e8f2=new b(null);return x(_0x3fef15,(_0x4587d3,_0x3d7b5a)=>{_0x33e8f2=_0x33e8f2['set'](new C(_0x4587d3),_0x3d7b5a);}),_0x33e8f2;}constructor(_0x471824,_0x432174=cu()){this['value']=_0x471824,this['children']=_0x432174;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x42bac3,_0x2718bf){if(this['value']!=null&&_0x2718bf(this['value']))return{'path':w(),'value':this['value']};if(v(_0x42bac3))return null;{const _0x28cc52=y(_0x42bac3),_0x209455=this['children']['get'](_0x28cc52);if(_0x209455!==null){const _0x4de929=_0x209455['findRootMostMatchingPathAndValue'](S(_0x42bac3),_0x2718bf);return _0x4de929!=null?{'path':k(new C(_0x28cc52),_0x4de929['path']),'value':_0x4de929['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x12b649){return this['findRootMostMatchingPathAndValue'](_0x12b649,()=>!0x0);}['subtree'](_0x252f1a){if(v(_0x252f1a))return this;{const _0x16114f=y(_0x252f1a),_0x51e163=this['children']['get'](_0x16114f);return _0x51e163!==null?_0x51e163['subtree'](S(_0x252f1a)):new b(null);}}['set'](_0x3e095a,_0x20029b){if(v(_0x3e095a))return new b(_0x20029b,this['children']);{const _0x28ea16=y(_0x3e095a),_0x2697ed=(this['children']['get'](_0x28ea16)||new b(null))['set'](S(_0x3e095a),_0x20029b),_0x1f29bf=this['children']['insert'](_0x28ea16,_0x2697ed);return new b(this['value'],_0x1f29bf);}}['remove'](_0x75f062){if(v(_0x75f062))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x1109a7=y(_0x75f062),_0x47a9ec=this['children']['get'](_0x1109a7);if(_0x47a9ec){const _0x33d704=_0x47a9ec['remove'](S(_0x75f062));let _0x5a5340;return _0x33d704['isEmpty']()?_0x5a5340=this['children']['remove'](_0x1109a7):_0x5a5340=this['children']['insert'](_0x1109a7,_0x33d704),this['value']===null&&_0x5a5340['isEmpty']()?new b(null):new b(this['value'],_0x5a5340);}else return this;}}['get'](_0x4bccc1){if(v(_0x4bccc1))return this['value'];{const _0x2a3727=y(_0x4bccc1),_0xf402d5=this['children']['get'](_0x2a3727);return _0xf402d5?_0xf402d5['get'](S(_0x4bccc1)):null;}}['setTree'](_0x588883,_0x365bc5){if(v(_0x588883))return _0x365bc5;{const _0x2252ae=y(_0x588883),_0x4955b5=(this['children']['get'](_0x2252ae)||new b(null))['setTree'](S(_0x588883),_0x365bc5);let _0xc8cb75;return _0x4955b5['isEmpty']()?_0xc8cb75=this['children']['remove'](_0x2252ae):_0xc8cb75=this['children']['insert'](_0x2252ae,_0x4955b5),new b(this['value'],_0xc8cb75);}}['fold'](_0x3ed094){return this['fold_'](w(),_0x3ed094);}['fold_'](_0xfaf685,_0x2b29c5){const _0x2b3cac={};return this['children']['inorderTraversal']((_0x3904bb,_0x5d9dee)=>{_0x2b3cac[_0x3904bb]=_0x5d9dee['fold_'](k(_0xfaf685,_0x3904bb),_0x2b29c5);}),_0x2b29c5(_0xfaf685,this['value'],_0x2b3cac);}['findOnPath'](_0x7de722,_0x292412){return this['findOnPath_'](_0x7de722,w(),_0x292412);}['findOnPath_'](_0xf9b2dc,_0x5bedf8,_0x2326a7){const _0x31810f=this['value']?_0x2326a7(_0x5bedf8,this['value']):!0x1;if(_0x31810f)return _0x31810f;if(v(_0xf9b2dc))return null;{const _0x3ee9fb=y(_0xf9b2dc),_0x41f409=this['children']['get'](_0x3ee9fb);return _0x41f409?_0x41f409['findOnPath_'](S(_0xf9b2dc),k(_0x5bedf8,_0x3ee9fb),_0x2326a7):null;}}['foreachOnPath'](_0x5b4980,_0x170906){return this['foreachOnPath_'](_0x5b4980,w(),_0x170906);}['foreachOnPath_'](_0x3eb81b,_0x355313,_0x5a8052){if(v(_0x3eb81b))return this;{this['value']&&_0x5a8052(_0x355313,this['value']);const _0x27a528=y(_0x3eb81b),_0x5b2025=this['children']['get'](_0x27a528);return _0x5b2025?_0x5b2025['foreachOnPath_'](S(_0x3eb81b),k(_0x355313,_0x27a528),_0x5a8052):new b(null);}}['foreach'](_0x4de6f6){this['foreach_'](w(),_0x4de6f6);}['foreach_'](_0x55a760,_0x5eb3e3){this['children']['inorderTraversal']((_0xb6daa4,_0x309663)=>{_0x309663['foreach_'](k(_0x55a760,_0xb6daa4),_0x5eb3e3);}),this['value']&&_0x5eb3e3(_0x55a760,this['value']);}['foreachChild'](_0x4841a4){this['children']['inorderTraversal']((_0x33bcb6,_0x2450d1)=>{_0x2450d1['value']&&_0x4841a4(_0x33bcb6,_0x2450d1['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x499b87){this['writeTree_']=_0x499b87;}static['empty'](){return new K(new b(null));}}function At(_0x7d5b63,_0x1697a7,_0xf75be2){if(v(_0x1697a7))return new K(new b(_0xf75be2));{const _0x1b5391=_0x7d5b63['writeTree_']['findRootMostValueAndPath'](_0x1697a7);if(_0x1b5391!=null){const _0x165a3a=_0x1b5391['path'];let _0x230aba=_0x1b5391['value'];const _0x28f7d5=F(_0x165a3a,_0x1697a7);return _0x230aba=_0x230aba['updateChild'](_0x28f7d5,_0xf75be2),new K(_0x7d5b63['writeTree_']['set'](_0x165a3a,_0x230aba));}else{const _0x542269=new b(_0xf75be2),_0x3c1d2a=_0x7d5b63['writeTree_']['setTree'](_0x1697a7,_0x542269);return new K(_0x3c1d2a);}}}function bi(_0x114f62,_0x154a96,_0x45825b){let _0x1acdec=_0x114f62;return x(_0x45825b,(_0x3c038f,_0x3aae0d)=>{_0x1acdec=At(_0x1acdec,k(_0x154a96,_0x3c038f),_0x3aae0d);}),_0x1acdec;}function or(_0x5657a8,_0x34231f){if(v(_0x34231f))return K['empty']();{const _0x525030=_0x5657a8['writeTree_']['setTree'](_0x34231f,new b(null));return new K(_0x525030);}}function Ri(_0x1ddb7d,_0x13f575){return ze(_0x1ddb7d,_0x13f575)!=null;}function ze(_0x185d17,_0x44ab5e){const _0x5160f8=_0x185d17['writeTree_']['findRootMostValueAndPath'](_0x44ab5e);return _0x5160f8!=null?_0x185d17['writeTree_']['get'](_0x5160f8['path'])['getChild'](F(_0x5160f8['path'],_0x44ab5e)):null;}function ar(_0x3dd73a){const _0x537491=[],_0x5087ac=_0x3dd73a['writeTree_']['value'];return _0x5087ac!=null?_0x5087ac['isLeafNode']()||_0x5087ac['forEachChild'](R,(_0x2a3d8c,_0x26c3f4)=>{_0x537491['push'](new E(_0x2a3d8c,_0x26c3f4));}):_0x3dd73a['writeTree_']['children']['inorderTraversal']((_0x26f507,_0x3065fd)=>{_0x3065fd['value']!=null&&_0x537491['push'](new E(_0x26f507,_0x3065fd['value']));}),_0x537491;}function Ee(_0x32312b,_0x149d35){if(v(_0x149d35))return _0x32312b;{const _0x336a0b=ze(_0x32312b,_0x149d35);return _0x336a0b!=null?new K(new b(_0x336a0b)):new K(_0x32312b['writeTree_']['subtree'](_0x149d35));}}function Ai(_0x5cf18d){return _0x5cf18d['writeTree_']['isEmpty']();}function at(_0x3cad25,_0x43f97e){return Uo(w(),_0x3cad25['writeTree_'],_0x43f97e);}function Uo(_0x40a041,_0x57e200,_0xd4d896){if(_0x57e200['value']!=null)return _0xd4d896['updateChild'](_0x40a041,_0x57e200['value']);{let _0x289608=null;return _0x57e200['children']['inorderTraversal']((_0x2f56fd,_0x3253a1)=>{_0x2f56fd==='.priority'?(f(_0x3253a1['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x289608=_0x3253a1['value']):_0xd4d896=Uo(k(_0x40a041,_0x2f56fd),_0x3253a1,_0xd4d896);}),!_0xd4d896['getChild'](_0x40a041)['isEmpty']()&&_0x289608!==null&&(_0xd4d896=_0xd4d896['updateChild'](k(_0x40a041,'.priority'),_0x289608)),_0xd4d896;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x47cd87,_0x191f05){return Ho(_0x191f05,_0x47cd87);}function lu(_0x22ec0d,_0x8ab347,_0x4600e6,_0xd2cbd8,_0x44c889){f(_0xd2cbd8>_0x22ec0d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x44c889===void 0x0&&(_0x44c889=!0x0),_0x22ec0d['allWrites']['push']({'path':_0x8ab347,'snap':_0x4600e6,'writeId':_0xd2cbd8,'visible':_0x44c889}),_0x44c889&&(_0x22ec0d['visibleWrites']=At(_0x22ec0d['visibleWrites'],_0x8ab347,_0x4600e6)),_0x22ec0d['lastWriteId']=_0xd2cbd8;}function hu(_0x31018b,_0x376ca9,_0x5ee95b,_0x1d9958){f(_0x1d9958>_0x31018b['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x31018b['allWrites']['push']({'path':_0x376ca9,'children':_0x5ee95b,'writeId':_0x1d9958,'visible':!0x0}),_0x31018b['visibleWrites']=bi(_0x31018b['visibleWrites'],_0x376ca9,_0x5ee95b),_0x31018b['lastWriteId']=_0x1d9958;}function uu(_0x54d149,_0x21bbbc){for(let _0x1fd764=0x0;_0x1fd764<_0x54d149['allWrites']['length'];_0x1fd764++){const _0x10f4b8=_0x54d149['allWrites'][_0x1fd764];if(_0x10f4b8['writeId']===_0x21bbbc)return _0x10f4b8;}return null;}function du(_0x84601a,_0x16fa29){const _0x1cf896=_0x84601a['allWrites']['findIndex'](_0x288f09=>_0x288f09['writeId']===_0x16fa29);f(_0x1cf896>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x434f05=_0x84601a['allWrites'][_0x1cf896];_0x84601a['allWrites']['splice'](_0x1cf896,0x1);let _0x19913c=_0x434f05['visible'],_0x8fc02b=!0x1,_0x540b06=_0x84601a['allWrites']['length']-0x1;for(;_0x19913c&&_0x540b06>=0x0;){const _0x1e6043=_0x84601a['allWrites'][_0x540b06];_0x1e6043['visible']&&(_0x540b06>=_0x1cf896&&fu(_0x1e6043,_0x434f05['path'])?_0x19913c=!0x1:G(_0x434f05['path'],_0x1e6043['path'])&&(_0x8fc02b=!0x0)),_0x540b06--;}if(_0x19913c){if(_0x8fc02b)return pu(_0x84601a),!0x0;if(_0x434f05['snap'])_0x84601a['visibleWrites']=or(_0x84601a['visibleWrites'],_0x434f05['path']);else{const _0x65c8d2=_0x434f05['children'];x(_0x65c8d2,_0x41407c=>{_0x84601a['visibleWrites']=or(_0x84601a['visibleWrites'],k(_0x434f05['path'],_0x41407c));});}return!0x0;}else return!0x1;}function fu(_0x58d962,_0x298fc8){if(_0x58d962['snap'])return G(_0x58d962['path'],_0x298fc8);for(const _0x4a70dd in _0x58d962['children'])if(_0x58d962['children']['hasOwnProperty'](_0x4a70dd)&&G(k(_0x58d962['path'],_0x4a70dd),_0x298fc8))return!0x0;return!0x1;}function pu(_0xe53cf9){_0xe53cf9['visibleWrites']=Wo(_0xe53cf9['allWrites'],_u,w()),_0xe53cf9['allWrites']['length']>0x0?_0xe53cf9['lastWriteId']=_0xe53cf9['allWrites'][_0xe53cf9['allWrites']['length']-0x1]['writeId']:_0xe53cf9['lastWriteId']=-0x1;}function _u(_0x2f501f){return _0x2f501f['visible'];}function Wo(_0x166385,_0x32d0a9,_0x4b2912){let _0x546d95=K['empty']();for(let _0x233f46=0x0;_0x233f46<_0x166385['length'];++_0x233f46){const _0x3e9d1b=_0x166385[_0x233f46];if(_0x32d0a9(_0x3e9d1b)){const _0x25770b=_0x3e9d1b['path'];let _0x332f63;if(_0x3e9d1b['snap'])G(_0x4b2912,_0x25770b)?(_0x332f63=F(_0x4b2912,_0x25770b),_0x546d95=At(_0x546d95,_0x332f63,_0x3e9d1b['snap'])):G(_0x25770b,_0x4b2912)&&(_0x332f63=F(_0x25770b,_0x4b2912),_0x546d95=At(_0x546d95,w(),_0x3e9d1b['snap']['getChild'](_0x332f63)));else{if(_0x3e9d1b['children']){if(G(_0x4b2912,_0x25770b))_0x332f63=F(_0x4b2912,_0x25770b),_0x546d95=bi(_0x546d95,_0x332f63,_0x3e9d1b['children']);else{if(G(_0x25770b,_0x4b2912)){if(_0x332f63=F(_0x25770b,_0x4b2912),v(_0x332f63))_0x546d95=bi(_0x546d95,w(),_0x3e9d1b['children']);else{const _0x451a45=Le(_0x3e9d1b['children'],y(_0x332f63));if(_0x451a45){const _0x35328a=_0x451a45['getChild'](S(_0x332f63));_0x546d95=At(_0x546d95,w(),_0x35328a);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x546d95;}function Bo(_0x4de8e0,_0xae7abc,_0x29c1a8,_0x3aecb2,_0x5e9be0){if(!_0x3aecb2&&!_0x5e9be0){const _0x5d137a=ze(_0x4de8e0['visibleWrites'],_0xae7abc);if(_0x5d137a!=null)return _0x5d137a;{const _0x76ef7f=Ee(_0x4de8e0['visibleWrites'],_0xae7abc);if(Ai(_0x76ef7f))return _0x29c1a8;if(_0x29c1a8==null&&!Ri(_0x76ef7f,w()))return null;{const _0x27be8d=_0x29c1a8||g['EMPTY_NODE'];return at(_0x76ef7f,_0x27be8d);}}}else{const _0x160d47=Ee(_0x4de8e0['visibleWrites'],_0xae7abc);if(!_0x5e9be0&&Ai(_0x160d47))return _0x29c1a8;if(!_0x5e9be0&&_0x29c1a8==null&&!Ri(_0x160d47,w()))return null;{const _0x35ace7=function(_0x106c82){return(_0x106c82['visible']||_0x5e9be0)&&(!_0x3aecb2||!~_0x3aecb2['indexOf'](_0x106c82['writeId']))&&(G(_0x106c82['path'],_0xae7abc)||G(_0xae7abc,_0x106c82['path']));},_0x1214a4=Wo(_0x4de8e0['allWrites'],_0x35ace7,_0xae7abc),_0x1dc1ba=_0x29c1a8||g['EMPTY_NODE'];return at(_0x1214a4,_0x1dc1ba);}}}function gu(_0x38e0c7,_0x427ad3,_0x4106ad){let _0xf959c1=g['EMPTY_NODE'];const _0x2d6078=ze(_0x38e0c7['visibleWrites'],_0x427ad3);if(_0x2d6078)return _0x2d6078['isLeafNode']()||_0x2d6078['forEachChild'](R,(_0x4bd4bd,_0x108f16)=>{_0xf959c1=_0xf959c1['updateImmediateChild'](_0x4bd4bd,_0x108f16);}),_0xf959c1;if(_0x4106ad){const _0x1f7347=Ee(_0x38e0c7['visibleWrites'],_0x427ad3);return _0x4106ad['forEachChild'](R,(_0x1b3733,_0x43a03d)=>{const _0x4bbc07=at(Ee(_0x1f7347,new C(_0x1b3733)),_0x43a03d);_0xf959c1=_0xf959c1['updateImmediateChild'](_0x1b3733,_0x4bbc07);}),ar(_0x1f7347)['forEach'](_0x55536d=>{_0xf959c1=_0xf959c1['updateImmediateChild'](_0x55536d['name'],_0x55536d['node']);}),_0xf959c1;}else{const _0x4ab53c=Ee(_0x38e0c7['visibleWrites'],_0x427ad3);return ar(_0x4ab53c)['forEach'](_0x2be37e=>{_0xf959c1=_0xf959c1['updateImmediateChild'](_0x2be37e['name'],_0x2be37e['node']);}),_0xf959c1;}}function mu(_0x320316,_0x4f55d3,_0xcd7eb3,_0x2d4e7d,_0x1a25a1){f(_0x2d4e7d||_0x1a25a1,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x164c3c=k(_0x4f55d3,_0xcd7eb3);if(Ri(_0x320316['visibleWrites'],_0x164c3c))return null;{const _0x42888a=Ee(_0x320316['visibleWrites'],_0x164c3c);return Ai(_0x42888a)?_0x1a25a1['getChild'](_0xcd7eb3):at(_0x42888a,_0x1a25a1['getChild'](_0xcd7eb3));}}function yu(_0x1197b6,_0x21363f,_0x33a818,_0x1ad3a5){const _0x3f3f21=k(_0x21363f,_0x33a818),_0x3cde54=ze(_0x1197b6['visibleWrites'],_0x3f3f21);if(_0x3cde54!=null)return _0x3cde54;if(_0x1ad3a5['isCompleteForChild'](_0x33a818)){const _0x5a96ce=Ee(_0x1197b6['visibleWrites'],_0x3f3f21);return at(_0x5a96ce,_0x1ad3a5['getNode']()['getImmediateChild'](_0x33a818));}else return null;}function vu(_0x423c13,_0x51905c){return ze(_0x423c13['visibleWrites'],_0x51905c);}function Eu(_0xc1dca9,_0x6994c7,_0x4fbdac,_0x5082c8,_0x5a52de,_0x4a4873,_0x377a82){let _0x269f86;const _0x53ae56=Ee(_0xc1dca9['visibleWrites'],_0x6994c7),_0x35638b=ze(_0x53ae56,w());if(_0x35638b!=null)_0x269f86=_0x35638b;else{if(_0x4fbdac!=null)_0x269f86=at(_0x53ae56,_0x4fbdac);else return[];}if(_0x269f86=_0x269f86['withIndex'](_0x377a82),!_0x269f86['isEmpty']()&&!_0x269f86['isLeafNode']()){const _0x146745=[],_0x5646fc=_0x377a82['getCompare'](),_0x14dd99=_0x4a4873?_0x269f86['getReverseIteratorFrom'](_0x5082c8,_0x377a82):_0x269f86['getIteratorFrom'](_0x5082c8,_0x377a82);let _0x3f86b5=_0x14dd99['getNext']();for(;_0x3f86b5&&_0x146745['length']<_0x5a52de;)_0x5646fc(_0x3f86b5,_0x5082c8)!==0x0&&_0x146745['push'](_0x3f86b5),_0x3f86b5=_0x14dd99['getNext']();return _0x146745;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x1db9b9,_0x446aa2,_0x4f96ee,_0x46519a){return Bo(_0x1db9b9['writeTree'],_0x1db9b9['treePath'],_0x446aa2,_0x4f96ee,_0x46519a);}function is(_0x3e23b1,_0x576d9e){return gu(_0x3e23b1['writeTree'],_0x3e23b1['treePath'],_0x576d9e);}function cr(_0x30fc74,_0xf90bd6,_0x461c67,_0xc04618){return mu(_0x30fc74['writeTree'],_0x30fc74['treePath'],_0xf90bd6,_0x461c67,_0xc04618);}function Tn(_0x4fc4a1,_0x4e9bd8){return vu(_0x4fc4a1['writeTree'],k(_0x4fc4a1['treePath'],_0x4e9bd8));}function wu(_0x2da899,_0x3131e8,_0x654054,_0xd8e6e1,_0x169492,_0x448cf0){return Eu(_0x2da899['writeTree'],_0x2da899['treePath'],_0x3131e8,_0x654054,_0xd8e6e1,_0x169492,_0x448cf0);}function ss(_0x18ae4a,_0x38ff36,_0x2012f1){return yu(_0x18ae4a['writeTree'],_0x18ae4a['treePath'],_0x38ff36,_0x2012f1);}function Vo(_0x148f88,_0x208ad2){return Ho(k(_0x148f88['treePath'],_0x208ad2),_0x148f88['writeTree']);}function Ho(_0x5457f3,_0x442225){return{'treePath':_0x5457f3,'writeTree':_0x442225};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x15e7c0){const _0x1522d9=_0x15e7c0['type'],_0x4e9a47=_0x15e7c0['childName'];f(_0x1522d9==='child_added'||_0x1522d9==='child_changed'||_0x1522d9==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4e9a47!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x56b330=this['changeMap']['get'](_0x4e9a47);if(_0x56b330){const _0x12341b=_0x56b330['type'];if(_0x1522d9==='child_added'&&_0x12341b==='child_removed')this['changeMap']['set'](_0x4e9a47,xt(_0x4e9a47,_0x15e7c0['snapshotNode'],_0x56b330['snapshotNode']));else{if(_0x1522d9==='child_removed'&&_0x12341b==='child_added')this['changeMap']['delete'](_0x4e9a47);else{if(_0x1522d9==='child_removed'&&_0x12341b==='child_changed')this['changeMap']['set'](_0x4e9a47,Lt(_0x4e9a47,_0x56b330['oldSnap']));else{if(_0x1522d9==='child_changed'&&_0x12341b==='child_added')this['changeMap']['set'](_0x4e9a47,rt(_0x4e9a47,_0x15e7c0['snapshotNode']));else{if(_0x1522d9==='child_changed'&&_0x12341b==='child_changed')this['changeMap']['set'](_0x4e9a47,xt(_0x4e9a47,_0x15e7c0['snapshotNode'],_0x56b330['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x15e7c0+'\x20occurred\x20after\x20'+_0x56b330);}}}}}else this['changeMap']['set'](_0x4e9a47,_0x15e7c0);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3cdc44){return null;}['getChildAfterChild'](_0x420af2,_0x50ee4e,_0x616a39){return null;}}const $o=new Tu();class rs{constructor(_0x43e642,_0x1939db,_0x24a034=null){this['writes_']=_0x43e642,this['viewCache_']=_0x1939db,this['optCompleteServerCache_']=_0x24a034;}['getCompleteChild'](_0x20c28d){const _0x3edcdb=this['viewCache_']['eventCache'];if(_0x3edcdb['isCompleteForChild'](_0x20c28d))return _0x3edcdb['getNode']()['getImmediateChild'](_0x20c28d);{const _0x442e45=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x20c28d,_0x442e45);}}['getChildAfterChild'](_0x1e2b99,_0x12c09e,_0x27f3df){const _0x4dbf51=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x16320e=wu(this['writes_'],_0x4dbf51,_0x12c09e,0x1,_0x27f3df,_0x1e2b99);return _0x16320e['length']===0x0?null:_0x16320e[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4e16ee){return{'filter':_0x4e16ee};}function bu(_0x3834cb,_0x592b1d){f(_0x592b1d['eventCache']['getNode']()['isIndexed'](_0x3834cb['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x592b1d['serverCache']['getNode']()['isIndexed'](_0x3834cb['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x39b3e2,_0x200aba,_0x238d7f,_0x58dfd2,_0x1ef781){const _0x2e4f76=new Cu();let _0x2c9518,_0x55e238;if(_0x238d7f['type']===z['OVERWRITE']){const _0x17449b=_0x238d7f;_0x17449b['source']['fromUser']?_0x2c9518=ki(_0x39b3e2,_0x200aba,_0x17449b['path'],_0x17449b['snap'],_0x58dfd2,_0x1ef781,_0x2e4f76):(f(_0x17449b['source']['fromServer'],'Unknown\x20source.'),_0x55e238=_0x17449b['source']['tagged']||_0x200aba['serverCache']['isFiltered']()&&!v(_0x17449b['path']),_0x2c9518=Sn(_0x39b3e2,_0x200aba,_0x17449b['path'],_0x17449b['snap'],_0x58dfd2,_0x1ef781,_0x55e238,_0x2e4f76));}else{if(_0x238d7f['type']===z['MERGE']){const _0x89908a=_0x238d7f;_0x89908a['source']['fromUser']?_0x2c9518=ku(_0x39b3e2,_0x200aba,_0x89908a['path'],_0x89908a['children'],_0x58dfd2,_0x1ef781,_0x2e4f76):(f(_0x89908a['source']['fromServer'],'Unknown\x20source.'),_0x55e238=_0x89908a['source']['tagged']||_0x200aba['serverCache']['isFiltered'](),_0x2c9518=Pi(_0x39b3e2,_0x200aba,_0x89908a['path'],_0x89908a['children'],_0x58dfd2,_0x1ef781,_0x55e238,_0x2e4f76));}else{if(_0x238d7f['type']===z['ACK_USER_WRITE']){const _0x3498c0=_0x238d7f;_0x3498c0['revert']?_0x2c9518=Ou(_0x39b3e2,_0x200aba,_0x3498c0['path'],_0x58dfd2,_0x1ef781,_0x2e4f76):_0x2c9518=Pu(_0x39b3e2,_0x200aba,_0x3498c0['path'],_0x3498c0['affectedTree'],_0x58dfd2,_0x1ef781,_0x2e4f76);}else{if(_0x238d7f['type']===z['LISTEN_COMPLETE'])_0x2c9518=Nu(_0x39b3e2,_0x200aba,_0x238d7f['path'],_0x58dfd2,_0x2e4f76);else throw ht('Unknown\x20operation\x20type:\x20'+_0x238d7f['type']);}}}const _0x33d05f=_0x2e4f76['getChanges']();return Au(_0x200aba,_0x2c9518,_0x33d05f),{'viewCache':_0x2c9518,'changes':_0x33d05f};}function Au(_0x186f4a,_0x2020a9,_0x4a2696){const _0x2e1905=_0x2020a9['eventCache'];if(_0x2e1905['isFullyInitialized']()){const _0x14c6c7=_0x2e1905['getNode']()['isLeafNode']()||_0x2e1905['getNode']()['isEmpty'](),_0x48bad8=wn(_0x186f4a);(_0x4a2696['length']>0x0||!_0x186f4a['eventCache']['isFullyInitialized']()||_0x14c6c7&&!_0x2e1905['getNode']()['equals'](_0x48bad8)||!_0x2e1905['getNode']()['getPriority']()['equals'](_0x48bad8['getPriority']()))&&_0x4a2696['push'](Lo(wn(_0x2020a9)));}}function Go(_0x2f8627,_0x3c33b3,_0x445fa2,_0x415a48,_0x3367b6,_0x538a8e){const _0x37ecb5=_0x3c33b3['eventCache'];if(Tn(_0x415a48,_0x445fa2)!=null)return _0x3c33b3;{let _0x209567,_0x20e78a;if(v(_0x445fa2)){if(f(_0x3c33b3['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3c33b3['serverCache']['isFiltered']()){const _0x3c0438=Ve(_0x3c33b3),_0x4d5390=_0x3c0438 instanceof g?_0x3c0438:g['EMPTY_NODE'],_0x455fe2=is(_0x415a48,_0x4d5390);_0x209567=_0x2f8627['filter']['updateFullNode'](_0x3c33b3['eventCache']['getNode'](),_0x455fe2,_0x538a8e);}else{const _0x3b056a=Cn(_0x415a48,Ve(_0x3c33b3));_0x209567=_0x2f8627['filter']['updateFullNode'](_0x3c33b3['eventCache']['getNode'](),_0x3b056a,_0x538a8e);}}else{const _0x485990=y(_0x445fa2);if(_0x485990==='.priority'){f(Ce(_0x445fa2)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x41f05e=_0x37ecb5['getNode']();_0x20e78a=_0x3c33b3['serverCache']['getNode']();const _0x33641a=cr(_0x415a48,_0x445fa2,_0x41f05e,_0x20e78a);_0x33641a!=null?_0x209567=_0x2f8627['filter']['updatePriority'](_0x41f05e,_0x33641a):_0x209567=_0x37ecb5['getNode']();}else{const _0x1663d0=S(_0x445fa2);let _0x4e464a;if(_0x37ecb5['isCompleteForChild'](_0x485990)){_0x20e78a=_0x3c33b3['serverCache']['getNode']();const _0x3f3cd0=cr(_0x415a48,_0x445fa2,_0x37ecb5['getNode'](),_0x20e78a);_0x3f3cd0!=null?_0x4e464a=_0x37ecb5['getNode']()['getImmediateChild'](_0x485990)['updateChild'](_0x1663d0,_0x3f3cd0):_0x4e464a=_0x37ecb5['getNode']()['getImmediateChild'](_0x485990);}else _0x4e464a=ss(_0x415a48,_0x485990,_0x3c33b3['serverCache']);_0x4e464a!=null?_0x209567=_0x2f8627['filter']['updateChild'](_0x37ecb5['getNode'](),_0x485990,_0x4e464a,_0x1663d0,_0x3367b6,_0x538a8e):_0x209567=_0x37ecb5['getNode']();}}return Rt(_0x3c33b3,_0x209567,_0x37ecb5['isFullyInitialized']()||v(_0x445fa2),_0x2f8627['filter']['filtersNodes']());}}function Sn(_0x32cf9d,_0x517b44,_0x376824,_0xc65c3b,_0x1023cc,_0x5e58bb,_0xb86945,_0x4c937b){const _0x4cc22e=_0x517b44['serverCache'];let _0x42661b;const _0x30e34a=_0xb86945?_0x32cf9d['filter']:_0x32cf9d['filter']['getIndexedFilter']();if(v(_0x376824))_0x42661b=_0x30e34a['updateFullNode'](_0x4cc22e['getNode'](),_0xc65c3b,null);else{if(_0x30e34a['filtersNodes']()&&!_0x4cc22e['isFiltered']()){const _0x270b94=_0x4cc22e['getNode']()['updateChild'](_0x376824,_0xc65c3b);_0x42661b=_0x30e34a['updateFullNode'](_0x4cc22e['getNode'](),_0x270b94,null);}else{const _0x230f44=y(_0x376824);if(!_0x4cc22e['isCompleteForPath'](_0x376824)&&Ce(_0x376824)>0x1)return _0x517b44;const _0x51b98e=S(_0x376824),_0x48d8ea=_0x4cc22e['getNode']()['getImmediateChild'](_0x230f44)['updateChild'](_0x51b98e,_0xc65c3b);_0x230f44==='.priority'?_0x42661b=_0x30e34a['updatePriority'](_0x4cc22e['getNode'](),_0x48d8ea):_0x42661b=_0x30e34a['updateChild'](_0x4cc22e['getNode'](),_0x230f44,_0x48d8ea,_0x51b98e,$o,null);}}const _0x29b031=Fo(_0x517b44,_0x42661b,_0x4cc22e['isFullyInitialized']()||v(_0x376824),_0x30e34a['filtersNodes']()),_0x152425=new rs(_0x1023cc,_0x29b031,_0x5e58bb);return Go(_0x32cf9d,_0x29b031,_0x376824,_0x1023cc,_0x152425,_0x4c937b);}function ki(_0x37960e,_0xc05e5b,_0x262c9a,_0x454894,_0x3dcd24,_0xa4cb23,_0x298843){const _0x8682fa=_0xc05e5b['eventCache'];let _0x30347a,_0x2f1d65;const _0x4af82c=new rs(_0x3dcd24,_0xc05e5b,_0xa4cb23);if(v(_0x262c9a))_0x2f1d65=_0x37960e['filter']['updateFullNode'](_0xc05e5b['eventCache']['getNode'](),_0x454894,_0x298843),_0x30347a=Rt(_0xc05e5b,_0x2f1d65,!0x0,_0x37960e['filter']['filtersNodes']());else{const _0x134298=y(_0x262c9a);if(_0x134298==='.priority')_0x2f1d65=_0x37960e['filter']['updatePriority'](_0xc05e5b['eventCache']['getNode'](),_0x454894),_0x30347a=Rt(_0xc05e5b,_0x2f1d65,_0x8682fa['isFullyInitialized'](),_0x8682fa['isFiltered']());else{const _0x10c896=S(_0x262c9a),_0x36cba2=_0x8682fa['getNode']()['getImmediateChild'](_0x134298);let _0x422e3a;if(v(_0x10c896))_0x422e3a=_0x454894;else{const _0x3448c8=_0x4af82c['getCompleteChild'](_0x134298);_0x3448c8!=null?ji(_0x10c896)==='.priority'&&_0x3448c8['getChild'](Ro(_0x10c896))['isEmpty']()?_0x422e3a=_0x3448c8:_0x422e3a=_0x3448c8['updateChild'](_0x10c896,_0x454894):_0x422e3a=g['EMPTY_NODE'];}if(_0x36cba2['equals'](_0x422e3a))_0x30347a=_0xc05e5b;else{const _0x2a61b1=_0x37960e['filter']['updateChild'](_0x8682fa['getNode'](),_0x134298,_0x422e3a,_0x10c896,_0x4af82c,_0x298843);_0x30347a=Rt(_0xc05e5b,_0x2a61b1,_0x8682fa['isFullyInitialized'](),_0x37960e['filter']['filtersNodes']());}}}return _0x30347a;}function lr(_0xc611d2,_0x5ad7f5){return _0xc611d2['eventCache']['isCompleteForChild'](_0x5ad7f5);}function ku(_0x3647db,_0x474fd5,_0x5e5808,_0x54543f,_0x1582e9,_0xf719c7,_0x4e5d48){let _0x26edea=_0x474fd5;return _0x54543f['foreach']((_0x24357e,_0x29550e)=>{const _0x5abf3e=k(_0x5e5808,_0x24357e);lr(_0x474fd5,y(_0x5abf3e))&&(_0x26edea=ki(_0x3647db,_0x26edea,_0x5abf3e,_0x29550e,_0x1582e9,_0xf719c7,_0x4e5d48));}),_0x54543f['foreach']((_0x1908cd,_0x46ac5b)=>{const _0x7b1802=k(_0x5e5808,_0x1908cd);lr(_0x474fd5,y(_0x7b1802))||(_0x26edea=ki(_0x3647db,_0x26edea,_0x7b1802,_0x46ac5b,_0x1582e9,_0xf719c7,_0x4e5d48));}),_0x26edea;}function hr(_0x247fec,_0x5e42ab,_0x4c3bad){return _0x4c3bad['foreach']((_0x565b73,_0x5447a5)=>{_0x5e42ab=_0x5e42ab['updateChild'](_0x565b73,_0x5447a5);}),_0x5e42ab;}function Pi(_0x287538,_0x3e6d44,_0x2c3869,_0x5f9801,_0x54a618,_0x21113f,_0x4f200b,_0x57e405){if(_0x3e6d44['serverCache']['getNode']()['isEmpty']()&&!_0x3e6d44['serverCache']['isFullyInitialized']())return _0x3e6d44;let _0x5b8478=_0x3e6d44,_0x419908;v(_0x2c3869)?_0x419908=_0x5f9801:_0x419908=new b(null)['setTree'](_0x2c3869,_0x5f9801);const _0x583a41=_0x3e6d44['serverCache']['getNode']();return _0x419908['children']['inorderTraversal']((_0x1eec10,_0x54d48a)=>{if(_0x583a41['hasChild'](_0x1eec10)){const _0x5142e5=_0x3e6d44['serverCache']['getNode']()['getImmediateChild'](_0x1eec10),_0x1ea227=hr(_0x287538,_0x5142e5,_0x54d48a);_0x5b8478=Sn(_0x287538,_0x5b8478,new C(_0x1eec10),_0x1ea227,_0x54a618,_0x21113f,_0x4f200b,_0x57e405);}}),_0x419908['children']['inorderTraversal']((_0x28b65c,_0x3c3cec)=>{const _0x8245e2=!_0x3e6d44['serverCache']['isCompleteForChild'](_0x28b65c)&&_0x3c3cec['value']===null;if(!_0x583a41['hasChild'](_0x28b65c)&&!_0x8245e2){const _0x41d288=_0x3e6d44['serverCache']['getNode']()['getImmediateChild'](_0x28b65c),_0x1cc2b6=hr(_0x287538,_0x41d288,_0x3c3cec);_0x5b8478=Sn(_0x287538,_0x5b8478,new C(_0x28b65c),_0x1cc2b6,_0x54a618,_0x21113f,_0x4f200b,_0x57e405);}}),_0x5b8478;}function Pu(_0x247467,_0x5943dc,_0x452712,_0x45b14b,_0x560702,_0xb0b598,_0x44c40b){if(Tn(_0x560702,_0x452712)!=null)return _0x5943dc;const _0x3e418d=_0x5943dc['serverCache']['isFiltered'](),_0x392bd2=_0x5943dc['serverCache'];if(_0x45b14b['value']!=null){if(v(_0x452712)&&_0x392bd2['isFullyInitialized']()||_0x392bd2['isCompleteForPath'](_0x452712))return Sn(_0x247467,_0x5943dc,_0x452712,_0x392bd2['getNode']()['getChild'](_0x452712),_0x560702,_0xb0b598,_0x3e418d,_0x44c40b);if(v(_0x452712)){let _0x202530=new b(null);return _0x392bd2['getNode']()['forEachChild'](ve,(_0x37f8d8,_0x1d46a9)=>{_0x202530=_0x202530['set'](new C(_0x37f8d8),_0x1d46a9);}),Pi(_0x247467,_0x5943dc,_0x452712,_0x202530,_0x560702,_0xb0b598,_0x3e418d,_0x44c40b);}else return _0x5943dc;}else{let _0x45d615=new b(null);return _0x45b14b['foreach']((_0x5217d9,_0x2b6102)=>{const _0x37695e=k(_0x452712,_0x5217d9);_0x392bd2['isCompleteForPath'](_0x37695e)&&(_0x45d615=_0x45d615['set'](_0x5217d9,_0x392bd2['getNode']()['getChild'](_0x37695e)));}),Pi(_0x247467,_0x5943dc,_0x452712,_0x45d615,_0x560702,_0xb0b598,_0x3e418d,_0x44c40b);}}function Nu(_0x51c604,_0x20f067,_0x514060,_0x5796f8,_0x2109a5){const _0xd64909=_0x20f067['serverCache'],_0x42d430=Fo(_0x20f067,_0xd64909['getNode'](),_0xd64909['isFullyInitialized']()||v(_0x514060),_0xd64909['isFiltered']());return Go(_0x51c604,_0x42d430,_0x514060,_0x5796f8,$o,_0x2109a5);}function Ou(_0x3855fc,_0x17d9ea,_0x382453,_0x5e80d0,_0x1c34d1,_0x137b22){let _0x2db6c0;if(Tn(_0x5e80d0,_0x382453)!=null)return _0x17d9ea;{const _0x4ff806=new rs(_0x5e80d0,_0x17d9ea,_0x1c34d1),_0x3a1a16=_0x17d9ea['eventCache']['getNode']();let _0x162069;if(v(_0x382453)||y(_0x382453)==='.priority'){let _0x260caf;if(_0x17d9ea['serverCache']['isFullyInitialized']())_0x260caf=Cn(_0x5e80d0,Ve(_0x17d9ea));else{const _0xdfdf9f=_0x17d9ea['serverCache']['getNode']();f(_0xdfdf9f instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x260caf=is(_0x5e80d0,_0xdfdf9f);}_0x260caf=_0x260caf,_0x162069=_0x3855fc['filter']['updateFullNode'](_0x3a1a16,_0x260caf,_0x137b22);}else{const _0x342283=y(_0x382453);let _0x269dd6=ss(_0x5e80d0,_0x342283,_0x17d9ea['serverCache']);_0x269dd6==null&&_0x17d9ea['serverCache']['isCompleteForChild'](_0x342283)&&(_0x269dd6=_0x3a1a16['getImmediateChild'](_0x342283)),_0x269dd6!=null?_0x162069=_0x3855fc['filter']['updateChild'](_0x3a1a16,_0x342283,_0x269dd6,S(_0x382453),_0x4ff806,_0x137b22):_0x17d9ea['eventCache']['getNode']()['hasChild'](_0x342283)?_0x162069=_0x3855fc['filter']['updateChild'](_0x3a1a16,_0x342283,g['EMPTY_NODE'],S(_0x382453),_0x4ff806,_0x137b22):_0x162069=_0x3a1a16,_0x162069['isEmpty']()&&_0x17d9ea['serverCache']['isFullyInitialized']()&&(_0x2db6c0=Cn(_0x5e80d0,Ve(_0x17d9ea)),_0x2db6c0['isLeafNode']()&&(_0x162069=_0x3855fc['filter']['updateFullNode'](_0x162069,_0x2db6c0,_0x137b22)));}return _0x2db6c0=_0x17d9ea['serverCache']['isFullyInitialized']()||Tn(_0x5e80d0,w())!=null,Rt(_0x17d9ea,_0x162069,_0x2db6c0,_0x3855fc['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x457771,_0x18bd07){this['query_']=_0x457771,this['eventRegistrations_']=[];const _0x4d6ec3=this['query_']['_queryParams'],_0x40c6ac=new Xi(_0x4d6ec3['getIndex']()),_0xe98202=Kh(_0x4d6ec3);this['processor_']=Su(_0xe98202);const _0x20b190=_0x18bd07['serverCache'],_0xc7acf9=_0x18bd07['eventCache'],_0x5192bf=_0x40c6ac['updateFullNode'](g['EMPTY_NODE'],_0x20b190['getNode'](),null),_0x1b405c=_0xe98202['updateFullNode'](g['EMPTY_NODE'],_0xc7acf9['getNode'](),null),_0x1458c6=new Te(_0x5192bf,_0x20b190['isFullyInitialized'](),_0x40c6ac['filtersNodes']()),_0x1875ea=new Te(_0x1b405c,_0xc7acf9['isFullyInitialized'](),_0xe98202['filtersNodes']());this['viewCache_']=Un(_0x1875ea,_0x1458c6),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x52f970){return _0x52f970['viewCache_']['serverCache']['getNode']();}function Lu(_0x1b107d){return wn(_0x1b107d['viewCache_']);}function xu(_0x1a6b6e,_0x558f0a){const _0x32cefa=Ve(_0x1a6b6e['viewCache_']);return _0x32cefa&&(_0x1a6b6e['query']['_queryParams']['loadsAllData']()||!v(_0x558f0a)&&!_0x32cefa['getImmediateChild'](y(_0x558f0a))['isEmpty']())?_0x32cefa['getChild'](_0x558f0a):null;}function ur(_0xec4191){return _0xec4191['eventRegistrations_']['length']===0x0;}function Fu(_0x243e7e,_0xfbd961){_0x243e7e['eventRegistrations_']['push'](_0xfbd961);}function dr(_0x16fae4,_0x35f76f,_0x592e2e){const _0x7bd8a9=[];if(_0x592e2e){f(_0x35f76f==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2784c7=_0x16fae4['query']['_path'];_0x16fae4['eventRegistrations_']['forEach'](_0x271695=>{const _0x5c44a1=_0x271695['createCancelEvent'](_0x592e2e,_0x2784c7);_0x5c44a1&&_0x7bd8a9['push'](_0x5c44a1);});}if(_0x35f76f){let _0x211b9f=[];for(let _0x1bbd1a=0x0;_0x1bbd1a<_0x16fae4['eventRegistrations_']['length'];++_0x1bbd1a){const _0x7ff40a=_0x16fae4['eventRegistrations_'][_0x1bbd1a];if(!_0x7ff40a['matches'](_0x35f76f))_0x211b9f['push'](_0x7ff40a);else{if(_0x35f76f['hasAnyCallback']()){_0x211b9f=_0x211b9f['concat'](_0x16fae4['eventRegistrations_']['slice'](_0x1bbd1a+0x1));break;}}}_0x16fae4['eventRegistrations_']=_0x211b9f;}else _0x16fae4['eventRegistrations_']=[];return _0x7bd8a9;}function fr(_0x35743b,_0x59a546,_0x47ccd9,_0x560aa9){_0x59a546['type']===z['MERGE']&&_0x59a546['source']['queryId']!==null&&(f(Ve(_0x35743b['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x35743b['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3444c4=_0x35743b['viewCache_'],_0x2ae9bc=Ru(_0x35743b['processor_'],_0x3444c4,_0x59a546,_0x47ccd9,_0x560aa9);return bu(_0x35743b['processor_'],_0x2ae9bc['viewCache']),f(_0x2ae9bc['viewCache']['serverCache']['isFullyInitialized']()||!_0x3444c4['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x35743b['viewCache_']=_0x2ae9bc['viewCache'],qo(_0x35743b,_0x2ae9bc['changes'],_0x2ae9bc['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x62100e,_0x4d3b32){const _0x5e0c1a=_0x62100e['viewCache_']['eventCache'],_0x2e2e68=[];return _0x5e0c1a['getNode']()['isLeafNode']()||_0x5e0c1a['getNode']()['forEachChild'](R,(_0x18f21b,_0x4ee045)=>{_0x2e2e68['push'](rt(_0x18f21b,_0x4ee045));}),_0x5e0c1a['isFullyInitialized']()&&_0x2e2e68['push'](Lo(_0x5e0c1a['getNode']())),qo(_0x62100e,_0x2e2e68,_0x5e0c1a['getNode'](),_0x4d3b32);}function qo(_0x34c4e5,_0x4f085c,_0x15e473,_0x3eb7e5){const _0x1a0428=_0x3eb7e5?[_0x3eb7e5]:_0x34c4e5['eventRegistrations_'];return ru(_0x34c4e5['eventGenerator_'],_0x4f085c,_0x15e473,_0x1a0428);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x2a9171){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x2a9171;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1c63a0){return _0x1c63a0['views']['size']===0x0;}function os(_0x46faae,_0x14f017,_0x5407dd,_0x2c90bd){const _0x2beed0=_0x14f017['source']['queryId'];if(_0x2beed0!==null){const _0x3b3bfa=_0x46faae['views']['get'](_0x2beed0);return f(_0x3b3bfa!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x3b3bfa,_0x14f017,_0x5407dd,_0x2c90bd);}else{let _0x53174a=[];for(const _0x20a904 of _0x46faae['views']['values']())_0x53174a=_0x53174a['concat'](fr(_0x20a904,_0x14f017,_0x5407dd,_0x2c90bd));return _0x53174a;}}function jo(_0x2c9433,_0x49f9c2,_0x64ff4a,_0x20a75a,_0x3a5701){const _0x44fcd8=_0x49f9c2['_queryIdentifier'],_0x1fd097=_0x2c9433['views']['get'](_0x44fcd8);if(!_0x1fd097){let _0x4a666b=Cn(_0x64ff4a,_0x3a5701?_0x20a75a:null),_0x48fdf0=!0x1;_0x4a666b?_0x48fdf0=!0x0:_0x20a75a instanceof g?(_0x4a666b=is(_0x64ff4a,_0x20a75a),_0x48fdf0=!0x1):(_0x4a666b=g['EMPTY_NODE'],_0x48fdf0=!0x1);const _0x1be863=Un(new Te(_0x4a666b,_0x48fdf0,!0x1),new Te(_0x20a75a,_0x3a5701,!0x1));return new Du(_0x49f9c2,_0x1be863);}return _0x1fd097;}function Hu(_0x50059c,_0x47407b,_0x10e74a,_0x9b9e4a,_0x297d3e,_0x5f1ef2){const _0x1fa8e4=jo(_0x50059c,_0x47407b,_0x9b9e4a,_0x297d3e,_0x5f1ef2);return _0x50059c['views']['has'](_0x47407b['_queryIdentifier'])||_0x50059c['views']['set'](_0x47407b['_queryIdentifier'],_0x1fa8e4),Fu(_0x1fa8e4,_0x10e74a),Uu(_0x1fa8e4,_0x10e74a);}function $u(_0x265b53,_0x29ac55,_0x1feee9,_0xcefded){const _0x30a072=_0x29ac55['_queryIdentifier'],_0x4f6a4c=[];let _0x2477f8=[];const _0xd94dd0=Se(_0x265b53);if(_0x30a072==='default'){for(const [_0x5b8f56,_0x56fed0]of _0x265b53['views']['entries']())_0x2477f8=_0x2477f8['concat'](dr(_0x56fed0,_0x1feee9,_0xcefded)),ur(_0x56fed0)&&(_0x265b53['views']['delete'](_0x5b8f56),_0x56fed0['query']['_queryParams']['loadsAllData']()||_0x4f6a4c['push'](_0x56fed0['query']));}else{const _0x56170b=_0x265b53['views']['get'](_0x30a072);_0x56170b&&(_0x2477f8=_0x2477f8['concat'](dr(_0x56170b,_0x1feee9,_0xcefded)),ur(_0x56170b)&&(_0x265b53['views']['delete'](_0x30a072),_0x56170b['query']['_queryParams']['loadsAllData']()||_0x4f6a4c['push'](_0x56170b['query'])));}return _0xd94dd0&&!Se(_0x265b53)&&_0x4f6a4c['push'](new(Bu())(_0x29ac55['_repo'],_0x29ac55['_path'])),{'removed':_0x4f6a4c,'events':_0x2477f8};}function Ko(_0xe3ee51){const _0x5cd2a7=[];for(const _0x1a0ea4 of _0xe3ee51['views']['values']())_0x1a0ea4['query']['_queryParams']['loadsAllData']()||_0x5cd2a7['push'](_0x1a0ea4);return _0x5cd2a7;}function Ie(_0x50c5a9,_0x26ce63){let _0x54e29c=null;for(const _0x54255d of _0x50c5a9['views']['values']())_0x54e29c=_0x54e29c||xu(_0x54255d,_0x26ce63);return _0x54e29c;}function Yo(_0x37e919,_0x548d9a){if(_0x548d9a['_queryParams']['loadsAllData']())return Bn(_0x37e919);{const _0xc762dd=_0x548d9a['_queryIdentifier'];return _0x37e919['views']['get'](_0xc762dd);}}function Qo(_0x378788,_0x1fc80b){return Yo(_0x378788,_0x1fc80b)!=null;}function Se(_0x4df63c){return Bn(_0x4df63c)!=null;}function Bn(_0x2a71ce){for(const _0x34050b of _0x2a71ce['views']['values']())if(_0x34050b['query']['_queryParams']['loadsAllData']())return _0x34050b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x5d5290){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x5d5290;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xec5f5d){this['listenProvider_']=_0xec5f5d,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x22204d,_0x25e3f5,_0x45a5d7,_0x3fb7f5,_0x7b3f8b){return lu(_0x22204d['pendingWriteTree_'],_0x25e3f5,_0x45a5d7,_0x3fb7f5,_0x7b3f8b),_0x7b3f8b?_t(_0x22204d,new Be(es(),_0x25e3f5,_0x45a5d7)):[];}function ju(_0x35fe26,_0x4c8b95,_0x228472,_0x48afbc){hu(_0x35fe26['pendingWriteTree_'],_0x4c8b95,_0x228472,_0x48afbc);const _0xe4bd65=b['fromObject'](_0x228472);return _t(_0x35fe26,new ot(es(),_0x4c8b95,_0xe4bd65));}function _e(_0x1e5fc6,_0x6e18ee,_0x547bb6=!0x1){const _0x589819=uu(_0x1e5fc6['pendingWriteTree_'],_0x6e18ee);if(du(_0x1e5fc6['pendingWriteTree_'],_0x6e18ee)){let _0x20ee2c=new b(null);return _0x589819['snap']!=null?_0x20ee2c=_0x20ee2c['set'](w(),!0x0):x(_0x589819['children'],_0xb5d9f7=>{_0x20ee2c=_0x20ee2c['set'](new C(_0xb5d9f7),!0x0);}),_t(_0x1e5fc6,new In(_0x589819['path'],_0x20ee2c,_0x547bb6));}else return[];}function Yt(_0x27c2b3,_0xb79e03,_0x13a973){return _t(_0x27c2b3,new Be(ts(),_0xb79e03,_0x13a973));}function Ku(_0x1f95d5,_0x27c16e,_0x3babd9){const _0x24a8a2=b['fromObject'](_0x3babd9);return _t(_0x1f95d5,new ot(ts(),_0x27c16e,_0x24a8a2));}function Yu(_0x1d71bd,_0xe8385){return _t(_0x1d71bd,new Ut(ts(),_0xe8385));}function Qu(_0x4c1b20,_0x41fe8b,_0x2abe78){const _0x45646f=cs(_0x4c1b20,_0x2abe78);if(_0x45646f){const _0xf4f949=ls(_0x45646f),_0x14b0ed=_0xf4f949['path'],_0x496f56=_0xf4f949['queryId'],_0xa0289c=F(_0x14b0ed,_0x41fe8b),_0x506aaa=new Ut(ns(_0x496f56),_0xa0289c);return hs(_0x4c1b20,_0x14b0ed,_0x506aaa);}else return[];}function An(_0x519dd9,_0x3bc2c4,_0xe7cbed,_0x5953d9,_0x307d21=!0x1){const _0x428f86=_0x3bc2c4['_path'],_0x3d2aa1=_0x519dd9['syncPointTree_']['get'](_0x428f86);let _0x5320b3=[];if(_0x3d2aa1&&(_0x3bc2c4['_queryIdentifier']==='default'||Qo(_0x3d2aa1,_0x3bc2c4))){const _0x2d4107=$u(_0x3d2aa1,_0x3bc2c4,_0xe7cbed,_0x5953d9);Vu(_0x3d2aa1)&&(_0x519dd9['syncPointTree_']=_0x519dd9['syncPointTree_']['remove'](_0x428f86));const _0x22c904=_0x2d4107['removed'];if(_0x5320b3=_0x2d4107['events'],!_0x307d21){const _0x41241f=_0x22c904['findIndex'](_0x538cc7=>_0x538cc7['_queryParams']['loadsAllData']())!==-0x1,_0x2b25b0=_0x519dd9['syncPointTree_']['findOnPath'](_0x428f86,(_0x486352,_0x32b113)=>Se(_0x32b113));if(_0x41241f&&!_0x2b25b0){const _0x39d112=_0x519dd9['syncPointTree_']['subtree'](_0x428f86);if(!_0x39d112['isEmpty']()){const _0xcbc185=Zu(_0x39d112);for(let _0x39e766=0x0;_0x39e766<_0xcbc185['length'];++_0x39e766){const _0x11a8c5=_0xcbc185[_0x39e766],_0x5eec3d=_0x11a8c5['query'],_0x7176bf=ea(_0x519dd9,_0x11a8c5);_0x519dd9['listenProvider_']['startListening'](kt(_0x5eec3d),Wt(_0x519dd9,_0x5eec3d),_0x7176bf['hashFn'],_0x7176bf['onComplete']);}}}!_0x2b25b0&&_0x22c904['length']>0x0&&!_0x5953d9&&(_0x41241f?_0x519dd9['listenProvider_']['stopListening'](kt(_0x3bc2c4),null):_0x22c904['forEach'](_0x45bed7=>{const _0x977129=_0x519dd9['queryToTagMap']['get'](Hn(_0x45bed7));_0x519dd9['listenProvider_']['stopListening'](kt(_0x45bed7),_0x977129);}));}ed(_0x519dd9,_0x22c904);}return _0x5320b3;}function Jo(_0x5e255b,_0x221478,_0x3e4023,_0x5ef252){const _0x5c87bf=cs(_0x5e255b,_0x5ef252);if(_0x5c87bf!=null){const _0x2a4fe6=ls(_0x5c87bf),_0x2a105b=_0x2a4fe6['path'],_0x56d758=_0x2a4fe6['queryId'],_0xfac026=F(_0x2a105b,_0x221478),_0x45da84=new Be(ns(_0x56d758),_0xfac026,_0x3e4023);return hs(_0x5e255b,_0x2a105b,_0x45da84);}else return[];}function Ju(_0x18a16d,_0x34a00f,_0x547b90,_0x217cf5){const _0x2711db=cs(_0x18a16d,_0x217cf5);if(_0x2711db){const _0x4377ea=ls(_0x2711db),_0x1c304d=_0x4377ea['path'],_0x374085=_0x4377ea['queryId'],_0xe919ed=F(_0x1c304d,_0x34a00f),_0x32d162=b['fromObject'](_0x547b90),_0x4e2263=new ot(ns(_0x374085),_0xe919ed,_0x32d162);return hs(_0x18a16d,_0x1c304d,_0x4e2263);}else return[];}function Ni(_0x48e326,_0x618e32,_0x50e22e,_0x50de45=!0x1){const _0x1b4eb0=_0x618e32['_path'];let _0x3e787f=null,_0x37c909=!0x1;_0x48e326['syncPointTree_']['foreachOnPath'](_0x1b4eb0,(_0x52c110,_0x4361ef)=>{const _0x1515e8=F(_0x52c110,_0x1b4eb0);_0x3e787f=_0x3e787f||Ie(_0x4361ef,_0x1515e8),_0x37c909=_0x37c909||Se(_0x4361ef);});let _0x3471a4=_0x48e326['syncPointTree_']['get'](_0x1b4eb0);_0x3471a4?(_0x37c909=_0x37c909||Se(_0x3471a4),_0x3e787f=_0x3e787f||Ie(_0x3471a4,w())):(_0x3471a4=new zo(),_0x48e326['syncPointTree_']=_0x48e326['syncPointTree_']['set'](_0x1b4eb0,_0x3471a4));let _0x5a66e4;_0x3e787f!=null?_0x5a66e4=!0x0:(_0x5a66e4=!0x1,_0x3e787f=g['EMPTY_NODE'],_0x48e326['syncPointTree_']['subtree'](_0x1b4eb0)['foreachChild']((_0x150a22,_0x142ed0)=>{const _0x5a5004=Ie(_0x142ed0,w());_0x5a5004&&(_0x3e787f=_0x3e787f['updateImmediateChild'](_0x150a22,_0x5a5004));}));const _0x49a121=Qo(_0x3471a4,_0x618e32);if(!_0x49a121&&!_0x618e32['_queryParams']['loadsAllData']()){const _0x10ea64=Hn(_0x618e32);f(!_0x48e326['queryToTagMap']['has'](_0x10ea64),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x8372a2=td();_0x48e326['queryToTagMap']['set'](_0x10ea64,_0x8372a2),_0x48e326['tagToQueryMap']['set'](_0x8372a2,_0x10ea64);}const _0x4a9837=Wn(_0x48e326['pendingWriteTree_'],_0x1b4eb0);let _0x41763d=Hu(_0x3471a4,_0x618e32,_0x50e22e,_0x4a9837,_0x3e787f,_0x5a66e4);if(!_0x49a121&&!_0x37c909&&!_0x50de45){const _0x468d14=Yo(_0x3471a4,_0x618e32);_0x41763d=_0x41763d['concat'](nd(_0x48e326,_0x618e32,_0x468d14));}return _0x41763d;}function Vn(_0x2b8fb6,_0x17b6ed,_0x998300){const _0x393366=_0x2b8fb6['pendingWriteTree_'],_0xcc7dce=_0x2b8fb6['syncPointTree_']['findOnPath'](_0x17b6ed,(_0x49215a,_0x59c55d)=>{const _0x25390d=F(_0x49215a,_0x17b6ed),_0xee64fe=Ie(_0x59c55d,_0x25390d);if(_0xee64fe)return _0xee64fe;});return Bo(_0x393366,_0x17b6ed,_0xcc7dce,_0x998300,!0x0);}function Xu(_0xe16bbd,_0x129c5e){const _0x49b4c8=_0x129c5e['_path'];let _0x212cae=null;_0xe16bbd['syncPointTree_']['foreachOnPath'](_0x49b4c8,(_0x53c6eb,_0x14cbe1)=>{const _0x1cc122=F(_0x53c6eb,_0x49b4c8);_0x212cae=_0x212cae||Ie(_0x14cbe1,_0x1cc122);});let _0x45abaa=_0xe16bbd['syncPointTree_']['get'](_0x49b4c8);_0x45abaa?_0x212cae=_0x212cae||Ie(_0x45abaa,w()):(_0x45abaa=new zo(),_0xe16bbd['syncPointTree_']=_0xe16bbd['syncPointTree_']['set'](_0x49b4c8,_0x45abaa));const _0x31f1d5=_0x212cae!=null,_0x8ecb49=_0x31f1d5?new Te(_0x212cae,!0x0,!0x1):null,_0x186abc=Wn(_0xe16bbd['pendingWriteTree_'],_0x129c5e['_path']),_0x3bc050=jo(_0x45abaa,_0x129c5e,_0x186abc,_0x31f1d5?_0x8ecb49['getNode']():g['EMPTY_NODE'],_0x31f1d5);return Lu(_0x3bc050);}function _t(_0x3af038,_0x5e88d3){return Xo(_0x5e88d3,_0x3af038['syncPointTree_'],null,Wn(_0x3af038['pendingWriteTree_'],w()));}function Xo(_0x39f884,_0x34d31d,_0x39a530,_0x1c9134){if(v(_0x39f884['path']))return Zo(_0x39f884,_0x34d31d,_0x39a530,_0x1c9134);{const _0x1e9715=_0x34d31d['get'](w());_0x39a530==null&&_0x1e9715!=null&&(_0x39a530=Ie(_0x1e9715,w()));let _0x4cfa42=[];const _0xf8d30d=y(_0x39f884['path']),_0x329d99=_0x39f884['operationForChild'](_0xf8d30d),_0x980583=_0x34d31d['children']['get'](_0xf8d30d);if(_0x980583&&_0x329d99){const _0x2f19fc=_0x39a530?_0x39a530['getImmediateChild'](_0xf8d30d):null,_0x29e8db=Vo(_0x1c9134,_0xf8d30d);_0x4cfa42=_0x4cfa42['concat'](Xo(_0x329d99,_0x980583,_0x2f19fc,_0x29e8db));}return _0x1e9715&&(_0x4cfa42=_0x4cfa42['concat'](os(_0x1e9715,_0x39f884,_0x1c9134,_0x39a530))),_0x4cfa42;}}function Zo(_0xd99b94,_0x170508,_0x4c4611,_0x1f3be3){const _0x184229=_0x170508['get'](w());_0x4c4611==null&&_0x184229!=null&&(_0x4c4611=Ie(_0x184229,w()));let _0x350912=[];return _0x170508['children']['inorderTraversal']((_0x2a9515,_0x32f479)=>{const _0x4c09fd=_0x4c4611?_0x4c4611['getImmediateChild'](_0x2a9515):null,_0x3d7771=Vo(_0x1f3be3,_0x2a9515),_0x1fc864=_0xd99b94['operationForChild'](_0x2a9515);_0x1fc864&&(_0x350912=_0x350912['concat'](Zo(_0x1fc864,_0x32f479,_0x4c09fd,_0x3d7771)));}),_0x184229&&(_0x350912=_0x350912['concat'](os(_0x184229,_0xd99b94,_0x1f3be3,_0x4c4611))),_0x350912;}function ea(_0x273d02,_0x21c12a){const _0x293728=_0x21c12a['query'],_0x335948=Wt(_0x273d02,_0x293728);return{'hashFn':()=>(Mu(_0x21c12a)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x161081=>{if(_0x161081==='ok')return _0x335948?Qu(_0x273d02,_0x293728['_path'],_0x335948):Yu(_0x273d02,_0x293728['_path']);{const _0x12e22f=Kl(_0x161081,_0x293728);return An(_0x273d02,_0x293728,null,_0x12e22f);}}};}function Wt(_0x444e22,_0x4cdece){const _0x16ebfe=Hn(_0x4cdece);return _0x444e22['queryToTagMap']['get'](_0x16ebfe);}function Hn(_0x1381f3){return _0x1381f3['_path']['toString']()+'$'+_0x1381f3['_queryIdentifier'];}function cs(_0x19ba76,_0x459cf2){return _0x19ba76['tagToQueryMap']['get'](_0x459cf2);}function ls(_0x1cef2c){const _0x112385=_0x1cef2c['indexOf']('$');return f(_0x112385!==-0x1&&_0x112385<_0x1cef2c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1cef2c['substr'](_0x112385+0x1),'path':new C(_0x1cef2c['substr'](0x0,_0x112385))};}function hs(_0x4f6cc8,_0x5758e3,_0x1ab751){const _0x2cdaf0=_0x4f6cc8['syncPointTree_']['get'](_0x5758e3);f(_0x2cdaf0,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x43c800=Wn(_0x4f6cc8['pendingWriteTree_'],_0x5758e3);return os(_0x2cdaf0,_0x1ab751,_0x43c800,null);}function Zu(_0x4a12a7){return _0x4a12a7['fold']((_0x2fae5e,_0x5e126e,_0x43244b)=>{if(_0x5e126e&&Se(_0x5e126e))return[Bn(_0x5e126e)];{let _0x15f118=[];return _0x5e126e&&(_0x15f118=Ko(_0x5e126e)),x(_0x43244b,(_0x2fae21,_0x170cdc)=>{_0x15f118=_0x15f118['concat'](_0x170cdc);}),_0x15f118;}});}function kt(_0x520e21){return _0x520e21['_queryParams']['loadsAllData']()&&!_0x520e21['_queryParams']['isDefault']()?new(qu())(_0x520e21['_repo'],_0x520e21['_path']):_0x520e21;}function ed(_0x24dc5d,_0x25081a){for(let _0x9a0f3f=0x0;_0x9a0f3f<_0x25081a['length'];++_0x9a0f3f){const _0x1f68fd=_0x25081a[_0x9a0f3f];if(!_0x1f68fd['_queryParams']['loadsAllData']()){const _0x1172cf=Hn(_0x1f68fd),_0x36795f=_0x24dc5d['queryToTagMap']['get'](_0x1172cf);_0x24dc5d['queryToTagMap']['delete'](_0x1172cf),_0x24dc5d['tagToQueryMap']['delete'](_0x36795f);}}}function td(){return zu++;}function nd(_0x490d60,_0x1a867a,_0x5cdcb9){const _0x3ca9be=_0x1a867a['_path'],_0x2fd5c6=Wt(_0x490d60,_0x1a867a),_0x33ffab=ea(_0x490d60,_0x5cdcb9),_0x358c7e=_0x490d60['listenProvider_']['startListening'](kt(_0x1a867a),_0x2fd5c6,_0x33ffab['hashFn'],_0x33ffab['onComplete']),_0x47e0dd=_0x490d60['syncPointTree_']['subtree'](_0x3ca9be);if(_0x2fd5c6)f(!Se(_0x47e0dd['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3d6180=_0x47e0dd['fold']((_0x61b8c5,_0x2623f6,_0x8fdaba)=>{if(!v(_0x61b8c5)&&_0x2623f6&&Se(_0x2623f6))return[Bn(_0x2623f6)['query']];{let _0x5c0b3f=[];return _0x2623f6&&(_0x5c0b3f=_0x5c0b3f['concat'](Ko(_0x2623f6)['map'](_0x355b79=>_0x355b79['query']))),x(_0x8fdaba,(_0x44e07a,_0x50de01)=>{_0x5c0b3f=_0x5c0b3f['concat'](_0x50de01);}),_0x5c0b3f;}});for(let _0xfdd290=0x0;_0xfdd290<_0x3d6180['length'];++_0xfdd290){const _0x2978f9=_0x3d6180[_0xfdd290];_0x490d60['listenProvider_']['stopListening'](kt(_0x2978f9),Wt(_0x490d60,_0x2978f9));}}return _0x358c7e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x281d26){this['node_']=_0x281d26;}['getImmediateChild'](_0x24a09a){const _0x3f0858=this['node_']['getImmediateChild'](_0x24a09a);return new us(_0x3f0858);}['node'](){return this['node_'];}}class ds{constructor(_0x533e67,_0x474795){this['syncTree_']=_0x533e67,this['path_']=_0x474795;}['getImmediateChild'](_0x26ba4e){const _0xcf6e82=k(this['path_'],_0x26ba4e);return new ds(this['syncTree_'],_0xcf6e82);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0xb0e419){return _0xb0e419=_0xb0e419||{},_0xb0e419['timestamp']=_0xb0e419['timestamp']||new Date()['getTime'](),_0xb0e419;},_r=function(_0x1083f9,_0x179050,_0x4cbd2c){if(!_0x1083f9||typeof _0x1083f9!='object')return _0x1083f9;if(f('.sv'in _0x1083f9,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x1083f9['.sv']=='string')return sd(_0x1083f9['.sv'],_0x179050,_0x4cbd2c);if(typeof _0x1083f9['.sv']=='object')return rd(_0x1083f9['.sv'],_0x179050);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1083f9,null,0x2));},sd=function(_0xcc6951,_0x220ab1,_0x57fa6c){switch(_0xcc6951){case'timestamp':return _0x57fa6c['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xcc6951);}},rd=function(_0x548e49,_0x34864d,_0x554d9d){_0x548e49['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x548e49,null,0x2));const _0x44acd3=_0x548e49['increment'];typeof _0x44acd3!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x44acd3);const _0x29d8ea=_0x34864d['node']();if(f(_0x29d8ea!==null&&typeof _0x29d8ea<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x29d8ea['isLeafNode']())return _0x44acd3;const _0x3b37b7=_0x29d8ea['getValue']();return typeof _0x3b37b7!='number'?_0x44acd3:_0x3b37b7+_0x44acd3;},ta=function(_0x176daa,_0x2d5472,_0x3198f3,_0x28d2d4){return ps(_0x2d5472,new ds(_0x3198f3,_0x176daa),_0x28d2d4);},fs=function(_0x839fc0,_0x44b38b,_0x96053a){return ps(_0x839fc0,new us(_0x44b38b),_0x96053a);};function ps(_0x1e9074,_0x22bf7d,_0x4f8f05){const _0x37b9bd=_0x1e9074['getPriority']()['val'](),_0x563664=_r(_0x37b9bd,_0x22bf7d['getImmediateChild']('.priority'),_0x4f8f05);let _0x461ad7;if(_0x1e9074['isLeafNode']()){const _0x246d9b=_0x1e9074,_0x5da037=_r(_0x246d9b['getValue'](),_0x22bf7d,_0x4f8f05);return _0x5da037!==_0x246d9b['getValue']()||_0x563664!==_0x246d9b['getPriority']()['val']()?new D(_0x5da037,A(_0x563664)):_0x1e9074;}else{const _0x2d026c=_0x1e9074;return _0x461ad7=_0x2d026c,_0x563664!==_0x2d026c['getPriority']()['val']()&&(_0x461ad7=_0x461ad7['updatePriority'](new D(_0x563664))),_0x2d026c['forEachChild'](R,(_0x19c001,_0x16f030)=>{const _0xa061c7=ps(_0x16f030,_0x22bf7d['getImmediateChild'](_0x19c001),_0x4f8f05);_0xa061c7!==_0x16f030&&(_0x461ad7=_0x461ad7['updateImmediateChild'](_0x19c001,_0xa061c7));}),_0x461ad7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x2ffd1f='',_0x557c84=null,_0x2af1a2={'children':{},'childCount':0x0}){this['name']=_0x2ffd1f,this['parent']=_0x557c84,this['node']=_0x2af1a2;}}function $n(_0x574b12,_0x5f3e1d){let _0x552576=_0x5f3e1d instanceof C?_0x5f3e1d:new C(_0x5f3e1d),_0x44db8b=_0x574b12,_0x2a3e97=y(_0x552576);for(;_0x2a3e97!==null;){const _0x405430=Le(_0x44db8b['node']['children'],_0x2a3e97)||{'children':{},'childCount':0x0};_0x44db8b=new _s(_0x2a3e97,_0x44db8b,_0x405430),_0x552576=S(_0x552576),_0x2a3e97=y(_0x552576);}return _0x44db8b;}function je(_0x3c9a04){return _0x3c9a04['node']['value'];}function gs(_0xc035a,_0x230d06){_0xc035a['node']['value']=_0x230d06,Oi(_0xc035a);}function na(_0x5e72e1){return _0x5e72e1['node']['childCount']>0x0;}function od(_0x370c6f){return je(_0x370c6f)===void 0x0&&!na(_0x370c6f);}function Gn(_0x38a578,_0x154283){x(_0x38a578['node']['children'],(_0x2cd523,_0x51eb44)=>{_0x154283(new _s(_0x2cd523,_0x38a578,_0x51eb44));});}function ia(_0x234676,_0x278a7e,_0x41159b,_0x318e3a){_0x41159b&&_0x278a7e(_0x234676),Gn(_0x234676,_0x1a9e4c=>{ia(_0x1a9e4c,_0x278a7e,!0x0);});}function ad(_0xe9e74d,_0x319226,_0x473c04){let _0x5b7d78=_0xe9e74d['parent'];for(;_0x5b7d78!==null;){if(_0x319226(_0x5b7d78))return!0x0;_0x5b7d78=_0x5b7d78['parent'];}return!0x1;}function Qt(_0x42781e){return new C(_0x42781e['parent']===null?_0x42781e['name']:Qt(_0x42781e['parent'])+'/'+_0x42781e['name']);}function Oi(_0x2aa4f8){_0x2aa4f8['parent']!==null&&cd(_0x2aa4f8['parent'],_0x2aa4f8['name'],_0x2aa4f8);}function cd(_0x426f87,_0x1be1a8,_0x3ce8cd){const _0x2130ae=od(_0x3ce8cd),_0x8dce83=Q(_0x426f87['node']['children'],_0x1be1a8);_0x2130ae&&_0x8dce83?(delete _0x426f87['node']['children'][_0x1be1a8],_0x426f87['node']['childCount']--,Oi(_0x426f87)):!_0x2130ae&&!_0x8dce83&&(_0x426f87['node']['children'][_0x1be1a8]=_0x3ce8cd['node'],_0x426f87['node']['childCount']++,Oi(_0x426f87));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x67fbce){return typeof _0x67fbce=='string'&&_0x67fbce['length']!==0x0&&!ld['test'](_0x67fbce);},sa=function(_0x2ed34e){return typeof _0x2ed34e=='string'&&_0x2ed34e['length']!==0x0&&!hd['test'](_0x2ed34e);},ud=function(_0x1e1039){return _0x1e1039&&(_0x1e1039=_0x1e1039['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x1e1039);},Bt=function(_0x5d3885){return _0x5d3885===null||typeof _0x5d3885=='string'||typeof _0x5d3885=='number'&&!xn(_0x5d3885)||_0x5d3885&&typeof _0x5d3885=='object'&&Q(_0x5d3885,'.sv');},He=function(_0x496e72,_0x4349f4,_0x11619e,_0x3338ce){_0x3338ce&&_0x4349f4===void 0x0||Jt(it(_0x496e72,'value'),_0x4349f4,_0x11619e);},Jt=function(_0x172bd4,_0x45acbb,_0x46865e){const _0x27c780=_0x46865e instanceof C?new Ah(_0x46865e,_0x172bd4):_0x46865e;if(_0x45acbb===void 0x0)throw new Error(_0x172bd4+'contains\x20undefined\x20'+Oe(_0x27c780));if(typeof _0x45acbb=='function')throw new Error(_0x172bd4+'contains\x20a\x20function\x20'+Oe(_0x27c780)+'\x20with\x20contents\x20=\x20'+_0x45acbb['toString']());if(xn(_0x45acbb))throw new Error(_0x172bd4+'contains\x20'+_0x45acbb['toString']()+'\x20'+Oe(_0x27c780));if(typeof _0x45acbb=='string'&&_0x45acbb['length']>ui/0x3&&Ln(_0x45acbb)>ui)throw new Error(_0x172bd4+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x27c780)+'\x20(\x27'+_0x45acbb['substring'](0x0,0x32)+'...\x27)');if(_0x45acbb&&typeof _0x45acbb=='object'){let _0x2df2c4=!0x1,_0x46658b=!0x1;if(x(_0x45acbb,(_0x2306b0,_0x3d5392)=>{if(_0x2306b0==='.value')_0x2df2c4=!0x0;else{if(_0x2306b0!=='.priority'&&_0x2306b0!=='.sv'&&(_0x46658b=!0x0,!ms(_0x2306b0)))throw new Error(_0x172bd4+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2306b0+')\x20'+Oe(_0x27c780)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x27c780,_0x2306b0),Jt(_0x172bd4,_0x3d5392,_0x27c780),Ph(_0x27c780);}),_0x2df2c4&&_0x46658b)throw new Error(_0x172bd4+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x27c780)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3a201e,_0x13f631){let _0xc2c8ec,_0x114c9b;for(_0xc2c8ec=0x0;_0xc2c8ec<_0x13f631['length'];_0xc2c8ec++){_0x114c9b=_0x13f631[_0xc2c8ec];const _0x56596c=Mt(_0x114c9b);for(let _0x458cbb=0x0;_0x458cbb<_0x56596c['length'];_0x458cbb++)if(!(_0x56596c[_0x458cbb]==='.priority'&&_0x458cbb===_0x56596c['length']-0x1)){if(!ms(_0x56596c[_0x458cbb]))throw new Error(_0x3a201e+'contains\x20an\x20invalid\x20key\x20('+_0x56596c[_0x458cbb]+')\x20in\x20path\x20'+_0x114c9b['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x13f631['sort'](Rh);let _0x5908f1=null;for(_0xc2c8ec=0x0;_0xc2c8ec<_0x13f631['length'];_0xc2c8ec++){if(_0x114c9b=_0x13f631[_0xc2c8ec],_0x5908f1!==null&&G(_0x5908f1,_0x114c9b))throw new Error(_0x3a201e+'contains\x20a\x20path\x20'+_0x5908f1['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x114c9b['toString']());_0x5908f1=_0x114c9b;}},ra=function(_0x22b3f0,_0x3c957c,_0x59c12f,_0x321855){const _0x2cba62=it(_0x22b3f0,'values');if(!(_0x3c957c&&typeof _0x3c957c=='object')||Array['isArray'](_0x3c957c))throw new Error(_0x2cba62+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3fd59a=[];x(_0x3c957c,(_0x2eaddd,_0x27badb)=>{const _0x261777=new C(_0x2eaddd);if(Jt(_0x2cba62,_0x27badb,k(_0x59c12f,_0x261777)),ji(_0x261777)==='.priority'&&!Bt(_0x27badb))throw new Error(_0x2cba62+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x261777['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3fd59a['push'](_0x261777);}),dd(_0x2cba62,_0x3fd59a);},fd=function(_0x3935e0,_0x330463,_0x3ff8d4){if(xn(_0x330463))throw new Error(it(_0x3935e0,'priority')+'is\x20'+_0x330463['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x330463))throw new Error(it(_0x3935e0,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x25d4ba,_0x537ab3,_0x5c4330,_0xe2b4bb){if(!sa(_0x5c4330))throw new Error(it(_0x25d4ba,_0x537ab3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5c4330+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x36f83a,_0x1b25f3,_0x11afb7,_0x3ed01e){_0x11afb7&&(_0x11afb7=_0x11afb7['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x36f83a,_0x1b25f3,_0x11afb7);},Me=function(_0x448fb9,_0x55c58b){if(y(_0x55c58b)==='.info')throw new Error(_0x448fb9+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x2e017b,_0xa12b9f){const _0x55519a=_0xa12b9f['path']['toString']();if(typeof _0xa12b9f['repoInfo']['host']!='string'||_0xa12b9f['repoInfo']['host']['length']===0x0||!ms(_0xa12b9f['repoInfo']['namespace'])&&_0xa12b9f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x55519a['length']!==0x0&&!ud(_0x55519a))throw new Error(it(_0x2e017b,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x27e3d1,_0x4ba75d){let _0x4af151=null;for(let _0x84891b=0x0;_0x84891b<_0x4ba75d['length'];_0x84891b++){const _0x29e5fb=_0x4ba75d[_0x84891b],_0x48eb8f=_0x29e5fb['getPath']();_0x4af151!==null&&!Ki(_0x48eb8f,_0x4af151['path'])&&(_0x27e3d1['eventLists_']['push'](_0x4af151),_0x4af151=null),_0x4af151===null&&(_0x4af151={'events':[],'path':_0x48eb8f}),_0x4af151['events']['push'](_0x29e5fb);}_0x4af151&&_0x27e3d1['eventLists_']['push'](_0x4af151);}function oa(_0x4c6792,_0x26df28,_0x1969b5){qn(_0x4c6792,_0x1969b5),aa(_0x4c6792,_0x5c86cb=>Ki(_0x5c86cb,_0x26df28));}function V(_0x49c70c,_0x238087,_0x3b7094){qn(_0x49c70c,_0x3b7094),aa(_0x49c70c,_0x359eef=>G(_0x359eef,_0x238087)||G(_0x238087,_0x359eef));}function aa(_0xad11f0,_0x1cbf80){_0xad11f0['recursionDepth_']++;let _0x10620a=!0x0;for(let _0x2dc00a=0x0;_0x2dc00a<_0xad11f0['eventLists_']['length'];_0x2dc00a++){const _0x8a5caf=_0xad11f0['eventLists_'][_0x2dc00a];if(_0x8a5caf){const _0x215c5b=_0x8a5caf['path'];_0x1cbf80(_0x215c5b)?(md(_0xad11f0['eventLists_'][_0x2dc00a]),_0xad11f0['eventLists_'][_0x2dc00a]=null):_0x10620a=!0x1;}}_0x10620a&&(_0xad11f0['eventLists_']=[]),_0xad11f0['recursionDepth_']--;}function md(_0x32a934){for(let _0x2edaeb=0x0;_0x2edaeb<_0x32a934['events']['length'];_0x2edaeb++){const _0xdb5c1f=_0x32a934['events'][_0x2edaeb];if(_0xdb5c1f!==null){_0x32a934['events'][_0x2edaeb]=null;const _0x2dedbf=_0xdb5c1f['getEventRunner']();St&&L('event:\x20'+_0xdb5c1f['toString']()),ft(_0x2dedbf);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x112ec0,_0x3f7240,_0x59e41e,_0x1cd76e){this['repoInfo_']=_0x112ec0,this['forceRestClient_']=_0x3f7240,this['authTokenProvider_']=_0x59e41e,this['appCheckProvider_']=_0x1cd76e,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2ed056,_0x431870,_0x4fc06a){if(_0x2ed056['stats_']=qi(_0x2ed056['repoInfo_']),_0x2ed056['forceRestClient_']||Xl())_0x2ed056['server_']=new vn(_0x2ed056['repoInfo_'],(_0x2d0f51,_0x37c7a3,_0xca8ccc,_0x4df3cf)=>{gr(_0x2ed056,_0x2d0f51,_0x37c7a3,_0xca8ccc,_0x4df3cf);},_0x2ed056['authTokenProvider_'],_0x2ed056['appCheckProvider_']),setTimeout(()=>mr(_0x2ed056,!0x0),0x0);else{if(typeof _0x4fc06a<'u'&&_0x4fc06a!==null){if(typeof _0x4fc06a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4fc06a);}catch(_0x4d3a4a){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4d3a4a);}}_0x2ed056['persistentConnection_']=new se(_0x2ed056['repoInfo_'],_0x431870,(_0x4a5b70,_0x2c0f92,_0x3d254b,_0x483e96)=>{gr(_0x2ed056,_0x4a5b70,_0x2c0f92,_0x3d254b,_0x483e96);},_0x3e731b=>{mr(_0x2ed056,_0x3e731b);},_0x2cb93c=>{Id(_0x2ed056,_0x2cb93c);},_0x2ed056['authTokenProvider_'],_0x2ed056['appCheckProvider_'],_0x4fc06a),_0x2ed056['server_']=_0x2ed056['persistentConnection_'];}_0x2ed056['authTokenProvider_']['addTokenChangeListener'](_0x1ccf9b=>{_0x2ed056['server_']['refreshAuthToken'](_0x1ccf9b);}),_0x2ed056['appCheckProvider_']['addTokenChangeListener'](_0x2c57e0=>{_0x2ed056['server_']['refreshAppCheckToken'](_0x2c57e0['token']);}),_0x2ed056['statsReporter_']=ih(_0x2ed056['repoInfo_'],()=>new iu(_0x2ed056['stats_'],_0x2ed056['server_'])),_0x2ed056['infoData_']=new Xh(),_0x2ed056['infoSyncTree_']=new pr({'startListening':(_0x2ea100,_0x46aa9a,_0x1f4ebb,_0x60dac0)=>{let _0x46f225=[];const _0x477e66=_0x2ed056['infoData_']['getNode'](_0x2ea100['_path']);return _0x477e66['isEmpty']()||(_0x46f225=Yt(_0x2ed056['infoSyncTree_'],_0x2ea100['_path'],_0x477e66),setTimeout(()=>{_0x60dac0('ok');},0x0)),_0x46f225;},'stopListening':()=>{}}),vs(_0x2ed056,'connected',!0x1),_0x2ed056['serverSyncTree_']=new pr({'startListening':(_0x2ffc99,_0x97006e,_0x5ba3f8,_0x477175)=>(_0x2ed056['server_']['listen'](_0x2ffc99,_0x5ba3f8,_0x97006e,(_0x252b9d,_0x1f1e25)=>{const _0x41bf3a=_0x477175(_0x252b9d,_0x1f1e25);V(_0x2ed056['eventQueue_'],_0x2ffc99['_path'],_0x41bf3a);}),[]),'stopListening':(_0x4dbd29,_0x229161)=>{_0x2ed056['server_']['unlisten'](_0x4dbd29,_0x229161);}});}function la(_0x593454){const _0x59424c=_0x593454['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x59424c;}function Xt(_0x52b498){return id({'timestamp':la(_0x52b498)});}function gr(_0x20e445,_0x37e5f3,_0x36bfbf,_0x53986a,_0x202fe2){_0x20e445['dataUpdateCount']++;const _0x91a714=new C(_0x37e5f3);_0x36bfbf=_0x20e445['interceptServerDataCallback_']?_0x20e445['interceptServerDataCallback_'](_0x37e5f3,_0x36bfbf):_0x36bfbf;let _0x23fcc5=[];if(_0x202fe2){if(_0x53986a){const _0x2a3936=_n(_0x36bfbf,_0x2b3c54=>A(_0x2b3c54));_0x23fcc5=Ju(_0x20e445['serverSyncTree_'],_0x91a714,_0x2a3936,_0x202fe2);}else{const _0x141dfa=A(_0x36bfbf);_0x23fcc5=Jo(_0x20e445['serverSyncTree_'],_0x91a714,_0x141dfa,_0x202fe2);}}else{if(_0x53986a){const _0x4f3464=_n(_0x36bfbf,_0x5aa417=>A(_0x5aa417));_0x23fcc5=Ku(_0x20e445['serverSyncTree_'],_0x91a714,_0x4f3464);}else{const _0x4959c8=A(_0x36bfbf);_0x23fcc5=Yt(_0x20e445['serverSyncTree_'],_0x91a714,_0x4959c8);}}let _0x55780f=_0x91a714;_0x23fcc5['length']>0x0&&(_0x55780f=ct(_0x20e445,_0x91a714)),V(_0x20e445['eventQueue_'],_0x55780f,_0x23fcc5);}function mr(_0x5edcc3,_0x5614e1){vs(_0x5edcc3,'connected',_0x5614e1),_0x5614e1===!0x1&&Sd(_0x5edcc3);}function Id(_0x489250,_0x418848){x(_0x418848,(_0x52e34d,_0x87c5da)=>{vs(_0x489250,_0x52e34d,_0x87c5da);});}function vs(_0x196f7c,_0x51b5ca,_0x28a90d){const _0x174d0a=new C('/.info/'+_0x51b5ca),_0x49c8e0=A(_0x28a90d);_0x196f7c['infoData_']['updateSnapshot'](_0x174d0a,_0x49c8e0);const _0x2c451b=Yt(_0x196f7c['infoSyncTree_'],_0x174d0a,_0x49c8e0);V(_0x196f7c['eventQueue_'],_0x174d0a,_0x2c451b);}function zn(_0x3d0dbf){return _0x3d0dbf['nextWriteId_']++;}function wd(_0x1fa0bc,_0x1501b7,_0x4af684){const _0x3b0699=Xu(_0x1fa0bc['serverSyncTree_'],_0x1501b7);return _0x3b0699!=null?Promise['resolve'](_0x3b0699):_0x1fa0bc['server_']['get'](_0x1501b7)['then'](_0x34c10e=>{const _0x4e695a=A(_0x34c10e)['withIndex'](_0x1501b7['_queryParams']['getIndex']());Ni(_0x1fa0bc['serverSyncTree_'],_0x1501b7,_0x4af684,!0x0);let _0x5930e8;if(_0x1501b7['_queryParams']['loadsAllData']())_0x5930e8=Yt(_0x1fa0bc['serverSyncTree_'],_0x1501b7['_path'],_0x4e695a);else{const _0x20bdc8=Wt(_0x1fa0bc['serverSyncTree_'],_0x1501b7);_0x5930e8=Jo(_0x1fa0bc['serverSyncTree_'],_0x1501b7['_path'],_0x4e695a,_0x20bdc8);}return V(_0x1fa0bc['eventQueue_'],_0x1501b7['_path'],_0x5930e8),An(_0x1fa0bc['serverSyncTree_'],_0x1501b7,_0x4af684,null,!0x0),_0x4e695a;},_0x3e4c6b=>(gt(_0x1fa0bc,'get\x20for\x20query\x20'+O(_0x1501b7)+'\x20failed:\x20'+_0x3e4c6b),Promise['reject'](new Error(_0x3e4c6b))));}function Cd(_0x394ba4,_0x7db3b1,_0x3bd427,_0x5a7c1c,_0x5f4de5){gt(_0x394ba4,'set',{'path':_0x7db3b1['toString'](),'value':_0x3bd427,'priority':_0x5a7c1c});const _0x37612f=Xt(_0x394ba4),_0x4b98f5=A(_0x3bd427,_0x5a7c1c),_0x37dc2f=Vn(_0x394ba4['serverSyncTree_'],_0x7db3b1),_0x805896=fs(_0x4b98f5,_0x37dc2f,_0x37612f),_0x5bd827=zn(_0x394ba4),_0x27a699=as(_0x394ba4['serverSyncTree_'],_0x7db3b1,_0x805896,_0x5bd827,!0x0);qn(_0x394ba4['eventQueue_'],_0x27a699),_0x394ba4['server_']['put'](_0x7db3b1['toString'](),_0x4b98f5['val'](!0x0),(_0x472a4f,_0x2dfa8f)=>{const _0x57071e=_0x472a4f==='ok';_0x57071e||U('set\x20at\x20'+_0x7db3b1+'\x20failed:\x20'+_0x472a4f);const _0x37d59a=_e(_0x394ba4['serverSyncTree_'],_0x5bd827,!_0x57071e);V(_0x394ba4['eventQueue_'],_0x7db3b1,_0x37d59a),be(_0x394ba4,_0x5f4de5,_0x472a4f,_0x2dfa8f);});const _0x300e13=Is(_0x394ba4,_0x7db3b1);ct(_0x394ba4,_0x300e13),V(_0x394ba4['eventQueue_'],_0x300e13,[]);}function Td(_0x9d435a,_0x3eafe2,_0x398d71,_0x405b40){gt(_0x9d435a,'update',{'path':_0x3eafe2['toString'](),'value':_0x398d71});let _0x2002ea=!0x0;const _0x90eda3=Xt(_0x9d435a),_0x372ace={};if(x(_0x398d71,(_0x5ac7d2,_0x27e497)=>{_0x2002ea=!0x1,_0x372ace[_0x5ac7d2]=ta(k(_0x3eafe2,_0x5ac7d2),A(_0x27e497),_0x9d435a['serverSyncTree_'],_0x90eda3);}),_0x2002ea)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x9d435a,_0x405b40,'ok',void 0x0);else{const _0x49fe92=zn(_0x9d435a),_0x50f5c7=ju(_0x9d435a['serverSyncTree_'],_0x3eafe2,_0x372ace,_0x49fe92);qn(_0x9d435a['eventQueue_'],_0x50f5c7),_0x9d435a['server_']['merge'](_0x3eafe2['toString'](),_0x398d71,(_0x1b4273,_0x48bf91)=>{const _0x2c259a=_0x1b4273==='ok';_0x2c259a||U('update\x20at\x20'+_0x3eafe2+'\x20failed:\x20'+_0x1b4273);const _0x4dcdb=_e(_0x9d435a['serverSyncTree_'],_0x49fe92,!_0x2c259a),_0x189558=_0x4dcdb['length']>0x0?ct(_0x9d435a,_0x3eafe2):_0x3eafe2;V(_0x9d435a['eventQueue_'],_0x189558,_0x4dcdb),be(_0x9d435a,_0x405b40,_0x1b4273,_0x48bf91);}),x(_0x398d71,_0x4fa4c0=>{const _0x3a9320=Is(_0x9d435a,k(_0x3eafe2,_0x4fa4c0));ct(_0x9d435a,_0x3a9320);}),V(_0x9d435a['eventQueue_'],_0x3eafe2,[]);}}function Sd(_0x5ca64f){gt(_0x5ca64f,'onDisconnectEvents');const _0x24c6b7=Xt(_0x5ca64f),_0x2b6044=En();Si(_0x5ca64f['onDisconnect_'],w(),(_0x2894b1,_0x1c6bcb)=>{const _0x464455=ta(_0x2894b1,_0x1c6bcb,_0x5ca64f['serverSyncTree_'],_0x24c6b7);pt(_0x2b6044,_0x2894b1,_0x464455);});let _0x3cd4bd=[];Si(_0x2b6044,w(),(_0x30638c,_0x35ef25)=>{_0x3cd4bd=_0x3cd4bd['concat'](Yt(_0x5ca64f['serverSyncTree_'],_0x30638c,_0x35ef25));const _0x353438=Is(_0x5ca64f,_0x30638c);ct(_0x5ca64f,_0x353438);}),_0x5ca64f['onDisconnect_']=En(),V(_0x5ca64f['eventQueue_'],w(),_0x3cd4bd);}function bd(_0x4f3a67,_0x15ec4d,_0x2a73d5){_0x4f3a67['server_']['onDisconnectCancel'](_0x15ec4d['toString'](),(_0x500c5f,_0xb43ffc)=>{_0x500c5f==='ok'&&Ti(_0x4f3a67['onDisconnect_'],_0x15ec4d),be(_0x4f3a67,_0x2a73d5,_0x500c5f,_0xb43ffc);});}function yr(_0x3707f5,_0x2b6554,_0x34658c,_0x4ceb16){const _0x452667=A(_0x34658c);_0x3707f5['server_']['onDisconnectPut'](_0x2b6554['toString'](),_0x452667['val'](!0x0),(_0x4c1f9c,_0x3a9752)=>{_0x4c1f9c==='ok'&&pt(_0x3707f5['onDisconnect_'],_0x2b6554,_0x452667),be(_0x3707f5,_0x4ceb16,_0x4c1f9c,_0x3a9752);});}function Rd(_0x168454,_0x557d5a,_0x15ea1a,_0x188840,_0x5bd107){const _0x246521=A(_0x15ea1a,_0x188840);_0x168454['server_']['onDisconnectPut'](_0x557d5a['toString'](),_0x246521['val'](!0x0),(_0x419540,_0x2ebbb3)=>{_0x419540==='ok'&&pt(_0x168454['onDisconnect_'],_0x557d5a,_0x246521),be(_0x168454,_0x5bd107,_0x419540,_0x2ebbb3);});}function Ad(_0x99a24b,_0x3b49fe,_0xa037d0,_0x21fcb1){if(pn(_0xa037d0)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x99a24b,_0x21fcb1,'ok',void 0x0);return;}_0x99a24b['server_']['onDisconnectMerge'](_0x3b49fe['toString'](),_0xa037d0,(_0x45a4ba,_0x19e377)=>{_0x45a4ba==='ok'&&x(_0xa037d0,(_0x175318,_0x56ac47)=>{const _0x3fe77e=A(_0x56ac47);pt(_0x99a24b['onDisconnect_'],k(_0x3b49fe,_0x175318),_0x3fe77e);}),be(_0x99a24b,_0x21fcb1,_0x45a4ba,_0x19e377);});}function kd(_0x283ea3,_0x4e3846,_0xbe2449){let _0x2c4bab;y(_0x4e3846['_path'])==='.info'?_0x2c4bab=Ni(_0x283ea3['infoSyncTree_'],_0x4e3846,_0xbe2449):_0x2c4bab=Ni(_0x283ea3['serverSyncTree_'],_0x4e3846,_0xbe2449),oa(_0x283ea3['eventQueue_'],_0x4e3846['_path'],_0x2c4bab);}function Pd(_0x322545,_0x8231a3,_0x3fa591){let _0x4cf144;y(_0x8231a3['_path'])==='.info'?_0x4cf144=An(_0x322545['infoSyncTree_'],_0x8231a3,_0x3fa591):_0x4cf144=An(_0x322545['serverSyncTree_'],_0x8231a3,_0x3fa591),oa(_0x322545['eventQueue_'],_0x8231a3['_path'],_0x4cf144);}function ha(_0x5d7461){_0x5d7461['persistentConnection_']&&_0x5d7461['persistentConnection_']['interrupt'](ca);}function Nd(_0x23f670){_0x23f670['persistentConnection_']&&_0x23f670['persistentConnection_']['resume'](ca);}function gt(_0x6482d1,..._0x49ba9c){let _0xaf80b4='';_0x6482d1['persistentConnection_']&&(_0xaf80b4=_0x6482d1['persistentConnection_']['id']+':'),L(_0xaf80b4,..._0x49ba9c);}function be(_0x53514e,_0x3a590a,_0x35e291,_0x52dea9){_0x3a590a&&ft(()=>{if(_0x35e291==='ok')_0x3a590a(null);else{const _0x135924=(_0x35e291||'error')['toUpperCase']();let _0x59f157=_0x135924;_0x52dea9&&(_0x59f157+=':\x20'+_0x52dea9);const _0x18965c=new Error(_0x59f157);_0x18965c['code']=_0x135924,_0x3a590a(_0x18965c);}});}function Od(_0x1f098e,_0x16a31a,_0x3b6203,_0xbba692,_0x85f01a,_0x20aadc){gt(_0x1f098e,'transaction\x20on\x20'+_0x16a31a);const _0x482694={'path':_0x16a31a,'update':_0x3b6203,'onComplete':_0xbba692,'status':null,'order':so(),'applyLocally':_0x20aadc,'retryCount':0x0,'unwatcher':_0x85f01a,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x480ee5=Es(_0x1f098e,_0x16a31a,void 0x0);_0x482694['currentInputSnapshot']=_0x480ee5;const _0x25ad54=_0x482694['update'](_0x480ee5['val']());if(_0x25ad54===void 0x0)_0x482694['unwatcher'](),_0x482694['currentOutputSnapshotRaw']=null,_0x482694['currentOutputSnapshotResolved']=null,_0x482694['onComplete']&&_0x482694['onComplete'](null,!0x1,_0x482694['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x25ad54,_0x482694['path']),_0x482694['status']=0x0;const _0x44dba5=$n(_0x1f098e['transactionQueueTree_'],_0x16a31a),_0x50c6fc=je(_0x44dba5)||[];_0x50c6fc['push'](_0x482694),gs(_0x44dba5,_0x50c6fc);let _0x6b2589;typeof _0x25ad54=='object'&&_0x25ad54!==null&&Q(_0x25ad54,'.priority')?(_0x6b2589=Le(_0x25ad54,'.priority'),f(Bt(_0x6b2589),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x6b2589=(Vn(_0x1f098e['serverSyncTree_'],_0x16a31a)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3cbb71=Xt(_0x1f098e),_0x21c6e4=A(_0x25ad54,_0x6b2589),_0x4b5455=fs(_0x21c6e4,_0x480ee5,_0x3cbb71);_0x482694['currentOutputSnapshotRaw']=_0x21c6e4,_0x482694['currentOutputSnapshotResolved']=_0x4b5455,_0x482694['currentWriteId']=zn(_0x1f098e);const _0x4d7963=as(_0x1f098e['serverSyncTree_'],_0x16a31a,_0x4b5455,_0x482694['currentWriteId'],_0x482694['applyLocally']);V(_0x1f098e['eventQueue_'],_0x16a31a,_0x4d7963),jn(_0x1f098e,_0x1f098e['transactionQueueTree_']);}}function Es(_0x27c737,_0x493108,_0x38ce6f){return Vn(_0x27c737['serverSyncTree_'],_0x493108,_0x38ce6f)||g['EMPTY_NODE'];}function jn(_0xf900ba,_0x335739=_0xf900ba['transactionQueueTree_']){if(_0x335739||Kn(_0xf900ba,_0x335739),je(_0x335739)){const _0x2c0d8d=da(_0xf900ba,_0x335739);f(_0x2c0d8d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x2c0d8d['every'](_0x4fa15b=>_0x4fa15b['status']===0x0)&&Dd(_0xf900ba,Qt(_0x335739),_0x2c0d8d);}else na(_0x335739)&&Gn(_0x335739,_0x2ca096=>{jn(_0xf900ba,_0x2ca096);});}function Dd(_0x2dc9a,_0x20022f,_0x5c8d38){const _0x33c0df=_0x5c8d38['map'](_0x268f15=>_0x268f15['currentWriteId']),_0x51d9ee=Es(_0x2dc9a,_0x20022f,_0x33c0df);let _0x3c5a12=_0x51d9ee;const _0x4d1602=_0x51d9ee['hash']();for(let _0x5ef0b0=0x0;_0x5ef0b0<_0x5c8d38['length'];_0x5ef0b0++){const _0x5b6ac9=_0x5c8d38[_0x5ef0b0];f(_0x5b6ac9['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5b6ac9['status']=0x1,_0x5b6ac9['retryCount']++;const _0x3a7eae=F(_0x20022f,_0x5b6ac9['path']);_0x3c5a12=_0x3c5a12['updateChild'](_0x3a7eae,_0x5b6ac9['currentOutputSnapshotRaw']);}const _0x2fd232=_0x3c5a12['val'](!0x0),_0x4495ab=_0x20022f;_0x2dc9a['server_']['put'](_0x4495ab['toString'](),_0x2fd232,_0x3d5687=>{gt(_0x2dc9a,'transaction\x20put\x20response',{'path':_0x4495ab['toString'](),'status':_0x3d5687});let _0x53cae3=[];if(_0x3d5687==='ok'){const _0x4772c8=[];for(let _0x59ed69=0x0;_0x59ed69<_0x5c8d38['length'];_0x59ed69++)_0x5c8d38[_0x59ed69]['status']=0x2,_0x53cae3=_0x53cae3['concat'](_e(_0x2dc9a['serverSyncTree_'],_0x5c8d38[_0x59ed69]['currentWriteId'])),_0x5c8d38[_0x59ed69]['onComplete']&&_0x4772c8['push'](()=>_0x5c8d38[_0x59ed69]['onComplete'](null,!0x0,_0x5c8d38[_0x59ed69]['currentOutputSnapshotResolved'])),_0x5c8d38[_0x59ed69]['unwatcher']();Kn(_0x2dc9a,$n(_0x2dc9a['transactionQueueTree_'],_0x20022f)),jn(_0x2dc9a,_0x2dc9a['transactionQueueTree_']),V(_0x2dc9a['eventQueue_'],_0x20022f,_0x53cae3);for(let _0x1c6c18=0x0;_0x1c6c18<_0x4772c8['length'];_0x1c6c18++)ft(_0x4772c8[_0x1c6c18]);}else{if(_0x3d5687==='datastale'){for(let _0x25b981=0x0;_0x25b981<_0x5c8d38['length'];_0x25b981++)_0x5c8d38[_0x25b981]['status']===0x3?_0x5c8d38[_0x25b981]['status']=0x4:_0x5c8d38[_0x25b981]['status']=0x0;}else{U('transaction\x20at\x20'+_0x4495ab['toString']()+'\x20failed:\x20'+_0x3d5687);for(let _0x55a832=0x0;_0x55a832<_0x5c8d38['length'];_0x55a832++)_0x5c8d38[_0x55a832]['status']=0x4,_0x5c8d38[_0x55a832]['abortReason']=_0x3d5687;}ct(_0x2dc9a,_0x20022f);}},_0x4d1602);}function ct(_0x4bf69c,_0xd6ee0c){const _0xc1fa5c=ua(_0x4bf69c,_0xd6ee0c),_0x470205=Qt(_0xc1fa5c),_0x23476b=da(_0x4bf69c,_0xc1fa5c);return Md(_0x4bf69c,_0x23476b,_0x470205),_0x470205;}function Md(_0x1afd89,_0x36f95d,_0x301949){if(_0x36f95d['length']===0x0)return;const _0x3df0f2=[];let _0x3a70b7=[];const _0x4a698e=_0x36f95d['filter'](_0x375182=>_0x375182['status']===0x0)['map'](_0x26adf5=>_0x26adf5['currentWriteId']);for(let _0xe9e0e0=0x0;_0xe9e0e0<_0x36f95d['length'];_0xe9e0e0++){const _0x380a5b=_0x36f95d[_0xe9e0e0],_0x39544d=F(_0x301949,_0x380a5b['path']);let _0x3f1d23=!0x1,_0x1053b1;if(f(_0x39544d!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x380a5b['status']===0x4)_0x3f1d23=!0x0,_0x1053b1=_0x380a5b['abortReason'],_0x3a70b7=_0x3a70b7['concat'](_e(_0x1afd89['serverSyncTree_'],_0x380a5b['currentWriteId'],!0x0));else{if(_0x380a5b['status']===0x0){if(_0x380a5b['retryCount']>=yd)_0x3f1d23=!0x0,_0x1053b1='maxretry',_0x3a70b7=_0x3a70b7['concat'](_e(_0x1afd89['serverSyncTree_'],_0x380a5b['currentWriteId'],!0x0));else{const _0x2fb040=Es(_0x1afd89,_0x380a5b['path'],_0x4a698e);_0x380a5b['currentInputSnapshot']=_0x2fb040;const _0x226abb=_0x36f95d[_0xe9e0e0]['update'](_0x2fb040['val']());if(_0x226abb!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x226abb,_0x380a5b['path']);let _0x2b231d=A(_0x226abb);typeof _0x226abb=='object'&&_0x226abb!=null&&Q(_0x226abb,'.priority')||(_0x2b231d=_0x2b231d['updatePriority'](_0x2fb040['getPriority']()));const _0x451452=_0x380a5b['currentWriteId'],_0xfa6690=Xt(_0x1afd89),_0xeef6a5=fs(_0x2b231d,_0x2fb040,_0xfa6690);_0x380a5b['currentOutputSnapshotRaw']=_0x2b231d,_0x380a5b['currentOutputSnapshotResolved']=_0xeef6a5,_0x380a5b['currentWriteId']=zn(_0x1afd89),_0x4a698e['splice'](_0x4a698e['indexOf'](_0x451452),0x1),_0x3a70b7=_0x3a70b7['concat'](as(_0x1afd89['serverSyncTree_'],_0x380a5b['path'],_0xeef6a5,_0x380a5b['currentWriteId'],_0x380a5b['applyLocally'])),_0x3a70b7=_0x3a70b7['concat'](_e(_0x1afd89['serverSyncTree_'],_0x451452,!0x0));}else _0x3f1d23=!0x0,_0x1053b1='nodata',_0x3a70b7=_0x3a70b7['concat'](_e(_0x1afd89['serverSyncTree_'],_0x380a5b['currentWriteId'],!0x0));}}}V(_0x1afd89['eventQueue_'],_0x301949,_0x3a70b7),_0x3a70b7=[],_0x3f1d23&&(_0x36f95d[_0xe9e0e0]['status']=0x2,function(_0x49a8be){setTimeout(_0x49a8be,Math['floor'](0x0));}(_0x36f95d[_0xe9e0e0]['unwatcher']),_0x36f95d[_0xe9e0e0]['onComplete']&&(_0x1053b1==='nodata'?_0x3df0f2['push'](()=>_0x36f95d[_0xe9e0e0]['onComplete'](null,!0x1,_0x36f95d[_0xe9e0e0]['currentInputSnapshot'])):_0x3df0f2['push'](()=>_0x36f95d[_0xe9e0e0]['onComplete'](new Error(_0x1053b1),!0x1,null))));}Kn(_0x1afd89,_0x1afd89['transactionQueueTree_']);for(let _0x34a561=0x0;_0x34a561<_0x3df0f2['length'];_0x34a561++)ft(_0x3df0f2[_0x34a561]);jn(_0x1afd89,_0x1afd89['transactionQueueTree_']);}function ua(_0x9ab2d8,_0x2ef977){let _0x17e24e,_0xfd3a9f=_0x9ab2d8['transactionQueueTree_'];for(_0x17e24e=y(_0x2ef977);_0x17e24e!==null&&je(_0xfd3a9f)===void 0x0;)_0xfd3a9f=$n(_0xfd3a9f,_0x17e24e),_0x2ef977=S(_0x2ef977),_0x17e24e=y(_0x2ef977);return _0xfd3a9f;}function da(_0xa0a371,_0x1d8332){const _0x20671a=[];return fa(_0xa0a371,_0x1d8332,_0x20671a),_0x20671a['sort']((_0x432260,_0x25f99d)=>_0x432260['order']-_0x25f99d['order']),_0x20671a;}function fa(_0xcd44be,_0x2860c4,_0x41a8dd){const _0x271211=je(_0x2860c4);if(_0x271211){for(let _0x24a6c6=0x0;_0x24a6c6<_0x271211['length'];_0x24a6c6++)_0x41a8dd['push'](_0x271211[_0x24a6c6]);}Gn(_0x2860c4,_0x56e6fe=>{fa(_0xcd44be,_0x56e6fe,_0x41a8dd);});}function Kn(_0x2ab9e9,_0x21a6e6){const _0x2fa4ba=je(_0x21a6e6);if(_0x2fa4ba){let _0x1c51f7=0x0;for(let _0x6cb05b=0x0;_0x6cb05b<_0x2fa4ba['length'];_0x6cb05b++)_0x2fa4ba[_0x6cb05b]['status']!==0x2&&(_0x2fa4ba[_0x1c51f7]=_0x2fa4ba[_0x6cb05b],_0x1c51f7++);_0x2fa4ba['length']=_0x1c51f7,gs(_0x21a6e6,_0x2fa4ba['length']>0x0?_0x2fa4ba:void 0x0);}Gn(_0x21a6e6,_0x22e1eb=>{Kn(_0x2ab9e9,_0x22e1eb);});}function Is(_0x3ed4f6,_0x3266e2){const _0x8fe74e=Qt(ua(_0x3ed4f6,_0x3266e2)),_0x4eb1ca=$n(_0x3ed4f6['transactionQueueTree_'],_0x3266e2);return ad(_0x4eb1ca,_0xd62f3a=>{di(_0x3ed4f6,_0xd62f3a);}),di(_0x3ed4f6,_0x4eb1ca),ia(_0x4eb1ca,_0x2e6530=>{di(_0x3ed4f6,_0x2e6530);}),_0x8fe74e;}function di(_0x30052f,_0x5dd2c7){const _0x3ea833=je(_0x5dd2c7);if(_0x3ea833){const _0x5e339b=[];let _0x2b21e2=[],_0x441ad7=-0x1;for(let _0x28ecf6=0x0;_0x28ecf6<_0x3ea833['length'];_0x28ecf6++)_0x3ea833[_0x28ecf6]['status']===0x3||(_0x3ea833[_0x28ecf6]['status']===0x1?(f(_0x441ad7===_0x28ecf6-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x441ad7=_0x28ecf6,_0x3ea833[_0x28ecf6]['status']=0x3,_0x3ea833[_0x28ecf6]['abortReason']='set'):(f(_0x3ea833[_0x28ecf6]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x3ea833[_0x28ecf6]['unwatcher'](),_0x2b21e2=_0x2b21e2['concat'](_e(_0x30052f['serverSyncTree_'],_0x3ea833[_0x28ecf6]['currentWriteId'],!0x0)),_0x3ea833[_0x28ecf6]['onComplete']&&_0x5e339b['push'](_0x3ea833[_0x28ecf6]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x441ad7===-0x1?gs(_0x5dd2c7,void 0x0):_0x3ea833['length']=_0x441ad7+0x1,V(_0x30052f['eventQueue_'],Qt(_0x5dd2c7),_0x2b21e2);for(let _0x17f3cf=0x0;_0x17f3cf<_0x5e339b['length'];_0x17f3cf++)ft(_0x5e339b[_0x17f3cf]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0xc35149){let _0x5b9cc6='';const _0xa58c30=_0xc35149['split']('/');for(let _0x28f51d=0x0;_0x28f51d<_0xa58c30['length'];_0x28f51d++)if(_0xa58c30[_0x28f51d]['length']>0x0){let _0x4f79fb=_0xa58c30[_0x28f51d];try{_0x4f79fb=decodeURIComponent(_0x4f79fb['replace'](/\+/g,'\x20'));}catch{}_0x5b9cc6+='/'+_0x4f79fb;}return _0x5b9cc6;}function xd(_0xd6d335){const _0x1fee5d={};_0xd6d335['charAt'](0x0)==='?'&&(_0xd6d335=_0xd6d335['substring'](0x1));for(const _0x3ea3cd of _0xd6d335['split']('&')){if(_0x3ea3cd['length']===0x0)continue;const _0x183bee=_0x3ea3cd['split']('=');_0x183bee['length']===0x2?_0x1fee5d[decodeURIComponent(_0x183bee[0x0])]=decodeURIComponent(_0x183bee[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3ea3cd+'\x27\x20in\x20query\x20\x27'+_0xd6d335+'\x27');}return _0x1fee5d;}const vr=function(_0x508719,_0x58fef1){const _0x311117=Fd(_0x508719),_0x2734e7=_0x311117['namespace'];_0x311117['domain']==='firebase.com'&&ae(_0x311117['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2734e7||_0x2734e7==='undefined')&&_0x311117['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x311117['secure']||$l();const _0xba4f08=_0x311117['scheme']==='ws'||_0x311117['scheme']==='wss';return{'repoInfo':new yo(_0x311117['host'],_0x311117['secure'],_0x2734e7,_0xba4f08,_0x58fef1,'',_0x2734e7!==_0x311117['subdomain']),'path':new C(_0x311117['pathString'])};},Fd=function(_0x558674){let _0x261028='',_0x4ea083='',_0x5857d3='',_0xa7a78f='',_0x86c83='',_0x44a078=!0x0,_0x4496d1='https',_0x4f5408=0x1bb;if(typeof _0x558674=='string'){let _0x39d75a=_0x558674['indexOf']('//');_0x39d75a>=0x0&&(_0x4496d1=_0x558674['substring'](0x0,_0x39d75a-0x1),_0x558674=_0x558674['substring'](_0x39d75a+0x2));let _0xa9ff8=_0x558674['indexOf']('/');_0xa9ff8===-0x1&&(_0xa9ff8=_0x558674['length']);let _0x1b40b0=_0x558674['indexOf']('?');_0x1b40b0===-0x1&&(_0x1b40b0=_0x558674['length']),_0x261028=_0x558674['substring'](0x0,Math['min'](_0xa9ff8,_0x1b40b0)),_0xa9ff8<_0x1b40b0&&(_0xa7a78f=Ld(_0x558674['substring'](_0xa9ff8,_0x1b40b0)));const _0x1db5f6=xd(_0x558674['substring'](Math['min'](_0x558674['length'],_0x1b40b0)));_0x39d75a=_0x261028['indexOf'](':'),_0x39d75a>=0x0?(_0x44a078=_0x4496d1==='https'||_0x4496d1==='wss',_0x4f5408=parseInt(_0x261028['substring'](_0x39d75a+0x1),0xa)):_0x39d75a=_0x261028['length'];const _0x2b9f6b=_0x261028['slice'](0x0,_0x39d75a);if(_0x2b9f6b['toLowerCase']()==='localhost')_0x4ea083='localhost';else{if(_0x2b9f6b['split']('.')['length']<=0x2)_0x4ea083=_0x2b9f6b;else{const _0x35d243=_0x261028['indexOf']('.');_0x5857d3=_0x261028['substring'](0x0,_0x35d243)['toLowerCase'](),_0x4ea083=_0x261028['substring'](_0x35d243+0x1),_0x86c83=_0x5857d3;}}'ns'in _0x1db5f6&&(_0x86c83=_0x1db5f6['ns']);}return{'host':_0x261028,'port':_0x4f5408,'domain':_0x4ea083,'subdomain':_0x5857d3,'secure':_0x44a078,'scheme':_0x4496d1,'pathString':_0xa7a78f,'namespace':_0x86c83};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x5398e8=0x0;const _0x119075=[];return function(_0x5282bc){const _0x5120e0=_0x5282bc===_0x5398e8;_0x5398e8=_0x5282bc;let _0x4aa825;const _0x2d75c3=new Array(0x8);for(_0x4aa825=0x7;_0x4aa825>=0x0;_0x4aa825--)_0x2d75c3[_0x4aa825]=Er['charAt'](_0x5282bc%0x40),_0x5282bc=Math['floor'](_0x5282bc/0x40);f(_0x5282bc===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x279b3d=_0x2d75c3['join']('');if(_0x5120e0){for(_0x4aa825=0xb;_0x4aa825>=0x0&&_0x119075[_0x4aa825]===0x3f;_0x4aa825--)_0x119075[_0x4aa825]=0x0;_0x119075[_0x4aa825]++;}else{for(_0x4aa825=0x0;_0x4aa825<0xc;_0x4aa825++)_0x119075[_0x4aa825]=Math['floor'](Math['random']()*0x40);}for(_0x4aa825=0x0;_0x4aa825<0xc;_0x4aa825++)_0x279b3d+=Er['charAt'](_0x119075[_0x4aa825]);return f(_0x279b3d['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x279b3d;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x561dd5,_0x519ab7,_0xc9a733,_0xa23c4e){this['eventType']=_0x561dd5,this['eventRegistration']=_0x519ab7,this['snapshot']=_0xc9a733,this['prevName']=_0xa23c4e;}['getPath'](){const _0x2b120a=this['snapshot']['ref'];return this['eventType']==='value'?_0x2b120a['_path']:_0x2b120a['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x7adeb1,_0x503483,_0xdf85c4){this['eventRegistration']=_0x7adeb1,this['error']=_0x503483,this['path']=_0xdf85c4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3a853c,_0x2c4da3){this['snapshotCallback']=_0x3a853c,this['cancelCallback']=_0x2c4da3;}['onValue'](_0x106bd1,_0x3d8393){this['snapshotCallback']['call'](null,_0x106bd1,_0x3d8393);}['onCancel'](_0x5e8fae){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x5e8fae);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x7a0adf){return this['snapshotCallback']===_0x7a0adf['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x7a0adf['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x7a0adf['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2b2cb1,_0xaad6a3){this['_repo']=_0x2b2cb1,this['_path']=_0xaad6a3;}['cancel'](){const _0x3b1a54=new H();return bd(this['_repo'],this['_path'],_0x3b1a54['wrapCallback'](()=>{})),_0x3b1a54['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x54a377=new H();return yr(this['_repo'],this['_path'],null,_0x54a377['wrapCallback'](()=>{})),_0x54a377['promise'];}['set'](_0x44c408){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x44c408,this['_path'],!0x1);const _0x10de19=new H();return yr(this['_repo'],this['_path'],_0x44c408,_0x10de19['wrapCallback'](()=>{})),_0x10de19['promise'];}['setWithPriority'](_0x323168,_0x2cf850){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x323168,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x2cf850);const _0x5f5c98=new H();return Rd(this['_repo'],this['_path'],_0x323168,_0x2cf850,_0x5f5c98['wrapCallback'](()=>{})),_0x5f5c98['promise'];}['update'](_0x1903ad){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1903ad,this['_path']);const _0x52eb24=new H();return Ad(this['_repo'],this['_path'],_0x1903ad,_0x52eb24['wrapCallback'](()=>{})),_0x52eb24['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x495d64,_0x188e4d,_0x401795,_0x25daca){this['_repo']=_0x495d64,this['_path']=_0x188e4d,this['_queryParams']=_0x401795,this['_orderByCalled']=_0x25daca;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2ca50e=sr(this['_queryParams']),_0x132883=$i(_0x2ca50e);return _0x132883==='{}'?'default':_0x132883;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x4bd4c7){if(_0x4bd4c7=P(_0x4bd4c7),!(_0x4bd4c7 instanceof Ae))return!0x1;const _0x54ced6=this['_repo']===_0x4bd4c7['_repo'],_0x169dae=Ki(this['_path'],_0x4bd4c7['_path']),_0x4cdfd7=this['_queryIdentifier']===_0x4bd4c7['_queryIdentifier'];return _0x54ced6&&_0x169dae&&_0x4cdfd7;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x597eb4,_0x2ece39){if(_0x597eb4['_orderByCalled']===!0x0)throw new Error(_0x2ece39+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2f4b5c){let _0x17970f=null,_0x4f02a4=null;if(_0x2f4b5c['hasStart']()&&(_0x17970f=_0x2f4b5c['getIndexStartValue']()),_0x2f4b5c['hasEnd']()&&(_0x4f02a4=_0x2f4b5c['getIndexEndValue']()),_0x2f4b5c['getIndex']()===ve){const _0x1f0bc5='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x273237='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2f4b5c['hasStart']()){if(_0x2f4b5c['getIndexStartName']()!==We)throw new Error(_0x1f0bc5);if(typeof _0x17970f!='string')throw new Error(_0x273237);}if(_0x2f4b5c['hasEnd']()){if(_0x2f4b5c['getIndexEndName']()!==we)throw new Error(_0x1f0bc5);if(typeof _0x4f02a4!='string')throw new Error(_0x273237);}}else{if(_0x2f4b5c['getIndex']()===R){if(_0x17970f!=null&&!Bt(_0x17970f)||_0x4f02a4!=null&&!Bt(_0x4f02a4))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2f4b5c['getIndex']()instanceof Ji||_0x2f4b5c['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x17970f!=null&&typeof _0x17970f=='object'||_0x4f02a4!=null&&typeof _0x4f02a4=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x12854c){if(_0x12854c['hasStart']()&&_0x12854c['hasEnd']()&&_0x12854c['hasLimit']()&&!_0x12854c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x3b3f82,_0xba96ad){super(_0x3b3f82,_0xba96ad,new Zi(),!0x1);}get['parent'](){const _0x498c43=Ro(this['_path']);return _0x498c43===null?null:new ee(this['_repo'],_0x498c43);}get['root'](){let _0x48fd13=this;for(;_0x48fd13['parent']!==null;)_0x48fd13=_0x48fd13['parent'];return _0x48fd13;}}class lt{constructor(_0x438d27,_0xe11f8a,_0x460acf){this['_node']=_0x438d27,this['ref']=_0xe11f8a,this['_index']=_0x460acf;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x434053){const _0x20b8bd=new C(_0x434053),_0x2b2635=Vt(this['ref'],_0x434053);return new lt(this['_node']['getChild'](_0x20b8bd),_0x2b2635,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xe4abc3){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5b4736,_0x163f87)=>_0xe4abc3(new lt(_0x163f87,Vt(this['ref'],_0x5b4736),R)));}['hasChild'](_0x46b8d6){const _0x24b19f=new C(_0x46b8d6);return!this['_node']['getChild'](_0x24b19f)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x54b31a,_0x53c89d){return _0x54b31a=P(_0x54b31a),_0x54b31a['_checkNotDeleted']('ref'),_0x53c89d!==void 0x0?Vt(_0x54b31a['_root'],_0x53c89d):_0x54b31a['_root'];}function Vt(_0x5929b8,_0x447693){return _0x5929b8=P(_0x5929b8),y(_0x5929b8['_path'])===null?pd('child','path',_0x447693):ys('child','path',_0x447693),new ee(_0x5929b8['_repo'],k(_0x5929b8['_path'],_0x447693));}function v_(_0x40e919){return _0x40e919=P(_0x40e919),new Vd(_0x40e919['_repo'],_0x40e919['_path']);}function E_(_0x1e5ff3,_0xfd891d){_0x1e5ff3=P(_0x1e5ff3),Me('push',_0x1e5ff3['_path']),He('push',_0xfd891d,_0x1e5ff3['_path'],!0x0);const _0x487da7=la(_0x1e5ff3['_repo']),_0x50c16e=Ud(_0x487da7),_0x1d3549=Vt(_0x1e5ff3,_0x50c16e),_0x4d6229=Vt(_0x1e5ff3,_0x50c16e);let _0x1cea17;return _0xfd891d!=null?_0x1cea17=Hd(_0x4d6229,_0xfd891d)['then'](()=>_0x4d6229):_0x1cea17=Promise['resolve'](_0x4d6229),_0x1d3549['then']=_0x1cea17['then']['bind'](_0x1cea17),_0x1d3549['catch']=_0x1cea17['then']['bind'](_0x1cea17,void 0x0),_0x1d3549;}function Hd(_0x12b07b,_0x3d25ea){_0x12b07b=P(_0x12b07b),Me('set',_0x12b07b['_path']),He('set',_0x3d25ea,_0x12b07b['_path'],!0x1);const _0x5bb593=new H();return Cd(_0x12b07b['_repo'],_0x12b07b['_path'],_0x3d25ea,null,_0x5bb593['wrapCallback'](()=>{})),_0x5bb593['promise'];}function I_(_0x242dd7,_0x4f364a){ra('update',_0x4f364a,_0x242dd7['_path']);const _0x473185=new H();return Td(_0x242dd7['_repo'],_0x242dd7['_path'],_0x4f364a,_0x473185['wrapCallback'](()=>{})),_0x473185['promise'];}function w_(_0x444df8){_0x444df8=P(_0x444df8);const _0x55622a=new pa(()=>{}),_0x497721=new Qn(_0x55622a);return wd(_0x444df8['_repo'],_0x444df8,_0x497721)['then'](_0x26cda9=>new lt(_0x26cda9,new ee(_0x444df8['_repo'],_0x444df8['_path']),_0x444df8['_queryParams']['getIndex']()));}class Qn{constructor(_0x211786){this['callbackContext']=_0x211786;}['respondsTo'](_0x172317){return _0x172317==='value';}['createEvent'](_0x32dea7,_0x18c505){const _0x3f68af=_0x18c505['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x32dea7['snapshotNode'],new ee(_0x18c505['_repo'],_0x18c505['_path']),_0x3f68af));}['getEventRunner'](_0x1ce2a1){return _0x1ce2a1['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1ce2a1['error']):()=>this['callbackContext']['onValue'](_0x1ce2a1['snapshot'],null);}['createCancelEvent'](_0xcbf68,_0x17142e){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xcbf68,_0x17142e):null;}['matches'](_0xcaccd1){return _0xcaccd1 instanceof Qn?!_0xcaccd1['callbackContext']||!this['callbackContext']?!0x0:_0xcaccd1['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x58b0b4,_0x33d742,_0x5084da,_0x3262c1,_0x516166){const _0x5ccae4=new pa(_0x5084da,void 0x0),_0x3481aa=new Qn(_0x5ccae4);return kd(_0x58b0b4['_repo'],_0x58b0b4,_0x3481aa),()=>Pd(_0x58b0b4['_repo'],_0x58b0b4,_0x3481aa);}function Gd(_0x4284c3,_0x40b7e1,_0x3e2ac1,_0x23759e){return $d(_0x4284c3,'value',_0x40b7e1);}class mt{}class ma extends mt{constructor(_0xe9758,_0x1d8b65){super(),this['_value']=_0xe9758,this['_key']=_0x1d8b65,this['type']='endAt';}['_apply'](_0x10bc67){He('endAt',this['_value'],_0x10bc67['_path'],!0x0);const _0x61e4b4=Jh(_0x10bc67['_queryParams'],this['_value'],this['_key']);if(ga(_0x61e4b4),Yn(_0x61e4b4),_0x10bc67['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x10bc67['_repo'],_0x10bc67['_path'],_0x61e4b4,_0x10bc67['_orderByCalled']);}}function C_(_0x2b7883,_0xc06246){return new ma(_0x2b7883,_0xc06246);}class ya extends mt{constructor(_0x1be2b4,_0x13f884){super(),this['_value']=_0x1be2b4,this['_key']=_0x13f884,this['type']='startAt';}['_apply'](_0x5e676f){He('startAt',this['_value'],_0x5e676f['_path'],!0x0);const _0x170ec8=Qh(_0x5e676f['_queryParams'],this['_value'],this['_key']);if(ga(_0x170ec8),Yn(_0x170ec8),_0x5e676f['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5e676f['_repo'],_0x5e676f['_path'],_0x170ec8,_0x5e676f['_orderByCalled']);}}function T_(_0x8e0374=null,_0x13cfe8){return new ya(_0x8e0374,_0x13cfe8);}class qd extends mt{constructor(_0x53380d){super(),this['_limit']=_0x53380d,this['type']='limitToFirst';}['_apply'](_0x564067){if(_0x564067['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x564067['_repo'],_0x564067['_path'],Yh(_0x564067['_queryParams'],this['_limit']),_0x564067['_orderByCalled']);}}function S_(_0x4c3e83){if(Math['floor'](_0x4c3e83)!==_0x4c3e83||_0x4c3e83<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x4c3e83);}class zd extends mt{constructor(_0x252612){super(),this['_path']=_0x252612,this['type']='orderByChild';}['_apply'](_0x732935){_a(_0x732935,'orderByChild');const _0x5582c=new C(this['_path']);if(v(_0x5582c))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5c5870=new Ji(_0x5582c),_0x1bda5d=xo(_0x732935['_queryParams'],_0x5c5870);return Yn(_0x1bda5d),new Ae(_0x732935['_repo'],_0x732935['_path'],_0x1bda5d,!0x0);}}function b_(_0x53df2a){if(_0x53df2a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x53df2a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x53df2a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x53df2a),new zd(_0x53df2a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xf321d6){_a(_0xf321d6,'orderByKey');const _0x1089b1=xo(_0xf321d6['_queryParams'],ve);return Yn(_0x1089b1),new Ae(_0xf321d6['_repo'],_0xf321d6['_path'],_0x1089b1,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x135fe0,_0x55df86){super(),this['_value']=_0x135fe0,this['_key']=_0x55df86,this['type']='equalTo';}['_apply'](_0x297c9b){if(He('equalTo',this['_value'],_0x297c9b['_path'],!0x1),_0x297c9b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x297c9b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x297c9b));}}function A_(_0x4b6011,_0x14e225){return new Kd(_0x4b6011,_0x14e225);}function k_(_0x944311,..._0x4a3735){let _0x48bd41=P(_0x944311);for(const _0x2c6118 of _0x4a3735)_0x48bd41=_0x2c6118['_apply'](_0x48bd41);return _0x48bd41;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0xd75981,_0x5761e0,_0x3736a4,_0x72380a){const _0x5314f1=_0x5761e0['lastIndexOf'](':'),_0x4f06b6=_0x5761e0['substring'](0x0,_0x5314f1),_0x3cb971=qt(_0x4f06b6);_0xd75981['repoInfo_']=new yo(_0x5761e0,_0x3cb971,_0xd75981['repoInfo_']['namespace'],_0xd75981['repoInfo_']['webSocketOnly'],_0xd75981['repoInfo_']['nodeAdmin'],_0xd75981['repoInfo_']['persistenceKey'],_0xd75981['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x3736a4),_0x72380a&&(_0xd75981['authTokenProvider_']=_0x72380a);}function Xd(_0x5cbf49,_0x3aeab9,_0x2d3cc6,_0x4483eb,_0x2fa900){let _0x284db8=_0x4483eb||_0x5cbf49['options']['databaseURL'];_0x284db8===void 0x0&&(_0x5cbf49['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5cbf49['options']['projectId']),_0x284db8=_0x5cbf49['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4598e4=vr(_0x284db8,_0x2fa900),_0x237189=_0x4598e4['repoInfo'],_0x359aa5;typeof process<'u'&&Bs&&(_0x359aa5=Bs[Yd]),_0x359aa5?(_0x284db8='http://'+_0x359aa5+'?ns='+_0x237189['namespace'],_0x4598e4=vr(_0x284db8,_0x2fa900),_0x237189=_0x4598e4['repoInfo']):_0x4598e4['repoInfo']['secure'];const _0x15055b=new eh(_0x5cbf49['name'],_0x5cbf49['options'],_0x3aeab9);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4598e4),v(_0x4598e4['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x265968=ef(_0x237189,_0x5cbf49,_0x15055b,new Zl(_0x5cbf49,_0x2d3cc6));return new tf(_0x265968,_0x5cbf49);}function Zd(_0x202632,_0x2a5d44){const _0x15c7ea=Di[_0x2a5d44];(!_0x15c7ea||_0x15c7ea[_0x202632['key']]!==_0x202632)&&ae('Database\x20'+_0x2a5d44+'('+_0x202632['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x202632),delete _0x15c7ea[_0x202632['key']];}function ef(_0x1b8d9c,_0x170309,_0x25123b,_0xa774a){let _0x4bbb4d=Di[_0x170309['name']];_0x4bbb4d||(_0x4bbb4d={},Di[_0x170309['name']]=_0x4bbb4d);let _0x155952=_0x4bbb4d[_0x1b8d9c['toURLString']()];return _0x155952&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x155952=new vd(_0x1b8d9c,Qd,_0x25123b,_0xa774a),_0x4bbb4d[_0x1b8d9c['toURLString']()]=_0x155952,_0x155952;}class tf{constructor(_0x14143f,_0x46a238){this['_repoInternal']=_0x14143f,this['app']=_0x46a238,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x33ca2b){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x33ca2b+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x262c05=Zr(),_0x311f79){const _0x36a203=Hi(_0x262c05,'database')['getImmediate']({'identifier':_0x311f79});if(!_0x36a203['_instanceStarted']){const _0x224206=hc('database');_0x224206&&nf(_0x36a203,..._0x224206);}return _0x36a203;}function nf(_0x57976,_0x3f2158,_0x1b8adc,_0x5890fb={}){_0x57976=P(_0x57976),_0x57976['_checkNotDeleted']('useEmulator');const _0x155fd5=_0x3f2158+':'+_0x1b8adc,_0x2574af=_0x57976['_repoInternal'];if(_0x57976['_instanceStarted']){if(_0x155fd5===_0x57976['_repoInternal']['repoInfo_']['host']&&xe(_0x5890fb,_0x2574af['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x175002;if(_0x2574af['repoInfo_']['nodeAdmin'])_0x5890fb['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x175002=new an(an['OWNER']);else{if(_0x5890fb['mockUserToken']){const _0x3c4800=typeof _0x5890fb['mockUserToken']=='string'?_0x5890fb['mockUserToken']:uc(_0x5890fb['mockUserToken'],_0x57976['app']['options']['projectId']);_0x175002=new an(_0x3c4800);}}qt(_0x3f2158)&&Qr(_0x3f2158),Jd(_0x2574af,_0x155fd5,_0x5890fb,_0x175002);}function N_(_0x2cafd0){_0x2cafd0=P(_0x2cafd0),_0x2cafd0['_checkNotDeleted']('goOffline'),ha(_0x2cafd0['_repo']);}function O_(_0x3b1fdc){_0x3b1fdc=P(_0x3b1fdc),_0x3b1fdc['_checkNotDeleted']('goOnline'),Nd(_0x3b1fdc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x3c217a){Ul(dt),st(new Fe('database',(_0x2c4afd,{instanceIdentifier:_0x4f3060})=>{const _0x2e9e26=_0x2c4afd['getProvider']('app')['getImmediate'](),_0xb9eee0=_0x2c4afd['getProvider']('auth-internal'),_0x1859b3=_0x2c4afd['getProvider']('app-check-internal');return Xd(_0x2e9e26,_0xb9eee0,_0x1859b3,_0x4f3060);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x3c217a),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x55841b,_0x96865c){this['committed']=_0x55841b,this['snapshot']=_0x96865c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x5064c2,_0x3e0d5a,_0x665147){if(_0x5064c2=P(_0x5064c2),Me('Reference.transaction',_0x5064c2['_path']),_0x5064c2['key']==='.length'||_0x5064c2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5064c2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x11a0b9=!0x0,_0x2eb856=new H(),_0x41f7cb=(_0x819bda,_0x1bc82f,_0x29e601)=>{let _0x577e95=null;_0x819bda?_0x2eb856['reject'](_0x819bda):(_0x577e95=new lt(_0x29e601,new ee(_0x5064c2['_repo'],_0x5064c2['_path']),R),_0x2eb856['resolve'](new of(_0x1bc82f,_0x577e95)));},_0x272184=Gd(_0x5064c2,()=>{});return Od(_0x5064c2['_repo'],_0x5064c2['_path'],_0x3e0d5a,_0x41f7cb,_0x272184,_0x11a0b9),_0x2eb856['promise'];}se['prototype']['simpleListen']=function(_0x52d515,_0x3ba451){this['sendRequest']('q',{'p':_0x52d515},_0x3ba451);},se['prototype']['echo']=function(_0x4defc8,_0x97e318){this['sendRequest']('echo',{'d':_0x4defc8},_0x97e318);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x16af3c,..._0x1cb453){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x16af3c,..._0x1cb453);}function cn(_0x1f259d,..._0x31186a){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x1f259d,..._0x31186a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x54610a,..._0x26f9c7){throw ws(_0x54610a,..._0x26f9c7);}function X(_0x48ce09,..._0x318f9b){return ws(_0x48ce09,..._0x318f9b);}function Ia(_0x122c51,_0x41051a,_0x11b9ca){const _0x585ff9={...af(),[_0x41051a]:_0x11b9ca};return new Gt('auth','Firebase',_0x585ff9)['create'](_0x41051a,{'appName':_0x122c51['name']});}function re(_0x3ccdd8){return Ia(_0x3ccdd8,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x3ee781,..._0x21b08d){if(typeof _0x3ee781!='string'){const _0x5ad98d=_0x21b08d[0x0],_0x45d85a=[..._0x21b08d['slice'](0x1)];return _0x45d85a[0x0]&&(_0x45d85a[0x0]['appName']=_0x3ee781['name']),_0x3ee781['_errorFactory']['create'](_0x5ad98d,..._0x45d85a);}return Ea['create'](_0x3ee781,..._0x21b08d);}function m(_0x138995,_0x5f24da,..._0x57b01){if(!_0x138995)throw ws(_0x5f24da,..._0x57b01);}function ne(_0x2f7721){const _0xe152c9='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2f7721;throw cn(_0xe152c9),new Error(_0xe152c9);}function ce(_0x35bc76,_0x2495ed){_0x35bc76||ne(_0x2495ed);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x5ef3a5;return typeof self<'u'&&((_0x5ef3a5=self['location'])==null?void 0x0:_0x5ef3a5['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x38b11f;return typeof self<'u'&&((_0x38b11f=self['location'])==null?void 0x0:_0x38b11f['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x2e6255=navigator;return _0x2e6255['languages']&&_0x2e6255['languages'][0x0]||_0x2e6255['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x648393,_0xbd4375){this['shortDelay']=_0x648393,this['longDelay']=_0xbd4375,ce(_0xbd4375>_0x648393,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x27e31f,_0x5e0938){ce(_0x27e31f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3edd1a}=_0x27e31f['emulator'];return _0x5e0938?''+_0x3edd1a+(_0x5e0938['startsWith']('/')?_0x5e0938['slice'](0x1):_0x5e0938):_0x3edd1a;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x130703,_0x153c3b,_0x32bda8){this['fetchImpl']=_0x130703,_0x153c3b&&(this['headersImpl']=_0x153c3b),_0x32bda8&&(this['responseImpl']=_0x32bda8);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0xbfb350,_0x3ce5b1){return _0xbfb350['tenantId']&&!_0x3ce5b1['tenantId']?{..._0x3ce5b1,'tenantId':_0xbfb350['tenantId']}:_0x3ce5b1;}async function Pe(_0x2503fd,_0x3bf12f,_0xb7bf5e,_0x81cc89,_0x3ee979={}){return Ca(_0x2503fd,_0x3ee979,async()=>{let _0x1cfee7={},_0x9b3384={};_0x81cc89&&(_0x3bf12f==='GET'?_0x9b3384=_0x81cc89:_0x1cfee7={'body':JSON['stringify'](_0x81cc89)});const _0x401e21=ut({..._0x9b3384,'key':_0x2503fd['config']['apiKey']})['slice'](0x1),_0x285b0c=await _0x2503fd['_getAdditionalHeaders']();_0x285b0c['Content-Type']='application/json',_0x2503fd['languageCode']&&(_0x285b0c['X-Firebase-Locale']=_0x2503fd['languageCode']);const _0x55237c={'method':_0x3bf12f,'headers':_0x285b0c,..._0x1cfee7};return dc()||(_0x55237c['referrerPolicy']='strict-origin-when-cross-origin'),_0x2503fd['emulatorConfig']&&qt(_0x2503fd['emulatorConfig']['host'])&&(_0x55237c['credentials']='include'),wa['fetch']()(await Ta(_0x2503fd,_0x2503fd['config']['apiHost'],_0xb7bf5e,_0x401e21),_0x55237c);});}async function Ca(_0xf0c1fe,_0x12bda0,_0x9c193e){_0xf0c1fe['_canInitEmulator']=!0x1;const _0x4dd8bc={...df,..._0x12bda0};try{const _0x39bed5=new gf(_0xf0c1fe),_0x2b08e0=await Promise['race']([_0x9c193e(),_0x39bed5['promise']]);_0x39bed5['clearNetworkTimeout']();const _0x342f9d=await _0x2b08e0['json']();if('needConfirmation'in _0x342f9d)throw on(_0xf0c1fe,'account-exists-with-different-credential',_0x342f9d);if(_0x2b08e0['ok']&&!('errorMessage'in _0x342f9d))return _0x342f9d;{const _0x5b7bd0=_0x2b08e0['ok']?_0x342f9d['errorMessage']:_0x342f9d['error']['message'],[_0x565abd,_0x28cf3a]=_0x5b7bd0['split']('\x20:\x20');if(_0x565abd==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0xf0c1fe,'credential-already-in-use',_0x342f9d);if(_0x565abd==='EMAIL_EXISTS')throw on(_0xf0c1fe,'email-already-in-use',_0x342f9d);if(_0x565abd==='USER_DISABLED')throw on(_0xf0c1fe,'user-disabled',_0x342f9d);const _0xcdf321=_0x4dd8bc[_0x565abd]||_0x565abd['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x28cf3a)throw Ia(_0xf0c1fe,_0xcdf321,_0x28cf3a);Y(_0xf0c1fe,_0xcdf321);}}catch(_0x4aa203){if(_0x4aa203 instanceof Re)throw _0x4aa203;Y(_0xf0c1fe,'network-request-failed',{'message':String(_0x4aa203)});}}async function en(_0x44767d,_0x585280,_0x7b03a4,_0x556a51,_0xa6a2ed={}){const _0x17bb3d=await Pe(_0x44767d,_0x585280,_0x7b03a4,_0x556a51,_0xa6a2ed);return'mfaPendingCredential'in _0x17bb3d&&Y(_0x44767d,'multi-factor-auth-required',{'_serverResponse':_0x17bb3d}),_0x17bb3d;}async function Ta(_0x3db5bc,_0x2615d6,_0x4cb4ef,_0x4e4c4e){const _0x2fcb30=''+_0x2615d6+_0x4cb4ef+'?'+_0x4e4c4e,_0x59bda2=_0x3db5bc,_0x3c6f39=_0x59bda2['config']['emulator']?Cs(_0x3db5bc['config'],_0x2fcb30):_0x3db5bc['config']['apiScheme']+'://'+_0x2fcb30;return ff['includes'](_0x4cb4ef)&&(await _0x59bda2['_persistenceManagerAvailable'],_0x59bda2['_getPersistenceType']()==='COOKIE')?_0x59bda2['_getPersistence']()['_getFinalTarget'](_0x3c6f39)['toString']():_0x3c6f39;}function _f(_0x497ff0){switch(_0x497ff0){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5bc664){this['auth']=_0x5bc664,this['timer']=null,this['promise']=new Promise((_0x56f389,_0x5b612e)=>{this['timer']=setTimeout(()=>_0x5b612e(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x23fa07,_0x54d855,_0x2f4daf){const _0x4ca750={'appName':_0x23fa07['name']};_0x2f4daf['email']&&(_0x4ca750['email']=_0x2f4daf['email']),_0x2f4daf['phoneNumber']&&(_0x4ca750['phoneNumber']=_0x2f4daf['phoneNumber']);const _0x69b9e1=X(_0x23fa07,_0x54d855,_0x4ca750);return _0x69b9e1['customData']['_tokenResponse']=_0x2f4daf,_0x69b9e1;}function wr(_0x4de578){return _0x4de578!==void 0x0&&_0x4de578['enterprise']!==void 0x0;}class mf{constructor(_0x4a21b7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4a21b7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4a21b7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4a21b7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2ab329){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xd50fcd of this['recaptchaEnforcementState'])if(_0xd50fcd['provider']&&_0xd50fcd['provider']===_0x2ab329)return _f(_0xd50fcd['enforcementState']);return null;}['isProviderEnabled'](_0x1a76df){return this['getProviderEnforcementState'](_0x1a76df)==='ENFORCE'||this['getProviderEnforcementState'](_0x1a76df)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x90e858,_0x1ef76e){return Pe(_0x90e858,'GET','/v2/recaptchaConfig',ke(_0x90e858,_0x1ef76e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x8d1d6c,_0x2a021d){return Pe(_0x8d1d6c,'POST','/v1/accounts:delete',_0x2a021d);}async function Pn(_0x315884,_0x3f7445){return Pe(_0x315884,'POST','/v1/accounts:lookup',_0x3f7445);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x344646){if(_0x344646)try{const _0x691a2b=new Date(Number(_0x344646));if(!isNaN(_0x691a2b['getTime']()))return _0x691a2b['toUTCString']();}catch{}}async function Ef(_0x4d2700,_0x5620b2=!0x1){const _0x4412e1=P(_0x4d2700),_0x2f9a78=await _0x4412e1['getIdToken'](_0x5620b2),_0x33fafb=Ts(_0x2f9a78);m(_0x33fafb&&_0x33fafb['exp']&&_0x33fafb['auth_time']&&_0x33fafb['iat'],_0x4412e1['auth'],'internal-error');const _0x27b518=typeof _0x33fafb['firebase']=='object'?_0x33fafb['firebase']:void 0x0,_0xe158d2=_0x27b518==null?void 0x0:_0x27b518['sign_in_provider'];return{'claims':_0x33fafb,'token':_0x2f9a78,'authTime':Pt(fi(_0x33fafb['auth_time'])),'issuedAtTime':Pt(fi(_0x33fafb['iat'])),'expirationTime':Pt(fi(_0x33fafb['exp'])),'signInProvider':_0xe158d2||null,'signInSecondFactor':(_0x27b518==null?void 0x0:_0x27b518['sign_in_second_factor'])||null};}function fi(_0x5bad77){return Number(_0x5bad77)*0x3e8;}function Ts(_0xee48d9){const [_0x4f1da5,_0x3ec27,_0x9037b6]=_0xee48d9['split']('.');if(_0x4f1da5===void 0x0||_0x3ec27===void 0x0||_0x9037b6===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2da283=fn(_0x3ec27);return _0x2da283?JSON['parse'](_0x2da283):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x13de6b){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x13de6b==null?void 0x0:_0x13de6b['toString']()),null;}}function Cr(_0x21f928){const _0x314463=Ts(_0x21f928);return m(_0x314463,'internal-error'),m(typeof _0x314463['exp']<'u','internal-error'),m(typeof _0x314463['iat']<'u','internal-error'),Number(_0x314463['exp'])-Number(_0x314463['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4de352,_0x58b0f8,_0x17fd2f=!0x1){if(_0x17fd2f)return _0x58b0f8;try{return await _0x58b0f8;}catch(_0x1ea97a){throw _0x1ea97a instanceof Re&&If(_0x1ea97a)&&_0x4de352['auth']['currentUser']===_0x4de352&&await _0x4de352['auth']['signOut'](),_0x1ea97a;}}function If({code:_0x1a330f}){return _0x1a330f==='auth/user-disabled'||_0x1a330f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x252ce4){this['user']=_0x252ce4,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x33bc78){if(_0x33bc78){const _0x5932aa=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x5932aa;}else{this['errorBackoff']=0x7530;const _0x495c57=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x495c57);}}['schedule'](_0x47ed94=!0x1){if(!this['isRunning'])return;const _0x437e3b=this['getInterval'](_0x47ed94);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x437e3b);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2bcc59){(_0x2bcc59==null?void 0x0:_0x2bcc59['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x43b9ce,_0x16f651){this['createdAt']=_0x43b9ce,this['lastLoginAt']=_0x16f651,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x399e0c){this['createdAt']=_0x399e0c['createdAt'],this['lastLoginAt']=_0x399e0c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x5db8a7){var _0x5904a8;const _0x1f4198=_0x5db8a7['auth'],_0xd3df4f=await _0x5db8a7['getIdToken'](),_0x2890b7=await Ht(_0x5db8a7,Pn(_0x1f4198,{'idToken':_0xd3df4f}));m(_0x2890b7==null?void 0x0:_0x2890b7['users']['length'],_0x1f4198,'internal-error');const _0x1e6138=_0x2890b7['users'][0x0];_0x5db8a7['_notifyReloadListener'](_0x1e6138);const _0xc31101=(_0x5904a8=_0x1e6138['providerUserInfo'])!=null&&_0x5904a8['length']?Sa(_0x1e6138['providerUserInfo']):[],_0x32f3b6=Tf(_0x5db8a7['providerData'],_0xc31101),_0x1170a4=_0x5db8a7['isAnonymous'],_0x29ddc2=!(_0x5db8a7['email']&&_0x1e6138['passwordHash'])&&!(_0x32f3b6!=null&&_0x32f3b6['length']),_0x96a312=_0x1170a4?_0x29ddc2:!0x1,_0x1940a0={'uid':_0x1e6138['localId'],'displayName':_0x1e6138['displayName']||null,'photoURL':_0x1e6138['photoUrl']||null,'email':_0x1e6138['email']||null,'emailVerified':_0x1e6138['emailVerified']||!0x1,'phoneNumber':_0x1e6138['phoneNumber']||null,'tenantId':_0x1e6138['tenantId']||null,'providerData':_0x32f3b6,'metadata':new Li(_0x1e6138['createdAt'],_0x1e6138['lastLoginAt']),'isAnonymous':_0x96a312};Object['assign'](_0x5db8a7,_0x1940a0);}async function Cf(_0x381b57){const _0x449c66=P(_0x381b57);await Nn(_0x449c66),await _0x449c66['auth']['_persistUserIfCurrent'](_0x449c66),_0x449c66['auth']['_notifyListenersIfCurrent'](_0x449c66);}function Tf(_0x58361f,_0x4b8202){return[..._0x58361f['filter'](_0x6a7295=>!_0x4b8202['some'](_0x1d501a=>_0x1d501a['providerId']===_0x6a7295['providerId'])),..._0x4b8202];}function Sa(_0x262821){return _0x262821['map'](({providerId:_0x4d2a93,..._0x5b4a87})=>({'providerId':_0x4d2a93,'uid':_0x5b4a87['rawId']||'','displayName':_0x5b4a87['displayName']||null,'email':_0x5b4a87['email']||null,'phoneNumber':_0x5b4a87['phoneNumber']||null,'photoURL':_0x5b4a87['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x18cd9a,_0x3f2a77){const _0x12ee06=await Ca(_0x18cd9a,{},async()=>{const _0x299e32=ut({'grant_type':'refresh_token','refresh_token':_0x3f2a77})['slice'](0x1),{tokenApiHost:_0x283e25,apiKey:_0x516ffe}=_0x18cd9a['config'],_0x3a6aa5=await Ta(_0x18cd9a,_0x283e25,'/v1/token','key='+_0x516ffe),_0x4cfdc1=await _0x18cd9a['_getAdditionalHeaders']();_0x4cfdc1['Content-Type']='application/x-www-form-urlencoded';const _0x5e720f={'method':'POST','headers':_0x4cfdc1,'body':_0x299e32};return _0x18cd9a['emulatorConfig']&&qt(_0x18cd9a['emulatorConfig']['host'])&&(_0x5e720f['credentials']='include'),wa['fetch']()(_0x3a6aa5,_0x5e720f);});return{'accessToken':_0x12ee06['access_token'],'expiresIn':_0x12ee06['expires_in'],'refreshToken':_0x12ee06['refresh_token']};}async function bf(_0x180eba,_0x459f67){return Pe(_0x180eba,'POST','/v2/accounts:revokeToken',ke(_0x180eba,_0x459f67));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x24e2c5){m(_0x24e2c5['idToken'],'internal-error'),m(typeof _0x24e2c5['idToken']<'u','internal-error'),m(typeof _0x24e2c5['refreshToken']<'u','internal-error');const _0x12d474='expiresIn'in _0x24e2c5&&typeof _0x24e2c5['expiresIn']<'u'?Number(_0x24e2c5['expiresIn']):Cr(_0x24e2c5['idToken']);this['updateTokensAndExpiration'](_0x24e2c5['idToken'],_0x24e2c5['refreshToken'],_0x12d474);}['updateFromIdToken'](_0x154685){m(_0x154685['length']!==0x0,'internal-error');const _0x2360d0=Cr(_0x154685);this['updateTokensAndExpiration'](_0x154685,null,_0x2360d0);}async['getToken'](_0x1f5851,_0x17c63a=!0x1){return!_0x17c63a&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1f5851,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1f5851,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x2d0b8b,_0x1193c1){const {accessToken:_0x252ec1,refreshToken:_0x55502e,expiresIn:_0x43811a}=await Sf(_0x2d0b8b,_0x1193c1);this['updateTokensAndExpiration'](_0x252ec1,_0x55502e,Number(_0x43811a));}['updateTokensAndExpiration'](_0x11b313,_0x610ec3,_0x1581c2){this['refreshToken']=_0x610ec3||null,this['accessToken']=_0x11b313||null,this['expirationTime']=Date['now']()+_0x1581c2*0x3e8;}static['fromJSON'](_0x34bc2b,_0x4a95a8){const {refreshToken:_0x1d7c2d,accessToken:_0xdbd3e,expirationTime:_0x3a1418}=_0x4a95a8,_0x49a796=new et();return _0x1d7c2d&&(m(typeof _0x1d7c2d=='string','internal-error',{'appName':_0x34bc2b}),_0x49a796['refreshToken']=_0x1d7c2d),_0xdbd3e&&(m(typeof _0xdbd3e=='string','internal-error',{'appName':_0x34bc2b}),_0x49a796['accessToken']=_0xdbd3e),_0x3a1418&&(m(typeof _0x3a1418=='number','internal-error',{'appName':_0x34bc2b}),_0x49a796['expirationTime']=_0x3a1418),_0x49a796;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x92442){this['accessToken']=_0x92442['accessToken'],this['refreshToken']=_0x92442['refreshToken'],this['expirationTime']=_0x92442['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x49a841,_0x4f58f1){m(typeof _0x49a841=='string'||typeof _0x49a841>'u','internal-error',{'appName':_0x4f58f1});}class j{constructor({uid:_0x5396fa,auth:_0x1f76d1,stsTokenManager:_0x2d2ced,..._0x2c9a97}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5396fa,this['auth']=_0x1f76d1,this['stsTokenManager']=_0x2d2ced,this['accessToken']=_0x2d2ced['accessToken'],this['displayName']=_0x2c9a97['displayName']||null,this['email']=_0x2c9a97['email']||null,this['emailVerified']=_0x2c9a97['emailVerified']||!0x1,this['phoneNumber']=_0x2c9a97['phoneNumber']||null,this['photoURL']=_0x2c9a97['photoURL']||null,this['isAnonymous']=_0x2c9a97['isAnonymous']||!0x1,this['tenantId']=_0x2c9a97['tenantId']||null,this['providerData']=_0x2c9a97['providerData']?[..._0x2c9a97['providerData']]:[],this['metadata']=new Li(_0x2c9a97['createdAt']||void 0x0,_0x2c9a97['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3c6274){const _0x526380=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x3c6274));return m(_0x526380,this['auth'],'internal-error'),this['accessToken']!==_0x526380&&(this['accessToken']=_0x526380,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x526380;}['getIdTokenResult'](_0x1f7782){return Ef(this,_0x1f7782);}['reload'](){return Cf(this);}['_assign'](_0x2ec8e0){this!==_0x2ec8e0&&(m(this['uid']===_0x2ec8e0['uid'],this['auth'],'internal-error'),this['displayName']=_0x2ec8e0['displayName'],this['photoURL']=_0x2ec8e0['photoURL'],this['email']=_0x2ec8e0['email'],this['emailVerified']=_0x2ec8e0['emailVerified'],this['phoneNumber']=_0x2ec8e0['phoneNumber'],this['isAnonymous']=_0x2ec8e0['isAnonymous'],this['tenantId']=_0x2ec8e0['tenantId'],this['providerData']=_0x2ec8e0['providerData']['map'](_0x1f5be2=>({..._0x1f5be2})),this['metadata']['_copy'](_0x2ec8e0['metadata']),this['stsTokenManager']['_assign'](_0x2ec8e0['stsTokenManager']));}['_clone'](_0x2c22af){const _0x4d03e2=new j({...this,'auth':_0x2c22af,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4d03e2['metadata']['_copy'](this['metadata']),_0x4d03e2;}['_onReload'](_0x196ed7){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x196ed7,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x642a4c){this['reloadListener']?this['reloadListener'](_0x642a4c):this['reloadUserInfo']=_0x642a4c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x23ebed,_0x1c2176=!0x1){let _0x5b3cc8=!0x1;_0x23ebed['idToken']&&_0x23ebed['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x23ebed),_0x5b3cc8=!0x0),_0x1c2176&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5b3cc8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x108678=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x108678})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x47f3c5=>({..._0x47f3c5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5223cc,_0x572d11){const _0x22c2ae=_0x572d11['displayName']??void 0x0,_0x37f7bb=_0x572d11['email']??void 0x0,_0x4836af=_0x572d11['phoneNumber']??void 0x0,_0x54c733=_0x572d11['photoURL']??void 0x0,_0x4fa78d=_0x572d11['tenantId']??void 0x0,_0x126b33=_0x572d11['_redirectEventId']??void 0x0,_0x2dc8b6=_0x572d11['createdAt']??void 0x0,_0x13a602=_0x572d11['lastLoginAt']??void 0x0,{uid:_0x1c19c9,emailVerified:_0x1a8b6e,isAnonymous:_0x4729f5,providerData:_0x23dfd2,stsTokenManager:_0x94873b}=_0x572d11;m(_0x1c19c9&&_0x94873b,_0x5223cc,'internal-error');const _0x4271e6=et['fromJSON'](this['name'],_0x94873b);m(typeof _0x1c19c9=='string',_0x5223cc,'internal-error'),le(_0x22c2ae,_0x5223cc['name']),le(_0x37f7bb,_0x5223cc['name']),m(typeof _0x1a8b6e=='boolean',_0x5223cc,'internal-error'),m(typeof _0x4729f5=='boolean',_0x5223cc,'internal-error'),le(_0x4836af,_0x5223cc['name']),le(_0x54c733,_0x5223cc['name']),le(_0x4fa78d,_0x5223cc['name']),le(_0x126b33,_0x5223cc['name']),le(_0x2dc8b6,_0x5223cc['name']),le(_0x13a602,_0x5223cc['name']);const _0x58ca8d=new j({'uid':_0x1c19c9,'auth':_0x5223cc,'email':_0x37f7bb,'emailVerified':_0x1a8b6e,'displayName':_0x22c2ae,'isAnonymous':_0x4729f5,'photoURL':_0x54c733,'phoneNumber':_0x4836af,'tenantId':_0x4fa78d,'stsTokenManager':_0x4271e6,'createdAt':_0x2dc8b6,'lastLoginAt':_0x13a602});return _0x23dfd2&&Array['isArray'](_0x23dfd2)&&(_0x58ca8d['providerData']=_0x23dfd2['map'](_0x155c6f=>({..._0x155c6f}))),_0x126b33&&(_0x58ca8d['_redirectEventId']=_0x126b33),_0x58ca8d;}static async['_fromIdTokenResponse'](_0x3eab2c,_0x453020,_0x2815b3=!0x1){const _0xb7adcb=new et();_0xb7adcb['updateFromServerResponse'](_0x453020);const _0x173375=new j({'uid':_0x453020['localId'],'auth':_0x3eab2c,'stsTokenManager':_0xb7adcb,'isAnonymous':_0x2815b3});return await Nn(_0x173375),_0x173375;}static async['_fromGetAccountInfoResponse'](_0x398ba5,_0x6c0de5,_0x378707){const _0x153e63=_0x6c0de5['users'][0x0];m(_0x153e63['localId']!==void 0x0,'internal-error');const _0xfc7ac9=_0x153e63['providerUserInfo']!==void 0x0?Sa(_0x153e63['providerUserInfo']):[],_0x5dffc2=!(_0x153e63['email']&&_0x153e63['passwordHash'])&&!(_0xfc7ac9!=null&&_0xfc7ac9['length']),_0x57bf52=new et();_0x57bf52['updateFromIdToken'](_0x378707);const _0x58591f=new j({'uid':_0x153e63['localId'],'auth':_0x398ba5,'stsTokenManager':_0x57bf52,'isAnonymous':_0x5dffc2}),_0x53f7ce={'uid':_0x153e63['localId'],'displayName':_0x153e63['displayName']||null,'photoURL':_0x153e63['photoUrl']||null,'email':_0x153e63['email']||null,'emailVerified':_0x153e63['emailVerified']||!0x1,'phoneNumber':_0x153e63['phoneNumber']||null,'tenantId':_0x153e63['tenantId']||null,'providerData':_0xfc7ac9,'metadata':new Li(_0x153e63['createdAt'],_0x153e63['lastLoginAt']),'isAnonymous':!(_0x153e63['email']&&_0x153e63['passwordHash'])&&!(_0xfc7ac9!=null&&_0xfc7ac9['length'])};return Object['assign'](_0x58591f,_0x53f7ce),_0x58591f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2b5365){ce(_0x2b5365 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x253c77=Tr['get'](_0x2b5365);return _0x253c77?(ce(_0x253c77 instanceof _0x2b5365,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x253c77):(_0x253c77=new _0x2b5365(),Tr['set'](_0x2b5365,_0x253c77),_0x253c77);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x35f319,_0x144328){this['storage'][_0x35f319]=_0x144328;}async['_get'](_0x29169e){const _0x2fed78=this['storage'][_0x29169e];return _0x2fed78===void 0x0?null:_0x2fed78;}async['_remove'](_0x2d4ede){delete this['storage'][_0x2d4ede];}['_addListener'](_0x34bcc5,_0xa40320){}['_removeListener'](_0x458258,_0x447e7c){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1faef4,_0x191fa6,_0x31682a){return'firebase:'+_0x1faef4+':'+_0x191fa6+':'+_0x31682a;}class tt{constructor(_0x399050,_0x10fd7a,_0x49ab73){this['persistence']=_0x399050,this['auth']=_0x10fd7a,this['userKey']=_0x49ab73;const {config:_0x64931b,name:_0x42637c}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x64931b['apiKey'],_0x42637c),this['fullPersistenceKey']=ln('persistence',_0x64931b['apiKey'],_0x42637c),this['boundEventHandler']=_0x10fd7a['_onStorageEvent']['bind'](_0x10fd7a),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x44c6f6){return this['persistence']['_set'](this['fullUserKey'],_0x44c6f6['toJSON']());}async['getCurrentUser'](){const _0x9e4ae2=await this['persistence']['_get'](this['fullUserKey']);if(!_0x9e4ae2)return null;if(typeof _0x9e4ae2=='string'){const _0x4fd544=await Pn(this['auth'],{'idToken':_0x9e4ae2})['catch'](()=>{});return _0x4fd544?j['_fromGetAccountInfoResponse'](this['auth'],_0x4fd544,_0x9e4ae2):null;}return j['_fromJSON'](this['auth'],_0x9e4ae2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x4563b1){if(this['persistence']===_0x4563b1)return;const _0x441981=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x4563b1,_0x441981)return this['setCurrentUser'](_0x441981);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x2e052e,_0x3cebea,_0x1a1a01='authUser'){if(!_0x3cebea['length'])return new tt(ie(Sr),_0x2e052e,_0x1a1a01);const _0x142690=(await Promise['all'](_0x3cebea['map'](async _0x9c4cd9=>{if(await _0x9c4cd9['_isAvailable']())return _0x9c4cd9;})))['filter'](_0x3e9b3f=>_0x3e9b3f);let _0x29bd56=_0x142690[0x0]||ie(Sr);const _0x48b19b=ln(_0x1a1a01,_0x2e052e['config']['apiKey'],_0x2e052e['name']);let _0x1cb1c4=null;for(const _0x54f7d4 of _0x3cebea)try{const _0x409846=await _0x54f7d4['_get'](_0x48b19b);if(_0x409846){let _0x104ec1;if(typeof _0x409846=='string'){const _0xd472c6=await Pn(_0x2e052e,{'idToken':_0x409846})['catch'](()=>{});if(!_0xd472c6)break;_0x104ec1=await j['_fromGetAccountInfoResponse'](_0x2e052e,_0xd472c6,_0x409846);}else _0x104ec1=j['_fromJSON'](_0x2e052e,_0x409846);_0x54f7d4!==_0x29bd56&&(_0x1cb1c4=_0x104ec1),_0x29bd56=_0x54f7d4;break;}}catch{}const _0x456489=_0x142690['filter'](_0x490681=>_0x490681['_shouldAllowMigration']);return!_0x29bd56['_shouldAllowMigration']||!_0x456489['length']?new tt(_0x29bd56,_0x2e052e,_0x1a1a01):(_0x29bd56=_0x456489[0x0],_0x1cb1c4&&await _0x29bd56['_set'](_0x48b19b,_0x1cb1c4['toJSON']()),await Promise['all'](_0x3cebea['map'](async _0x172325=>{if(_0x172325!==_0x29bd56)try{await _0x172325['_remove'](_0x48b19b);}catch{}})),new tt(_0x29bd56,_0x2e052e,_0x1a1a01));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x198266){const _0x3b296a=_0x198266['toLowerCase']();if(_0x3b296a['includes']('opera/')||_0x3b296a['includes']('opr/')||_0x3b296a['includes']('opios/'))return'Opera';if(Pa(_0x3b296a))return'IEMobile';if(_0x3b296a['includes']('msie')||_0x3b296a['includes']('trident/'))return'IE';if(_0x3b296a['includes']('edge/'))return'Edge';if(Ra(_0x3b296a))return'Firefox';if(_0x3b296a['includes']('silk/'))return'Silk';if(Oa(_0x3b296a))return'Blackberry';if(Da(_0x3b296a))return'Webos';if(Aa(_0x3b296a))return'Safari';if((_0x3b296a['includes']('chrome/')||ka(_0x3b296a))&&!_0x3b296a['includes']('edge/'))return'Chrome';if(Na(_0x3b296a))return'Android';{const _0x26237c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x2c2436=_0x198266['match'](_0x26237c);if((_0x2c2436==null?void 0x0:_0x2c2436['length'])===0x2)return _0x2c2436[0x1];}return'Other';}function Ra(_0x4ada7d=W()){return/firefox\//i['test'](_0x4ada7d);}function Aa(_0x36dfed=W()){const _0x23f49b=_0x36dfed['toLowerCase']();return _0x23f49b['includes']('safari/')&&!_0x23f49b['includes']('chrome/')&&!_0x23f49b['includes']('crios/')&&!_0x23f49b['includes']('android');}function ka(_0x492ae2=W()){return/crios\//i['test'](_0x492ae2);}function Pa(_0x5ee1c0=W()){return/iemobile/i['test'](_0x5ee1c0);}function Na(_0x263222=W()){return/android/i['test'](_0x263222);}function Oa(_0x20134a=W()){return/blackberry/i['test'](_0x20134a);}function Da(_0x7786b3=W()){return/webos/i['test'](_0x7786b3);}function Ss(_0x1a1a90=W()){return/iphone|ipad|ipod/i['test'](_0x1a1a90)||/macintosh/i['test'](_0x1a1a90)&&/mobile/i['test'](_0x1a1a90);}function Rf(_0x1920e5=W()){var _0x13c068;return Ss(_0x1920e5)&&!!((_0x13c068=window['navigator'])!=null&&_0x13c068['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x57f947=W()){return Ss(_0x57f947)||Na(_0x57f947)||Da(_0x57f947)||Oa(_0x57f947)||/windows phone/i['test'](_0x57f947)||Pa(_0x57f947);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x108bb4,_0x4b9491=[]){let _0xb220ad;switch(_0x108bb4){case'Browser':_0xb220ad=br(W());break;case'Worker':_0xb220ad=br(W())+'-'+_0x108bb4;break;default:_0xb220ad=_0x108bb4;}const _0x3dba96=_0x4b9491['length']?_0x4b9491['join'](','):'FirebaseCore-web';return _0xb220ad+'/JsCore/'+dt+'/'+_0x3dba96;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x7d92d3){this['auth']=_0x7d92d3,this['queue']=[];}['pushCallback'](_0x124902,_0x5efbaa){const _0x520bb4=_0x3935c4=>new Promise((_0x56a8fd,_0x317adb)=>{try{const _0x364ec9=_0x124902(_0x3935c4);_0x56a8fd(_0x364ec9);}catch(_0x216100){_0x317adb(_0x216100);}});_0x520bb4['onAbort']=_0x5efbaa,this['queue']['push'](_0x520bb4);const _0x5e1a3d=this['queue']['length']-0x1;return()=>{this['queue'][_0x5e1a3d]=()=>Promise['resolve']();};}async['runMiddleware'](_0x32fc8d){if(this['auth']['currentUser']===_0x32fc8d)return;const _0x251e04=[];try{for(const _0x9acc20 of this['queue'])await _0x9acc20(_0x32fc8d),_0x9acc20['onAbort']&&_0x251e04['push'](_0x9acc20['onAbort']);}catch(_0x58d086){_0x251e04['reverse']();for(const _0x56fa6b of _0x251e04)try{_0x56fa6b();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x58d086==null?void 0x0:_0x58d086['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x57d9a7,_0x11a83b={}){return Pe(_0x57d9a7,'GET','/v2/passwordPolicy',ke(_0x57d9a7,_0x11a83b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3b8c5d){var _0x3b5fdc;const _0x49ad7d=_0x3b8c5d['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x49ad7d['minPasswordLength']??Nf,_0x49ad7d['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x49ad7d['maxPasswordLength']),_0x49ad7d['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x49ad7d['containsLowercaseCharacter']),_0x49ad7d['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x49ad7d['containsUppercaseCharacter']),_0x49ad7d['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x49ad7d['containsNumericCharacter']),_0x49ad7d['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x49ad7d['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3b8c5d['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3b5fdc=_0x3b8c5d['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3b5fdc['join'](''))??'',this['forceUpgradeOnSignin']=_0x3b8c5d['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3b8c5d['schemaVersion'];}['validatePassword'](_0x488e12){const _0x445fc5={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x488e12,_0x445fc5),this['validatePasswordCharacterOptions'](_0x488e12,_0x445fc5),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['meetsMinPasswordLength']??!0x0),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['meetsMaxPasswordLength']??!0x0),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['containsLowercaseLetter']??!0x0),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['containsUppercaseLetter']??!0x0),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['containsNumericCharacter']??!0x0),_0x445fc5['isValid']&&(_0x445fc5['isValid']=_0x445fc5['containsNonAlphanumericCharacter']??!0x0),_0x445fc5;}['validatePasswordLengthOptions'](_0x10937f,_0x329253){const _0xaa1557=this['customStrengthOptions']['minPasswordLength'],_0x56acd5=this['customStrengthOptions']['maxPasswordLength'];_0xaa1557&&(_0x329253['meetsMinPasswordLength']=_0x10937f['length']>=_0xaa1557),_0x56acd5&&(_0x329253['meetsMaxPasswordLength']=_0x10937f['length']<=_0x56acd5);}['validatePasswordCharacterOptions'](_0x1e8bac,_0x4348f6){this['updatePasswordCharacterOptionsStatuses'](_0x4348f6,!0x1,!0x1,!0x1,!0x1);let _0x225d03;for(let _0xa6086e=0x0;_0xa6086e<_0x1e8bac['length'];_0xa6086e++)_0x225d03=_0x1e8bac['charAt'](_0xa6086e),this['updatePasswordCharacterOptionsStatuses'](_0x4348f6,_0x225d03>='a'&&_0x225d03<='z',_0x225d03>='A'&&_0x225d03<='Z',_0x225d03>='0'&&_0x225d03<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x225d03));}['updatePasswordCharacterOptionsStatuses'](_0x5ef630,_0x365d8d,_0x2cc8b6,_0x49a75e,_0x48bb40){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5ef630['containsLowercaseLetter']||(_0x5ef630['containsLowercaseLetter']=_0x365d8d)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5ef630['containsUppercaseLetter']||(_0x5ef630['containsUppercaseLetter']=_0x2cc8b6)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5ef630['containsNumericCharacter']||(_0x5ef630['containsNumericCharacter']=_0x49a75e)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5ef630['containsNonAlphanumericCharacter']||(_0x5ef630['containsNonAlphanumericCharacter']=_0x48bb40));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x56589e,_0x28ef59,_0x44e6df,_0x574156){this['app']=_0x56589e,this['heartbeatServiceProvider']=_0x28ef59,this['appCheckServiceProvider']=_0x44e6df,this['config']=_0x574156,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x56589e['name'],this['clientVersion']=_0x574156['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5bcb24=>this['_resolvePersistenceManagerAvailable']=_0x5bcb24);}['_initializeWithPersistence'](_0x2b8619,_0x41714d){return _0x41714d&&(this['_popupRedirectResolver']=ie(_0x41714d)),this['_initializationPromise']=this['queue'](async()=>{var _0x5de754,_0x330c18,_0x77071;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2b8619),(_0x5de754=this['_resolvePersistenceManagerAvailable'])==null||_0x5de754['call'](this),!this['_deleted'])){if((_0x330c18=this['_popupRedirectResolver'])!=null&&_0x330c18['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x41714d),this['lastNotifiedUid']=((_0x77071=this['currentUser'])==null?void 0x0:_0x77071['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x573d10=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x573d10)){if(this['currentUser']&&_0x573d10&&this['currentUser']['uid']===_0x573d10['uid']){this['_currentUser']['_assign'](_0x573d10),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x573d10,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x48fef3){try{const _0x18421f=await Pn(this,{'idToken':_0x48fef3}),_0x10d52e=await j['_fromGetAccountInfoResponse'](this,_0x18421f,_0x48fef3);await this['directlySetCurrentUser'](_0x10d52e);}catch(_0x2ee068){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2ee068),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x89f81f){var _0x3d12b3;if($(this['app'])){const _0x217e31=this['app']['settings']['authIdToken'];return _0x217e31?new Promise(_0x450d8f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x217e31)['then'](_0x450d8f,_0x450d8f));}):this['directlySetCurrentUser'](null);}const _0x310f5c=await this['assertedPersistence']['getCurrentUser']();let _0x27660b=_0x310f5c,_0x59c3c5=!0x1;if(_0x89f81f&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x35bc7d=(_0x3d12b3=this['redirectUser'])==null?void 0x0:_0x3d12b3['_redirectEventId'],_0x21f71c=_0x27660b==null?void 0x0:_0x27660b['_redirectEventId'],_0xe42bf=await this['tryRedirectSignIn'](_0x89f81f);(!_0x35bc7d||_0x35bc7d===_0x21f71c)&&(_0xe42bf!=null&&_0xe42bf['user'])&&(_0x27660b=_0xe42bf['user'],_0x59c3c5=!0x0);}if(!_0x27660b)return this['directlySetCurrentUser'](null);if(!_0x27660b['_redirectEventId']){if(_0x59c3c5)try{await this['beforeStateQueue']['runMiddleware'](_0x27660b);}catch(_0x4b53f6){_0x27660b=_0x310f5c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4b53f6));}return _0x27660b?this['reloadAndSetCurrentUserOrClear'](_0x27660b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x27660b['_redirectEventId']?this['directlySetCurrentUser'](_0x27660b):this['reloadAndSetCurrentUserOrClear'](_0x27660b);}async['tryRedirectSignIn'](_0x1d0312){let _0x3dcfa9=null;try{_0x3dcfa9=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1d0312,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3dcfa9;}async['reloadAndSetCurrentUserOrClear'](_0x25cfaf){try{await Nn(_0x25cfaf);}catch(_0x33bc4c){if((_0x33bc4c==null?void 0x0:_0x33bc4c['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x25cfaf);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1d9dcc){if($(this['app']))return Promise['reject'](re(this));const _0x575770=_0x1d9dcc?P(_0x1d9dcc):null;return _0x575770&&m(_0x575770['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x575770&&_0x575770['_clone'](this));}async['_updateCurrentUser'](_0x44e123,_0x5bb3d2=!0x1){if(!this['_deleted'])return _0x44e123&&m(this['tenantId']===_0x44e123['tenantId'],this,'tenant-id-mismatch'),_0x5bb3d2||await this['beforeStateQueue']['runMiddleware'](_0x44e123),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x44e123),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x29de23){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x29de23));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x57415f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x94480c=this['_getPasswordPolicyInternal']();return _0x94480c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x94480c['validatePassword'](_0x57415f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x38612e=await Pf(this),_0x542206=new Of(_0x38612e);this['tenantId']===null?this['_projectPasswordPolicy']=_0x542206:this['_tenantPasswordPolicies'][this['tenantId']]=_0x542206;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x25aa5f){this['_errorFactory']=new Gt('auth','Firebase',_0x25aa5f());}['onAuthStateChanged'](_0x250b96,_0x55b746,_0x2b9e94){return this['registerStateListener'](this['authStateSubscription'],_0x250b96,_0x55b746,_0x2b9e94);}['beforeAuthStateChanged'](_0x3f5758,_0x13d1d0){return this['beforeStateQueue']['pushCallback'](_0x3f5758,_0x13d1d0);}['onIdTokenChanged'](_0x30aa0b,_0x4489f7,_0x2e8560){return this['registerStateListener'](this['idTokenSubscription'],_0x30aa0b,_0x4489f7,_0x2e8560);}['authStateReady'](){return new Promise((_0xaecf5,_0x1c332d)=>{if(this['currentUser'])_0xaecf5();else{const _0x3964c8=this['onAuthStateChanged'](()=>{_0x3964c8(),_0xaecf5();},_0x1c332d);}});}async['revokeAccessToken'](_0x461b1f){if(this['currentUser']){const _0x11d454=await this['currentUser']['getIdToken'](),_0x5461dd={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x461b1f,'idToken':_0x11d454};this['tenantId']!=null&&(_0x5461dd['tenantId']=this['tenantId']),await bf(this,_0x5461dd);}}['toJSON'](){var _0x2dc8db;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2dc8db=this['_currentUser'])==null?void 0x0:_0x2dc8db['toJSON']()};}async['_setRedirectUser'](_0x3445a6,_0x485bb6){const _0x1553a8=await this['getOrInitRedirectPersistenceManager'](_0x485bb6);return _0x3445a6===null?_0x1553a8['removeCurrentUser']():_0x1553a8['setCurrentUser'](_0x3445a6);}async['getOrInitRedirectPersistenceManager'](_0x140687){if(!this['redirectPersistenceManager']){const _0x4e20df=_0x140687&&ie(_0x140687)||this['_popupRedirectResolver'];m(_0x4e20df,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x4e20df['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x316167){var _0x4fbc14,_0x393a97;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4fbc14=this['_currentUser'])==null?void 0x0:_0x4fbc14['_redirectEventId'])===_0x316167?this['_currentUser']:((_0x393a97=this['redirectUser'])==null?void 0x0:_0x393a97['_redirectEventId'])===_0x316167?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x46c11f){if(_0x46c11f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x46c11f));}['_notifyListenersIfCurrent'](_0x29b03a){_0x29b03a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x48139a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4aec6f=((_0x48139a=this['currentUser'])==null?void 0x0:_0x48139a['uid'])??null;this['lastNotifiedUid']!==_0x4aec6f&&(this['lastNotifiedUid']=_0x4aec6f,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x2ae4e4,_0x458be6,_0x119667,_0x508bb8){if(this['_deleted'])return()=>{};const _0x4ede84=typeof _0x458be6=='function'?_0x458be6:_0x458be6['next']['bind'](_0x458be6);let _0x211e6e=!0x1;const _0x2ddf=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2ddf,this,'internal-error'),_0x2ddf['then'](()=>{_0x211e6e||_0x4ede84(this['currentUser']);}),typeof _0x458be6=='function'){const _0x42d2a5=_0x2ae4e4['addObserver'](_0x458be6,_0x119667,_0x508bb8);return()=>{_0x211e6e=!0x0,_0x42d2a5();};}else{const _0x5c2fcd=_0x2ae4e4['addObserver'](_0x458be6);return()=>{_0x211e6e=!0x0,_0x5c2fcd();};}}async['directlySetCurrentUser'](_0x228a9e){this['currentUser']&&this['currentUser']!==_0x228a9e&&this['_currentUser']['_stopProactiveRefresh'](),_0x228a9e&&this['isProactiveRefreshEnabled']&&_0x228a9e['_startProactiveRefresh'](),this['currentUser']=_0x228a9e,_0x228a9e?await this['assertedPersistence']['setCurrentUser'](_0x228a9e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1b3d78){return this['operations']=this['operations']['then'](_0x1b3d78,_0x1b3d78),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5112f2){!_0x5112f2||this['frameworks']['includes'](_0x5112f2)||(this['frameworks']['push'](_0x5112f2),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x696dda;const _0x9bc3aa={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x9bc3aa['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x18bae3=await((_0x696dda=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x696dda['getHeartbeatsHeader']());_0x18bae3&&(_0x9bc3aa['X-Firebase-Client']=_0x18bae3);const _0x2c62c1=await this['_getAppCheckToken']();return _0x2c62c1&&(_0x9bc3aa['X-Firebase-AppCheck']=_0x2c62c1),_0x9bc3aa;}async['_getAppCheckToken'](){var _0x3cfb51;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x16bbfc=await((_0x3cfb51=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3cfb51['getToken']());return _0x16bbfc!=null&&_0x16bbfc['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x16bbfc['error']),_0x16bbfc==null?void 0x0:_0x16bbfc['token'];}}function Ke(_0x563b13){return P(_0x563b13);}class Rr{constructor(_0x44c5c9){this['auth']=_0x44c5c9,this['observer']=null,this['addObserver']=Tc(_0x23f692=>this['observer']=_0x23f692);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5365f2){Jn=_0x5365f2;}function xa(_0x34791e){return Jn['loadJS'](_0x34791e);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x5b505d){return'__'+_0x5b505d+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1bc485){_0x1bc485();}['execute'](_0x3a4aa5,_0x383f38){return Promise['resolve']('token');}['render'](_0x3e828d,_0x15f21d){return'';}}class Wf{['ready'](_0x43ebc5){_0x43ebc5();}['execute'](_0x4f96f6,_0x55b532){return Promise['resolve']('token');}['render'](_0x4822ff,_0x378b0e){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x49ef22){this['type']=Bf,this['auth']=Ke(_0x49ef22);}async['verify'](_0x9a7257='verify',_0x51ec30=!0x1){async function _0x3a6f7d(_0x42396e){if(!_0x51ec30){if(_0x42396e['tenantId']==null&&_0x42396e['_agentRecaptchaConfig']!=null)return _0x42396e['_agentRecaptchaConfig']['siteKey'];if(_0x42396e['tenantId']!=null&&_0x42396e['_tenantRecaptchaConfigs'][_0x42396e['tenantId']]!==void 0x0)return _0x42396e['_tenantRecaptchaConfigs'][_0x42396e['tenantId']]['siteKey'];}return new Promise(async(_0x488569,_0x579a32)=>{yf(_0x42396e,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4d10a2=>{if(_0x4d10a2['recaptchaKey']===void 0x0)_0x579a32(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2aba46=new mf(_0x4d10a2);return _0x42396e['tenantId']==null?_0x42396e['_agentRecaptchaConfig']=_0x2aba46:_0x42396e['_tenantRecaptchaConfigs'][_0x42396e['tenantId']]=_0x2aba46,_0x488569(_0x2aba46['siteKey']);}})['catch'](_0x4817b3=>{_0x579a32(_0x4817b3);});});}function _0x322904(_0x3dab95,_0x5e0504,_0x126119){const _0xa4886c=window['grecaptcha'];wr(_0xa4886c)?_0xa4886c['enterprise']['ready'](()=>{_0xa4886c['enterprise']['execute'](_0x3dab95,{'action':_0x9a7257})['then'](_0x1351f7=>{_0x5e0504(_0x1351f7);})['catch'](()=>{_0x5e0504(Fa);});}):_0x126119(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x44ffcf,_0x5e84da)=>{_0x3a6f7d(this['auth'])['then'](async _0x3a1031=>{if(!_0x51ec30&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x322904(_0x3a1031,_0x44ffcf,_0x5e84da);else{if(typeof window>'u'){_0x5e84da(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3df51d=Lf();_0x3df51d['length']!==0x0&&(_0x3df51d+=_0x3a1031+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x353f1c;(_0x353f1c=he['scriptInjectionDeferred'])==null||_0x353f1c['resolve']();},xa(_0x3df51d)['then'](()=>{var _0x4ff36f;return(_0x4ff36f=he['scriptInjectionDeferred'])==null?void 0x0:_0x4ff36f['promise'];})['then'](()=>{_0x322904(_0x3a1031,_0x44ffcf,_0x5e84da);})['catch'](_0x4d2989=>{_0x5e84da(_0x4d2989);});}})['catch'](_0x32bacd=>{_0x5e84da(_0x32bacd);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5372b0,_0x4e3f45,_0x5a7e31,_0x1605fe=!0x1,_0x1f9399=!0x1){const _0x17bd7e=new he(_0x5372b0);let _0x21f759;if(_0x1f9399)_0x21f759=Fa;else try{_0x21f759=await _0x17bd7e['verify'](_0x5a7e31);}catch{_0x21f759=await _0x17bd7e['verify'](_0x5a7e31,!0x0);}const _0x40c252={..._0x4e3f45};if(_0x5a7e31==='mfaSmsEnrollment'||_0x5a7e31==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x40c252){const _0x211e1e=_0x40c252['phoneEnrollmentInfo']['phoneNumber'],_0x4dc291=_0x40c252['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x40c252,{'phoneEnrollmentInfo':{'phoneNumber':_0x211e1e,'recaptchaToken':_0x4dc291,'captchaResponse':_0x21f759,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x40c252){const _0x424ddb=_0x40c252['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x40c252,{'phoneSignInInfo':{'recaptchaToken':_0x424ddb,'captchaResponse':_0x21f759,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x40c252;}return _0x1605fe?Object['assign'](_0x40c252,{'captchaResp':_0x21f759}):Object['assign'](_0x40c252,{'captchaResponse':_0x21f759}),Object['assign'](_0x40c252,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x40c252,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x40c252;}async function xi(_0x181307,_0x12c23c,_0x233cbc,_0x5e9e94,_0x285772){var _0x17ee6e;if((_0x17ee6e=_0x181307['_getRecaptchaConfig']())!=null&&_0x17ee6e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x39eabc=await kr(_0x181307,_0x12c23c,_0x233cbc,_0x233cbc==='getOobCode');return _0x5e9e94(_0x181307,_0x39eabc);}else return _0x5e9e94(_0x181307,_0x12c23c)['catch'](async _0x13917e=>{if(_0x13917e['code']==='auth/missing-recaptcha-token'){console['log'](_0x233cbc+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4286d3=await kr(_0x181307,_0x12c23c,_0x233cbc,_0x233cbc==='getOobCode');return _0x5e9e94(_0x181307,_0x4286d3);}else return Promise['reject'](_0x13917e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x3a967f,_0x1263f6){const _0x53301a=Hi(_0x3a967f,'auth');if(_0x53301a['isInitialized']()){const _0x32a3be=_0x53301a['getImmediate'](),_0x8eb31a=_0x53301a['getOptions']();if(xe(_0x8eb31a,_0x1263f6??{}))return _0x32a3be;Y(_0x32a3be,'already-initialized');}return _0x53301a['initialize']({'options':_0x1263f6});}function Hf(_0x9f46fd,_0x2a30c2){const _0x3d7852=(_0x2a30c2==null?void 0x0:_0x2a30c2['persistence'])||[],_0x32ac38=(Array['isArray'](_0x3d7852)?_0x3d7852:[_0x3d7852])['map'](ie);_0x2a30c2!=null&&_0x2a30c2['errorMap']&&_0x9f46fd['_updateErrorMap'](_0x2a30c2['errorMap']),_0x9f46fd['_initializeWithPersistence'](_0x32ac38,_0x2a30c2==null?void 0x0:_0x2a30c2['popupRedirectResolver']);}function $f(_0x4c9d7c,_0x5efde9,_0x56ea3d){const _0x19d6be=Ke(_0x4c9d7c);m(/^https?:\/\//['test'](_0x5efde9),_0x19d6be,'invalid-emulator-scheme');const _0x10691e=!0x1,_0x589e36=Ua(_0x5efde9),{host:_0x580485,port:_0x16188e}=Gf(_0x5efde9),_0x531d31=_0x16188e===null?'':':'+_0x16188e,_0x3dae4e={'url':_0x589e36+'//'+_0x580485+_0x531d31+'/'},_0x547d6c=Object['freeze']({'host':_0x580485,'port':_0x16188e,'protocol':_0x589e36['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x10691e})});if(!_0x19d6be['_canInitEmulator']){m(_0x19d6be['config']['emulator']&&_0x19d6be['emulatorConfig'],_0x19d6be,'emulator-config-failed'),m(xe(_0x3dae4e,_0x19d6be['config']['emulator'])&&xe(_0x547d6c,_0x19d6be['emulatorConfig']),_0x19d6be,'emulator-config-failed');return;}_0x19d6be['config']['emulator']=_0x3dae4e,_0x19d6be['emulatorConfig']=_0x547d6c,_0x19d6be['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x580485)?Qr(_0x589e36+'//'+_0x580485+_0x531d31):qf();}function Ua(_0x1f2195){const _0x298933=_0x1f2195['indexOf'](':');return _0x298933<0x0?'':_0x1f2195['substr'](0x0,_0x298933+0x1);}function Gf(_0x56d0cc){const _0x591c2c=Ua(_0x56d0cc),_0x444499=/(\/\/)?([^?#/]+)/['exec'](_0x56d0cc['substr'](_0x591c2c['length']));if(!_0x444499)return{'host':'','port':null};const _0x28c61c=_0x444499[0x2]['split']('@')['pop']()||'',_0x3bb771=/^(\[[^\]]+\])(:|$)/['exec'](_0x28c61c);if(_0x3bb771){const _0xd4c9d6=_0x3bb771[0x1];return{'host':_0xd4c9d6,'port':Pr(_0x28c61c['substr'](_0xd4c9d6['length']+0x1))};}else{const [_0xc54055,_0xc3c242]=_0x28c61c['split'](':');return{'host':_0xc54055,'port':Pr(_0xc3c242)};}}function Pr(_0x58d7a4){if(!_0x58d7a4)return null;const _0x50b049=Number(_0x58d7a4);return isNaN(_0x50b049)?null:_0x50b049;}function qf(){function _0x31e7d3(){const _0x5d3d9f=document['createElement']('p'),_0x481492=_0x5d3d9f['style'];_0x5d3d9f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x481492['position']='fixed',_0x481492['width']='100%',_0x481492['backgroundColor']='#ffffff',_0x481492['border']='.1em\x20solid\x20#000000',_0x481492['color']='#b50000',_0x481492['bottom']='0px',_0x481492['left']='0px',_0x481492['margin']='0px',_0x481492['zIndex']='10000',_0x481492['textAlign']='center',_0x5d3d9f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5d3d9f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x31e7d3):_0x31e7d3());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3406f1,_0x237e89){this['providerId']=_0x3406f1,this['signInMethod']=_0x237e89;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2fd02c){return ne('not\x20implemented');}['_linkToIdToken'](_0x1395b6,_0x1aeb99){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x23065f){return ne('not\x20implemented');}}async function zf(_0x5beac8,_0x16fdbb){return Pe(_0x5beac8,'POST','/v1/accounts:signUp',_0x16fdbb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x5ee3a8,_0x18c966){return en(_0x5ee3a8,'POST','/v1/accounts:signInWithPassword',ke(_0x5ee3a8,_0x18c966));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x571ae7,_0x5482bc){return en(_0x571ae7,'POST','/v1/accounts:signInWithEmailLink',ke(_0x571ae7,_0x5482bc));}async function Yf(_0x913e16,_0x529231){return en(_0x913e16,'POST','/v1/accounts:signInWithEmailLink',ke(_0x913e16,_0x529231));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x41a2b1,_0x11c884,_0x41402c,_0x2ce4f9=null){super('password',_0x41402c),this['_email']=_0x41a2b1,this['_password']=_0x11c884,this['_tenantId']=_0x2ce4f9;}static['_fromEmailAndPassword'](_0x2a9e53,_0x440c40){return new $t(_0x2a9e53,_0x440c40,'password');}static['_fromEmailAndCode'](_0x393216,_0x368fc9,_0xa31681=null){return new $t(_0x393216,_0x368fc9,'emailLink',_0xa31681);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x55ff9f){const _0x316edf=typeof _0x55ff9f=='string'?JSON['parse'](_0x55ff9f):_0x55ff9f;if(_0x316edf!=null&&_0x316edf['email']&&(_0x316edf!=null&&_0x316edf['password'])){if(_0x316edf['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x316edf['email'],_0x316edf['password']);if(_0x316edf['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x316edf['email'],_0x316edf['password'],_0x316edf['tenantId']);}return null;}async['_getIdTokenResponse'](_0x287d8f){switch(this['signInMethod']){case'password':const _0x5e5bf5={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x287d8f,_0x5e5bf5,'signInWithPassword',jf);case'emailLink':return Kf(_0x287d8f,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x287d8f,'internal-error');}}async['_linkToIdToken'](_0x23fc28,_0x470f7b){switch(this['signInMethod']){case'password':const _0x45f6ea={'idToken':_0x470f7b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x23fc28,_0x45f6ea,'signUpPassword',zf);case'emailLink':return Yf(_0x23fc28,{'idToken':_0x470f7b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x23fc28,'internal-error');}}['_getReauthenticationResolver'](_0xe7960e){return this['_getIdTokenResponse'](_0xe7960e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x21e84a,_0x31116c){return en(_0x21e84a,'POST','/v1/accounts:signInWithIdp',ke(_0x21e84a,_0x31116c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x5ce0c4){const _0x4b3f25=new $e(_0x5ce0c4['providerId'],_0x5ce0c4['signInMethod']);return _0x5ce0c4['idToken']||_0x5ce0c4['accessToken']?(_0x5ce0c4['idToken']&&(_0x4b3f25['idToken']=_0x5ce0c4['idToken']),_0x5ce0c4['accessToken']&&(_0x4b3f25['accessToken']=_0x5ce0c4['accessToken']),_0x5ce0c4['nonce']&&!_0x5ce0c4['pendingToken']&&(_0x4b3f25['nonce']=_0x5ce0c4['nonce']),_0x5ce0c4['pendingToken']&&(_0x4b3f25['pendingToken']=_0x5ce0c4['pendingToken'])):_0x5ce0c4['oauthToken']&&_0x5ce0c4['oauthTokenSecret']?(_0x4b3f25['accessToken']=_0x5ce0c4['oauthToken'],_0x4b3f25['secret']=_0x5ce0c4['oauthTokenSecret']):Y('argument-error'),_0x4b3f25;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xa50023){const _0x3a277a=typeof _0xa50023=='string'?JSON['parse'](_0xa50023):_0xa50023,{providerId:_0x4a6e89,signInMethod:_0x34e860,..._0x490ccb}=_0x3a277a;if(!_0x4a6e89||!_0x34e860)return null;const _0x5d5fa3=new $e(_0x4a6e89,_0x34e860);return _0x5d5fa3['idToken']=_0x490ccb['idToken']||void 0x0,_0x5d5fa3['accessToken']=_0x490ccb['accessToken']||void 0x0,_0x5d5fa3['secret']=_0x490ccb['secret'],_0x5d5fa3['nonce']=_0x490ccb['nonce'],_0x5d5fa3['pendingToken']=_0x490ccb['pendingToken']||null,_0x5d5fa3;}['_getIdTokenResponse'](_0x11ad2f){const _0x432df6=this['buildRequest']();return nt(_0x11ad2f,_0x432df6);}['_linkToIdToken'](_0x4f62f1,_0x20b6f8){const _0x4a4665=this['buildRequest']();return _0x4a4665['idToken']=_0x20b6f8,nt(_0x4f62f1,_0x4a4665);}['_getReauthenticationResolver'](_0x1064ae){const _0x4988e5=this['buildRequest']();return _0x4988e5['autoCreate']=!0x1,nt(_0x1064ae,_0x4988e5);}['buildRequest'](){const _0x3eabcb={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3eabcb['pendingToken']=this['pendingToken'];else{const _0x288535={};this['idToken']&&(_0x288535['id_token']=this['idToken']),this['accessToken']&&(_0x288535['access_token']=this['accessToken']),this['secret']&&(_0x288535['oauth_token_secret']=this['secret']),_0x288535['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x288535['nonce']=this['nonce']),_0x3eabcb['postBody']=ut(_0x288535);}return _0x3eabcb;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x15ad2f){switch(_0x15ad2f){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0xb3933e){const _0x2bf82c=Ct(Tt(_0xb3933e))['link'],_0x543bc9=_0x2bf82c?Ct(Tt(_0x2bf82c))['deep_link_id']:null,_0x4f106a=Ct(Tt(_0xb3933e))['deep_link_id'];return(_0x4f106a?Ct(Tt(_0x4f106a))['link']:null)||_0x4f106a||_0x543bc9||_0x2bf82c||_0xb3933e;}class Rs{constructor(_0x5439b4){const _0x106dc2=Ct(Tt(_0x5439b4)),_0x298c40=_0x106dc2['apiKey']??null,_0x320741=_0x106dc2['oobCode']??null,_0x3eeb71=Jf(_0x106dc2['mode']??null);m(_0x298c40&&_0x320741&&_0x3eeb71,'argument-error'),this['apiKey']=_0x298c40,this['operation']=_0x3eeb71,this['code']=_0x320741,this['continueUrl']=_0x106dc2['continueUrl']??null,this['languageCode']=_0x106dc2['lang']??null,this['tenantId']=_0x106dc2['tenantId']??null;}static['parseLink'](_0x32dc96){const _0x1a8b47=Xf(_0x32dc96);try{return new Rs(_0x1a8b47);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x23e3b8,_0x1a540a){return $t['_fromEmailAndPassword'](_0x23e3b8,_0x1a540a);}static['credentialWithLink'](_0x2b5259,_0x99f24e){const _0x5213a5=Rs['parseLink'](_0x99f24e);return m(_0x5213a5,'argument-error'),$t['_fromEmailAndCode'](_0x2b5259,_0x5213a5['code'],_0x5213a5['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x345741){this['providerId']=_0x345741,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x58960f){this['defaultLanguageCode']=_0x58960f;}['setCustomParameters'](_0x581ccf){return this['customParameters']=_0x581ccf,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2e9c86){return this['scopes']['includes'](_0x2e9c86)||this['scopes']['push'](_0x2e9c86),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x5cfba8){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5cfba8});}static['credentialFromResult'](_0xd193b1){return ue['credentialFromTaggedObject'](_0xd193b1);}static['credentialFromError'](_0x368b73){return ue['credentialFromTaggedObject'](_0x368b73['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x245cc5}){if(!_0x245cc5||!('oauthAccessToken'in _0x245cc5)||!_0x245cc5['oauthAccessToken'])return null;try{return ue['credential'](_0x245cc5['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3881c7,_0xf2c53a){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3881c7,'accessToken':_0xf2c53a});}static['credentialFromResult'](_0x538dc2){return de['credentialFromTaggedObject'](_0x538dc2);}static['credentialFromError'](_0x3f03cb){return de['credentialFromTaggedObject'](_0x3f03cb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x239671}){if(!_0x239671)return null;const {oauthIdToken:_0x44cbe8,oauthAccessToken:_0x387627}=_0x239671;if(!_0x44cbe8&&!_0x387627)return null;try{return de['credential'](_0x44cbe8,_0x387627);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5d3169){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5d3169});}static['credentialFromResult'](_0x30da70){return fe['credentialFromTaggedObject'](_0x30da70);}static['credentialFromError'](_0xd7a540){return fe['credentialFromTaggedObject'](_0xd7a540['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x162f0a}){if(!_0x162f0a||!('oauthAccessToken'in _0x162f0a)||!_0x162f0a['oauthAccessToken'])return null;try{return fe['credential'](_0x162f0a['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x1a7eaa,_0x45183d){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1a7eaa,'oauthTokenSecret':_0x45183d});}static['credentialFromResult'](_0x40d1c5){return pe['credentialFromTaggedObject'](_0x40d1c5);}static['credentialFromError'](_0x7b3b7f){return pe['credentialFromTaggedObject'](_0x7b3b7f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2fd6e2}){if(!_0x2fd6e2)return null;const {oauthAccessToken:_0x556d20,oauthTokenSecret:_0x2acfdd}=_0x2fd6e2;if(!_0x556d20||!_0x2acfdd)return null;try{return pe['credential'](_0x556d20,_0x2acfdd);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3b2174,_0x1b7022){return en(_0x3b2174,'POST','/v1/accounts:signUp',ke(_0x3b2174,_0x1b7022));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0xe88d55){this['user']=_0xe88d55['user'],this['providerId']=_0xe88d55['providerId'],this['_tokenResponse']=_0xe88d55['_tokenResponse'],this['operationType']=_0xe88d55['operationType'];}static async['_fromIdTokenResponse'](_0x269808,_0x458b89,_0x150791,_0xef9876=!0x1){const _0x24d154=await j['_fromIdTokenResponse'](_0x269808,_0x150791,_0xef9876),_0x24912a=Nr(_0x150791);return new Ge({'user':_0x24d154,'providerId':_0x24912a,'_tokenResponse':_0x150791,'operationType':_0x458b89});}static async['_forOperation'](_0x4b3dc5,_0x128c0b,_0x23f5c7){await _0x4b3dc5['_updateTokensIfNecessary'](_0x23f5c7,!0x0);const _0x153b7d=Nr(_0x23f5c7);return new Ge({'user':_0x4b3dc5,'providerId':_0x153b7d,'_tokenResponse':_0x23f5c7,'operationType':_0x128c0b});}}function Nr(_0xe6ecd3){return _0xe6ecd3['providerId']?_0xe6ecd3['providerId']:'phoneNumber'in _0xe6ecd3?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x14faf6,_0x51bfa6,_0x320876,_0x55204a){super(_0x51bfa6['code'],_0x51bfa6['message']),this['operationType']=_0x320876,this['user']=_0x55204a,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x14faf6['name'],'tenantId':_0x14faf6['tenantId']??void 0x0,'_serverResponse':_0x51bfa6['customData']['_serverResponse'],'operationType':_0x320876};}static['_fromErrorAndOperation'](_0x1128d3,_0x15e0f9,_0x2c7857,_0x570d01){return new On(_0x1128d3,_0x15e0f9,_0x2c7857,_0x570d01);}}function Ba(_0x5c5b6c,_0x59ae56,_0x2521e5,_0xa6145b){return(_0x59ae56==='reauthenticate'?_0x2521e5['_getReauthenticationResolver'](_0x5c5b6c):_0x2521e5['_getIdTokenResponse'](_0x5c5b6c))['catch'](_0x34fe48=>{throw _0x34fe48['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x5c5b6c,_0x34fe48,_0x59ae56,_0xa6145b):_0x34fe48;});}async function ep(_0x1b86b9,_0x34d192,_0x2df3aa=!0x1){const _0x225600=await Ht(_0x1b86b9,_0x34d192['_linkToIdToken'](_0x1b86b9['auth'],await _0x1b86b9['getIdToken']()),_0x2df3aa);return Ge['_forOperation'](_0x1b86b9,'link',_0x225600);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3bcec4,_0x1ce818,_0x39f76=!0x1){const {auth:_0xde958b}=_0x3bcec4;if($(_0xde958b['app']))return Promise['reject'](re(_0xde958b));const _0x4cfefd='reauthenticate';try{const _0xfc4a36=await Ht(_0x3bcec4,Ba(_0xde958b,_0x4cfefd,_0x1ce818,_0x3bcec4),_0x39f76);m(_0xfc4a36['idToken'],_0xde958b,'internal-error');const _0x2ce4bb=Ts(_0xfc4a36['idToken']);m(_0x2ce4bb,_0xde958b,'internal-error');const {sub:_0x5be2a7}=_0x2ce4bb;return m(_0x3bcec4['uid']===_0x5be2a7,_0xde958b,'user-mismatch'),Ge['_forOperation'](_0x3bcec4,_0x4cfefd,_0xfc4a36);}catch(_0x4a5f71){throw(_0x4a5f71==null?void 0x0:_0x4a5f71['code'])==='auth/user-not-found'&&Y(_0xde958b,'user-mismatch'),_0x4a5f71;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4d5913,_0x1febb7,_0x2a9bbe=!0x1){if($(_0x4d5913['app']))return Promise['reject'](re(_0x4d5913));const _0x96acff='signIn',_0x38fd79=await Ba(_0x4d5913,_0x96acff,_0x1febb7),_0x1872dd=await Ge['_fromIdTokenResponse'](_0x4d5913,_0x96acff,_0x38fd79);return _0x2a9bbe||await _0x4d5913['_updateCurrentUser'](_0x1872dd['user']),_0x1872dd;}async function np(_0x5d9fa5,_0x3a8ac5){return Va(Ke(_0x5d9fa5),_0x3a8ac5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x13dd25){const _0xc0accd=Ke(_0x13dd25);_0xc0accd['_getPasswordPolicyInternal']()&&await _0xc0accd['_updatePasswordPolicy']();}async function L_(_0x34b14c,_0x41101b,_0x432c1f){if($(_0x34b14c['app']))return Promise['reject'](re(_0x34b14c));const _0xa874b5=Ke(_0x34b14c),_0x1a9fc3=await xi(_0xa874b5,{'returnSecureToken':!0x0,'email':_0x41101b,'password':_0x432c1f,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xaed707=>{throw _0xaed707['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x34b14c),_0xaed707;}),_0x3acdce=await Ge['_fromIdTokenResponse'](_0xa874b5,'signIn',_0x1a9fc3);return await _0xa874b5['_updateCurrentUser'](_0x3acdce['user']),_0x3acdce;}function x_(_0x171311,_0x175ca7,_0x5ceb6c){return $(_0x171311['app'])?Promise['reject'](re(_0x171311)):np(P(_0x171311),yt['credential'](_0x175ca7,_0x5ceb6c))['catch'](async _0x20e91a=>{throw _0x20e91a['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x171311),_0x20e91a;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x406aa3,_0x39c92b){return P(_0x406aa3)['setPersistence'](_0x39c92b);}function ip(_0x31f8cc,_0xa479a8,_0x406a51,_0x34ff8d){return P(_0x31f8cc)['onIdTokenChanged'](_0xa479a8,_0x406a51,_0x34ff8d);}function sp(_0x2f33a0,_0x4698ce,_0xab8a4e){return P(_0x2f33a0)['beforeAuthStateChanged'](_0x4698ce,_0xab8a4e);}function U_(_0xd74ca9,_0x186e4a,_0x15a0d2,_0x3123d9){return P(_0xd74ca9)['onAuthStateChanged'](_0x186e4a,_0x15a0d2,_0x3123d9);}function W_(_0x191715){return P(_0x191715)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4a3cb3,_0x456418){this['storageRetriever']=_0x4a3cb3,this['type']=_0x456418;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4135ec,_0x5569bc){return this['storage']['setItem'](_0x4135ec,JSON['stringify'](_0x5569bc)),Promise['resolve']();}['_get'](_0x399d4c){const _0x33498f=this['storage']['getItem'](_0x399d4c);return Promise['resolve'](_0x33498f?JSON['parse'](_0x33498f):null);}['_remove'](_0x330089){return this['storage']['removeItem'](_0x330089),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x272ccf,_0xd5af2e)=>this['onStorageEvent'](_0x272ccf,_0xd5af2e),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xc89ac8){for(const _0x49e752 of Object['keys'](this['listeners'])){const _0xab898f=this['storage']['getItem'](_0x49e752),_0x174769=this['localCache'][_0x49e752];_0xab898f!==_0x174769&&_0xc89ac8(_0x49e752,_0x174769,_0xab898f);}}['onStorageEvent'](_0x415ca3,_0xede1ca=!0x1){if(!_0x415ca3['key']){this['forAllChangedKeys']((_0x5c3fba,_0x56a095,_0x1007de)=>{this['notifyListeners'](_0x5c3fba,_0x1007de);});return;}const _0x10e698=_0x415ca3['key'];_0xede1ca?this['detachListener']():this['stopPolling']();const _0x37bce3=()=>{const _0x39d41f=this['storage']['getItem'](_0x10e698);!_0xede1ca&&this['localCache'][_0x10e698]===_0x39d41f||this['notifyListeners'](_0x10e698,_0x39d41f);},_0x2e6a5d=this['storage']['getItem'](_0x10e698);Af()&&_0x2e6a5d!==_0x415ca3['newValue']&&_0x415ca3['newValue']!==_0x415ca3['oldValue']?setTimeout(_0x37bce3,op):_0x37bce3();}['notifyListeners'](_0x28b9fd,_0x1178f3){this['localCache'][_0x28b9fd]=_0x1178f3;const _0x5dbc9b=this['listeners'][_0x28b9fd];if(_0x5dbc9b){for(const _0x13a050 of Array['from'](_0x5dbc9b))_0x13a050(_0x1178f3&&JSON['parse'](_0x1178f3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x555c45,_0x46b4e5,_0xc0b0bf)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x555c45,'oldValue':_0x46b4e5,'newValue':_0xc0b0bf}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x3d19dd,_0x5ed004){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x3d19dd]||(this['listeners'][_0x3d19dd]=new Set(),this['localCache'][_0x3d19dd]=this['storage']['getItem'](_0x3d19dd)),this['listeners'][_0x3d19dd]['add'](_0x5ed004);}['_removeListener'](_0x14bdcb,_0x1ac6b4){this['listeners'][_0x14bdcb]&&(this['listeners'][_0x14bdcb]['delete'](_0x1ac6b4),this['listeners'][_0x14bdcb]['size']===0x0&&delete this['listeners'][_0x14bdcb]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x42f24c,_0x46dbef){await super['_set'](_0x42f24c,_0x46dbef),this['localCache'][_0x42f24c]=JSON['stringify'](_0x46dbef);}async['_get'](_0x3d0e0c){const _0x22f29e=await super['_get'](_0x3d0e0c);return this['localCache'][_0x3d0e0c]=JSON['stringify'](_0x22f29e),_0x22f29e;}async['_remove'](_0x19a6af){await super['_remove'](_0x19a6af),delete this['localCache'][_0x19a6af];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x41b577,_0x171d1f){}['_removeListener'](_0x199f8a,_0x4af793){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2d6005){return Promise['all'](_0x2d6005['map'](async _0x4a0106=>{try{return{'fulfilled':!0x0,'value':await _0x4a0106};}catch(_0x32484e){return{'fulfilled':!0x1,'reason':_0x32484e};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x216507){this['eventTarget']=_0x216507,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2b06da){const _0x5415c7=this['receivers']['find'](_0x3ea7cc=>_0x3ea7cc['isListeningto'](_0x2b06da));if(_0x5415c7)return _0x5415c7;const _0x4068b8=new Xn(_0x2b06da);return this['receivers']['push'](_0x4068b8),_0x4068b8;}['isListeningto'](_0x2030cb){return this['eventTarget']===_0x2030cb;}async['handleEvent'](_0x4988d7){const _0x177bc8=_0x4988d7,{eventId:_0x3590fc,eventType:_0x52499d,data:_0xc53ab3}=_0x177bc8['data'],_0x2e2146=this['handlersMap'][_0x52499d];if(!(_0x2e2146!=null&&_0x2e2146['size']))return;_0x177bc8['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3590fc,'eventType':_0x52499d});const _0x37f3f2=Array['from'](_0x2e2146)['map'](async _0x5d7363=>_0x5d7363(_0x177bc8['origin'],_0xc53ab3)),_0x7501bb=await cp(_0x37f3f2);_0x177bc8['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3590fc,'eventType':_0x52499d,'response':_0x7501bb});}['_subscribe'](_0x327bd3,_0x5c0cb5){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x327bd3]||(this['handlersMap'][_0x327bd3]=new Set()),this['handlersMap'][_0x327bd3]['add'](_0x5c0cb5);}['_unsubscribe'](_0x43b7a4,_0x50000a){this['handlersMap'][_0x43b7a4]&&_0x50000a&&this['handlersMap'][_0x43b7a4]['delete'](_0x50000a),(!_0x50000a||this['handlersMap'][_0x43b7a4]['size']===0x0)&&delete this['handlersMap'][_0x43b7a4],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x147acf='',_0x4cf59f=0xa){let _0x125b46='';for(let _0x36adf0=0x0;_0x36adf0<_0x4cf59f;_0x36adf0++)_0x125b46+=Math['floor'](Math['random']()*0xa);return _0x147acf+_0x125b46;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x487669){this['target']=_0x487669,this['handlers']=new Set();}['removeMessageHandler'](_0x2a93bf){_0x2a93bf['messageChannel']&&(_0x2a93bf['messageChannel']['port1']['removeEventListener']('message',_0x2a93bf['onMessage']),_0x2a93bf['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2a93bf);}async['_send'](_0x4e4fc6,_0x374451,_0x1d756d=0x32){const _0x47cddd=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x47cddd)throw new Error('connection_unavailable');let _0x51927e,_0x3a51dd;return new Promise((_0x152dde,_0x5aea14)=>{const _0x352c42=As('',0x14);_0x47cddd['port1']['start']();const _0x1fe3d9=setTimeout(()=>{_0x5aea14(new Error('unsupported_event'));},_0x1d756d);_0x3a51dd={'messageChannel':_0x47cddd,'onMessage'(_0x3365b6){const _0x5c417a=_0x3365b6;if(_0x5c417a['data']['eventId']===_0x352c42)switch(_0x5c417a['data']['status']){case'ack':clearTimeout(_0x1fe3d9),_0x51927e=setTimeout(()=>{_0x5aea14(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x51927e),_0x152dde(_0x5c417a['data']['response']);break;default:clearTimeout(_0x1fe3d9),clearTimeout(_0x51927e),_0x5aea14(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x3a51dd),_0x47cddd['port1']['addEventListener']('message',_0x3a51dd['onMessage']),this['target']['postMessage']({'eventType':_0x4e4fc6,'eventId':_0x352c42,'data':_0x374451},[_0x47cddd['port2']]);})['finally'](()=>{_0x3a51dd&&this['removeMessageHandler'](_0x3a51dd);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x413828){Z()['location']['href']=_0x413828;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4e5ca5;return((_0x4e5ca5=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4e5ca5['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1c01aa){this['request']=_0x1c01aa;}['toPromise'](){return new Promise((_0x15f30c,_0x57b39a)=>{this['request']['addEventListener']('success',()=>{_0x15f30c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x57b39a(this['request']['error']);});});}}function Zn(_0x1409f7,_0x11dea2){return _0x1409f7['transaction']([Mn],_0x11dea2?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x41e384=indexedDB['deleteDatabase'](Ka);return new nn(_0x41e384)['toPromise']();}function Qa(){const _0x32e6c2=indexedDB['open'](Ka,pp);return new Promise((_0x51fa57,_0xda928a)=>{_0x32e6c2['addEventListener']('error',()=>{_0xda928a(_0x32e6c2['error']);}),_0x32e6c2['addEventListener']('upgradeneeded',()=>{const _0x18e486=_0x32e6c2['result'];try{_0x18e486['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x32c150){_0xda928a(_0x32c150);}}),_0x32e6c2['addEventListener']('success',async()=>{const _0x693e9d=_0x32e6c2['result'];_0x693e9d['objectStoreNames']['contains'](Mn)?_0x51fa57(_0x693e9d):(_0x693e9d['close'](),await _p(),_0x51fa57(await Qa()));});});}async function Or(_0x1b628f,_0x45bc19,_0x406f35){const _0xa9ae2e=Zn(_0x1b628f,!0x0)['put']({[Ya]:_0x45bc19,'value':_0x406f35});return new nn(_0xa9ae2e)['toPromise']();}async function gp(_0x2454e3,_0x54ff96){const _0x2b4bfb=Zn(_0x2454e3,!0x1)['get'](_0x54ff96),_0x4bc0eb=await new nn(_0x2b4bfb)['toPromise']();return _0x4bc0eb===void 0x0?null:_0x4bc0eb['value'];}function Dr(_0x340898,_0x1000c6){const _0x331356=Zn(_0x340898,!0x0)['delete'](_0x1000c6);return new nn(_0x331356)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x25928a){let _0x2032ef=0x0;for(;;)try{const _0x3fbca1=await this['_openDb']();return await _0x25928a(_0x3fbca1);}catch(_0x4f18cd){if(_0x2032ef++>yp)throw _0x4f18cd;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x2b2ffc,_0x3de76f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3de76f['key'])})),this['receiver']['_subscribe']('ping',async(_0x5e7d62,_0x2dd545)=>['keyChanged']);}async['initializeSender'](){var _0x40b15d,_0x3e18e7;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x2f5d92=await this['sender']['_send']('ping',{},0x320);_0x2f5d92&&(_0x40b15d=_0x2f5d92[0x0])!=null&&_0x40b15d['fulfilled']&&(_0x3e18e7=_0x2f5d92[0x0])!=null&&_0x3e18e7['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4e94f0){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4e94f0},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x3baacd=>{await Or(_0x3baacd,Dn,'1'),await Dr(_0x3baacd,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x10d997){this['pendingWrites']++;try{await _0x10d997();}finally{this['pendingWrites']--;}}async['_set'](_0x4333a3,_0x5e607c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x34845=>Or(_0x34845,_0x4333a3,_0x5e607c)),this['localCache'][_0x4333a3]=_0x5e607c,this['notifyServiceWorker'](_0x4333a3)));}async['_get'](_0x4fa2c9){const _0x2ee953=await this['_withRetries'](_0x4a6bd1=>gp(_0x4a6bd1,_0x4fa2c9));return this['localCache'][_0x4fa2c9]=_0x2ee953,_0x2ee953;}async['_remove'](_0x1fedd9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x51de95=>Dr(_0x51de95,_0x1fedd9)),delete this['localCache'][_0x1fedd9],this['notifyServiceWorker'](_0x1fedd9)));}async['_poll'](){const _0x13895a=await this['_withRetries'](_0x211483=>{const _0x3d01be=Zn(_0x211483,!0x1)['getAll']();return new nn(_0x3d01be)['toPromise']();});if(!_0x13895a)return[];if(this['pendingWrites']!==0x0)return[];const _0x137b85=[],_0x3b72a1=new Set();if(_0x13895a['length']!==0x0){for(const {fbase_key:_0x48727f,value:_0xa927f4}of _0x13895a)_0x3b72a1['add'](_0x48727f),JSON['stringify'](this['localCache'][_0x48727f])!==JSON['stringify'](_0xa927f4)&&(this['notifyListeners'](_0x48727f,_0xa927f4),_0x137b85['push'](_0x48727f));}for(const _0x5cfd16 of Object['keys'](this['localCache']))this['localCache'][_0x5cfd16]&&!_0x3b72a1['has'](_0x5cfd16)&&(this['notifyListeners'](_0x5cfd16,null),_0x137b85['push'](_0x5cfd16));return _0x137b85;}['notifyListeners'](_0x5bd2b1,_0x54ec11){this['localCache'][_0x5bd2b1]=_0x54ec11;const _0x335757=this['listeners'][_0x5bd2b1];if(_0x335757){for(const _0x3b3d4d of Array['from'](_0x335757))_0x3b3d4d(_0x54ec11);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4e185b,_0xeed6d0){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4e185b]||(this['listeners'][_0x4e185b]=new Set(),this['_get'](_0x4e185b)),this['listeners'][_0x4e185b]['add'](_0xeed6d0);}['_removeListener'](_0x1e55e8,_0x5d2cc0){this['listeners'][_0x1e55e8]&&(this['listeners'][_0x1e55e8]['delete'](_0x5d2cc0),this['listeners'][_0x1e55e8]['size']===0x0&&delete this['listeners'][_0x1e55e8]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x1f644f,_0x230b50){return _0x230b50?ie(_0x230b50):(m(_0x1f644f['_popupRedirectResolver'],_0x1f644f,'argument-error'),_0x1f644f['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2f0c21){super('custom','custom'),this['params']=_0x2f0c21;}['_getIdTokenResponse'](_0xd5c2fa){return nt(_0xd5c2fa,this['_buildIdpRequest']());}['_linkToIdToken'](_0x5926dc,_0x2a86b4){return nt(_0x5926dc,this['_buildIdpRequest'](_0x2a86b4));}['_getReauthenticationResolver'](_0x5afcc0){return nt(_0x5afcc0,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x95b88a){const _0x3e5694={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x95b88a&&(_0x3e5694['idToken']=_0x95b88a),_0x3e5694;}}function Ip(_0x39fc82){return Va(_0x39fc82['auth'],new ks(_0x39fc82),_0x39fc82['bypassAuthState']);}function wp(_0x10c99c){const {auth:_0x31a16c,user:_0x52aa47}=_0x10c99c;return m(_0x52aa47,_0x31a16c,'internal-error'),tp(_0x52aa47,new ks(_0x10c99c),_0x10c99c['bypassAuthState']);}async function Cp(_0x144349){const {auth:_0x3cf22a,user:_0x566d80}=_0x144349;return m(_0x566d80,_0x3cf22a,'internal-error'),ep(_0x566d80,new ks(_0x144349),_0x144349['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x237552,_0x3daf1b,_0x4ed440,_0x45a517,_0x5bad76=!0x1){this['auth']=_0x237552,this['resolver']=_0x4ed440,this['user']=_0x45a517,this['bypassAuthState']=_0x5bad76,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3daf1b)?_0x3daf1b:[_0x3daf1b];}['execute'](){return new Promise(async(_0x58b21d,_0x41f2f5)=>{this['pendingPromise']={'resolve':_0x58b21d,'reject':_0x41f2f5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2bebc7){this['reject'](_0x2bebc7);}});}async['onAuthEvent'](_0x3cfa16){const {urlResponse:_0x5c8b49,sessionId:_0x35ac96,postBody:_0x337179,tenantId:_0x3c46a1,error:_0x54d1eb,type:_0x3ef9f3}=_0x3cfa16;if(_0x54d1eb){this['reject'](_0x54d1eb);return;}const _0x27306d={'auth':this['auth'],'requestUri':_0x5c8b49,'sessionId':_0x35ac96,'tenantId':_0x3c46a1||void 0x0,'postBody':_0x337179||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3ef9f3)(_0x27306d));}catch(_0x43c246){this['reject'](_0x43c246);}}['onError'](_0x21d61e){this['reject'](_0x21d61e);}['getIdpTask'](_0x2426b8){switch(_0x2426b8){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x5741fd){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5741fd),this['unregisterAndCleanUp']();}['reject'](_0x186f0b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x186f0b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x142e68,_0x432746,_0xd5a609,_0x33c1ce,_0x4d914f){super(_0x142e68,_0x432746,_0x33c1ce,_0x4d914f),this['provider']=_0xd5a609,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3ee009=await this['execute']();return m(_0x3ee009,this['auth'],'internal-error'),_0x3ee009;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5b8177=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5b8177),this['authWindow']['associatedEvent']=_0x5b8177,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4f2284=>{this['reject'](_0x4f2284);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5a1218=>{_0x5a1218||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x58e804;return((_0x58e804=this['authWindow'])==null?void 0x0:_0x58e804['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1b6c51=()=>{var _0x210956,_0x54addc;if((_0x54addc=(_0x210956=this['authWindow'])==null?void 0x0:_0x210956['window'])!=null&&_0x54addc['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1b6c51,Tp['get']());};_0x1b6c51();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x25a5ff,_0x47464c,_0x2ae856=!0x1){super(_0x25a5ff,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x47464c,void 0x0,_0x2ae856),this['eventId']=null;}async['execute'](){let _0x13846f=hn['get'](this['auth']['_key']());if(!_0x13846f){try{const _0x19b51c=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x13846f=()=>Promise['resolve'](_0x19b51c);}catch(_0x12b696){_0x13846f=()=>Promise['reject'](_0x12b696);}hn['set'](this['auth']['_key'](),_0x13846f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x13846f();}async['onAuthEvent'](_0x29ac6c){if(_0x29ac6c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x29ac6c);if(_0x29ac6c['type']==='unknown'){this['resolve'](null);return;}if(_0x29ac6c['eventId']){const _0x1cf774=await this['auth']['_redirectUserForId'](_0x29ac6c['eventId']);if(_0x1cf774)return this['user']=_0x1cf774,super['onAuthEvent'](_0x29ac6c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3cb469,_0x381ad0){const _0x348f08=Pp(_0x381ad0),_0xb6f98a=kp(_0x3cb469);if(!await _0xb6f98a['_isAvailable']())return!0x1;const _0x8d7bc9=await _0xb6f98a['_get'](_0x348f08)==='true';return await _0xb6f98a['_remove'](_0x348f08),_0x8d7bc9;}function Ap(_0x7dfbb,_0x1aec10){hn['set'](_0x7dfbb['_key'](),_0x1aec10);}function kp(_0x51d298){return ie(_0x51d298['_redirectPersistence']);}function Pp(_0x3dfb88){return ln(Sp,_0x3dfb88['config']['apiKey'],_0x3dfb88['name']);}async function Np(_0x86bdbb,_0x1857b6,_0x51809d=!0x1){if($(_0x86bdbb['app']))return Promise['reject'](re(_0x86bdbb));const _0x3d5a58=Ke(_0x86bdbb),_0x459414=Ep(_0x3d5a58,_0x1857b6),_0x315e5c=await new bp(_0x3d5a58,_0x459414,_0x51809d)['execute']();return _0x315e5c&&!_0x51809d&&(delete _0x315e5c['user']['_redirectEventId'],await _0x3d5a58['_persistUserIfCurrent'](_0x315e5c['user']),await _0x3d5a58['_setRedirectUser'](null,_0x1857b6)),_0x315e5c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3d5934){this['auth']=_0x3d5934,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3b4213){this['consumers']['add'](_0x3b4213),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3b4213)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3b4213),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2b640c){this['consumers']['delete'](_0x2b640c);}['onEvent'](_0x5cf428){if(this['hasEventBeenHandled'](_0x5cf428))return!0x1;let _0x120b32=!0x1;return this['consumers']['forEach'](_0x519cfd=>{this['isEventForConsumer'](_0x5cf428,_0x519cfd)&&(_0x120b32=!0x0,this['sendToConsumer'](_0x5cf428,_0x519cfd),this['saveEventToCache'](_0x5cf428));}),this['hasHandledPotentialRedirect']||!Mp(_0x5cf428)||(this['hasHandledPotentialRedirect']=!0x0,_0x120b32||(this['queuedRedirectEvent']=_0x5cf428,_0x120b32=!0x0)),_0x120b32;}['sendToConsumer'](_0x1f1f0d,_0x2a6209){var _0x31c9bd;if(_0x1f1f0d['error']&&!Za(_0x1f1f0d)){const _0x49fb50=((_0x31c9bd=_0x1f1f0d['error']['code'])==null?void 0x0:_0x31c9bd['split']('auth/')[0x1])||'internal-error';_0x2a6209['onError'](X(this['auth'],_0x49fb50));}else _0x2a6209['onAuthEvent'](_0x1f1f0d);}['isEventForConsumer'](_0x30317c,_0x4680f3){const _0x336985=_0x4680f3['eventId']===null||!!_0x30317c['eventId']&&_0x30317c['eventId']===_0x4680f3['eventId'];return _0x4680f3['filter']['includes'](_0x30317c['type'])&&_0x336985;}['hasEventBeenHandled'](_0x1d21ee){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1d21ee));}['saveEventToCache'](_0x2f7277){this['cachedEventUids']['add'](Mr(_0x2f7277)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x13b524){return[_0x13b524['type'],_0x13b524['eventId'],_0x13b524['sessionId'],_0x13b524['tenantId']]['filter'](_0x245cb2=>_0x245cb2)['join']('-');}function Za({type:_0x2252ea,error:_0x112d06}){return _0x2252ea==='unknown'&&(_0x112d06==null?void 0x0:_0x112d06['code'])==='auth/no-auth-event';}function Mp(_0x16da37){switch(_0x16da37['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x16da37);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x25bd09,_0x4ca93c={}){return Pe(_0x25bd09,'GET','/v1/projects',_0x4ca93c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x3a6aa8){if(_0x3a6aa8['config']['emulator'])return;const {authorizedDomains:_0x2da26b}=await Lp(_0x3a6aa8);for(const _0x2e8233 of _0x2da26b)try{if(Wp(_0x2e8233))return;}catch{}Y(_0x3a6aa8,'unauthorized-domain');}function Wp(_0x4158ad){const _0x5c42ad=Mi(),{protocol:_0x1158ec,hostname:_0x44f4d3}=new URL(_0x5c42ad);if(_0x4158ad['startsWith']('chrome-extension://')){const _0x47bb0e=new URL(_0x4158ad);return _0x47bb0e['hostname']===''&&_0x44f4d3===''?_0x1158ec==='chrome-extension:'&&_0x4158ad['replace']('chrome-extension://','')===_0x5c42ad['replace']('chrome-extension://',''):_0x1158ec==='chrome-extension:'&&_0x47bb0e['hostname']===_0x44f4d3;}if(!Fp['test'](_0x1158ec))return!0x1;if(xp['test'](_0x4158ad))return _0x44f4d3===_0x4158ad;const _0x405f66=_0x4158ad['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x405f66+'|'+_0x405f66+')$','i')['test'](_0x44f4d3);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x1d07d6=Z()['___jsl'];if(_0x1d07d6!=null&&_0x1d07d6['H']){for(const _0x55ae1b of Object['keys'](_0x1d07d6['H']))if(_0x1d07d6['H'][_0x55ae1b]['r']=_0x1d07d6['H'][_0x55ae1b]['r']||[],_0x1d07d6['H'][_0x55ae1b]['L']=_0x1d07d6['H'][_0x55ae1b]['L']||[],_0x1d07d6['H'][_0x55ae1b]['r']=[..._0x1d07d6['H'][_0x55ae1b]['L']],_0x1d07d6['CP']){for(let _0x4d85eb=0x0;_0x4d85eb<_0x1d07d6['CP']['length'];_0x4d85eb++)_0x1d07d6['CP'][_0x4d85eb]=null;}}}function Vp(_0x34e73e){return new Promise((_0x4141b1,_0x15116e)=>{var _0x25b344,_0x232342,_0x21f69e;function _0x1f6bcd(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4141b1(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x15116e(X(_0x34e73e,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x232342=(_0x25b344=Z()['gapi'])==null?void 0x0:_0x25b344['iframes'])!=null&&_0x232342['Iframe'])_0x4141b1(gapi['iframes']['getContext']());else{if((_0x21f69e=Z()['gapi'])!=null&&_0x21f69e['load'])_0x1f6bcd();else{const _0x4f3815=Ff('iframefcb');return Z()[_0x4f3815]=()=>{gapi['load']?_0x1f6bcd():_0x15116e(X(_0x34e73e,'network-request-failed'));},xa(xf()+'?onload='+_0x4f3815)['catch'](_0x20130c=>_0x15116e(_0x20130c));}}})['catch'](_0x23ea03=>{throw un=null,_0x23ea03;});}let un=null;function Hp(_0x299ee8){return un=un||Vp(_0x299ee8),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0xa98db1){const _0x1e4175=_0xa98db1['config'];m(_0x1e4175['authDomain'],_0xa98db1,'auth-domain-config-required');const _0x11de51=_0x1e4175['emulator']?Cs(_0x1e4175,qp):'https://'+_0xa98db1['config']['authDomain']+'/'+Gp,_0x3edb47={'apiKey':_0x1e4175['apiKey'],'appName':_0xa98db1['name'],'v':dt},_0x5140bd=jp['get'](_0xa98db1['config']['apiHost']);_0x5140bd&&(_0x3edb47['eid']=_0x5140bd);const _0xdb010c=_0xa98db1['_getFrameworks']();return _0xdb010c['length']&&(_0x3edb47['fw']=_0xdb010c['join'](',')),_0x11de51+'?'+ut(_0x3edb47)['slice'](0x1);}async function Yp(_0x1bdd93){const _0x1b95f6=await Hp(_0x1bdd93),_0x105108=Z()['gapi'];return m(_0x105108,_0x1bdd93,'internal-error'),_0x1b95f6['open']({'where':document['body'],'url':Kp(_0x1bdd93),'messageHandlersFilter':_0x105108['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x302294=>new Promise(async(_0x25513a,_0x4d28be)=>{await _0x302294['restyle']({'setHideOnLeave':!0x1});const _0x3db9e0=X(_0x1bdd93,'network-request-failed'),_0x1d271e=Z()['setTimeout'](()=>{_0x4d28be(_0x3db9e0);},$p['get']());function _0x6a0a41(){Z()['clearTimeout'](_0x1d271e),_0x25513a(_0x302294);}_0x302294['ping'](_0x6a0a41)['then'](_0x6a0a41,()=>{_0x4d28be(_0x3db9e0);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x69529){this['window']=_0x69529,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x59e21b,_0x44f960,_0x950832,_0x373bf7=Jp,_0x381b8d=Xp){const _0x1fcdc8=Math['max']((window['screen']['availHeight']-_0x381b8d)/0x2,0x0)['toString'](),_0x3d9a32=Math['max']((window['screen']['availWidth']-_0x373bf7)/0x2,0x0)['toString']();let _0x1d1fe7='';const _0x509e43={...Qp,'width':_0x373bf7['toString'](),'height':_0x381b8d['toString'](),'top':_0x1fcdc8,'left':_0x3d9a32},_0x3c87b6=W()['toLowerCase']();_0x950832&&(_0x1d1fe7=ka(_0x3c87b6)?Zp:_0x950832),Ra(_0x3c87b6)&&(_0x44f960=_0x44f960||e_,_0x509e43['scrollbars']='yes');const _0xf6dad5=Object['entries'](_0x509e43)['reduce']((_0x89366a,[_0x41e28e,_0x4bce0a])=>''+_0x89366a+_0x41e28e+'='+_0x4bce0a+',','');if(Rf(_0x3c87b6)&&_0x1d1fe7!=='_self')return n_(_0x44f960||'',_0x1d1fe7),new xr(null);const _0x5c660e=window['open'](_0x44f960||'',_0x1d1fe7,_0xf6dad5);m(_0x5c660e,_0x59e21b,'popup-blocked');try{_0x5c660e['focus']();}catch{}return new xr(_0x5c660e);}function n_(_0x10217a,_0x18e15e){const _0x5b789e=document['createElement']('a');_0x5b789e['href']=_0x10217a,_0x5b789e['target']=_0x18e15e;const _0x54fd8d=document['createEvent']('MouseEvent');_0x54fd8d['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5b789e['dispatchEvent'](_0x54fd8d);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x136c1c,_0x359790,_0x42dedc,_0x1580b5,_0x241776,_0xb4ef73){m(_0x136c1c['config']['authDomain'],_0x136c1c,'auth-domain-config-required'),m(_0x136c1c['config']['apiKey'],_0x136c1c,'invalid-api-key');const _0x4bbdab={'apiKey':_0x136c1c['config']['apiKey'],'appName':_0x136c1c['name'],'authType':_0x42dedc,'redirectUrl':_0x1580b5,'v':dt,'eventId':_0x241776};if(_0x359790 instanceof Wa){_0x359790['setDefaultLanguage'](_0x136c1c['languageCode']),_0x4bbdab['providerId']=_0x359790['providerId']||'',pn(_0x359790['getCustomParameters']())||(_0x4bbdab['customParameters']=JSON['stringify'](_0x359790['getCustomParameters']()));for(const [_0x2e015d,_0x16988e]of Object['entries']({}))_0x4bbdab[_0x2e015d]=_0x16988e;}if(_0x359790 instanceof tn){const _0x4ec4e8=_0x359790['getScopes']()['filter'](_0x305ccc=>_0x305ccc!=='');_0x4ec4e8['length']>0x0&&(_0x4bbdab['scopes']=_0x4ec4e8['join'](','));}_0x136c1c['tenantId']&&(_0x4bbdab['tid']=_0x136c1c['tenantId']);const _0x5e3f2b=_0x4bbdab;for(const _0x5b2dcc of Object['keys'](_0x5e3f2b))_0x5e3f2b[_0x5b2dcc]===void 0x0&&delete _0x5e3f2b[_0x5b2dcc];const _0x56a592=await _0x136c1c['_getAppCheckToken'](),_0x25ad4c=_0x56a592?'#'+r_+'='+encodeURIComponent(_0x56a592):'';return o_(_0x136c1c)+'?'+ut(_0x5e3f2b)['slice'](0x1)+_0x25ad4c;}function o_({config:_0x137090}){return _0x137090['emulator']?Cs(_0x137090,s_):'https://'+_0x137090['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xcc683,_0xf21bdb,_0x29c927,_0x2119df){var _0x18a528;ce((_0x18a528=this['eventManagers'][_0xcc683['_key']()])==null?void 0x0:_0x18a528['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x377b7d=await Fr(_0xcc683,_0xf21bdb,_0x29c927,Mi(),_0x2119df);return t_(_0xcc683,_0x377b7d,As());}async['_openRedirect'](_0x37e205,_0x314578,_0x2410ba,_0x3569c4){await this['_originValidation'](_0x37e205);const _0x241d3f=await Fr(_0x37e205,_0x314578,_0x2410ba,Mi(),_0x3569c4);return hp(_0x241d3f),new Promise(()=>{});}['_initialize'](_0x28ac07){const _0xcd73a3=_0x28ac07['_key']();if(this['eventManagers'][_0xcd73a3]){const {manager:_0x1c3713,promise:_0x16da83}=this['eventManagers'][_0xcd73a3];return _0x1c3713?Promise['resolve'](_0x1c3713):(ce(_0x16da83,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x16da83);}const _0x464fde=this['initAndGetManager'](_0x28ac07);return this['eventManagers'][_0xcd73a3]={'promise':_0x464fde},_0x464fde['catch'](()=>{delete this['eventManagers'][_0xcd73a3];}),_0x464fde;}async['initAndGetManager'](_0x23ec3b){const _0x45d36c=await Yp(_0x23ec3b),_0x96216e=new Dp(_0x23ec3b);return _0x45d36c['register']('authEvent',_0x40fcf9=>(m(_0x40fcf9==null?void 0x0:_0x40fcf9['authEvent'],_0x23ec3b,'invalid-auth-event'),{'status':_0x96216e['onEvent'](_0x40fcf9['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x23ec3b['_key']()]={'manager':_0x96216e},this['iframes'][_0x23ec3b['_key']()]=_0x45d36c,_0x96216e;}['_isIframeWebStorageSupported'](_0x45ef70,_0x37d9e8){this['iframes'][_0x45ef70['_key']()]['send'](pi,{'type':pi},_0x495565=>{var _0x30e631;const _0x2a442e=(_0x30e631=_0x495565==null?void 0x0:_0x495565[0x0])==null?void 0x0:_0x30e631[pi];_0x2a442e!==void 0x0&&_0x37d9e8(!!_0x2a442e),Y(_0x45ef70,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x252ba9){const _0x4eca5c=_0x252ba9['_key']();return this['originValidationPromises'][_0x4eca5c]||(this['originValidationPromises'][_0x4eca5c]=Up(_0x252ba9)),this['originValidationPromises'][_0x4eca5c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0xbeb5a2){this['auth']=_0xbeb5a2,this['internalListeners']=new Map();}['getUid'](){var _0x5b6916;return this['assertAuthConfigured'](),((_0x5b6916=this['auth']['currentUser'])==null?void 0x0:_0x5b6916['uid'])||null;}async['getToken'](_0x558f86){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x558f86)}:null;}['addAuthTokenListener'](_0x71a8c4){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x71a8c4))return;const _0x183217=this['auth']['onIdTokenChanged'](_0x932bc4=>{_0x71a8c4((_0x932bc4==null?void 0x0:_0x932bc4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x71a8c4,_0x183217),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x429804){this['assertAuthConfigured']();const _0x5979e5=this['internalListeners']['get'](_0x429804);_0x5979e5&&(this['internalListeners']['delete'](_0x429804),_0x5979e5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x4fd33e){switch(_0x4fd33e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x377622){st(new Fe('auth',(_0x5e073c,{options:_0x4616e7})=>{const _0x304ac3=_0x5e073c['getProvider']('app')['getImmediate'](),_0x4859d5=_0x5e073c['getProvider']('heartbeat'),_0x2a2a22=_0x5e073c['getProvider']('app-check-internal'),{apiKey:_0x3f4918,authDomain:_0x4d63c2}=_0x304ac3['options'];m(_0x3f4918&&!_0x3f4918['includes'](':'),'invalid-api-key',{'appName':_0x304ac3['name']});const _0x46cd48={'apiKey':_0x3f4918,'authDomain':_0x4d63c2,'clientPlatform':_0x377622,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x377622)},_0x226864=new Df(_0x304ac3,_0x4859d5,_0x2a2a22,_0x46cd48);return Hf(_0x226864,_0x4616e7),_0x226864;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3d24c5,_0x32b3db,_0x2d1ae6)=>{_0x3d24c5['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x47fefb=>{const _0x40443f=Ke(_0x47fefb['getProvider']('auth')['getImmediate']());return(_0x472477=>new l_(_0x472477))(_0x40443f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x377622)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x397b36=>async _0x103eb8=>{const _0x319905=_0x103eb8&&await _0x103eb8['getIdTokenResult'](),_0x3a3488=_0x319905&&(new Date()['getTime']()-Date['parse'](_0x319905['issuedAtTime']))/0x3e8;if(_0x3a3488&&_0x3a3488>f_)return;const _0x489bfa=_0x319905==null?void 0x0:_0x319905['token'];Br!==_0x489bfa&&(Br=_0x489bfa,await fetch(_0x397b36,{'method':_0x489bfa?'POST':'DELETE','headers':_0x489bfa?{'Authorization':'Bearer\x20'+_0x489bfa}:{}}));};function B_(_0x4cd65b=Zr()){const _0x211872=Hi(_0x4cd65b,'auth');if(_0x211872['isInitialized']())return _0x211872['getImmediate']();const _0x505b9c=Vf(_0x4cd65b,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x4fa8a3=jr('authTokenSyncURL');if(_0x4fa8a3&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x9c9e13=new URL(_0x4fa8a3,location['origin']);if(location['origin']===_0x9c9e13['origin']){const _0x2d1da7=p_(_0x9c9e13['toString']());sp(_0x505b9c,_0x2d1da7,()=>_0x2d1da7(_0x505b9c['currentUser'])),ip(_0x505b9c,_0x3cb654=>_0x2d1da7(_0x3cb654));}}const _0x3813af=qr('auth');return _0x3813af&&$f(_0x505b9c,'http://'+_0x3813af),_0x505b9c;}function __(){var _0x921adf;return((_0x921adf=document['getElementsByTagName']('head'))==null?void 0x0:_0x921adf[0x0])??document;}Mf({'loadJS'(_0x2b2bd2){return new Promise((_0xbedeb9,_0x367824)=>{const _0x36c674=document['createElement']('script');_0x36c674['setAttribute']('src',_0x2b2bd2),_0x36c674['onload']=_0xbedeb9,_0x36c674['onerror']=_0x3c4ebd=>{const _0x283987=X('internal-error');_0x283987['customData']=_0x3c4ebd,_0x367824(_0x283987);},_0x36c674['type']='text/javascript',_0x36c674['charset']='UTF-8',__()['appendChild'](_0x36c674);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};