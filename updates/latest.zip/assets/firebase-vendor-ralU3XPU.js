const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x8fedcb,_0x15a540){if(!_0x8fedcb)throw ht(_0x15a540);},ht=function(_0x5d1785){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5d1785);},Hr=function(_0x35b439){const _0x248dd7=[];let _0x46eb42=0x0;for(let _0x489976=0x0;_0x489976<_0x35b439['length'];_0x489976++){let _0x1c3c01=_0x35b439['charCodeAt'](_0x489976);_0x1c3c01<0x80?_0x248dd7[_0x46eb42++]=_0x1c3c01:_0x1c3c01<0x800?(_0x248dd7[_0x46eb42++]=_0x1c3c01>>0x6|0xc0,_0x248dd7[_0x46eb42++]=_0x1c3c01&0x3f|0x80):(_0x1c3c01&0xfc00)===0xd800&&_0x489976+0x1<_0x35b439['length']&&(_0x35b439['charCodeAt'](_0x489976+0x1)&0xfc00)===0xdc00?(_0x1c3c01=0x10000+((_0x1c3c01&0x3ff)<<0xa)+(_0x35b439['charCodeAt'](++_0x489976)&0x3ff),_0x248dd7[_0x46eb42++]=_0x1c3c01>>0x12|0xf0,_0x248dd7[_0x46eb42++]=_0x1c3c01>>0xc&0x3f|0x80,_0x248dd7[_0x46eb42++]=_0x1c3c01>>0x6&0x3f|0x80,_0x248dd7[_0x46eb42++]=_0x1c3c01&0x3f|0x80):(_0x248dd7[_0x46eb42++]=_0x1c3c01>>0xc|0xe0,_0x248dd7[_0x46eb42++]=_0x1c3c01>>0x6&0x3f|0x80,_0x248dd7[_0x46eb42++]=_0x1c3c01&0x3f|0x80);}return _0x248dd7;},nc=function(_0x33e1b1){const _0x5b0553=[];let _0x1eecf7=0x0,_0x5d3fd5=0x0;for(;_0x1eecf7<_0x33e1b1['length'];){const _0x394e4b=_0x33e1b1[_0x1eecf7++];if(_0x394e4b<0x80)_0x5b0553[_0x5d3fd5++]=String['fromCharCode'](_0x394e4b);else{if(_0x394e4b>0xbf&&_0x394e4b<0xe0){const _0xc787d9=_0x33e1b1[_0x1eecf7++];_0x5b0553[_0x5d3fd5++]=String['fromCharCode']((_0x394e4b&0x1f)<<0x6|_0xc787d9&0x3f);}else{if(_0x394e4b>0xef&&_0x394e4b<0x16d){const _0x2930bf=_0x33e1b1[_0x1eecf7++],_0x453917=_0x33e1b1[_0x1eecf7++],_0x22de42=_0x33e1b1[_0x1eecf7++],_0x41361b=((_0x394e4b&0x7)<<0x12|(_0x2930bf&0x3f)<<0xc|(_0x453917&0x3f)<<0x6|_0x22de42&0x3f)-0x10000;_0x5b0553[_0x5d3fd5++]=String['fromCharCode'](0xd800+(_0x41361b>>0xa)),_0x5b0553[_0x5d3fd5++]=String['fromCharCode'](0xdc00+(_0x41361b&0x3ff));}else{const _0x16820f=_0x33e1b1[_0x1eecf7++],_0x35ab02=_0x33e1b1[_0x1eecf7++];_0x5b0553[_0x5d3fd5++]=String['fromCharCode']((_0x394e4b&0xf)<<0xc|(_0x16820f&0x3f)<<0x6|_0x35ab02&0x3f);}}}}return _0x5b0553['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x3e2ec8,_0x2680cd){if(!Array['isArray'](_0x3e2ec8))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4cc464=_0x2680cd?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x50de96=[];for(let _0x1d3716=0x0;_0x1d3716<_0x3e2ec8['length'];_0x1d3716+=0x3){const _0x3c2dec=_0x3e2ec8[_0x1d3716],_0x18486f=_0x1d3716+0x1<_0x3e2ec8['length'],_0x3f6f04=_0x18486f?_0x3e2ec8[_0x1d3716+0x1]:0x0,_0x1def46=_0x1d3716+0x2<_0x3e2ec8['length'],_0x9fae5e=_0x1def46?_0x3e2ec8[_0x1d3716+0x2]:0x0,_0x2acb8a=_0x3c2dec>>0x2,_0x46a654=(_0x3c2dec&0x3)<<0x4|_0x3f6f04>>0x4;let _0xb40a18=(_0x3f6f04&0xf)<<0x2|_0x9fae5e>>0x6,_0xad2848=_0x9fae5e&0x3f;_0x1def46||(_0xad2848=0x40,_0x18486f||(_0xb40a18=0x40)),_0x50de96['push'](_0x4cc464[_0x2acb8a],_0x4cc464[_0x46a654],_0x4cc464[_0xb40a18],_0x4cc464[_0xad2848]);}return _0x50de96['join']('');},'encodeString'(_0x3253de,_0x5a7f90){return this['HAS_NATIVE_SUPPORT']&&!_0x5a7f90?btoa(_0x3253de):this['encodeByteArray'](Hr(_0x3253de),_0x5a7f90);},'decodeString'(_0x3ea3be,_0x3d146b){return this['HAS_NATIVE_SUPPORT']&&!_0x3d146b?atob(_0x3ea3be):nc(this['decodeStringToByteArray'](_0x3ea3be,_0x3d146b));},'decodeStringToByteArray'(_0x9f1500,_0x2a121a){this['init_']();const _0x264b9b=_0x2a121a?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x10f908=[];for(let _0x1b79f2=0x0;_0x1b79f2<_0x9f1500['length'];){const _0x29f82a=_0x264b9b[_0x9f1500['charAt'](_0x1b79f2++)],_0x1d3d81=_0x1b79f2<_0x9f1500['length']?_0x264b9b[_0x9f1500['charAt'](_0x1b79f2)]:0x0;++_0x1b79f2;const _0x245257=_0x1b79f2<_0x9f1500['length']?_0x264b9b[_0x9f1500['charAt'](_0x1b79f2)]:0x40;++_0x1b79f2;const _0x54919a=_0x1b79f2<_0x9f1500['length']?_0x264b9b[_0x9f1500['charAt'](_0x1b79f2)]:0x40;if(++_0x1b79f2,_0x29f82a==null||_0x1d3d81==null||_0x245257==null||_0x54919a==null)throw new ic();const _0x10d9bf=_0x29f82a<<0x2|_0x1d3d81>>0x4;if(_0x10f908['push'](_0x10d9bf),_0x245257!==0x40){const _0x392f0d=_0x1d3d81<<0x4&0xf0|_0x245257>>0x2;if(_0x10f908['push'](_0x392f0d),_0x54919a!==0x40){const _0x25b31f=_0x245257<<0x6&0xc0|_0x54919a;_0x10f908['push'](_0x25b31f);}}}return _0x10f908;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x521c03=0x0;_0x521c03<this['ENCODED_VALS']['length'];_0x521c03++)this['byteToCharMap_'][_0x521c03]=this['ENCODED_VALS']['charAt'](_0x521c03),this['charToByteMap_'][this['byteToCharMap_'][_0x521c03]]=_0x521c03,this['byteToCharMapWebSafe_'][_0x521c03]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x521c03),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x521c03]]=_0x521c03,_0x521c03>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x521c03)]=_0x521c03,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x521c03)]=_0x521c03);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x179e06){const _0x45d1fb=Hr(_0x179e06);return Fi['encodeByteArray'](_0x45d1fb,!0x0);},dn=function(_0x360bae){return $r(_0x360bae)['replace'](/\./g,'');},fn=function(_0x860e49){try{return Fi['decodeString'](_0x860e49,!0x0);}catch(_0x49e437){console['error']('base64Decode\x20failed:\x20',_0x49e437);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2d2bb8){return Gr(void 0x0,_0x2d2bb8);}function Gr(_0x29484d,_0x3ee58b){if(!(_0x3ee58b instanceof Object))return _0x3ee58b;switch(_0x3ee58b['constructor']){case Date:const _0x2dbf9a=_0x3ee58b;return new Date(_0x2dbf9a['getTime']());case Object:_0x29484d===void 0x0&&(_0x29484d={});break;case Array:_0x29484d=[];break;default:return _0x3ee58b;}for(const _0x28811d in _0x3ee58b)!_0x3ee58b['hasOwnProperty'](_0x28811d)||!rc(_0x28811d)||(_0x29484d[_0x28811d]=Gr(_0x29484d[_0x28811d],_0x3ee58b[_0x28811d]));return _0x29484d;}function rc(_0x444331){return _0x444331!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x3e4049=Ps['__FIREBASE_DEFAULTS__'];if(_0x3e4049)return JSON['parse'](_0x3e4049);},lc=()=>{if(typeof document>'u')return;let _0x4b6ac5;try{_0x4b6ac5=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x39410d=_0x4b6ac5&&fn(_0x4b6ac5[0x1]);return _0x39410d&&JSON['parse'](_0x39410d);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0xfdfa11){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xfdfa11);return;}},qr=_0x54f12c=>{var _0x59accf,_0x316d9b;return(_0x316d9b=(_0x59accf=Ui())==null?void 0x0:_0x59accf['emulatorHosts'])==null?void 0x0:_0x316d9b[_0x54f12c];},hc=_0x374a3c=>{const _0x838d69=qr(_0x374a3c);if(!_0x838d69)return;const _0x396ca2=_0x838d69['lastIndexOf'](':');if(_0x396ca2<=0x0||_0x396ca2+0x1===_0x838d69['length'])throw new Error('Invalid\x20host\x20'+_0x838d69+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2733d0=parseInt(_0x838d69['substring'](_0x396ca2+0x1),0xa);return _0x838d69[0x0]==='['?[_0x838d69['substring'](0x1,_0x396ca2-0x1),_0x2733d0]:[_0x838d69['substring'](0x0,_0x396ca2),_0x2733d0];},zr=()=>{var _0x5b1581;return(_0x5b1581=Ui())==null?void 0x0:_0x5b1581['config'];},jr=_0x240a5d=>{var _0x2d33c0;return(_0x2d33c0=Ui())==null?void 0x0:_0x2d33c0['_'+_0x240a5d];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0xfd86f8,_0xc7031e)=>{this['resolve']=_0xfd86f8,this['reject']=_0xc7031e;});}['wrapCallback'](_0xba89e7){return(_0x8703c1,_0x1e1515)=>{_0x8703c1?this['reject'](_0x8703c1):this['resolve'](_0x1e1515),typeof _0xba89e7=='function'&&(this['promise']['catch'](()=>{}),_0xba89e7['length']===0x1?_0xba89e7(_0x8703c1):_0xba89e7(_0x8703c1,_0x1e1515));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4766a8,_0x51346c){if(_0x4766a8['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x23b967={'alg':'none','type':'JWT'},_0x19daea=_0x51346c||'demo-project',_0x1e9fab=_0x4766a8['iat']||0x0,_0x593c7a=_0x4766a8['sub']||_0x4766a8['user_id'];if(!_0x593c7a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x4ebcbb={'iss':'https://securetoken.google.com/'+_0x19daea,'aud':_0x19daea,'iat':_0x1e9fab,'exp':_0x1e9fab+0xe10,'auth_time':_0x1e9fab,'sub':_0x593c7a,'user_id':_0x593c7a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4766a8};return[dn(JSON['stringify'](_0x23b967)),dn(JSON['stringify'](_0x4ebcbb)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x3b94b8=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3b94b8=='object'&&_0x3b94b8['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xd2d0a1=W();return _0xd2d0a1['indexOf']('MSIE\x20')>=0x0||_0xd2d0a1['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x18bbf7,_0x36bd26)=>{try{let _0x22f63d=!0x0;const _0x1704a0='validate-browser-context-for-indexeddb-analytics-module',_0x15e5bb=self['indexedDB']['open'](_0x1704a0);_0x15e5bb['onsuccess']=()=>{_0x15e5bb['result']['close'](),_0x22f63d||self['indexedDB']['deleteDatabase'](_0x1704a0),_0x18bbf7(!0x0);},_0x15e5bb['onupgradeneeded']=()=>{_0x22f63d=!0x1;},_0x15e5bb['onerror']=()=>{var _0x27e8ef;_0x36bd26(((_0x27e8ef=_0x15e5bb['error'])==null?void 0x0:_0x27e8ef['message'])||'');};}catch(_0x35bbe9){_0x36bd26(_0x35bbe9);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x17ba36,_0x1ff0db,_0x4ca2c7){super(_0x1ff0db),this['code']=_0x17ba36,this['customData']=_0x4ca2c7,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x5decb6,_0xa19fbc,_0x1d992e){this['service']=_0x5decb6,this['serviceName']=_0xa19fbc,this['errors']=_0x1d992e;}['create'](_0x33149c,..._0x3d8e16){const _0x274c7d=_0x3d8e16[0x0]||{},_0x4f8508=this['service']+'/'+_0x33149c,_0x2b31b2=this['errors'][_0x33149c],_0x5490ba=_0x2b31b2?vc(_0x2b31b2,_0x274c7d):'Error',_0x746603=this['serviceName']+':\x20'+_0x5490ba+'\x20('+_0x4f8508+').';return new Re(_0x4f8508,_0x746603,_0x274c7d);}}function vc(_0x1eb8cc,_0x392ba7){return _0x1eb8cc['replace'](Ec,(_0x3b10b0,_0x7ce24a)=>{const _0x3c90fe=_0x392ba7[_0x7ce24a];return _0x3c90fe!=null?String(_0x3c90fe):'<'+_0x7ce24a+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x11d516){return JSON['parse'](_0x11d516);}function O(_0x202c25){return JSON['stringify'](_0x202c25);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x546d78){let _0x285ce9={},_0x5f4276={},_0x331f39={},_0x56d525='';try{const _0x1495a9=_0x546d78['split']('.');_0x285ce9=Nt(fn(_0x1495a9[0x0])||''),_0x5f4276=Nt(fn(_0x1495a9[0x1])||''),_0x56d525=_0x1495a9[0x2],_0x331f39=_0x5f4276['d']||{},delete _0x5f4276['d'];}catch{}return{'header':_0x285ce9,'claims':_0x5f4276,'data':_0x331f39,'signature':_0x56d525};},Ic=function(_0x37b06b){const _0x5f258a=Yr(_0x37b06b),_0x4832e8=_0x5f258a['claims'];return!!_0x4832e8&&typeof _0x4832e8=='object'&&_0x4832e8['hasOwnProperty']('iat');},wc=function(_0x397fbb){const _0x548119=Yr(_0x397fbb)['claims'];return typeof _0x548119=='object'&&_0x548119['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4b9db1,_0x13d08a){return Object['prototype']['hasOwnProperty']['call'](_0x4b9db1,_0x13d08a);}function Le(_0x5afd6a,_0x533186){if(Object['prototype']['hasOwnProperty']['call'](_0x5afd6a,_0x533186))return _0x5afd6a[_0x533186];}function pn(_0x2c421d){for(const _0x80bd0 in _0x2c421d)if(Object['prototype']['hasOwnProperty']['call'](_0x2c421d,_0x80bd0))return!0x1;return!0x0;}function _n(_0x41fd6d,_0x3fb305,_0x7f3d35){const _0x1004e1={};for(const _0xf64d4e in _0x41fd6d)Object['prototype']['hasOwnProperty']['call'](_0x41fd6d,_0xf64d4e)&&(_0x1004e1[_0xf64d4e]=_0x3fb305['call'](_0x7f3d35,_0x41fd6d[_0xf64d4e],_0xf64d4e,_0x41fd6d));return _0x1004e1;}function xe(_0x384f2e,_0x212b0c){if(_0x384f2e===_0x212b0c)return!0x0;const _0x42b296=Object['keys'](_0x384f2e),_0x6b047d=Object['keys'](_0x212b0c);for(const _0x574458 of _0x42b296){if(!_0x6b047d['includes'](_0x574458))return!0x1;const _0x535a61=_0x384f2e[_0x574458],_0x2afc21=_0x212b0c[_0x574458];if(Ns(_0x535a61)&&Ns(_0x2afc21)){if(!xe(_0x535a61,_0x2afc21))return!0x1;}else{if(_0x535a61!==_0x2afc21)return!0x1;}}for(const _0x1729d6 of _0x6b047d)if(!_0x42b296['includes'](_0x1729d6))return!0x1;return!0x0;}function Ns(_0x53b8de){return _0x53b8de!==null&&typeof _0x53b8de=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x293ee9){const _0x4105e6=[];for(const [_0x56a7e1,_0x3ff738]of Object['entries'](_0x293ee9))Array['isArray'](_0x3ff738)?_0x3ff738['forEach'](_0x125378=>{_0x4105e6['push'](encodeURIComponent(_0x56a7e1)+'='+encodeURIComponent(_0x125378));}):_0x4105e6['push'](encodeURIComponent(_0x56a7e1)+'='+encodeURIComponent(_0x3ff738));return _0x4105e6['length']?'&'+_0x4105e6['join']('&'):'';}function Ct(_0x30b1f2){const _0xea243b={};return _0x30b1f2['replace'](/^\?/,'')['split']('&')['forEach'](_0x719f30=>{if(_0x719f30){const [_0x4c1200,_0x5eada7]=_0x719f30['split']('=');_0xea243b[decodeURIComponent(_0x4c1200)]=decodeURIComponent(_0x5eada7);}}),_0xea243b;}function Tt(_0x378514){const _0x2fd783=_0x378514['indexOf']('?');if(!_0x2fd783)return'';const _0x322371=_0x378514['indexOf']('#',_0x2fd783);return _0x378514['substring'](_0x2fd783,_0x322371>0x0?_0x322371:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x312e7c=0x1;_0x312e7c<this['blockSize'];++_0x312e7c)this['pad_'][_0x312e7c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x27a2cd,_0xc4011d){_0xc4011d||(_0xc4011d=0x0);const _0x4bf07d=this['W_'];if(typeof _0x27a2cd=='string'){for(let _0x142e64=0x0;_0x142e64<0x10;_0x142e64++)_0x4bf07d[_0x142e64]=_0x27a2cd['charCodeAt'](_0xc4011d)<<0x18|_0x27a2cd['charCodeAt'](_0xc4011d+0x1)<<0x10|_0x27a2cd['charCodeAt'](_0xc4011d+0x2)<<0x8|_0x27a2cd['charCodeAt'](_0xc4011d+0x3),_0xc4011d+=0x4;}else{for(let _0x12548b=0x0;_0x12548b<0x10;_0x12548b++)_0x4bf07d[_0x12548b]=_0x27a2cd[_0xc4011d]<<0x18|_0x27a2cd[_0xc4011d+0x1]<<0x10|_0x27a2cd[_0xc4011d+0x2]<<0x8|_0x27a2cd[_0xc4011d+0x3],_0xc4011d+=0x4;}for(let _0x216296=0x10;_0x216296<0x50;_0x216296++){const _0x6b81e5=_0x4bf07d[_0x216296-0x3]^_0x4bf07d[_0x216296-0x8]^_0x4bf07d[_0x216296-0xe]^_0x4bf07d[_0x216296-0x10];_0x4bf07d[_0x216296]=(_0x6b81e5<<0x1|_0x6b81e5>>>0x1f)&0xffffffff;}let _0x256938=this['chain_'][0x0],_0x1f71c7=this['chain_'][0x1],_0x598ee8=this['chain_'][0x2],_0x3daca5=this['chain_'][0x3],_0x27c478=this['chain_'][0x4],_0x4d275e,_0x5f3423;for(let _0x15b4e8=0x0;_0x15b4e8<0x50;_0x15b4e8++){_0x15b4e8<0x28?_0x15b4e8<0x14?(_0x4d275e=_0x3daca5^_0x1f71c7&(_0x598ee8^_0x3daca5),_0x5f3423=0x5a827999):(_0x4d275e=_0x1f71c7^_0x598ee8^_0x3daca5,_0x5f3423=0x6ed9eba1):_0x15b4e8<0x3c?(_0x4d275e=_0x1f71c7&_0x598ee8|_0x3daca5&(_0x1f71c7|_0x598ee8),_0x5f3423=0x8f1bbcdc):(_0x4d275e=_0x1f71c7^_0x598ee8^_0x3daca5,_0x5f3423=0xca62c1d6);const _0x2c96f2=(_0x256938<<0x5|_0x256938>>>0x1b)+_0x4d275e+_0x27c478+_0x5f3423+_0x4bf07d[_0x15b4e8]&0xffffffff;_0x27c478=_0x3daca5,_0x3daca5=_0x598ee8,_0x598ee8=(_0x1f71c7<<0x1e|_0x1f71c7>>>0x2)&0xffffffff,_0x1f71c7=_0x256938,_0x256938=_0x2c96f2;}this['chain_'][0x0]=this['chain_'][0x0]+_0x256938&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1f71c7&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x598ee8&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3daca5&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x27c478&0xffffffff;}['update'](_0x238df3,_0x3bdc97){if(_0x238df3==null)return;_0x3bdc97===void 0x0&&(_0x3bdc97=_0x238df3['length']);const _0x92dd37=_0x3bdc97-this['blockSize'];let _0x568660=0x0;const _0x4708bc=this['buf_'];let _0x571687=this['inbuf_'];for(;_0x568660<_0x3bdc97;){if(_0x571687===0x0){for(;_0x568660<=_0x92dd37;)this['compress_'](_0x238df3,_0x568660),_0x568660+=this['blockSize'];}if(typeof _0x238df3=='string'){for(;_0x568660<_0x3bdc97;)if(_0x4708bc[_0x571687]=_0x238df3['charCodeAt'](_0x568660),++_0x571687,++_0x568660,_0x571687===this['blockSize']){this['compress_'](_0x4708bc),_0x571687=0x0;break;}}else{for(;_0x568660<_0x3bdc97;)if(_0x4708bc[_0x571687]=_0x238df3[_0x568660],++_0x571687,++_0x568660,_0x571687===this['blockSize']){this['compress_'](_0x4708bc),_0x571687=0x0;break;}}}this['inbuf_']=_0x571687,this['total_']+=_0x3bdc97;}['digest'](){const _0x1a1076=[];let _0xf0b538=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1e86ce=this['blockSize']-0x1;_0x1e86ce>=0x38;_0x1e86ce--)this['buf_'][_0x1e86ce]=_0xf0b538&0xff,_0xf0b538/=0x100;this['compress_'](this['buf_']);let _0x557c56=0x0;for(let _0xf7a8b1=0x0;_0xf7a8b1<0x5;_0xf7a8b1++)for(let _0x102588=0x18;_0x102588>=0x0;_0x102588-=0x8)_0x1a1076[_0x557c56]=this['chain_'][_0xf7a8b1]>>_0x102588&0xff,++_0x557c56;return _0x1a1076;}}function Tc(_0x28f7bb,_0x2e535e){const _0x2067d6=new Sc(_0x28f7bb,_0x2e535e);return _0x2067d6['subscribe']['bind'](_0x2067d6);}class Sc{constructor(_0x3cb284,_0x53a0ad){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x53a0ad,this['task']['then'](()=>{_0x3cb284(this);})['catch'](_0x1d412a=>{this['error'](_0x1d412a);});}['next'](_0x1aa7d2){this['forEachObserver'](_0x4f4820=>{_0x4f4820['next'](_0x1aa7d2);});}['error'](_0x1bcc36){this['forEachObserver'](_0x1d969e=>{_0x1d969e['error'](_0x1bcc36);}),this['close'](_0x1bcc36);}['complete'](){this['forEachObserver'](_0x392d01=>{_0x392d01['complete']();}),this['close']();}['subscribe'](_0x20d993,_0x35dbbe,_0x2eb10f){let _0x21b178;if(_0x20d993===void 0x0&&_0x35dbbe===void 0x0&&_0x2eb10f===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x20d993,['next','error','complete'])?_0x21b178=_0x20d993:_0x21b178={'next':_0x20d993,'error':_0x35dbbe,'complete':_0x2eb10f},_0x21b178['next']===void 0x0&&(_0x21b178['next']=ti),_0x21b178['error']===void 0x0&&(_0x21b178['error']=ti),_0x21b178['complete']===void 0x0&&(_0x21b178['complete']=ti);const _0x2eaa3c=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x21b178['error'](this['finalError']):_0x21b178['complete']();}catch{}}),this['observers']['push'](_0x21b178),_0x2eaa3c;}['unsubscribeOne'](_0x369f49){this['observers']===void 0x0||this['observers'][_0x369f49]===void 0x0||(delete this['observers'][_0x369f49],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x31e9be){if(!this['finalized']){for(let _0x8bc82c=0x0;_0x8bc82c<this['observers']['length'];_0x8bc82c++)this['sendOne'](_0x8bc82c,_0x31e9be);}}['sendOne'](_0x22b147,_0x232ffa){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x22b147]!==void 0x0)try{_0x232ffa(this['observers'][_0x22b147]);}catch(_0x35da50){typeof console<'u'&&console['error']&&console['error'](_0x35da50);}});}['close'](_0x25ef5e){this['finalized']||(this['finalized']=!0x0,_0x25ef5e!==void 0x0&&(this['finalError']=_0x25ef5e),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x279e06,_0x11e727){if(typeof _0x279e06!='object'||_0x279e06===null)return!0x1;for(const _0xfcd492 of _0x11e727)if(_0xfcd492 in _0x279e06&&typeof _0x279e06[_0xfcd492]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1f547e,_0x54760f){return _0x1f547e+'\x20failed:\x20'+_0x54760f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x3cb502){const _0xd9047d=[];let _0x5e6903=0x0;for(let _0xcc53f8=0x0;_0xcc53f8<_0x3cb502['length'];_0xcc53f8++){let _0x48231a=_0x3cb502['charCodeAt'](_0xcc53f8);if(_0x48231a>=0xd800&&_0x48231a<=0xdbff){const _0x13ec99=_0x48231a-0xd800;_0xcc53f8++,f(_0xcc53f8<_0x3cb502['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2d4147=_0x3cb502['charCodeAt'](_0xcc53f8)-0xdc00;_0x48231a=0x10000+(_0x13ec99<<0xa)+_0x2d4147;}_0x48231a<0x80?_0xd9047d[_0x5e6903++]=_0x48231a:_0x48231a<0x800?(_0xd9047d[_0x5e6903++]=_0x48231a>>0x6|0xc0,_0xd9047d[_0x5e6903++]=_0x48231a&0x3f|0x80):_0x48231a<0x10000?(_0xd9047d[_0x5e6903++]=_0x48231a>>0xc|0xe0,_0xd9047d[_0x5e6903++]=_0x48231a>>0x6&0x3f|0x80,_0xd9047d[_0x5e6903++]=_0x48231a&0x3f|0x80):(_0xd9047d[_0x5e6903++]=_0x48231a>>0x12|0xf0,_0xd9047d[_0x5e6903++]=_0x48231a>>0xc&0x3f|0x80,_0xd9047d[_0x5e6903++]=_0x48231a>>0x6&0x3f|0x80,_0xd9047d[_0x5e6903++]=_0x48231a&0x3f|0x80);}return _0xd9047d;},Ln=function(_0x3e8640){let _0x318ad5=0x0;for(let _0x13f839=0x0;_0x13f839<_0x3e8640['length'];_0x13f839++){const _0x1a9304=_0x3e8640['charCodeAt'](_0x13f839);_0x1a9304<0x80?_0x318ad5++:_0x1a9304<0x800?_0x318ad5+=0x2:_0x1a9304>=0xd800&&_0x1a9304<=0xdbff?(_0x318ad5+=0x4,_0x13f839++):_0x318ad5+=0x3;}return _0x318ad5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x306dfe){return _0x306dfe&&_0x306dfe['_delegate']?_0x306dfe['_delegate']:_0x306dfe;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x550bc8){try{return(_0x550bc8['startsWith']('http://')||_0x550bc8['startsWith']('https://')?new URL(_0x550bc8)['hostname']:_0x550bc8)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x1727d8){return(await fetch(_0x1727d8,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x226354,_0x224c4a,_0x4579ea){this['name']=_0x226354,this['instanceFactory']=_0x224c4a,this['type']=_0x4579ea,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2303de){return this['instantiationMode']=_0x2303de,this;}['setMultipleInstances'](_0x2a7450){return this['multipleInstances']=_0x2a7450,this;}['setServiceProps'](_0x26e9f8){return this['serviceProps']=_0x26e9f8,this;}['setInstanceCreatedCallback'](_0x24a601){return this['onInstanceCreated']=_0x24a601,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3772b4,_0x1cc5e3){this['name']=_0x3772b4,this['container']=_0x1cc5e3,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x46eb51){const _0x3559d6=this['normalizeInstanceIdentifier'](_0x46eb51);if(!this['instancesDeferred']['has'](_0x3559d6)){const _0x53b931=new H();if(this['instancesDeferred']['set'](_0x3559d6,_0x53b931),this['isInitialized'](_0x3559d6)||this['shouldAutoInitialize']())try{const _0x34663d=this['getOrInitializeService']({'instanceIdentifier':_0x3559d6});_0x34663d&&_0x53b931['resolve'](_0x34663d);}catch{}}return this['instancesDeferred']['get'](_0x3559d6)['promise'];}['getImmediate'](_0x29c6ba){const _0x4341f9=this['normalizeInstanceIdentifier'](_0x29c6ba==null?void 0x0:_0x29c6ba['identifier']),_0x5a0dd2=(_0x29c6ba==null?void 0x0:_0x29c6ba['optional'])??!0x1;if(this['isInitialized'](_0x4341f9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4341f9});}catch(_0x2017ea){if(_0x5a0dd2)return null;throw _0x2017ea;}else{if(_0x5a0dd2)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4008ec){if(_0x4008ec['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4008ec['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4008ec,!!this['shouldAutoInitialize']()){if(Pc(_0x4008ec))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4680c0,_0x147c15]of this['instancesDeferred']['entries']()){const _0x593bd7=this['normalizeInstanceIdentifier'](_0x4680c0);try{const _0x46f71b=this['getOrInitializeService']({'instanceIdentifier':_0x593bd7});_0x147c15['resolve'](_0x46f71b);}catch{}}}}['clearInstance'](_0x21bdec=Ne){this['instancesDeferred']['delete'](_0x21bdec),this['instancesOptions']['delete'](_0x21bdec),this['instances']['delete'](_0x21bdec);}async['delete'](){const _0x4d107f=Array['from'](this['instances']['values']());await Promise['all']([..._0x4d107f['filter'](_0x273941=>'INTERNAL'in _0x273941)['map'](_0x756880=>_0x756880['INTERNAL']['delete']()),..._0x4d107f['filter'](_0x13e038=>'_delete'in _0x13e038)['map'](_0x2235e3=>_0x2235e3['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4d18f7=Ne){return this['instances']['has'](_0x4d18f7);}['getOptions'](_0x382a79=Ne){return this['instancesOptions']['get'](_0x382a79)||{};}['initialize'](_0x1bc0aa={}){const {options:_0x39bb1e={}}=_0x1bc0aa,_0x225ee7=this['normalizeInstanceIdentifier'](_0x1bc0aa['instanceIdentifier']);if(this['isInitialized'](_0x225ee7))throw Error(this['name']+'('+_0x225ee7+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x204e3b=this['getOrInitializeService']({'instanceIdentifier':_0x225ee7,'options':_0x39bb1e});for(const [_0x5b6aee,_0x2a3a7e]of this['instancesDeferred']['entries']()){const _0x28e1cf=this['normalizeInstanceIdentifier'](_0x5b6aee);_0x225ee7===_0x28e1cf&&_0x2a3a7e['resolve'](_0x204e3b);}return _0x204e3b;}['onInit'](_0x4f0c8e,_0x29e95d){const _0x456113=this['normalizeInstanceIdentifier'](_0x29e95d),_0x312f87=this['onInitCallbacks']['get'](_0x456113)??new Set();_0x312f87['add'](_0x4f0c8e),this['onInitCallbacks']['set'](_0x456113,_0x312f87);const _0x4fbb73=this['instances']['get'](_0x456113);return _0x4fbb73&&_0x4f0c8e(_0x4fbb73,_0x456113),()=>{_0x312f87['delete'](_0x4f0c8e);};}['invokeOnInitCallbacks'](_0x3b1e22,_0x22114d){const _0x41448d=this['onInitCallbacks']['get'](_0x22114d);if(_0x41448d){for(const _0x4bbe04 of _0x41448d)try{_0x4bbe04(_0x3b1e22,_0x22114d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x30a1ce,options:_0x248b78={}}){let _0x228e45=this['instances']['get'](_0x30a1ce);if(!_0x228e45&&this['component']&&(_0x228e45=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x30a1ce),'options':_0x248b78}),this['instances']['set'](_0x30a1ce,_0x228e45),this['instancesOptions']['set'](_0x30a1ce,_0x248b78),this['invokeOnInitCallbacks'](_0x228e45,_0x30a1ce),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x30a1ce,_0x228e45);}catch{}return _0x228e45||null;}['normalizeInstanceIdentifier'](_0x56c094=Ne){return this['component']?this['component']['multipleInstances']?_0x56c094:Ne:_0x56c094;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x1adede){return _0x1adede===Ne?void 0x0:_0x1adede;}function Pc(_0x32b067){return _0x32b067['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x197633){this['name']=_0x197633,this['providers']=new Map();}['addComponent'](_0x1f161f){const _0x1c3a02=this['getProvider'](_0x1f161f['name']);if(_0x1c3a02['isComponentSet']())throw new Error('Component\x20'+_0x1f161f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1c3a02['setComponent'](_0x1f161f);}['addOrOverwriteComponent'](_0xbddcef){this['getProvider'](_0xbddcef['name'])['isComponentSet']()&&this['providers']['delete'](_0xbddcef['name']),this['addComponent'](_0xbddcef);}['getProvider'](_0x1b4fcb){if(this['providers']['has'](_0x1b4fcb))return this['providers']['get'](_0x1b4fcb);const _0x59f3ba=new Ac(_0x1b4fcb,this);return this['providers']['set'](_0x1b4fcb,_0x59f3ba),_0x59f3ba;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x43666e){_0x43666e[_0x43666e['DEBUG']=0x0]='DEBUG',_0x43666e[_0x43666e['VERBOSE']=0x1]='VERBOSE',_0x43666e[_0x43666e['INFO']=0x2]='INFO',_0x43666e[_0x43666e['WARN']=0x3]='WARN',_0x43666e[_0x43666e['ERROR']=0x4]='ERROR',_0x43666e[_0x43666e['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4a0bb6,_0x560b0,..._0x1e1d7a)=>{if(_0x560b0<_0x4a0bb6['logLevel'])return;const _0x2037d4=new Date()['toISOString'](),_0x6f7ebb=Mc[_0x560b0];if(_0x6f7ebb)console[_0x6f7ebb]('['+_0x2037d4+']\x20\x20'+_0x4a0bb6['name']+':',..._0x1e1d7a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x560b0+')');};class Bi{constructor(_0x191be4){this['name']=_0x191be4,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0xed9166){if(!(_0xed9166 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0xed9166+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0xed9166;}['setLogLevel'](_0x5afdb1){this['_logLevel']=typeof _0x5afdb1=='string'?Oc[_0x5afdb1]:_0x5afdb1;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x394bd0){if(typeof _0x394bd0!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x394bd0;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x5c7feb){this['_userLogHandler']=_0x5c7feb;}['debug'](..._0x1da994){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1da994),this['_logHandler'](this,T['DEBUG'],..._0x1da994);}['log'](..._0x284741){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x284741),this['_logHandler'](this,T['VERBOSE'],..._0x284741);}['info'](..._0x47f10e){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x47f10e),this['_logHandler'](this,T['INFO'],..._0x47f10e);}['warn'](..._0x289e3d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x289e3d),this['_logHandler'](this,T['WARN'],..._0x289e3d);}['error'](..._0x1a52c6){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1a52c6),this['_logHandler'](this,T['ERROR'],..._0x1a52c6);}}const xc=(_0x1ec5fc,_0x4ebd28)=>_0x4ebd28['some'](_0x5d8fd5=>_0x1ec5fc instanceof _0x5d8fd5);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4e01f6){const _0x2a0b8e=new Promise((_0x3e794f,_0x22cb90)=>{const _0x39e352=()=>{_0x4e01f6['removeEventListener']('success',_0x5f0e91),_0x4e01f6['removeEventListener']('error',_0x4c9460);},_0x5f0e91=()=>{_0x3e794f(ge(_0x4e01f6['result'])),_0x39e352();},_0x4c9460=()=>{_0x22cb90(_0x4e01f6['error']),_0x39e352();};_0x4e01f6['addEventListener']('success',_0x5f0e91),_0x4e01f6['addEventListener']('error',_0x4c9460);});return _0x2a0b8e['then'](_0x421c35=>{_0x421c35 instanceof IDBCursor&&Jr['set'](_0x421c35,_0x4e01f6);})['catch'](()=>{}),Vi['set'](_0x2a0b8e,_0x4e01f6),_0x2a0b8e;}function Bc(_0x495077){if(_i['has'](_0x495077))return;const _0x10d5f6=new Promise((_0x3afb8c,_0x525ebb)=>{const _0xef21f2=()=>{_0x495077['removeEventListener']('complete',_0x575e8f),_0x495077['removeEventListener']('error',_0x51773a),_0x495077['removeEventListener']('abort',_0x51773a);},_0x575e8f=()=>{_0x3afb8c(),_0xef21f2();},_0x51773a=()=>{_0x525ebb(_0x495077['error']||new DOMException('AbortError','AbortError')),_0xef21f2();};_0x495077['addEventListener']('complete',_0x575e8f),_0x495077['addEventListener']('error',_0x51773a),_0x495077['addEventListener']('abort',_0x51773a);});_i['set'](_0x495077,_0x10d5f6);}let gi={'get'(_0xa15b8,_0x2a2a07,_0x513e03){if(_0xa15b8 instanceof IDBTransaction){if(_0x2a2a07==='done')return _i['get'](_0xa15b8);if(_0x2a2a07==='objectStoreNames')return _0xa15b8['objectStoreNames']||Xr['get'](_0xa15b8);if(_0x2a2a07==='store')return _0x513e03['objectStoreNames'][0x1]?void 0x0:_0x513e03['objectStore'](_0x513e03['objectStoreNames'][0x0]);}return ge(_0xa15b8[_0x2a2a07]);},'set'(_0x1aff7e,_0x1f700e,_0x46792a){return _0x1aff7e[_0x1f700e]=_0x46792a,!0x0;},'has'(_0x1cff79,_0x2b0335){return _0x1cff79 instanceof IDBTransaction&&(_0x2b0335==='done'||_0x2b0335==='store')?!0x0:_0x2b0335 in _0x1cff79;}};function Vc(_0xc84bce){gi=_0xc84bce(gi);}function Hc(_0x53924e){return _0x53924e===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x53eb51,..._0x4fcb91){const _0x161f06=_0x53924e['call'](ii(this),_0x53eb51,..._0x4fcb91);return Xr['set'](_0x161f06,_0x53eb51['sort']?_0x53eb51['sort']():[_0x53eb51]),ge(_0x161f06);}:Uc()['includes'](_0x53924e)?function(..._0x2c44f2){return _0x53924e['apply'](ii(this),_0x2c44f2),ge(Jr['get'](this));}:function(..._0x158950){return ge(_0x53924e['apply'](ii(this),_0x158950));};}function $c(_0x22ae90){return typeof _0x22ae90=='function'?Hc(_0x22ae90):(_0x22ae90 instanceof IDBTransaction&&Bc(_0x22ae90),xc(_0x22ae90,Fc())?new Proxy(_0x22ae90,gi):_0x22ae90);}function ge(_0x2257d5){if(_0x2257d5 instanceof IDBRequest)return Wc(_0x2257d5);if(ni['has'](_0x2257d5))return ni['get'](_0x2257d5);const _0x1cc4f8=$c(_0x2257d5);return _0x1cc4f8!==_0x2257d5&&(ni['set'](_0x2257d5,_0x1cc4f8),Vi['set'](_0x1cc4f8,_0x2257d5)),_0x1cc4f8;}const ii=_0x529fda=>Vi['get'](_0x529fda);function Gc(_0x20cc5f,_0x417821,{blocked:_0x5bf229,upgrade:_0x45061a,blocking:_0x2bcd23,terminated:_0x2c670c}={}){const _0x5978c3=indexedDB['open'](_0x20cc5f,_0x417821),_0x3b1621=ge(_0x5978c3);return _0x45061a&&_0x5978c3['addEventListener']('upgradeneeded',_0x2b5750=>{_0x45061a(ge(_0x5978c3['result']),_0x2b5750['oldVersion'],_0x2b5750['newVersion'],ge(_0x5978c3['transaction']),_0x2b5750);}),_0x5bf229&&_0x5978c3['addEventListener']('blocked',_0x358684=>_0x5bf229(_0x358684['oldVersion'],_0x358684['newVersion'],_0x358684)),_0x3b1621['then'](_0x2ccf3c=>{_0x2c670c&&_0x2ccf3c['addEventListener']('close',()=>_0x2c670c()),_0x2bcd23&&_0x2ccf3c['addEventListener']('versionchange',_0x4522e2=>_0x2bcd23(_0x4522e2['oldVersion'],_0x4522e2['newVersion'],_0x4522e2));})['catch'](()=>{}),_0x3b1621;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x19aa2d,_0x892e67){if(!(_0x19aa2d instanceof IDBDatabase&&!(_0x892e67 in _0x19aa2d)&&typeof _0x892e67=='string'))return;if(si['get'](_0x892e67))return si['get'](_0x892e67);const _0x54c6d9=_0x892e67['replace'](/FromIndex$/,''),_0x2c2ce5=_0x892e67!==_0x54c6d9,_0xe343b4=zc['includes'](_0x54c6d9);if(!(_0x54c6d9 in(_0x2c2ce5?IDBIndex:IDBObjectStore)['prototype'])||!(_0xe343b4||qc['includes'](_0x54c6d9)))return;const _0x4f99b3=async function(_0x105407,..._0x4d5660){const _0x7fde0a=this['transaction'](_0x105407,_0xe343b4?'readwrite':'readonly');let _0x3b0a8b=_0x7fde0a['store'];return _0x2c2ce5&&(_0x3b0a8b=_0x3b0a8b['index'](_0x4d5660['shift']())),(await Promise['all']([_0x3b0a8b[_0x54c6d9](..._0x4d5660),_0xe343b4&&_0x7fde0a['done']]))[0x0];};return si['set'](_0x892e67,_0x4f99b3),_0x4f99b3;}Vc(_0x344b14=>({..._0x344b14,'get':(_0x57c453,_0x53f63a,_0x132a94)=>Ms(_0x57c453,_0x53f63a)||_0x344b14['get'](_0x57c453,_0x53f63a,_0x132a94),'has':(_0x1a3a5f,_0x4a9035)=>!!Ms(_0x1a3a5f,_0x4a9035)||_0x344b14['has'](_0x1a3a5f,_0x4a9035)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0xd84e8b){this['container']=_0xd84e8b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x45ed55=>{if(Kc(_0x45ed55)){const _0x280048=_0x45ed55['getImmediate']();return _0x280048['library']+'/'+_0x280048['version'];}else return null;})['filter'](_0x4ef51f=>_0x4ef51f)['join']('\x20');}}function Kc(_0x34323d){const _0x8dc8f0=_0x34323d['getComponent']();return(_0x8dc8f0==null?void 0x0:_0x8dc8f0['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x4d1556,_0x1775c1){try{_0x4d1556['container']['addComponent'](_0x1775c1);}catch(_0x16c9e0){oe['debug']('Component\x20'+_0x1775c1['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4d1556['name'],_0x16c9e0);}}function st(_0x34ee1a){const _0x1aab70=_0x34ee1a['name'];if(Ei['has'](_0x1aab70))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1aab70+'.'),!0x1;Ei['set'](_0x1aab70,_0x34ee1a);for(const _0xfd742f of Ue['values']())xs(_0xfd742f,_0x34ee1a);for(const _0x364e13 of vi['values']())xs(_0x364e13,_0x34ee1a);return!0x0;}function Hi(_0x2e535c,_0x4faba4){const _0x4299b4=_0x2e535c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x4299b4&&_0x4299b4['triggerHeartbeat'](),_0x2e535c['container']['getProvider'](_0x4faba4);}function $(_0x19528a){return _0x19528a==null?!0x1:_0x19528a['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1e39a5,_0x5c15f4,_0x4e717b){this['_isDeleted']=!0x1,this['_options']={..._0x1e39a5},this['_config']={..._0x5c15f4},this['_name']=_0x5c15f4['name'],this['_automaticDataCollectionEnabled']=_0x5c15f4['automaticDataCollectionEnabled'],this['_container']=_0x4e717b,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x3ff53f){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x3ff53f;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x1f470f){this['_isDeleted']=_0x1f470f;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3460f5,_0x32a79d={}){let _0x1820a7=_0x3460f5;typeof _0x32a79d!='object'&&(_0x32a79d={'name':_0x32a79d});const _0x51a9ed={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x32a79d},_0x5740c2=_0x51a9ed['name'];if(typeof _0x5740c2!='string'||!_0x5740c2)throw me['create']('bad-app-name',{'appName':String(_0x5740c2)});if(_0x1820a7||(_0x1820a7=zr()),!_0x1820a7)throw me['create']('no-options');const _0x4902a2=Ue['get'](_0x5740c2);if(_0x4902a2){if(xe(_0x1820a7,_0x4902a2['options'])&&xe(_0x51a9ed,_0x4902a2['config']))return _0x4902a2;throw me['create']('duplicate-app',{'appName':_0x5740c2});}const _0x111d75=new Nc(_0x5740c2);for(const _0x57bf34 of Ei['values']())_0x111d75['addComponent'](_0x57bf34);const _0x446a98=new Tl(_0x1820a7,_0x51a9ed,_0x111d75);return Ue['set'](_0x5740c2,_0x446a98),_0x446a98;}function Zr(_0x63e65a=yi){const _0x1c62b6=Ue['get'](_0x63e65a);if(!_0x1c62b6&&_0x63e65a===yi&&zr())return Sl();if(!_0x1c62b6)throw me['create']('no-app',{'appName':_0x63e65a});return _0x1c62b6;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x296244){let _0x55bf6b=!0x1;const _0xdaeacb=_0x296244['name'];Ue['has'](_0xdaeacb)?(_0x55bf6b=!0x0,Ue['delete'](_0xdaeacb)):vi['has'](_0xdaeacb)&&_0x296244['decRefCount']()<=0x0&&(vi['delete'](_0xdaeacb),_0x55bf6b=!0x0),_0x55bf6b&&(await Promise['all'](_0x296244['container']['getProviders']()['map'](_0x398d9a=>_0x398d9a['delete']())),_0x296244['isDeleted']=!0x0);}function ye(_0x314500,_0x23a49a,_0x5bebf4){let _0x30db18=wl[_0x314500]??_0x314500;_0x5bebf4&&(_0x30db18+='-'+_0x5bebf4);const _0x498729=_0x30db18['match'](/\s|\//),_0x213f15=_0x23a49a['match'](/\s|\//);if(_0x498729||_0x213f15){const _0x2c4a77=['Unable\x20to\x20register\x20library\x20\x22'+_0x30db18+'\x22\x20with\x20version\x20\x22'+_0x23a49a+'\x22:'];_0x498729&&_0x2c4a77['push']('library\x20name\x20\x22'+_0x30db18+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x498729&&_0x213f15&&_0x2c4a77['push']('and'),_0x213f15&&_0x2c4a77['push']('version\x20name\x20\x22'+_0x23a49a+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2c4a77['join']('\x20'));return;}st(new Fe(_0x30db18+'-version',()=>({'library':_0x30db18,'version':_0x23a49a}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x5a4387,_0x3863fb)=>{switch(_0x3863fb){case 0x0:try{_0x5a4387['createObjectStore'](Ot);}catch(_0x367594){console['warn'](_0x367594);}}}})['catch'](_0x41cd7a=>{throw me['create']('idb-open',{'originalErrorMessage':_0x41cd7a['message']});})),ri;}async function Al(_0x15d159){try{const _0x3a993f=(await eo())['transaction'](Ot),_0x5c5047=await _0x3a993f['objectStore'](Ot)['get'](to(_0x15d159));return await _0x3a993f['done'],_0x5c5047;}catch(_0x55fed6){if(_0x55fed6 instanceof Re)oe['warn'](_0x55fed6['message']);else{const _0x2ccdb3=me['create']('idb-get',{'originalErrorMessage':_0x55fed6==null?void 0x0:_0x55fed6['message']});oe['warn'](_0x2ccdb3['message']);}}}async function Fs(_0x3f5f8a,_0x19d326){try{const _0xd23d4=(await eo())['transaction'](Ot,'readwrite');await _0xd23d4['objectStore'](Ot)['put'](_0x19d326,to(_0x3f5f8a)),await _0xd23d4['done'];}catch(_0x4c46d2){if(_0x4c46d2 instanceof Re)oe['warn'](_0x4c46d2['message']);else{const _0x513608=me['create']('idb-set',{'originalErrorMessage':_0x4c46d2==null?void 0x0:_0x4c46d2['message']});oe['warn'](_0x513608['message']);}}}function to(_0xc900f2){return _0xc900f2['name']+'!'+_0xc900f2['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x5cc8b){this['container']=_0x5cc8b,this['_heartbeatsCache']=null;const _0x23e856=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x23e856),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x17c8f7=>(this['_heartbeatsCache']=_0x17c8f7,_0x17c8f7));}async['triggerHeartbeat'](){var _0x3d0b33,_0x397c70;try{const _0x5135db=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3e1b81=Us();if(((_0x3d0b33=this['_heartbeatsCache'])==null?void 0x0:_0x3d0b33['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x397c70=this['_heartbeatsCache'])==null?void 0x0:_0x397c70['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3e1b81||this['_heartbeatsCache']['heartbeats']['some'](_0x5799fc=>_0x5799fc['date']===_0x3e1b81))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3e1b81,'agent':_0x5135db}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x144f74=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x144f74,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x6c8bf4){oe['warn'](_0x6c8bf4);}}async['getHeartbeatsHeader'](){var _0x59af43;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x59af43=this['_heartbeatsCache'])==null?void 0x0:_0x59af43['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x55a641=Us(),{heartbeatsToSend:_0x30fc4b,unsentEntries:_0x42304c}=Ol(this['_heartbeatsCache']['heartbeats']),_0x180e9c=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x30fc4b}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x55a641,_0x42304c['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x42304c,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x180e9c;}catch(_0x2e3998){return oe['warn'](_0x2e3998),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5a3edd,_0x558c82=kl){const _0x53f67c=[];let _0x59d7ba=_0x5a3edd['slice']();for(const _0x4cd530 of _0x5a3edd){const _0x460971=_0x53f67c['find'](_0x1b7dce=>_0x1b7dce['agent']===_0x4cd530['agent']);if(_0x460971){if(_0x460971['dates']['push'](_0x4cd530['date']),Ws(_0x53f67c)>_0x558c82){_0x460971['dates']['pop']();break;}}else{if(_0x53f67c['push']({'agent':_0x4cd530['agent'],'dates':[_0x4cd530['date']]}),Ws(_0x53f67c)>_0x558c82){_0x53f67c['pop']();break;}}_0x59d7ba=_0x59d7ba['slice'](0x1);}return{'heartbeatsToSend':_0x53f67c,'unsentEntries':_0x59d7ba};}class Dl{constructor(_0x482254){this['app']=_0x482254,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x12588b=await Al(this['app']);return _0x12588b!=null&&_0x12588b['heartbeats']?_0x12588b:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x29f5f6){if(await this['_canUseIndexedDBPromise']){const _0x160d77=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x29f5f6['lastSentHeartbeatDate']??_0x160d77['lastSentHeartbeatDate'],'heartbeats':_0x29f5f6['heartbeats']});}else return;}async['add'](_0x4bdf12){if(await this['_canUseIndexedDBPromise']){const _0x5865dd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4bdf12['lastSentHeartbeatDate']??_0x5865dd['lastSentHeartbeatDate'],'heartbeats':[..._0x5865dd['heartbeats'],..._0x4bdf12['heartbeats']]});}else return;}}function Ws(_0x2f654a){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2f654a}))['length'];}function Ml(_0x5903e3){if(_0x5903e3['length']===0x0)return-0x1;let _0x25b5eb=0x0,_0x919309=_0x5903e3[0x0]['date'];for(let _0xb63024=0x1;_0xb63024<_0x5903e3['length'];_0xb63024++)_0x5903e3[_0xb63024]['date']<_0x919309&&(_0x919309=_0x5903e3[_0xb63024]['date'],_0x25b5eb=_0xb63024);return _0x25b5eb;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x5320f7){st(new Fe('platform-logger',_0x48e867=>new jc(_0x48e867),'PRIVATE')),st(new Fe('heartbeat',_0x3a7785=>new Nl(_0x3a7785),'PRIVATE')),ye(mi,Ls,_0x5320f7),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x59aeea){no=_0x59aeea;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x833fb8){this['domStorage_']=_0x833fb8,this['prefix_']='firebase:';}['set'](_0x5c103e,_0x46626a){_0x46626a==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x5c103e)):this['domStorage_']['setItem'](this['prefixedName_'](_0x5c103e),O(_0x46626a));}['get'](_0x131d45){const _0x4316e2=this['domStorage_']['getItem'](this['prefixedName_'](_0x131d45));return _0x4316e2==null?null:Nt(_0x4316e2);}['remove'](_0x1f86ab){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1f86ab));}['prefixedName_'](_0x497f89){return this['prefix_']+_0x497f89;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x509bcd,_0x437277){_0x437277==null?delete this['cache_'][_0x509bcd]:this['cache_'][_0x509bcd]=_0x437277;}['get'](_0x40412c){return Q(this['cache_'],_0x40412c)?this['cache_'][_0x40412c]:null;}['remove'](_0x55eda9){delete this['cache_'][_0x55eda9];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3f087f){try{if(typeof window<'u'&&typeof window[_0x3f087f]<'u'){const _0x35971d=window[_0x3f087f];return _0x35971d['setItem']('firebase:sentinel','cache'),_0x35971d['removeItem']('firebase:sentinel'),new Wl(_0x35971d);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1daf02=0x1;return function(){return _0x1daf02++;};}()),ro=function(_0x395bf3){const _0xd3a248=Rc(_0x395bf3),_0x5df36d=new Cc();_0x5df36d['update'](_0xd3a248);const _0x56dd64=_0x5df36d['digest']();return Fi['encodeByteArray'](_0x56dd64);},zt=function(..._0x31115b){let _0x1dfc49='';for(let _0x4c88a6=0x0;_0x4c88a6<_0x31115b['length'];_0x4c88a6++){const _0x2f984b=_0x31115b[_0x4c88a6];Array['isArray'](_0x2f984b)||_0x2f984b&&typeof _0x2f984b=='object'&&typeof _0x2f984b['length']=='number'?_0x1dfc49+=zt['apply'](null,_0x2f984b):typeof _0x2f984b=='object'?_0x1dfc49+=O(_0x2f984b):_0x1dfc49+=_0x2f984b,_0x1dfc49+='\x20';}return _0x1dfc49;};let St=null,$s=!0x0;const Hl=function(_0x40d05f,_0x317f57){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x45e21e){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x28c629=zt['apply'](null,_0x45e21e);St(_0x28c629);}},jt=function(_0x218184){return function(..._0x226a75){L(_0x218184,..._0x226a75);};},Ii=function(..._0x2030c5){const _0x223486='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2030c5);Ze['error'](_0x223486);},ae=function(..._0x218c03){const _0x1bf649='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x218c03);throw Ze['error'](_0x1bf649),new Error(_0x1bf649);},U=function(..._0x4bbbf7){const _0x4dc3d5='FIREBASE\x20WARNING:\x20'+zt(..._0x4bbbf7);Ze['warn'](_0x4dc3d5);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x24febe){return typeof _0x24febe=='number'&&(_0x24febe!==_0x24febe||_0x24febe===Number['POSITIVE_INFINITY']||_0x24febe===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2d424f){if(document['readyState']==='complete')_0x2d424f();else{let _0x598937=!0x1;const _0x1fba3a=function(){if(!document['body']){setTimeout(_0x1fba3a,Math['floor'](0xa));return;}_0x598937||(_0x598937=!0x0,_0x2d424f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x1fba3a,!0x1),window['addEventListener']('load',_0x1fba3a,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x1fba3a();}),window['attachEvent']('onload',_0x1fba3a));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5c1eca,_0x2b50c4){if(_0x5c1eca===_0x2b50c4)return 0x0;if(_0x5c1eca===We||_0x2b50c4===we)return-0x1;if(_0x2b50c4===We||_0x5c1eca===we)return 0x1;{const _0x1d13e1=Gs(_0x5c1eca),_0x2cb5b8=Gs(_0x2b50c4);return _0x1d13e1!==null?_0x2cb5b8!==null?_0x1d13e1-_0x2cb5b8===0x0?_0x5c1eca['length']-_0x2b50c4['length']:_0x1d13e1-_0x2cb5b8:-0x1:_0x2cb5b8!==null?0x1:_0x5c1eca<_0x2b50c4?-0x1:0x1;}},ql=function(_0x5e3aab,_0x5815a3){return _0x5e3aab===_0x5815a3?0x0:_0x5e3aab<_0x5815a3?-0x1:0x1;},vt=function(_0x302f19,_0x1f9165){if(_0x1f9165&&_0x302f19 in _0x1f9165)return _0x1f9165[_0x302f19];throw new Error('Missing\x20required\x20key\x20('+_0x302f19+')\x20in\x20object:\x20'+O(_0x1f9165));},$i=function(_0x3c202e){if(typeof _0x3c202e!='object'||_0x3c202e===null)return O(_0x3c202e);const _0xa048a3=[];for(const _0x59fe0d in _0x3c202e)_0xa048a3['push'](_0x59fe0d);_0xa048a3['sort']();let _0x5a9407='{';for(let _0xaa3c8d=0x0;_0xaa3c8d<_0xa048a3['length'];_0xaa3c8d++)_0xaa3c8d!==0x0&&(_0x5a9407+=','),_0x5a9407+=O(_0xa048a3[_0xaa3c8d]),_0x5a9407+=':',_0x5a9407+=$i(_0x3c202e[_0xa048a3[_0xaa3c8d]]);return _0x5a9407+='}',_0x5a9407;},oo=function(_0x300efc,_0xc86cbe){const _0x5f271e=_0x300efc['length'];if(_0x5f271e<=_0xc86cbe)return[_0x300efc];const _0x544daf=[];for(let _0x42fb66=0x0;_0x42fb66<_0x5f271e;_0x42fb66+=_0xc86cbe)_0x42fb66+_0xc86cbe>_0x5f271e?_0x544daf['push'](_0x300efc['substring'](_0x42fb66,_0x5f271e)):_0x544daf['push'](_0x300efc['substring'](_0x42fb66,_0x42fb66+_0xc86cbe));return _0x544daf;};function x(_0x680b06,_0x39de77){for(const _0x1eaef3 in _0x680b06)_0x680b06['hasOwnProperty'](_0x1eaef3)&&_0x39de77(_0x1eaef3,_0x680b06[_0x1eaef3]);}const ao=function(_0x11b86c){f(!xn(_0x11b86c),'Invalid\x20JSON\x20number');const _0x3543d2=0xb,_0x44f2d2=0x34,_0x5ee900=(0x1<<_0x3543d2-0x1)-0x1;let _0x18486d,_0xde3731,_0x220c05,_0x4e8d15,_0x24d614;_0x11b86c===0x0?(_0xde3731=0x0,_0x220c05=0x0,_0x18486d=0x1/_0x11b86c===-0x1/0x0?0x1:0x0):(_0x18486d=_0x11b86c<0x0,_0x11b86c=Math['abs'](_0x11b86c),_0x11b86c>=Math['pow'](0x2,0x1-_0x5ee900)?(_0x4e8d15=Math['min'](Math['floor'](Math['log'](_0x11b86c)/Math['LN2']),_0x5ee900),_0xde3731=_0x4e8d15+_0x5ee900,_0x220c05=Math['round'](_0x11b86c*Math['pow'](0x2,_0x44f2d2-_0x4e8d15)-Math['pow'](0x2,_0x44f2d2))):(_0xde3731=0x0,_0x220c05=Math['round'](_0x11b86c/Math['pow'](0x2,0x1-_0x5ee900-_0x44f2d2))));const _0x40f530=[];for(_0x24d614=_0x44f2d2;_0x24d614;_0x24d614-=0x1)_0x40f530['push'](_0x220c05%0x2?0x1:0x0),_0x220c05=Math['floor'](_0x220c05/0x2);for(_0x24d614=_0x3543d2;_0x24d614;_0x24d614-=0x1)_0x40f530['push'](_0xde3731%0x2?0x1:0x0),_0xde3731=Math['floor'](_0xde3731/0x2);_0x40f530['push'](_0x18486d?0x1:0x0),_0x40f530['reverse']();const _0x34bc59=_0x40f530['join']('');let _0x2509e4='';for(_0x24d614=0x0;_0x24d614<0x40;_0x24d614+=0x8){let _0x595335=parseInt(_0x34bc59['substr'](_0x24d614,0x8),0x2)['toString'](0x10);_0x595335['length']===0x1&&(_0x595335='0'+_0x595335),_0x2509e4=_0x2509e4+_0x595335;}return _0x2509e4['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x1147a6,_0x5c71c6){let _0x12d760='Unknown\x20Error';_0x1147a6==='too_big'?_0x12d760='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1147a6==='permission_denied'?_0x12d760='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1147a6==='unavailable'&&(_0x12d760='The\x20service\x20is\x20unavailable');const _0x14367a=new Error(_0x1147a6+'\x20at\x20'+_0x5c71c6['_path']['toString']()+':\x20'+_0x12d760);return _0x14367a['code']=_0x1147a6['toUpperCase'](),_0x14367a;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x55677e){if(Yl['test'](_0x55677e)){const _0x4f62ad=Number(_0x55677e);if(_0x4f62ad>=Ql&&_0x4f62ad<=Jl)return _0x4f62ad;}return null;},ft=function(_0x5cd5e6){try{_0x5cd5e6();}catch(_0x3cd775){setTimeout(()=>{const _0x39c3de=_0x3cd775['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x39c3de),_0x3cd775;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x3ae25c,_0x11c0a7){const _0x480992=setTimeout(_0x3ae25c,_0x11c0a7);return typeof _0x480992=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x480992):typeof _0x480992=='object'&&_0x480992['unref']&&_0x480992['unref'](),_0x480992;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0xe6a0e3,_0x175595){this['appCheckProvider']=_0x175595,this['appName']=_0xe6a0e3['name'],$(_0xe6a0e3)&&_0xe6a0e3['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xe6a0e3['settings']['appCheckToken']),this['appCheck']=_0x175595==null?void 0x0:_0x175595['getImmediate']({'optional':!0x0}),this['appCheck']||_0x175595==null||_0x175595['get']()['then'](_0x7b5e5e=>this['appCheck']=_0x7b5e5e);}['getToken'](_0x27f597){if(this['serverAppAppCheckToken']){if(_0x27f597)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x27f597):new Promise((_0x55f449,_0x2071e7)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x27f597)['then'](_0x55f449,_0x2071e7):_0x55f449(null);},0x0);});}['addTokenChangeListener'](_0x201c25){var _0x4fc832;(_0x4fc832=this['appCheckProvider'])==null||_0x4fc832['get']()['then'](_0x4f3c05=>_0x4f3c05['addTokenListener'](_0x201c25));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xc4e189,_0x2bdcee,_0x9524fb){this['appName_']=_0xc4e189,this['firebaseOptions_']=_0x2bdcee,this['authProvider_']=_0x9524fb,this['auth_']=null,this['auth_']=_0x9524fb['getImmediate']({'optional':!0x0}),this['auth_']||_0x9524fb['onInit'](_0x3b809d=>this['auth_']=_0x3b809d);}['getToken'](_0x4cf369){return this['auth_']?this['auth_']['getToken'](_0x4cf369)['catch'](_0x8b25ad=>_0x8b25ad&&_0x8b25ad['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x8b25ad)):new Promise((_0x342992,_0x24f468)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4cf369)['then'](_0x342992,_0x24f468):_0x342992(null);},0x0);});}['addTokenChangeListener'](_0x2168fe){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2168fe):this['authProvider_']['get']()['then'](_0x5c1d99=>_0x5c1d99['addAuthTokenListener'](_0x2168fe));}['removeTokenChangeListener'](_0x35ac82){this['authProvider_']['get']()['then'](_0x5d4d3d=>_0x5d4d3d['removeAuthTokenListener'](_0x35ac82));}['notifyForInvalidToken'](){let _0x265b46='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x265b46+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x265b46+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x265b46+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x265b46);}}class an{constructor(_0x1f35e8){this['accessToken']=_0x1f35e8;}['getToken'](_0x2f2c10){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x9ac034){_0x9ac034(this['accessToken']);}['removeTokenChangeListener'](_0x1db08e){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x41315f,_0x2c73c0,_0x4303bd,_0x228aca,_0x496660=!0x1,_0x5026a4='',_0x18d9c9=!0x1,_0x50ed16=!0x1,_0x8da4f=null){this['secure']=_0x2c73c0,this['namespace']=_0x4303bd,this['webSocketOnly']=_0x228aca,this['nodeAdmin']=_0x496660,this['persistenceKey']=_0x5026a4,this['includeNamespaceInQueryParams']=_0x18d9c9,this['isUsingEmulator']=_0x50ed16,this['emulatorOptions']=_0x8da4f,this['_host']=_0x41315f['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x41315f)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2ea31c){_0x2ea31c!==this['internalHost']&&(this['internalHost']=_0x2ea31c,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0xc35425=this['toURLString']();return this['persistenceKey']&&(_0xc35425+='<'+this['persistenceKey']+'>'),_0xc35425;}['toURLString'](){const _0x568036=this['secure']?'https://':'http://',_0x5c2d91=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x568036+this['host']+'/'+_0x5c2d91;}}function th(_0x1106b4){return _0x1106b4['host']!==_0x1106b4['internalHost']||_0x1106b4['isCustomHost']()||_0x1106b4['includeNamespaceInQueryParams'];}function vo(_0x24413a,_0x3b2de2,_0x5379fc){f(typeof _0x3b2de2=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x5379fc=='object','typeof\x20params\x20must\x20==\x20object');let _0x4aac4f;if(_0x3b2de2===go)_0x4aac4f=(_0x24413a['secure']?'wss://':'ws://')+_0x24413a['internalHost']+'/.ws?';else{if(_0x3b2de2===mo)_0x4aac4f=(_0x24413a['secure']?'https://':'http://')+_0x24413a['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3b2de2);}th(_0x24413a)&&(_0x5379fc['ns']=_0x24413a['namespace']);const _0x219d97=[];return x(_0x5379fc,(_0x213338,_0x35e7c0)=>{_0x219d97['push'](_0x213338+'='+_0x35e7c0);}),_0x4aac4f+_0x219d97['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x2237c9,_0x6358a7=0x1){Q(this['counters_'],_0x2237c9)||(this['counters_'][_0x2237c9]=0x0),this['counters_'][_0x2237c9]+=_0x6358a7;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x3fba37){const _0x1c9020=_0x3fba37['toString']();return oi[_0x1c9020]||(oi[_0x1c9020]=new nh()),oi[_0x1c9020];}function ih(_0x9d964d,_0x1be581){const _0x217050=_0x9d964d['toString']();return ai[_0x217050]||(ai[_0x217050]=_0x1be581()),ai[_0x217050];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3bf226){this['onMessage_']=_0x3bf226,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x191e23,_0x592720){this['closeAfterResponse']=_0x191e23,this['onClose']=_0x592720,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x19066e,_0xed8a49){for(this['pendingResponses'][_0x19066e]=_0xed8a49;this['pendingResponses'][this['currentResponseNum']];){const _0x19b02d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xd8e7c9=0x0;_0xd8e7c9<_0x19b02d['length'];++_0xd8e7c9)_0x19b02d[_0xd8e7c9]&&ft(()=>{this['onMessage_'](_0x19b02d[_0xd8e7c9]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x5edcee,_0x428600,_0x9d6f20,_0x28a7e6,_0x3cd3ed,_0xb4310e,_0x51626a){this['connId']=_0x5edcee,this['repoInfo']=_0x428600,this['applicationId']=_0x9d6f20,this['appCheckToken']=_0x28a7e6,this['authToken']=_0x3cd3ed,this['transportSessionId']=_0xb4310e,this['lastSessionId']=_0x51626a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x5edcee),this['stats_']=qi(_0x428600),this['urlFn']=_0xf77031=>(this['appCheckToken']&&(_0xf77031[wi]=this['appCheckToken']),vo(_0x428600,mo,_0xf77031));}['open'](_0x3c1acd,_0x272e6c){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x272e6c,this['myPacketOrderer']=new sh(_0x3c1acd),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0xf0d16c)=>{const [_0x41661c,_0x30eaba,_0x5a8760,_0x2376fc,_0x475dd2]=_0xf0d16c;if(this['incrementIncomingBytes_'](_0xf0d16c),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x41661c===qs)this['id']=_0x30eaba,this['password']=_0x5a8760;else{if(_0x41661c===rh)_0x30eaba?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x30eaba,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x41661c);}}},(..._0x3dc3a4)=>{const [_0x26984f,_0xa8500a]=_0x3dc3a4;this['incrementIncomingBytes_'](_0x3dc3a4),this['myPacketOrderer']['handleResponse'](_0x26984f,_0xa8500a);},()=>{this['onClosed_']();},this['urlFn']);const _0x36c8c4={};_0x36c8c4[qs]='t',_0x36c8c4[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x36c8c4[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x36c8c4[co]=Gi,this['transportSessionId']&&(_0x36c8c4[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x36c8c4[po]=this['lastSessionId']),this['applicationId']&&(_0x36c8c4[_o]=this['applicationId']),this['appCheckToken']&&(_0x36c8c4[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x36c8c4[ho]=uo);const _0x448baa=this['urlFn'](_0x36c8c4);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x448baa),this['scriptTagHolder']['addTag'](_0x448baa,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x483fa6){const _0x18ca1e=O(_0x483fa6);this['bytesSent']+=_0x18ca1e['length'],this['stats_']['incrementCounter']('bytes_sent',_0x18ca1e['length']);const _0x3a8437=$r(_0x18ca1e),_0x4fb8d2=oo(_0x3a8437,fh);for(let _0x5b7ed6=0x0;_0x5b7ed6<_0x4fb8d2['length'];_0x5b7ed6++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x4fb8d2['length'],_0x4fb8d2[_0x5b7ed6]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x37a61e,_0x1f3812){this['myDisconnFrame']=document['createElement']('iframe');const _0x93b5c2={};_0x93b5c2[dh]='t',_0x93b5c2[Eo]=_0x37a61e,_0x93b5c2[Io]=_0x1f3812,this['myDisconnFrame']['src']=this['urlFn'](_0x93b5c2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xf85447){const _0x36dc5b=O(_0xf85447)['length'];this['bytesReceived']+=_0x36dc5b,this['stats_']['incrementCounter']('bytes_received',_0x36dc5b);}}class zi{constructor(_0x238fbf,_0x2b5e30,_0x45fe80,_0xe2a2e4){this['onDisconnect']=_0x45fe80,this['urlFn']=_0xe2a2e4,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x238fbf,window[ah+this['uniqueCallbackIdentifier']]=_0x2b5e30,this['myIFrame']=zi['createIFrame_']();let _0x4aa167='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4aa167='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x9c9ff='<html><body>'+_0x4aa167+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x9c9ff),this['myIFrame']['doc']['close']();}catch(_0x2eff9b){L('frame\x20writing\x20exception'),_0x2eff9b['stack']&&L(_0x2eff9b['stack']),L(_0x2eff9b);}}}static['createIFrame_'](){const _0x5df3c6=document['createElement']('iframe');if(_0x5df3c6['style']['display']='none',document['body']){document['body']['appendChild'](_0x5df3c6);try{_0x5df3c6['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x564255=document['domain'];_0x5df3c6['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x564255+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x5df3c6['contentDocument']?_0x5df3c6['doc']=_0x5df3c6['contentDocument']:_0x5df3c6['contentWindow']?_0x5df3c6['doc']=_0x5df3c6['contentWindow']['document']:_0x5df3c6['document']&&(_0x5df3c6['doc']=_0x5df3c6['document']),_0x5df3c6;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x368eb1=this['onDisconnect'];_0x368eb1&&(this['onDisconnect']=null,_0x368eb1());}['startLongPoll'](_0xa2f7d9,_0x5376a3){for(this['myID']=_0xa2f7d9,this['myPW']=_0x5376a3,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2ec4cf={};_0x2ec4cf[Eo]=this['myID'],_0x2ec4cf[Io]=this['myPW'],_0x2ec4cf[wo]=this['currentSerial'];let _0x3f21f4=this['urlFn'](_0x2ec4cf),_0x4703c9='',_0x2bb312=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x4703c9['length']<=Co;){const _0x30a4c8=this['pendingSegs']['shift']();_0x4703c9=_0x4703c9+'&'+lh+_0x2bb312+'='+_0x30a4c8['seg']+'&'+hh+_0x2bb312+'='+_0x30a4c8['ts']+'&'+uh+_0x2bb312+'='+_0x30a4c8['d'],_0x2bb312++;}return _0x3f21f4=_0x3f21f4+_0x4703c9,this['addLongPollTag_'](_0x3f21f4,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5620d4,_0x409fab,_0x1fe33b){this['pendingSegs']['push']({'seg':_0x5620d4,'ts':_0x409fab,'d':_0x1fe33b}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1efbee,_0x25b5d5){this['outstandingRequests']['add'](_0x25b5d5);const _0x425f2f=()=>{this['outstandingRequests']['delete'](_0x25b5d5),this['newRequest_']();},_0x4b0cc3=setTimeout(_0x425f2f,Math['floor'](ph)),_0xefd4c2=()=>{clearTimeout(_0x4b0cc3),_0x425f2f();};this['addTag'](_0x1efbee,_0xefd4c2);}['addTag'](_0x22e943,_0x20a039){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0xde8aae=this['myIFrame']['doc']['createElement']('script');_0xde8aae['type']='text/javascript',_0xde8aae['async']=!0x0,_0xde8aae['src']=_0x22e943,_0xde8aae['onload']=_0xde8aae['onreadystatechange']=function(){const _0x170d5e=_0xde8aae['readyState'];(!_0x170d5e||_0x170d5e==='loaded'||_0x170d5e==='complete')&&(_0xde8aae['onload']=_0xde8aae['onreadystatechange']=null,_0xde8aae['parentNode']&&_0xde8aae['parentNode']['removeChild'](_0xde8aae),_0x20a039());},_0xde8aae['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x22e943),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0xde8aae);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x28c600,_0x3cc7b9,_0x5c23eb,_0x288f9a,_0x48976a,_0x4cda58,_0x23b8ad){this['connId']=_0x28c600,this['applicationId']=_0x5c23eb,this['appCheckToken']=_0x288f9a,this['authToken']=_0x48976a,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x3cc7b9),this['connURL']=q['connectionURL_'](_0x3cc7b9,_0x4cda58,_0x23b8ad,_0x288f9a,_0x5c23eb),this['nodeAdmin']=_0x3cc7b9['nodeAdmin'];}static['connectionURL_'](_0xb563b1,_0x13c2fd,_0x49fbdf,_0x4f5d96,_0x396605){const _0xf73f14={};return _0xf73f14[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0xf73f14[ho]=uo),_0x13c2fd&&(_0xf73f14[lo]=_0x13c2fd),_0x49fbdf&&(_0xf73f14[po]=_0x49fbdf),_0x4f5d96&&(_0xf73f14[wi]=_0x4f5d96),_0x396605&&(_0xf73f14[_o]=_0x396605),vo(_0xb563b1,go,_0xf73f14);}['open'](_0x5591e0,_0x502add){this['onDisconnect']=_0x502add,this['onMessage']=_0x5591e0,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x32d65d;_c(),this['mySock']=new gn(this['connURL'],[],_0x32d65d);}catch(_0x550ce5){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x46de5c=_0x550ce5['message']||_0x550ce5['data'];_0x46de5c&&this['log_'](_0x46de5c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x45b696=>{this['handleIncomingFrame'](_0x45b696);},this['mySock']['onerror']=_0x73f284=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x5ef495=_0x73f284['message']||_0x73f284['data'];_0x5ef495&&this['log_'](_0x5ef495),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x54b3fb=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3c130a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x255197=navigator['userAgent']['match'](_0x3c130a);_0x255197&&_0x255197['length']>0x1&&parseFloat(_0x255197[0x1])<4.4&&(_0x54b3fb=!0x0);}return!_0x54b3fb&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5dfe70){if(this['frames']['push'](_0x5dfe70),this['frames']['length']===this['totalFrames']){const _0x195252=this['frames']['join']('');this['frames']=null;const _0x9c7494=Nt(_0x195252);this['onMessage'](_0x9c7494);}}['handleNewFrameCount_'](_0x106f02){this['totalFrames']=_0x106f02,this['frames']=[];}['extractFrameCount_'](_0xcef479){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0xcef479['length']<=0x6){const _0x21be56=Number(_0xcef479);if(!isNaN(_0x21be56))return this['handleNewFrameCount_'](_0x21be56),null;}return this['handleNewFrameCount_'](0x1),_0xcef479;}['handleIncomingFrame'](_0x2a40b7){if(this['mySock']===null)return;const _0x2cf4c5=_0x2a40b7['data'];if(this['bytesReceived']+=_0x2cf4c5['length'],this['stats_']['incrementCounter']('bytes_received',_0x2cf4c5['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2cf4c5);else{const _0x27aebe=this['extractFrameCount_'](_0x2cf4c5);_0x27aebe!==null&&this['appendFrame_'](_0x27aebe);}}['send'](_0x21e0db){this['resetKeepAlive']();const _0xb6de0b=O(_0x21e0db);this['bytesSent']+=_0xb6de0b['length'],this['stats_']['incrementCounter']('bytes_sent',_0xb6de0b['length']);const _0x45f55b=oo(_0xb6de0b,gh);_0x45f55b['length']>0x1&&this['sendString_'](String(_0x45f55b['length']));for(let _0x8f0d46=0x0;_0x8f0d46<_0x45f55b['length'];_0x8f0d46++)this['sendString_'](_0x45f55b[_0x8f0d46]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x3891a0){try{this['mySock']['send'](_0x3891a0);}catch(_0x303541){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x303541['message']||_0x303541['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x176f95){this['initTransports_'](_0x176f95);}['initTransports_'](_0x43892a){const _0x3f0927=q&&q['isAvailable']();let _0x355892=_0x3f0927&&!q['previouslyFailed']();if(_0x43892a['webSocketOnly']&&(_0x3f0927||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x355892=!0x0),_0x355892)this['transports_']=[q];else{const _0x2e3117=this['transports_']=[];for(const _0x3086e3 of Dt['ALL_TRANSPORTS'])_0x3086e3&&_0x3086e3['isAvailable']()&&_0x2e3117['push'](_0x3086e3);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x49dcf6,_0x1ce700,_0x5aab09,_0x747fb7,_0x4c7964,_0x3acad3,_0x21c0bf,_0x16a97a,_0x584729,_0x58c1c3){this['id']=_0x49dcf6,this['repoInfo_']=_0x1ce700,this['applicationId_']=_0x5aab09,this['appCheckToken_']=_0x747fb7,this['authToken_']=_0x4c7964,this['onMessage_']=_0x3acad3,this['onReady_']=_0x21c0bf,this['onDisconnect_']=_0x16a97a,this['onKill_']=_0x584729,this['lastSessionId']=_0x58c1c3,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x1ce700),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0xb6cf72=this['transportManager_']['initialTransport']();this['conn_']=new _0xb6cf72(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0xb6cf72['responsesRequiredToBeHealthy']||0x0;const _0x663f26=this['connReceiver_'](this['conn_']),_0xb8f96e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x663f26,_0xb8f96e);},Math['floor'](0x0));const _0x28ed5b=_0xb6cf72['healthyTimeout']||0x0;_0x28ed5b>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x28ed5b)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x288c3c){return _0x11d4fa=>{_0x288c3c===this['conn_']?this['onConnectionLost_'](_0x11d4fa):_0x288c3c===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x34553f){return _0x3c82fc=>{this['state_']!==0x2&&(_0x34553f===this['rx_']?this['onPrimaryMessageReceived_'](_0x3c82fc):_0x34553f===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3c82fc):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x50270e){const _0x22d057={'t':'d','d':_0x50270e};this['sendData_'](_0x22d057);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x58741b){if(ci in _0x58741b){const _0x3d0992=_0x58741b[ci];_0x3d0992===Ys?this['upgradeIfSecondaryHealthy_']():_0x3d0992===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3d0992===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x352cc3){const _0xb273e9=vt('t',_0x352cc3),_0x5e1a6b=vt('d',_0x352cc3);if(_0xb273e9==='c')this['onSecondaryControl_'](_0x5e1a6b);else{if(_0xb273e9==='d')this['pendingDataMessages']['push'](_0x5e1a6b);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0xb273e9);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2eed61){const _0x10ac68=vt('t',_0x2eed61),_0x183aff=vt('d',_0x2eed61);_0x10ac68==='c'?this['onControl_'](_0x183aff):_0x10ac68==='d'&&this['onDataMessage_'](_0x183aff);}['onDataMessage_'](_0x479c99){this['onPrimaryResponse_'](),this['onMessage_'](_0x479c99);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x30f11f){const _0x50bc3a=vt(ci,_0x30f11f);if(zs in _0x30f11f){const _0x572dde=_0x30f11f[zs];if(_0x50bc3a===Th){const _0x399612={..._0x572dde};this['repoInfo_']['isUsingEmulator']&&(_0x399612['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x399612);}else{if(_0x50bc3a===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x4d6dd1=0x0;_0x4d6dd1<this['pendingDataMessages']['length'];++_0x4d6dd1)this['onDataMessage_'](this['pendingDataMessages'][_0x4d6dd1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x50bc3a===wh?this['onConnectionShutdown_'](_0x572dde):_0x50bc3a===js?this['onReset_'](_0x572dde):_0x50bc3a===Ch?Ii('Server\x20Error:\x20'+_0x572dde):_0x50bc3a===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x50bc3a);}}}['onHandshake_'](_0x12e84e){const _0x34f0c2=_0x12e84e['ts'],_0x57504b=_0x12e84e['v'],_0x5f0038=_0x12e84e['h'];this['sessionId']=_0x12e84e['s'],this['repoInfo_']['host']=_0x5f0038,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x34f0c2),Gi!==_0x57504b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x14de2e=this['transportManager_']['upgradeTransport']();_0x14de2e&&this['startUpgrade_'](_0x14de2e);}['startUpgrade_'](_0x53013d){this['secondaryConn_']=new _0x53013d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x53013d['responsesRequiredToBeHealthy']||0x0;const _0x50c763=this['connReceiver_'](this['secondaryConn_']),_0x400f61=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x50c763,_0x400f61),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3c88fe){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3c88fe),this['repoInfo_']['host']=_0x3c88fe,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x55714d,_0x7886bd){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x55714d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x7886bd,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x229947=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x229947||this['rx_']===_0x229947)&&this['close']();}['onConnectionLost_'](_0x58eee7){this['conn_']=null,!_0x58eee7&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3d3b60){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3d3b60),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3f4bbd){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3f4bbd);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x2e83f1,_0x4b60fc,_0x9bd357,_0x5569c5){}['merge'](_0x401e80,_0x59e032,_0x1c004d,_0x4a4e6a){}['refreshAuthToken'](_0x2ebfcf){}['refreshAppCheckToken'](_0x1e02ba){}['onDisconnectPut'](_0x251109,_0x18cbc4,_0x3dfa0f){}['onDisconnectMerge'](_0x16c5c8,_0x347175,_0x3a15e1){}['onDisconnectCancel'](_0x251335,_0x3ab90d){}['reportStats'](_0x31a28d){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x5224c7){this['allowedEvents_']=_0x5224c7,this['listeners_']={},f(Array['isArray'](_0x5224c7)&&_0x5224c7['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x38c03c,..._0x580398){if(Array['isArray'](this['listeners_'][_0x38c03c])){const _0x45b299=[...this['listeners_'][_0x38c03c]];for(let _0x53b829=0x0;_0x53b829<_0x45b299['length'];_0x53b829++)_0x45b299[_0x53b829]['callback']['apply'](_0x45b299[_0x53b829]['context'],_0x580398);}}['on'](_0x2bec7e,_0x41cc43,_0x520a80){this['validateEventType_'](_0x2bec7e),this['listeners_'][_0x2bec7e]=this['listeners_'][_0x2bec7e]||[],this['listeners_'][_0x2bec7e]['push']({'callback':_0x41cc43,'context':_0x520a80});const _0x7e624a=this['getInitialEvent'](_0x2bec7e);_0x7e624a&&_0x41cc43['apply'](_0x520a80,_0x7e624a);}['off'](_0x3b2bed,_0x3070a7,_0x406bcc){this['validateEventType_'](_0x3b2bed);const _0x46e1b0=this['listeners_'][_0x3b2bed]||[];for(let _0x52d763=0x0;_0x52d763<_0x46e1b0['length'];_0x52d763++)if(_0x46e1b0[_0x52d763]['callback']===_0x3070a7&&(!_0x406bcc||_0x406bcc===_0x46e1b0[_0x52d763]['context'])){_0x46e1b0['splice'](_0x52d763,0x1);return;}}['validateEventType_'](_0x5da9c6){f(this['allowedEvents_']['find'](_0x1c0624=>_0x1c0624===_0x5da9c6),'Unknown\x20event:\x20'+_0x5da9c6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4fe5d6){return f(_0x4fe5d6==='online','Unknown\x20event\x20type:\x20'+_0x4fe5d6),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x18f168,_0x23ca1c){if(_0x23ca1c===void 0x0){this['pieces_']=_0x18f168['split']('/');let _0x138646=0x0;for(let _0x2458c7=0x0;_0x2458c7<this['pieces_']['length'];_0x2458c7++)this['pieces_'][_0x2458c7]['length']>0x0&&(this['pieces_'][_0x138646]=this['pieces_'][_0x2458c7],_0x138646++);this['pieces_']['length']=_0x138646,this['pieceNum_']=0x0;}else this['pieces_']=_0x18f168,this['pieceNum_']=_0x23ca1c;}['toString'](){let _0x2a9e10='';for(let _0x1dc9f5=this['pieceNum_'];_0x1dc9f5<this['pieces_']['length'];_0x1dc9f5++)this['pieces_'][_0x1dc9f5]!==''&&(_0x2a9e10+='/'+this['pieces_'][_0x1dc9f5]);return _0x2a9e10||'/';}}function w(){return new C('');}function y(_0x1c1fc3){return _0x1c1fc3['pieceNum_']>=_0x1c1fc3['pieces_']['length']?null:_0x1c1fc3['pieces_'][_0x1c1fc3['pieceNum_']];}function Ce(_0x334124){return _0x334124['pieces_']['length']-_0x334124['pieceNum_'];}function S(_0x1c7347){let _0x33ac08=_0x1c7347['pieceNum_'];return _0x33ac08<_0x1c7347['pieces_']['length']&&_0x33ac08++,new C(_0x1c7347['pieces_'],_0x33ac08);}function ji(_0x245296){return _0x245296['pieceNum_']<_0x245296['pieces_']['length']?_0x245296['pieces_'][_0x245296['pieces_']['length']-0x1]:null;}function bh(_0x1f6789){let _0x34b6a1='';for(let _0x1557ff=_0x1f6789['pieceNum_'];_0x1557ff<_0x1f6789['pieces_']['length'];_0x1557ff++)_0x1f6789['pieces_'][_0x1557ff]!==''&&(_0x34b6a1+='/'+encodeURIComponent(String(_0x1f6789['pieces_'][_0x1557ff])));return _0x34b6a1||'/';}function Mt(_0x54a82a,_0x58c00d=0x0){return _0x54a82a['pieces_']['slice'](_0x54a82a['pieceNum_']+_0x58c00d);}function Ro(_0x570519){if(_0x570519['pieceNum_']>=_0x570519['pieces_']['length'])return null;const _0x14ab69=[];for(let _0x49cb21=_0x570519['pieceNum_'];_0x49cb21<_0x570519['pieces_']['length']-0x1;_0x49cb21++)_0x14ab69['push'](_0x570519['pieces_'][_0x49cb21]);return new C(_0x14ab69,0x0);}function k(_0x292f14,_0x19997c){const _0x2fe5cb=[];for(let _0x1511d6=_0x292f14['pieceNum_'];_0x1511d6<_0x292f14['pieces_']['length'];_0x1511d6++)_0x2fe5cb['push'](_0x292f14['pieces_'][_0x1511d6]);if(_0x19997c instanceof C){for(let _0x52ba20=_0x19997c['pieceNum_'];_0x52ba20<_0x19997c['pieces_']['length'];_0x52ba20++)_0x2fe5cb['push'](_0x19997c['pieces_'][_0x52ba20]);}else{const _0x1c5256=_0x19997c['split']('/');for(let _0x91081a=0x0;_0x91081a<_0x1c5256['length'];_0x91081a++)_0x1c5256[_0x91081a]['length']>0x0&&_0x2fe5cb['push'](_0x1c5256[_0x91081a]);}return new C(_0x2fe5cb,0x0);}function v(_0x53a7ff){return _0x53a7ff['pieceNum_']>=_0x53a7ff['pieces_']['length'];}function F(_0x4c87fc,_0x1fa81e){const _0x2ccef2=y(_0x4c87fc),_0x37a099=y(_0x1fa81e);if(_0x2ccef2===null)return _0x1fa81e;if(_0x2ccef2===_0x37a099)return F(S(_0x4c87fc),S(_0x1fa81e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1fa81e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x4c87fc+')');}function Rh(_0x3ed7e7,_0x47cad1){const _0x12b44b=Mt(_0x3ed7e7,0x0),_0x2ee5a2=Mt(_0x47cad1,0x0);for(let _0x139a79=0x0;_0x139a79<_0x12b44b['length']&&_0x139a79<_0x2ee5a2['length'];_0x139a79++){const _0x2a121e=qe(_0x12b44b[_0x139a79],_0x2ee5a2[_0x139a79]);if(_0x2a121e!==0x0)return _0x2a121e;}return _0x12b44b['length']===_0x2ee5a2['length']?0x0:_0x12b44b['length']<_0x2ee5a2['length']?-0x1:0x1;}function Ki(_0x1fac1c,_0x451207){if(Ce(_0x1fac1c)!==Ce(_0x451207))return!0x1;for(let _0x4b9c26=_0x1fac1c['pieceNum_'],_0xc17922=_0x451207['pieceNum_'];_0x4b9c26<=_0x1fac1c['pieces_']['length'];_0x4b9c26++,_0xc17922++)if(_0x1fac1c['pieces_'][_0x4b9c26]!==_0x451207['pieces_'][_0xc17922])return!0x1;return!0x0;}function G(_0x540f1f,_0x56a005){let _0x1f5904=_0x540f1f['pieceNum_'],_0x1d3cb1=_0x56a005['pieceNum_'];if(Ce(_0x540f1f)>Ce(_0x56a005))return!0x1;for(;_0x1f5904<_0x540f1f['pieces_']['length'];){if(_0x540f1f['pieces_'][_0x1f5904]!==_0x56a005['pieces_'][_0x1d3cb1])return!0x1;++_0x1f5904,++_0x1d3cb1;}return!0x0;}class Ah{constructor(_0x417637,_0x25629a){this['errorPrefix_']=_0x25629a,this['parts_']=Mt(_0x417637,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x50f89d=0x0;_0x50f89d<this['parts_']['length'];_0x50f89d++)this['byteLength_']+=Ln(this['parts_'][_0x50f89d]);Ao(this);}}function kh(_0x5b31b2,_0x4f4140){_0x5b31b2['parts_']['length']>0x0&&(_0x5b31b2['byteLength_']+=0x1),_0x5b31b2['parts_']['push'](_0x4f4140),_0x5b31b2['byteLength_']+=Ln(_0x4f4140),Ao(_0x5b31b2);}function Ph(_0xdce9f){const _0x587ead=_0xdce9f['parts_']['pop']();_0xdce9f['byteLength_']-=Ln(_0x587ead),_0xdce9f['parts_']['length']>0x0&&(_0xdce9f['byteLength_']-=0x1);}function Ao(_0xbb8819){if(_0xbb8819['byteLength_']>Zs)throw new Error(_0xbb8819['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0xbb8819['byteLength_']+').');if(_0xbb8819['parts_']['length']>Xs)throw new Error(_0xbb8819['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0xbb8819));}function Oe(_0x150f01){return _0x150f01['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x150f01['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x5577d0,_0x6786d5;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x6786d5='visibilitychange',_0x5577d0='hidden'):typeof document['mozHidden']<'u'?(_0x6786d5='mozvisibilitychange',_0x5577d0='mozHidden'):typeof document['msHidden']<'u'?(_0x6786d5='msvisibilitychange',_0x5577d0='msHidden'):typeof document['webkitHidden']<'u'&&(_0x6786d5='webkitvisibilitychange',_0x5577d0='webkitHidden')),this['visible_']=!0x0,_0x6786d5&&document['addEventListener'](_0x6786d5,()=>{const _0x5ad4e1=!document[_0x5577d0];_0x5ad4e1!==this['visible_']&&(this['visible_']=_0x5ad4e1,this['trigger']('visible',_0x5ad4e1));},!0x1);}['getInitialEvent'](_0x28f0c1){return f(_0x28f0c1==='visible','Unknown\x20event\x20type:\x20'+_0x28f0c1),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x2160ec,_0x1bcad2,_0x2eb723,_0x43eedb,_0x2f71c2,_0x4ef09c,_0x4cce51,_0x536fa2){if(super(),this['repoInfo_']=_0x2160ec,this['applicationId_']=_0x1bcad2,this['onDataUpdate_']=_0x2eb723,this['onConnectStatus_']=_0x43eedb,this['onServerInfoUpdate_']=_0x2f71c2,this['authTokenProvider_']=_0x4ef09c,this['appCheckTokenProvider_']=_0x4cce51,this['authOverride_']=_0x536fa2,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x536fa2)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x2160ec['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3da595,_0x44b8d4,_0x44cb84){const _0x6b63a1=++this['requestNumber_'],_0x1b0316={'r':_0x6b63a1,'a':_0x3da595,'b':_0x44b8d4};this['log_'](O(_0x1b0316)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1b0316),_0x44cb84&&(this['requestCBHash_'][_0x6b63a1]=_0x44cb84);}['get'](_0x22303e){this['initConnection_']();const _0x3ac303=new H(),_0x95608b={'action':'g','request':{'p':_0x22303e['_path']['toString'](),'q':_0x22303e['_queryObject']},'onComplete':_0x542815=>{const _0x3a39af=_0x542815['d'];_0x542815['s']==='ok'?_0x3ac303['resolve'](_0x3a39af):_0x3ac303['reject'](_0x3a39af);}};this['outstandingGets_']['push'](_0x95608b),this['outstandingGetCount_']++;const _0x3897b4=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3897b4),_0x3ac303['promise'];}['listen'](_0x4a6476,_0x2a8691,_0x1feea6,_0x69dc2d){this['initConnection_']();const _0x1b3f78=_0x4a6476['_queryIdentifier'],_0x40c53c=_0x4a6476['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x40c53c+'\x20'+_0x1b3f78),this['listens']['has'](_0x40c53c)||this['listens']['set'](_0x40c53c,new Map()),f(_0x4a6476['_queryParams']['isDefault']()||!_0x4a6476['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x40c53c)['has'](_0x1b3f78),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x548108={'onComplete':_0x69dc2d,'hashFn':_0x2a8691,'query':_0x4a6476,'tag':_0x1feea6};this['listens']['get'](_0x40c53c)['set'](_0x1b3f78,_0x548108),this['connected_']&&this['sendListen_'](_0x548108);}['sendGet_'](_0x4c5e1f){const _0x5c7705=this['outstandingGets_'][_0x4c5e1f];this['sendRequest']('g',_0x5c7705['request'],_0x3674a6=>{delete this['outstandingGets_'][_0x4c5e1f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5c7705['onComplete']&&_0x5c7705['onComplete'](_0x3674a6);});}['sendListen_'](_0x5c511e){const _0x385e81=_0x5c511e['query'],_0x1f085c=_0x385e81['_path']['toString'](),_0x2aff4d=_0x385e81['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1f085c+'\x20for\x20'+_0x2aff4d);const _0x2db2e0={'p':_0x1f085c},_0x38e1d7='q';_0x5c511e['tag']&&(_0x2db2e0['q']=_0x385e81['_queryObject'],_0x2db2e0['t']=_0x5c511e['tag']),_0x2db2e0['h']=_0x5c511e['hashFn'](),this['sendRequest'](_0x38e1d7,_0x2db2e0,_0x47f96f=>{const _0x1e51a0=_0x47f96f['d'],_0x58b493=_0x47f96f['s'];se['warnOnListenWarnings_'](_0x1e51a0,_0x385e81),(this['listens']['get'](_0x1f085c)&&this['listens']['get'](_0x1f085c)['get'](_0x2aff4d))===_0x5c511e&&(this['log_']('listen\x20response',_0x47f96f),_0x58b493!=='ok'&&this['removeListen_'](_0x1f085c,_0x2aff4d),_0x5c511e['onComplete']&&_0x5c511e['onComplete'](_0x58b493,_0x1e51a0));});}static['warnOnListenWarnings_'](_0x25c8f1,_0xfb3f1b){if(_0x25c8f1&&typeof _0x25c8f1=='object'&&Q(_0x25c8f1,'w')){const _0xfedc2=Le(_0x25c8f1,'w');if(Array['isArray'](_0xfedc2)&&~_0xfedc2['indexOf']('no_index')){const _0x44235c='\x22.indexOn\x22:\x20\x22'+_0xfb3f1b['_queryParams']['getIndex']()['toString']()+'\x22',_0xdb83c4=_0xfb3f1b['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x44235c+'\x20at\x20'+_0xdb83c4+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2f582f){this['authToken_']=_0x2f582f,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2f582f);}['reduceReconnectDelayIfAdminCredential_'](_0x1428ab){(_0x1428ab&&_0x1428ab['length']===0x28||wc(_0x1428ab))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x7968c9){this['appCheckToken_']=_0x7968c9,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4bce78=this['authToken_'],_0x3c7ed3=Ic(_0x4bce78)?'auth':'gauth',_0x41098f={'cred':_0x4bce78};this['authOverride_']===null?_0x41098f['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x41098f['authvar']=this['authOverride_']),this['sendRequest'](_0x3c7ed3,_0x41098f,_0x2e6616=>{const _0x411c2f=_0x2e6616['s'],_0x2ecc72=_0x2e6616['d']||'error';this['authToken_']===_0x4bce78&&(_0x411c2f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x411c2f,_0x2ecc72));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x548a16=>{const _0xfca82b=_0x548a16['s'],_0x128be7=_0x548a16['d']||'error';_0xfca82b==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xfca82b,_0x128be7);});}['unlisten'](_0x247fd7,_0x30b981){const _0x283e43=_0x247fd7['_path']['toString'](),_0x10146e=_0x247fd7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x283e43+'\x20'+_0x10146e),f(_0x247fd7['_queryParams']['isDefault']()||!_0x247fd7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x283e43,_0x10146e)&&this['connected_']&&this['sendUnlisten_'](_0x283e43,_0x10146e,_0x247fd7['_queryObject'],_0x30b981);}['sendUnlisten_'](_0x3274d9,_0x43d36a,_0x4fa84c,_0xf4f1c7){this['log_']('Unlisten\x20on\x20'+_0x3274d9+'\x20for\x20'+_0x43d36a);const _0x193d7a={'p':_0x3274d9},_0x4433e6='n';_0xf4f1c7&&(_0x193d7a['q']=_0x4fa84c,_0x193d7a['t']=_0xf4f1c7),this['sendRequest'](_0x4433e6,_0x193d7a);}['onDisconnectPut'](_0xc0cf51,_0x51bc4d,_0x327f02){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0xc0cf51,_0x51bc4d,_0x327f02):this['onDisconnectRequestQueue_']['push']({'pathString':_0xc0cf51,'action':'o','data':_0x51bc4d,'onComplete':_0x327f02});}['onDisconnectMerge'](_0xfd32fa,_0x25e113,_0x58c8b6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0xfd32fa,_0x25e113,_0x58c8b6):this['onDisconnectRequestQueue_']['push']({'pathString':_0xfd32fa,'action':'om','data':_0x25e113,'onComplete':_0x58c8b6});}['onDisconnectCancel'](_0x2d13df,_0x2972da){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x2d13df,null,_0x2972da):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2d13df,'action':'oc','data':null,'onComplete':_0x2972da});}['sendOnDisconnect_'](_0x599fdd,_0x30f1fc,_0x536cf4,_0x427a41){const _0x6f6960={'p':_0x30f1fc,'d':_0x536cf4};this['log_']('onDisconnect\x20'+_0x599fdd,_0x6f6960),this['sendRequest'](_0x599fdd,_0x6f6960,_0x21d780=>{_0x427a41&&setTimeout(()=>{_0x427a41(_0x21d780['s'],_0x21d780['d']);},Math['floor'](0x0));});}['put'](_0x5585c1,_0x2d113b,_0xa239a7,_0xb293){this['putInternal']('p',_0x5585c1,_0x2d113b,_0xa239a7,_0xb293);}['merge'](_0x557d21,_0x4337c6,_0x4a4784,_0x8fa46e){this['putInternal']('m',_0x557d21,_0x4337c6,_0x4a4784,_0x8fa46e);}['putInternal'](_0x2edcbf,_0x571e53,_0x5550cb,_0x4ec951,_0x595412){this['initConnection_']();const _0x43cc53={'p':_0x571e53,'d':_0x5550cb};_0x595412!==void 0x0&&(_0x43cc53['h']=_0x595412),this['outstandingPuts_']['push']({'action':_0x2edcbf,'request':_0x43cc53,'onComplete':_0x4ec951}),this['outstandingPutCount_']++;const _0x8c3e08=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x8c3e08):this['log_']('Buffering\x20put:\x20'+_0x571e53);}['sendPut_'](_0x40e3c5){const _0x493ebe=this['outstandingPuts_'][_0x40e3c5]['action'],_0x5ce2bf=this['outstandingPuts_'][_0x40e3c5]['request'],_0x9133e3=this['outstandingPuts_'][_0x40e3c5]['onComplete'];this['outstandingPuts_'][_0x40e3c5]['queued']=this['connected_'],this['sendRequest'](_0x493ebe,_0x5ce2bf,_0x38ec09=>{this['log_'](_0x493ebe+'\x20response',_0x38ec09),delete this['outstandingPuts_'][_0x40e3c5],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x9133e3&&_0x9133e3(_0x38ec09['s'],_0x38ec09['d']);});}['reportStats'](_0x2fdcc9){if(this['connected_']){const _0xf1b4cf={'c':_0x2fdcc9};this['log_']('reportStats',_0xf1b4cf),this['sendRequest']('s',_0xf1b4cf,_0x35d12f=>{if(_0x35d12f['s']!=='ok'){const _0x764b34=_0x35d12f['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x764b34);}});}}['onDataMessage_'](_0x4adb1e){if('r'in _0x4adb1e){this['log_']('from\x20server:\x20'+O(_0x4adb1e));const _0x3abc27=_0x4adb1e['r'],_0x25add8=this['requestCBHash_'][_0x3abc27];_0x25add8&&(delete this['requestCBHash_'][_0x3abc27],_0x25add8(_0x4adb1e['b']));}else{if('error'in _0x4adb1e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4adb1e['error'];'a'in _0x4adb1e&&this['onDataPush_'](_0x4adb1e['a'],_0x4adb1e['b']);}}['onDataPush_'](_0x3e3e3f,_0x310b8a){this['log_']('handleServerMessage',_0x3e3e3f,_0x310b8a),_0x3e3e3f==='d'?this['onDataUpdate_'](_0x310b8a['p'],_0x310b8a['d'],!0x1,_0x310b8a['t']):_0x3e3e3f==='m'?this['onDataUpdate_'](_0x310b8a['p'],_0x310b8a['d'],!0x0,_0x310b8a['t']):_0x3e3e3f==='c'?this['onListenRevoked_'](_0x310b8a['p'],_0x310b8a['q']):_0x3e3e3f==='ac'?this['onAuthRevoked_'](_0x310b8a['s'],_0x310b8a['d']):_0x3e3e3f==='apc'?this['onAppCheckRevoked_'](_0x310b8a['s'],_0x310b8a['d']):_0x3e3e3f==='sd'?this['onSecurityDebugPacket_'](_0x310b8a):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3e3e3f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3ea8aa,_0x2bc945){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3ea8aa),this['lastSessionId']=_0x2bc945,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x228b72){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x228b72));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x3a9d0c){_0x3a9d0c&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x3a9d0c;}['onOnline_'](_0x482489){_0x482489?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x44a856=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x1c5d73=Math['max'](0x0,this['reconnectDelay_']-_0x44a856);_0x1c5d73=Math['random']()*_0x1c5d73,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x1c5d73+'ms'),this['scheduleConnect_'](_0x1c5d73),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1ad416=this['onDataMessage_']['bind'](this),_0x357131=this['onReady_']['bind'](this),_0x421ccf=this['onRealtimeDisconnect_']['bind'](this),_0xd1f899=this['id']+':'+se['nextConnectionId_']++,_0x45290d=this['lastSessionId'];let _0x25f4b9=!0x1,_0x253df6=null;const _0x20df6f=function(){_0x253df6?_0x253df6['close']():(_0x25f4b9=!0x0,_0x421ccf());},_0x2d946e=function(_0x579e55){f(_0x253df6,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x253df6['sendRequest'](_0x579e55);};this['realtime_']={'close':_0x20df6f,'sendRequest':_0x2d946e};const _0x17cd15=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xbec216,_0x1f67b4]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x17cd15),this['appCheckTokenProvider_']['getToken'](_0x17cd15)]);_0x25f4b9?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xbec216&&_0xbec216['accessToken'],this['appCheckToken_']=_0x1f67b4&&_0x1f67b4['token'],_0x253df6=new Sh(_0xd1f899,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1ad416,_0x357131,_0x421ccf,_0x5bfb01=>{U(_0x5bfb01+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x45290d));}catch(_0x19dfe2){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x19dfe2),_0x25f4b9||(this['repoInfo_']['nodeAdmin']&&U(_0x19dfe2),_0x20df6f());}}}['interrupt'](_0x488fa){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x488fa),this['interruptReasons_'][_0x488fa]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x5b67ab){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x5b67ab),delete this['interruptReasons_'][_0x5b67ab],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x935a7d){const _0x483fdd=_0x935a7d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x483fdd});}['cancelSentTransactions_'](){for(let _0xcfdacc=0x0;_0xcfdacc<this['outstandingPuts_']['length'];_0xcfdacc++){const _0x55cabd=this['outstandingPuts_'][_0xcfdacc];_0x55cabd&&'h'in _0x55cabd['request']&&_0x55cabd['queued']&&(_0x55cabd['onComplete']&&_0x55cabd['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xcfdacc],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x83ffb1,_0x536eaa){let _0xfab47e;_0x536eaa?_0xfab47e=_0x536eaa['map'](_0x12f9dd=>$i(_0x12f9dd))['join']('$'):_0xfab47e='default';const _0x43dd3e=this['removeListen_'](_0x83ffb1,_0xfab47e);_0x43dd3e&&_0x43dd3e['onComplete']&&_0x43dd3e['onComplete']('permission_denied');}['removeListen_'](_0x4ea521,_0x21f72e){const _0x20d90d=new C(_0x4ea521)['toString']();let _0x17785c;if(this['listens']['has'](_0x20d90d)){const _0xa19617=this['listens']['get'](_0x20d90d);_0x17785c=_0xa19617['get'](_0x21f72e),_0xa19617['delete'](_0x21f72e),_0xa19617['size']===0x0&&this['listens']['delete'](_0x20d90d);}else _0x17785c=void 0x0;return _0x17785c;}['onAuthRevoked_'](_0x3b8ac1,_0x5d930e){L('Auth\x20token\x20revoked:\x20'+_0x3b8ac1+'/'+_0x5d930e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3b8ac1==='invalid_token'||_0x3b8ac1==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x449126,_0x2268bb){L('App\x20check\x20token\x20revoked:\x20'+_0x449126+'/'+_0x2268bb),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x449126==='invalid_token'||_0x449126==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x491cef){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x491cef):'msg'in _0x491cef&&console['log']('FIREBASE:\x20'+_0x491cef['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2ff4c5 of this['listens']['values']())for(const _0x596bee of _0x2ff4c5['values']())this['sendListen_'](_0x596bee);for(let _0x1cb35e=0x0;_0x1cb35e<this['outstandingPuts_']['length'];_0x1cb35e++)this['outstandingPuts_'][_0x1cb35e]&&this['sendPut_'](_0x1cb35e);for(;this['onDisconnectRequestQueue_']['length'];){const _0x3676c1=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x3676c1['action'],_0x3676c1['pathString'],_0x3676c1['data'],_0x3676c1['onComplete']);}for(let _0x2d8d20=0x0;_0x2d8d20<this['outstandingGets_']['length'];_0x2d8d20++)this['outstandingGets_'][_0x2d8d20]&&this['sendGet_'](_0x2d8d20);}['sendConnectStats_'](){const _0x298d5d={};let _0x5e85d3='js';_0x298d5d['sdk.'+_0x5e85d3+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x298d5d['framework.cordova']=0x1:Kr()&&(_0x298d5d['framework.reactnative']=0x1),this['reportStats'](_0x298d5d);}['shouldReconnect_'](){const _0x1f6640=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x1f6640;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2e9e8c,_0x2f2ad2){this['name']=_0x2e9e8c,this['node']=_0x2f2ad2;}static['Wrap'](_0x368ce6,_0x5e22f8){return new E(_0x368ce6,_0x5e22f8);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x193e2f,_0x59d61f){const _0x40e4dc=new E(We,_0x193e2f),_0x4e4022=new E(We,_0x59d61f);return this['compare'](_0x40e4dc,_0x4e4022)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x50925b){sn=_0x50925b;}['compare'](_0xb2af29,_0x264fab){return qe(_0xb2af29['name'],_0x264fab['name']);}['isDefinedOn'](_0x5e4c8a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2a6b9a,_0x1b9fd5){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x34176f,_0x18c69a){return f(typeof _0x34176f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x34176f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3b5af5,_0x464120,_0x2fb5de,_0x5ccd3a,_0x27a048=null){this['isReverse_']=_0x5ccd3a,this['resultGenerator_']=_0x27a048,this['nodeStack_']=[];let _0x3cb96e=0x1;for(;!_0x3b5af5['isEmpty']();)if(_0x3b5af5=_0x3b5af5,_0x3cb96e=_0x464120?_0x2fb5de(_0x3b5af5['key'],_0x464120):0x1,_0x5ccd3a&&(_0x3cb96e*=-0x1),_0x3cb96e<0x0)this['isReverse_']?_0x3b5af5=_0x3b5af5['left']:_0x3b5af5=_0x3b5af5['right'];else{if(_0x3cb96e===0x0){this['nodeStack_']['push'](_0x3b5af5);break;}else this['nodeStack_']['push'](_0x3b5af5),this['isReverse_']?_0x3b5af5=_0x3b5af5['right']:_0x3b5af5=_0x3b5af5['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x29eca4=this['nodeStack_']['pop'](),_0x1229eb;if(this['resultGenerator_']?_0x1229eb=this['resultGenerator_'](_0x29eca4['key'],_0x29eca4['value']):_0x1229eb={'key':_0x29eca4['key'],'value':_0x29eca4['value']},this['isReverse_']){for(_0x29eca4=_0x29eca4['left'];!_0x29eca4['isEmpty']();)this['nodeStack_']['push'](_0x29eca4),_0x29eca4=_0x29eca4['right'];}else{for(_0x29eca4=_0x29eca4['right'];!_0x29eca4['isEmpty']();)this['nodeStack_']['push'](_0x29eca4),_0x29eca4=_0x29eca4['left'];}return _0x1229eb;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x147f16=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x147f16['key'],_0x147f16['value']):{'key':_0x147f16['key'],'value':_0x147f16['value']};}}class M{constructor(_0x2cf817,_0x34d00d,_0x4fb6ed,_0x54e28e,_0x1f31c5){this['key']=_0x2cf817,this['value']=_0x34d00d,this['color']=_0x4fb6ed??M['RED'],this['left']=_0x54e28e??B['EMPTY_NODE'],this['right']=_0x1f31c5??B['EMPTY_NODE'];}['copy'](_0x1de3d3,_0x2109df,_0x4c19c7,_0x109ba6,_0x298c17){return new M(_0x1de3d3??this['key'],_0x2109df??this['value'],_0x4c19c7??this['color'],_0x109ba6??this['left'],_0x298c17??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x19443a){return this['left']['inorderTraversal'](_0x19443a)||!!_0x19443a(this['key'],this['value'])||this['right']['inorderTraversal'](_0x19443a);}['reverseTraversal'](_0x10748f){return this['right']['reverseTraversal'](_0x10748f)||_0x10748f(this['key'],this['value'])||this['left']['reverseTraversal'](_0x10748f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1f7186,_0x59dee5,_0x3f2265){let _0x1682ce=this;const _0x5023d6=_0x3f2265(_0x1f7186,_0x1682ce['key']);return _0x5023d6<0x0?_0x1682ce=_0x1682ce['copy'](null,null,null,_0x1682ce['left']['insert'](_0x1f7186,_0x59dee5,_0x3f2265),null):_0x5023d6===0x0?_0x1682ce=_0x1682ce['copy'](null,_0x59dee5,null,null,null):_0x1682ce=_0x1682ce['copy'](null,null,null,null,_0x1682ce['right']['insert'](_0x1f7186,_0x59dee5,_0x3f2265)),_0x1682ce['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3bb151=this;return!_0x3bb151['left']['isRed_']()&&!_0x3bb151['left']['left']['isRed_']()&&(_0x3bb151=_0x3bb151['moveRedLeft_']()),_0x3bb151=_0x3bb151['copy'](null,null,null,_0x3bb151['left']['removeMin_'](),null),_0x3bb151['fixUp_']();}['remove'](_0x521625,_0x35a92a){let _0x5056b2,_0x19892f;if(_0x5056b2=this,_0x35a92a(_0x521625,_0x5056b2['key'])<0x0)!_0x5056b2['left']['isEmpty']()&&!_0x5056b2['left']['isRed_']()&&!_0x5056b2['left']['left']['isRed_']()&&(_0x5056b2=_0x5056b2['moveRedLeft_']()),_0x5056b2=_0x5056b2['copy'](null,null,null,_0x5056b2['left']['remove'](_0x521625,_0x35a92a),null);else{if(_0x5056b2['left']['isRed_']()&&(_0x5056b2=_0x5056b2['rotateRight_']()),!_0x5056b2['right']['isEmpty']()&&!_0x5056b2['right']['isRed_']()&&!_0x5056b2['right']['left']['isRed_']()&&(_0x5056b2=_0x5056b2['moveRedRight_']()),_0x35a92a(_0x521625,_0x5056b2['key'])===0x0){if(_0x5056b2['right']['isEmpty']())return B['EMPTY_NODE'];_0x19892f=_0x5056b2['right']['min_'](),_0x5056b2=_0x5056b2['copy'](_0x19892f['key'],_0x19892f['value'],null,null,_0x5056b2['right']['removeMin_']());}_0x5056b2=_0x5056b2['copy'](null,null,null,null,_0x5056b2['right']['remove'](_0x521625,_0x35a92a));}return _0x5056b2['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x56e715=this;return _0x56e715['right']['isRed_']()&&!_0x56e715['left']['isRed_']()&&(_0x56e715=_0x56e715['rotateLeft_']()),_0x56e715['left']['isRed_']()&&_0x56e715['left']['left']['isRed_']()&&(_0x56e715=_0x56e715['rotateRight_']()),_0x56e715['left']['isRed_']()&&_0x56e715['right']['isRed_']()&&(_0x56e715=_0x56e715['colorFlip_']()),_0x56e715;}['moveRedLeft_'](){let _0x510639=this['colorFlip_']();return _0x510639['right']['left']['isRed_']()&&(_0x510639=_0x510639['copy'](null,null,null,null,_0x510639['right']['rotateRight_']()),_0x510639=_0x510639['rotateLeft_'](),_0x510639=_0x510639['colorFlip_']()),_0x510639;}['moveRedRight_'](){let _0x1857f5=this['colorFlip_']();return _0x1857f5['left']['left']['isRed_']()&&(_0x1857f5=_0x1857f5['rotateRight_'](),_0x1857f5=_0x1857f5['colorFlip_']()),_0x1857f5;}['rotateLeft_'](){const _0x55d9ae=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x55d9ae,null);}['rotateRight_'](){const _0x5dc176=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5dc176);}['colorFlip_'](){const _0x42292c=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4ba915=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x42292c,_0x4ba915);}['checkMaxDepth_'](){const _0x187c82=this['check_']();return Math['pow'](0x2,_0x187c82)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2d74fc=this['left']['check_']();if(_0x2d74fc!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2d74fc+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x394a27,_0x208726,_0x24ed93,_0x31aacf,_0x470ad6){return this;}['insert'](_0x306db5,_0x13c3b7,_0x31fd49){return new M(_0x306db5,_0x13c3b7,null);}['remove'](_0x3555f0,_0x12978e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x40e5c9){return!0x1;}['reverseTraversal'](_0x12a577){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x2585f0,_0xcf9101=B['EMPTY_NODE']){this['comparator_']=_0x2585f0,this['root_']=_0xcf9101;}['insert'](_0x295d00,_0x4dd2a0){return new B(this['comparator_'],this['root_']['insert'](_0x295d00,_0x4dd2a0,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1bef82){return new B(this['comparator_'],this['root_']['remove'](_0x1bef82,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1cdfd4){let _0x2422ee,_0x1dbe4e=this['root_'];for(;!_0x1dbe4e['isEmpty']();){if(_0x2422ee=this['comparator_'](_0x1cdfd4,_0x1dbe4e['key']),_0x2422ee===0x0)return _0x1dbe4e['value'];_0x2422ee<0x0?_0x1dbe4e=_0x1dbe4e['left']:_0x2422ee>0x0&&(_0x1dbe4e=_0x1dbe4e['right']);}return null;}['getPredecessorKey'](_0x270ef4){let _0x5bb4dd,_0x2bd5c3=this['root_'],_0x3781d7=null;for(;!_0x2bd5c3['isEmpty']();)if(_0x5bb4dd=this['comparator_'](_0x270ef4,_0x2bd5c3['key']),_0x5bb4dd===0x0){if(_0x2bd5c3['left']['isEmpty']())return _0x3781d7?_0x3781d7['key']:null;for(_0x2bd5c3=_0x2bd5c3['left'];!_0x2bd5c3['right']['isEmpty']();)_0x2bd5c3=_0x2bd5c3['right'];return _0x2bd5c3['key'];}else _0x5bb4dd<0x0?_0x2bd5c3=_0x2bd5c3['left']:_0x5bb4dd>0x0&&(_0x3781d7=_0x2bd5c3,_0x2bd5c3=_0x2bd5c3['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0xbe9b8a){return this['root_']['inorderTraversal'](_0xbe9b8a);}['reverseTraversal'](_0x7ef8d2){return this['root_']['reverseTraversal'](_0x7ef8d2);}['getIterator'](_0x2069e8){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2069e8);}['getIteratorFrom'](_0x1379da,_0x34dc90){return new rn(this['root_'],_0x1379da,this['comparator_'],!0x1,_0x34dc90);}['getReverseIteratorFrom'](_0x4a8112,_0xffca94){return new rn(this['root_'],_0x4a8112,this['comparator_'],!0x0,_0xffca94);}['getReverseIterator'](_0x1a5d90){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1a5d90);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x46d1c2,_0x42ec41){return qe(_0x46d1c2['name'],_0x42ec41['name']);}function Qi(_0x17e6d4,_0x3e99b2){return qe(_0x17e6d4,_0x3e99b2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2d6bb6){Ci=_0x2d6bb6;}const Po=function(_0x3c3b4a){return typeof _0x3c3b4a=='number'?'number:'+ao(_0x3c3b4a):'string:'+_0x3c3b4a;},No=function(_0x14bdcd){if(_0x14bdcd['isLeafNode']()){const _0x53c730=_0x14bdcd['val']();f(typeof _0x53c730=='string'||typeof _0x53c730=='number'||typeof _0x53c730=='object'&&Q(_0x53c730,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x14bdcd===Ci||_0x14bdcd['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x14bdcd===Ci||_0x14bdcd['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x3a7a40){nr=_0x3a7a40;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x13fe31,_0x265b6d=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x13fe31,this['priorityNode_']=_0x265b6d,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x35fdc3){return new D(this['value_'],_0x35fdc3);}['getImmediateChild'](_0xca9449){return _0xca9449==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x49374e){return v(_0x49374e)?this:y(_0x49374e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5c03cd,_0x40ea00){return null;}['updateImmediateChild'](_0x307018,_0x39b7ba){return _0x307018==='.priority'?this['updatePriority'](_0x39b7ba):_0x39b7ba['isEmpty']()&&_0x307018!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x307018,_0x39b7ba)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x93048,_0x24d613){const _0x101a4d=y(_0x93048);return _0x101a4d===null?_0x24d613:_0x24d613['isEmpty']()&&_0x101a4d!=='.priority'?this:(f(_0x101a4d!=='.priority'||Ce(_0x93048)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x101a4d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x93048),_0x24d613)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0xd617cb,_0x57cd64){return!0x1;}['val'](_0x23740f){return _0x23740f&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5a75cf='';this['priorityNode_']['isEmpty']()||(_0x5a75cf+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x4326bb=typeof this['value_'];_0x5a75cf+=_0x4326bb+':',_0x4326bb==='number'?_0x5a75cf+=ao(this['value_']):_0x5a75cf+=this['value_'],this['lazyHash_']=ro(_0x5a75cf);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0xcb84cf){return _0xcb84cf===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0xcb84cf instanceof D['__childrenNodeConstructor']?-0x1:(f(_0xcb84cf['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0xcb84cf));}['compareToLeafNode_'](_0x24cb55){const _0x2f9525=typeof _0x24cb55['value_'],_0x45d4d3=typeof this['value_'],_0x1ee4eb=D['VALUE_TYPE_ORDER']['indexOf'](_0x2f9525),_0x4480bc=D['VALUE_TYPE_ORDER']['indexOf'](_0x45d4d3);return f(_0x1ee4eb>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2f9525),f(_0x4480bc>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x45d4d3),_0x1ee4eb===_0x4480bc?_0x45d4d3==='object'?0x0:this['value_']<_0x24cb55['value_']?-0x1:this['value_']===_0x24cb55['value_']?0x0:0x1:_0x4480bc-_0x1ee4eb;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x150b1e){if(_0x150b1e===this)return!0x0;if(_0x150b1e['isLeafNode']()){const _0x289d8f=_0x150b1e;return this['value_']===_0x289d8f['value_']&&this['priorityNode_']['equals'](_0x289d8f['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3b17de){Oo=_0x3b17de;}function Wh(_0x572590){Do=_0x572590;}class Bh extends Fn{['compare'](_0x8cc945,_0x4ab3cd){const _0x4ac8a7=_0x8cc945['node']['getPriority'](),_0x117c6b=_0x4ab3cd['node']['getPriority'](),_0x103460=_0x4ac8a7['compareTo'](_0x117c6b);return _0x103460===0x0?qe(_0x8cc945['name'],_0x4ab3cd['name']):_0x103460;}['isDefinedOn'](_0x2c7a35){return!_0x2c7a35['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x1d0c78,_0x244e2e){return!_0x1d0c78['getPriority']()['equals'](_0x244e2e['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x137410,_0x271f57){const _0x213f58=Oo(_0x137410);return new E(_0x271f57,new D('[PRIORITY-POST]',_0x213f58));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x411a86){const _0x463a7f=_0x13c0ef=>parseInt(Math['log'](_0x13c0ef)/Vh,0xa),_0x36e185=_0x23186d=>parseInt(Array(_0x23186d+0x1)['join']('1'),0x2);this['count']=_0x463a7f(_0x411a86+0x1),this['current_']=this['count']-0x1;const _0x477d22=_0x36e185(this['count']);this['bits_']=_0x411a86+0x1&_0x477d22;}['nextBitIsOne'](){const _0x18f6a9=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x18f6a9;}}const yn=function(_0x34c5b6,_0x3fa3e2,_0x3ab7fa,_0x154d96){_0x34c5b6['sort'](_0x3fa3e2);const _0x32ddb0=function(_0x2fc311,_0x54d0b7){const _0x5bd7d4=_0x54d0b7-_0x2fc311;let _0x3d7d86,_0x2852db;if(_0x5bd7d4===0x0)return null;if(_0x5bd7d4===0x1)return _0x3d7d86=_0x34c5b6[_0x2fc311],_0x2852db=_0x3ab7fa?_0x3ab7fa(_0x3d7d86):_0x3d7d86,new M(_0x2852db,_0x3d7d86['node'],M['BLACK'],null,null);{const _0x3b64cf=parseInt(_0x5bd7d4/0x2,0xa)+_0x2fc311,_0x3f3afa=_0x32ddb0(_0x2fc311,_0x3b64cf),_0x2ace46=_0x32ddb0(_0x3b64cf+0x1,_0x54d0b7);return _0x3d7d86=_0x34c5b6[_0x3b64cf],_0x2852db=_0x3ab7fa?_0x3ab7fa(_0x3d7d86):_0x3d7d86,new M(_0x2852db,_0x3d7d86['node'],M['BLACK'],_0x3f3afa,_0x2ace46);}},_0x4829f1=function(_0x1105c8){let _0x494709=null,_0xec7afb=null,_0x7f1b68=_0x34c5b6['length'];const _0x3cbb3e=function(_0x32e68f,_0x4afcb3){const _0x1c626f=_0x7f1b68-_0x32e68f,_0x4b84c1=_0x7f1b68;_0x7f1b68-=_0x32e68f;const _0xb820c0=_0x32ddb0(_0x1c626f+0x1,_0x4b84c1),_0x1bc54e=_0x34c5b6[_0x1c626f],_0x1534fc=_0x3ab7fa?_0x3ab7fa(_0x1bc54e):_0x1bc54e;_0x29cf89(new M(_0x1534fc,_0x1bc54e['node'],_0x4afcb3,null,_0xb820c0));},_0x29cf89=function(_0x59a53e){_0x494709?(_0x494709['left']=_0x59a53e,_0x494709=_0x59a53e):(_0xec7afb=_0x59a53e,_0x494709=_0x59a53e);};for(let _0x1ca34b=0x0;_0x1ca34b<_0x1105c8['count'];++_0x1ca34b){const _0x1abe68=_0x1105c8['nextBitIsOne'](),_0x2bd3dd=Math['pow'](0x2,_0x1105c8['count']-(_0x1ca34b+0x1));_0x1abe68?_0x3cbb3e(_0x2bd3dd,M['BLACK']):(_0x3cbb3e(_0x2bd3dd,M['BLACK']),_0x3cbb3e(_0x2bd3dd,M['RED']));}return _0xec7afb;},_0x604585=new Hh(_0x34c5b6['length']),_0xed9d38=_0x4829f1(_0x604585);return new B(_0x154d96||_0x3fa3e2,_0xed9d38);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x551bb6,_0x31494e){this['indexes_']=_0x551bb6,this['indexSet_']=_0x31494e;}['get'](_0x1537cf){const _0x5e32be=Le(this['indexes_'],_0x1537cf);if(!_0x5e32be)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1537cf);return _0x5e32be instanceof B?_0x5e32be:null;}['hasIndex'](_0x3b416e){return Q(this['indexSet_'],_0x3b416e['toString']());}['addIndex'](_0x1b9cbe,_0x3479c5){f(_0x1b9cbe!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3b1f90=[];let _0x4890f5=!0x1;const _0x32f6d0=_0x3479c5['getIterator'](E['Wrap']);let _0x1e8b08=_0x32f6d0['getNext']();for(;_0x1e8b08;)_0x4890f5=_0x4890f5||_0x1b9cbe['isDefinedOn'](_0x1e8b08['node']),_0x3b1f90['push'](_0x1e8b08),_0x1e8b08=_0x32f6d0['getNext']();let _0x1c0b62;_0x4890f5?_0x1c0b62=yn(_0x3b1f90,_0x1b9cbe['getCompare']()):_0x1c0b62=Qe;const _0x316102=_0x1b9cbe['toString'](),_0x1aa760={...this['indexSet_']};_0x1aa760[_0x316102]=_0x1b9cbe;const _0x58f002={...this['indexes_']};return _0x58f002[_0x316102]=_0x1c0b62,new te(_0x58f002,_0x1aa760);}['addToIndexes'](_0x25bf24,_0x45e3c2){const _0x9bb81f=_n(this['indexes_'],(_0x4740fa,_0x5ab60e)=>{const _0x1ad2ff=Le(this['indexSet_'],_0x5ab60e);if(f(_0x1ad2ff,'Missing\x20index\x20implementation\x20for\x20'+_0x5ab60e),_0x4740fa===Qe){if(_0x1ad2ff['isDefinedOn'](_0x25bf24['node'])){const _0x51d607=[],_0x399cdd=_0x45e3c2['getIterator'](E['Wrap']);let _0x303550=_0x399cdd['getNext']();for(;_0x303550;)_0x303550['name']!==_0x25bf24['name']&&_0x51d607['push'](_0x303550),_0x303550=_0x399cdd['getNext']();return _0x51d607['push'](_0x25bf24),yn(_0x51d607,_0x1ad2ff['getCompare']());}else return Qe;}else{const _0x2b9650=_0x45e3c2['get'](_0x25bf24['name']);let _0x3efdc2=_0x4740fa;return _0x2b9650&&(_0x3efdc2=_0x3efdc2['remove'](new E(_0x25bf24['name'],_0x2b9650))),_0x3efdc2['insert'](_0x25bf24,_0x25bf24['node']);}});return new te(_0x9bb81f,this['indexSet_']);}['removeFromIndexes'](_0x245272,_0x1b6df2){const _0x43822f=_n(this['indexes_'],_0x17c583=>{if(_0x17c583===Qe)return _0x17c583;{const _0x27abb0=_0x1b6df2['get'](_0x245272['name']);return _0x27abb0?_0x17c583['remove'](new E(_0x245272['name'],_0x27abb0)):_0x17c583;}});return new te(_0x43822f,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x2ee079,_0x142a64,_0x12c69f){this['children_']=_0x2ee079,this['priorityNode_']=_0x142a64,this['indexMap_']=_0x12c69f,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x2d3d0c){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x2d3d0c,this['indexMap_']);}['getImmediateChild'](_0x2b4f93){if(_0x2b4f93==='.priority')return this['getPriority']();{const _0x22df3c=this['children_']['get'](_0x2b4f93);return _0x22df3c===null?It:_0x22df3c;}}['getChild'](_0x39d9ef){const _0x3287e0=y(_0x39d9ef);return _0x3287e0===null?this:this['getImmediateChild'](_0x3287e0)['getChild'](S(_0x39d9ef));}['hasChild'](_0x42eaa2){return this['children_']['get'](_0x42eaa2)!==null;}['updateImmediateChild'](_0x3d4768,_0x23d8e5){if(f(_0x23d8e5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x3d4768==='.priority')return this['updatePriority'](_0x23d8e5);{const _0x5cc55b=new E(_0x3d4768,_0x23d8e5);let _0x2ad28c,_0x526927;_0x23d8e5['isEmpty']()?(_0x2ad28c=this['children_']['remove'](_0x3d4768),_0x526927=this['indexMap_']['removeFromIndexes'](_0x5cc55b,this['children_'])):(_0x2ad28c=this['children_']['insert'](_0x3d4768,_0x23d8e5),_0x526927=this['indexMap_']['addToIndexes'](_0x5cc55b,this['children_']));const _0x393239=_0x2ad28c['isEmpty']()?It:this['priorityNode_'];return new g(_0x2ad28c,_0x393239,_0x526927);}}['updateChild'](_0x5695e8,_0x47eea7){const _0x130f80=y(_0x5695e8);if(_0x130f80===null)return _0x47eea7;{f(y(_0x5695e8)!=='.priority'||Ce(_0x5695e8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x235e9c=this['getImmediateChild'](_0x130f80)['updateChild'](S(_0x5695e8),_0x47eea7);return this['updateImmediateChild'](_0x130f80,_0x235e9c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2f4385){if(this['isEmpty']())return null;const _0x4fb625={};let _0x3c7ad7=0x0,_0x1db1ca=0x0,_0x16f54e=!0x0;if(this['forEachChild'](R,(_0x5e9379,_0x58cb3c)=>{_0x4fb625[_0x5e9379]=_0x58cb3c['val'](_0x2f4385),_0x3c7ad7++,_0x16f54e&&g['INTEGER_REGEXP_']['test'](_0x5e9379)?_0x1db1ca=Math['max'](_0x1db1ca,Number(_0x5e9379)):_0x16f54e=!0x1;}),!_0x2f4385&&_0x16f54e&&_0x1db1ca<0x2*_0x3c7ad7){const _0x4b8b0c=[];for(const _0x275989 in _0x4fb625)_0x4b8b0c[_0x275989]=_0x4fb625[_0x275989];return _0x4b8b0c;}else return _0x2f4385&&!this['getPriority']()['isEmpty']()&&(_0x4fb625['.priority']=this['getPriority']()['val']()),_0x4fb625;}['hash'](){if(this['lazyHash_']===null){let _0x25dd0c='';this['getPriority']()['isEmpty']()||(_0x25dd0c+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x470df6,_0x334833)=>{const _0x48afd7=_0x334833['hash']();_0x48afd7!==''&&(_0x25dd0c+=':'+_0x470df6+':'+_0x48afd7);}),this['lazyHash_']=_0x25dd0c===''?'':ro(_0x25dd0c);}return this['lazyHash_'];}['getPredecessorChildName'](_0x59058f,_0x405061,_0xe1090f){const _0x3e95a7=this['resolveIndex_'](_0xe1090f);if(_0x3e95a7){const _0x4b7854=_0x3e95a7['getPredecessorKey'](new E(_0x59058f,_0x405061));return _0x4b7854?_0x4b7854['name']:null;}else return this['children_']['getPredecessorKey'](_0x59058f);}['getFirstChildName'](_0x2877ed){const _0x5b2bd0=this['resolveIndex_'](_0x2877ed);if(_0x5b2bd0){const _0xfa1a8d=_0x5b2bd0['minKey']();return _0xfa1a8d&&_0xfa1a8d['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3c3f4f){const _0x2824c4=this['getFirstChildName'](_0x3c3f4f);return _0x2824c4?new E(_0x2824c4,this['children_']['get'](_0x2824c4)):null;}['getLastChildName'](_0x4cab24){const _0x4cdcc4=this['resolveIndex_'](_0x4cab24);if(_0x4cdcc4){const _0x16b108=_0x4cdcc4['maxKey']();return _0x16b108&&_0x16b108['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2b2834){const _0x45bf30=this['getLastChildName'](_0x2b2834);return _0x45bf30?new E(_0x45bf30,this['children_']['get'](_0x45bf30)):null;}['forEachChild'](_0x60cebf,_0x10df94){const _0x35335a=this['resolveIndex_'](_0x60cebf);return _0x35335a?_0x35335a['inorderTraversal'](_0x43e84c=>_0x10df94(_0x43e84c['name'],_0x43e84c['node'])):this['children_']['inorderTraversal'](_0x10df94);}['getIterator'](_0x5a725b){return this['getIteratorFrom'](_0x5a725b['minPost'](),_0x5a725b);}['getIteratorFrom'](_0xe9605d,_0x716175){const _0x1144a0=this['resolveIndex_'](_0x716175);if(_0x1144a0)return _0x1144a0['getIteratorFrom'](_0xe9605d,_0x3cf873=>_0x3cf873);{const _0x5c5abe=this['children_']['getIteratorFrom'](_0xe9605d['name'],E['Wrap']);let _0x2951ea=_0x5c5abe['peek']();for(;_0x2951ea!=null&&_0x716175['compare'](_0x2951ea,_0xe9605d)<0x0;)_0x5c5abe['getNext'](),_0x2951ea=_0x5c5abe['peek']();return _0x5c5abe;}}['getReverseIterator'](_0x4e1e0b){return this['getReverseIteratorFrom'](_0x4e1e0b['maxPost'](),_0x4e1e0b);}['getReverseIteratorFrom'](_0x3ad7af,_0xab20fb){const _0x2df256=this['resolveIndex_'](_0xab20fb);if(_0x2df256)return _0x2df256['getReverseIteratorFrom'](_0x3ad7af,_0x479dd2=>_0x479dd2);{const _0x371a18=this['children_']['getReverseIteratorFrom'](_0x3ad7af['name'],E['Wrap']);let _0x83e879=_0x371a18['peek']();for(;_0x83e879!=null&&_0xab20fb['compare'](_0x83e879,_0x3ad7af)>0x0;)_0x371a18['getNext'](),_0x83e879=_0x371a18['peek']();return _0x371a18;}}['compareTo'](_0x53e0cf){return this['isEmpty']()?_0x53e0cf['isEmpty']()?0x0:-0x1:_0x53e0cf['isLeafNode']()||_0x53e0cf['isEmpty']()?0x1:_0x53e0cf===Kt?-0x1:0x0;}['withIndex'](_0x54309e){if(_0x54309e===ve||this['indexMap_']['hasIndex'](_0x54309e))return this;{const _0x2f8569=this['indexMap_']['addIndex'](_0x54309e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2f8569);}}['isIndexed'](_0x16d46c){return _0x16d46c===ve||this['indexMap_']['hasIndex'](_0x16d46c);}['equals'](_0x11c9f){if(_0x11c9f===this)return!0x0;if(_0x11c9f['isLeafNode']())return!0x1;{const _0x498a30=_0x11c9f;if(this['getPriority']()['equals'](_0x498a30['getPriority']())){if(this['children_']['count']()===_0x498a30['children_']['count']()){const _0x2b031a=this['getIterator'](R),_0x54ee40=_0x498a30['getIterator'](R);let _0x253d54=_0x2b031a['getNext'](),_0x23a042=_0x54ee40['getNext']();for(;_0x253d54&&_0x23a042;){if(_0x253d54['name']!==_0x23a042['name']||!_0x253d54['node']['equals'](_0x23a042['node']))return!0x1;_0x253d54=_0x2b031a['getNext'](),_0x23a042=_0x54ee40['getNext']();}return _0x253d54===null&&_0x23a042===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0xe22ba9){return _0xe22ba9===ve?null:this['indexMap_']['get'](_0xe22ba9['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x4d59fc){return _0x4d59fc===this?0x0:0x1;}['equals'](_0x33c7a3){return _0x33c7a3===this;}['getPriority'](){return this;}['getImmediateChild'](_0xeefa66){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x426f4f,_0xa8cb2f=null){if(_0x426f4f===null)return g['EMPTY_NODE'];if(typeof _0x426f4f=='object'&&'.priority'in _0x426f4f&&(_0xa8cb2f=_0x426f4f['.priority']),f(_0xa8cb2f===null||typeof _0xa8cb2f=='string'||typeof _0xa8cb2f=='number'||typeof _0xa8cb2f=='object'&&'.sv'in _0xa8cb2f,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0xa8cb2f),typeof _0x426f4f=='object'&&'.value'in _0x426f4f&&_0x426f4f['.value']!==null&&(_0x426f4f=_0x426f4f['.value']),typeof _0x426f4f!='object'||'.sv'in _0x426f4f){const _0x2d0a16=_0x426f4f;return new D(_0x2d0a16,A(_0xa8cb2f));}if(!(_0x426f4f instanceof Array)&&Gh){const _0x396adf=[];let _0x34cc7a=!0x1;if(x(_0x426f4f,(_0x3c26be,_0x290dcc)=>{if(_0x3c26be['substring'](0x0,0x1)!=='.'){const _0x28d301=A(_0x290dcc);_0x28d301['isEmpty']()||(_0x34cc7a=_0x34cc7a||!_0x28d301['getPriority']()['isEmpty'](),_0x396adf['push'](new E(_0x3c26be,_0x28d301)));}}),_0x396adf['length']===0x0)return g['EMPTY_NODE'];const _0x11b663=yn(_0x396adf,xh,_0x46e433=>_0x46e433['name'],Qi);if(_0x34cc7a){const _0x4b2fed=yn(_0x396adf,R['getCompare']());return new g(_0x11b663,A(_0xa8cb2f),new te({'.priority':_0x4b2fed},{'.priority':R}));}else return new g(_0x11b663,A(_0xa8cb2f),te['Default']);}else{let _0xc45d1c=g['EMPTY_NODE'];return x(_0x426f4f,(_0x89d3c5,_0x362bc1)=>{if(Q(_0x426f4f,_0x89d3c5)&&_0x89d3c5['substring'](0x0,0x1)!=='.'){const _0x50921a=A(_0x362bc1);(_0x50921a['isLeafNode']()||!_0x50921a['isEmpty']())&&(_0xc45d1c=_0xc45d1c['updateImmediateChild'](_0x89d3c5,_0x50921a));}}),_0xc45d1c['updatePriority'](A(_0xa8cb2f));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x3e7a50){super(),this['indexPath_']=_0x3e7a50,f(!v(_0x3e7a50)&&y(_0x3e7a50)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x674756){return _0x674756['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4e5b78){return!_0x4e5b78['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5e0b2f,_0x387230){const _0x89d6c1=this['extractChild'](_0x5e0b2f['node']),_0xe35cda=this['extractChild'](_0x387230['node']),_0x58f4f8=_0x89d6c1['compareTo'](_0xe35cda);return _0x58f4f8===0x0?qe(_0x5e0b2f['name'],_0x387230['name']):_0x58f4f8;}['makePost'](_0x256578,_0x395edf){const _0x2f6248=A(_0x256578),_0x4a9915=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2f6248);return new E(_0x395edf,_0x4a9915);}['maxPost'](){const _0x4457ab=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4457ab);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x4f33d2,_0x4f32be){const _0x23c527=_0x4f33d2['node']['compareTo'](_0x4f32be['node']);return _0x23c527===0x0?qe(_0x4f33d2['name'],_0x4f32be['name']):_0x23c527;}['isDefinedOn'](_0x392911){return!0x0;}['indexedValueChanged'](_0x322767,_0x26eef6){return!_0x322767['equals'](_0x26eef6);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1f3d44,_0x3eb9f4){const _0x27cb93=A(_0x1f3d44);return new E(_0x3eb9f4,_0x27cb93);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x3d9e28){return{'type':'value','snapshotNode':_0x3d9e28};}function rt(_0x48dfed,_0x5d1fec){return{'type':'child_added','snapshotNode':_0x5d1fec,'childName':_0x48dfed};}function Lt(_0x3ca73a,_0x2db212){return{'type':'child_removed','snapshotNode':_0x2db212,'childName':_0x3ca73a};}function xt(_0x37cd9e,_0x55b633,_0x43225b){return{'type':'child_changed','snapshotNode':_0x55b633,'childName':_0x37cd9e,'oldSnap':_0x43225b};}function zh(_0x8b939b,_0x39a84d){return{'type':'child_moved','snapshotNode':_0x39a84d,'childName':_0x8b939b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x39c909){this['index_']=_0x39c909;}['updateChild'](_0xc03c69,_0x449496,_0x33b7f9,_0x575933,_0x4d0178,_0x509909){f(_0xc03c69['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x14c917=_0xc03c69['getImmediateChild'](_0x449496);return _0x14c917['getChild'](_0x575933)['equals'](_0x33b7f9['getChild'](_0x575933))&&_0x14c917['isEmpty']()===_0x33b7f9['isEmpty']()||(_0x509909!=null&&(_0x33b7f9['isEmpty']()?_0xc03c69['hasChild'](_0x449496)?_0x509909['trackChildChange'](Lt(_0x449496,_0x14c917)):f(_0xc03c69['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x14c917['isEmpty']()?_0x509909['trackChildChange'](rt(_0x449496,_0x33b7f9)):_0x509909['trackChildChange'](xt(_0x449496,_0x33b7f9,_0x14c917))),_0xc03c69['isLeafNode']()&&_0x33b7f9['isEmpty']())?_0xc03c69:_0xc03c69['updateImmediateChild'](_0x449496,_0x33b7f9)['withIndex'](this['index_']);}['updateFullNode'](_0xd26d03,_0x9a82f,_0x500662){return _0x500662!=null&&(_0xd26d03['isLeafNode']()||_0xd26d03['forEachChild'](R,(_0xc5ef04,_0x10312a)=>{_0x9a82f['hasChild'](_0xc5ef04)||_0x500662['trackChildChange'](Lt(_0xc5ef04,_0x10312a));}),_0x9a82f['isLeafNode']()||_0x9a82f['forEachChild'](R,(_0x3536d4,_0x129c18)=>{if(_0xd26d03['hasChild'](_0x3536d4)){const _0x25038a=_0xd26d03['getImmediateChild'](_0x3536d4);_0x25038a['equals'](_0x129c18)||_0x500662['trackChildChange'](xt(_0x3536d4,_0x129c18,_0x25038a));}else _0x500662['trackChildChange'](rt(_0x3536d4,_0x129c18));})),_0x9a82f['withIndex'](this['index_']);}['updatePriority'](_0x3ef05b,_0xdb7498){return _0x3ef05b['isEmpty']()?g['EMPTY_NODE']:_0x3ef05b['updatePriority'](_0xdb7498);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x52e086){this['indexedFilter_']=new Xi(_0x52e086['getIndex']()),this['index_']=_0x52e086['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x52e086),this['endPost_']=Ft['getEndPost_'](_0x52e086),this['startIsInclusive_']=!_0x52e086['startAfterSet_'],this['endIsInclusive_']=!_0x52e086['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1ac0cd){const _0x32223a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1ac0cd)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1ac0cd)<0x0,_0x1c1405=this['endIsInclusive_']?this['index_']['compare'](_0x1ac0cd,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1ac0cd,this['getEndPost']())<0x0;return _0x32223a&&_0x1c1405;}['updateChild'](_0x8377b6,_0x384af4,_0x1e47ba,_0x49aeb2,_0x3bcef6,_0x1ee808){return this['matches'](new E(_0x384af4,_0x1e47ba))||(_0x1e47ba=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x8377b6,_0x384af4,_0x1e47ba,_0x49aeb2,_0x3bcef6,_0x1ee808);}['updateFullNode'](_0x112b8d,_0x207951,_0x23f8f8){_0x207951['isLeafNode']()&&(_0x207951=g['EMPTY_NODE']);let _0x8661e8=_0x207951['withIndex'](this['index_']);_0x8661e8=_0x8661e8['updatePriority'](g['EMPTY_NODE']);const _0xb3ecaa=this;return _0x207951['forEachChild'](R,(_0x4da59c,_0x132b28)=>{_0xb3ecaa['matches'](new E(_0x4da59c,_0x132b28))||(_0x8661e8=_0x8661e8['updateImmediateChild'](_0x4da59c,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x112b8d,_0x8661e8,_0x23f8f8);}['updatePriority'](_0x424270,_0x38553e){return _0x424270;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x526985){if(_0x526985['hasStart']()){const _0x18d873=_0x526985['getIndexStartName']();return _0x526985['getIndex']()['makePost'](_0x526985['getIndexStartValue'](),_0x18d873);}else return _0x526985['getIndex']()['minPost']();}static['getEndPost_'](_0x3d945d){if(_0x3d945d['hasEnd']()){const _0x1b60aa=_0x3d945d['getIndexEndName']();return _0x3d945d['getIndex']()['makePost'](_0x3d945d['getIndexEndValue'](),_0x1b60aa);}else return _0x3d945d['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2975a8){this['withinDirectionalStart']=_0x103b18=>this['reverse_']?this['withinEndPost'](_0x103b18):this['withinStartPost'](_0x103b18),this['withinDirectionalEnd']=_0x4c006f=>this['reverse_']?this['withinStartPost'](_0x4c006f):this['withinEndPost'](_0x4c006f),this['withinStartPost']=_0x4164b8=>{const _0x411ebc=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4164b8);return this['startIsInclusive_']?_0x411ebc<=0x0:_0x411ebc<0x0;},this['withinEndPost']=_0xa9c4c=>{const _0x2f7ea8=this['index_']['compare'](_0xa9c4c,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2f7ea8<=0x0:_0x2f7ea8<0x0;},this['rangedFilter_']=new Ft(_0x2975a8),this['index_']=_0x2975a8['getIndex'](),this['limit_']=_0x2975a8['getLimit'](),this['reverse_']=!_0x2975a8['isViewFromLeft'](),this['startIsInclusive_']=!_0x2975a8['startAfterSet_'],this['endIsInclusive_']=!_0x2975a8['endBeforeSet_'];}['updateChild'](_0xe53cf9,_0x15caf2,_0x3df767,_0x521c4c,_0x501af3,_0x5533fb){return this['rangedFilter_']['matches'](new E(_0x15caf2,_0x3df767))||(_0x3df767=g['EMPTY_NODE']),_0xe53cf9['getImmediateChild'](_0x15caf2)['equals'](_0x3df767)?_0xe53cf9:_0xe53cf9['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xe53cf9,_0x15caf2,_0x3df767,_0x521c4c,_0x501af3,_0x5533fb):this['fullLimitUpdateChild_'](_0xe53cf9,_0x15caf2,_0x3df767,_0x501af3,_0x5533fb);}['updateFullNode'](_0x3c6284,_0x11a942,_0x5d54d4){let _0x426cd2;if(_0x11a942['isLeafNode']()||_0x11a942['isEmpty']())_0x426cd2=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x11a942['numChildren']()&&_0x11a942['isIndexed'](this['index_'])){_0x426cd2=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x357040;this['reverse_']?_0x357040=_0x11a942['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x357040=_0x11a942['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2c80c1=0x0;for(;_0x357040['hasNext']()&&_0x2c80c1<this['limit_'];){const _0x3d4281=_0x357040['getNext']();if(this['withinDirectionalStart'](_0x3d4281)){if(this['withinDirectionalEnd'](_0x3d4281))_0x426cd2=_0x426cd2['updateImmediateChild'](_0x3d4281['name'],_0x3d4281['node']),_0x2c80c1++;else break;}else continue;}}else{_0x426cd2=_0x11a942['withIndex'](this['index_']),_0x426cd2=_0x426cd2['updatePriority'](g['EMPTY_NODE']);let _0x40b80b;this['reverse_']?_0x40b80b=_0x426cd2['getReverseIterator'](this['index_']):_0x40b80b=_0x426cd2['getIterator'](this['index_']);let _0x44eb06=0x0;for(;_0x40b80b['hasNext']();){const _0x23c038=_0x40b80b['getNext']();_0x44eb06<this['limit_']&&this['withinDirectionalStart'](_0x23c038)&&this['withinDirectionalEnd'](_0x23c038)?_0x44eb06++:_0x426cd2=_0x426cd2['updateImmediateChild'](_0x23c038['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x3c6284,_0x426cd2,_0x5d54d4);}['updatePriority'](_0x2cce76,_0x2db6de){return _0x2cce76;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x521f53,_0x2848cf,_0x2e2582,_0x5e42c0,_0x57b218){let _0x17cf11;if(this['reverse_']){const _0x43a9e1=this['index_']['getCompare']();_0x17cf11=(_0x1dfb2a,_0x47999d)=>_0x43a9e1(_0x47999d,_0x1dfb2a);}else _0x17cf11=this['index_']['getCompare']();const _0x3210a7=_0x521f53;f(_0x3210a7['numChildren']()===this['limit_'],'');const _0x24b0cf=new E(_0x2848cf,_0x2e2582),_0x5ebe89=this['reverse_']?_0x3210a7['getFirstChild'](this['index_']):_0x3210a7['getLastChild'](this['index_']),_0x1ff2a5=this['rangedFilter_']['matches'](_0x24b0cf);if(_0x3210a7['hasChild'](_0x2848cf)){const _0x19fd0b=_0x3210a7['getImmediateChild'](_0x2848cf);let _0x2f4946=_0x5e42c0['getChildAfterChild'](this['index_'],_0x5ebe89,this['reverse_']);for(;_0x2f4946!=null&&(_0x2f4946['name']===_0x2848cf||_0x3210a7['hasChild'](_0x2f4946['name']));)_0x2f4946=_0x5e42c0['getChildAfterChild'](this['index_'],_0x2f4946,this['reverse_']);const _0x31ad7f=_0x2f4946==null?0x1:_0x17cf11(_0x2f4946,_0x24b0cf);if(_0x1ff2a5&&!_0x2e2582['isEmpty']()&&_0x31ad7f>=0x0)return _0x57b218!=null&&_0x57b218['trackChildChange'](xt(_0x2848cf,_0x2e2582,_0x19fd0b)),_0x3210a7['updateImmediateChild'](_0x2848cf,_0x2e2582);{_0x57b218!=null&&_0x57b218['trackChildChange'](Lt(_0x2848cf,_0x19fd0b));const _0x17a6ab=_0x3210a7['updateImmediateChild'](_0x2848cf,g['EMPTY_NODE']);return _0x2f4946!=null&&this['rangedFilter_']['matches'](_0x2f4946)?(_0x57b218!=null&&_0x57b218['trackChildChange'](rt(_0x2f4946['name'],_0x2f4946['node'])),_0x17a6ab['updateImmediateChild'](_0x2f4946['name'],_0x2f4946['node'])):_0x17a6ab;}}else return _0x2e2582['isEmpty']()?_0x521f53:_0x1ff2a5&&_0x17cf11(_0x5ebe89,_0x24b0cf)>=0x0?(_0x57b218!=null&&(_0x57b218['trackChildChange'](Lt(_0x5ebe89['name'],_0x5ebe89['node'])),_0x57b218['trackChildChange'](rt(_0x2848cf,_0x2e2582))),_0x3210a7['updateImmediateChild'](_0x2848cf,_0x2e2582)['updateImmediateChild'](_0x5ebe89['name'],g['EMPTY_NODE'])):_0x521f53;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5491fe=new Zi();return _0x5491fe['limitSet_']=this['limitSet_'],_0x5491fe['limit_']=this['limit_'],_0x5491fe['startSet_']=this['startSet_'],_0x5491fe['startAfterSet_']=this['startAfterSet_'],_0x5491fe['indexStartValue_']=this['indexStartValue_'],_0x5491fe['startNameSet_']=this['startNameSet_'],_0x5491fe['indexStartName_']=this['indexStartName_'],_0x5491fe['endSet_']=this['endSet_'],_0x5491fe['endBeforeSet_']=this['endBeforeSet_'],_0x5491fe['indexEndValue_']=this['indexEndValue_'],_0x5491fe['endNameSet_']=this['endNameSet_'],_0x5491fe['indexEndName_']=this['indexEndName_'],_0x5491fe['index_']=this['index_'],_0x5491fe['viewFrom_']=this['viewFrom_'],_0x5491fe;}}function Kh(_0xc13724){return _0xc13724['loadsAllData']()?new Xi(_0xc13724['getIndex']()):_0xc13724['hasLimit']()?new jh(_0xc13724):new Ft(_0xc13724);}function Yh(_0x4fb96d,_0x1386ed){const _0x5c31c4=_0x4fb96d['copy']();return _0x5c31c4['limitSet_']=!0x0,_0x5c31c4['limit_']=_0x1386ed,_0x5c31c4['viewFrom_']='l',_0x5c31c4;}function Qh(_0x50451f,_0x37fa51,_0x547dcc){const _0x56d0d9=_0x50451f['copy']();return _0x56d0d9['startSet_']=!0x0,_0x37fa51===void 0x0&&(_0x37fa51=null),_0x56d0d9['indexStartValue_']=_0x37fa51,_0x547dcc!=null?(_0x56d0d9['startNameSet_']=!0x0,_0x56d0d9['indexStartName_']=_0x547dcc):(_0x56d0d9['startNameSet_']=!0x1,_0x56d0d9['indexStartName_']=''),_0x56d0d9;}function Jh(_0x4544b8,_0x180588,_0x5744aa){const _0x5a5020=_0x4544b8['copy']();return _0x5a5020['endSet_']=!0x0,_0x180588===void 0x0&&(_0x180588=null),_0x5a5020['indexEndValue_']=_0x180588,_0x5744aa!==void 0x0?(_0x5a5020['endNameSet_']=!0x0,_0x5a5020['indexEndName_']=_0x5744aa):(_0x5a5020['endNameSet_']=!0x1,_0x5a5020['indexEndName_']=''),_0x5a5020;}function xo(_0x124f25,_0x3c9bf1){const _0x54f5f1=_0x124f25['copy']();return _0x54f5f1['index_']=_0x3c9bf1,_0x54f5f1;}function ir(_0x519bcc){const _0x58cd59={};if(_0x519bcc['isDefault']())return _0x58cd59;let _0x4bc611;if(_0x519bcc['index_']===R?_0x4bc611='$priority':_0x519bcc['index_']===Mo?_0x4bc611='$value':_0x519bcc['index_']===ve?_0x4bc611='$key':(f(_0x519bcc['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4bc611=_0x519bcc['index_']['toString']()),_0x58cd59['orderBy']=O(_0x4bc611),_0x519bcc['startSet_']){const _0x4e58cc=_0x519bcc['startAfterSet_']?'startAfter':'startAt';_0x58cd59[_0x4e58cc]=O(_0x519bcc['indexStartValue_']),_0x519bcc['startNameSet_']&&(_0x58cd59[_0x4e58cc]+=','+O(_0x519bcc['indexStartName_']));}if(_0x519bcc['endSet_']){const _0x1bd51f=_0x519bcc['endBeforeSet_']?'endBefore':'endAt';_0x58cd59[_0x1bd51f]=O(_0x519bcc['indexEndValue_']),_0x519bcc['endNameSet_']&&(_0x58cd59[_0x1bd51f]+=','+O(_0x519bcc['indexEndName_']));}return _0x519bcc['limitSet_']&&(_0x519bcc['isViewFromLeft']()?_0x58cd59['limitToFirst']=_0x519bcc['limit_']:_0x58cd59['limitToLast']=_0x519bcc['limit_']),_0x58cd59;}function sr(_0x264e77){const _0x34395e={};if(_0x264e77['startSet_']&&(_0x34395e['sp']=_0x264e77['indexStartValue_'],_0x264e77['startNameSet_']&&(_0x34395e['sn']=_0x264e77['indexStartName_']),_0x34395e['sin']=!_0x264e77['startAfterSet_']),_0x264e77['endSet_']&&(_0x34395e['ep']=_0x264e77['indexEndValue_'],_0x264e77['endNameSet_']&&(_0x34395e['en']=_0x264e77['indexEndName_']),_0x34395e['ein']=!_0x264e77['endBeforeSet_']),_0x264e77['limitSet_']){_0x34395e['l']=_0x264e77['limit_'];let _0x49f35d=_0x264e77['viewFrom_'];_0x49f35d===''&&(_0x264e77['isViewFromLeft']()?_0x49f35d='l':_0x49f35d='r'),_0x34395e['vf']=_0x49f35d;}return _0x264e77['index_']!==R&&(_0x34395e['i']=_0x264e77['index_']['toString']()),_0x34395e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x39892a){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x45b662,_0x3fc486){return _0x3fc486!==void 0x0?'tag$'+_0x3fc486:(f(_0x45b662['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x45b662['_path']['toString']());}constructor(_0xa65dfb,_0x70e435,_0x80de12,_0x4adb2a){super(),this['repoInfo_']=_0xa65dfb,this['onDataUpdate_']=_0x70e435,this['authTokenProvider_']=_0x80de12,this['appCheckTokenProvider_']=_0x4adb2a,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x38dad1,_0x2b7317,_0x36f1c7,_0x197c2a){const _0x2ff046=_0x38dad1['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2ff046+'\x20'+_0x38dad1['_queryIdentifier']);const _0x4299ad=vn['getListenId_'](_0x38dad1,_0x36f1c7),_0x42fc81={};this['listens_'][_0x4299ad]=_0x42fc81;const _0x308e8b=ir(_0x38dad1['_queryParams']);this['restRequest_'](_0x2ff046+'.json',_0x308e8b,(_0x2399ea,_0x322d79)=>{let _0x4b80f9=_0x322d79;if(_0x2399ea===0x194&&(_0x4b80f9=null,_0x2399ea=null),_0x2399ea===null&&this['onDataUpdate_'](_0x2ff046,_0x4b80f9,!0x1,_0x36f1c7),Le(this['listens_'],_0x4299ad)===_0x42fc81){let _0x7c0ce0;_0x2399ea?_0x2399ea===0x191?_0x7c0ce0='permission_denied':_0x7c0ce0='rest_error:'+_0x2399ea:_0x7c0ce0='ok',_0x197c2a(_0x7c0ce0,null);}});}['unlisten'](_0x28a084,_0x4db1d6){const _0x4654e5=vn['getListenId_'](_0x28a084,_0x4db1d6);delete this['listens_'][_0x4654e5];}['get'](_0x3a62fb){const _0x2ace0f=ir(_0x3a62fb['_queryParams']),_0xee8c7d=_0x3a62fb['_path']['toString'](),_0x156cef=new H();return this['restRequest_'](_0xee8c7d+'.json',_0x2ace0f,(_0x3ec7c1,_0x2d166a)=>{let _0x36d5e6=_0x2d166a;_0x3ec7c1===0x194&&(_0x36d5e6=null,_0x3ec7c1=null),_0x3ec7c1===null?(this['onDataUpdate_'](_0xee8c7d,_0x36d5e6,!0x1,null),_0x156cef['resolve'](_0x36d5e6)):_0x156cef['reject'](new Error(_0x36d5e6));}),_0x156cef['promise'];}['refreshAuthToken'](_0x3088f1){}['restRequest_'](_0x40f33c,_0x3b3243={},_0x1999b7){return _0x3b3243['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x135370,_0x4159ea])=>{_0x135370&&_0x135370['accessToken']&&(_0x3b3243['auth']=_0x135370['accessToken']),_0x4159ea&&_0x4159ea['token']&&(_0x3b3243['ac']=_0x4159ea['token']);const _0x19d12e=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x40f33c+'?ns='+this['repoInfo_']['namespace']+ut(_0x3b3243);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x19d12e);const _0x47d4f6=new XMLHttpRequest();_0x47d4f6['onreadystatechange']=()=>{if(_0x1999b7&&_0x47d4f6['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x19d12e+'\x20received.\x20status:',_0x47d4f6['status'],'response:',_0x47d4f6['responseText']);let _0x53f54c=null;if(_0x47d4f6['status']>=0xc8&&_0x47d4f6['status']<0x12c){try{_0x53f54c=Nt(_0x47d4f6['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x19d12e+':\x20'+_0x47d4f6['responseText']);}_0x1999b7(null,_0x53f54c);}else _0x47d4f6['status']!==0x191&&_0x47d4f6['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x19d12e+'\x20Status:\x20'+_0x47d4f6['status']),_0x1999b7(_0x47d4f6['status']);_0x1999b7=null;}},_0x47d4f6['open']('GET',_0x19d12e,!0x0),_0x47d4f6['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x22f7d6){return this['rootNode_']['getChild'](_0x22f7d6);}['updateSnapshot'](_0x4da5a6,_0x1871d4){this['rootNode_']=this['rootNode_']['updateChild'](_0x4da5a6,_0x1871d4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x35c78e,_0x29dd39,_0x146860){if(v(_0x29dd39))_0x35c78e['value']=_0x146860,_0x35c78e['children']['clear']();else{if(_0x35c78e['value']!==null)_0x35c78e['value']=_0x35c78e['value']['updateChild'](_0x29dd39,_0x146860);else{const _0x495682=y(_0x29dd39);_0x35c78e['children']['has'](_0x495682)||_0x35c78e['children']['set'](_0x495682,En());const _0x535e57=_0x35c78e['children']['get'](_0x495682);_0x29dd39=S(_0x29dd39),pt(_0x535e57,_0x29dd39,_0x146860);}}}function Ti(_0x29cf14,_0x20767c){if(v(_0x20767c))return _0x29cf14['value']=null,_0x29cf14['children']['clear'](),!0x0;if(_0x29cf14['value']!==null){if(_0x29cf14['value']['isLeafNode']())return!0x1;{const _0x27f809=_0x29cf14['value'];return _0x29cf14['value']=null,_0x27f809['forEachChild'](R,(_0x3ccd27,_0x4fc82f)=>{pt(_0x29cf14,new C(_0x3ccd27),_0x4fc82f);}),Ti(_0x29cf14,_0x20767c);}}else{if(_0x29cf14['children']['size']>0x0){const _0x1c02b1=y(_0x20767c);return _0x20767c=S(_0x20767c),_0x29cf14['children']['has'](_0x1c02b1)&&Ti(_0x29cf14['children']['get'](_0x1c02b1),_0x20767c)&&_0x29cf14['children']['delete'](_0x1c02b1),_0x29cf14['children']['size']===0x0;}else return!0x0;}}function Si(_0x573324,_0x3952ee,_0x1051f1){_0x573324['value']!==null?_0x1051f1(_0x3952ee,_0x573324['value']):Zh(_0x573324,(_0x5bb276,_0x1292dc)=>{const _0x406ef9=new C(_0x3952ee['toString']()+'/'+_0x5bb276);Si(_0x1292dc,_0x406ef9,_0x1051f1);});}function Zh(_0x1827e6,_0x1b62ff){_0x1827e6['children']['forEach']((_0x3814e2,_0x27f4e4)=>{_0x1b62ff(_0x27f4e4,_0x3814e2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x389e2c){this['collection_']=_0x389e2c,this['last_']=null;}['get'](){const _0x31ab4b=this['collection_']['get'](),_0x5af955={..._0x31ab4b};return this['last_']&&x(this['last_'],(_0x5871b5,_0x5ac2f5)=>{_0x5af955[_0x5871b5]=_0x5af955[_0x5871b5]-_0x5ac2f5;}),this['last_']=_0x31ab4b,_0x5af955;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x126111,_0xa41a21){this['server_']=_0xa41a21,this['statsToReport_']={},this['statsListener_']=new eu(_0x126111);const _0x34c8d9=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x34c8d9));}['reportStats_'](){const _0x14f863=this['statsListener_']['get'](),_0x49be37={};let _0x39e962=!0x1;x(_0x14f863,(_0x442b1f,_0x3a3e10)=>{_0x3a3e10>0x0&&Q(this['statsToReport_'],_0x442b1f)&&(_0x49be37[_0x442b1f]=_0x3a3e10,_0x39e962=!0x0);}),_0x39e962&&this['server_']['reportStats'](_0x49be37),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x3f5d9b){_0x3f5d9b[_0x3f5d9b['OVERWRITE']=0x0]='OVERWRITE',_0x3f5d9b[_0x3f5d9b['MERGE']=0x1]='MERGE',_0x3f5d9b[_0x3f5d9b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x3f5d9b[_0x3f5d9b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x2c9e1a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2c9e1a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x2ce9df,_0x199ed9,_0x144d1a){this['path']=_0x2ce9df,this['affectedTree']=_0x199ed9,this['revert']=_0x144d1a,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x4debb0){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xf80e28=this['affectedTree']['subtree'](new C(_0x4debb0));return new In(w(),_0xf80e28,this['revert']);}}else return f(y(this['path'])===_0x4debb0,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4546b2,_0xcb3a66){this['source']=_0x4546b2,this['path']=_0xcb3a66,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x2a5e13){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x80e7f1,_0x2edfb2,_0x36d6ea){this['source']=_0x80e7f1,this['path']=_0x2edfb2,this['snap']=_0x36d6ea,this['type']=z['OVERWRITE'];}['operationForChild'](_0x4f3a99){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x4f3a99)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x1c41ce,_0x23c704,_0x27546f){this['source']=_0x1c41ce,this['path']=_0x23c704,this['children']=_0x27546f,this['type']=z['MERGE'];}['operationForChild'](_0x170cd6){if(v(this['path'])){const _0x3ca2d3=this['children']['subtree'](new C(_0x170cd6));return _0x3ca2d3['isEmpty']()?null:_0x3ca2d3['value']?new Be(this['source'],w(),_0x3ca2d3['value']):new ot(this['source'],w(),_0x3ca2d3);}else return f(y(this['path'])===_0x170cd6,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x178b0c,_0x2094fc,_0x4a8998){this['node_']=_0x178b0c,this['fullyInitialized_']=_0x2094fc,this['filtered_']=_0x4a8998;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x42f244){if(v(_0x42f244))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3c868e=y(_0x42f244);return this['isCompleteForChild'](_0x3c868e);}['isCompleteForChild'](_0x5a99f6){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5a99f6);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x48bacc){this['query_']=_0x48bacc,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x56236c,_0x3258c8,_0xc92027,_0x217a31){const _0x4f701f=[],_0x329cbc=[];return _0x3258c8['forEach'](_0x136771=>{_0x136771['type']==='child_changed'&&_0x56236c['index_']['indexedValueChanged'](_0x136771['oldSnap'],_0x136771['snapshotNode'])&&_0x329cbc['push'](zh(_0x136771['childName'],_0x136771['snapshotNode']));}),wt(_0x56236c,_0x4f701f,'child_removed',_0x3258c8,_0x217a31,_0xc92027),wt(_0x56236c,_0x4f701f,'child_added',_0x3258c8,_0x217a31,_0xc92027),wt(_0x56236c,_0x4f701f,'child_moved',_0x329cbc,_0x217a31,_0xc92027),wt(_0x56236c,_0x4f701f,'child_changed',_0x3258c8,_0x217a31,_0xc92027),wt(_0x56236c,_0x4f701f,'value',_0x3258c8,_0x217a31,_0xc92027),_0x4f701f;}function wt(_0x4dc122,_0x16252d,_0x4b2ff3,_0x4ef0d2,_0x1489df,_0x2135f3){const _0x5a1f2f=_0x4ef0d2['filter'](_0x363364=>_0x363364['type']===_0x4b2ff3);_0x5a1f2f['sort']((_0x3ca05e,_0x3a1574)=>au(_0x4dc122,_0x3ca05e,_0x3a1574)),_0x5a1f2f['forEach'](_0x9bf86a=>{const _0x411f0a=ou(_0x4dc122,_0x9bf86a,_0x2135f3);_0x1489df['forEach'](_0x1cc777=>{_0x1cc777['respondsTo'](_0x9bf86a['type'])&&_0x16252d['push'](_0x1cc777['createEvent'](_0x411f0a,_0x4dc122['query_']));});});}function ou(_0x856d41,_0x2e73bc,_0xa15d60){return _0x2e73bc['type']==='value'||_0x2e73bc['type']==='child_removed'||(_0x2e73bc['prevName']=_0xa15d60['getPredecessorChildName'](_0x2e73bc['childName'],_0x2e73bc['snapshotNode'],_0x856d41['index_'])),_0x2e73bc;}function au(_0x21ed87,_0x5dbddc,_0x301a69){if(_0x5dbddc['childName']==null||_0x301a69['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1cecce=new E(_0x5dbddc['childName'],_0x5dbddc['snapshotNode']),_0x2062a1=new E(_0x301a69['childName'],_0x301a69['snapshotNode']);return _0x21ed87['index_']['compare'](_0x1cecce,_0x2062a1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x101701,_0x5111ff){return{'eventCache':_0x101701,'serverCache':_0x5111ff};}function Rt(_0xbb2d49,_0x3f1aa3,_0x2eb1e6,_0x41115b){return Un(new Te(_0x3f1aa3,_0x2eb1e6,_0x41115b),_0xbb2d49['serverCache']);}function Fo(_0x4256e1,_0x3bd83c,_0x2e249f,_0x4b0b6d){return Un(_0x4256e1['eventCache'],new Te(_0x3bd83c,_0x2e249f,_0x4b0b6d));}function wn(_0x532d12){return _0x532d12['eventCache']['isFullyInitialized']()?_0x532d12['eventCache']['getNode']():null;}function Ve(_0x41b941){return _0x41b941['serverCache']['isFullyInitialized']()?_0x41b941['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x24d236){let _0x84437=new b(null);return x(_0x24d236,(_0x1ddd1f,_0x2a1861)=>{_0x84437=_0x84437['set'](new C(_0x1ddd1f),_0x2a1861);}),_0x84437;}constructor(_0x2c7fa1,_0xea58d3=cu()){this['value']=_0x2c7fa1,this['children']=_0xea58d3;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x38f99c,_0x4c213b){if(this['value']!=null&&_0x4c213b(this['value']))return{'path':w(),'value':this['value']};if(v(_0x38f99c))return null;{const _0x379b71=y(_0x38f99c),_0x383c57=this['children']['get'](_0x379b71);if(_0x383c57!==null){const _0x2571dc=_0x383c57['findRootMostMatchingPathAndValue'](S(_0x38f99c),_0x4c213b);return _0x2571dc!=null?{'path':k(new C(_0x379b71),_0x2571dc['path']),'value':_0x2571dc['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x39ed30){return this['findRootMostMatchingPathAndValue'](_0x39ed30,()=>!0x0);}['subtree'](_0x2e41f8){if(v(_0x2e41f8))return this;{const _0x4bd105=y(_0x2e41f8),_0x3751f4=this['children']['get'](_0x4bd105);return _0x3751f4!==null?_0x3751f4['subtree'](S(_0x2e41f8)):new b(null);}}['set'](_0x32bc15,_0x290863){if(v(_0x32bc15))return new b(_0x290863,this['children']);{const _0x16857b=y(_0x32bc15),_0x2254f3=(this['children']['get'](_0x16857b)||new b(null))['set'](S(_0x32bc15),_0x290863),_0x3710cd=this['children']['insert'](_0x16857b,_0x2254f3);return new b(this['value'],_0x3710cd);}}['remove'](_0x60cc1d){if(v(_0x60cc1d))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2d2fcd=y(_0x60cc1d),_0x3e7441=this['children']['get'](_0x2d2fcd);if(_0x3e7441){const _0x59ae79=_0x3e7441['remove'](S(_0x60cc1d));let _0x5190dd;return _0x59ae79['isEmpty']()?_0x5190dd=this['children']['remove'](_0x2d2fcd):_0x5190dd=this['children']['insert'](_0x2d2fcd,_0x59ae79),this['value']===null&&_0x5190dd['isEmpty']()?new b(null):new b(this['value'],_0x5190dd);}else return this;}}['get'](_0x1549cc){if(v(_0x1549cc))return this['value'];{const _0x5dbc0a=y(_0x1549cc),_0xc2eebc=this['children']['get'](_0x5dbc0a);return _0xc2eebc?_0xc2eebc['get'](S(_0x1549cc)):null;}}['setTree'](_0x40fac6,_0x24426){if(v(_0x40fac6))return _0x24426;{const _0x378c43=y(_0x40fac6),_0x50dd94=(this['children']['get'](_0x378c43)||new b(null))['setTree'](S(_0x40fac6),_0x24426);let _0x38aaec;return _0x50dd94['isEmpty']()?_0x38aaec=this['children']['remove'](_0x378c43):_0x38aaec=this['children']['insert'](_0x378c43,_0x50dd94),new b(this['value'],_0x38aaec);}}['fold'](_0x4562e2){return this['fold_'](w(),_0x4562e2);}['fold_'](_0x1d8dd8,_0x452a91){const _0x139dbe={};return this['children']['inorderTraversal']((_0x2ae775,_0x2c139b)=>{_0x139dbe[_0x2ae775]=_0x2c139b['fold_'](k(_0x1d8dd8,_0x2ae775),_0x452a91);}),_0x452a91(_0x1d8dd8,this['value'],_0x139dbe);}['findOnPath'](_0x36ca0b,_0x29dddf){return this['findOnPath_'](_0x36ca0b,w(),_0x29dddf);}['findOnPath_'](_0x4c4e6b,_0x57fe82,_0x4855b2){const _0x9ff2a6=this['value']?_0x4855b2(_0x57fe82,this['value']):!0x1;if(_0x9ff2a6)return _0x9ff2a6;if(v(_0x4c4e6b))return null;{const _0x20e431=y(_0x4c4e6b),_0x1c8293=this['children']['get'](_0x20e431);return _0x1c8293?_0x1c8293['findOnPath_'](S(_0x4c4e6b),k(_0x57fe82,_0x20e431),_0x4855b2):null;}}['foreachOnPath'](_0x33d55e,_0x28ef84){return this['foreachOnPath_'](_0x33d55e,w(),_0x28ef84);}['foreachOnPath_'](_0x2d194f,_0x43b2d3,_0x4ccd9){if(v(_0x2d194f))return this;{this['value']&&_0x4ccd9(_0x43b2d3,this['value']);const _0x652f24=y(_0x2d194f),_0x1979aa=this['children']['get'](_0x652f24);return _0x1979aa?_0x1979aa['foreachOnPath_'](S(_0x2d194f),k(_0x43b2d3,_0x652f24),_0x4ccd9):new b(null);}}['foreach'](_0x409177){this['foreach_'](w(),_0x409177);}['foreach_'](_0x1d2542,_0x39e7d4){this['children']['inorderTraversal']((_0x122202,_0x467775)=>{_0x467775['foreach_'](k(_0x1d2542,_0x122202),_0x39e7d4);}),this['value']&&_0x39e7d4(_0x1d2542,this['value']);}['foreachChild'](_0x2dd808){this['children']['inorderTraversal']((_0x17a415,_0x39a125)=>{_0x39a125['value']&&_0x2dd808(_0x17a415,_0x39a125['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x299639){this['writeTree_']=_0x299639;}static['empty'](){return new K(new b(null));}}function At(_0x24cec4,_0x5620eb,_0x347c25){if(v(_0x5620eb))return new K(new b(_0x347c25));{const _0x479f20=_0x24cec4['writeTree_']['findRootMostValueAndPath'](_0x5620eb);if(_0x479f20!=null){const _0x96823e=_0x479f20['path'];let _0x1283f2=_0x479f20['value'];const _0x20ec82=F(_0x96823e,_0x5620eb);return _0x1283f2=_0x1283f2['updateChild'](_0x20ec82,_0x347c25),new K(_0x24cec4['writeTree_']['set'](_0x96823e,_0x1283f2));}else{const _0x72800=new b(_0x347c25),_0x4af95e=_0x24cec4['writeTree_']['setTree'](_0x5620eb,_0x72800);return new K(_0x4af95e);}}}function bi(_0x1731cd,_0x2bc16f,_0x37ddac){let _0x491ed5=_0x1731cd;return x(_0x37ddac,(_0x34ff30,_0x1bf006)=>{_0x491ed5=At(_0x491ed5,k(_0x2bc16f,_0x34ff30),_0x1bf006);}),_0x491ed5;}function or(_0x24ab08,_0x13e192){if(v(_0x13e192))return K['empty']();{const _0x1701ce=_0x24ab08['writeTree_']['setTree'](_0x13e192,new b(null));return new K(_0x1701ce);}}function Ri(_0x393eac,_0x56514f){return ze(_0x393eac,_0x56514f)!=null;}function ze(_0x50559f,_0x239290){const _0x59e06b=_0x50559f['writeTree_']['findRootMostValueAndPath'](_0x239290);return _0x59e06b!=null?_0x50559f['writeTree_']['get'](_0x59e06b['path'])['getChild'](F(_0x59e06b['path'],_0x239290)):null;}function ar(_0x4a74c4){const _0x54bcb8=[],_0xf9c9ac=_0x4a74c4['writeTree_']['value'];return _0xf9c9ac!=null?_0xf9c9ac['isLeafNode']()||_0xf9c9ac['forEachChild'](R,(_0x9f9347,_0x286cfc)=>{_0x54bcb8['push'](new E(_0x9f9347,_0x286cfc));}):_0x4a74c4['writeTree_']['children']['inorderTraversal']((_0x40df4f,_0x2c25a7)=>{_0x2c25a7['value']!=null&&_0x54bcb8['push'](new E(_0x40df4f,_0x2c25a7['value']));}),_0x54bcb8;}function Ee(_0x1e5c08,_0x2a6d69){if(v(_0x2a6d69))return _0x1e5c08;{const _0xba2ce4=ze(_0x1e5c08,_0x2a6d69);return _0xba2ce4!=null?new K(new b(_0xba2ce4)):new K(_0x1e5c08['writeTree_']['subtree'](_0x2a6d69));}}function Ai(_0x57a779){return _0x57a779['writeTree_']['isEmpty']();}function at(_0x4cfc8f,_0x4811d2){return Uo(w(),_0x4cfc8f['writeTree_'],_0x4811d2);}function Uo(_0x31fd2e,_0x14c7fc,_0x114e12){if(_0x14c7fc['value']!=null)return _0x114e12['updateChild'](_0x31fd2e,_0x14c7fc['value']);{let _0x44057c=null;return _0x14c7fc['children']['inorderTraversal']((_0x4c1dc7,_0x2821a5)=>{_0x4c1dc7==='.priority'?(f(_0x2821a5['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x44057c=_0x2821a5['value']):_0x114e12=Uo(k(_0x31fd2e,_0x4c1dc7),_0x2821a5,_0x114e12);}),!_0x114e12['getChild'](_0x31fd2e)['isEmpty']()&&_0x44057c!==null&&(_0x114e12=_0x114e12['updateChild'](k(_0x31fd2e,'.priority'),_0x44057c)),_0x114e12;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x3aaf14,_0x1e0e46){return Ho(_0x1e0e46,_0x3aaf14);}function lu(_0x33f96d,_0x542b90,_0x256a7e,_0x9fcf32,_0x22fc11){f(_0x9fcf32>_0x33f96d['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x22fc11===void 0x0&&(_0x22fc11=!0x0),_0x33f96d['allWrites']['push']({'path':_0x542b90,'snap':_0x256a7e,'writeId':_0x9fcf32,'visible':_0x22fc11}),_0x22fc11&&(_0x33f96d['visibleWrites']=At(_0x33f96d['visibleWrites'],_0x542b90,_0x256a7e)),_0x33f96d['lastWriteId']=_0x9fcf32;}function hu(_0x3b1535,_0x277b32,_0x46cdcc,_0x109ef3){f(_0x109ef3>_0x3b1535['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x3b1535['allWrites']['push']({'path':_0x277b32,'children':_0x46cdcc,'writeId':_0x109ef3,'visible':!0x0}),_0x3b1535['visibleWrites']=bi(_0x3b1535['visibleWrites'],_0x277b32,_0x46cdcc),_0x3b1535['lastWriteId']=_0x109ef3;}function uu(_0x533bf0,_0x55048b){for(let _0x1fdc23=0x0;_0x1fdc23<_0x533bf0['allWrites']['length'];_0x1fdc23++){const _0x464d3d=_0x533bf0['allWrites'][_0x1fdc23];if(_0x464d3d['writeId']===_0x55048b)return _0x464d3d;}return null;}function du(_0x46e39b,_0x4dadea){const _0x5341b1=_0x46e39b['allWrites']['findIndex'](_0x168bc4=>_0x168bc4['writeId']===_0x4dadea);f(_0x5341b1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x6fdf60=_0x46e39b['allWrites'][_0x5341b1];_0x46e39b['allWrites']['splice'](_0x5341b1,0x1);let _0x587433=_0x6fdf60['visible'],_0xdf03d5=!0x1,_0x5b93a5=_0x46e39b['allWrites']['length']-0x1;for(;_0x587433&&_0x5b93a5>=0x0;){const _0x3a5c4b=_0x46e39b['allWrites'][_0x5b93a5];_0x3a5c4b['visible']&&(_0x5b93a5>=_0x5341b1&&fu(_0x3a5c4b,_0x6fdf60['path'])?_0x587433=!0x1:G(_0x6fdf60['path'],_0x3a5c4b['path'])&&(_0xdf03d5=!0x0)),_0x5b93a5--;}if(_0x587433){if(_0xdf03d5)return pu(_0x46e39b),!0x0;if(_0x6fdf60['snap'])_0x46e39b['visibleWrites']=or(_0x46e39b['visibleWrites'],_0x6fdf60['path']);else{const _0x1bb42d=_0x6fdf60['children'];x(_0x1bb42d,_0x5cd110=>{_0x46e39b['visibleWrites']=or(_0x46e39b['visibleWrites'],k(_0x6fdf60['path'],_0x5cd110));});}return!0x0;}else return!0x1;}function fu(_0x5dc01d,_0x1522aa){if(_0x5dc01d['snap'])return G(_0x5dc01d['path'],_0x1522aa);for(const _0x50c6a0 in _0x5dc01d['children'])if(_0x5dc01d['children']['hasOwnProperty'](_0x50c6a0)&&G(k(_0x5dc01d['path'],_0x50c6a0),_0x1522aa))return!0x0;return!0x1;}function pu(_0x574fcb){_0x574fcb['visibleWrites']=Wo(_0x574fcb['allWrites'],_u,w()),_0x574fcb['allWrites']['length']>0x0?_0x574fcb['lastWriteId']=_0x574fcb['allWrites'][_0x574fcb['allWrites']['length']-0x1]['writeId']:_0x574fcb['lastWriteId']=-0x1;}function _u(_0x592518){return _0x592518['visible'];}function Wo(_0xf64f2,_0x268169,_0x62217f){let _0xc026a8=K['empty']();for(let _0x424603=0x0;_0x424603<_0xf64f2['length'];++_0x424603){const _0x55b39e=_0xf64f2[_0x424603];if(_0x268169(_0x55b39e)){const _0x45dc5f=_0x55b39e['path'];let _0x493977;if(_0x55b39e['snap'])G(_0x62217f,_0x45dc5f)?(_0x493977=F(_0x62217f,_0x45dc5f),_0xc026a8=At(_0xc026a8,_0x493977,_0x55b39e['snap'])):G(_0x45dc5f,_0x62217f)&&(_0x493977=F(_0x45dc5f,_0x62217f),_0xc026a8=At(_0xc026a8,w(),_0x55b39e['snap']['getChild'](_0x493977)));else{if(_0x55b39e['children']){if(G(_0x62217f,_0x45dc5f))_0x493977=F(_0x62217f,_0x45dc5f),_0xc026a8=bi(_0xc026a8,_0x493977,_0x55b39e['children']);else{if(G(_0x45dc5f,_0x62217f)){if(_0x493977=F(_0x45dc5f,_0x62217f),v(_0x493977))_0xc026a8=bi(_0xc026a8,w(),_0x55b39e['children']);else{const _0x2c9d82=Le(_0x55b39e['children'],y(_0x493977));if(_0x2c9d82){const _0xfbae26=_0x2c9d82['getChild'](S(_0x493977));_0xc026a8=At(_0xc026a8,w(),_0xfbae26);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xc026a8;}function Bo(_0x1d7ea0,_0x13d6c4,_0x5390e8,_0x17924,_0x3d7688){if(!_0x17924&&!_0x3d7688){const _0x374e44=ze(_0x1d7ea0['visibleWrites'],_0x13d6c4);if(_0x374e44!=null)return _0x374e44;{const _0x53627e=Ee(_0x1d7ea0['visibleWrites'],_0x13d6c4);if(Ai(_0x53627e))return _0x5390e8;if(_0x5390e8==null&&!Ri(_0x53627e,w()))return null;{const _0x4f7664=_0x5390e8||g['EMPTY_NODE'];return at(_0x53627e,_0x4f7664);}}}else{const _0x3d5740=Ee(_0x1d7ea0['visibleWrites'],_0x13d6c4);if(!_0x3d7688&&Ai(_0x3d5740))return _0x5390e8;if(!_0x3d7688&&_0x5390e8==null&&!Ri(_0x3d5740,w()))return null;{const _0x2cd150=function(_0x4554cf){return(_0x4554cf['visible']||_0x3d7688)&&(!_0x17924||!~_0x17924['indexOf'](_0x4554cf['writeId']))&&(G(_0x4554cf['path'],_0x13d6c4)||G(_0x13d6c4,_0x4554cf['path']));},_0x453947=Wo(_0x1d7ea0['allWrites'],_0x2cd150,_0x13d6c4),_0x5ac9e6=_0x5390e8||g['EMPTY_NODE'];return at(_0x453947,_0x5ac9e6);}}}function gu(_0x4d3afc,_0x7b1d67,_0x6003d){let _0x5046ad=g['EMPTY_NODE'];const _0x33c1a8=ze(_0x4d3afc['visibleWrites'],_0x7b1d67);if(_0x33c1a8)return _0x33c1a8['isLeafNode']()||_0x33c1a8['forEachChild'](R,(_0xb58d,_0x20b217)=>{_0x5046ad=_0x5046ad['updateImmediateChild'](_0xb58d,_0x20b217);}),_0x5046ad;if(_0x6003d){const _0x37a39c=Ee(_0x4d3afc['visibleWrites'],_0x7b1d67);return _0x6003d['forEachChild'](R,(_0x34df5f,_0x4033c4)=>{const _0x58121f=at(Ee(_0x37a39c,new C(_0x34df5f)),_0x4033c4);_0x5046ad=_0x5046ad['updateImmediateChild'](_0x34df5f,_0x58121f);}),ar(_0x37a39c)['forEach'](_0x2cbe79=>{_0x5046ad=_0x5046ad['updateImmediateChild'](_0x2cbe79['name'],_0x2cbe79['node']);}),_0x5046ad;}else{const _0x145572=Ee(_0x4d3afc['visibleWrites'],_0x7b1d67);return ar(_0x145572)['forEach'](_0x19ba44=>{_0x5046ad=_0x5046ad['updateImmediateChild'](_0x19ba44['name'],_0x19ba44['node']);}),_0x5046ad;}}function mu(_0x2fa35e,_0x26d178,_0x592d4d,_0x1c3585,_0x2cbfd9){f(_0x1c3585||_0x2cbfd9,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x43515b=k(_0x26d178,_0x592d4d);if(Ri(_0x2fa35e['visibleWrites'],_0x43515b))return null;{const _0x3f8701=Ee(_0x2fa35e['visibleWrites'],_0x43515b);return Ai(_0x3f8701)?_0x2cbfd9['getChild'](_0x592d4d):at(_0x3f8701,_0x2cbfd9['getChild'](_0x592d4d));}}function yu(_0x33c311,_0x95dc9,_0x1f0762,_0x4028b3){const _0x3c8184=k(_0x95dc9,_0x1f0762),_0x3ffe4a=ze(_0x33c311['visibleWrites'],_0x3c8184);if(_0x3ffe4a!=null)return _0x3ffe4a;if(_0x4028b3['isCompleteForChild'](_0x1f0762)){const _0x13101e=Ee(_0x33c311['visibleWrites'],_0x3c8184);return at(_0x13101e,_0x4028b3['getNode']()['getImmediateChild'](_0x1f0762));}else return null;}function vu(_0x230262,_0xaee4e3){return ze(_0x230262['visibleWrites'],_0xaee4e3);}function Eu(_0x3835d2,_0x73456,_0x341395,_0x2bcfdf,_0x52a7fa,_0x290258,_0x3c4955){let _0xaf7be6;const _0x3a5169=Ee(_0x3835d2['visibleWrites'],_0x73456),_0x47d613=ze(_0x3a5169,w());if(_0x47d613!=null)_0xaf7be6=_0x47d613;else{if(_0x341395!=null)_0xaf7be6=at(_0x3a5169,_0x341395);else return[];}if(_0xaf7be6=_0xaf7be6['withIndex'](_0x3c4955),!_0xaf7be6['isEmpty']()&&!_0xaf7be6['isLeafNode']()){const _0x55c3de=[],_0x2827bb=_0x3c4955['getCompare'](),_0x57bcaf=_0x290258?_0xaf7be6['getReverseIteratorFrom'](_0x2bcfdf,_0x3c4955):_0xaf7be6['getIteratorFrom'](_0x2bcfdf,_0x3c4955);let _0x4e9432=_0x57bcaf['getNext']();for(;_0x4e9432&&_0x55c3de['length']<_0x52a7fa;)_0x2827bb(_0x4e9432,_0x2bcfdf)!==0x0&&_0x55c3de['push'](_0x4e9432),_0x4e9432=_0x57bcaf['getNext']();return _0x55c3de;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x45c217,_0x2d12ed,_0x4398f3,_0x197186){return Bo(_0x45c217['writeTree'],_0x45c217['treePath'],_0x2d12ed,_0x4398f3,_0x197186);}function is(_0x4abcfd,_0x245a95){return gu(_0x4abcfd['writeTree'],_0x4abcfd['treePath'],_0x245a95);}function cr(_0x58c166,_0x5b9b5d,_0xb52e68,_0xcad0c1){return mu(_0x58c166['writeTree'],_0x58c166['treePath'],_0x5b9b5d,_0xb52e68,_0xcad0c1);}function Tn(_0x1171a1,_0x2374bb){return vu(_0x1171a1['writeTree'],k(_0x1171a1['treePath'],_0x2374bb));}function wu(_0x189321,_0x30cdc2,_0x2ecd9b,_0x570b5a,_0x3929de,_0x37bcf4){return Eu(_0x189321['writeTree'],_0x189321['treePath'],_0x30cdc2,_0x2ecd9b,_0x570b5a,_0x3929de,_0x37bcf4);}function ss(_0x26a9aa,_0x1f9971,_0x1bfc51){return yu(_0x26a9aa['writeTree'],_0x26a9aa['treePath'],_0x1f9971,_0x1bfc51);}function Vo(_0x2a8b34,_0x3fa28d){return Ho(k(_0x2a8b34['treePath'],_0x3fa28d),_0x2a8b34['writeTree']);}function Ho(_0x38792f,_0x2cc971){return{'treePath':_0x38792f,'writeTree':_0x2cc971};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x148b99){const _0x3a5f73=_0x148b99['type'],_0x3e8403=_0x148b99['childName'];f(_0x3a5f73==='child_added'||_0x3a5f73==='child_changed'||_0x3a5f73==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3e8403!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x35e726=this['changeMap']['get'](_0x3e8403);if(_0x35e726){const _0x1e24d7=_0x35e726['type'];if(_0x3a5f73==='child_added'&&_0x1e24d7==='child_removed')this['changeMap']['set'](_0x3e8403,xt(_0x3e8403,_0x148b99['snapshotNode'],_0x35e726['snapshotNode']));else{if(_0x3a5f73==='child_removed'&&_0x1e24d7==='child_added')this['changeMap']['delete'](_0x3e8403);else{if(_0x3a5f73==='child_removed'&&_0x1e24d7==='child_changed')this['changeMap']['set'](_0x3e8403,Lt(_0x3e8403,_0x35e726['oldSnap']));else{if(_0x3a5f73==='child_changed'&&_0x1e24d7==='child_added')this['changeMap']['set'](_0x3e8403,rt(_0x3e8403,_0x148b99['snapshotNode']));else{if(_0x3a5f73==='child_changed'&&_0x1e24d7==='child_changed')this['changeMap']['set'](_0x3e8403,xt(_0x3e8403,_0x148b99['snapshotNode'],_0x35e726['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x148b99+'\x20occurred\x20after\x20'+_0x35e726);}}}}}else this['changeMap']['set'](_0x3e8403,_0x148b99);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x27b515){return null;}['getChildAfterChild'](_0x1b059e,_0x414b5a,_0x1cbd65){return null;}}const $o=new Tu();class rs{constructor(_0x43399a,_0x2b3851,_0x5962b0=null){this['writes_']=_0x43399a,this['viewCache_']=_0x2b3851,this['optCompleteServerCache_']=_0x5962b0;}['getCompleteChild'](_0x53cc23){const _0x2e938d=this['viewCache_']['eventCache'];if(_0x2e938d['isCompleteForChild'](_0x53cc23))return _0x2e938d['getNode']()['getImmediateChild'](_0x53cc23);{const _0x5b04b5=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x53cc23,_0x5b04b5);}}['getChildAfterChild'](_0x14bd72,_0x70fc89,_0x52df09){const _0x98692c=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x250726=wu(this['writes_'],_0x98692c,_0x70fc89,0x1,_0x52df09,_0x14bd72);return _0x250726['length']===0x0?null:_0x250726[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4de66d){return{'filter':_0x4de66d};}function bu(_0x593d63,_0x1013c0){f(_0x1013c0['eventCache']['getNode']()['isIndexed'](_0x593d63['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1013c0['serverCache']['getNode']()['isIndexed'](_0x593d63['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x3f3e5c,_0x6aa32,_0x6cee74,_0x2ff84e,_0x191d73){const _0x4adca1=new Cu();let _0x3beaf7,_0x506698;if(_0x6cee74['type']===z['OVERWRITE']){const _0x1da7c5=_0x6cee74;_0x1da7c5['source']['fromUser']?_0x3beaf7=ki(_0x3f3e5c,_0x6aa32,_0x1da7c5['path'],_0x1da7c5['snap'],_0x2ff84e,_0x191d73,_0x4adca1):(f(_0x1da7c5['source']['fromServer'],'Unknown\x20source.'),_0x506698=_0x1da7c5['source']['tagged']||_0x6aa32['serverCache']['isFiltered']()&&!v(_0x1da7c5['path']),_0x3beaf7=Sn(_0x3f3e5c,_0x6aa32,_0x1da7c5['path'],_0x1da7c5['snap'],_0x2ff84e,_0x191d73,_0x506698,_0x4adca1));}else{if(_0x6cee74['type']===z['MERGE']){const _0x4fe8a2=_0x6cee74;_0x4fe8a2['source']['fromUser']?_0x3beaf7=ku(_0x3f3e5c,_0x6aa32,_0x4fe8a2['path'],_0x4fe8a2['children'],_0x2ff84e,_0x191d73,_0x4adca1):(f(_0x4fe8a2['source']['fromServer'],'Unknown\x20source.'),_0x506698=_0x4fe8a2['source']['tagged']||_0x6aa32['serverCache']['isFiltered'](),_0x3beaf7=Pi(_0x3f3e5c,_0x6aa32,_0x4fe8a2['path'],_0x4fe8a2['children'],_0x2ff84e,_0x191d73,_0x506698,_0x4adca1));}else{if(_0x6cee74['type']===z['ACK_USER_WRITE']){const _0x2f20b5=_0x6cee74;_0x2f20b5['revert']?_0x3beaf7=Ou(_0x3f3e5c,_0x6aa32,_0x2f20b5['path'],_0x2ff84e,_0x191d73,_0x4adca1):_0x3beaf7=Pu(_0x3f3e5c,_0x6aa32,_0x2f20b5['path'],_0x2f20b5['affectedTree'],_0x2ff84e,_0x191d73,_0x4adca1);}else{if(_0x6cee74['type']===z['LISTEN_COMPLETE'])_0x3beaf7=Nu(_0x3f3e5c,_0x6aa32,_0x6cee74['path'],_0x2ff84e,_0x4adca1);else throw ht('Unknown\x20operation\x20type:\x20'+_0x6cee74['type']);}}}const _0x36f5a4=_0x4adca1['getChanges']();return Au(_0x6aa32,_0x3beaf7,_0x36f5a4),{'viewCache':_0x3beaf7,'changes':_0x36f5a4};}function Au(_0x179e37,_0x4d1f51,_0x225931){const _0x3245de=_0x4d1f51['eventCache'];if(_0x3245de['isFullyInitialized']()){const _0x1042bf=_0x3245de['getNode']()['isLeafNode']()||_0x3245de['getNode']()['isEmpty'](),_0x5919f7=wn(_0x179e37);(_0x225931['length']>0x0||!_0x179e37['eventCache']['isFullyInitialized']()||_0x1042bf&&!_0x3245de['getNode']()['equals'](_0x5919f7)||!_0x3245de['getNode']()['getPriority']()['equals'](_0x5919f7['getPriority']()))&&_0x225931['push'](Lo(wn(_0x4d1f51)));}}function Go(_0x6afa61,_0x4bb7b4,_0x11642d,_0x5bdbba,_0x2dce94,_0x264f10){const _0x4b1382=_0x4bb7b4['eventCache'];if(Tn(_0x5bdbba,_0x11642d)!=null)return _0x4bb7b4;{let _0x25c571,_0x4386dc;if(v(_0x11642d)){if(f(_0x4bb7b4['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x4bb7b4['serverCache']['isFiltered']()){const _0x30b046=Ve(_0x4bb7b4),_0x36cc6a=_0x30b046 instanceof g?_0x30b046:g['EMPTY_NODE'],_0x1d30e1=is(_0x5bdbba,_0x36cc6a);_0x25c571=_0x6afa61['filter']['updateFullNode'](_0x4bb7b4['eventCache']['getNode'](),_0x1d30e1,_0x264f10);}else{const _0x19b064=Cn(_0x5bdbba,Ve(_0x4bb7b4));_0x25c571=_0x6afa61['filter']['updateFullNode'](_0x4bb7b4['eventCache']['getNode'](),_0x19b064,_0x264f10);}}else{const _0x29bb99=y(_0x11642d);if(_0x29bb99==='.priority'){f(Ce(_0x11642d)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x24ddf9=_0x4b1382['getNode']();_0x4386dc=_0x4bb7b4['serverCache']['getNode']();const _0x455a86=cr(_0x5bdbba,_0x11642d,_0x24ddf9,_0x4386dc);_0x455a86!=null?_0x25c571=_0x6afa61['filter']['updatePriority'](_0x24ddf9,_0x455a86):_0x25c571=_0x4b1382['getNode']();}else{const _0xd52b78=S(_0x11642d);let _0x3aa204;if(_0x4b1382['isCompleteForChild'](_0x29bb99)){_0x4386dc=_0x4bb7b4['serverCache']['getNode']();const _0x57b32f=cr(_0x5bdbba,_0x11642d,_0x4b1382['getNode'](),_0x4386dc);_0x57b32f!=null?_0x3aa204=_0x4b1382['getNode']()['getImmediateChild'](_0x29bb99)['updateChild'](_0xd52b78,_0x57b32f):_0x3aa204=_0x4b1382['getNode']()['getImmediateChild'](_0x29bb99);}else _0x3aa204=ss(_0x5bdbba,_0x29bb99,_0x4bb7b4['serverCache']);_0x3aa204!=null?_0x25c571=_0x6afa61['filter']['updateChild'](_0x4b1382['getNode'](),_0x29bb99,_0x3aa204,_0xd52b78,_0x2dce94,_0x264f10):_0x25c571=_0x4b1382['getNode']();}}return Rt(_0x4bb7b4,_0x25c571,_0x4b1382['isFullyInitialized']()||v(_0x11642d),_0x6afa61['filter']['filtersNodes']());}}function Sn(_0x548b6a,_0x35890d,_0x5b3e6e,_0x35638f,_0x48ac30,_0x233459,_0x3dcb60,_0x15157a){const _0x288574=_0x35890d['serverCache'];let _0x5d1f10;const _0x53becf=_0x3dcb60?_0x548b6a['filter']:_0x548b6a['filter']['getIndexedFilter']();if(v(_0x5b3e6e))_0x5d1f10=_0x53becf['updateFullNode'](_0x288574['getNode'](),_0x35638f,null);else{if(_0x53becf['filtersNodes']()&&!_0x288574['isFiltered']()){const _0x3b423c=_0x288574['getNode']()['updateChild'](_0x5b3e6e,_0x35638f);_0x5d1f10=_0x53becf['updateFullNode'](_0x288574['getNode'](),_0x3b423c,null);}else{const _0x375b8b=y(_0x5b3e6e);if(!_0x288574['isCompleteForPath'](_0x5b3e6e)&&Ce(_0x5b3e6e)>0x1)return _0x35890d;const _0x232d1c=S(_0x5b3e6e),_0x1734fc=_0x288574['getNode']()['getImmediateChild'](_0x375b8b)['updateChild'](_0x232d1c,_0x35638f);_0x375b8b==='.priority'?_0x5d1f10=_0x53becf['updatePriority'](_0x288574['getNode'](),_0x1734fc):_0x5d1f10=_0x53becf['updateChild'](_0x288574['getNode'](),_0x375b8b,_0x1734fc,_0x232d1c,$o,null);}}const _0x3f25f2=Fo(_0x35890d,_0x5d1f10,_0x288574['isFullyInitialized']()||v(_0x5b3e6e),_0x53becf['filtersNodes']()),_0x1c0dee=new rs(_0x48ac30,_0x3f25f2,_0x233459);return Go(_0x548b6a,_0x3f25f2,_0x5b3e6e,_0x48ac30,_0x1c0dee,_0x15157a);}function ki(_0x1ec8d7,_0x402ae3,_0x3fa4f6,_0x265f6d,_0x33736b,_0x5bdde1,_0x1e774a){const _0x1ba437=_0x402ae3['eventCache'];let _0x4da08c,_0x4574f1;const _0x56a232=new rs(_0x33736b,_0x402ae3,_0x5bdde1);if(v(_0x3fa4f6))_0x4574f1=_0x1ec8d7['filter']['updateFullNode'](_0x402ae3['eventCache']['getNode'](),_0x265f6d,_0x1e774a),_0x4da08c=Rt(_0x402ae3,_0x4574f1,!0x0,_0x1ec8d7['filter']['filtersNodes']());else{const _0x288562=y(_0x3fa4f6);if(_0x288562==='.priority')_0x4574f1=_0x1ec8d7['filter']['updatePriority'](_0x402ae3['eventCache']['getNode'](),_0x265f6d),_0x4da08c=Rt(_0x402ae3,_0x4574f1,_0x1ba437['isFullyInitialized'](),_0x1ba437['isFiltered']());else{const _0x1486fa=S(_0x3fa4f6),_0xd2340=_0x1ba437['getNode']()['getImmediateChild'](_0x288562);let _0x53121c;if(v(_0x1486fa))_0x53121c=_0x265f6d;else{const _0x17ec02=_0x56a232['getCompleteChild'](_0x288562);_0x17ec02!=null?ji(_0x1486fa)==='.priority'&&_0x17ec02['getChild'](Ro(_0x1486fa))['isEmpty']()?_0x53121c=_0x17ec02:_0x53121c=_0x17ec02['updateChild'](_0x1486fa,_0x265f6d):_0x53121c=g['EMPTY_NODE'];}if(_0xd2340['equals'](_0x53121c))_0x4da08c=_0x402ae3;else{const _0x219c66=_0x1ec8d7['filter']['updateChild'](_0x1ba437['getNode'](),_0x288562,_0x53121c,_0x1486fa,_0x56a232,_0x1e774a);_0x4da08c=Rt(_0x402ae3,_0x219c66,_0x1ba437['isFullyInitialized'](),_0x1ec8d7['filter']['filtersNodes']());}}}return _0x4da08c;}function lr(_0x1b4b42,_0x172621){return _0x1b4b42['eventCache']['isCompleteForChild'](_0x172621);}function ku(_0x15a85a,_0x62ce9b,_0x5eda05,_0x5e231a,_0x3c58a7,_0x3dc258,_0x3286d5){let _0xf26df6=_0x62ce9b;return _0x5e231a['foreach']((_0x56e00c,_0x33208b)=>{const _0xf9d01e=k(_0x5eda05,_0x56e00c);lr(_0x62ce9b,y(_0xf9d01e))&&(_0xf26df6=ki(_0x15a85a,_0xf26df6,_0xf9d01e,_0x33208b,_0x3c58a7,_0x3dc258,_0x3286d5));}),_0x5e231a['foreach']((_0x259ee3,_0x290a73)=>{const _0x5b0380=k(_0x5eda05,_0x259ee3);lr(_0x62ce9b,y(_0x5b0380))||(_0xf26df6=ki(_0x15a85a,_0xf26df6,_0x5b0380,_0x290a73,_0x3c58a7,_0x3dc258,_0x3286d5));}),_0xf26df6;}function hr(_0x5c5a67,_0x50f5d5,_0x37eec0){return _0x37eec0['foreach']((_0x163909,_0x3893ad)=>{_0x50f5d5=_0x50f5d5['updateChild'](_0x163909,_0x3893ad);}),_0x50f5d5;}function Pi(_0x528797,_0x615fbb,_0x202e12,_0x4bca54,_0x5ace91,_0x38b803,_0x1243ec,_0x1120f6){if(_0x615fbb['serverCache']['getNode']()['isEmpty']()&&!_0x615fbb['serverCache']['isFullyInitialized']())return _0x615fbb;let _0x27dfaf=_0x615fbb,_0x23c181;v(_0x202e12)?_0x23c181=_0x4bca54:_0x23c181=new b(null)['setTree'](_0x202e12,_0x4bca54);const _0x5ead47=_0x615fbb['serverCache']['getNode']();return _0x23c181['children']['inorderTraversal']((_0x3c73cf,_0x50ef0b)=>{if(_0x5ead47['hasChild'](_0x3c73cf)){const _0xcecdcc=_0x615fbb['serverCache']['getNode']()['getImmediateChild'](_0x3c73cf),_0x5d7253=hr(_0x528797,_0xcecdcc,_0x50ef0b);_0x27dfaf=Sn(_0x528797,_0x27dfaf,new C(_0x3c73cf),_0x5d7253,_0x5ace91,_0x38b803,_0x1243ec,_0x1120f6);}}),_0x23c181['children']['inorderTraversal']((_0x232c88,_0x36a3a7)=>{const _0x53fb7c=!_0x615fbb['serverCache']['isCompleteForChild'](_0x232c88)&&_0x36a3a7['value']===null;if(!_0x5ead47['hasChild'](_0x232c88)&&!_0x53fb7c){const _0x2721a8=_0x615fbb['serverCache']['getNode']()['getImmediateChild'](_0x232c88),_0x5ddc4b=hr(_0x528797,_0x2721a8,_0x36a3a7);_0x27dfaf=Sn(_0x528797,_0x27dfaf,new C(_0x232c88),_0x5ddc4b,_0x5ace91,_0x38b803,_0x1243ec,_0x1120f6);}}),_0x27dfaf;}function Pu(_0x4f36cf,_0x5f1781,_0x44dc21,_0x2c8f38,_0x2c17ee,_0x24db7d,_0x32d0bf){if(Tn(_0x2c17ee,_0x44dc21)!=null)return _0x5f1781;const _0x14b015=_0x5f1781['serverCache']['isFiltered'](),_0x3102af=_0x5f1781['serverCache'];if(_0x2c8f38['value']!=null){if(v(_0x44dc21)&&_0x3102af['isFullyInitialized']()||_0x3102af['isCompleteForPath'](_0x44dc21))return Sn(_0x4f36cf,_0x5f1781,_0x44dc21,_0x3102af['getNode']()['getChild'](_0x44dc21),_0x2c17ee,_0x24db7d,_0x14b015,_0x32d0bf);if(v(_0x44dc21)){let _0x4c3505=new b(null);return _0x3102af['getNode']()['forEachChild'](ve,(_0x127c5f,_0x1ddb18)=>{_0x4c3505=_0x4c3505['set'](new C(_0x127c5f),_0x1ddb18);}),Pi(_0x4f36cf,_0x5f1781,_0x44dc21,_0x4c3505,_0x2c17ee,_0x24db7d,_0x14b015,_0x32d0bf);}else return _0x5f1781;}else{let _0x1765a7=new b(null);return _0x2c8f38['foreach']((_0x1ceecf,_0x2875c5)=>{const _0x4a277f=k(_0x44dc21,_0x1ceecf);_0x3102af['isCompleteForPath'](_0x4a277f)&&(_0x1765a7=_0x1765a7['set'](_0x1ceecf,_0x3102af['getNode']()['getChild'](_0x4a277f)));}),Pi(_0x4f36cf,_0x5f1781,_0x44dc21,_0x1765a7,_0x2c17ee,_0x24db7d,_0x14b015,_0x32d0bf);}}function Nu(_0x5a31a0,_0x2d9c70,_0x2e9c81,_0x53d898,_0x247de3){const _0x268721=_0x2d9c70['serverCache'],_0x52fadb=Fo(_0x2d9c70,_0x268721['getNode'](),_0x268721['isFullyInitialized']()||v(_0x2e9c81),_0x268721['isFiltered']());return Go(_0x5a31a0,_0x52fadb,_0x2e9c81,_0x53d898,$o,_0x247de3);}function Ou(_0x235167,_0x4ac6eb,_0x1e7114,_0x1a92f9,_0x786afd,_0x44e7c5){let _0x24bdf2;if(Tn(_0x1a92f9,_0x1e7114)!=null)return _0x4ac6eb;{const _0x10114e=new rs(_0x1a92f9,_0x4ac6eb,_0x786afd),_0x2a3e3a=_0x4ac6eb['eventCache']['getNode']();let _0x1f5718;if(v(_0x1e7114)||y(_0x1e7114)==='.priority'){let _0x239fcf;if(_0x4ac6eb['serverCache']['isFullyInitialized']())_0x239fcf=Cn(_0x1a92f9,Ve(_0x4ac6eb));else{const _0x4f2602=_0x4ac6eb['serverCache']['getNode']();f(_0x4f2602 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x239fcf=is(_0x1a92f9,_0x4f2602);}_0x239fcf=_0x239fcf,_0x1f5718=_0x235167['filter']['updateFullNode'](_0x2a3e3a,_0x239fcf,_0x44e7c5);}else{const _0x3b0c47=y(_0x1e7114);let _0x5364b7=ss(_0x1a92f9,_0x3b0c47,_0x4ac6eb['serverCache']);_0x5364b7==null&&_0x4ac6eb['serverCache']['isCompleteForChild'](_0x3b0c47)&&(_0x5364b7=_0x2a3e3a['getImmediateChild'](_0x3b0c47)),_0x5364b7!=null?_0x1f5718=_0x235167['filter']['updateChild'](_0x2a3e3a,_0x3b0c47,_0x5364b7,S(_0x1e7114),_0x10114e,_0x44e7c5):_0x4ac6eb['eventCache']['getNode']()['hasChild'](_0x3b0c47)?_0x1f5718=_0x235167['filter']['updateChild'](_0x2a3e3a,_0x3b0c47,g['EMPTY_NODE'],S(_0x1e7114),_0x10114e,_0x44e7c5):_0x1f5718=_0x2a3e3a,_0x1f5718['isEmpty']()&&_0x4ac6eb['serverCache']['isFullyInitialized']()&&(_0x24bdf2=Cn(_0x1a92f9,Ve(_0x4ac6eb)),_0x24bdf2['isLeafNode']()&&(_0x1f5718=_0x235167['filter']['updateFullNode'](_0x1f5718,_0x24bdf2,_0x44e7c5)));}return _0x24bdf2=_0x4ac6eb['serverCache']['isFullyInitialized']()||Tn(_0x1a92f9,w())!=null,Rt(_0x4ac6eb,_0x1f5718,_0x24bdf2,_0x235167['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4aa56a,_0x57000e){this['query_']=_0x4aa56a,this['eventRegistrations_']=[];const _0x6b608a=this['query_']['_queryParams'],_0x1a9801=new Xi(_0x6b608a['getIndex']()),_0x219599=Kh(_0x6b608a);this['processor_']=Su(_0x219599);const _0x1a1dba=_0x57000e['serverCache'],_0x4c409e=_0x57000e['eventCache'],_0x920c4d=_0x1a9801['updateFullNode'](g['EMPTY_NODE'],_0x1a1dba['getNode'](),null),_0x2c6c57=_0x219599['updateFullNode'](g['EMPTY_NODE'],_0x4c409e['getNode'](),null),_0xe97c93=new Te(_0x920c4d,_0x1a1dba['isFullyInitialized'](),_0x1a9801['filtersNodes']()),_0x80ba55=new Te(_0x2c6c57,_0x4c409e['isFullyInitialized'](),_0x219599['filtersNodes']());this['viewCache_']=Un(_0x80ba55,_0xe97c93),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x41daec){return _0x41daec['viewCache_']['serverCache']['getNode']();}function Lu(_0x24b883){return wn(_0x24b883['viewCache_']);}function xu(_0x280775,_0x576c4c){const _0x3a6c70=Ve(_0x280775['viewCache_']);return _0x3a6c70&&(_0x280775['query']['_queryParams']['loadsAllData']()||!v(_0x576c4c)&&!_0x3a6c70['getImmediateChild'](y(_0x576c4c))['isEmpty']())?_0x3a6c70['getChild'](_0x576c4c):null;}function ur(_0x1bf09a){return _0x1bf09a['eventRegistrations_']['length']===0x0;}function Fu(_0x72a83c,_0x30f788){_0x72a83c['eventRegistrations_']['push'](_0x30f788);}function dr(_0x4c936d,_0x577fbd,_0x192a3f){const _0x46d48c=[];if(_0x192a3f){f(_0x577fbd==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x14a012=_0x4c936d['query']['_path'];_0x4c936d['eventRegistrations_']['forEach'](_0x374859=>{const _0x4c95c0=_0x374859['createCancelEvent'](_0x192a3f,_0x14a012);_0x4c95c0&&_0x46d48c['push'](_0x4c95c0);});}if(_0x577fbd){let _0x220ab3=[];for(let _0xa93a14=0x0;_0xa93a14<_0x4c936d['eventRegistrations_']['length'];++_0xa93a14){const _0x43e070=_0x4c936d['eventRegistrations_'][_0xa93a14];if(!_0x43e070['matches'](_0x577fbd))_0x220ab3['push'](_0x43e070);else{if(_0x577fbd['hasAnyCallback']()){_0x220ab3=_0x220ab3['concat'](_0x4c936d['eventRegistrations_']['slice'](_0xa93a14+0x1));break;}}}_0x4c936d['eventRegistrations_']=_0x220ab3;}else _0x4c936d['eventRegistrations_']=[];return _0x46d48c;}function fr(_0x14be9b,_0x5205e7,_0x591762,_0x1aaccf){_0x5205e7['type']===z['MERGE']&&_0x5205e7['source']['queryId']!==null&&(f(Ve(_0x14be9b['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x14be9b['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x44ff2e=_0x14be9b['viewCache_'],_0x315dde=Ru(_0x14be9b['processor_'],_0x44ff2e,_0x5205e7,_0x591762,_0x1aaccf);return bu(_0x14be9b['processor_'],_0x315dde['viewCache']),f(_0x315dde['viewCache']['serverCache']['isFullyInitialized']()||!_0x44ff2e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x14be9b['viewCache_']=_0x315dde['viewCache'],qo(_0x14be9b,_0x315dde['changes'],_0x315dde['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x4cb1a7,_0x8b9f42){const _0x318139=_0x4cb1a7['viewCache_']['eventCache'],_0x11e0ea=[];return _0x318139['getNode']()['isLeafNode']()||_0x318139['getNode']()['forEachChild'](R,(_0x191d68,_0x446fde)=>{_0x11e0ea['push'](rt(_0x191d68,_0x446fde));}),_0x318139['isFullyInitialized']()&&_0x11e0ea['push'](Lo(_0x318139['getNode']())),qo(_0x4cb1a7,_0x11e0ea,_0x318139['getNode'](),_0x8b9f42);}function qo(_0x37ce32,_0x540ade,_0x1650ae,_0xc514b8){const _0x1ace65=_0xc514b8?[_0xc514b8]:_0x37ce32['eventRegistrations_'];return ru(_0x37ce32['eventGenerator_'],_0x540ade,_0x1650ae,_0x1ace65);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x3848ba){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x3848ba;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0xba903c){return _0xba903c['views']['size']===0x0;}function os(_0x4b0910,_0x4c9512,_0xe279b6,_0x591dfd){const _0x3cc9d5=_0x4c9512['source']['queryId'];if(_0x3cc9d5!==null){const _0x1edd95=_0x4b0910['views']['get'](_0x3cc9d5);return f(_0x1edd95!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x1edd95,_0x4c9512,_0xe279b6,_0x591dfd);}else{let _0x397c95=[];for(const _0x5830b4 of _0x4b0910['views']['values']())_0x397c95=_0x397c95['concat'](fr(_0x5830b4,_0x4c9512,_0xe279b6,_0x591dfd));return _0x397c95;}}function jo(_0x2eb2c9,_0x4a68f8,_0x15c0c6,_0x3fb66f,_0x1e34bd){const _0x19e6a8=_0x4a68f8['_queryIdentifier'],_0x566a5f=_0x2eb2c9['views']['get'](_0x19e6a8);if(!_0x566a5f){let _0x4802b3=Cn(_0x15c0c6,_0x1e34bd?_0x3fb66f:null),_0x7e158a=!0x1;_0x4802b3?_0x7e158a=!0x0:_0x3fb66f instanceof g?(_0x4802b3=is(_0x15c0c6,_0x3fb66f),_0x7e158a=!0x1):(_0x4802b3=g['EMPTY_NODE'],_0x7e158a=!0x1);const _0x5f573b=Un(new Te(_0x4802b3,_0x7e158a,!0x1),new Te(_0x3fb66f,_0x1e34bd,!0x1));return new Du(_0x4a68f8,_0x5f573b);}return _0x566a5f;}function Hu(_0x55f81c,_0x3e062c,_0x5a2c46,_0x425828,_0x3b62d0,_0x233146){const _0x977d51=jo(_0x55f81c,_0x3e062c,_0x425828,_0x3b62d0,_0x233146);return _0x55f81c['views']['has'](_0x3e062c['_queryIdentifier'])||_0x55f81c['views']['set'](_0x3e062c['_queryIdentifier'],_0x977d51),Fu(_0x977d51,_0x5a2c46),Uu(_0x977d51,_0x5a2c46);}function $u(_0x2e688d,_0x3cfc80,_0x23054e,_0x4b847a){const _0x4141dd=_0x3cfc80['_queryIdentifier'],_0x427b75=[];let _0xf6fcab=[];const _0x3b19cc=Se(_0x2e688d);if(_0x4141dd==='default'){for(const [_0x65cce4,_0x753b23]of _0x2e688d['views']['entries']())_0xf6fcab=_0xf6fcab['concat'](dr(_0x753b23,_0x23054e,_0x4b847a)),ur(_0x753b23)&&(_0x2e688d['views']['delete'](_0x65cce4),_0x753b23['query']['_queryParams']['loadsAllData']()||_0x427b75['push'](_0x753b23['query']));}else{const _0x365bc0=_0x2e688d['views']['get'](_0x4141dd);_0x365bc0&&(_0xf6fcab=_0xf6fcab['concat'](dr(_0x365bc0,_0x23054e,_0x4b847a)),ur(_0x365bc0)&&(_0x2e688d['views']['delete'](_0x4141dd),_0x365bc0['query']['_queryParams']['loadsAllData']()||_0x427b75['push'](_0x365bc0['query'])));}return _0x3b19cc&&!Se(_0x2e688d)&&_0x427b75['push'](new(Bu())(_0x3cfc80['_repo'],_0x3cfc80['_path'])),{'removed':_0x427b75,'events':_0xf6fcab};}function Ko(_0x206a27){const _0x2bb626=[];for(const _0x29effd of _0x206a27['views']['values']())_0x29effd['query']['_queryParams']['loadsAllData']()||_0x2bb626['push'](_0x29effd);return _0x2bb626;}function Ie(_0x1e798f,_0x2be07c){let _0x2e0b82=null;for(const _0x496933 of _0x1e798f['views']['values']())_0x2e0b82=_0x2e0b82||xu(_0x496933,_0x2be07c);return _0x2e0b82;}function Yo(_0x4325d6,_0x95d61a){if(_0x95d61a['_queryParams']['loadsAllData']())return Bn(_0x4325d6);{const _0x4ebc04=_0x95d61a['_queryIdentifier'];return _0x4325d6['views']['get'](_0x4ebc04);}}function Qo(_0x324752,_0x2831cd){return Yo(_0x324752,_0x2831cd)!=null;}function Se(_0x18c073){return Bn(_0x18c073)!=null;}function Bn(_0x6e4504){for(const _0xd12dd1 of _0x6e4504['views']['values']())if(_0xd12dd1['query']['_queryParams']['loadsAllData']())return _0xd12dd1;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x36aa1e){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x36aa1e;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xab761f){this['listenProvider_']=_0xab761f,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x38c6f4,_0x565192,_0xdc406f,_0x4757b6,_0x3cad2e){return lu(_0x38c6f4['pendingWriteTree_'],_0x565192,_0xdc406f,_0x4757b6,_0x3cad2e),_0x3cad2e?_t(_0x38c6f4,new Be(es(),_0x565192,_0xdc406f)):[];}function ju(_0x18b368,_0x3a4f01,_0xbb140a,_0x1a740d){hu(_0x18b368['pendingWriteTree_'],_0x3a4f01,_0xbb140a,_0x1a740d);const _0x5b0b97=b['fromObject'](_0xbb140a);return _t(_0x18b368,new ot(es(),_0x3a4f01,_0x5b0b97));}function _e(_0xa09286,_0x2c781c,_0x1c4877=!0x1){const _0x40ad68=uu(_0xa09286['pendingWriteTree_'],_0x2c781c);if(du(_0xa09286['pendingWriteTree_'],_0x2c781c)){let _0xeeaf65=new b(null);return _0x40ad68['snap']!=null?_0xeeaf65=_0xeeaf65['set'](w(),!0x0):x(_0x40ad68['children'],_0xd9977f=>{_0xeeaf65=_0xeeaf65['set'](new C(_0xd9977f),!0x0);}),_t(_0xa09286,new In(_0x40ad68['path'],_0xeeaf65,_0x1c4877));}else return[];}function Yt(_0x1c776d,_0x29734a,_0x2fdd35){return _t(_0x1c776d,new Be(ts(),_0x29734a,_0x2fdd35));}function Ku(_0x527326,_0x4e25a2,_0x4b409e){const _0x2dc1e7=b['fromObject'](_0x4b409e);return _t(_0x527326,new ot(ts(),_0x4e25a2,_0x2dc1e7));}function Yu(_0x562e3c,_0x3a382b){return _t(_0x562e3c,new Ut(ts(),_0x3a382b));}function Qu(_0x21d7d9,_0xa0f701,_0x2de871){const _0x467e44=cs(_0x21d7d9,_0x2de871);if(_0x467e44){const _0x3fd6c2=ls(_0x467e44),_0x23a510=_0x3fd6c2['path'],_0x5b04fa=_0x3fd6c2['queryId'],_0x2baba4=F(_0x23a510,_0xa0f701),_0x4a2a5c=new Ut(ns(_0x5b04fa),_0x2baba4);return hs(_0x21d7d9,_0x23a510,_0x4a2a5c);}else return[];}function An(_0x253e06,_0x394787,_0x284321,_0x5c9b63,_0x41737c=!0x1){const _0x22634d=_0x394787['_path'],_0x403901=_0x253e06['syncPointTree_']['get'](_0x22634d);let _0x432187=[];if(_0x403901&&(_0x394787['_queryIdentifier']==='default'||Qo(_0x403901,_0x394787))){const _0x2fa1db=$u(_0x403901,_0x394787,_0x284321,_0x5c9b63);Vu(_0x403901)&&(_0x253e06['syncPointTree_']=_0x253e06['syncPointTree_']['remove'](_0x22634d));const _0x209d47=_0x2fa1db['removed'];if(_0x432187=_0x2fa1db['events'],!_0x41737c){const _0x50a854=_0x209d47['findIndex'](_0x54a4fa=>_0x54a4fa['_queryParams']['loadsAllData']())!==-0x1,_0x5dddd9=_0x253e06['syncPointTree_']['findOnPath'](_0x22634d,(_0x15123c,_0x1da32b)=>Se(_0x1da32b));if(_0x50a854&&!_0x5dddd9){const _0x480245=_0x253e06['syncPointTree_']['subtree'](_0x22634d);if(!_0x480245['isEmpty']()){const _0x310c36=Zu(_0x480245);for(let _0x41cb30=0x0;_0x41cb30<_0x310c36['length'];++_0x41cb30){const _0x11bdee=_0x310c36[_0x41cb30],_0xe1a8f2=_0x11bdee['query'],_0x189161=ea(_0x253e06,_0x11bdee);_0x253e06['listenProvider_']['startListening'](kt(_0xe1a8f2),Wt(_0x253e06,_0xe1a8f2),_0x189161['hashFn'],_0x189161['onComplete']);}}}!_0x5dddd9&&_0x209d47['length']>0x0&&!_0x5c9b63&&(_0x50a854?_0x253e06['listenProvider_']['stopListening'](kt(_0x394787),null):_0x209d47['forEach'](_0x4be307=>{const _0x40d36f=_0x253e06['queryToTagMap']['get'](Hn(_0x4be307));_0x253e06['listenProvider_']['stopListening'](kt(_0x4be307),_0x40d36f);}));}ed(_0x253e06,_0x209d47);}return _0x432187;}function Jo(_0x8f6e31,_0x46f67b,_0x523ef6,_0x27a198){const _0x5a1269=cs(_0x8f6e31,_0x27a198);if(_0x5a1269!=null){const _0x4e28af=ls(_0x5a1269),_0x16ae31=_0x4e28af['path'],_0x304414=_0x4e28af['queryId'],_0x2dacd4=F(_0x16ae31,_0x46f67b),_0x466b8d=new Be(ns(_0x304414),_0x2dacd4,_0x523ef6);return hs(_0x8f6e31,_0x16ae31,_0x466b8d);}else return[];}function Ju(_0x493f6a,_0x11cd77,_0x366b44,_0x327542){const _0x184208=cs(_0x493f6a,_0x327542);if(_0x184208){const _0x2ed501=ls(_0x184208),_0x2c08e5=_0x2ed501['path'],_0xa716f8=_0x2ed501['queryId'],_0x119492=F(_0x2c08e5,_0x11cd77),_0x16dd7d=b['fromObject'](_0x366b44),_0x3c89e8=new ot(ns(_0xa716f8),_0x119492,_0x16dd7d);return hs(_0x493f6a,_0x2c08e5,_0x3c89e8);}else return[];}function Ni(_0x55abe8,_0x1e8b97,_0x5020ed,_0x2b7339=!0x1){const _0x28428a=_0x1e8b97['_path'];let _0x1893a3=null,_0x587254=!0x1;_0x55abe8['syncPointTree_']['foreachOnPath'](_0x28428a,(_0x4fb223,_0x3d7362)=>{const _0x18b954=F(_0x4fb223,_0x28428a);_0x1893a3=_0x1893a3||Ie(_0x3d7362,_0x18b954),_0x587254=_0x587254||Se(_0x3d7362);});let _0xf06106=_0x55abe8['syncPointTree_']['get'](_0x28428a);_0xf06106?(_0x587254=_0x587254||Se(_0xf06106),_0x1893a3=_0x1893a3||Ie(_0xf06106,w())):(_0xf06106=new zo(),_0x55abe8['syncPointTree_']=_0x55abe8['syncPointTree_']['set'](_0x28428a,_0xf06106));let _0x961c8;_0x1893a3!=null?_0x961c8=!0x0:(_0x961c8=!0x1,_0x1893a3=g['EMPTY_NODE'],_0x55abe8['syncPointTree_']['subtree'](_0x28428a)['foreachChild']((_0x93464b,_0x4f3f04)=>{const _0x365005=Ie(_0x4f3f04,w());_0x365005&&(_0x1893a3=_0x1893a3['updateImmediateChild'](_0x93464b,_0x365005));}));const _0x5b8da0=Qo(_0xf06106,_0x1e8b97);if(!_0x5b8da0&&!_0x1e8b97['_queryParams']['loadsAllData']()){const _0x1fe8e3=Hn(_0x1e8b97);f(!_0x55abe8['queryToTagMap']['has'](_0x1fe8e3),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x20f8d1=td();_0x55abe8['queryToTagMap']['set'](_0x1fe8e3,_0x20f8d1),_0x55abe8['tagToQueryMap']['set'](_0x20f8d1,_0x1fe8e3);}const _0x47aa9f=Wn(_0x55abe8['pendingWriteTree_'],_0x28428a);let _0x38d3f2=Hu(_0xf06106,_0x1e8b97,_0x5020ed,_0x47aa9f,_0x1893a3,_0x961c8);if(!_0x5b8da0&&!_0x587254&&!_0x2b7339){const _0x2c8bd5=Yo(_0xf06106,_0x1e8b97);_0x38d3f2=_0x38d3f2['concat'](nd(_0x55abe8,_0x1e8b97,_0x2c8bd5));}return _0x38d3f2;}function Vn(_0x1d6966,_0x26ee09,_0x162cd9){const _0x57b8b6=_0x1d6966['pendingWriteTree_'],_0x10bda1=_0x1d6966['syncPointTree_']['findOnPath'](_0x26ee09,(_0x293a53,_0x2a93db)=>{const _0x380dcc=F(_0x293a53,_0x26ee09),_0x4d2614=Ie(_0x2a93db,_0x380dcc);if(_0x4d2614)return _0x4d2614;});return Bo(_0x57b8b6,_0x26ee09,_0x10bda1,_0x162cd9,!0x0);}function Xu(_0x50e5b6,_0x5bec8b){const _0x4cf38b=_0x5bec8b['_path'];let _0x45eb6d=null;_0x50e5b6['syncPointTree_']['foreachOnPath'](_0x4cf38b,(_0x80f20d,_0xbe6a2d)=>{const _0x297115=F(_0x80f20d,_0x4cf38b);_0x45eb6d=_0x45eb6d||Ie(_0xbe6a2d,_0x297115);});let _0x207718=_0x50e5b6['syncPointTree_']['get'](_0x4cf38b);_0x207718?_0x45eb6d=_0x45eb6d||Ie(_0x207718,w()):(_0x207718=new zo(),_0x50e5b6['syncPointTree_']=_0x50e5b6['syncPointTree_']['set'](_0x4cf38b,_0x207718));const _0x11819d=_0x45eb6d!=null,_0x137961=_0x11819d?new Te(_0x45eb6d,!0x0,!0x1):null,_0x42467a=Wn(_0x50e5b6['pendingWriteTree_'],_0x5bec8b['_path']),_0x201f14=jo(_0x207718,_0x5bec8b,_0x42467a,_0x11819d?_0x137961['getNode']():g['EMPTY_NODE'],_0x11819d);return Lu(_0x201f14);}function _t(_0xffc21a,_0x5ae9dc){return Xo(_0x5ae9dc,_0xffc21a['syncPointTree_'],null,Wn(_0xffc21a['pendingWriteTree_'],w()));}function Xo(_0x5895b4,_0x5c27e3,_0x50f7a4,_0x3d23ae){if(v(_0x5895b4['path']))return Zo(_0x5895b4,_0x5c27e3,_0x50f7a4,_0x3d23ae);{const _0x205e57=_0x5c27e3['get'](w());_0x50f7a4==null&&_0x205e57!=null&&(_0x50f7a4=Ie(_0x205e57,w()));let _0x1e264e=[];const _0x278624=y(_0x5895b4['path']),_0x3c7230=_0x5895b4['operationForChild'](_0x278624),_0x348d18=_0x5c27e3['children']['get'](_0x278624);if(_0x348d18&&_0x3c7230){const _0x2e30c1=_0x50f7a4?_0x50f7a4['getImmediateChild'](_0x278624):null,_0x43faba=Vo(_0x3d23ae,_0x278624);_0x1e264e=_0x1e264e['concat'](Xo(_0x3c7230,_0x348d18,_0x2e30c1,_0x43faba));}return _0x205e57&&(_0x1e264e=_0x1e264e['concat'](os(_0x205e57,_0x5895b4,_0x3d23ae,_0x50f7a4))),_0x1e264e;}}function Zo(_0x42777c,_0x546ef4,_0x1f1fad,_0x2aa2c1){const _0xb3077e=_0x546ef4['get'](w());_0x1f1fad==null&&_0xb3077e!=null&&(_0x1f1fad=Ie(_0xb3077e,w()));let _0x30d56e=[];return _0x546ef4['children']['inorderTraversal']((_0x401eaf,_0x2144bc)=>{const _0xce28b1=_0x1f1fad?_0x1f1fad['getImmediateChild'](_0x401eaf):null,_0x91eeec=Vo(_0x2aa2c1,_0x401eaf),_0x35972d=_0x42777c['operationForChild'](_0x401eaf);_0x35972d&&(_0x30d56e=_0x30d56e['concat'](Zo(_0x35972d,_0x2144bc,_0xce28b1,_0x91eeec)));}),_0xb3077e&&(_0x30d56e=_0x30d56e['concat'](os(_0xb3077e,_0x42777c,_0x2aa2c1,_0x1f1fad))),_0x30d56e;}function ea(_0x520910,_0x3dc3e7){const _0x421638=_0x3dc3e7['query'],_0x476d54=Wt(_0x520910,_0x421638);return{'hashFn':()=>(Mu(_0x3dc3e7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1b8726=>{if(_0x1b8726==='ok')return _0x476d54?Qu(_0x520910,_0x421638['_path'],_0x476d54):Yu(_0x520910,_0x421638['_path']);{const _0x1350b4=Kl(_0x1b8726,_0x421638);return An(_0x520910,_0x421638,null,_0x1350b4);}}};}function Wt(_0x20262d,_0x4be161){const _0x4a758f=Hn(_0x4be161);return _0x20262d['queryToTagMap']['get'](_0x4a758f);}function Hn(_0x54dc46){return _0x54dc46['_path']['toString']()+'$'+_0x54dc46['_queryIdentifier'];}function cs(_0x3aafbb,_0x57cfe2){return _0x3aafbb['tagToQueryMap']['get'](_0x57cfe2);}function ls(_0xf34f56){const _0x13b714=_0xf34f56['indexOf']('$');return f(_0x13b714!==-0x1&&_0x13b714<_0xf34f56['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0xf34f56['substr'](_0x13b714+0x1),'path':new C(_0xf34f56['substr'](0x0,_0x13b714))};}function hs(_0x5e9cf6,_0x42b4ac,_0x21491c){const _0x2e5ed0=_0x5e9cf6['syncPointTree_']['get'](_0x42b4ac);f(_0x2e5ed0,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4db38d=Wn(_0x5e9cf6['pendingWriteTree_'],_0x42b4ac);return os(_0x2e5ed0,_0x21491c,_0x4db38d,null);}function Zu(_0x4f5438){return _0x4f5438['fold']((_0x514c8d,_0x2e1044,_0x37adcc)=>{if(_0x2e1044&&Se(_0x2e1044))return[Bn(_0x2e1044)];{let _0x556f91=[];return _0x2e1044&&(_0x556f91=Ko(_0x2e1044)),x(_0x37adcc,(_0x19cd62,_0x3767ae)=>{_0x556f91=_0x556f91['concat'](_0x3767ae);}),_0x556f91;}});}function kt(_0x452817){return _0x452817['_queryParams']['loadsAllData']()&&!_0x452817['_queryParams']['isDefault']()?new(qu())(_0x452817['_repo'],_0x452817['_path']):_0x452817;}function ed(_0x3faf6b,_0xaec7db){for(let _0x5c8349=0x0;_0x5c8349<_0xaec7db['length'];++_0x5c8349){const _0x37d4c=_0xaec7db[_0x5c8349];if(!_0x37d4c['_queryParams']['loadsAllData']()){const _0x35f6db=Hn(_0x37d4c),_0x533b4b=_0x3faf6b['queryToTagMap']['get'](_0x35f6db);_0x3faf6b['queryToTagMap']['delete'](_0x35f6db),_0x3faf6b['tagToQueryMap']['delete'](_0x533b4b);}}}function td(){return zu++;}function nd(_0x14a39e,_0x2ff4ff,_0x5ca8fb){const _0x30dad2=_0x2ff4ff['_path'],_0x318dc5=Wt(_0x14a39e,_0x2ff4ff),_0x491309=ea(_0x14a39e,_0x5ca8fb),_0x3e5fa=_0x14a39e['listenProvider_']['startListening'](kt(_0x2ff4ff),_0x318dc5,_0x491309['hashFn'],_0x491309['onComplete']),_0x19904a=_0x14a39e['syncPointTree_']['subtree'](_0x30dad2);if(_0x318dc5)f(!Se(_0x19904a['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x58debe=_0x19904a['fold']((_0x192456,_0x11f2d7,_0x5a03f5)=>{if(!v(_0x192456)&&_0x11f2d7&&Se(_0x11f2d7))return[Bn(_0x11f2d7)['query']];{let _0x732ad=[];return _0x11f2d7&&(_0x732ad=_0x732ad['concat'](Ko(_0x11f2d7)['map'](_0x376ba8=>_0x376ba8['query']))),x(_0x5a03f5,(_0x1e6b6d,_0x195ad7)=>{_0x732ad=_0x732ad['concat'](_0x195ad7);}),_0x732ad;}});for(let _0x1e23bb=0x0;_0x1e23bb<_0x58debe['length'];++_0x1e23bb){const _0x3f79a2=_0x58debe[_0x1e23bb];_0x14a39e['listenProvider_']['stopListening'](kt(_0x3f79a2),Wt(_0x14a39e,_0x3f79a2));}}return _0x3e5fa;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x4b7db5){this['node_']=_0x4b7db5;}['getImmediateChild'](_0x4244d3){const _0x45777d=this['node_']['getImmediateChild'](_0x4244d3);return new us(_0x45777d);}['node'](){return this['node_'];}}class ds{constructor(_0x41e2e4,_0x1d8d85){this['syncTree_']=_0x41e2e4,this['path_']=_0x1d8d85;}['getImmediateChild'](_0x1f802c){const _0x34bf5e=k(this['path_'],_0x1f802c);return new ds(this['syncTree_'],_0x34bf5e);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x550619){return _0x550619=_0x550619||{},_0x550619['timestamp']=_0x550619['timestamp']||new Date()['getTime'](),_0x550619;},_r=function(_0x31f0c9,_0x137baf,_0x429083){if(!_0x31f0c9||typeof _0x31f0c9!='object')return _0x31f0c9;if(f('.sv'in _0x31f0c9,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x31f0c9['.sv']=='string')return sd(_0x31f0c9['.sv'],_0x137baf,_0x429083);if(typeof _0x31f0c9['.sv']=='object')return rd(_0x31f0c9['.sv'],_0x137baf);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x31f0c9,null,0x2));},sd=function(_0x5a93cd,_0xc62864,_0x3dc0b4){switch(_0x5a93cd){case'timestamp':return _0x3dc0b4['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x5a93cd);}},rd=function(_0x1df575,_0xa8119,_0x745d95){_0x1df575['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1df575,null,0x2));const _0x19d9a0=_0x1df575['increment'];typeof _0x19d9a0!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x19d9a0);const _0x1ae9ea=_0xa8119['node']();if(f(_0x1ae9ea!==null&&typeof _0x1ae9ea<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1ae9ea['isLeafNode']())return _0x19d9a0;const _0x5bf651=_0x1ae9ea['getValue']();return typeof _0x5bf651!='number'?_0x19d9a0:_0x5bf651+_0x19d9a0;},ta=function(_0x3e4edd,_0x48e6c2,_0x2c926e,_0x1f7ae3){return ps(_0x48e6c2,new ds(_0x2c926e,_0x3e4edd),_0x1f7ae3);},fs=function(_0x41401a,_0xd6001c,_0x4c5788){return ps(_0x41401a,new us(_0xd6001c),_0x4c5788);};function ps(_0xacc2d5,_0x39b62f,_0x117cb1){const _0xd03bac=_0xacc2d5['getPriority']()['val'](),_0xaccdb6=_r(_0xd03bac,_0x39b62f['getImmediateChild']('.priority'),_0x117cb1);let _0x2ed6da;if(_0xacc2d5['isLeafNode']()){const _0x1ad1ec=_0xacc2d5,_0x2521f2=_r(_0x1ad1ec['getValue'](),_0x39b62f,_0x117cb1);return _0x2521f2!==_0x1ad1ec['getValue']()||_0xaccdb6!==_0x1ad1ec['getPriority']()['val']()?new D(_0x2521f2,A(_0xaccdb6)):_0xacc2d5;}else{const _0x22e511=_0xacc2d5;return _0x2ed6da=_0x22e511,_0xaccdb6!==_0x22e511['getPriority']()['val']()&&(_0x2ed6da=_0x2ed6da['updatePriority'](new D(_0xaccdb6))),_0x22e511['forEachChild'](R,(_0x13b08d,_0x3d6dd9)=>{const _0x4435a0=ps(_0x3d6dd9,_0x39b62f['getImmediateChild'](_0x13b08d),_0x117cb1);_0x4435a0!==_0x3d6dd9&&(_0x2ed6da=_0x2ed6da['updateImmediateChild'](_0x13b08d,_0x4435a0));}),_0x2ed6da;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x40957e='',_0x407260=null,_0x171e63={'children':{},'childCount':0x0}){this['name']=_0x40957e,this['parent']=_0x407260,this['node']=_0x171e63;}}function $n(_0x1b2075,_0x34a2dd){let _0x3b14dd=_0x34a2dd instanceof C?_0x34a2dd:new C(_0x34a2dd),_0xfb506e=_0x1b2075,_0x2839ab=y(_0x3b14dd);for(;_0x2839ab!==null;){const _0x3114e3=Le(_0xfb506e['node']['children'],_0x2839ab)||{'children':{},'childCount':0x0};_0xfb506e=new _s(_0x2839ab,_0xfb506e,_0x3114e3),_0x3b14dd=S(_0x3b14dd),_0x2839ab=y(_0x3b14dd);}return _0xfb506e;}function je(_0x3b59f5){return _0x3b59f5['node']['value'];}function gs(_0x3df983,_0x36b336){_0x3df983['node']['value']=_0x36b336,Oi(_0x3df983);}function na(_0x386b06){return _0x386b06['node']['childCount']>0x0;}function od(_0x1cf0b1){return je(_0x1cf0b1)===void 0x0&&!na(_0x1cf0b1);}function Gn(_0x56736a,_0xe11be7){x(_0x56736a['node']['children'],(_0x5c2bfd,_0x50a8e9)=>{_0xe11be7(new _s(_0x5c2bfd,_0x56736a,_0x50a8e9));});}function ia(_0x4d6842,_0x26df4c,_0x399988,_0x2ff6e5){_0x399988&&_0x26df4c(_0x4d6842),Gn(_0x4d6842,_0x1e6c04=>{ia(_0x1e6c04,_0x26df4c,!0x0);});}function ad(_0xcd3b18,_0x5cc17f,_0x978e01){let _0x5150e2=_0xcd3b18['parent'];for(;_0x5150e2!==null;){if(_0x5cc17f(_0x5150e2))return!0x0;_0x5150e2=_0x5150e2['parent'];}return!0x1;}function Qt(_0x3349c9){return new C(_0x3349c9['parent']===null?_0x3349c9['name']:Qt(_0x3349c9['parent'])+'/'+_0x3349c9['name']);}function Oi(_0x3ec7aa){_0x3ec7aa['parent']!==null&&cd(_0x3ec7aa['parent'],_0x3ec7aa['name'],_0x3ec7aa);}function cd(_0x10ffc1,_0x34c89d,_0x4c096f){const _0x393f95=od(_0x4c096f),_0x1081fa=Q(_0x10ffc1['node']['children'],_0x34c89d);_0x393f95&&_0x1081fa?(delete _0x10ffc1['node']['children'][_0x34c89d],_0x10ffc1['node']['childCount']--,Oi(_0x10ffc1)):!_0x393f95&&!_0x1081fa&&(_0x10ffc1['node']['children'][_0x34c89d]=_0x4c096f['node'],_0x10ffc1['node']['childCount']++,Oi(_0x10ffc1));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x1d4a82){return typeof _0x1d4a82=='string'&&_0x1d4a82['length']!==0x0&&!ld['test'](_0x1d4a82);},sa=function(_0xe84d7b){return typeof _0xe84d7b=='string'&&_0xe84d7b['length']!==0x0&&!hd['test'](_0xe84d7b);},ud=function(_0x435d49){return _0x435d49&&(_0x435d49=_0x435d49['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x435d49);},Bt=function(_0x4efccf){return _0x4efccf===null||typeof _0x4efccf=='string'||typeof _0x4efccf=='number'&&!xn(_0x4efccf)||_0x4efccf&&typeof _0x4efccf=='object'&&Q(_0x4efccf,'.sv');},He=function(_0x4e8bb5,_0x4e8359,_0x4afa2b,_0x51a743){_0x51a743&&_0x4e8359===void 0x0||Jt(it(_0x4e8bb5,'value'),_0x4e8359,_0x4afa2b);},Jt=function(_0x174932,_0x3ab25b,_0x145c5f){const _0x35c980=_0x145c5f instanceof C?new Ah(_0x145c5f,_0x174932):_0x145c5f;if(_0x3ab25b===void 0x0)throw new Error(_0x174932+'contains\x20undefined\x20'+Oe(_0x35c980));if(typeof _0x3ab25b=='function')throw new Error(_0x174932+'contains\x20a\x20function\x20'+Oe(_0x35c980)+'\x20with\x20contents\x20=\x20'+_0x3ab25b['toString']());if(xn(_0x3ab25b))throw new Error(_0x174932+'contains\x20'+_0x3ab25b['toString']()+'\x20'+Oe(_0x35c980));if(typeof _0x3ab25b=='string'&&_0x3ab25b['length']>ui/0x3&&Ln(_0x3ab25b)>ui)throw new Error(_0x174932+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x35c980)+'\x20(\x27'+_0x3ab25b['substring'](0x0,0x32)+'...\x27)');if(_0x3ab25b&&typeof _0x3ab25b=='object'){let _0x2f266a=!0x1,_0x41fcbe=!0x1;if(x(_0x3ab25b,(_0x52338a,_0x155715)=>{if(_0x52338a==='.value')_0x2f266a=!0x0;else{if(_0x52338a!=='.priority'&&_0x52338a!=='.sv'&&(_0x41fcbe=!0x0,!ms(_0x52338a)))throw new Error(_0x174932+'\x20contains\x20an\x20invalid\x20key\x20('+_0x52338a+')\x20'+Oe(_0x35c980)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x35c980,_0x52338a),Jt(_0x174932,_0x155715,_0x35c980),Ph(_0x35c980);}),_0x2f266a&&_0x41fcbe)throw new Error(_0x174932+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x35c980)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x58bc8d,_0x436ce3){let _0x57d326,_0x2895a5;for(_0x57d326=0x0;_0x57d326<_0x436ce3['length'];_0x57d326++){_0x2895a5=_0x436ce3[_0x57d326];const _0x8609d4=Mt(_0x2895a5);for(let _0x166f94=0x0;_0x166f94<_0x8609d4['length'];_0x166f94++)if(!(_0x8609d4[_0x166f94]==='.priority'&&_0x166f94===_0x8609d4['length']-0x1)){if(!ms(_0x8609d4[_0x166f94]))throw new Error(_0x58bc8d+'contains\x20an\x20invalid\x20key\x20('+_0x8609d4[_0x166f94]+')\x20in\x20path\x20'+_0x2895a5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x436ce3['sort'](Rh);let _0x8e73f5=null;for(_0x57d326=0x0;_0x57d326<_0x436ce3['length'];_0x57d326++){if(_0x2895a5=_0x436ce3[_0x57d326],_0x8e73f5!==null&&G(_0x8e73f5,_0x2895a5))throw new Error(_0x58bc8d+'contains\x20a\x20path\x20'+_0x8e73f5['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2895a5['toString']());_0x8e73f5=_0x2895a5;}},ra=function(_0x109f52,_0x1434e6,_0x5b50e0,_0x2e5507){const _0x3949cf=it(_0x109f52,'values');if(!(_0x1434e6&&typeof _0x1434e6=='object')||Array['isArray'](_0x1434e6))throw new Error(_0x3949cf+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xb95150=[];x(_0x1434e6,(_0x2d07e8,_0x4862c3)=>{const _0x5548c2=new C(_0x2d07e8);if(Jt(_0x3949cf,_0x4862c3,k(_0x5b50e0,_0x5548c2)),ji(_0x5548c2)==='.priority'&&!Bt(_0x4862c3))throw new Error(_0x3949cf+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5548c2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xb95150['push'](_0x5548c2);}),dd(_0x3949cf,_0xb95150);},fd=function(_0x257dac,_0x1c2c34,_0x41ac27){if(xn(_0x1c2c34))throw new Error(it(_0x257dac,'priority')+'is\x20'+_0x1c2c34['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x1c2c34))throw new Error(it(_0x257dac,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x2b3a44,_0x4d53ac,_0x40c487,_0x1e095a){if(!sa(_0x40c487))throw new Error(it(_0x2b3a44,_0x4d53ac)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x40c487+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4ae791,_0x579186,_0x19f2e1,_0x4a979d){_0x19f2e1&&(_0x19f2e1=_0x19f2e1['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4ae791,_0x579186,_0x19f2e1);},Me=function(_0x113dcb,_0x5c38d5){if(y(_0x5c38d5)==='.info')throw new Error(_0x113dcb+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3c36f6,_0x25c8f8){const _0x16c644=_0x25c8f8['path']['toString']();if(typeof _0x25c8f8['repoInfo']['host']!='string'||_0x25c8f8['repoInfo']['host']['length']===0x0||!ms(_0x25c8f8['repoInfo']['namespace'])&&_0x25c8f8['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x16c644['length']!==0x0&&!ud(_0x16c644))throw new Error(it(_0x3c36f6,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x254620,_0x18d785){let _0x232df9=null;for(let _0x109edd=0x0;_0x109edd<_0x18d785['length'];_0x109edd++){const _0xd6aa3f=_0x18d785[_0x109edd],_0x45c4a7=_0xd6aa3f['getPath']();_0x232df9!==null&&!Ki(_0x45c4a7,_0x232df9['path'])&&(_0x254620['eventLists_']['push'](_0x232df9),_0x232df9=null),_0x232df9===null&&(_0x232df9={'events':[],'path':_0x45c4a7}),_0x232df9['events']['push'](_0xd6aa3f);}_0x232df9&&_0x254620['eventLists_']['push'](_0x232df9);}function oa(_0x2f201a,_0x365703,_0x2903b1){qn(_0x2f201a,_0x2903b1),aa(_0x2f201a,_0x4cc6ef=>Ki(_0x4cc6ef,_0x365703));}function V(_0x174dae,_0x50f1aa,_0x3167bd){qn(_0x174dae,_0x3167bd),aa(_0x174dae,_0x17ee27=>G(_0x17ee27,_0x50f1aa)||G(_0x50f1aa,_0x17ee27));}function aa(_0x5a41e4,_0x4154f8){_0x5a41e4['recursionDepth_']++;let _0x18c79a=!0x0;for(let _0x42f686=0x0;_0x42f686<_0x5a41e4['eventLists_']['length'];_0x42f686++){const _0x58e273=_0x5a41e4['eventLists_'][_0x42f686];if(_0x58e273){const _0x565661=_0x58e273['path'];_0x4154f8(_0x565661)?(md(_0x5a41e4['eventLists_'][_0x42f686]),_0x5a41e4['eventLists_'][_0x42f686]=null):_0x18c79a=!0x1;}}_0x18c79a&&(_0x5a41e4['eventLists_']=[]),_0x5a41e4['recursionDepth_']--;}function md(_0x96717){for(let _0x529a4d=0x0;_0x529a4d<_0x96717['events']['length'];_0x529a4d++){const _0x4eb8aa=_0x96717['events'][_0x529a4d];if(_0x4eb8aa!==null){_0x96717['events'][_0x529a4d]=null;const _0x43df40=_0x4eb8aa['getEventRunner']();St&&L('event:\x20'+_0x4eb8aa['toString']()),ft(_0x43df40);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x501696,_0x16bee0,_0xcea06b,_0x391210){this['repoInfo_']=_0x501696,this['forceRestClient_']=_0x16bee0,this['authTokenProvider_']=_0xcea06b,this['appCheckProvider_']=_0x391210,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4be602,_0x3a51d4,_0x37f27b){if(_0x4be602['stats_']=qi(_0x4be602['repoInfo_']),_0x4be602['forceRestClient_']||Xl())_0x4be602['server_']=new vn(_0x4be602['repoInfo_'],(_0x3ec32d,_0x3f40ca,_0x542c21,_0x4c4bdd)=>{gr(_0x4be602,_0x3ec32d,_0x3f40ca,_0x542c21,_0x4c4bdd);},_0x4be602['authTokenProvider_'],_0x4be602['appCheckProvider_']),setTimeout(()=>mr(_0x4be602,!0x0),0x0);else{if(typeof _0x37f27b<'u'&&_0x37f27b!==null){if(typeof _0x37f27b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x37f27b);}catch(_0x2a9db2){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x2a9db2);}}_0x4be602['persistentConnection_']=new se(_0x4be602['repoInfo_'],_0x3a51d4,(_0x6c5b5d,_0x220abe,_0x15fc63,_0x257421)=>{gr(_0x4be602,_0x6c5b5d,_0x220abe,_0x15fc63,_0x257421);},_0x4fac72=>{mr(_0x4be602,_0x4fac72);},_0x4e7d80=>{Id(_0x4be602,_0x4e7d80);},_0x4be602['authTokenProvider_'],_0x4be602['appCheckProvider_'],_0x37f27b),_0x4be602['server_']=_0x4be602['persistentConnection_'];}_0x4be602['authTokenProvider_']['addTokenChangeListener'](_0x5dc459=>{_0x4be602['server_']['refreshAuthToken'](_0x5dc459);}),_0x4be602['appCheckProvider_']['addTokenChangeListener'](_0xe764e2=>{_0x4be602['server_']['refreshAppCheckToken'](_0xe764e2['token']);}),_0x4be602['statsReporter_']=ih(_0x4be602['repoInfo_'],()=>new iu(_0x4be602['stats_'],_0x4be602['server_'])),_0x4be602['infoData_']=new Xh(),_0x4be602['infoSyncTree_']=new pr({'startListening':(_0x16350e,_0x232f1c,_0x47937e,_0x30788d)=>{let _0x521d9f=[];const _0x3633c5=_0x4be602['infoData_']['getNode'](_0x16350e['_path']);return _0x3633c5['isEmpty']()||(_0x521d9f=Yt(_0x4be602['infoSyncTree_'],_0x16350e['_path'],_0x3633c5),setTimeout(()=>{_0x30788d('ok');},0x0)),_0x521d9f;},'stopListening':()=>{}}),vs(_0x4be602,'connected',!0x1),_0x4be602['serverSyncTree_']=new pr({'startListening':(_0x1d68bf,_0x84bfe3,_0x5c1309,_0x3ccef7)=>(_0x4be602['server_']['listen'](_0x1d68bf,_0x5c1309,_0x84bfe3,(_0xf0b28a,_0x503c3a)=>{const _0x431338=_0x3ccef7(_0xf0b28a,_0x503c3a);V(_0x4be602['eventQueue_'],_0x1d68bf['_path'],_0x431338);}),[]),'stopListening':(_0xb5b314,_0x5f2f43)=>{_0x4be602['server_']['unlisten'](_0xb5b314,_0x5f2f43);}});}function la(_0x238515){const _0x15590d=_0x238515['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x15590d;}function Xt(_0x4d0c99){return id({'timestamp':la(_0x4d0c99)});}function gr(_0x34f00c,_0x191aeb,_0x16a83f,_0x3ff757,_0x24130a){_0x34f00c['dataUpdateCount']++;const _0x491fe5=new C(_0x191aeb);_0x16a83f=_0x34f00c['interceptServerDataCallback_']?_0x34f00c['interceptServerDataCallback_'](_0x191aeb,_0x16a83f):_0x16a83f;let _0x55aad6=[];if(_0x24130a){if(_0x3ff757){const _0x5b6f5a=_n(_0x16a83f,_0x20344d=>A(_0x20344d));_0x55aad6=Ju(_0x34f00c['serverSyncTree_'],_0x491fe5,_0x5b6f5a,_0x24130a);}else{const _0x2dad50=A(_0x16a83f);_0x55aad6=Jo(_0x34f00c['serverSyncTree_'],_0x491fe5,_0x2dad50,_0x24130a);}}else{if(_0x3ff757){const _0x2dc63c=_n(_0x16a83f,_0x379830=>A(_0x379830));_0x55aad6=Ku(_0x34f00c['serverSyncTree_'],_0x491fe5,_0x2dc63c);}else{const _0x4e2e7e=A(_0x16a83f);_0x55aad6=Yt(_0x34f00c['serverSyncTree_'],_0x491fe5,_0x4e2e7e);}}let _0x187d9b=_0x491fe5;_0x55aad6['length']>0x0&&(_0x187d9b=ct(_0x34f00c,_0x491fe5)),V(_0x34f00c['eventQueue_'],_0x187d9b,_0x55aad6);}function mr(_0x3d9133,_0x424afb){vs(_0x3d9133,'connected',_0x424afb),_0x424afb===!0x1&&Sd(_0x3d9133);}function Id(_0x2baa60,_0x343e75){x(_0x343e75,(_0x355e42,_0x4e10c6)=>{vs(_0x2baa60,_0x355e42,_0x4e10c6);});}function vs(_0x22b23f,_0x36ec37,_0x1598fc){const _0x121141=new C('/.info/'+_0x36ec37),_0x233133=A(_0x1598fc);_0x22b23f['infoData_']['updateSnapshot'](_0x121141,_0x233133);const _0x10bf57=Yt(_0x22b23f['infoSyncTree_'],_0x121141,_0x233133);V(_0x22b23f['eventQueue_'],_0x121141,_0x10bf57);}function zn(_0x5662fc){return _0x5662fc['nextWriteId_']++;}function wd(_0x21bd90,_0x4d5382,_0x5d632b){const _0x14b3cb=Xu(_0x21bd90['serverSyncTree_'],_0x4d5382);return _0x14b3cb!=null?Promise['resolve'](_0x14b3cb):_0x21bd90['server_']['get'](_0x4d5382)['then'](_0x3e705d=>{const _0x45edd4=A(_0x3e705d)['withIndex'](_0x4d5382['_queryParams']['getIndex']());Ni(_0x21bd90['serverSyncTree_'],_0x4d5382,_0x5d632b,!0x0);let _0x22b711;if(_0x4d5382['_queryParams']['loadsAllData']())_0x22b711=Yt(_0x21bd90['serverSyncTree_'],_0x4d5382['_path'],_0x45edd4);else{const _0x2ce1a1=Wt(_0x21bd90['serverSyncTree_'],_0x4d5382);_0x22b711=Jo(_0x21bd90['serverSyncTree_'],_0x4d5382['_path'],_0x45edd4,_0x2ce1a1);}return V(_0x21bd90['eventQueue_'],_0x4d5382['_path'],_0x22b711),An(_0x21bd90['serverSyncTree_'],_0x4d5382,_0x5d632b,null,!0x0),_0x45edd4;},_0x4c0d34=>(gt(_0x21bd90,'get\x20for\x20query\x20'+O(_0x4d5382)+'\x20failed:\x20'+_0x4c0d34),Promise['reject'](new Error(_0x4c0d34))));}function Cd(_0x3b9aa5,_0x4447c5,_0x2d7992,_0x37ed4f,_0x2b6261){gt(_0x3b9aa5,'set',{'path':_0x4447c5['toString'](),'value':_0x2d7992,'priority':_0x37ed4f});const _0x53aacb=Xt(_0x3b9aa5),_0x59316f=A(_0x2d7992,_0x37ed4f),_0x2b7bb0=Vn(_0x3b9aa5['serverSyncTree_'],_0x4447c5),_0x53d2c1=fs(_0x59316f,_0x2b7bb0,_0x53aacb),_0x2cd5ea=zn(_0x3b9aa5),_0x11e10c=as(_0x3b9aa5['serverSyncTree_'],_0x4447c5,_0x53d2c1,_0x2cd5ea,!0x0);qn(_0x3b9aa5['eventQueue_'],_0x11e10c),_0x3b9aa5['server_']['put'](_0x4447c5['toString'](),_0x59316f['val'](!0x0),(_0x2e336a,_0x5e0ed1)=>{const _0x2200f6=_0x2e336a==='ok';_0x2200f6||U('set\x20at\x20'+_0x4447c5+'\x20failed:\x20'+_0x2e336a);const _0x265601=_e(_0x3b9aa5['serverSyncTree_'],_0x2cd5ea,!_0x2200f6);V(_0x3b9aa5['eventQueue_'],_0x4447c5,_0x265601),be(_0x3b9aa5,_0x2b6261,_0x2e336a,_0x5e0ed1);});const _0x42e209=Is(_0x3b9aa5,_0x4447c5);ct(_0x3b9aa5,_0x42e209),V(_0x3b9aa5['eventQueue_'],_0x42e209,[]);}function Td(_0x18bb42,_0x1f5ed6,_0x458cf4,_0x390339){gt(_0x18bb42,'update',{'path':_0x1f5ed6['toString'](),'value':_0x458cf4});let _0x47d335=!0x0;const _0x5c0457=Xt(_0x18bb42),_0x47c9c4={};if(x(_0x458cf4,(_0x2f1b8c,_0x3b077e)=>{_0x47d335=!0x1,_0x47c9c4[_0x2f1b8c]=ta(k(_0x1f5ed6,_0x2f1b8c),A(_0x3b077e),_0x18bb42['serverSyncTree_'],_0x5c0457);}),_0x47d335)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x18bb42,_0x390339,'ok',void 0x0);else{const _0x2b43ea=zn(_0x18bb42),_0x3f22f0=ju(_0x18bb42['serverSyncTree_'],_0x1f5ed6,_0x47c9c4,_0x2b43ea);qn(_0x18bb42['eventQueue_'],_0x3f22f0),_0x18bb42['server_']['merge'](_0x1f5ed6['toString'](),_0x458cf4,(_0x35cdf9,_0x126d97)=>{const _0xf09284=_0x35cdf9==='ok';_0xf09284||U('update\x20at\x20'+_0x1f5ed6+'\x20failed:\x20'+_0x35cdf9);const _0x3f6c79=_e(_0x18bb42['serverSyncTree_'],_0x2b43ea,!_0xf09284),_0x554472=_0x3f6c79['length']>0x0?ct(_0x18bb42,_0x1f5ed6):_0x1f5ed6;V(_0x18bb42['eventQueue_'],_0x554472,_0x3f6c79),be(_0x18bb42,_0x390339,_0x35cdf9,_0x126d97);}),x(_0x458cf4,_0x8c8cf3=>{const _0x8f19c1=Is(_0x18bb42,k(_0x1f5ed6,_0x8c8cf3));ct(_0x18bb42,_0x8f19c1);}),V(_0x18bb42['eventQueue_'],_0x1f5ed6,[]);}}function Sd(_0x4923ab){gt(_0x4923ab,'onDisconnectEvents');const _0x3fba1c=Xt(_0x4923ab),_0xc7e2d9=En();Si(_0x4923ab['onDisconnect_'],w(),(_0x40c471,_0x20abbb)=>{const _0xe06435=ta(_0x40c471,_0x20abbb,_0x4923ab['serverSyncTree_'],_0x3fba1c);pt(_0xc7e2d9,_0x40c471,_0xe06435);});let _0x2aec67=[];Si(_0xc7e2d9,w(),(_0x1d31d2,_0x93434e)=>{_0x2aec67=_0x2aec67['concat'](Yt(_0x4923ab['serverSyncTree_'],_0x1d31d2,_0x93434e));const _0x5a3572=Is(_0x4923ab,_0x1d31d2);ct(_0x4923ab,_0x5a3572);}),_0x4923ab['onDisconnect_']=En(),V(_0x4923ab['eventQueue_'],w(),_0x2aec67);}function bd(_0x53351e,_0x542ffd,_0x55910c){_0x53351e['server_']['onDisconnectCancel'](_0x542ffd['toString'](),(_0x27431c,_0x502c99)=>{_0x27431c==='ok'&&Ti(_0x53351e['onDisconnect_'],_0x542ffd),be(_0x53351e,_0x55910c,_0x27431c,_0x502c99);});}function yr(_0x384557,_0x3a13a5,_0x72fb3,_0x55aac7){const _0x49807a=A(_0x72fb3);_0x384557['server_']['onDisconnectPut'](_0x3a13a5['toString'](),_0x49807a['val'](!0x0),(_0x4dacdf,_0x4f589d)=>{_0x4dacdf==='ok'&&pt(_0x384557['onDisconnect_'],_0x3a13a5,_0x49807a),be(_0x384557,_0x55aac7,_0x4dacdf,_0x4f589d);});}function Rd(_0x445800,_0x58cb89,_0x552239,_0x10a4db,_0x479ff5){const _0xed009f=A(_0x552239,_0x10a4db);_0x445800['server_']['onDisconnectPut'](_0x58cb89['toString'](),_0xed009f['val'](!0x0),(_0x486df4,_0x1f1f6e)=>{_0x486df4==='ok'&&pt(_0x445800['onDisconnect_'],_0x58cb89,_0xed009f),be(_0x445800,_0x479ff5,_0x486df4,_0x1f1f6e);});}function Ad(_0x1b73fd,_0x16f286,_0x19ff4d,_0x16281b){if(pn(_0x19ff4d)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1b73fd,_0x16281b,'ok',void 0x0);return;}_0x1b73fd['server_']['onDisconnectMerge'](_0x16f286['toString'](),_0x19ff4d,(_0x34cb14,_0x1dfb0c)=>{_0x34cb14==='ok'&&x(_0x19ff4d,(_0x47f176,_0x190ad9)=>{const _0x490816=A(_0x190ad9);pt(_0x1b73fd['onDisconnect_'],k(_0x16f286,_0x47f176),_0x490816);}),be(_0x1b73fd,_0x16281b,_0x34cb14,_0x1dfb0c);});}function kd(_0x4b0135,_0x3705c5,_0x23a4e9){let _0x2fb417;y(_0x3705c5['_path'])==='.info'?_0x2fb417=Ni(_0x4b0135['infoSyncTree_'],_0x3705c5,_0x23a4e9):_0x2fb417=Ni(_0x4b0135['serverSyncTree_'],_0x3705c5,_0x23a4e9),oa(_0x4b0135['eventQueue_'],_0x3705c5['_path'],_0x2fb417);}function Pd(_0xb85ab5,_0x11ef8d,_0x494f01){let _0x4f5b90;y(_0x11ef8d['_path'])==='.info'?_0x4f5b90=An(_0xb85ab5['infoSyncTree_'],_0x11ef8d,_0x494f01):_0x4f5b90=An(_0xb85ab5['serverSyncTree_'],_0x11ef8d,_0x494f01),oa(_0xb85ab5['eventQueue_'],_0x11ef8d['_path'],_0x4f5b90);}function ha(_0x101efd){_0x101efd['persistentConnection_']&&_0x101efd['persistentConnection_']['interrupt'](ca);}function Nd(_0x5817b1){_0x5817b1['persistentConnection_']&&_0x5817b1['persistentConnection_']['resume'](ca);}function gt(_0x20f5d3,..._0x43567e){let _0x833b7a='';_0x20f5d3['persistentConnection_']&&(_0x833b7a=_0x20f5d3['persistentConnection_']['id']+':'),L(_0x833b7a,..._0x43567e);}function be(_0x3a7752,_0x1f1ceb,_0x21b1d1,_0x98beaa){_0x1f1ceb&&ft(()=>{if(_0x21b1d1==='ok')_0x1f1ceb(null);else{const _0x2de757=(_0x21b1d1||'error')['toUpperCase']();let _0x305cda=_0x2de757;_0x98beaa&&(_0x305cda+=':\x20'+_0x98beaa);const _0x994b5d=new Error(_0x305cda);_0x994b5d['code']=_0x2de757,_0x1f1ceb(_0x994b5d);}});}function Od(_0x123195,_0x48f32c,_0x1c24b5,_0xedc9ba,_0x1ed760,_0x157cfe){gt(_0x123195,'transaction\x20on\x20'+_0x48f32c);const _0x1092b2={'path':_0x48f32c,'update':_0x1c24b5,'onComplete':_0xedc9ba,'status':null,'order':so(),'applyLocally':_0x157cfe,'retryCount':0x0,'unwatcher':_0x1ed760,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x544338=Es(_0x123195,_0x48f32c,void 0x0);_0x1092b2['currentInputSnapshot']=_0x544338;const _0x2574ff=_0x1092b2['update'](_0x544338['val']());if(_0x2574ff===void 0x0)_0x1092b2['unwatcher'](),_0x1092b2['currentOutputSnapshotRaw']=null,_0x1092b2['currentOutputSnapshotResolved']=null,_0x1092b2['onComplete']&&_0x1092b2['onComplete'](null,!0x1,_0x1092b2['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2574ff,_0x1092b2['path']),_0x1092b2['status']=0x0;const _0x54dcae=$n(_0x123195['transactionQueueTree_'],_0x48f32c),_0x212f8a=je(_0x54dcae)||[];_0x212f8a['push'](_0x1092b2),gs(_0x54dcae,_0x212f8a);let _0x38f202;typeof _0x2574ff=='object'&&_0x2574ff!==null&&Q(_0x2574ff,'.priority')?(_0x38f202=Le(_0x2574ff,'.priority'),f(Bt(_0x38f202),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x38f202=(Vn(_0x123195['serverSyncTree_'],_0x48f32c)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x51f203=Xt(_0x123195),_0x3ca8a0=A(_0x2574ff,_0x38f202),_0x58089d=fs(_0x3ca8a0,_0x544338,_0x51f203);_0x1092b2['currentOutputSnapshotRaw']=_0x3ca8a0,_0x1092b2['currentOutputSnapshotResolved']=_0x58089d,_0x1092b2['currentWriteId']=zn(_0x123195);const _0x2b1dc6=as(_0x123195['serverSyncTree_'],_0x48f32c,_0x58089d,_0x1092b2['currentWriteId'],_0x1092b2['applyLocally']);V(_0x123195['eventQueue_'],_0x48f32c,_0x2b1dc6),jn(_0x123195,_0x123195['transactionQueueTree_']);}}function Es(_0x29eca0,_0x255ea3,_0x5efe60){return Vn(_0x29eca0['serverSyncTree_'],_0x255ea3,_0x5efe60)||g['EMPTY_NODE'];}function jn(_0x252c78,_0x2603e8=_0x252c78['transactionQueueTree_']){if(_0x2603e8||Kn(_0x252c78,_0x2603e8),je(_0x2603e8)){const _0x5c325a=da(_0x252c78,_0x2603e8);f(_0x5c325a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5c325a['every'](_0x4592d8=>_0x4592d8['status']===0x0)&&Dd(_0x252c78,Qt(_0x2603e8),_0x5c325a);}else na(_0x2603e8)&&Gn(_0x2603e8,_0x5970ce=>{jn(_0x252c78,_0x5970ce);});}function Dd(_0x2ae861,_0x131cdd,_0x30320b){const _0x51172b=_0x30320b['map'](_0x14742c=>_0x14742c['currentWriteId']),_0x33e32b=Es(_0x2ae861,_0x131cdd,_0x51172b);let _0x1b03db=_0x33e32b;const _0x153418=_0x33e32b['hash']();for(let _0x26150a=0x0;_0x26150a<_0x30320b['length'];_0x26150a++){const _0x41ae17=_0x30320b[_0x26150a];f(_0x41ae17['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x41ae17['status']=0x1,_0x41ae17['retryCount']++;const _0x30b645=F(_0x131cdd,_0x41ae17['path']);_0x1b03db=_0x1b03db['updateChild'](_0x30b645,_0x41ae17['currentOutputSnapshotRaw']);}const _0x18ebad=_0x1b03db['val'](!0x0),_0x529a36=_0x131cdd;_0x2ae861['server_']['put'](_0x529a36['toString'](),_0x18ebad,_0x2d4619=>{gt(_0x2ae861,'transaction\x20put\x20response',{'path':_0x529a36['toString'](),'status':_0x2d4619});let _0x4b1886=[];if(_0x2d4619==='ok'){const _0x7c92c=[];for(let _0x33e016=0x0;_0x33e016<_0x30320b['length'];_0x33e016++)_0x30320b[_0x33e016]['status']=0x2,_0x4b1886=_0x4b1886['concat'](_e(_0x2ae861['serverSyncTree_'],_0x30320b[_0x33e016]['currentWriteId'])),_0x30320b[_0x33e016]['onComplete']&&_0x7c92c['push'](()=>_0x30320b[_0x33e016]['onComplete'](null,!0x0,_0x30320b[_0x33e016]['currentOutputSnapshotResolved'])),_0x30320b[_0x33e016]['unwatcher']();Kn(_0x2ae861,$n(_0x2ae861['transactionQueueTree_'],_0x131cdd)),jn(_0x2ae861,_0x2ae861['transactionQueueTree_']),V(_0x2ae861['eventQueue_'],_0x131cdd,_0x4b1886);for(let _0x5a1550=0x0;_0x5a1550<_0x7c92c['length'];_0x5a1550++)ft(_0x7c92c[_0x5a1550]);}else{if(_0x2d4619==='datastale'){for(let _0x34321b=0x0;_0x34321b<_0x30320b['length'];_0x34321b++)_0x30320b[_0x34321b]['status']===0x3?_0x30320b[_0x34321b]['status']=0x4:_0x30320b[_0x34321b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x529a36['toString']()+'\x20failed:\x20'+_0x2d4619);for(let _0x24ad59=0x0;_0x24ad59<_0x30320b['length'];_0x24ad59++)_0x30320b[_0x24ad59]['status']=0x4,_0x30320b[_0x24ad59]['abortReason']=_0x2d4619;}ct(_0x2ae861,_0x131cdd);}},_0x153418);}function ct(_0x25e71a,_0x524847){const _0x52075e=ua(_0x25e71a,_0x524847),_0x35c496=Qt(_0x52075e),_0x1a7b1f=da(_0x25e71a,_0x52075e);return Md(_0x25e71a,_0x1a7b1f,_0x35c496),_0x35c496;}function Md(_0x562c61,_0x3c50b7,_0x181306){if(_0x3c50b7['length']===0x0)return;const _0x3f5b27=[];let _0x3690da=[];const _0x372309=_0x3c50b7['filter'](_0x24b3e4=>_0x24b3e4['status']===0x0)['map'](_0x5910ae=>_0x5910ae['currentWriteId']);for(let _0x54d008=0x0;_0x54d008<_0x3c50b7['length'];_0x54d008++){const _0x2e99e9=_0x3c50b7[_0x54d008],_0x370950=F(_0x181306,_0x2e99e9['path']);let _0x29a76a=!0x1,_0x849a5b;if(f(_0x370950!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2e99e9['status']===0x4)_0x29a76a=!0x0,_0x849a5b=_0x2e99e9['abortReason'],_0x3690da=_0x3690da['concat'](_e(_0x562c61['serverSyncTree_'],_0x2e99e9['currentWriteId'],!0x0));else{if(_0x2e99e9['status']===0x0){if(_0x2e99e9['retryCount']>=yd)_0x29a76a=!0x0,_0x849a5b='maxretry',_0x3690da=_0x3690da['concat'](_e(_0x562c61['serverSyncTree_'],_0x2e99e9['currentWriteId'],!0x0));else{const _0x3564a0=Es(_0x562c61,_0x2e99e9['path'],_0x372309);_0x2e99e9['currentInputSnapshot']=_0x3564a0;const _0x4c394d=_0x3c50b7[_0x54d008]['update'](_0x3564a0['val']());if(_0x4c394d!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c394d,_0x2e99e9['path']);let _0x81dcdd=A(_0x4c394d);typeof _0x4c394d=='object'&&_0x4c394d!=null&&Q(_0x4c394d,'.priority')||(_0x81dcdd=_0x81dcdd['updatePriority'](_0x3564a0['getPriority']()));const _0x51e2d3=_0x2e99e9['currentWriteId'],_0x4a3931=Xt(_0x562c61),_0x22331c=fs(_0x81dcdd,_0x3564a0,_0x4a3931);_0x2e99e9['currentOutputSnapshotRaw']=_0x81dcdd,_0x2e99e9['currentOutputSnapshotResolved']=_0x22331c,_0x2e99e9['currentWriteId']=zn(_0x562c61),_0x372309['splice'](_0x372309['indexOf'](_0x51e2d3),0x1),_0x3690da=_0x3690da['concat'](as(_0x562c61['serverSyncTree_'],_0x2e99e9['path'],_0x22331c,_0x2e99e9['currentWriteId'],_0x2e99e9['applyLocally'])),_0x3690da=_0x3690da['concat'](_e(_0x562c61['serverSyncTree_'],_0x51e2d3,!0x0));}else _0x29a76a=!0x0,_0x849a5b='nodata',_0x3690da=_0x3690da['concat'](_e(_0x562c61['serverSyncTree_'],_0x2e99e9['currentWriteId'],!0x0));}}}V(_0x562c61['eventQueue_'],_0x181306,_0x3690da),_0x3690da=[],_0x29a76a&&(_0x3c50b7[_0x54d008]['status']=0x2,function(_0x586967){setTimeout(_0x586967,Math['floor'](0x0));}(_0x3c50b7[_0x54d008]['unwatcher']),_0x3c50b7[_0x54d008]['onComplete']&&(_0x849a5b==='nodata'?_0x3f5b27['push'](()=>_0x3c50b7[_0x54d008]['onComplete'](null,!0x1,_0x3c50b7[_0x54d008]['currentInputSnapshot'])):_0x3f5b27['push'](()=>_0x3c50b7[_0x54d008]['onComplete'](new Error(_0x849a5b),!0x1,null))));}Kn(_0x562c61,_0x562c61['transactionQueueTree_']);for(let _0x5263cf=0x0;_0x5263cf<_0x3f5b27['length'];_0x5263cf++)ft(_0x3f5b27[_0x5263cf]);jn(_0x562c61,_0x562c61['transactionQueueTree_']);}function ua(_0x144cd9,_0x1c7042){let _0x480e89,_0x1d6bd6=_0x144cd9['transactionQueueTree_'];for(_0x480e89=y(_0x1c7042);_0x480e89!==null&&je(_0x1d6bd6)===void 0x0;)_0x1d6bd6=$n(_0x1d6bd6,_0x480e89),_0x1c7042=S(_0x1c7042),_0x480e89=y(_0x1c7042);return _0x1d6bd6;}function da(_0x2211a9,_0x2e3506){const _0x4fbddc=[];return fa(_0x2211a9,_0x2e3506,_0x4fbddc),_0x4fbddc['sort']((_0x3f098c,_0x17b278)=>_0x3f098c['order']-_0x17b278['order']),_0x4fbddc;}function fa(_0x1592a8,_0x29aa02,_0x14faf8){const _0x2d6100=je(_0x29aa02);if(_0x2d6100){for(let _0x324fa3=0x0;_0x324fa3<_0x2d6100['length'];_0x324fa3++)_0x14faf8['push'](_0x2d6100[_0x324fa3]);}Gn(_0x29aa02,_0x2757a7=>{fa(_0x1592a8,_0x2757a7,_0x14faf8);});}function Kn(_0x4937d2,_0x1f2ea7){const _0x331158=je(_0x1f2ea7);if(_0x331158){let _0x2aea02=0x0;for(let _0x22802d=0x0;_0x22802d<_0x331158['length'];_0x22802d++)_0x331158[_0x22802d]['status']!==0x2&&(_0x331158[_0x2aea02]=_0x331158[_0x22802d],_0x2aea02++);_0x331158['length']=_0x2aea02,gs(_0x1f2ea7,_0x331158['length']>0x0?_0x331158:void 0x0);}Gn(_0x1f2ea7,_0x14434a=>{Kn(_0x4937d2,_0x14434a);});}function Is(_0x115dca,_0x3f811d){const _0x3b2aad=Qt(ua(_0x115dca,_0x3f811d)),_0x1a93ad=$n(_0x115dca['transactionQueueTree_'],_0x3f811d);return ad(_0x1a93ad,_0x42bb3d=>{di(_0x115dca,_0x42bb3d);}),di(_0x115dca,_0x1a93ad),ia(_0x1a93ad,_0x75dab6=>{di(_0x115dca,_0x75dab6);}),_0x3b2aad;}function di(_0x5aae17,_0x3542cd){const _0x32c235=je(_0x3542cd);if(_0x32c235){const _0x10ef73=[];let _0x47d0a7=[],_0x4d80eb=-0x1;for(let _0x22a9e4=0x0;_0x22a9e4<_0x32c235['length'];_0x22a9e4++)_0x32c235[_0x22a9e4]['status']===0x3||(_0x32c235[_0x22a9e4]['status']===0x1?(f(_0x4d80eb===_0x22a9e4-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4d80eb=_0x22a9e4,_0x32c235[_0x22a9e4]['status']=0x3,_0x32c235[_0x22a9e4]['abortReason']='set'):(f(_0x32c235[_0x22a9e4]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x32c235[_0x22a9e4]['unwatcher'](),_0x47d0a7=_0x47d0a7['concat'](_e(_0x5aae17['serverSyncTree_'],_0x32c235[_0x22a9e4]['currentWriteId'],!0x0)),_0x32c235[_0x22a9e4]['onComplete']&&_0x10ef73['push'](_0x32c235[_0x22a9e4]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4d80eb===-0x1?gs(_0x3542cd,void 0x0):_0x32c235['length']=_0x4d80eb+0x1,V(_0x5aae17['eventQueue_'],Qt(_0x3542cd),_0x47d0a7);for(let _0x4d7898=0x0;_0x4d7898<_0x10ef73['length'];_0x4d7898++)ft(_0x10ef73[_0x4d7898]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x74f410){let _0x2ae9f9='';const _0x41b789=_0x74f410['split']('/');for(let _0x23045c=0x0;_0x23045c<_0x41b789['length'];_0x23045c++)if(_0x41b789[_0x23045c]['length']>0x0){let _0x15c8f3=_0x41b789[_0x23045c];try{_0x15c8f3=decodeURIComponent(_0x15c8f3['replace'](/\+/g,'\x20'));}catch{}_0x2ae9f9+='/'+_0x15c8f3;}return _0x2ae9f9;}function xd(_0x28458){const _0x3d24c8={};_0x28458['charAt'](0x0)==='?'&&(_0x28458=_0x28458['substring'](0x1));for(const _0x5eec9 of _0x28458['split']('&')){if(_0x5eec9['length']===0x0)continue;const _0x1f28d3=_0x5eec9['split']('=');_0x1f28d3['length']===0x2?_0x3d24c8[decodeURIComponent(_0x1f28d3[0x0])]=decodeURIComponent(_0x1f28d3[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5eec9+'\x27\x20in\x20query\x20\x27'+_0x28458+'\x27');}return _0x3d24c8;}const vr=function(_0x363251,_0xce5d46){const _0x8110dd=Fd(_0x363251),_0x2352fb=_0x8110dd['namespace'];_0x8110dd['domain']==='firebase.com'&&ae(_0x8110dd['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2352fb||_0x2352fb==='undefined')&&_0x8110dd['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x8110dd['secure']||$l();const _0x52add9=_0x8110dd['scheme']==='ws'||_0x8110dd['scheme']==='wss';return{'repoInfo':new yo(_0x8110dd['host'],_0x8110dd['secure'],_0x2352fb,_0x52add9,_0xce5d46,'',_0x2352fb!==_0x8110dd['subdomain']),'path':new C(_0x8110dd['pathString'])};},Fd=function(_0xd3b0f1){let _0x339a05='',_0x417ab3='',_0x14399b='',_0x5e185f='',_0x5ec65f='',_0x57ebd5=!0x0,_0x197d58='https',_0x16c045=0x1bb;if(typeof _0xd3b0f1=='string'){let _0x4973b9=_0xd3b0f1['indexOf']('//');_0x4973b9>=0x0&&(_0x197d58=_0xd3b0f1['substring'](0x0,_0x4973b9-0x1),_0xd3b0f1=_0xd3b0f1['substring'](_0x4973b9+0x2));let _0x3f20a4=_0xd3b0f1['indexOf']('/');_0x3f20a4===-0x1&&(_0x3f20a4=_0xd3b0f1['length']);let _0x5e04de=_0xd3b0f1['indexOf']('?');_0x5e04de===-0x1&&(_0x5e04de=_0xd3b0f1['length']),_0x339a05=_0xd3b0f1['substring'](0x0,Math['min'](_0x3f20a4,_0x5e04de)),_0x3f20a4<_0x5e04de&&(_0x5e185f=Ld(_0xd3b0f1['substring'](_0x3f20a4,_0x5e04de)));const _0x1e9e02=xd(_0xd3b0f1['substring'](Math['min'](_0xd3b0f1['length'],_0x5e04de)));_0x4973b9=_0x339a05['indexOf'](':'),_0x4973b9>=0x0?(_0x57ebd5=_0x197d58==='https'||_0x197d58==='wss',_0x16c045=parseInt(_0x339a05['substring'](_0x4973b9+0x1),0xa)):_0x4973b9=_0x339a05['length'];const _0x5e39dc=_0x339a05['slice'](0x0,_0x4973b9);if(_0x5e39dc['toLowerCase']()==='localhost')_0x417ab3='localhost';else{if(_0x5e39dc['split']('.')['length']<=0x2)_0x417ab3=_0x5e39dc;else{const _0x1a4f95=_0x339a05['indexOf']('.');_0x14399b=_0x339a05['substring'](0x0,_0x1a4f95)['toLowerCase'](),_0x417ab3=_0x339a05['substring'](_0x1a4f95+0x1),_0x5ec65f=_0x14399b;}}'ns'in _0x1e9e02&&(_0x5ec65f=_0x1e9e02['ns']);}return{'host':_0x339a05,'port':_0x16c045,'domain':_0x417ab3,'subdomain':_0x14399b,'secure':_0x57ebd5,'scheme':_0x197d58,'pathString':_0x5e185f,'namespace':_0x5ec65f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x1e8088=0x0;const _0x19a05b=[];return function(_0x35f140){const _0x112b8a=_0x35f140===_0x1e8088;_0x1e8088=_0x35f140;let _0x228d0a;const _0x1c5406=new Array(0x8);for(_0x228d0a=0x7;_0x228d0a>=0x0;_0x228d0a--)_0x1c5406[_0x228d0a]=Er['charAt'](_0x35f140%0x40),_0x35f140=Math['floor'](_0x35f140/0x40);f(_0x35f140===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x55943e=_0x1c5406['join']('');if(_0x112b8a){for(_0x228d0a=0xb;_0x228d0a>=0x0&&_0x19a05b[_0x228d0a]===0x3f;_0x228d0a--)_0x19a05b[_0x228d0a]=0x0;_0x19a05b[_0x228d0a]++;}else{for(_0x228d0a=0x0;_0x228d0a<0xc;_0x228d0a++)_0x19a05b[_0x228d0a]=Math['floor'](Math['random']()*0x40);}for(_0x228d0a=0x0;_0x228d0a<0xc;_0x228d0a++)_0x55943e+=Er['charAt'](_0x19a05b[_0x228d0a]);return f(_0x55943e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x55943e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x3069a3,_0x16ed78,_0x1d8903,_0x331070){this['eventType']=_0x3069a3,this['eventRegistration']=_0x16ed78,this['snapshot']=_0x1d8903,this['prevName']=_0x331070;}['getPath'](){const _0x4716c8=this['snapshot']['ref'];return this['eventType']==='value'?_0x4716c8['_path']:_0x4716c8['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x320434,_0x41b5ba,_0x54fcf8){this['eventRegistration']=_0x320434,this['error']=_0x41b5ba,this['path']=_0x54fcf8;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x174488,_0x20aa10){this['snapshotCallback']=_0x174488,this['cancelCallback']=_0x20aa10;}['onValue'](_0x159f66,_0x28d94d){this['snapshotCallback']['call'](null,_0x159f66,_0x28d94d);}['onCancel'](_0x3085ec){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3085ec);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x2d101d){return this['snapshotCallback']===_0x2d101d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x2d101d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x2d101d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x2a287b,_0x1299f6){this['_repo']=_0x2a287b,this['_path']=_0x1299f6;}['cancel'](){const _0x26db69=new H();return bd(this['_repo'],this['_path'],_0x26db69['wrapCallback'](()=>{})),_0x26db69['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x15be5e=new H();return yr(this['_repo'],this['_path'],null,_0x15be5e['wrapCallback'](()=>{})),_0x15be5e['promise'];}['set'](_0x182802){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x182802,this['_path'],!0x1);const _0x2e3c2b=new H();return yr(this['_repo'],this['_path'],_0x182802,_0x2e3c2b['wrapCallback'](()=>{})),_0x2e3c2b['promise'];}['setWithPriority'](_0x1f6630,_0x1bb0d1){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x1f6630,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1bb0d1);const _0x58ae7e=new H();return Rd(this['_repo'],this['_path'],_0x1f6630,_0x1bb0d1,_0x58ae7e['wrapCallback'](()=>{})),_0x58ae7e['promise'];}['update'](_0x2b7cb3){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x2b7cb3,this['_path']);const _0x8d7c1b=new H();return Ad(this['_repo'],this['_path'],_0x2b7cb3,_0x8d7c1b['wrapCallback'](()=>{})),_0x8d7c1b['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4df24a,_0x53a179,_0x492e64,_0x437de6){this['_repo']=_0x4df24a,this['_path']=_0x53a179,this['_queryParams']=_0x492e64,this['_orderByCalled']=_0x437de6;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x39c704=sr(this['_queryParams']),_0x284ac4=$i(_0x39c704);return _0x284ac4==='{}'?'default':_0x284ac4;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x5347c6){if(_0x5347c6=P(_0x5347c6),!(_0x5347c6 instanceof Ae))return!0x1;const _0x169d23=this['_repo']===_0x5347c6['_repo'],_0x2ff515=Ki(this['_path'],_0x5347c6['_path']),_0x1b09b9=this['_queryIdentifier']===_0x5347c6['_queryIdentifier'];return _0x169d23&&_0x2ff515&&_0x1b09b9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x12f3f6,_0x5d7599){if(_0x12f3f6['_orderByCalled']===!0x0)throw new Error(_0x5d7599+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x33d2b4){let _0x509403=null,_0x31115e=null;if(_0x33d2b4['hasStart']()&&(_0x509403=_0x33d2b4['getIndexStartValue']()),_0x33d2b4['hasEnd']()&&(_0x31115e=_0x33d2b4['getIndexEndValue']()),_0x33d2b4['getIndex']()===ve){const _0x5c0d66='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xd61399='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x33d2b4['hasStart']()){if(_0x33d2b4['getIndexStartName']()!==We)throw new Error(_0x5c0d66);if(typeof _0x509403!='string')throw new Error(_0xd61399);}if(_0x33d2b4['hasEnd']()){if(_0x33d2b4['getIndexEndName']()!==we)throw new Error(_0x5c0d66);if(typeof _0x31115e!='string')throw new Error(_0xd61399);}}else{if(_0x33d2b4['getIndex']()===R){if(_0x509403!=null&&!Bt(_0x509403)||_0x31115e!=null&&!Bt(_0x31115e))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x33d2b4['getIndex']()instanceof Ji||_0x33d2b4['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x509403!=null&&typeof _0x509403=='object'||_0x31115e!=null&&typeof _0x31115e=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x434f63){if(_0x434f63['hasStart']()&&_0x434f63['hasEnd']()&&_0x434f63['hasLimit']()&&!_0x434f63['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x225881,_0x1c0b99){super(_0x225881,_0x1c0b99,new Zi(),!0x1);}get['parent'](){const _0x273644=Ro(this['_path']);return _0x273644===null?null:new ee(this['_repo'],_0x273644);}get['root'](){let _0x222f42=this;for(;_0x222f42['parent']!==null;)_0x222f42=_0x222f42['parent'];return _0x222f42;}}class lt{constructor(_0x1f6071,_0x56b0fd,_0x182ffb){this['_node']=_0x1f6071,this['ref']=_0x56b0fd,this['_index']=_0x182ffb;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x40434b){const _0x3b0d7a=new C(_0x40434b),_0xa32ff1=Vt(this['ref'],_0x40434b);return new lt(this['_node']['getChild'](_0x3b0d7a),_0xa32ff1,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x1ed0d2){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x5c2c96,_0x19ff25)=>_0x1ed0d2(new lt(_0x19ff25,Vt(this['ref'],_0x5c2c96),R)));}['hasChild'](_0x2b4764){const _0x1822d7=new C(_0x2b4764);return!this['_node']['getChild'](_0x1822d7)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4aca91,_0x431840){return _0x4aca91=P(_0x4aca91),_0x4aca91['_checkNotDeleted']('ref'),_0x431840!==void 0x0?Vt(_0x4aca91['_root'],_0x431840):_0x4aca91['_root'];}function Vt(_0x51d582,_0x21974a){return _0x51d582=P(_0x51d582),y(_0x51d582['_path'])===null?pd('child','path',_0x21974a):ys('child','path',_0x21974a),new ee(_0x51d582['_repo'],k(_0x51d582['_path'],_0x21974a));}function v_(_0x2259a4){return _0x2259a4=P(_0x2259a4),new Vd(_0x2259a4['_repo'],_0x2259a4['_path']);}function E_(_0x17ba08,_0x4b5fe2){_0x17ba08=P(_0x17ba08),Me('push',_0x17ba08['_path']),He('push',_0x4b5fe2,_0x17ba08['_path'],!0x0);const _0x5b6bac=la(_0x17ba08['_repo']),_0x21e91f=Ud(_0x5b6bac),_0x20969c=Vt(_0x17ba08,_0x21e91f),_0x2184ad=Vt(_0x17ba08,_0x21e91f);let _0x4aabf0;return _0x4b5fe2!=null?_0x4aabf0=Hd(_0x2184ad,_0x4b5fe2)['then'](()=>_0x2184ad):_0x4aabf0=Promise['resolve'](_0x2184ad),_0x20969c['then']=_0x4aabf0['then']['bind'](_0x4aabf0),_0x20969c['catch']=_0x4aabf0['then']['bind'](_0x4aabf0,void 0x0),_0x20969c;}function Hd(_0x35c3f6,_0x356941){_0x35c3f6=P(_0x35c3f6),Me('set',_0x35c3f6['_path']),He('set',_0x356941,_0x35c3f6['_path'],!0x1);const _0x51ae51=new H();return Cd(_0x35c3f6['_repo'],_0x35c3f6['_path'],_0x356941,null,_0x51ae51['wrapCallback'](()=>{})),_0x51ae51['promise'];}function I_(_0x24bd77,_0x409e0c){ra('update',_0x409e0c,_0x24bd77['_path']);const _0x1415b1=new H();return Td(_0x24bd77['_repo'],_0x24bd77['_path'],_0x409e0c,_0x1415b1['wrapCallback'](()=>{})),_0x1415b1['promise'];}function w_(_0x5d6334){_0x5d6334=P(_0x5d6334);const _0x4f98bf=new pa(()=>{}),_0x4d0cf8=new Qn(_0x4f98bf);return wd(_0x5d6334['_repo'],_0x5d6334,_0x4d0cf8)['then'](_0x33f8b3=>new lt(_0x33f8b3,new ee(_0x5d6334['_repo'],_0x5d6334['_path']),_0x5d6334['_queryParams']['getIndex']()));}class Qn{constructor(_0x4429ba){this['callbackContext']=_0x4429ba;}['respondsTo'](_0x4e2aa1){return _0x4e2aa1==='value';}['createEvent'](_0x3e302e,_0x5daa80){const _0x524ed2=_0x5daa80['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x3e302e['snapshotNode'],new ee(_0x5daa80['_repo'],_0x5daa80['_path']),_0x524ed2));}['getEventRunner'](_0x4c51e8){return _0x4c51e8['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4c51e8['error']):()=>this['callbackContext']['onValue'](_0x4c51e8['snapshot'],null);}['createCancelEvent'](_0x39e473,_0x21929a){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x39e473,_0x21929a):null;}['matches'](_0x3d367b){return _0x3d367b instanceof Qn?!_0x3d367b['callbackContext']||!this['callbackContext']?!0x0:_0x3d367b['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x4aabd1,_0x22e7c7,_0x1386f9,_0x24e4b4,_0x2f952c){const _0x45d63b=new pa(_0x1386f9,void 0x0),_0x1c2e6d=new Qn(_0x45d63b);return kd(_0x4aabd1['_repo'],_0x4aabd1,_0x1c2e6d),()=>Pd(_0x4aabd1['_repo'],_0x4aabd1,_0x1c2e6d);}function Gd(_0x3ec9cb,_0x39a7bb,_0x201340,_0x39f1b5){return $d(_0x3ec9cb,'value',_0x39a7bb);}class mt{}class ma extends mt{constructor(_0x1233dc,_0x1a7a14){super(),this['_value']=_0x1233dc,this['_key']=_0x1a7a14,this['type']='endAt';}['_apply'](_0x587ea4){He('endAt',this['_value'],_0x587ea4['_path'],!0x0);const _0x403ddd=Jh(_0x587ea4['_queryParams'],this['_value'],this['_key']);if(ga(_0x403ddd),Yn(_0x403ddd),_0x587ea4['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x587ea4['_repo'],_0x587ea4['_path'],_0x403ddd,_0x587ea4['_orderByCalled']);}}function C_(_0x567d60,_0x6dc22b){return new ma(_0x567d60,_0x6dc22b);}class ya extends mt{constructor(_0x572e4e,_0x32d17b){super(),this['_value']=_0x572e4e,this['_key']=_0x32d17b,this['type']='startAt';}['_apply'](_0x3d7bcf){He('startAt',this['_value'],_0x3d7bcf['_path'],!0x0);const _0x4c9bcc=Qh(_0x3d7bcf['_queryParams'],this['_value'],this['_key']);if(ga(_0x4c9bcc),Yn(_0x4c9bcc),_0x3d7bcf['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x3d7bcf['_repo'],_0x3d7bcf['_path'],_0x4c9bcc,_0x3d7bcf['_orderByCalled']);}}function T_(_0x383951=null,_0x1ab20f){return new ya(_0x383951,_0x1ab20f);}class qd extends mt{constructor(_0x336f94){super(),this['_limit']=_0x336f94,this['type']='limitToFirst';}['_apply'](_0x2fa57e){if(_0x2fa57e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x2fa57e['_repo'],_0x2fa57e['_path'],Yh(_0x2fa57e['_queryParams'],this['_limit']),_0x2fa57e['_orderByCalled']);}}function S_(_0x8e13fe){if(Math['floor'](_0x8e13fe)!==_0x8e13fe||_0x8e13fe<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x8e13fe);}class zd extends mt{constructor(_0x11b3c5){super(),this['_path']=_0x11b3c5,this['type']='orderByChild';}['_apply'](_0x175504){_a(_0x175504,'orderByChild');const _0x3b4c5d=new C(this['_path']);if(v(_0x3b4c5d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x430e17=new Ji(_0x3b4c5d),_0xb3f6b1=xo(_0x175504['_queryParams'],_0x430e17);return Yn(_0xb3f6b1),new Ae(_0x175504['_repo'],_0x175504['_path'],_0xb3f6b1,!0x0);}}function b_(_0x5c8f30){if(_0x5c8f30==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5c8f30==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5c8f30==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5c8f30),new zd(_0x5c8f30);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x58afac){_a(_0x58afac,'orderByKey');const _0x168003=xo(_0x58afac['_queryParams'],ve);return Yn(_0x168003),new Ae(_0x58afac['_repo'],_0x58afac['_path'],_0x168003,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x386b52,_0xc35c74){super(),this['_value']=_0x386b52,this['_key']=_0xc35c74,this['type']='equalTo';}['_apply'](_0x24af04){if(He('equalTo',this['_value'],_0x24af04['_path'],!0x1),_0x24af04['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x24af04['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x24af04));}}function A_(_0x49bdcd,_0x268e75){return new Kd(_0x49bdcd,_0x268e75);}function k_(_0x4252af,..._0x5bf7d7){let _0x5dcb85=P(_0x4252af);for(const _0x27fd41 of _0x5bf7d7)_0x5dcb85=_0x27fd41['_apply'](_0x5dcb85);return _0x5dcb85;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4517bd,_0x4d26ed,_0x92d255,_0x540dd9){const _0x2a8807=_0x4d26ed['lastIndexOf'](':'),_0x8325be=_0x4d26ed['substring'](0x0,_0x2a8807),_0x15ff92=qt(_0x8325be);_0x4517bd['repoInfo_']=new yo(_0x4d26ed,_0x15ff92,_0x4517bd['repoInfo_']['namespace'],_0x4517bd['repoInfo_']['webSocketOnly'],_0x4517bd['repoInfo_']['nodeAdmin'],_0x4517bd['repoInfo_']['persistenceKey'],_0x4517bd['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x92d255),_0x540dd9&&(_0x4517bd['authTokenProvider_']=_0x540dd9);}function Xd(_0xe82050,_0x31a871,_0x412eb2,_0x4c0962,_0x5c133d){let _0x1ae650=_0x4c0962||_0xe82050['options']['databaseURL'];_0x1ae650===void 0x0&&(_0xe82050['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0xe82050['options']['projectId']),_0x1ae650=_0xe82050['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4ce387=vr(_0x1ae650,_0x5c133d),_0x21545b=_0x4ce387['repoInfo'],_0x145e84;typeof process<'u'&&Bs&&(_0x145e84=Bs[Yd]),_0x145e84?(_0x1ae650='http://'+_0x145e84+'?ns='+_0x21545b['namespace'],_0x4ce387=vr(_0x1ae650,_0x5c133d),_0x21545b=_0x4ce387['repoInfo']):_0x4ce387['repoInfo']['secure'];const _0x3f76e1=new eh(_0xe82050['name'],_0xe82050['options'],_0x31a871);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4ce387),v(_0x4ce387['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x47211e=ef(_0x21545b,_0xe82050,_0x3f76e1,new Zl(_0xe82050,_0x412eb2));return new tf(_0x47211e,_0xe82050);}function Zd(_0x340ee1,_0x5a630d){const _0x387ed4=Di[_0x5a630d];(!_0x387ed4||_0x387ed4[_0x340ee1['key']]!==_0x340ee1)&&ae('Database\x20'+_0x5a630d+'('+_0x340ee1['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x340ee1),delete _0x387ed4[_0x340ee1['key']];}function ef(_0x32718c,_0x210c9d,_0x541010,_0x544184){let _0x4b08c4=Di[_0x210c9d['name']];_0x4b08c4||(_0x4b08c4={},Di[_0x210c9d['name']]=_0x4b08c4);let _0x1aa69c=_0x4b08c4[_0x32718c['toURLString']()];return _0x1aa69c&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1aa69c=new vd(_0x32718c,Qd,_0x541010,_0x544184),_0x4b08c4[_0x32718c['toURLString']()]=_0x1aa69c,_0x1aa69c;}class tf{constructor(_0x4573cd,_0x2cb251){this['_repoInternal']=_0x4573cd,this['app']=_0x2cb251,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x17a30f){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x17a30f+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3aa60e=Zr(),_0x207197){const _0x42ee66=Hi(_0x3aa60e,'database')['getImmediate']({'identifier':_0x207197});if(!_0x42ee66['_instanceStarted']){const _0x2d51a4=hc('database');_0x2d51a4&&nf(_0x42ee66,..._0x2d51a4);}return _0x42ee66;}function nf(_0x5150d4,_0x4ff03c,_0x5c905f,_0x409301={}){_0x5150d4=P(_0x5150d4),_0x5150d4['_checkNotDeleted']('useEmulator');const _0x69dab6=_0x4ff03c+':'+_0x5c905f,_0x2f61a9=_0x5150d4['_repoInternal'];if(_0x5150d4['_instanceStarted']){if(_0x69dab6===_0x5150d4['_repoInternal']['repoInfo_']['host']&&xe(_0x409301,_0x2f61a9['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1d691b;if(_0x2f61a9['repoInfo_']['nodeAdmin'])_0x409301['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1d691b=new an(an['OWNER']);else{if(_0x409301['mockUserToken']){const _0x4e42e2=typeof _0x409301['mockUserToken']=='string'?_0x409301['mockUserToken']:uc(_0x409301['mockUserToken'],_0x5150d4['app']['options']['projectId']);_0x1d691b=new an(_0x4e42e2);}}qt(_0x4ff03c)&&Qr(_0x4ff03c),Jd(_0x2f61a9,_0x69dab6,_0x409301,_0x1d691b);}function N_(_0x470e76){_0x470e76=P(_0x470e76),_0x470e76['_checkNotDeleted']('goOffline'),ha(_0x470e76['_repo']);}function O_(_0x20f856){_0x20f856=P(_0x20f856),_0x20f856['_checkNotDeleted']('goOnline'),Nd(_0x20f856['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x398645){Ul(dt),st(new Fe('database',(_0x55242b,{instanceIdentifier:_0x166e7f})=>{const _0x30fd02=_0x55242b['getProvider']('app')['getImmediate'](),_0x1e4e5b=_0x55242b['getProvider']('auth-internal'),_0x666fa5=_0x55242b['getProvider']('app-check-internal');return Xd(_0x30fd02,_0x1e4e5b,_0x666fa5,_0x166e7f);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x398645),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x426d44,_0x4907d1){this['committed']=_0x426d44,this['snapshot']=_0x4907d1;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x40f6f7,_0x319d72,_0xe3c828){if(_0x40f6f7=P(_0x40f6f7),Me('Reference.transaction',_0x40f6f7['_path']),_0x40f6f7['key']==='.length'||_0x40f6f7['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x40f6f7['key']+'\x20is\x20a\x20read-only\x20object.';const _0x284211=!0x0,_0x472b45=new H(),_0xb9c337=(_0x4f0a5d,_0x2e2ca4,_0x5716e5)=>{let _0x18b1aa=null;_0x4f0a5d?_0x472b45['reject'](_0x4f0a5d):(_0x18b1aa=new lt(_0x5716e5,new ee(_0x40f6f7['_repo'],_0x40f6f7['_path']),R),_0x472b45['resolve'](new of(_0x2e2ca4,_0x18b1aa)));},_0x3d383b=Gd(_0x40f6f7,()=>{});return Od(_0x40f6f7['_repo'],_0x40f6f7['_path'],_0x319d72,_0xb9c337,_0x3d383b,_0x284211),_0x472b45['promise'];}se['prototype']['simpleListen']=function(_0x2e9ba5,_0x3d75e4){this['sendRequest']('q',{'p':_0x2e9ba5},_0x3d75e4);},se['prototype']['echo']=function(_0x44d6b0,_0x587ada){this['sendRequest']('echo',{'d':_0x44d6b0},_0x587ada);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x1899db,..._0x3d6749){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x1899db,..._0x3d6749);}function cn(_0x1c17ac,..._0x37a986){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x1c17ac,..._0x37a986);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xeb94cb,..._0x929a2c){throw ws(_0xeb94cb,..._0x929a2c);}function X(_0x93f1f3,..._0x57be0c){return ws(_0x93f1f3,..._0x57be0c);}function Ia(_0x13527d,_0x309356,_0x40f54a){const _0x1e4123={...af(),[_0x309356]:_0x40f54a};return new Gt('auth','Firebase',_0x1e4123)['create'](_0x309356,{'appName':_0x13527d['name']});}function re(_0x10e8e1){return Ia(_0x10e8e1,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x240a8f,..._0x165ecf){if(typeof _0x240a8f!='string'){const _0x518119=_0x165ecf[0x0],_0x275044=[..._0x165ecf['slice'](0x1)];return _0x275044[0x0]&&(_0x275044[0x0]['appName']=_0x240a8f['name']),_0x240a8f['_errorFactory']['create'](_0x518119,..._0x275044);}return Ea['create'](_0x240a8f,..._0x165ecf);}function m(_0xd98ed8,_0x4dacef,..._0x32cc2e){if(!_0xd98ed8)throw ws(_0x4dacef,..._0x32cc2e);}function ne(_0x19f1e7){const _0x30bb84='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x19f1e7;throw cn(_0x30bb84),new Error(_0x30bb84);}function ce(_0x51ba49,_0x307313){_0x51ba49||ne(_0x307313);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x31ad48;return typeof self<'u'&&((_0x31ad48=self['location'])==null?void 0x0:_0x31ad48['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0xcc92c1;return typeof self<'u'&&((_0xcc92c1=self['location'])==null?void 0x0:_0xcc92c1['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x42acf8=navigator;return _0x42acf8['languages']&&_0x42acf8['languages'][0x0]||_0x42acf8['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x25cc93,_0x3e50d7){this['shortDelay']=_0x25cc93,this['longDelay']=_0x3e50d7,ce(_0x3e50d7>_0x25cc93,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xbcf2a8,_0x376a0e){ce(_0xbcf2a8['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x16b245}=_0xbcf2a8['emulator'];return _0x376a0e?''+_0x16b245+(_0x376a0e['startsWith']('/')?_0x376a0e['slice'](0x1):_0x376a0e):_0x16b245;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xe11e67,_0x203170,_0x2243cd){this['fetchImpl']=_0xe11e67,_0x203170&&(this['headersImpl']=_0x203170),_0x2243cd&&(this['responseImpl']=_0x2243cd);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x10e35a,_0x545620){return _0x10e35a['tenantId']&&!_0x545620['tenantId']?{..._0x545620,'tenantId':_0x10e35a['tenantId']}:_0x545620;}async function Pe(_0x3efe11,_0x395a1e,_0x46a9d1,_0x2b2206,_0x534e9b={}){return Ca(_0x3efe11,_0x534e9b,async()=>{let _0x1d6479={},_0x335af9={};_0x2b2206&&(_0x395a1e==='GET'?_0x335af9=_0x2b2206:_0x1d6479={'body':JSON['stringify'](_0x2b2206)});const _0x23782f=ut({..._0x335af9,'key':_0x3efe11['config']['apiKey']})['slice'](0x1),_0x20529a=await _0x3efe11['_getAdditionalHeaders']();_0x20529a['Content-Type']='application/json',_0x3efe11['languageCode']&&(_0x20529a['X-Firebase-Locale']=_0x3efe11['languageCode']);const _0x40d6e4={'method':_0x395a1e,'headers':_0x20529a,..._0x1d6479};return dc()||(_0x40d6e4['referrerPolicy']='strict-origin-when-cross-origin'),_0x3efe11['emulatorConfig']&&qt(_0x3efe11['emulatorConfig']['host'])&&(_0x40d6e4['credentials']='include'),wa['fetch']()(await Ta(_0x3efe11,_0x3efe11['config']['apiHost'],_0x46a9d1,_0x23782f),_0x40d6e4);});}async function Ca(_0x218507,_0x246b09,_0x592d26){_0x218507['_canInitEmulator']=!0x1;const _0x43ab96={...df,..._0x246b09};try{const _0x5e9daf=new gf(_0x218507),_0x33e371=await Promise['race']([_0x592d26(),_0x5e9daf['promise']]);_0x5e9daf['clearNetworkTimeout']();const _0x44b1fb=await _0x33e371['json']();if('needConfirmation'in _0x44b1fb)throw on(_0x218507,'account-exists-with-different-credential',_0x44b1fb);if(_0x33e371['ok']&&!('errorMessage'in _0x44b1fb))return _0x44b1fb;{const _0x273ce3=_0x33e371['ok']?_0x44b1fb['errorMessage']:_0x44b1fb['error']['message'],[_0x361f7b,_0x5add48]=_0x273ce3['split']('\x20:\x20');if(_0x361f7b==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x218507,'credential-already-in-use',_0x44b1fb);if(_0x361f7b==='EMAIL_EXISTS')throw on(_0x218507,'email-already-in-use',_0x44b1fb);if(_0x361f7b==='USER_DISABLED')throw on(_0x218507,'user-disabled',_0x44b1fb);const _0x16b942=_0x43ab96[_0x361f7b]||_0x361f7b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5add48)throw Ia(_0x218507,_0x16b942,_0x5add48);Y(_0x218507,_0x16b942);}}catch(_0x243776){if(_0x243776 instanceof Re)throw _0x243776;Y(_0x218507,'network-request-failed',{'message':String(_0x243776)});}}async function en(_0x33b8c6,_0x159cb7,_0x356312,_0x5eaecd,_0x29f3bc={}){const _0x1a6195=await Pe(_0x33b8c6,_0x159cb7,_0x356312,_0x5eaecd,_0x29f3bc);return'mfaPendingCredential'in _0x1a6195&&Y(_0x33b8c6,'multi-factor-auth-required',{'_serverResponse':_0x1a6195}),_0x1a6195;}async function Ta(_0x5877b4,_0x122de2,_0x2f123b,_0x286e93){const _0x3d11b5=''+_0x122de2+_0x2f123b+'?'+_0x286e93,_0x175f33=_0x5877b4,_0x54e6f6=_0x175f33['config']['emulator']?Cs(_0x5877b4['config'],_0x3d11b5):_0x5877b4['config']['apiScheme']+'://'+_0x3d11b5;return ff['includes'](_0x2f123b)&&(await _0x175f33['_persistenceManagerAvailable'],_0x175f33['_getPersistenceType']()==='COOKIE')?_0x175f33['_getPersistence']()['_getFinalTarget'](_0x54e6f6)['toString']():_0x54e6f6;}function _f(_0x904054){switch(_0x904054){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x351d53){this['auth']=_0x351d53,this['timer']=null,this['promise']=new Promise((_0x227e67,_0xe88edf)=>{this['timer']=setTimeout(()=>_0xe88edf(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x47b7a0,_0x12dcbf,_0x18b5c6){const _0x1adfe6={'appName':_0x47b7a0['name']};_0x18b5c6['email']&&(_0x1adfe6['email']=_0x18b5c6['email']),_0x18b5c6['phoneNumber']&&(_0x1adfe6['phoneNumber']=_0x18b5c6['phoneNumber']);const _0x28dd9c=X(_0x47b7a0,_0x12dcbf,_0x1adfe6);return _0x28dd9c['customData']['_tokenResponse']=_0x18b5c6,_0x28dd9c;}function wr(_0x2cb7a5){return _0x2cb7a5!==void 0x0&&_0x2cb7a5['enterprise']!==void 0x0;}class mf{constructor(_0x51dc91){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x51dc91['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x51dc91['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x51dc91['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1e7505){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x50482d of this['recaptchaEnforcementState'])if(_0x50482d['provider']&&_0x50482d['provider']===_0x1e7505)return _f(_0x50482d['enforcementState']);return null;}['isProviderEnabled'](_0x378984){return this['getProviderEnforcementState'](_0x378984)==='ENFORCE'||this['getProviderEnforcementState'](_0x378984)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5dc5d2,_0x2fc0eb){return Pe(_0x5dc5d2,'GET','/v2/recaptchaConfig',ke(_0x5dc5d2,_0x2fc0eb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x873d3d,_0x21d97d){return Pe(_0x873d3d,'POST','/v1/accounts:delete',_0x21d97d);}async function Pn(_0x5e8671,_0x43fcf2){return Pe(_0x5e8671,'POST','/v1/accounts:lookup',_0x43fcf2);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x32cc6f){if(_0x32cc6f)try{const _0xe0e1dc=new Date(Number(_0x32cc6f));if(!isNaN(_0xe0e1dc['getTime']()))return _0xe0e1dc['toUTCString']();}catch{}}async function Ef(_0x2be48f,_0x31de1f=!0x1){const _0x1fd75b=P(_0x2be48f),_0x2d146a=await _0x1fd75b['getIdToken'](_0x31de1f),_0x3779bb=Ts(_0x2d146a);m(_0x3779bb&&_0x3779bb['exp']&&_0x3779bb['auth_time']&&_0x3779bb['iat'],_0x1fd75b['auth'],'internal-error');const _0x32e4c6=typeof _0x3779bb['firebase']=='object'?_0x3779bb['firebase']:void 0x0,_0x5b9177=_0x32e4c6==null?void 0x0:_0x32e4c6['sign_in_provider'];return{'claims':_0x3779bb,'token':_0x2d146a,'authTime':Pt(fi(_0x3779bb['auth_time'])),'issuedAtTime':Pt(fi(_0x3779bb['iat'])),'expirationTime':Pt(fi(_0x3779bb['exp'])),'signInProvider':_0x5b9177||null,'signInSecondFactor':(_0x32e4c6==null?void 0x0:_0x32e4c6['sign_in_second_factor'])||null};}function fi(_0xebdbdc){return Number(_0xebdbdc)*0x3e8;}function Ts(_0x5dd0e1){const [_0x4a465b,_0x1852c5,_0x15cc09]=_0x5dd0e1['split']('.');if(_0x4a465b===void 0x0||_0x1852c5===void 0x0||_0x15cc09===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2ae4f2=fn(_0x1852c5);return _0x2ae4f2?JSON['parse'](_0x2ae4f2):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x1b27c6){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x1b27c6==null?void 0x0:_0x1b27c6['toString']()),null;}}function Cr(_0x1ded84){const _0x287d06=Ts(_0x1ded84);return m(_0x287d06,'internal-error'),m(typeof _0x287d06['exp']<'u','internal-error'),m(typeof _0x287d06['iat']<'u','internal-error'),Number(_0x287d06['exp'])-Number(_0x287d06['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x7af79c,_0x117053,_0x18a7c6=!0x1){if(_0x18a7c6)return _0x117053;try{return await _0x117053;}catch(_0x56de7){throw _0x56de7 instanceof Re&&If(_0x56de7)&&_0x7af79c['auth']['currentUser']===_0x7af79c&&await _0x7af79c['auth']['signOut'](),_0x56de7;}}function If({code:_0x51ca4c}){return _0x51ca4c==='auth/user-disabled'||_0x51ca4c==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x203bbc){this['user']=_0x203bbc,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xadbaa5){if(_0xadbaa5){const _0x24c5ac=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x24c5ac;}else{this['errorBackoff']=0x7530;const _0x57702e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x57702e);}}['schedule'](_0x2aa12a=!0x1){if(!this['isRunning'])return;const _0x3ac4a6=this['getInterval'](_0x2aa12a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3ac4a6);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x580773){(_0x580773==null?void 0x0:_0x580773['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x1732b0,_0x2d6088){this['createdAt']=_0x1732b0,this['lastLoginAt']=_0x2d6088,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x430739){this['createdAt']=_0x430739['createdAt'],this['lastLoginAt']=_0x430739['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x46e41c){var _0x3fdc80;const _0x3dc98d=_0x46e41c['auth'],_0x5e1fa7=await _0x46e41c['getIdToken'](),_0x15d18f=await Ht(_0x46e41c,Pn(_0x3dc98d,{'idToken':_0x5e1fa7}));m(_0x15d18f==null?void 0x0:_0x15d18f['users']['length'],_0x3dc98d,'internal-error');const _0x31e409=_0x15d18f['users'][0x0];_0x46e41c['_notifyReloadListener'](_0x31e409);const _0xbc034=(_0x3fdc80=_0x31e409['providerUserInfo'])!=null&&_0x3fdc80['length']?Sa(_0x31e409['providerUserInfo']):[],_0x224f78=Tf(_0x46e41c['providerData'],_0xbc034),_0x2ea6ca=_0x46e41c['isAnonymous'],_0x2b844e=!(_0x46e41c['email']&&_0x31e409['passwordHash'])&&!(_0x224f78!=null&&_0x224f78['length']),_0xe7a074=_0x2ea6ca?_0x2b844e:!0x1,_0x484724={'uid':_0x31e409['localId'],'displayName':_0x31e409['displayName']||null,'photoURL':_0x31e409['photoUrl']||null,'email':_0x31e409['email']||null,'emailVerified':_0x31e409['emailVerified']||!0x1,'phoneNumber':_0x31e409['phoneNumber']||null,'tenantId':_0x31e409['tenantId']||null,'providerData':_0x224f78,'metadata':new Li(_0x31e409['createdAt'],_0x31e409['lastLoginAt']),'isAnonymous':_0xe7a074};Object['assign'](_0x46e41c,_0x484724);}async function Cf(_0x179511){const _0x9ef7fc=P(_0x179511);await Nn(_0x9ef7fc),await _0x9ef7fc['auth']['_persistUserIfCurrent'](_0x9ef7fc),_0x9ef7fc['auth']['_notifyListenersIfCurrent'](_0x9ef7fc);}function Tf(_0x562503,_0x1b9dee){return[..._0x562503['filter'](_0x10d84a=>!_0x1b9dee['some'](_0x35acbb=>_0x35acbb['providerId']===_0x10d84a['providerId'])),..._0x1b9dee];}function Sa(_0x2ad1a4){return _0x2ad1a4['map'](({providerId:_0x549b5a,..._0x4e2e4d})=>({'providerId':_0x549b5a,'uid':_0x4e2e4d['rawId']||'','displayName':_0x4e2e4d['displayName']||null,'email':_0x4e2e4d['email']||null,'phoneNumber':_0x4e2e4d['phoneNumber']||null,'photoURL':_0x4e2e4d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x45c8a9,_0x172bd8){const _0x455fbd=await Ca(_0x45c8a9,{},async()=>{const _0x2308eb=ut({'grant_type':'refresh_token','refresh_token':_0x172bd8})['slice'](0x1),{tokenApiHost:_0x13b42f,apiKey:_0x47bdaa}=_0x45c8a9['config'],_0x4c5138=await Ta(_0x45c8a9,_0x13b42f,'/v1/token','key='+_0x47bdaa),_0x42ed03=await _0x45c8a9['_getAdditionalHeaders']();_0x42ed03['Content-Type']='application/x-www-form-urlencoded';const _0x349250={'method':'POST','headers':_0x42ed03,'body':_0x2308eb};return _0x45c8a9['emulatorConfig']&&qt(_0x45c8a9['emulatorConfig']['host'])&&(_0x349250['credentials']='include'),wa['fetch']()(_0x4c5138,_0x349250);});return{'accessToken':_0x455fbd['access_token'],'expiresIn':_0x455fbd['expires_in'],'refreshToken':_0x455fbd['refresh_token']};}async function bf(_0x2da493,_0x2c1c33){return Pe(_0x2da493,'POST','/v2/accounts:revokeToken',ke(_0x2da493,_0x2c1c33));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x1d0be3){m(_0x1d0be3['idToken'],'internal-error'),m(typeof _0x1d0be3['idToken']<'u','internal-error'),m(typeof _0x1d0be3['refreshToken']<'u','internal-error');const _0x162cdb='expiresIn'in _0x1d0be3&&typeof _0x1d0be3['expiresIn']<'u'?Number(_0x1d0be3['expiresIn']):Cr(_0x1d0be3['idToken']);this['updateTokensAndExpiration'](_0x1d0be3['idToken'],_0x1d0be3['refreshToken'],_0x162cdb);}['updateFromIdToken'](_0x387d58){m(_0x387d58['length']!==0x0,'internal-error');const _0x1677e3=Cr(_0x387d58);this['updateTokensAndExpiration'](_0x387d58,null,_0x1677e3);}async['getToken'](_0x49aca4,_0x402090=!0x1){return!_0x402090&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x49aca4,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x49aca4,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x39ef79,_0x354d1a){const {accessToken:_0x1945a1,refreshToken:_0x59ad34,expiresIn:_0x18cf62}=await Sf(_0x39ef79,_0x354d1a);this['updateTokensAndExpiration'](_0x1945a1,_0x59ad34,Number(_0x18cf62));}['updateTokensAndExpiration'](_0x29e8a9,_0x580fe6,_0x2146da){this['refreshToken']=_0x580fe6||null,this['accessToken']=_0x29e8a9||null,this['expirationTime']=Date['now']()+_0x2146da*0x3e8;}static['fromJSON'](_0x476851,_0x29d1c5){const {refreshToken:_0x52e609,accessToken:_0x17c801,expirationTime:_0x490777}=_0x29d1c5,_0x12bf03=new et();return _0x52e609&&(m(typeof _0x52e609=='string','internal-error',{'appName':_0x476851}),_0x12bf03['refreshToken']=_0x52e609),_0x17c801&&(m(typeof _0x17c801=='string','internal-error',{'appName':_0x476851}),_0x12bf03['accessToken']=_0x17c801),_0x490777&&(m(typeof _0x490777=='number','internal-error',{'appName':_0x476851}),_0x12bf03['expirationTime']=_0x490777),_0x12bf03;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5e5677){this['accessToken']=_0x5e5677['accessToken'],this['refreshToken']=_0x5e5677['refreshToken'],this['expirationTime']=_0x5e5677['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x323757,_0x3ec662){m(typeof _0x323757=='string'||typeof _0x323757>'u','internal-error',{'appName':_0x3ec662});}class j{constructor({uid:_0x585326,auth:_0x47178a,stsTokenManager:_0x260768,..._0x4bbe5b}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x585326,this['auth']=_0x47178a,this['stsTokenManager']=_0x260768,this['accessToken']=_0x260768['accessToken'],this['displayName']=_0x4bbe5b['displayName']||null,this['email']=_0x4bbe5b['email']||null,this['emailVerified']=_0x4bbe5b['emailVerified']||!0x1,this['phoneNumber']=_0x4bbe5b['phoneNumber']||null,this['photoURL']=_0x4bbe5b['photoURL']||null,this['isAnonymous']=_0x4bbe5b['isAnonymous']||!0x1,this['tenantId']=_0x4bbe5b['tenantId']||null,this['providerData']=_0x4bbe5b['providerData']?[..._0x4bbe5b['providerData']]:[],this['metadata']=new Li(_0x4bbe5b['createdAt']||void 0x0,_0x4bbe5b['lastLoginAt']||void 0x0);}async['getIdToken'](_0x900dfe){const _0x554e5f=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x900dfe));return m(_0x554e5f,this['auth'],'internal-error'),this['accessToken']!==_0x554e5f&&(this['accessToken']=_0x554e5f,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x554e5f;}['getIdTokenResult'](_0x5a6c40){return Ef(this,_0x5a6c40);}['reload'](){return Cf(this);}['_assign'](_0x52a5b1){this!==_0x52a5b1&&(m(this['uid']===_0x52a5b1['uid'],this['auth'],'internal-error'),this['displayName']=_0x52a5b1['displayName'],this['photoURL']=_0x52a5b1['photoURL'],this['email']=_0x52a5b1['email'],this['emailVerified']=_0x52a5b1['emailVerified'],this['phoneNumber']=_0x52a5b1['phoneNumber'],this['isAnonymous']=_0x52a5b1['isAnonymous'],this['tenantId']=_0x52a5b1['tenantId'],this['providerData']=_0x52a5b1['providerData']['map'](_0x4ad28a=>({..._0x4ad28a})),this['metadata']['_copy'](_0x52a5b1['metadata']),this['stsTokenManager']['_assign'](_0x52a5b1['stsTokenManager']));}['_clone'](_0x1083ba){const _0x1480f4=new j({...this,'auth':_0x1083ba,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1480f4['metadata']['_copy'](this['metadata']),_0x1480f4;}['_onReload'](_0x379ac5){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x379ac5,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x45f56c){this['reloadListener']?this['reloadListener'](_0x45f56c):this['reloadUserInfo']=_0x45f56c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x27b20d,_0x19b088=!0x1){let _0x58ec94=!0x1;_0x27b20d['idToken']&&_0x27b20d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x27b20d),_0x58ec94=!0x0),_0x19b088&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x58ec94&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0xb15216=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0xb15216})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x177102=>({..._0x177102})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5c9bf8,_0x286c28){const _0x1d75a6=_0x286c28['displayName']??void 0x0,_0x32d84e=_0x286c28['email']??void 0x0,_0xc3f9bc=_0x286c28['phoneNumber']??void 0x0,_0x1267d2=_0x286c28['photoURL']??void 0x0,_0x418dc8=_0x286c28['tenantId']??void 0x0,_0x25efa9=_0x286c28['_redirectEventId']??void 0x0,_0x3ef6ad=_0x286c28['createdAt']??void 0x0,_0x240eb0=_0x286c28['lastLoginAt']??void 0x0,{uid:_0x1ebec6,emailVerified:_0x2e931e,isAnonymous:_0x4c853c,providerData:_0x42a7bb,stsTokenManager:_0x594994}=_0x286c28;m(_0x1ebec6&&_0x594994,_0x5c9bf8,'internal-error');const _0x373553=et['fromJSON'](this['name'],_0x594994);m(typeof _0x1ebec6=='string',_0x5c9bf8,'internal-error'),le(_0x1d75a6,_0x5c9bf8['name']),le(_0x32d84e,_0x5c9bf8['name']),m(typeof _0x2e931e=='boolean',_0x5c9bf8,'internal-error'),m(typeof _0x4c853c=='boolean',_0x5c9bf8,'internal-error'),le(_0xc3f9bc,_0x5c9bf8['name']),le(_0x1267d2,_0x5c9bf8['name']),le(_0x418dc8,_0x5c9bf8['name']),le(_0x25efa9,_0x5c9bf8['name']),le(_0x3ef6ad,_0x5c9bf8['name']),le(_0x240eb0,_0x5c9bf8['name']);const _0x5263ec=new j({'uid':_0x1ebec6,'auth':_0x5c9bf8,'email':_0x32d84e,'emailVerified':_0x2e931e,'displayName':_0x1d75a6,'isAnonymous':_0x4c853c,'photoURL':_0x1267d2,'phoneNumber':_0xc3f9bc,'tenantId':_0x418dc8,'stsTokenManager':_0x373553,'createdAt':_0x3ef6ad,'lastLoginAt':_0x240eb0});return _0x42a7bb&&Array['isArray'](_0x42a7bb)&&(_0x5263ec['providerData']=_0x42a7bb['map'](_0x24d67b=>({..._0x24d67b}))),_0x25efa9&&(_0x5263ec['_redirectEventId']=_0x25efa9),_0x5263ec;}static async['_fromIdTokenResponse'](_0xad9d15,_0x213576,_0x5c9a4b=!0x1){const _0xa3a61c=new et();_0xa3a61c['updateFromServerResponse'](_0x213576);const _0x57cb88=new j({'uid':_0x213576['localId'],'auth':_0xad9d15,'stsTokenManager':_0xa3a61c,'isAnonymous':_0x5c9a4b});return await Nn(_0x57cb88),_0x57cb88;}static async['_fromGetAccountInfoResponse'](_0x414dfa,_0x5176b2,_0x45fcf5){const _0xe8fb11=_0x5176b2['users'][0x0];m(_0xe8fb11['localId']!==void 0x0,'internal-error');const _0x464a59=_0xe8fb11['providerUserInfo']!==void 0x0?Sa(_0xe8fb11['providerUserInfo']):[],_0x5e626f=!(_0xe8fb11['email']&&_0xe8fb11['passwordHash'])&&!(_0x464a59!=null&&_0x464a59['length']),_0x302e00=new et();_0x302e00['updateFromIdToken'](_0x45fcf5);const _0x2b0ff2=new j({'uid':_0xe8fb11['localId'],'auth':_0x414dfa,'stsTokenManager':_0x302e00,'isAnonymous':_0x5e626f}),_0x296e9c={'uid':_0xe8fb11['localId'],'displayName':_0xe8fb11['displayName']||null,'photoURL':_0xe8fb11['photoUrl']||null,'email':_0xe8fb11['email']||null,'emailVerified':_0xe8fb11['emailVerified']||!0x1,'phoneNumber':_0xe8fb11['phoneNumber']||null,'tenantId':_0xe8fb11['tenantId']||null,'providerData':_0x464a59,'metadata':new Li(_0xe8fb11['createdAt'],_0xe8fb11['lastLoginAt']),'isAnonymous':!(_0xe8fb11['email']&&_0xe8fb11['passwordHash'])&&!(_0x464a59!=null&&_0x464a59['length'])};return Object['assign'](_0x2b0ff2,_0x296e9c),_0x2b0ff2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x10743a){ce(_0x10743a instanceof Function,'Expected\x20a\x20class\x20definition');let _0x3496b9=Tr['get'](_0x10743a);return _0x3496b9?(ce(_0x3496b9 instanceof _0x10743a,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x3496b9):(_0x3496b9=new _0x10743a(),Tr['set'](_0x10743a,_0x3496b9),_0x3496b9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1f65c0,_0x48174c){this['storage'][_0x1f65c0]=_0x48174c;}async['_get'](_0x27a8e5){const _0x35a761=this['storage'][_0x27a8e5];return _0x35a761===void 0x0?null:_0x35a761;}async['_remove'](_0x3e866e){delete this['storage'][_0x3e866e];}['_addListener'](_0x58edbf,_0x3ccd9b){}['_removeListener'](_0x20e852,_0x28eaa6){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4e973b,_0x3057ea,_0x4df609){return'firebase:'+_0x4e973b+':'+_0x3057ea+':'+_0x4df609;}class tt{constructor(_0x3fe7f6,_0x497f44,_0x13b296){this['persistence']=_0x3fe7f6,this['auth']=_0x497f44,this['userKey']=_0x13b296;const {config:_0x203c0a,name:_0x724a6a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x203c0a['apiKey'],_0x724a6a),this['fullPersistenceKey']=ln('persistence',_0x203c0a['apiKey'],_0x724a6a),this['boundEventHandler']=_0x497f44['_onStorageEvent']['bind'](_0x497f44),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3c2804){return this['persistence']['_set'](this['fullUserKey'],_0x3c2804['toJSON']());}async['getCurrentUser'](){const _0x4a5f32=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4a5f32)return null;if(typeof _0x4a5f32=='string'){const _0xd42bc9=await Pn(this['auth'],{'idToken':_0x4a5f32})['catch'](()=>{});return _0xd42bc9?j['_fromGetAccountInfoResponse'](this['auth'],_0xd42bc9,_0x4a5f32):null;}return j['_fromJSON'](this['auth'],_0x4a5f32);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1af42c){if(this['persistence']===_0x1af42c)return;const _0x38487d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1af42c,_0x38487d)return this['setCurrentUser'](_0x38487d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1d8ee3,_0x22aad5,_0x1e1652='authUser'){if(!_0x22aad5['length'])return new tt(ie(Sr),_0x1d8ee3,_0x1e1652);const _0x3b7b68=(await Promise['all'](_0x22aad5['map'](async _0x52cd6f=>{if(await _0x52cd6f['_isAvailable']())return _0x52cd6f;})))['filter'](_0x32dcc0=>_0x32dcc0);let _0x5d22b3=_0x3b7b68[0x0]||ie(Sr);const _0x2590d2=ln(_0x1e1652,_0x1d8ee3['config']['apiKey'],_0x1d8ee3['name']);let _0x58548f=null;for(const _0x2b6c11 of _0x22aad5)try{const _0x289882=await _0x2b6c11['_get'](_0x2590d2);if(_0x289882){let _0x446111;if(typeof _0x289882=='string'){const _0x10c6db=await Pn(_0x1d8ee3,{'idToken':_0x289882})['catch'](()=>{});if(!_0x10c6db)break;_0x446111=await j['_fromGetAccountInfoResponse'](_0x1d8ee3,_0x10c6db,_0x289882);}else _0x446111=j['_fromJSON'](_0x1d8ee3,_0x289882);_0x2b6c11!==_0x5d22b3&&(_0x58548f=_0x446111),_0x5d22b3=_0x2b6c11;break;}}catch{}const _0x2963d6=_0x3b7b68['filter'](_0x56382a=>_0x56382a['_shouldAllowMigration']);return!_0x5d22b3['_shouldAllowMigration']||!_0x2963d6['length']?new tt(_0x5d22b3,_0x1d8ee3,_0x1e1652):(_0x5d22b3=_0x2963d6[0x0],_0x58548f&&await _0x5d22b3['_set'](_0x2590d2,_0x58548f['toJSON']()),await Promise['all'](_0x22aad5['map'](async _0x387dc7=>{if(_0x387dc7!==_0x5d22b3)try{await _0x387dc7['_remove'](_0x2590d2);}catch{}})),new tt(_0x5d22b3,_0x1d8ee3,_0x1e1652));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1cb86f){const _0x306de8=_0x1cb86f['toLowerCase']();if(_0x306de8['includes']('opera/')||_0x306de8['includes']('opr/')||_0x306de8['includes']('opios/'))return'Opera';if(Pa(_0x306de8))return'IEMobile';if(_0x306de8['includes']('msie')||_0x306de8['includes']('trident/'))return'IE';if(_0x306de8['includes']('edge/'))return'Edge';if(Ra(_0x306de8))return'Firefox';if(_0x306de8['includes']('silk/'))return'Silk';if(Oa(_0x306de8))return'Blackberry';if(Da(_0x306de8))return'Webos';if(Aa(_0x306de8))return'Safari';if((_0x306de8['includes']('chrome/')||ka(_0x306de8))&&!_0x306de8['includes']('edge/'))return'Chrome';if(Na(_0x306de8))return'Android';{const _0x40316d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x33515a=_0x1cb86f['match'](_0x40316d);if((_0x33515a==null?void 0x0:_0x33515a['length'])===0x2)return _0x33515a[0x1];}return'Other';}function Ra(_0x20ec93=W()){return/firefox\//i['test'](_0x20ec93);}function Aa(_0x230714=W()){const _0x10607d=_0x230714['toLowerCase']();return _0x10607d['includes']('safari/')&&!_0x10607d['includes']('chrome/')&&!_0x10607d['includes']('crios/')&&!_0x10607d['includes']('android');}function ka(_0x4bb22b=W()){return/crios\//i['test'](_0x4bb22b);}function Pa(_0x17849f=W()){return/iemobile/i['test'](_0x17849f);}function Na(_0x4cf4a5=W()){return/android/i['test'](_0x4cf4a5);}function Oa(_0x49ac6f=W()){return/blackberry/i['test'](_0x49ac6f);}function Da(_0x4df46f=W()){return/webos/i['test'](_0x4df46f);}function Ss(_0x559983=W()){return/iphone|ipad|ipod/i['test'](_0x559983)||/macintosh/i['test'](_0x559983)&&/mobile/i['test'](_0x559983);}function Rf(_0x5a6344=W()){var _0x57e953;return Ss(_0x5a6344)&&!!((_0x57e953=window['navigator'])!=null&&_0x57e953['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x588a33=W()){return Ss(_0x588a33)||Na(_0x588a33)||Da(_0x588a33)||Oa(_0x588a33)||/windows phone/i['test'](_0x588a33)||Pa(_0x588a33);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x9ca3e3,_0x199999=[]){let _0xd59bb1;switch(_0x9ca3e3){case'Browser':_0xd59bb1=br(W());break;case'Worker':_0xd59bb1=br(W())+'-'+_0x9ca3e3;break;default:_0xd59bb1=_0x9ca3e3;}const _0x4238ba=_0x199999['length']?_0x199999['join'](','):'FirebaseCore-web';return _0xd59bb1+'/JsCore/'+dt+'/'+_0x4238ba;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3d4b06){this['auth']=_0x3d4b06,this['queue']=[];}['pushCallback'](_0x188640,_0x48d3b1){const _0x48f773=_0x1c476d=>new Promise((_0x57da1b,_0x4a4a14)=>{try{const _0x351b06=_0x188640(_0x1c476d);_0x57da1b(_0x351b06);}catch(_0x5ce4e7){_0x4a4a14(_0x5ce4e7);}});_0x48f773['onAbort']=_0x48d3b1,this['queue']['push'](_0x48f773);const _0x571f02=this['queue']['length']-0x1;return()=>{this['queue'][_0x571f02]=()=>Promise['resolve']();};}async['runMiddleware'](_0xce259){if(this['auth']['currentUser']===_0xce259)return;const _0x5d93a9=[];try{for(const _0x6d8966 of this['queue'])await _0x6d8966(_0xce259),_0x6d8966['onAbort']&&_0x5d93a9['push'](_0x6d8966['onAbort']);}catch(_0x59cd96){_0x5d93a9['reverse']();for(const _0x588215 of _0x5d93a9)try{_0x588215();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x59cd96==null?void 0x0:_0x59cd96['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x59a58b,_0x55906d={}){return Pe(_0x59a58b,'GET','/v2/passwordPolicy',ke(_0x59a58b,_0x55906d));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x293bbc){var _0xe41718;const _0x19e0eb=_0x293bbc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x19e0eb['minPasswordLength']??Nf,_0x19e0eb['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x19e0eb['maxPasswordLength']),_0x19e0eb['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x19e0eb['containsLowercaseCharacter']),_0x19e0eb['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x19e0eb['containsUppercaseCharacter']),_0x19e0eb['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x19e0eb['containsNumericCharacter']),_0x19e0eb['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x19e0eb['containsNonAlphanumericCharacter']),this['enforcementState']=_0x293bbc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xe41718=_0x293bbc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xe41718['join'](''))??'',this['forceUpgradeOnSignin']=_0x293bbc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x293bbc['schemaVersion'];}['validatePassword'](_0x41064b){const _0x498ee2={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x41064b,_0x498ee2),this['validatePasswordCharacterOptions'](_0x41064b,_0x498ee2),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['meetsMinPasswordLength']??!0x0),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['meetsMaxPasswordLength']??!0x0),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['containsLowercaseLetter']??!0x0),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['containsUppercaseLetter']??!0x0),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['containsNumericCharacter']??!0x0),_0x498ee2['isValid']&&(_0x498ee2['isValid']=_0x498ee2['containsNonAlphanumericCharacter']??!0x0),_0x498ee2;}['validatePasswordLengthOptions'](_0x649f97,_0x1dcd6f){const _0x22d980=this['customStrengthOptions']['minPasswordLength'],_0x2ef400=this['customStrengthOptions']['maxPasswordLength'];_0x22d980&&(_0x1dcd6f['meetsMinPasswordLength']=_0x649f97['length']>=_0x22d980),_0x2ef400&&(_0x1dcd6f['meetsMaxPasswordLength']=_0x649f97['length']<=_0x2ef400);}['validatePasswordCharacterOptions'](_0x250ffe,_0xde397c){this['updatePasswordCharacterOptionsStatuses'](_0xde397c,!0x1,!0x1,!0x1,!0x1);let _0xdf4336;for(let _0x1819bd=0x0;_0x1819bd<_0x250ffe['length'];_0x1819bd++)_0xdf4336=_0x250ffe['charAt'](_0x1819bd),this['updatePasswordCharacterOptionsStatuses'](_0xde397c,_0xdf4336>='a'&&_0xdf4336<='z',_0xdf4336>='A'&&_0xdf4336<='Z',_0xdf4336>='0'&&_0xdf4336<='9',this['allowedNonAlphanumericCharacters']['includes'](_0xdf4336));}['updatePasswordCharacterOptionsStatuses'](_0x2382f5,_0x8fb643,_0x3ccf36,_0x433515,_0x1e9cc3){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2382f5['containsLowercaseLetter']||(_0x2382f5['containsLowercaseLetter']=_0x8fb643)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2382f5['containsUppercaseLetter']||(_0x2382f5['containsUppercaseLetter']=_0x3ccf36)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2382f5['containsNumericCharacter']||(_0x2382f5['containsNumericCharacter']=_0x433515)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2382f5['containsNonAlphanumericCharacter']||(_0x2382f5['containsNonAlphanumericCharacter']=_0x1e9cc3));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x261fb3,_0x17592c,_0x259ba0,_0x3ed62f){this['app']=_0x261fb3,this['heartbeatServiceProvider']=_0x17592c,this['appCheckServiceProvider']=_0x259ba0,this['config']=_0x3ed62f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x261fb3['name'],this['clientVersion']=_0x3ed62f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x12cccd=>this['_resolvePersistenceManagerAvailable']=_0x12cccd);}['_initializeWithPersistence'](_0x513429,_0x1ae75e){return _0x1ae75e&&(this['_popupRedirectResolver']=ie(_0x1ae75e)),this['_initializationPromise']=this['queue'](async()=>{var _0xe8f510,_0xea405b,_0xb0875e;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x513429),(_0xe8f510=this['_resolvePersistenceManagerAvailable'])==null||_0xe8f510['call'](this),!this['_deleted'])){if((_0xea405b=this['_popupRedirectResolver'])!=null&&_0xea405b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1ae75e),this['lastNotifiedUid']=((_0xb0875e=this['currentUser'])==null?void 0x0:_0xb0875e['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x19e560=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x19e560)){if(this['currentUser']&&_0x19e560&&this['currentUser']['uid']===_0x19e560['uid']){this['_currentUser']['_assign'](_0x19e560),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x19e560,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2683a6){try{const _0x152cd0=await Pn(this,{'idToken':_0x2683a6}),_0x16874d=await j['_fromGetAccountInfoResponse'](this,_0x152cd0,_0x2683a6);await this['directlySetCurrentUser'](_0x16874d);}catch(_0x2c1cfc){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2c1cfc),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x35c433){var _0x3cd6b8;if($(this['app'])){const _0x1f1a7d=this['app']['settings']['authIdToken'];return _0x1f1a7d?new Promise(_0x5bd651=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1f1a7d)['then'](_0x5bd651,_0x5bd651));}):this['directlySetCurrentUser'](null);}const _0x55e41a=await this['assertedPersistence']['getCurrentUser']();let _0x3b0a27=_0x55e41a,_0x586083=!0x1;if(_0x35c433&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x43f66a=(_0x3cd6b8=this['redirectUser'])==null?void 0x0:_0x3cd6b8['_redirectEventId'],_0x1bb8da=_0x3b0a27==null?void 0x0:_0x3b0a27['_redirectEventId'],_0x32bfa2=await this['tryRedirectSignIn'](_0x35c433);(!_0x43f66a||_0x43f66a===_0x1bb8da)&&(_0x32bfa2!=null&&_0x32bfa2['user'])&&(_0x3b0a27=_0x32bfa2['user'],_0x586083=!0x0);}if(!_0x3b0a27)return this['directlySetCurrentUser'](null);if(!_0x3b0a27['_redirectEventId']){if(_0x586083)try{await this['beforeStateQueue']['runMiddleware'](_0x3b0a27);}catch(_0x362e20){_0x3b0a27=_0x55e41a,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x362e20));}return _0x3b0a27?this['reloadAndSetCurrentUserOrClear'](_0x3b0a27):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3b0a27['_redirectEventId']?this['directlySetCurrentUser'](_0x3b0a27):this['reloadAndSetCurrentUserOrClear'](_0x3b0a27);}async['tryRedirectSignIn'](_0x47d5f1){let _0x496bf3=null;try{_0x496bf3=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x47d5f1,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x496bf3;}async['reloadAndSetCurrentUserOrClear'](_0x60f376){try{await Nn(_0x60f376);}catch(_0x12b00d){if((_0x12b00d==null?void 0x0:_0x12b00d['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x60f376);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x5a0284){if($(this['app']))return Promise['reject'](re(this));const _0x17570d=_0x5a0284?P(_0x5a0284):null;return _0x17570d&&m(_0x17570d['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x17570d&&_0x17570d['_clone'](this));}async['_updateCurrentUser'](_0x375a36,_0x5f2af6=!0x1){if(!this['_deleted'])return _0x375a36&&m(this['tenantId']===_0x375a36['tenantId'],this,'tenant-id-mismatch'),_0x5f2af6||await this['beforeStateQueue']['runMiddleware'](_0x375a36),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x375a36),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4bb256){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4bb256));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xfb4605){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0xc58afc=this['_getPasswordPolicyInternal']();return _0xc58afc['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0xc58afc['validatePassword'](_0xfb4605);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xff2253=await Pf(this),_0x5bd3a0=new Of(_0xff2253);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5bd3a0:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5bd3a0;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x4196db){this['_errorFactory']=new Gt('auth','Firebase',_0x4196db());}['onAuthStateChanged'](_0x53d943,_0x17f968,_0x4c0644){return this['registerStateListener'](this['authStateSubscription'],_0x53d943,_0x17f968,_0x4c0644);}['beforeAuthStateChanged'](_0x51e2f9,_0x336ba4){return this['beforeStateQueue']['pushCallback'](_0x51e2f9,_0x336ba4);}['onIdTokenChanged'](_0x271992,_0x44bde1,_0x39c659){return this['registerStateListener'](this['idTokenSubscription'],_0x271992,_0x44bde1,_0x39c659);}['authStateReady'](){return new Promise((_0x2a6d4b,_0x4845b9)=>{if(this['currentUser'])_0x2a6d4b();else{const _0x4a9fdd=this['onAuthStateChanged'](()=>{_0x4a9fdd(),_0x2a6d4b();},_0x4845b9);}});}async['revokeAccessToken'](_0xd16447){if(this['currentUser']){const _0x57921e=await this['currentUser']['getIdToken'](),_0x2ef394={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0xd16447,'idToken':_0x57921e};this['tenantId']!=null&&(_0x2ef394['tenantId']=this['tenantId']),await bf(this,_0x2ef394);}}['toJSON'](){var _0x4c15bc;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4c15bc=this['_currentUser'])==null?void 0x0:_0x4c15bc['toJSON']()};}async['_setRedirectUser'](_0x26ccd7,_0x5d8c40){const _0x13ee2c=await this['getOrInitRedirectPersistenceManager'](_0x5d8c40);return _0x26ccd7===null?_0x13ee2c['removeCurrentUser']():_0x13ee2c['setCurrentUser'](_0x26ccd7);}async['getOrInitRedirectPersistenceManager'](_0x26c812){if(!this['redirectPersistenceManager']){const _0x23dee2=_0x26c812&&ie(_0x26c812)||this['_popupRedirectResolver'];m(_0x23dee2,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x23dee2['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5c67ea){var _0x520da0,_0x4becd9;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x520da0=this['_currentUser'])==null?void 0x0:_0x520da0['_redirectEventId'])===_0x5c67ea?this['_currentUser']:((_0x4becd9=this['redirectUser'])==null?void 0x0:_0x4becd9['_redirectEventId'])===_0x5c67ea?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x332cf6){if(_0x332cf6===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x332cf6));}['_notifyListenersIfCurrent'](_0x3fdd12){_0x3fdd12===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x22a231;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3da10e=((_0x22a231=this['currentUser'])==null?void 0x0:_0x22a231['uid'])??null;this['lastNotifiedUid']!==_0x3da10e&&(this['lastNotifiedUid']=_0x3da10e,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xb9d99c,_0x2a9f78,_0x35f129,_0x1b2451){if(this['_deleted'])return()=>{};const _0x44086e=typeof _0x2a9f78=='function'?_0x2a9f78:_0x2a9f78['next']['bind'](_0x2a9f78);let _0xa60d93=!0x1;const _0xdf3d09=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xdf3d09,this,'internal-error'),_0xdf3d09['then'](()=>{_0xa60d93||_0x44086e(this['currentUser']);}),typeof _0x2a9f78=='function'){const _0x1c37c2=_0xb9d99c['addObserver'](_0x2a9f78,_0x35f129,_0x1b2451);return()=>{_0xa60d93=!0x0,_0x1c37c2();};}else{const _0x7ed3b=_0xb9d99c['addObserver'](_0x2a9f78);return()=>{_0xa60d93=!0x0,_0x7ed3b();};}}async['directlySetCurrentUser'](_0x1b3576){this['currentUser']&&this['currentUser']!==_0x1b3576&&this['_currentUser']['_stopProactiveRefresh'](),_0x1b3576&&this['isProactiveRefreshEnabled']&&_0x1b3576['_startProactiveRefresh'](),this['currentUser']=_0x1b3576,_0x1b3576?await this['assertedPersistence']['setCurrentUser'](_0x1b3576):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x34f831){return this['operations']=this['operations']['then'](_0x34f831,_0x34f831),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3a4e91){!_0x3a4e91||this['frameworks']['includes'](_0x3a4e91)||(this['frameworks']['push'](_0x3a4e91),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x563836;const _0x753299={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x753299['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x332017=await((_0x563836=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x563836['getHeartbeatsHeader']());_0x332017&&(_0x753299['X-Firebase-Client']=_0x332017);const _0x3acd67=await this['_getAppCheckToken']();return _0x3acd67&&(_0x753299['X-Firebase-AppCheck']=_0x3acd67),_0x753299;}async['_getAppCheckToken'](){var _0x34d258;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3bb5df=await((_0x34d258=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x34d258['getToken']());return _0x3bb5df!=null&&_0x3bb5df['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3bb5df['error']),_0x3bb5df==null?void 0x0:_0x3bb5df['token'];}}function Ke(_0x34abbf){return P(_0x34abbf);}class Rr{constructor(_0x2ed74f){this['auth']=_0x2ed74f,this['observer']=null,this['addObserver']=Tc(_0x28da5b=>this['observer']=_0x28da5b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x3b18b6){Jn=_0x3b18b6;}function xa(_0x211c93){return Jn['loadJS'](_0x211c93);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x55333d){return'__'+_0x55333d+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xaf27b3){_0xaf27b3();}['execute'](_0x1225c8,_0x1cb1b0){return Promise['resolve']('token');}['render'](_0x3ec0c3,_0x5f3ed5){return'';}}class Wf{['ready'](_0x5c4a87){_0x5c4a87();}['execute'](_0x267d33,_0x143932){return Promise['resolve']('token');}['render'](_0x4f5107,_0x24f73b){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x5adc3c){this['type']=Bf,this['auth']=Ke(_0x5adc3c);}async['verify'](_0x24d082='verify',_0x3e14a9=!0x1){async function _0x5c4bbf(_0x4bb570){if(!_0x3e14a9){if(_0x4bb570['tenantId']==null&&_0x4bb570['_agentRecaptchaConfig']!=null)return _0x4bb570['_agentRecaptchaConfig']['siteKey'];if(_0x4bb570['tenantId']!=null&&_0x4bb570['_tenantRecaptchaConfigs'][_0x4bb570['tenantId']]!==void 0x0)return _0x4bb570['_tenantRecaptchaConfigs'][_0x4bb570['tenantId']]['siteKey'];}return new Promise(async(_0x3bc396,_0x5871e7)=>{yf(_0x4bb570,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2a5142=>{if(_0x2a5142['recaptchaKey']===void 0x0)_0x5871e7(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0xd013ea=new mf(_0x2a5142);return _0x4bb570['tenantId']==null?_0x4bb570['_agentRecaptchaConfig']=_0xd013ea:_0x4bb570['_tenantRecaptchaConfigs'][_0x4bb570['tenantId']]=_0xd013ea,_0x3bc396(_0xd013ea['siteKey']);}})['catch'](_0x43fbe9=>{_0x5871e7(_0x43fbe9);});});}function _0x3dd987(_0x5c3162,_0x54023c,_0xbd33be){const _0x5a6d75=window['grecaptcha'];wr(_0x5a6d75)?_0x5a6d75['enterprise']['ready'](()=>{_0x5a6d75['enterprise']['execute'](_0x5c3162,{'action':_0x24d082})['then'](_0x26d63b=>{_0x54023c(_0x26d63b);})['catch'](()=>{_0x54023c(Fa);});}):_0xbd33be(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x494726,_0x2a6c8d)=>{_0x5c4bbf(this['auth'])['then'](async _0xd47b05=>{if(!_0x3e14a9&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x3dd987(_0xd47b05,_0x494726,_0x2a6c8d);else{if(typeof window>'u'){_0x2a6c8d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x345f49=Lf();_0x345f49['length']!==0x0&&(_0x345f49+=_0xd47b05+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0xeda26a;(_0xeda26a=he['scriptInjectionDeferred'])==null||_0xeda26a['resolve']();},xa(_0x345f49)['then'](()=>{var _0x38af61;return(_0x38af61=he['scriptInjectionDeferred'])==null?void 0x0:_0x38af61['promise'];})['then'](()=>{_0x3dd987(_0xd47b05,_0x494726,_0x2a6c8d);})['catch'](_0x239a6e=>{_0x2a6c8d(_0x239a6e);});}})['catch'](_0x1035f1=>{_0x2a6c8d(_0x1035f1);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x32b8d7,_0x429c8e,_0x510cd2,_0x156380=!0x1,_0x4d007f=!0x1){const _0x5c824d=new he(_0x32b8d7);let _0x404621;if(_0x4d007f)_0x404621=Fa;else try{_0x404621=await _0x5c824d['verify'](_0x510cd2);}catch{_0x404621=await _0x5c824d['verify'](_0x510cd2,!0x0);}const _0x5be930={..._0x429c8e};if(_0x510cd2==='mfaSmsEnrollment'||_0x510cd2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5be930){const _0x416bdc=_0x5be930['phoneEnrollmentInfo']['phoneNumber'],_0x1733db=_0x5be930['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5be930,{'phoneEnrollmentInfo':{'phoneNumber':_0x416bdc,'recaptchaToken':_0x1733db,'captchaResponse':_0x404621,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5be930){const _0xf3d06=_0x5be930['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5be930,{'phoneSignInInfo':{'recaptchaToken':_0xf3d06,'captchaResponse':_0x404621,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5be930;}return _0x156380?Object['assign'](_0x5be930,{'captchaResp':_0x404621}):Object['assign'](_0x5be930,{'captchaResponse':_0x404621}),Object['assign'](_0x5be930,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5be930,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5be930;}async function xi(_0x11333d,_0x17db81,_0x45a76a,_0x31c760,_0x38bfa0){var _0x4f2a98;if((_0x4f2a98=_0x11333d['_getRecaptchaConfig']())!=null&&_0x4f2a98['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x55b012=await kr(_0x11333d,_0x17db81,_0x45a76a,_0x45a76a==='getOobCode');return _0x31c760(_0x11333d,_0x55b012);}else return _0x31c760(_0x11333d,_0x17db81)['catch'](async _0x141cc5=>{if(_0x141cc5['code']==='auth/missing-recaptcha-token'){console['log'](_0x45a76a+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x338e9e=await kr(_0x11333d,_0x17db81,_0x45a76a,_0x45a76a==='getOobCode');return _0x31c760(_0x11333d,_0x338e9e);}else return Promise['reject'](_0x141cc5);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x926258,_0xa000b9){const _0x14b719=Hi(_0x926258,'auth');if(_0x14b719['isInitialized']()){const _0x4532ca=_0x14b719['getImmediate'](),_0x3c521b=_0x14b719['getOptions']();if(xe(_0x3c521b,_0xa000b9??{}))return _0x4532ca;Y(_0x4532ca,'already-initialized');}return _0x14b719['initialize']({'options':_0xa000b9});}function Hf(_0xec4348,_0x88c41b){const _0x2306d5=(_0x88c41b==null?void 0x0:_0x88c41b['persistence'])||[],_0xcb8876=(Array['isArray'](_0x2306d5)?_0x2306d5:[_0x2306d5])['map'](ie);_0x88c41b!=null&&_0x88c41b['errorMap']&&_0xec4348['_updateErrorMap'](_0x88c41b['errorMap']),_0xec4348['_initializeWithPersistence'](_0xcb8876,_0x88c41b==null?void 0x0:_0x88c41b['popupRedirectResolver']);}function $f(_0x2695c,_0x296fc5,_0x1e30c4){const _0x597493=Ke(_0x2695c);m(/^https?:\/\//['test'](_0x296fc5),_0x597493,'invalid-emulator-scheme');const _0x1ec24b=!0x1,_0x333db3=Ua(_0x296fc5),{host:_0xf1713a,port:_0x184846}=Gf(_0x296fc5),_0x583a3a=_0x184846===null?'':':'+_0x184846,_0x5740c8={'url':_0x333db3+'//'+_0xf1713a+_0x583a3a+'/'},_0xfddb5f=Object['freeze']({'host':_0xf1713a,'port':_0x184846,'protocol':_0x333db3['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1ec24b})});if(!_0x597493['_canInitEmulator']){m(_0x597493['config']['emulator']&&_0x597493['emulatorConfig'],_0x597493,'emulator-config-failed'),m(xe(_0x5740c8,_0x597493['config']['emulator'])&&xe(_0xfddb5f,_0x597493['emulatorConfig']),_0x597493,'emulator-config-failed');return;}_0x597493['config']['emulator']=_0x5740c8,_0x597493['emulatorConfig']=_0xfddb5f,_0x597493['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0xf1713a)?Qr(_0x333db3+'//'+_0xf1713a+_0x583a3a):qf();}function Ua(_0x26f203){const _0xc52855=_0x26f203['indexOf'](':');return _0xc52855<0x0?'':_0x26f203['substr'](0x0,_0xc52855+0x1);}function Gf(_0x48241e){const _0xc6482c=Ua(_0x48241e),_0x4a972e=/(\/\/)?([^?#/]+)/['exec'](_0x48241e['substr'](_0xc6482c['length']));if(!_0x4a972e)return{'host':'','port':null};const _0x5b51d7=_0x4a972e[0x2]['split']('@')['pop']()||'',_0x509d19=/^(\[[^\]]+\])(:|$)/['exec'](_0x5b51d7);if(_0x509d19){const _0x2b178d=_0x509d19[0x1];return{'host':_0x2b178d,'port':Pr(_0x5b51d7['substr'](_0x2b178d['length']+0x1))};}else{const [_0x1d765e,_0x1130d1]=_0x5b51d7['split'](':');return{'host':_0x1d765e,'port':Pr(_0x1130d1)};}}function Pr(_0x3dfe83){if(!_0x3dfe83)return null;const _0x18e88b=Number(_0x3dfe83);return isNaN(_0x18e88b)?null:_0x18e88b;}function qf(){function _0x2ffb24(){const _0x2c1110=document['createElement']('p'),_0x2b85ec=_0x2c1110['style'];_0x2c1110['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2b85ec['position']='fixed',_0x2b85ec['width']='100%',_0x2b85ec['backgroundColor']='#ffffff',_0x2b85ec['border']='.1em\x20solid\x20#000000',_0x2b85ec['color']='#b50000',_0x2b85ec['bottom']='0px',_0x2b85ec['left']='0px',_0x2b85ec['margin']='0px',_0x2b85ec['zIndex']='10000',_0x2b85ec['textAlign']='center',_0x2c1110['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2c1110);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2ffb24):_0x2ffb24());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xf231f0,_0x1b13dc){this['providerId']=_0xf231f0,this['signInMethod']=_0x1b13dc;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x5ef681){return ne('not\x20implemented');}['_linkToIdToken'](_0x48e741,_0x52c7f8){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xee7c7f){return ne('not\x20implemented');}}async function zf(_0x221794,_0x237f33){return Pe(_0x221794,'POST','/v1/accounts:signUp',_0x237f33);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x3f8937,_0x5269e8){return en(_0x3f8937,'POST','/v1/accounts:signInWithPassword',ke(_0x3f8937,_0x5269e8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3948fe,_0x23906c){return en(_0x3948fe,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3948fe,_0x23906c));}async function Yf(_0x2227e3,_0x2a741a){return en(_0x2227e3,'POST','/v1/accounts:signInWithEmailLink',ke(_0x2227e3,_0x2a741a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1ba80e,_0x58dd6b,_0x3e0d99,_0x185062=null){super('password',_0x3e0d99),this['_email']=_0x1ba80e,this['_password']=_0x58dd6b,this['_tenantId']=_0x185062;}static['_fromEmailAndPassword'](_0x52cd9c,_0x52c4a6){return new $t(_0x52cd9c,_0x52c4a6,'password');}static['_fromEmailAndCode'](_0x1c6682,_0x1ab8c1,_0x19eb80=null){return new $t(_0x1c6682,_0x1ab8c1,'emailLink',_0x19eb80);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x3c4a9d){const _0x551d33=typeof _0x3c4a9d=='string'?JSON['parse'](_0x3c4a9d):_0x3c4a9d;if(_0x551d33!=null&&_0x551d33['email']&&(_0x551d33!=null&&_0x551d33['password'])){if(_0x551d33['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x551d33['email'],_0x551d33['password']);if(_0x551d33['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x551d33['email'],_0x551d33['password'],_0x551d33['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3e8974){switch(this['signInMethod']){case'password':const _0x17ea6d={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3e8974,_0x17ea6d,'signInWithPassword',jf);case'emailLink':return Kf(_0x3e8974,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3e8974,'internal-error');}}async['_linkToIdToken'](_0x552059,_0x40df9c){switch(this['signInMethod']){case'password':const _0x165480={'idToken':_0x40df9c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x552059,_0x165480,'signUpPassword',zf);case'emailLink':return Yf(_0x552059,{'idToken':_0x40df9c,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x552059,'internal-error');}}['_getReauthenticationResolver'](_0x48f54a){return this['_getIdTokenResponse'](_0x48f54a);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2c1451,_0x5e65ae){return en(_0x2c1451,'POST','/v1/accounts:signInWithIdp',ke(_0x2c1451,_0x5e65ae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x16c46d){const _0x433e6f=new $e(_0x16c46d['providerId'],_0x16c46d['signInMethod']);return _0x16c46d['idToken']||_0x16c46d['accessToken']?(_0x16c46d['idToken']&&(_0x433e6f['idToken']=_0x16c46d['idToken']),_0x16c46d['accessToken']&&(_0x433e6f['accessToken']=_0x16c46d['accessToken']),_0x16c46d['nonce']&&!_0x16c46d['pendingToken']&&(_0x433e6f['nonce']=_0x16c46d['nonce']),_0x16c46d['pendingToken']&&(_0x433e6f['pendingToken']=_0x16c46d['pendingToken'])):_0x16c46d['oauthToken']&&_0x16c46d['oauthTokenSecret']?(_0x433e6f['accessToken']=_0x16c46d['oauthToken'],_0x433e6f['secret']=_0x16c46d['oauthTokenSecret']):Y('argument-error'),_0x433e6f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5b93fc){const _0x3ab615=typeof _0x5b93fc=='string'?JSON['parse'](_0x5b93fc):_0x5b93fc,{providerId:_0x2eef0a,signInMethod:_0x5dc860,..._0x1ba0f0}=_0x3ab615;if(!_0x2eef0a||!_0x5dc860)return null;const _0x4230be=new $e(_0x2eef0a,_0x5dc860);return _0x4230be['idToken']=_0x1ba0f0['idToken']||void 0x0,_0x4230be['accessToken']=_0x1ba0f0['accessToken']||void 0x0,_0x4230be['secret']=_0x1ba0f0['secret'],_0x4230be['nonce']=_0x1ba0f0['nonce'],_0x4230be['pendingToken']=_0x1ba0f0['pendingToken']||null,_0x4230be;}['_getIdTokenResponse'](_0x503b6a){const _0x35c585=this['buildRequest']();return nt(_0x503b6a,_0x35c585);}['_linkToIdToken'](_0x375ca7,_0xb0001b){const _0x5a91ec=this['buildRequest']();return _0x5a91ec['idToken']=_0xb0001b,nt(_0x375ca7,_0x5a91ec);}['_getReauthenticationResolver'](_0x7c9183){const _0x23480=this['buildRequest']();return _0x23480['autoCreate']=!0x1,nt(_0x7c9183,_0x23480);}['buildRequest'](){const _0x17c063={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x17c063['pendingToken']=this['pendingToken'];else{const _0x47e4d0={};this['idToken']&&(_0x47e4d0['id_token']=this['idToken']),this['accessToken']&&(_0x47e4d0['access_token']=this['accessToken']),this['secret']&&(_0x47e4d0['oauth_token_secret']=this['secret']),_0x47e4d0['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x47e4d0['nonce']=this['nonce']),_0x17c063['postBody']=ut(_0x47e4d0);}return _0x17c063;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x4955cb){switch(_0x4955cb){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x4770a0){const _0x5aae6d=Ct(Tt(_0x4770a0))['link'],_0x1288d9=_0x5aae6d?Ct(Tt(_0x5aae6d))['deep_link_id']:null,_0x4070ae=Ct(Tt(_0x4770a0))['deep_link_id'];return(_0x4070ae?Ct(Tt(_0x4070ae))['link']:null)||_0x4070ae||_0x1288d9||_0x5aae6d||_0x4770a0;}class Rs{constructor(_0x2ef4aa){const _0x3f61ca=Ct(Tt(_0x2ef4aa)),_0x22882a=_0x3f61ca['apiKey']??null,_0x52557d=_0x3f61ca['oobCode']??null,_0x334e5c=Jf(_0x3f61ca['mode']??null);m(_0x22882a&&_0x52557d&&_0x334e5c,'argument-error'),this['apiKey']=_0x22882a,this['operation']=_0x334e5c,this['code']=_0x52557d,this['continueUrl']=_0x3f61ca['continueUrl']??null,this['languageCode']=_0x3f61ca['lang']??null,this['tenantId']=_0x3f61ca['tenantId']??null;}static['parseLink'](_0x132cc4){const _0x265c31=Xf(_0x132cc4);try{return new Rs(_0x265c31);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x2c7d34,_0x4763d6){return $t['_fromEmailAndPassword'](_0x2c7d34,_0x4763d6);}static['credentialWithLink'](_0x2d21c4,_0x4ce5ef){const _0x2870ec=Rs['parseLink'](_0x4ce5ef);return m(_0x2870ec,'argument-error'),$t['_fromEmailAndCode'](_0x2d21c4,_0x2870ec['code'],_0x2870ec['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x26451b){this['providerId']=_0x26451b,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1d180f){this['defaultLanguageCode']=_0x1d180f;}['setCustomParameters'](_0x55ec1b){return this['customParameters']=_0x55ec1b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4cb45c){return this['scopes']['includes'](_0x4cb45c)||this['scopes']['push'](_0x4cb45c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2a5887){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2a5887});}static['credentialFromResult'](_0x36312a){return ue['credentialFromTaggedObject'](_0x36312a);}static['credentialFromError'](_0x355e8b){return ue['credentialFromTaggedObject'](_0x355e8b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2b2768}){if(!_0x2b2768||!('oauthAccessToken'in _0x2b2768)||!_0x2b2768['oauthAccessToken'])return null;try{return ue['credential'](_0x2b2768['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xce556e,_0xdb29b2){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xce556e,'accessToken':_0xdb29b2});}static['credentialFromResult'](_0x4ed427){return de['credentialFromTaggedObject'](_0x4ed427);}static['credentialFromError'](_0x2525c4){return de['credentialFromTaggedObject'](_0x2525c4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb898ba}){if(!_0xb898ba)return null;const {oauthIdToken:_0x3f5a8b,oauthAccessToken:_0x31c51a}=_0xb898ba;if(!_0x3f5a8b&&!_0x31c51a)return null;try{return de['credential'](_0x3f5a8b,_0x31c51a);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4f56d3){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4f56d3});}static['credentialFromResult'](_0x39b169){return fe['credentialFromTaggedObject'](_0x39b169);}static['credentialFromError'](_0x464abb){return fe['credentialFromTaggedObject'](_0x464abb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x186dbe}){if(!_0x186dbe||!('oauthAccessToken'in _0x186dbe)||!_0x186dbe['oauthAccessToken'])return null;try{return fe['credential'](_0x186dbe['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x589787,_0x2682ab){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x589787,'oauthTokenSecret':_0x2682ab});}static['credentialFromResult'](_0x47c520){return pe['credentialFromTaggedObject'](_0x47c520);}static['credentialFromError'](_0x445d66){return pe['credentialFromTaggedObject'](_0x445d66['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x113dbc}){if(!_0x113dbc)return null;const {oauthAccessToken:_0xa8558e,oauthTokenSecret:_0x2e064c}=_0x113dbc;if(!_0xa8558e||!_0x2e064c)return null;try{return pe['credential'](_0xa8558e,_0x2e064c);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x390e3a,_0x4dcfb9){return en(_0x390e3a,'POST','/v1/accounts:signUp',ke(_0x390e3a,_0x4dcfb9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x15a3f1){this['user']=_0x15a3f1['user'],this['providerId']=_0x15a3f1['providerId'],this['_tokenResponse']=_0x15a3f1['_tokenResponse'],this['operationType']=_0x15a3f1['operationType'];}static async['_fromIdTokenResponse'](_0x2f1e62,_0x4e9f61,_0x4a19da,_0x2b4590=!0x1){const _0x58777e=await j['_fromIdTokenResponse'](_0x2f1e62,_0x4a19da,_0x2b4590),_0x3b568b=Nr(_0x4a19da);return new Ge({'user':_0x58777e,'providerId':_0x3b568b,'_tokenResponse':_0x4a19da,'operationType':_0x4e9f61});}static async['_forOperation'](_0x3df5cb,_0x1013a3,_0x5c6cac){await _0x3df5cb['_updateTokensIfNecessary'](_0x5c6cac,!0x0);const _0x4cad14=Nr(_0x5c6cac);return new Ge({'user':_0x3df5cb,'providerId':_0x4cad14,'_tokenResponse':_0x5c6cac,'operationType':_0x1013a3});}}function Nr(_0x28564c){return _0x28564c['providerId']?_0x28564c['providerId']:'phoneNumber'in _0x28564c?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x5c88a8,_0x4c326c,_0x326901,_0x41cd10){super(_0x4c326c['code'],_0x4c326c['message']),this['operationType']=_0x326901,this['user']=_0x41cd10,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x5c88a8['name'],'tenantId':_0x5c88a8['tenantId']??void 0x0,'_serverResponse':_0x4c326c['customData']['_serverResponse'],'operationType':_0x326901};}static['_fromErrorAndOperation'](_0x5f4218,_0x2d20b4,_0x1dad99,_0x3dad71){return new On(_0x5f4218,_0x2d20b4,_0x1dad99,_0x3dad71);}}function Ba(_0xec4db1,_0x29c336,_0x19241b,_0x54e78e){return(_0x29c336==='reauthenticate'?_0x19241b['_getReauthenticationResolver'](_0xec4db1):_0x19241b['_getIdTokenResponse'](_0xec4db1))['catch'](_0x27922b=>{throw _0x27922b['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0xec4db1,_0x27922b,_0x29c336,_0x54e78e):_0x27922b;});}async function ep(_0xe580e7,_0x145fa0,_0x5701a7=!0x1){const _0x306eb1=await Ht(_0xe580e7,_0x145fa0['_linkToIdToken'](_0xe580e7['auth'],await _0xe580e7['getIdToken']()),_0x5701a7);return Ge['_forOperation'](_0xe580e7,'link',_0x306eb1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x20922c,_0x30c868,_0x3f6181=!0x1){const {auth:_0x34e7ff}=_0x20922c;if($(_0x34e7ff['app']))return Promise['reject'](re(_0x34e7ff));const _0x142c76='reauthenticate';try{const _0xddf0e3=await Ht(_0x20922c,Ba(_0x34e7ff,_0x142c76,_0x30c868,_0x20922c),_0x3f6181);m(_0xddf0e3['idToken'],_0x34e7ff,'internal-error');const _0x23ad35=Ts(_0xddf0e3['idToken']);m(_0x23ad35,_0x34e7ff,'internal-error');const {sub:_0x4022f0}=_0x23ad35;return m(_0x20922c['uid']===_0x4022f0,_0x34e7ff,'user-mismatch'),Ge['_forOperation'](_0x20922c,_0x142c76,_0xddf0e3);}catch(_0x48d9b5){throw(_0x48d9b5==null?void 0x0:_0x48d9b5['code'])==='auth/user-not-found'&&Y(_0x34e7ff,'user-mismatch'),_0x48d9b5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x163055,_0x158d83,_0x32f29f=!0x1){if($(_0x163055['app']))return Promise['reject'](re(_0x163055));const _0x44c27b='signIn',_0x51281a=await Ba(_0x163055,_0x44c27b,_0x158d83),_0x152c85=await Ge['_fromIdTokenResponse'](_0x163055,_0x44c27b,_0x51281a);return _0x32f29f||await _0x163055['_updateCurrentUser'](_0x152c85['user']),_0x152c85;}async function np(_0x73bb5d,_0x1137cc){return Va(Ke(_0x73bb5d),_0x1137cc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x472b5a){const _0x58c754=Ke(_0x472b5a);_0x58c754['_getPasswordPolicyInternal']()&&await _0x58c754['_updatePasswordPolicy']();}async function L_(_0x829770,_0x1ef5d2,_0x444736){if($(_0x829770['app']))return Promise['reject'](re(_0x829770));const _0x36e280=Ke(_0x829770),_0x57772a=await xi(_0x36e280,{'returnSecureToken':!0x0,'email':_0x1ef5d2,'password':_0x444736,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x419c1a=>{throw _0x419c1a['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x829770),_0x419c1a;}),_0x3c37f7=await Ge['_fromIdTokenResponse'](_0x36e280,'signIn',_0x57772a);return await _0x36e280['_updateCurrentUser'](_0x3c37f7['user']),_0x3c37f7;}function x_(_0x305d08,_0x4d26f2,_0x28ace3){return $(_0x305d08['app'])?Promise['reject'](re(_0x305d08)):np(P(_0x305d08),yt['credential'](_0x4d26f2,_0x28ace3))['catch'](async _0x39c6ba=>{throw _0x39c6ba['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x305d08),_0x39c6ba;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x82f48e,_0x2438ac){return P(_0x82f48e)['setPersistence'](_0x2438ac);}function ip(_0x5338fa,_0x2df8fe,_0xb03910,_0x466149){return P(_0x5338fa)['onIdTokenChanged'](_0x2df8fe,_0xb03910,_0x466149);}function sp(_0x15009a,_0x380fb4,_0x3de230){return P(_0x15009a)['beforeAuthStateChanged'](_0x380fb4,_0x3de230);}function U_(_0x1aa567,_0x4e27c3,_0x32974a,_0x34c4b7){return P(_0x1aa567)['onAuthStateChanged'](_0x4e27c3,_0x32974a,_0x34c4b7);}function W_(_0x3454e6){return P(_0x3454e6)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2edcc4,_0x363685){this['storageRetriever']=_0x2edcc4,this['type']=_0x363685;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0xd61d74,_0x1e7fae){return this['storage']['setItem'](_0xd61d74,JSON['stringify'](_0x1e7fae)),Promise['resolve']();}['_get'](_0x2b5168){const _0x2e546c=this['storage']['getItem'](_0x2b5168);return Promise['resolve'](_0x2e546c?JSON['parse'](_0x2e546c):null);}['_remove'](_0x3dc08c){return this['storage']['removeItem'](_0x3dc08c),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x56972c,_0x157cbf)=>this['onStorageEvent'](_0x56972c,_0x157cbf),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x3008d9){for(const _0x4f1ca5 of Object['keys'](this['listeners'])){const _0x593f47=this['storage']['getItem'](_0x4f1ca5),_0x2ed997=this['localCache'][_0x4f1ca5];_0x593f47!==_0x2ed997&&_0x3008d9(_0x4f1ca5,_0x2ed997,_0x593f47);}}['onStorageEvent'](_0x147a8e,_0xd29862=!0x1){if(!_0x147a8e['key']){this['forAllChangedKeys']((_0x24a6dd,_0xd5ea69,_0x3a7f22)=>{this['notifyListeners'](_0x24a6dd,_0x3a7f22);});return;}const _0x22dd67=_0x147a8e['key'];_0xd29862?this['detachListener']():this['stopPolling']();const _0x175761=()=>{const _0x537257=this['storage']['getItem'](_0x22dd67);!_0xd29862&&this['localCache'][_0x22dd67]===_0x537257||this['notifyListeners'](_0x22dd67,_0x537257);},_0x2688b9=this['storage']['getItem'](_0x22dd67);Af()&&_0x2688b9!==_0x147a8e['newValue']&&_0x147a8e['newValue']!==_0x147a8e['oldValue']?setTimeout(_0x175761,op):_0x175761();}['notifyListeners'](_0x2c2d76,_0x333d75){this['localCache'][_0x2c2d76]=_0x333d75;const _0x238671=this['listeners'][_0x2c2d76];if(_0x238671){for(const _0x17172a of Array['from'](_0x238671))_0x17172a(_0x333d75&&JSON['parse'](_0x333d75));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x351b04,_0x209558,_0x1d5b32)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x351b04,'oldValue':_0x209558,'newValue':_0x1d5b32}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4744df,_0x2833f4){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4744df]||(this['listeners'][_0x4744df]=new Set(),this['localCache'][_0x4744df]=this['storage']['getItem'](_0x4744df)),this['listeners'][_0x4744df]['add'](_0x2833f4);}['_removeListener'](_0x1f656f,_0x4ccc30){this['listeners'][_0x1f656f]&&(this['listeners'][_0x1f656f]['delete'](_0x4ccc30),this['listeners'][_0x1f656f]['size']===0x0&&delete this['listeners'][_0x1f656f]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x26ec87,_0x50e172){await super['_set'](_0x26ec87,_0x50e172),this['localCache'][_0x26ec87]=JSON['stringify'](_0x50e172);}async['_get'](_0x3573d3){const _0x14ed73=await super['_get'](_0x3573d3);return this['localCache'][_0x3573d3]=JSON['stringify'](_0x14ed73),_0x14ed73;}async['_remove'](_0x4f176a){await super['_remove'](_0x4f176a),delete this['localCache'][_0x4f176a];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x48ca1e,_0x5c5c8b){}['_removeListener'](_0x327e80,_0x26df45){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5474ed){return Promise['all'](_0x5474ed['map'](async _0x29a7c8=>{try{return{'fulfilled':!0x0,'value':await _0x29a7c8};}catch(_0x536b60){return{'fulfilled':!0x1,'reason':_0x536b60};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x59618c){this['eventTarget']=_0x59618c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x565dae){const _0x2fc4d9=this['receivers']['find'](_0x45e7fa=>_0x45e7fa['isListeningto'](_0x565dae));if(_0x2fc4d9)return _0x2fc4d9;const _0x40a325=new Xn(_0x565dae);return this['receivers']['push'](_0x40a325),_0x40a325;}['isListeningto'](_0x185a91){return this['eventTarget']===_0x185a91;}async['handleEvent'](_0x164e6d){const _0x2bb623=_0x164e6d,{eventId:_0x21c0bb,eventType:_0x5db9ac,data:_0x409d22}=_0x2bb623['data'],_0x3c2ac3=this['handlersMap'][_0x5db9ac];if(!(_0x3c2ac3!=null&&_0x3c2ac3['size']))return;_0x2bb623['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x21c0bb,'eventType':_0x5db9ac});const _0x17fd0d=Array['from'](_0x3c2ac3)['map'](async _0x3654fe=>_0x3654fe(_0x2bb623['origin'],_0x409d22)),_0x5885d1=await cp(_0x17fd0d);_0x2bb623['ports'][0x0]['postMessage']({'status':'done','eventId':_0x21c0bb,'eventType':_0x5db9ac,'response':_0x5885d1});}['_subscribe'](_0x14969f,_0x475851){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x14969f]||(this['handlersMap'][_0x14969f]=new Set()),this['handlersMap'][_0x14969f]['add'](_0x475851);}['_unsubscribe'](_0x3162d6,_0x489dae){this['handlersMap'][_0x3162d6]&&_0x489dae&&this['handlersMap'][_0x3162d6]['delete'](_0x489dae),(!_0x489dae||this['handlersMap'][_0x3162d6]['size']===0x0)&&delete this['handlersMap'][_0x3162d6],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1f4132='',_0x5e5bef=0xa){let _0xa34f78='';for(let _0xa91ac3=0x0;_0xa91ac3<_0x5e5bef;_0xa91ac3++)_0xa34f78+=Math['floor'](Math['random']()*0xa);return _0x1f4132+_0xa34f78;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1dde7a){this['target']=_0x1dde7a,this['handlers']=new Set();}['removeMessageHandler'](_0x467908){_0x467908['messageChannel']&&(_0x467908['messageChannel']['port1']['removeEventListener']('message',_0x467908['onMessage']),_0x467908['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x467908);}async['_send'](_0x293647,_0x6f83f6,_0x17ec89=0x32){const _0x498ab3=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x498ab3)throw new Error('connection_unavailable');let _0x3a6259,_0x2b0751;return new Promise((_0x2d9af3,_0x417286)=>{const _0x488e09=As('',0x14);_0x498ab3['port1']['start']();const _0x23bb6c=setTimeout(()=>{_0x417286(new Error('unsupported_event'));},_0x17ec89);_0x2b0751={'messageChannel':_0x498ab3,'onMessage'(_0x1c3090){const _0xb0fadd=_0x1c3090;if(_0xb0fadd['data']['eventId']===_0x488e09)switch(_0xb0fadd['data']['status']){case'ack':clearTimeout(_0x23bb6c),_0x3a6259=setTimeout(()=>{_0x417286(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3a6259),_0x2d9af3(_0xb0fadd['data']['response']);break;default:clearTimeout(_0x23bb6c),clearTimeout(_0x3a6259),_0x417286(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2b0751),_0x498ab3['port1']['addEventListener']('message',_0x2b0751['onMessage']),this['target']['postMessage']({'eventType':_0x293647,'eventId':_0x488e09,'data':_0x6f83f6},[_0x498ab3['port2']]);})['finally'](()=>{_0x2b0751&&this['removeMessageHandler'](_0x2b0751);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x1849d1){Z()['location']['href']=_0x1849d1;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x1c5dc9;return((_0x1c5dc9=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1c5dc9['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x5c3ae5){this['request']=_0x5c3ae5;}['toPromise'](){return new Promise((_0x2f6b32,_0x1991d9)=>{this['request']['addEventListener']('success',()=>{_0x2f6b32(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1991d9(this['request']['error']);});});}}function Zn(_0x5425b5,_0xd3def){return _0x5425b5['transaction']([Mn],_0xd3def?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x3d16d8=indexedDB['deleteDatabase'](Ka);return new nn(_0x3d16d8)['toPromise']();}function Qa(){const _0x23ce90=indexedDB['open'](Ka,pp);return new Promise((_0x80f6d2,_0x4a45c9)=>{_0x23ce90['addEventListener']('error',()=>{_0x4a45c9(_0x23ce90['error']);}),_0x23ce90['addEventListener']('upgradeneeded',()=>{const _0x139021=_0x23ce90['result'];try{_0x139021['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x43102d){_0x4a45c9(_0x43102d);}}),_0x23ce90['addEventListener']('success',async()=>{const _0x2c3e43=_0x23ce90['result'];_0x2c3e43['objectStoreNames']['contains'](Mn)?_0x80f6d2(_0x2c3e43):(_0x2c3e43['close'](),await _p(),_0x80f6d2(await Qa()));});});}async function Or(_0x1f80ab,_0x7134dd,_0x50075f){const _0x45b11b=Zn(_0x1f80ab,!0x0)['put']({[Ya]:_0x7134dd,'value':_0x50075f});return new nn(_0x45b11b)['toPromise']();}async function gp(_0x930b98,_0x3f63e5){const _0x3ef788=Zn(_0x930b98,!0x1)['get'](_0x3f63e5),_0x575cde=await new nn(_0x3ef788)['toPromise']();return _0x575cde===void 0x0?null:_0x575cde['value'];}function Dr(_0x1a014e,_0x4155ac){const _0x330930=Zn(_0x1a014e,!0x0)['delete'](_0x4155ac);return new nn(_0x330930)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x589d6f){let _0x2c7960=0x0;for(;;)try{const _0xb8f745=await this['_openDb']();return await _0x589d6f(_0xb8f745);}catch(_0x1bb1ef){if(_0x2c7960++>yp)throw _0x1bb1ef;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x583102,_0x455025)=>({'keyProcessed':(await this['_poll']())['includes'](_0x455025['key'])})),this['receiver']['_subscribe']('ping',async(_0x340023,_0xc9f804)=>['keyChanged']);}async['initializeSender'](){var _0x580716,_0x5050f4;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x168fcd=await this['sender']['_send']('ping',{},0x320);_0x168fcd&&(_0x580716=_0x168fcd[0x0])!=null&&_0x580716['fulfilled']&&(_0x5050f4=_0x168fcd[0x0])!=null&&_0x5050f4['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x11018a){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x11018a},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2afc56=>{await Or(_0x2afc56,Dn,'1'),await Dr(_0x2afc56,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2d093b){this['pendingWrites']++;try{await _0x2d093b();}finally{this['pendingWrites']--;}}async['_set'](_0x34a576,_0x57f160){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x446528=>Or(_0x446528,_0x34a576,_0x57f160)),this['localCache'][_0x34a576]=_0x57f160,this['notifyServiceWorker'](_0x34a576)));}async['_get'](_0x352d6e){const _0x41e86d=await this['_withRetries'](_0x20d59c=>gp(_0x20d59c,_0x352d6e));return this['localCache'][_0x352d6e]=_0x41e86d,_0x41e86d;}async['_remove'](_0x3daf27){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4cb8af=>Dr(_0x4cb8af,_0x3daf27)),delete this['localCache'][_0x3daf27],this['notifyServiceWorker'](_0x3daf27)));}async['_poll'](){const _0x127c50=await this['_withRetries'](_0x2a2e50=>{const _0x2eb4ea=Zn(_0x2a2e50,!0x1)['getAll']();return new nn(_0x2eb4ea)['toPromise']();});if(!_0x127c50)return[];if(this['pendingWrites']!==0x0)return[];const _0x19fd91=[],_0x458122=new Set();if(_0x127c50['length']!==0x0){for(const {fbase_key:_0xf9ac7d,value:_0x1fa98b}of _0x127c50)_0x458122['add'](_0xf9ac7d),JSON['stringify'](this['localCache'][_0xf9ac7d])!==JSON['stringify'](_0x1fa98b)&&(this['notifyListeners'](_0xf9ac7d,_0x1fa98b),_0x19fd91['push'](_0xf9ac7d));}for(const _0x3154a8 of Object['keys'](this['localCache']))this['localCache'][_0x3154a8]&&!_0x458122['has'](_0x3154a8)&&(this['notifyListeners'](_0x3154a8,null),_0x19fd91['push'](_0x3154a8));return _0x19fd91;}['notifyListeners'](_0x371223,_0x1113a0){this['localCache'][_0x371223]=_0x1113a0;const _0x387f4b=this['listeners'][_0x371223];if(_0x387f4b){for(const _0x36ddbd of Array['from'](_0x387f4b))_0x36ddbd(_0x1113a0);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3ec521,_0x40fd54){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3ec521]||(this['listeners'][_0x3ec521]=new Set(),this['_get'](_0x3ec521)),this['listeners'][_0x3ec521]['add'](_0x40fd54);}['_removeListener'](_0x1ed1a6,_0x32c29d){this['listeners'][_0x1ed1a6]&&(this['listeners'][_0x1ed1a6]['delete'](_0x32c29d),this['listeners'][_0x1ed1a6]['size']===0x0&&delete this['listeners'][_0x1ed1a6]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x303e0b,_0x18f951){return _0x18f951?ie(_0x18f951):(m(_0x303e0b['_popupRedirectResolver'],_0x303e0b,'argument-error'),_0x303e0b['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x48257c){super('custom','custom'),this['params']=_0x48257c;}['_getIdTokenResponse'](_0x250406){return nt(_0x250406,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2d200c,_0xb6724f){return nt(_0x2d200c,this['_buildIdpRequest'](_0xb6724f));}['_getReauthenticationResolver'](_0x2554f3){return nt(_0x2554f3,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xebb119){const _0x34f83f={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xebb119&&(_0x34f83f['idToken']=_0xebb119),_0x34f83f;}}function Ip(_0x1d89e2){return Va(_0x1d89e2['auth'],new ks(_0x1d89e2),_0x1d89e2['bypassAuthState']);}function wp(_0x18bfa3){const {auth:_0x4b2547,user:_0x3451ef}=_0x18bfa3;return m(_0x3451ef,_0x4b2547,'internal-error'),tp(_0x3451ef,new ks(_0x18bfa3),_0x18bfa3['bypassAuthState']);}async function Cp(_0x5c94cc){const {auth:_0x3fc640,user:_0x179946}=_0x5c94cc;return m(_0x179946,_0x3fc640,'internal-error'),ep(_0x179946,new ks(_0x5c94cc),_0x5c94cc['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x266253,_0x52f181,_0x2385e6,_0x21434d,_0x2d5344=!0x1){this['auth']=_0x266253,this['resolver']=_0x2385e6,this['user']=_0x21434d,this['bypassAuthState']=_0x2d5344,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x52f181)?_0x52f181:[_0x52f181];}['execute'](){return new Promise(async(_0x276651,_0xf0efa5)=>{this['pendingPromise']={'resolve':_0x276651,'reject':_0xf0efa5};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x27e706){this['reject'](_0x27e706);}});}async['onAuthEvent'](_0x201345){const {urlResponse:_0xc4a76,sessionId:_0xac545b,postBody:_0x13c5e1,tenantId:_0x86323e,error:_0x2ed800,type:_0x5e9a4c}=_0x201345;if(_0x2ed800){this['reject'](_0x2ed800);return;}const _0xdd47ff={'auth':this['auth'],'requestUri':_0xc4a76,'sessionId':_0xac545b,'tenantId':_0x86323e||void 0x0,'postBody':_0x13c5e1||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5e9a4c)(_0xdd47ff));}catch(_0x3663e5){this['reject'](_0x3663e5);}}['onError'](_0x114233){this['reject'](_0x114233);}['getIdpTask'](_0x50e1f9){switch(_0x50e1f9){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x165f52){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x165f52),this['unregisterAndCleanUp']();}['reject'](_0x550dad){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x550dad),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x44e1f8,_0x4f8c41,_0x3a8ede,_0x26dff6,_0x2a22f2){super(_0x44e1f8,_0x4f8c41,_0x26dff6,_0x2a22f2),this['provider']=_0x3a8ede,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x14cd63=await this['execute']();return m(_0x14cd63,this['auth'],'internal-error'),_0x14cd63;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x22a458=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x22a458),this['authWindow']['associatedEvent']=_0x22a458,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3099a9=>{this['reject'](_0x3099a9);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x47ba81=>{_0x47ba81||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3b2792;return((_0x3b2792=this['authWindow'])==null?void 0x0:_0x3b2792['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x56892e=()=>{var _0x19fafb,_0x41bbac;if((_0x41bbac=(_0x19fafb=this['authWindow'])==null?void 0x0:_0x19fafb['window'])!=null&&_0x41bbac['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x56892e,Tp['get']());};_0x56892e();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x19aecd,_0x36ea11,_0x4f778b=!0x1){super(_0x19aecd,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x36ea11,void 0x0,_0x4f778b),this['eventId']=null;}async['execute'](){let _0xeaf46d=hn['get'](this['auth']['_key']());if(!_0xeaf46d){try{const _0x5e9307=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0xeaf46d=()=>Promise['resolve'](_0x5e9307);}catch(_0x465802){_0xeaf46d=()=>Promise['reject'](_0x465802);}hn['set'](this['auth']['_key'](),_0xeaf46d);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xeaf46d();}async['onAuthEvent'](_0x5ba6d7){if(_0x5ba6d7['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5ba6d7);if(_0x5ba6d7['type']==='unknown'){this['resolve'](null);return;}if(_0x5ba6d7['eventId']){const _0x4f1874=await this['auth']['_redirectUserForId'](_0x5ba6d7['eventId']);if(_0x4f1874)return this['user']=_0x4f1874,super['onAuthEvent'](_0x5ba6d7);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3ad9dd,_0x45ecb3){const _0x7115b6=Pp(_0x45ecb3),_0x524d97=kp(_0x3ad9dd);if(!await _0x524d97['_isAvailable']())return!0x1;const _0x84838e=await _0x524d97['_get'](_0x7115b6)==='true';return await _0x524d97['_remove'](_0x7115b6),_0x84838e;}function Ap(_0x2e9d88,_0x3e8345){hn['set'](_0x2e9d88['_key'](),_0x3e8345);}function kp(_0x32a3c7){return ie(_0x32a3c7['_redirectPersistence']);}function Pp(_0x24b58d){return ln(Sp,_0x24b58d['config']['apiKey'],_0x24b58d['name']);}async function Np(_0x185d4e,_0xea688f,_0x1b7af5=!0x1){if($(_0x185d4e['app']))return Promise['reject'](re(_0x185d4e));const _0x1ebb82=Ke(_0x185d4e),_0x192c46=Ep(_0x1ebb82,_0xea688f),_0x823f61=await new bp(_0x1ebb82,_0x192c46,_0x1b7af5)['execute']();return _0x823f61&&!_0x1b7af5&&(delete _0x823f61['user']['_redirectEventId'],await _0x1ebb82['_persistUserIfCurrent'](_0x823f61['user']),await _0x1ebb82['_setRedirectUser'](null,_0xea688f)),_0x823f61;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x177d00){this['auth']=_0x177d00,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xce9d23){this['consumers']['add'](_0xce9d23),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xce9d23)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xce9d23),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x552d86){this['consumers']['delete'](_0x552d86);}['onEvent'](_0x1a2661){if(this['hasEventBeenHandled'](_0x1a2661))return!0x1;let _0x5511bd=!0x1;return this['consumers']['forEach'](_0x4211ab=>{this['isEventForConsumer'](_0x1a2661,_0x4211ab)&&(_0x5511bd=!0x0,this['sendToConsumer'](_0x1a2661,_0x4211ab),this['saveEventToCache'](_0x1a2661));}),this['hasHandledPotentialRedirect']||!Mp(_0x1a2661)||(this['hasHandledPotentialRedirect']=!0x0,_0x5511bd||(this['queuedRedirectEvent']=_0x1a2661,_0x5511bd=!0x0)),_0x5511bd;}['sendToConsumer'](_0x5755f3,_0x521f0d){var _0x19700e;if(_0x5755f3['error']&&!Za(_0x5755f3)){const _0x30b679=((_0x19700e=_0x5755f3['error']['code'])==null?void 0x0:_0x19700e['split']('auth/')[0x1])||'internal-error';_0x521f0d['onError'](X(this['auth'],_0x30b679));}else _0x521f0d['onAuthEvent'](_0x5755f3);}['isEventForConsumer'](_0x58f465,_0x566c25){const _0x51dc9=_0x566c25['eventId']===null||!!_0x58f465['eventId']&&_0x58f465['eventId']===_0x566c25['eventId'];return _0x566c25['filter']['includes'](_0x58f465['type'])&&_0x51dc9;}['hasEventBeenHandled'](_0x2b28d9){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2b28d9));}['saveEventToCache'](_0x2cbcb1){this['cachedEventUids']['add'](Mr(_0x2cbcb1)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x5e73a9){return[_0x5e73a9['type'],_0x5e73a9['eventId'],_0x5e73a9['sessionId'],_0x5e73a9['tenantId']]['filter'](_0x51de5b=>_0x51de5b)['join']('-');}function Za({type:_0x2a9644,error:_0x1c5590}){return _0x2a9644==='unknown'&&(_0x1c5590==null?void 0x0:_0x1c5590['code'])==='auth/no-auth-event';}function Mp(_0x37a479){switch(_0x37a479['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x37a479);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x53ba29,_0x2532cc={}){return Pe(_0x53ba29,'GET','/v1/projects',_0x2532cc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x2bbda4){if(_0x2bbda4['config']['emulator'])return;const {authorizedDomains:_0x15fd8a}=await Lp(_0x2bbda4);for(const _0x6fe8b8 of _0x15fd8a)try{if(Wp(_0x6fe8b8))return;}catch{}Y(_0x2bbda4,'unauthorized-domain');}function Wp(_0x273127){const _0x2ea5f6=Mi(),{protocol:_0x2422f6,hostname:_0x4c76ac}=new URL(_0x2ea5f6);if(_0x273127['startsWith']('chrome-extension://')){const _0x40478e=new URL(_0x273127);return _0x40478e['hostname']===''&&_0x4c76ac===''?_0x2422f6==='chrome-extension:'&&_0x273127['replace']('chrome-extension://','')===_0x2ea5f6['replace']('chrome-extension://',''):_0x2422f6==='chrome-extension:'&&_0x40478e['hostname']===_0x4c76ac;}if(!Fp['test'](_0x2422f6))return!0x1;if(xp['test'](_0x273127))return _0x4c76ac===_0x273127;const _0x12ccee=_0x273127['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x12ccee+'|'+_0x12ccee+')$','i')['test'](_0x4c76ac);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x534c19=Z()['___jsl'];if(_0x534c19!=null&&_0x534c19['H']){for(const _0xb683b2 of Object['keys'](_0x534c19['H']))if(_0x534c19['H'][_0xb683b2]['r']=_0x534c19['H'][_0xb683b2]['r']||[],_0x534c19['H'][_0xb683b2]['L']=_0x534c19['H'][_0xb683b2]['L']||[],_0x534c19['H'][_0xb683b2]['r']=[..._0x534c19['H'][_0xb683b2]['L']],_0x534c19['CP']){for(let _0x22807f=0x0;_0x22807f<_0x534c19['CP']['length'];_0x22807f++)_0x534c19['CP'][_0x22807f]=null;}}}function Vp(_0x22a70a){return new Promise((_0x1f113d,_0x1ca6b9)=>{var _0x43b313,_0x3fdc91,_0xdb9506;function _0x3ab7e2(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1f113d(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1ca6b9(X(_0x22a70a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x3fdc91=(_0x43b313=Z()['gapi'])==null?void 0x0:_0x43b313['iframes'])!=null&&_0x3fdc91['Iframe'])_0x1f113d(gapi['iframes']['getContext']());else{if((_0xdb9506=Z()['gapi'])!=null&&_0xdb9506['load'])_0x3ab7e2();else{const _0x2189a1=Ff('iframefcb');return Z()[_0x2189a1]=()=>{gapi['load']?_0x3ab7e2():_0x1ca6b9(X(_0x22a70a,'network-request-failed'));},xa(xf()+'?onload='+_0x2189a1)['catch'](_0x5bcc42=>_0x1ca6b9(_0x5bcc42));}}})['catch'](_0x123046=>{throw un=null,_0x123046;});}let un=null;function Hp(_0x347bd2){return un=un||Vp(_0x347bd2),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x509451){const _0x5f0545=_0x509451['config'];m(_0x5f0545['authDomain'],_0x509451,'auth-domain-config-required');const _0x1ff3d4=_0x5f0545['emulator']?Cs(_0x5f0545,qp):'https://'+_0x509451['config']['authDomain']+'/'+Gp,_0x1e8d18={'apiKey':_0x5f0545['apiKey'],'appName':_0x509451['name'],'v':dt},_0x2737dd=jp['get'](_0x509451['config']['apiHost']);_0x2737dd&&(_0x1e8d18['eid']=_0x2737dd);const _0x253381=_0x509451['_getFrameworks']();return _0x253381['length']&&(_0x1e8d18['fw']=_0x253381['join'](',')),_0x1ff3d4+'?'+ut(_0x1e8d18)['slice'](0x1);}async function Yp(_0x35cda8){const _0x32d03d=await Hp(_0x35cda8),_0x5a691a=Z()['gapi'];return m(_0x5a691a,_0x35cda8,'internal-error'),_0x32d03d['open']({'where':document['body'],'url':Kp(_0x35cda8),'messageHandlersFilter':_0x5a691a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x57de7a=>new Promise(async(_0x516310,_0x2b3ab6)=>{await _0x57de7a['restyle']({'setHideOnLeave':!0x1});const _0x980f3e=X(_0x35cda8,'network-request-failed'),_0x24add1=Z()['setTimeout'](()=>{_0x2b3ab6(_0x980f3e);},$p['get']());function _0x85df9c(){Z()['clearTimeout'](_0x24add1),_0x516310(_0x57de7a);}_0x57de7a['ping'](_0x85df9c)['then'](_0x85df9c,()=>{_0x2b3ab6(_0x980f3e);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x2dae9c){this['window']=_0x2dae9c,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x82a410,_0x4995af,_0x3d1adc,_0x1bf879=Jp,_0x22a9d4=Xp){const _0x43079f=Math['max']((window['screen']['availHeight']-_0x22a9d4)/0x2,0x0)['toString'](),_0x2fc1c4=Math['max']((window['screen']['availWidth']-_0x1bf879)/0x2,0x0)['toString']();let _0x1883dd='';const _0x446fac={...Qp,'width':_0x1bf879['toString'](),'height':_0x22a9d4['toString'](),'top':_0x43079f,'left':_0x2fc1c4},_0x158e76=W()['toLowerCase']();_0x3d1adc&&(_0x1883dd=ka(_0x158e76)?Zp:_0x3d1adc),Ra(_0x158e76)&&(_0x4995af=_0x4995af||e_,_0x446fac['scrollbars']='yes');const _0x56fb58=Object['entries'](_0x446fac)['reduce']((_0x3e2e29,[_0x30ac7a,_0x2558cb])=>''+_0x3e2e29+_0x30ac7a+'='+_0x2558cb+',','');if(Rf(_0x158e76)&&_0x1883dd!=='_self')return n_(_0x4995af||'',_0x1883dd),new xr(null);const _0x4515b8=window['open'](_0x4995af||'',_0x1883dd,_0x56fb58);m(_0x4515b8,_0x82a410,'popup-blocked');try{_0x4515b8['focus']();}catch{}return new xr(_0x4515b8);}function n_(_0x2cf652,_0xe25699){const _0xd958d4=document['createElement']('a');_0xd958d4['href']=_0x2cf652,_0xd958d4['target']=_0xe25699;const _0x367f7c=document['createEvent']('MouseEvent');_0x367f7c['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xd958d4['dispatchEvent'](_0x367f7c);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x43d638,_0x9daf5e,_0x32f598,_0x54b9b5,_0x25e7df,_0x4944cd){m(_0x43d638['config']['authDomain'],_0x43d638,'auth-domain-config-required'),m(_0x43d638['config']['apiKey'],_0x43d638,'invalid-api-key');const _0x17beb4={'apiKey':_0x43d638['config']['apiKey'],'appName':_0x43d638['name'],'authType':_0x32f598,'redirectUrl':_0x54b9b5,'v':dt,'eventId':_0x25e7df};if(_0x9daf5e instanceof Wa){_0x9daf5e['setDefaultLanguage'](_0x43d638['languageCode']),_0x17beb4['providerId']=_0x9daf5e['providerId']||'',pn(_0x9daf5e['getCustomParameters']())||(_0x17beb4['customParameters']=JSON['stringify'](_0x9daf5e['getCustomParameters']()));for(const [_0x1ed80a,_0x35bb5e]of Object['entries']({}))_0x17beb4[_0x1ed80a]=_0x35bb5e;}if(_0x9daf5e instanceof tn){const _0x31e1eb=_0x9daf5e['getScopes']()['filter'](_0x5a5819=>_0x5a5819!=='');_0x31e1eb['length']>0x0&&(_0x17beb4['scopes']=_0x31e1eb['join'](','));}_0x43d638['tenantId']&&(_0x17beb4['tid']=_0x43d638['tenantId']);const _0x2c50b9=_0x17beb4;for(const _0x459239 of Object['keys'](_0x2c50b9))_0x2c50b9[_0x459239]===void 0x0&&delete _0x2c50b9[_0x459239];const _0x42505b=await _0x43d638['_getAppCheckToken'](),_0x59c594=_0x42505b?'#'+r_+'='+encodeURIComponent(_0x42505b):'';return o_(_0x43d638)+'?'+ut(_0x2c50b9)['slice'](0x1)+_0x59c594;}function o_({config:_0x26091c}){return _0x26091c['emulator']?Cs(_0x26091c,s_):'https://'+_0x26091c['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x2db675,_0xc82b10,_0x4efbc8,_0x5394df){var _0x225685;ce((_0x225685=this['eventManagers'][_0x2db675['_key']()])==null?void 0x0:_0x225685['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x34aaed=await Fr(_0x2db675,_0xc82b10,_0x4efbc8,Mi(),_0x5394df);return t_(_0x2db675,_0x34aaed,As());}async['_openRedirect'](_0x4df058,_0x1387df,_0x2dc6be,_0x56b673){await this['_originValidation'](_0x4df058);const _0x474fc2=await Fr(_0x4df058,_0x1387df,_0x2dc6be,Mi(),_0x56b673);return hp(_0x474fc2),new Promise(()=>{});}['_initialize'](_0x332e1f){const _0x50593a=_0x332e1f['_key']();if(this['eventManagers'][_0x50593a]){const {manager:_0x20eb5c,promise:_0x391d47}=this['eventManagers'][_0x50593a];return _0x20eb5c?Promise['resolve'](_0x20eb5c):(ce(_0x391d47,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x391d47);}const _0x3d0027=this['initAndGetManager'](_0x332e1f);return this['eventManagers'][_0x50593a]={'promise':_0x3d0027},_0x3d0027['catch'](()=>{delete this['eventManagers'][_0x50593a];}),_0x3d0027;}async['initAndGetManager'](_0x98ae4e){const _0x1a1ded=await Yp(_0x98ae4e),_0x50540e=new Dp(_0x98ae4e);return _0x1a1ded['register']('authEvent',_0x5bccd0=>(m(_0x5bccd0==null?void 0x0:_0x5bccd0['authEvent'],_0x98ae4e,'invalid-auth-event'),{'status':_0x50540e['onEvent'](_0x5bccd0['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x98ae4e['_key']()]={'manager':_0x50540e},this['iframes'][_0x98ae4e['_key']()]=_0x1a1ded,_0x50540e;}['_isIframeWebStorageSupported'](_0x2a1079,_0x49182d){this['iframes'][_0x2a1079['_key']()]['send'](pi,{'type':pi},_0x12d1de=>{var _0x3c57b8;const _0x2e0227=(_0x3c57b8=_0x12d1de==null?void 0x0:_0x12d1de[0x0])==null?void 0x0:_0x3c57b8[pi];_0x2e0227!==void 0x0&&_0x49182d(!!_0x2e0227),Y(_0x2a1079,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x242498){const _0x225596=_0x242498['_key']();return this['originValidationPromises'][_0x225596]||(this['originValidationPromises'][_0x225596]=Up(_0x242498)),this['originValidationPromises'][_0x225596];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4ea5b1){this['auth']=_0x4ea5b1,this['internalListeners']=new Map();}['getUid'](){var _0x3ed7f4;return this['assertAuthConfigured'](),((_0x3ed7f4=this['auth']['currentUser'])==null?void 0x0:_0x3ed7f4['uid'])||null;}async['getToken'](_0x33fae3){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x33fae3)}:null;}['addAuthTokenListener'](_0x5edaf1){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5edaf1))return;const _0x5056a3=this['auth']['onIdTokenChanged'](_0x350c85=>{_0x5edaf1((_0x350c85==null?void 0x0:_0x350c85['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5edaf1,_0x5056a3),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x54be06){this['assertAuthConfigured']();const _0x1c5d22=this['internalListeners']['get'](_0x54be06);_0x1c5d22&&(this['internalListeners']['delete'](_0x54be06),_0x1c5d22(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x237d48){switch(_0x237d48){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4418a2){st(new Fe('auth',(_0x49772f,{options:_0x260434})=>{const _0x36544f=_0x49772f['getProvider']('app')['getImmediate'](),_0x4a9161=_0x49772f['getProvider']('heartbeat'),_0x48dbdc=_0x49772f['getProvider']('app-check-internal'),{apiKey:_0x3b0839,authDomain:_0xeceba2}=_0x36544f['options'];m(_0x3b0839&&!_0x3b0839['includes'](':'),'invalid-api-key',{'appName':_0x36544f['name']});const _0xb45fe5={'apiKey':_0x3b0839,'authDomain':_0xeceba2,'clientPlatform':_0x4418a2,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4418a2)},_0x517659=new Df(_0x36544f,_0x4a9161,_0x48dbdc,_0xb45fe5);return Hf(_0x517659,_0x260434),_0x517659;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x55a6bb,_0x48c853,_0x98ba08)=>{_0x55a6bb['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x6dde29=>{const _0xfe7aea=Ke(_0x6dde29['getProvider']('auth')['getImmediate']());return(_0x11aa6d=>new l_(_0x11aa6d))(_0xfe7aea);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4418a2)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x174cce=>async _0x499f06=>{const _0x549b89=_0x499f06&&await _0x499f06['getIdTokenResult'](),_0x5e9daa=_0x549b89&&(new Date()['getTime']()-Date['parse'](_0x549b89['issuedAtTime']))/0x3e8;if(_0x5e9daa&&_0x5e9daa>f_)return;const _0x5b5d60=_0x549b89==null?void 0x0:_0x549b89['token'];Br!==_0x5b5d60&&(Br=_0x5b5d60,await fetch(_0x174cce,{'method':_0x5b5d60?'POST':'DELETE','headers':_0x5b5d60?{'Authorization':'Bearer\x20'+_0x5b5d60}:{}}));};function B_(_0x1379e0=Zr()){const _0x32a6b4=Hi(_0x1379e0,'auth');if(_0x32a6b4['isInitialized']())return _0x32a6b4['getImmediate']();const _0x508b85=Vf(_0x1379e0,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x5b78b5=jr('authTokenSyncURL');if(_0x5b78b5&&typeof isSecureContext=='boolean'&&isSecureContext){const _0xa15b31=new URL(_0x5b78b5,location['origin']);if(location['origin']===_0xa15b31['origin']){const _0x345ed5=p_(_0xa15b31['toString']());sp(_0x508b85,_0x345ed5,()=>_0x345ed5(_0x508b85['currentUser'])),ip(_0x508b85,_0x4e3ef8=>_0x345ed5(_0x4e3ef8));}}const _0x42de64=qr('auth');return _0x42de64&&$f(_0x508b85,'http://'+_0x42de64),_0x508b85;}function __(){var _0x36cd46;return((_0x36cd46=document['getElementsByTagName']('head'))==null?void 0x0:_0x36cd46[0x0])??document;}Mf({'loadJS'(_0x1d9ed6){return new Promise((_0x3d3b25,_0x129cb7)=>{const _0x2a672a=document['createElement']('script');_0x2a672a['setAttribute']('src',_0x1d9ed6),_0x2a672a['onload']=_0x3d3b25,_0x2a672a['onerror']=_0x3d9a48=>{const _0x2c83b1=X('internal-error');_0x2c83b1['customData']=_0x3d9a48,_0x129cb7(_0x2c83b1);},_0x2a672a['type']='text/javascript',_0x2a672a['charset']='UTF-8',__()['appendChild'](_0x2a672a);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,P_ as a,B_ as b,ap as c,Zr as d,w_ as e,x_ as f,g_ as g,m_ as h,Sl as i,Hd as j,D_ as k,Gd as l,N_ as m,U_ as n,v_ as o,O_ as p,k_ as q,y_ as r,F_ as s,b_ as t,I_ as u,A_ as v,Vt as w,E_ as x,M_ as y,T_ as z};