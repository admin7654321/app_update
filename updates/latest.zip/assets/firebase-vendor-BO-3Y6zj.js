const Ja=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5e7bc9,_0x1fd654){if(!_0x5e7bc9)throw lt(_0x1fd654);},lt=function(_0x34820f){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x34820f);},Hr=function(_0x46ae90){const _0x270540=[];let _0x22d52f=0x0;for(let _0x15e477=0x0;_0x15e477<_0x46ae90['length'];_0x15e477++){let _0x6fa317=_0x46ae90['charCodeAt'](_0x15e477);_0x6fa317<0x80?_0x270540[_0x22d52f++]=_0x6fa317:_0x6fa317<0x800?(_0x270540[_0x22d52f++]=_0x6fa317>>0x6|0xc0,_0x270540[_0x22d52f++]=_0x6fa317&0x3f|0x80):(_0x6fa317&0xfc00)===0xd800&&_0x15e477+0x1<_0x46ae90['length']&&(_0x46ae90['charCodeAt'](_0x15e477+0x1)&0xfc00)===0xdc00?(_0x6fa317=0x10000+((_0x6fa317&0x3ff)<<0xa)+(_0x46ae90['charCodeAt'](++_0x15e477)&0x3ff),_0x270540[_0x22d52f++]=_0x6fa317>>0x12|0xf0,_0x270540[_0x22d52f++]=_0x6fa317>>0xc&0x3f|0x80,_0x270540[_0x22d52f++]=_0x6fa317>>0x6&0x3f|0x80,_0x270540[_0x22d52f++]=_0x6fa317&0x3f|0x80):(_0x270540[_0x22d52f++]=_0x6fa317>>0xc|0xe0,_0x270540[_0x22d52f++]=_0x6fa317>>0x6&0x3f|0x80,_0x270540[_0x22d52f++]=_0x6fa317&0x3f|0x80);}return _0x270540;},Xa=function(_0x2717c5){const _0x489c80=[];let _0x32ef33=0x0,_0x105e5f=0x0;for(;_0x32ef33<_0x2717c5['length'];){const _0xc5d2d4=_0x2717c5[_0x32ef33++];if(_0xc5d2d4<0x80)_0x489c80[_0x105e5f++]=String['fromCharCode'](_0xc5d2d4);else{if(_0xc5d2d4>0xbf&&_0xc5d2d4<0xe0){const _0x5350f0=_0x2717c5[_0x32ef33++];_0x489c80[_0x105e5f++]=String['fromCharCode']((_0xc5d2d4&0x1f)<<0x6|_0x5350f0&0x3f);}else{if(_0xc5d2d4>0xef&&_0xc5d2d4<0x16d){const _0x4ee8c5=_0x2717c5[_0x32ef33++],_0x506c0a=_0x2717c5[_0x32ef33++],_0x1f533b=_0x2717c5[_0x32ef33++],_0x4eb39f=((_0xc5d2d4&0x7)<<0x12|(_0x4ee8c5&0x3f)<<0xc|(_0x506c0a&0x3f)<<0x6|_0x1f533b&0x3f)-0x10000;_0x489c80[_0x105e5f++]=String['fromCharCode'](0xd800+(_0x4eb39f>>0xa)),_0x489c80[_0x105e5f++]=String['fromCharCode'](0xdc00+(_0x4eb39f&0x3ff));}else{const _0x5f1d64=_0x2717c5[_0x32ef33++],_0x34741f=_0x2717c5[_0x32ef33++];_0x489c80[_0x105e5f++]=String['fromCharCode']((_0xc5d2d4&0xf)<<0xc|(_0x5f1d64&0x3f)<<0x6|_0x34741f&0x3f);}}}}return _0x489c80['join']('');},xi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x169732,_0x33d500){if(!Array['isArray'](_0x169732))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x52c0e1=_0x33d500?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0xc1acf=[];for(let _0x75ef1a=0x0;_0x75ef1a<_0x169732['length'];_0x75ef1a+=0x3){const _0x25fc19=_0x169732[_0x75ef1a],_0x106c87=_0x75ef1a+0x1<_0x169732['length'],_0x53a5b8=_0x106c87?_0x169732[_0x75ef1a+0x1]:0x0,_0xa0e250=_0x75ef1a+0x2<_0x169732['length'],_0x213b6d=_0xa0e250?_0x169732[_0x75ef1a+0x2]:0x0,_0x31e7a8=_0x25fc19>>0x2,_0x1be005=(_0x25fc19&0x3)<<0x4|_0x53a5b8>>0x4;let _0x4d0b3b=(_0x53a5b8&0xf)<<0x2|_0x213b6d>>0x6,_0x475226=_0x213b6d&0x3f;_0xa0e250||(_0x475226=0x40,_0x106c87||(_0x4d0b3b=0x40)),_0xc1acf['push'](_0x52c0e1[_0x31e7a8],_0x52c0e1[_0x1be005],_0x52c0e1[_0x4d0b3b],_0x52c0e1[_0x475226]);}return _0xc1acf['join']('');},'encodeString'(_0x34e237,_0x8edb6c){return this['HAS_NATIVE_SUPPORT']&&!_0x8edb6c?btoa(_0x34e237):this['encodeByteArray'](Hr(_0x34e237),_0x8edb6c);},'decodeString'(_0x154551,_0x33a5e4){return this['HAS_NATIVE_SUPPORT']&&!_0x33a5e4?atob(_0x154551):Xa(this['decodeStringToByteArray'](_0x154551,_0x33a5e4));},'decodeStringToByteArray'(_0x1a7f4c,_0x4c5148){this['init_']();const _0x4ebda5=_0x4c5148?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x75c07d=[];for(let _0x3bc66a=0x0;_0x3bc66a<_0x1a7f4c['length'];){const _0x1c2897=_0x4ebda5[_0x1a7f4c['charAt'](_0x3bc66a++)],_0x38e427=_0x3bc66a<_0x1a7f4c['length']?_0x4ebda5[_0x1a7f4c['charAt'](_0x3bc66a)]:0x0;++_0x3bc66a;const _0x2c3fc1=_0x3bc66a<_0x1a7f4c['length']?_0x4ebda5[_0x1a7f4c['charAt'](_0x3bc66a)]:0x40;++_0x3bc66a;const _0x35cbbf=_0x3bc66a<_0x1a7f4c['length']?_0x4ebda5[_0x1a7f4c['charAt'](_0x3bc66a)]:0x40;if(++_0x3bc66a,_0x1c2897==null||_0x38e427==null||_0x2c3fc1==null||_0x35cbbf==null)throw new Za();const _0x4feadf=_0x1c2897<<0x2|_0x38e427>>0x4;if(_0x75c07d['push'](_0x4feadf),_0x2c3fc1!==0x40){const _0xaca7bd=_0x38e427<<0x4&0xf0|_0x2c3fc1>>0x2;if(_0x75c07d['push'](_0xaca7bd),_0x35cbbf!==0x40){const _0x187962=_0x2c3fc1<<0x6&0xc0|_0x35cbbf;_0x75c07d['push'](_0x187962);}}}return _0x75c07d;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x5f18af=0x0;_0x5f18af<this['ENCODED_VALS']['length'];_0x5f18af++)this['byteToCharMap_'][_0x5f18af]=this['ENCODED_VALS']['charAt'](_0x5f18af),this['charToByteMap_'][this['byteToCharMap_'][_0x5f18af]]=_0x5f18af,this['byteToCharMapWebSafe_'][_0x5f18af]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5f18af),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x5f18af]]=_0x5f18af,_0x5f18af>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x5f18af)]=_0x5f18af,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x5f18af)]=_0x5f18af);}}};class Za extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x844db7){const _0x346e4d=Hr(_0x844db7);return xi['encodeByteArray'](_0x346e4d,!0x0);},un=function(_0x5bc80a){return $r(_0x5bc80a)['replace'](/\./g,'');},dn=function(_0x25822b){try{return xi['decodeString'](_0x25822b,!0x0);}catch(_0x25e1e7){console['error']('base64Decode\x20failed:\x20',_0x25e1e7);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ec(_0x5a7d69){return Gr(void 0x0,_0x5a7d69);}function Gr(_0x20b8e9,_0xba3113){if(!(_0xba3113 instanceof Object))return _0xba3113;switch(_0xba3113['constructor']){case Date:const _0x34d389=_0xba3113;return new Date(_0x34d389['getTime']());case Object:_0x20b8e9===void 0x0&&(_0x20b8e9={});break;case Array:_0x20b8e9=[];break;default:return _0xba3113;}for(const _0x12cf1d in _0xba3113)!_0xba3113['hasOwnProperty'](_0x12cf1d)||!tc(_0x12cf1d)||(_0x20b8e9[_0x12cf1d]=Gr(_0x20b8e9[_0x12cf1d],_0xba3113[_0x12cf1d]));return _0x20b8e9;}function tc(_0xce392){return _0xce392!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ic=()=>nc()['__FIREBASE_DEFAULTS__'],sc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3f2c34=Ns['__FIREBASE_DEFAULTS__'];if(_0x3f2c34)return JSON['parse'](_0x3f2c34);},rc=()=>{if(typeof document>'u')return;let _0x240382;try{_0x240382=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3dd720=_0x240382&&dn(_0x240382[0x1]);return _0x3dd720&&JSON['parse'](_0x3dd720);},Fi=()=>{try{return Ja()||ic()||sc()||rc();}catch(_0x3754f6){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3754f6);return;}},qr=_0x218e3d=>{var _0x13c7e4,_0x17c0ac;return(_0x17c0ac=(_0x13c7e4=Fi())==null?void 0x0:_0x13c7e4['emulatorHosts'])==null?void 0x0:_0x17c0ac[_0x218e3d];},oc=_0x2d939a=>{const _0x444f27=qr(_0x2d939a);if(!_0x444f27)return;const _0x57fdad=_0x444f27['lastIndexOf'](':');if(_0x57fdad<=0x0||_0x57fdad+0x1===_0x444f27['length'])throw new Error('Invalid\x20host\x20'+_0x444f27+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2b434e=parseInt(_0x444f27['substring'](_0x57fdad+0x1),0xa);return _0x444f27[0x0]==='['?[_0x444f27['substring'](0x1,_0x57fdad-0x1),_0x2b434e]:[_0x444f27['substring'](0x0,_0x57fdad),_0x2b434e];},zr=()=>{var _0x20d931;return(_0x20d931=Fi())==null?void 0x0:_0x20d931['config'];},jr=_0x4cfd08=>{var _0x596cb7;return(_0x596cb7=Fi())==null?void 0x0:_0x596cb7['_'+_0x4cfd08];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2df580,_0x15185b)=>{this['resolve']=_0x2df580,this['reject']=_0x15185b;});}['wrapCallback'](_0x1a9831){return(_0x494dfb,_0x3bc98b)=>{_0x494dfb?this['reject'](_0x494dfb):this['resolve'](_0x3bc98b),typeof _0x1a9831=='function'&&(this['promise']['catch'](()=>{}),_0x1a9831['length']===0x1?_0x1a9831(_0x494dfb):_0x1a9831(_0x494dfb,_0x3bc98b));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ac(_0x44bf10,_0x12a58a){if(_0x44bf10['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xd0aded={'alg':'none','type':'JWT'},_0x28fb3a=_0x12a58a||'demo-project',_0xdd2ea8=_0x44bf10['iat']||0x0,_0x1a1a6a=_0x44bf10['sub']||_0x44bf10['user_id'];if(!_0x1a1a6a)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x119577={'iss':'https://securetoken.google.com/'+_0x28fb3a,'aud':_0x28fb3a,'iat':_0xdd2ea8,'exp':_0xdd2ea8+0xe10,'auth_time':_0xdd2ea8,'sub':_0x1a1a6a,'user_id':_0x1a1a6a,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x44bf10};return[un(JSON['stringify'](_0xd0aded)),un(JSON['stringify'](_0x119577)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Ui(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function cc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function lc(){const _0x2bc94d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2bc94d=='object'&&_0x2bc94d['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function hc(){const _0x4667ad=W();return _0x4667ad['indexOf']('MSIE\x20')>=0x0||_0x4667ad['indexOf']('Trident/')>=0x0;}function uc(){return Vr['NODE_ADMIN']===!0x0;}function dc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function fc(){return new Promise((_0x32f282,_0xc5ae73)=>{try{let _0x58ab7d=!0x0;const _0x59eb23='validate-browser-context-for-indexeddb-analytics-module',_0x1aa7dd=self['indexedDB']['open'](_0x59eb23);_0x1aa7dd['onsuccess']=()=>{_0x1aa7dd['result']['close'](),_0x58ab7d||self['indexedDB']['deleteDatabase'](_0x59eb23),_0x32f282(!0x0);},_0x1aa7dd['onupgradeneeded']=()=>{_0x58ab7d=!0x1;},_0x1aa7dd['onerror']=()=>{var _0x1f241d;_0xc5ae73(((_0x1f241d=_0x1aa7dd['error'])==null?void 0x0:_0x1f241d['message'])||'');};}catch(_0xb77f1b){_0xc5ae73(_0xb77f1b);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pc='FirebaseError';class be extends Error{constructor(_0x52bf43,_0x27c1e2,_0x38940e){super(_0x27c1e2),this['code']=_0x52bf43,this['customData']=_0x38940e,this['name']=pc,Object['setPrototypeOf'](this,be['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,$t['prototype']['create']);}}class $t{constructor(_0x405e03,_0x51baca,_0x17d52c){this['service']=_0x405e03,this['serviceName']=_0x51baca,this['errors']=_0x17d52c;}['create'](_0x546dcb,..._0x343cce){const _0x3bac53=_0x343cce[0x0]||{},_0x1bce8c=this['service']+'/'+_0x546dcb,_0x237095=this['errors'][_0x546dcb],_0x1830fb=_0x237095?_c(_0x237095,_0x3bac53):'Error',_0x549be9=this['serviceName']+':\x20'+_0x1830fb+'\x20('+_0x1bce8c+').';return new be(_0x1bce8c,_0x549be9,_0x3bac53);}}function _c(_0x181cc5,_0x7691ff){return _0x181cc5['replace'](gc,(_0x4f8392,_0xe2d2f4)=>{const _0x49bb0f=_0x7691ff[_0xe2d2f4];return _0x49bb0f!=null?String(_0x49bb0f):'<'+_0xe2d2f4+'?>';});}const gc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2a8937){return JSON['parse'](_0x2a8937);}function O(_0x119374){return JSON['stringify'](_0x119374);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1eb32e){let _0x149898={},_0x1d998c={},_0x97e5cf={},_0x187b84='';try{const _0x115c60=_0x1eb32e['split']('.');_0x149898=Nt(dn(_0x115c60[0x0])||''),_0x1d998c=Nt(dn(_0x115c60[0x1])||''),_0x187b84=_0x115c60[0x2],_0x97e5cf=_0x1d998c['d']||{},delete _0x1d998c['d'];}catch{}return{'header':_0x149898,'claims':_0x1d998c,'data':_0x97e5cf,'signature':_0x187b84};},mc=function(_0x503e48){const _0x5a641d=Yr(_0x503e48),_0x59b85d=_0x5a641d['claims'];return!!_0x59b85d&&typeof _0x59b85d=='object'&&_0x59b85d['hasOwnProperty']('iat');},yc=function(_0x4af5e2){const _0xbceec4=Yr(_0x4af5e2)['claims'];return typeof _0xbceec4=='object'&&_0xbceec4['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x22630b,_0x4e171e){return Object['prototype']['hasOwnProperty']['call'](_0x22630b,_0x4e171e);}function Me(_0x136b32,_0x4dc578){if(Object['prototype']['hasOwnProperty']['call'](_0x136b32,_0x4dc578))return _0x136b32[_0x4dc578];}function fn(_0x295000){for(const _0x399297 in _0x295000)if(Object['prototype']['hasOwnProperty']['call'](_0x295000,_0x399297))return!0x1;return!0x0;}function pn(_0x70fc50,_0x58a057,_0x1535cc){const _0x507fd0={};for(const _0x597f8b in _0x70fc50)Object['prototype']['hasOwnProperty']['call'](_0x70fc50,_0x597f8b)&&(_0x507fd0[_0x597f8b]=_0x58a057['call'](_0x1535cc,_0x70fc50[_0x597f8b],_0x597f8b,_0x70fc50));return _0x507fd0;}function Le(_0x5f1f57,_0x38ea5e){if(_0x5f1f57===_0x38ea5e)return!0x0;const _0x4aa5ec=Object['keys'](_0x5f1f57),_0x44fb75=Object['keys'](_0x38ea5e);for(const _0x11b88a of _0x4aa5ec){if(!_0x44fb75['includes'](_0x11b88a))return!0x1;const _0xea219c=_0x5f1f57[_0x11b88a],_0x297bb9=_0x38ea5e[_0x11b88a];if(Ps(_0xea219c)&&Ps(_0x297bb9)){if(!Le(_0xea219c,_0x297bb9))return!0x1;}else{if(_0xea219c!==_0x297bb9)return!0x1;}}for(const _0xd7fc4d of _0x44fb75)if(!_0x4aa5ec['includes'](_0xd7fc4d))return!0x1;return!0x0;}function Ps(_0x479d8b){return _0x479d8b!==null&&typeof _0x479d8b=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ht(_0x47224b){const _0x43c58a=[];for(const [_0x548a5e,_0xc79319]of Object['entries'](_0x47224b))Array['isArray'](_0xc79319)?_0xc79319['forEach'](_0x1458a5=>{_0x43c58a['push'](encodeURIComponent(_0x548a5e)+'='+encodeURIComponent(_0x1458a5));}):_0x43c58a['push'](encodeURIComponent(_0x548a5e)+'='+encodeURIComponent(_0xc79319));return _0x43c58a['length']?'&'+_0x43c58a['join']('&'):'';}function wt(_0x5c190c){const _0x4b79d5={};return _0x5c190c['replace'](/^\?/,'')['split']('&')['forEach'](_0xc619a9=>{if(_0xc619a9){const [_0x362b5d,_0x401b04]=_0xc619a9['split']('=');_0x4b79d5[decodeURIComponent(_0x362b5d)]=decodeURIComponent(_0x401b04);}}),_0x4b79d5;}function Ct(_0x21c56a){const _0x494aea=_0x21c56a['indexOf']('?');if(!_0x494aea)return'';const _0x52fffd=_0x21c56a['indexOf']('#',_0x494aea);return _0x21c56a['substring'](_0x494aea,_0x52fffd>0x0?_0x52fffd:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x8f10cf=0x1;_0x8f10cf<this['blockSize'];++_0x8f10cf)this['pad_'][_0x8f10cf]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x50277b,_0x3c328f){_0x3c328f||(_0x3c328f=0x0);const _0x2b68e8=this['W_'];if(typeof _0x50277b=='string'){for(let _0x5889b8=0x0;_0x5889b8<0x10;_0x5889b8++)_0x2b68e8[_0x5889b8]=_0x50277b['charCodeAt'](_0x3c328f)<<0x18|_0x50277b['charCodeAt'](_0x3c328f+0x1)<<0x10|_0x50277b['charCodeAt'](_0x3c328f+0x2)<<0x8|_0x50277b['charCodeAt'](_0x3c328f+0x3),_0x3c328f+=0x4;}else{for(let _0xe1b010=0x0;_0xe1b010<0x10;_0xe1b010++)_0x2b68e8[_0xe1b010]=_0x50277b[_0x3c328f]<<0x18|_0x50277b[_0x3c328f+0x1]<<0x10|_0x50277b[_0x3c328f+0x2]<<0x8|_0x50277b[_0x3c328f+0x3],_0x3c328f+=0x4;}for(let _0xcbe45f=0x10;_0xcbe45f<0x50;_0xcbe45f++){const _0x5717a9=_0x2b68e8[_0xcbe45f-0x3]^_0x2b68e8[_0xcbe45f-0x8]^_0x2b68e8[_0xcbe45f-0xe]^_0x2b68e8[_0xcbe45f-0x10];_0x2b68e8[_0xcbe45f]=(_0x5717a9<<0x1|_0x5717a9>>>0x1f)&0xffffffff;}let _0x692df2=this['chain_'][0x0],_0x5b602c=this['chain_'][0x1],_0x36aea4=this['chain_'][0x2],_0x3149c6=this['chain_'][0x3],_0x45d759=this['chain_'][0x4],_0x154365,_0x69364f;for(let _0xb18f2=0x0;_0xb18f2<0x50;_0xb18f2++){_0xb18f2<0x28?_0xb18f2<0x14?(_0x154365=_0x3149c6^_0x5b602c&(_0x36aea4^_0x3149c6),_0x69364f=0x5a827999):(_0x154365=_0x5b602c^_0x36aea4^_0x3149c6,_0x69364f=0x6ed9eba1):_0xb18f2<0x3c?(_0x154365=_0x5b602c&_0x36aea4|_0x3149c6&(_0x5b602c|_0x36aea4),_0x69364f=0x8f1bbcdc):(_0x154365=_0x5b602c^_0x36aea4^_0x3149c6,_0x69364f=0xca62c1d6);const _0x29de1d=(_0x692df2<<0x5|_0x692df2>>>0x1b)+_0x154365+_0x45d759+_0x69364f+_0x2b68e8[_0xb18f2]&0xffffffff;_0x45d759=_0x3149c6,_0x3149c6=_0x36aea4,_0x36aea4=(_0x5b602c<<0x1e|_0x5b602c>>>0x2)&0xffffffff,_0x5b602c=_0x692df2,_0x692df2=_0x29de1d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x692df2&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5b602c&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x36aea4&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x3149c6&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x45d759&0xffffffff;}['update'](_0x5d570c,_0x3ea8e8){if(_0x5d570c==null)return;_0x3ea8e8===void 0x0&&(_0x3ea8e8=_0x5d570c['length']);const _0x4c3ac1=_0x3ea8e8-this['blockSize'];let _0x257b50=0x0;const _0x4abfb9=this['buf_'];let _0x37a284=this['inbuf_'];for(;_0x257b50<_0x3ea8e8;){if(_0x37a284===0x0){for(;_0x257b50<=_0x4c3ac1;)this['compress_'](_0x5d570c,_0x257b50),_0x257b50+=this['blockSize'];}if(typeof _0x5d570c=='string'){for(;_0x257b50<_0x3ea8e8;)if(_0x4abfb9[_0x37a284]=_0x5d570c['charCodeAt'](_0x257b50),++_0x37a284,++_0x257b50,_0x37a284===this['blockSize']){this['compress_'](_0x4abfb9),_0x37a284=0x0;break;}}else{for(;_0x257b50<_0x3ea8e8;)if(_0x4abfb9[_0x37a284]=_0x5d570c[_0x257b50],++_0x37a284,++_0x257b50,_0x37a284===this['blockSize']){this['compress_'](_0x4abfb9),_0x37a284=0x0;break;}}}this['inbuf_']=_0x37a284,this['total_']+=_0x3ea8e8;}['digest'](){const _0x5aad89=[];let _0x5ab333=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x58938c=this['blockSize']-0x1;_0x58938c>=0x38;_0x58938c--)this['buf_'][_0x58938c]=_0x5ab333&0xff,_0x5ab333/=0x100;this['compress_'](this['buf_']);let _0x2bf5a6=0x0;for(let _0x2cdaf6=0x0;_0x2cdaf6<0x5;_0x2cdaf6++)for(let _0x17a8be=0x18;_0x17a8be>=0x0;_0x17a8be-=0x8)_0x5aad89[_0x2bf5a6]=this['chain_'][_0x2cdaf6]>>_0x17a8be&0xff,++_0x2bf5a6;return _0x5aad89;}}function Ec(_0x35441c,_0x57c92e){const _0x25be02=new Ic(_0x35441c,_0x57c92e);return _0x25be02['subscribe']['bind'](_0x25be02);}class Ic{constructor(_0x41a554,_0x555036){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x555036,this['task']['then'](()=>{_0x41a554(this);})['catch'](_0x1d1d92=>{this['error'](_0x1d1d92);});}['next'](_0x71d847){this['forEachObserver'](_0x2bc23d=>{_0x2bc23d['next'](_0x71d847);});}['error'](_0x37bcef){this['forEachObserver'](_0x42dff3=>{_0x42dff3['error'](_0x37bcef);}),this['close'](_0x37bcef);}['complete'](){this['forEachObserver'](_0x5bb339=>{_0x5bb339['complete']();}),this['close']();}['subscribe'](_0x50dcfd,_0x403e74,_0x116bb0){let _0x4f0885;if(_0x50dcfd===void 0x0&&_0x403e74===void 0x0&&_0x116bb0===void 0x0)throw new Error('Missing\x20Observer.');wc(_0x50dcfd,['next','error','complete'])?_0x4f0885=_0x50dcfd:_0x4f0885={'next':_0x50dcfd,'error':_0x403e74,'complete':_0x116bb0},_0x4f0885['next']===void 0x0&&(_0x4f0885['next']=ei),_0x4f0885['error']===void 0x0&&(_0x4f0885['error']=ei),_0x4f0885['complete']===void 0x0&&(_0x4f0885['complete']=ei);const _0x52865e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4f0885['error'](this['finalError']):_0x4f0885['complete']();}catch{}}),this['observers']['push'](_0x4f0885),_0x52865e;}['unsubscribeOne'](_0x53b068){this['observers']===void 0x0||this['observers'][_0x53b068]===void 0x0||(delete this['observers'][_0x53b068],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x471dcf){if(!this['finalized']){for(let _0x1f4854=0x0;_0x1f4854<this['observers']['length'];_0x1f4854++)this['sendOne'](_0x1f4854,_0x471dcf);}}['sendOne'](_0x22d96b,_0x4e8bda){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x22d96b]!==void 0x0)try{_0x4e8bda(this['observers'][_0x22d96b]);}catch(_0x3e1232){typeof console<'u'&&console['error']&&console['error'](_0x3e1232);}});}['close'](_0x4611d6){this['finalized']||(this['finalized']=!0x0,_0x4611d6!==void 0x0&&(this['finalError']=_0x4611d6),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function wc(_0x1f75eb,_0x13a9a2){if(typeof _0x1f75eb!='object'||_0x1f75eb===null)return!0x1;for(const _0x1cbdfe of _0x13a9a2)if(_0x1cbdfe in _0x1f75eb&&typeof _0x1f75eb[_0x1cbdfe]=='function')return!0x0;return!0x1;}function ei(){}function nt(_0x11bd38,_0x19bd79){return _0x11bd38+'\x20failed:\x20'+_0x19bd79+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cc=function(_0x1ba1a1){const _0x449d38=[];let _0x2c69aa=0x0;for(let _0x438e24=0x0;_0x438e24<_0x1ba1a1['length'];_0x438e24++){let _0x24edaf=_0x1ba1a1['charCodeAt'](_0x438e24);if(_0x24edaf>=0xd800&&_0x24edaf<=0xdbff){const _0x829791=_0x24edaf-0xd800;_0x438e24++,f(_0x438e24<_0x1ba1a1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1da370=_0x1ba1a1['charCodeAt'](_0x438e24)-0xdc00;_0x24edaf=0x10000+(_0x829791<<0xa)+_0x1da370;}_0x24edaf<0x80?_0x449d38[_0x2c69aa++]=_0x24edaf:_0x24edaf<0x800?(_0x449d38[_0x2c69aa++]=_0x24edaf>>0x6|0xc0,_0x449d38[_0x2c69aa++]=_0x24edaf&0x3f|0x80):_0x24edaf<0x10000?(_0x449d38[_0x2c69aa++]=_0x24edaf>>0xc|0xe0,_0x449d38[_0x2c69aa++]=_0x24edaf>>0x6&0x3f|0x80,_0x449d38[_0x2c69aa++]=_0x24edaf&0x3f|0x80):(_0x449d38[_0x2c69aa++]=_0x24edaf>>0x12|0xf0,_0x449d38[_0x2c69aa++]=_0x24edaf>>0xc&0x3f|0x80,_0x449d38[_0x2c69aa++]=_0x24edaf>>0x6&0x3f|0x80,_0x449d38[_0x2c69aa++]=_0x24edaf&0x3f|0x80);}return _0x449d38;},Mn=function(_0x219d5a){let _0x1acf8a=0x0;for(let _0x222eef=0x0;_0x222eef<_0x219d5a['length'];_0x222eef++){const _0x5ae270=_0x219d5a['charCodeAt'](_0x222eef);_0x5ae270<0x80?_0x1acf8a++:_0x5ae270<0x800?_0x1acf8a+=0x2:_0x5ae270>=0xd800&&_0x5ae270<=0xdbff?(_0x1acf8a+=0x4,_0x222eef++):_0x1acf8a+=0x3;}return _0x1acf8a;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x17bfb3){return _0x17bfb3&&_0x17bfb3['_delegate']?_0x17bfb3['_delegate']:_0x17bfb3;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Gt(_0x44b5af){try{return(_0x44b5af['startsWith']('http://')||_0x44b5af['startsWith']('https://')?new URL(_0x44b5af)['hostname']:_0x44b5af)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x24b0cb){return(await fetch(_0x24b0cb,{'credentials':'include'}))['ok'];}class xe{constructor(_0x112a8d,_0xe7d72a,_0x2efb42){this['name']=_0x112a8d,this['instanceFactory']=_0xe7d72a,this['type']=_0x2efb42,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x18e90c){return this['instantiationMode']=_0x18e90c,this;}['setMultipleInstances'](_0x3887cf){return this['multipleInstances']=_0x3887cf,this;}['setServiceProps'](_0x26568e){return this['serviceProps']=_0x26568e,this;}['setInstanceCreatedCallback'](_0x3cb44c){return this['onInstanceCreated']=_0x3cb44c,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tc{constructor(_0x4853fe,_0x2eb8f7){this['name']=_0x4853fe,this['container']=_0x2eb8f7,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5f4402){const _0x23fcf4=this['normalizeInstanceIdentifier'](_0x5f4402);if(!this['instancesDeferred']['has'](_0x23fcf4)){const _0x268964=new H();if(this['instancesDeferred']['set'](_0x23fcf4,_0x268964),this['isInitialized'](_0x23fcf4)||this['shouldAutoInitialize']())try{const _0x2390f0=this['getOrInitializeService']({'instanceIdentifier':_0x23fcf4});_0x2390f0&&_0x268964['resolve'](_0x2390f0);}catch{}}return this['instancesDeferred']['get'](_0x23fcf4)['promise'];}['getImmediate'](_0x44dafe){const _0x201164=this['normalizeInstanceIdentifier'](_0x44dafe==null?void 0x0:_0x44dafe['identifier']),_0x2e516c=(_0x44dafe==null?void 0x0:_0x44dafe['optional'])??!0x1;if(this['isInitialized'](_0x201164)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x201164});}catch(_0x29e7db){if(_0x2e516c)return null;throw _0x29e7db;}else{if(_0x2e516c)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x684a91){if(_0x684a91['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x684a91['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x684a91,!!this['shouldAutoInitialize']()){if(bc(_0x684a91))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x2791de,_0x1acf4f]of this['instancesDeferred']['entries']()){const _0xa39e12=this['normalizeInstanceIdentifier'](_0x2791de);try{const _0x2134d5=this['getOrInitializeService']({'instanceIdentifier':_0xa39e12});_0x1acf4f['resolve'](_0x2134d5);}catch{}}}}['clearInstance'](_0x2ab1e1=ke){this['instancesDeferred']['delete'](_0x2ab1e1),this['instancesOptions']['delete'](_0x2ab1e1),this['instances']['delete'](_0x2ab1e1);}async['delete'](){const _0xbc1232=Array['from'](this['instances']['values']());await Promise['all']([..._0xbc1232['filter'](_0x368244=>'INTERNAL'in _0x368244)['map'](_0x492ea5=>_0x492ea5['INTERNAL']['delete']()),..._0xbc1232['filter'](_0x491195=>'_delete'in _0x491195)['map'](_0x60dfbf=>_0x60dfbf['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x1e0f0e=ke){return this['instances']['has'](_0x1e0f0e);}['getOptions'](_0x322c47=ke){return this['instancesOptions']['get'](_0x322c47)||{};}['initialize'](_0x92dbf6={}){const {options:_0x2288c6={}}=_0x92dbf6,_0x5cc860=this['normalizeInstanceIdentifier'](_0x92dbf6['instanceIdentifier']);if(this['isInitialized'](_0x5cc860))throw Error(this['name']+'('+_0x5cc860+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5377cc=this['getOrInitializeService']({'instanceIdentifier':_0x5cc860,'options':_0x2288c6});for(const [_0x1462fa,_0xc6070c]of this['instancesDeferred']['entries']()){const _0x546808=this['normalizeInstanceIdentifier'](_0x1462fa);_0x5cc860===_0x546808&&_0xc6070c['resolve'](_0x5377cc);}return _0x5377cc;}['onInit'](_0x14c3b3,_0x164185){const _0x36c5b7=this['normalizeInstanceIdentifier'](_0x164185),_0x267780=this['onInitCallbacks']['get'](_0x36c5b7)??new Set();_0x267780['add'](_0x14c3b3),this['onInitCallbacks']['set'](_0x36c5b7,_0x267780);const _0x50ceb8=this['instances']['get'](_0x36c5b7);return _0x50ceb8&&_0x14c3b3(_0x50ceb8,_0x36c5b7),()=>{_0x267780['delete'](_0x14c3b3);};}['invokeOnInitCallbacks'](_0x3ab96e,_0x32d95a){const _0x46cb33=this['onInitCallbacks']['get'](_0x32d95a);if(_0x46cb33){for(const _0x40ce06 of _0x46cb33)try{_0x40ce06(_0x3ab96e,_0x32d95a);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x555bce,options:_0xd1c859={}}){let _0x4013d3=this['instances']['get'](_0x555bce);if(!_0x4013d3&&this['component']&&(_0x4013d3=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':Sc(_0x555bce),'options':_0xd1c859}),this['instances']['set'](_0x555bce,_0x4013d3),this['instancesOptions']['set'](_0x555bce,_0xd1c859),this['invokeOnInitCallbacks'](_0x4013d3,_0x555bce),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x555bce,_0x4013d3);}catch{}return _0x4013d3||null;}['normalizeInstanceIdentifier'](_0x253703=ke){return this['component']?this['component']['multipleInstances']?_0x253703:ke:_0x253703;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function Sc(_0x3c2169){return _0x3c2169===ke?void 0x0:_0x3c2169;}function bc(_0x523a31){return _0x523a31['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rc{constructor(_0x5df72e){this['name']=_0x5df72e,this['providers']=new Map();}['addComponent'](_0x2b66c6){const _0x195fd8=this['getProvider'](_0x2b66c6['name']);if(_0x195fd8['isComponentSet']())throw new Error('Component\x20'+_0x2b66c6['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x195fd8['setComponent'](_0x2b66c6);}['addOrOverwriteComponent'](_0x19a1ad){this['getProvider'](_0x19a1ad['name'])['isComponentSet']()&&this['providers']['delete'](_0x19a1ad['name']),this['addComponent'](_0x19a1ad);}['getProvider'](_0xfd04ce){if(this['providers']['has'](_0xfd04ce))return this['providers']['get'](_0xfd04ce);const _0x5b4de3=new Tc(_0xfd04ce,this);return this['providers']['set'](_0xfd04ce,_0x5b4de3),_0x5b4de3;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xcb3d1e){_0xcb3d1e[_0xcb3d1e['DEBUG']=0x0]='DEBUG',_0xcb3d1e[_0xcb3d1e['VERBOSE']=0x1]='VERBOSE',_0xcb3d1e[_0xcb3d1e['INFO']=0x2]='INFO',_0xcb3d1e[_0xcb3d1e['WARN']=0x3]='WARN',_0xcb3d1e[_0xcb3d1e['ERROR']=0x4]='ERROR',_0xcb3d1e[_0xcb3d1e['SILENT']=0x5]='SILENT';}(T||(T={})));const Ac={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},kc=T['INFO'],Nc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Pc=(_0x268316,_0x2e3310,..._0x3b4837)=>{if(_0x2e3310<_0x268316['logLevel'])return;const _0x4efd85=new Date()['toISOString'](),_0x2f684d=Nc[_0x2e3310];if(_0x2f684d)console[_0x2f684d]('['+_0x4efd85+']\x20\x20'+_0x268316['name']+':',..._0x3b4837);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2e3310+')');};class Wi{constructor(_0x5b2014){this['name']=_0x5b2014,this['_logLevel']=kc,this['_logHandler']=Pc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x50a10f){if(!(_0x50a10f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x50a10f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x50a10f;}['setLogLevel'](_0x39889f){this['_logLevel']=typeof _0x39889f=='string'?Ac[_0x39889f]:_0x39889f;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x260ce1){if(typeof _0x260ce1!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x260ce1;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2dad11){this['_userLogHandler']=_0x2dad11;}['debug'](..._0x362b4f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x362b4f),this['_logHandler'](this,T['DEBUG'],..._0x362b4f);}['log'](..._0x52c055){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x52c055),this['_logHandler'](this,T['VERBOSE'],..._0x52c055);}['info'](..._0x4772fd){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4772fd),this['_logHandler'](this,T['INFO'],..._0x4772fd);}['warn'](..._0xcaa07){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0xcaa07),this['_logHandler'](this,T['WARN'],..._0xcaa07);}['error'](..._0x1dad40){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1dad40),this['_logHandler'](this,T['ERROR'],..._0x1dad40);}}const Oc=(_0x592308,_0x521032)=>_0x521032['some'](_0x41e86b=>_0x592308 instanceof _0x41e86b);let Os,Ds;function Dc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Mc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),pi=new WeakMap(),Xr=new WeakMap(),ti=new WeakMap(),Bi=new WeakMap();function Lc(_0x5839a7){const _0x267ada=new Promise((_0x5b30e9,_0x1aea5e)=>{const _0x1595cd=()=>{_0x5839a7['removeEventListener']('success',_0x390708),_0x5839a7['removeEventListener']('error',_0x3a3cff);},_0x390708=()=>{_0x5b30e9(ge(_0x5839a7['result'])),_0x1595cd();},_0x3a3cff=()=>{_0x1aea5e(_0x5839a7['error']),_0x1595cd();};_0x5839a7['addEventListener']('success',_0x390708),_0x5839a7['addEventListener']('error',_0x3a3cff);});return _0x267ada['then'](_0x12b6b5=>{_0x12b6b5 instanceof IDBCursor&&Jr['set'](_0x12b6b5,_0x5839a7);})['catch'](()=>{}),Bi['set'](_0x267ada,_0x5839a7),_0x267ada;}function xc(_0x31287f){if(pi['has'](_0x31287f))return;const _0xd8b891=new Promise((_0x9bd33e,_0x59a147)=>{const _0x414e64=()=>{_0x31287f['removeEventListener']('complete',_0x5c00cb),_0x31287f['removeEventListener']('error',_0x4db1f9),_0x31287f['removeEventListener']('abort',_0x4db1f9);},_0x5c00cb=()=>{_0x9bd33e(),_0x414e64();},_0x4db1f9=()=>{_0x59a147(_0x31287f['error']||new DOMException('AbortError','AbortError')),_0x414e64();};_0x31287f['addEventListener']('complete',_0x5c00cb),_0x31287f['addEventListener']('error',_0x4db1f9),_0x31287f['addEventListener']('abort',_0x4db1f9);});pi['set'](_0x31287f,_0xd8b891);}let _i={'get'(_0x1c028a,_0x29c3b8,_0x516d9b){if(_0x1c028a instanceof IDBTransaction){if(_0x29c3b8==='done')return pi['get'](_0x1c028a);if(_0x29c3b8==='objectStoreNames')return _0x1c028a['objectStoreNames']||Xr['get'](_0x1c028a);if(_0x29c3b8==='store')return _0x516d9b['objectStoreNames'][0x1]?void 0x0:_0x516d9b['objectStore'](_0x516d9b['objectStoreNames'][0x0]);}return ge(_0x1c028a[_0x29c3b8]);},'set'(_0x186b09,_0x9491ed,_0x343b12){return _0x186b09[_0x9491ed]=_0x343b12,!0x0;},'has'(_0x5b4a65,_0x1676d5){return _0x5b4a65 instanceof IDBTransaction&&(_0x1676d5==='done'||_0x1676d5==='store')?!0x0:_0x1676d5 in _0x5b4a65;}};function Fc(_0x13056d){_i=_0x13056d(_i);}function Uc(_0x1dc6de){return _0x1dc6de===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x3563ee,..._0x47f9e5){const _0x2e05e4=_0x1dc6de['call'](ni(this),_0x3563ee,..._0x47f9e5);return Xr['set'](_0x2e05e4,_0x3563ee['sort']?_0x3563ee['sort']():[_0x3563ee]),ge(_0x2e05e4);}:Mc()['includes'](_0x1dc6de)?function(..._0x5a3812){return _0x1dc6de['apply'](ni(this),_0x5a3812),ge(Jr['get'](this));}:function(..._0x2cb466){return ge(_0x1dc6de['apply'](ni(this),_0x2cb466));};}function Wc(_0x7f0d70){return typeof _0x7f0d70=='function'?Uc(_0x7f0d70):(_0x7f0d70 instanceof IDBTransaction&&xc(_0x7f0d70),Oc(_0x7f0d70,Dc())?new Proxy(_0x7f0d70,_i):_0x7f0d70);}function ge(_0x5b6926){if(_0x5b6926 instanceof IDBRequest)return Lc(_0x5b6926);if(ti['has'](_0x5b6926))return ti['get'](_0x5b6926);const _0x35a17b=Wc(_0x5b6926);return _0x35a17b!==_0x5b6926&&(ti['set'](_0x5b6926,_0x35a17b),Bi['set'](_0x35a17b,_0x5b6926)),_0x35a17b;}const ni=_0x4a26a0=>Bi['get'](_0x4a26a0);function Bc(_0x5048da,_0x3c6d93,{blocked:_0x9ecc67,upgrade:_0xde08a6,blocking:_0x44a51e,terminated:_0x41e76d}={}){const _0x41a8b7=indexedDB['open'](_0x5048da,_0x3c6d93),_0x392e07=ge(_0x41a8b7);return _0xde08a6&&_0x41a8b7['addEventListener']('upgradeneeded',_0xa5cade=>{_0xde08a6(ge(_0x41a8b7['result']),_0xa5cade['oldVersion'],_0xa5cade['newVersion'],ge(_0x41a8b7['transaction']),_0xa5cade);}),_0x9ecc67&&_0x41a8b7['addEventListener']('blocked',_0x15a28a=>_0x9ecc67(_0x15a28a['oldVersion'],_0x15a28a['newVersion'],_0x15a28a)),_0x392e07['then'](_0x57cb38=>{_0x41e76d&&_0x57cb38['addEventListener']('close',()=>_0x41e76d()),_0x44a51e&&_0x57cb38['addEventListener']('versionchange',_0x41a020=>_0x44a51e(_0x41a020['oldVersion'],_0x41a020['newVersion'],_0x41a020));})['catch'](()=>{}),_0x392e07;}const Vc=['get','getKey','getAll','getAllKeys','count'],Hc=['put','add','delete','clear'],ii=new Map();function Ms(_0x5b0b62,_0x168729){if(!(_0x5b0b62 instanceof IDBDatabase&&!(_0x168729 in _0x5b0b62)&&typeof _0x168729=='string'))return;if(ii['get'](_0x168729))return ii['get'](_0x168729);const _0x410ec5=_0x168729['replace'](/FromIndex$/,''),_0x2d54b7=_0x168729!==_0x410ec5,_0x49fba2=Hc['includes'](_0x410ec5);if(!(_0x410ec5 in(_0x2d54b7?IDBIndex:IDBObjectStore)['prototype'])||!(_0x49fba2||Vc['includes'](_0x410ec5)))return;const _0x4144ba=async function(_0x15755b,..._0x30c208){const _0x2010d8=this['transaction'](_0x15755b,_0x49fba2?'readwrite':'readonly');let _0x4e3e2a=_0x2010d8['store'];return _0x2d54b7&&(_0x4e3e2a=_0x4e3e2a['index'](_0x30c208['shift']())),(await Promise['all']([_0x4e3e2a[_0x410ec5](..._0x30c208),_0x49fba2&&_0x2010d8['done']]))[0x0];};return ii['set'](_0x168729,_0x4144ba),_0x4144ba;}Fc(_0x368c8a=>({..._0x368c8a,'get':(_0x24bbaa,_0x24d572,_0x47a527)=>Ms(_0x24bbaa,_0x24d572)||_0x368c8a['get'](_0x24bbaa,_0x24d572,_0x47a527),'has':(_0x558c73,_0x493140)=>!!Ms(_0x558c73,_0x493140)||_0x368c8a['has'](_0x558c73,_0x493140)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $c{constructor(_0x2c9753){this['container']=_0x2c9753;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x4d0ca3=>{if(Gc(_0x4d0ca3)){const _0x388f1d=_0x4d0ca3['getImmediate']();return _0x388f1d['library']+'/'+_0x388f1d['version'];}else return null;})['filter'](_0x4bfe6a=>_0x4bfe6a)['join']('\x20');}}function Gc(_0xafe682){const _0x421ffd=_0xafe682['getComponent']();return(_0x421ffd==null?void 0x0:_0x421ffd['type'])==='VERSION';}const gi='@firebase/app',Ls='0.15.1',oe=new Wi('@firebase/app'),qc='@firebase/app-compat',zc='@firebase/analytics-compat',jc='@firebase/analytics',Kc='@firebase/app-check-compat',Yc='@firebase/app-check',Qc='@firebase/auth',Jc='@firebase/auth-compat',Xc='@firebase/database',Zc='@firebase/data-connect',el='@firebase/database-compat',tl='@firebase/functions',nl='@firebase/functions-compat',il='@firebase/installations',sl='@firebase/installations-compat',rl='@firebase/messaging',ol='@firebase/messaging-compat',al='@firebase/performance',cl='@firebase/performance-compat',ll='@firebase/remote-config',hl='@firebase/remote-config-compat',ul='@firebase/storage',dl='@firebase/storage-compat',fl='@firebase/firestore',pl='@firebase/ai',_l='@firebase/firestore-compat',gl='firebase',ml='12.16.0',mi='[DEFAULT]',yl={[gi]:'fire-core',[qc]:'fire-core-compat',[jc]:'fire-analytics',[zc]:'fire-analytics-compat',[Yc]:'fire-app-check',[Kc]:'fire-app-check-compat',[Qc]:'fire-auth',[Jc]:'fire-auth-compat',[Xc]:'fire-rtdb',[Zc]:'fire-data-connect',[el]:'fire-rtdb-compat',[tl]:'fire-fn',[nl]:'fire-fn-compat',[il]:'fire-iid',[sl]:'fire-iid-compat',[rl]:'fire-fcm',[ol]:'fire-fcm-compat',[al]:'fire-perf',[cl]:'fire-perf-compat',[ll]:'fire-rc',[hl]:'fire-rc-compat',[ul]:'fire-gcs',[dl]:'fire-gcs-compat',[fl]:'fire-fst',[_l]:'fire-fst-compat',[pl]:'fire-vertex','fire-js':'fire-js',[gl]:'fire-js-all'},Fe=new Map(),yi=new Map(),vi=new Map();function xs(_0x2c45b9,_0x19b26e){try{_0x2c45b9['container']['addComponent'](_0x19b26e);}catch(_0x3c74fc){oe['debug']('Component\x20'+_0x19b26e['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2c45b9['name'],_0x3c74fc);}}function it(_0x206685){const _0x19d595=_0x206685['name'];if(vi['has'](_0x19d595))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x19d595+'.'),!0x1;vi['set'](_0x19d595,_0x206685);for(const _0x24fa08 of Fe['values']())xs(_0x24fa08,_0x206685);for(const _0x564886 of yi['values']())xs(_0x564886,_0x206685);return!0x0;}function Vi(_0xb2da7a,_0x560aeb){const _0x29422a=_0xb2da7a['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x29422a&&_0x29422a['triggerHeartbeat'](),_0xb2da7a['container']['getProvider'](_0x560aeb);}function $(_0x278901){return _0x278901==null?!0x1:_0x278901['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new $t('app','Firebase',vl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class El{constructor(_0x174e25,_0x562205,_0x311605){this['_isDeleted']=!0x1,this['_options']={..._0x174e25},this['_config']={..._0x562205},this['_name']=_0x562205['name'],this['_automaticDataCollectionEnabled']=_0x562205['automaticDataCollectionEnabled'],this['_container']=_0x311605,this['container']['addComponent'](new xe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x495a38){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x495a38;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x362e42){this['_isDeleted']=_0x362e42;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ut=ml;function Il(_0x3cea6d,_0x6cf712={}){let _0x3ce306=_0x3cea6d;typeof _0x6cf712!='object'&&(_0x6cf712={'name':_0x6cf712});const _0x407c2a={'name':mi,'automaticDataCollectionEnabled':!0x0,..._0x6cf712},_0x1f95c0=_0x407c2a['name'];if(typeof _0x1f95c0!='string'||!_0x1f95c0)throw me['create']('bad-app-name',{'appName':String(_0x1f95c0)});if(_0x3ce306||(_0x3ce306=zr()),!_0x3ce306)throw me['create']('no-options');const _0x32deb1=Fe['get'](_0x1f95c0);if(_0x32deb1){if(Le(_0x3ce306,_0x32deb1['options'])&&Le(_0x407c2a,_0x32deb1['config']))return _0x32deb1;throw me['create']('duplicate-app',{'appName':_0x1f95c0});}const _0x1bf813=new Rc(_0x1f95c0);for(const _0x427c5a of vi['values']())_0x1bf813['addComponent'](_0x427c5a);const _0x2dfbbc=new El(_0x3ce306,_0x407c2a,_0x1bf813);return Fe['set'](_0x1f95c0,_0x2dfbbc),_0x2dfbbc;}function Zr(_0x4aacf9=mi){const _0x5c8a26=Fe['get'](_0x4aacf9);if(!_0x5c8a26&&_0x4aacf9===mi&&zr())return Il();if(!_0x5c8a26)throw me['create']('no-app',{'appName':_0x4aacf9});return _0x5c8a26;}function f_(){return Array['from'](Fe['values']());}async function p_(_0xed355c){let _0xf81b4a=!0x1;const _0x2b79ff=_0xed355c['name'];Fe['has'](_0x2b79ff)?(_0xf81b4a=!0x0,Fe['delete'](_0x2b79ff)):yi['has'](_0x2b79ff)&&_0xed355c['decRefCount']()<=0x0&&(yi['delete'](_0x2b79ff),_0xf81b4a=!0x0),_0xf81b4a&&(await Promise['all'](_0xed355c['container']['getProviders']()['map'](_0x1cdec7=>_0x1cdec7['delete']())),_0xed355c['isDeleted']=!0x0);}function ye(_0x53e3e0,_0xe72a38,_0x17be23){let _0x7fbd39=yl[_0x53e3e0]??_0x53e3e0;_0x17be23&&(_0x7fbd39+='-'+_0x17be23);const _0x32d381=_0x7fbd39['match'](/\s|\//),_0x205225=_0xe72a38['match'](/\s|\//);if(_0x32d381||_0x205225){const _0x39568e=['Unable\x20to\x20register\x20library\x20\x22'+_0x7fbd39+'\x22\x20with\x20version\x20\x22'+_0xe72a38+'\x22:'];_0x32d381&&_0x39568e['push']('library\x20name\x20\x22'+_0x7fbd39+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x32d381&&_0x205225&&_0x39568e['push']('and'),_0x205225&&_0x39568e['push']('version\x20name\x20\x22'+_0xe72a38+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x39568e['join']('\x20'));return;}it(new xe(_0x7fbd39+'-version',()=>({'library':_0x7fbd39,'version':_0xe72a38}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wl='firebase-heartbeat-database',Cl=0x1,Pt='firebase-heartbeat-store';let si=null;function eo(){return si||(si=Bc(wl,Cl,{'upgrade':(_0x16f7f0,_0xb3d0e8)=>{switch(_0xb3d0e8){case 0x0:try{_0x16f7f0['createObjectStore'](Pt);}catch(_0x5a6729){console['warn'](_0x5a6729);}}}})['catch'](_0x6ca398=>{throw me['create']('idb-open',{'originalErrorMessage':_0x6ca398['message']});})),si;}async function Tl(_0x54e9f0){try{const _0x211e67=(await eo())['transaction'](Pt),_0xf03a99=await _0x211e67['objectStore'](Pt)['get'](to(_0x54e9f0));return await _0x211e67['done'],_0xf03a99;}catch(_0x2fa4c3){if(_0x2fa4c3 instanceof be)oe['warn'](_0x2fa4c3['message']);else{const _0x1a9ee4=me['create']('idb-get',{'originalErrorMessage':_0x2fa4c3==null?void 0x0:_0x2fa4c3['message']});oe['warn'](_0x1a9ee4['message']);}}}async function Fs(_0x3e07d3,_0x165667){try{const _0x1fd9ef=(await eo())['transaction'](Pt,'readwrite');await _0x1fd9ef['objectStore'](Pt)['put'](_0x165667,to(_0x3e07d3)),await _0x1fd9ef['done'];}catch(_0x550fdb){if(_0x550fdb instanceof be)oe['warn'](_0x550fdb['message']);else{const _0x12725b=me['create']('idb-set',{'originalErrorMessage':_0x550fdb==null?void 0x0:_0x550fdb['message']});oe['warn'](_0x12725b['message']);}}}function to(_0x25bbd2){return _0x25bbd2['name']+'!'+_0x25bbd2['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sl=0x400,bl=0x1e;class Rl{constructor(_0x357326){this['container']=_0x357326,this['_heartbeatsCache']=null;const _0x2e06d2=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new kl(_0x2e06d2),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4191a3=>(this['_heartbeatsCache']=_0x4191a3,_0x4191a3));}async['triggerHeartbeat'](){var _0x311a83,_0x3eea8e;try{const _0x47e548=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2fe612=Us();if(((_0x311a83=this['_heartbeatsCache'])==null?void 0x0:_0x311a83['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3eea8e=this['_heartbeatsCache'])==null?void 0x0:_0x3eea8e['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2fe612||this['_heartbeatsCache']['heartbeats']['some'](_0x38df26=>_0x38df26['date']===_0x2fe612))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2fe612,'agent':_0x47e548}),this['_heartbeatsCache']['heartbeats']['length']>bl){const _0x5e34e6=Nl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5e34e6,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5eebc4){oe['warn'](_0x5eebc4);}}async['getHeartbeatsHeader'](){var _0x55884b;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x55884b=this['_heartbeatsCache'])==null?void 0x0:_0x55884b['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3fd79f=Us(),{heartbeatsToSend:_0x4cd998,unsentEntries:_0x2264b3}=Al(this['_heartbeatsCache']['heartbeats']),_0x2f6bf6=un(JSON['stringify']({'version':0x2,'heartbeats':_0x4cd998}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3fd79f,_0x2264b3['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2264b3,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2f6bf6;}catch(_0x39de30){return oe['warn'](_0x39de30),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Al(_0x19ca37,_0x20eb60=Sl){const _0x9e0028=[];let _0x202b5a=_0x19ca37['slice']();for(const _0x127ebe of _0x19ca37){const _0x42f7b6=_0x9e0028['find'](_0x3e62a7=>_0x3e62a7['agent']===_0x127ebe['agent']);if(_0x42f7b6){if(_0x42f7b6['dates']['push'](_0x127ebe['date']),Ws(_0x9e0028)>_0x20eb60){_0x42f7b6['dates']['pop']();break;}}else{if(_0x9e0028['push']({'agent':_0x127ebe['agent'],'dates':[_0x127ebe['date']]}),Ws(_0x9e0028)>_0x20eb60){_0x9e0028['pop']();break;}}_0x202b5a=_0x202b5a['slice'](0x1);}return{'heartbeatsToSend':_0x9e0028,'unsentEntries':_0x202b5a};}class kl{constructor(_0x4fbb00){this['app']=_0x4fbb00,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return dc()?fc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x53ae38=await Tl(this['app']);return _0x53ae38!=null&&_0x53ae38['heartbeats']?_0x53ae38:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x361f0d){if(await this['_canUseIndexedDBPromise']){const _0x1bb02e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x361f0d['lastSentHeartbeatDate']??_0x1bb02e['lastSentHeartbeatDate'],'heartbeats':_0x361f0d['heartbeats']});}else return;}async['add'](_0x23f8df){if(await this['_canUseIndexedDBPromise']){const _0x8c146f=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x23f8df['lastSentHeartbeatDate']??_0x8c146f['lastSentHeartbeatDate'],'heartbeats':[..._0x8c146f['heartbeats'],..._0x23f8df['heartbeats']]});}else return;}}function Ws(_0x3d31b1){return un(JSON['stringify']({'version':0x2,'heartbeats':_0x3d31b1}))['length'];}function Nl(_0x4956d6){if(_0x4956d6['length']===0x0)return-0x1;let _0x30e67d=0x0,_0xc1b09e=_0x4956d6[0x0]['date'];for(let _0x5af5e9=0x1;_0x5af5e9<_0x4956d6['length'];_0x5af5e9++)_0x4956d6[_0x5af5e9]['date']<_0xc1b09e&&(_0xc1b09e=_0x4956d6[_0x5af5e9]['date'],_0x30e67d=_0x5af5e9);return _0x30e67d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pl(_0x31c198){it(new xe('platform-logger',_0xa1d55e=>new $c(_0xa1d55e),'PRIVATE')),it(new xe('heartbeat',_0x307532=>new Rl(_0x307532),'PRIVATE')),ye(gi,Ls,_0x31c198),ye(gi,Ls,'esm2020'),ye('fire-js','');}Pl('');var Ol='firebase',Dl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(Ol,Dl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ml(_0x384531){no=_0x384531;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ll{constructor(_0x253aea){this['domStorage_']=_0x253aea,this['prefix_']='firebase:';}['set'](_0x42f930,_0x2f4c04){_0x2f4c04==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x42f930)):this['domStorage_']['setItem'](this['prefixedName_'](_0x42f930),O(_0x2f4c04));}['get'](_0x264366){const _0x384c82=this['domStorage_']['getItem'](this['prefixedName_'](_0x264366));return _0x384c82==null?null:Nt(_0x384c82);}['remove'](_0x50803a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x50803a));}['prefixedName_'](_0x4acd70){return this['prefix_']+_0x4acd70;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1810b1,_0x4169fa){_0x4169fa==null?delete this['cache_'][_0x1810b1]:this['cache_'][_0x1810b1]=_0x4169fa;}['get'](_0x4c009b){return Q(this['cache_'],_0x4c009b)?this['cache_'][_0x4c009b]:null;}['remove'](_0x2f1711){delete this['cache_'][_0x2f1711];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3b690e){try{if(typeof window<'u'&&typeof window[_0x3b690e]<'u'){const _0x206406=window[_0x3b690e];return _0x206406['setItem']('firebase:sentinel','cache'),_0x206406['removeItem']('firebase:sentinel'),new Ll(_0x206406);}}catch{}return new xl();},Pe=io('localStorage'),Fl=io('sessionStorage'),Xe=new Wi('@firebase/database'),so=(function(){let _0x47de4d=0x1;return function(){return _0x47de4d++;};}()),ro=function(_0x4bbdd9){const _0x48164f=Cc(_0x4bbdd9),_0x22b700=new vc();_0x22b700['update'](_0x48164f);const _0x4cbe79=_0x22b700['digest']();return xi['encodeByteArray'](_0x4cbe79);},qt=function(..._0x3c05c6){let _0x554436='';for(let _0x176661=0x0;_0x176661<_0x3c05c6['length'];_0x176661++){const _0x146c15=_0x3c05c6[_0x176661];Array['isArray'](_0x146c15)||_0x146c15&&typeof _0x146c15=='object'&&typeof _0x146c15['length']=='number'?_0x554436+=qt['apply'](null,_0x146c15):typeof _0x146c15=='object'?_0x554436+=O(_0x146c15):_0x554436+=_0x146c15,_0x554436+='\x20';}return _0x554436;};let Tt=null,$s=!0x0;const Ul=function(_0x222292,_0xe7606d){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Xe['logLevel']=T['VERBOSE'],Tt=Xe['log']['bind'](Xe);},L=function(..._0x363e15){if($s===!0x0&&($s=!0x1,Tt===null&&Fl['get']('logging_enabled')===!0x0&&Ul()),Tt){const _0x5e1719=qt['apply'](null,_0x363e15);Tt(_0x5e1719);}},zt=function(_0x56a950){return function(..._0x37b9d3){L(_0x56a950,..._0x37b9d3);};},Ei=function(..._0x1733d1){const _0x1a6b4a='FIREBASE\x20INTERNAL\x20ERROR:\x20'+qt(..._0x1733d1);Xe['error'](_0x1a6b4a);},ae=function(..._0x3dd4c0){const _0x2a24e3='FIREBASE\x20FATAL\x20ERROR:\x20'+qt(..._0x3dd4c0);throw Xe['error'](_0x2a24e3),new Error(_0x2a24e3);},U=function(..._0x5ea0de){const _0x323629='FIREBASE\x20WARNING:\x20'+qt(..._0x5ea0de);Xe['warn'](_0x323629);},Wl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Ln=function(_0x2d7db5){return typeof _0x2d7db5=='number'&&(_0x2d7db5!==_0x2d7db5||_0x2d7db5===Number['POSITIVE_INFINITY']||_0x2d7db5===Number['NEGATIVE_INFINITY']);},Bl=function(_0x3202c1){if(document['readyState']==='complete')_0x3202c1();else{let _0x58a2b5=!0x1;const _0x239a7e=function(){if(!document['body']){setTimeout(_0x239a7e,Math['floor'](0xa));return;}_0x58a2b5||(_0x58a2b5=!0x0,_0x3202c1());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x239a7e,!0x1),window['addEventListener']('load',_0x239a7e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x239a7e();}),window['attachEvent']('onload',_0x239a7e));}},Ue='[MIN_NAME]',Ie='[MAX_NAME]',Ge=function(_0x543308,_0x169ec7){if(_0x543308===_0x169ec7)return 0x0;if(_0x543308===Ue||_0x169ec7===Ie)return-0x1;if(_0x169ec7===Ue||_0x543308===Ie)return 0x1;{const _0x50e313=Gs(_0x543308),_0x1a8821=Gs(_0x169ec7);return _0x50e313!==null?_0x1a8821!==null?_0x50e313-_0x1a8821===0x0?_0x543308['length']-_0x169ec7['length']:_0x50e313-_0x1a8821:-0x1:_0x1a8821!==null?0x1:_0x543308<_0x169ec7?-0x1:0x1;}},Vl=function(_0x268e01,_0x3240cf){return _0x268e01===_0x3240cf?0x0:_0x268e01<_0x3240cf?-0x1:0x1;},yt=function(_0xadca8,_0x30d596){if(_0x30d596&&_0xadca8 in _0x30d596)return _0x30d596[_0xadca8];throw new Error('Missing\x20required\x20key\x20('+_0xadca8+')\x20in\x20object:\x20'+O(_0x30d596));},Hi=function(_0x2aee4a){if(typeof _0x2aee4a!='object'||_0x2aee4a===null)return O(_0x2aee4a);const _0x41d937=[];for(const _0x533180 in _0x2aee4a)_0x41d937['push'](_0x533180);_0x41d937['sort']();let _0x3058a2='{';for(let _0x4b083a=0x0;_0x4b083a<_0x41d937['length'];_0x4b083a++)_0x4b083a!==0x0&&(_0x3058a2+=','),_0x3058a2+=O(_0x41d937[_0x4b083a]),_0x3058a2+=':',_0x3058a2+=Hi(_0x2aee4a[_0x41d937[_0x4b083a]]);return _0x3058a2+='}',_0x3058a2;},oo=function(_0x2b9e49,_0x46cfc2){const _0xd3b8df=_0x2b9e49['length'];if(_0xd3b8df<=_0x46cfc2)return[_0x2b9e49];const _0x30f4cc=[];for(let _0x5ef776=0x0;_0x5ef776<_0xd3b8df;_0x5ef776+=_0x46cfc2)_0x5ef776+_0x46cfc2>_0xd3b8df?_0x30f4cc['push'](_0x2b9e49['substring'](_0x5ef776,_0xd3b8df)):_0x30f4cc['push'](_0x2b9e49['substring'](_0x5ef776,_0x5ef776+_0x46cfc2));return _0x30f4cc;};function x(_0x46fcc2,_0x10b4ba){for(const _0x5e9919 in _0x46fcc2)_0x46fcc2['hasOwnProperty'](_0x5e9919)&&_0x10b4ba(_0x5e9919,_0x46fcc2[_0x5e9919]);}const ao=function(_0xefb183){f(!Ln(_0xefb183),'Invalid\x20JSON\x20number');const _0x362443=0xb,_0x17e5e9=0x34,_0x490cad=(0x1<<_0x362443-0x1)-0x1;let _0x300112,_0x3c365b,_0x3bdf7d,_0x5547d2,_0x199950;_0xefb183===0x0?(_0x3c365b=0x0,_0x3bdf7d=0x0,_0x300112=0x1/_0xefb183===-0x1/0x0?0x1:0x0):(_0x300112=_0xefb183<0x0,_0xefb183=Math['abs'](_0xefb183),_0xefb183>=Math['pow'](0x2,0x1-_0x490cad)?(_0x5547d2=Math['min'](Math['floor'](Math['log'](_0xefb183)/Math['LN2']),_0x490cad),_0x3c365b=_0x5547d2+_0x490cad,_0x3bdf7d=Math['round'](_0xefb183*Math['pow'](0x2,_0x17e5e9-_0x5547d2)-Math['pow'](0x2,_0x17e5e9))):(_0x3c365b=0x0,_0x3bdf7d=Math['round'](_0xefb183/Math['pow'](0x2,0x1-_0x490cad-_0x17e5e9))));const _0x40ef41=[];for(_0x199950=_0x17e5e9;_0x199950;_0x199950-=0x1)_0x40ef41['push'](_0x3bdf7d%0x2?0x1:0x0),_0x3bdf7d=Math['floor'](_0x3bdf7d/0x2);for(_0x199950=_0x362443;_0x199950;_0x199950-=0x1)_0x40ef41['push'](_0x3c365b%0x2?0x1:0x0),_0x3c365b=Math['floor'](_0x3c365b/0x2);_0x40ef41['push'](_0x300112?0x1:0x0),_0x40ef41['reverse']();const _0x1d13e7=_0x40ef41['join']('');let _0x49e4e7='';for(_0x199950=0x0;_0x199950<0x40;_0x199950+=0x8){let _0x575d79=parseInt(_0x1d13e7['substr'](_0x199950,0x8),0x2)['toString'](0x10);_0x575d79['length']===0x1&&(_0x575d79='0'+_0x575d79),_0x49e4e7=_0x49e4e7+_0x575d79;}return _0x49e4e7['toLowerCase']();},Hl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},$l=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Gl(_0x1e7baa,_0x21f347){let _0x2295e9='Unknown\x20Error';_0x1e7baa==='too_big'?_0x2295e9='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1e7baa==='permission_denied'?_0x2295e9='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1e7baa==='unavailable'&&(_0x2295e9='The\x20service\x20is\x20unavailable');const _0x23bca6=new Error(_0x1e7baa+'\x20at\x20'+_0x21f347['_path']['toString']()+':\x20'+_0x2295e9);return _0x23bca6['code']=_0x1e7baa['toUpperCase'](),_0x23bca6;}const ql=new RegExp('^-?(0*)\x5cd{1,10}$'),zl=-0x80000000,jl=0x7fffffff,Gs=function(_0x435779){if(ql['test'](_0x435779)){const _0x2fc88b=Number(_0x435779);if(_0x2fc88b>=zl&&_0x2fc88b<=jl)return _0x2fc88b;}return null;},dt=function(_0x2fd4d4){try{_0x2fd4d4();}catch(_0x1e998c){setTimeout(()=>{const _0x39c79a=_0x1e998c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x39c79a),_0x1e998c;},Math['floor'](0x0));}},Kl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},St=function(_0x2effd2,_0x51206f){const _0x519340=setTimeout(_0x2effd2,_0x51206f);return typeof _0x519340=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x519340):typeof _0x519340=='object'&&_0x519340['unref']&&_0x519340['unref'](),_0x519340;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yl{constructor(_0x543b37,_0x51f9b3){this['appCheckProvider']=_0x51f9b3,this['appName']=_0x543b37['name'],$(_0x543b37)&&_0x543b37['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x543b37['settings']['appCheckToken']),this['appCheck']=_0x51f9b3==null?void 0x0:_0x51f9b3['getImmediate']({'optional':!0x0}),this['appCheck']||_0x51f9b3==null||_0x51f9b3['get']()['then'](_0x1e4419=>this['appCheck']=_0x1e4419);}['getToken'](_0x473aa1){if(this['serverAppAppCheckToken']){if(_0x473aa1)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x473aa1):new Promise((_0x3404aa,_0x1a0a9b)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x473aa1)['then'](_0x3404aa,_0x1a0a9b):_0x3404aa(null);},0x0);});}['addTokenChangeListener'](_0x24a01d){var _0x49d1fc;(_0x49d1fc=this['appCheckProvider'])==null||_0x49d1fc['get']()['then'](_0x255ca3=>_0x255ca3['addTokenListener'](_0x24a01d));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x508427,_0x2fbbb5,_0x41b78a){this['appName_']=_0x508427,this['firebaseOptions_']=_0x2fbbb5,this['authProvider_']=_0x41b78a,this['auth_']=null,this['auth_']=_0x41b78a['getImmediate']({'optional':!0x0}),this['auth_']||_0x41b78a['onInit'](_0x2f33b2=>this['auth_']=_0x2f33b2);}['getToken'](_0x4cb4e4){return this['auth_']?this['auth_']['getToken'](_0x4cb4e4)['catch'](_0x297113=>_0x297113&&_0x297113['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x297113)):new Promise((_0x37255d,_0x184640)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4cb4e4)['then'](_0x37255d,_0x184640):_0x37255d(null);},0x0);});}['addTokenChangeListener'](_0x512c85){this['auth_']?this['auth_']['addAuthTokenListener'](_0x512c85):this['authProvider_']['get']()['then'](_0xbb3b0c=>_0xbb3b0c['addAuthTokenListener'](_0x512c85));}['removeTokenChangeListener'](_0x77be61){this['authProvider_']['get']()['then'](_0x22c391=>_0x22c391['removeAuthTokenListener'](_0x77be61));}['notifyForInvalidToken'](){let _0x353094='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x353094+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x353094+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x353094+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x353094);}}class on{constructor(_0x1df554){this['accessToken']=_0x1df554;}['getToken'](_0x18d0e2){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x382ac2){_0x382ac2(this['accessToken']);}['removeTokenChangeListener'](_0x2eb0ec){}['notifyForInvalidToken'](){}}on['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',Ii='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x5dd476,_0x368d16,_0x2d9dad,_0xbcc195,_0x1f438b=!0x1,_0x195f61='',_0x5c4dec=!0x1,_0x2b75df=!0x1,_0x342dd7=null){this['secure']=_0x368d16,this['namespace']=_0x2d9dad,this['webSocketOnly']=_0xbcc195,this['nodeAdmin']=_0x1f438b,this['persistenceKey']=_0x195f61,this['includeNamespaceInQueryParams']=_0x5c4dec,this['isUsingEmulator']=_0x2b75df,this['emulatorOptions']=_0x342dd7,this['_host']=_0x5dd476['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x5dd476)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1f51d1){_0x1f51d1!==this['internalHost']&&(this['internalHost']=_0x1f51d1,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x2daa2f=this['toURLString']();return this['persistenceKey']&&(_0x2daa2f+='<'+this['persistenceKey']+'>'),_0x2daa2f;}['toURLString'](){const _0x51024d=this['secure']?'https://':'http://',_0x59a594=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x51024d+this['host']+'/'+_0x59a594;}}function Jl(_0x5a5487){return _0x5a5487['host']!==_0x5a5487['internalHost']||_0x5a5487['isCustomHost']()||_0x5a5487['includeNamespaceInQueryParams'];}function vo(_0xfcabed,_0x3614ac,_0x49b6b2){f(typeof _0x3614ac=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x49b6b2=='object','typeof\x20params\x20must\x20==\x20object');let _0x51d14c;if(_0x3614ac===go)_0x51d14c=(_0xfcabed['secure']?'wss://':'ws://')+_0xfcabed['internalHost']+'/.ws?';else{if(_0x3614ac===mo)_0x51d14c=(_0xfcabed['secure']?'https://':'http://')+_0xfcabed['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3614ac);}Jl(_0xfcabed)&&(_0x49b6b2['ns']=_0xfcabed['namespace']);const _0x2f9730=[];return x(_0x49b6b2,(_0x30eccc,_0xef97f2)=>{_0x2f9730['push'](_0x30eccc+'='+_0xef97f2);}),_0x51d14c+_0x2f9730['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xl{constructor(){this['counters_']={};}['incrementCounter'](_0x452d55,_0x4d3881=0x1){Q(this['counters_'],_0x452d55)||(this['counters_'][_0x452d55]=0x0),this['counters_'][_0x452d55]+=_0x4d3881;}['get'](){return ec(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ri={},oi={};function Gi(_0x18c28f){const _0xfbce8d=_0x18c28f['toString']();return ri[_0xfbce8d]||(ri[_0xfbce8d]=new Xl()),ri[_0xfbce8d];}function Zl(_0x2bdb00,_0x498f89){const _0x559ddf=_0x2bdb00['toString']();return oi[_0x559ddf]||(oi[_0x559ddf]=_0x498f89()),oi[_0x559ddf];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x23ec4d){this['onMessage_']=_0x23ec4d,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xddc9af,_0x5b44ef){this['closeAfterResponse']=_0xddc9af,this['onClose']=_0x5b44ef,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x3dc686,_0x58414c){for(this['pendingResponses'][_0x3dc686]=_0x58414c;this['pendingResponses'][this['currentResponseNum']];){const _0x50af10=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x2e39f2=0x0;_0x2e39f2<_0x50af10['length'];++_0x2e39f2)_0x50af10[_0x2e39f2]&&dt(()=>{this['onMessage_'](_0x50af10[_0x2e39f2]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',th='close',nh='pLPCommand',ih='pRTLPCB',Eo='id',Io='pw',wo='ser',sh='cb',rh='seg',oh='ts',ah='d',ch='dframe',Co=0x74e,To=0x1e,lh=Co-To,hh=0x61a8,uh=0x7530;class Qe{constructor(_0x3c6e35,_0x59f4c8,_0x560819,_0x6b6ae0,_0x2092f8,_0x5c29ae,_0x2ebc40){this['connId']=_0x3c6e35,this['repoInfo']=_0x59f4c8,this['applicationId']=_0x560819,this['appCheckToken']=_0x6b6ae0,this['authToken']=_0x2092f8,this['transportSessionId']=_0x5c29ae,this['lastSessionId']=_0x2ebc40,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=zt(_0x3c6e35),this['stats_']=Gi(_0x59f4c8),this['urlFn']=_0x3359e9=>(this['appCheckToken']&&(_0x3359e9[Ii]=this['appCheckToken']),vo(_0x59f4c8,mo,_0x3359e9));}['open'](_0x4a514b,_0x37eff2){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x37eff2,this['myPacketOrderer']=new eh(_0x4a514b),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](uh)),Bl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x174bde)=>{const [_0x4f31ed,_0x271b52,_0x27b3f0,_0x42781,_0x17f112]=_0x174bde;if(this['incrementIncomingBytes_'](_0x174bde),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4f31ed===qs)this['id']=_0x271b52,this['password']=_0x27b3f0;else{if(_0x4f31ed===th)_0x271b52?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x271b52,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4f31ed);}}},(..._0x539c3c)=>{const [_0x475492,_0xc92049]=_0x539c3c;this['incrementIncomingBytes_'](_0x539c3c),this['myPacketOrderer']['handleResponse'](_0x475492,_0xc92049);},()=>{this['onClosed_']();},this['urlFn']);const _0x458a9c={};_0x458a9c[qs]='t',_0x458a9c[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x458a9c[sh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x458a9c[co]=$i,this['transportSessionId']&&(_0x458a9c[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x458a9c[po]=this['lastSessionId']),this['applicationId']&&(_0x458a9c[_o]=this['applicationId']),this['appCheckToken']&&(_0x458a9c[Ii]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x458a9c[ho]=uo);const _0x52e6e4=this['urlFn'](_0x458a9c);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x52e6e4),this['scriptTagHolder']['addTag'](_0x52e6e4,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Qe['forceAllow_']=!0x0;}static['forceDisallow'](){Qe['forceDisallow_']=!0x0;}static['isAvailable'](){return Qe['forceAllow_']?!0x0:!Qe['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!Hl()&&!$l();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1913e5){const _0x1aca62=O(_0x1913e5);this['bytesSent']+=_0x1aca62['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1aca62['length']);const _0x38bb56=$r(_0x1aca62),_0x3007cc=oo(_0x38bb56,lh);for(let _0x249c51=0x0;_0x249c51<_0x3007cc['length'];_0x249c51++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3007cc['length'],_0x3007cc[_0x249c51]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x410fd7,_0x4877e0){this['myDisconnFrame']=document['createElement']('iframe');const _0x315b86={};_0x315b86[ch]='t',_0x315b86[Eo]=_0x410fd7,_0x315b86[Io]=_0x4877e0,this['myDisconnFrame']['src']=this['urlFn'](_0x315b86),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x4c0fce){const _0xe3121f=O(_0x4c0fce)['length'];this['bytesReceived']+=_0xe3121f,this['stats_']['incrementCounter']('bytes_received',_0xe3121f);}}class qi{constructor(_0x364dcb,_0x31d83b,_0xc244a3,_0x1f096c){this['onDisconnect']=_0xc244a3,this['urlFn']=_0x1f096c,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[nh+this['uniqueCallbackIdentifier']]=_0x364dcb,window[ih+this['uniqueCallbackIdentifier']]=_0x31d83b,this['myIFrame']=qi['createIFrame_']();let _0x44aa1f='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x44aa1f='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4b3f34='<html><body>'+_0x44aa1f+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4b3f34),this['myIFrame']['doc']['close']();}catch(_0x3dcc45){L('frame\x20writing\x20exception'),_0x3dcc45['stack']&&L(_0x3dcc45['stack']),L(_0x3dcc45);}}}static['createIFrame_'](){const _0x1ff166=document['createElement']('iframe');if(_0x1ff166['style']['display']='none',document['body']){document['body']['appendChild'](_0x1ff166);try{_0x1ff166['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x38e72a=document['domain'];_0x1ff166['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x38e72a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1ff166['contentDocument']?_0x1ff166['doc']=_0x1ff166['contentDocument']:_0x1ff166['contentWindow']?_0x1ff166['doc']=_0x1ff166['contentWindow']['document']:_0x1ff166['document']&&(_0x1ff166['doc']=_0x1ff166['document']),_0x1ff166;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3fd9a6=this['onDisconnect'];_0x3fd9a6&&(this['onDisconnect']=null,_0x3fd9a6());}['startLongPoll'](_0x4df80d,_0x2b7db6){for(this['myID']=_0x4df80d,this['myPW']=_0x2b7db6,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x25f253={};_0x25f253[Eo]=this['myID'],_0x25f253[Io]=this['myPW'],_0x25f253[wo]=this['currentSerial'];let _0x575706=this['urlFn'](_0x25f253),_0x20a260='',_0x5e8231=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x20a260['length']<=Co;){const _0x246fe4=this['pendingSegs']['shift']();_0x20a260=_0x20a260+'&'+rh+_0x5e8231+'='+_0x246fe4['seg']+'&'+oh+_0x5e8231+'='+_0x246fe4['ts']+'&'+ah+_0x5e8231+'='+_0x246fe4['d'],_0x5e8231++;}return _0x575706=_0x575706+_0x20a260,this['addLongPollTag_'](_0x575706,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x130c2b,_0x97ce0c,_0x183e8f){this['pendingSegs']['push']({'seg':_0x130c2b,'ts':_0x97ce0c,'d':_0x183e8f}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x7424f8,_0x1fe096){this['outstandingRequests']['add'](_0x1fe096);const _0x47960c=()=>{this['outstandingRequests']['delete'](_0x1fe096),this['newRequest_']();},_0x197206=setTimeout(_0x47960c,Math['floor'](hh)),_0x41000f=()=>{clearTimeout(_0x197206),_0x47960c();};this['addTag'](_0x7424f8,_0x41000f);}['addTag'](_0x3bd206,_0x26344b){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x44c2a7=this['myIFrame']['doc']['createElement']('script');_0x44c2a7['type']='text/javascript',_0x44c2a7['async']=!0x0,_0x44c2a7['src']=_0x3bd206,_0x44c2a7['onload']=_0x44c2a7['onreadystatechange']=function(){const _0x40fbe6=_0x44c2a7['readyState'];(!_0x40fbe6||_0x40fbe6==='loaded'||_0x40fbe6==='complete')&&(_0x44c2a7['onload']=_0x44c2a7['onreadystatechange']=null,_0x44c2a7['parentNode']&&_0x44c2a7['parentNode']['removeChild'](_0x44c2a7),_0x26344b());},_0x44c2a7['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3bd206),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x44c2a7);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dh=0x4000,fh=0xafc8;let _n=null;typeof MozWebSocket<'u'?_n=MozWebSocket:typeof WebSocket<'u'&&(_n=WebSocket);class q{constructor(_0x339c90,_0x260301,_0x100f8f,_0x504a88,_0x5076cb,_0x3c12d6,_0x3b55fa){this['connId']=_0x339c90,this['applicationId']=_0x100f8f,this['appCheckToken']=_0x504a88,this['authToken']=_0x5076cb,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=zt(this['connId']),this['stats_']=Gi(_0x260301),this['connURL']=q['connectionURL_'](_0x260301,_0x3c12d6,_0x3b55fa,_0x504a88,_0x100f8f),this['nodeAdmin']=_0x260301['nodeAdmin'];}static['connectionURL_'](_0x463639,_0x277f2b,_0x3a3a70,_0x2050ec,_0x121b1b){const _0x576634={};return _0x576634[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x576634[ho]=uo),_0x277f2b&&(_0x576634[lo]=_0x277f2b),_0x3a3a70&&(_0x576634[po]=_0x3a3a70),_0x2050ec&&(_0x576634[Ii]=_0x2050ec),_0x121b1b&&(_0x576634[_o]=_0x121b1b),vo(_0x463639,go,_0x576634);}['open'](_0x549144,_0x2ea89e){this['onDisconnect']=_0x2ea89e,this['onMessage']=_0x549144,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x297060;uc(),this['mySock']=new _n(this['connURL'],[],_0x297060);}catch(_0x363ee6){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x2bbfe8=_0x363ee6['message']||_0x363ee6['data'];_0x2bbfe8&&this['log_'](_0x2bbfe8),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x462abb=>{this['handleIncomingFrame'](_0x462abb);},this['mySock']['onerror']=_0x2dae9c=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2615d9=_0x2dae9c['message']||_0x2dae9c['data'];_0x2615d9&&this['log_'](_0x2615d9),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x14918b=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xf181fc=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4454e6=navigator['userAgent']['match'](_0xf181fc);_0x4454e6&&_0x4454e6['length']>0x1&&parseFloat(_0x4454e6[0x1])<4.4&&(_0x14918b=!0x0);}return!_0x14918b&&_n!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x3cf3d7){if(this['frames']['push'](_0x3cf3d7),this['frames']['length']===this['totalFrames']){const _0x2607a2=this['frames']['join']('');this['frames']=null;const _0x5c2157=Nt(_0x2607a2);this['onMessage'](_0x5c2157);}}['handleNewFrameCount_'](_0xd620c2){this['totalFrames']=_0xd620c2,this['frames']=[];}['extractFrameCount_'](_0x2d2d99){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2d2d99['length']<=0x6){const _0x1a8952=Number(_0x2d2d99);if(!isNaN(_0x1a8952))return this['handleNewFrameCount_'](_0x1a8952),null;}return this['handleNewFrameCount_'](0x1),_0x2d2d99;}['handleIncomingFrame'](_0x494d08){if(this['mySock']===null)return;const _0x1e04fb=_0x494d08['data'];if(this['bytesReceived']+=_0x1e04fb['length'],this['stats_']['incrementCounter']('bytes_received',_0x1e04fb['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1e04fb);else{const _0x5e4e0b=this['extractFrameCount_'](_0x1e04fb);_0x5e4e0b!==null&&this['appendFrame_'](_0x5e4e0b);}}['send'](_0x5a48eb){this['resetKeepAlive']();const _0xc95a52=O(_0x5a48eb);this['bytesSent']+=_0xc95a52['length'],this['stats_']['incrementCounter']('bytes_sent',_0xc95a52['length']);const _0x263ffe=oo(_0xc95a52,dh);_0x263ffe['length']>0x1&&this['sendString_'](String(_0x263ffe['length']));for(let _0x18ee02=0x0;_0x18ee02<_0x263ffe['length'];_0x18ee02++)this['sendString_'](_0x263ffe[_0x18ee02]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](fh));}['sendString_'](_0x4d19e8){try{this['mySock']['send'](_0x4d19e8);}catch(_0x47c046){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x47c046['message']||_0x47c046['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{static get['ALL_TRANSPORTS'](){return[Qe,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x32de44){this['initTransports_'](_0x32de44);}['initTransports_'](_0xf50f0a){const _0x555bd0=q&&q['isAvailable']();let _0x214c0b=_0x555bd0&&!q['previouslyFailed']();if(_0xf50f0a['webSocketOnly']&&(_0x555bd0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x214c0b=!0x0),_0x214c0b)this['transports_']=[q];else{const _0x47427b=this['transports_']=[];for(const _0x440f11 of Ot['ALL_TRANSPORTS'])_0x440f11&&_0x440f11['isAvailable']()&&_0x47427b['push'](_0x440f11);Ot['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Ot['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ph=0xea60,_h=0x1388,gh=0xa*0x400,mh=0x64*0x400,ai='t',zs='d',yh='s',js='r',vh='e',Ks='o',Ys='a',Qs='n',Js='p',Eh='h';class Ih{constructor(_0x328c96,_0x47117c,_0x4bff60,_0x153bb9,_0x3f73ec,_0x433cc0,_0x297d3b,_0x24264e,_0x522a56,_0x284dbd){this['id']=_0x328c96,this['repoInfo_']=_0x47117c,this['applicationId_']=_0x4bff60,this['appCheckToken_']=_0x153bb9,this['authToken_']=_0x3f73ec,this['onMessage_']=_0x433cc0,this['onReady_']=_0x297d3b,this['onDisconnect_']=_0x24264e,this['onKill_']=_0x522a56,this['lastSessionId']=_0x284dbd,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=zt('c:'+this['id']+':'),this['transportManager_']=new Ot(_0x47117c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3e4a72=this['transportManager_']['initialTransport']();this['conn_']=new _0x3e4a72(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3e4a72['responsesRequiredToBeHealthy']||0x0;const _0x2bf9de=this['connReceiver_'](this['conn_']),_0xe9512f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2bf9de,_0xe9512f);},Math['floor'](0x0));const _0x433bd6=_0x3e4a72['healthyTimeout']||0x0;_0x433bd6>0x0&&(this['healthyTimeout_']=St(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>mh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>gh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x433bd6)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xdffe97){return _0x536278=>{_0xdffe97===this['conn_']?this['onConnectionLost_'](_0x536278):_0xdffe97===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xae15b1){return _0x5b0e3e=>{this['state_']!==0x2&&(_0xae15b1===this['rx_']?this['onPrimaryMessageReceived_'](_0x5b0e3e):_0xae15b1===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5b0e3e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4bd9f6){const _0x363019={'t':'d','d':_0x4bd9f6};this['sendData_'](_0x363019);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x41b07b){if(ai in _0x41b07b){const _0x3617ca=_0x41b07b[ai];_0x3617ca===Ys?this['upgradeIfSecondaryHealthy_']():_0x3617ca===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x3617ca===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x434ea3){const _0x1c9c2f=yt('t',_0x434ea3),_0x4803c4=yt('d',_0x434ea3);if(_0x1c9c2f==='c')this['onSecondaryControl_'](_0x4803c4);else{if(_0x1c9c2f==='d')this['pendingDataMessages']['push'](_0x4803c4);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1c9c2f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xf5fde7){const _0x18b14e=yt('t',_0xf5fde7),_0x3edd45=yt('d',_0xf5fde7);_0x18b14e==='c'?this['onControl_'](_0x3edd45):_0x18b14e==='d'&&this['onDataMessage_'](_0x3edd45);}['onDataMessage_'](_0x5de146){this['onPrimaryResponse_'](),this['onMessage_'](_0x5de146);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4952ee){const _0x59d35b=yt(ai,_0x4952ee);if(zs in _0x4952ee){const _0x465d4a=_0x4952ee[zs];if(_0x59d35b===Eh){const _0x16f3a1={..._0x465d4a};this['repoInfo_']['isUsingEmulator']&&(_0x16f3a1['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x16f3a1);}else{if(_0x59d35b===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x40b6a3=0x0;_0x40b6a3<this['pendingDataMessages']['length'];++_0x40b6a3)this['onDataMessage_'](this['pendingDataMessages'][_0x40b6a3]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x59d35b===yh?this['onConnectionShutdown_'](_0x465d4a):_0x59d35b===js?this['onReset_'](_0x465d4a):_0x59d35b===vh?Ei('Server\x20Error:\x20'+_0x465d4a):_0x59d35b===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ei('Unknown\x20control\x20packet\x20command:\x20'+_0x59d35b);}}}['onHandshake_'](_0x20d12e){const _0x3e0ece=_0x20d12e['ts'],_0x2c424a=_0x20d12e['v'],_0x3249dc=_0x20d12e['h'];this['sessionId']=_0x20d12e['s'],this['repoInfo_']['host']=_0x3249dc,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3e0ece),$i!==_0x2c424a&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5c7fa3=this['transportManager_']['upgradeTransport']();_0x5c7fa3&&this['startUpgrade_'](_0x5c7fa3);}['startUpgrade_'](_0x2ff4b9){this['secondaryConn_']=new _0x2ff4b9(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x2ff4b9['responsesRequiredToBeHealthy']||0x0;const _0x4279cc=this['connReceiver_'](this['secondaryConn_']),_0x87f88f=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x4279cc,_0x87f88f),St(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](ph));}['onReset_'](_0x26a860){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x26a860),this['repoInfo_']['host']=_0x26a860,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1f4458,_0x2e630c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1f4458,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2e630c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):St(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](_h));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x293090=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x293090||this['rx_']===_0x293090)&&this['close']();}['onConnectionLost_'](_0x1e29c4){this['conn_']=null,!_0x1e29c4&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3c98f0){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3c98f0),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x524639){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x524639);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x5bf25e,_0xaac199,_0x4d235f,_0x2688cb){}['merge'](_0xdb4207,_0x1a1209,_0x50b882,_0x446f9d){}['refreshAuthToken'](_0x1b5bd3){}['refreshAppCheckToken'](_0x4e2902){}['onDisconnectPut'](_0x4b05c6,_0x58fc07,_0x1d05f9){}['onDisconnectMerge'](_0x385b79,_0x6b6fc5,_0x1f99ff){}['onDisconnectCancel'](_0xf40316,_0x2ae451){}['reportStats'](_0x34471f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1c5260){this['allowedEvents_']=_0x1c5260,this['listeners_']={},f(Array['isArray'](_0x1c5260)&&_0x1c5260['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xc1cb61,..._0x15f707){if(Array['isArray'](this['listeners_'][_0xc1cb61])){const _0x524845=[...this['listeners_'][_0xc1cb61]];for(let _0x2d0d40=0x0;_0x2d0d40<_0x524845['length'];_0x2d0d40++)_0x524845[_0x2d0d40]['callback']['apply'](_0x524845[_0x2d0d40]['context'],_0x15f707);}}['on'](_0x4a91c8,_0x174b50,_0x295d47){this['validateEventType_'](_0x4a91c8),this['listeners_'][_0x4a91c8]=this['listeners_'][_0x4a91c8]||[],this['listeners_'][_0x4a91c8]['push']({'callback':_0x174b50,'context':_0x295d47});const _0x40478c=this['getInitialEvent'](_0x4a91c8);_0x40478c&&_0x174b50['apply'](_0x295d47,_0x40478c);}['off'](_0x59c7cf,_0x3fc1d3,_0x41cf0a){this['validateEventType_'](_0x59c7cf);const _0x6f381f=this['listeners_'][_0x59c7cf]||[];for(let _0x1d3cc7=0x0;_0x1d3cc7<_0x6f381f['length'];_0x1d3cc7++)if(_0x6f381f[_0x1d3cc7]['callback']===_0x3fc1d3&&(!_0x41cf0a||_0x41cf0a===_0x6f381f[_0x1d3cc7]['context'])){_0x6f381f['splice'](_0x1d3cc7,0x1);return;}}['validateEventType_'](_0x4d1843){f(this['allowedEvents_']['find'](_0x53c2a9=>_0x53c2a9===_0x4d1843),'Unknown\x20event:\x20'+_0x4d1843);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn extends bo{static['getInstance'](){return new gn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Ui()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x18b3e0){return f(_0x18b3e0==='online','Unknown\x20event\x20type:\x20'+_0x18b3e0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x24cf1a,_0x5bd394){if(_0x5bd394===void 0x0){this['pieces_']=_0x24cf1a['split']('/');let _0x395552=0x0;for(let _0x191c77=0x0;_0x191c77<this['pieces_']['length'];_0x191c77++)this['pieces_'][_0x191c77]['length']>0x0&&(this['pieces_'][_0x395552]=this['pieces_'][_0x191c77],_0x395552++);this['pieces_']['length']=_0x395552,this['pieceNum_']=0x0;}else this['pieces_']=_0x24cf1a,this['pieceNum_']=_0x5bd394;}['toString'](){let _0x2a2faf='';for(let _0x7241b=this['pieceNum_'];_0x7241b<this['pieces_']['length'];_0x7241b++)this['pieces_'][_0x7241b]!==''&&(_0x2a2faf+='/'+this['pieces_'][_0x7241b]);return _0x2a2faf||'/';}}function w(){return new C('');}function y(_0x25a2e1){return _0x25a2e1['pieceNum_']>=_0x25a2e1['pieces_']['length']?null:_0x25a2e1['pieces_'][_0x25a2e1['pieceNum_']];}function we(_0x356d41){return _0x356d41['pieces_']['length']-_0x356d41['pieceNum_'];}function S(_0x114bc8){let _0x3cd8a5=_0x114bc8['pieceNum_'];return _0x3cd8a5<_0x114bc8['pieces_']['length']&&_0x3cd8a5++,new C(_0x114bc8['pieces_'],_0x3cd8a5);}function zi(_0xbfba6c){return _0xbfba6c['pieceNum_']<_0xbfba6c['pieces_']['length']?_0xbfba6c['pieces_'][_0xbfba6c['pieces_']['length']-0x1]:null;}function wh(_0x5a7777){let _0x1eacc3='';for(let _0x3492d3=_0x5a7777['pieceNum_'];_0x3492d3<_0x5a7777['pieces_']['length'];_0x3492d3++)_0x5a7777['pieces_'][_0x3492d3]!==''&&(_0x1eacc3+='/'+encodeURIComponent(String(_0x5a7777['pieces_'][_0x3492d3])));return _0x1eacc3||'/';}function Dt(_0x4e0def,_0x412851=0x0){return _0x4e0def['pieces_']['slice'](_0x4e0def['pieceNum_']+_0x412851);}function Ro(_0x569642){if(_0x569642['pieceNum_']>=_0x569642['pieces_']['length'])return null;const _0x1db995=[];for(let _0x44639a=_0x569642['pieceNum_'];_0x44639a<_0x569642['pieces_']['length']-0x1;_0x44639a++)_0x1db995['push'](_0x569642['pieces_'][_0x44639a]);return new C(_0x1db995,0x0);}function k(_0x49ac09,_0x11f9f9){const _0x542fb7=[];for(let _0xfc6d57=_0x49ac09['pieceNum_'];_0xfc6d57<_0x49ac09['pieces_']['length'];_0xfc6d57++)_0x542fb7['push'](_0x49ac09['pieces_'][_0xfc6d57]);if(_0x11f9f9 instanceof C){for(let _0x1639f7=_0x11f9f9['pieceNum_'];_0x1639f7<_0x11f9f9['pieces_']['length'];_0x1639f7++)_0x542fb7['push'](_0x11f9f9['pieces_'][_0x1639f7]);}else{const _0x18d34c=_0x11f9f9['split']('/');for(let _0x4c617f=0x0;_0x4c617f<_0x18d34c['length'];_0x4c617f++)_0x18d34c[_0x4c617f]['length']>0x0&&_0x542fb7['push'](_0x18d34c[_0x4c617f]);}return new C(_0x542fb7,0x0);}function v(_0x53b469){return _0x53b469['pieceNum_']>=_0x53b469['pieces_']['length'];}function F(_0x41c842,_0x2820e2){const _0x5ad700=y(_0x41c842),_0x35e1d0=y(_0x2820e2);if(_0x5ad700===null)return _0x2820e2;if(_0x5ad700===_0x35e1d0)return F(S(_0x41c842),S(_0x2820e2));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x2820e2+')\x20is\x20not\x20within\x20outerPath\x20('+_0x41c842+')');}function Ch(_0x2bd74a,_0x6a78e8){const _0x427602=Dt(_0x2bd74a,0x0),_0xd5f7a2=Dt(_0x6a78e8,0x0);for(let _0x4ac3c4=0x0;_0x4ac3c4<_0x427602['length']&&_0x4ac3c4<_0xd5f7a2['length'];_0x4ac3c4++){const _0x52f225=Ge(_0x427602[_0x4ac3c4],_0xd5f7a2[_0x4ac3c4]);if(_0x52f225!==0x0)return _0x52f225;}return _0x427602['length']===_0xd5f7a2['length']?0x0:_0x427602['length']<_0xd5f7a2['length']?-0x1:0x1;}function ji(_0x537bbc,_0x558b4b){if(we(_0x537bbc)!==we(_0x558b4b))return!0x1;for(let _0x3dd816=_0x537bbc['pieceNum_'],_0x2bd035=_0x558b4b['pieceNum_'];_0x3dd816<=_0x537bbc['pieces_']['length'];_0x3dd816++,_0x2bd035++)if(_0x537bbc['pieces_'][_0x3dd816]!==_0x558b4b['pieces_'][_0x2bd035])return!0x1;return!0x0;}function G(_0x3e8086,_0x5c448b){let _0x4980f1=_0x3e8086['pieceNum_'],_0xe63dab=_0x5c448b['pieceNum_'];if(we(_0x3e8086)>we(_0x5c448b))return!0x1;for(;_0x4980f1<_0x3e8086['pieces_']['length'];){if(_0x3e8086['pieces_'][_0x4980f1]!==_0x5c448b['pieces_'][_0xe63dab])return!0x1;++_0x4980f1,++_0xe63dab;}return!0x0;}class Th{constructor(_0x30df1d,_0x1ded34){this['errorPrefix_']=_0x1ded34,this['parts_']=Dt(_0x30df1d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x13999d=0x0;_0x13999d<this['parts_']['length'];_0x13999d++)this['byteLength_']+=Mn(this['parts_'][_0x13999d]);Ao(this);}}function Sh(_0x31ff3e,_0x5716d8){_0x31ff3e['parts_']['length']>0x0&&(_0x31ff3e['byteLength_']+=0x1),_0x31ff3e['parts_']['push'](_0x5716d8),_0x31ff3e['byteLength_']+=Mn(_0x5716d8),Ao(_0x31ff3e);}function bh(_0x3c6638){const _0x45efda=_0x3c6638['parts_']['pop']();_0x3c6638['byteLength_']-=Mn(_0x45efda),_0x3c6638['parts_']['length']>0x0&&(_0x3c6638['byteLength_']-=0x1);}function Ao(_0x1aef84){if(_0x1aef84['byteLength_']>Zs)throw new Error(_0x1aef84['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x1aef84['byteLength_']+').');if(_0x1aef84['parts_']['length']>Xs)throw new Error(_0x1aef84['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x1aef84));}function Ne(_0x29732a){return _0x29732a['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x29732a['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x40f6c4,_0xbbb571;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xbbb571='visibilitychange',_0x40f6c4='hidden'):typeof document['mozHidden']<'u'?(_0xbbb571='mozvisibilitychange',_0x40f6c4='mozHidden'):typeof document['msHidden']<'u'?(_0xbbb571='msvisibilitychange',_0x40f6c4='msHidden'):typeof document['webkitHidden']<'u'&&(_0xbbb571='webkitvisibilitychange',_0x40f6c4='webkitHidden')),this['visible_']=!0x0,_0xbbb571&&document['addEventListener'](_0xbbb571,()=>{const _0x37d9a4=!document[_0x40f6c4];_0x37d9a4!==this['visible_']&&(this['visible_']=_0x37d9a4,this['trigger']('visible',_0x37d9a4));},!0x1);}['getInitialEvent'](_0x5a83d3){return f(_0x5a83d3==='visible','Unknown\x20event\x20type:\x20'+_0x5a83d3),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const vt=0x3e8,Rh=0x12c*0x3e8,er=0x1e*0x3e8,Ah=1.3,kh=0x7530,Nh='server_kill',tr=0x3;class se extends So{constructor(_0x1d6f6f,_0x52ca0e,_0x1a4b32,_0x563de0,_0x4ba20e,_0x597c4b,_0x4fcfcd,_0x46d599){if(super(),this['repoInfo_']=_0x1d6f6f,this['applicationId_']=_0x52ca0e,this['onDataUpdate_']=_0x1a4b32,this['onConnectStatus_']=_0x563de0,this['onServerInfoUpdate_']=_0x4ba20e,this['authTokenProvider_']=_0x597c4b,this['appCheckTokenProvider_']=_0x4fcfcd,this['authOverride_']=_0x46d599,this['id']=se['nextPersistentConnectionId_']++,this['log_']=zt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=vt,this['maxReconnectDelay_']=Rh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x46d599)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x1d6f6f['host']['indexOf']('fblocal')===-0x1&&gn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x41b691,_0xef02eb,_0x158fef){const _0x375964=++this['requestNumber_'],_0x2db3e5={'r':_0x375964,'a':_0x41b691,'b':_0xef02eb};this['log_'](O(_0x2db3e5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x2db3e5),_0x158fef&&(this['requestCBHash_'][_0x375964]=_0x158fef);}['get'](_0x58380d){this['initConnection_']();const _0x47b9ba=new H(),_0x2c0a7a={'action':'g','request':{'p':_0x58380d['_path']['toString'](),'q':_0x58380d['_queryObject']},'onComplete':_0x327aa5=>{const _0x6bf395=_0x327aa5['d'];_0x327aa5['s']==='ok'?_0x47b9ba['resolve'](_0x6bf395):_0x47b9ba['reject'](_0x6bf395);}};this['outstandingGets_']['push'](_0x2c0a7a),this['outstandingGetCount_']++;const _0x3fe4ef=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3fe4ef),_0x47b9ba['promise'];}['listen'](_0x96ebc3,_0x42d4ef,_0x5bf9fe,_0x4b02b1){this['initConnection_']();const _0x58a843=_0x96ebc3['_queryIdentifier'],_0x3f2cdb=_0x96ebc3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3f2cdb+'\x20'+_0x58a843),this['listens']['has'](_0x3f2cdb)||this['listens']['set'](_0x3f2cdb,new Map()),f(_0x96ebc3['_queryParams']['isDefault']()||!_0x96ebc3['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3f2cdb)['has'](_0x58a843),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x41f9bb={'onComplete':_0x4b02b1,'hashFn':_0x42d4ef,'query':_0x96ebc3,'tag':_0x5bf9fe};this['listens']['get'](_0x3f2cdb)['set'](_0x58a843,_0x41f9bb),this['connected_']&&this['sendListen_'](_0x41f9bb);}['sendGet_'](_0x307d29){const _0x1b712b=this['outstandingGets_'][_0x307d29];this['sendRequest']('g',_0x1b712b['request'],_0x44b916=>{delete this['outstandingGets_'][_0x307d29],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1b712b['onComplete']&&_0x1b712b['onComplete'](_0x44b916);});}['sendListen_'](_0x376d74){const _0x324f71=_0x376d74['query'],_0x5fffd=_0x324f71['_path']['toString'](),_0x95d2e3=_0x324f71['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5fffd+'\x20for\x20'+_0x95d2e3);const _0x47c449={'p':_0x5fffd},_0x1c0161='q';_0x376d74['tag']&&(_0x47c449['q']=_0x324f71['_queryObject'],_0x47c449['t']=_0x376d74['tag']),_0x47c449['h']=_0x376d74['hashFn'](),this['sendRequest'](_0x1c0161,_0x47c449,_0x150877=>{const _0xbcbb9a=_0x150877['d'],_0x458507=_0x150877['s'];se['warnOnListenWarnings_'](_0xbcbb9a,_0x324f71),(this['listens']['get'](_0x5fffd)&&this['listens']['get'](_0x5fffd)['get'](_0x95d2e3))===_0x376d74&&(this['log_']('listen\x20response',_0x150877),_0x458507!=='ok'&&this['removeListen_'](_0x5fffd,_0x95d2e3),_0x376d74['onComplete']&&_0x376d74['onComplete'](_0x458507,_0xbcbb9a));});}static['warnOnListenWarnings_'](_0x5db87e,_0x1bb3dd){if(_0x5db87e&&typeof _0x5db87e=='object'&&Q(_0x5db87e,'w')){const _0x1b0873=Me(_0x5db87e,'w');if(Array['isArray'](_0x1b0873)&&~_0x1b0873['indexOf']('no_index')){const _0xeb0704='\x22.indexOn\x22:\x20\x22'+_0x1bb3dd['_queryParams']['getIndex']()['toString']()+'\x22',_0x1ed869=_0x1bb3dd['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0xeb0704+'\x20at\x20'+_0x1ed869+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x483724){this['authToken_']=_0x483724,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x483724);}['reduceReconnectDelayIfAdminCredential_'](_0x4eb263){(_0x4eb263&&_0x4eb263['length']===0x28||yc(_0x4eb263))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x119c98){this['appCheckToken_']=_0x119c98,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x49defc=this['authToken_'],_0x4add14=mc(_0x49defc)?'auth':'gauth',_0x27bab9={'cred':_0x49defc};this['authOverride_']===null?_0x27bab9['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x27bab9['authvar']=this['authOverride_']),this['sendRequest'](_0x4add14,_0x27bab9,_0x2af07e=>{const _0x462a0f=_0x2af07e['s'],_0x1b42bd=_0x2af07e['d']||'error';this['authToken_']===_0x49defc&&(_0x462a0f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x462a0f,_0x1b42bd));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x371d9c=>{const _0x4253fd=_0x371d9c['s'],_0x14ecd4=_0x371d9c['d']||'error';_0x4253fd==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4253fd,_0x14ecd4);});}['unlisten'](_0x1e4218,_0x123d93){const _0x511156=_0x1e4218['_path']['toString'](),_0x19170f=_0x1e4218['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x511156+'\x20'+_0x19170f),f(_0x1e4218['_queryParams']['isDefault']()||!_0x1e4218['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x511156,_0x19170f)&&this['connected_']&&this['sendUnlisten_'](_0x511156,_0x19170f,_0x1e4218['_queryObject'],_0x123d93);}['sendUnlisten_'](_0x314e11,_0x54d020,_0x3241f6,_0x23c3f3){this['log_']('Unlisten\x20on\x20'+_0x314e11+'\x20for\x20'+_0x54d020);const _0x4ea70a={'p':_0x314e11},_0x5639be='n';_0x23c3f3&&(_0x4ea70a['q']=_0x3241f6,_0x4ea70a['t']=_0x23c3f3),this['sendRequest'](_0x5639be,_0x4ea70a);}['onDisconnectPut'](_0x4a601d,_0x366a09,_0x1c509b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4a601d,_0x366a09,_0x1c509b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4a601d,'action':'o','data':_0x366a09,'onComplete':_0x1c509b});}['onDisconnectMerge'](_0x33d864,_0x5229e0,_0x7abbec){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x33d864,_0x5229e0,_0x7abbec):this['onDisconnectRequestQueue_']['push']({'pathString':_0x33d864,'action':'om','data':_0x5229e0,'onComplete':_0x7abbec});}['onDisconnectCancel'](_0x21058f,_0xc72367){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x21058f,null,_0xc72367):this['onDisconnectRequestQueue_']['push']({'pathString':_0x21058f,'action':'oc','data':null,'onComplete':_0xc72367});}['sendOnDisconnect_'](_0x18031b,_0x15395c,_0x21daa3,_0x41658a){const _0x32f765={'p':_0x15395c,'d':_0x21daa3};this['log_']('onDisconnect\x20'+_0x18031b,_0x32f765),this['sendRequest'](_0x18031b,_0x32f765,_0x233ac0=>{_0x41658a&&setTimeout(()=>{_0x41658a(_0x233ac0['s'],_0x233ac0['d']);},Math['floor'](0x0));});}['put'](_0xe314ff,_0x4a1962,_0x5cf31c,_0x512993){this['putInternal']('p',_0xe314ff,_0x4a1962,_0x5cf31c,_0x512993);}['merge'](_0x5eba1b,_0x326796,_0x543214,_0x1cd983){this['putInternal']('m',_0x5eba1b,_0x326796,_0x543214,_0x1cd983);}['putInternal'](_0x3ce235,_0x564a4e,_0x504190,_0x1534e1,_0x3b1949){this['initConnection_']();const _0x571e3d={'p':_0x564a4e,'d':_0x504190};_0x3b1949!==void 0x0&&(_0x571e3d['h']=_0x3b1949),this['outstandingPuts_']['push']({'action':_0x3ce235,'request':_0x571e3d,'onComplete':_0x1534e1}),this['outstandingPutCount_']++;const _0x4486b9=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4486b9):this['log_']('Buffering\x20put:\x20'+_0x564a4e);}['sendPut_'](_0x1c0c44){const _0xffd996=this['outstandingPuts_'][_0x1c0c44]['action'],_0x4d0ef1=this['outstandingPuts_'][_0x1c0c44]['request'],_0x13b58f=this['outstandingPuts_'][_0x1c0c44]['onComplete'];this['outstandingPuts_'][_0x1c0c44]['queued']=this['connected_'],this['sendRequest'](_0xffd996,_0x4d0ef1,_0x582915=>{this['log_'](_0xffd996+'\x20response',_0x582915),delete this['outstandingPuts_'][_0x1c0c44],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x13b58f&&_0x13b58f(_0x582915['s'],_0x582915['d']);});}['reportStats'](_0x55ad61){if(this['connected_']){const _0x27af0f={'c':_0x55ad61};this['log_']('reportStats',_0x27af0f),this['sendRequest']('s',_0x27af0f,_0x41e3e5=>{if(_0x41e3e5['s']!=='ok'){const _0x279649=_0x41e3e5['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x279649);}});}}['onDataMessage_'](_0x3913a8){if('r'in _0x3913a8){this['log_']('from\x20server:\x20'+O(_0x3913a8));const _0x47243e=_0x3913a8['r'],_0x5a4f24=this['requestCBHash_'][_0x47243e];_0x5a4f24&&(delete this['requestCBHash_'][_0x47243e],_0x5a4f24(_0x3913a8['b']));}else{if('error'in _0x3913a8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x3913a8['error'];'a'in _0x3913a8&&this['onDataPush_'](_0x3913a8['a'],_0x3913a8['b']);}}['onDataPush_'](_0x5d0a87,_0x163ce5){this['log_']('handleServerMessage',_0x5d0a87,_0x163ce5),_0x5d0a87==='d'?this['onDataUpdate_'](_0x163ce5['p'],_0x163ce5['d'],!0x1,_0x163ce5['t']):_0x5d0a87==='m'?this['onDataUpdate_'](_0x163ce5['p'],_0x163ce5['d'],!0x0,_0x163ce5['t']):_0x5d0a87==='c'?this['onListenRevoked_'](_0x163ce5['p'],_0x163ce5['q']):_0x5d0a87==='ac'?this['onAuthRevoked_'](_0x163ce5['s'],_0x163ce5['d']):_0x5d0a87==='apc'?this['onAppCheckRevoked_'](_0x163ce5['s'],_0x163ce5['d']):_0x5d0a87==='sd'?this['onSecurityDebugPacket_'](_0x163ce5):Ei('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5d0a87)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1577f6,_0x12f4dd){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1577f6),this['lastSessionId']=_0x12f4dd,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4a1e76){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4a1e76));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2b3f9a){_0x2b3f9a&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2b3f9a;}['onOnline_'](_0x204eff){_0x204eff?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>kh&&(this['reconnectDelay_']=vt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x26b207=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xef2615=Math['max'](0x0,this['reconnectDelay_']-_0x26b207);_0xef2615=Math['random']()*_0xef2615,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xef2615+'ms'),this['scheduleConnect_'](_0xef2615),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Ah);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x45e2bb=this['onDataMessage_']['bind'](this),_0x274550=this['onReady_']['bind'](this),_0x4aa5e4=this['onRealtimeDisconnect_']['bind'](this),_0x1fc0da=this['id']+':'+se['nextConnectionId_']++,_0x462f3c=this['lastSessionId'];let _0xee14e9=!0x1,_0x5e1fe9=null;const _0x377963=function(){_0x5e1fe9?_0x5e1fe9['close']():(_0xee14e9=!0x0,_0x4aa5e4());},_0x9779c7=function(_0x3e1187){f(_0x5e1fe9,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x5e1fe9['sendRequest'](_0x3e1187);};this['realtime_']={'close':_0x377963,'sendRequest':_0x9779c7};const _0x25f404=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x29cf1e,_0x1ae1c7]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x25f404),this['appCheckTokenProvider_']['getToken'](_0x25f404)]);_0xee14e9?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x29cf1e&&_0x29cf1e['accessToken'],this['appCheckToken_']=_0x1ae1c7&&_0x1ae1c7['token'],_0x5e1fe9=new Ih(_0x1fc0da,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x45e2bb,_0x274550,_0x4aa5e4,_0x37e5e3=>{U(_0x37e5e3+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Nh);},_0x462f3c));}catch(_0x333984){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x333984),_0xee14e9||(this['repoInfo_']['nodeAdmin']&&U(_0x333984),_0x377963());}}}['interrupt'](_0x29f398){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x29f398),this['interruptReasons_'][_0x29f398]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1cdc0d){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1cdc0d),delete this['interruptReasons_'][_0x1cdc0d],fn(this['interruptReasons_'])&&(this['reconnectDelay_']=vt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x2b510f){const _0x4eeb47=_0x2b510f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4eeb47});}['cancelSentTransactions_'](){for(let _0x261115=0x0;_0x261115<this['outstandingPuts_']['length'];_0x261115++){const _0x159027=this['outstandingPuts_'][_0x261115];_0x159027&&'h'in _0x159027['request']&&_0x159027['queued']&&(_0x159027['onComplete']&&_0x159027['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x261115],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x2f1e26,_0x3b0ec1){let _0x4786ac;_0x3b0ec1?_0x4786ac=_0x3b0ec1['map'](_0x2b8323=>Hi(_0x2b8323))['join']('$'):_0x4786ac='default';const _0x405709=this['removeListen_'](_0x2f1e26,_0x4786ac);_0x405709&&_0x405709['onComplete']&&_0x405709['onComplete']('permission_denied');}['removeListen_'](_0x4bab59,_0x40f271){const _0x1c215a=new C(_0x4bab59)['toString']();let _0x3a2dbc;if(this['listens']['has'](_0x1c215a)){const _0x398589=this['listens']['get'](_0x1c215a);_0x3a2dbc=_0x398589['get'](_0x40f271),_0x398589['delete'](_0x40f271),_0x398589['size']===0x0&&this['listens']['delete'](_0x1c215a);}else _0x3a2dbc=void 0x0;return _0x3a2dbc;}['onAuthRevoked_'](_0x52555d,_0xba2596){L('Auth\x20token\x20revoked:\x20'+_0x52555d+'/'+_0xba2596),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x52555d==='invalid_token'||_0x52555d==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x56f4a3,_0x2b01fd){L('App\x20check\x20token\x20revoked:\x20'+_0x56f4a3+'/'+_0x2b01fd),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x56f4a3==='invalid_token'||_0x56f4a3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x42fc6a){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x42fc6a):'msg'in _0x42fc6a&&console['log']('FIREBASE:\x20'+_0x42fc6a['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2b5153 of this['listens']['values']())for(const _0x451244 of _0x2b5153['values']())this['sendListen_'](_0x451244);for(let _0x339fa5=0x0;_0x339fa5<this['outstandingPuts_']['length'];_0x339fa5++)this['outstandingPuts_'][_0x339fa5]&&this['sendPut_'](_0x339fa5);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2eca95=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2eca95['action'],_0x2eca95['pathString'],_0x2eca95['data'],_0x2eca95['onComplete']);}for(let _0x48cdd7=0x0;_0x48cdd7<this['outstandingGets_']['length'];_0x48cdd7++)this['outstandingGets_'][_0x48cdd7]&&this['sendGet_'](_0x48cdd7);}['sendConnectStats_'](){const _0x3f43d3={};let _0x16fccb='js';_0x3f43d3['sdk.'+_0x16fccb+'.'+no['replace'](/\./g,'-')]=0x1,Ui()?_0x3f43d3['framework.cordova']=0x1:Kr()&&(_0x3f43d3['framework.reactnative']=0x1),this['reportStats'](_0x3f43d3);}['shouldReconnect_'](){const _0x5e92d5=gn['getInstance']()['currentlyOnline']();return fn(this['interruptReasons_'])&&_0x5e92d5;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xc84d5c,_0x123ed2){this['name']=_0xc84d5c,this['node']=_0x123ed2;}static['Wrap'](_0x576e9a,_0xc22790){return new E(_0x576e9a,_0xc22790);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1b3955,_0x332203){const _0x31026d=new E(Ue,_0x1b3955),_0x4842cd=new E(Ue,_0x332203);return this['compare'](_0x31026d,_0x4842cd)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nn;class ko extends xn{static get['__EMPTY_NODE'](){return nn;}static set['__EMPTY_NODE'](_0xb0b5a){nn=_0xb0b5a;}['compare'](_0x4db156,_0x22b011){return Ge(_0x4db156['name'],_0x22b011['name']);}['isDefinedOn'](_0x42a09e){throw lt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4858d7,_0x5eb278){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,nn);}['makePost'](_0x369735,_0x32e7ab){return f(typeof _0x369735=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x369735,nn);}['toString'](){return'.key';}}const De=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sn{constructor(_0x9a3b7e,_0x2d1abb,_0x429d86,_0x2f84f,_0x37f50e=null){this['isReverse_']=_0x2f84f,this['resultGenerator_']=_0x37f50e,this['nodeStack_']=[];let _0x94aedf=0x1;for(;!_0x9a3b7e['isEmpty']();)if(_0x9a3b7e=_0x9a3b7e,_0x94aedf=_0x2d1abb?_0x429d86(_0x9a3b7e['key'],_0x2d1abb):0x1,_0x2f84f&&(_0x94aedf*=-0x1),_0x94aedf<0x0)this['isReverse_']?_0x9a3b7e=_0x9a3b7e['left']:_0x9a3b7e=_0x9a3b7e['right'];else{if(_0x94aedf===0x0){this['nodeStack_']['push'](_0x9a3b7e);break;}else this['nodeStack_']['push'](_0x9a3b7e),this['isReverse_']?_0x9a3b7e=_0x9a3b7e['right']:_0x9a3b7e=_0x9a3b7e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x3275bd=this['nodeStack_']['pop'](),_0x553c6b;if(this['resultGenerator_']?_0x553c6b=this['resultGenerator_'](_0x3275bd['key'],_0x3275bd['value']):_0x553c6b={'key':_0x3275bd['key'],'value':_0x3275bd['value']},this['isReverse_']){for(_0x3275bd=_0x3275bd['left'];!_0x3275bd['isEmpty']();)this['nodeStack_']['push'](_0x3275bd),_0x3275bd=_0x3275bd['right'];}else{for(_0x3275bd=_0x3275bd['right'];!_0x3275bd['isEmpty']();)this['nodeStack_']['push'](_0x3275bd),_0x3275bd=_0x3275bd['left'];}return _0x553c6b;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1a893f=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1a893f['key'],_0x1a893f['value']):{'key':_0x1a893f['key'],'value':_0x1a893f['value']};}}class M{constructor(_0x29c970,_0x431b24,_0x4be6e7,_0x18b350,_0x461b2b){this['key']=_0x29c970,this['value']=_0x431b24,this['color']=_0x4be6e7??M['RED'],this['left']=_0x18b350??B['EMPTY_NODE'],this['right']=_0x461b2b??B['EMPTY_NODE'];}['copy'](_0x51eb77,_0x1ebdb1,_0x511177,_0x403321,_0x3d8db0){return new M(_0x51eb77??this['key'],_0x1ebdb1??this['value'],_0x511177??this['color'],_0x403321??this['left'],_0x3d8db0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x14a6a0){return this['left']['inorderTraversal'](_0x14a6a0)||!!_0x14a6a0(this['key'],this['value'])||this['right']['inorderTraversal'](_0x14a6a0);}['reverseTraversal'](_0x2942bf){return this['right']['reverseTraversal'](_0x2942bf)||_0x2942bf(this['key'],this['value'])||this['left']['reverseTraversal'](_0x2942bf);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5b55e8,_0xcc1c31,_0x5ee223){let _0x47653b=this;const _0x4e77bf=_0x5ee223(_0x5b55e8,_0x47653b['key']);return _0x4e77bf<0x0?_0x47653b=_0x47653b['copy'](null,null,null,_0x47653b['left']['insert'](_0x5b55e8,_0xcc1c31,_0x5ee223),null):_0x4e77bf===0x0?_0x47653b=_0x47653b['copy'](null,_0xcc1c31,null,null,null):_0x47653b=_0x47653b['copy'](null,null,null,null,_0x47653b['right']['insert'](_0x5b55e8,_0xcc1c31,_0x5ee223)),_0x47653b['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3845d0=this;return!_0x3845d0['left']['isRed_']()&&!_0x3845d0['left']['left']['isRed_']()&&(_0x3845d0=_0x3845d0['moveRedLeft_']()),_0x3845d0=_0x3845d0['copy'](null,null,null,_0x3845d0['left']['removeMin_'](),null),_0x3845d0['fixUp_']();}['remove'](_0x1c259b,_0x3a2b21){let _0x4de20b,_0x1ec9a1;if(_0x4de20b=this,_0x3a2b21(_0x1c259b,_0x4de20b['key'])<0x0)!_0x4de20b['left']['isEmpty']()&&!_0x4de20b['left']['isRed_']()&&!_0x4de20b['left']['left']['isRed_']()&&(_0x4de20b=_0x4de20b['moveRedLeft_']()),_0x4de20b=_0x4de20b['copy'](null,null,null,_0x4de20b['left']['remove'](_0x1c259b,_0x3a2b21),null);else{if(_0x4de20b['left']['isRed_']()&&(_0x4de20b=_0x4de20b['rotateRight_']()),!_0x4de20b['right']['isEmpty']()&&!_0x4de20b['right']['isRed_']()&&!_0x4de20b['right']['left']['isRed_']()&&(_0x4de20b=_0x4de20b['moveRedRight_']()),_0x3a2b21(_0x1c259b,_0x4de20b['key'])===0x0){if(_0x4de20b['right']['isEmpty']())return B['EMPTY_NODE'];_0x1ec9a1=_0x4de20b['right']['min_'](),_0x4de20b=_0x4de20b['copy'](_0x1ec9a1['key'],_0x1ec9a1['value'],null,null,_0x4de20b['right']['removeMin_']());}_0x4de20b=_0x4de20b['copy'](null,null,null,null,_0x4de20b['right']['remove'](_0x1c259b,_0x3a2b21));}return _0x4de20b['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x19e680=this;return _0x19e680['right']['isRed_']()&&!_0x19e680['left']['isRed_']()&&(_0x19e680=_0x19e680['rotateLeft_']()),_0x19e680['left']['isRed_']()&&_0x19e680['left']['left']['isRed_']()&&(_0x19e680=_0x19e680['rotateRight_']()),_0x19e680['left']['isRed_']()&&_0x19e680['right']['isRed_']()&&(_0x19e680=_0x19e680['colorFlip_']()),_0x19e680;}['moveRedLeft_'](){let _0x146755=this['colorFlip_']();return _0x146755['right']['left']['isRed_']()&&(_0x146755=_0x146755['copy'](null,null,null,null,_0x146755['right']['rotateRight_']()),_0x146755=_0x146755['rotateLeft_'](),_0x146755=_0x146755['colorFlip_']()),_0x146755;}['moveRedRight_'](){let _0x226b16=this['colorFlip_']();return _0x226b16['left']['left']['isRed_']()&&(_0x226b16=_0x226b16['rotateRight_'](),_0x226b16=_0x226b16['colorFlip_']()),_0x226b16;}['rotateLeft_'](){const _0x1cd15a=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1cd15a,null);}['rotateRight_'](){const _0x5d9c34=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5d9c34);}['colorFlip_'](){const _0x15baed=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5d71ed=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x15baed,_0x5d71ed);}['checkMaxDepth_'](){const _0x320236=this['check_']();return Math['pow'](0x2,_0x320236)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1e5991=this['left']['check_']();if(_0x1e5991!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1e5991+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Ph{['copy'](_0x5b1e62,_0x5e2448,_0x18f24c,_0x4c329a,_0x6dfc64){return this;}['insert'](_0x2dff7c,_0x561abf,_0x405b14){return new M(_0x2dff7c,_0x561abf,null);}['remove'](_0x1dfcc1,_0x7d7845){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x31878d){return!0x1;}['reverseTraversal'](_0xd134eb){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x5bc7fc,_0x460011=B['EMPTY_NODE']){this['comparator_']=_0x5bc7fc,this['root_']=_0x460011;}['insert'](_0x332724,_0x5300dc){return new B(this['comparator_'],this['root_']['insert'](_0x332724,_0x5300dc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5f14cd){return new B(this['comparator_'],this['root_']['remove'](_0x5f14cd,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x29aee1){let _0x4f38ab,_0x47eff1=this['root_'];for(;!_0x47eff1['isEmpty']();){if(_0x4f38ab=this['comparator_'](_0x29aee1,_0x47eff1['key']),_0x4f38ab===0x0)return _0x47eff1['value'];_0x4f38ab<0x0?_0x47eff1=_0x47eff1['left']:_0x4f38ab>0x0&&(_0x47eff1=_0x47eff1['right']);}return null;}['getPredecessorKey'](_0x3222b3){let _0x232f9a,_0x3dee92=this['root_'],_0x417e4b=null;for(;!_0x3dee92['isEmpty']();)if(_0x232f9a=this['comparator_'](_0x3222b3,_0x3dee92['key']),_0x232f9a===0x0){if(_0x3dee92['left']['isEmpty']())return _0x417e4b?_0x417e4b['key']:null;for(_0x3dee92=_0x3dee92['left'];!_0x3dee92['right']['isEmpty']();)_0x3dee92=_0x3dee92['right'];return _0x3dee92['key'];}else _0x232f9a<0x0?_0x3dee92=_0x3dee92['left']:_0x232f9a>0x0&&(_0x417e4b=_0x3dee92,_0x3dee92=_0x3dee92['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x52e0e2){return this['root_']['inorderTraversal'](_0x52e0e2);}['reverseTraversal'](_0x28f221){return this['root_']['reverseTraversal'](_0x28f221);}['getIterator'](_0x4c55f7){return new sn(this['root_'],null,this['comparator_'],!0x1,_0x4c55f7);}['getIteratorFrom'](_0x375288,_0x3848e2){return new sn(this['root_'],_0x375288,this['comparator_'],!0x1,_0x3848e2);}['getReverseIteratorFrom'](_0x50371d,_0x4328d9){return new sn(this['root_'],_0x50371d,this['comparator_'],!0x0,_0x4328d9);}['getReverseIterator'](_0x41dfc5){return new sn(this['root_'],null,this['comparator_'],!0x0,_0x41dfc5);}}B['EMPTY_NODE']=new Ph();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oh(_0x5abefd,_0x246c89){return Ge(_0x5abefd['name'],_0x246c89['name']);}function Yi(_0x31f925,_0x5b6638){return Ge(_0x31f925,_0x5b6638);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wi;function Dh(_0x368da7){wi=_0x368da7;}const No=function(_0x169420){return typeof _0x169420=='number'?'number:'+ao(_0x169420):'string:'+_0x169420;},Po=function(_0xef5110){if(_0xef5110['isLeafNode']()){const _0x1e6161=_0xef5110['val']();f(typeof _0x1e6161=='string'||typeof _0x1e6161=='number'||typeof _0x1e6161=='object'&&Q(_0x1e6161,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xef5110===wi||_0xef5110['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xef5110===wi||_0xef5110['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x38348b){nr=_0x38348b;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x29ea6b,_0xeee138=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x29ea6b,this['priorityNode_']=_0xeee138,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xfc3c81){return new D(this['value_'],_0xfc3c81);}['getImmediateChild'](_0x2a9432){return _0x2a9432==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3ab33f){return v(_0x3ab33f)?this:y(_0x3ab33f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0xda9a67,_0x547cab){return null;}['updateImmediateChild'](_0x3b096e,_0x4667b8){return _0x3b096e==='.priority'?this['updatePriority'](_0x4667b8):_0x4667b8['isEmpty']()&&_0x3b096e!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x3b096e,_0x4667b8)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x474bc3,_0x1fca7d){const _0xb13038=y(_0x474bc3);return _0xb13038===null?_0x1fca7d:_0x1fca7d['isEmpty']()&&_0xb13038!=='.priority'?this:(f(_0xb13038!=='.priority'||we(_0x474bc3)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xb13038,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x474bc3),_0x1fca7d)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2850cf,_0x4161e6){return!0x1;}['val'](_0x45bb4a){return _0x45bb4a&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x36fee7='';this['priorityNode_']['isEmpty']()||(_0x36fee7+='priority:'+No(this['priorityNode_']['val']())+':');const _0x18dcdb=typeof this['value_'];_0x36fee7+=_0x18dcdb+':',_0x18dcdb==='number'?_0x36fee7+=ao(this['value_']):_0x36fee7+=this['value_'],this['lazyHash_']=ro(_0x36fee7);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x19bd6e){return _0x19bd6e===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x19bd6e instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x19bd6e['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x19bd6e));}['compareToLeafNode_'](_0x90da09){const _0x5e3529=typeof _0x90da09['value_'],_0x4a0ab4=typeof this['value_'],_0x2b03c9=D['VALUE_TYPE_ORDER']['indexOf'](_0x5e3529),_0x1ddebd=D['VALUE_TYPE_ORDER']['indexOf'](_0x4a0ab4);return f(_0x2b03c9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5e3529),f(_0x1ddebd>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4a0ab4),_0x2b03c9===_0x1ddebd?_0x4a0ab4==='object'?0x0:this['value_']<_0x90da09['value_']?-0x1:this['value_']===_0x90da09['value_']?0x0:0x1:_0x1ddebd-_0x2b03c9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x463aac){if(_0x463aac===this)return!0x0;if(_0x463aac['isLeafNode']()){const _0x1fff65=_0x463aac;return this['value_']===_0x1fff65['value_']&&this['priorityNode_']['equals'](_0x1fff65['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Mh(_0x407312){Oo=_0x407312;}function Lh(_0x4eb789){Do=_0x4eb789;}class xh extends xn{['compare'](_0x53b7c5,_0x4514cf){const _0x32a840=_0x53b7c5['node']['getPriority'](),_0xd12dd6=_0x4514cf['node']['getPriority'](),_0x56e9e8=_0x32a840['compareTo'](_0xd12dd6);return _0x56e9e8===0x0?Ge(_0x53b7c5['name'],_0x4514cf['name']):_0x56e9e8;}['isDefinedOn'](_0x56fc5c){return!_0x56fc5c['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3f72ac,_0x4a2720){return!_0x3f72ac['getPriority']()['equals'](_0x4a2720['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x2eccb1,_0x18a5d2){const _0x37c1fd=Oo(_0x2eccb1);return new E(_0x18a5d2,new D('[PRIORITY-POST]',_0x37c1fd));}['toString'](){return'.priority';}}const R=new xh(),Fh=Math['log'](0x2);class Uh{constructor(_0x94a053){const _0x52846b=_0x1b969f=>parseInt(Math['log'](_0x1b969f)/Fh,0xa),_0x5c1dbc=_0x555b8f=>parseInt(Array(_0x555b8f+0x1)['join']('1'),0x2);this['count']=_0x52846b(_0x94a053+0x1),this['current_']=this['count']-0x1;const _0x30ed61=_0x5c1dbc(this['count']);this['bits_']=_0x94a053+0x1&_0x30ed61;}['nextBitIsOne'](){const _0x24780c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x24780c;}}const mn=function(_0x3afe4e,_0x362288,_0x5534b2,_0x49a71f){_0x3afe4e['sort'](_0x362288);const _0x27e33c=function(_0xa9b399,_0x5c52bf){const _0x3e8069=_0x5c52bf-_0xa9b399;let _0x9f48ee,_0x30fc38;if(_0x3e8069===0x0)return null;if(_0x3e8069===0x1)return _0x9f48ee=_0x3afe4e[_0xa9b399],_0x30fc38=_0x5534b2?_0x5534b2(_0x9f48ee):_0x9f48ee,new M(_0x30fc38,_0x9f48ee['node'],M['BLACK'],null,null);{const _0x449639=parseInt(_0x3e8069/0x2,0xa)+_0xa9b399,_0xee939c=_0x27e33c(_0xa9b399,_0x449639),_0x5e63fd=_0x27e33c(_0x449639+0x1,_0x5c52bf);return _0x9f48ee=_0x3afe4e[_0x449639],_0x30fc38=_0x5534b2?_0x5534b2(_0x9f48ee):_0x9f48ee,new M(_0x30fc38,_0x9f48ee['node'],M['BLACK'],_0xee939c,_0x5e63fd);}},_0x43028d=function(_0x47c42f){let _0x14d13e=null,_0x8d3535=null,_0x5a6f06=_0x3afe4e['length'];const _0x398f16=function(_0x2afd09,_0x5bdb4a){const _0x581976=_0x5a6f06-_0x2afd09,_0x33039f=_0x5a6f06;_0x5a6f06-=_0x2afd09;const _0x198eb3=_0x27e33c(_0x581976+0x1,_0x33039f),_0x29d792=_0x3afe4e[_0x581976],_0x5ea7d0=_0x5534b2?_0x5534b2(_0x29d792):_0x29d792;_0x462145(new M(_0x5ea7d0,_0x29d792['node'],_0x5bdb4a,null,_0x198eb3));},_0x462145=function(_0xc8a5a1){_0x14d13e?(_0x14d13e['left']=_0xc8a5a1,_0x14d13e=_0xc8a5a1):(_0x8d3535=_0xc8a5a1,_0x14d13e=_0xc8a5a1);};for(let _0x4c834e=0x0;_0x4c834e<_0x47c42f['count'];++_0x4c834e){const _0x454915=_0x47c42f['nextBitIsOne'](),_0x257f15=Math['pow'](0x2,_0x47c42f['count']-(_0x4c834e+0x1));_0x454915?_0x398f16(_0x257f15,M['BLACK']):(_0x398f16(_0x257f15,M['BLACK']),_0x398f16(_0x257f15,M['RED']));}return _0x8d3535;},_0x18f448=new Uh(_0x3afe4e['length']),_0x3728b6=_0x43028d(_0x18f448);return new B(_0x49a71f||_0x362288,_0x3728b6);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ci;const Ye={};class te{static get['Default'](){return f(Ye&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ci=ci||new te({'.priority':Ye},{'.priority':R}),ci;}constructor(_0x21489b,_0x2b6679){this['indexes_']=_0x21489b,this['indexSet_']=_0x2b6679;}['get'](_0x502b4f){const _0x3fe5c2=Me(this['indexes_'],_0x502b4f);if(!_0x3fe5c2)throw new Error('No\x20index\x20defined\x20for\x20'+_0x502b4f);return _0x3fe5c2 instanceof B?_0x3fe5c2:null;}['hasIndex'](_0x367525){return Q(this['indexSet_'],_0x367525['toString']());}['addIndex'](_0x4e3fca,_0x25167e){f(_0x4e3fca!==De,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x53f6cc=[];let _0x4ceb80=!0x1;const _0x2c35c5=_0x25167e['getIterator'](E['Wrap']);let _0x57028c=_0x2c35c5['getNext']();for(;_0x57028c;)_0x4ceb80=_0x4ceb80||_0x4e3fca['isDefinedOn'](_0x57028c['node']),_0x53f6cc['push'](_0x57028c),_0x57028c=_0x2c35c5['getNext']();let _0x47426c;_0x4ceb80?_0x47426c=mn(_0x53f6cc,_0x4e3fca['getCompare']()):_0x47426c=Ye;const _0x2c01b7=_0x4e3fca['toString'](),_0x39e3c9={...this['indexSet_']};_0x39e3c9[_0x2c01b7]=_0x4e3fca;const _0x9fcb49={...this['indexes_']};return _0x9fcb49[_0x2c01b7]=_0x47426c,new te(_0x9fcb49,_0x39e3c9);}['addToIndexes'](_0x26b091,_0xbd5f5d){const _0x57c70f=pn(this['indexes_'],(_0x170007,_0x2f2437)=>{const _0x478ca5=Me(this['indexSet_'],_0x2f2437);if(f(_0x478ca5,'Missing\x20index\x20implementation\x20for\x20'+_0x2f2437),_0x170007===Ye){if(_0x478ca5['isDefinedOn'](_0x26b091['node'])){const _0x295283=[],_0x3151e7=_0xbd5f5d['getIterator'](E['Wrap']);let _0x13ff34=_0x3151e7['getNext']();for(;_0x13ff34;)_0x13ff34['name']!==_0x26b091['name']&&_0x295283['push'](_0x13ff34),_0x13ff34=_0x3151e7['getNext']();return _0x295283['push'](_0x26b091),mn(_0x295283,_0x478ca5['getCompare']());}else return Ye;}else{const _0x10ad53=_0xbd5f5d['get'](_0x26b091['name']);let _0x5bcef6=_0x170007;return _0x10ad53&&(_0x5bcef6=_0x5bcef6['remove'](new E(_0x26b091['name'],_0x10ad53))),_0x5bcef6['insert'](_0x26b091,_0x26b091['node']);}});return new te(_0x57c70f,this['indexSet_']);}['removeFromIndexes'](_0x409a7b,_0x4eecf5){const _0x59fc3e=pn(this['indexes_'],_0x3f047e=>{if(_0x3f047e===Ye)return _0x3f047e;{const _0x5c8ed4=_0x4eecf5['get'](_0x409a7b['name']);return _0x5c8ed4?_0x3f047e['remove'](new E(_0x409a7b['name'],_0x5c8ed4)):_0x3f047e;}});return new te(_0x59fc3e,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Et;class g{static get['EMPTY_NODE'](){return Et||(Et=new g(new B(Yi),null,te['Default']));}constructor(_0x2eb06a,_0x198f57,_0x5e0cba){this['children_']=_0x2eb06a,this['priorityNode_']=_0x198f57,this['indexMap_']=_0x5e0cba,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||Et;}['updatePriority'](_0x106403){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x106403,this['indexMap_']);}['getImmediateChild'](_0x1251c6){if(_0x1251c6==='.priority')return this['getPriority']();{const _0x27e01f=this['children_']['get'](_0x1251c6);return _0x27e01f===null?Et:_0x27e01f;}}['getChild'](_0x2d0c57){const _0x248b99=y(_0x2d0c57);return _0x248b99===null?this:this['getImmediateChild'](_0x248b99)['getChild'](S(_0x2d0c57));}['hasChild'](_0xd6b6d7){return this['children_']['get'](_0xd6b6d7)!==null;}['updateImmediateChild'](_0x1a189f,_0x5ed910){if(f(_0x5ed910,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1a189f==='.priority')return this['updatePriority'](_0x5ed910);{const _0x56ce7e=new E(_0x1a189f,_0x5ed910);let _0x42d9f6,_0x29828d;_0x5ed910['isEmpty']()?(_0x42d9f6=this['children_']['remove'](_0x1a189f),_0x29828d=this['indexMap_']['removeFromIndexes'](_0x56ce7e,this['children_'])):(_0x42d9f6=this['children_']['insert'](_0x1a189f,_0x5ed910),_0x29828d=this['indexMap_']['addToIndexes'](_0x56ce7e,this['children_']));const _0x578ac6=_0x42d9f6['isEmpty']()?Et:this['priorityNode_'];return new g(_0x42d9f6,_0x578ac6,_0x29828d);}}['updateChild'](_0x2666b8,_0x44b68c){const _0x1b1cba=y(_0x2666b8);if(_0x1b1cba===null)return _0x44b68c;{f(y(_0x2666b8)!=='.priority'||we(_0x2666b8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4b049d=this['getImmediateChild'](_0x1b1cba)['updateChild'](S(_0x2666b8),_0x44b68c);return this['updateImmediateChild'](_0x1b1cba,_0x4b049d);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x36e090){if(this['isEmpty']())return null;const _0x419421={};let _0x38a033=0x0,_0xee9a34=0x0,_0x540036=!0x0;if(this['forEachChild'](R,(_0x4cd010,_0x563527)=>{_0x419421[_0x4cd010]=_0x563527['val'](_0x36e090),_0x38a033++,_0x540036&&g['INTEGER_REGEXP_']['test'](_0x4cd010)?_0xee9a34=Math['max'](_0xee9a34,Number(_0x4cd010)):_0x540036=!0x1;}),!_0x36e090&&_0x540036&&_0xee9a34<0x2*_0x38a033){const _0x1e44e5=[];for(const _0x57a0cd in _0x419421)_0x1e44e5[_0x57a0cd]=_0x419421[_0x57a0cd];return _0x1e44e5;}else return _0x36e090&&!this['getPriority']()['isEmpty']()&&(_0x419421['.priority']=this['getPriority']()['val']()),_0x419421;}['hash'](){if(this['lazyHash_']===null){let _0x4385c7='';this['getPriority']()['isEmpty']()||(_0x4385c7+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1db9fc,_0x2dbafa)=>{const _0x431866=_0x2dbafa['hash']();_0x431866!==''&&(_0x4385c7+=':'+_0x1db9fc+':'+_0x431866);}),this['lazyHash_']=_0x4385c7===''?'':ro(_0x4385c7);}return this['lazyHash_'];}['getPredecessorChildName'](_0xe43ffc,_0x214f95,_0x4efad5){const _0x2629b6=this['resolveIndex_'](_0x4efad5);if(_0x2629b6){const _0xaa8fc2=_0x2629b6['getPredecessorKey'](new E(_0xe43ffc,_0x214f95));return _0xaa8fc2?_0xaa8fc2['name']:null;}else return this['children_']['getPredecessorKey'](_0xe43ffc);}['getFirstChildName'](_0x2b76da){const _0x4c660c=this['resolveIndex_'](_0x2b76da);if(_0x4c660c){const _0x4ccaf3=_0x4c660c['minKey']();return _0x4ccaf3&&_0x4ccaf3['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x286934){const _0x492dd2=this['getFirstChildName'](_0x286934);return _0x492dd2?new E(_0x492dd2,this['children_']['get'](_0x492dd2)):null;}['getLastChildName'](_0x542fc9){const _0x53e4b1=this['resolveIndex_'](_0x542fc9);if(_0x53e4b1){const _0x45b3b8=_0x53e4b1['maxKey']();return _0x45b3b8&&_0x45b3b8['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x42a03e){const _0x1b8f62=this['getLastChildName'](_0x42a03e);return _0x1b8f62?new E(_0x1b8f62,this['children_']['get'](_0x1b8f62)):null;}['forEachChild'](_0x11e2b1,_0x323b6b){const _0x35e18c=this['resolveIndex_'](_0x11e2b1);return _0x35e18c?_0x35e18c['inorderTraversal'](_0x5c75ee=>_0x323b6b(_0x5c75ee['name'],_0x5c75ee['node'])):this['children_']['inorderTraversal'](_0x323b6b);}['getIterator'](_0x3bed06){return this['getIteratorFrom'](_0x3bed06['minPost'](),_0x3bed06);}['getIteratorFrom'](_0x5a1ae0,_0x4709ca){const _0x19d8e8=this['resolveIndex_'](_0x4709ca);if(_0x19d8e8)return _0x19d8e8['getIteratorFrom'](_0x5a1ae0,_0x5a54c8=>_0x5a54c8);{const _0x4c9886=this['children_']['getIteratorFrom'](_0x5a1ae0['name'],E['Wrap']);let _0x2edce3=_0x4c9886['peek']();for(;_0x2edce3!=null&&_0x4709ca['compare'](_0x2edce3,_0x5a1ae0)<0x0;)_0x4c9886['getNext'](),_0x2edce3=_0x4c9886['peek']();return _0x4c9886;}}['getReverseIterator'](_0xe0c401){return this['getReverseIteratorFrom'](_0xe0c401['maxPost'](),_0xe0c401);}['getReverseIteratorFrom'](_0x3a246f,_0x43c078){const _0x5c1407=this['resolveIndex_'](_0x43c078);if(_0x5c1407)return _0x5c1407['getReverseIteratorFrom'](_0x3a246f,_0x7983a2=>_0x7983a2);{const _0x555903=this['children_']['getReverseIteratorFrom'](_0x3a246f['name'],E['Wrap']);let _0x5ee45d=_0x555903['peek']();for(;_0x5ee45d!=null&&_0x43c078['compare'](_0x5ee45d,_0x3a246f)>0x0;)_0x555903['getNext'](),_0x5ee45d=_0x555903['peek']();return _0x555903;}}['compareTo'](_0x3f4e6a){return this['isEmpty']()?_0x3f4e6a['isEmpty']()?0x0:-0x1:_0x3f4e6a['isLeafNode']()||_0x3f4e6a['isEmpty']()?0x1:_0x3f4e6a===jt?-0x1:0x0;}['withIndex'](_0x12b2c6){if(_0x12b2c6===De||this['indexMap_']['hasIndex'](_0x12b2c6))return this;{const _0x1ebd56=this['indexMap_']['addIndex'](_0x12b2c6,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1ebd56);}}['isIndexed'](_0xd2e2d4){return _0xd2e2d4===De||this['indexMap_']['hasIndex'](_0xd2e2d4);}['equals'](_0x163f8d){if(_0x163f8d===this)return!0x0;if(_0x163f8d['isLeafNode']())return!0x1;{const _0x4b758e=_0x163f8d;if(this['getPriority']()['equals'](_0x4b758e['getPriority']())){if(this['children_']['count']()===_0x4b758e['children_']['count']()){const _0x9c00e1=this['getIterator'](R),_0x3d880d=_0x4b758e['getIterator'](R);let _0x25260b=_0x9c00e1['getNext'](),_0x2715ef=_0x3d880d['getNext']();for(;_0x25260b&&_0x2715ef;){if(_0x25260b['name']!==_0x2715ef['name']||!_0x25260b['node']['equals'](_0x2715ef['node']))return!0x1;_0x25260b=_0x9c00e1['getNext'](),_0x2715ef=_0x3d880d['getNext']();}return _0x25260b===null&&_0x2715ef===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2bdf0e){return _0x2bdf0e===De?null:this['indexMap_']['get'](_0x2bdf0e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Wh extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3fc299){return _0x3fc299===this?0x0:0x1;}['equals'](_0x19cbca){return _0x19cbca===this;}['getPriority'](){return this;}['getImmediateChild'](_0x384b85){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const jt=new Wh();Object['defineProperties'](E,{'MIN':{'value':new E(Ue,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,jt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Dh(jt),Lh(jt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bh=!0x0;function A(_0x5b73e5,_0x163789=null){if(_0x5b73e5===null)return g['EMPTY_NODE'];if(typeof _0x5b73e5=='object'&&'.priority'in _0x5b73e5&&(_0x163789=_0x5b73e5['.priority']),f(_0x163789===null||typeof _0x163789=='string'||typeof _0x163789=='number'||typeof _0x163789=='object'&&'.sv'in _0x163789,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x163789),typeof _0x5b73e5=='object'&&'.value'in _0x5b73e5&&_0x5b73e5['.value']!==null&&(_0x5b73e5=_0x5b73e5['.value']),typeof _0x5b73e5!='object'||'.sv'in _0x5b73e5){const _0x4b09e2=_0x5b73e5;return new D(_0x4b09e2,A(_0x163789));}if(!(_0x5b73e5 instanceof Array)&&Bh){const _0x2a69c1=[];let _0x11a2bc=!0x1;if(x(_0x5b73e5,(_0x5956c6,_0x21bf6c)=>{if(_0x5956c6['substring'](0x0,0x1)!=='.'){const _0x1ff708=A(_0x21bf6c);_0x1ff708['isEmpty']()||(_0x11a2bc=_0x11a2bc||!_0x1ff708['getPriority']()['isEmpty'](),_0x2a69c1['push'](new E(_0x5956c6,_0x1ff708)));}}),_0x2a69c1['length']===0x0)return g['EMPTY_NODE'];const _0xe8d058=mn(_0x2a69c1,Oh,_0xea2a5f=>_0xea2a5f['name'],Yi);if(_0x11a2bc){const _0x588ab5=mn(_0x2a69c1,R['getCompare']());return new g(_0xe8d058,A(_0x163789),new te({'.priority':_0x588ab5},{'.priority':R}));}else return new g(_0xe8d058,A(_0x163789),te['Default']);}else{let _0x35d170=g['EMPTY_NODE'];return x(_0x5b73e5,(_0x44f4ca,_0x233b8a)=>{if(Q(_0x5b73e5,_0x44f4ca)&&_0x44f4ca['substring'](0x0,0x1)!=='.'){const _0x1b73a5=A(_0x233b8a);(_0x1b73a5['isLeafNode']()||!_0x1b73a5['isEmpty']())&&(_0x35d170=_0x35d170['updateImmediateChild'](_0x44f4ca,_0x1b73a5));}}),_0x35d170['updatePriority'](A(_0x163789));}}Mh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends xn{constructor(_0x403996){super(),this['indexPath_']=_0x403996,f(!v(_0x403996)&&y(_0x403996)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1e578e){return _0x1e578e['getChild'](this['indexPath_']);}['isDefinedOn'](_0x50f577){return!_0x50f577['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x33cc2b,_0x568c74){const _0x3513cb=this['extractChild'](_0x33cc2b['node']),_0x52bc58=this['extractChild'](_0x568c74['node']),_0x2bb017=_0x3513cb['compareTo'](_0x52bc58);return _0x2bb017===0x0?Ge(_0x33cc2b['name'],_0x568c74['name']):_0x2bb017;}['makePost'](_0x5e4817,_0x3a8ca0){const _0x10e7cc=A(_0x5e4817),_0x354e07=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x10e7cc);return new E(_0x3a8ca0,_0x354e07);}['maxPost'](){const _0x3b7a59=g['EMPTY_NODE']['updateChild'](this['indexPath_'],jt);return new E(Ie,_0x3b7a59);}['toString'](){return Dt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vh extends xn{['compare'](_0x59e04f,_0x449607){const _0xa132a9=_0x59e04f['node']['compareTo'](_0x449607['node']);return _0xa132a9===0x0?Ge(_0x59e04f['name'],_0x449607['name']):_0xa132a9;}['isDefinedOn'](_0x27efa3){return!0x0;}['indexedValueChanged'](_0x60e512,_0x21423a){return!_0x60e512['equals'](_0x21423a);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2841ad,_0x5ec916){const _0x128284=A(_0x2841ad);return new E(_0x5ec916,_0x128284);}['toString'](){return'.value';}}const Mo=new Vh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x3c337f){return{'type':'value','snapshotNode':_0x3c337f};}function st(_0x34cbaf,_0x28623a){return{'type':'child_added','snapshotNode':_0x28623a,'childName':_0x34cbaf};}function Mt(_0x2d59d6,_0x219e7a){return{'type':'child_removed','snapshotNode':_0x219e7a,'childName':_0x2d59d6};}function Lt(_0xefba66,_0x375c21,_0x3e4f34){return{'type':'child_changed','snapshotNode':_0x375c21,'childName':_0xefba66,'oldSnap':_0x3e4f34};}function Hh(_0xc7637a,_0x5d1149){return{'type':'child_moved','snapshotNode':_0x5d1149,'childName':_0xc7637a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x4e587c){this['index_']=_0x4e587c;}['updateChild'](_0x5b5110,_0x5ee47a,_0x2dc51b,_0x57b68d,_0x38a737,_0x2ec57f){f(_0x5b5110['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2ed67a=_0x5b5110['getImmediateChild'](_0x5ee47a);return _0x2ed67a['getChild'](_0x57b68d)['equals'](_0x2dc51b['getChild'](_0x57b68d))&&_0x2ed67a['isEmpty']()===_0x2dc51b['isEmpty']()||(_0x2ec57f!=null&&(_0x2dc51b['isEmpty']()?_0x5b5110['hasChild'](_0x5ee47a)?_0x2ec57f['trackChildChange'](Mt(_0x5ee47a,_0x2ed67a)):f(_0x5b5110['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2ed67a['isEmpty']()?_0x2ec57f['trackChildChange'](st(_0x5ee47a,_0x2dc51b)):_0x2ec57f['trackChildChange'](Lt(_0x5ee47a,_0x2dc51b,_0x2ed67a))),_0x5b5110['isLeafNode']()&&_0x2dc51b['isEmpty']())?_0x5b5110:_0x5b5110['updateImmediateChild'](_0x5ee47a,_0x2dc51b)['withIndex'](this['index_']);}['updateFullNode'](_0x2667cd,_0x249aef,_0x47b897){return _0x47b897!=null&&(_0x2667cd['isLeafNode']()||_0x2667cd['forEachChild'](R,(_0x50b45e,_0x2d2697)=>{_0x249aef['hasChild'](_0x50b45e)||_0x47b897['trackChildChange'](Mt(_0x50b45e,_0x2d2697));}),_0x249aef['isLeafNode']()||_0x249aef['forEachChild'](R,(_0x1657f5,_0x216e71)=>{if(_0x2667cd['hasChild'](_0x1657f5)){const _0xa138a3=_0x2667cd['getImmediateChild'](_0x1657f5);_0xa138a3['equals'](_0x216e71)||_0x47b897['trackChildChange'](Lt(_0x1657f5,_0x216e71,_0xa138a3));}else _0x47b897['trackChildChange'](st(_0x1657f5,_0x216e71));})),_0x249aef['withIndex'](this['index_']);}['updatePriority'](_0x5bf5a5,_0x125551){return _0x5bf5a5['isEmpty']()?g['EMPTY_NODE']:_0x5bf5a5['updatePriority'](_0x125551);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xt{constructor(_0x185f41){this['indexedFilter_']=new Ji(_0x185f41['getIndex']()),this['index_']=_0x185f41['getIndex'](),this['startPost_']=xt['getStartPost_'](_0x185f41),this['endPost_']=xt['getEndPost_'](_0x185f41),this['startIsInclusive_']=!_0x185f41['startAfterSet_'],this['endIsInclusive_']=!_0x185f41['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4f1eb4){const _0x2cfaeb=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4f1eb4)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4f1eb4)<0x0,_0x418684=this['endIsInclusive_']?this['index_']['compare'](_0x4f1eb4,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4f1eb4,this['getEndPost']())<0x0;return _0x2cfaeb&&_0x418684;}['updateChild'](_0x3bc8ea,_0xfaf11a,_0x5bbb2d,_0x55a2ec,_0x442449,_0x5abd57){return this['matches'](new E(_0xfaf11a,_0x5bbb2d))||(_0x5bbb2d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3bc8ea,_0xfaf11a,_0x5bbb2d,_0x55a2ec,_0x442449,_0x5abd57);}['updateFullNode'](_0x49c85b,_0x159ec4,_0x37e1dd){_0x159ec4['isLeafNode']()&&(_0x159ec4=g['EMPTY_NODE']);let _0x5174fe=_0x159ec4['withIndex'](this['index_']);_0x5174fe=_0x5174fe['updatePriority'](g['EMPTY_NODE']);const _0x276c99=this;return _0x159ec4['forEachChild'](R,(_0x1ab3e1,_0x180568)=>{_0x276c99['matches'](new E(_0x1ab3e1,_0x180568))||(_0x5174fe=_0x5174fe['updateImmediateChild'](_0x1ab3e1,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x49c85b,_0x5174fe,_0x37e1dd);}['updatePriority'](_0x3028c3,_0x465820){return _0x3028c3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x215064){if(_0x215064['hasStart']()){const _0x3e1992=_0x215064['getIndexStartName']();return _0x215064['getIndex']()['makePost'](_0x215064['getIndexStartValue'](),_0x3e1992);}else return _0x215064['getIndex']()['minPost']();}static['getEndPost_'](_0x3a1208){if(_0x3a1208['hasEnd']()){const _0x396a87=_0x3a1208['getIndexEndName']();return _0x3a1208['getIndex']()['makePost'](_0x3a1208['getIndexEndValue'](),_0x396a87);}else return _0x3a1208['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $h{constructor(_0x52b101){this['withinDirectionalStart']=_0x188309=>this['reverse_']?this['withinEndPost'](_0x188309):this['withinStartPost'](_0x188309),this['withinDirectionalEnd']=_0x3d0c63=>this['reverse_']?this['withinStartPost'](_0x3d0c63):this['withinEndPost'](_0x3d0c63),this['withinStartPost']=_0x3b95c8=>{const _0x20115b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x3b95c8);return this['startIsInclusive_']?_0x20115b<=0x0:_0x20115b<0x0;},this['withinEndPost']=_0x2790d3=>{const _0x2c5e00=this['index_']['compare'](_0x2790d3,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2c5e00<=0x0:_0x2c5e00<0x0;},this['rangedFilter_']=new xt(_0x52b101),this['index_']=_0x52b101['getIndex'](),this['limit_']=_0x52b101['getLimit'](),this['reverse_']=!_0x52b101['isViewFromLeft'](),this['startIsInclusive_']=!_0x52b101['startAfterSet_'],this['endIsInclusive_']=!_0x52b101['endBeforeSet_'];}['updateChild'](_0x56447c,_0x241eea,_0x520bba,_0x153759,_0x450cff,_0x45b719){return this['rangedFilter_']['matches'](new E(_0x241eea,_0x520bba))||(_0x520bba=g['EMPTY_NODE']),_0x56447c['getImmediateChild'](_0x241eea)['equals'](_0x520bba)?_0x56447c:_0x56447c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x56447c,_0x241eea,_0x520bba,_0x153759,_0x450cff,_0x45b719):this['fullLimitUpdateChild_'](_0x56447c,_0x241eea,_0x520bba,_0x450cff,_0x45b719);}['updateFullNode'](_0x4f7800,_0x2b51f5,_0x37660b){let _0x413806;if(_0x2b51f5['isLeafNode']()||_0x2b51f5['isEmpty']())_0x413806=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x2b51f5['numChildren']()&&_0x2b51f5['isIndexed'](this['index_'])){_0x413806=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x4ba641;this['reverse_']?_0x4ba641=_0x2b51f5['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x4ba641=_0x2b51f5['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x48b2a5=0x0;for(;_0x4ba641['hasNext']()&&_0x48b2a5<this['limit_'];){const _0x5300da=_0x4ba641['getNext']();if(this['withinDirectionalStart'](_0x5300da)){if(this['withinDirectionalEnd'](_0x5300da))_0x413806=_0x413806['updateImmediateChild'](_0x5300da['name'],_0x5300da['node']),_0x48b2a5++;else break;}else continue;}}else{_0x413806=_0x2b51f5['withIndex'](this['index_']),_0x413806=_0x413806['updatePriority'](g['EMPTY_NODE']);let _0x243951;this['reverse_']?_0x243951=_0x413806['getReverseIterator'](this['index_']):_0x243951=_0x413806['getIterator'](this['index_']);let _0x417050=0x0;for(;_0x243951['hasNext']();){const _0x425f79=_0x243951['getNext']();_0x417050<this['limit_']&&this['withinDirectionalStart'](_0x425f79)&&this['withinDirectionalEnd'](_0x425f79)?_0x417050++:_0x413806=_0x413806['updateImmediateChild'](_0x425f79['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4f7800,_0x413806,_0x37660b);}['updatePriority'](_0x1e176a,_0x768830){return _0x1e176a;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3afa19,_0x1a4cf5,_0xfcee25,_0x2a7a68,_0x5d9c1f){let _0x5c5673;if(this['reverse_']){const _0x1c22c0=this['index_']['getCompare']();_0x5c5673=(_0x2f078e,_0xc19bd9)=>_0x1c22c0(_0xc19bd9,_0x2f078e);}else _0x5c5673=this['index_']['getCompare']();const _0x572674=_0x3afa19;f(_0x572674['numChildren']()===this['limit_'],'');const _0x3be897=new E(_0x1a4cf5,_0xfcee25),_0x52e69a=this['reverse_']?_0x572674['getFirstChild'](this['index_']):_0x572674['getLastChild'](this['index_']),_0xdcf7b8=this['rangedFilter_']['matches'](_0x3be897);if(_0x572674['hasChild'](_0x1a4cf5)){const _0x544b30=_0x572674['getImmediateChild'](_0x1a4cf5);let _0x18552c=_0x2a7a68['getChildAfterChild'](this['index_'],_0x52e69a,this['reverse_']);for(;_0x18552c!=null&&(_0x18552c['name']===_0x1a4cf5||_0x572674['hasChild'](_0x18552c['name']));)_0x18552c=_0x2a7a68['getChildAfterChild'](this['index_'],_0x18552c,this['reverse_']);const _0x4d1aa5=_0x18552c==null?0x1:_0x5c5673(_0x18552c,_0x3be897);if(_0xdcf7b8&&!_0xfcee25['isEmpty']()&&_0x4d1aa5>=0x0)return _0x5d9c1f!=null&&_0x5d9c1f['trackChildChange'](Lt(_0x1a4cf5,_0xfcee25,_0x544b30)),_0x572674['updateImmediateChild'](_0x1a4cf5,_0xfcee25);{_0x5d9c1f!=null&&_0x5d9c1f['trackChildChange'](Mt(_0x1a4cf5,_0x544b30));const _0x5a9e71=_0x572674['updateImmediateChild'](_0x1a4cf5,g['EMPTY_NODE']);return _0x18552c!=null&&this['rangedFilter_']['matches'](_0x18552c)?(_0x5d9c1f!=null&&_0x5d9c1f['trackChildChange'](st(_0x18552c['name'],_0x18552c['node'])),_0x5a9e71['updateImmediateChild'](_0x18552c['name'],_0x18552c['node'])):_0x5a9e71;}}else return _0xfcee25['isEmpty']()?_0x3afa19:_0xdcf7b8&&_0x5c5673(_0x52e69a,_0x3be897)>=0x0?(_0x5d9c1f!=null&&(_0x5d9c1f['trackChildChange'](Mt(_0x52e69a['name'],_0x52e69a['node'])),_0x5d9c1f['trackChildChange'](st(_0x1a4cf5,_0xfcee25))),_0x572674['updateImmediateChild'](_0x1a4cf5,_0xfcee25)['updateImmediateChild'](_0x52e69a['name'],g['EMPTY_NODE'])):_0x3afa19;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Ue;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x2ef76b=new Xi();return _0x2ef76b['limitSet_']=this['limitSet_'],_0x2ef76b['limit_']=this['limit_'],_0x2ef76b['startSet_']=this['startSet_'],_0x2ef76b['startAfterSet_']=this['startAfterSet_'],_0x2ef76b['indexStartValue_']=this['indexStartValue_'],_0x2ef76b['startNameSet_']=this['startNameSet_'],_0x2ef76b['indexStartName_']=this['indexStartName_'],_0x2ef76b['endSet_']=this['endSet_'],_0x2ef76b['endBeforeSet_']=this['endBeforeSet_'],_0x2ef76b['indexEndValue_']=this['indexEndValue_'],_0x2ef76b['endNameSet_']=this['endNameSet_'],_0x2ef76b['indexEndName_']=this['indexEndName_'],_0x2ef76b['index_']=this['index_'],_0x2ef76b['viewFrom_']=this['viewFrom_'],_0x2ef76b;}}function Gh(_0x50aa38){return _0x50aa38['loadsAllData']()?new Ji(_0x50aa38['getIndex']()):_0x50aa38['hasLimit']()?new $h(_0x50aa38):new xt(_0x50aa38);}function qh(_0x2f49fe,_0x3c373f,_0x486b91){const _0x3f3113=_0x2f49fe['copy']();return _0x3f3113['startSet_']=!0x0,_0x3c373f===void 0x0&&(_0x3c373f=null),_0x3f3113['indexStartValue_']=_0x3c373f,_0x486b91!=null?(_0x3f3113['startNameSet_']=!0x0,_0x3f3113['indexStartName_']=_0x486b91):(_0x3f3113['startNameSet_']=!0x1,_0x3f3113['indexStartName_']=''),_0x3f3113;}function zh(_0x26e91b,_0x17e0ed,_0x39612e){const _0xda72c6=_0x26e91b['copy']();return _0xda72c6['endSet_']=!0x0,_0x17e0ed===void 0x0&&(_0x17e0ed=null),_0xda72c6['indexEndValue_']=_0x17e0ed,_0x39612e!==void 0x0?(_0xda72c6['endNameSet_']=!0x0,_0xda72c6['indexEndName_']=_0x39612e):(_0xda72c6['endNameSet_']=!0x1,_0xda72c6['indexEndName_']=''),_0xda72c6;}function jh(_0x5adbea,_0x309d31){const _0x44fee4=_0x5adbea['copy']();return _0x44fee4['index_']=_0x309d31,_0x44fee4;}function ir(_0x4da0bd){const _0x68d720={};if(_0x4da0bd['isDefault']())return _0x68d720;let _0x1583ad;if(_0x4da0bd['index_']===R?_0x1583ad='$priority':_0x4da0bd['index_']===Mo?_0x1583ad='$value':_0x4da0bd['index_']===De?_0x1583ad='$key':(f(_0x4da0bd['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x1583ad=_0x4da0bd['index_']['toString']()),_0x68d720['orderBy']=O(_0x1583ad),_0x4da0bd['startSet_']){const _0x5a3f33=_0x4da0bd['startAfterSet_']?'startAfter':'startAt';_0x68d720[_0x5a3f33]=O(_0x4da0bd['indexStartValue_']),_0x4da0bd['startNameSet_']&&(_0x68d720[_0x5a3f33]+=','+O(_0x4da0bd['indexStartName_']));}if(_0x4da0bd['endSet_']){const _0xb07a47=_0x4da0bd['endBeforeSet_']?'endBefore':'endAt';_0x68d720[_0xb07a47]=O(_0x4da0bd['indexEndValue_']),_0x4da0bd['endNameSet_']&&(_0x68d720[_0xb07a47]+=','+O(_0x4da0bd['indexEndName_']));}return _0x4da0bd['limitSet_']&&(_0x4da0bd['isViewFromLeft']()?_0x68d720['limitToFirst']=_0x4da0bd['limit_']:_0x68d720['limitToLast']=_0x4da0bd['limit_']),_0x68d720;}function sr(_0x5d1a5d){const _0x2aac12={};if(_0x5d1a5d['startSet_']&&(_0x2aac12['sp']=_0x5d1a5d['indexStartValue_'],_0x5d1a5d['startNameSet_']&&(_0x2aac12['sn']=_0x5d1a5d['indexStartName_']),_0x2aac12['sin']=!_0x5d1a5d['startAfterSet_']),_0x5d1a5d['endSet_']&&(_0x2aac12['ep']=_0x5d1a5d['indexEndValue_'],_0x5d1a5d['endNameSet_']&&(_0x2aac12['en']=_0x5d1a5d['indexEndName_']),_0x2aac12['ein']=!_0x5d1a5d['endBeforeSet_']),_0x5d1a5d['limitSet_']){_0x2aac12['l']=_0x5d1a5d['limit_'];let _0x4b4926=_0x5d1a5d['viewFrom_'];_0x4b4926===''&&(_0x5d1a5d['isViewFromLeft']()?_0x4b4926='l':_0x4b4926='r'),_0x2aac12['vf']=_0x4b4926;}return _0x5d1a5d['index_']!==R&&(_0x2aac12['i']=_0x5d1a5d['index_']['toString']()),_0x2aac12;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yn extends So{['reportStats'](_0x5c05af){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xcbe8a5,_0x1a593f){return _0x1a593f!==void 0x0?'tag$'+_0x1a593f:(f(_0xcbe8a5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xcbe8a5['_path']['toString']());}constructor(_0x816dcd,_0x628f06,_0x1752e,_0xcd66e6){super(),this['repoInfo_']=_0x816dcd,this['onDataUpdate_']=_0x628f06,this['authTokenProvider_']=_0x1752e,this['appCheckTokenProvider_']=_0xcd66e6,this['log_']=zt('p:rest:'),this['listens_']={};}['listen'](_0x3b63e4,_0x7e1dab,_0x26797f,_0x598988){const _0x2a88c8=_0x3b63e4['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2a88c8+'\x20'+_0x3b63e4['_queryIdentifier']);const _0x59abfe=yn['getListenId_'](_0x3b63e4,_0x26797f),_0x1ef25f={};this['listens_'][_0x59abfe]=_0x1ef25f;const _0x5c6e2d=ir(_0x3b63e4['_queryParams']);this['restRequest_'](_0x2a88c8+'.json',_0x5c6e2d,(_0x3dc37f,_0x212e64)=>{let _0x5d9ff5=_0x212e64;if(_0x3dc37f===0x194&&(_0x5d9ff5=null,_0x3dc37f=null),_0x3dc37f===null&&this['onDataUpdate_'](_0x2a88c8,_0x5d9ff5,!0x1,_0x26797f),Me(this['listens_'],_0x59abfe)===_0x1ef25f){let _0x230592;_0x3dc37f?_0x3dc37f===0x191?_0x230592='permission_denied':_0x230592='rest_error:'+_0x3dc37f:_0x230592='ok',_0x598988(_0x230592,null);}});}['unlisten'](_0x6c3f03,_0x59de25){const _0xd77b35=yn['getListenId_'](_0x6c3f03,_0x59de25);delete this['listens_'][_0xd77b35];}['get'](_0x1e572d){const _0x503a84=ir(_0x1e572d['_queryParams']),_0x2e3814=_0x1e572d['_path']['toString'](),_0x328dcc=new H();return this['restRequest_'](_0x2e3814+'.json',_0x503a84,(_0x3d9b5d,_0x3630b6)=>{let _0x45c28d=_0x3630b6;_0x3d9b5d===0x194&&(_0x45c28d=null,_0x3d9b5d=null),_0x3d9b5d===null?(this['onDataUpdate_'](_0x2e3814,_0x45c28d,!0x1,null),_0x328dcc['resolve'](_0x45c28d)):_0x328dcc['reject'](new Error(_0x45c28d));}),_0x328dcc['promise'];}['refreshAuthToken'](_0x303180){}['restRequest_'](_0x4f3423,_0x1134e5={},_0x4e3863){return _0x1134e5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2d86b6,_0x3ec556])=>{_0x2d86b6&&_0x2d86b6['accessToken']&&(_0x1134e5['auth']=_0x2d86b6['accessToken']),_0x3ec556&&_0x3ec556['token']&&(_0x1134e5['ac']=_0x3ec556['token']);const _0x17b74b=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x4f3423+'?ns='+this['repoInfo_']['namespace']+ht(_0x1134e5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x17b74b);const _0x2d640f=new XMLHttpRequest();_0x2d640f['onreadystatechange']=()=>{if(_0x4e3863&&_0x2d640f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x17b74b+'\x20received.\x20status:',_0x2d640f['status'],'response:',_0x2d640f['responseText']);let _0x1ac0c7=null;if(_0x2d640f['status']>=0xc8&&_0x2d640f['status']<0x12c){try{_0x1ac0c7=Nt(_0x2d640f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x17b74b+':\x20'+_0x2d640f['responseText']);}_0x4e3863(null,_0x1ac0c7);}else _0x2d640f['status']!==0x191&&_0x2d640f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x17b74b+'\x20Status:\x20'+_0x2d640f['status']),_0x4e3863(_0x2d640f['status']);_0x4e3863=null;}},_0x2d640f['open']('GET',_0x17b74b,!0x0),_0x2d640f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x34ef25){return this['rootNode_']['getChild'](_0x34ef25);}['updateSnapshot'](_0x43bbea,_0x121bc9){this['rootNode_']=this['rootNode_']['updateChild'](_0x43bbea,_0x121bc9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function vn(){return{'value':null,'children':new Map()};}function ft(_0x12221c,_0x119065,_0x4424ab){if(v(_0x119065))_0x12221c['value']=_0x4424ab,_0x12221c['children']['clear']();else{if(_0x12221c['value']!==null)_0x12221c['value']=_0x12221c['value']['updateChild'](_0x119065,_0x4424ab);else{const _0x5d1ad4=y(_0x119065);_0x12221c['children']['has'](_0x5d1ad4)||_0x12221c['children']['set'](_0x5d1ad4,vn());const _0x7e6602=_0x12221c['children']['get'](_0x5d1ad4);_0x119065=S(_0x119065),ft(_0x7e6602,_0x119065,_0x4424ab);}}}function Ci(_0x1fd1d3,_0x3bc7a3){if(v(_0x3bc7a3))return _0x1fd1d3['value']=null,_0x1fd1d3['children']['clear'](),!0x0;if(_0x1fd1d3['value']!==null){if(_0x1fd1d3['value']['isLeafNode']())return!0x1;{const _0x1933f9=_0x1fd1d3['value'];return _0x1fd1d3['value']=null,_0x1933f9['forEachChild'](R,(_0x36132d,_0x240f60)=>{ft(_0x1fd1d3,new C(_0x36132d),_0x240f60);}),Ci(_0x1fd1d3,_0x3bc7a3);}}else{if(_0x1fd1d3['children']['size']>0x0){const _0x3cc958=y(_0x3bc7a3);return _0x3bc7a3=S(_0x3bc7a3),_0x1fd1d3['children']['has'](_0x3cc958)&&Ci(_0x1fd1d3['children']['get'](_0x3cc958),_0x3bc7a3)&&_0x1fd1d3['children']['delete'](_0x3cc958),_0x1fd1d3['children']['size']===0x0;}else return!0x0;}}function Ti(_0x32539b,_0x2a1a28,_0x27b3ac){_0x32539b['value']!==null?_0x27b3ac(_0x2a1a28,_0x32539b['value']):Yh(_0x32539b,(_0x383188,_0x1cc6ce)=>{const _0x487ea7=new C(_0x2a1a28['toString']()+'/'+_0x383188);Ti(_0x1cc6ce,_0x487ea7,_0x27b3ac);});}function Yh(_0x5d7f9d,_0x592177){_0x5d7f9d['children']['forEach']((_0x3a88f2,_0x546888)=>{_0x592177(_0x546888,_0x3a88f2);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qh{constructor(_0x55ed58){this['collection_']=_0x55ed58,this['last_']=null;}['get'](){const _0x1746bb=this['collection_']['get'](),_0x3f9795={..._0x1746bb};return this['last_']&&x(this['last_'],(_0x52eb2c,_0x6b1d80)=>{_0x3f9795[_0x52eb2c]=_0x3f9795[_0x52eb2c]-_0x6b1d80;}),this['last_']=_0x1746bb,_0x3f9795;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,Jh=0x1e*0x3e8,Xh=0x12c*0x3e8;class Zh{constructor(_0x30d62a,_0x4f2651){this['server_']=_0x4f2651,this['statsToReport_']={},this['statsListener_']=new Qh(_0x30d62a);const _0x5e8225=rr+(Jh-rr)*Math['random']();St(this['reportStats_']['bind'](this),Math['floor'](_0x5e8225));}['reportStats_'](){const _0x2d7feb=this['statsListener_']['get'](),_0x5100b7={};let _0x3c5d79=!0x1;x(_0x2d7feb,(_0x11fa73,_0x128a37)=>{_0x128a37>0x0&&Q(this['statsToReport_'],_0x11fa73)&&(_0x5100b7[_0x11fa73]=_0x128a37,_0x3c5d79=!0x0);}),_0x3c5d79&&this['server_']['reportStats'](_0x5100b7),St(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Xh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xd12277){_0xd12277[_0xd12277['OVERWRITE']=0x0]='OVERWRITE',_0xd12277[_0xd12277['MERGE']=0x1]='MERGE',_0xd12277[_0xd12277['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xd12277[_0xd12277['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x426524){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x426524,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class En{constructor(_0x2a095c,_0x16cb71,_0x21467){this['path']=_0x2a095c,this['affectedTree']=_0x16cb71,this['revert']=_0x21467,this['type']=z['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2a4833){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xa6a7e1=this['affectedTree']['subtree'](new C(_0x2a4833));return new En(w(),_0xa6a7e1,this['revert']);}}else return f(y(this['path'])===_0x2a4833,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new En(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x44ff4c,_0x4dd4fe){this['source']=_0x44ff4c,this['path']=_0x4dd4fe,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x50512d){return v(this['path'])?new Ft(this['source'],w()):new Ft(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class We{constructor(_0x10869c,_0x29f6b7,_0x448753){this['source']=_0x10869c,this['path']=_0x29f6b7,this['snap']=_0x448753,this['type']=z['OVERWRITE'];}['operationForChild'](_0x351a5b){return v(this['path'])?new We(this['source'],w(),this['snap']['getImmediateChild'](_0x351a5b)):new We(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rt{constructor(_0x2c7052,_0x19bdca,_0x424d0b){this['source']=_0x2c7052,this['path']=_0x19bdca,this['children']=_0x424d0b,this['type']=z['MERGE'];}['operationForChild'](_0x2d8977){if(v(this['path'])){const _0x16ebaf=this['children']['subtree'](new C(_0x2d8977));return _0x16ebaf['isEmpty']()?null:_0x16ebaf['value']?new We(this['source'],w(),_0x16ebaf['value']):new rt(this['source'],w(),_0x16ebaf);}else return f(y(this['path'])===_0x2d8977,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new rt(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x10e1eb,_0x3e3384,_0x2da2bd){this['node_']=_0x10e1eb,this['fullyInitialized_']=_0x3e3384,this['filtered_']=_0x2da2bd;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x60c6ba){if(v(_0x60c6ba))return this['isFullyInitialized']()&&!this['filtered_'];const _0xb9a973=y(_0x60c6ba);return this['isCompleteForChild'](_0xb9a973);}['isCompleteForChild'](_0x1ebbaf){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1ebbaf);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1f4651){this['query_']=_0x1f4651,this['index_']=this['query_']['_queryParams']['getIndex']();}}function tu(_0x4a1c82,_0x3e9117,_0x2b793e,_0x8a5546){const _0x454bdc=[],_0x13917e=[];return _0x3e9117['forEach'](_0x6c44c0=>{_0x6c44c0['type']==='child_changed'&&_0x4a1c82['index_']['indexedValueChanged'](_0x6c44c0['oldSnap'],_0x6c44c0['snapshotNode'])&&_0x13917e['push'](Hh(_0x6c44c0['childName'],_0x6c44c0['snapshotNode']));}),It(_0x4a1c82,_0x454bdc,'child_removed',_0x3e9117,_0x8a5546,_0x2b793e),It(_0x4a1c82,_0x454bdc,'child_added',_0x3e9117,_0x8a5546,_0x2b793e),It(_0x4a1c82,_0x454bdc,'child_moved',_0x13917e,_0x8a5546,_0x2b793e),It(_0x4a1c82,_0x454bdc,'child_changed',_0x3e9117,_0x8a5546,_0x2b793e),It(_0x4a1c82,_0x454bdc,'value',_0x3e9117,_0x8a5546,_0x2b793e),_0x454bdc;}function It(_0x49faaf,_0x562592,_0x592437,_0x5eebea,_0x3c5e43,_0x328108){const _0x5cdd40=_0x5eebea['filter'](_0x325789=>_0x325789['type']===_0x592437);_0x5cdd40['sort']((_0x19f03e,_0x11cbf6)=>iu(_0x49faaf,_0x19f03e,_0x11cbf6)),_0x5cdd40['forEach'](_0x28eb2f=>{const _0x4dcf2a=nu(_0x49faaf,_0x28eb2f,_0x328108);_0x3c5e43['forEach'](_0x3d1917=>{_0x3d1917['respondsTo'](_0x28eb2f['type'])&&_0x562592['push'](_0x3d1917['createEvent'](_0x4dcf2a,_0x49faaf['query_']));});});}function nu(_0x3a8192,_0x8f99ab,_0x51b4ff){return _0x8f99ab['type']==='value'||_0x8f99ab['type']==='child_removed'||(_0x8f99ab['prevName']=_0x51b4ff['getPredecessorChildName'](_0x8f99ab['childName'],_0x8f99ab['snapshotNode'],_0x3a8192['index_'])),_0x8f99ab;}function iu(_0x4923a8,_0x4aef5b,_0x5cb5d6){if(_0x4aef5b['childName']==null||_0x5cb5d6['childName']==null)throw lt('Should\x20only\x20compare\x20child_\x20events.');const _0x3b6f27=new E(_0x4aef5b['childName'],_0x4aef5b['snapshotNode']),_0x145522=new E(_0x5cb5d6['childName'],_0x5cb5d6['snapshotNode']);return _0x4923a8['index_']['compare'](_0x3b6f27,_0x145522);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Fn(_0x30548f,_0x428511){return{'eventCache':_0x30548f,'serverCache':_0x428511};}function bt(_0x13bbf3,_0x5abd75,_0x4a65eb,_0x35c0f3){return Fn(new Ce(_0x5abd75,_0x4a65eb,_0x35c0f3),_0x13bbf3['serverCache']);}function xo(_0x25b616,_0x531a6b,_0x3377a7,_0x40129d){return Fn(_0x25b616['eventCache'],new Ce(_0x531a6b,_0x3377a7,_0x40129d));}function In(_0x116554){return _0x116554['eventCache']['isFullyInitialized']()?_0x116554['eventCache']['getNode']():null;}function Be(_0x5d352a){return _0x5d352a['serverCache']['isFullyInitialized']()?_0x5d352a['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const su=()=>(li||(li=new B(Vl)),li);class b{static['fromObject'](_0x4c4f2b){let _0xbff66d=new b(null);return x(_0x4c4f2b,(_0xe01271,_0x467034)=>{_0xbff66d=_0xbff66d['set'](new C(_0xe01271),_0x467034);}),_0xbff66d;}constructor(_0x272aa0,_0x38171c=su()){this['value']=_0x272aa0,this['children']=_0x38171c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x340787,_0x30e0f5){if(this['value']!=null&&_0x30e0f5(this['value']))return{'path':w(),'value':this['value']};if(v(_0x340787))return null;{const _0x558ed9=y(_0x340787),_0x47bad9=this['children']['get'](_0x558ed9);if(_0x47bad9!==null){const _0x3066b4=_0x47bad9['findRootMostMatchingPathAndValue'](S(_0x340787),_0x30e0f5);return _0x3066b4!=null?{'path':k(new C(_0x558ed9),_0x3066b4['path']),'value':_0x3066b4['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x11efa6){return this['findRootMostMatchingPathAndValue'](_0x11efa6,()=>!0x0);}['subtree'](_0x2e3883){if(v(_0x2e3883))return this;{const _0x34699d=y(_0x2e3883),_0x6eb82e=this['children']['get'](_0x34699d);return _0x6eb82e!==null?_0x6eb82e['subtree'](S(_0x2e3883)):new b(null);}}['set'](_0x101b6c,_0x5dd37f){if(v(_0x101b6c))return new b(_0x5dd37f,this['children']);{const _0x2c18f1=y(_0x101b6c),_0x47fbd6=(this['children']['get'](_0x2c18f1)||new b(null))['set'](S(_0x101b6c),_0x5dd37f),_0x11b154=this['children']['insert'](_0x2c18f1,_0x47fbd6);return new b(this['value'],_0x11b154);}}['remove'](_0x3a1e59){if(v(_0x3a1e59))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x16d6a7=y(_0x3a1e59),_0xcc0b85=this['children']['get'](_0x16d6a7);if(_0xcc0b85){const _0x1543fe=_0xcc0b85['remove'](S(_0x3a1e59));let _0x1618f8;return _0x1543fe['isEmpty']()?_0x1618f8=this['children']['remove'](_0x16d6a7):_0x1618f8=this['children']['insert'](_0x16d6a7,_0x1543fe),this['value']===null&&_0x1618f8['isEmpty']()?new b(null):new b(this['value'],_0x1618f8);}else return this;}}['get'](_0x598dff){if(v(_0x598dff))return this['value'];{const _0x47077b=y(_0x598dff),_0x14a6d5=this['children']['get'](_0x47077b);return _0x14a6d5?_0x14a6d5['get'](S(_0x598dff)):null;}}['setTree'](_0x327313,_0x139147){if(v(_0x327313))return _0x139147;{const _0x308b58=y(_0x327313),_0x476d72=(this['children']['get'](_0x308b58)||new b(null))['setTree'](S(_0x327313),_0x139147);let _0xb91f2;return _0x476d72['isEmpty']()?_0xb91f2=this['children']['remove'](_0x308b58):_0xb91f2=this['children']['insert'](_0x308b58,_0x476d72),new b(this['value'],_0xb91f2);}}['fold'](_0x245efa){return this['fold_'](w(),_0x245efa);}['fold_'](_0x24275c,_0x9f523b){const _0x588d77={};return this['children']['inorderTraversal']((_0x110f1c,_0x5087d9)=>{_0x588d77[_0x110f1c]=_0x5087d9['fold_'](k(_0x24275c,_0x110f1c),_0x9f523b);}),_0x9f523b(_0x24275c,this['value'],_0x588d77);}['findOnPath'](_0x9ef9f,_0x34da4f){return this['findOnPath_'](_0x9ef9f,w(),_0x34da4f);}['findOnPath_'](_0x57027a,_0x59bfb0,_0x14fca3){const _0x2cd4cf=this['value']?_0x14fca3(_0x59bfb0,this['value']):!0x1;if(_0x2cd4cf)return _0x2cd4cf;if(v(_0x57027a))return null;{const _0x120d1a=y(_0x57027a),_0x447a32=this['children']['get'](_0x120d1a);return _0x447a32?_0x447a32['findOnPath_'](S(_0x57027a),k(_0x59bfb0,_0x120d1a),_0x14fca3):null;}}['foreachOnPath'](_0x638109,_0x265a09){return this['foreachOnPath_'](_0x638109,w(),_0x265a09);}['foreachOnPath_'](_0x59f76c,_0x1b4bea,_0x2fae6c){if(v(_0x59f76c))return this;{this['value']&&_0x2fae6c(_0x1b4bea,this['value']);const _0x502300=y(_0x59f76c),_0x5a57f5=this['children']['get'](_0x502300);return _0x5a57f5?_0x5a57f5['foreachOnPath_'](S(_0x59f76c),k(_0x1b4bea,_0x502300),_0x2fae6c):new b(null);}}['foreach'](_0xec63cb){this['foreach_'](w(),_0xec63cb);}['foreach_'](_0x5dc7cb,_0x2b7931){this['children']['inorderTraversal']((_0x36645b,_0x56552f)=>{_0x56552f['foreach_'](k(_0x5dc7cb,_0x36645b),_0x2b7931);}),this['value']&&_0x2b7931(_0x5dc7cb,this['value']);}['foreachChild'](_0x34f8cb){this['children']['inorderTraversal']((_0x434afd,_0x9c6307)=>{_0x9c6307['value']&&_0x34f8cb(_0x434afd,_0x9c6307['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x540309){this['writeTree_']=_0x540309;}static['empty'](){return new K(new b(null));}}function Rt(_0x584200,_0xf2b331,_0x52f01c){if(v(_0xf2b331))return new K(new b(_0x52f01c));{const _0x6db777=_0x584200['writeTree_']['findRootMostValueAndPath'](_0xf2b331);if(_0x6db777!=null){const _0x3d9638=_0x6db777['path'];let _0x26c2f6=_0x6db777['value'];const _0x3ff823=F(_0x3d9638,_0xf2b331);return _0x26c2f6=_0x26c2f6['updateChild'](_0x3ff823,_0x52f01c),new K(_0x584200['writeTree_']['set'](_0x3d9638,_0x26c2f6));}else{const _0x13bf3a=new b(_0x52f01c),_0x17303e=_0x584200['writeTree_']['setTree'](_0xf2b331,_0x13bf3a);return new K(_0x17303e);}}}function Si(_0x3f6746,_0x329496,_0x1c6d05){let _0x4492ee=_0x3f6746;return x(_0x1c6d05,(_0x543792,_0x9951e2)=>{_0x4492ee=Rt(_0x4492ee,k(_0x329496,_0x543792),_0x9951e2);}),_0x4492ee;}function or(_0x3973fb,_0x5ae37b){if(v(_0x5ae37b))return K['empty']();{const _0x593a05=_0x3973fb['writeTree_']['setTree'](_0x5ae37b,new b(null));return new K(_0x593a05);}}function bi(_0x479f9f,_0x5520f6){return qe(_0x479f9f,_0x5520f6)!=null;}function qe(_0x19a545,_0x15a015){const _0x1694a6=_0x19a545['writeTree_']['findRootMostValueAndPath'](_0x15a015);return _0x1694a6!=null?_0x19a545['writeTree_']['get'](_0x1694a6['path'])['getChild'](F(_0x1694a6['path'],_0x15a015)):null;}function ar(_0x55f917){const _0x4b4216=[],_0xb8d81a=_0x55f917['writeTree_']['value'];return _0xb8d81a!=null?_0xb8d81a['isLeafNode']()||_0xb8d81a['forEachChild'](R,(_0x215f9a,_0x46b831)=>{_0x4b4216['push'](new E(_0x215f9a,_0x46b831));}):_0x55f917['writeTree_']['children']['inorderTraversal']((_0x9a1676,_0x44525e)=>{_0x44525e['value']!=null&&_0x4b4216['push'](new E(_0x9a1676,_0x44525e['value']));}),_0x4b4216;}function ve(_0x3e0eef,_0x2ee800){if(v(_0x2ee800))return _0x3e0eef;{const _0x589643=qe(_0x3e0eef,_0x2ee800);return _0x589643!=null?new K(new b(_0x589643)):new K(_0x3e0eef['writeTree_']['subtree'](_0x2ee800));}}function Ri(_0x52d0bb){return _0x52d0bb['writeTree_']['isEmpty']();}function ot(_0x23ede2,_0x4e81d8){return Fo(w(),_0x23ede2['writeTree_'],_0x4e81d8);}function Fo(_0x49e804,_0x3e9030,_0x1c2462){if(_0x3e9030['value']!=null)return _0x1c2462['updateChild'](_0x49e804,_0x3e9030['value']);{let _0x273318=null;return _0x3e9030['children']['inorderTraversal']((_0x3adebc,_0x4ae507)=>{_0x3adebc==='.priority'?(f(_0x4ae507['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x273318=_0x4ae507['value']):_0x1c2462=Fo(k(_0x49e804,_0x3adebc),_0x4ae507,_0x1c2462);}),!_0x1c2462['getChild'](_0x49e804)['isEmpty']()&&_0x273318!==null&&(_0x1c2462=_0x1c2462['updateChild'](k(_0x49e804,'.priority'),_0x273318)),_0x1c2462;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x2a99e9,_0x2a9f81){return Vo(_0x2a9f81,_0x2a99e9);}function ru(_0x4a76b2,_0x3faad6,_0x44cdb4,_0x2f0473,_0x28a376){f(_0x2f0473>_0x4a76b2['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x28a376===void 0x0&&(_0x28a376=!0x0),_0x4a76b2['allWrites']['push']({'path':_0x3faad6,'snap':_0x44cdb4,'writeId':_0x2f0473,'visible':_0x28a376}),_0x28a376&&(_0x4a76b2['visibleWrites']=Rt(_0x4a76b2['visibleWrites'],_0x3faad6,_0x44cdb4)),_0x4a76b2['lastWriteId']=_0x2f0473;}function ou(_0x208767,_0xd008e3,_0x583f86,_0xd1ab0d){f(_0xd1ab0d>_0x208767['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x208767['allWrites']['push']({'path':_0xd008e3,'children':_0x583f86,'writeId':_0xd1ab0d,'visible':!0x0}),_0x208767['visibleWrites']=Si(_0x208767['visibleWrites'],_0xd008e3,_0x583f86),_0x208767['lastWriteId']=_0xd1ab0d;}function au(_0x3bd541,_0x1b8ae4){for(let _0x5ca31f=0x0;_0x5ca31f<_0x3bd541['allWrites']['length'];_0x5ca31f++){const _0x4a1104=_0x3bd541['allWrites'][_0x5ca31f];if(_0x4a1104['writeId']===_0x1b8ae4)return _0x4a1104;}return null;}function cu(_0x818c35,_0xab6b1){const _0x3fabbf=_0x818c35['allWrites']['findIndex'](_0x19b317=>_0x19b317['writeId']===_0xab6b1);f(_0x3fabbf>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xf38cd6=_0x818c35['allWrites'][_0x3fabbf];_0x818c35['allWrites']['splice'](_0x3fabbf,0x1);let _0x4c2bea=_0xf38cd6['visible'],_0x5053ff=!0x1,_0x883a36=_0x818c35['allWrites']['length']-0x1;for(;_0x4c2bea&&_0x883a36>=0x0;){const _0x141342=_0x818c35['allWrites'][_0x883a36];_0x141342['visible']&&(_0x883a36>=_0x3fabbf&&lu(_0x141342,_0xf38cd6['path'])?_0x4c2bea=!0x1:G(_0xf38cd6['path'],_0x141342['path'])&&(_0x5053ff=!0x0)),_0x883a36--;}if(_0x4c2bea){if(_0x5053ff)return hu(_0x818c35),!0x0;if(_0xf38cd6['snap'])_0x818c35['visibleWrites']=or(_0x818c35['visibleWrites'],_0xf38cd6['path']);else{const _0x150bfc=_0xf38cd6['children'];x(_0x150bfc,_0x18c0a5=>{_0x818c35['visibleWrites']=or(_0x818c35['visibleWrites'],k(_0xf38cd6['path'],_0x18c0a5));});}return!0x0;}else return!0x1;}function lu(_0x619943,_0x550512){if(_0x619943['snap'])return G(_0x619943['path'],_0x550512);for(const _0x3e50b3 in _0x619943['children'])if(_0x619943['children']['hasOwnProperty'](_0x3e50b3)&&G(k(_0x619943['path'],_0x3e50b3),_0x550512))return!0x0;return!0x1;}function hu(_0x22e37b){_0x22e37b['visibleWrites']=Uo(_0x22e37b['allWrites'],uu,w()),_0x22e37b['allWrites']['length']>0x0?_0x22e37b['lastWriteId']=_0x22e37b['allWrites'][_0x22e37b['allWrites']['length']-0x1]['writeId']:_0x22e37b['lastWriteId']=-0x1;}function uu(_0x5dd0de){return _0x5dd0de['visible'];}function Uo(_0x54aee3,_0x43e653,_0x31e51c){let _0x395a98=K['empty']();for(let _0x44a129=0x0;_0x44a129<_0x54aee3['length'];++_0x44a129){const _0x5b4ef4=_0x54aee3[_0x44a129];if(_0x43e653(_0x5b4ef4)){const _0x18f5cf=_0x5b4ef4['path'];let _0x3211fc;if(_0x5b4ef4['snap'])G(_0x31e51c,_0x18f5cf)?(_0x3211fc=F(_0x31e51c,_0x18f5cf),_0x395a98=Rt(_0x395a98,_0x3211fc,_0x5b4ef4['snap'])):G(_0x18f5cf,_0x31e51c)&&(_0x3211fc=F(_0x18f5cf,_0x31e51c),_0x395a98=Rt(_0x395a98,w(),_0x5b4ef4['snap']['getChild'](_0x3211fc)));else{if(_0x5b4ef4['children']){if(G(_0x31e51c,_0x18f5cf))_0x3211fc=F(_0x31e51c,_0x18f5cf),_0x395a98=Si(_0x395a98,_0x3211fc,_0x5b4ef4['children']);else{if(G(_0x18f5cf,_0x31e51c)){if(_0x3211fc=F(_0x18f5cf,_0x31e51c),v(_0x3211fc))_0x395a98=Si(_0x395a98,w(),_0x5b4ef4['children']);else{const _0x349362=Me(_0x5b4ef4['children'],y(_0x3211fc));if(_0x349362){const _0x1189d0=_0x349362['getChild'](S(_0x3211fc));_0x395a98=Rt(_0x395a98,w(),_0x1189d0);}}}}}else throw lt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x395a98;}function Wo(_0x69dcc1,_0x4142fd,_0x4d7062,_0x5f0482,_0x24e959){if(!_0x5f0482&&!_0x24e959){const _0x534d80=qe(_0x69dcc1['visibleWrites'],_0x4142fd);if(_0x534d80!=null)return _0x534d80;{const _0x5d392c=ve(_0x69dcc1['visibleWrites'],_0x4142fd);if(Ri(_0x5d392c))return _0x4d7062;if(_0x4d7062==null&&!bi(_0x5d392c,w()))return null;{const _0x516585=_0x4d7062||g['EMPTY_NODE'];return ot(_0x5d392c,_0x516585);}}}else{const _0xd2acbe=ve(_0x69dcc1['visibleWrites'],_0x4142fd);if(!_0x24e959&&Ri(_0xd2acbe))return _0x4d7062;if(!_0x24e959&&_0x4d7062==null&&!bi(_0xd2acbe,w()))return null;{const _0x633ac8=function(_0x84ff22){return(_0x84ff22['visible']||_0x24e959)&&(!_0x5f0482||!~_0x5f0482['indexOf'](_0x84ff22['writeId']))&&(G(_0x84ff22['path'],_0x4142fd)||G(_0x4142fd,_0x84ff22['path']));},_0x1517b9=Uo(_0x69dcc1['allWrites'],_0x633ac8,_0x4142fd),_0x34ae29=_0x4d7062||g['EMPTY_NODE'];return ot(_0x1517b9,_0x34ae29);}}}function du(_0x6959a4,_0xcceea4,_0x435d83){let _0x4ba410=g['EMPTY_NODE'];const _0x5109c3=qe(_0x6959a4['visibleWrites'],_0xcceea4);if(_0x5109c3)return _0x5109c3['isLeafNode']()||_0x5109c3['forEachChild'](R,(_0x5bfa49,_0x563d93)=>{_0x4ba410=_0x4ba410['updateImmediateChild'](_0x5bfa49,_0x563d93);}),_0x4ba410;if(_0x435d83){const _0x5cc28b=ve(_0x6959a4['visibleWrites'],_0xcceea4);return _0x435d83['forEachChild'](R,(_0x2e562f,_0x2aa4ac)=>{const _0x585974=ot(ve(_0x5cc28b,new C(_0x2e562f)),_0x2aa4ac);_0x4ba410=_0x4ba410['updateImmediateChild'](_0x2e562f,_0x585974);}),ar(_0x5cc28b)['forEach'](_0x2e42e2=>{_0x4ba410=_0x4ba410['updateImmediateChild'](_0x2e42e2['name'],_0x2e42e2['node']);}),_0x4ba410;}else{const _0xd1c4c=ve(_0x6959a4['visibleWrites'],_0xcceea4);return ar(_0xd1c4c)['forEach'](_0xefada2=>{_0x4ba410=_0x4ba410['updateImmediateChild'](_0xefada2['name'],_0xefada2['node']);}),_0x4ba410;}}function fu(_0x2071a3,_0x4205ec,_0x90f812,_0x5aacd7,_0xcfd11f){f(_0x5aacd7||_0xcfd11f,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x10612f=k(_0x4205ec,_0x90f812);if(bi(_0x2071a3['visibleWrites'],_0x10612f))return null;{const _0x382f7a=ve(_0x2071a3['visibleWrites'],_0x10612f);return Ri(_0x382f7a)?_0xcfd11f['getChild'](_0x90f812):ot(_0x382f7a,_0xcfd11f['getChild'](_0x90f812));}}function pu(_0xaf702b,_0x1459eb,_0x1bec0d,_0x4f006a){const _0x5ec16f=k(_0x1459eb,_0x1bec0d),_0x16bd4e=qe(_0xaf702b['visibleWrites'],_0x5ec16f);if(_0x16bd4e!=null)return _0x16bd4e;if(_0x4f006a['isCompleteForChild'](_0x1bec0d)){const _0x475a9d=ve(_0xaf702b['visibleWrites'],_0x5ec16f);return ot(_0x475a9d,_0x4f006a['getNode']()['getImmediateChild'](_0x1bec0d));}else return null;}function _u(_0xc51502,_0x1a88f7){return qe(_0xc51502['visibleWrites'],_0x1a88f7);}function gu(_0x23509a,_0x38b5bc,_0x5a8c34,_0x1cfa97,_0x59e584,_0x11ef59,_0x27190d){let _0x9ce512;const _0x47bf36=ve(_0x23509a['visibleWrites'],_0x38b5bc),_0x27eeb5=qe(_0x47bf36,w());if(_0x27eeb5!=null)_0x9ce512=_0x27eeb5;else{if(_0x5a8c34!=null)_0x9ce512=ot(_0x47bf36,_0x5a8c34);else return[];}if(_0x9ce512=_0x9ce512['withIndex'](_0x27190d),!_0x9ce512['isEmpty']()&&!_0x9ce512['isLeafNode']()){const _0x1f3151=[],_0x311987=_0x27190d['getCompare'](),_0x3c8434=_0x11ef59?_0x9ce512['getReverseIteratorFrom'](_0x1cfa97,_0x27190d):_0x9ce512['getIteratorFrom'](_0x1cfa97,_0x27190d);let _0x5e76ad=_0x3c8434['getNext']();for(;_0x5e76ad&&_0x1f3151['length']<_0x59e584;)_0x311987(_0x5e76ad,_0x1cfa97)!==0x0&&_0x1f3151['push'](_0x5e76ad),_0x5e76ad=_0x3c8434['getNext']();return _0x1f3151;}else return[];}function mu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function wn(_0x10c2dc,_0x192b3e,_0x2c937a,_0x4ac7fb){return Wo(_0x10c2dc['writeTree'],_0x10c2dc['treePath'],_0x192b3e,_0x2c937a,_0x4ac7fb);}function ns(_0x49e676,_0x47d348){return du(_0x49e676['writeTree'],_0x49e676['treePath'],_0x47d348);}function cr(_0x3ce5b5,_0xbdf584,_0x2eedd7,_0x4acd7b){return fu(_0x3ce5b5['writeTree'],_0x3ce5b5['treePath'],_0xbdf584,_0x2eedd7,_0x4acd7b);}function Cn(_0x23da8c,_0x53be15){return _u(_0x23da8c['writeTree'],k(_0x23da8c['treePath'],_0x53be15));}function yu(_0x2302f9,_0x1aa894,_0x503acc,_0x302370,_0x101c24,_0x358745){return gu(_0x2302f9['writeTree'],_0x2302f9['treePath'],_0x1aa894,_0x503acc,_0x302370,_0x101c24,_0x358745);}function is(_0x1705ef,_0x40342b,_0xc3d2c9){return pu(_0x1705ef['writeTree'],_0x1705ef['treePath'],_0x40342b,_0xc3d2c9);}function Bo(_0x56f2da,_0x10e2c2){return Vo(k(_0x56f2da['treePath'],_0x10e2c2),_0x56f2da['writeTree']);}function Vo(_0x3268b6,_0x5dfdfb){return{'treePath':_0x3268b6,'writeTree':_0x5dfdfb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x564f34){const _0x2c2d41=_0x564f34['type'],_0x5d19e4=_0x564f34['childName'];f(_0x2c2d41==='child_added'||_0x2c2d41==='child_changed'||_0x2c2d41==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x5d19e4!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5eae28=this['changeMap']['get'](_0x5d19e4);if(_0x5eae28){const _0x1d8837=_0x5eae28['type'];if(_0x2c2d41==='child_added'&&_0x1d8837==='child_removed')this['changeMap']['set'](_0x5d19e4,Lt(_0x5d19e4,_0x564f34['snapshotNode'],_0x5eae28['snapshotNode']));else{if(_0x2c2d41==='child_removed'&&_0x1d8837==='child_added')this['changeMap']['delete'](_0x5d19e4);else{if(_0x2c2d41==='child_removed'&&_0x1d8837==='child_changed')this['changeMap']['set'](_0x5d19e4,Mt(_0x5d19e4,_0x5eae28['oldSnap']));else{if(_0x2c2d41==='child_changed'&&_0x1d8837==='child_added')this['changeMap']['set'](_0x5d19e4,st(_0x5d19e4,_0x564f34['snapshotNode']));else{if(_0x2c2d41==='child_changed'&&_0x1d8837==='child_changed')this['changeMap']['set'](_0x5d19e4,Lt(_0x5d19e4,_0x564f34['snapshotNode'],_0x5eae28['oldSnap']));else throw lt('Illegal\x20combination\x20of\x20changes:\x20'+_0x564f34+'\x20occurred\x20after\x20'+_0x5eae28);}}}}}else this['changeMap']['set'](_0x5d19e4,_0x564f34);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{['getCompleteChild'](_0x2f64b8){return null;}['getChildAfterChild'](_0x5a31e6,_0x16ae97,_0x51b385){return null;}}const Ho=new Eu();class ss{constructor(_0x10143b,_0x3a383e,_0x3c5006=null){this['writes_']=_0x10143b,this['viewCache_']=_0x3a383e,this['optCompleteServerCache_']=_0x3c5006;}['getCompleteChild'](_0x4a10c5){const _0x25601a=this['viewCache_']['eventCache'];if(_0x25601a['isCompleteForChild'](_0x4a10c5))return _0x25601a['getNode']()['getImmediateChild'](_0x4a10c5);{const _0xb5c4d0=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x4a10c5,_0xb5c4d0);}}['getChildAfterChild'](_0x1d054f,_0x15c73b,_0x3721a9){const _0x54230d=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Be(this['viewCache_']),_0x30a056=yu(this['writes_'],_0x54230d,_0x15c73b,0x1,_0x3721a9,_0x1d054f);return _0x30a056['length']===0x0?null:_0x30a056[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Iu(_0x5393ed){return{'filter':_0x5393ed};}function wu(_0x145e5b,_0x5b8fd1){f(_0x5b8fd1['eventCache']['getNode']()['isIndexed'](_0x145e5b['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x5b8fd1['serverCache']['getNode']()['isIndexed'](_0x145e5b['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Cu(_0x5b7b8b,_0x5e19fc,_0x363ab7,_0x37e6a5,_0xb3bb2e){const _0xa04cc2=new vu();let _0x226bd5,_0x389ce1;if(_0x363ab7['type']===z['OVERWRITE']){const _0x49535f=_0x363ab7;_0x49535f['source']['fromUser']?_0x226bd5=Ai(_0x5b7b8b,_0x5e19fc,_0x49535f['path'],_0x49535f['snap'],_0x37e6a5,_0xb3bb2e,_0xa04cc2):(f(_0x49535f['source']['fromServer'],'Unknown\x20source.'),_0x389ce1=_0x49535f['source']['tagged']||_0x5e19fc['serverCache']['isFiltered']()&&!v(_0x49535f['path']),_0x226bd5=Tn(_0x5b7b8b,_0x5e19fc,_0x49535f['path'],_0x49535f['snap'],_0x37e6a5,_0xb3bb2e,_0x389ce1,_0xa04cc2));}else{if(_0x363ab7['type']===z['MERGE']){const _0x89e5ba=_0x363ab7;_0x89e5ba['source']['fromUser']?_0x226bd5=Su(_0x5b7b8b,_0x5e19fc,_0x89e5ba['path'],_0x89e5ba['children'],_0x37e6a5,_0xb3bb2e,_0xa04cc2):(f(_0x89e5ba['source']['fromServer'],'Unknown\x20source.'),_0x389ce1=_0x89e5ba['source']['tagged']||_0x5e19fc['serverCache']['isFiltered'](),_0x226bd5=ki(_0x5b7b8b,_0x5e19fc,_0x89e5ba['path'],_0x89e5ba['children'],_0x37e6a5,_0xb3bb2e,_0x389ce1,_0xa04cc2));}else{if(_0x363ab7['type']===z['ACK_USER_WRITE']){const _0x4b1789=_0x363ab7;_0x4b1789['revert']?_0x226bd5=Au(_0x5b7b8b,_0x5e19fc,_0x4b1789['path'],_0x37e6a5,_0xb3bb2e,_0xa04cc2):_0x226bd5=bu(_0x5b7b8b,_0x5e19fc,_0x4b1789['path'],_0x4b1789['affectedTree'],_0x37e6a5,_0xb3bb2e,_0xa04cc2);}else{if(_0x363ab7['type']===z['LISTEN_COMPLETE'])_0x226bd5=Ru(_0x5b7b8b,_0x5e19fc,_0x363ab7['path'],_0x37e6a5,_0xa04cc2);else throw lt('Unknown\x20operation\x20type:\x20'+_0x363ab7['type']);}}}const _0x323089=_0xa04cc2['getChanges']();return Tu(_0x5e19fc,_0x226bd5,_0x323089),{'viewCache':_0x226bd5,'changes':_0x323089};}function Tu(_0x3a3ca0,_0x134a09,_0x29dc28){const _0x35af5d=_0x134a09['eventCache'];if(_0x35af5d['isFullyInitialized']()){const _0x470dc3=_0x35af5d['getNode']()['isLeafNode']()||_0x35af5d['getNode']()['isEmpty'](),_0x2df0eb=In(_0x3a3ca0);(_0x29dc28['length']>0x0||!_0x3a3ca0['eventCache']['isFullyInitialized']()||_0x470dc3&&!_0x35af5d['getNode']()['equals'](_0x2df0eb)||!_0x35af5d['getNode']()['getPriority']()['equals'](_0x2df0eb['getPriority']()))&&_0x29dc28['push'](Lo(In(_0x134a09)));}}function $o(_0xd5ce3f,_0x42888a,_0x55dccd,_0x592621,_0x5ca66d,_0x4d7bd4){const _0x3e3379=_0x42888a['eventCache'];if(Cn(_0x592621,_0x55dccd)!=null)return _0x42888a;{let _0x54e4f6,_0x432330;if(v(_0x55dccd)){if(f(_0x42888a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x42888a['serverCache']['isFiltered']()){const _0x282c3e=Be(_0x42888a),_0x9498d8=_0x282c3e instanceof g?_0x282c3e:g['EMPTY_NODE'],_0x4a539d=ns(_0x592621,_0x9498d8);_0x54e4f6=_0xd5ce3f['filter']['updateFullNode'](_0x42888a['eventCache']['getNode'](),_0x4a539d,_0x4d7bd4);}else{const _0xfb9091=wn(_0x592621,Be(_0x42888a));_0x54e4f6=_0xd5ce3f['filter']['updateFullNode'](_0x42888a['eventCache']['getNode'](),_0xfb9091,_0x4d7bd4);}}else{const _0x296010=y(_0x55dccd);if(_0x296010==='.priority'){f(we(_0x55dccd)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3b54a0=_0x3e3379['getNode']();_0x432330=_0x42888a['serverCache']['getNode']();const _0x20aaf1=cr(_0x592621,_0x55dccd,_0x3b54a0,_0x432330);_0x20aaf1!=null?_0x54e4f6=_0xd5ce3f['filter']['updatePriority'](_0x3b54a0,_0x20aaf1):_0x54e4f6=_0x3e3379['getNode']();}else{const _0x3c9eed=S(_0x55dccd);let _0x45232c;if(_0x3e3379['isCompleteForChild'](_0x296010)){_0x432330=_0x42888a['serverCache']['getNode']();const _0xe8c32a=cr(_0x592621,_0x55dccd,_0x3e3379['getNode'](),_0x432330);_0xe8c32a!=null?_0x45232c=_0x3e3379['getNode']()['getImmediateChild'](_0x296010)['updateChild'](_0x3c9eed,_0xe8c32a):_0x45232c=_0x3e3379['getNode']()['getImmediateChild'](_0x296010);}else _0x45232c=is(_0x592621,_0x296010,_0x42888a['serverCache']);_0x45232c!=null?_0x54e4f6=_0xd5ce3f['filter']['updateChild'](_0x3e3379['getNode'](),_0x296010,_0x45232c,_0x3c9eed,_0x5ca66d,_0x4d7bd4):_0x54e4f6=_0x3e3379['getNode']();}}return bt(_0x42888a,_0x54e4f6,_0x3e3379['isFullyInitialized']()||v(_0x55dccd),_0xd5ce3f['filter']['filtersNodes']());}}function Tn(_0x4a6270,_0x3e8e99,_0x4c15bc,_0xfeb1b9,_0x27a194,_0x3b050b,_0x1e9976,_0xa6e02){const _0x116a41=_0x3e8e99['serverCache'];let _0x4fead3;const _0x195ed9=_0x1e9976?_0x4a6270['filter']:_0x4a6270['filter']['getIndexedFilter']();if(v(_0x4c15bc))_0x4fead3=_0x195ed9['updateFullNode'](_0x116a41['getNode'](),_0xfeb1b9,null);else{if(_0x195ed9['filtersNodes']()&&!_0x116a41['isFiltered']()){const _0x24b7ae=_0x116a41['getNode']()['updateChild'](_0x4c15bc,_0xfeb1b9);_0x4fead3=_0x195ed9['updateFullNode'](_0x116a41['getNode'](),_0x24b7ae,null);}else{const _0x26098f=y(_0x4c15bc);if(!_0x116a41['isCompleteForPath'](_0x4c15bc)&&we(_0x4c15bc)>0x1)return _0x3e8e99;const _0x511832=S(_0x4c15bc),_0x5389c7=_0x116a41['getNode']()['getImmediateChild'](_0x26098f)['updateChild'](_0x511832,_0xfeb1b9);_0x26098f==='.priority'?_0x4fead3=_0x195ed9['updatePriority'](_0x116a41['getNode'](),_0x5389c7):_0x4fead3=_0x195ed9['updateChild'](_0x116a41['getNode'](),_0x26098f,_0x5389c7,_0x511832,Ho,null);}}const _0x552db0=xo(_0x3e8e99,_0x4fead3,_0x116a41['isFullyInitialized']()||v(_0x4c15bc),_0x195ed9['filtersNodes']()),_0x4a1583=new ss(_0x27a194,_0x552db0,_0x3b050b);return $o(_0x4a6270,_0x552db0,_0x4c15bc,_0x27a194,_0x4a1583,_0xa6e02);}function Ai(_0x46e087,_0x3316ee,_0x3e24a9,_0x5b7d83,_0x34ddd3,_0x1cdfc3,_0x590560){const _0x210468=_0x3316ee['eventCache'];let _0x231055,_0x528879;const _0xc28794=new ss(_0x34ddd3,_0x3316ee,_0x1cdfc3);if(v(_0x3e24a9))_0x528879=_0x46e087['filter']['updateFullNode'](_0x3316ee['eventCache']['getNode'](),_0x5b7d83,_0x590560),_0x231055=bt(_0x3316ee,_0x528879,!0x0,_0x46e087['filter']['filtersNodes']());else{const _0x36fe30=y(_0x3e24a9);if(_0x36fe30==='.priority')_0x528879=_0x46e087['filter']['updatePriority'](_0x3316ee['eventCache']['getNode'](),_0x5b7d83),_0x231055=bt(_0x3316ee,_0x528879,_0x210468['isFullyInitialized'](),_0x210468['isFiltered']());else{const _0x5422dd=S(_0x3e24a9),_0x456a40=_0x210468['getNode']()['getImmediateChild'](_0x36fe30);let _0x1f1f52;if(v(_0x5422dd))_0x1f1f52=_0x5b7d83;else{const _0x7c39b=_0xc28794['getCompleteChild'](_0x36fe30);_0x7c39b!=null?zi(_0x5422dd)==='.priority'&&_0x7c39b['getChild'](Ro(_0x5422dd))['isEmpty']()?_0x1f1f52=_0x7c39b:_0x1f1f52=_0x7c39b['updateChild'](_0x5422dd,_0x5b7d83):_0x1f1f52=g['EMPTY_NODE'];}if(_0x456a40['equals'](_0x1f1f52))_0x231055=_0x3316ee;else{const _0x474bee=_0x46e087['filter']['updateChild'](_0x210468['getNode'](),_0x36fe30,_0x1f1f52,_0x5422dd,_0xc28794,_0x590560);_0x231055=bt(_0x3316ee,_0x474bee,_0x210468['isFullyInitialized'](),_0x46e087['filter']['filtersNodes']());}}}return _0x231055;}function lr(_0x6abad1,_0x571f3e){return _0x6abad1['eventCache']['isCompleteForChild'](_0x571f3e);}function Su(_0x43d74c,_0x2f5d6d,_0x328ac2,_0x52a0ce,_0x3db52f,_0x149a91,_0x4924c3){let _0x382200=_0x2f5d6d;return _0x52a0ce['foreach']((_0x3b9abf,_0x332870)=>{const _0x389bae=k(_0x328ac2,_0x3b9abf);lr(_0x2f5d6d,y(_0x389bae))&&(_0x382200=Ai(_0x43d74c,_0x382200,_0x389bae,_0x332870,_0x3db52f,_0x149a91,_0x4924c3));}),_0x52a0ce['foreach']((_0x44f997,_0x5a5029)=>{const _0x55557a=k(_0x328ac2,_0x44f997);lr(_0x2f5d6d,y(_0x55557a))||(_0x382200=Ai(_0x43d74c,_0x382200,_0x55557a,_0x5a5029,_0x3db52f,_0x149a91,_0x4924c3));}),_0x382200;}function hr(_0x44f001,_0x1b7b00,_0x25ca9c){return _0x25ca9c['foreach']((_0x24185d,_0x297d62)=>{_0x1b7b00=_0x1b7b00['updateChild'](_0x24185d,_0x297d62);}),_0x1b7b00;}function ki(_0x459d7a,_0x571f18,_0x22727c,_0x406b69,_0x2ba9c6,_0x38961e,_0x53d439,_0x32f31c){if(_0x571f18['serverCache']['getNode']()['isEmpty']()&&!_0x571f18['serverCache']['isFullyInitialized']())return _0x571f18;let _0x245963=_0x571f18,_0x377e21;v(_0x22727c)?_0x377e21=_0x406b69:_0x377e21=new b(null)['setTree'](_0x22727c,_0x406b69);const _0x1db438=_0x571f18['serverCache']['getNode']();return _0x377e21['children']['inorderTraversal']((_0x364c6f,_0x38d82b)=>{if(_0x1db438['hasChild'](_0x364c6f)){const _0x5c30a5=_0x571f18['serverCache']['getNode']()['getImmediateChild'](_0x364c6f),_0xcd7e99=hr(_0x459d7a,_0x5c30a5,_0x38d82b);_0x245963=Tn(_0x459d7a,_0x245963,new C(_0x364c6f),_0xcd7e99,_0x2ba9c6,_0x38961e,_0x53d439,_0x32f31c);}}),_0x377e21['children']['inorderTraversal']((_0x293eff,_0x29a1d4)=>{const _0x2503ef=!_0x571f18['serverCache']['isCompleteForChild'](_0x293eff)&&_0x29a1d4['value']===null;if(!_0x1db438['hasChild'](_0x293eff)&&!_0x2503ef){const _0x58e24c=_0x571f18['serverCache']['getNode']()['getImmediateChild'](_0x293eff),_0x217617=hr(_0x459d7a,_0x58e24c,_0x29a1d4);_0x245963=Tn(_0x459d7a,_0x245963,new C(_0x293eff),_0x217617,_0x2ba9c6,_0x38961e,_0x53d439,_0x32f31c);}}),_0x245963;}function bu(_0x2bfa5d,_0x18dfdb,_0x1070f0,_0xe70dab,_0x137721,_0x1a489f,_0x1438d0){if(Cn(_0x137721,_0x1070f0)!=null)return _0x18dfdb;const _0x27798b=_0x18dfdb['serverCache']['isFiltered'](),_0x184dcf=_0x18dfdb['serverCache'];if(_0xe70dab['value']!=null){if(v(_0x1070f0)&&_0x184dcf['isFullyInitialized']()||_0x184dcf['isCompleteForPath'](_0x1070f0))return Tn(_0x2bfa5d,_0x18dfdb,_0x1070f0,_0x184dcf['getNode']()['getChild'](_0x1070f0),_0x137721,_0x1a489f,_0x27798b,_0x1438d0);if(v(_0x1070f0)){let _0x5c38b7=new b(null);return _0x184dcf['getNode']()['forEachChild'](De,(_0x5e88ac,_0x4fac0c)=>{_0x5c38b7=_0x5c38b7['set'](new C(_0x5e88ac),_0x4fac0c);}),ki(_0x2bfa5d,_0x18dfdb,_0x1070f0,_0x5c38b7,_0x137721,_0x1a489f,_0x27798b,_0x1438d0);}else return _0x18dfdb;}else{let _0x239301=new b(null);return _0xe70dab['foreach']((_0x1e3852,_0x5b1130)=>{const _0x1a67ce=k(_0x1070f0,_0x1e3852);_0x184dcf['isCompleteForPath'](_0x1a67ce)&&(_0x239301=_0x239301['set'](_0x1e3852,_0x184dcf['getNode']()['getChild'](_0x1a67ce)));}),ki(_0x2bfa5d,_0x18dfdb,_0x1070f0,_0x239301,_0x137721,_0x1a489f,_0x27798b,_0x1438d0);}}function Ru(_0x3012e9,_0x5e6ecd,_0x42d646,_0x34a6b9,_0x31f127){const _0x41aeca=_0x5e6ecd['serverCache'],_0x7ee975=xo(_0x5e6ecd,_0x41aeca['getNode'](),_0x41aeca['isFullyInitialized']()||v(_0x42d646),_0x41aeca['isFiltered']());return $o(_0x3012e9,_0x7ee975,_0x42d646,_0x34a6b9,Ho,_0x31f127);}function Au(_0xd5b605,_0x5ad7fe,_0x190c46,_0x4dae42,_0x2828a7,_0x129452){let _0x2acee0;if(Cn(_0x4dae42,_0x190c46)!=null)return _0x5ad7fe;{const _0x227820=new ss(_0x4dae42,_0x5ad7fe,_0x2828a7),_0x1a1585=_0x5ad7fe['eventCache']['getNode']();let _0x1786e4;if(v(_0x190c46)||y(_0x190c46)==='.priority'){let _0x21d678;if(_0x5ad7fe['serverCache']['isFullyInitialized']())_0x21d678=wn(_0x4dae42,Be(_0x5ad7fe));else{const _0x262723=_0x5ad7fe['serverCache']['getNode']();f(_0x262723 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x21d678=ns(_0x4dae42,_0x262723);}_0x21d678=_0x21d678,_0x1786e4=_0xd5b605['filter']['updateFullNode'](_0x1a1585,_0x21d678,_0x129452);}else{const _0x140e8d=y(_0x190c46);let _0x2eab6e=is(_0x4dae42,_0x140e8d,_0x5ad7fe['serverCache']);_0x2eab6e==null&&_0x5ad7fe['serverCache']['isCompleteForChild'](_0x140e8d)&&(_0x2eab6e=_0x1a1585['getImmediateChild'](_0x140e8d)),_0x2eab6e!=null?_0x1786e4=_0xd5b605['filter']['updateChild'](_0x1a1585,_0x140e8d,_0x2eab6e,S(_0x190c46),_0x227820,_0x129452):_0x5ad7fe['eventCache']['getNode']()['hasChild'](_0x140e8d)?_0x1786e4=_0xd5b605['filter']['updateChild'](_0x1a1585,_0x140e8d,g['EMPTY_NODE'],S(_0x190c46),_0x227820,_0x129452):_0x1786e4=_0x1a1585,_0x1786e4['isEmpty']()&&_0x5ad7fe['serverCache']['isFullyInitialized']()&&(_0x2acee0=wn(_0x4dae42,Be(_0x5ad7fe)),_0x2acee0['isLeafNode']()&&(_0x1786e4=_0xd5b605['filter']['updateFullNode'](_0x1786e4,_0x2acee0,_0x129452)));}return _0x2acee0=_0x5ad7fe['serverCache']['isFullyInitialized']()||Cn(_0x4dae42,w())!=null,bt(_0x5ad7fe,_0x1786e4,_0x2acee0,_0xd5b605['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ku{constructor(_0x6139d4,_0x3d20d8){this['query_']=_0x6139d4,this['eventRegistrations_']=[];const _0x399282=this['query_']['_queryParams'],_0x784bae=new Ji(_0x399282['getIndex']()),_0x16ccc0=Gh(_0x399282);this['processor_']=Iu(_0x16ccc0);const _0x11282b=_0x3d20d8['serverCache'],_0x4beaa9=_0x3d20d8['eventCache'],_0x531ca6=_0x784bae['updateFullNode'](g['EMPTY_NODE'],_0x11282b['getNode'](),null),_0x3ce7a9=_0x16ccc0['updateFullNode'](g['EMPTY_NODE'],_0x4beaa9['getNode'](),null),_0x46e375=new Ce(_0x531ca6,_0x11282b['isFullyInitialized'](),_0x784bae['filtersNodes']()),_0x58e67f=new Ce(_0x3ce7a9,_0x4beaa9['isFullyInitialized'](),_0x16ccc0['filtersNodes']());this['viewCache_']=Fn(_0x58e67f,_0x46e375),this['eventGenerator_']=new eu(this['query_']);}get['query'](){return this['query_'];}}function Nu(_0xe2ecce){return _0xe2ecce['viewCache_']['serverCache']['getNode']();}function Pu(_0x2d79ef){return In(_0x2d79ef['viewCache_']);}function Ou(_0x7f1cfa,_0x5edef9){const _0x5e7566=Be(_0x7f1cfa['viewCache_']);return _0x5e7566&&(_0x7f1cfa['query']['_queryParams']['loadsAllData']()||!v(_0x5edef9)&&!_0x5e7566['getImmediateChild'](y(_0x5edef9))['isEmpty']())?_0x5e7566['getChild'](_0x5edef9):null;}function ur(_0x55f5b2){return _0x55f5b2['eventRegistrations_']['length']===0x0;}function Du(_0x54e795,_0x31f283){_0x54e795['eventRegistrations_']['push'](_0x31f283);}function dr(_0x19099e,_0x1ffd29,_0x4bc3f9){const _0x4f5fda=[];if(_0x4bc3f9){f(_0x1ffd29==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x55b489=_0x19099e['query']['_path'];_0x19099e['eventRegistrations_']['forEach'](_0x4f9d09=>{const _0x549516=_0x4f9d09['createCancelEvent'](_0x4bc3f9,_0x55b489);_0x549516&&_0x4f5fda['push'](_0x549516);});}if(_0x1ffd29){let _0x393bc1=[];for(let _0x50567c=0x0;_0x50567c<_0x19099e['eventRegistrations_']['length'];++_0x50567c){const _0x4aed4d=_0x19099e['eventRegistrations_'][_0x50567c];if(!_0x4aed4d['matches'](_0x1ffd29))_0x393bc1['push'](_0x4aed4d);else{if(_0x1ffd29['hasAnyCallback']()){_0x393bc1=_0x393bc1['concat'](_0x19099e['eventRegistrations_']['slice'](_0x50567c+0x1));break;}}}_0x19099e['eventRegistrations_']=_0x393bc1;}else _0x19099e['eventRegistrations_']=[];return _0x4f5fda;}function fr(_0x3f7a64,_0x48dd0a,_0x469507,_0x22ac7c){_0x48dd0a['type']===z['MERGE']&&_0x48dd0a['source']['queryId']!==null&&(f(Be(_0x3f7a64['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(In(_0x3f7a64['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x474b72=_0x3f7a64['viewCache_'],_0x377f6b=Cu(_0x3f7a64['processor_'],_0x474b72,_0x48dd0a,_0x469507,_0x22ac7c);return wu(_0x3f7a64['processor_'],_0x377f6b['viewCache']),f(_0x377f6b['viewCache']['serverCache']['isFullyInitialized']()||!_0x474b72['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x3f7a64['viewCache_']=_0x377f6b['viewCache'],Go(_0x3f7a64,_0x377f6b['changes'],_0x377f6b['viewCache']['eventCache']['getNode'](),null);}function Mu(_0x13a987,_0x5c9e19){const _0x2b17af=_0x13a987['viewCache_']['eventCache'],_0x42b6a4=[];return _0x2b17af['getNode']()['isLeafNode']()||_0x2b17af['getNode']()['forEachChild'](R,(_0x377da0,_0x5228a8)=>{_0x42b6a4['push'](st(_0x377da0,_0x5228a8));}),_0x2b17af['isFullyInitialized']()&&_0x42b6a4['push'](Lo(_0x2b17af['getNode']())),Go(_0x13a987,_0x42b6a4,_0x2b17af['getNode'](),_0x5c9e19);}function Go(_0x316397,_0x561217,_0x55b8ba,_0x3d576c){const _0x2f390a=_0x3d576c?[_0x3d576c]:_0x316397['eventRegistrations_'];return tu(_0x316397['eventGenerator_'],_0x561217,_0x55b8ba,_0x2f390a);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Sn;class qo{constructor(){this['views']=new Map();}}function Lu(_0x67d638){f(!Sn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Sn=_0x67d638;}function xu(){return f(Sn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Sn;}function Fu(_0x5962c5){return _0x5962c5['views']['size']===0x0;}function rs(_0x45dec1,_0x35cba2,_0x2e6e2a,_0x1a7ab9){const _0x55ec7d=_0x35cba2['source']['queryId'];if(_0x55ec7d!==null){const _0x57e299=_0x45dec1['views']['get'](_0x55ec7d);return f(_0x57e299!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x57e299,_0x35cba2,_0x2e6e2a,_0x1a7ab9);}else{let _0x5de855=[];for(const _0x231bb7 of _0x45dec1['views']['values']())_0x5de855=_0x5de855['concat'](fr(_0x231bb7,_0x35cba2,_0x2e6e2a,_0x1a7ab9));return _0x5de855;}}function zo(_0x465222,_0x1fc4fa,_0x5c798f,_0x4551db,_0x21e2f2){const _0x425092=_0x1fc4fa['_queryIdentifier'],_0x218e4d=_0x465222['views']['get'](_0x425092);if(!_0x218e4d){let _0xc04400=wn(_0x5c798f,_0x21e2f2?_0x4551db:null),_0x49dc93=!0x1;_0xc04400?_0x49dc93=!0x0:_0x4551db instanceof g?(_0xc04400=ns(_0x5c798f,_0x4551db),_0x49dc93=!0x1):(_0xc04400=g['EMPTY_NODE'],_0x49dc93=!0x1);const _0x44243d=Fn(new Ce(_0xc04400,_0x49dc93,!0x1),new Ce(_0x4551db,_0x21e2f2,!0x1));return new ku(_0x1fc4fa,_0x44243d);}return _0x218e4d;}function Uu(_0x5a2675,_0x85d5ab,_0xd471aa,_0x29ab2b,_0x3c7a67,_0x3601a5){const _0x1f502a=zo(_0x5a2675,_0x85d5ab,_0x29ab2b,_0x3c7a67,_0x3601a5);return _0x5a2675['views']['has'](_0x85d5ab['_queryIdentifier'])||_0x5a2675['views']['set'](_0x85d5ab['_queryIdentifier'],_0x1f502a),Du(_0x1f502a,_0xd471aa),Mu(_0x1f502a,_0xd471aa);}function Wu(_0x202db4,_0x3b097a,_0x4f377f,_0x581fa3){const _0x275894=_0x3b097a['_queryIdentifier'],_0x1d9c51=[];let _0xd0b02a=[];const _0x1a762d=Te(_0x202db4);if(_0x275894==='default'){for(const [_0x36244f,_0x36ac78]of _0x202db4['views']['entries']())_0xd0b02a=_0xd0b02a['concat'](dr(_0x36ac78,_0x4f377f,_0x581fa3)),ur(_0x36ac78)&&(_0x202db4['views']['delete'](_0x36244f),_0x36ac78['query']['_queryParams']['loadsAllData']()||_0x1d9c51['push'](_0x36ac78['query']));}else{const _0x43b008=_0x202db4['views']['get'](_0x275894);_0x43b008&&(_0xd0b02a=_0xd0b02a['concat'](dr(_0x43b008,_0x4f377f,_0x581fa3)),ur(_0x43b008)&&(_0x202db4['views']['delete'](_0x275894),_0x43b008['query']['_queryParams']['loadsAllData']()||_0x1d9c51['push'](_0x43b008['query'])));}return _0x1a762d&&!Te(_0x202db4)&&_0x1d9c51['push'](new(xu())(_0x3b097a['_repo'],_0x3b097a['_path'])),{'removed':_0x1d9c51,'events':_0xd0b02a};}function jo(_0x62d042){const _0x17a324=[];for(const _0x42aa6b of _0x62d042['views']['values']())_0x42aa6b['query']['_queryParams']['loadsAllData']()||_0x17a324['push'](_0x42aa6b);return _0x17a324;}function Ee(_0x2bdb05,_0x230e7a){let _0x3b7db0=null;for(const _0x31abfe of _0x2bdb05['views']['values']())_0x3b7db0=_0x3b7db0||Ou(_0x31abfe,_0x230e7a);return _0x3b7db0;}function Ko(_0x412548,_0x3074d8){if(_0x3074d8['_queryParams']['loadsAllData']())return Wn(_0x412548);{const _0x220187=_0x3074d8['_queryIdentifier'];return _0x412548['views']['get'](_0x220187);}}function Yo(_0x2fc2a2,_0x464ba3){return Ko(_0x2fc2a2,_0x464ba3)!=null;}function Te(_0x5d81c2){return Wn(_0x5d81c2)!=null;}function Wn(_0x4c5049){for(const _0x22897a of _0x4c5049['views']['values']())if(_0x22897a['query']['_queryParams']['loadsAllData']())return _0x22897a;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;function Bu(_0x264855){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x264855;}function Vu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}let Hu=0x1;class pr{constructor(_0x5e3252){this['listenProvider_']=_0x5e3252,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=mu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4d83cb,_0x161797,_0x198f44,_0x39cc38,_0x506a67){return ru(_0x4d83cb['pendingWriteTree_'],_0x161797,_0x198f44,_0x39cc38,_0x506a67),_0x506a67?pt(_0x4d83cb,new We(Zi(),_0x161797,_0x198f44)):[];}function $u(_0x4b42df,_0x1a9c69,_0x2ee46f,_0x240727){ou(_0x4b42df['pendingWriteTree_'],_0x1a9c69,_0x2ee46f,_0x240727);const _0x4d9a3a=b['fromObject'](_0x2ee46f);return pt(_0x4b42df,new rt(Zi(),_0x1a9c69,_0x4d9a3a));}function _e(_0x1e989a,_0x1cd6c9,_0x5b725a=!0x1){const _0x10d787=au(_0x1e989a['pendingWriteTree_'],_0x1cd6c9);if(cu(_0x1e989a['pendingWriteTree_'],_0x1cd6c9)){let _0xc880f0=new b(null);return _0x10d787['snap']!=null?_0xc880f0=_0xc880f0['set'](w(),!0x0):x(_0x10d787['children'],_0x5a7094=>{_0xc880f0=_0xc880f0['set'](new C(_0x5a7094),!0x0);}),pt(_0x1e989a,new En(_0x10d787['path'],_0xc880f0,_0x5b725a));}else return[];}function Kt(_0x514b53,_0xe112b2,_0x58a43c){return pt(_0x514b53,new We(es(),_0xe112b2,_0x58a43c));}function Gu(_0x1f3b3d,_0x207dd1,_0x246dbc){const _0x5c9780=b['fromObject'](_0x246dbc);return pt(_0x1f3b3d,new rt(es(),_0x207dd1,_0x5c9780));}function qu(_0x413605,_0x4592fe){return pt(_0x413605,new Ft(es(),_0x4592fe));}function zu(_0x280a13,_0x119628,_0x44d79b){const _0x4cf3d5=as(_0x280a13,_0x44d79b);if(_0x4cf3d5){const _0x2e5cb8=cs(_0x4cf3d5),_0x5af816=_0x2e5cb8['path'],_0x3e186a=_0x2e5cb8['queryId'],_0x3c8edc=F(_0x5af816,_0x119628),_0x431e68=new Ft(ts(_0x3e186a),_0x3c8edc);return ls(_0x280a13,_0x5af816,_0x431e68);}else return[];}function Rn(_0x1f1db8,_0x297d24,_0x3c49f6,_0x5f05b8,_0x57663b=!0x1){const _0x15b2b9=_0x297d24['_path'],_0x24b138=_0x1f1db8['syncPointTree_']['get'](_0x15b2b9);let _0xcc63f7=[];if(_0x24b138&&(_0x297d24['_queryIdentifier']==='default'||Yo(_0x24b138,_0x297d24))){const _0x240cb4=Wu(_0x24b138,_0x297d24,_0x3c49f6,_0x5f05b8);Fu(_0x24b138)&&(_0x1f1db8['syncPointTree_']=_0x1f1db8['syncPointTree_']['remove'](_0x15b2b9));const _0x2092ad=_0x240cb4['removed'];if(_0xcc63f7=_0x240cb4['events'],!_0x57663b){const _0x7650ef=_0x2092ad['findIndex'](_0x3ec221=>_0x3ec221['_queryParams']['loadsAllData']())!==-0x1,_0x42308d=_0x1f1db8['syncPointTree_']['findOnPath'](_0x15b2b9,(_0x305768,_0x548bb1)=>Te(_0x548bb1));if(_0x7650ef&&!_0x42308d){const _0x4eea2f=_0x1f1db8['syncPointTree_']['subtree'](_0x15b2b9);if(!_0x4eea2f['isEmpty']()){const _0x5065df=Yu(_0x4eea2f);for(let _0x1867fc=0x0;_0x1867fc<_0x5065df['length'];++_0x1867fc){const _0x304517=_0x5065df[_0x1867fc],_0x21ee1e=_0x304517['query'],_0x374d06=Zo(_0x1f1db8,_0x304517);_0x1f1db8['listenProvider_']['startListening'](At(_0x21ee1e),Ut(_0x1f1db8,_0x21ee1e),_0x374d06['hashFn'],_0x374d06['onComplete']);}}}!_0x42308d&&_0x2092ad['length']>0x0&&!_0x5f05b8&&(_0x7650ef?_0x1f1db8['listenProvider_']['stopListening'](At(_0x297d24),null):_0x2092ad['forEach'](_0x50a6cc=>{const _0x2c5563=_0x1f1db8['queryToTagMap']['get'](Vn(_0x50a6cc));_0x1f1db8['listenProvider_']['stopListening'](At(_0x50a6cc),_0x2c5563);}));}Qu(_0x1f1db8,_0x2092ad);}return _0xcc63f7;}function Qo(_0x3ca42f,_0x1dcdbe,_0xf084b4,_0x332c8b){const _0xc9bdbc=as(_0x3ca42f,_0x332c8b);if(_0xc9bdbc!=null){const _0x12d275=cs(_0xc9bdbc),_0x17bb39=_0x12d275['path'],_0x401149=_0x12d275['queryId'],_0x4ae72f=F(_0x17bb39,_0x1dcdbe),_0x228aba=new We(ts(_0x401149),_0x4ae72f,_0xf084b4);return ls(_0x3ca42f,_0x17bb39,_0x228aba);}else return[];}function ju(_0x3e4107,_0x4c6a47,_0x15d226,_0x2cb2c3){const _0x4bf670=as(_0x3e4107,_0x2cb2c3);if(_0x4bf670){const _0x5e08d5=cs(_0x4bf670),_0x2f8c6b=_0x5e08d5['path'],_0x2289f6=_0x5e08d5['queryId'],_0x141156=F(_0x2f8c6b,_0x4c6a47),_0x5cfb83=b['fromObject'](_0x15d226),_0x56d308=new rt(ts(_0x2289f6),_0x141156,_0x5cfb83);return ls(_0x3e4107,_0x2f8c6b,_0x56d308);}else return[];}function Ni(_0x4ea0c0,_0x1561db,_0x13e2cf,_0x147582=!0x1){const _0x57f207=_0x1561db['_path'];let _0x47134a=null,_0x101777=!0x1;_0x4ea0c0['syncPointTree_']['foreachOnPath'](_0x57f207,(_0x281abe,_0x243ff2)=>{const _0x3256aa=F(_0x281abe,_0x57f207);_0x47134a=_0x47134a||Ee(_0x243ff2,_0x3256aa),_0x101777=_0x101777||Te(_0x243ff2);});let _0x21702d=_0x4ea0c0['syncPointTree_']['get'](_0x57f207);_0x21702d?(_0x101777=_0x101777||Te(_0x21702d),_0x47134a=_0x47134a||Ee(_0x21702d,w())):(_0x21702d=new qo(),_0x4ea0c0['syncPointTree_']=_0x4ea0c0['syncPointTree_']['set'](_0x57f207,_0x21702d));let _0x5bf89a;_0x47134a!=null?_0x5bf89a=!0x0:(_0x5bf89a=!0x1,_0x47134a=g['EMPTY_NODE'],_0x4ea0c0['syncPointTree_']['subtree'](_0x57f207)['foreachChild']((_0x52507c,_0x192884)=>{const _0x3d2e9b=Ee(_0x192884,w());_0x3d2e9b&&(_0x47134a=_0x47134a['updateImmediateChild'](_0x52507c,_0x3d2e9b));}));const _0x5b4a33=Yo(_0x21702d,_0x1561db);if(!_0x5b4a33&&!_0x1561db['_queryParams']['loadsAllData']()){const _0x3d054e=Vn(_0x1561db);f(!_0x4ea0c0['queryToTagMap']['has'](_0x3d054e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x617c75=Ju();_0x4ea0c0['queryToTagMap']['set'](_0x3d054e,_0x617c75),_0x4ea0c0['tagToQueryMap']['set'](_0x617c75,_0x3d054e);}const _0x388f5e=Un(_0x4ea0c0['pendingWriteTree_'],_0x57f207);let _0x2e0f54=Uu(_0x21702d,_0x1561db,_0x13e2cf,_0x388f5e,_0x47134a,_0x5bf89a);if(!_0x5b4a33&&!_0x101777&&!_0x147582){const _0x3b54d5=Ko(_0x21702d,_0x1561db);_0x2e0f54=_0x2e0f54['concat'](Xu(_0x4ea0c0,_0x1561db,_0x3b54d5));}return _0x2e0f54;}function Bn(_0x542af8,_0x2f8d22,_0x738659){const _0x276578=_0x542af8['pendingWriteTree_'],_0x5ae3de=_0x542af8['syncPointTree_']['findOnPath'](_0x2f8d22,(_0x34e9cb,_0x4b5ec2)=>{const _0x1d6503=F(_0x34e9cb,_0x2f8d22),_0x420cec=Ee(_0x4b5ec2,_0x1d6503);if(_0x420cec)return _0x420cec;});return Wo(_0x276578,_0x2f8d22,_0x5ae3de,_0x738659,!0x0);}function Ku(_0x425f97,_0x5aa3ce){const _0x2b7ff5=_0x5aa3ce['_path'];let _0x4dc337=null;_0x425f97['syncPointTree_']['foreachOnPath'](_0x2b7ff5,(_0x1b14fa,_0x3e0182)=>{const _0xbb188e=F(_0x1b14fa,_0x2b7ff5);_0x4dc337=_0x4dc337||Ee(_0x3e0182,_0xbb188e);});let _0x4697d9=_0x425f97['syncPointTree_']['get'](_0x2b7ff5);_0x4697d9?_0x4dc337=_0x4dc337||Ee(_0x4697d9,w()):(_0x4697d9=new qo(),_0x425f97['syncPointTree_']=_0x425f97['syncPointTree_']['set'](_0x2b7ff5,_0x4697d9));const _0x2c34ba=_0x4dc337!=null,_0x450c78=_0x2c34ba?new Ce(_0x4dc337,!0x0,!0x1):null,_0x1599c9=Un(_0x425f97['pendingWriteTree_'],_0x5aa3ce['_path']),_0x27ddb2=zo(_0x4697d9,_0x5aa3ce,_0x1599c9,_0x2c34ba?_0x450c78['getNode']():g['EMPTY_NODE'],_0x2c34ba);return Pu(_0x27ddb2);}function pt(_0x1a2780,_0x2efadc){return Jo(_0x2efadc,_0x1a2780['syncPointTree_'],null,Un(_0x1a2780['pendingWriteTree_'],w()));}function Jo(_0x1040bf,_0x1a21b6,_0x36c2cc,_0x3a529e){if(v(_0x1040bf['path']))return Xo(_0x1040bf,_0x1a21b6,_0x36c2cc,_0x3a529e);{const _0x123030=_0x1a21b6['get'](w());_0x36c2cc==null&&_0x123030!=null&&(_0x36c2cc=Ee(_0x123030,w()));let _0x2d3a62=[];const _0x4d3084=y(_0x1040bf['path']),_0x36fad6=_0x1040bf['operationForChild'](_0x4d3084),_0x2770af=_0x1a21b6['children']['get'](_0x4d3084);if(_0x2770af&&_0x36fad6){const _0x210da1=_0x36c2cc?_0x36c2cc['getImmediateChild'](_0x4d3084):null,_0x358c09=Bo(_0x3a529e,_0x4d3084);_0x2d3a62=_0x2d3a62['concat'](Jo(_0x36fad6,_0x2770af,_0x210da1,_0x358c09));}return _0x123030&&(_0x2d3a62=_0x2d3a62['concat'](rs(_0x123030,_0x1040bf,_0x3a529e,_0x36c2cc))),_0x2d3a62;}}function Xo(_0x218eac,_0x6e736a,_0x139cf6,_0x155754){const _0x680ebf=_0x6e736a['get'](w());_0x139cf6==null&&_0x680ebf!=null&&(_0x139cf6=Ee(_0x680ebf,w()));let _0x41c0c5=[];return _0x6e736a['children']['inorderTraversal']((_0x6a1db7,_0x29c676)=>{const _0x33740e=_0x139cf6?_0x139cf6['getImmediateChild'](_0x6a1db7):null,_0x248bad=Bo(_0x155754,_0x6a1db7),_0x39c2f7=_0x218eac['operationForChild'](_0x6a1db7);_0x39c2f7&&(_0x41c0c5=_0x41c0c5['concat'](Xo(_0x39c2f7,_0x29c676,_0x33740e,_0x248bad)));}),_0x680ebf&&(_0x41c0c5=_0x41c0c5['concat'](rs(_0x680ebf,_0x218eac,_0x155754,_0x139cf6))),_0x41c0c5;}function Zo(_0x1d0b46,_0xdbfe16){const _0x3e8a7b=_0xdbfe16['query'],_0x3fd092=Ut(_0x1d0b46,_0x3e8a7b);return{'hashFn':()=>(Nu(_0xdbfe16)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x209cb3=>{if(_0x209cb3==='ok')return _0x3fd092?zu(_0x1d0b46,_0x3e8a7b['_path'],_0x3fd092):qu(_0x1d0b46,_0x3e8a7b['_path']);{const _0x544c24=Gl(_0x209cb3,_0x3e8a7b);return Rn(_0x1d0b46,_0x3e8a7b,null,_0x544c24);}}};}function Ut(_0x5e26b9,_0x4e5a6d){const _0x3b83eb=Vn(_0x4e5a6d);return _0x5e26b9['queryToTagMap']['get'](_0x3b83eb);}function Vn(_0x6a2015){return _0x6a2015['_path']['toString']()+'$'+_0x6a2015['_queryIdentifier'];}function as(_0x393077,_0x284ff4){return _0x393077['tagToQueryMap']['get'](_0x284ff4);}function cs(_0x22f50b){const _0x592413=_0x22f50b['indexOf']('$');return f(_0x592413!==-0x1&&_0x592413<_0x22f50b['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x22f50b['substr'](_0x592413+0x1),'path':new C(_0x22f50b['substr'](0x0,_0x592413))};}function ls(_0x2b60bd,_0x3c1b4a,_0x2f64da){const _0x585afb=_0x2b60bd['syncPointTree_']['get'](_0x3c1b4a);f(_0x585afb,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4639c1=Un(_0x2b60bd['pendingWriteTree_'],_0x3c1b4a);return rs(_0x585afb,_0x2f64da,_0x4639c1,null);}function Yu(_0x13c8a9){return _0x13c8a9['fold']((_0x37b2a0,_0x5a5721,_0xc2e58a)=>{if(_0x5a5721&&Te(_0x5a5721))return[Wn(_0x5a5721)];{let _0x4a5a49=[];return _0x5a5721&&(_0x4a5a49=jo(_0x5a5721)),x(_0xc2e58a,(_0x5e2919,_0x6e4ab5)=>{_0x4a5a49=_0x4a5a49['concat'](_0x6e4ab5);}),_0x4a5a49;}});}function At(_0x722cb0){return _0x722cb0['_queryParams']['loadsAllData']()&&!_0x722cb0['_queryParams']['isDefault']()?new(Vu())(_0x722cb0['_repo'],_0x722cb0['_path']):_0x722cb0;}function Qu(_0x4e9bb0,_0x4b63ac){for(let _0x4aca4c=0x0;_0x4aca4c<_0x4b63ac['length'];++_0x4aca4c){const _0x108b5b=_0x4b63ac[_0x4aca4c];if(!_0x108b5b['_queryParams']['loadsAllData']()){const _0x22ed0c=Vn(_0x108b5b),_0x1bad16=_0x4e9bb0['queryToTagMap']['get'](_0x22ed0c);_0x4e9bb0['queryToTagMap']['delete'](_0x22ed0c),_0x4e9bb0['tagToQueryMap']['delete'](_0x1bad16);}}}function Ju(){return Hu++;}function Xu(_0x4ffce6,_0x3b053d,_0x121b21){const _0x1ffe4f=_0x3b053d['_path'],_0x3fe922=Ut(_0x4ffce6,_0x3b053d),_0x39f2ec=Zo(_0x4ffce6,_0x121b21),_0xb9d54c=_0x4ffce6['listenProvider_']['startListening'](At(_0x3b053d),_0x3fe922,_0x39f2ec['hashFn'],_0x39f2ec['onComplete']),_0x35bcfa=_0x4ffce6['syncPointTree_']['subtree'](_0x1ffe4f);if(_0x3fe922)f(!Te(_0x35bcfa['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2aa528=_0x35bcfa['fold']((_0x143740,_0x2ce699,_0x821b94)=>{if(!v(_0x143740)&&_0x2ce699&&Te(_0x2ce699))return[Wn(_0x2ce699)['query']];{let _0x2c0a69=[];return _0x2ce699&&(_0x2c0a69=_0x2c0a69['concat'](jo(_0x2ce699)['map'](_0x320254=>_0x320254['query']))),x(_0x821b94,(_0x4cdc1,_0xeef4e3)=>{_0x2c0a69=_0x2c0a69['concat'](_0xeef4e3);}),_0x2c0a69;}});for(let _0x3f8032=0x0;_0x3f8032<_0x2aa528['length'];++_0x3f8032){const _0x1b00ed=_0x2aa528[_0x3f8032];_0x4ffce6['listenProvider_']['stopListening'](At(_0x1b00ed),Ut(_0x4ffce6,_0x1b00ed));}}return _0xb9d54c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x318256){this['node_']=_0x318256;}['getImmediateChild'](_0x454fff){const _0x49be07=this['node_']['getImmediateChild'](_0x454fff);return new hs(_0x49be07);}['node'](){return this['node_'];}}class us{constructor(_0x3522ff,_0x3ecc1f){this['syncTree_']=_0x3522ff,this['path_']=_0x3ecc1f;}['getImmediateChild'](_0x1739de){const _0x212f98=k(this['path_'],_0x1739de);return new us(this['syncTree_'],_0x212f98);}['node'](){return Bn(this['syncTree_'],this['path_']);}}const Zu=function(_0x2d0dc2){return _0x2d0dc2=_0x2d0dc2||{},_0x2d0dc2['timestamp']=_0x2d0dc2['timestamp']||new Date()['getTime'](),_0x2d0dc2;},_r=function(_0x36f348,_0x4ac70d,_0x32312e){if(!_0x36f348||typeof _0x36f348!='object')return _0x36f348;if(f('.sv'in _0x36f348,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x36f348['.sv']=='string')return ed(_0x36f348['.sv'],_0x4ac70d,_0x32312e);if(typeof _0x36f348['.sv']=='object')return td(_0x36f348['.sv'],_0x4ac70d);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x36f348,null,0x2));},ed=function(_0x276989,_0x2bb893,_0xad873c){switch(_0x276989){case'timestamp':return _0xad873c['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x276989);}},td=function(_0x2bf95e,_0x17e055,_0x9cbd52){_0x2bf95e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2bf95e,null,0x2));const _0x2ce6e2=_0x2bf95e['increment'];typeof _0x2ce6e2!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2ce6e2);const _0x233a3c=_0x17e055['node']();if(f(_0x233a3c!==null&&typeof _0x233a3c<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x233a3c['isLeafNode']())return _0x2ce6e2;const _0x5d566d=_0x233a3c['getValue']();return typeof _0x5d566d!='number'?_0x2ce6e2:_0x5d566d+_0x2ce6e2;},ea=function(_0x8f9f8d,_0x3d381a,_0x3b33d5,_0xe63657){return fs(_0x3d381a,new us(_0x3b33d5,_0x8f9f8d),_0xe63657);},ds=function(_0x27c5b8,_0x40c70e,_0x5c8326){return fs(_0x27c5b8,new hs(_0x40c70e),_0x5c8326);};function fs(_0x4ccdf4,_0x4a6500,_0x389ab0){const _0x25ed28=_0x4ccdf4['getPriority']()['val'](),_0x5d214f=_r(_0x25ed28,_0x4a6500['getImmediateChild']('.priority'),_0x389ab0);let _0x1747a5;if(_0x4ccdf4['isLeafNode']()){const _0x3a0c4e=_0x4ccdf4,_0x579af1=_r(_0x3a0c4e['getValue'](),_0x4a6500,_0x389ab0);return _0x579af1!==_0x3a0c4e['getValue']()||_0x5d214f!==_0x3a0c4e['getPriority']()['val']()?new D(_0x579af1,A(_0x5d214f)):_0x4ccdf4;}else{const _0x1e7881=_0x4ccdf4;return _0x1747a5=_0x1e7881,_0x5d214f!==_0x1e7881['getPriority']()['val']()&&(_0x1747a5=_0x1747a5['updatePriority'](new D(_0x5d214f))),_0x1e7881['forEachChild'](R,(_0x349770,_0x740652)=>{const _0xea160f=fs(_0x740652,_0x4a6500['getImmediateChild'](_0x349770),_0x389ab0);_0xea160f!==_0x740652&&(_0x1747a5=_0x1747a5['updateImmediateChild'](_0x349770,_0xea160f));}),_0x1747a5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x14b7ff='',_0x49c84e=null,_0x2693ce={'children':{},'childCount':0x0}){this['name']=_0x14b7ff,this['parent']=_0x49c84e,this['node']=_0x2693ce;}}function Hn(_0x13a543,_0x2a609c){let _0x27f2a3=_0x2a609c instanceof C?_0x2a609c:new C(_0x2a609c),_0x1aafcd=_0x13a543,_0x92471e=y(_0x27f2a3);for(;_0x92471e!==null;){const _0x18d59a=Me(_0x1aafcd['node']['children'],_0x92471e)||{'children':{},'childCount':0x0};_0x1aafcd=new ps(_0x92471e,_0x1aafcd,_0x18d59a),_0x27f2a3=S(_0x27f2a3),_0x92471e=y(_0x27f2a3);}return _0x1aafcd;}function ze(_0x30d168){return _0x30d168['node']['value'];}function _s(_0x321fee,_0x5c101d){_0x321fee['node']['value']=_0x5c101d,Pi(_0x321fee);}function ta(_0x46f590){return _0x46f590['node']['childCount']>0x0;}function nd(_0x2e54c7){return ze(_0x2e54c7)===void 0x0&&!ta(_0x2e54c7);}function $n(_0x40611a,_0x54228f){x(_0x40611a['node']['children'],(_0x521c38,_0x480415)=>{_0x54228f(new ps(_0x521c38,_0x40611a,_0x480415));});}function na(_0x55a87f,_0x4c552c,_0x309111,_0x5160f8){_0x309111&&_0x4c552c(_0x55a87f),$n(_0x55a87f,_0x221fa9=>{na(_0x221fa9,_0x4c552c,!0x0);});}function id(_0x29d5c2,_0xa40e33,_0x3ab4c3){let _0x3e7603=_0x29d5c2['parent'];for(;_0x3e7603!==null;){if(_0xa40e33(_0x3e7603))return!0x0;_0x3e7603=_0x3e7603['parent'];}return!0x1;}function Yt(_0x2c2bd1){return new C(_0x2c2bd1['parent']===null?_0x2c2bd1['name']:Yt(_0x2c2bd1['parent'])+'/'+_0x2c2bd1['name']);}function Pi(_0x2310fc){_0x2310fc['parent']!==null&&sd(_0x2310fc['parent'],_0x2310fc['name'],_0x2310fc);}function sd(_0x1054f0,_0x5a62c0,_0x23664f){const _0x56c0ff=nd(_0x23664f),_0x45d9fb=Q(_0x1054f0['node']['children'],_0x5a62c0);_0x56c0ff&&_0x45d9fb?(delete _0x1054f0['node']['children'][_0x5a62c0],_0x1054f0['node']['childCount']--,Pi(_0x1054f0)):!_0x56c0ff&&!_0x45d9fb&&(_0x1054f0['node']['children'][_0x5a62c0]=_0x23664f['node'],_0x1054f0['node']['childCount']++,Pi(_0x1054f0));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rd=/[\[\].#$\/\u0000-\u001F\u007F]/,od=/[\[\].#$\u0000-\u001F\u007F]/,hi=0xa*0x400*0x400,gs=function(_0x5db6d0){return typeof _0x5db6d0=='string'&&_0x5db6d0['length']!==0x0&&!rd['test'](_0x5db6d0);},ia=function(_0x5f3052){return typeof _0x5f3052=='string'&&_0x5f3052['length']!==0x0&&!od['test'](_0x5f3052);},ad=function(_0x37dbfa){return _0x37dbfa&&(_0x37dbfa=_0x37dbfa['replace'](/^\/*\.info(\/|$)/,'/')),ia(_0x37dbfa);},Wt=function(_0x163024){return _0x163024===null||typeof _0x163024=='string'||typeof _0x163024=='number'&&!Ln(_0x163024)||_0x163024&&typeof _0x163024=='object'&&Q(_0x163024,'.sv');},Ve=function(_0x24032b,_0x268f49,_0x18fcd3,_0x314799){_0x314799&&_0x268f49===void 0x0||Qt(nt(_0x24032b,'value'),_0x268f49,_0x18fcd3);},Qt=function(_0x4ddcc7,_0x3273f3,_0x39ddde){const _0x2ce726=_0x39ddde instanceof C?new Th(_0x39ddde,_0x4ddcc7):_0x39ddde;if(_0x3273f3===void 0x0)throw new Error(_0x4ddcc7+'contains\x20undefined\x20'+Ne(_0x2ce726));if(typeof _0x3273f3=='function')throw new Error(_0x4ddcc7+'contains\x20a\x20function\x20'+Ne(_0x2ce726)+'\x20with\x20contents\x20=\x20'+_0x3273f3['toString']());if(Ln(_0x3273f3))throw new Error(_0x4ddcc7+'contains\x20'+_0x3273f3['toString']()+'\x20'+Ne(_0x2ce726));if(typeof _0x3273f3=='string'&&_0x3273f3['length']>hi/0x3&&Mn(_0x3273f3)>hi)throw new Error(_0x4ddcc7+'contains\x20a\x20string\x20greater\x20than\x20'+hi+'\x20utf8\x20bytes\x20'+Ne(_0x2ce726)+'\x20(\x27'+_0x3273f3['substring'](0x0,0x32)+'...\x27)');if(_0x3273f3&&typeof _0x3273f3=='object'){let _0x43dfb8=!0x1,_0x353779=!0x1;if(x(_0x3273f3,(_0x35be5e,_0x485b5f)=>{if(_0x35be5e==='.value')_0x43dfb8=!0x0;else{if(_0x35be5e!=='.priority'&&_0x35be5e!=='.sv'&&(_0x353779=!0x0,!gs(_0x35be5e)))throw new Error(_0x4ddcc7+'\x20contains\x20an\x20invalid\x20key\x20('+_0x35be5e+')\x20'+Ne(_0x2ce726)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}Sh(_0x2ce726,_0x35be5e),Qt(_0x4ddcc7,_0x485b5f,_0x2ce726),bh(_0x2ce726);}),_0x43dfb8&&_0x353779)throw new Error(_0x4ddcc7+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x2ce726)+'\x20in\x20addition\x20to\x20actual\x20children.');}},cd=function(_0x2668c4,_0x35444d){let _0x411d28,_0x3b4889;for(_0x411d28=0x0;_0x411d28<_0x35444d['length'];_0x411d28++){_0x3b4889=_0x35444d[_0x411d28];const _0x3b8b3f=Dt(_0x3b4889);for(let _0x13060b=0x0;_0x13060b<_0x3b8b3f['length'];_0x13060b++)if(!(_0x3b8b3f[_0x13060b]==='.priority'&&_0x13060b===_0x3b8b3f['length']-0x1)){if(!gs(_0x3b8b3f[_0x13060b]))throw new Error(_0x2668c4+'contains\x20an\x20invalid\x20key\x20('+_0x3b8b3f[_0x13060b]+')\x20in\x20path\x20'+_0x3b4889['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x35444d['sort'](Ch);let _0x22a5bb=null;for(_0x411d28=0x0;_0x411d28<_0x35444d['length'];_0x411d28++){if(_0x3b4889=_0x35444d[_0x411d28],_0x22a5bb!==null&&G(_0x22a5bb,_0x3b4889))throw new Error(_0x2668c4+'contains\x20a\x20path\x20'+_0x22a5bb['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3b4889['toString']());_0x22a5bb=_0x3b4889;}},sa=function(_0x2a6a34,_0x5e0553,_0x17a4ef,_0x3447fc){const _0x16e275=nt(_0x2a6a34,'values');if(!(_0x5e0553&&typeof _0x5e0553=='object')||Array['isArray'](_0x5e0553))throw new Error(_0x16e275+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1ac275=[];x(_0x5e0553,(_0x4fcdf3,_0x2d15d9)=>{const _0x453ff8=new C(_0x4fcdf3);if(Qt(_0x16e275,_0x2d15d9,k(_0x17a4ef,_0x453ff8)),zi(_0x453ff8)==='.priority'&&!Wt(_0x2d15d9))throw new Error(_0x16e275+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x453ff8['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1ac275['push'](_0x453ff8);}),cd(_0x16e275,_0x1ac275);},ld=function(_0x5c35a6,_0x5d7c01,_0x43b0b5){if(Ln(_0x5d7c01))throw new Error(nt(_0x5c35a6,'priority')+'is\x20'+_0x5d7c01['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Wt(_0x5d7c01))throw new Error(nt(_0x5c35a6,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ms=function(_0x5b125f,_0x24197a,_0x18d489,_0x4f9afa){if(!ia(_0x18d489))throw new Error(nt(_0x5b125f,_0x24197a)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x18d489+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},hd=function(_0x1de641,_0x33ec5c,_0x32d951,_0x26a2d6){_0x32d951&&(_0x32d951=_0x32d951['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x1de641,_0x33ec5c,_0x32d951);},Oe=function(_0x4fbe79,_0x35ff7e){if(y(_0x35ff7e)==='.info')throw new Error(_0x4fbe79+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},ud=function(_0x2debfb,_0x2ea81f){const _0x1a77f7=_0x2ea81f['path']['toString']();if(typeof _0x2ea81f['repoInfo']['host']!='string'||_0x2ea81f['repoInfo']['host']['length']===0x0||!gs(_0x2ea81f['repoInfo']['namespace'])&&_0x2ea81f['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x1a77f7['length']!==0x0&&!ad(_0x1a77f7))throw new Error(nt(_0x2debfb,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Gn(_0x30d6ad,_0x5c99dc){let _0x35118f=null;for(let _0x1db2d4=0x0;_0x1db2d4<_0x5c99dc['length'];_0x1db2d4++){const _0x4a8b28=_0x5c99dc[_0x1db2d4],_0x410be1=_0x4a8b28['getPath']();_0x35118f!==null&&!ji(_0x410be1,_0x35118f['path'])&&(_0x30d6ad['eventLists_']['push'](_0x35118f),_0x35118f=null),_0x35118f===null&&(_0x35118f={'events':[],'path':_0x410be1}),_0x35118f['events']['push'](_0x4a8b28);}_0x35118f&&_0x30d6ad['eventLists_']['push'](_0x35118f);}function ra(_0x112d73,_0x354b1d,_0x4d7704){Gn(_0x112d73,_0x4d7704),oa(_0x112d73,_0x24e0ba=>ji(_0x24e0ba,_0x354b1d));}function V(_0x33c18b,_0x683196,_0x225ce0){Gn(_0x33c18b,_0x225ce0),oa(_0x33c18b,_0x2881ea=>G(_0x2881ea,_0x683196)||G(_0x683196,_0x2881ea));}function oa(_0x342c0a,_0x3acc9b){_0x342c0a['recursionDepth_']++;let _0x360f2d=!0x0;for(let _0x36ab89=0x0;_0x36ab89<_0x342c0a['eventLists_']['length'];_0x36ab89++){const _0x5a699e=_0x342c0a['eventLists_'][_0x36ab89];if(_0x5a699e){const _0x3e90ef=_0x5a699e['path'];_0x3acc9b(_0x3e90ef)?(fd(_0x342c0a['eventLists_'][_0x36ab89]),_0x342c0a['eventLists_'][_0x36ab89]=null):_0x360f2d=!0x1;}}_0x360f2d&&(_0x342c0a['eventLists_']=[]),_0x342c0a['recursionDepth_']--;}function fd(_0x5184ff){for(let _0x9c9fd9=0x0;_0x9c9fd9<_0x5184ff['events']['length'];_0x9c9fd9++){const _0xc9d94c=_0x5184ff['events'][_0x9c9fd9];if(_0xc9d94c!==null){_0x5184ff['events'][_0x9c9fd9]=null;const _0x56107c=_0xc9d94c['getEventRunner']();Tt&&L('event:\x20'+_0xc9d94c['toString']()),dt(_0x56107c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const aa='repo_interrupt',pd=0x19;class _d{constructor(_0x358296,_0x13044d,_0x39b58c,_0x2d0e35){this['repoInfo_']=_0x358296,this['forceRestClient_']=_0x13044d,this['authTokenProvider_']=_0x39b58c,this['appCheckProvider_']=_0x2d0e35,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new dd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=vn(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function gd(_0x5a2861,_0x5f2de6,_0x1e1ab9){if(_0x5a2861['stats_']=Gi(_0x5a2861['repoInfo_']),_0x5a2861['forceRestClient_']||Kl())_0x5a2861['server_']=new yn(_0x5a2861['repoInfo_'],(_0x178296,_0x5a9243,_0x24164b,_0x18e731)=>{gr(_0x5a2861,_0x178296,_0x5a9243,_0x24164b,_0x18e731);},_0x5a2861['authTokenProvider_'],_0x5a2861['appCheckProvider_']),setTimeout(()=>mr(_0x5a2861,!0x0),0x0);else{if(typeof _0x1e1ab9<'u'&&_0x1e1ab9!==null){if(typeof _0x1e1ab9!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1e1ab9);}catch(_0x38913b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x38913b);}}_0x5a2861['persistentConnection_']=new se(_0x5a2861['repoInfo_'],_0x5f2de6,(_0x48e4e9,_0x1f8398,_0x2d2c20,_0x2c373c)=>{gr(_0x5a2861,_0x48e4e9,_0x1f8398,_0x2d2c20,_0x2c373c);},_0x8984cb=>{mr(_0x5a2861,_0x8984cb);},_0x58c48d=>{md(_0x5a2861,_0x58c48d);},_0x5a2861['authTokenProvider_'],_0x5a2861['appCheckProvider_'],_0x1e1ab9),_0x5a2861['server_']=_0x5a2861['persistentConnection_'];}_0x5a2861['authTokenProvider_']['addTokenChangeListener'](_0x219b79=>{_0x5a2861['server_']['refreshAuthToken'](_0x219b79);}),_0x5a2861['appCheckProvider_']['addTokenChangeListener'](_0xe9e66a=>{_0x5a2861['server_']['refreshAppCheckToken'](_0xe9e66a['token']);}),_0x5a2861['statsReporter_']=Zl(_0x5a2861['repoInfo_'],()=>new Zh(_0x5a2861['stats_'],_0x5a2861['server_'])),_0x5a2861['infoData_']=new Kh(),_0x5a2861['infoSyncTree_']=new pr({'startListening':(_0x561446,_0x1d8f43,_0x26caa2,_0x2cd9fa)=>{let _0x2819e1=[];const _0x546860=_0x5a2861['infoData_']['getNode'](_0x561446['_path']);return _0x546860['isEmpty']()||(_0x2819e1=Kt(_0x5a2861['infoSyncTree_'],_0x561446['_path'],_0x546860),setTimeout(()=>{_0x2cd9fa('ok');},0x0)),_0x2819e1;},'stopListening':()=>{}}),ys(_0x5a2861,'connected',!0x1),_0x5a2861['serverSyncTree_']=new pr({'startListening':(_0x30b92b,_0x23f7e0,_0x17ff17,_0x4446e8)=>(_0x5a2861['server_']['listen'](_0x30b92b,_0x17ff17,_0x23f7e0,(_0x15e337,_0x9c6cdd)=>{const _0x16d438=_0x4446e8(_0x15e337,_0x9c6cdd);V(_0x5a2861['eventQueue_'],_0x30b92b['_path'],_0x16d438);}),[]),'stopListening':(_0x10876f,_0x5ae7a9)=>{_0x5a2861['server_']['unlisten'](_0x10876f,_0x5ae7a9);}});}function ca(_0x3f26e4){const _0x2cea77=_0x3f26e4['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x2cea77;}function Jt(_0x4e85d4){return Zu({'timestamp':ca(_0x4e85d4)});}function gr(_0x3c907f,_0xc34955,_0xaf8ee4,_0x2f3557,_0x6d08a8){_0x3c907f['dataUpdateCount']++;const _0x2fe7db=new C(_0xc34955);_0xaf8ee4=_0x3c907f['interceptServerDataCallback_']?_0x3c907f['interceptServerDataCallback_'](_0xc34955,_0xaf8ee4):_0xaf8ee4;let _0x181af9=[];if(_0x6d08a8){if(_0x2f3557){const _0x298c1d=pn(_0xaf8ee4,_0x3d8e91=>A(_0x3d8e91));_0x181af9=ju(_0x3c907f['serverSyncTree_'],_0x2fe7db,_0x298c1d,_0x6d08a8);}else{const _0x5dc148=A(_0xaf8ee4);_0x181af9=Qo(_0x3c907f['serverSyncTree_'],_0x2fe7db,_0x5dc148,_0x6d08a8);}}else{if(_0x2f3557){const _0x40ba3b=pn(_0xaf8ee4,_0x13b201=>A(_0x13b201));_0x181af9=Gu(_0x3c907f['serverSyncTree_'],_0x2fe7db,_0x40ba3b);}else{const _0xc702ad=A(_0xaf8ee4);_0x181af9=Kt(_0x3c907f['serverSyncTree_'],_0x2fe7db,_0xc702ad);}}let _0x368528=_0x2fe7db;_0x181af9['length']>0x0&&(_0x368528=at(_0x3c907f,_0x2fe7db)),V(_0x3c907f['eventQueue_'],_0x368528,_0x181af9);}function mr(_0x16775b,_0x507987){ys(_0x16775b,'connected',_0x507987),_0x507987===!0x1&&Id(_0x16775b);}function md(_0x2612cf,_0x2dd1fa){x(_0x2dd1fa,(_0xd3fe81,_0x31db40)=>{ys(_0x2612cf,_0xd3fe81,_0x31db40);});}function ys(_0x384565,_0x715576,_0x4bc1cf){const _0x1c5be4=new C('/.info/'+_0x715576),_0x203847=A(_0x4bc1cf);_0x384565['infoData_']['updateSnapshot'](_0x1c5be4,_0x203847);const _0x47dbf7=Kt(_0x384565['infoSyncTree_'],_0x1c5be4,_0x203847);V(_0x384565['eventQueue_'],_0x1c5be4,_0x47dbf7);}function qn(_0x26f434){return _0x26f434['nextWriteId_']++;}function yd(_0x30e272,_0xd9de26,_0x2e48c6){const _0x4e9ec5=Ku(_0x30e272['serverSyncTree_'],_0xd9de26);return _0x4e9ec5!=null?Promise['resolve'](_0x4e9ec5):_0x30e272['server_']['get'](_0xd9de26)['then'](_0x3c79e5=>{const _0x51100d=A(_0x3c79e5)['withIndex'](_0xd9de26['_queryParams']['getIndex']());Ni(_0x30e272['serverSyncTree_'],_0xd9de26,_0x2e48c6,!0x0);let _0x374d5c;if(_0xd9de26['_queryParams']['loadsAllData']())_0x374d5c=Kt(_0x30e272['serverSyncTree_'],_0xd9de26['_path'],_0x51100d);else{const _0x1657ed=Ut(_0x30e272['serverSyncTree_'],_0xd9de26);_0x374d5c=Qo(_0x30e272['serverSyncTree_'],_0xd9de26['_path'],_0x51100d,_0x1657ed);}return V(_0x30e272['eventQueue_'],_0xd9de26['_path'],_0x374d5c),Rn(_0x30e272['serverSyncTree_'],_0xd9de26,_0x2e48c6,null,!0x0),_0x51100d;},_0x26c831=>(_t(_0x30e272,'get\x20for\x20query\x20'+O(_0xd9de26)+'\x20failed:\x20'+_0x26c831),Promise['reject'](new Error(_0x26c831))));}function vd(_0x520eac,_0x12cdc0,_0x30d31c,_0xc4104f,_0x5b0493){_t(_0x520eac,'set',{'path':_0x12cdc0['toString'](),'value':_0x30d31c,'priority':_0xc4104f});const _0xb7f049=Jt(_0x520eac),_0x406432=A(_0x30d31c,_0xc4104f),_0xa782f8=Bn(_0x520eac['serverSyncTree_'],_0x12cdc0),_0x3abf5d=ds(_0x406432,_0xa782f8,_0xb7f049),_0x5203df=qn(_0x520eac),_0x5c50e1=os(_0x520eac['serverSyncTree_'],_0x12cdc0,_0x3abf5d,_0x5203df,!0x0);Gn(_0x520eac['eventQueue_'],_0x5c50e1),_0x520eac['server_']['put'](_0x12cdc0['toString'](),_0x406432['val'](!0x0),(_0x5a44ba,_0x1cf903)=>{const _0x5218da=_0x5a44ba==='ok';_0x5218da||U('set\x20at\x20'+_0x12cdc0+'\x20failed:\x20'+_0x5a44ba);const _0x2a10c3=_e(_0x520eac['serverSyncTree_'],_0x5203df,!_0x5218da);V(_0x520eac['eventQueue_'],_0x12cdc0,_0x2a10c3),Se(_0x520eac,_0x5b0493,_0x5a44ba,_0x1cf903);});const _0x1b05e1=Es(_0x520eac,_0x12cdc0);at(_0x520eac,_0x1b05e1),V(_0x520eac['eventQueue_'],_0x1b05e1,[]);}function Ed(_0x5162d2,_0x9cd80d,_0x376ed7,_0xe43843){_t(_0x5162d2,'update',{'path':_0x9cd80d['toString'](),'value':_0x376ed7});let _0x3ed219=!0x0;const _0x3d8ae3=Jt(_0x5162d2),_0x51a4ef={};if(x(_0x376ed7,(_0x4339c9,_0xcb108d)=>{_0x3ed219=!0x1,_0x51a4ef[_0x4339c9]=ea(k(_0x9cd80d,_0x4339c9),A(_0xcb108d),_0x5162d2['serverSyncTree_'],_0x3d8ae3);}),_0x3ed219)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0x5162d2,_0xe43843,'ok',void 0x0);else{const _0x398deb=qn(_0x5162d2),_0xea1d2d=$u(_0x5162d2['serverSyncTree_'],_0x9cd80d,_0x51a4ef,_0x398deb);Gn(_0x5162d2['eventQueue_'],_0xea1d2d),_0x5162d2['server_']['merge'](_0x9cd80d['toString'](),_0x376ed7,(_0x4a301b,_0x28b196)=>{const _0x435881=_0x4a301b==='ok';_0x435881||U('update\x20at\x20'+_0x9cd80d+'\x20failed:\x20'+_0x4a301b);const _0x248661=_e(_0x5162d2['serverSyncTree_'],_0x398deb,!_0x435881),_0x35e244=_0x248661['length']>0x0?at(_0x5162d2,_0x9cd80d):_0x9cd80d;V(_0x5162d2['eventQueue_'],_0x35e244,_0x248661),Se(_0x5162d2,_0xe43843,_0x4a301b,_0x28b196);}),x(_0x376ed7,_0x5bb3f5=>{const _0x1e30d2=Es(_0x5162d2,k(_0x9cd80d,_0x5bb3f5));at(_0x5162d2,_0x1e30d2);}),V(_0x5162d2['eventQueue_'],_0x9cd80d,[]);}}function Id(_0x2f3e0a){_t(_0x2f3e0a,'onDisconnectEvents');const _0x20b3b0=Jt(_0x2f3e0a),_0x12492e=vn();Ti(_0x2f3e0a['onDisconnect_'],w(),(_0x5e586f,_0x38a177)=>{const _0x45f973=ea(_0x5e586f,_0x38a177,_0x2f3e0a['serverSyncTree_'],_0x20b3b0);ft(_0x12492e,_0x5e586f,_0x45f973);});let _0x1b5258=[];Ti(_0x12492e,w(),(_0x28a073,_0xb1145c)=>{_0x1b5258=_0x1b5258['concat'](Kt(_0x2f3e0a['serverSyncTree_'],_0x28a073,_0xb1145c));const _0x5aff1b=Es(_0x2f3e0a,_0x28a073);at(_0x2f3e0a,_0x5aff1b);}),_0x2f3e0a['onDisconnect_']=vn(),V(_0x2f3e0a['eventQueue_'],w(),_0x1b5258);}function wd(_0x5e6f0f,_0xf96c7f,_0x98a0ac){_0x5e6f0f['server_']['onDisconnectCancel'](_0xf96c7f['toString'](),(_0x3a8fd3,_0x2ef91e)=>{_0x3a8fd3==='ok'&&Ci(_0x5e6f0f['onDisconnect_'],_0xf96c7f),Se(_0x5e6f0f,_0x98a0ac,_0x3a8fd3,_0x2ef91e);});}function yr(_0x2dcc77,_0xc58216,_0x5aaab7,_0x539ce3){const _0x725116=A(_0x5aaab7);_0x2dcc77['server_']['onDisconnectPut'](_0xc58216['toString'](),_0x725116['val'](!0x0),(_0x1f8a7c,_0x288ec9)=>{_0x1f8a7c==='ok'&&ft(_0x2dcc77['onDisconnect_'],_0xc58216,_0x725116),Se(_0x2dcc77,_0x539ce3,_0x1f8a7c,_0x288ec9);});}function Cd(_0x296eb9,_0x326d18,_0x475bcb,_0x4ac34c,_0x45653a){const _0x3219ad=A(_0x475bcb,_0x4ac34c);_0x296eb9['server_']['onDisconnectPut'](_0x326d18['toString'](),_0x3219ad['val'](!0x0),(_0x192a9b,_0x38a078)=>{_0x192a9b==='ok'&&ft(_0x296eb9['onDisconnect_'],_0x326d18,_0x3219ad),Se(_0x296eb9,_0x45653a,_0x192a9b,_0x38a078);});}function Td(_0x5e01eb,_0x57e2b5,_0x358c73,_0x51f1e3){if(fn(_0x358c73)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Se(_0x5e01eb,_0x51f1e3,'ok',void 0x0);return;}_0x5e01eb['server_']['onDisconnectMerge'](_0x57e2b5['toString'](),_0x358c73,(_0x26c53b,_0x58d7c4)=>{_0x26c53b==='ok'&&x(_0x358c73,(_0x3de3ef,_0x23c31f)=>{const _0x226740=A(_0x23c31f);ft(_0x5e01eb['onDisconnect_'],k(_0x57e2b5,_0x3de3ef),_0x226740);}),Se(_0x5e01eb,_0x51f1e3,_0x26c53b,_0x58d7c4);});}function Sd(_0x2abc33,_0x439828,_0x29550b){let _0x4a780c;y(_0x439828['_path'])==='.info'?_0x4a780c=Ni(_0x2abc33['infoSyncTree_'],_0x439828,_0x29550b):_0x4a780c=Ni(_0x2abc33['serverSyncTree_'],_0x439828,_0x29550b),ra(_0x2abc33['eventQueue_'],_0x439828['_path'],_0x4a780c);}function bd(_0xfd2fe6,_0x1eb811,_0x39a8e5){let _0x1e9e49;y(_0x1eb811['_path'])==='.info'?_0x1e9e49=Rn(_0xfd2fe6['infoSyncTree_'],_0x1eb811,_0x39a8e5):_0x1e9e49=Rn(_0xfd2fe6['serverSyncTree_'],_0x1eb811,_0x39a8e5),ra(_0xfd2fe6['eventQueue_'],_0x1eb811['_path'],_0x1e9e49);}function la(_0x3026ef){_0x3026ef['persistentConnection_']&&_0x3026ef['persistentConnection_']['interrupt'](aa);}function Rd(_0x53a59b){_0x53a59b['persistentConnection_']&&_0x53a59b['persistentConnection_']['resume'](aa);}function _t(_0x207fb3,..._0x450dd4){let _0x1860f4='';_0x207fb3['persistentConnection_']&&(_0x1860f4=_0x207fb3['persistentConnection_']['id']+':'),L(_0x1860f4,..._0x450dd4);}function Se(_0x424473,_0x236b32,_0x20479b,_0x3a7a10){_0x236b32&&dt(()=>{if(_0x20479b==='ok')_0x236b32(null);else{const _0x4dc9a7=(_0x20479b||'error')['toUpperCase']();let _0x399db4=_0x4dc9a7;_0x3a7a10&&(_0x399db4+=':\x20'+_0x3a7a10);const _0x14103a=new Error(_0x399db4);_0x14103a['code']=_0x4dc9a7,_0x236b32(_0x14103a);}});}function Ad(_0x30f86c,_0x502a53,_0x4cc221,_0x3f41dc,_0x14996c,_0x133805){_t(_0x30f86c,'transaction\x20on\x20'+_0x502a53);const _0x34bd60={'path':_0x502a53,'update':_0x4cc221,'onComplete':_0x3f41dc,'status':null,'order':so(),'applyLocally':_0x133805,'retryCount':0x0,'unwatcher':_0x14996c,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3d4a4c=vs(_0x30f86c,_0x502a53,void 0x0);_0x34bd60['currentInputSnapshot']=_0x3d4a4c;const _0x15042e=_0x34bd60['update'](_0x3d4a4c['val']());if(_0x15042e===void 0x0)_0x34bd60['unwatcher'](),_0x34bd60['currentOutputSnapshotRaw']=null,_0x34bd60['currentOutputSnapshotResolved']=null,_0x34bd60['onComplete']&&_0x34bd60['onComplete'](null,!0x1,_0x34bd60['currentInputSnapshot']);else{Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x15042e,_0x34bd60['path']),_0x34bd60['status']=0x0;const _0x31948d=Hn(_0x30f86c['transactionQueueTree_'],_0x502a53),_0x3177d9=ze(_0x31948d)||[];_0x3177d9['push'](_0x34bd60),_s(_0x31948d,_0x3177d9);let _0x140de2;typeof _0x15042e=='object'&&_0x15042e!==null&&Q(_0x15042e,'.priority')?(_0x140de2=Me(_0x15042e,'.priority'),f(Wt(_0x140de2),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x140de2=(Bn(_0x30f86c['serverSyncTree_'],_0x502a53)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x11cefb=Jt(_0x30f86c),_0x5d6c9b=A(_0x15042e,_0x140de2),_0x1c63cd=ds(_0x5d6c9b,_0x3d4a4c,_0x11cefb);_0x34bd60['currentOutputSnapshotRaw']=_0x5d6c9b,_0x34bd60['currentOutputSnapshotResolved']=_0x1c63cd,_0x34bd60['currentWriteId']=qn(_0x30f86c);const _0x1d1f28=os(_0x30f86c['serverSyncTree_'],_0x502a53,_0x1c63cd,_0x34bd60['currentWriteId'],_0x34bd60['applyLocally']);V(_0x30f86c['eventQueue_'],_0x502a53,_0x1d1f28),zn(_0x30f86c,_0x30f86c['transactionQueueTree_']);}}function vs(_0x50b537,_0x559fab,_0x5c4e01){return Bn(_0x50b537['serverSyncTree_'],_0x559fab,_0x5c4e01)||g['EMPTY_NODE'];}function zn(_0x3c1857,_0x3ad217=_0x3c1857['transactionQueueTree_']){if(_0x3ad217||jn(_0x3c1857,_0x3ad217),ze(_0x3ad217)){const _0x45d9dd=ua(_0x3c1857,_0x3ad217);f(_0x45d9dd['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x45d9dd['every'](_0x388cdf=>_0x388cdf['status']===0x0)&&kd(_0x3c1857,Yt(_0x3ad217),_0x45d9dd);}else ta(_0x3ad217)&&$n(_0x3ad217,_0x9bd199=>{zn(_0x3c1857,_0x9bd199);});}function kd(_0x19a51d,_0x28ac6c,_0x2e7e39){const _0x1924e1=_0x2e7e39['map'](_0x4a03c3=>_0x4a03c3['currentWriteId']),_0x11e2b9=vs(_0x19a51d,_0x28ac6c,_0x1924e1);let _0x3abe7a=_0x11e2b9;const _0xd2bfe8=_0x11e2b9['hash']();for(let _0xf327e5=0x0;_0xf327e5<_0x2e7e39['length'];_0xf327e5++){const _0x4727f5=_0x2e7e39[_0xf327e5];f(_0x4727f5['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4727f5['status']=0x1,_0x4727f5['retryCount']++;const _0x4e1194=F(_0x28ac6c,_0x4727f5['path']);_0x3abe7a=_0x3abe7a['updateChild'](_0x4e1194,_0x4727f5['currentOutputSnapshotRaw']);}const _0x3f38d4=_0x3abe7a['val'](!0x0),_0x2aae3d=_0x28ac6c;_0x19a51d['server_']['put'](_0x2aae3d['toString'](),_0x3f38d4,_0x1ab6ce=>{_t(_0x19a51d,'transaction\x20put\x20response',{'path':_0x2aae3d['toString'](),'status':_0x1ab6ce});let _0x12d6fb=[];if(_0x1ab6ce==='ok'){const _0x4818ad=[];for(let _0x63b680=0x0;_0x63b680<_0x2e7e39['length'];_0x63b680++)_0x2e7e39[_0x63b680]['status']=0x2,_0x12d6fb=_0x12d6fb['concat'](_e(_0x19a51d['serverSyncTree_'],_0x2e7e39[_0x63b680]['currentWriteId'])),_0x2e7e39[_0x63b680]['onComplete']&&_0x4818ad['push'](()=>_0x2e7e39[_0x63b680]['onComplete'](null,!0x0,_0x2e7e39[_0x63b680]['currentOutputSnapshotResolved'])),_0x2e7e39[_0x63b680]['unwatcher']();jn(_0x19a51d,Hn(_0x19a51d['transactionQueueTree_'],_0x28ac6c)),zn(_0x19a51d,_0x19a51d['transactionQueueTree_']),V(_0x19a51d['eventQueue_'],_0x28ac6c,_0x12d6fb);for(let _0xf251c=0x0;_0xf251c<_0x4818ad['length'];_0xf251c++)dt(_0x4818ad[_0xf251c]);}else{if(_0x1ab6ce==='datastale'){for(let _0x1c182a=0x0;_0x1c182a<_0x2e7e39['length'];_0x1c182a++)_0x2e7e39[_0x1c182a]['status']===0x3?_0x2e7e39[_0x1c182a]['status']=0x4:_0x2e7e39[_0x1c182a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2aae3d['toString']()+'\x20failed:\x20'+_0x1ab6ce);for(let _0x35599d=0x0;_0x35599d<_0x2e7e39['length'];_0x35599d++)_0x2e7e39[_0x35599d]['status']=0x4,_0x2e7e39[_0x35599d]['abortReason']=_0x1ab6ce;}at(_0x19a51d,_0x28ac6c);}},_0xd2bfe8);}function at(_0x1640e4,_0x565844){const _0x3c63ba=ha(_0x1640e4,_0x565844),_0x439d1b=Yt(_0x3c63ba),_0x5f69ee=ua(_0x1640e4,_0x3c63ba);return Nd(_0x1640e4,_0x5f69ee,_0x439d1b),_0x439d1b;}function Nd(_0x577d5f,_0x320b73,_0x465cad){if(_0x320b73['length']===0x0)return;const _0x211bca=[];let _0x8a8f94=[];const _0x553205=_0x320b73['filter'](_0x53f409=>_0x53f409['status']===0x0)['map'](_0x44d2d9=>_0x44d2d9['currentWriteId']);for(let _0x3e4642=0x0;_0x3e4642<_0x320b73['length'];_0x3e4642++){const _0x12a1f9=_0x320b73[_0x3e4642],_0x48a89e=F(_0x465cad,_0x12a1f9['path']);let _0x510fa9=!0x1,_0x5330bf;if(f(_0x48a89e!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x12a1f9['status']===0x4)_0x510fa9=!0x0,_0x5330bf=_0x12a1f9['abortReason'],_0x8a8f94=_0x8a8f94['concat'](_e(_0x577d5f['serverSyncTree_'],_0x12a1f9['currentWriteId'],!0x0));else{if(_0x12a1f9['status']===0x0){if(_0x12a1f9['retryCount']>=pd)_0x510fa9=!0x0,_0x5330bf='maxretry',_0x8a8f94=_0x8a8f94['concat'](_e(_0x577d5f['serverSyncTree_'],_0x12a1f9['currentWriteId'],!0x0));else{const _0xb6b026=vs(_0x577d5f,_0x12a1f9['path'],_0x553205);_0x12a1f9['currentInputSnapshot']=_0xb6b026;const _0x7ad70b=_0x320b73[_0x3e4642]['update'](_0xb6b026['val']());if(_0x7ad70b!==void 0x0){Qt('transaction\x20failed:\x20Data\x20returned\x20',_0x7ad70b,_0x12a1f9['path']);let _0x44ce1a=A(_0x7ad70b);typeof _0x7ad70b=='object'&&_0x7ad70b!=null&&Q(_0x7ad70b,'.priority')||(_0x44ce1a=_0x44ce1a['updatePriority'](_0xb6b026['getPriority']()));const _0x89173b=_0x12a1f9['currentWriteId'],_0x1f82c9=Jt(_0x577d5f),_0x4c26e5=ds(_0x44ce1a,_0xb6b026,_0x1f82c9);_0x12a1f9['currentOutputSnapshotRaw']=_0x44ce1a,_0x12a1f9['currentOutputSnapshotResolved']=_0x4c26e5,_0x12a1f9['currentWriteId']=qn(_0x577d5f),_0x553205['splice'](_0x553205['indexOf'](_0x89173b),0x1),_0x8a8f94=_0x8a8f94['concat'](os(_0x577d5f['serverSyncTree_'],_0x12a1f9['path'],_0x4c26e5,_0x12a1f9['currentWriteId'],_0x12a1f9['applyLocally'])),_0x8a8f94=_0x8a8f94['concat'](_e(_0x577d5f['serverSyncTree_'],_0x89173b,!0x0));}else _0x510fa9=!0x0,_0x5330bf='nodata',_0x8a8f94=_0x8a8f94['concat'](_e(_0x577d5f['serverSyncTree_'],_0x12a1f9['currentWriteId'],!0x0));}}}V(_0x577d5f['eventQueue_'],_0x465cad,_0x8a8f94),_0x8a8f94=[],_0x510fa9&&(_0x320b73[_0x3e4642]['status']=0x2,function(_0x11f211){setTimeout(_0x11f211,Math['floor'](0x0));}(_0x320b73[_0x3e4642]['unwatcher']),_0x320b73[_0x3e4642]['onComplete']&&(_0x5330bf==='nodata'?_0x211bca['push'](()=>_0x320b73[_0x3e4642]['onComplete'](null,!0x1,_0x320b73[_0x3e4642]['currentInputSnapshot'])):_0x211bca['push'](()=>_0x320b73[_0x3e4642]['onComplete'](new Error(_0x5330bf),!0x1,null))));}jn(_0x577d5f,_0x577d5f['transactionQueueTree_']);for(let _0x9757a1=0x0;_0x9757a1<_0x211bca['length'];_0x9757a1++)dt(_0x211bca[_0x9757a1]);zn(_0x577d5f,_0x577d5f['transactionQueueTree_']);}function ha(_0x221b9d,_0x3177a3){let _0x525315,_0x864ff=_0x221b9d['transactionQueueTree_'];for(_0x525315=y(_0x3177a3);_0x525315!==null&&ze(_0x864ff)===void 0x0;)_0x864ff=Hn(_0x864ff,_0x525315),_0x3177a3=S(_0x3177a3),_0x525315=y(_0x3177a3);return _0x864ff;}function ua(_0x53a8f5,_0x573be1){const _0x2786c9=[];return da(_0x53a8f5,_0x573be1,_0x2786c9),_0x2786c9['sort']((_0x1722e0,_0x2fdae8)=>_0x1722e0['order']-_0x2fdae8['order']),_0x2786c9;}function da(_0xd2c1ac,_0x2090d5,_0x4ec9df){const _0x3f1e21=ze(_0x2090d5);if(_0x3f1e21){for(let _0x3f79e1=0x0;_0x3f79e1<_0x3f1e21['length'];_0x3f79e1++)_0x4ec9df['push'](_0x3f1e21[_0x3f79e1]);}$n(_0x2090d5,_0x46cf72=>{da(_0xd2c1ac,_0x46cf72,_0x4ec9df);});}function jn(_0x38b72a,_0x54f63b){const _0x1d85ce=ze(_0x54f63b);if(_0x1d85ce){let _0x555a93=0x0;for(let _0x5ef2cc=0x0;_0x5ef2cc<_0x1d85ce['length'];_0x5ef2cc++)_0x1d85ce[_0x5ef2cc]['status']!==0x2&&(_0x1d85ce[_0x555a93]=_0x1d85ce[_0x5ef2cc],_0x555a93++);_0x1d85ce['length']=_0x555a93,_s(_0x54f63b,_0x1d85ce['length']>0x0?_0x1d85ce:void 0x0);}$n(_0x54f63b,_0x4ff0df=>{jn(_0x38b72a,_0x4ff0df);});}function Es(_0x4f44af,_0x13803f){const _0x34aee1=Yt(ha(_0x4f44af,_0x13803f)),_0x1eb687=Hn(_0x4f44af['transactionQueueTree_'],_0x13803f);return id(_0x1eb687,_0x3c03c6=>{ui(_0x4f44af,_0x3c03c6);}),ui(_0x4f44af,_0x1eb687),na(_0x1eb687,_0x1a7a7a=>{ui(_0x4f44af,_0x1a7a7a);}),_0x34aee1;}function ui(_0x569c51,_0x455772){const _0xf9f58d=ze(_0x455772);if(_0xf9f58d){const _0x350716=[];let _0x58aad3=[],_0x582093=-0x1;for(let _0x506b27=0x0;_0x506b27<_0xf9f58d['length'];_0x506b27++)_0xf9f58d[_0x506b27]['status']===0x3||(_0xf9f58d[_0x506b27]['status']===0x1?(f(_0x582093===_0x506b27-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x582093=_0x506b27,_0xf9f58d[_0x506b27]['status']=0x3,_0xf9f58d[_0x506b27]['abortReason']='set'):(f(_0xf9f58d[_0x506b27]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xf9f58d[_0x506b27]['unwatcher'](),_0x58aad3=_0x58aad3['concat'](_e(_0x569c51['serverSyncTree_'],_0xf9f58d[_0x506b27]['currentWriteId'],!0x0)),_0xf9f58d[_0x506b27]['onComplete']&&_0x350716['push'](_0xf9f58d[_0x506b27]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x582093===-0x1?_s(_0x455772,void 0x0):_0xf9f58d['length']=_0x582093+0x1,V(_0x569c51['eventQueue_'],Yt(_0x455772),_0x58aad3);for(let _0x3adf4c=0x0;_0x3adf4c<_0x350716['length'];_0x3adf4c++)dt(_0x350716[_0x3adf4c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pd(_0x55245e){let _0x464bec='';const _0x17c4b5=_0x55245e['split']('/');for(let _0x171598=0x0;_0x171598<_0x17c4b5['length'];_0x171598++)if(_0x17c4b5[_0x171598]['length']>0x0){let _0x3d63f4=_0x17c4b5[_0x171598];try{_0x3d63f4=decodeURIComponent(_0x3d63f4['replace'](/\+/g,'\x20'));}catch{}_0x464bec+='/'+_0x3d63f4;}return _0x464bec;}function Od(_0x3498fb){const _0x581f96={};_0x3498fb['charAt'](0x0)==='?'&&(_0x3498fb=_0x3498fb['substring'](0x1));for(const _0x20099c of _0x3498fb['split']('&')){if(_0x20099c['length']===0x0)continue;const _0x1d9033=_0x20099c['split']('=');_0x1d9033['length']===0x2?_0x581f96[decodeURIComponent(_0x1d9033[0x0])]=decodeURIComponent(_0x1d9033[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x20099c+'\x27\x20in\x20query\x20\x27'+_0x3498fb+'\x27');}return _0x581f96;}const vr=function(_0x36d02d,_0x50ef18){const _0xc845c5=Dd(_0x36d02d),_0x2a5429=_0xc845c5['namespace'];_0xc845c5['domain']==='firebase.com'&&ae(_0xc845c5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2a5429||_0x2a5429==='undefined')&&_0xc845c5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xc845c5['secure']||Wl();const _0x50f4c9=_0xc845c5['scheme']==='ws'||_0xc845c5['scheme']==='wss';return{'repoInfo':new yo(_0xc845c5['host'],_0xc845c5['secure'],_0x2a5429,_0x50f4c9,_0x50ef18,'',_0x2a5429!==_0xc845c5['subdomain']),'path':new C(_0xc845c5['pathString'])};},Dd=function(_0x416b65){let _0x3262a5='',_0x22057c='',_0x46f5de='',_0x1182e6='',_0x9930cb='',_0x2d42e2=!0x0,_0x1488c7='https',_0x4afaad=0x1bb;if(typeof _0x416b65=='string'){let _0x5733aa=_0x416b65['indexOf']('//');_0x5733aa>=0x0&&(_0x1488c7=_0x416b65['substring'](0x0,_0x5733aa-0x1),_0x416b65=_0x416b65['substring'](_0x5733aa+0x2));let _0x15d9ce=_0x416b65['indexOf']('/');_0x15d9ce===-0x1&&(_0x15d9ce=_0x416b65['length']);let _0x868a78=_0x416b65['indexOf']('?');_0x868a78===-0x1&&(_0x868a78=_0x416b65['length']),_0x3262a5=_0x416b65['substring'](0x0,Math['min'](_0x15d9ce,_0x868a78)),_0x15d9ce<_0x868a78&&(_0x1182e6=Pd(_0x416b65['substring'](_0x15d9ce,_0x868a78)));const _0x42990b=Od(_0x416b65['substring'](Math['min'](_0x416b65['length'],_0x868a78)));_0x5733aa=_0x3262a5['indexOf'](':'),_0x5733aa>=0x0?(_0x2d42e2=_0x1488c7==='https'||_0x1488c7==='wss',_0x4afaad=parseInt(_0x3262a5['substring'](_0x5733aa+0x1),0xa)):_0x5733aa=_0x3262a5['length'];const _0x22a34d=_0x3262a5['slice'](0x0,_0x5733aa);if(_0x22a34d['toLowerCase']()==='localhost')_0x22057c='localhost';else{if(_0x22a34d['split']('.')['length']<=0x2)_0x22057c=_0x22a34d;else{const _0x548545=_0x3262a5['indexOf']('.');_0x46f5de=_0x3262a5['substring'](0x0,_0x548545)['toLowerCase'](),_0x22057c=_0x3262a5['substring'](_0x548545+0x1),_0x9930cb=_0x46f5de;}}'ns'in _0x42990b&&(_0x9930cb=_0x42990b['ns']);}return{'host':_0x3262a5,'port':_0x4afaad,'domain':_0x22057c,'subdomain':_0x46f5de,'secure':_0x2d42e2,'scheme':_0x1488c7,'pathString':_0x1182e6,'namespace':_0x9930cb};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Md=(function(){let _0x1cf1d0=0x0;const _0x3806fe=[];return function(_0x3504f0){const _0x23a38a=_0x3504f0===_0x1cf1d0;_0x1cf1d0=_0x3504f0;let _0x16d7ee;const _0x2c807d=new Array(0x8);for(_0x16d7ee=0x7;_0x16d7ee>=0x0;_0x16d7ee--)_0x2c807d[_0x16d7ee]=Er['charAt'](_0x3504f0%0x40),_0x3504f0=Math['floor'](_0x3504f0/0x40);f(_0x3504f0===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x2602fb=_0x2c807d['join']('');if(_0x23a38a){for(_0x16d7ee=0xb;_0x16d7ee>=0x0&&_0x3806fe[_0x16d7ee]===0x3f;_0x16d7ee--)_0x3806fe[_0x16d7ee]=0x0;_0x3806fe[_0x16d7ee]++;}else{for(_0x16d7ee=0x0;_0x16d7ee<0xc;_0x16d7ee++)_0x3806fe[_0x16d7ee]=Math['floor'](Math['random']()*0x40);}for(_0x16d7ee=0x0;_0x16d7ee<0xc;_0x16d7ee++)_0x2602fb+=Er['charAt'](_0x3806fe[_0x16d7ee]);return f(_0x2602fb['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x2602fb;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ld{constructor(_0x3c0328,_0x5b4711,_0x3199ac,_0x1e99d8){this['eventType']=_0x3c0328,this['eventRegistration']=_0x5b4711,this['snapshot']=_0x3199ac,this['prevName']=_0x1e99d8;}['getPath'](){const _0x54deb7=this['snapshot']['ref'];return this['eventType']==='value'?_0x54deb7['_path']:_0x54deb7['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class xd{constructor(_0x565358,_0x47c1f8,_0x1184f4){this['eventRegistration']=_0x565358,this['error']=_0x47c1f8,this['path']=_0x1184f4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fa{constructor(_0x43f020,_0x3d71c7){this['snapshotCallback']=_0x43f020,this['cancelCallback']=_0x3d71c7;}['onValue'](_0x415021,_0x1a4e9d){this['snapshotCallback']['call'](null,_0x415021,_0x1a4e9d);}['onCancel'](_0x3439b2){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3439b2);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5aca92){return this['snapshotCallback']===_0x5aca92['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5aca92['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5aca92['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fd{constructor(_0x375d52,_0x2b2d69){this['_repo']=_0x375d52,this['_path']=_0x2b2d69;}['cancel'](){const _0x1bc2d5=new H();return wd(this['_repo'],this['_path'],_0x1bc2d5['wrapCallback'](()=>{})),_0x1bc2d5['promise'];}['remove'](){Oe('OnDisconnect.remove',this['_path']);const _0x1c09da=new H();return yr(this['_repo'],this['_path'],null,_0x1c09da['wrapCallback'](()=>{})),_0x1c09da['promise'];}['set'](_0x285236){Oe('OnDisconnect.set',this['_path']),Ve('OnDisconnect.set',_0x285236,this['_path'],!0x1);const _0x3cc992=new H();return yr(this['_repo'],this['_path'],_0x285236,_0x3cc992['wrapCallback'](()=>{})),_0x3cc992['promise'];}['setWithPriority'](_0x5e6a05,_0x57cfd9){Oe('OnDisconnect.setWithPriority',this['_path']),Ve('OnDisconnect.setWithPriority',_0x5e6a05,this['_path'],!0x1),ld('OnDisconnect.setWithPriority',_0x57cfd9);const _0x2f0ca9=new H();return Cd(this['_repo'],this['_path'],_0x5e6a05,_0x57cfd9,_0x2f0ca9['wrapCallback'](()=>{})),_0x2f0ca9['promise'];}['update'](_0xac672d){Oe('OnDisconnect.update',this['_path']),sa('OnDisconnect.update',_0xac672d,this['_path']);const _0xe1b329=new H();return Td(this['_repo'],this['_path'],_0xac672d,_0xe1b329['wrapCallback'](()=>{})),_0xe1b329['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gt{constructor(_0x4c8ac6,_0x150edd,_0x5ae5d6,_0xf3034c){this['_repo']=_0x4c8ac6,this['_path']=_0x150edd,this['_queryParams']=_0x5ae5d6,this['_orderByCalled']=_0xf3034c;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x13572b=sr(this['_queryParams']),_0x2978a2=Hi(_0x13572b);return _0x2978a2==='{}'?'default':_0x2978a2;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1db069){if(_0x1db069=N(_0x1db069),!(_0x1db069 instanceof gt))return!0x1;const _0x4f612c=this['_repo']===_0x1db069['_repo'],_0x4289bc=ji(this['_path'],_0x1db069['_path']),_0x39994e=this['_queryIdentifier']===_0x1db069['_queryIdentifier'];return _0x4f612c&&_0x4289bc&&_0x39994e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+wh(this['_path']);}}function Ud(_0x566c25,_0x3f366c){if(_0x566c25['_orderByCalled']===!0x0)throw new Error(_0x3f366c+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Is(_0x514e8a){let _0x416d51=null,_0x21287f=null;if(_0x514e8a['hasStart']()&&(_0x416d51=_0x514e8a['getIndexStartValue']()),_0x514e8a['hasEnd']()&&(_0x21287f=_0x514e8a['getIndexEndValue']()),_0x514e8a['getIndex']()===De){const _0x1cfb73='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x3048d8='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x514e8a['hasStart']()){if(_0x514e8a['getIndexStartName']()!==Ue)throw new Error(_0x1cfb73);if(typeof _0x416d51!='string')throw new Error(_0x3048d8);}if(_0x514e8a['hasEnd']()){if(_0x514e8a['getIndexEndName']()!==Ie)throw new Error(_0x1cfb73);if(typeof _0x21287f!='string')throw new Error(_0x3048d8);}}else{if(_0x514e8a['getIndex']()===R){if(_0x416d51!=null&&!Wt(_0x416d51)||_0x21287f!=null&&!Wt(_0x21287f))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x514e8a['getIndex']()instanceof Qi||_0x514e8a['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x416d51!=null&&typeof _0x416d51=='object'||_0x21287f!=null&&typeof _0x21287f=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function pa(_0xddf70d){if(_0xddf70d['hasStart']()&&_0xddf70d['hasEnd']()&&_0xddf70d['hasLimit']()&&!_0xddf70d['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends gt{constructor(_0x20ddd8,_0x4c246f){super(_0x20ddd8,_0x4c246f,new Xi(),!0x1);}get['parent'](){const _0x2c78c1=Ro(this['_path']);return _0x2c78c1===null?null:new ee(this['_repo'],_0x2c78c1);}get['root'](){let _0x22d036=this;for(;_0x22d036['parent']!==null;)_0x22d036=_0x22d036['parent'];return _0x22d036;}}class ct{constructor(_0x4cf8cc,_0x287a82,_0x55107f){this['_node']=_0x4cf8cc,this['ref']=_0x287a82,this['_index']=_0x55107f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2109f9){const _0x4de1cf=new C(_0x2109f9),_0x2987f9=Bt(this['ref'],_0x2109f9);return new ct(this['_node']['getChild'](_0x4de1cf),_0x2987f9,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x56f084){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xdc4f3f,_0x46f8c3)=>_0x56f084(new ct(_0x46f8c3,Bt(this['ref'],_0xdc4f3f),R)));}['hasChild'](_0x2bda52){const _0x256d12=new C(_0x2bda52);return!this['_node']['getChild'](_0x256d12)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x388619,_0x1dea4b){return _0x388619=N(_0x388619),_0x388619['_checkNotDeleted']('ref'),_0x1dea4b!==void 0x0?Bt(_0x388619['_root'],_0x1dea4b):_0x388619['_root'];}function Bt(_0x344287,_0x38dee4){return _0x344287=N(_0x344287),y(_0x344287['_path'])===null?hd('child','path',_0x38dee4):ms('child','path',_0x38dee4),new ee(_0x344287['_repo'],k(_0x344287['_path'],_0x38dee4));}function g_(_0x506072){return _0x506072=N(_0x506072),new Fd(_0x506072['_repo'],_0x506072['_path']);}function m_(_0x37b4ec,_0x449a79){_0x37b4ec=N(_0x37b4ec),Oe('push',_0x37b4ec['_path']),Ve('push',_0x449a79,_0x37b4ec['_path'],!0x0);const _0x74cd61=ca(_0x37b4ec['_repo']),_0x94ace3=Md(_0x74cd61),_0x25eeef=Bt(_0x37b4ec,_0x94ace3),_0x5c720f=Bt(_0x37b4ec,_0x94ace3);let _0x2425d4;return _0x449a79!=null?_0x2425d4=Wd(_0x5c720f,_0x449a79)['then'](()=>_0x5c720f):_0x2425d4=Promise['resolve'](_0x5c720f),_0x25eeef['then']=_0x2425d4['then']['bind'](_0x2425d4),_0x25eeef['catch']=_0x2425d4['then']['bind'](_0x2425d4,void 0x0),_0x25eeef;}function Wd(_0x36bece,_0x36a0b6){_0x36bece=N(_0x36bece),Oe('set',_0x36bece['_path']),Ve('set',_0x36a0b6,_0x36bece['_path'],!0x1);const _0x13b0ba=new H();return vd(_0x36bece['_repo'],_0x36bece['_path'],_0x36a0b6,null,_0x13b0ba['wrapCallback'](()=>{})),_0x13b0ba['promise'];}function y_(_0x4defec,_0xc54a5f){sa('update',_0xc54a5f,_0x4defec['_path']);const _0x14cf8a=new H();return Ed(_0x4defec['_repo'],_0x4defec['_path'],_0xc54a5f,_0x14cf8a['wrapCallback'](()=>{})),_0x14cf8a['promise'];}function v_(_0xa0abe8){_0xa0abe8=N(_0xa0abe8);const _0x879b71=new fa(()=>{}),_0x5131ed=new Kn(_0x879b71);return yd(_0xa0abe8['_repo'],_0xa0abe8,_0x5131ed)['then'](_0x5d5287=>new ct(_0x5d5287,new ee(_0xa0abe8['_repo'],_0xa0abe8['_path']),_0xa0abe8['_queryParams']['getIndex']()));}class Kn{constructor(_0x7a7d4e){this['callbackContext']=_0x7a7d4e;}['respondsTo'](_0x1d8421){return _0x1d8421==='value';}['createEvent'](_0x44e2a5,_0x2d43cd){const _0x31dece=_0x2d43cd['_queryParams']['getIndex']();return new Ld('value',this,new ct(_0x44e2a5['snapshotNode'],new ee(_0x2d43cd['_repo'],_0x2d43cd['_path']),_0x31dece));}['getEventRunner'](_0x139928){return _0x139928['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x139928['error']):()=>this['callbackContext']['onValue'](_0x139928['snapshot'],null);}['createCancelEvent'](_0x2131e5,_0x3361a8){return this['callbackContext']['hasCancelCallback']?new xd(this,_0x2131e5,_0x3361a8):null;}['matches'](_0x53ff86){return _0x53ff86 instanceof Kn?!_0x53ff86['callbackContext']||!this['callbackContext']?!0x0:_0x53ff86['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Bd(_0xda2ff3,_0x3aeeb7,_0x1ea017,_0x49f7ac,_0xf7af70){const _0x9ce116=new fa(_0x1ea017,void 0x0),_0x4d4707=new Kn(_0x9ce116);return Sd(_0xda2ff3['_repo'],_0xda2ff3,_0x4d4707),()=>bd(_0xda2ff3['_repo'],_0xda2ff3,_0x4d4707);}function Vd(_0xbd45f,_0x2aecab,_0x292596,_0x3ad689){return Bd(_0xbd45f,'value',_0x2aecab);}class Yn{}class Hd extends Yn{constructor(_0x197700,_0x453ff1){super(),this['_value']=_0x197700,this['_key']=_0x453ff1,this['type']='endAt';}['_apply'](_0x27ef74){Ve('endAt',this['_value'],_0x27ef74['_path'],!0x0);const _0x4630ea=zh(_0x27ef74['_queryParams'],this['_value'],this['_key']);if(pa(_0x4630ea),Is(_0x4630ea),_0x27ef74['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new gt(_0x27ef74['_repo'],_0x27ef74['_path'],_0x4630ea,_0x27ef74['_orderByCalled']);}}class $d extends Yn{constructor(_0x3aafd7,_0x54a84b){super(),this['_value']=_0x3aafd7,this['_key']=_0x54a84b,this['type']='startAt';}['_apply'](_0x26b978){Ve('startAt',this['_value'],_0x26b978['_path'],!0x0);const _0x1282b7=qh(_0x26b978['_queryParams'],this['_value'],this['_key']);if(pa(_0x1282b7),Is(_0x1282b7),_0x26b978['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new gt(_0x26b978['_repo'],_0x26b978['_path'],_0x1282b7,_0x26b978['_orderByCalled']);}}class Gd extends Yn{constructor(_0xafc573){super(),this['_path']=_0xafc573,this['type']='orderByChild';}['_apply'](_0x544982){Ud(_0x544982,'orderByChild');const _0x167d0b=new C(this['_path']);if(v(_0x167d0b))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x29e0a1=new Qi(_0x167d0b),_0x3b4d7d=jh(_0x544982['_queryParams'],_0x29e0a1);return Is(_0x3b4d7d),new gt(_0x544982['_repo'],_0x544982['_path'],_0x3b4d7d,!0x0);}}function E_(_0x371d50){if(_0x371d50==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x371d50==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x371d50==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x371d50),new Gd(_0x371d50);}class qd extends Yn{constructor(_0x4e35b2,_0x1db6a9){super(),this['_value']=_0x4e35b2,this['_key']=_0x1db6a9,this['type']='equalTo';}['_apply'](_0x4861a3){if(Ve('equalTo',this['_value'],_0x4861a3['_path'],!0x1),_0x4861a3['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4861a3['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new Hd(this['_value'],this['_key'])['_apply'](new $d(this['_value'],this['_key'])['_apply'](_0x4861a3));}}function I_(_0x5c2120,_0x19adb0){return new qd(_0x5c2120,_0x19adb0);}function w_(_0x3a951e,..._0x1945c3){let _0x20b114=N(_0x3a951e);for(const _0x5c4044 of _0x1945c3)_0x20b114=_0x5c4044['_apply'](_0x20b114);return _0x20b114;}Lu(ee),Bu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zd='FIREBASE_DATABASE_EMULATOR_HOST',Oi={};let jd=!0x1;function Kd(_0x3f2a94,_0x5eaddb,_0x1fb012,_0x3d2b50){const _0x44dea6=_0x5eaddb['lastIndexOf'](':'),_0x210752=_0x5eaddb['substring'](0x0,_0x44dea6),_0x249799=Gt(_0x210752);_0x3f2a94['repoInfo_']=new yo(_0x5eaddb,_0x249799,_0x3f2a94['repoInfo_']['namespace'],_0x3f2a94['repoInfo_']['webSocketOnly'],_0x3f2a94['repoInfo_']['nodeAdmin'],_0x3f2a94['repoInfo_']['persistenceKey'],_0x3f2a94['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1fb012),_0x3d2b50&&(_0x3f2a94['authTokenProvider_']=_0x3d2b50);}function Yd(_0x309149,_0x1a2de9,_0x416684,_0x2c06bd,_0x1316b1){let _0x17b587=_0x2c06bd||_0x309149['options']['databaseURL'];_0x17b587===void 0x0&&(_0x309149['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x309149['options']['projectId']),_0x17b587=_0x309149['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4cd6ba=vr(_0x17b587,_0x1316b1),_0x5041c7=_0x4cd6ba['repoInfo'],_0x52bc82;typeof process<'u'&&Bs&&(_0x52bc82=Bs[zd]),_0x52bc82?(_0x17b587='http://'+_0x52bc82+'?ns='+_0x5041c7['namespace'],_0x4cd6ba=vr(_0x17b587,_0x1316b1),_0x5041c7=_0x4cd6ba['repoInfo']):_0x4cd6ba['repoInfo']['secure'];const _0x3acc3e=new Ql(_0x309149['name'],_0x309149['options'],_0x1a2de9);ud('Invalid\x20Firebase\x20Database\x20URL',_0x4cd6ba),v(_0x4cd6ba['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x19a129=Jd(_0x5041c7,_0x309149,_0x3acc3e,new Yl(_0x309149,_0x416684));return new Xd(_0x19a129,_0x309149);}function Qd(_0x78074,_0x1ae435){const _0x26c70d=Oi[_0x1ae435];(!_0x26c70d||_0x26c70d[_0x78074['key']]!==_0x78074)&&ae('Database\x20'+_0x1ae435+'('+_0x78074['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),la(_0x78074),delete _0x26c70d[_0x78074['key']];}function Jd(_0x47e308,_0x4db32f,_0x4f1314,_0x9aec6e){let _0x139245=Oi[_0x4db32f['name']];_0x139245||(_0x139245={},Oi[_0x4db32f['name']]=_0x139245);let _0x4771e7=_0x139245[_0x47e308['toURLString']()];return _0x4771e7&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x4771e7=new _d(_0x47e308,jd,_0x4f1314,_0x9aec6e),_0x139245[_0x47e308['toURLString']()]=_0x4771e7,_0x4771e7;}class Xd{constructor(_0x59012c,_0x320c94){this['_repoInternal']=_0x59012c,this['app']=_0x320c94,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(gd(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Qd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3a157c){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3a157c+'\x20on\x20a\x20deleted\x20database.');}}function C_(_0x208c03=Zr(),_0x38606d){const _0xe4fc0f=Vi(_0x208c03,'database')['getImmediate']({'identifier':_0x38606d});if(!_0xe4fc0f['_instanceStarted']){const _0x4a42a2=oc('database');_0x4a42a2&&Zd(_0xe4fc0f,..._0x4a42a2);}return _0xe4fc0f;}function Zd(_0x514cc1,_0xa851ea,_0x23f897,_0x441ca8={}){_0x514cc1=N(_0x514cc1),_0x514cc1['_checkNotDeleted']('useEmulator');const _0x245024=_0xa851ea+':'+_0x23f897,_0x56f861=_0x514cc1['_repoInternal'];if(_0x514cc1['_instanceStarted']){if(_0x245024===_0x514cc1['_repoInternal']['repoInfo_']['host']&&Le(_0x441ca8,_0x56f861['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x27b204;if(_0x56f861['repoInfo_']['nodeAdmin'])_0x441ca8['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x27b204=new on(on['OWNER']);else{if(_0x441ca8['mockUserToken']){const _0x4174dd=typeof _0x441ca8['mockUserToken']=='string'?_0x441ca8['mockUserToken']:ac(_0x441ca8['mockUserToken'],_0x514cc1['app']['options']['projectId']);_0x27b204=new on(_0x4174dd);}}Gt(_0xa851ea)&&Qr(_0xa851ea),Kd(_0x56f861,_0x245024,_0x441ca8,_0x27b204);}function T_(_0x38c07f){_0x38c07f=N(_0x38c07f),_0x38c07f['_checkNotDeleted']('goOffline'),la(_0x38c07f['_repo']);}function S_(_0x4a9908){_0x4a9908=N(_0x4a9908),_0x4a9908['_checkNotDeleted']('goOnline'),Rd(_0x4a9908['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ef(_0xfe3bfc){Ml(ut),it(new xe('database',(_0x47449b,{instanceIdentifier:_0x5275d0})=>{const _0x2dd89f=_0x47449b['getProvider']('app')['getImmediate'](),_0x3dde9d=_0x47449b['getProvider']('auth-internal'),_0x2e59cc=_0x47449b['getProvider']('app-check-internal');return Yd(_0x2dd89f,_0x3dde9d,_0x2e59cc,_0x5275d0);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xfe3bfc),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const tf={'.sv':'timestamp'};function b_(){return tf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nf{constructor(_0x117e2d,_0x3f7519){this['committed']=_0x117e2d,this['snapshot']=_0x3f7519;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function R_(_0x24a97a,_0x2b5b92,_0x1dbbd8){if(_0x24a97a=N(_0x24a97a),Oe('Reference.transaction',_0x24a97a['_path']),_0x24a97a['key']==='.length'||_0x24a97a['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x24a97a['key']+'\x20is\x20a\x20read-only\x20object.';const _0x4c2eb0=!0x0,_0x33c036=new H(),_0xbe1571=(_0x2b3aff,_0x1ae02b,_0x3fcdff)=>{let _0x4812fe=null;_0x2b3aff?_0x33c036['reject'](_0x2b3aff):(_0x4812fe=new ct(_0x3fcdff,new ee(_0x24a97a['_repo'],_0x24a97a['_path']),R),_0x33c036['resolve'](new nf(_0x1ae02b,_0x4812fe)));},_0x2a6595=Vd(_0x24a97a,()=>{});return Ad(_0x24a97a['_repo'],_0x24a97a['_path'],_0x2b5b92,_0xbe1571,_0x2a6595,_0x4c2eb0),_0x33c036['promise'];}se['prototype']['simpleListen']=function(_0x5e7dd6,_0xb4b3db){this['sendRequest']('q',{'p':_0x5e7dd6},_0xb4b3db);},se['prototype']['echo']=function(_0x3539fd,_0x5a1cb9){this['sendRequest']('echo',{'d':_0x3539fd},_0x5a1cb9);},ef();function _a(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const sf=_a,ga=new $t('auth','Firebase',_a()),An=new Wi('@firebase/auth');function rf(_0x4dd194,..._0x1a8517){An['logLevel']<=T['WARN']&&An['warn']('Auth\x20('+ut+'):\x20'+_0x4dd194,..._0x1a8517);}function an(_0x50d2c6,..._0x1a4d13){An['logLevel']<=T['ERROR']&&An['error']('Auth\x20('+ut+'):\x20'+_0x50d2c6,..._0x1a4d13);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x62105e,..._0x152bf7){throw ws(_0x62105e,..._0x152bf7);}function X(_0x1c5826,..._0x3b1b2e){return ws(_0x1c5826,..._0x3b1b2e);}function ma(_0xc3e94c,_0x22c9ee,_0x4f4ef4){const _0x53e157={...sf(),[_0x22c9ee]:_0x4f4ef4};return new $t('auth','Firebase',_0x53e157)['create'](_0x22c9ee,{'appName':_0xc3e94c['name']});}function re(_0x2e9e7c){return ma(_0x2e9e7c,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2f288f,..._0x5e8f62){if(typeof _0x2f288f!='string'){const _0x384db8=_0x5e8f62[0x0],_0x18bb8c=[..._0x5e8f62['slice'](0x1)];return _0x18bb8c[0x0]&&(_0x18bb8c[0x0]['appName']=_0x2f288f['name']),_0x2f288f['_errorFactory']['create'](_0x384db8,..._0x18bb8c);}return ga['create'](_0x2f288f,..._0x5e8f62);}function m(_0x3173ef,_0x25af81,..._0x41457f){if(!_0x3173ef)throw ws(_0x25af81,..._0x41457f);}function ne(_0x3d1040){const _0x1cf556='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3d1040;throw an(_0x1cf556),new Error(_0x1cf556);}function ce(_0xa8d5a6,_0xe91837){_0xa8d5a6||ne(_0xe91837);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Di(){var _0x175e81;return typeof self<'u'&&((_0x175e81=self['location'])==null?void 0x0:_0x175e81['href'])||'';}function of(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1219ea;return typeof self<'u'&&((_0x1219ea=self['location'])==null?void 0x0:_0x1219ea['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function af(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(of()||lc()||'connection'in navigator)?navigator['onLine']:!0x0;}function cf(){if(typeof navigator>'u')return null;const _0x22a478=navigator;return _0x22a478['languages']&&_0x22a478['languages'][0x0]||_0x22a478['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xt{constructor(_0x49a8e8,_0x119818){this['shortDelay']=_0x49a8e8,this['longDelay']=_0x119818,ce(_0x119818>_0x49a8e8,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Ui()||Kr();}['get'](){return af()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x38f126,_0x449f21){ce(_0x38f126['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x59e88c}=_0x38f126['emulator'];return _0x449f21?''+_0x59e88c+(_0x449f21['startsWith']('/')?_0x449f21['slice'](0x1):_0x449f21):_0x59e88c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ya{static['initialize'](_0x5514a8,_0x59dbfa,_0x29527f){this['fetchImpl']=_0x5514a8,_0x59dbfa&&(this['headersImpl']=_0x59dbfa),_0x29527f&&(this['responseImpl']=_0x29527f);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},hf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],uf=new Xt(0x7530,0xea60);function Re(_0x50ad1a,_0x4b0ce0){return _0x50ad1a['tenantId']&&!_0x4b0ce0['tenantId']?{..._0x4b0ce0,'tenantId':_0x50ad1a['tenantId']}:_0x4b0ce0;}async function Ae(_0x29364e,_0x2dbd7b,_0x4e61dd,_0x12a905,_0x37ebcb={}){return va(_0x29364e,_0x37ebcb,async()=>{let _0x3f63ff={},_0x6514c2={};_0x12a905&&(_0x2dbd7b==='GET'?_0x6514c2=_0x12a905:_0x3f63ff={'body':JSON['stringify'](_0x12a905)});const _0x4bc443=ht({..._0x6514c2,'key':_0x29364e['config']['apiKey']})['slice'](0x1),_0x255c54=await _0x29364e['_getAdditionalHeaders']();_0x255c54['Content-Type']='application/json',_0x29364e['languageCode']&&(_0x255c54['X-Firebase-Locale']=_0x29364e['languageCode']);const _0x3020fe={'method':_0x2dbd7b,'headers':_0x255c54,..._0x3f63ff};return cc()||(_0x3020fe['referrerPolicy']='strict-origin-when-cross-origin'),_0x29364e['emulatorConfig']&&Gt(_0x29364e['emulatorConfig']['host'])&&(_0x3020fe['credentials']='include'),ya['fetch']()(await Ea(_0x29364e,_0x29364e['config']['apiHost'],_0x4e61dd,_0x4bc443),_0x3020fe);});}async function va(_0x38fd4e,_0x553517,_0x5f5df0){_0x38fd4e['_canInitEmulator']=!0x1;const _0x2a3f26={...lf,..._0x553517};try{const _0x4ee21f=new ff(_0x38fd4e),_0x2701f9=await Promise['race']([_0x5f5df0(),_0x4ee21f['promise']]);_0x4ee21f['clearNetworkTimeout']();const _0x5ca25d=await _0x2701f9['json']();if('needConfirmation'in _0x5ca25d)throw rn(_0x38fd4e,'account-exists-with-different-credential',_0x5ca25d);if(_0x2701f9['ok']&&!('errorMessage'in _0x5ca25d))return _0x5ca25d;{const _0x1593dc=_0x2701f9['ok']?_0x5ca25d['errorMessage']:_0x5ca25d['error']['message'],[_0x23776f,_0x303d14]=_0x1593dc['split']('\x20:\x20');if(_0x23776f==='FEDERATED_USER_ID_ALREADY_LINKED')throw rn(_0x38fd4e,'credential-already-in-use',_0x5ca25d);if(_0x23776f==='EMAIL_EXISTS')throw rn(_0x38fd4e,'email-already-in-use',_0x5ca25d);if(_0x23776f==='USER_DISABLED')throw rn(_0x38fd4e,'user-disabled',_0x5ca25d);const _0x211dea=_0x2a3f26[_0x23776f]||_0x23776f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x303d14)throw ma(_0x38fd4e,_0x211dea,_0x303d14);Y(_0x38fd4e,_0x211dea);}}catch(_0x5c580b){if(_0x5c580b instanceof be)throw _0x5c580b;Y(_0x38fd4e,'network-request-failed',{'message':String(_0x5c580b)});}}async function Zt(_0x5e06fa,_0x15ef55,_0x34958d,_0x200148,_0x4503c2={}){const _0x5b877b=await Ae(_0x5e06fa,_0x15ef55,_0x34958d,_0x200148,_0x4503c2);return'mfaPendingCredential'in _0x5b877b&&Y(_0x5e06fa,'multi-factor-auth-required',{'_serverResponse':_0x5b877b}),_0x5b877b;}async function Ea(_0x533e42,_0x3a13e7,_0x124c2c,_0x3700da){const _0x135cf2=''+_0x3a13e7+_0x124c2c+'?'+_0x3700da,_0x61f7ea=_0x533e42,_0x574bb0=_0x61f7ea['config']['emulator']?Cs(_0x533e42['config'],_0x135cf2):_0x533e42['config']['apiScheme']+'://'+_0x135cf2;return hf['includes'](_0x124c2c)&&(await _0x61f7ea['_persistenceManagerAvailable'],_0x61f7ea['_getPersistenceType']()==='COOKIE')?_0x61f7ea['_getPersistence']()['_getFinalTarget'](_0x574bb0)['toString']():_0x574bb0;}function df(_0x5f12da){switch(_0x5f12da){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class ff{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x323e37){this['auth']=_0x323e37,this['timer']=null,this['promise']=new Promise((_0x332e60,_0x48a1f3)=>{this['timer']=setTimeout(()=>_0x48a1f3(X(this['auth'],'network-request-failed')),uf['get']());});}}function rn(_0x4893e7,_0x49248c,_0x54567c){const _0x17ccb3={'appName':_0x4893e7['name']};_0x54567c['email']&&(_0x17ccb3['email']=_0x54567c['email']),_0x54567c['phoneNumber']&&(_0x17ccb3['phoneNumber']=_0x54567c['phoneNumber']);const _0x5c95ac=X(_0x4893e7,_0x49248c,_0x17ccb3);return _0x5c95ac['customData']['_tokenResponse']=_0x54567c,_0x5c95ac;}function wr(_0xcc2ebf){return _0xcc2ebf!==void 0x0&&_0xcc2ebf['enterprise']!==void 0x0;}class pf{constructor(_0x2f08ba){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2f08ba['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2f08ba['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2f08ba['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4c31b7){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x51b213 of this['recaptchaEnforcementState'])if(_0x51b213['provider']&&_0x51b213['provider']===_0x4c31b7)return df(_0x51b213['enforcementState']);return null;}['isProviderEnabled'](_0xef88d5){return this['getProviderEnforcementState'](_0xef88d5)==='ENFORCE'||this['getProviderEnforcementState'](_0xef88d5)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function _f(_0x3d02cd,_0x45448c){return Ae(_0x3d02cd,'GET','/v2/recaptchaConfig',Re(_0x3d02cd,_0x45448c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function gf(_0x12d3f7,_0x430913){return Ae(_0x12d3f7,'POST','/v1/accounts:delete',_0x430913);}async function kn(_0xb3dd7f,_0x22aebc){return Ae(_0xb3dd7f,'POST','/v1/accounts:lookup',_0x22aebc);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kt(_0x173746){if(_0x173746)try{const _0x2ba540=new Date(Number(_0x173746));if(!isNaN(_0x2ba540['getTime']()))return _0x2ba540['toUTCString']();}catch{}}async function mf(_0x4ce753,_0xb308c4=!0x1){const _0x2f5c61=N(_0x4ce753),_0x51f316=await _0x2f5c61['getIdToken'](_0xb308c4),_0x3b5ead=Ts(_0x51f316);m(_0x3b5ead&&_0x3b5ead['exp']&&_0x3b5ead['auth_time']&&_0x3b5ead['iat'],_0x2f5c61['auth'],'internal-error');const _0x2c938f=typeof _0x3b5ead['firebase']=='object'?_0x3b5ead['firebase']:void 0x0,_0x32ae74=_0x2c938f==null?void 0x0:_0x2c938f['sign_in_provider'];return{'claims':_0x3b5ead,'token':_0x51f316,'authTime':kt(di(_0x3b5ead['auth_time'])),'issuedAtTime':kt(di(_0x3b5ead['iat'])),'expirationTime':kt(di(_0x3b5ead['exp'])),'signInProvider':_0x32ae74||null,'signInSecondFactor':(_0x2c938f==null?void 0x0:_0x2c938f['sign_in_second_factor'])||null};}function di(_0x28c460){return Number(_0x28c460)*0x3e8;}function Ts(_0x16638d){const [_0x2be9b3,_0x36483c,_0x4b6b09]=_0x16638d['split']('.');if(_0x2be9b3===void 0x0||_0x36483c===void 0x0||_0x4b6b09===void 0x0)return an('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x48270b=dn(_0x36483c);return _0x48270b?JSON['parse'](_0x48270b):(an('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x51909c){return an('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x51909c==null?void 0x0:_0x51909c['toString']()),null;}}function Cr(_0x24fb76){const _0x260433=Ts(_0x24fb76);return m(_0x260433,'internal-error'),m(typeof _0x260433['exp']<'u','internal-error'),m(typeof _0x260433['iat']<'u','internal-error'),Number(_0x260433['exp'])-Number(_0x260433['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Vt(_0x332d85,_0xc8efda,_0x26d282=!0x1){if(_0x26d282)return _0xc8efda;try{return await _0xc8efda;}catch(_0x4639dc){throw _0x4639dc instanceof be&&yf(_0x4639dc)&&_0x332d85['auth']['currentUser']===_0x332d85&&await _0x332d85['auth']['signOut'](),_0x4639dc;}}function yf({code:_0x597592}){return _0x597592==='auth/user-disabled'||_0x597592==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vf{constructor(_0x3aa6b1){this['user']=_0x3aa6b1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x1aacf1){if(_0x1aacf1){const _0x1594dc=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1594dc;}else{this['errorBackoff']=0x7530;const _0x1d4dc2=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x1d4dc2);}}['schedule'](_0x3db4f9=!0x1){if(!this['isRunning'])return;const _0x47ee13=this['getInterval'](_0x3db4f9);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x47ee13);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4058b0){(_0x4058b0==null?void 0x0:_0x4058b0['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mi{constructor(_0x168fc3,_0x444f1c){this['createdAt']=_0x168fc3,this['lastLoginAt']=_0x444f1c,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=kt(this['lastLoginAt']),this['creationTime']=kt(this['createdAt']);}['_copy'](_0x5c5459){this['createdAt']=_0x5c5459['createdAt'],this['lastLoginAt']=_0x5c5459['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x3f11b9){var _0x1454d6;const _0xd1977b=_0x3f11b9['auth'],_0x170158=await _0x3f11b9['getIdToken'](),_0x5e5349=await Vt(_0x3f11b9,kn(_0xd1977b,{'idToken':_0x170158}));m(_0x5e5349==null?void 0x0:_0x5e5349['users']['length'],_0xd1977b,'internal-error');const _0x49ef61=_0x5e5349['users'][0x0];_0x3f11b9['_notifyReloadListener'](_0x49ef61);const _0x216240=(_0x1454d6=_0x49ef61['providerUserInfo'])!=null&&_0x1454d6['length']?Ia(_0x49ef61['providerUserInfo']):[],_0x4ac6ba=If(_0x3f11b9['providerData'],_0x216240),_0x34bda2=_0x3f11b9['isAnonymous'],_0x20808e=!(_0x3f11b9['email']&&_0x49ef61['passwordHash'])&&!(_0x4ac6ba!=null&&_0x4ac6ba['length']),_0x1ec173=_0x34bda2?_0x20808e:!0x1,_0xac1e6={'uid':_0x49ef61['localId'],'displayName':_0x49ef61['displayName']||null,'photoURL':_0x49ef61['photoUrl']||null,'email':_0x49ef61['email']||null,'emailVerified':_0x49ef61['emailVerified']||!0x1,'phoneNumber':_0x49ef61['phoneNumber']||null,'tenantId':_0x49ef61['tenantId']||null,'providerData':_0x4ac6ba,'metadata':new Mi(_0x49ef61['createdAt'],_0x49ef61['lastLoginAt']),'isAnonymous':_0x1ec173};Object['assign'](_0x3f11b9,_0xac1e6);}async function Ef(_0x18343e){const _0x3c5e37=N(_0x18343e);await Nn(_0x3c5e37),await _0x3c5e37['auth']['_persistUserIfCurrent'](_0x3c5e37),_0x3c5e37['auth']['_notifyListenersIfCurrent'](_0x3c5e37);}function If(_0x1dfa3a,_0x4fe65b){return[..._0x1dfa3a['filter'](_0x13c727=>!_0x4fe65b['some'](_0x1b8cd5=>_0x1b8cd5['providerId']===_0x13c727['providerId'])),..._0x4fe65b];}function Ia(_0x149580){return _0x149580['map'](({providerId:_0x5dfeee,..._0x565292})=>({'providerId':_0x5dfeee,'uid':_0x565292['rawId']||'','displayName':_0x565292['displayName']||null,'email':_0x565292['email']||null,'phoneNumber':_0x565292['phoneNumber']||null,'photoURL':_0x565292['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function wf(_0x3a0314,_0x809fea){const _0xd5b953=await va(_0x3a0314,{},async()=>{const _0x4ee13f=ht({'grant_type':'refresh_token','refresh_token':_0x809fea})['slice'](0x1),{tokenApiHost:_0x5d040e,apiKey:_0x36aa31}=_0x3a0314['config'],_0x2ed929=await Ea(_0x3a0314,_0x5d040e,'/v1/token','key='+_0x36aa31),_0x3b7685=await _0x3a0314['_getAdditionalHeaders']();_0x3b7685['Content-Type']='application/x-www-form-urlencoded';const _0x127237={'method':'POST','headers':_0x3b7685,'body':_0x4ee13f};return _0x3a0314['emulatorConfig']&&Gt(_0x3a0314['emulatorConfig']['host'])&&(_0x127237['credentials']='include'),ya['fetch']()(_0x2ed929,_0x127237);});return{'accessToken':_0xd5b953['access_token'],'expiresIn':_0xd5b953['expires_in'],'refreshToken':_0xd5b953['refresh_token']};}async function Cf(_0x44a7e7,_0x3a05de){return Ae(_0x44a7e7,'POST','/v2/accounts:revokeToken',Re(_0x44a7e7,_0x3a05de));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ze{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4df8b2){m(_0x4df8b2['idToken'],'internal-error'),m(typeof _0x4df8b2['idToken']<'u','internal-error'),m(typeof _0x4df8b2['refreshToken']<'u','internal-error');const _0x38ce23='expiresIn'in _0x4df8b2&&typeof _0x4df8b2['expiresIn']<'u'?Number(_0x4df8b2['expiresIn']):Cr(_0x4df8b2['idToken']);this['updateTokensAndExpiration'](_0x4df8b2['idToken'],_0x4df8b2['refreshToken'],_0x38ce23);}['updateFromIdToken'](_0x5cc435){m(_0x5cc435['length']!==0x0,'internal-error');const _0x38c405=Cr(_0x5cc435);this['updateTokensAndExpiration'](_0x5cc435,null,_0x38c405);}async['getToken'](_0x54fd32,_0x2c0917=!0x1){return!_0x2c0917&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x54fd32,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x54fd32,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x47b035,_0x4d16c3){const {accessToken:_0x587996,refreshToken:_0x5cd9ba,expiresIn:_0x50f885}=await wf(_0x47b035,_0x4d16c3);this['updateTokensAndExpiration'](_0x587996,_0x5cd9ba,Number(_0x50f885));}['updateTokensAndExpiration'](_0x3fa2a4,_0x2a23a7,_0x35067b){this['refreshToken']=_0x2a23a7||null,this['accessToken']=_0x3fa2a4||null,this['expirationTime']=Date['now']()+_0x35067b*0x3e8;}static['fromJSON'](_0xfffe2f,_0x3769b8){const {refreshToken:_0x5904d9,accessToken:_0x3a3829,expirationTime:_0x2513bb}=_0x3769b8,_0x2db670=new Ze();return _0x5904d9&&(m(typeof _0x5904d9=='string','internal-error',{'appName':_0xfffe2f}),_0x2db670['refreshToken']=_0x5904d9),_0x3a3829&&(m(typeof _0x3a3829=='string','internal-error',{'appName':_0xfffe2f}),_0x2db670['accessToken']=_0x3a3829),_0x2513bb&&(m(typeof _0x2513bb=='number','internal-error',{'appName':_0xfffe2f}),_0x2db670['expirationTime']=_0x2513bb),_0x2db670;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2a583f){this['accessToken']=_0x2a583f['accessToken'],this['refreshToken']=_0x2a583f['refreshToken'],this['expirationTime']=_0x2a583f['expirationTime'];}['_clone'](){return Object['assign'](new Ze(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x53a16c,_0x326e06){m(typeof _0x53a16c=='string'||typeof _0x53a16c>'u','internal-error',{'appName':_0x326e06});}class j{constructor({uid:_0x214f22,auth:_0x3e0e98,stsTokenManager:_0xbbed7a,..._0x459972}){this['providerId']='firebase',this['proactiveRefresh']=new vf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x214f22,this['auth']=_0x3e0e98,this['stsTokenManager']=_0xbbed7a,this['accessToken']=_0xbbed7a['accessToken'],this['displayName']=_0x459972['displayName']||null,this['email']=_0x459972['email']||null,this['emailVerified']=_0x459972['emailVerified']||!0x1,this['phoneNumber']=_0x459972['phoneNumber']||null,this['photoURL']=_0x459972['photoURL']||null,this['isAnonymous']=_0x459972['isAnonymous']||!0x1,this['tenantId']=_0x459972['tenantId']||null,this['providerData']=_0x459972['providerData']?[..._0x459972['providerData']]:[],this['metadata']=new Mi(_0x459972['createdAt']||void 0x0,_0x459972['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3513e6){const _0x5f2f09=await Vt(this,this['stsTokenManager']['getToken'](this['auth'],_0x3513e6));return m(_0x5f2f09,this['auth'],'internal-error'),this['accessToken']!==_0x5f2f09&&(this['accessToken']=_0x5f2f09,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x5f2f09;}['getIdTokenResult'](_0x14f3eb){return mf(this,_0x14f3eb);}['reload'](){return Ef(this);}['_assign'](_0x4dad49){this!==_0x4dad49&&(m(this['uid']===_0x4dad49['uid'],this['auth'],'internal-error'),this['displayName']=_0x4dad49['displayName'],this['photoURL']=_0x4dad49['photoURL'],this['email']=_0x4dad49['email'],this['emailVerified']=_0x4dad49['emailVerified'],this['phoneNumber']=_0x4dad49['phoneNumber'],this['isAnonymous']=_0x4dad49['isAnonymous'],this['tenantId']=_0x4dad49['tenantId'],this['providerData']=_0x4dad49['providerData']['map'](_0x425c90=>({..._0x425c90})),this['metadata']['_copy'](_0x4dad49['metadata']),this['stsTokenManager']['_assign'](_0x4dad49['stsTokenManager']));}['_clone'](_0x177c6a){const _0x1b2f76=new j({...this,'auth':_0x177c6a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1b2f76['metadata']['_copy'](this['metadata']),_0x1b2f76;}['_onReload'](_0x210a7a){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x210a7a,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4e64cf){this['reloadListener']?this['reloadListener'](_0x4e64cf):this['reloadUserInfo']=_0x4e64cf;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x2b85eb,_0x1e4b11=!0x1){let _0x234fe5=!0x1;_0x2b85eb['idToken']&&_0x2b85eb['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x2b85eb),_0x234fe5=!0x0),_0x1e4b11&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x234fe5&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x5de627=await this['getIdToken']();return await Vt(this,gf(this['auth'],{'idToken':_0x5de627})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x524f76=>({..._0x524f76})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x80c445,_0x18ccc7){const _0x417c64=_0x18ccc7['displayName']??void 0x0,_0x332e95=_0x18ccc7['email']??void 0x0,_0x199c67=_0x18ccc7['phoneNumber']??void 0x0,_0x4bb94e=_0x18ccc7['photoURL']??void 0x0,_0x1684a4=_0x18ccc7['tenantId']??void 0x0,_0x485dca=_0x18ccc7['_redirectEventId']??void 0x0,_0x33b8b1=_0x18ccc7['createdAt']??void 0x0,_0x4a2cc8=_0x18ccc7['lastLoginAt']??void 0x0,{uid:_0x522051,emailVerified:_0x3704e3,isAnonymous:_0x41cfeb,providerData:_0x14996b,stsTokenManager:_0x246619}=_0x18ccc7;m(_0x522051&&_0x246619,_0x80c445,'internal-error');const _0x1a7435=Ze['fromJSON'](this['name'],_0x246619);m(typeof _0x522051=='string',_0x80c445,'internal-error'),le(_0x417c64,_0x80c445['name']),le(_0x332e95,_0x80c445['name']),m(typeof _0x3704e3=='boolean',_0x80c445,'internal-error'),m(typeof _0x41cfeb=='boolean',_0x80c445,'internal-error'),le(_0x199c67,_0x80c445['name']),le(_0x4bb94e,_0x80c445['name']),le(_0x1684a4,_0x80c445['name']),le(_0x485dca,_0x80c445['name']),le(_0x33b8b1,_0x80c445['name']),le(_0x4a2cc8,_0x80c445['name']);const _0x5f6b70=new j({'uid':_0x522051,'auth':_0x80c445,'email':_0x332e95,'emailVerified':_0x3704e3,'displayName':_0x417c64,'isAnonymous':_0x41cfeb,'photoURL':_0x4bb94e,'phoneNumber':_0x199c67,'tenantId':_0x1684a4,'stsTokenManager':_0x1a7435,'createdAt':_0x33b8b1,'lastLoginAt':_0x4a2cc8});return _0x14996b&&Array['isArray'](_0x14996b)&&(_0x5f6b70['providerData']=_0x14996b['map'](_0x2fd07c=>({..._0x2fd07c}))),_0x485dca&&(_0x5f6b70['_redirectEventId']=_0x485dca),_0x5f6b70;}static async['_fromIdTokenResponse'](_0x188e3b,_0x2161a3,_0xc81c0f=!0x1){const _0x453a96=new Ze();_0x453a96['updateFromServerResponse'](_0x2161a3);const _0x4206a9=new j({'uid':_0x2161a3['localId'],'auth':_0x188e3b,'stsTokenManager':_0x453a96,'isAnonymous':_0xc81c0f});return await Nn(_0x4206a9),_0x4206a9;}static async['_fromGetAccountInfoResponse'](_0x1bcca0,_0x10aee2,_0x3f18a1){const _0x5ad516=_0x10aee2['users'][0x0];m(_0x5ad516['localId']!==void 0x0,'internal-error');const _0x2080b3=_0x5ad516['providerUserInfo']!==void 0x0?Ia(_0x5ad516['providerUserInfo']):[],_0x3bf84b=!(_0x5ad516['email']&&_0x5ad516['passwordHash'])&&!(_0x2080b3!=null&&_0x2080b3['length']),_0x1d36db=new Ze();_0x1d36db['updateFromIdToken'](_0x3f18a1);const _0x2b2564=new j({'uid':_0x5ad516['localId'],'auth':_0x1bcca0,'stsTokenManager':_0x1d36db,'isAnonymous':_0x3bf84b}),_0x1dd3a7={'uid':_0x5ad516['localId'],'displayName':_0x5ad516['displayName']||null,'photoURL':_0x5ad516['photoUrl']||null,'email':_0x5ad516['email']||null,'emailVerified':_0x5ad516['emailVerified']||!0x1,'phoneNumber':_0x5ad516['phoneNumber']||null,'tenantId':_0x5ad516['tenantId']||null,'providerData':_0x2080b3,'metadata':new Mi(_0x5ad516['createdAt'],_0x5ad516['lastLoginAt']),'isAnonymous':!(_0x5ad516['email']&&_0x5ad516['passwordHash'])&&!(_0x2080b3!=null&&_0x2080b3['length'])};return Object['assign'](_0x2b2564,_0x1dd3a7),_0x2b2564;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2aa7f2){ce(_0x2aa7f2 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4dbe86=Tr['get'](_0x2aa7f2);return _0x4dbe86?(ce(_0x4dbe86 instanceof _0x2aa7f2,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4dbe86):(_0x4dbe86=new _0x2aa7f2(),Tr['set'](_0x2aa7f2,_0x4dbe86),_0x4dbe86);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x16df64,_0x29a811){this['storage'][_0x16df64]=_0x29a811;}async['_get'](_0x30ac7b){const _0x347f6c=this['storage'][_0x30ac7b];return _0x347f6c===void 0x0?null:_0x347f6c;}async['_remove'](_0x4dc6a7){delete this['storage'][_0x4dc6a7];}['_addListener'](_0x1376d9,_0x46269a){}['_removeListener'](_0x4818a,_0x4d4e94){}}wa['type']='NONE';const Sr=wa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cn(_0x11330a,_0x142da6,_0x1c8cf5){return'firebase:'+_0x11330a+':'+_0x142da6+':'+_0x1c8cf5;}class et{constructor(_0x1afd41,_0x7e5993,_0x5f156a){this['persistence']=_0x1afd41,this['auth']=_0x7e5993,this['userKey']=_0x5f156a;const {config:_0x204d5d,name:_0x179bcb}=this['auth'];this['fullUserKey']=cn(this['userKey'],_0x204d5d['apiKey'],_0x179bcb),this['fullPersistenceKey']=cn('persistence',_0x204d5d['apiKey'],_0x179bcb),this['boundEventHandler']=_0x7e5993['_onStorageEvent']['bind'](_0x7e5993),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2cacd3){return this['persistence']['_set'](this['fullUserKey'],_0x2cacd3['toJSON']());}async['getCurrentUser'](){const _0x242a97=await this['persistence']['_get'](this['fullUserKey']);if(!_0x242a97)return null;if(typeof _0x242a97=='string'){const _0x4706b5=await kn(this['auth'],{'idToken':_0x242a97})['catch'](()=>{});return _0x4706b5?j['_fromGetAccountInfoResponse'](this['auth'],_0x4706b5,_0x242a97):null;}return j['_fromJSON'](this['auth'],_0x242a97);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5a6a39){if(this['persistence']===_0x5a6a39)return;const _0x1ae2b8=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5a6a39,_0x1ae2b8)return this['setCurrentUser'](_0x1ae2b8);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x276391,_0x53b29b,_0xa37dbb='authUser'){if(!_0x53b29b['length'])return new et(ie(Sr),_0x276391,_0xa37dbb);const _0x2417d9=(await Promise['all'](_0x53b29b['map'](async _0x3848f9=>{if(await _0x3848f9['_isAvailable']())return _0x3848f9;})))['filter'](_0xde5d8d=>_0xde5d8d);let _0x4a8b25=_0x2417d9[0x0]||ie(Sr);const _0x2e2813=cn(_0xa37dbb,_0x276391['config']['apiKey'],_0x276391['name']);let _0x2e7e00=null;for(const _0x5c270a of _0x53b29b)try{const _0x2de620=await _0x5c270a['_get'](_0x2e2813);if(_0x2de620){let _0x383d9a;if(typeof _0x2de620=='string'){const _0x569c4d=await kn(_0x276391,{'idToken':_0x2de620})['catch'](()=>{});if(!_0x569c4d)break;_0x383d9a=await j['_fromGetAccountInfoResponse'](_0x276391,_0x569c4d,_0x2de620);}else _0x383d9a=j['_fromJSON'](_0x276391,_0x2de620);_0x5c270a!==_0x4a8b25&&(_0x2e7e00=_0x383d9a),_0x4a8b25=_0x5c270a;break;}}catch{}const _0x34e874=_0x2417d9['filter'](_0x31fe98=>_0x31fe98['_shouldAllowMigration']);return!_0x4a8b25['_shouldAllowMigration']||!_0x34e874['length']?new et(_0x4a8b25,_0x276391,_0xa37dbb):(_0x4a8b25=_0x34e874[0x0],_0x2e7e00&&await _0x4a8b25['_set'](_0x2e2813,_0x2e7e00['toJSON']()),await Promise['all'](_0x53b29b['map'](async _0x1128ba=>{if(_0x1128ba!==_0x4a8b25)try{await _0x1128ba['_remove'](_0x2e2813);}catch{}})),new et(_0x4a8b25,_0x276391,_0xa37dbb));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1f3ab4){const _0x227ecf=_0x1f3ab4['toLowerCase']();if(_0x227ecf['includes']('opera/')||_0x227ecf['includes']('opr/')||_0x227ecf['includes']('opios/'))return'Opera';if(ba(_0x227ecf))return'IEMobile';if(_0x227ecf['includes']('msie')||_0x227ecf['includes']('trident/'))return'IE';if(_0x227ecf['includes']('edge/'))return'Edge';if(Ca(_0x227ecf))return'Firefox';if(_0x227ecf['includes']('silk/'))return'Silk';if(Aa(_0x227ecf))return'Blackberry';if(ka(_0x227ecf))return'Webos';if(Ta(_0x227ecf))return'Safari';if((_0x227ecf['includes']('chrome/')||Sa(_0x227ecf))&&!_0x227ecf['includes']('edge/'))return'Chrome';if(Ra(_0x227ecf))return'Android';{const _0x8e1d3e=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x548780=_0x1f3ab4['match'](_0x8e1d3e);if((_0x548780==null?void 0x0:_0x548780['length'])===0x2)return _0x548780[0x1];}return'Other';}function Ca(_0x4d5294=W()){return/firefox\//i['test'](_0x4d5294);}function Ta(_0x2daf4d=W()){const _0x310240=_0x2daf4d['toLowerCase']();return _0x310240['includes']('safari/')&&!_0x310240['includes']('chrome/')&&!_0x310240['includes']('crios/')&&!_0x310240['includes']('android');}function Sa(_0xcfba0e=W()){return/crios\//i['test'](_0xcfba0e);}function ba(_0x2a2894=W()){return/iemobile/i['test'](_0x2a2894);}function Ra(_0x5aefe=W()){return/android/i['test'](_0x5aefe);}function Aa(_0x348e40=W()){return/blackberry/i['test'](_0x348e40);}function ka(_0x2661ac=W()){return/webos/i['test'](_0x2661ac);}function Ss(_0x2c28ac=W()){return/iphone|ipad|ipod/i['test'](_0x2c28ac)||/macintosh/i['test'](_0x2c28ac)&&/mobile/i['test'](_0x2c28ac);}function Tf(_0x193a1a=W()){var _0x35b789;return Ss(_0x193a1a)&&!!((_0x35b789=window['navigator'])!=null&&_0x35b789['standalone']);}function Sf(){return hc()&&document['documentMode']===0xa;}function Na(_0x50382f=W()){return Ss(_0x50382f)||Ra(_0x50382f)||ka(_0x50382f)||Aa(_0x50382f)||/windows phone/i['test'](_0x50382f)||ba(_0x50382f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pa(_0x224223,_0x49abad=[]){let _0x5aaab4;switch(_0x224223){case'Browser':_0x5aaab4=br(W());break;case'Worker':_0x5aaab4=br(W())+'-'+_0x224223;break;default:_0x5aaab4=_0x224223;}const _0x2e8572=_0x49abad['length']?_0x49abad['join'](','):'FirebaseCore-web';return _0x5aaab4+'/JsCore/'+ut+'/'+_0x2e8572;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bf{constructor(_0x11cff4){this['auth']=_0x11cff4,this['queue']=[];}['pushCallback'](_0x593f95,_0x238c5d){const _0x4b7032=_0x9558d5=>new Promise((_0x5dd33c,_0x417aff)=>{try{const _0x59d3b7=_0x593f95(_0x9558d5);_0x5dd33c(_0x59d3b7);}catch(_0xeea983){_0x417aff(_0xeea983);}});_0x4b7032['onAbort']=_0x238c5d,this['queue']['push'](_0x4b7032);const _0x511fb9=this['queue']['length']-0x1;return()=>{this['queue'][_0x511fb9]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2b4b24){if(this['auth']['currentUser']===_0x2b4b24)return;const _0x3c9205=[];try{for(const _0x296449 of this['queue'])await _0x296449(_0x2b4b24),_0x296449['onAbort']&&_0x3c9205['push'](_0x296449['onAbort']);}catch(_0xfd4478){_0x3c9205['reverse']();for(const _0x5fd422 of _0x3c9205)try{_0x5fd422();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0xfd4478==null?void 0x0:_0xfd4478['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rf(_0x45d4b4,_0x4d89ba={}){return Ae(_0x45d4b4,'GET','/v2/passwordPolicy',Re(_0x45d4b4,_0x4d89ba));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Af=0x6;class kf{constructor(_0x381ed5){var _0x81b365;const _0x35ba58=_0x381ed5['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x35ba58['minPasswordLength']??Af,_0x35ba58['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x35ba58['maxPasswordLength']),_0x35ba58['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x35ba58['containsLowercaseCharacter']),_0x35ba58['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x35ba58['containsUppercaseCharacter']),_0x35ba58['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x35ba58['containsNumericCharacter']),_0x35ba58['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x35ba58['containsNonAlphanumericCharacter']),this['enforcementState']=_0x381ed5['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x81b365=_0x381ed5['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x81b365['join'](''))??'',this['forceUpgradeOnSignin']=_0x381ed5['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x381ed5['schemaVersion'];}['validatePassword'](_0xb3152){const _0xb22d51={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0xb3152,_0xb22d51),this['validatePasswordCharacterOptions'](_0xb3152,_0xb22d51),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['meetsMinPasswordLength']??!0x0),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['meetsMaxPasswordLength']??!0x0),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['containsLowercaseLetter']??!0x0),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['containsUppercaseLetter']??!0x0),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['containsNumericCharacter']??!0x0),_0xb22d51['isValid']&&(_0xb22d51['isValid']=_0xb22d51['containsNonAlphanumericCharacter']??!0x0),_0xb22d51;}['validatePasswordLengthOptions'](_0x20124f,_0xfc260e){const _0x38d498=this['customStrengthOptions']['minPasswordLength'],_0xd0d878=this['customStrengthOptions']['maxPasswordLength'];_0x38d498&&(_0xfc260e['meetsMinPasswordLength']=_0x20124f['length']>=_0x38d498),_0xd0d878&&(_0xfc260e['meetsMaxPasswordLength']=_0x20124f['length']<=_0xd0d878);}['validatePasswordCharacterOptions'](_0x291fb1,_0x585102){this['updatePasswordCharacterOptionsStatuses'](_0x585102,!0x1,!0x1,!0x1,!0x1);let _0x461221;for(let _0x56dc24=0x0;_0x56dc24<_0x291fb1['length'];_0x56dc24++)_0x461221=_0x291fb1['charAt'](_0x56dc24),this['updatePasswordCharacterOptionsStatuses'](_0x585102,_0x461221>='a'&&_0x461221<='z',_0x461221>='A'&&_0x461221<='Z',_0x461221>='0'&&_0x461221<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x461221));}['updatePasswordCharacterOptionsStatuses'](_0x44e9a3,_0x596e29,_0x3f071f,_0x55b1d8,_0x2c003a){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x44e9a3['containsLowercaseLetter']||(_0x44e9a3['containsLowercaseLetter']=_0x596e29)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x44e9a3['containsUppercaseLetter']||(_0x44e9a3['containsUppercaseLetter']=_0x3f071f)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x44e9a3['containsNumericCharacter']||(_0x44e9a3['containsNumericCharacter']=_0x55b1d8)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x44e9a3['containsNonAlphanumericCharacter']||(_0x44e9a3['containsNonAlphanumericCharacter']=_0x2c003a));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nf{constructor(_0xb5b2ec,_0x5876ac,_0x5ea481,_0x47bdaa){this['app']=_0xb5b2ec,this['heartbeatServiceProvider']=_0x5876ac,this['appCheckServiceProvider']=_0x5ea481,this['config']=_0x47bdaa,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new bf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ga,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xb5b2ec['name'],this['clientVersion']=_0x47bdaa['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x41528d=>this['_resolvePersistenceManagerAvailable']=_0x41528d);}['_initializeWithPersistence'](_0x27e0e4,_0x621e24){return _0x621e24&&(this['_popupRedirectResolver']=ie(_0x621e24)),this['_initializationPromise']=this['queue'](async()=>{var _0x262a84,_0x56614c,_0x88748c;if(!this['_deleted']&&(this['persistenceManager']=await et['create'](this,_0x27e0e4),(_0x262a84=this['_resolvePersistenceManagerAvailable'])==null||_0x262a84['call'](this),!this['_deleted'])){if((_0x56614c=this['_popupRedirectResolver'])!=null&&_0x56614c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x621e24),this['lastNotifiedUid']=((_0x88748c=this['currentUser'])==null?void 0x0:_0x88748c['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2d4b59=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2d4b59)){if(this['currentUser']&&_0x2d4b59&&this['currentUser']['uid']===_0x2d4b59['uid']){this['_currentUser']['_assign'](_0x2d4b59),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2d4b59,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x546be3){try{const _0x5ba6ed=await kn(this,{'idToken':_0x546be3}),_0x4d657a=await j['_fromGetAccountInfoResponse'](this,_0x5ba6ed,_0x546be3);await this['directlySetCurrentUser'](_0x4d657a);}catch(_0x537742){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x537742),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x563c5d){var _0x273da8;if($(this['app'])){const _0x39bfc3=this['app']['settings']['authIdToken'];return _0x39bfc3?new Promise(_0x24e568=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x39bfc3)['then'](_0x24e568,_0x24e568));}):this['directlySetCurrentUser'](null);}const _0x538751=await this['assertedPersistence']['getCurrentUser']();let _0x56de0b=_0x538751,_0x58db09=!0x1;if(_0x563c5d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x14333f=(_0x273da8=this['redirectUser'])==null?void 0x0:_0x273da8['_redirectEventId'],_0x449546=_0x56de0b==null?void 0x0:_0x56de0b['_redirectEventId'],_0x2c685d=await this['tryRedirectSignIn'](_0x563c5d);(!_0x14333f||_0x14333f===_0x449546)&&(_0x2c685d!=null&&_0x2c685d['user'])&&(_0x56de0b=_0x2c685d['user'],_0x58db09=!0x0);}if(!_0x56de0b)return this['directlySetCurrentUser'](null);if(!_0x56de0b['_redirectEventId']){if(_0x58db09)try{await this['beforeStateQueue']['runMiddleware'](_0x56de0b);}catch(_0x4bdafb){_0x56de0b=_0x538751,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4bdafb));}return _0x56de0b?this['reloadAndSetCurrentUserOrClear'](_0x56de0b):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x56de0b['_redirectEventId']?this['directlySetCurrentUser'](_0x56de0b):this['reloadAndSetCurrentUserOrClear'](_0x56de0b);}async['tryRedirectSignIn'](_0x52305b){let _0xc8f016=null;try{_0xc8f016=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x52305b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xc8f016;}async['reloadAndSetCurrentUserOrClear'](_0xf4c562){try{await Nn(_0xf4c562);}catch(_0x16fef9){if((_0x16fef9==null?void 0x0:_0x16fef9['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0xf4c562);}['useDeviceLanguage'](){this['languageCode']=cf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x28fe52){if($(this['app']))return Promise['reject'](re(this));const _0x23c61b=_0x28fe52?N(_0x28fe52):null;return _0x23c61b&&m(_0x23c61b['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x23c61b&&_0x23c61b['_clone'](this));}async['_updateCurrentUser'](_0x51f9f7,_0x503edc=!0x1){if(!this['_deleted'])return _0x51f9f7&&m(this['tenantId']===_0x51f9f7['tenantId'],this,'tenant-id-mismatch'),_0x503edc||await this['beforeStateQueue']['runMiddleware'](_0x51f9f7),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x51f9f7),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2d9731){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2d9731));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3cf9d0){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x3b5cc5=this['_getPasswordPolicyInternal']();return _0x3b5cc5['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x3b5cc5['validatePassword'](_0x3cf9d0);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x4fd375=await Rf(this),_0x52e6b6=new kf(_0x4fd375);this['tenantId']===null?this['_projectPasswordPolicy']=_0x52e6b6:this['_tenantPasswordPolicies'][this['tenantId']]=_0x52e6b6;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5d49cd){this['_errorFactory']=new $t('auth','Firebase',_0x5d49cd());}['onAuthStateChanged'](_0x377730,_0x1cece9,_0x5f0688){return this['registerStateListener'](this['authStateSubscription'],_0x377730,_0x1cece9,_0x5f0688);}['beforeAuthStateChanged'](_0x4142b9,_0x330209){return this['beforeStateQueue']['pushCallback'](_0x4142b9,_0x330209);}['onIdTokenChanged'](_0x437f06,_0x259d7b,_0x282b24){return this['registerStateListener'](this['idTokenSubscription'],_0x437f06,_0x259d7b,_0x282b24);}['authStateReady'](){return new Promise((_0x51e4cf,_0x5701ec)=>{if(this['currentUser'])_0x51e4cf();else{const _0x55bfe0=this['onAuthStateChanged'](()=>{_0x55bfe0(),_0x51e4cf();},_0x5701ec);}});}async['revokeAccessToken'](_0x1b87ba){if(this['currentUser']){const _0x55d976=await this['currentUser']['getIdToken'](),_0xbc6839={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1b87ba,'idToken':_0x55d976};this['tenantId']!=null&&(_0xbc6839['tenantId']=this['tenantId']),await Cf(this,_0xbc6839);}}['toJSON'](){var _0x17d95d;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x17d95d=this['_currentUser'])==null?void 0x0:_0x17d95d['toJSON']()};}async['_setRedirectUser'](_0x3a0216,_0x5809f8){const _0x3a399d=await this['getOrInitRedirectPersistenceManager'](_0x5809f8);return _0x3a0216===null?_0x3a399d['removeCurrentUser']():_0x3a399d['setCurrentUser'](_0x3a0216);}async['getOrInitRedirectPersistenceManager'](_0x1a9bd8){if(!this['redirectPersistenceManager']){const _0xf1d0d9=_0x1a9bd8&&ie(_0x1a9bd8)||this['_popupRedirectResolver'];m(_0xf1d0d9,this,'argument-error'),this['redirectPersistenceManager']=await et['create'](this,[ie(_0xf1d0d9['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4414af){var _0x2381f3,_0x5e1f5f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x2381f3=this['_currentUser'])==null?void 0x0:_0x2381f3['_redirectEventId'])===_0x4414af?this['_currentUser']:((_0x5e1f5f=this['redirectUser'])==null?void 0x0:_0x5e1f5f['_redirectEventId'])===_0x4414af?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x37b44f){if(_0x37b44f===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x37b44f));}['_notifyListenersIfCurrent'](_0x128b00){_0x128b00===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1e01f5;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x9f7df3=((_0x1e01f5=this['currentUser'])==null?void 0x0:_0x1e01f5['uid'])??null;this['lastNotifiedUid']!==_0x9f7df3&&(this['lastNotifiedUid']=_0x9f7df3,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4d6f4d,_0x777294,_0x1963cf,_0x2f3bb5){if(this['_deleted'])return()=>{};const _0x2bd404=typeof _0x777294=='function'?_0x777294:_0x777294['next']['bind'](_0x777294);let _0x2f62e4=!0x1;const _0x4b6d8d=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4b6d8d,this,'internal-error'),_0x4b6d8d['then'](()=>{_0x2f62e4||_0x2bd404(this['currentUser']);}),typeof _0x777294=='function'){const _0x5ef300=_0x4d6f4d['addObserver'](_0x777294,_0x1963cf,_0x2f3bb5);return()=>{_0x2f62e4=!0x0,_0x5ef300();};}else{const _0x167f02=_0x4d6f4d['addObserver'](_0x777294);return()=>{_0x2f62e4=!0x0,_0x167f02();};}}async['directlySetCurrentUser'](_0x4e74b4){this['currentUser']&&this['currentUser']!==_0x4e74b4&&this['_currentUser']['_stopProactiveRefresh'](),_0x4e74b4&&this['isProactiveRefreshEnabled']&&_0x4e74b4['_startProactiveRefresh'](),this['currentUser']=_0x4e74b4,_0x4e74b4?await this['assertedPersistence']['setCurrentUser'](_0x4e74b4):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x5a9211){return this['operations']=this['operations']['then'](_0x5a9211,_0x5a9211),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x257510){!_0x257510||this['frameworks']['includes'](_0x257510)||(this['frameworks']['push'](_0x257510),this['frameworks']['sort'](),this['clientVersion']=Pa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x37450d;const _0x5c2ee3={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5c2ee3['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x226f3b=await((_0x37450d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x37450d['getHeartbeatsHeader']());_0x226f3b&&(_0x5c2ee3['X-Firebase-Client']=_0x226f3b);const _0x27c68a=await this['_getAppCheckToken']();return _0x27c68a&&(_0x5c2ee3['X-Firebase-AppCheck']=_0x27c68a),_0x5c2ee3;}async['_getAppCheckToken'](){var _0x461f99;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x35e60f=await((_0x461f99=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x461f99['getToken']());return _0x35e60f!=null&&_0x35e60f['error']&&rf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x35e60f['error']),_0x35e60f==null?void 0x0:_0x35e60f['token'];}}function je(_0x16958e){return N(_0x16958e);}class Rr{constructor(_0x519cce){this['auth']=_0x519cce,this['observer']=null,this['addObserver']=Ec(_0x17fbf5=>this['observer']=_0x17fbf5);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Qn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Pf(_0x256d3d){Qn=_0x256d3d;}function Oa(_0x3aa77c){return Qn['loadJS'](_0x3aa77c);}function Of(){return Qn['recaptchaEnterpriseScript'];}function Df(){return Qn['gapiScript'];}function Mf(_0x27414b){return'__'+_0x27414b+Math['floor'](Math['random']()*0xf4240);}class Lf{constructor(){this['enterprise']=new xf();}['ready'](_0x43a5ec){_0x43a5ec();}['execute'](_0x45f7c6,_0x52a88f){return Promise['resolve']('token');}['render'](_0x343d53,_0x23f3ce){return'';}}class xf{['ready'](_0x353b29){_0x353b29();}['execute'](_0x411c84,_0x577671){return Promise['resolve']('token');}['render'](_0x383b04,_0x5d3e71){return'';}}const Ff='recaptcha-enterprise',Da='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x17c661){this['type']=Ff,this['auth']=je(_0x17c661);}async['verify'](_0x53c86f='verify',_0x798025=!0x1){async function _0x6c9033(_0x1ff626){if(!_0x798025){if(_0x1ff626['tenantId']==null&&_0x1ff626['_agentRecaptchaConfig']!=null)return _0x1ff626['_agentRecaptchaConfig']['siteKey'];if(_0x1ff626['tenantId']!=null&&_0x1ff626['_tenantRecaptchaConfigs'][_0x1ff626['tenantId']]!==void 0x0)return _0x1ff626['_tenantRecaptchaConfigs'][_0x1ff626['tenantId']]['siteKey'];}return new Promise(async(_0x13c626,_0x4f95f9)=>{_f(_0x1ff626,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2fbef6=>{if(_0x2fbef6['recaptchaKey']===void 0x0)_0x4f95f9(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3c2218=new pf(_0x2fbef6);return _0x1ff626['tenantId']==null?_0x1ff626['_agentRecaptchaConfig']=_0x3c2218:_0x1ff626['_tenantRecaptchaConfigs'][_0x1ff626['tenantId']]=_0x3c2218,_0x13c626(_0x3c2218['siteKey']);}})['catch'](_0x5a4ebb=>{_0x4f95f9(_0x5a4ebb);});});}function _0x421fac(_0x1677f8,_0x25cb5c,_0x47a28c){const _0x30dc5c=window['grecaptcha'];wr(_0x30dc5c)?_0x30dc5c['enterprise']['ready'](()=>{_0x30dc5c['enterprise']['execute'](_0x1677f8,{'action':_0x53c86f})['then'](_0x2b9bdc=>{_0x25cb5c(_0x2b9bdc);})['catch'](()=>{_0x25cb5c(Da);});}):_0x47a28c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Lf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3d8833,_0x16d4e0)=>{_0x6c9033(this['auth'])['then'](async _0x277df4=>{if(!_0x798025&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x421fac(_0x277df4,_0x3d8833,_0x16d4e0);else{if(typeof window>'u'){_0x16d4e0(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3b46a0=Of();_0x3b46a0['length']!==0x0&&(_0x3b46a0+=_0x277df4+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x594b94;(_0x594b94=he['scriptInjectionDeferred'])==null||_0x594b94['resolve']();},Oa(_0x3b46a0)['then'](()=>{var _0x147489;return(_0x147489=he['scriptInjectionDeferred'])==null?void 0x0:_0x147489['promise'];})['then'](()=>{_0x421fac(_0x277df4,_0x3d8833,_0x16d4e0);})['catch'](_0xd0fc11=>{_0x16d4e0(_0xd0fc11);});}})['catch'](_0x1a546e=>{_0x16d4e0(_0x1a546e);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x1491d2,_0x146a48,_0x22dbc7,_0x4205f5=!0x1,_0x1d1852=!0x1){const _0x32265e=new he(_0x1491d2);let _0x2f2fc5;if(_0x1d1852)_0x2f2fc5=Da;else try{_0x2f2fc5=await _0x32265e['verify'](_0x22dbc7);}catch{_0x2f2fc5=await _0x32265e['verify'](_0x22dbc7,!0x0);}const _0x3defb8={..._0x146a48};if(_0x22dbc7==='mfaSmsEnrollment'||_0x22dbc7==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3defb8){const _0x1cab32=_0x3defb8['phoneEnrollmentInfo']['phoneNumber'],_0x485a51=_0x3defb8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3defb8,{'phoneEnrollmentInfo':{'phoneNumber':_0x1cab32,'recaptchaToken':_0x485a51,'captchaResponse':_0x2f2fc5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3defb8){const _0x36a9c4=_0x3defb8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3defb8,{'phoneSignInInfo':{'recaptchaToken':_0x36a9c4,'captchaResponse':_0x2f2fc5,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3defb8;}return _0x4205f5?Object['assign'](_0x3defb8,{'captchaResp':_0x2f2fc5}):Object['assign'](_0x3defb8,{'captchaResponse':_0x2f2fc5}),Object['assign'](_0x3defb8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3defb8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3defb8;}async function Li(_0x1287b3,_0x16c1a4,_0x14cef7,_0x2a9b49,_0x16808d){var _0x58d246;if((_0x58d246=_0x1287b3['_getRecaptchaConfig']())!=null&&_0x58d246['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x382ccf=await kr(_0x1287b3,_0x16c1a4,_0x14cef7,_0x14cef7==='getOobCode');return _0x2a9b49(_0x1287b3,_0x382ccf);}else return _0x2a9b49(_0x1287b3,_0x16c1a4)['catch'](async _0x3fc1ff=>{if(_0x3fc1ff['code']==='auth/missing-recaptcha-token'){console['log'](_0x14cef7+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2d6f32=await kr(_0x1287b3,_0x16c1a4,_0x14cef7,_0x14cef7==='getOobCode');return _0x2a9b49(_0x1287b3,_0x2d6f32);}else return Promise['reject'](_0x3fc1ff);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x50c675,_0xe3b761){const _0x8a1e50=Vi(_0x50c675,'auth');if(_0x8a1e50['isInitialized']()){const _0x1fe146=_0x8a1e50['getImmediate'](),_0x274662=_0x8a1e50['getOptions']();if(Le(_0x274662,_0xe3b761??{}))return _0x1fe146;Y(_0x1fe146,'already-initialized');}return _0x8a1e50['initialize']({'options':_0xe3b761});}function Wf(_0xcb47db,_0xa2ec75){const _0x38b169=(_0xa2ec75==null?void 0x0:_0xa2ec75['persistence'])||[],_0xd9593a=(Array['isArray'](_0x38b169)?_0x38b169:[_0x38b169])['map'](ie);_0xa2ec75!=null&&_0xa2ec75['errorMap']&&_0xcb47db['_updateErrorMap'](_0xa2ec75['errorMap']),_0xcb47db['_initializeWithPersistence'](_0xd9593a,_0xa2ec75==null?void 0x0:_0xa2ec75['popupRedirectResolver']);}function Bf(_0x1c9025,_0x1c58b3,_0x5d4f52){const _0x136a89=je(_0x1c9025);m(/^https?:\/\//['test'](_0x1c58b3),_0x136a89,'invalid-emulator-scheme');const _0x28456f=!0x1,_0x5221b2=Ma(_0x1c58b3),{host:_0x21875e,port:_0x71af35}=Vf(_0x1c58b3),_0x478cb2=_0x71af35===null?'':':'+_0x71af35,_0x2191d1={'url':_0x5221b2+'//'+_0x21875e+_0x478cb2+'/'},_0x1537bf=Object['freeze']({'host':_0x21875e,'port':_0x71af35,'protocol':_0x5221b2['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x28456f})});if(!_0x136a89['_canInitEmulator']){m(_0x136a89['config']['emulator']&&_0x136a89['emulatorConfig'],_0x136a89,'emulator-config-failed'),m(Le(_0x2191d1,_0x136a89['config']['emulator'])&&Le(_0x1537bf,_0x136a89['emulatorConfig']),_0x136a89,'emulator-config-failed');return;}_0x136a89['config']['emulator']=_0x2191d1,_0x136a89['emulatorConfig']=_0x1537bf,_0x136a89['settings']['appVerificationDisabledForTesting']=!0x0,Gt(_0x21875e)?Qr(_0x5221b2+'//'+_0x21875e+_0x478cb2):Hf();}function Ma(_0x24b9dd){const _0x9498d4=_0x24b9dd['indexOf'](':');return _0x9498d4<0x0?'':_0x24b9dd['substr'](0x0,_0x9498d4+0x1);}function Vf(_0x2f6791){const _0xc7e6bc=Ma(_0x2f6791),_0x4930c2=/(\/\/)?([^?#/]+)/['exec'](_0x2f6791['substr'](_0xc7e6bc['length']));if(!_0x4930c2)return{'host':'','port':null};const _0x2565fc=_0x4930c2[0x2]['split']('@')['pop']()||'',_0x3ac76c=/^(\[[^\]]+\])(:|$)/['exec'](_0x2565fc);if(_0x3ac76c){const _0x91653f=_0x3ac76c[0x1];return{'host':_0x91653f,'port':Nr(_0x2565fc['substr'](_0x91653f['length']+0x1))};}else{const [_0x6c4a7,_0x567798]=_0x2565fc['split'](':');return{'host':_0x6c4a7,'port':Nr(_0x567798)};}}function Nr(_0x5d1392){if(!_0x5d1392)return null;const _0x53b5a3=Number(_0x5d1392);return isNaN(_0x53b5a3)?null:_0x53b5a3;}function Hf(){function _0x84aa9d(){const _0x419b37=document['createElement']('p'),_0x46b5c5=_0x419b37['style'];_0x419b37['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x46b5c5['position']='fixed',_0x46b5c5['width']='100%',_0x46b5c5['backgroundColor']='#ffffff',_0x46b5c5['border']='.1em\x20solid\x20#000000',_0x46b5c5['color']='#b50000',_0x46b5c5['bottom']='0px',_0x46b5c5['left']='0px',_0x46b5c5['margin']='0px',_0x46b5c5['zIndex']='10000',_0x46b5c5['textAlign']='center',_0x419b37['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x419b37);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x84aa9d):_0x84aa9d());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x125c4c,_0x396b13){this['providerId']=_0x125c4c,this['signInMethod']=_0x396b13;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x13db6e){return ne('not\x20implemented');}['_linkToIdToken'](_0x36208a,_0x3bf2b6){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1e877a){return ne('not\x20implemented');}}async function $f(_0x344a24,_0x2b7294){return Ae(_0x344a24,'POST','/v1/accounts:signUp',_0x2b7294);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x12fae5,_0x428d13){return Zt(_0x12fae5,'POST','/v1/accounts:signInWithPassword',Re(_0x12fae5,_0x428d13));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x592cd5,_0x352ee2){return Zt(_0x592cd5,'POST','/v1/accounts:signInWithEmailLink',Re(_0x592cd5,_0x352ee2));}async function zf(_0x381450,_0x2eef13){return Zt(_0x381450,'POST','/v1/accounts:signInWithEmailLink',Re(_0x381450,_0x2eef13));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ht extends bs{constructor(_0x33751b,_0x543fa7,_0x596213,_0x103285=null){super('password',_0x596213),this['_email']=_0x33751b,this['_password']=_0x543fa7,this['_tenantId']=_0x103285;}static['_fromEmailAndPassword'](_0x111b2e,_0x18a9dd){return new Ht(_0x111b2e,_0x18a9dd,'password');}static['_fromEmailAndCode'](_0x305f7f,_0x2856c4,_0x2764df=null){return new Ht(_0x305f7f,_0x2856c4,'emailLink',_0x2764df);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xcc0eb0){const _0x5610e4=typeof _0xcc0eb0=='string'?JSON['parse'](_0xcc0eb0):_0xcc0eb0;if(_0x5610e4!=null&&_0x5610e4['email']&&(_0x5610e4!=null&&_0x5610e4['password'])){if(_0x5610e4['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5610e4['email'],_0x5610e4['password']);if(_0x5610e4['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5610e4['email'],_0x5610e4['password'],_0x5610e4['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3c5579){switch(this['signInMethod']){case'password':const _0x4d19fb={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Li(_0x3c5579,_0x4d19fb,'signInWithPassword',Gf);case'emailLink':return qf(_0x3c5579,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3c5579,'internal-error');}}async['_linkToIdToken'](_0x489db5,_0x25a484){switch(this['signInMethod']){case'password':const _0x323827={'idToken':_0x25a484,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Li(_0x489db5,_0x323827,'signUpPassword',$f);case'emailLink':return zf(_0x489db5,{'idToken':_0x25a484,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x489db5,'internal-error');}}['_getReauthenticationResolver'](_0x5107f7){return this['_getIdTokenResponse'](_0x5107f7);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tt(_0x1de1ff,_0x2a11ee){return Zt(_0x1de1ff,'POST','/v1/accounts:signInWithIdp',Re(_0x1de1ff,_0x2a11ee));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class He extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4e07b5){const _0x322c79=new He(_0x4e07b5['providerId'],_0x4e07b5['signInMethod']);return _0x4e07b5['idToken']||_0x4e07b5['accessToken']?(_0x4e07b5['idToken']&&(_0x322c79['idToken']=_0x4e07b5['idToken']),_0x4e07b5['accessToken']&&(_0x322c79['accessToken']=_0x4e07b5['accessToken']),_0x4e07b5['nonce']&&!_0x4e07b5['pendingToken']&&(_0x322c79['nonce']=_0x4e07b5['nonce']),_0x4e07b5['pendingToken']&&(_0x322c79['pendingToken']=_0x4e07b5['pendingToken'])):_0x4e07b5['oauthToken']&&_0x4e07b5['oauthTokenSecret']?(_0x322c79['accessToken']=_0x4e07b5['oauthToken'],_0x322c79['secret']=_0x4e07b5['oauthTokenSecret']):Y('argument-error'),_0x322c79;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x5d2364){const _0x699028=typeof _0x5d2364=='string'?JSON['parse'](_0x5d2364):_0x5d2364,{providerId:_0x2d7352,signInMethod:_0x3dceb4,..._0x423b29}=_0x699028;if(!_0x2d7352||!_0x3dceb4)return null;const _0x1d563f=new He(_0x2d7352,_0x3dceb4);return _0x1d563f['idToken']=_0x423b29['idToken']||void 0x0,_0x1d563f['accessToken']=_0x423b29['accessToken']||void 0x0,_0x1d563f['secret']=_0x423b29['secret'],_0x1d563f['nonce']=_0x423b29['nonce'],_0x1d563f['pendingToken']=_0x423b29['pendingToken']||null,_0x1d563f;}['_getIdTokenResponse'](_0x2c27fb){const _0x18b16e=this['buildRequest']();return tt(_0x2c27fb,_0x18b16e);}['_linkToIdToken'](_0x52ce15,_0x1f6bf8){const _0x22c6c1=this['buildRequest']();return _0x22c6c1['idToken']=_0x1f6bf8,tt(_0x52ce15,_0x22c6c1);}['_getReauthenticationResolver'](_0x468b6f){const _0x2cb17d=this['buildRequest']();return _0x2cb17d['autoCreate']=!0x1,tt(_0x468b6f,_0x2cb17d);}['buildRequest'](){const _0x2ed474={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2ed474['pendingToken']=this['pendingToken'];else{const _0x3acde2={};this['idToken']&&(_0x3acde2['id_token']=this['idToken']),this['accessToken']&&(_0x3acde2['access_token']=this['accessToken']),this['secret']&&(_0x3acde2['oauth_token_secret']=this['secret']),_0x3acde2['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3acde2['nonce']=this['nonce']),_0x2ed474['postBody']=ht(_0x3acde2);}return _0x2ed474;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x4afce5){switch(_0x4afce5){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x2b0de0){const _0x2223b8=wt(Ct(_0x2b0de0))['link'],_0x37c042=_0x2223b8?wt(Ct(_0x2223b8))['deep_link_id']:null,_0x1d0b73=wt(Ct(_0x2b0de0))['deep_link_id'];return(_0x1d0b73?wt(Ct(_0x1d0b73))['link']:null)||_0x1d0b73||_0x37c042||_0x2223b8||_0x2b0de0;}class Rs{constructor(_0x2627fa){const _0x4c2d20=wt(Ct(_0x2627fa)),_0x29789e=_0x4c2d20['apiKey']??null,_0x16d035=_0x4c2d20['oobCode']??null,_0x32fdad=Kf(_0x4c2d20['mode']??null);m(_0x29789e&&_0x16d035&&_0x32fdad,'argument-error'),this['apiKey']=_0x29789e,this['operation']=_0x32fdad,this['code']=_0x16d035,this['continueUrl']=_0x4c2d20['continueUrl']??null,this['languageCode']=_0x4c2d20['lang']??null,this['tenantId']=_0x4c2d20['tenantId']??null;}static['parseLink'](_0x55151b){const _0x34fc51=Yf(_0x55151b);try{return new Rs(_0x34fc51);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mt{constructor(){this['providerId']=mt['PROVIDER_ID'];}static['credential'](_0x120d9e,_0x222289){return Ht['_fromEmailAndPassword'](_0x120d9e,_0x222289);}static['credentialWithLink'](_0x544290,_0x4a5e85){const _0x4b2d2c=Rs['parseLink'](_0x4a5e85);return m(_0x4b2d2c,'argument-error'),Ht['_fromEmailAndCode'](_0x544290,_0x4b2d2c['code'],_0x4b2d2c['tenantId']);}}mt['PROVIDER_ID']='password',mt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',mt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class La{constructor(_0xd7fe39){this['providerId']=_0xd7fe39,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4797a8){this['defaultLanguageCode']=_0x4797a8;}['setCustomParameters'](_0x57427e){return this['customParameters']=_0x57427e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en extends La{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x974c9e){return this['scopes']['includes'](_0x974c9e)||this['scopes']['push'](_0x974c9e),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends en{constructor(){super('facebook.com');}static['credential'](_0x4fce92){return He['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4fce92});}static['credentialFromResult'](_0x5b8a5a){return ue['credentialFromTaggedObject'](_0x5b8a5a);}static['credentialFromError'](_0x33853b){return ue['credentialFromTaggedObject'](_0x33853b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x406721}){if(!_0x406721||!('oauthAccessToken'in _0x406721)||!_0x406721['oauthAccessToken'])return null;try{return ue['credential'](_0x406721['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends en{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x20d412,_0x33c20e){return He['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x20d412,'accessToken':_0x33c20e});}static['credentialFromResult'](_0x49a05b){return de['credentialFromTaggedObject'](_0x49a05b);}static['credentialFromError'](_0x10e307){return de['credentialFromTaggedObject'](_0x10e307['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x84e299}){if(!_0x84e299)return null;const {oauthIdToken:_0x24d9aa,oauthAccessToken:_0x57514e}=_0x84e299;if(!_0x24d9aa&&!_0x57514e)return null;try{return de['credential'](_0x24d9aa,_0x57514e);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends en{constructor(){super('github.com');}static['credential'](_0x3f07ca){return He['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3f07ca});}static['credentialFromResult'](_0x5af8eb){return fe['credentialFromTaggedObject'](_0x5af8eb);}static['credentialFromError'](_0x34a6bc){return fe['credentialFromTaggedObject'](_0x34a6bc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4d3669}){if(!_0x4d3669||!('oauthAccessToken'in _0x4d3669)||!_0x4d3669['oauthAccessToken'])return null;try{return fe['credential'](_0x4d3669['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends en{constructor(){super('twitter.com');}static['credential'](_0x140d80,_0x1a8267){return He['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x140d80,'oauthTokenSecret':_0x1a8267});}static['credentialFromResult'](_0x571aab){return pe['credentialFromTaggedObject'](_0x571aab);}static['credentialFromError'](_0x3dac48){return pe['credentialFromTaggedObject'](_0x3dac48['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x35d03b}){if(!_0x35d03b)return null;const {oauthAccessToken:_0x3bdae7,oauthTokenSecret:_0x14b8d6}=_0x35d03b;if(!_0x3bdae7||!_0x14b8d6)return null;try{return pe['credential'](_0x3bdae7,_0x14b8d6);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x537710,_0x1c97c7){return Zt(_0x537710,'POST','/v1/accounts:signUp',Re(_0x537710,_0x1c97c7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $e{constructor(_0x49129d){this['user']=_0x49129d['user'],this['providerId']=_0x49129d['providerId'],this['_tokenResponse']=_0x49129d['_tokenResponse'],this['operationType']=_0x49129d['operationType'];}static async['_fromIdTokenResponse'](_0x426a5a,_0x5647f7,_0x47dd5a,_0x946d83=!0x1){const _0x193e11=await j['_fromIdTokenResponse'](_0x426a5a,_0x47dd5a,_0x946d83),_0x58feab=Pr(_0x47dd5a);return new $e({'user':_0x193e11,'providerId':_0x58feab,'_tokenResponse':_0x47dd5a,'operationType':_0x5647f7});}static async['_forOperation'](_0x359b7f,_0x157cc3,_0x24ef7f){await _0x359b7f['_updateTokensIfNecessary'](_0x24ef7f,!0x0);const _0x510f8f=Pr(_0x24ef7f);return new $e({'user':_0x359b7f,'providerId':_0x510f8f,'_tokenResponse':_0x24ef7f,'operationType':_0x157cc3});}}function Pr(_0x57cf0f){return _0x57cf0f['providerId']?_0x57cf0f['providerId']:'phoneNumber'in _0x57cf0f?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pn extends be{constructor(_0x5eabcd,_0x217cac,_0x3f4cc4,_0x4d8df4){super(_0x217cac['code'],_0x217cac['message']),this['operationType']=_0x3f4cc4,this['user']=_0x4d8df4,Object['setPrototypeOf'](this,Pn['prototype']),this['customData']={'appName':_0x5eabcd['name'],'tenantId':_0x5eabcd['tenantId']??void 0x0,'_serverResponse':_0x217cac['customData']['_serverResponse'],'operationType':_0x3f4cc4};}static['_fromErrorAndOperation'](_0xe7e947,_0x3642e5,_0x4cc2d7,_0x306058){return new Pn(_0xe7e947,_0x3642e5,_0x4cc2d7,_0x306058);}}function xa(_0x52edb6,_0x44b501,_0xdd4b7d,_0x13e2f6){return(_0x44b501==='reauthenticate'?_0xdd4b7d['_getReauthenticationResolver'](_0x52edb6):_0xdd4b7d['_getIdTokenResponse'](_0x52edb6))['catch'](_0x2733f0=>{throw _0x2733f0['code']==='auth/multi-factor-auth-required'?Pn['_fromErrorAndOperation'](_0x52edb6,_0x2733f0,_0x44b501,_0x13e2f6):_0x2733f0;});}async function Jf(_0x22b28b,_0x9de48e,_0xd1678b=!0x1){const _0x44f69d=await Vt(_0x22b28b,_0x9de48e['_linkToIdToken'](_0x22b28b['auth'],await _0x22b28b['getIdToken']()),_0xd1678b);return $e['_forOperation'](_0x22b28b,'link',_0x44f69d);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x1cd043,_0x118b7a,_0xe0bbff=!0x1){const {auth:_0x41ba0e}=_0x1cd043;if($(_0x41ba0e['app']))return Promise['reject'](re(_0x41ba0e));const _0x212818='reauthenticate';try{const _0x448292=await Vt(_0x1cd043,xa(_0x41ba0e,_0x212818,_0x118b7a,_0x1cd043),_0xe0bbff);m(_0x448292['idToken'],_0x41ba0e,'internal-error');const _0x33199b=Ts(_0x448292['idToken']);m(_0x33199b,_0x41ba0e,'internal-error');const {sub:_0x2fd8c9}=_0x33199b;return m(_0x1cd043['uid']===_0x2fd8c9,_0x41ba0e,'user-mismatch'),$e['_forOperation'](_0x1cd043,_0x212818,_0x448292);}catch(_0x264953){throw(_0x264953==null?void 0x0:_0x264953['code'])==='auth/user-not-found'&&Y(_0x41ba0e,'user-mismatch'),_0x264953;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Fa(_0x46dca4,_0x37c9f0,_0x1dc89b=!0x1){if($(_0x46dca4['app']))return Promise['reject'](re(_0x46dca4));const _0x86278a='signIn',_0x190fa1=await xa(_0x46dca4,_0x86278a,_0x37c9f0),_0x2d1005=await $e['_fromIdTokenResponse'](_0x46dca4,_0x86278a,_0x190fa1);return _0x1dc89b||await _0x46dca4['_updateCurrentUser'](_0x2d1005['user']),_0x2d1005;}async function Zf(_0x583393,_0x229bca){return Fa(je(_0x583393),_0x229bca);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x451304){const _0x2a093c=je(_0x451304);_0x2a093c['_getPasswordPolicyInternal']()&&await _0x2a093c['_updatePasswordPolicy']();}async function A_(_0x1c96c7,_0x4e8d8d,_0x539ffa){if($(_0x1c96c7['app']))return Promise['reject'](re(_0x1c96c7));const _0x2448ad=je(_0x1c96c7),_0x13f11e=await Li(_0x2448ad,{'returnSecureToken':!0x0,'email':_0x4e8d8d,'password':_0x539ffa,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x4723e8=>{throw _0x4723e8['code']==='auth/password-does-not-meet-requirements'&&Ua(_0x1c96c7),_0x4723e8;}),_0x2ff8a9=await $e['_fromIdTokenResponse'](_0x2448ad,'signIn',_0x13f11e);return await _0x2448ad['_updateCurrentUser'](_0x2ff8a9['user']),_0x2ff8a9;}function k_(_0x557520,_0x4072bf,_0x2cd199){return $(_0x557520['app'])?Promise['reject'](re(_0x557520)):Zf(N(_0x557520),mt['credential'](_0x4072bf,_0x2cd199))['catch'](async _0x3ec6e5=>{throw _0x3ec6e5['code']==='auth/password-does-not-meet-requirements'&&Ua(_0x557520),_0x3ec6e5;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N_(_0x4758ab,_0x1ede00){return N(_0x4758ab)['setPersistence'](_0x1ede00);}function ep(_0x3c29cf,_0x1ddc40,_0x3f5001,_0x34670f){return N(_0x3c29cf)['onIdTokenChanged'](_0x1ddc40,_0x3f5001,_0x34670f);}function tp(_0x3cc91e,_0x18c56b,_0x839adc){return N(_0x3cc91e)['beforeAuthStateChanged'](_0x18c56b,_0x839adc);}function P_(_0x39f10b,_0x3dc8cb,_0x28cf11,_0x498f7c){return N(_0x39f10b)['onAuthStateChanged'](_0x3dc8cb,_0x28cf11,_0x498f7c);}function O_(_0x5a4c82){return N(_0x5a4c82)['signOut']();}const On='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x41e19b,_0x3bc1a3){this['storageRetriever']=_0x41e19b,this['type']=_0x3bc1a3;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](On,'1'),this['storage']['removeItem'](On),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3bffce,_0x735936){return this['storage']['setItem'](_0x3bffce,JSON['stringify'](_0x735936)),Promise['resolve']();}['_get'](_0x1efa66){const _0x3ddab3=this['storage']['getItem'](_0x1efa66);return Promise['resolve'](_0x3ddab3?JSON['parse'](_0x3ddab3):null);}['_remove'](_0xa6b7f0){return this['storage']['removeItem'](_0xa6b7f0),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ba extends Wa{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x595915,_0x2fb7a4)=>this['onStorageEvent'](_0x595915,_0x2fb7a4),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Na(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0xf39e09){for(const _0x58789d of Object['keys'](this['listeners'])){const _0x2561a7=this['storage']['getItem'](_0x58789d),_0x3cccd1=this['localCache'][_0x58789d];_0x2561a7!==_0x3cccd1&&_0xf39e09(_0x58789d,_0x3cccd1,_0x2561a7);}}['onStorageEvent'](_0x9a57af,_0x54e8f4=!0x1){if(!_0x9a57af['key']){this['forAllChangedKeys']((_0x200451,_0x3a5edf,_0x6cf324)=>{this['notifyListeners'](_0x200451,_0x6cf324);});return;}const _0x371165=_0x9a57af['key'];_0x54e8f4?this['detachListener']():this['stopPolling']();const _0x4ed0a9=()=>{const _0x598aec=this['storage']['getItem'](_0x371165);!_0x54e8f4&&this['localCache'][_0x371165]===_0x598aec||this['notifyListeners'](_0x371165,_0x598aec);},_0x574fb9=this['storage']['getItem'](_0x371165);Sf()&&_0x574fb9!==_0x9a57af['newValue']&&_0x9a57af['newValue']!==_0x9a57af['oldValue']?setTimeout(_0x4ed0a9,ip):_0x4ed0a9();}['notifyListeners'](_0x135b94,_0x389551){this['localCache'][_0x135b94]=_0x389551;const _0xefeea=this['listeners'][_0x135b94];if(_0xefeea){for(const _0xb09e0d of Array['from'](_0xefeea))_0xb09e0d(_0x389551&&JSON['parse'](_0x389551));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xe32e8c,_0x5d4653,_0x37b0f4)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xe32e8c,'oldValue':_0x5d4653,'newValue':_0x37b0f4}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2751e6,_0x4554f2){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2751e6]||(this['listeners'][_0x2751e6]=new Set(),this['localCache'][_0x2751e6]=this['storage']['getItem'](_0x2751e6)),this['listeners'][_0x2751e6]['add'](_0x4554f2);}['_removeListener'](_0x5285f0,_0x31a810){this['listeners'][_0x5285f0]&&(this['listeners'][_0x5285f0]['delete'](_0x31a810),this['listeners'][_0x5285f0]['size']===0x0&&delete this['listeners'][_0x5285f0]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x170a4a,_0x4fd63b){await super['_set'](_0x170a4a,_0x4fd63b),this['localCache'][_0x170a4a]=JSON['stringify'](_0x4fd63b);}async['_get'](_0x99cc92){const _0x573c96=await super['_get'](_0x99cc92);return this['localCache'][_0x99cc92]=JSON['stringify'](_0x573c96),_0x573c96;}async['_remove'](_0x224f75){await super['_remove'](_0x224f75),delete this['localCache'][_0x224f75];}}Ba['type']='LOCAL';const sp=Ba;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Va extends Wa{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x38a909,_0x7b5924){}['_removeListener'](_0x38f685,_0x197302){}}Va['type']='SESSION';const Ha=Va;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x5390ac){return Promise['all'](_0x5390ac['map'](async _0x2d6a3b=>{try{return{'fulfilled':!0x0,'value':await _0x2d6a3b};}catch(_0x5eb85a){return{'fulfilled':!0x1,'reason':_0x5eb85a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jn{constructor(_0x1b945f){this['eventTarget']=_0x1b945f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2b5007){const _0x12b146=this['receivers']['find'](_0x5d0a74=>_0x5d0a74['isListeningto'](_0x2b5007));if(_0x12b146)return _0x12b146;const _0xbcbc4b=new Jn(_0x2b5007);return this['receivers']['push'](_0xbcbc4b),_0xbcbc4b;}['isListeningto'](_0x1ce4b3){return this['eventTarget']===_0x1ce4b3;}async['handleEvent'](_0x4f5c0e){const _0x484658=_0x4f5c0e,{eventId:_0x827f12,eventType:_0x12399b,data:_0x478473}=_0x484658['data'],_0xe19922=this['handlersMap'][_0x12399b];if(!(_0xe19922!=null&&_0xe19922['size']))return;_0x484658['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x827f12,'eventType':_0x12399b});const _0x3f3a5d=Array['from'](_0xe19922)['map'](async _0x5bea3d=>_0x5bea3d(_0x484658['origin'],_0x478473)),_0x285759=await rp(_0x3f3a5d);_0x484658['ports'][0x0]['postMessage']({'status':'done','eventId':_0x827f12,'eventType':_0x12399b,'response':_0x285759});}['_subscribe'](_0x3b5158,_0x5e3a){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3b5158]||(this['handlersMap'][_0x3b5158]=new Set()),this['handlersMap'][_0x3b5158]['add'](_0x5e3a);}['_unsubscribe'](_0x2962b0,_0x147ef2){this['handlersMap'][_0x2962b0]&&_0x147ef2&&this['handlersMap'][_0x2962b0]['delete'](_0x147ef2),(!_0x147ef2||this['handlersMap'][_0x2962b0]['size']===0x0)&&delete this['handlersMap'][_0x2962b0],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1143d5='',_0x521485=0xa){let _0x773e48='';for(let _0x583d74=0x0;_0x583d74<_0x521485;_0x583d74++)_0x773e48+=Math['floor'](Math['random']()*0xa);return _0x1143d5+_0x773e48;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x4c333a){this['target']=_0x4c333a,this['handlers']=new Set();}['removeMessageHandler'](_0x6fff5f){_0x6fff5f['messageChannel']&&(_0x6fff5f['messageChannel']['port1']['removeEventListener']('message',_0x6fff5f['onMessage']),_0x6fff5f['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x6fff5f);}async['_send'](_0x18a86b,_0x5a396c,_0x211f2f=0x32){const _0x1bd7e3=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x1bd7e3)throw new Error('connection_unavailable');let _0x3e67d6,_0x111285;return new Promise((_0x40bd40,_0x1fc21b)=>{const _0xc8ae72=As('',0x14);_0x1bd7e3['port1']['start']();const _0x32170f=setTimeout(()=>{_0x1fc21b(new Error('unsupported_event'));},_0x211f2f);_0x111285={'messageChannel':_0x1bd7e3,'onMessage'(_0x210b62){const _0x3041b1=_0x210b62;if(_0x3041b1['data']['eventId']===_0xc8ae72)switch(_0x3041b1['data']['status']){case'ack':clearTimeout(_0x32170f),_0x3e67d6=setTimeout(()=>{_0x1fc21b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3e67d6),_0x40bd40(_0x3041b1['data']['response']);break;default:clearTimeout(_0x32170f),clearTimeout(_0x3e67d6),_0x1fc21b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x111285),_0x1bd7e3['port1']['addEventListener']('message',_0x111285['onMessage']),this['target']['postMessage']({'eventType':_0x18a86b,'eventId':_0xc8ae72,'data':_0x5a396c},[_0x1bd7e3['port2']]);})['finally'](()=>{_0x111285&&this['removeMessageHandler'](_0x111285);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x248924){Z()['location']['href']=_0x248924;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function $a(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x131782;return((_0x131782=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x131782['controller'])||null;}function hp(){return $a()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ga='firebaseLocalStorageDb',up=0x1,Dn='firebaseLocalStorage',qa='fbase_key';class tn{constructor(_0x114589){this['request']=_0x114589;}['toPromise'](){return new Promise((_0x5a0572,_0x5af700)=>{this['request']['addEventListener']('success',()=>{_0x5a0572(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x5af700(this['request']['error']);});});}}function Xn(_0x4d1b1b,_0x584391){return _0x4d1b1b['transaction']([Dn],_0x584391?'readwrite':'readonly')['objectStore'](Dn);}function dp(){const _0x996021=indexedDB['deleteDatabase'](Ga);return new tn(_0x996021)['toPromise']();}function za(){const _0x4df00a=indexedDB['open'](Ga,up);return new Promise((_0x264264,_0x5f1dba)=>{_0x4df00a['addEventListener']('error',()=>{_0x5f1dba(_0x4df00a['error']);}),_0x4df00a['addEventListener']('upgradeneeded',()=>{const _0x120ea0=_0x4df00a['result'];try{_0x120ea0['createObjectStore'](Dn,{'keyPath':qa});}catch(_0x1366a7){_0x5f1dba(_0x1366a7);}}),_0x4df00a['addEventListener']('success',async()=>{const _0xf246f4=_0x4df00a['result'];_0xf246f4['objectStoreNames']['contains'](Dn)?_0x264264(_0xf246f4):(_0xf246f4['close'](),await dp(),_0x264264(await za()));});});}async function Or(_0x5d003a,_0x58bdd3,_0x2ba06c){const _0x57808e=Xn(_0x5d003a,!0x0)['put']({[qa]:_0x58bdd3,'value':_0x2ba06c});return new tn(_0x57808e)['toPromise']();}async function fp(_0x35c968,_0x2562e4){const _0x2aab49=Xn(_0x35c968,!0x1)['get'](_0x2562e4),_0x3806f0=await new tn(_0x2aab49)['toPromise']();return _0x3806f0===void 0x0?null:_0x3806f0['value'];}function Dr(_0x85e3bb,_0x580fac){const _0xe2cb7b=Xn(_0x85e3bb,!0x0)['delete'](_0x580fac);return new tn(_0xe2cb7b)['toPromise']();}const pp=0x320,_p=0x3;class ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=za(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2518e4){let _0x9036a7=0x0;for(;;)try{const _0x33a0c9=await this['_openDb']();return await _0x2518e4(_0x33a0c9);}catch(_0x20f247){if(_0x9036a7++>_p)throw _0x20f247;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return $a()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Jn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x44630e,_0x59acb7)=>({'keyProcessed':(await this['_poll']())['includes'](_0x59acb7['key'])})),this['receiver']['_subscribe']('ping',async(_0x2adf42,_0x45c54a)=>['keyChanged']);}async['initializeSender'](){var _0x45faa6,_0x24f312;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0xfe641b=await this['sender']['_send']('ping',{},0x320);_0xfe641b&&(_0x45faa6=_0xfe641b[0x0])!=null&&_0x45faa6['fulfilled']&&(_0x24f312=_0xfe641b[0x0])!=null&&_0x24f312['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x550901){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x550901},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1dabb1=>{await Or(_0x1dabb1,On,'1'),await Dr(_0x1dabb1,On);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x24e9c5){this['pendingWrites']++;try{await _0x24e9c5();}finally{this['pendingWrites']--;}}async['_set'](_0x1839db,_0x744cc2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5c770f=>Or(_0x5c770f,_0x1839db,_0x744cc2)),this['localCache'][_0x1839db]=_0x744cc2,this['notifyServiceWorker'](_0x1839db)));}async['_get'](_0x585e45){const _0x3e4f2d=await this['_withRetries'](_0x4b91a2=>fp(_0x4b91a2,_0x585e45));return this['localCache'][_0x585e45]=_0x3e4f2d,_0x3e4f2d;}async['_remove'](_0x3e0922){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x214783=>Dr(_0x214783,_0x3e0922)),delete this['localCache'][_0x3e0922],this['notifyServiceWorker'](_0x3e0922)));}async['_poll'](){const _0x5b3cba=await this['_withRetries'](_0x40d8e6=>{const _0x2ab178=Xn(_0x40d8e6,!0x1)['getAll']();return new tn(_0x2ab178)['toPromise']();});if(!_0x5b3cba)return[];if(this['pendingWrites']!==0x0)return[];const _0x231b4b=[],_0x9f4ed6=new Set();if(_0x5b3cba['length']!==0x0){for(const {fbase_key:_0x227ac4,value:_0x41b8f6}of _0x5b3cba)_0x9f4ed6['add'](_0x227ac4),JSON['stringify'](this['localCache'][_0x227ac4])!==JSON['stringify'](_0x41b8f6)&&(this['notifyListeners'](_0x227ac4,_0x41b8f6),_0x231b4b['push'](_0x227ac4));}for(const _0xc31e4e of Object['keys'](this['localCache']))this['localCache'][_0xc31e4e]&&!_0x9f4ed6['has'](_0xc31e4e)&&(this['notifyListeners'](_0xc31e4e,null),_0x231b4b['push'](_0xc31e4e));return _0x231b4b;}['notifyListeners'](_0x58a587,_0x50f94d){this['localCache'][_0x58a587]=_0x50f94d;const _0x15bb87=this['listeners'][_0x58a587];if(_0x15bb87){for(const _0x1b06f7 of Array['from'](_0x15bb87))_0x1b06f7(_0x50f94d);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x22b451,_0x10c13e){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x22b451]||(this['listeners'][_0x22b451]=new Set(),this['_get'](_0x22b451)),this['listeners'][_0x22b451]['add'](_0x10c13e);}['_removeListener'](_0x144ac2,_0x1d9fba){this['listeners'][_0x144ac2]&&(this['listeners'][_0x144ac2]['delete'](_0x1d9fba),this['listeners'][_0x144ac2]['size']===0x0&&delete this['listeners'][_0x144ac2]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}ja['type']='LOCAL';const gp=ja;new Xt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x115916,_0x3ea6d9){return _0x3ea6d9?ie(_0x3ea6d9):(m(_0x115916['_popupRedirectResolver'],_0x115916,'argument-error'),_0x115916['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x8724d4){super('custom','custom'),this['params']=_0x8724d4;}['_getIdTokenResponse'](_0x1dcff7){return tt(_0x1dcff7,this['_buildIdpRequest']());}['_linkToIdToken'](_0x347984,_0x40531f){return tt(_0x347984,this['_buildIdpRequest'](_0x40531f));}['_getReauthenticationResolver'](_0xf568b3){return tt(_0xf568b3,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3ecfed){const _0x38bc92={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3ecfed&&(_0x38bc92['idToken']=_0x3ecfed),_0x38bc92;}}function yp(_0x231f7b){return Fa(_0x231f7b['auth'],new ks(_0x231f7b),_0x231f7b['bypassAuthState']);}function vp(_0x1f6d04){const {auth:_0x24a9b2,user:_0x4db731}=_0x1f6d04;return m(_0x4db731,_0x24a9b2,'internal-error'),Xf(_0x4db731,new ks(_0x1f6d04),_0x1f6d04['bypassAuthState']);}async function Ep(_0x5849ff){const {auth:_0x5658cc,user:_0xd13a71}=_0x5849ff;return m(_0xd13a71,_0x5658cc,'internal-error'),Jf(_0xd13a71,new ks(_0x5849ff),_0x5849ff['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ka{constructor(_0x59990c,_0x973509,_0x530e57,_0x30f785,_0xc6fa3c=!0x1){this['auth']=_0x59990c,this['resolver']=_0x530e57,this['user']=_0x30f785,this['bypassAuthState']=_0xc6fa3c,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x973509)?_0x973509:[_0x973509];}['execute'](){return new Promise(async(_0x2622fc,_0x3270e0)=>{this['pendingPromise']={'resolve':_0x2622fc,'reject':_0x3270e0};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x27face){this['reject'](_0x27face);}});}async['onAuthEvent'](_0x8f7ed4){const {urlResponse:_0x42c107,sessionId:_0x4e6a57,postBody:_0x5d02ed,tenantId:_0x53f98c,error:_0x159d39,type:_0x4f3726}=_0x8f7ed4;if(_0x159d39){this['reject'](_0x159d39);return;}const _0x4f4616={'auth':this['auth'],'requestUri':_0x42c107,'sessionId':_0x4e6a57,'tenantId':_0x53f98c||void 0x0,'postBody':_0x5d02ed||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4f3726)(_0x4f4616));}catch(_0x1c3334){this['reject'](_0x1c3334);}}['onError'](_0x16ecc7){this['reject'](_0x16ecc7);}['getIdpTask'](_0x32efd2){switch(_0x32efd2){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x15ecbe){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x15ecbe),this['unregisterAndCleanUp']();}['reject'](_0x2daeea){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x2daeea),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Xt(0x7d0,0x2710);class Je extends Ka{constructor(_0x1b0f38,_0xffb155,_0x97b34b,_0x7ffb57,_0x2e2a64){super(_0x1b0f38,_0xffb155,_0x7ffb57,_0x2e2a64),this['provider']=_0x97b34b,this['authWindow']=null,this['pollId']=null,Je['currentPopupAction']&&Je['currentPopupAction']['cancel'](),Je['currentPopupAction']=this;}async['executeNotNull'](){const _0x2607fe=await this['execute']();return m(_0x2607fe,this['auth'],'internal-error'),_0x2607fe;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1c0483=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1c0483),this['authWindow']['associatedEvent']=_0x1c0483,this['resolver']['_originValidation'](this['auth'])['catch'](_0x43e1cf=>{this['reject'](_0x43e1cf);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4fa2a2=>{_0x4fa2a2||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5512b0;return((_0x5512b0=this['authWindow'])==null?void 0x0:_0x5512b0['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Je['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1c3d0f=()=>{var _0x376e08,_0x432f8c;if((_0x432f8c=(_0x376e08=this['authWindow'])==null?void 0x0:_0x376e08['window'])!=null&&_0x432f8c['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1c3d0f,Ip['get']());};_0x1c3d0f();}}Je['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',ln=new Map();class Cp extends Ka{constructor(_0x3b151d,_0x363176,_0x437a44=!0x1){super(_0x3b151d,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x363176,void 0x0,_0x437a44),this['eventId']=null;}async['execute'](){let _0x102a34=ln['get'](this['auth']['_key']());if(!_0x102a34){try{const _0x366b26=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x102a34=()=>Promise['resolve'](_0x366b26);}catch(_0x1ce64d){_0x102a34=()=>Promise['reject'](_0x1ce64d);}ln['set'](this['auth']['_key'](),_0x102a34);}return this['bypassAuthState']||ln['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x102a34();}async['onAuthEvent'](_0x54302a){if(_0x54302a['type']==='signInViaRedirect')return super['onAuthEvent'](_0x54302a);if(_0x54302a['type']==='unknown'){this['resolve'](null);return;}if(_0x54302a['eventId']){const _0x2f25e1=await this['auth']['_redirectUserForId'](_0x54302a['eventId']);if(_0x2f25e1)return this['user']=_0x2f25e1,super['onAuthEvent'](_0x54302a);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x28b3ac,_0x39bd07){const _0xb16243=Rp(_0x39bd07),_0x48e4ca=bp(_0x28b3ac);if(!await _0x48e4ca['_isAvailable']())return!0x1;const _0xe29d80=await _0x48e4ca['_get'](_0xb16243)==='true';return await _0x48e4ca['_remove'](_0xb16243),_0xe29d80;}function Sp(_0xe2d06,_0x17891c){ln['set'](_0xe2d06['_key'](),_0x17891c);}function bp(_0x39c2a8){return ie(_0x39c2a8['_redirectPersistence']);}function Rp(_0x12ec29){return cn(wp,_0x12ec29['config']['apiKey'],_0x12ec29['name']);}async function Ap(_0x12961e,_0x5db140,_0x208275=!0x1){if($(_0x12961e['app']))return Promise['reject'](re(_0x12961e));const _0x483c9f=je(_0x12961e),_0x11accc=mp(_0x483c9f,_0x5db140),_0x4bb8ec=await new Cp(_0x483c9f,_0x11accc,_0x208275)['execute']();return _0x4bb8ec&&!_0x208275&&(delete _0x4bb8ec['user']['_redirectEventId'],await _0x483c9f['_persistUserIfCurrent'](_0x4bb8ec['user']),await _0x483c9f['_setRedirectUser'](null,_0x5db140)),_0x4bb8ec;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x2f079b){this['auth']=_0x2f079b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x168469){this['consumers']['add'](_0x168469),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x168469)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x168469),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x242685){this['consumers']['delete'](_0x242685);}['onEvent'](_0x1192d8){if(this['hasEventBeenHandled'](_0x1192d8))return!0x1;let _0x3576a0=!0x1;return this['consumers']['forEach'](_0x918b75=>{this['isEventForConsumer'](_0x1192d8,_0x918b75)&&(_0x3576a0=!0x0,this['sendToConsumer'](_0x1192d8,_0x918b75),this['saveEventToCache'](_0x1192d8));}),this['hasHandledPotentialRedirect']||!Pp(_0x1192d8)||(this['hasHandledPotentialRedirect']=!0x0,_0x3576a0||(this['queuedRedirectEvent']=_0x1192d8,_0x3576a0=!0x0)),_0x3576a0;}['sendToConsumer'](_0x535d4e,_0x19a262){var _0x3bd3cb;if(_0x535d4e['error']&&!Ya(_0x535d4e)){const _0x5e9eaf=((_0x3bd3cb=_0x535d4e['error']['code'])==null?void 0x0:_0x3bd3cb['split']('auth/')[0x1])||'internal-error';_0x19a262['onError'](X(this['auth'],_0x5e9eaf));}else _0x19a262['onAuthEvent'](_0x535d4e);}['isEventForConsumer'](_0x28c7b5,_0x2b2e2f){const _0x40ee0c=_0x2b2e2f['eventId']===null||!!_0x28c7b5['eventId']&&_0x28c7b5['eventId']===_0x2b2e2f['eventId'];return _0x2b2e2f['filter']['includes'](_0x28c7b5['type'])&&_0x40ee0c;}['hasEventBeenHandled'](_0x2f5e08){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2f5e08));}['saveEventToCache'](_0x2780cc){this['cachedEventUids']['add'](Mr(_0x2780cc)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x22492d){return[_0x22492d['type'],_0x22492d['eventId'],_0x22492d['sessionId'],_0x22492d['tenantId']]['filter'](_0x240189=>_0x240189)['join']('-');}function Ya({type:_0x136f2b,error:_0x21adec}){return _0x136f2b==='unknown'&&(_0x21adec==null?void 0x0:_0x21adec['code'])==='auth/no-auth-event';}function Pp(_0x5c644b){switch(_0x5c644b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Ya(_0x5c644b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x321107,_0x5cfc74={}){return Ae(_0x321107,'GET','/v1/projects',_0x5cfc74);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x281589){if(_0x281589['config']['emulator'])return;const {authorizedDomains:_0x1c8d72}=await Op(_0x281589);for(const _0x3fa989 of _0x1c8d72)try{if(xp(_0x3fa989))return;}catch{}Y(_0x281589,'unauthorized-domain');}function xp(_0x2919de){const _0x16ae34=Di(),{protocol:_0x41d048,hostname:_0x50f903}=new URL(_0x16ae34);if(_0x2919de['startsWith']('chrome-extension://')){const _0x4653af=new URL(_0x2919de);return _0x4653af['hostname']===''&&_0x50f903===''?_0x41d048==='chrome-extension:'&&_0x2919de['replace']('chrome-extension://','')===_0x16ae34['replace']('chrome-extension://',''):_0x41d048==='chrome-extension:'&&_0x4653af['hostname']===_0x50f903;}if(!Mp['test'](_0x41d048))return!0x1;if(Dp['test'](_0x2919de))return _0x50f903===_0x2919de;const _0x12729e=_0x2919de['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x12729e+'|'+_0x12729e+')$','i')['test'](_0x50f903);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Xt(0x7530,0xea60);function Lr(){const _0x3d6caf=Z()['___jsl'];if(_0x3d6caf!=null&&_0x3d6caf['H']){for(const _0xc0a202 of Object['keys'](_0x3d6caf['H']))if(_0x3d6caf['H'][_0xc0a202]['r']=_0x3d6caf['H'][_0xc0a202]['r']||[],_0x3d6caf['H'][_0xc0a202]['L']=_0x3d6caf['H'][_0xc0a202]['L']||[],_0x3d6caf['H'][_0xc0a202]['r']=[..._0x3d6caf['H'][_0xc0a202]['L']],_0x3d6caf['CP']){for(let _0x23c4b0=0x0;_0x23c4b0<_0x3d6caf['CP']['length'];_0x23c4b0++)_0x3d6caf['CP'][_0x23c4b0]=null;}}}function Up(_0x224a3a){return new Promise((_0x902e35,_0x1feec5)=>{var _0x50207b,_0x3bc7fc,_0x56cf29;function _0x5dcb7b(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x902e35(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1feec5(X(_0x224a3a,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x3bc7fc=(_0x50207b=Z()['gapi'])==null?void 0x0:_0x50207b['iframes'])!=null&&_0x3bc7fc['Iframe'])_0x902e35(gapi['iframes']['getContext']());else{if((_0x56cf29=Z()['gapi'])!=null&&_0x56cf29['load'])_0x5dcb7b();else{const _0x2429cf=Mf('iframefcb');return Z()[_0x2429cf]=()=>{gapi['load']?_0x5dcb7b():_0x1feec5(X(_0x224a3a,'network-request-failed'));},Oa(Df()+'?onload='+_0x2429cf)['catch'](_0x1311f7=>_0x1feec5(_0x1311f7));}}})['catch'](_0x11742c=>{throw hn=null,_0x11742c;});}let hn=null;function Wp(_0x124160){return hn=hn||Up(_0x124160),hn;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Xt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x3d1480){const _0x380a16=_0x3d1480['config'];m(_0x380a16['authDomain'],_0x3d1480,'auth-domain-config-required');const _0x2ad1ff=_0x380a16['emulator']?Cs(_0x380a16,Hp):'https://'+_0x3d1480['config']['authDomain']+'/'+Vp,_0xf49a7e={'apiKey':_0x380a16['apiKey'],'appName':_0x3d1480['name'],'v':ut},_0x347d34=Gp['get'](_0x3d1480['config']['apiHost']);_0x347d34&&(_0xf49a7e['eid']=_0x347d34);const _0x2d43ba=_0x3d1480['_getFrameworks']();return _0x2d43ba['length']&&(_0xf49a7e['fw']=_0x2d43ba['join'](',')),_0x2ad1ff+'?'+ht(_0xf49a7e)['slice'](0x1);}async function zp(_0x27f6a9){const _0x299c38=await Wp(_0x27f6a9),_0x4d3ff5=Z()['gapi'];return m(_0x4d3ff5,_0x27f6a9,'internal-error'),_0x299c38['open']({'where':document['body'],'url':qp(_0x27f6a9),'messageHandlersFilter':_0x4d3ff5['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x5508a5=>new Promise(async(_0xda6a8d,_0xa0430c)=>{await _0x5508a5['restyle']({'setHideOnLeave':!0x1});const _0xcad5ea=X(_0x27f6a9,'network-request-failed'),_0x1a3957=Z()['setTimeout'](()=>{_0xa0430c(_0xcad5ea);},Bp['get']());function _0x5595ce(){Z()['clearTimeout'](_0x1a3957),_0xda6a8d(_0x5508a5);}_0x5508a5['ping'](_0x5595ce)['then'](_0x5595ce,()=>{_0xa0430c(_0xcad5ea);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class xr{constructor(_0x504045){this['window']=_0x504045,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x83689b,_0x2b5146,_0x427984,_0xc97f3=Kp,_0x3b3e93=Yp){const _0x427f72=Math['max']((window['screen']['availHeight']-_0x3b3e93)/0x2,0x0)['toString'](),_0x413d0c=Math['max']((window['screen']['availWidth']-_0xc97f3)/0x2,0x0)['toString']();let _0x205de0='';const _0x4f00f4={...jp,'width':_0xc97f3['toString'](),'height':_0x3b3e93['toString'](),'top':_0x427f72,'left':_0x413d0c},_0x45c72d=W()['toLowerCase']();_0x427984&&(_0x205de0=Sa(_0x45c72d)?Qp:_0x427984),Ca(_0x45c72d)&&(_0x2b5146=_0x2b5146||Jp,_0x4f00f4['scrollbars']='yes');const _0x1af36e=Object['entries'](_0x4f00f4)['reduce']((_0x30376f,[_0x33c550,_0xe85c77])=>''+_0x30376f+_0x33c550+'='+_0xe85c77+',','');if(Tf(_0x45c72d)&&_0x205de0!=='_self')return Zp(_0x2b5146||'',_0x205de0),new xr(null);const _0x3165ff=window['open'](_0x2b5146||'',_0x205de0,_0x1af36e);m(_0x3165ff,_0x83689b,'popup-blocked');try{_0x3165ff['focus']();}catch{}return new xr(_0x3165ff);}function Zp(_0x9360a8,_0x25e5a6){const _0x11bc41=document['createElement']('a');_0x11bc41['href']=_0x9360a8,_0x11bc41['target']=_0x25e5a6;const _0x3ca788=document['createEvent']('MouseEvent');_0x3ca788['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x11bc41['dispatchEvent'](_0x3ca788);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function Fr(_0x55283f,_0x7b8260,_0x412fe1,_0x5f6186,_0xdaf96a,_0x42b53a){m(_0x55283f['config']['authDomain'],_0x55283f,'auth-domain-config-required'),m(_0x55283f['config']['apiKey'],_0x55283f,'invalid-api-key');const _0x14ea9c={'apiKey':_0x55283f['config']['apiKey'],'appName':_0x55283f['name'],'authType':_0x412fe1,'redirectUrl':_0x5f6186,'v':ut,'eventId':_0xdaf96a};if(_0x7b8260 instanceof La){_0x7b8260['setDefaultLanguage'](_0x55283f['languageCode']),_0x14ea9c['providerId']=_0x7b8260['providerId']||'',fn(_0x7b8260['getCustomParameters']())||(_0x14ea9c['customParameters']=JSON['stringify'](_0x7b8260['getCustomParameters']()));for(const [_0x2c766c,_0x549158]of Object['entries']({}))_0x14ea9c[_0x2c766c]=_0x549158;}if(_0x7b8260 instanceof en){const _0x94e7d7=_0x7b8260['getScopes']()['filter'](_0x25fe33=>_0x25fe33!=='');_0x94e7d7['length']>0x0&&(_0x14ea9c['scopes']=_0x94e7d7['join'](','));}_0x55283f['tenantId']&&(_0x14ea9c['tid']=_0x55283f['tenantId']);const _0x358fc3=_0x14ea9c;for(const _0x266642 of Object['keys'](_0x358fc3))_0x358fc3[_0x266642]===void 0x0&&delete _0x358fc3[_0x266642];const _0xbf8d08=await _0x55283f['_getAppCheckToken'](),_0x4c269c=_0xbf8d08?'#'+n_+'='+encodeURIComponent(_0xbf8d08):'';return i_(_0x55283f)+'?'+ht(_0x358fc3)['slice'](0x1)+_0x4c269c;}function i_({config:_0xdeffde}){return _0xdeffde['emulator']?Cs(_0xdeffde,t_):'https://'+_0xdeffde['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=Ha,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x4ecdf3,_0x3f9465,_0x10c1ef,_0x48226b){var _0x21de02;ce((_0x21de02=this['eventManagers'][_0x4ecdf3['_key']()])==null?void 0x0:_0x21de02['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x554c2d=await Fr(_0x4ecdf3,_0x3f9465,_0x10c1ef,Di(),_0x48226b);return Xp(_0x4ecdf3,_0x554c2d,As());}async['_openRedirect'](_0x4fcc6f,_0x553708,_0x4e9372,_0x5c983d){await this['_originValidation'](_0x4fcc6f);const _0x5b6641=await Fr(_0x4fcc6f,_0x553708,_0x4e9372,Di(),_0x5c983d);return ap(_0x5b6641),new Promise(()=>{});}['_initialize'](_0x4c1c57){const _0x2e520b=_0x4c1c57['_key']();if(this['eventManagers'][_0x2e520b]){const {manager:_0x59c9d1,promise:_0x2130cc}=this['eventManagers'][_0x2e520b];return _0x59c9d1?Promise['resolve'](_0x59c9d1):(ce(_0x2130cc,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2130cc);}const _0xda59c4=this['initAndGetManager'](_0x4c1c57);return this['eventManagers'][_0x2e520b]={'promise':_0xda59c4},_0xda59c4['catch'](()=>{delete this['eventManagers'][_0x2e520b];}),_0xda59c4;}async['initAndGetManager'](_0x3cd2bf){const _0x49703b=await zp(_0x3cd2bf),_0x542936=new Np(_0x3cd2bf);return _0x49703b['register']('authEvent',_0x51e661=>(m(_0x51e661==null?void 0x0:_0x51e661['authEvent'],_0x3cd2bf,'invalid-auth-event'),{'status':_0x542936['onEvent'](_0x51e661['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3cd2bf['_key']()]={'manager':_0x542936},this['iframes'][_0x3cd2bf['_key']()]=_0x49703b,_0x542936;}['_isIframeWebStorageSupported'](_0x335b73,_0x572aa4){this['iframes'][_0x335b73['_key']()]['send'](fi,{'type':fi},_0x1b6ab4=>{var _0x1d742a;const _0x22af91=(_0x1d742a=_0x1b6ab4==null?void 0x0:_0x1b6ab4[0x0])==null?void 0x0:_0x1d742a[fi];_0x22af91!==void 0x0&&_0x572aa4(!!_0x22af91),Y(_0x335b73,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x26670f){const _0x41350b=_0x26670f['_key']();return this['originValidationPromises'][_0x41350b]||(this['originValidationPromises'][_0x41350b]=Lp(_0x26670f)),this['originValidationPromises'][_0x41350b];}get['_shouldInitProactively'](){return Na()||Ta()||Ss();}}const r_=s_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x24e59d){this['auth']=_0x24e59d,this['internalListeners']=new Map();}['getUid'](){var _0x3bec30;return this['assertAuthConfigured'](),((_0x3bec30=this['auth']['currentUser'])==null?void 0x0:_0x3bec30['uid'])||null;}async['getToken'](_0x377b34){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x377b34)}:null;}['addAuthTokenListener'](_0x1701b9){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x1701b9))return;const _0x18550e=this['auth']['onIdTokenChanged'](_0x3bc8b7=>{_0x1701b9((_0x3bc8b7==null?void 0x0:_0x3bc8b7['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x1701b9,_0x18550e),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x276b4e){this['assertAuthConfigured']();const _0x159780=this['internalListeners']['get'](_0x276b4e);_0x159780&&(this['internalListeners']['delete'](_0x276b4e),_0x159780(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x34a24d){switch(_0x34a24d){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x233b5f){it(new xe('auth',(_0x3a6d77,{options:_0x46394f})=>{const _0x545cb2=_0x3a6d77['getProvider']('app')['getImmediate'](),_0x835e5b=_0x3a6d77['getProvider']('heartbeat'),_0x1b5588=_0x3a6d77['getProvider']('app-check-internal'),{apiKey:_0x193558,authDomain:_0x54a897}=_0x545cb2['options'];m(_0x193558&&!_0x193558['includes'](':'),'invalid-api-key',{'appName':_0x545cb2['name']});const _0xd01868={'apiKey':_0x193558,'authDomain':_0x54a897,'clientPlatform':_0x233b5f,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Pa(_0x233b5f)},_0x3c7d54=new Nf(_0x545cb2,_0x835e5b,_0x1b5588,_0xd01868);return Wf(_0x3c7d54,_0x46394f),_0x3c7d54;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3ee47b,_0x9688c4,_0x2ac6f5)=>{_0x3ee47b['getProvider']('auth-internal')['initialize']();})),it(new xe('auth-internal',_0x13c860=>{const _0x1cf465=je(_0x13c860['getProvider']('auth')['getImmediate']());return(_0x2d9205=>new o_(_0x2d9205))(_0x1cf465);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,a_(_0x233b5f)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=jr('authIdTokenMaxAge')||l_;let Br=null;const u_=_0x3e7e8f=>async _0x33c6c7=>{const _0x5f2502=_0x33c6c7&&await _0x33c6c7['getIdTokenResult'](),_0x4a0d9c=_0x5f2502&&(new Date()['getTime']()-Date['parse'](_0x5f2502['issuedAtTime']))/0x3e8;if(_0x4a0d9c&&_0x4a0d9c>h_)return;const _0x38b01a=_0x5f2502==null?void 0x0:_0x5f2502['token'];Br!==_0x38b01a&&(Br=_0x38b01a,await fetch(_0x3e7e8f,{'method':_0x38b01a?'POST':'DELETE','headers':_0x38b01a?{'Authorization':'Bearer\x20'+_0x38b01a}:{}}));};function D_(_0x196a79=Zr()){const _0x4411f0=Vi(_0x196a79,'auth');if(_0x4411f0['isInitialized']())return _0x4411f0['getImmediate']();const _0x40baa4=Uf(_0x196a79,{'popupRedirectResolver':r_,'persistence':[gp,sp,Ha]}),_0x3f7c2c=jr('authTokenSyncURL');if(_0x3f7c2c&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x2afb7d=new URL(_0x3f7c2c,location['origin']);if(location['origin']===_0x2afb7d['origin']){const _0x1c4197=u_(_0x2afb7d['toString']());tp(_0x40baa4,_0x1c4197,()=>_0x1c4197(_0x40baa4['currentUser'])),ep(_0x40baa4,_0x50ffa8=>_0x1c4197(_0x50ffa8));}}const _0x25e9b4=qr('auth');return _0x25e9b4&&Bf(_0x40baa4,'http://'+_0x25e9b4),_0x40baa4;}function d_(){var _0x383284;return((_0x383284=document['getElementsByTagName']('head'))==null?void 0x0:_0x383284[0x0])??document;}Pf({'loadJS'(_0x3660cb){return new Promise((_0x2e0684,_0x35ab1b)=>{const _0x441637=document['createElement']('script');_0x441637['setAttribute']('src',_0x3660cb),_0x441637['onload']=_0x2e0684,_0x441637['onerror']=_0x3c773b=>{const _0x3ed44e=X('internal-error');_0x3ed44e['customData']=_0x3c773b,_0x35ab1b(_0x3ed44e);},_0x441637['type']='text/javascript',_0x441637['charset']='UTF-8',d_()['appendChild'](_0x441637);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{A_ as A,C_ as a,D_ as b,sp as c,Zr as d,v_ as e,k_ as f,f_ as g,O_ as h,Il as i,p_ as j,Wd as k,b_ as l,Vd as m,T_ as n,g_ as o,P_ as p,S_ as q,__ as r,N_ as s,w_ as t,y_ as u,E_ as v,I_ as w,Bt as x,m_ as y,R_ as z};