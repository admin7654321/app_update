const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x22d746,_0x45a68b){if(!_0x22d746)throw ot(_0x45a68b);},ot=function(_0x2fc839){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2fc839);},Wr=function(_0x339f35){const _0x2b07ee=[];let _0x395302=0x0;for(let _0x5eab84=0x0;_0x5eab84<_0x339f35['length'];_0x5eab84++){let _0x142404=_0x339f35['charCodeAt'](_0x5eab84);_0x142404<0x80?_0x2b07ee[_0x395302++]=_0x142404:_0x142404<0x800?(_0x2b07ee[_0x395302++]=_0x142404>>0x6|0xc0,_0x2b07ee[_0x395302++]=_0x142404&0x3f|0x80):(_0x142404&0xfc00)===0xd800&&_0x5eab84+0x1<_0x339f35['length']&&(_0x339f35['charCodeAt'](_0x5eab84+0x1)&0xfc00)===0xdc00?(_0x142404=0x10000+((_0x142404&0x3ff)<<0xa)+(_0x339f35['charCodeAt'](++_0x5eab84)&0x3ff),_0x2b07ee[_0x395302++]=_0x142404>>0x12|0xf0,_0x2b07ee[_0x395302++]=_0x142404>>0xc&0x3f|0x80,_0x2b07ee[_0x395302++]=_0x142404>>0x6&0x3f|0x80,_0x2b07ee[_0x395302++]=_0x142404&0x3f|0x80):(_0x2b07ee[_0x395302++]=_0x142404>>0xc|0xe0,_0x2b07ee[_0x395302++]=_0x142404>>0x6&0x3f|0x80,_0x2b07ee[_0x395302++]=_0x142404&0x3f|0x80);}return _0x2b07ee;},Za=function(_0x113e24){const _0x319a16=[];let _0x9af19b=0x0,_0x26e7f7=0x0;for(;_0x9af19b<_0x113e24['length'];){const _0x6b62c9=_0x113e24[_0x9af19b++];if(_0x6b62c9<0x80)_0x319a16[_0x26e7f7++]=String['fromCharCode'](_0x6b62c9);else{if(_0x6b62c9>0xbf&&_0x6b62c9<0xe0){const _0x1ecb48=_0x113e24[_0x9af19b++];_0x319a16[_0x26e7f7++]=String['fromCharCode']((_0x6b62c9&0x1f)<<0x6|_0x1ecb48&0x3f);}else{if(_0x6b62c9>0xef&&_0x6b62c9<0x16d){const _0x4f3cb0=_0x113e24[_0x9af19b++],_0x44e446=_0x113e24[_0x9af19b++],_0x355ee3=_0x113e24[_0x9af19b++],_0x1de911=((_0x6b62c9&0x7)<<0x12|(_0x4f3cb0&0x3f)<<0xc|(_0x44e446&0x3f)<<0x6|_0x355ee3&0x3f)-0x10000;_0x319a16[_0x26e7f7++]=String['fromCharCode'](0xd800+(_0x1de911>>0xa)),_0x319a16[_0x26e7f7++]=String['fromCharCode'](0xdc00+(_0x1de911&0x3ff));}else{const _0x37242b=_0x113e24[_0x9af19b++],_0x3a4be7=_0x113e24[_0x9af19b++];_0x319a16[_0x26e7f7++]=String['fromCharCode']((_0x6b62c9&0xf)<<0xc|(_0x37242b&0x3f)<<0x6|_0x3a4be7&0x3f);}}}}return _0x319a16['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x36ba3f,_0xd2369b){if(!Array['isArray'](_0x36ba3f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2033e6=_0xd2369b?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5c2bc6=[];for(let _0x519498=0x0;_0x519498<_0x36ba3f['length'];_0x519498+=0x3){const _0x67eb0a=_0x36ba3f[_0x519498],_0x5981f0=_0x519498+0x1<_0x36ba3f['length'],_0x24425f=_0x5981f0?_0x36ba3f[_0x519498+0x1]:0x0,_0x443b30=_0x519498+0x2<_0x36ba3f['length'],_0x5d0692=_0x443b30?_0x36ba3f[_0x519498+0x2]:0x0,_0x13af41=_0x67eb0a>>0x2,_0x3d313e=(_0x67eb0a&0x3)<<0x4|_0x24425f>>0x4;let _0x515381=(_0x24425f&0xf)<<0x2|_0x5d0692>>0x6,_0xed0cb2=_0x5d0692&0x3f;_0x443b30||(_0xed0cb2=0x40,_0x5981f0||(_0x515381=0x40)),_0x5c2bc6['push'](_0x2033e6[_0x13af41],_0x2033e6[_0x3d313e],_0x2033e6[_0x515381],_0x2033e6[_0xed0cb2]);}return _0x5c2bc6['join']('');},'encodeString'(_0x2a5c98,_0x5d232f){return this['HAS_NATIVE_SUPPORT']&&!_0x5d232f?btoa(_0x2a5c98):this['encodeByteArray'](Wr(_0x2a5c98),_0x5d232f);},'decodeString'(_0x218039,_0x30e4a3){return this['HAS_NATIVE_SUPPORT']&&!_0x30e4a3?atob(_0x218039):Za(this['decodeStringToByteArray'](_0x218039,_0x30e4a3));},'decodeStringToByteArray'(_0x3e2993,_0x165a54){this['init_']();const _0x4856f8=_0x165a54?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x39b855=[];for(let _0x254828=0x0;_0x254828<_0x3e2993['length'];){const _0x49a1eb=_0x4856f8[_0x3e2993['charAt'](_0x254828++)],_0x245ad4=_0x254828<_0x3e2993['length']?_0x4856f8[_0x3e2993['charAt'](_0x254828)]:0x0;++_0x254828;const _0x28fa46=_0x254828<_0x3e2993['length']?_0x4856f8[_0x3e2993['charAt'](_0x254828)]:0x40;++_0x254828;const _0x9b5a50=_0x254828<_0x3e2993['length']?_0x4856f8[_0x3e2993['charAt'](_0x254828)]:0x40;if(++_0x254828,_0x49a1eb==null||_0x245ad4==null||_0x28fa46==null||_0x9b5a50==null)throw new ec();const _0x165212=_0x49a1eb<<0x2|_0x245ad4>>0x4;if(_0x39b855['push'](_0x165212),_0x28fa46!==0x40){const _0xf400c4=_0x245ad4<<0x4&0xf0|_0x28fa46>>0x2;if(_0x39b855['push'](_0xf400c4),_0x9b5a50!==0x40){const _0x1939e5=_0x28fa46<<0x6&0xc0|_0x9b5a50;_0x39b855['push'](_0x1939e5);}}}return _0x39b855;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xe62be8=0x0;_0xe62be8<this['ENCODED_VALS']['length'];_0xe62be8++)this['byteToCharMap_'][_0xe62be8]=this['ENCODED_VALS']['charAt'](_0xe62be8),this['charToByteMap_'][this['byteToCharMap_'][_0xe62be8]]=_0xe62be8,this['byteToCharMapWebSafe_'][_0xe62be8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xe62be8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xe62be8]]=_0xe62be8,_0xe62be8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xe62be8)]=_0xe62be8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xe62be8)]=_0xe62be8);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0x3715f9){const _0x3417c6=Wr(_0x3715f9);return Di['encodeByteArray'](_0x3417c6,!0x0);},an=function(_0x42bf7b){return Br(_0x42bf7b)['replace'](/\./g,'');},cn=function(_0x1c7327){try{return Di['decodeString'](_0x1c7327,!0x0);}catch(_0x28009e){console['error']('base64Decode\x20failed:\x20',_0x28009e);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x1f616e){return Vr(void 0x0,_0x1f616e);}function Vr(_0x384224,_0x5ecdec){if(!(_0x5ecdec instanceof Object))return _0x5ecdec;switch(_0x5ecdec['constructor']){case Date:const _0x2fa7b3=_0x5ecdec;return new Date(_0x2fa7b3['getTime']());case Object:_0x384224===void 0x0&&(_0x384224={});break;case Array:_0x384224=[];break;default:return _0x5ecdec;}for(const _0x5f1f50 in _0x5ecdec)!_0x5ecdec['hasOwnProperty'](_0x5f1f50)||!nc(_0x5f1f50)||(_0x384224[_0x5f1f50]=Vr(_0x384224[_0x5f1f50],_0x5ecdec[_0x5f1f50]));return _0x384224;}function nc(_0x989f7a){return _0x989f7a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x16a44d=As['__FIREBASE_DEFAULTS__'];if(_0x16a44d)return JSON['parse'](_0x16a44d);},oc=()=>{if(typeof document>'u')return;let _0x2f097c;try{_0x2f097c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x3b442d=_0x2f097c&&cn(_0x2f097c[0x1]);return _0x3b442d&&JSON['parse'](_0x3b442d);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x4c4e36){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x4c4e36);return;}},Hr=_0x172f83=>{var _0x193f52,_0x8639c8;return(_0x8639c8=(_0x193f52=Mi())==null?void 0x0:_0x193f52['emulatorHosts'])==null?void 0x0:_0x8639c8[_0x172f83];},ac=_0x586d63=>{const _0x580a7c=Hr(_0x586d63);if(!_0x580a7c)return;const _0x3da962=_0x580a7c['lastIndexOf'](':');if(_0x3da962<=0x0||_0x3da962+0x1===_0x580a7c['length'])throw new Error('Invalid\x20host\x20'+_0x580a7c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3bbe4d=parseInt(_0x580a7c['substring'](_0x3da962+0x1),0xa);return _0x580a7c[0x0]==='['?[_0x580a7c['substring'](0x1,_0x3da962-0x1),_0x3bbe4d]:[_0x580a7c['substring'](0x0,_0x3da962),_0x3bbe4d];},$r=()=>{var _0x554b87;return(_0x554b87=Mi())==null?void 0x0:_0x554b87['config'];},Gr=_0x3c8057=>{var _0xc6098f;return(_0xc6098f=Mi())==null?void 0x0:_0xc6098f['_'+_0x3c8057];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x1af6a8,_0x1b21b3)=>{this['resolve']=_0x1af6a8,this['reject']=_0x1b21b3;});}['wrapCallback'](_0x361eb0){return(_0x401c87,_0x4e9a05)=>{_0x401c87?this['reject'](_0x401c87):this['resolve'](_0x4e9a05),typeof _0x361eb0=='function'&&(this['promise']['catch'](()=>{}),_0x361eb0['length']===0x1?_0x361eb0(_0x401c87):_0x361eb0(_0x401c87,_0x4e9a05));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x21aac7,_0x14b215){if(_0x21aac7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x417a06={'alg':'none','type':'JWT'},_0xb993c5=_0x14b215||'demo-project',_0x415c54=_0x21aac7['iat']||0x0,_0x532528=_0x21aac7['sub']||_0x21aac7['user_id'];if(!_0x532528)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xdbe31d={'iss':'https://securetoken.google.com/'+_0xb993c5,'aud':_0xb993c5,'iat':_0x415c54,'exp':_0x415c54+0xe10,'auth_time':_0x415c54,'sub':_0x532528,'user_id':_0x532528,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x21aac7};return[an(JSON['stringify'](_0x417a06)),an(JSON['stringify'](_0xdbe31d)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x337b12=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x337b12=='object'&&_0x337b12['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x36985d=W();return _0x36985d['indexOf']('MSIE\x20')>=0x0||_0x36985d['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0xa2126a,_0x4a5b79)=>{try{let _0x401663=!0x0;const _0x35fae8='validate-browser-context-for-indexeddb-analytics-module',_0x1ad137=self['indexedDB']['open'](_0x35fae8);_0x1ad137['onsuccess']=()=>{_0x1ad137['result']['close'](),_0x401663||self['indexedDB']['deleteDatabase'](_0x35fae8),_0xa2126a(!0x0);},_0x1ad137['onupgradeneeded']=()=>{_0x401663=!0x1;},_0x1ad137['onerror']=()=>{var _0x55e6e5;_0x4a5b79(((_0x55e6e5=_0x1ad137['error'])==null?void 0x0:_0x55e6e5['message'])||'');};}catch(_0x123432){_0x4a5b79(_0x123432);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x2d8c85,_0x30e74a,_0x16b74b){super(_0x30e74a),this['code']=_0x2d8c85,this['customData']=_0x16b74b,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0x4a9cde,_0x2240f9,_0x6e8774){this['service']=_0x4a9cde,this['serviceName']=_0x2240f9,this['errors']=_0x6e8774;}['create'](_0x14ded9,..._0xf8c996){const _0x110050=_0xf8c996[0x0]||{},_0x3c5f66=this['service']+'/'+_0x14ded9,_0x2fced2=this['errors'][_0x14ded9],_0x2426bc=_0x2fced2?gc(_0x2fced2,_0x110050):'Error',_0x230234=this['serviceName']+':\x20'+_0x2426bc+'\x20('+_0x3c5f66+').';return new Se(_0x3c5f66,_0x230234,_0x110050);}}function gc(_0x1b69e1,_0x5550eb){return _0x1b69e1['replace'](mc,(_0x241ba6,_0x4406d2)=>{const _0x1aa3d2=_0x5550eb[_0x4406d2];return _0x1aa3d2!=null?String(_0x1aa3d2):'<'+_0x4406d2+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x5aeb05){return JSON['parse'](_0x5aeb05);}function O(_0x24b18b){return JSON['stringify'](_0x24b18b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x140e6f){let _0x4040d3={},_0x5c0344={},_0x10d34c={},_0x3a5289='';try{const _0x31d759=_0x140e6f['split']('.');_0x4040d3=bt(cn(_0x31d759[0x0])||''),_0x5c0344=bt(cn(_0x31d759[0x1])||''),_0x3a5289=_0x31d759[0x2],_0x10d34c=_0x5c0344['d']||{},delete _0x5c0344['d'];}catch{}return{'header':_0x4040d3,'claims':_0x5c0344,'data':_0x10d34c,'signature':_0x3a5289};},yc=function(_0x2f34d9){const _0x39ad7d=zr(_0x2f34d9),_0x47d112=_0x39ad7d['claims'];return!!_0x47d112&&typeof _0x47d112=='object'&&_0x47d112['hasOwnProperty']('iat');},vc=function(_0x13fd37){const _0x1cd5a5=zr(_0x13fd37)['claims'];return typeof _0x1cd5a5=='object'&&_0x1cd5a5['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1df9b3,_0x5bd66e){return Object['prototype']['hasOwnProperty']['call'](_0x1df9b3,_0x5bd66e);}function Oe(_0x8eb792,_0xc57a6d){if(Object['prototype']['hasOwnProperty']['call'](_0x8eb792,_0xc57a6d))return _0x8eb792[_0xc57a6d];}function hi(_0x124e9a){for(const _0x38e386 in _0x124e9a)if(Object['prototype']['hasOwnProperty']['call'](_0x124e9a,_0x38e386))return!0x1;return!0x0;}function ln(_0x5dce16,_0x5cb61a,_0x3fb73e){const _0x2ccc0d={};for(const _0x30ecfd in _0x5dce16)Object['prototype']['hasOwnProperty']['call'](_0x5dce16,_0x30ecfd)&&(_0x2ccc0d[_0x30ecfd]=_0x5cb61a['call'](_0x3fb73e,_0x5dce16[_0x30ecfd],_0x30ecfd,_0x5dce16));return _0x2ccc0d;}function De(_0xefc44e,_0x2638ae){if(_0xefc44e===_0x2638ae)return!0x0;const _0x4a2e49=Object['keys'](_0xefc44e),_0x367eb3=Object['keys'](_0x2638ae);for(const _0x1de0cb of _0x4a2e49){if(!_0x367eb3['includes'](_0x1de0cb))return!0x1;const _0x215eb4=_0xefc44e[_0x1de0cb],_0x4f532d=_0x2638ae[_0x1de0cb];if(ks(_0x215eb4)&&ks(_0x4f532d)){if(!De(_0x215eb4,_0x4f532d))return!0x1;}else{if(_0x215eb4!==_0x4f532d)return!0x1;}}for(const _0x49990a of _0x367eb3)if(!_0x4a2e49['includes'](_0x49990a))return!0x1;return!0x0;}function ks(_0xcd110e){return _0xcd110e!==null&&typeof _0xcd110e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x3b4a4e){const _0x263030=[];for(const [_0x1ab914,_0x238154]of Object['entries'](_0x3b4a4e))Array['isArray'](_0x238154)?_0x238154['forEach'](_0x47419d=>{_0x263030['push'](encodeURIComponent(_0x1ab914)+'='+encodeURIComponent(_0x47419d));}):_0x263030['push'](encodeURIComponent(_0x1ab914)+'='+encodeURIComponent(_0x238154));return _0x263030['length']?'&'+_0x263030['join']('&'):'';}function yt(_0x99a0f){const _0x491f3a={};return _0x99a0f['replace'](/^\?/,'')['split']('&')['forEach'](_0x263479=>{if(_0x263479){const [_0x398f6a,_0x38384e]=_0x263479['split']('=');_0x491f3a[decodeURIComponent(_0x398f6a)]=decodeURIComponent(_0x38384e);}}),_0x491f3a;}function vt(_0x173e79){const _0x579e58=_0x173e79['indexOf']('?');if(!_0x579e58)return'';const _0x4dc533=_0x173e79['indexOf']('#',_0x579e58);return _0x173e79['substring'](_0x579e58,_0x4dc533>0x0?_0x4dc533:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2f5117=0x1;_0x2f5117<this['blockSize'];++_0x2f5117)this['pad_'][_0x2f5117]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x47e0be,_0x5e1c34){_0x5e1c34||(_0x5e1c34=0x0);const _0x125d94=this['W_'];if(typeof _0x47e0be=='string'){for(let _0x455a49=0x0;_0x455a49<0x10;_0x455a49++)_0x125d94[_0x455a49]=_0x47e0be['charCodeAt'](_0x5e1c34)<<0x18|_0x47e0be['charCodeAt'](_0x5e1c34+0x1)<<0x10|_0x47e0be['charCodeAt'](_0x5e1c34+0x2)<<0x8|_0x47e0be['charCodeAt'](_0x5e1c34+0x3),_0x5e1c34+=0x4;}else{for(let _0x5045d8=0x0;_0x5045d8<0x10;_0x5045d8++)_0x125d94[_0x5045d8]=_0x47e0be[_0x5e1c34]<<0x18|_0x47e0be[_0x5e1c34+0x1]<<0x10|_0x47e0be[_0x5e1c34+0x2]<<0x8|_0x47e0be[_0x5e1c34+0x3],_0x5e1c34+=0x4;}for(let _0x5e15ba=0x10;_0x5e15ba<0x50;_0x5e15ba++){const _0x212d31=_0x125d94[_0x5e15ba-0x3]^_0x125d94[_0x5e15ba-0x8]^_0x125d94[_0x5e15ba-0xe]^_0x125d94[_0x5e15ba-0x10];_0x125d94[_0x5e15ba]=(_0x212d31<<0x1|_0x212d31>>>0x1f)&0xffffffff;}let _0x1ab872=this['chain_'][0x0],_0x4a2415=this['chain_'][0x1],_0x31cc73=this['chain_'][0x2],_0x8eb8ea=this['chain_'][0x3],_0xd07fe5=this['chain_'][0x4],_0x35550e,_0x55e718;for(let _0x3dfd51=0x0;_0x3dfd51<0x50;_0x3dfd51++){_0x3dfd51<0x28?_0x3dfd51<0x14?(_0x35550e=_0x8eb8ea^_0x4a2415&(_0x31cc73^_0x8eb8ea),_0x55e718=0x5a827999):(_0x35550e=_0x4a2415^_0x31cc73^_0x8eb8ea,_0x55e718=0x6ed9eba1):_0x3dfd51<0x3c?(_0x35550e=_0x4a2415&_0x31cc73|_0x8eb8ea&(_0x4a2415|_0x31cc73),_0x55e718=0x8f1bbcdc):(_0x35550e=_0x4a2415^_0x31cc73^_0x8eb8ea,_0x55e718=0xca62c1d6);const _0x21d4e9=(_0x1ab872<<0x5|_0x1ab872>>>0x1b)+_0x35550e+_0xd07fe5+_0x55e718+_0x125d94[_0x3dfd51]&0xffffffff;_0xd07fe5=_0x8eb8ea,_0x8eb8ea=_0x31cc73,_0x31cc73=(_0x4a2415<<0x1e|_0x4a2415>>>0x2)&0xffffffff,_0x4a2415=_0x1ab872,_0x1ab872=_0x21d4e9;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1ab872&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4a2415&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x31cc73&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x8eb8ea&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xd07fe5&0xffffffff;}['update'](_0x3ec402,_0x2d1fb6){if(_0x3ec402==null)return;_0x2d1fb6===void 0x0&&(_0x2d1fb6=_0x3ec402['length']);const _0xd562b7=_0x2d1fb6-this['blockSize'];let _0x6e5d18=0x0;const _0x2e3b99=this['buf_'];let _0x56a3f0=this['inbuf_'];for(;_0x6e5d18<_0x2d1fb6;){if(_0x56a3f0===0x0){for(;_0x6e5d18<=_0xd562b7;)this['compress_'](_0x3ec402,_0x6e5d18),_0x6e5d18+=this['blockSize'];}if(typeof _0x3ec402=='string'){for(;_0x6e5d18<_0x2d1fb6;)if(_0x2e3b99[_0x56a3f0]=_0x3ec402['charCodeAt'](_0x6e5d18),++_0x56a3f0,++_0x6e5d18,_0x56a3f0===this['blockSize']){this['compress_'](_0x2e3b99),_0x56a3f0=0x0;break;}}else{for(;_0x6e5d18<_0x2d1fb6;)if(_0x2e3b99[_0x56a3f0]=_0x3ec402[_0x6e5d18],++_0x56a3f0,++_0x6e5d18,_0x56a3f0===this['blockSize']){this['compress_'](_0x2e3b99),_0x56a3f0=0x0;break;}}}this['inbuf_']=_0x56a3f0,this['total_']+=_0x2d1fb6;}['digest'](){const _0x53dc1d=[];let _0xe3f5d5=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x32d152=this['blockSize']-0x1;_0x32d152>=0x38;_0x32d152--)this['buf_'][_0x32d152]=_0xe3f5d5&0xff,_0xe3f5d5/=0x100;this['compress_'](this['buf_']);let _0x1610d1=0x0;for(let _0x18c3fc=0x0;_0x18c3fc<0x5;_0x18c3fc++)for(let _0x481fee=0x18;_0x481fee>=0x0;_0x481fee-=0x8)_0x53dc1d[_0x1610d1]=this['chain_'][_0x18c3fc]>>_0x481fee&0xff,++_0x1610d1;return _0x53dc1d;}}function Ic(_0x2194c2,_0x4d0f17){const _0x576c42=new wc(_0x2194c2,_0x4d0f17);return _0x576c42['subscribe']['bind'](_0x576c42);}class wc{constructor(_0x15c526,_0x1f27d5){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x1f27d5,this['task']['then'](()=>{_0x15c526(this);})['catch'](_0x5dcf92=>{this['error'](_0x5dcf92);});}['next'](_0x1cc250){this['forEachObserver'](_0x364217=>{_0x364217['next'](_0x1cc250);});}['error'](_0x36e400){this['forEachObserver'](_0x5ba4e7=>{_0x5ba4e7['error'](_0x36e400);}),this['close'](_0x36e400);}['complete'](){this['forEachObserver'](_0x5f5976=>{_0x5f5976['complete']();}),this['close']();}['subscribe'](_0x847c08,_0x3e542b,_0x52db52){let _0x3db306;if(_0x847c08===void 0x0&&_0x3e542b===void 0x0&&_0x52db52===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x847c08,['next','error','complete'])?_0x3db306=_0x847c08:_0x3db306={'next':_0x847c08,'error':_0x3e542b,'complete':_0x52db52},_0x3db306['next']===void 0x0&&(_0x3db306['next']=Qn),_0x3db306['error']===void 0x0&&(_0x3db306['error']=Qn),_0x3db306['complete']===void 0x0&&(_0x3db306['complete']=Qn);const _0x4e4b5d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x3db306['error'](this['finalError']):_0x3db306['complete']();}catch{}}),this['observers']['push'](_0x3db306),_0x4e4b5d;}['unsubscribeOne'](_0x1e247d){this['observers']===void 0x0||this['observers'][_0x1e247d]===void 0x0||(delete this['observers'][_0x1e247d],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2dd8d7){if(!this['finalized']){for(let _0x15ffe9=0x0;_0x15ffe9<this['observers']['length'];_0x15ffe9++)this['sendOne'](_0x15ffe9,_0x2dd8d7);}}['sendOne'](_0x715d4,_0x460bf5){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x715d4]!==void 0x0)try{_0x460bf5(this['observers'][_0x715d4]);}catch(_0x5dfe80){typeof console<'u'&&console['error']&&console['error'](_0x5dfe80);}});}['close'](_0x3bd59f){this['finalized']||(this['finalized']=!0x0,_0x3bd59f!==void 0x0&&(this['finalError']=_0x3bd59f),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x37aed2,_0x3da05a){if(typeof _0x37aed2!='object'||_0x37aed2===null)return!0x1;for(const _0x2f5b44 of _0x3da05a)if(_0x2f5b44 in _0x37aed2&&typeof _0x37aed2[_0x2f5b44]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x5e5091,_0x48106c){return _0x5e5091+'\x20failed:\x20'+_0x48106c+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0x3dbe2d){const _0x1badfb=[];let _0x2048db=0x0;for(let _0x12815c=0x0;_0x12815c<_0x3dbe2d['length'];_0x12815c++){let _0x31dc54=_0x3dbe2d['charCodeAt'](_0x12815c);if(_0x31dc54>=0xd800&&_0x31dc54<=0xdbff){const _0x32efdd=_0x31dc54-0xd800;_0x12815c++,f(_0x12815c<_0x3dbe2d['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x193179=_0x3dbe2d['charCodeAt'](_0x12815c)-0xdc00;_0x31dc54=0x10000+(_0x32efdd<<0xa)+_0x193179;}_0x31dc54<0x80?_0x1badfb[_0x2048db++]=_0x31dc54:_0x31dc54<0x800?(_0x1badfb[_0x2048db++]=_0x31dc54>>0x6|0xc0,_0x1badfb[_0x2048db++]=_0x31dc54&0x3f|0x80):_0x31dc54<0x10000?(_0x1badfb[_0x2048db++]=_0x31dc54>>0xc|0xe0,_0x1badfb[_0x2048db++]=_0x31dc54>>0x6&0x3f|0x80,_0x1badfb[_0x2048db++]=_0x31dc54&0x3f|0x80):(_0x1badfb[_0x2048db++]=_0x31dc54>>0x12|0xf0,_0x1badfb[_0x2048db++]=_0x31dc54>>0xc&0x3f|0x80,_0x1badfb[_0x2048db++]=_0x31dc54>>0x6&0x3f|0x80,_0x1badfb[_0x2048db++]=_0x31dc54&0x3f|0x80);}return _0x1badfb;},Pn=function(_0x11d61d){let _0x1515f1=0x0;for(let _0x461258=0x0;_0x461258<_0x11d61d['length'];_0x461258++){const _0x5f251d=_0x11d61d['charCodeAt'](_0x461258);_0x5f251d<0x80?_0x1515f1++:_0x5f251d<0x800?_0x1515f1+=0x2:_0x5f251d>=0xd800&&_0x5f251d<=0xdbff?(_0x1515f1+=0x4,_0x461258++):_0x1515f1+=0x3;}return _0x1515f1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0xfc759c){return _0xfc759c&&_0xfc759c['_delegate']?_0xfc759c['_delegate']:_0xfc759c;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x3488bd){try{return(_0x3488bd['startsWith']('http://')||_0x3488bd['startsWith']('https://')?new URL(_0x3488bd)['hostname']:_0x3488bd)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x3b29be){return(await fetch(_0x3b29be,{'credentials':'include'}))['ok'];}class Me{constructor(_0x4ed950,_0x2fe85f,_0x39bb4d){this['name']=_0x4ed950,this['instanceFactory']=_0x2fe85f,this['type']=_0x39bb4d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x5ef106){return this['instantiationMode']=_0x5ef106,this;}['setMultipleInstances'](_0x52d843){return this['multipleInstances']=_0x52d843,this;}['setServiceProps'](_0x33236f){return this['serviceProps']=_0x33236f,this;}['setInstanceCreatedCallback'](_0x41ec47){return this['onInstanceCreated']=_0x41ec47,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x9576d7,_0x192d38){this['name']=_0x9576d7,this['container']=_0x192d38,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4cbd97){const _0x26d357=this['normalizeInstanceIdentifier'](_0x4cbd97);if(!this['instancesDeferred']['has'](_0x26d357)){const _0x5e6efa=new Ve();if(this['instancesDeferred']['set'](_0x26d357,_0x5e6efa),this['isInitialized'](_0x26d357)||this['shouldAutoInitialize']())try{const _0x13d9ce=this['getOrInitializeService']({'instanceIdentifier':_0x26d357});_0x13d9ce&&_0x5e6efa['resolve'](_0x13d9ce);}catch{}}return this['instancesDeferred']['get'](_0x26d357)['promise'];}['getImmediate'](_0x4d542a){const _0x4e0504=this['normalizeInstanceIdentifier'](_0x4d542a==null?void 0x0:_0x4d542a['identifier']),_0x4158bb=(_0x4d542a==null?void 0x0:_0x4d542a['optional'])??!0x1;if(this['isInitialized'](_0x4e0504)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4e0504});}catch(_0x3a4dfe){if(_0x4158bb)return null;throw _0x3a4dfe;}else{if(_0x4158bb)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xf6b997){if(_0xf6b997['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xf6b997['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xf6b997,!!this['shouldAutoInitialize']()){if(Rc(_0xf6b997))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0xe919a8,_0x1bf224]of this['instancesDeferred']['entries']()){const _0x204ae1=this['normalizeInstanceIdentifier'](_0xe919a8);try{const _0x5a11ab=this['getOrInitializeService']({'instanceIdentifier':_0x204ae1});_0x1bf224['resolve'](_0x5a11ab);}catch{}}}}['clearInstance'](_0x438da1=ke){this['instancesDeferred']['delete'](_0x438da1),this['instancesOptions']['delete'](_0x438da1),this['instances']['delete'](_0x438da1);}async['delete'](){const _0x57b60d=Array['from'](this['instances']['values']());await Promise['all']([..._0x57b60d['filter'](_0x10175b=>'INTERNAL'in _0x10175b)['map'](_0x179cbf=>_0x179cbf['INTERNAL']['delete']()),..._0x57b60d['filter'](_0x2a9c2b=>'_delete'in _0x2a9c2b)['map'](_0x10d82f=>_0x10d82f['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x5f34b5=ke){return this['instances']['has'](_0x5f34b5);}['getOptions'](_0x5d2a7b=ke){return this['instancesOptions']['get'](_0x5d2a7b)||{};}['initialize'](_0x2ef5bb={}){const {options:_0x5a0524={}}=_0x2ef5bb,_0x3cd137=this['normalizeInstanceIdentifier'](_0x2ef5bb['instanceIdentifier']);if(this['isInitialized'](_0x3cd137))throw Error(this['name']+'('+_0x3cd137+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5c1a49=this['getOrInitializeService']({'instanceIdentifier':_0x3cd137,'options':_0x5a0524});for(const [_0x3b2926,_0x5b735d]of this['instancesDeferred']['entries']()){const _0x2e315a=this['normalizeInstanceIdentifier'](_0x3b2926);_0x3cd137===_0x2e315a&&_0x5b735d['resolve'](_0x5c1a49);}return _0x5c1a49;}['onInit'](_0x9056b8,_0x12ec40){const _0x212a06=this['normalizeInstanceIdentifier'](_0x12ec40),_0x396dcf=this['onInitCallbacks']['get'](_0x212a06)??new Set();_0x396dcf['add'](_0x9056b8),this['onInitCallbacks']['set'](_0x212a06,_0x396dcf);const _0x5b7a6c=this['instances']['get'](_0x212a06);return _0x5b7a6c&&_0x9056b8(_0x5b7a6c,_0x212a06),()=>{_0x396dcf['delete'](_0x9056b8);};}['invokeOnInitCallbacks'](_0x5a0054,_0x68c0ae){const _0x371964=this['onInitCallbacks']['get'](_0x68c0ae);if(_0x371964){for(const _0x1c5ccf of _0x371964)try{_0x1c5ccf(_0x5a0054,_0x68c0ae);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x504cef,options:_0x97ddc8={}}){let _0x49dadb=this['instances']['get'](_0x504cef);if(!_0x49dadb&&this['component']&&(_0x49dadb=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x504cef),'options':_0x97ddc8}),this['instances']['set'](_0x504cef,_0x49dadb),this['instancesOptions']['set'](_0x504cef,_0x97ddc8),this['invokeOnInitCallbacks'](_0x49dadb,_0x504cef),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x504cef,_0x49dadb);}catch{}return _0x49dadb||null;}['normalizeInstanceIdentifier'](_0x3a5998=ke){return this['component']?this['component']['multipleInstances']?_0x3a5998:ke:_0x3a5998;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0xba0e37){return _0xba0e37===ke?void 0x0:_0xba0e37;}function Rc(_0x4cb3f9){return _0x4cb3f9['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2459f9){this['name']=_0x2459f9,this['providers']=new Map();}['addComponent'](_0x2ac208){const _0x582758=this['getProvider'](_0x2ac208['name']);if(_0x582758['isComponentSet']())throw new Error('Component\x20'+_0x2ac208['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x582758['setComponent'](_0x2ac208);}['addOrOverwriteComponent'](_0x4584d5){this['getProvider'](_0x4584d5['name'])['isComponentSet']()&&this['providers']['delete'](_0x4584d5['name']),this['addComponent'](_0x4584d5);}['getProvider'](_0x1c19bd){if(this['providers']['has'](_0x1c19bd))return this['providers']['get'](_0x1c19bd);const _0x2aa3ca=new Sc(_0x1c19bd,this);return this['providers']['set'](_0x1c19bd,_0x2aa3ca),_0x2aa3ca;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x44da1d){_0x44da1d[_0x44da1d['DEBUG']=0x0]='DEBUG',_0x44da1d[_0x44da1d['VERBOSE']=0x1]='VERBOSE',_0x44da1d[_0x44da1d['INFO']=0x2]='INFO',_0x44da1d[_0x44da1d['WARN']=0x3]='WARN',_0x44da1d[_0x44da1d['ERROR']=0x4]='ERROR',_0x44da1d[_0x44da1d['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x539f27,_0x1d752c,..._0xbc0783)=>{if(_0x1d752c<_0x539f27['logLevel'])return;const _0x4c649a=new Date()['toISOString'](),_0x9cb462=Pc[_0x1d752c];if(_0x9cb462)console[_0x9cb462]('['+_0x4c649a+']\x20\x20'+_0x539f27['name']+':',..._0xbc0783);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1d752c+')');};class xi{constructor(_0x4cfcdc){this['name']=_0x4cfcdc,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5abbcb){if(!(_0x5abbcb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5abbcb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5abbcb;}['setLogLevel'](_0x36e645){this['_logLevel']=typeof _0x36e645=='string'?kc[_0x36e645]:_0x36e645;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x4ec013){if(typeof _0x4ec013!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x4ec013;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2928e){this['_userLogHandler']=_0x2928e;}['debug'](..._0x404b1e){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x404b1e),this['_logHandler'](this,T['DEBUG'],..._0x404b1e);}['log'](..._0x4cf6cf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4cf6cf),this['_logHandler'](this,T['VERBOSE'],..._0x4cf6cf);}['info'](..._0x4adc51){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x4adc51),this['_logHandler'](this,T['INFO'],..._0x4adc51);}['warn'](..._0x40aee7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x40aee7),this['_logHandler'](this,T['WARN'],..._0x40aee7);}['error'](..._0x54b83b){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x54b83b),this['_logHandler'](this,T['ERROR'],..._0x54b83b);}}const Dc=(_0x4f389d,_0x1aee6b)=>_0x1aee6b['some'](_0x4319d7=>_0x4f389d instanceof _0x4319d7);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x1fc495){const _0x313486=new Promise((_0x542446,_0x5e179f)=>{const _0x344f22=()=>{_0x1fc495['removeEventListener']('success',_0x3911da),_0x1fc495['removeEventListener']('error',_0x2eb33a);},_0x3911da=()=>{_0x542446(_e(_0x1fc495['result'])),_0x344f22();},_0x2eb33a=()=>{_0x5e179f(_0x1fc495['error']),_0x344f22();};_0x1fc495['addEventListener']('success',_0x3911da),_0x1fc495['addEventListener']('error',_0x2eb33a);});return _0x313486['then'](_0x1fff5c=>{_0x1fff5c instanceof IDBCursor&&Kr['set'](_0x1fff5c,_0x1fc495);})['catch'](()=>{}),Fi['set'](_0x313486,_0x1fc495),_0x313486;}function Fc(_0x42a6d5){if(ui['has'](_0x42a6d5))return;const _0x1e8709=new Promise((_0x305029,_0x2365ab)=>{const _0xd29032=()=>{_0x42a6d5['removeEventListener']('complete',_0x9398d4),_0x42a6d5['removeEventListener']('error',_0x989d39),_0x42a6d5['removeEventListener']('abort',_0x989d39);},_0x9398d4=()=>{_0x305029(),_0xd29032();},_0x989d39=()=>{_0x2365ab(_0x42a6d5['error']||new DOMException('AbortError','AbortError')),_0xd29032();};_0x42a6d5['addEventListener']('complete',_0x9398d4),_0x42a6d5['addEventListener']('error',_0x989d39),_0x42a6d5['addEventListener']('abort',_0x989d39);});ui['set'](_0x42a6d5,_0x1e8709);}let di={'get'(_0x1a5c3f,_0x2eb438,_0x311eae){if(_0x1a5c3f instanceof IDBTransaction){if(_0x2eb438==='done')return ui['get'](_0x1a5c3f);if(_0x2eb438==='objectStoreNames')return _0x1a5c3f['objectStoreNames']||Yr['get'](_0x1a5c3f);if(_0x2eb438==='store')return _0x311eae['objectStoreNames'][0x1]?void 0x0:_0x311eae['objectStore'](_0x311eae['objectStoreNames'][0x0]);}return _e(_0x1a5c3f[_0x2eb438]);},'set'(_0x3a2fe6,_0xf6a0c,_0x3d809b){return _0x3a2fe6[_0xf6a0c]=_0x3d809b,!0x0;},'has'(_0x54c431,_0x48d119){return _0x54c431 instanceof IDBTransaction&&(_0x48d119==='done'||_0x48d119==='store')?!0x0:_0x48d119 in _0x54c431;}};function Uc(_0x535621){di=_0x535621(di);}function Wc(_0x32a05c){return _0x32a05c===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x34bb9c,..._0x405ac0){const _0x5c96c6=_0x32a05c['call'](Xn(this),_0x34bb9c,..._0x405ac0);return Yr['set'](_0x5c96c6,_0x34bb9c['sort']?_0x34bb9c['sort']():[_0x34bb9c]),_e(_0x5c96c6);}:Lc()['includes'](_0x32a05c)?function(..._0x1596a8){return _0x32a05c['apply'](Xn(this),_0x1596a8),_e(Kr['get'](this));}:function(..._0x3e7595){return _e(_0x32a05c['apply'](Xn(this),_0x3e7595));};}function Bc(_0x489609){return typeof _0x489609=='function'?Wc(_0x489609):(_0x489609 instanceof IDBTransaction&&Fc(_0x489609),Dc(_0x489609,Mc())?new Proxy(_0x489609,di):_0x489609);}function _e(_0xf245c1){if(_0xf245c1 instanceof IDBRequest)return xc(_0xf245c1);if(Jn['has'](_0xf245c1))return Jn['get'](_0xf245c1);const _0x1197aa=Bc(_0xf245c1);return _0x1197aa!==_0xf245c1&&(Jn['set'](_0xf245c1,_0x1197aa),Fi['set'](_0x1197aa,_0xf245c1)),_0x1197aa;}const Xn=_0x4d4bb5=>Fi['get'](_0x4d4bb5);function Vc(_0x42162e,_0x229e6e,{blocked:_0x476cb5,upgrade:_0x102202,blocking:_0x5a7efd,terminated:_0x5a9c9e}={}){const _0x39be98=indexedDB['open'](_0x42162e,_0x229e6e),_0x44fe52=_e(_0x39be98);return _0x102202&&_0x39be98['addEventListener']('upgradeneeded',_0xacfa7e=>{_0x102202(_e(_0x39be98['result']),_0xacfa7e['oldVersion'],_0xacfa7e['newVersion'],_e(_0x39be98['transaction']),_0xacfa7e);}),_0x476cb5&&_0x39be98['addEventListener']('blocked',_0xf690a6=>_0x476cb5(_0xf690a6['oldVersion'],_0xf690a6['newVersion'],_0xf690a6)),_0x44fe52['then'](_0x237153=>{_0x5a9c9e&&_0x237153['addEventListener']('close',()=>_0x5a9c9e()),_0x5a7efd&&_0x237153['addEventListener']('versionchange',_0x45bb79=>_0x5a7efd(_0x45bb79['oldVersion'],_0x45bb79['newVersion'],_0x45bb79));})['catch'](()=>{}),_0x44fe52;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x33e600,_0x463bd9){if(!(_0x33e600 instanceof IDBDatabase&&!(_0x463bd9 in _0x33e600)&&typeof _0x463bd9=='string'))return;if(Zn['get'](_0x463bd9))return Zn['get'](_0x463bd9);const _0x26b9e8=_0x463bd9['replace'](/FromIndex$/,''),_0x68e47d=_0x463bd9!==_0x26b9e8,_0x5ead66=$c['includes'](_0x26b9e8);if(!(_0x26b9e8 in(_0x68e47d?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5ead66||Hc['includes'](_0x26b9e8)))return;const _0xebf1ed=async function(_0x4f7f09,..._0x5eb504){const _0x4b020f=this['transaction'](_0x4f7f09,_0x5ead66?'readwrite':'readonly');let _0x40f91b=_0x4b020f['store'];return _0x68e47d&&(_0x40f91b=_0x40f91b['index'](_0x5eb504['shift']())),(await Promise['all']([_0x40f91b[_0x26b9e8](..._0x5eb504),_0x5ead66&&_0x4b020f['done']]))[0x0];};return Zn['set'](_0x463bd9,_0xebf1ed),_0xebf1ed;}Uc(_0xd161a1=>({..._0xd161a1,'get':(_0x2b6ed3,_0x2b746a,_0x56e5ac)=>Os(_0x2b6ed3,_0x2b746a)||_0xd161a1['get'](_0x2b6ed3,_0x2b746a,_0x56e5ac),'has':(_0x498270,_0x383276)=>!!Os(_0x498270,_0x383276)||_0xd161a1['has'](_0x498270,_0x383276)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x2343bf){this['container']=_0x2343bf;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2019e0=>{if(qc(_0x2019e0)){const _0x25967e=_0x2019e0['getImmediate']();return _0x25967e['library']+'/'+_0x25967e['version'];}else return null;})['filter'](_0x24faa8=>_0x24faa8)['join']('\x20');}}function qc(_0x18653d){const _0x9201a2=_0x18653d['getComponent']();return(_0x9201a2==null?void 0x0:_0x9201a2['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x111a40,_0x5d1f17){try{_0x111a40['container']['addComponent'](_0x5d1f17);}catch(_0x564677){re['debug']('Component\x20'+_0x5d1f17['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x111a40['name'],_0x564677);}}function et(_0x25bbcf){const _0x5677bc=_0x25bbcf['name'];if(gi['has'](_0x5677bc))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5677bc+'.'),!0x1;gi['set'](_0x5677bc,_0x25bbcf);for(const _0x19cb3c of Le['values']())Ms(_0x19cb3c,_0x25bbcf);for(const _0x29421f of _i['values']())Ms(_0x29421f,_0x25bbcf);return!0x0;}function Ui(_0x137a8e,_0x568bfb){const _0x41a15f=_0x137a8e['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x41a15f&&_0x41a15f['triggerHeartbeat'](),_0x137a8e['container']['getProvider'](_0x568bfb);}function H(_0x195e60){return _0x195e60==null?!0x1:_0x195e60['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x5e1899,_0x51041e,_0x4e4df4){this['_isDeleted']=!0x1,this['_options']={..._0x5e1899},this['_config']={..._0x51041e},this['_name']=_0x51041e['name'],this['_automaticDataCollectionEnabled']=_0x51041e['automaticDataCollectionEnabled'],this['_container']=_0x4e4df4,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x178abb){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x178abb;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x432958){this['_isDeleted']=_0x432958;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0x5f9670,_0x288442={}){let _0x598bce=_0x5f9670;typeof _0x288442!='object'&&(_0x288442={'name':_0x288442});const _0x329faa={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x288442},_0x186a8d=_0x329faa['name'];if(typeof _0x186a8d!='string'||!_0x186a8d)throw ge['create']('bad-app-name',{'appName':String(_0x186a8d)});if(_0x598bce||(_0x598bce=$r()),!_0x598bce)throw ge['create']('no-options');const _0x42e5af=Le['get'](_0x186a8d);if(_0x42e5af){if(De(_0x598bce,_0x42e5af['options'])&&De(_0x329faa,_0x42e5af['config']))return _0x42e5af;throw ge['create']('duplicate-app',{'appName':_0x186a8d});}const _0x4a4b99=new Ac(_0x186a8d);for(const _0x4a133a of gi['values']())_0x4a4b99['addComponent'](_0x4a133a);const _0x427cb0=new Il(_0x598bce,_0x329faa,_0x4a4b99);return Le['set'](_0x186a8d,_0x427cb0),_0x427cb0;}function Qr(_0x284d7b=pi){const _0x2cfee1=Le['get'](_0x284d7b);if(!_0x2cfee1&&_0x284d7b===pi&&$r())return wl();if(!_0x2cfee1)throw ge['create']('no-app',{'appName':_0x284d7b});return _0x2cfee1;}function c_(){return Array['from'](Le['values']());}async function l_(_0x4d730e){let _0x171997=!0x1;const _0x4d44ea=_0x4d730e['name'];Le['has'](_0x4d44ea)?(_0x171997=!0x0,Le['delete'](_0x4d44ea)):_i['has'](_0x4d44ea)&&_0x4d730e['decRefCount']()<=0x0&&(_i['delete'](_0x4d44ea),_0x171997=!0x0),_0x171997&&(await Promise['all'](_0x4d730e['container']['getProviders']()['map'](_0x517337=>_0x517337['delete']())),_0x4d730e['isDeleted']=!0x0);}function me(_0x12c29b,_0x4a1669,_0x2aae44){let _0x3eda51=vl[_0x12c29b]??_0x12c29b;_0x2aae44&&(_0x3eda51+='-'+_0x2aae44);const _0x277aff=_0x3eda51['match'](/\s|\//),_0x162d10=_0x4a1669['match'](/\s|\//);if(_0x277aff||_0x162d10){const _0x4705f6=['Unable\x20to\x20register\x20library\x20\x22'+_0x3eda51+'\x22\x20with\x20version\x20\x22'+_0x4a1669+'\x22:'];_0x277aff&&_0x4705f6['push']('library\x20name\x20\x22'+_0x3eda51+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x277aff&&_0x162d10&&_0x4705f6['push']('and'),_0x162d10&&_0x4705f6['push']('version\x20name\x20\x22'+_0x4a1669+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x4705f6['join']('\x20'));return;}et(new Me(_0x3eda51+'-version',()=>({'library':_0x3eda51,'version':_0x4a1669}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x3e3daf,_0x38de54)=>{switch(_0x38de54){case 0x0:try{_0x3e3daf['createObjectStore'](Rt);}catch(_0x69383f){console['warn'](_0x69383f);}}}})['catch'](_0x3a0e4f=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x3a0e4f['message']});})),ei;}async function Sl(_0x45569b){try{const _0x420433=(await Jr())['transaction'](Rt),_0x54201e=await _0x420433['objectStore'](Rt)['get'](Xr(_0x45569b));return await _0x420433['done'],_0x54201e;}catch(_0xfc2dd5){if(_0xfc2dd5 instanceof Se)re['warn'](_0xfc2dd5['message']);else{const _0x15d327=ge['create']('idb-get',{'originalErrorMessage':_0xfc2dd5==null?void 0x0:_0xfc2dd5['message']});re['warn'](_0x15d327['message']);}}}async function Ls(_0x3a9cbe,_0x178826){try{const _0x330246=(await Jr())['transaction'](Rt,'readwrite');await _0x330246['objectStore'](Rt)['put'](_0x178826,Xr(_0x3a9cbe)),await _0x330246['done'];}catch(_0x54a1f1){if(_0x54a1f1 instanceof Se)re['warn'](_0x54a1f1['message']);else{const _0x52d3ef=ge['create']('idb-set',{'originalErrorMessage':_0x54a1f1==null?void 0x0:_0x54a1f1['message']});re['warn'](_0x52d3ef['message']);}}}function Xr(_0x4fee60){return _0x4fee60['name']+'!'+_0x4fee60['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x2b31d7){this['container']=_0x2b31d7,this['_heartbeatsCache']=null;const _0xdb1b94=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0xdb1b94),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3d4aa2=>(this['_heartbeatsCache']=_0x3d4aa2,_0x3d4aa2));}async['triggerHeartbeat'](){var _0x852a69,_0x438d4a;try{const _0xcc67c8=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5984a6=xs();if(((_0x852a69=this['_heartbeatsCache'])==null?void 0x0:_0x852a69['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x438d4a=this['_heartbeatsCache'])==null?void 0x0:_0x438d4a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5984a6||this['_heartbeatsCache']['heartbeats']['some'](_0x3690f5=>_0x3690f5['date']===_0x5984a6))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5984a6,'agent':_0xcc67c8}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x31528f=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x31528f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x270065){re['warn'](_0x270065);}}async['getHeartbeatsHeader'](){var _0x291015;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x291015=this['_heartbeatsCache'])==null?void 0x0:_0x291015['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x35977a=xs(),{heartbeatsToSend:_0x596a7d,unsentEntries:_0x4dff64}=kl(this['_heartbeatsCache']['heartbeats']),_0x518566=an(JSON['stringify']({'version':0x2,'heartbeats':_0x596a7d}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x35977a,_0x4dff64['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x4dff64,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x518566;}catch(_0x46980c){return re['warn'](_0x46980c),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x58e9b6,_0x109f0c=bl){const _0x552eec=[];let _0x3f2a24=_0x58e9b6['slice']();for(const _0x2cd523 of _0x58e9b6){const _0x33472d=_0x552eec['find'](_0x128c81=>_0x128c81['agent']===_0x2cd523['agent']);if(_0x33472d){if(_0x33472d['dates']['push'](_0x2cd523['date']),Fs(_0x552eec)>_0x109f0c){_0x33472d['dates']['pop']();break;}}else{if(_0x552eec['push']({'agent':_0x2cd523['agent'],'dates':[_0x2cd523['date']]}),Fs(_0x552eec)>_0x109f0c){_0x552eec['pop']();break;}}_0x3f2a24=_0x3f2a24['slice'](0x1);}return{'heartbeatsToSend':_0x552eec,'unsentEntries':_0x3f2a24};}class Nl{constructor(_0x46a5b3){this['app']=_0x46a5b3,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x214781=await Sl(this['app']);return _0x214781!=null&&_0x214781['heartbeats']?_0x214781:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5660fc){if(await this['_canUseIndexedDBPromise']){const _0x1a69e4=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x5660fc['lastSentHeartbeatDate']??_0x1a69e4['lastSentHeartbeatDate'],'heartbeats':_0x5660fc['heartbeats']});}else return;}async['add'](_0x1c8d02){if(await this['_canUseIndexedDBPromise']){const _0x717f2c=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x1c8d02['lastSentHeartbeatDate']??_0x717f2c['lastSentHeartbeatDate'],'heartbeats':[..._0x717f2c['heartbeats'],..._0x1c8d02['heartbeats']]});}else return;}}function Fs(_0x28f830){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x28f830}))['length'];}function Pl(_0x4c2767){if(_0x4c2767['length']===0x0)return-0x1;let _0x1e29ac=0x0,_0x288514=_0x4c2767[0x0]['date'];for(let _0x1f212c=0x1;_0x1f212c<_0x4c2767['length'];_0x1f212c++)_0x4c2767[_0x1f212c]['date']<_0x288514&&(_0x288514=_0x4c2767[_0x1f212c]['date'],_0x1e29ac=_0x1f212c);return _0x1e29ac;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x141937){et(new Me('platform-logger',_0x578513=>new Gc(_0x578513),'PRIVATE')),et(new Me('heartbeat',_0x32cf70=>new Al(_0x32cf70),'PRIVATE')),me(fi,Ds,_0x141937),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x27b619){Zr=_0x27b619;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x443294){this['domStorage_']=_0x443294,this['prefix_']='firebase:';}['set'](_0x56f097,_0x323cea){_0x323cea==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x56f097)):this['domStorage_']['setItem'](this['prefixedName_'](_0x56f097),O(_0x323cea));}['get'](_0x597084){const _0x412da0=this['domStorage_']['getItem'](this['prefixedName_'](_0x597084));return _0x412da0==null?null:bt(_0x412da0);}['remove'](_0x37f7b8){this['domStorage_']['removeItem'](this['prefixedName_'](_0x37f7b8));}['prefixedName_'](_0x589f56){return this['prefix_']+_0x589f56;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x700d14,_0x491503){_0x491503==null?delete this['cache_'][_0x700d14]:this['cache_'][_0x700d14]=_0x491503;}['get'](_0x157444){return Y(this['cache_'],_0x157444)?this['cache_'][_0x157444]:null;}['remove'](_0x425686){delete this['cache_'][_0x425686];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x4add24){try{if(typeof window<'u'&&typeof window[_0x4add24]<'u'){const _0x41bea8=window[_0x4add24];return _0x41bea8['setItem']('firebase:sentinel','cache'),_0x41bea8['removeItem']('firebase:sentinel'),new xl(_0x41bea8);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x32fd51=0x1;return function(){return _0x32fd51++;};}()),no=function(_0x5e4f36){const _0x132dd2=Tc(_0x5e4f36),_0x4d7618=new Ec();_0x4d7618['update'](_0x132dd2);const _0x4637e5=_0x4d7618['digest']();return Di['encodeByteArray'](_0x4637e5);},Bt=function(..._0x3e7443){let _0x257181='';for(let _0x3966ee=0x0;_0x3966ee<_0x3e7443['length'];_0x3966ee++){const _0x142eb6=_0x3e7443[_0x3966ee];Array['isArray'](_0x142eb6)||_0x142eb6&&typeof _0x142eb6=='object'&&typeof _0x142eb6['length']=='number'?_0x257181+=Bt['apply'](null,_0x142eb6):typeof _0x142eb6=='object'?_0x257181+=O(_0x142eb6):_0x257181+=_0x142eb6,_0x257181+='\x20';}return _0x257181;};let Et=null,Vs=!0x0;const Wl=function(_0xfcbb45,_0xff80ea){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0xa65627){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0xe3a7dc=Bt['apply'](null,_0xa65627);Et(_0xe3a7dc);}},Vt=function(_0x14424b){return function(..._0x2dda54){L(_0x14424b,..._0x2dda54);};},mi=function(..._0xc3fde4){const _0x31ca19='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0xc3fde4);Qe['error'](_0x31ca19);},oe=function(..._0x4abaa7){const _0x2ced9e='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x4abaa7);throw Qe['error'](_0x2ced9e),new Error(_0x2ced9e);},U=function(..._0x2f4d2a){const _0x198b06='FIREBASE\x20WARNING:\x20'+Bt(..._0x2f4d2a);Qe['warn'](_0x198b06);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x2a27a8){return typeof _0x2a27a8=='number'&&(_0x2a27a8!==_0x2a27a8||_0x2a27a8===Number['POSITIVE_INFINITY']||_0x2a27a8===Number['NEGATIVE_INFINITY']);},Vl=function(_0x88f29c){if(document['readyState']==='complete')_0x88f29c();else{let _0x4cfc65=!0x1;const _0x23ac99=function(){if(!document['body']){setTimeout(_0x23ac99,Math['floor'](0xa));return;}_0x4cfc65||(_0x4cfc65=!0x0,_0x88f29c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x23ac99,!0x1),window['addEventListener']('load',_0x23ac99,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x23ac99();}),window['attachEvent']('onload',_0x23ac99));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x3ca3ae,_0x126bf9){if(_0x3ca3ae===_0x126bf9)return 0x0;if(_0x3ca3ae===xe||_0x126bf9===Ie)return-0x1;if(_0x126bf9===xe||_0x3ca3ae===Ie)return 0x1;{const _0x53913f=Hs(_0x3ca3ae),_0x2792ea=Hs(_0x126bf9);return _0x53913f!==null?_0x2792ea!==null?_0x53913f-_0x2792ea===0x0?_0x3ca3ae['length']-_0x126bf9['length']:_0x53913f-_0x2792ea:-0x1:_0x2792ea!==null?0x1:_0x3ca3ae<_0x126bf9?-0x1:0x1;}},Hl=function(_0x4233dc,_0x548623){return _0x4233dc===_0x548623?0x0:_0x4233dc<_0x548623?-0x1:0x1;},pt=function(_0x180a12,_0x2bc84d){if(_0x2bc84d&&_0x180a12 in _0x2bc84d)return _0x2bc84d[_0x180a12];throw new Error('Missing\x20required\x20key\x20('+_0x180a12+')\x20in\x20object:\x20'+O(_0x2bc84d));},Bi=function(_0x59b736){if(typeof _0x59b736!='object'||_0x59b736===null)return O(_0x59b736);const _0x159313=[];for(const _0x2e9d81 in _0x59b736)_0x159313['push'](_0x2e9d81);_0x159313['sort']();let _0x24027b='{';for(let _0x323841=0x0;_0x323841<_0x159313['length'];_0x323841++)_0x323841!==0x0&&(_0x24027b+=','),_0x24027b+=O(_0x159313[_0x323841]),_0x24027b+=':',_0x24027b+=Bi(_0x59b736[_0x159313[_0x323841]]);return _0x24027b+='}',_0x24027b;},io=function(_0x5c7ae3,_0x141cd3){const _0x4220e7=_0x5c7ae3['length'];if(_0x4220e7<=_0x141cd3)return[_0x5c7ae3];const _0x3de9c5=[];for(let _0x5408e1=0x0;_0x5408e1<_0x4220e7;_0x5408e1+=_0x141cd3)_0x5408e1+_0x141cd3>_0x4220e7?_0x3de9c5['push'](_0x5c7ae3['substring'](_0x5408e1,_0x4220e7)):_0x3de9c5['push'](_0x5c7ae3['substring'](_0x5408e1,_0x5408e1+_0x141cd3));return _0x3de9c5;};function x(_0x24d13d,_0xeedf7d){for(const _0x398110 in _0x24d13d)_0x24d13d['hasOwnProperty'](_0x398110)&&_0xeedf7d(_0x398110,_0x24d13d[_0x398110]);}const so=function(_0x338c3d){f(!Wi(_0x338c3d),'Invalid\x20JSON\x20number');const _0x428f07=0xb,_0x299ebd=0x34,_0xeec7cf=(0x1<<_0x428f07-0x1)-0x1;let _0x17e733,_0xe44269,_0x7955af,_0x19b976,_0x3215de;_0x338c3d===0x0?(_0xe44269=0x0,_0x7955af=0x0,_0x17e733=0x1/_0x338c3d===-0x1/0x0?0x1:0x0):(_0x17e733=_0x338c3d<0x0,_0x338c3d=Math['abs'](_0x338c3d),_0x338c3d>=Math['pow'](0x2,0x1-_0xeec7cf)?(_0x19b976=Math['min'](Math['floor'](Math['log'](_0x338c3d)/Math['LN2']),_0xeec7cf),_0xe44269=_0x19b976+_0xeec7cf,_0x7955af=Math['round'](_0x338c3d*Math['pow'](0x2,_0x299ebd-_0x19b976)-Math['pow'](0x2,_0x299ebd))):(_0xe44269=0x0,_0x7955af=Math['round'](_0x338c3d/Math['pow'](0x2,0x1-_0xeec7cf-_0x299ebd))));const _0x3f33fc=[];for(_0x3215de=_0x299ebd;_0x3215de;_0x3215de-=0x1)_0x3f33fc['push'](_0x7955af%0x2?0x1:0x0),_0x7955af=Math['floor'](_0x7955af/0x2);for(_0x3215de=_0x428f07;_0x3215de;_0x3215de-=0x1)_0x3f33fc['push'](_0xe44269%0x2?0x1:0x0),_0xe44269=Math['floor'](_0xe44269/0x2);_0x3f33fc['push'](_0x17e733?0x1:0x0),_0x3f33fc['reverse']();const _0x1962d6=_0x3f33fc['join']('');let _0x4b2084='';for(_0x3215de=0x0;_0x3215de<0x40;_0x3215de+=0x8){let _0x342110=parseInt(_0x1962d6['substr'](_0x3215de,0x8),0x2)['toString'](0x10);_0x342110['length']===0x1&&(_0x342110='0'+_0x342110),_0x4b2084=_0x4b2084+_0x342110;}return _0x4b2084['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x4930f2,_0x311fc6){let _0xaf260='Unknown\x20Error';_0x4930f2==='too_big'?_0xaf260='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4930f2==='permission_denied'?_0xaf260='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4930f2==='unavailable'&&(_0xaf260='The\x20service\x20is\x20unavailable');const _0x21cedb=new Error(_0x4930f2+'\x20at\x20'+_0x311fc6['_path']['toString']()+':\x20'+_0xaf260);return _0x21cedb['code']=_0x4930f2['toUpperCase'](),_0x21cedb;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x18b3ef){if(zl['test'](_0x18b3ef)){const _0xae4f7e=Number(_0x18b3ef);if(_0xae4f7e>=jl&&_0xae4f7e<=Kl)return _0xae4f7e;}return null;},lt=function(_0xcb1790){try{_0xcb1790();}catch(_0x2a076c){setTimeout(()=>{const _0x527a50=_0x2a076c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x527a50),_0x2a076c;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x5005b6,_0x343ad7){const _0x1fe9d5=setTimeout(_0x5005b6,_0x343ad7);return typeof _0x1fe9d5=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1fe9d5):typeof _0x1fe9d5=='object'&&_0x1fe9d5['unref']&&_0x1fe9d5['unref'](),_0x1fe9d5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x39b3ac,_0x12052e){this['appCheckProvider']=_0x12052e,this['appName']=_0x39b3ac['name'],H(_0x39b3ac)&&_0x39b3ac['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x39b3ac['settings']['appCheckToken']),this['appCheck']=_0x12052e==null?void 0x0:_0x12052e['getImmediate']({'optional':!0x0}),this['appCheck']||_0x12052e==null||_0x12052e['get']()['then'](_0x2da4de=>this['appCheck']=_0x2da4de);}['getToken'](_0x2c9aad){if(this['serverAppAppCheckToken']){if(_0x2c9aad)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x2c9aad):new Promise((_0x479809,_0x3cb658)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x2c9aad)['then'](_0x479809,_0x3cb658):_0x479809(null);},0x0);});}['addTokenChangeListener'](_0x30516a){var _0x466365;(_0x466365=this['appCheckProvider'])==null||_0x466365['get']()['then'](_0x30167a=>_0x30167a['addTokenListener'](_0x30516a));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x28e215,_0x4be4e7,_0x45c6e7){this['appName_']=_0x28e215,this['firebaseOptions_']=_0x4be4e7,this['authProvider_']=_0x45c6e7,this['auth_']=null,this['auth_']=_0x45c6e7['getImmediate']({'optional':!0x0}),this['auth_']||_0x45c6e7['onInit'](_0x1431d9=>this['auth_']=_0x1431d9);}['getToken'](_0xbdd480){return this['auth_']?this['auth_']['getToken'](_0xbdd480)['catch'](_0xaaed2a=>_0xaaed2a&&_0xaaed2a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xaaed2a)):new Promise((_0x38a6f7,_0x568825)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xbdd480)['then'](_0x38a6f7,_0x568825):_0x38a6f7(null);},0x0);});}['addTokenChangeListener'](_0x30ba33){this['auth_']?this['auth_']['addAuthTokenListener'](_0x30ba33):this['authProvider_']['get']()['then'](_0x172f53=>_0x172f53['addAuthTokenListener'](_0x30ba33));}['removeTokenChangeListener'](_0x2802ba){this['authProvider_']['get']()['then'](_0x4f8341=>_0x4f8341['removeAuthTokenListener'](_0x2802ba));}['notifyForInvalidToken'](){let _0x2c8975='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x2c8975+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x2c8975+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x2c8975+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x2c8975);}}class tn{constructor(_0x1a4a49){this['accessToken']=_0x1a4a49;}['getToken'](_0xbd6677){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2d040f){_0x2d040f(this['accessToken']);}['removeTokenChangeListener'](_0x4002bb){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x3b2846,_0x42908a,_0x42d444,_0x5a19d1,_0x553c28=!0x1,_0x2f0f50='',_0x545dda=!0x1,_0x1443d6=!0x1,_0x43114b=null){this['secure']=_0x42908a,this['namespace']=_0x42d444,this['webSocketOnly']=_0x5a19d1,this['nodeAdmin']=_0x553c28,this['persistenceKey']=_0x2f0f50,this['includeNamespaceInQueryParams']=_0x545dda,this['isUsingEmulator']=_0x1443d6,this['emulatorOptions']=_0x43114b,this['_host']=_0x3b2846['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x3b2846)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x487689){_0x487689!==this['internalHost']&&(this['internalHost']=_0x487689,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1b4d0e=this['toURLString']();return this['persistenceKey']&&(_0x1b4d0e+='<'+this['persistenceKey']+'>'),_0x1b4d0e;}['toURLString'](){const _0x2af54a=this['secure']?'https://':'http://',_0x4409c4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2af54a+this['host']+'/'+_0x4409c4;}}function Xl(_0x3d1b38){return _0x3d1b38['host']!==_0x3d1b38['internalHost']||_0x3d1b38['isCustomHost']()||_0x3d1b38['includeNamespaceInQueryParams'];}function go(_0x431627,_0x5a3efb,_0x4f1bc4){f(typeof _0x5a3efb=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4f1bc4=='object','typeof\x20params\x20must\x20==\x20object');let _0x20c3df;if(_0x5a3efb===fo)_0x20c3df=(_0x431627['secure']?'wss://':'ws://')+_0x431627['internalHost']+'/.ws?';else{if(_0x5a3efb===po)_0x20c3df=(_0x431627['secure']?'https://':'http://')+_0x431627['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5a3efb);}Xl(_0x431627)&&(_0x4f1bc4['ns']=_0x431627['namespace']);const _0x17dfda=[];return x(_0x4f1bc4,(_0xbc5f84,_0x34f8e1)=>{_0x17dfda['push'](_0xbc5f84+'='+_0x34f8e1);}),_0x20c3df+_0x17dfda['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x3a11c7,_0x55b3ee=0x1){Y(this['counters_'],_0x3a11c7)||(this['counters_'][_0x3a11c7]=0x0),this['counters_'][_0x3a11c7]+=_0x55b3ee;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x246d90){const _0x43ba73=_0x246d90['toString']();return ti[_0x43ba73]||(ti[_0x43ba73]=new Zl()),ti[_0x43ba73];}function eh(_0x4bfc99,_0x37886e){const _0x287704=_0x4bfc99['toString']();return ni[_0x287704]||(ni[_0x287704]=_0x37886e()),ni[_0x287704];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0x398937){this['onMessage_']=_0x398937,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x329992,_0x203c4e){this['closeAfterResponse']=_0x329992,this['onClose']=_0x203c4e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2248a2,_0x113f2d){for(this['pendingResponses'][_0x2248a2]=_0x113f2d;this['pendingResponses'][this['currentResponseNum']];){const _0x4e9181=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4bea86=0x0;_0x4bea86<_0x4e9181['length'];++_0x4bea86)_0x4e9181[_0x4bea86]&&lt(()=>{this['onMessage_'](_0x4e9181[_0x4bea86]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x2fb1e8,_0x3d5e74,_0x5dd9fc,_0x39650f,_0x467ad7,_0x11ec29,_0x28a7f7){this['connId']=_0x2fb1e8,this['repoInfo']=_0x3d5e74,this['applicationId']=_0x5dd9fc,this['appCheckToken']=_0x39650f,this['authToken']=_0x467ad7,this['transportSessionId']=_0x11ec29,this['lastSessionId']=_0x28a7f7,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x2fb1e8),this['stats_']=Hi(_0x3d5e74),this['urlFn']=_0x16ea0b=>(this['appCheckToken']&&(_0x16ea0b[yi]=this['appCheckToken']),go(_0x3d5e74,po,_0x16ea0b));}['open'](_0x4f39ae,_0x27ccdb){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x27ccdb,this['myPacketOrderer']=new th(_0x4f39ae),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x5dbdbc)=>{const [_0x480d2e,_0x5b62b0,_0x594cb8,_0x3ebf8f,_0x1c8460]=_0x5dbdbc;if(this['incrementIncomingBytes_'](_0x5dbdbc),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x480d2e===$s)this['id']=_0x5b62b0,this['password']=_0x594cb8;else{if(_0x480d2e===nh)_0x5b62b0?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5b62b0,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x480d2e);}}},(..._0x3de021)=>{const [_0x397a30,_0x204ac0]=_0x3de021;this['incrementIncomingBytes_'](_0x3de021),this['myPacketOrderer']['handleResponse'](_0x397a30,_0x204ac0);},()=>{this['onClosed_']();},this['urlFn']);const _0x3cf176={};_0x3cf176[$s]='t',_0x3cf176[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3cf176[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3cf176[ro]=Vi,this['transportSessionId']&&(_0x3cf176[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x3cf176[ho]=this['lastSessionId']),this['applicationId']&&(_0x3cf176[uo]=this['applicationId']),this['appCheckToken']&&(_0x3cf176[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x3cf176[ao]=co);const _0x29f30a=this['urlFn'](_0x3cf176);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x29f30a),this['scriptTagHolder']['addTag'](_0x29f30a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x116974){const _0x1484fa=O(_0x116974);this['bytesSent']+=_0x1484fa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1484fa['length']);const _0x22a7fb=Br(_0x1484fa),_0x3b5c89=io(_0x22a7fb,hh);for(let _0x2825e9=0x0;_0x2825e9<_0x3b5c89['length'];_0x2825e9++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3b5c89['length'],_0x3b5c89[_0x2825e9]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1a8309,_0x2855ed){this['myDisconnFrame']=document['createElement']('iframe');const _0x13b212={};_0x13b212[lh]='t',_0x13b212[mo]=_0x1a8309,_0x13b212[yo]=_0x2855ed,this['myDisconnFrame']['src']=this['urlFn'](_0x13b212),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x21c1ce){const _0x5a7931=O(_0x21c1ce)['length'];this['bytesReceived']+=_0x5a7931,this['stats_']['incrementCounter']('bytes_received',_0x5a7931);}}class $i{constructor(_0xba1855,_0x5d4bb3,_0x267d4e,_0x1fef43){this['onDisconnect']=_0x267d4e,this['urlFn']=_0x1fef43,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0xba1855,window[sh+this['uniqueCallbackIdentifier']]=_0x5d4bb3,this['myIFrame']=$i['createIFrame_']();let _0x2b06eb='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2b06eb='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4f85ef='<html><body>'+_0x2b06eb+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4f85ef),this['myIFrame']['doc']['close']();}catch(_0x497d64){L('frame\x20writing\x20exception'),_0x497d64['stack']&&L(_0x497d64['stack']),L(_0x497d64);}}}static['createIFrame_'](){const _0x2a34b2=document['createElement']('iframe');if(_0x2a34b2['style']['display']='none',document['body']){document['body']['appendChild'](_0x2a34b2);try{_0x2a34b2['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x156b4d=document['domain'];_0x2a34b2['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x156b4d+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2a34b2['contentDocument']?_0x2a34b2['doc']=_0x2a34b2['contentDocument']:_0x2a34b2['contentWindow']?_0x2a34b2['doc']=_0x2a34b2['contentWindow']['document']:_0x2a34b2['document']&&(_0x2a34b2['doc']=_0x2a34b2['document']),_0x2a34b2;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x212782=this['onDisconnect'];_0x212782&&(this['onDisconnect']=null,_0x212782());}['startLongPoll'](_0x37c797,_0x1a028e){for(this['myID']=_0x37c797,this['myPW']=_0x1a028e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x392f40={};_0x392f40[mo]=this['myID'],_0x392f40[yo]=this['myPW'],_0x392f40[vo]=this['currentSerial'];let _0x21d868=this['urlFn'](_0x392f40),_0x90c7b0='',_0x143387=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x90c7b0['length']<=Eo;){const _0x3ce3dc=this['pendingSegs']['shift']();_0x90c7b0=_0x90c7b0+'&'+oh+_0x143387+'='+_0x3ce3dc['seg']+'&'+ah+_0x143387+'='+_0x3ce3dc['ts']+'&'+ch+_0x143387+'='+_0x3ce3dc['d'],_0x143387++;}return _0x21d868=_0x21d868+_0x90c7b0,this['addLongPollTag_'](_0x21d868,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3f7168,_0x20da9c,_0x448066){this['pendingSegs']['push']({'seg':_0x3f7168,'ts':_0x20da9c,'d':_0x448066}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2ae6ca,_0x3a7ac0){this['outstandingRequests']['add'](_0x3a7ac0);const _0x2af739=()=>{this['outstandingRequests']['delete'](_0x3a7ac0),this['newRequest_']();},_0x45d8b1=setTimeout(_0x2af739,Math['floor'](uh)),_0x2904e4=()=>{clearTimeout(_0x45d8b1),_0x2af739();};this['addTag'](_0x2ae6ca,_0x2904e4);}['addTag'](_0x37c78d,_0x376629){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x39804c=this['myIFrame']['doc']['createElement']('script');_0x39804c['type']='text/javascript',_0x39804c['async']=!0x0,_0x39804c['src']=_0x37c78d,_0x39804c['onload']=_0x39804c['onreadystatechange']=function(){const _0x4f0117=_0x39804c['readyState'];(!_0x4f0117||_0x4f0117==='loaded'||_0x4f0117==='complete')&&(_0x39804c['onload']=_0x39804c['onreadystatechange']=null,_0x39804c['parentNode']&&_0x39804c['parentNode']['removeChild'](_0x39804c),_0x376629());},_0x39804c['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x37c78d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x39804c);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x5e1e1d,_0x32f4f0,_0x434a56,_0x324698,_0xd43e28,_0x56ffb1,_0x36efca){this['connId']=_0x5e1e1d,this['applicationId']=_0x434a56,this['appCheckToken']=_0x324698,this['authToken']=_0xd43e28,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x32f4f0),this['connURL']=G['connectionURL_'](_0x32f4f0,_0x56ffb1,_0x36efca,_0x324698,_0x434a56),this['nodeAdmin']=_0x32f4f0['nodeAdmin'];}static['connectionURL_'](_0x20803d,_0x3e58ed,_0x21ce20,_0x981870,_0xe49f6e){const _0xd2cda7={};return _0xd2cda7[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0xd2cda7[ao]=co),_0x3e58ed&&(_0xd2cda7[oo]=_0x3e58ed),_0x21ce20&&(_0xd2cda7[ho]=_0x21ce20),_0x981870&&(_0xd2cda7[yi]=_0x981870),_0xe49f6e&&(_0xd2cda7[uo]=_0xe49f6e),go(_0x20803d,fo,_0xd2cda7);}['open'](_0x2a5223,_0x1704e6){this['onDisconnect']=_0x1704e6,this['onMessage']=_0x2a5223,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x34792c;dc(),this['mySock']=new hn(this['connURL'],[],_0x34792c);}catch(_0x1e42cc){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x55fc6d=_0x1e42cc['message']||_0x1e42cc['data'];_0x55fc6d&&this['log_'](_0x55fc6d),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x550d86=>{this['handleIncomingFrame'](_0x550d86);},this['mySock']['onerror']=_0x4a254d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2aaa81=_0x4a254d['message']||_0x4a254d['data'];_0x2aaa81&&this['log_'](_0x2aaa81),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2a2371=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2a084f=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x14e0ee=navigator['userAgent']['match'](_0x2a084f);_0x14e0ee&&_0x14e0ee['length']>0x1&&parseFloat(_0x14e0ee[0x1])<4.4&&(_0x2a2371=!0x0);}return!_0x2a2371&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x5f2f60){if(this['frames']['push'](_0x5f2f60),this['frames']['length']===this['totalFrames']){const _0x2f965f=this['frames']['join']('');this['frames']=null;const _0x26ce87=bt(_0x2f965f);this['onMessage'](_0x26ce87);}}['handleNewFrameCount_'](_0x3b6be4){this['totalFrames']=_0x3b6be4,this['frames']=[];}['extractFrameCount_'](_0x222e40){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x222e40['length']<=0x6){const _0x30634f=Number(_0x222e40);if(!isNaN(_0x30634f))return this['handleNewFrameCount_'](_0x30634f),null;}return this['handleNewFrameCount_'](0x1),_0x222e40;}['handleIncomingFrame'](_0xe899ff){if(this['mySock']===null)return;const _0x3d186e=_0xe899ff['data'];if(this['bytesReceived']+=_0x3d186e['length'],this['stats_']['incrementCounter']('bytes_received',_0x3d186e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3d186e);else{const _0x753c96=this['extractFrameCount_'](_0x3d186e);_0x753c96!==null&&this['appendFrame_'](_0x753c96);}}['send'](_0x3e90b0){this['resetKeepAlive']();const _0x3bf405=O(_0x3e90b0);this['bytesSent']+=_0x3bf405['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3bf405['length']);const _0x5cda29=io(_0x3bf405,fh);_0x5cda29['length']>0x1&&this['sendString_'](String(_0x5cda29['length']));for(let _0x503a15=0x0;_0x503a15<_0x5cda29['length'];_0x503a15++)this['sendString_'](_0x5cda29[_0x503a15]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x20084c){try{this['mySock']['send'](_0x20084c);}catch(_0x285cff){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x285cff['message']||_0x285cff['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x122e61){this['initTransports_'](_0x122e61);}['initTransports_'](_0x2c49d6){const _0x571712=G&&G['isAvailable']();let _0x45df1f=_0x571712&&!G['previouslyFailed']();if(_0x2c49d6['webSocketOnly']&&(_0x571712||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x45df1f=!0x0),_0x45df1f)this['transports_']=[G];else{const _0xaa0d76=this['transports_']=[];for(const _0x2c9999 of At['ALL_TRANSPORTS'])_0x2c9999&&_0x2c9999['isAvailable']()&&_0xaa0d76['push'](_0x2c9999);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0x521acd,_0x21cf36,_0x4837d1,_0x5e9642,_0x51b4a1,_0x26279c,_0xcf1c06,_0xf0ee7b,_0xbfd3a3,_0x3dd433){this['id']=_0x521acd,this['repoInfo_']=_0x21cf36,this['applicationId_']=_0x4837d1,this['appCheckToken_']=_0x5e9642,this['authToken_']=_0x51b4a1,this['onMessage_']=_0x26279c,this['onReady_']=_0xcf1c06,this['onDisconnect_']=_0xf0ee7b,this['onKill_']=_0xbfd3a3,this['lastSessionId']=_0x3dd433,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x21cf36),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x321fd8=this['transportManager_']['initialTransport']();this['conn_']=new _0x321fd8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x321fd8['responsesRequiredToBeHealthy']||0x0;const _0x56b42b=this['connReceiver_'](this['conn_']),_0x330e90=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x56b42b,_0x330e90);},Math['floor'](0x0));const _0x39e431=_0x321fd8['healthyTimeout']||0x0;_0x39e431>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x39e431)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1cdfd2){return _0x3f5352=>{_0x1cdfd2===this['conn_']?this['onConnectionLost_'](_0x3f5352):_0x1cdfd2===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x227621){return _0x237150=>{this['state_']!==0x2&&(_0x227621===this['rx_']?this['onPrimaryMessageReceived_'](_0x237150):_0x227621===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x237150):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4d9bfe){const _0x5b055b={'t':'d','d':_0x4d9bfe};this['sendData_'](_0x5b055b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x55eb37){if(ii in _0x55eb37){const _0x440480=_0x55eb37[ii];_0x440480===js?this['upgradeIfSecondaryHealthy_']():_0x440480===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x440480===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1da6c5){const _0x548b0f=pt('t',_0x1da6c5),_0x2f8966=pt('d',_0x1da6c5);if(_0x548b0f==='c')this['onSecondaryControl_'](_0x2f8966);else{if(_0x548b0f==='d')this['pendingDataMessages']['push'](_0x2f8966);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x548b0f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x451cff){const _0x54eac9=pt('t',_0x451cff),_0x471849=pt('d',_0x451cff);_0x54eac9==='c'?this['onControl_'](_0x471849):_0x54eac9==='d'&&this['onDataMessage_'](_0x471849);}['onDataMessage_'](_0xc4ab6c){this['onPrimaryResponse_'](),this['onMessage_'](_0xc4ab6c);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x210f82){const _0x2ebfad=pt(ii,_0x210f82);if(Gs in _0x210f82){const _0x4ae874=_0x210f82[Gs];if(_0x2ebfad===Ih){const _0x189cdf={..._0x4ae874};this['repoInfo_']['isUsingEmulator']&&(_0x189cdf['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x189cdf);}else{if(_0x2ebfad===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x45cca0=0x0;_0x45cca0<this['pendingDataMessages']['length'];++_0x45cca0)this['onDataMessage_'](this['pendingDataMessages'][_0x45cca0]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2ebfad===vh?this['onConnectionShutdown_'](_0x4ae874):_0x2ebfad===qs?this['onReset_'](_0x4ae874):_0x2ebfad===Eh?mi('Server\x20Error:\x20'+_0x4ae874):_0x2ebfad===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x2ebfad);}}}['onHandshake_'](_0x23e4e2){const _0x235781=_0x23e4e2['ts'],_0x50b42a=_0x23e4e2['v'],_0x38709d=_0x23e4e2['h'];this['sessionId']=_0x23e4e2['s'],this['repoInfo_']['host']=_0x38709d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x235781),Vi!==_0x50b42a&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x153e8d=this['transportManager_']['upgradeTransport']();_0x153e8d&&this['startUpgrade_'](_0x153e8d);}['startUpgrade_'](_0x589285){this['secondaryConn_']=new _0x589285(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x589285['responsesRequiredToBeHealthy']||0x0;const _0x92b476=this['connReceiver_'](this['secondaryConn_']),_0x951d99=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x92b476,_0x951d99),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x26fe25){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x26fe25),this['repoInfo_']['host']=_0x26fe25,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1ee3f2,_0x4d585c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1ee3f2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4d585c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2f8a42=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2f8a42||this['rx_']===_0x2f8a42)&&this['close']();}['onConnectionLost_'](_0xcf7400){this['conn_']=null,!_0xcf7400&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x32c3a7){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x32c3a7),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5b3436){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5b3436);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x1389e2,_0x30e24a,_0x28468f,_0x194c9a){}['merge'](_0x2c0d45,_0x112110,_0x22107d,_0x38b6a7){}['refreshAuthToken'](_0x1a85c4){}['refreshAppCheckToken'](_0x41fc7d){}['onDisconnectPut'](_0x8f4fc7,_0x1bd101,_0x475073){}['onDisconnectMerge'](_0xfdc630,_0x3495b3,_0x1ea775){}['onDisconnectCancel'](_0x4e0747,_0x3c2756){}['reportStats'](_0x7586a3){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x532ef1){this['allowedEvents_']=_0x532ef1,this['listeners_']={},f(Array['isArray'](_0x532ef1)&&_0x532ef1['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2bc5b5,..._0x4b3c33){if(Array['isArray'](this['listeners_'][_0x2bc5b5])){const _0x2edb5d=[...this['listeners_'][_0x2bc5b5]];for(let _0x2dd4c7=0x0;_0x2dd4c7<_0x2edb5d['length'];_0x2dd4c7++)_0x2edb5d[_0x2dd4c7]['callback']['apply'](_0x2edb5d[_0x2dd4c7]['context'],_0x4b3c33);}}['on'](_0x162acb,_0x2c0a78,_0x2dede3){this['validateEventType_'](_0x162acb),this['listeners_'][_0x162acb]=this['listeners_'][_0x162acb]||[],this['listeners_'][_0x162acb]['push']({'callback':_0x2c0a78,'context':_0x2dede3});const _0x4a9708=this['getInitialEvent'](_0x162acb);_0x4a9708&&_0x2c0a78['apply'](_0x2dede3,_0x4a9708);}['off'](_0x494f06,_0x32d2b1,_0x25904b){this['validateEventType_'](_0x494f06);const _0x54b3b4=this['listeners_'][_0x494f06]||[];for(let _0x248d64=0x0;_0x248d64<_0x54b3b4['length'];_0x248d64++)if(_0x54b3b4[_0x248d64]['callback']===_0x32d2b1&&(!_0x25904b||_0x25904b===_0x54b3b4[_0x248d64]['context'])){_0x54b3b4['splice'](_0x248d64,0x1);return;}}['validateEventType_'](_0x52cc65){f(this['allowedEvents_']['find'](_0x344950=>_0x344950===_0x52cc65),'Unknown\x20event:\x20'+_0x52cc65);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x50b8d3){return f(_0x50b8d3==='online','Unknown\x20event\x20type:\x20'+_0x50b8d3),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x52bd00,_0x1bf0e3){if(_0x1bf0e3===void 0x0){this['pieces_']=_0x52bd00['split']('/');let _0x3a00d8=0x0;for(let _0x105194=0x0;_0x105194<this['pieces_']['length'];_0x105194++)this['pieces_'][_0x105194]['length']>0x0&&(this['pieces_'][_0x3a00d8]=this['pieces_'][_0x105194],_0x3a00d8++);this['pieces_']['length']=_0x3a00d8,this['pieceNum_']=0x0;}else this['pieces_']=_0x52bd00,this['pieceNum_']=_0x1bf0e3;}['toString'](){let _0x110d68='';for(let _0x1499bc=this['pieceNum_'];_0x1499bc<this['pieces_']['length'];_0x1499bc++)this['pieces_'][_0x1499bc]!==''&&(_0x110d68+='/'+this['pieces_'][_0x1499bc]);return _0x110d68||'/';}}function w(){return new C('');}function y(_0x18e891){return _0x18e891['pieceNum_']>=_0x18e891['pieces_']['length']?null:_0x18e891['pieces_'][_0x18e891['pieceNum_']];}function we(_0x4b2c3d){return _0x4b2c3d['pieces_']['length']-_0x4b2c3d['pieceNum_'];}function b(_0x7d1390){let _0x393411=_0x7d1390['pieceNum_'];return _0x393411<_0x7d1390['pieces_']['length']&&_0x393411++,new C(_0x7d1390['pieces_'],_0x393411);}function Gi(_0xf8b8e4){return _0xf8b8e4['pieceNum_']<_0xf8b8e4['pieces_']['length']?_0xf8b8e4['pieces_'][_0xf8b8e4['pieces_']['length']-0x1]:null;}function Ch(_0x5c9889){let _0x55bad7='';for(let _0x5b3139=_0x5c9889['pieceNum_'];_0x5b3139<_0x5c9889['pieces_']['length'];_0x5b3139++)_0x5c9889['pieces_'][_0x5b3139]!==''&&(_0x55bad7+='/'+encodeURIComponent(String(_0x5c9889['pieces_'][_0x5b3139])));return _0x55bad7||'/';}function kt(_0x577a9a,_0x3e60d8=0x0){return _0x577a9a['pieces_']['slice'](_0x577a9a['pieceNum_']+_0x3e60d8);}function To(_0x1b88e8){if(_0x1b88e8['pieceNum_']>=_0x1b88e8['pieces_']['length'])return null;const _0xe760e1=[];for(let _0x1e0a5e=_0x1b88e8['pieceNum_'];_0x1e0a5e<_0x1b88e8['pieces_']['length']-0x1;_0x1e0a5e++)_0xe760e1['push'](_0x1b88e8['pieces_'][_0x1e0a5e]);return new C(_0xe760e1,0x0);}function A(_0x24904a,_0x99cffa){const _0x3b5217=[];for(let _0x5e19fc=_0x24904a['pieceNum_'];_0x5e19fc<_0x24904a['pieces_']['length'];_0x5e19fc++)_0x3b5217['push'](_0x24904a['pieces_'][_0x5e19fc]);if(_0x99cffa instanceof C){for(let _0x1eae50=_0x99cffa['pieceNum_'];_0x1eae50<_0x99cffa['pieces_']['length'];_0x1eae50++)_0x3b5217['push'](_0x99cffa['pieces_'][_0x1eae50]);}else{const _0x34f191=_0x99cffa['split']('/');for(let _0x39a09b=0x0;_0x39a09b<_0x34f191['length'];_0x39a09b++)_0x34f191[_0x39a09b]['length']>0x0&&_0x3b5217['push'](_0x34f191[_0x39a09b]);}return new C(_0x3b5217,0x0);}function v(_0x26a857){return _0x26a857['pieceNum_']>=_0x26a857['pieces_']['length'];}function F(_0x24465d,_0x179a25){const _0x3e8d2b=y(_0x24465d),_0x1c7ce0=y(_0x179a25);if(_0x3e8d2b===null)return _0x179a25;if(_0x3e8d2b===_0x1c7ce0)return F(b(_0x24465d),b(_0x179a25));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x179a25+')\x20is\x20not\x20within\x20outerPath\x20('+_0x24465d+')');}function Th(_0x17a3dc,_0x47befc){const _0x3cd918=kt(_0x17a3dc,0x0),_0x2ed7b8=kt(_0x47befc,0x0);for(let _0x150d5f=0x0;_0x150d5f<_0x3cd918['length']&&_0x150d5f<_0x2ed7b8['length'];_0x150d5f++){const _0x4572c3=He(_0x3cd918[_0x150d5f],_0x2ed7b8[_0x150d5f]);if(_0x4572c3!==0x0)return _0x4572c3;}return _0x3cd918['length']===_0x2ed7b8['length']?0x0:_0x3cd918['length']<_0x2ed7b8['length']?-0x1:0x1;}function qi(_0x5db279,_0x3c30fa){if(we(_0x5db279)!==we(_0x3c30fa))return!0x1;for(let _0x455d85=_0x5db279['pieceNum_'],_0x590c7d=_0x3c30fa['pieceNum_'];_0x455d85<=_0x5db279['pieces_']['length'];_0x455d85++,_0x590c7d++)if(_0x5db279['pieces_'][_0x455d85]!==_0x3c30fa['pieces_'][_0x590c7d])return!0x1;return!0x0;}function $(_0x1e7761,_0x4483b1){let _0x45abb7=_0x1e7761['pieceNum_'],_0x14cfd3=_0x4483b1['pieceNum_'];if(we(_0x1e7761)>we(_0x4483b1))return!0x1;for(;_0x45abb7<_0x1e7761['pieces_']['length'];){if(_0x1e7761['pieces_'][_0x45abb7]!==_0x4483b1['pieces_'][_0x14cfd3])return!0x1;++_0x45abb7,++_0x14cfd3;}return!0x0;}class Sh{constructor(_0xcd9bbf,_0x13b180){this['errorPrefix_']=_0x13b180,this['parts_']=kt(_0xcd9bbf,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1734b1=0x0;_0x1734b1<this['parts_']['length'];_0x1734b1++)this['byteLength_']+=Pn(this['parts_'][_0x1734b1]);So(this);}}function bh(_0x1717c4,_0x218d9d){_0x1717c4['parts_']['length']>0x0&&(_0x1717c4['byteLength_']+=0x1),_0x1717c4['parts_']['push'](_0x218d9d),_0x1717c4['byteLength_']+=Pn(_0x218d9d),So(_0x1717c4);}function Rh(_0x165b98){const _0x4f8228=_0x165b98['parts_']['pop']();_0x165b98['byteLength_']-=Pn(_0x4f8228),_0x165b98['parts_']['length']>0x0&&(_0x165b98['byteLength_']-=0x1);}function So(_0xb71fd2){if(_0xb71fd2['byteLength_']>Js)throw new Error(_0xb71fd2['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0xb71fd2['byteLength_']+').');if(_0xb71fd2['parts_']['length']>Qs)throw new Error(_0xb71fd2['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0xb71fd2));}function Ne(_0xa6b9ed){return _0xa6b9ed['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xa6b9ed['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x1c626c,_0x3a5cdf;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3a5cdf='visibilitychange',_0x1c626c='hidden'):typeof document['mozHidden']<'u'?(_0x3a5cdf='mozvisibilitychange',_0x1c626c='mozHidden'):typeof document['msHidden']<'u'?(_0x3a5cdf='msvisibilitychange',_0x1c626c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3a5cdf='webkitvisibilitychange',_0x1c626c='webkitHidden')),this['visible_']=!0x0,_0x3a5cdf&&document['addEventListener'](_0x3a5cdf,()=>{const _0x275f1d=!document[_0x1c626c];_0x275f1d!==this['visible_']&&(this['visible_']=_0x275f1d,this['trigger']('visible',_0x275f1d));},!0x1);}['getInitialEvent'](_0xf3a1dd){return f(_0xf3a1dd==='visible','Unknown\x20event\x20type:\x20'+_0xf3a1dd),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x24a038,_0x1e8550,_0x39607d,_0x51de4f,_0x446642,_0x4b23a0,_0x37515c,_0x52bb13){if(super(),this['repoInfo_']=_0x24a038,this['applicationId_']=_0x1e8550,this['onDataUpdate_']=_0x39607d,this['onConnectStatus_']=_0x51de4f,this['onServerInfoUpdate_']=_0x446642,this['authTokenProvider_']=_0x4b23a0,this['appCheckTokenProvider_']=_0x37515c,this['authOverride_']=_0x52bb13,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x52bb13)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x24a038['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0xf52dd5,_0xcf689b,_0x19f2a0){const _0x49c51d=++this['requestNumber_'],_0xdbe7fc={'r':_0x49c51d,'a':_0xf52dd5,'b':_0xcf689b};this['log_'](O(_0xdbe7fc)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xdbe7fc),_0x19f2a0&&(this['requestCBHash_'][_0x49c51d]=_0x19f2a0);}['get'](_0xb6d54b){this['initConnection_']();const _0x1095c9=new Ve(),_0xfb8777={'action':'g','request':{'p':_0xb6d54b['_path']['toString'](),'q':_0xb6d54b['_queryObject']},'onComplete':_0x30288a=>{const _0x537023=_0x30288a['d'];_0x30288a['s']==='ok'?_0x1095c9['resolve'](_0x537023):_0x1095c9['reject'](_0x537023);}};this['outstandingGets_']['push'](_0xfb8777),this['outstandingGetCount_']++;const _0x5b4c69=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x5b4c69),_0x1095c9['promise'];}['listen'](_0x880bcf,_0x23b18c,_0xfeb0a1,_0x3d78df){this['initConnection_']();const _0x4c7824=_0x880bcf['_queryIdentifier'],_0x23c7ef=_0x880bcf['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x23c7ef+'\x20'+_0x4c7824),this['listens']['has'](_0x23c7ef)||this['listens']['set'](_0x23c7ef,new Map()),f(_0x880bcf['_queryParams']['isDefault']()||!_0x880bcf['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x23c7ef)['has'](_0x4c7824),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x39bb5f={'onComplete':_0x3d78df,'hashFn':_0x23b18c,'query':_0x880bcf,'tag':_0xfeb0a1};this['listens']['get'](_0x23c7ef)['set'](_0x4c7824,_0x39bb5f),this['connected_']&&this['sendListen_'](_0x39bb5f);}['sendGet_'](_0x1337bd){const _0x25e41f=this['outstandingGets_'][_0x1337bd];this['sendRequest']('g',_0x25e41f['request'],_0x5e93f0=>{delete this['outstandingGets_'][_0x1337bd],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x25e41f['onComplete']&&_0x25e41f['onComplete'](_0x5e93f0);});}['sendListen_'](_0x3a1caa){const _0x47edf8=_0x3a1caa['query'],_0x5ec7a3=_0x47edf8['_path']['toString'](),_0x3976fa=_0x47edf8['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5ec7a3+'\x20for\x20'+_0x3976fa);const _0x1b1f4d={'p':_0x5ec7a3},_0x4f25b9='q';_0x3a1caa['tag']&&(_0x1b1f4d['q']=_0x47edf8['_queryObject'],_0x1b1f4d['t']=_0x3a1caa['tag']),_0x1b1f4d['h']=_0x3a1caa['hashFn'](),this['sendRequest'](_0x4f25b9,_0x1b1f4d,_0x40b1f5=>{const _0x56cf42=_0x40b1f5['d'],_0x59a140=_0x40b1f5['s'];ie['warnOnListenWarnings_'](_0x56cf42,_0x47edf8),(this['listens']['get'](_0x5ec7a3)&&this['listens']['get'](_0x5ec7a3)['get'](_0x3976fa))===_0x3a1caa&&(this['log_']('listen\x20response',_0x40b1f5),_0x59a140!=='ok'&&this['removeListen_'](_0x5ec7a3,_0x3976fa),_0x3a1caa['onComplete']&&_0x3a1caa['onComplete'](_0x59a140,_0x56cf42));});}static['warnOnListenWarnings_'](_0x11efb8,_0x2e62fc){if(_0x11efb8&&typeof _0x11efb8=='object'&&Y(_0x11efb8,'w')){const _0x190fec=Oe(_0x11efb8,'w');if(Array['isArray'](_0x190fec)&&~_0x190fec['indexOf']('no_index')){const _0x1c742b='\x22.indexOn\x22:\x20\x22'+_0x2e62fc['_queryParams']['getIndex']()['toString']()+'\x22',_0x501475=_0x2e62fc['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1c742b+'\x20at\x20'+_0x501475+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2e4cc6){this['authToken_']=_0x2e4cc6,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2e4cc6);}['reduceReconnectDelayIfAdminCredential_'](_0x3666bd){(_0x3666bd&&_0x3666bd['length']===0x28||vc(_0x3666bd))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x23cafc){this['appCheckToken_']=_0x23cafc,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3e5b91=this['authToken_'],_0x34d72f=yc(_0x3e5b91)?'auth':'gauth',_0x55eca2={'cred':_0x3e5b91};this['authOverride_']===null?_0x55eca2['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x55eca2['authvar']=this['authOverride_']),this['sendRequest'](_0x34d72f,_0x55eca2,_0x1a33ef=>{const _0x92f19f=_0x1a33ef['s'],_0x5e19a6=_0x1a33ef['d']||'error';this['authToken_']===_0x3e5b91&&(_0x92f19f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x92f19f,_0x5e19a6));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x28524d=>{const _0x3f6a88=_0x28524d['s'],_0x5a4c33=_0x28524d['d']||'error';_0x3f6a88==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x3f6a88,_0x5a4c33);});}['unlisten'](_0x4c5fcd,_0xc29842){const _0x3ec015=_0x4c5fcd['_path']['toString'](),_0x1c424b=_0x4c5fcd['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3ec015+'\x20'+_0x1c424b),f(_0x4c5fcd['_queryParams']['isDefault']()||!_0x4c5fcd['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3ec015,_0x1c424b)&&this['connected_']&&this['sendUnlisten_'](_0x3ec015,_0x1c424b,_0x4c5fcd['_queryObject'],_0xc29842);}['sendUnlisten_'](_0x5c8815,_0x1ba115,_0x34b85c,_0x312827){this['log_']('Unlisten\x20on\x20'+_0x5c8815+'\x20for\x20'+_0x1ba115);const _0x10cfca={'p':_0x5c8815},_0x3de9d8='n';_0x312827&&(_0x10cfca['q']=_0x34b85c,_0x10cfca['t']=_0x312827),this['sendRequest'](_0x3de9d8,_0x10cfca);}['onDisconnectPut'](_0x5694f5,_0x186e41,_0x27a16d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x5694f5,_0x186e41,_0x27a16d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5694f5,'action':'o','data':_0x186e41,'onComplete':_0x27a16d});}['onDisconnectMerge'](_0x148d54,_0x17fcbc,_0x490a4c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x148d54,_0x17fcbc,_0x490a4c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x148d54,'action':'om','data':_0x17fcbc,'onComplete':_0x490a4c});}['onDisconnectCancel'](_0x469f8d,_0x37b508){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x469f8d,null,_0x37b508):this['onDisconnectRequestQueue_']['push']({'pathString':_0x469f8d,'action':'oc','data':null,'onComplete':_0x37b508});}['sendOnDisconnect_'](_0x4320d0,_0x4059e7,_0x46c217,_0x1a5afd){const _0x305c52={'p':_0x4059e7,'d':_0x46c217};this['log_']('onDisconnect\x20'+_0x4320d0,_0x305c52),this['sendRequest'](_0x4320d0,_0x305c52,_0x3084c5=>{_0x1a5afd&&setTimeout(()=>{_0x1a5afd(_0x3084c5['s'],_0x3084c5['d']);},Math['floor'](0x0));});}['put'](_0x23189f,_0x4d9e30,_0xbb8bac,_0x13f799){this['putInternal']('p',_0x23189f,_0x4d9e30,_0xbb8bac,_0x13f799);}['merge'](_0x22b241,_0x1f5248,_0x301072,_0x89d875){this['putInternal']('m',_0x22b241,_0x1f5248,_0x301072,_0x89d875);}['putInternal'](_0x56a51f,_0x447f7b,_0x2a111b,_0x221905,_0x54c86e){this['initConnection_']();const _0x5a6d03={'p':_0x447f7b,'d':_0x2a111b};_0x54c86e!==void 0x0&&(_0x5a6d03['h']=_0x54c86e),this['outstandingPuts_']['push']({'action':_0x56a51f,'request':_0x5a6d03,'onComplete':_0x221905}),this['outstandingPutCount_']++;const _0xe98e35=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xe98e35):this['log_']('Buffering\x20put:\x20'+_0x447f7b);}['sendPut_'](_0x10081f){const _0x34f2a6=this['outstandingPuts_'][_0x10081f]['action'],_0xe68094=this['outstandingPuts_'][_0x10081f]['request'],_0x101ad6=this['outstandingPuts_'][_0x10081f]['onComplete'];this['outstandingPuts_'][_0x10081f]['queued']=this['connected_'],this['sendRequest'](_0x34f2a6,_0xe68094,_0x27da9f=>{this['log_'](_0x34f2a6+'\x20response',_0x27da9f),delete this['outstandingPuts_'][_0x10081f],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x101ad6&&_0x101ad6(_0x27da9f['s'],_0x27da9f['d']);});}['reportStats'](_0x91e58a){if(this['connected_']){const _0x5338f1={'c':_0x91e58a};this['log_']('reportStats',_0x5338f1),this['sendRequest']('s',_0x5338f1,_0x3d6357=>{if(_0x3d6357['s']!=='ok'){const _0x56b049=_0x3d6357['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x56b049);}});}}['onDataMessage_'](_0x5a86ed){if('r'in _0x5a86ed){this['log_']('from\x20server:\x20'+O(_0x5a86ed));const _0x9e2001=_0x5a86ed['r'],_0x1520c1=this['requestCBHash_'][_0x9e2001];_0x1520c1&&(delete this['requestCBHash_'][_0x9e2001],_0x1520c1(_0x5a86ed['b']));}else{if('error'in _0x5a86ed)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5a86ed['error'];'a'in _0x5a86ed&&this['onDataPush_'](_0x5a86ed['a'],_0x5a86ed['b']);}}['onDataPush_'](_0x390d87,_0x375d4e){this['log_']('handleServerMessage',_0x390d87,_0x375d4e),_0x390d87==='d'?this['onDataUpdate_'](_0x375d4e['p'],_0x375d4e['d'],!0x1,_0x375d4e['t']):_0x390d87==='m'?this['onDataUpdate_'](_0x375d4e['p'],_0x375d4e['d'],!0x0,_0x375d4e['t']):_0x390d87==='c'?this['onListenRevoked_'](_0x375d4e['p'],_0x375d4e['q']):_0x390d87==='ac'?this['onAuthRevoked_'](_0x375d4e['s'],_0x375d4e['d']):_0x390d87==='apc'?this['onAppCheckRevoked_'](_0x375d4e['s'],_0x375d4e['d']):_0x390d87==='sd'?this['onSecurityDebugPacket_'](_0x375d4e):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x390d87)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x38736f,_0x4bef9d){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x38736f),this['lastSessionId']=_0x4bef9d,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x59973f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x59973f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x1ef34e){_0x1ef34e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x1ef34e;}['onOnline_'](_0xeb2f8e){_0xeb2f8e?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5cc852=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x9b6338=Math['max'](0x0,this['reconnectDelay_']-_0x5cc852);_0x9b6338=Math['random']()*_0x9b6338,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x9b6338+'ms'),this['scheduleConnect_'](_0x9b6338),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x560860=this['onDataMessage_']['bind'](this),_0x1fbce2=this['onReady_']['bind'](this),_0x8943be=this['onRealtimeDisconnect_']['bind'](this),_0x240f0f=this['id']+':'+ie['nextConnectionId_']++,_0x34feeb=this['lastSessionId'];let _0x3a9980=!0x1,_0x1c470f=null;const _0x333f2e=function(){_0x1c470f?_0x1c470f['close']():(_0x3a9980=!0x0,_0x8943be());},_0x3c8999=function(_0x1bb5d5){f(_0x1c470f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1c470f['sendRequest'](_0x1bb5d5);};this['realtime_']={'close':_0x333f2e,'sendRequest':_0x3c8999};const _0x7e3c13=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x27c323,_0x358e48]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x7e3c13),this['appCheckTokenProvider_']['getToken'](_0x7e3c13)]);_0x3a9980?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x27c323&&_0x27c323['accessToken'],this['appCheckToken_']=_0x358e48&&_0x358e48['token'],_0x1c470f=new wh(_0x240f0f,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x560860,_0x1fbce2,_0x8943be,_0x390f82=>{U(_0x390f82+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x34feeb));}catch(_0x22431f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x22431f),_0x3a9980||(this['repoInfo_']['nodeAdmin']&&U(_0x22431f),_0x333f2e());}}}['interrupt'](_0xa69d61){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xa69d61),this['interruptReasons_'][_0xa69d61]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2ed96a){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2ed96a),delete this['interruptReasons_'][_0x2ed96a],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x48b0cc){const _0x4d09c0=_0x48b0cc-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4d09c0});}['cancelSentTransactions_'](){for(let _0x2249e6=0x0;_0x2249e6<this['outstandingPuts_']['length'];_0x2249e6++){const _0x33a82b=this['outstandingPuts_'][_0x2249e6];_0x33a82b&&'h'in _0x33a82b['request']&&_0x33a82b['queued']&&(_0x33a82b['onComplete']&&_0x33a82b['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2249e6],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3d8638,_0x494d2f){let _0x586828;_0x494d2f?_0x586828=_0x494d2f['map'](_0x426ce2=>Bi(_0x426ce2))['join']('$'):_0x586828='default';const _0x352e13=this['removeListen_'](_0x3d8638,_0x586828);_0x352e13&&_0x352e13['onComplete']&&_0x352e13['onComplete']('permission_denied');}['removeListen_'](_0x3ce678,_0x5635a1){const _0x38666d=new C(_0x3ce678)['toString']();let _0xe6d93c;if(this['listens']['has'](_0x38666d)){const _0x5a698c=this['listens']['get'](_0x38666d);_0xe6d93c=_0x5a698c['get'](_0x5635a1),_0x5a698c['delete'](_0x5635a1),_0x5a698c['size']===0x0&&this['listens']['delete'](_0x38666d);}else _0xe6d93c=void 0x0;return _0xe6d93c;}['onAuthRevoked_'](_0x1ea719,_0x532141){L('Auth\x20token\x20revoked:\x20'+_0x1ea719+'/'+_0x532141),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x1ea719==='invalid_token'||_0x1ea719==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x153535,_0x11493b){L('App\x20check\x20token\x20revoked:\x20'+_0x153535+'/'+_0x11493b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x153535==='invalid_token'||_0x153535==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3c1c45){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3c1c45):'msg'in _0x3c1c45&&console['log']('FIREBASE:\x20'+_0x3c1c45['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1f9319 of this['listens']['values']())for(const _0x482401 of _0x1f9319['values']())this['sendListen_'](_0x482401);for(let _0x11c1aa=0x0;_0x11c1aa<this['outstandingPuts_']['length'];_0x11c1aa++)this['outstandingPuts_'][_0x11c1aa]&&this['sendPut_'](_0x11c1aa);for(;this['onDisconnectRequestQueue_']['length'];){const _0x36360f=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x36360f['action'],_0x36360f['pathString'],_0x36360f['data'],_0x36360f['onComplete']);}for(let _0x4bfbbf=0x0;_0x4bfbbf<this['outstandingGets_']['length'];_0x4bfbbf++)this['outstandingGets_'][_0x4bfbbf]&&this['sendGet_'](_0x4bfbbf);}['sendConnectStats_'](){const _0x1c7f52={};let _0x278226='js';_0x1c7f52['sdk.'+_0x278226+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x1c7f52['framework.cordova']=0x1:qr()&&(_0x1c7f52['framework.reactnative']=0x1),this['reportStats'](_0x1c7f52);}['shouldReconnect_'](){const _0x238e8a=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x238e8a;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x2b0368,_0x7b0c39){this['name']=_0x2b0368,this['node']=_0x7b0c39;}static['Wrap'](_0x49e611,_0x48a239){return new E(_0x49e611,_0x48a239);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5b2647,_0x1d2fcf){const _0x5ac1f4=new E(xe,_0x5b2647),_0xfb694=new E(xe,_0x1d2fcf);return this['compare'](_0x5ac1f4,_0xfb694)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x34428c){Xt=_0x34428c;}['compare'](_0x576f38,_0xeac226){return He(_0x576f38['name'],_0xeac226['name']);}['isDefinedOn'](_0xda56d4){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x342851,_0x4e06fb){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0xae43cb,_0x15317d){return f(typeof _0xae43cb=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xae43cb,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x37353b,_0x133875,_0x3a4c32,_0x440367,_0x4c383b=null){this['isReverse_']=_0x440367,this['resultGenerator_']=_0x4c383b,this['nodeStack_']=[];let _0x20c6b3=0x1;for(;!_0x37353b['isEmpty']();)if(_0x37353b=_0x37353b,_0x20c6b3=_0x133875?_0x3a4c32(_0x37353b['key'],_0x133875):0x1,_0x440367&&(_0x20c6b3*=-0x1),_0x20c6b3<0x0)this['isReverse_']?_0x37353b=_0x37353b['left']:_0x37353b=_0x37353b['right'];else{if(_0x20c6b3===0x0){this['nodeStack_']['push'](_0x37353b);break;}else this['nodeStack_']['push'](_0x37353b),this['isReverse_']?_0x37353b=_0x37353b['right']:_0x37353b=_0x37353b['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5ccaea=this['nodeStack_']['pop'](),_0x22e098;if(this['resultGenerator_']?_0x22e098=this['resultGenerator_'](_0x5ccaea['key'],_0x5ccaea['value']):_0x22e098={'key':_0x5ccaea['key'],'value':_0x5ccaea['value']},this['isReverse_']){for(_0x5ccaea=_0x5ccaea['left'];!_0x5ccaea['isEmpty']();)this['nodeStack_']['push'](_0x5ccaea),_0x5ccaea=_0x5ccaea['right'];}else{for(_0x5ccaea=_0x5ccaea['right'];!_0x5ccaea['isEmpty']();)this['nodeStack_']['push'](_0x5ccaea),_0x5ccaea=_0x5ccaea['left'];}return _0x22e098;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4bb4ae=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4bb4ae['key'],_0x4bb4ae['value']):{'key':_0x4bb4ae['key'],'value':_0x4bb4ae['value']};}}class M{constructor(_0x3982c1,_0x4a38a3,_0x514dfc,_0x5b5037,_0xc0d4cf){this['key']=_0x3982c1,this['value']=_0x4a38a3,this['color']=_0x514dfc??M['RED'],this['left']=_0x5b5037??B['EMPTY_NODE'],this['right']=_0xc0d4cf??B['EMPTY_NODE'];}['copy'](_0x58697c,_0x52d014,_0x217006,_0x1e3ce5,_0x55021e){return new M(_0x58697c??this['key'],_0x52d014??this['value'],_0x217006??this['color'],_0x1e3ce5??this['left'],_0x55021e??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x425cca){return this['left']['inorderTraversal'](_0x425cca)||!!_0x425cca(this['key'],this['value'])||this['right']['inorderTraversal'](_0x425cca);}['reverseTraversal'](_0x329f61){return this['right']['reverseTraversal'](_0x329f61)||_0x329f61(this['key'],this['value'])||this['left']['reverseTraversal'](_0x329f61);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x37367a,_0x1c1b80,_0x43ab27){let _0x56e957=this;const _0x1d3c4c=_0x43ab27(_0x37367a,_0x56e957['key']);return _0x1d3c4c<0x0?_0x56e957=_0x56e957['copy'](null,null,null,_0x56e957['left']['insert'](_0x37367a,_0x1c1b80,_0x43ab27),null):_0x1d3c4c===0x0?_0x56e957=_0x56e957['copy'](null,_0x1c1b80,null,null,null):_0x56e957=_0x56e957['copy'](null,null,null,null,_0x56e957['right']['insert'](_0x37367a,_0x1c1b80,_0x43ab27)),_0x56e957['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1de5b4=this;return!_0x1de5b4['left']['isRed_']()&&!_0x1de5b4['left']['left']['isRed_']()&&(_0x1de5b4=_0x1de5b4['moveRedLeft_']()),_0x1de5b4=_0x1de5b4['copy'](null,null,null,_0x1de5b4['left']['removeMin_'](),null),_0x1de5b4['fixUp_']();}['remove'](_0x5467da,_0x140b8e){let _0x2b7860,_0x44ab1e;if(_0x2b7860=this,_0x140b8e(_0x5467da,_0x2b7860['key'])<0x0)!_0x2b7860['left']['isEmpty']()&&!_0x2b7860['left']['isRed_']()&&!_0x2b7860['left']['left']['isRed_']()&&(_0x2b7860=_0x2b7860['moveRedLeft_']()),_0x2b7860=_0x2b7860['copy'](null,null,null,_0x2b7860['left']['remove'](_0x5467da,_0x140b8e),null);else{if(_0x2b7860['left']['isRed_']()&&(_0x2b7860=_0x2b7860['rotateRight_']()),!_0x2b7860['right']['isEmpty']()&&!_0x2b7860['right']['isRed_']()&&!_0x2b7860['right']['left']['isRed_']()&&(_0x2b7860=_0x2b7860['moveRedRight_']()),_0x140b8e(_0x5467da,_0x2b7860['key'])===0x0){if(_0x2b7860['right']['isEmpty']())return B['EMPTY_NODE'];_0x44ab1e=_0x2b7860['right']['min_'](),_0x2b7860=_0x2b7860['copy'](_0x44ab1e['key'],_0x44ab1e['value'],null,null,_0x2b7860['right']['removeMin_']());}_0x2b7860=_0x2b7860['copy'](null,null,null,null,_0x2b7860['right']['remove'](_0x5467da,_0x140b8e));}return _0x2b7860['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1657e3=this;return _0x1657e3['right']['isRed_']()&&!_0x1657e3['left']['isRed_']()&&(_0x1657e3=_0x1657e3['rotateLeft_']()),_0x1657e3['left']['isRed_']()&&_0x1657e3['left']['left']['isRed_']()&&(_0x1657e3=_0x1657e3['rotateRight_']()),_0x1657e3['left']['isRed_']()&&_0x1657e3['right']['isRed_']()&&(_0x1657e3=_0x1657e3['colorFlip_']()),_0x1657e3;}['moveRedLeft_'](){let _0x1a1b42=this['colorFlip_']();return _0x1a1b42['right']['left']['isRed_']()&&(_0x1a1b42=_0x1a1b42['copy'](null,null,null,null,_0x1a1b42['right']['rotateRight_']()),_0x1a1b42=_0x1a1b42['rotateLeft_'](),_0x1a1b42=_0x1a1b42['colorFlip_']()),_0x1a1b42;}['moveRedRight_'](){let _0x1c5e81=this['colorFlip_']();return _0x1c5e81['left']['left']['isRed_']()&&(_0x1c5e81=_0x1c5e81['rotateRight_'](),_0x1c5e81=_0x1c5e81['colorFlip_']()),_0x1c5e81;}['rotateLeft_'](){const _0x1bf985=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1bf985,null);}['rotateRight_'](){const _0x177919=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x177919);}['colorFlip_'](){const _0x33f943=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x18a100=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x33f943,_0x18a100);}['checkMaxDepth_'](){const _0x150981=this['check_']();return Math['pow'](0x2,_0x150981)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x914b8a=this['left']['check_']();if(_0x914b8a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x914b8a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x4f0963,_0x243c8e,_0x3535a2,_0x4ff4bb,_0x42b2d8){return this;}['insert'](_0x232b7a,_0x5e5d56,_0x4c244e){return new M(_0x232b7a,_0x5e5d56,null);}['remove'](_0x451a39,_0x34771a){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x44e6a8){return!0x1;}['reverseTraversal'](_0x4e9d78){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x452cc9,_0x43ba74=B['EMPTY_NODE']){this['comparator_']=_0x452cc9,this['root_']=_0x43ba74;}['insert'](_0x499b44,_0x329ee4){return new B(this['comparator_'],this['root_']['insert'](_0x499b44,_0x329ee4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x52db45){return new B(this['comparator_'],this['root_']['remove'](_0x52db45,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x447516){let _0x2c4c38,_0x126ae3=this['root_'];for(;!_0x126ae3['isEmpty']();){if(_0x2c4c38=this['comparator_'](_0x447516,_0x126ae3['key']),_0x2c4c38===0x0)return _0x126ae3['value'];_0x2c4c38<0x0?_0x126ae3=_0x126ae3['left']:_0x2c4c38>0x0&&(_0x126ae3=_0x126ae3['right']);}return null;}['getPredecessorKey'](_0x122fe0){let _0x40b21f,_0x4d92a8=this['root_'],_0x3b8ebe=null;for(;!_0x4d92a8['isEmpty']();)if(_0x40b21f=this['comparator_'](_0x122fe0,_0x4d92a8['key']),_0x40b21f===0x0){if(_0x4d92a8['left']['isEmpty']())return _0x3b8ebe?_0x3b8ebe['key']:null;for(_0x4d92a8=_0x4d92a8['left'];!_0x4d92a8['right']['isEmpty']();)_0x4d92a8=_0x4d92a8['right'];return _0x4d92a8['key'];}else _0x40b21f<0x0?_0x4d92a8=_0x4d92a8['left']:_0x40b21f>0x0&&(_0x3b8ebe=_0x4d92a8,_0x4d92a8=_0x4d92a8['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1ccf72){return this['root_']['inorderTraversal'](_0x1ccf72);}['reverseTraversal'](_0x160f61){return this['root_']['reverseTraversal'](_0x160f61);}['getIterator'](_0x544d99){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x544d99);}['getIteratorFrom'](_0x3bc5e3,_0x3fbba1){return new Zt(this['root_'],_0x3bc5e3,this['comparator_'],!0x1,_0x3fbba1);}['getReverseIteratorFrom'](_0x27e11c,_0x47b812){return new Zt(this['root_'],_0x27e11c,this['comparator_'],!0x0,_0x47b812);}['getReverseIterator'](_0x8fa5ea){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x8fa5ea);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x2679a0,_0x5e9917){return He(_0x2679a0['name'],_0x5e9917['name']);}function ji(_0x1d90fe,_0x4509de){return He(_0x1d90fe,_0x4509de);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x338ec7){vi=_0x338ec7;}const Ro=function(_0xa5b909){return typeof _0xa5b909=='number'?'number:'+so(_0xa5b909):'string:'+_0xa5b909;},Ao=function(_0x22cb2c){if(_0x22cb2c['isLeafNode']()){const _0xe5aae7=_0x22cb2c['val']();f(typeof _0xe5aae7=='string'||typeof _0xe5aae7=='number'||typeof _0xe5aae7=='object'&&Y(_0xe5aae7,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x22cb2c===vi||_0x22cb2c['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x22cb2c===vi||_0x22cb2c['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0x48c4bd){er=_0x48c4bd;}static get['__childrenNodeConstructor'](){return er;}constructor(_0xcfe075,_0x2e212b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xcfe075,this['priorityNode_']=_0x2e212b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3095de){return new D(this['value_'],_0x3095de);}['getImmediateChild'](_0x29c6ea){return _0x29c6ea==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x388715){return v(_0x388715)?this:y(_0x388715)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x31284d,_0x2ec808){return null;}['updateImmediateChild'](_0x25cbfb,_0x31281d){return _0x25cbfb==='.priority'?this['updatePriority'](_0x31281d):_0x31281d['isEmpty']()&&_0x25cbfb!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x25cbfb,_0x31281d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4e38f1,_0x8b7cfb){const _0x3f60ff=y(_0x4e38f1);return _0x3f60ff===null?_0x8b7cfb:_0x8b7cfb['isEmpty']()&&_0x3f60ff!=='.priority'?this:(f(_0x3f60ff!=='.priority'||we(_0x4e38f1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3f60ff,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4e38f1),_0x8b7cfb)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1cb210,_0x31d451){return!0x1;}['val'](_0x44a2c5){return _0x44a2c5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1a3d5a='';this['priorityNode_']['isEmpty']()||(_0x1a3d5a+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x11f6a9=typeof this['value_'];_0x1a3d5a+=_0x11f6a9+':',_0x11f6a9==='number'?_0x1a3d5a+=so(this['value_']):_0x1a3d5a+=this['value_'],this['lazyHash_']=no(_0x1a3d5a);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x9c8c45){return _0x9c8c45===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x9c8c45 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x9c8c45['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x9c8c45));}['compareToLeafNode_'](_0x48ad0f){const _0x5bf530=typeof _0x48ad0f['value_'],_0x4bbb84=typeof this['value_'],_0x43499a=D['VALUE_TYPE_ORDER']['indexOf'](_0x5bf530),_0x4d9298=D['VALUE_TYPE_ORDER']['indexOf'](_0x4bbb84);return f(_0x43499a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5bf530),f(_0x4d9298>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4bbb84),_0x43499a===_0x4d9298?_0x4bbb84==='object'?0x0:this['value_']<_0x48ad0f['value_']?-0x1:this['value_']===_0x48ad0f['value_']?0x0:0x1:_0x4d9298-_0x43499a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x238033){if(_0x238033===this)return!0x0;if(_0x238033['isLeafNode']()){const _0x177156=_0x238033;return this['value_']===_0x177156['value_']&&this['priorityNode_']['equals'](_0x177156['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0xfd705e){ko=_0xfd705e;}function xh(_0x3d7d80){No=_0x3d7d80;}class Fh extends On{['compare'](_0x58429,_0x2c1591){const _0x45281f=_0x58429['node']['getPriority'](),_0x44b854=_0x2c1591['node']['getPriority'](),_0x297c8d=_0x45281f['compareTo'](_0x44b854);return _0x297c8d===0x0?He(_0x58429['name'],_0x2c1591['name']):_0x297c8d;}['isDefinedOn'](_0x2977f5){return!_0x2977f5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xbec125,_0x488e7b){return!_0xbec125['getPriority']()['equals'](_0x488e7b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x2d4e4e,_0x48d4db){const _0x3a3fff=ko(_0x2d4e4e);return new E(_0x48d4db,new D('[PRIORITY-POST]',_0x3a3fff));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x5109e4){const _0x434e47=_0xa1e09f=>parseInt(Math['log'](_0xa1e09f)/Uh,0xa),_0x2d57ea=_0x2fbf3b=>parseInt(Array(_0x2fbf3b+0x1)['join']('1'),0x2);this['count']=_0x434e47(_0x5109e4+0x1),this['current_']=this['count']-0x1;const _0xc4c003=_0x2d57ea(this['count']);this['bits_']=_0x5109e4+0x1&_0xc4c003;}['nextBitIsOne'](){const _0x26c25c=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x26c25c;}}const dn=function(_0x460d5a,_0x5cad94,_0x2187d1,_0x1a97b2){_0x460d5a['sort'](_0x5cad94);const _0xe8c493=function(_0x555b76,_0x370845){const _0x279430=_0x370845-_0x555b76;let _0x53213f,_0x35b304;if(_0x279430===0x0)return null;if(_0x279430===0x1)return _0x53213f=_0x460d5a[_0x555b76],_0x35b304=_0x2187d1?_0x2187d1(_0x53213f):_0x53213f,new M(_0x35b304,_0x53213f['node'],M['BLACK'],null,null);{const _0x481b62=parseInt(_0x279430/0x2,0xa)+_0x555b76,_0x80a622=_0xe8c493(_0x555b76,_0x481b62),_0x2d3727=_0xe8c493(_0x481b62+0x1,_0x370845);return _0x53213f=_0x460d5a[_0x481b62],_0x35b304=_0x2187d1?_0x2187d1(_0x53213f):_0x53213f,new M(_0x35b304,_0x53213f['node'],M['BLACK'],_0x80a622,_0x2d3727);}},_0x5ea90c=function(_0x500e20){let _0x562c9e=null,_0x3d3e93=null,_0x2ff8ba=_0x460d5a['length'];const _0xea4fcc=function(_0x74a04,_0x5469d5){const _0x539893=_0x2ff8ba-_0x74a04,_0x4b5d7c=_0x2ff8ba;_0x2ff8ba-=_0x74a04;const _0x2c7180=_0xe8c493(_0x539893+0x1,_0x4b5d7c),_0x4167c1=_0x460d5a[_0x539893],_0x2c13b9=_0x2187d1?_0x2187d1(_0x4167c1):_0x4167c1;_0xe3f3b5(new M(_0x2c13b9,_0x4167c1['node'],_0x5469d5,null,_0x2c7180));},_0xe3f3b5=function(_0x4bfa77){_0x562c9e?(_0x562c9e['left']=_0x4bfa77,_0x562c9e=_0x4bfa77):(_0x3d3e93=_0x4bfa77,_0x562c9e=_0x4bfa77);};for(let _0x49c00e=0x0;_0x49c00e<_0x500e20['count'];++_0x49c00e){const _0x5491d7=_0x500e20['nextBitIsOne'](),_0x3ea239=Math['pow'](0x2,_0x500e20['count']-(_0x49c00e+0x1));_0x5491d7?_0xea4fcc(_0x3ea239,M['BLACK']):(_0xea4fcc(_0x3ea239,M['BLACK']),_0xea4fcc(_0x3ea239,M['RED']));}return _0x3d3e93;},_0x554cec=new Wh(_0x460d5a['length']),_0x3ae405=_0x5ea90c(_0x554cec);return new B(_0x1a97b2||_0x5cad94,_0x3ae405);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x38aaab,_0x51507f){this['indexes_']=_0x38aaab,this['indexSet_']=_0x51507f;}['get'](_0xeca1e4){const _0x444ee0=Oe(this['indexes_'],_0xeca1e4);if(!_0x444ee0)throw new Error('No\x20index\x20defined\x20for\x20'+_0xeca1e4);return _0x444ee0 instanceof B?_0x444ee0:null;}['hasIndex'](_0x1e8d8b){return Y(this['indexSet_'],_0x1e8d8b['toString']());}['addIndex'](_0x45702c,_0x4090b9){f(_0x45702c!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x57604f=[];let _0x5c4f5f=!0x1;const _0x1050d1=_0x4090b9['getIterator'](E['Wrap']);let _0x3b338b=_0x1050d1['getNext']();for(;_0x3b338b;)_0x5c4f5f=_0x5c4f5f||_0x45702c['isDefinedOn'](_0x3b338b['node']),_0x57604f['push'](_0x3b338b),_0x3b338b=_0x1050d1['getNext']();let _0x3649f4;_0x5c4f5f?_0x3649f4=dn(_0x57604f,_0x45702c['getCompare']()):_0x3649f4=je;const _0x942627=_0x45702c['toString'](),_0x455aa0={...this['indexSet_']};_0x455aa0[_0x942627]=_0x45702c;const _0x305cd3={...this['indexes_']};return _0x305cd3[_0x942627]=_0x3649f4,new ee(_0x305cd3,_0x455aa0);}['addToIndexes'](_0x4c4b28,_0x5259d3){const _0x310b26=ln(this['indexes_'],(_0x47775c,_0x2dc6ec)=>{const _0x501c92=Oe(this['indexSet_'],_0x2dc6ec);if(f(_0x501c92,'Missing\x20index\x20implementation\x20for\x20'+_0x2dc6ec),_0x47775c===je){if(_0x501c92['isDefinedOn'](_0x4c4b28['node'])){const _0x3a1ad9=[],_0x1c1ab2=_0x5259d3['getIterator'](E['Wrap']);let _0x4c20b1=_0x1c1ab2['getNext']();for(;_0x4c20b1;)_0x4c20b1['name']!==_0x4c4b28['name']&&_0x3a1ad9['push'](_0x4c20b1),_0x4c20b1=_0x1c1ab2['getNext']();return _0x3a1ad9['push'](_0x4c4b28),dn(_0x3a1ad9,_0x501c92['getCompare']());}else return je;}else{const _0xb7923f=_0x5259d3['get'](_0x4c4b28['name']);let _0x5858fb=_0x47775c;return _0xb7923f&&(_0x5858fb=_0x5858fb['remove'](new E(_0x4c4b28['name'],_0xb7923f))),_0x5858fb['insert'](_0x4c4b28,_0x4c4b28['node']);}});return new ee(_0x310b26,this['indexSet_']);}['removeFromIndexes'](_0x15222c,_0x100766){const _0x2e1305=ln(this['indexes_'],_0x551945=>{if(_0x551945===je)return _0x551945;{const _0x4849dc=_0x100766['get'](_0x15222c['name']);return _0x4849dc?_0x551945['remove'](new E(_0x15222c['name'],_0x4849dc)):_0x551945;}});return new ee(_0x2e1305,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x52022e,_0x5911b9,_0x1e20a0){this['children_']=_0x52022e,this['priorityNode_']=_0x5911b9,this['indexMap_']=_0x1e20a0,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x47e791){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x47e791,this['indexMap_']);}['getImmediateChild'](_0x1f22d0){if(_0x1f22d0==='.priority')return this['getPriority']();{const _0x402605=this['children_']['get'](_0x1f22d0);return _0x402605===null?gt:_0x402605;}}['getChild'](_0x133584){const _0x346842=y(_0x133584);return _0x346842===null?this:this['getImmediateChild'](_0x346842)['getChild'](b(_0x133584));}['hasChild'](_0x31dd6e){return this['children_']['get'](_0x31dd6e)!==null;}['updateImmediateChild'](_0x45bb9d,_0x567573){if(f(_0x567573,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x45bb9d==='.priority')return this['updatePriority'](_0x567573);{const _0x54c4aa=new E(_0x45bb9d,_0x567573);let _0x5e2468,_0x583b3e;_0x567573['isEmpty']()?(_0x5e2468=this['children_']['remove'](_0x45bb9d),_0x583b3e=this['indexMap_']['removeFromIndexes'](_0x54c4aa,this['children_'])):(_0x5e2468=this['children_']['insert'](_0x45bb9d,_0x567573),_0x583b3e=this['indexMap_']['addToIndexes'](_0x54c4aa,this['children_']));const _0x7b0d24=_0x5e2468['isEmpty']()?gt:this['priorityNode_'];return new g(_0x5e2468,_0x7b0d24,_0x583b3e);}}['updateChild'](_0x1e1e6a,_0x359772){const _0x1afd8d=y(_0x1e1e6a);if(_0x1afd8d===null)return _0x359772;{f(y(_0x1e1e6a)!=='.priority'||we(_0x1e1e6a)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x92d6c2=this['getImmediateChild'](_0x1afd8d)['updateChild'](b(_0x1e1e6a),_0x359772);return this['updateImmediateChild'](_0x1afd8d,_0x92d6c2);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1486d2){if(this['isEmpty']())return null;const _0x18e8dd={};let _0x36aabc=0x0,_0x182e7e=0x0,_0x46b75a=!0x0;if(this['forEachChild'](R,(_0x1c36d7,_0x523399)=>{_0x18e8dd[_0x1c36d7]=_0x523399['val'](_0x1486d2),_0x36aabc++,_0x46b75a&&g['INTEGER_REGEXP_']['test'](_0x1c36d7)?_0x182e7e=Math['max'](_0x182e7e,Number(_0x1c36d7)):_0x46b75a=!0x1;}),!_0x1486d2&&_0x46b75a&&_0x182e7e<0x2*_0x36aabc){const _0x4dce3b=[];for(const _0x33eba3 in _0x18e8dd)_0x4dce3b[_0x33eba3]=_0x18e8dd[_0x33eba3];return _0x4dce3b;}else return _0x1486d2&&!this['getPriority']()['isEmpty']()&&(_0x18e8dd['.priority']=this['getPriority']()['val']()),_0x18e8dd;}['hash'](){if(this['lazyHash_']===null){let _0x357f98='';this['getPriority']()['isEmpty']()||(_0x357f98+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x534d82,_0x2021c3)=>{const _0x54db21=_0x2021c3['hash']();_0x54db21!==''&&(_0x357f98+=':'+_0x534d82+':'+_0x54db21);}),this['lazyHash_']=_0x357f98===''?'':no(_0x357f98);}return this['lazyHash_'];}['getPredecessorChildName'](_0x252b2c,_0x1725f8,_0x5695a6){const _0x25f811=this['resolveIndex_'](_0x5695a6);if(_0x25f811){const _0xd6d9fd=_0x25f811['getPredecessorKey'](new E(_0x252b2c,_0x1725f8));return _0xd6d9fd?_0xd6d9fd['name']:null;}else return this['children_']['getPredecessorKey'](_0x252b2c);}['getFirstChildName'](_0x879eb0){const _0x37d0e4=this['resolveIndex_'](_0x879eb0);if(_0x37d0e4){const _0x2ccfc1=_0x37d0e4['minKey']();return _0x2ccfc1&&_0x2ccfc1['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x42dbeb){const _0x63cc81=this['getFirstChildName'](_0x42dbeb);return _0x63cc81?new E(_0x63cc81,this['children_']['get'](_0x63cc81)):null;}['getLastChildName'](_0x1fda3f){const _0x2a1493=this['resolveIndex_'](_0x1fda3f);if(_0x2a1493){const _0x2d6f16=_0x2a1493['maxKey']();return _0x2d6f16&&_0x2d6f16['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1a6a78){const _0x278d4f=this['getLastChildName'](_0x1a6a78);return _0x278d4f?new E(_0x278d4f,this['children_']['get'](_0x278d4f)):null;}['forEachChild'](_0x109c82,_0x17eb6b){const _0x2a0dc2=this['resolveIndex_'](_0x109c82);return _0x2a0dc2?_0x2a0dc2['inorderTraversal'](_0x178238=>_0x17eb6b(_0x178238['name'],_0x178238['node'])):this['children_']['inorderTraversal'](_0x17eb6b);}['getIterator'](_0x3f230a){return this['getIteratorFrom'](_0x3f230a['minPost'](),_0x3f230a);}['getIteratorFrom'](_0x3747d6,_0x38d664){const _0x327f6a=this['resolveIndex_'](_0x38d664);if(_0x327f6a)return _0x327f6a['getIteratorFrom'](_0x3747d6,_0x4a09e1=>_0x4a09e1);{const _0x17eddb=this['children_']['getIteratorFrom'](_0x3747d6['name'],E['Wrap']);let _0xb7f066=_0x17eddb['peek']();for(;_0xb7f066!=null&&_0x38d664['compare'](_0xb7f066,_0x3747d6)<0x0;)_0x17eddb['getNext'](),_0xb7f066=_0x17eddb['peek']();return _0x17eddb;}}['getReverseIterator'](_0x2830bf){return this['getReverseIteratorFrom'](_0x2830bf['maxPost'](),_0x2830bf);}['getReverseIteratorFrom'](_0x2e88ab,_0x218682){const _0x16566e=this['resolveIndex_'](_0x218682);if(_0x16566e)return _0x16566e['getReverseIteratorFrom'](_0x2e88ab,_0x4d7655=>_0x4d7655);{const _0x4e458a=this['children_']['getReverseIteratorFrom'](_0x2e88ab['name'],E['Wrap']);let _0x555468=_0x4e458a['peek']();for(;_0x555468!=null&&_0x218682['compare'](_0x555468,_0x2e88ab)>0x0;)_0x4e458a['getNext'](),_0x555468=_0x4e458a['peek']();return _0x4e458a;}}['compareTo'](_0x1549dc){return this['isEmpty']()?_0x1549dc['isEmpty']()?0x0:-0x1:_0x1549dc['isLeafNode']()||_0x1549dc['isEmpty']()?0x1:_0x1549dc===Ht?-0x1:0x0;}['withIndex'](_0x26ece1){if(_0x26ece1===ye||this['indexMap_']['hasIndex'](_0x26ece1))return this;{const _0x289767=this['indexMap_']['addIndex'](_0x26ece1,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x289767);}}['isIndexed'](_0x1c348a){return _0x1c348a===ye||this['indexMap_']['hasIndex'](_0x1c348a);}['equals'](_0x1bb6ea){if(_0x1bb6ea===this)return!0x0;if(_0x1bb6ea['isLeafNode']())return!0x1;{const _0x1974ad=_0x1bb6ea;if(this['getPriority']()['equals'](_0x1974ad['getPriority']())){if(this['children_']['count']()===_0x1974ad['children_']['count']()){const _0x11ade1=this['getIterator'](R),_0x29576e=_0x1974ad['getIterator'](R);let _0x45dc99=_0x11ade1['getNext'](),_0x5c22eb=_0x29576e['getNext']();for(;_0x45dc99&&_0x5c22eb;){if(_0x45dc99['name']!==_0x5c22eb['name']||!_0x45dc99['node']['equals'](_0x5c22eb['node']))return!0x1;_0x45dc99=_0x11ade1['getNext'](),_0x5c22eb=_0x29576e['getNext']();}return _0x45dc99===null&&_0x5c22eb===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x290df9){return _0x290df9===ye?null:this['indexMap_']['get'](_0x290df9['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x4e461f){return _0x4e461f===this?0x0:0x1;}['equals'](_0x48ad1e){return _0x48ad1e===this;}['getPriority'](){return this;}['getImmediateChild'](_0x55eef1){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0xce4ab,_0x3b2a7f=null){if(_0xce4ab===null)return g['EMPTY_NODE'];if(typeof _0xce4ab=='object'&&'.priority'in _0xce4ab&&(_0x3b2a7f=_0xce4ab['.priority']),f(_0x3b2a7f===null||typeof _0x3b2a7f=='string'||typeof _0x3b2a7f=='number'||typeof _0x3b2a7f=='object'&&'.sv'in _0x3b2a7f,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3b2a7f),typeof _0xce4ab=='object'&&'.value'in _0xce4ab&&_0xce4ab['.value']!==null&&(_0xce4ab=_0xce4ab['.value']),typeof _0xce4ab!='object'||'.sv'in _0xce4ab){const _0x94110=_0xce4ab;return new D(_0x94110,N(_0x3b2a7f));}if(!(_0xce4ab instanceof Array)&&Vh){const _0x1c1beb=[];let _0x250643=!0x1;if(x(_0xce4ab,(_0x31e018,_0x170d1f)=>{if(_0x31e018['substring'](0x0,0x1)!=='.'){const _0x1333cc=N(_0x170d1f);_0x1333cc['isEmpty']()||(_0x250643=_0x250643||!_0x1333cc['getPriority']()['isEmpty'](),_0x1c1beb['push'](new E(_0x31e018,_0x1333cc)));}}),_0x1c1beb['length']===0x0)return g['EMPTY_NODE'];const _0x22b98f=dn(_0x1c1beb,Dh,_0x53a7f2=>_0x53a7f2['name'],ji);if(_0x250643){const _0x4878aa=dn(_0x1c1beb,R['getCompare']());return new g(_0x22b98f,N(_0x3b2a7f),new ee({'.priority':_0x4878aa},{'.priority':R}));}else return new g(_0x22b98f,N(_0x3b2a7f),ee['Default']);}else{let _0x5708ca=g['EMPTY_NODE'];return x(_0xce4ab,(_0x344b36,_0x124d43)=>{if(Y(_0xce4ab,_0x344b36)&&_0x344b36['substring'](0x0,0x1)!=='.'){const _0x529a09=N(_0x124d43);(_0x529a09['isLeafNode']()||!_0x529a09['isEmpty']())&&(_0x5708ca=_0x5708ca['updateImmediateChild'](_0x344b36,_0x529a09));}}),_0x5708ca['updatePriority'](N(_0x3b2a7f));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x588af3){super(),this['indexPath_']=_0x588af3,f(!v(_0x588af3)&&y(_0x588af3)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1ee248){return _0x1ee248['getChild'](this['indexPath_']);}['isDefinedOn'](_0x2bbc45){return!_0x2bbc45['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xcdd23b,_0x520994){const _0x208009=this['extractChild'](_0xcdd23b['node']),_0x404a99=this['extractChild'](_0x520994['node']),_0x535b3=_0x208009['compareTo'](_0x404a99);return _0x535b3===0x0?He(_0xcdd23b['name'],_0x520994['name']):_0x535b3;}['makePost'](_0x395dd5,_0x1d8e59){const _0x7440ec=N(_0x395dd5),_0x5d5cf9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x7440ec);return new E(_0x1d8e59,_0x5d5cf9);}['maxPost'](){const _0x5ba97f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0x5ba97f);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x7a1417,_0x3336d4){const _0x396f1e=_0x7a1417['node']['compareTo'](_0x3336d4['node']);return _0x396f1e===0x0?He(_0x7a1417['name'],_0x3336d4['name']):_0x396f1e;}['isDefinedOn'](_0x19b214){return!0x0;}['indexedValueChanged'](_0x154bf7,_0x3b7d14){return!_0x154bf7['equals'](_0x3b7d14);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x91247f,_0x1f0ec0){const _0x4ec455=N(_0x91247f);return new E(_0x1f0ec0,_0x4ec455);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x164cc8){return{'type':'value','snapshotNode':_0x164cc8};}function tt(_0x3a3cc0,_0x22c76b){return{'type':'child_added','snapshotNode':_0x22c76b,'childName':_0x3a3cc0};}function Nt(_0xa5832c,_0x9d4e5){return{'type':'child_removed','snapshotNode':_0x9d4e5,'childName':_0xa5832c};}function Pt(_0xbe042e,_0x342083,_0xddc1bd){return{'type':'child_changed','snapshotNode':_0x342083,'childName':_0xbe042e,'oldSnap':_0xddc1bd};}function $h(_0x2c6674,_0x3205c8){return{'type':'child_moved','snapshotNode':_0x3205c8,'childName':_0x2c6674};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x4b0b79){this['index_']=_0x4b0b79;}['updateChild'](_0xa11013,_0x2692bd,_0x4d0347,_0x310edb,_0x3037fb,_0x33705c){f(_0xa11013['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x2b1d1e=_0xa11013['getImmediateChild'](_0x2692bd);return _0x2b1d1e['getChild'](_0x310edb)['equals'](_0x4d0347['getChild'](_0x310edb))&&_0x2b1d1e['isEmpty']()===_0x4d0347['isEmpty']()||(_0x33705c!=null&&(_0x4d0347['isEmpty']()?_0xa11013['hasChild'](_0x2692bd)?_0x33705c['trackChildChange'](Nt(_0x2692bd,_0x2b1d1e)):f(_0xa11013['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x2b1d1e['isEmpty']()?_0x33705c['trackChildChange'](tt(_0x2692bd,_0x4d0347)):_0x33705c['trackChildChange'](Pt(_0x2692bd,_0x4d0347,_0x2b1d1e))),_0xa11013['isLeafNode']()&&_0x4d0347['isEmpty']())?_0xa11013:_0xa11013['updateImmediateChild'](_0x2692bd,_0x4d0347)['withIndex'](this['index_']);}['updateFullNode'](_0x3d45e2,_0x25daec,_0x5d893e){return _0x5d893e!=null&&(_0x3d45e2['isLeafNode']()||_0x3d45e2['forEachChild'](R,(_0x3cd94b,_0x55e069)=>{_0x25daec['hasChild'](_0x3cd94b)||_0x5d893e['trackChildChange'](Nt(_0x3cd94b,_0x55e069));}),_0x25daec['isLeafNode']()||_0x25daec['forEachChild'](R,(_0x4a4073,_0x38f748)=>{if(_0x3d45e2['hasChild'](_0x4a4073)){const _0x48ed39=_0x3d45e2['getImmediateChild'](_0x4a4073);_0x48ed39['equals'](_0x38f748)||_0x5d893e['trackChildChange'](Pt(_0x4a4073,_0x38f748,_0x48ed39));}else _0x5d893e['trackChildChange'](tt(_0x4a4073,_0x38f748));})),_0x25daec['withIndex'](this['index_']);}['updatePriority'](_0x1e0050,_0x548e48){return _0x1e0050['isEmpty']()?g['EMPTY_NODE']:_0x1e0050['updatePriority'](_0x548e48);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x4eb761){this['indexedFilter_']=new Yi(_0x4eb761['getIndex']()),this['index_']=_0x4eb761['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x4eb761),this['endPost_']=Ot['getEndPost_'](_0x4eb761),this['startIsInclusive_']=!_0x4eb761['startAfterSet_'],this['endIsInclusive_']=!_0x4eb761['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x280881){const _0xcb5a86=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x280881)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x280881)<0x0,_0x4446f7=this['endIsInclusive_']?this['index_']['compare'](_0x280881,this['getEndPost']())<=0x0:this['index_']['compare'](_0x280881,this['getEndPost']())<0x0;return _0xcb5a86&&_0x4446f7;}['updateChild'](_0x3a035,_0x2ebd1e,_0xbf4e76,_0x1f1d89,_0xb19166,_0x5d8e0f){return this['matches'](new E(_0x2ebd1e,_0xbf4e76))||(_0xbf4e76=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3a035,_0x2ebd1e,_0xbf4e76,_0x1f1d89,_0xb19166,_0x5d8e0f);}['updateFullNode'](_0x37a2c4,_0x2ab08a,_0x597d50){_0x2ab08a['isLeafNode']()&&(_0x2ab08a=g['EMPTY_NODE']);let _0x11f5ba=_0x2ab08a['withIndex'](this['index_']);_0x11f5ba=_0x11f5ba['updatePriority'](g['EMPTY_NODE']);const _0xe194bc=this;return _0x2ab08a['forEachChild'](R,(_0x575f0e,_0x505fa5)=>{_0xe194bc['matches'](new E(_0x575f0e,_0x505fa5))||(_0x11f5ba=_0x11f5ba['updateImmediateChild'](_0x575f0e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x37a2c4,_0x11f5ba,_0x597d50);}['updatePriority'](_0x5296b9,_0x40d837){return _0x5296b9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x559124){if(_0x559124['hasStart']()){const _0x2d8294=_0x559124['getIndexStartName']();return _0x559124['getIndex']()['makePost'](_0x559124['getIndexStartValue'](),_0x2d8294);}else return _0x559124['getIndex']()['minPost']();}static['getEndPost_'](_0x2c9373){if(_0x2c9373['hasEnd']()){const _0x5a3775=_0x2c9373['getIndexEndName']();return _0x2c9373['getIndex']()['makePost'](_0x2c9373['getIndexEndValue'](),_0x5a3775);}else return _0x2c9373['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x308374){this['withinDirectionalStart']=_0x1e2864=>this['reverse_']?this['withinEndPost'](_0x1e2864):this['withinStartPost'](_0x1e2864),this['withinDirectionalEnd']=_0x395d4d=>this['reverse_']?this['withinStartPost'](_0x395d4d):this['withinEndPost'](_0x395d4d),this['withinStartPost']=_0x4dd4c8=>{const _0x225fe1=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x4dd4c8);return this['startIsInclusive_']?_0x225fe1<=0x0:_0x225fe1<0x0;},this['withinEndPost']=_0x2e8830=>{const _0x4dd2f1=this['index_']['compare'](_0x2e8830,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4dd2f1<=0x0:_0x4dd2f1<0x0;},this['rangedFilter_']=new Ot(_0x308374),this['index_']=_0x308374['getIndex'](),this['limit_']=_0x308374['getLimit'](),this['reverse_']=!_0x308374['isViewFromLeft'](),this['startIsInclusive_']=!_0x308374['startAfterSet_'],this['endIsInclusive_']=!_0x308374['endBeforeSet_'];}['updateChild'](_0x221ea4,_0x318ebc,_0x16058a,_0x413695,_0x369aef,_0x46e739){return this['rangedFilter_']['matches'](new E(_0x318ebc,_0x16058a))||(_0x16058a=g['EMPTY_NODE']),_0x221ea4['getImmediateChild'](_0x318ebc)['equals'](_0x16058a)?_0x221ea4:_0x221ea4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x221ea4,_0x318ebc,_0x16058a,_0x413695,_0x369aef,_0x46e739):this['fullLimitUpdateChild_'](_0x221ea4,_0x318ebc,_0x16058a,_0x369aef,_0x46e739);}['updateFullNode'](_0x5de5ff,_0x5f4c52,_0x4b0c50){let _0x442dd5;if(_0x5f4c52['isLeafNode']()||_0x5f4c52['isEmpty']())_0x442dd5=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5f4c52['numChildren']()&&_0x5f4c52['isIndexed'](this['index_'])){_0x442dd5=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x53f339;this['reverse_']?_0x53f339=_0x5f4c52['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x53f339=_0x5f4c52['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2a5a51=0x0;for(;_0x53f339['hasNext']()&&_0x2a5a51<this['limit_'];){const _0x4bc2a0=_0x53f339['getNext']();if(this['withinDirectionalStart'](_0x4bc2a0)){if(this['withinDirectionalEnd'](_0x4bc2a0))_0x442dd5=_0x442dd5['updateImmediateChild'](_0x4bc2a0['name'],_0x4bc2a0['node']),_0x2a5a51++;else break;}else continue;}}else{_0x442dd5=_0x5f4c52['withIndex'](this['index_']),_0x442dd5=_0x442dd5['updatePriority'](g['EMPTY_NODE']);let _0x1a01a6;this['reverse_']?_0x1a01a6=_0x442dd5['getReverseIterator'](this['index_']):_0x1a01a6=_0x442dd5['getIterator'](this['index_']);let _0x59b42a=0x0;for(;_0x1a01a6['hasNext']();){const _0x500206=_0x1a01a6['getNext']();_0x59b42a<this['limit_']&&this['withinDirectionalStart'](_0x500206)&&this['withinDirectionalEnd'](_0x500206)?_0x59b42a++:_0x442dd5=_0x442dd5['updateImmediateChild'](_0x500206['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x5de5ff,_0x442dd5,_0x4b0c50);}['updatePriority'](_0x445325,_0x4ae9dd){return _0x445325;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x18d023,_0x51732b,_0xf88f65,_0x4ea221,_0x3e2cd1){let _0x3c7fbe;if(this['reverse_']){const _0x412108=this['index_']['getCompare']();_0x3c7fbe=(_0x532689,_0x2ba616)=>_0x412108(_0x2ba616,_0x532689);}else _0x3c7fbe=this['index_']['getCompare']();const _0x114990=_0x18d023;f(_0x114990['numChildren']()===this['limit_'],'');const _0x3d266a=new E(_0x51732b,_0xf88f65),_0x437dd7=this['reverse_']?_0x114990['getFirstChild'](this['index_']):_0x114990['getLastChild'](this['index_']),_0x34c2e9=this['rangedFilter_']['matches'](_0x3d266a);if(_0x114990['hasChild'](_0x51732b)){const _0x29a796=_0x114990['getImmediateChild'](_0x51732b);let _0x436a45=_0x4ea221['getChildAfterChild'](this['index_'],_0x437dd7,this['reverse_']);for(;_0x436a45!=null&&(_0x436a45['name']===_0x51732b||_0x114990['hasChild'](_0x436a45['name']));)_0x436a45=_0x4ea221['getChildAfterChild'](this['index_'],_0x436a45,this['reverse_']);const _0x2a2b88=_0x436a45==null?0x1:_0x3c7fbe(_0x436a45,_0x3d266a);if(_0x34c2e9&&!_0xf88f65['isEmpty']()&&_0x2a2b88>=0x0)return _0x3e2cd1!=null&&_0x3e2cd1['trackChildChange'](Pt(_0x51732b,_0xf88f65,_0x29a796)),_0x114990['updateImmediateChild'](_0x51732b,_0xf88f65);{_0x3e2cd1!=null&&_0x3e2cd1['trackChildChange'](Nt(_0x51732b,_0x29a796));const _0x290289=_0x114990['updateImmediateChild'](_0x51732b,g['EMPTY_NODE']);return _0x436a45!=null&&this['rangedFilter_']['matches'](_0x436a45)?(_0x3e2cd1!=null&&_0x3e2cd1['trackChildChange'](tt(_0x436a45['name'],_0x436a45['node'])),_0x290289['updateImmediateChild'](_0x436a45['name'],_0x436a45['node'])):_0x290289;}}else return _0xf88f65['isEmpty']()?_0x18d023:_0x34c2e9&&_0x3c7fbe(_0x437dd7,_0x3d266a)>=0x0?(_0x3e2cd1!=null&&(_0x3e2cd1['trackChildChange'](Nt(_0x437dd7['name'],_0x437dd7['node'])),_0x3e2cd1['trackChildChange'](tt(_0x51732b,_0xf88f65))),_0x114990['updateImmediateChild'](_0x51732b,_0xf88f65)['updateImmediateChild'](_0x437dd7['name'],g['EMPTY_NODE'])):_0x18d023;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3c85b9=new Qi();return _0x3c85b9['limitSet_']=this['limitSet_'],_0x3c85b9['limit_']=this['limit_'],_0x3c85b9['startSet_']=this['startSet_'],_0x3c85b9['startAfterSet_']=this['startAfterSet_'],_0x3c85b9['indexStartValue_']=this['indexStartValue_'],_0x3c85b9['startNameSet_']=this['startNameSet_'],_0x3c85b9['indexStartName_']=this['indexStartName_'],_0x3c85b9['endSet_']=this['endSet_'],_0x3c85b9['endBeforeSet_']=this['endBeforeSet_'],_0x3c85b9['indexEndValue_']=this['indexEndValue_'],_0x3c85b9['endNameSet_']=this['endNameSet_'],_0x3c85b9['indexEndName_']=this['indexEndName_'],_0x3c85b9['index_']=this['index_'],_0x3c85b9['viewFrom_']=this['viewFrom_'],_0x3c85b9;}}function qh(_0x1485b1){return _0x1485b1['loadsAllData']()?new Yi(_0x1485b1['getIndex']()):_0x1485b1['hasLimit']()?new Gh(_0x1485b1):new Ot(_0x1485b1);}function zh(_0x2c1758,_0x21a927){const _0x2df037=_0x2c1758['copy']();return _0x2df037['limitSet_']=!0x0,_0x2df037['limit_']=_0x21a927,_0x2df037['viewFrom_']='l',_0x2df037;}function jh(_0xb2cb53,_0x551bac,_0x213e4b){const _0x30ccc8=_0xb2cb53['copy']();return _0x30ccc8['startSet_']=!0x0,_0x551bac===void 0x0&&(_0x551bac=null),_0x30ccc8['indexStartValue_']=_0x551bac,_0x213e4b!=null?(_0x30ccc8['startNameSet_']=!0x0,_0x30ccc8['indexStartName_']=_0x213e4b):(_0x30ccc8['startNameSet_']=!0x1,_0x30ccc8['indexStartName_']=''),_0x30ccc8;}function Kh(_0x18393c,_0x415f27,_0x428b84){const _0x469c1e=_0x18393c['copy']();return _0x469c1e['endSet_']=!0x0,_0x415f27===void 0x0&&(_0x415f27=null),_0x469c1e['indexEndValue_']=_0x415f27,_0x428b84!==void 0x0?(_0x469c1e['endNameSet_']=!0x0,_0x469c1e['indexEndName_']=_0x428b84):(_0x469c1e['endNameSet_']=!0x1,_0x469c1e['indexEndName_']=''),_0x469c1e;}function Do(_0x30cfc4,_0x380544){const _0x46d37b=_0x30cfc4['copy']();return _0x46d37b['index_']=_0x380544,_0x46d37b;}function tr(_0xf15430){const _0x33de08={};if(_0xf15430['isDefault']())return _0x33de08;let _0x598688;if(_0xf15430['index_']===R?_0x598688='$priority':_0xf15430['index_']===Po?_0x598688='$value':_0xf15430['index_']===ye?_0x598688='$key':(f(_0xf15430['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x598688=_0xf15430['index_']['toString']()),_0x33de08['orderBy']=O(_0x598688),_0xf15430['startSet_']){const _0x5d8e6c=_0xf15430['startAfterSet_']?'startAfter':'startAt';_0x33de08[_0x5d8e6c]=O(_0xf15430['indexStartValue_']),_0xf15430['startNameSet_']&&(_0x33de08[_0x5d8e6c]+=','+O(_0xf15430['indexStartName_']));}if(_0xf15430['endSet_']){const _0x1b0274=_0xf15430['endBeforeSet_']?'endBefore':'endAt';_0x33de08[_0x1b0274]=O(_0xf15430['indexEndValue_']),_0xf15430['endNameSet_']&&(_0x33de08[_0x1b0274]+=','+O(_0xf15430['indexEndName_']));}return _0xf15430['limitSet_']&&(_0xf15430['isViewFromLeft']()?_0x33de08['limitToFirst']=_0xf15430['limit_']:_0x33de08['limitToLast']=_0xf15430['limit_']),_0x33de08;}function nr(_0x12190b){const _0xac7dd5={};if(_0x12190b['startSet_']&&(_0xac7dd5['sp']=_0x12190b['indexStartValue_'],_0x12190b['startNameSet_']&&(_0xac7dd5['sn']=_0x12190b['indexStartName_']),_0xac7dd5['sin']=!_0x12190b['startAfterSet_']),_0x12190b['endSet_']&&(_0xac7dd5['ep']=_0x12190b['indexEndValue_'],_0x12190b['endNameSet_']&&(_0xac7dd5['en']=_0x12190b['indexEndName_']),_0xac7dd5['ein']=!_0x12190b['endBeforeSet_']),_0x12190b['limitSet_']){_0xac7dd5['l']=_0x12190b['limit_'];let _0x5d1aa4=_0x12190b['viewFrom_'];_0x5d1aa4===''&&(_0x12190b['isViewFromLeft']()?_0x5d1aa4='l':_0x5d1aa4='r'),_0xac7dd5['vf']=_0x5d1aa4;}return _0x12190b['index_']!==R&&(_0xac7dd5['i']=_0x12190b['index_']['toString']()),_0xac7dd5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x28fe71){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x4a3e73,_0x18f715){return _0x18f715!==void 0x0?'tag$'+_0x18f715:(f(_0x4a3e73['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x4a3e73['_path']['toString']());}constructor(_0x4dbae5,_0x4abf3c,_0x1a5474,_0x364b18){super(),this['repoInfo_']=_0x4dbae5,this['onDataUpdate_']=_0x4abf3c,this['authTokenProvider_']=_0x1a5474,this['appCheckTokenProvider_']=_0x364b18,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x3bfdc3,_0x11429b,_0x3d5ff3,_0x9abc9c){const _0x1a8dd5=_0x3bfdc3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1a8dd5+'\x20'+_0x3bfdc3['_queryIdentifier']);const _0x1c9b85=fn['getListenId_'](_0x3bfdc3,_0x3d5ff3),_0x59330f={};this['listens_'][_0x1c9b85]=_0x59330f;const _0x2ac43f=tr(_0x3bfdc3['_queryParams']);this['restRequest_'](_0x1a8dd5+'.json',_0x2ac43f,(_0x362d9b,_0x4cb085)=>{let _0x5f3ba4=_0x4cb085;if(_0x362d9b===0x194&&(_0x5f3ba4=null,_0x362d9b=null),_0x362d9b===null&&this['onDataUpdate_'](_0x1a8dd5,_0x5f3ba4,!0x1,_0x3d5ff3),Oe(this['listens_'],_0x1c9b85)===_0x59330f){let _0x5df012;_0x362d9b?_0x362d9b===0x191?_0x5df012='permission_denied':_0x5df012='rest_error:'+_0x362d9b:_0x5df012='ok',_0x9abc9c(_0x5df012,null);}});}['unlisten'](_0x57b941,_0x579310){const _0x4f261e=fn['getListenId_'](_0x57b941,_0x579310);delete this['listens_'][_0x4f261e];}['get'](_0x3bc6fd){const _0x246727=tr(_0x3bc6fd['_queryParams']),_0x4ceba9=_0x3bc6fd['_path']['toString'](),_0x94cfc5=new Ve();return this['restRequest_'](_0x4ceba9+'.json',_0x246727,(_0x309060,_0x28cade)=>{let _0x576a2e=_0x28cade;_0x309060===0x194&&(_0x576a2e=null,_0x309060=null),_0x309060===null?(this['onDataUpdate_'](_0x4ceba9,_0x576a2e,!0x1,null),_0x94cfc5['resolve'](_0x576a2e)):_0x94cfc5['reject'](new Error(_0x576a2e));}),_0x94cfc5['promise'];}['refreshAuthToken'](_0x4ae252){}['restRequest_'](_0x557bd1,_0x124a7f={},_0xc4a872){return _0x124a7f['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4cb900,_0x5f5caa])=>{_0x4cb900&&_0x4cb900['accessToken']&&(_0x124a7f['auth']=_0x4cb900['accessToken']),_0x5f5caa&&_0x5f5caa['token']&&(_0x124a7f['ac']=_0x5f5caa['token']);const _0x1db63f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x557bd1+'?ns='+this['repoInfo_']['namespace']+at(_0x124a7f);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1db63f);const _0x22bd4a=new XMLHttpRequest();_0x22bd4a['onreadystatechange']=()=>{if(_0xc4a872&&_0x22bd4a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1db63f+'\x20received.\x20status:',_0x22bd4a['status'],'response:',_0x22bd4a['responseText']);let _0x18b879=null;if(_0x22bd4a['status']>=0xc8&&_0x22bd4a['status']<0x12c){try{_0x18b879=bt(_0x22bd4a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1db63f+':\x20'+_0x22bd4a['responseText']);}_0xc4a872(null,_0x18b879);}else _0x22bd4a['status']!==0x191&&_0x22bd4a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1db63f+'\x20Status:\x20'+_0x22bd4a['status']),_0xc4a872(_0x22bd4a['status']);_0xc4a872=null;}},_0x22bd4a['open']('GET',_0x1db63f,!0x0),_0x22bd4a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x42969){return this['rootNode_']['getChild'](_0x42969);}['updateSnapshot'](_0x3f5141,_0x5c378d){this['rootNode_']=this['rootNode_']['updateChild'](_0x3f5141,_0x5c378d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x514968,_0xb105dc,_0x57d675){if(v(_0xb105dc))_0x514968['value']=_0x57d675,_0x514968['children']['clear']();else{if(_0x514968['value']!==null)_0x514968['value']=_0x514968['value']['updateChild'](_0xb105dc,_0x57d675);else{const _0x4bb371=y(_0xb105dc);_0x514968['children']['has'](_0x4bb371)||_0x514968['children']['set'](_0x4bb371,pn());const _0x8b62ac=_0x514968['children']['get'](_0x4bb371);_0xb105dc=b(_0xb105dc),Mo(_0x8b62ac,_0xb105dc,_0x57d675);}}}function Ei(_0x4d61a9,_0x3dbd34,_0x3c0439){_0x4d61a9['value']!==null?_0x3c0439(_0x3dbd34,_0x4d61a9['value']):Qh(_0x4d61a9,(_0x37b44f,_0x48f52c)=>{const _0x427fb7=new C(_0x3dbd34['toString']()+'/'+_0x37b44f);Ei(_0x48f52c,_0x427fb7,_0x3c0439);});}function Qh(_0x5de241,_0x2d986d){_0x5de241['children']['forEach']((_0x482961,_0x1d6730)=>{_0x2d986d(_0x1d6730,_0x482961);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x4e318e){this['collection_']=_0x4e318e,this['last_']=null;}['get'](){const _0x51a89d=this['collection_']['get'](),_0x25b72e={..._0x51a89d};return this['last_']&&x(this['last_'],(_0x177701,_0x49eefb)=>{_0x25b72e[_0x177701]=_0x25b72e[_0x177701]-_0x49eefb;}),this['last_']=_0x51a89d,_0x25b72e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0xaf3d41,_0x44857a){this['server_']=_0x44857a,this['statsToReport_']={},this['statsListener_']=new Jh(_0xaf3d41);const _0x197f46=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x197f46));}['reportStats_'](){const _0x34bd5c=this['statsListener_']['get'](),_0x455fb8={};let _0x20237e=!0x1;x(_0x34bd5c,(_0x323e7b,_0xf32a22)=>{_0xf32a22>0x0&&Y(this['statsToReport_'],_0x323e7b)&&(_0x455fb8[_0x323e7b]=_0xf32a22,_0x20237e=!0x0);}),_0x20237e&&this['server_']['reportStats'](_0x455fb8),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x1caf64){_0x1caf64[_0x1caf64['OVERWRITE']=0x0]='OVERWRITE',_0x1caf64[_0x1caf64['MERGE']=0x1]='MERGE',_0x1caf64[_0x1caf64['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1caf64[_0x1caf64['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x21e31d){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x21e31d,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x419838,_0x1c8572,_0x654ecf){this['path']=_0x419838,this['affectedTree']=_0x1c8572,this['revert']=_0x654ecf,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x5016c0){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x8c8ae8=this['affectedTree']['subtree'](new C(_0x5016c0));return new _n(w(),_0x8c8ae8,this['revert']);}}else return f(y(this['path'])===_0x5016c0,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x541572,_0x5ee485){this['source']=_0x541572,this['path']=_0x5ee485,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x448286){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x29b99b,_0x204a7a,_0x1168e8){this['source']=_0x29b99b,this['path']=_0x204a7a,this['snap']=_0x1168e8,this['type']=q['OVERWRITE'];}['operationForChild'](_0x4966de){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x4966de)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x8cf73,_0x421ccd,_0x16bed6){this['source']=_0x8cf73,this['path']=_0x421ccd,this['children']=_0x16bed6,this['type']=q['MERGE'];}['operationForChild'](_0x2cc25e){if(v(this['path'])){const _0x3466ff=this['children']['subtree'](new C(_0x2cc25e));return _0x3466ff['isEmpty']()?null:_0x3466ff['value']?new Fe(this['source'],w(),_0x3466ff['value']):new nt(this['source'],w(),_0x3466ff);}else return f(y(this['path'])===_0x2cc25e,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x2c2cc3,_0x2acf2f,_0x1bd7e2){this['node_']=_0x2c2cc3,this['fullyInitialized_']=_0x2acf2f,this['filtered_']=_0x1bd7e2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x142810){if(v(_0x142810))return this['isFullyInitialized']()&&!this['filtered_'];const _0x144768=y(_0x142810);return this['isCompleteForChild'](_0x144768);}['isCompleteForChild'](_0x435450){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x435450);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0x3c5f0a){this['query_']=_0x3c5f0a,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x1da467,_0x22bc44,_0x1474b4,_0x3a7a08){const _0x4ab33f=[],_0x4c5f4e=[];return _0x22bc44['forEach'](_0x26b85e=>{_0x26b85e['type']==='child_changed'&&_0x1da467['index_']['indexedValueChanged'](_0x26b85e['oldSnap'],_0x26b85e['snapshotNode'])&&_0x4c5f4e['push']($h(_0x26b85e['childName'],_0x26b85e['snapshotNode']));}),mt(_0x1da467,_0x4ab33f,'child_removed',_0x22bc44,_0x3a7a08,_0x1474b4),mt(_0x1da467,_0x4ab33f,'child_added',_0x22bc44,_0x3a7a08,_0x1474b4),mt(_0x1da467,_0x4ab33f,'child_moved',_0x4c5f4e,_0x3a7a08,_0x1474b4),mt(_0x1da467,_0x4ab33f,'child_changed',_0x22bc44,_0x3a7a08,_0x1474b4),mt(_0x1da467,_0x4ab33f,'value',_0x22bc44,_0x3a7a08,_0x1474b4),_0x4ab33f;}function mt(_0x55cf3d,_0x35b4eb,_0x5e88c1,_0x5d6585,_0x2d390f,_0x2b919e){const _0x426b21=_0x5d6585['filter'](_0x1743b4=>_0x1743b4['type']===_0x5e88c1);_0x426b21['sort']((_0x48e13d,_0x527d1e)=>su(_0x55cf3d,_0x48e13d,_0x527d1e)),_0x426b21['forEach'](_0x8fb40e=>{const _0x61d803=iu(_0x55cf3d,_0x8fb40e,_0x2b919e);_0x2d390f['forEach'](_0x5d8b81=>{_0x5d8b81['respondsTo'](_0x8fb40e['type'])&&_0x35b4eb['push'](_0x5d8b81['createEvent'](_0x61d803,_0x55cf3d['query_']));});});}function iu(_0x5cfeae,_0x2a7aef,_0x34fa75){return _0x2a7aef['type']==='value'||_0x2a7aef['type']==='child_removed'||(_0x2a7aef['prevName']=_0x34fa75['getPredecessorChildName'](_0x2a7aef['childName'],_0x2a7aef['snapshotNode'],_0x5cfeae['index_'])),_0x2a7aef;}function su(_0x46221b,_0x4e68e6,_0x47d6fc){if(_0x4e68e6['childName']==null||_0x47d6fc['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x42625c=new E(_0x4e68e6['childName'],_0x4e68e6['snapshotNode']),_0x5e7134=new E(_0x47d6fc['childName'],_0x47d6fc['snapshotNode']);return _0x46221b['index_']['compare'](_0x42625c,_0x5e7134);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x2e1371,_0x5035b7){return{'eventCache':_0x2e1371,'serverCache':_0x5035b7};}function wt(_0x50a717,_0x1048ec,_0x1f771a,_0x4056a3){return Dn(new Ce(_0x1048ec,_0x1f771a,_0x4056a3),_0x50a717['serverCache']);}function Lo(_0x23c9e8,_0x302f33,_0x2f1aab,_0x48f02d){return Dn(_0x23c9e8['eventCache'],new Ce(_0x302f33,_0x2f1aab,_0x48f02d));}function gn(_0x213dc5){return _0x213dc5['eventCache']['isFullyInitialized']()?_0x213dc5['eventCache']['getNode']():null;}function Ue(_0x52775e){return _0x52775e['serverCache']['isFullyInitialized']()?_0x52775e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x2a2312){let _0x3bbdc5=new S(null);return x(_0x2a2312,(_0x728c56,_0x1bc02d)=>{_0x3bbdc5=_0x3bbdc5['set'](new C(_0x728c56),_0x1bc02d);}),_0x3bbdc5;}constructor(_0xa5b674,_0x40b120=ru()){this['value']=_0xa5b674,this['children']=_0x40b120;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4c35e9,_0x5dc81c){if(this['value']!=null&&_0x5dc81c(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4c35e9))return null;{const _0x146305=y(_0x4c35e9),_0xde38ba=this['children']['get'](_0x146305);if(_0xde38ba!==null){const _0x1f2191=_0xde38ba['findRootMostMatchingPathAndValue'](b(_0x4c35e9),_0x5dc81c);return _0x1f2191!=null?{'path':A(new C(_0x146305),_0x1f2191['path']),'value':_0x1f2191['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x46c9e2){return this['findRootMostMatchingPathAndValue'](_0x46c9e2,()=>!0x0);}['subtree'](_0x4c7911){if(v(_0x4c7911))return this;{const _0x435876=y(_0x4c7911),_0x2311cb=this['children']['get'](_0x435876);return _0x2311cb!==null?_0x2311cb['subtree'](b(_0x4c7911)):new S(null);}}['set'](_0x95830f,_0x4dcddd){if(v(_0x95830f))return new S(_0x4dcddd,this['children']);{const _0x4c4a2f=y(_0x95830f),_0x146c06=(this['children']['get'](_0x4c4a2f)||new S(null))['set'](b(_0x95830f),_0x4dcddd),_0x59ccf1=this['children']['insert'](_0x4c4a2f,_0x146c06);return new S(this['value'],_0x59ccf1);}}['remove'](_0x365fac){if(v(_0x365fac))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x123fd2=y(_0x365fac),_0x3a476f=this['children']['get'](_0x123fd2);if(_0x3a476f){const _0x47bff9=_0x3a476f['remove'](b(_0x365fac));let _0xb455c7;return _0x47bff9['isEmpty']()?_0xb455c7=this['children']['remove'](_0x123fd2):_0xb455c7=this['children']['insert'](_0x123fd2,_0x47bff9),this['value']===null&&_0xb455c7['isEmpty']()?new S(null):new S(this['value'],_0xb455c7);}else return this;}}['get'](_0x2156dd){if(v(_0x2156dd))return this['value'];{const _0x7a2e4c=y(_0x2156dd),_0x2093d8=this['children']['get'](_0x7a2e4c);return _0x2093d8?_0x2093d8['get'](b(_0x2156dd)):null;}}['setTree'](_0xb40b82,_0x2dca34){if(v(_0xb40b82))return _0x2dca34;{const _0x1006d8=y(_0xb40b82),_0x20f6a6=(this['children']['get'](_0x1006d8)||new S(null))['setTree'](b(_0xb40b82),_0x2dca34);let _0xa865da;return _0x20f6a6['isEmpty']()?_0xa865da=this['children']['remove'](_0x1006d8):_0xa865da=this['children']['insert'](_0x1006d8,_0x20f6a6),new S(this['value'],_0xa865da);}}['fold'](_0x1efa60){return this['fold_'](w(),_0x1efa60);}['fold_'](_0x1f5b0f,_0x4f4d1c){const _0x9a7a79={};return this['children']['inorderTraversal']((_0x408d90,_0x3bbea1)=>{_0x9a7a79[_0x408d90]=_0x3bbea1['fold_'](A(_0x1f5b0f,_0x408d90),_0x4f4d1c);}),_0x4f4d1c(_0x1f5b0f,this['value'],_0x9a7a79);}['findOnPath'](_0x5987e5,_0x45573d){return this['findOnPath_'](_0x5987e5,w(),_0x45573d);}['findOnPath_'](_0x1f8854,_0x2e68a5,_0x413162){const _0x598099=this['value']?_0x413162(_0x2e68a5,this['value']):!0x1;if(_0x598099)return _0x598099;if(v(_0x1f8854))return null;{const _0x336ea1=y(_0x1f8854),_0xfb4726=this['children']['get'](_0x336ea1);return _0xfb4726?_0xfb4726['findOnPath_'](b(_0x1f8854),A(_0x2e68a5,_0x336ea1),_0x413162):null;}}['foreachOnPath'](_0x50e93b,_0x22a2dc){return this['foreachOnPath_'](_0x50e93b,w(),_0x22a2dc);}['foreachOnPath_'](_0x5194da,_0x2dd4c2,_0x34ce17){if(v(_0x5194da))return this;{this['value']&&_0x34ce17(_0x2dd4c2,this['value']);const _0x4401ff=y(_0x5194da),_0x1fadba=this['children']['get'](_0x4401ff);return _0x1fadba?_0x1fadba['foreachOnPath_'](b(_0x5194da),A(_0x2dd4c2,_0x4401ff),_0x34ce17):new S(null);}}['foreach'](_0x3d5eca){this['foreach_'](w(),_0x3d5eca);}['foreach_'](_0x770afd,_0x2a73b7){this['children']['inorderTraversal']((_0x384d53,_0x3c6d66)=>{_0x3c6d66['foreach_'](A(_0x770afd,_0x384d53),_0x2a73b7);}),this['value']&&_0x2a73b7(_0x770afd,this['value']);}['foreachChild'](_0x2124d2){this['children']['inorderTraversal']((_0x1d6411,_0x4f9806)=>{_0x4f9806['value']&&_0x2124d2(_0x1d6411,_0x4f9806['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x3009b4){this['writeTree_']=_0x3009b4;}static['empty'](){return new j(new S(null));}}function Ct(_0x39dcc5,_0x1953e4,_0x52d3cb){if(v(_0x1953e4))return new j(new S(_0x52d3cb));{const _0x36777f=_0x39dcc5['writeTree_']['findRootMostValueAndPath'](_0x1953e4);if(_0x36777f!=null){const _0x5091ff=_0x36777f['path'];let _0x5221b2=_0x36777f['value'];const _0x27bce7=F(_0x5091ff,_0x1953e4);return _0x5221b2=_0x5221b2['updateChild'](_0x27bce7,_0x52d3cb),new j(_0x39dcc5['writeTree_']['set'](_0x5091ff,_0x5221b2));}else{const _0x5e9a13=new S(_0x52d3cb),_0x348abd=_0x39dcc5['writeTree_']['setTree'](_0x1953e4,_0x5e9a13);return new j(_0x348abd);}}}function Ii(_0x3d3b91,_0x1da2e7,_0x2e5bdc){let _0x4dd5ce=_0x3d3b91;return x(_0x2e5bdc,(_0x6d4a,_0x4e7b97)=>{_0x4dd5ce=Ct(_0x4dd5ce,A(_0x1da2e7,_0x6d4a),_0x4e7b97);}),_0x4dd5ce;}function sr(_0x2af449,_0x350385){if(v(_0x350385))return j['empty']();{const _0x53e352=_0x2af449['writeTree_']['setTree'](_0x350385,new S(null));return new j(_0x53e352);}}function wi(_0x2e75bd,_0x5ddcdf){return $e(_0x2e75bd,_0x5ddcdf)!=null;}function $e(_0x74ba3a,_0x97395a){const _0x37a8f2=_0x74ba3a['writeTree_']['findRootMostValueAndPath'](_0x97395a);return _0x37a8f2!=null?_0x74ba3a['writeTree_']['get'](_0x37a8f2['path'])['getChild'](F(_0x37a8f2['path'],_0x97395a)):null;}function rr(_0x21571b){const _0x93938d=[],_0x349e53=_0x21571b['writeTree_']['value'];return _0x349e53!=null?_0x349e53['isLeafNode']()||_0x349e53['forEachChild'](R,(_0x424aae,_0x28e65c)=>{_0x93938d['push'](new E(_0x424aae,_0x28e65c));}):_0x21571b['writeTree_']['children']['inorderTraversal']((_0x51d659,_0x17eeec)=>{_0x17eeec['value']!=null&&_0x93938d['push'](new E(_0x51d659,_0x17eeec['value']));}),_0x93938d;}function ve(_0x953b7,_0x2b5765){if(v(_0x2b5765))return _0x953b7;{const _0xa9aeae=$e(_0x953b7,_0x2b5765);return _0xa9aeae!=null?new j(new S(_0xa9aeae)):new j(_0x953b7['writeTree_']['subtree'](_0x2b5765));}}function Ci(_0x58ead7){return _0x58ead7['writeTree_']['isEmpty']();}function it(_0x2c1482,_0x5091bd){return xo(w(),_0x2c1482['writeTree_'],_0x5091bd);}function xo(_0x207680,_0x2bfda1,_0x134527){if(_0x2bfda1['value']!=null)return _0x134527['updateChild'](_0x207680,_0x2bfda1['value']);{let _0x25929d=null;return _0x2bfda1['children']['inorderTraversal']((_0xcfca4,_0x2d4ffb)=>{_0xcfca4==='.priority'?(f(_0x2d4ffb['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x25929d=_0x2d4ffb['value']):_0x134527=xo(A(_0x207680,_0xcfca4),_0x2d4ffb,_0x134527);}),!_0x134527['getChild'](_0x207680)['isEmpty']()&&_0x25929d!==null&&(_0x134527=_0x134527['updateChild'](A(_0x207680,'.priority'),_0x25929d)),_0x134527;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x28ce26,_0x5b2d61){return Bo(_0x5b2d61,_0x28ce26);}function ou(_0x5eb5ff,_0x4794cb,_0x454841,_0x97c6ec,_0x345b61){f(_0x97c6ec>_0x5eb5ff['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x345b61===void 0x0&&(_0x345b61=!0x0),_0x5eb5ff['allWrites']['push']({'path':_0x4794cb,'snap':_0x454841,'writeId':_0x97c6ec,'visible':_0x345b61}),_0x345b61&&(_0x5eb5ff['visibleWrites']=Ct(_0x5eb5ff['visibleWrites'],_0x4794cb,_0x454841)),_0x5eb5ff['lastWriteId']=_0x97c6ec;}function au(_0x4a3bdd,_0x322e68,_0x3f256b,_0x24846b){f(_0x24846b>_0x4a3bdd['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4a3bdd['allWrites']['push']({'path':_0x322e68,'children':_0x3f256b,'writeId':_0x24846b,'visible':!0x0}),_0x4a3bdd['visibleWrites']=Ii(_0x4a3bdd['visibleWrites'],_0x322e68,_0x3f256b),_0x4a3bdd['lastWriteId']=_0x24846b;}function cu(_0x48a012,_0x3d4e37){for(let _0x5a0d3a=0x0;_0x5a0d3a<_0x48a012['allWrites']['length'];_0x5a0d3a++){const _0x53eb6e=_0x48a012['allWrites'][_0x5a0d3a];if(_0x53eb6e['writeId']===_0x3d4e37)return _0x53eb6e;}return null;}function lu(_0x3d1614,_0x5737de){const _0x36ccf9=_0x3d1614['allWrites']['findIndex'](_0x236604=>_0x236604['writeId']===_0x5737de);f(_0x36ccf9>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x35c186=_0x3d1614['allWrites'][_0x36ccf9];_0x3d1614['allWrites']['splice'](_0x36ccf9,0x1);let _0x5c0303=_0x35c186['visible'],_0x3ff805=!0x1,_0x54f61e=_0x3d1614['allWrites']['length']-0x1;for(;_0x5c0303&&_0x54f61e>=0x0;){const _0x3f3caa=_0x3d1614['allWrites'][_0x54f61e];_0x3f3caa['visible']&&(_0x54f61e>=_0x36ccf9&&hu(_0x3f3caa,_0x35c186['path'])?_0x5c0303=!0x1:$(_0x35c186['path'],_0x3f3caa['path'])&&(_0x3ff805=!0x0)),_0x54f61e--;}if(_0x5c0303){if(_0x3ff805)return uu(_0x3d1614),!0x0;if(_0x35c186['snap'])_0x3d1614['visibleWrites']=sr(_0x3d1614['visibleWrites'],_0x35c186['path']);else{const _0x427fb0=_0x35c186['children'];x(_0x427fb0,_0x2153b4=>{_0x3d1614['visibleWrites']=sr(_0x3d1614['visibleWrites'],A(_0x35c186['path'],_0x2153b4));});}return!0x0;}else return!0x1;}function hu(_0x15d380,_0xa3b2b3){if(_0x15d380['snap'])return $(_0x15d380['path'],_0xa3b2b3);for(const _0x28530f in _0x15d380['children'])if(_0x15d380['children']['hasOwnProperty'](_0x28530f)&&$(A(_0x15d380['path'],_0x28530f),_0xa3b2b3))return!0x0;return!0x1;}function uu(_0x381530){_0x381530['visibleWrites']=Fo(_0x381530['allWrites'],du,w()),_0x381530['allWrites']['length']>0x0?_0x381530['lastWriteId']=_0x381530['allWrites'][_0x381530['allWrites']['length']-0x1]['writeId']:_0x381530['lastWriteId']=-0x1;}function du(_0x4cec90){return _0x4cec90['visible'];}function Fo(_0x367823,_0x1c9ec5,_0x172e93){let _0x2de612=j['empty']();for(let _0x37fa34=0x0;_0x37fa34<_0x367823['length'];++_0x37fa34){const _0x3a8982=_0x367823[_0x37fa34];if(_0x1c9ec5(_0x3a8982)){const _0x1e4da6=_0x3a8982['path'];let _0x1db6fa;if(_0x3a8982['snap'])$(_0x172e93,_0x1e4da6)?(_0x1db6fa=F(_0x172e93,_0x1e4da6),_0x2de612=Ct(_0x2de612,_0x1db6fa,_0x3a8982['snap'])):$(_0x1e4da6,_0x172e93)&&(_0x1db6fa=F(_0x1e4da6,_0x172e93),_0x2de612=Ct(_0x2de612,w(),_0x3a8982['snap']['getChild'](_0x1db6fa)));else{if(_0x3a8982['children']){if($(_0x172e93,_0x1e4da6))_0x1db6fa=F(_0x172e93,_0x1e4da6),_0x2de612=Ii(_0x2de612,_0x1db6fa,_0x3a8982['children']);else{if($(_0x1e4da6,_0x172e93)){if(_0x1db6fa=F(_0x1e4da6,_0x172e93),v(_0x1db6fa))_0x2de612=Ii(_0x2de612,w(),_0x3a8982['children']);else{const _0x3939dd=Oe(_0x3a8982['children'],y(_0x1db6fa));if(_0x3939dd){const _0x2070e2=_0x3939dd['getChild'](b(_0x1db6fa));_0x2de612=Ct(_0x2de612,w(),_0x2070e2);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2de612;}function Uo(_0x1f48ff,_0xca30d0,_0x3f8718,_0x264bd5,_0x3dfd1f){if(!_0x264bd5&&!_0x3dfd1f){const _0x482080=$e(_0x1f48ff['visibleWrites'],_0xca30d0);if(_0x482080!=null)return _0x482080;{const _0x13ce2b=ve(_0x1f48ff['visibleWrites'],_0xca30d0);if(Ci(_0x13ce2b))return _0x3f8718;if(_0x3f8718==null&&!wi(_0x13ce2b,w()))return null;{const _0x42c592=_0x3f8718||g['EMPTY_NODE'];return it(_0x13ce2b,_0x42c592);}}}else{const _0x57a561=ve(_0x1f48ff['visibleWrites'],_0xca30d0);if(!_0x3dfd1f&&Ci(_0x57a561))return _0x3f8718;if(!_0x3dfd1f&&_0x3f8718==null&&!wi(_0x57a561,w()))return null;{const _0x2dfb6a=function(_0x881067){return(_0x881067['visible']||_0x3dfd1f)&&(!_0x264bd5||!~_0x264bd5['indexOf'](_0x881067['writeId']))&&($(_0x881067['path'],_0xca30d0)||$(_0xca30d0,_0x881067['path']));},_0x4f3cbe=Fo(_0x1f48ff['allWrites'],_0x2dfb6a,_0xca30d0),_0x5952b7=_0x3f8718||g['EMPTY_NODE'];return it(_0x4f3cbe,_0x5952b7);}}}function fu(_0x301c89,_0x47f9ac,_0x4f3994){let _0xe5b5db=g['EMPTY_NODE'];const _0x5af1ef=$e(_0x301c89['visibleWrites'],_0x47f9ac);if(_0x5af1ef)return _0x5af1ef['isLeafNode']()||_0x5af1ef['forEachChild'](R,(_0x116cf4,_0x4e97de)=>{_0xe5b5db=_0xe5b5db['updateImmediateChild'](_0x116cf4,_0x4e97de);}),_0xe5b5db;if(_0x4f3994){const _0x51e8bb=ve(_0x301c89['visibleWrites'],_0x47f9ac);return _0x4f3994['forEachChild'](R,(_0x1ab5d9,_0x20241c)=>{const _0x7fac3c=it(ve(_0x51e8bb,new C(_0x1ab5d9)),_0x20241c);_0xe5b5db=_0xe5b5db['updateImmediateChild'](_0x1ab5d9,_0x7fac3c);}),rr(_0x51e8bb)['forEach'](_0xe15281=>{_0xe5b5db=_0xe5b5db['updateImmediateChild'](_0xe15281['name'],_0xe15281['node']);}),_0xe5b5db;}else{const _0x2d02bb=ve(_0x301c89['visibleWrites'],_0x47f9ac);return rr(_0x2d02bb)['forEach'](_0x3d3432=>{_0xe5b5db=_0xe5b5db['updateImmediateChild'](_0x3d3432['name'],_0x3d3432['node']);}),_0xe5b5db;}}function pu(_0x588a94,_0x179569,_0x412c7f,_0x463f11,_0x5c427d){f(_0x463f11||_0x5c427d,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x44a11b=A(_0x179569,_0x412c7f);if(wi(_0x588a94['visibleWrites'],_0x44a11b))return null;{const _0x2aced1=ve(_0x588a94['visibleWrites'],_0x44a11b);return Ci(_0x2aced1)?_0x5c427d['getChild'](_0x412c7f):it(_0x2aced1,_0x5c427d['getChild'](_0x412c7f));}}function _u(_0x2e9412,_0x53da4b,_0x28ea58,_0x233948){const _0x472d31=A(_0x53da4b,_0x28ea58),_0x4b5501=$e(_0x2e9412['visibleWrites'],_0x472d31);if(_0x4b5501!=null)return _0x4b5501;if(_0x233948['isCompleteForChild'](_0x28ea58)){const _0x30a67f=ve(_0x2e9412['visibleWrites'],_0x472d31);return it(_0x30a67f,_0x233948['getNode']()['getImmediateChild'](_0x28ea58));}else return null;}function gu(_0x388319,_0x52510a){return $e(_0x388319['visibleWrites'],_0x52510a);}function mu(_0x559e2a,_0x43658c,_0x4cb236,_0x5540ad,_0x4b853b,_0x4a9f65,_0x4f8e8b){let _0x5cdbda;const _0x142719=ve(_0x559e2a['visibleWrites'],_0x43658c),_0x32c5c9=$e(_0x142719,w());if(_0x32c5c9!=null)_0x5cdbda=_0x32c5c9;else{if(_0x4cb236!=null)_0x5cdbda=it(_0x142719,_0x4cb236);else return[];}if(_0x5cdbda=_0x5cdbda['withIndex'](_0x4f8e8b),!_0x5cdbda['isEmpty']()&&!_0x5cdbda['isLeafNode']()){const _0x48953d=[],_0x43894e=_0x4f8e8b['getCompare'](),_0x28de21=_0x4a9f65?_0x5cdbda['getReverseIteratorFrom'](_0x5540ad,_0x4f8e8b):_0x5cdbda['getIteratorFrom'](_0x5540ad,_0x4f8e8b);let _0x3b5e8d=_0x28de21['getNext']();for(;_0x3b5e8d&&_0x48953d['length']<_0x4b853b;)_0x43894e(_0x3b5e8d,_0x5540ad)!==0x0&&_0x48953d['push'](_0x3b5e8d),_0x3b5e8d=_0x28de21['getNext']();return _0x48953d;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x392cf0,_0x27b1e3,_0x4cc708,_0x50c0fa){return Uo(_0x392cf0['writeTree'],_0x392cf0['treePath'],_0x27b1e3,_0x4cc708,_0x50c0fa);}function es(_0x3da573,_0x2cd2b8){return fu(_0x3da573['writeTree'],_0x3da573['treePath'],_0x2cd2b8);}function or(_0x2229b7,_0x54a69b,_0x4e6d2b,_0x54092b){return pu(_0x2229b7['writeTree'],_0x2229b7['treePath'],_0x54a69b,_0x4e6d2b,_0x54092b);}function yn(_0x5dfeb1,_0x312c9d){return gu(_0x5dfeb1['writeTree'],A(_0x5dfeb1['treePath'],_0x312c9d));}function vu(_0x5248e8,_0x209ef3,_0x1af6ee,_0x2b7dac,_0x29bd49,_0x45ad86){return mu(_0x5248e8['writeTree'],_0x5248e8['treePath'],_0x209ef3,_0x1af6ee,_0x2b7dac,_0x29bd49,_0x45ad86);}function ts(_0x2617d0,_0x58c132,_0x33a4ef){return _u(_0x2617d0['writeTree'],_0x2617d0['treePath'],_0x58c132,_0x33a4ef);}function Wo(_0x1291c7,_0x5107ff){return Bo(A(_0x1291c7['treePath'],_0x5107ff),_0x1291c7['writeTree']);}function Bo(_0x4146d0,_0x4991b7){return{'treePath':_0x4146d0,'writeTree':_0x4991b7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x34cf3a){const _0x102041=_0x34cf3a['type'],_0x534a79=_0x34cf3a['childName'];f(_0x102041==='child_added'||_0x102041==='child_changed'||_0x102041==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x534a79!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x46e659=this['changeMap']['get'](_0x534a79);if(_0x46e659){const _0x59c464=_0x46e659['type'];if(_0x102041==='child_added'&&_0x59c464==='child_removed')this['changeMap']['set'](_0x534a79,Pt(_0x534a79,_0x34cf3a['snapshotNode'],_0x46e659['snapshotNode']));else{if(_0x102041==='child_removed'&&_0x59c464==='child_added')this['changeMap']['delete'](_0x534a79);else{if(_0x102041==='child_removed'&&_0x59c464==='child_changed')this['changeMap']['set'](_0x534a79,Nt(_0x534a79,_0x46e659['oldSnap']));else{if(_0x102041==='child_changed'&&_0x59c464==='child_added')this['changeMap']['set'](_0x534a79,tt(_0x534a79,_0x34cf3a['snapshotNode']));else{if(_0x102041==='child_changed'&&_0x59c464==='child_changed')this['changeMap']['set'](_0x534a79,Pt(_0x534a79,_0x34cf3a['snapshotNode'],_0x46e659['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0x34cf3a+'\x20occurred\x20after\x20'+_0x46e659);}}}}}else this['changeMap']['set'](_0x534a79,_0x34cf3a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x9ff5dd){return null;}['getChildAfterChild'](_0x463d85,_0x3d19e5,_0xb87920){return null;}}const Vo=new Iu();class ns{constructor(_0x27fc63,_0x210a37,_0x4cf1e6=null){this['writes_']=_0x27fc63,this['viewCache_']=_0x210a37,this['optCompleteServerCache_']=_0x4cf1e6;}['getCompleteChild'](_0xc077ba){const _0x4e0eaf=this['viewCache_']['eventCache'];if(_0x4e0eaf['isCompleteForChild'](_0xc077ba))return _0x4e0eaf['getNode']()['getImmediateChild'](_0xc077ba);{const _0x837bc3=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0xc077ba,_0x837bc3);}}['getChildAfterChild'](_0xbea522,_0x445601,_0x98e1f0){const _0x26f6dc=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x377eb2=vu(this['writes_'],_0x26f6dc,_0x445601,0x1,_0x98e1f0,_0xbea522);return _0x377eb2['length']===0x0?null:_0x377eb2[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x46eef8){return{'filter':_0x46eef8};}function Cu(_0x356b1a,_0x2d6d1b){f(_0x2d6d1b['eventCache']['getNode']()['isIndexed'](_0x356b1a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x2d6d1b['serverCache']['getNode']()['isIndexed'](_0x356b1a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x135497,_0x2fdd65,_0x1d1206,_0x5758d2,_0x20f586){const _0x443259=new Eu();let _0x352739,_0x2d5ab0;if(_0x1d1206['type']===q['OVERWRITE']){const _0x31c01e=_0x1d1206;_0x31c01e['source']['fromUser']?_0x352739=Ti(_0x135497,_0x2fdd65,_0x31c01e['path'],_0x31c01e['snap'],_0x5758d2,_0x20f586,_0x443259):(f(_0x31c01e['source']['fromServer'],'Unknown\x20source.'),_0x2d5ab0=_0x31c01e['source']['tagged']||_0x2fdd65['serverCache']['isFiltered']()&&!v(_0x31c01e['path']),_0x352739=vn(_0x135497,_0x2fdd65,_0x31c01e['path'],_0x31c01e['snap'],_0x5758d2,_0x20f586,_0x2d5ab0,_0x443259));}else{if(_0x1d1206['type']===q['MERGE']){const _0x1ee874=_0x1d1206;_0x1ee874['source']['fromUser']?_0x352739=bu(_0x135497,_0x2fdd65,_0x1ee874['path'],_0x1ee874['children'],_0x5758d2,_0x20f586,_0x443259):(f(_0x1ee874['source']['fromServer'],'Unknown\x20source.'),_0x2d5ab0=_0x1ee874['source']['tagged']||_0x2fdd65['serverCache']['isFiltered'](),_0x352739=Si(_0x135497,_0x2fdd65,_0x1ee874['path'],_0x1ee874['children'],_0x5758d2,_0x20f586,_0x2d5ab0,_0x443259));}else{if(_0x1d1206['type']===q['ACK_USER_WRITE']){const _0x460d69=_0x1d1206;_0x460d69['revert']?_0x352739=ku(_0x135497,_0x2fdd65,_0x460d69['path'],_0x5758d2,_0x20f586,_0x443259):_0x352739=Ru(_0x135497,_0x2fdd65,_0x460d69['path'],_0x460d69['affectedTree'],_0x5758d2,_0x20f586,_0x443259);}else{if(_0x1d1206['type']===q['LISTEN_COMPLETE'])_0x352739=Au(_0x135497,_0x2fdd65,_0x1d1206['path'],_0x5758d2,_0x443259);else throw ot('Unknown\x20operation\x20type:\x20'+_0x1d1206['type']);}}}const _0x4aa016=_0x443259['getChanges']();return Su(_0x2fdd65,_0x352739,_0x4aa016),{'viewCache':_0x352739,'changes':_0x4aa016};}function Su(_0x283eb6,_0x5610cf,_0x54ecf7){const _0x328563=_0x5610cf['eventCache'];if(_0x328563['isFullyInitialized']()){const _0x50c9f1=_0x328563['getNode']()['isLeafNode']()||_0x328563['getNode']()['isEmpty'](),_0x8da86c=gn(_0x283eb6);(_0x54ecf7['length']>0x0||!_0x283eb6['eventCache']['isFullyInitialized']()||_0x50c9f1&&!_0x328563['getNode']()['equals'](_0x8da86c)||!_0x328563['getNode']()['getPriority']()['equals'](_0x8da86c['getPriority']()))&&_0x54ecf7['push'](Oo(gn(_0x5610cf)));}}function Ho(_0x3f934f,_0x19d89a,_0x5f3c65,_0x5dfea9,_0x55a253,_0x5317cc){const _0x3d45bc=_0x19d89a['eventCache'];if(yn(_0x5dfea9,_0x5f3c65)!=null)return _0x19d89a;{let _0x5dcd36,_0x4767e4;if(v(_0x5f3c65)){if(f(_0x19d89a['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x19d89a['serverCache']['isFiltered']()){const _0x2c9694=Ue(_0x19d89a),_0x491293=_0x2c9694 instanceof g?_0x2c9694:g['EMPTY_NODE'],_0x98a10d=es(_0x5dfea9,_0x491293);_0x5dcd36=_0x3f934f['filter']['updateFullNode'](_0x19d89a['eventCache']['getNode'](),_0x98a10d,_0x5317cc);}else{const _0x4d7e4f=mn(_0x5dfea9,Ue(_0x19d89a));_0x5dcd36=_0x3f934f['filter']['updateFullNode'](_0x19d89a['eventCache']['getNode'](),_0x4d7e4f,_0x5317cc);}}else{const _0x524cc9=y(_0x5f3c65);if(_0x524cc9==='.priority'){f(we(_0x5f3c65)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4af260=_0x3d45bc['getNode']();_0x4767e4=_0x19d89a['serverCache']['getNode']();const _0x41f6a9=or(_0x5dfea9,_0x5f3c65,_0x4af260,_0x4767e4);_0x41f6a9!=null?_0x5dcd36=_0x3f934f['filter']['updatePriority'](_0x4af260,_0x41f6a9):_0x5dcd36=_0x3d45bc['getNode']();}else{const _0x48acbb=b(_0x5f3c65);let _0x56500f;if(_0x3d45bc['isCompleteForChild'](_0x524cc9)){_0x4767e4=_0x19d89a['serverCache']['getNode']();const _0x2449c4=or(_0x5dfea9,_0x5f3c65,_0x3d45bc['getNode'](),_0x4767e4);_0x2449c4!=null?_0x56500f=_0x3d45bc['getNode']()['getImmediateChild'](_0x524cc9)['updateChild'](_0x48acbb,_0x2449c4):_0x56500f=_0x3d45bc['getNode']()['getImmediateChild'](_0x524cc9);}else _0x56500f=ts(_0x5dfea9,_0x524cc9,_0x19d89a['serverCache']);_0x56500f!=null?_0x5dcd36=_0x3f934f['filter']['updateChild'](_0x3d45bc['getNode'](),_0x524cc9,_0x56500f,_0x48acbb,_0x55a253,_0x5317cc):_0x5dcd36=_0x3d45bc['getNode']();}}return wt(_0x19d89a,_0x5dcd36,_0x3d45bc['isFullyInitialized']()||v(_0x5f3c65),_0x3f934f['filter']['filtersNodes']());}}function vn(_0x2934e2,_0x56092b,_0x3bade5,_0x3e0cac,_0x4a5e0c,_0x2d045d,_0xe6663b,_0xab9d8b){const _0x33aec6=_0x56092b['serverCache'];let _0x268350;const _0x44b29d=_0xe6663b?_0x2934e2['filter']:_0x2934e2['filter']['getIndexedFilter']();if(v(_0x3bade5))_0x268350=_0x44b29d['updateFullNode'](_0x33aec6['getNode'](),_0x3e0cac,null);else{if(_0x44b29d['filtersNodes']()&&!_0x33aec6['isFiltered']()){const _0x190e32=_0x33aec6['getNode']()['updateChild'](_0x3bade5,_0x3e0cac);_0x268350=_0x44b29d['updateFullNode'](_0x33aec6['getNode'](),_0x190e32,null);}else{const _0x1122fc=y(_0x3bade5);if(!_0x33aec6['isCompleteForPath'](_0x3bade5)&&we(_0x3bade5)>0x1)return _0x56092b;const _0x1ac4a2=b(_0x3bade5),_0x13abcb=_0x33aec6['getNode']()['getImmediateChild'](_0x1122fc)['updateChild'](_0x1ac4a2,_0x3e0cac);_0x1122fc==='.priority'?_0x268350=_0x44b29d['updatePriority'](_0x33aec6['getNode'](),_0x13abcb):_0x268350=_0x44b29d['updateChild'](_0x33aec6['getNode'](),_0x1122fc,_0x13abcb,_0x1ac4a2,Vo,null);}}const _0x38334d=Lo(_0x56092b,_0x268350,_0x33aec6['isFullyInitialized']()||v(_0x3bade5),_0x44b29d['filtersNodes']()),_0x449b83=new ns(_0x4a5e0c,_0x38334d,_0x2d045d);return Ho(_0x2934e2,_0x38334d,_0x3bade5,_0x4a5e0c,_0x449b83,_0xab9d8b);}function Ti(_0x15f516,_0x105d36,_0x58c9f8,_0x1ffed4,_0x6c8bac,_0x4e95c0,_0x235cf4){const _0x1a499b=_0x105d36['eventCache'];let _0x15ad0a,_0x105f4a;const _0x5f0ff6=new ns(_0x6c8bac,_0x105d36,_0x4e95c0);if(v(_0x58c9f8))_0x105f4a=_0x15f516['filter']['updateFullNode'](_0x105d36['eventCache']['getNode'](),_0x1ffed4,_0x235cf4),_0x15ad0a=wt(_0x105d36,_0x105f4a,!0x0,_0x15f516['filter']['filtersNodes']());else{const _0x260cbe=y(_0x58c9f8);if(_0x260cbe==='.priority')_0x105f4a=_0x15f516['filter']['updatePriority'](_0x105d36['eventCache']['getNode'](),_0x1ffed4),_0x15ad0a=wt(_0x105d36,_0x105f4a,_0x1a499b['isFullyInitialized'](),_0x1a499b['isFiltered']());else{const _0x18093a=b(_0x58c9f8),_0x31f199=_0x1a499b['getNode']()['getImmediateChild'](_0x260cbe);let _0x1cf108;if(v(_0x18093a))_0x1cf108=_0x1ffed4;else{const _0x484550=_0x5f0ff6['getCompleteChild'](_0x260cbe);_0x484550!=null?Gi(_0x18093a)==='.priority'&&_0x484550['getChild'](To(_0x18093a))['isEmpty']()?_0x1cf108=_0x484550:_0x1cf108=_0x484550['updateChild'](_0x18093a,_0x1ffed4):_0x1cf108=g['EMPTY_NODE'];}if(_0x31f199['equals'](_0x1cf108))_0x15ad0a=_0x105d36;else{const _0x176d53=_0x15f516['filter']['updateChild'](_0x1a499b['getNode'](),_0x260cbe,_0x1cf108,_0x18093a,_0x5f0ff6,_0x235cf4);_0x15ad0a=wt(_0x105d36,_0x176d53,_0x1a499b['isFullyInitialized'](),_0x15f516['filter']['filtersNodes']());}}}return _0x15ad0a;}function ar(_0x380153,_0x91656e){return _0x380153['eventCache']['isCompleteForChild'](_0x91656e);}function bu(_0x1519b2,_0x257423,_0x30b7af,_0x584288,_0x8f03f3,_0x1d2ae0,_0x187b94){let _0x182266=_0x257423;return _0x584288['foreach']((_0x468421,_0x35b584)=>{const _0x2404d5=A(_0x30b7af,_0x468421);ar(_0x257423,y(_0x2404d5))&&(_0x182266=Ti(_0x1519b2,_0x182266,_0x2404d5,_0x35b584,_0x8f03f3,_0x1d2ae0,_0x187b94));}),_0x584288['foreach']((_0x1b485b,_0x48b2ff)=>{const _0x4dfa21=A(_0x30b7af,_0x1b485b);ar(_0x257423,y(_0x4dfa21))||(_0x182266=Ti(_0x1519b2,_0x182266,_0x4dfa21,_0x48b2ff,_0x8f03f3,_0x1d2ae0,_0x187b94));}),_0x182266;}function cr(_0x5cab7f,_0x4ac2f3,_0x353ce0){return _0x353ce0['foreach']((_0x15148e,_0x5a5e0e)=>{_0x4ac2f3=_0x4ac2f3['updateChild'](_0x15148e,_0x5a5e0e);}),_0x4ac2f3;}function Si(_0x5d28d7,_0x4b3318,_0x1772f7,_0x3cc761,_0x2b9be5,_0x4e1cde,_0x1996c8,_0x2ce173){if(_0x4b3318['serverCache']['getNode']()['isEmpty']()&&!_0x4b3318['serverCache']['isFullyInitialized']())return _0x4b3318;let _0x2ba6de=_0x4b3318,_0x16c2b7;v(_0x1772f7)?_0x16c2b7=_0x3cc761:_0x16c2b7=new S(null)['setTree'](_0x1772f7,_0x3cc761);const _0x272529=_0x4b3318['serverCache']['getNode']();return _0x16c2b7['children']['inorderTraversal']((_0x14b73d,_0x3a074e)=>{if(_0x272529['hasChild'](_0x14b73d)){const _0x219341=_0x4b3318['serverCache']['getNode']()['getImmediateChild'](_0x14b73d),_0x5a54d4=cr(_0x5d28d7,_0x219341,_0x3a074e);_0x2ba6de=vn(_0x5d28d7,_0x2ba6de,new C(_0x14b73d),_0x5a54d4,_0x2b9be5,_0x4e1cde,_0x1996c8,_0x2ce173);}}),_0x16c2b7['children']['inorderTraversal']((_0x3ddfbd,_0x7f4bba)=>{const _0x3be96b=!_0x4b3318['serverCache']['isCompleteForChild'](_0x3ddfbd)&&_0x7f4bba['value']===null;if(!_0x272529['hasChild'](_0x3ddfbd)&&!_0x3be96b){const _0x439511=_0x4b3318['serverCache']['getNode']()['getImmediateChild'](_0x3ddfbd),_0x20ade5=cr(_0x5d28d7,_0x439511,_0x7f4bba);_0x2ba6de=vn(_0x5d28d7,_0x2ba6de,new C(_0x3ddfbd),_0x20ade5,_0x2b9be5,_0x4e1cde,_0x1996c8,_0x2ce173);}}),_0x2ba6de;}function Ru(_0x350a35,_0x5952b1,_0x5e0e0b,_0xb80aef,_0x2aadc3,_0x5635eb,_0x3600c2){if(yn(_0x2aadc3,_0x5e0e0b)!=null)return _0x5952b1;const _0x4e698c=_0x5952b1['serverCache']['isFiltered'](),_0x5a517b=_0x5952b1['serverCache'];if(_0xb80aef['value']!=null){if(v(_0x5e0e0b)&&_0x5a517b['isFullyInitialized']()||_0x5a517b['isCompleteForPath'](_0x5e0e0b))return vn(_0x350a35,_0x5952b1,_0x5e0e0b,_0x5a517b['getNode']()['getChild'](_0x5e0e0b),_0x2aadc3,_0x5635eb,_0x4e698c,_0x3600c2);if(v(_0x5e0e0b)){let _0x22ed08=new S(null);return _0x5a517b['getNode']()['forEachChild'](ye,(_0x413e00,_0x20804a)=>{_0x22ed08=_0x22ed08['set'](new C(_0x413e00),_0x20804a);}),Si(_0x350a35,_0x5952b1,_0x5e0e0b,_0x22ed08,_0x2aadc3,_0x5635eb,_0x4e698c,_0x3600c2);}else return _0x5952b1;}else{let _0x410667=new S(null);return _0xb80aef['foreach']((_0x187a09,_0x1431ce)=>{const _0x122181=A(_0x5e0e0b,_0x187a09);_0x5a517b['isCompleteForPath'](_0x122181)&&(_0x410667=_0x410667['set'](_0x187a09,_0x5a517b['getNode']()['getChild'](_0x122181)));}),Si(_0x350a35,_0x5952b1,_0x5e0e0b,_0x410667,_0x2aadc3,_0x5635eb,_0x4e698c,_0x3600c2);}}function Au(_0x3d5e2b,_0x1a6871,_0x5d4ccc,_0x1b282c,_0x3b8f08){const _0x117c5d=_0x1a6871['serverCache'],_0x4db5a4=Lo(_0x1a6871,_0x117c5d['getNode'](),_0x117c5d['isFullyInitialized']()||v(_0x5d4ccc),_0x117c5d['isFiltered']());return Ho(_0x3d5e2b,_0x4db5a4,_0x5d4ccc,_0x1b282c,Vo,_0x3b8f08);}function ku(_0x20976f,_0x267d93,_0x5c3ad4,_0x279563,_0x5ac587,_0x12da19){let _0x12603d;if(yn(_0x279563,_0x5c3ad4)!=null)return _0x267d93;{const _0x107e5d=new ns(_0x279563,_0x267d93,_0x5ac587),_0x521c07=_0x267d93['eventCache']['getNode']();let _0x22bed0;if(v(_0x5c3ad4)||y(_0x5c3ad4)==='.priority'){let _0x2d3ae3;if(_0x267d93['serverCache']['isFullyInitialized']())_0x2d3ae3=mn(_0x279563,Ue(_0x267d93));else{const _0x22410e=_0x267d93['serverCache']['getNode']();f(_0x22410e instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2d3ae3=es(_0x279563,_0x22410e);}_0x2d3ae3=_0x2d3ae3,_0x22bed0=_0x20976f['filter']['updateFullNode'](_0x521c07,_0x2d3ae3,_0x12da19);}else{const _0x2086fa=y(_0x5c3ad4);let _0x3ad1a0=ts(_0x279563,_0x2086fa,_0x267d93['serverCache']);_0x3ad1a0==null&&_0x267d93['serverCache']['isCompleteForChild'](_0x2086fa)&&(_0x3ad1a0=_0x521c07['getImmediateChild'](_0x2086fa)),_0x3ad1a0!=null?_0x22bed0=_0x20976f['filter']['updateChild'](_0x521c07,_0x2086fa,_0x3ad1a0,b(_0x5c3ad4),_0x107e5d,_0x12da19):_0x267d93['eventCache']['getNode']()['hasChild'](_0x2086fa)?_0x22bed0=_0x20976f['filter']['updateChild'](_0x521c07,_0x2086fa,g['EMPTY_NODE'],b(_0x5c3ad4),_0x107e5d,_0x12da19):_0x22bed0=_0x521c07,_0x22bed0['isEmpty']()&&_0x267d93['serverCache']['isFullyInitialized']()&&(_0x12603d=mn(_0x279563,Ue(_0x267d93)),_0x12603d['isLeafNode']()&&(_0x22bed0=_0x20976f['filter']['updateFullNode'](_0x22bed0,_0x12603d,_0x12da19)));}return _0x12603d=_0x267d93['serverCache']['isFullyInitialized']()||yn(_0x279563,w())!=null,wt(_0x267d93,_0x22bed0,_0x12603d,_0x20976f['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x1ade01,_0x25d939){this['query_']=_0x1ade01,this['eventRegistrations_']=[];const _0xf461d6=this['query_']['_queryParams'],_0x594d1f=new Yi(_0xf461d6['getIndex']()),_0x477ffe=qh(_0xf461d6);this['processor_']=wu(_0x477ffe);const _0x2613dd=_0x25d939['serverCache'],_0x2c74de=_0x25d939['eventCache'],_0x1426f2=_0x594d1f['updateFullNode'](g['EMPTY_NODE'],_0x2613dd['getNode'](),null),_0x359294=_0x477ffe['updateFullNode'](g['EMPTY_NODE'],_0x2c74de['getNode'](),null),_0x20af29=new Ce(_0x1426f2,_0x2613dd['isFullyInitialized'](),_0x594d1f['filtersNodes']()),_0x22d21f=new Ce(_0x359294,_0x2c74de['isFullyInitialized'](),_0x477ffe['filtersNodes']());this['viewCache_']=Dn(_0x22d21f,_0x20af29),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x28735f){return _0x28735f['viewCache_']['serverCache']['getNode']();}function Ou(_0x1267e4){return gn(_0x1267e4['viewCache_']);}function Du(_0x1982f0,_0xfe4c05){const _0x339ba4=Ue(_0x1982f0['viewCache_']);return _0x339ba4&&(_0x1982f0['query']['_queryParams']['loadsAllData']()||!v(_0xfe4c05)&&!_0x339ba4['getImmediateChild'](y(_0xfe4c05))['isEmpty']())?_0x339ba4['getChild'](_0xfe4c05):null;}function lr(_0x5deac0){return _0x5deac0['eventRegistrations_']['length']===0x0;}function Mu(_0xd26b02,_0x5f5c46){_0xd26b02['eventRegistrations_']['push'](_0x5f5c46);}function hr(_0xd285f0,_0x428d99,_0x488dbb){const _0x24b483=[];if(_0x488dbb){f(_0x428d99==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x28e58e=_0xd285f0['query']['_path'];_0xd285f0['eventRegistrations_']['forEach'](_0x41df5b=>{const _0xdd3bd9=_0x41df5b['createCancelEvent'](_0x488dbb,_0x28e58e);_0xdd3bd9&&_0x24b483['push'](_0xdd3bd9);});}if(_0x428d99){let _0x4c0522=[];for(let _0x22ddde=0x0;_0x22ddde<_0xd285f0['eventRegistrations_']['length'];++_0x22ddde){const _0x4a0d78=_0xd285f0['eventRegistrations_'][_0x22ddde];if(!_0x4a0d78['matches'](_0x428d99))_0x4c0522['push'](_0x4a0d78);else{if(_0x428d99['hasAnyCallback']()){_0x4c0522=_0x4c0522['concat'](_0xd285f0['eventRegistrations_']['slice'](_0x22ddde+0x1));break;}}}_0xd285f0['eventRegistrations_']=_0x4c0522;}else _0xd285f0['eventRegistrations_']=[];return _0x24b483;}function ur(_0x1d212b,_0x30d5ab,_0x5dbe44,_0x1eef07){_0x30d5ab['type']===q['MERGE']&&_0x30d5ab['source']['queryId']!==null&&(f(Ue(_0x1d212b['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x1d212b['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x47b87e=_0x1d212b['viewCache_'],_0x28a52b=Tu(_0x1d212b['processor_'],_0x47b87e,_0x30d5ab,_0x5dbe44,_0x1eef07);return Cu(_0x1d212b['processor_'],_0x28a52b['viewCache']),f(_0x28a52b['viewCache']['serverCache']['isFullyInitialized']()||!_0x47b87e['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1d212b['viewCache_']=_0x28a52b['viewCache'],$o(_0x1d212b,_0x28a52b['changes'],_0x28a52b['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x3c59a3,_0x39a7aa){const _0x56e07d=_0x3c59a3['viewCache_']['eventCache'],_0x351513=[];return _0x56e07d['getNode']()['isLeafNode']()||_0x56e07d['getNode']()['forEachChild'](R,(_0x20b5dd,_0x1ecf51)=>{_0x351513['push'](tt(_0x20b5dd,_0x1ecf51));}),_0x56e07d['isFullyInitialized']()&&_0x351513['push'](Oo(_0x56e07d['getNode']())),$o(_0x3c59a3,_0x351513,_0x56e07d['getNode'](),_0x39a7aa);}function $o(_0x5d2b85,_0x2c07dc,_0x52478b,_0x459688){const _0x243817=_0x459688?[_0x459688]:_0x5d2b85['eventRegistrations_'];return nu(_0x5d2b85['eventGenerator_'],_0x2c07dc,_0x52478b,_0x243817);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x8f93cd){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x8f93cd;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x32cd94){return _0x32cd94['views']['size']===0x0;}function is(_0x3b5323,_0xda87dc,_0x389405,_0x258ab9){const _0x2e1892=_0xda87dc['source']['queryId'];if(_0x2e1892!==null){const _0x4cc6a1=_0x3b5323['views']['get'](_0x2e1892);return f(_0x4cc6a1!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x4cc6a1,_0xda87dc,_0x389405,_0x258ab9);}else{let _0xba8cea=[];for(const _0x59e796 of _0x3b5323['views']['values']())_0xba8cea=_0xba8cea['concat'](ur(_0x59e796,_0xda87dc,_0x389405,_0x258ab9));return _0xba8cea;}}function qo(_0x17c14a,_0x21c018,_0x48d6d8,_0x5dbf46,_0x3ad050){const _0x6ef5e1=_0x21c018['_queryIdentifier'],_0x3615f6=_0x17c14a['views']['get'](_0x6ef5e1);if(!_0x3615f6){let _0x25d2d3=mn(_0x48d6d8,_0x3ad050?_0x5dbf46:null),_0x389a13=!0x1;_0x25d2d3?_0x389a13=!0x0:_0x5dbf46 instanceof g?(_0x25d2d3=es(_0x48d6d8,_0x5dbf46),_0x389a13=!0x1):(_0x25d2d3=g['EMPTY_NODE'],_0x389a13=!0x1);const _0x54a8b2=Dn(new Ce(_0x25d2d3,_0x389a13,!0x1),new Ce(_0x5dbf46,_0x3ad050,!0x1));return new Nu(_0x21c018,_0x54a8b2);}return _0x3615f6;}function Wu(_0x1f2e95,_0x2ea09f,_0x431fd4,_0x2ce433,_0x24b2f0,_0x33d77b){const _0xa6f3bf=qo(_0x1f2e95,_0x2ea09f,_0x2ce433,_0x24b2f0,_0x33d77b);return _0x1f2e95['views']['has'](_0x2ea09f['_queryIdentifier'])||_0x1f2e95['views']['set'](_0x2ea09f['_queryIdentifier'],_0xa6f3bf),Mu(_0xa6f3bf,_0x431fd4),Lu(_0xa6f3bf,_0x431fd4);}function Bu(_0xb265c6,_0x3d170e,_0x559440,_0x5c0522){const _0x331c88=_0x3d170e['_queryIdentifier'],_0x50581f=[];let _0x413706=[];const _0x375748=Te(_0xb265c6);if(_0x331c88==='default'){for(const [_0x4d2396,_0x3d18d5]of _0xb265c6['views']['entries']())_0x413706=_0x413706['concat'](hr(_0x3d18d5,_0x559440,_0x5c0522)),lr(_0x3d18d5)&&(_0xb265c6['views']['delete'](_0x4d2396),_0x3d18d5['query']['_queryParams']['loadsAllData']()||_0x50581f['push'](_0x3d18d5['query']));}else{const _0x14d672=_0xb265c6['views']['get'](_0x331c88);_0x14d672&&(_0x413706=_0x413706['concat'](hr(_0x14d672,_0x559440,_0x5c0522)),lr(_0x14d672)&&(_0xb265c6['views']['delete'](_0x331c88),_0x14d672['query']['_queryParams']['loadsAllData']()||_0x50581f['push'](_0x14d672['query'])));}return _0x375748&&!Te(_0xb265c6)&&_0x50581f['push'](new(Fu())(_0x3d170e['_repo'],_0x3d170e['_path'])),{'removed':_0x50581f,'events':_0x413706};}function zo(_0x523c35){const _0x448963=[];for(const _0x1e90f4 of _0x523c35['views']['values']())_0x1e90f4['query']['_queryParams']['loadsAllData']()||_0x448963['push'](_0x1e90f4);return _0x448963;}function Ee(_0x48150d,_0x49b0dc){let _0x39ad2e=null;for(const _0x33c65f of _0x48150d['views']['values']())_0x39ad2e=_0x39ad2e||Du(_0x33c65f,_0x49b0dc);return _0x39ad2e;}function jo(_0x486e20,_0xd9dc33){if(_0xd9dc33['_queryParams']['loadsAllData']())return Ln(_0x486e20);{const _0x51a96f=_0xd9dc33['_queryIdentifier'];return _0x486e20['views']['get'](_0x51a96f);}}function Ko(_0xc49408,_0x41c3c0){return jo(_0xc49408,_0x41c3c0)!=null;}function Te(_0x862dc6){return Ln(_0x862dc6)!=null;}function Ln(_0x13a353){for(const _0x4147fa of _0x13a353['views']['values']())if(_0x4147fa['query']['_queryParams']['loadsAllData']())return _0x4147fa;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x17800f){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x17800f;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0xb0b935){this['listenProvider_']=_0xb0b935,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x2e1455,_0x44bd5b,_0x7f43bc,_0x52323e,_0x5d2845){return ou(_0x2e1455['pendingWriteTree_'],_0x44bd5b,_0x7f43bc,_0x52323e,_0x5d2845),_0x5d2845?ht(_0x2e1455,new Fe(Ji(),_0x44bd5b,_0x7f43bc)):[];}function Gu(_0x2d596b,_0x129299,_0x48e89e,_0x37b18d){au(_0x2d596b['pendingWriteTree_'],_0x129299,_0x48e89e,_0x37b18d);const _0x56287f=S['fromObject'](_0x48e89e);return ht(_0x2d596b,new nt(Ji(),_0x129299,_0x56287f));}function pe(_0x14a4cb,_0x1e3a3f,_0x3bd038=!0x1){const _0x28936d=cu(_0x14a4cb['pendingWriteTree_'],_0x1e3a3f);if(lu(_0x14a4cb['pendingWriteTree_'],_0x1e3a3f)){let _0x27c3a7=new S(null);return _0x28936d['snap']!=null?_0x27c3a7=_0x27c3a7['set'](w(),!0x0):x(_0x28936d['children'],_0x3d4d7c=>{_0x27c3a7=_0x27c3a7['set'](new C(_0x3d4d7c),!0x0);}),ht(_0x14a4cb,new _n(_0x28936d['path'],_0x27c3a7,_0x3bd038));}else return[];}function $t(_0x1dcc77,_0x466225,_0x1b4786){return ht(_0x1dcc77,new Fe(Xi(),_0x466225,_0x1b4786));}function qu(_0x5bf157,_0xda9d96,_0xf476d0){const _0x330d19=S['fromObject'](_0xf476d0);return ht(_0x5bf157,new nt(Xi(),_0xda9d96,_0x330d19));}function zu(_0x2f0b7b,_0x12b27a){return ht(_0x2f0b7b,new Dt(Xi(),_0x12b27a));}function ju(_0x1d1a91,_0x3ecfa1,_0x2f2c1d){const _0x26b76f=rs(_0x1d1a91,_0x2f2c1d);if(_0x26b76f){const _0x18caed=os(_0x26b76f),_0x7c953=_0x18caed['path'],_0x2ad00b=_0x18caed['queryId'],_0x2d5054=F(_0x7c953,_0x3ecfa1),_0x191bee=new Dt(Zi(_0x2ad00b),_0x2d5054);return as(_0x1d1a91,_0x7c953,_0x191bee);}else return[];}function wn(_0x4bccb5,_0x2f0a56,_0x5673cb,_0xc0e41,_0x2543ee=!0x1){const _0x3b4ec6=_0x2f0a56['_path'],_0x33dbe5=_0x4bccb5['syncPointTree_']['get'](_0x3b4ec6);let _0x358c10=[];if(_0x33dbe5&&(_0x2f0a56['_queryIdentifier']==='default'||Ko(_0x33dbe5,_0x2f0a56))){const _0x499645=Bu(_0x33dbe5,_0x2f0a56,_0x5673cb,_0xc0e41);Uu(_0x33dbe5)&&(_0x4bccb5['syncPointTree_']=_0x4bccb5['syncPointTree_']['remove'](_0x3b4ec6));const _0x26db99=_0x499645['removed'];if(_0x358c10=_0x499645['events'],!_0x2543ee){const _0x3aadca=_0x26db99['findIndex'](_0x34523c=>_0x34523c['_queryParams']['loadsAllData']())!==-0x1,_0x1f9c6b=_0x4bccb5['syncPointTree_']['findOnPath'](_0x3b4ec6,(_0x543180,_0x1bafd1)=>Te(_0x1bafd1));if(_0x3aadca&&!_0x1f9c6b){const _0x564b95=_0x4bccb5['syncPointTree_']['subtree'](_0x3b4ec6);if(!_0x564b95['isEmpty']()){const _0x553dea=Qu(_0x564b95);for(let _0x4db458=0x0;_0x4db458<_0x553dea['length'];++_0x4db458){const _0x31fc85=_0x553dea[_0x4db458],_0x7db285=_0x31fc85['query'],_0x1e5450=Xo(_0x4bccb5,_0x31fc85);_0x4bccb5['listenProvider_']['startListening'](Tt(_0x7db285),Mt(_0x4bccb5,_0x7db285),_0x1e5450['hashFn'],_0x1e5450['onComplete']);}}}!_0x1f9c6b&&_0x26db99['length']>0x0&&!_0xc0e41&&(_0x3aadca?_0x4bccb5['listenProvider_']['stopListening'](Tt(_0x2f0a56),null):_0x26db99['forEach'](_0x3994b2=>{const _0x42b91c=_0x4bccb5['queryToTagMap']['get'](Fn(_0x3994b2));_0x4bccb5['listenProvider_']['stopListening'](Tt(_0x3994b2),_0x42b91c);}));}Ju(_0x4bccb5,_0x26db99);}return _0x358c10;}function Yo(_0x4b1680,_0x3fac36,_0x408d32,_0x33698a){const _0x32f022=rs(_0x4b1680,_0x33698a);if(_0x32f022!=null){const _0x503aca=os(_0x32f022),_0x798e1d=_0x503aca['path'],_0xd872c2=_0x503aca['queryId'],_0x3c0dea=F(_0x798e1d,_0x3fac36),_0x3b647b=new Fe(Zi(_0xd872c2),_0x3c0dea,_0x408d32);return as(_0x4b1680,_0x798e1d,_0x3b647b);}else return[];}function Ku(_0x41edc1,_0x24ea93,_0x580f87,_0x13f97d){const _0x4e4ede=rs(_0x41edc1,_0x13f97d);if(_0x4e4ede){const _0x137caf=os(_0x4e4ede),_0x3b3414=_0x137caf['path'],_0x2bc328=_0x137caf['queryId'],_0x1f2cf3=F(_0x3b3414,_0x24ea93),_0x35610e=S['fromObject'](_0x580f87),_0x293041=new nt(Zi(_0x2bc328),_0x1f2cf3,_0x35610e);return as(_0x41edc1,_0x3b3414,_0x293041);}else return[];}function bi(_0x44fc91,_0x446add,_0x1a7f69,_0x547234=!0x1){const _0x2e0acc=_0x446add['_path'];let _0x37c37b=null,_0x2da78e=!0x1;_0x44fc91['syncPointTree_']['foreachOnPath'](_0x2e0acc,(_0x28075c,_0x5891c3)=>{const _0x37c06d=F(_0x28075c,_0x2e0acc);_0x37c37b=_0x37c37b||Ee(_0x5891c3,_0x37c06d),_0x2da78e=_0x2da78e||Te(_0x5891c3);});let _0x25ef01=_0x44fc91['syncPointTree_']['get'](_0x2e0acc);_0x25ef01?(_0x2da78e=_0x2da78e||Te(_0x25ef01),_0x37c37b=_0x37c37b||Ee(_0x25ef01,w())):(_0x25ef01=new Go(),_0x44fc91['syncPointTree_']=_0x44fc91['syncPointTree_']['set'](_0x2e0acc,_0x25ef01));let _0x5dd7a8;_0x37c37b!=null?_0x5dd7a8=!0x0:(_0x5dd7a8=!0x1,_0x37c37b=g['EMPTY_NODE'],_0x44fc91['syncPointTree_']['subtree'](_0x2e0acc)['foreachChild']((_0x5b94ea,_0x2830f7)=>{const _0x1f0188=Ee(_0x2830f7,w());_0x1f0188&&(_0x37c37b=_0x37c37b['updateImmediateChild'](_0x5b94ea,_0x1f0188));}));const _0x5816bc=Ko(_0x25ef01,_0x446add);if(!_0x5816bc&&!_0x446add['_queryParams']['loadsAllData']()){const _0x4c4d29=Fn(_0x446add);f(!_0x44fc91['queryToTagMap']['has'](_0x4c4d29),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x5a2a28=Xu();_0x44fc91['queryToTagMap']['set'](_0x4c4d29,_0x5a2a28),_0x44fc91['tagToQueryMap']['set'](_0x5a2a28,_0x4c4d29);}const _0x4d58b4=Mn(_0x44fc91['pendingWriteTree_'],_0x2e0acc);let _0x566964=Wu(_0x25ef01,_0x446add,_0x1a7f69,_0x4d58b4,_0x37c37b,_0x5dd7a8);if(!_0x5816bc&&!_0x2da78e&&!_0x547234){const _0x5f43b3=jo(_0x25ef01,_0x446add);_0x566964=_0x566964['concat'](Zu(_0x44fc91,_0x446add,_0x5f43b3));}return _0x566964;}function xn(_0x355900,_0x394ca5,_0x53c5bd){const _0x5e7486=_0x355900['pendingWriteTree_'],_0x199cbe=_0x355900['syncPointTree_']['findOnPath'](_0x394ca5,(_0x1c68e6,_0x4ab71b)=>{const _0x55dd84=F(_0x1c68e6,_0x394ca5),_0x327f62=Ee(_0x4ab71b,_0x55dd84);if(_0x327f62)return _0x327f62;});return Uo(_0x5e7486,_0x394ca5,_0x199cbe,_0x53c5bd,!0x0);}function Yu(_0x53ec25,_0x434d27){const _0xf793ad=_0x434d27['_path'];let _0x22c067=null;_0x53ec25['syncPointTree_']['foreachOnPath'](_0xf793ad,(_0xab091c,_0x19d488)=>{const _0x38caca=F(_0xab091c,_0xf793ad);_0x22c067=_0x22c067||Ee(_0x19d488,_0x38caca);});let _0x493de8=_0x53ec25['syncPointTree_']['get'](_0xf793ad);_0x493de8?_0x22c067=_0x22c067||Ee(_0x493de8,w()):(_0x493de8=new Go(),_0x53ec25['syncPointTree_']=_0x53ec25['syncPointTree_']['set'](_0xf793ad,_0x493de8));const _0x5a508e=_0x22c067!=null,_0x5c8a3b=_0x5a508e?new Ce(_0x22c067,!0x0,!0x1):null,_0x1aa6ff=Mn(_0x53ec25['pendingWriteTree_'],_0x434d27['_path']),_0x3b2534=qo(_0x493de8,_0x434d27,_0x1aa6ff,_0x5a508e?_0x5c8a3b['getNode']():g['EMPTY_NODE'],_0x5a508e);return Ou(_0x3b2534);}function ht(_0x1aded1,_0x5a1b11){return Qo(_0x5a1b11,_0x1aded1['syncPointTree_'],null,Mn(_0x1aded1['pendingWriteTree_'],w()));}function Qo(_0x47252b,_0x57c0e4,_0x1ed6fb,_0x26045b){if(v(_0x47252b['path']))return Jo(_0x47252b,_0x57c0e4,_0x1ed6fb,_0x26045b);{const _0x42d53c=_0x57c0e4['get'](w());_0x1ed6fb==null&&_0x42d53c!=null&&(_0x1ed6fb=Ee(_0x42d53c,w()));let _0x12d08a=[];const _0x204212=y(_0x47252b['path']),_0xb7051=_0x47252b['operationForChild'](_0x204212),_0x5d89e2=_0x57c0e4['children']['get'](_0x204212);if(_0x5d89e2&&_0xb7051){const _0x325c95=_0x1ed6fb?_0x1ed6fb['getImmediateChild'](_0x204212):null,_0x1a9c49=Wo(_0x26045b,_0x204212);_0x12d08a=_0x12d08a['concat'](Qo(_0xb7051,_0x5d89e2,_0x325c95,_0x1a9c49));}return _0x42d53c&&(_0x12d08a=_0x12d08a['concat'](is(_0x42d53c,_0x47252b,_0x26045b,_0x1ed6fb))),_0x12d08a;}}function Jo(_0xbb7b23,_0x44acc1,_0x29d4da,_0x3bc63f){const _0x358a5c=_0x44acc1['get'](w());_0x29d4da==null&&_0x358a5c!=null&&(_0x29d4da=Ee(_0x358a5c,w()));let _0x1bc26a=[];return _0x44acc1['children']['inorderTraversal']((_0x41ef4f,_0x5cc2a8)=>{const _0x1e7ac1=_0x29d4da?_0x29d4da['getImmediateChild'](_0x41ef4f):null,_0x2381cf=Wo(_0x3bc63f,_0x41ef4f),_0x5bd65f=_0xbb7b23['operationForChild'](_0x41ef4f);_0x5bd65f&&(_0x1bc26a=_0x1bc26a['concat'](Jo(_0x5bd65f,_0x5cc2a8,_0x1e7ac1,_0x2381cf)));}),_0x358a5c&&(_0x1bc26a=_0x1bc26a['concat'](is(_0x358a5c,_0xbb7b23,_0x3bc63f,_0x29d4da))),_0x1bc26a;}function Xo(_0x4959ff,_0x3f94cd){const _0x45218f=_0x3f94cd['query'],_0x2340f4=Mt(_0x4959ff,_0x45218f);return{'hashFn':()=>(Pu(_0x3f94cd)||g['EMPTY_NODE'])['hash'](),'onComplete':_0xe746c5=>{if(_0xe746c5==='ok')return _0x2340f4?ju(_0x4959ff,_0x45218f['_path'],_0x2340f4):zu(_0x4959ff,_0x45218f['_path']);{const _0x5e52f8=ql(_0xe746c5,_0x45218f);return wn(_0x4959ff,_0x45218f,null,_0x5e52f8);}}};}function Mt(_0x347f9e,_0x4d28ee){const _0x128e22=Fn(_0x4d28ee);return _0x347f9e['queryToTagMap']['get'](_0x128e22);}function Fn(_0x4a3cfc){return _0x4a3cfc['_path']['toString']()+'$'+_0x4a3cfc['_queryIdentifier'];}function rs(_0xfadeb3,_0x2044e9){return _0xfadeb3['tagToQueryMap']['get'](_0x2044e9);}function os(_0x5b33e5){const _0x1bd20e=_0x5b33e5['indexOf']('$');return f(_0x1bd20e!==-0x1&&_0x1bd20e<_0x5b33e5['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5b33e5['substr'](_0x1bd20e+0x1),'path':new C(_0x5b33e5['substr'](0x0,_0x1bd20e))};}function as(_0x3d2955,_0x46dfb5,_0x382afe){const _0x3d8770=_0x3d2955['syncPointTree_']['get'](_0x46dfb5);f(_0x3d8770,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x321d79=Mn(_0x3d2955['pendingWriteTree_'],_0x46dfb5);return is(_0x3d8770,_0x382afe,_0x321d79,null);}function Qu(_0x503847){return _0x503847['fold']((_0x1a2b38,_0x35b98e,_0x4b2100)=>{if(_0x35b98e&&Te(_0x35b98e))return[Ln(_0x35b98e)];{let _0x5d174f=[];return _0x35b98e&&(_0x5d174f=zo(_0x35b98e)),x(_0x4b2100,(_0x1fbabe,_0x20f43a)=>{_0x5d174f=_0x5d174f['concat'](_0x20f43a);}),_0x5d174f;}});}function Tt(_0x4564aa){return _0x4564aa['_queryParams']['loadsAllData']()&&!_0x4564aa['_queryParams']['isDefault']()?new(Hu())(_0x4564aa['_repo'],_0x4564aa['_path']):_0x4564aa;}function Ju(_0x2fa55d,_0x4938f0){for(let _0x1a1cf1=0x0;_0x1a1cf1<_0x4938f0['length'];++_0x1a1cf1){const _0x32a8bb=_0x4938f0[_0x1a1cf1];if(!_0x32a8bb['_queryParams']['loadsAllData']()){const _0x4a770b=Fn(_0x32a8bb),_0xe0f75=_0x2fa55d['queryToTagMap']['get'](_0x4a770b);_0x2fa55d['queryToTagMap']['delete'](_0x4a770b),_0x2fa55d['tagToQueryMap']['delete'](_0xe0f75);}}}function Xu(){return $u++;}function Zu(_0x4b2b97,_0x383ce6,_0x547319){const _0x5da1b7=_0x383ce6['_path'],_0x173ea6=Mt(_0x4b2b97,_0x383ce6),_0x38adc0=Xo(_0x4b2b97,_0x547319),_0x1151e8=_0x4b2b97['listenProvider_']['startListening'](Tt(_0x383ce6),_0x173ea6,_0x38adc0['hashFn'],_0x38adc0['onComplete']),_0x321127=_0x4b2b97['syncPointTree_']['subtree'](_0x5da1b7);if(_0x173ea6)f(!Te(_0x321127['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x18194f=_0x321127['fold']((_0x48a9f6,_0x28b3a,_0x107125)=>{if(!v(_0x48a9f6)&&_0x28b3a&&Te(_0x28b3a))return[Ln(_0x28b3a)['query']];{let _0xbe94fc=[];return _0x28b3a&&(_0xbe94fc=_0xbe94fc['concat'](zo(_0x28b3a)['map'](_0x54564b=>_0x54564b['query']))),x(_0x107125,(_0x332442,_0x5e6837)=>{_0xbe94fc=_0xbe94fc['concat'](_0x5e6837);}),_0xbe94fc;}});for(let _0xb3ae69=0x0;_0xb3ae69<_0x18194f['length'];++_0xb3ae69){const _0x18d725=_0x18194f[_0xb3ae69];_0x4b2b97['listenProvider_']['stopListening'](Tt(_0x18d725),Mt(_0x4b2b97,_0x18d725));}}return _0x1151e8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x1d5319){this['node_']=_0x1d5319;}['getImmediateChild'](_0x279491){const _0x46ad43=this['node_']['getImmediateChild'](_0x279491);return new cs(_0x46ad43);}['node'](){return this['node_'];}}class ls{constructor(_0x53412e,_0x323112){this['syncTree_']=_0x53412e,this['path_']=_0x323112;}['getImmediateChild'](_0x43387b){const _0x33b61f=A(this['path_'],_0x43387b);return new ls(this['syncTree_'],_0x33b61f);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x4d4504){return _0x4d4504=_0x4d4504||{},_0x4d4504['timestamp']=_0x4d4504['timestamp']||new Date()['getTime'](),_0x4d4504;},fr=function(_0x144e5e,_0x2d375f,_0x5455c3){if(!_0x144e5e||typeof _0x144e5e!='object')return _0x144e5e;if(f('.sv'in _0x144e5e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x144e5e['.sv']=='string')return td(_0x144e5e['.sv'],_0x2d375f,_0x5455c3);if(typeof _0x144e5e['.sv']=='object')return nd(_0x144e5e['.sv'],_0x2d375f);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x144e5e,null,0x2));},td=function(_0xb8426c,_0x470c6f,_0x1fb805){switch(_0xb8426c){case'timestamp':return _0x1fb805['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0xb8426c);}},nd=function(_0x54544d,_0x3db672,_0x574c6d){_0x54544d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x54544d,null,0x2));const _0x3c2485=_0x54544d['increment'];typeof _0x3c2485!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3c2485);const _0x2e2eb2=_0x3db672['node']();if(f(_0x2e2eb2!==null&&typeof _0x2e2eb2<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2e2eb2['isLeafNode']())return _0x3c2485;const _0x5b0994=_0x2e2eb2['getValue']();return typeof _0x5b0994!='number'?_0x3c2485:_0x5b0994+_0x3c2485;},Zo=function(_0x592b1b,_0x552d39,_0xb34afd,_0x340318){return us(_0x552d39,new ls(_0xb34afd,_0x592b1b),_0x340318);},hs=function(_0x5ebbe1,_0x4261d4,_0x1be216){return us(_0x5ebbe1,new cs(_0x4261d4),_0x1be216);};function us(_0x141bec,_0x4b15cc,_0x44d2cc){const _0x37838d=_0x141bec['getPriority']()['val'](),_0x1a5744=fr(_0x37838d,_0x4b15cc['getImmediateChild']('.priority'),_0x44d2cc);let _0xa018b5;if(_0x141bec['isLeafNode']()){const _0x381123=_0x141bec,_0xd4e572=fr(_0x381123['getValue'](),_0x4b15cc,_0x44d2cc);return _0xd4e572!==_0x381123['getValue']()||_0x1a5744!==_0x381123['getPriority']()['val']()?new D(_0xd4e572,N(_0x1a5744)):_0x141bec;}else{const _0x183aae=_0x141bec;return _0xa018b5=_0x183aae,_0x1a5744!==_0x183aae['getPriority']()['val']()&&(_0xa018b5=_0xa018b5['updatePriority'](new D(_0x1a5744))),_0x183aae['forEachChild'](R,(_0x2dc216,_0x3cb8e9)=>{const _0x1ceaf0=us(_0x3cb8e9,_0x4b15cc['getImmediateChild'](_0x2dc216),_0x44d2cc);_0x1ceaf0!==_0x3cb8e9&&(_0xa018b5=_0xa018b5['updateImmediateChild'](_0x2dc216,_0x1ceaf0));}),_0xa018b5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x47b482='',_0xb3b268=null,_0x40b52d={'children':{},'childCount':0x0}){this['name']=_0x47b482,this['parent']=_0xb3b268,this['node']=_0x40b52d;}}function Un(_0x1c449f,_0x2f06d2){let _0x4c41ed=_0x2f06d2 instanceof C?_0x2f06d2:new C(_0x2f06d2),_0x594ba3=_0x1c449f,_0x39833c=y(_0x4c41ed);for(;_0x39833c!==null;){const _0x6e2ac2=Oe(_0x594ba3['node']['children'],_0x39833c)||{'children':{},'childCount':0x0};_0x594ba3=new ds(_0x39833c,_0x594ba3,_0x6e2ac2),_0x4c41ed=b(_0x4c41ed),_0x39833c=y(_0x4c41ed);}return _0x594ba3;}function Ge(_0x54b6d6){return _0x54b6d6['node']['value'];}function fs(_0x36e4fe,_0x507e3c){_0x36e4fe['node']['value']=_0x507e3c,Ri(_0x36e4fe);}function ea(_0x454ff6){return _0x454ff6['node']['childCount']>0x0;}function id(_0x41e24b){return Ge(_0x41e24b)===void 0x0&&!ea(_0x41e24b);}function Wn(_0x24582d,_0x45015f){x(_0x24582d['node']['children'],(_0x210829,_0x426dc8)=>{_0x45015f(new ds(_0x210829,_0x24582d,_0x426dc8));});}function ta(_0x404053,_0x5d4d40,_0x2b1bd7,_0x28b4fd){_0x2b1bd7&&_0x5d4d40(_0x404053),Wn(_0x404053,_0x3cad37=>{ta(_0x3cad37,_0x5d4d40,!0x0);});}function sd(_0x452ec6,_0x3ac198,_0x3dc81a){let _0x1c451e=_0x452ec6['parent'];for(;_0x1c451e!==null;){if(_0x3ac198(_0x1c451e))return!0x0;_0x1c451e=_0x1c451e['parent'];}return!0x1;}function Gt(_0x5812aa){return new C(_0x5812aa['parent']===null?_0x5812aa['name']:Gt(_0x5812aa['parent'])+'/'+_0x5812aa['name']);}function Ri(_0x41526a){_0x41526a['parent']!==null&&rd(_0x41526a['parent'],_0x41526a['name'],_0x41526a);}function rd(_0x3510ba,_0x2ab44d,_0x3d9805){const _0x52041c=id(_0x3d9805),_0x3b1607=Y(_0x3510ba['node']['children'],_0x2ab44d);_0x52041c&&_0x3b1607?(delete _0x3510ba['node']['children'][_0x2ab44d],_0x3510ba['node']['childCount']--,Ri(_0x3510ba)):!_0x52041c&&!_0x3b1607&&(_0x3510ba['node']['children'][_0x2ab44d]=_0x3d9805['node'],_0x3510ba['node']['childCount']++,Ri(_0x3510ba));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x3381a6){return typeof _0x3381a6=='string'&&_0x3381a6['length']!==0x0&&!od['test'](_0x3381a6);},na=function(_0x10ed05){return typeof _0x10ed05=='string'&&_0x10ed05['length']!==0x0&&!ad['test'](_0x10ed05);},cd=function(_0xce65c4){return _0xce65c4&&(_0xce65c4=_0xce65c4['replace'](/^\/*\.info(\/|$)/,'/')),na(_0xce65c4);},Cn=function(_0x568d09){return _0x568d09===null||typeof _0x568d09=='string'||typeof _0x568d09=='number'&&!Wi(_0x568d09)||_0x568d09&&typeof _0x568d09=='object'&&Y(_0x568d09,'.sv');},qt=function(_0x1a8a75,_0x2c9176,_0x84a468,_0x19ee49){_0x19ee49&&_0x2c9176===void 0x0||zt(Nn(_0x1a8a75,'value'),_0x2c9176,_0x84a468);},zt=function(_0x204606,_0x173d0a,_0x24a38a){const _0x38a74d=_0x24a38a instanceof C?new Sh(_0x24a38a,_0x204606):_0x24a38a;if(_0x173d0a===void 0x0)throw new Error(_0x204606+'contains\x20undefined\x20'+Ne(_0x38a74d));if(typeof _0x173d0a=='function')throw new Error(_0x204606+'contains\x20a\x20function\x20'+Ne(_0x38a74d)+'\x20with\x20contents\x20=\x20'+_0x173d0a['toString']());if(Wi(_0x173d0a))throw new Error(_0x204606+'contains\x20'+_0x173d0a['toString']()+'\x20'+Ne(_0x38a74d));if(typeof _0x173d0a=='string'&&_0x173d0a['length']>oi/0x3&&Pn(_0x173d0a)>oi)throw new Error(_0x204606+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x38a74d)+'\x20(\x27'+_0x173d0a['substring'](0x0,0x32)+'...\x27)');if(_0x173d0a&&typeof _0x173d0a=='object'){let _0xc1ce9d=!0x1,_0x4b319b=!0x1;if(x(_0x173d0a,(_0x2b583e,_0x179c5d)=>{if(_0x2b583e==='.value')_0xc1ce9d=!0x0;else{if(_0x2b583e!=='.priority'&&_0x2b583e!=='.sv'&&(_0x4b319b=!0x0,!ps(_0x2b583e)))throw new Error(_0x204606+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2b583e+')\x20'+Ne(_0x38a74d)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x38a74d,_0x2b583e),zt(_0x204606,_0x179c5d,_0x38a74d),Rh(_0x38a74d);}),_0xc1ce9d&&_0x4b319b)throw new Error(_0x204606+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x38a74d)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0xf14df3,_0x2f7cf3){let _0x11283c,_0x32ca9a;for(_0x11283c=0x0;_0x11283c<_0x2f7cf3['length'];_0x11283c++){_0x32ca9a=_0x2f7cf3[_0x11283c];const _0x50048c=kt(_0x32ca9a);for(let _0xe84868=0x0;_0xe84868<_0x50048c['length'];_0xe84868++)if(!(_0x50048c[_0xe84868]==='.priority'&&_0xe84868===_0x50048c['length']-0x1)){if(!ps(_0x50048c[_0xe84868]))throw new Error(_0xf14df3+'contains\x20an\x20invalid\x20key\x20('+_0x50048c[_0xe84868]+')\x20in\x20path\x20'+_0x32ca9a['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2f7cf3['sort'](Th);let _0x42c814=null;for(_0x11283c=0x0;_0x11283c<_0x2f7cf3['length'];_0x11283c++){if(_0x32ca9a=_0x2f7cf3[_0x11283c],_0x42c814!==null&&$(_0x42c814,_0x32ca9a))throw new Error(_0xf14df3+'contains\x20a\x20path\x20'+_0x42c814['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x32ca9a['toString']());_0x42c814=_0x32ca9a;}},hd=function(_0x491e89,_0x5f38cd,_0x43adeb,_0x47698e){const _0x448cb6=Nn(_0x491e89,'values');if(!(_0x5f38cd&&typeof _0x5f38cd=='object')||Array['isArray'](_0x5f38cd))throw new Error(_0x448cb6+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3a679b=[];x(_0x5f38cd,(_0xda2aec,_0x2ba801)=>{const _0x20c52e=new C(_0xda2aec);if(zt(_0x448cb6,_0x2ba801,A(_0x43adeb,_0x20c52e)),Gi(_0x20c52e)==='.priority'&&!Cn(_0x2ba801))throw new Error(_0x448cb6+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x20c52e['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3a679b['push'](_0x20c52e);}),ld(_0x448cb6,_0x3a679b);},_s=function(_0x185ebd,_0x2d86c1,_0x30e2a5,_0x574aa9){if(!na(_0x30e2a5))throw new Error(Nn(_0x185ebd,_0x2d86c1)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x30e2a5+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x5698b4,_0x3eaa26,_0x308646,_0x319ed9){_0x308646&&(_0x308646=_0x308646['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x5698b4,_0x3eaa26,_0x308646);},gs=function(_0x40d6d0,_0x58e133){if(y(_0x58e133)==='.info')throw new Error(_0x40d6d0+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0xe570ab,_0x51c4d4){const _0x2329a5=_0x51c4d4['path']['toString']();if(typeof _0x51c4d4['repoInfo']['host']!='string'||_0x51c4d4['repoInfo']['host']['length']===0x0||!ps(_0x51c4d4['repoInfo']['namespace'])&&_0x51c4d4['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2329a5['length']!==0x0&&!cd(_0x2329a5))throw new Error(Nn(_0xe570ab,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x5d1d2c,_0x5319d6){let _0x3658c0=null;for(let _0x1c6289=0x0;_0x1c6289<_0x5319d6['length'];_0x1c6289++){const _0x152bfc=_0x5319d6[_0x1c6289],_0x54235b=_0x152bfc['getPath']();_0x3658c0!==null&&!qi(_0x54235b,_0x3658c0['path'])&&(_0x5d1d2c['eventLists_']['push'](_0x3658c0),_0x3658c0=null),_0x3658c0===null&&(_0x3658c0={'events':[],'path':_0x54235b}),_0x3658c0['events']['push'](_0x152bfc);}_0x3658c0&&_0x5d1d2c['eventLists_']['push'](_0x3658c0);}function ia(_0x30290f,_0x260b4f,_0x610ee6){Bn(_0x30290f,_0x610ee6),sa(_0x30290f,_0x333150=>qi(_0x333150,_0x260b4f));}function V(_0xf6149c,_0x1da043,_0x208533){Bn(_0xf6149c,_0x208533),sa(_0xf6149c,_0x3445d3=>$(_0x3445d3,_0x1da043)||$(_0x1da043,_0x3445d3));}function sa(_0x480c65,_0x23e637){_0x480c65['recursionDepth_']++;let _0x43ccc9=!0x0;for(let _0x240eee=0x0;_0x240eee<_0x480c65['eventLists_']['length'];_0x240eee++){const _0x45a553=_0x480c65['eventLists_'][_0x240eee];if(_0x45a553){const _0xc5b04=_0x45a553['path'];_0x23e637(_0xc5b04)?(pd(_0x480c65['eventLists_'][_0x240eee]),_0x480c65['eventLists_'][_0x240eee]=null):_0x43ccc9=!0x1;}}_0x43ccc9&&(_0x480c65['eventLists_']=[]),_0x480c65['recursionDepth_']--;}function pd(_0x58df99){for(let _0x216e5e=0x0;_0x216e5e<_0x58df99['events']['length'];_0x216e5e++){const _0x4e27c1=_0x58df99['events'][_0x216e5e];if(_0x4e27c1!==null){_0x58df99['events'][_0x216e5e]=null;const _0x17407d=_0x4e27c1['getEventRunner']();Et&&L('event:\x20'+_0x4e27c1['toString']()),lt(_0x17407d);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x1bbbef,_0x26f727,_0x349e11,_0x44434a){this['repoInfo_']=_0x1bbbef,this['forceRestClient_']=_0x26f727,this['authTokenProvider_']=_0x349e11,this['appCheckProvider_']=_0x44434a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x49fbb1,_0x210413,_0x2a830f){if(_0x49fbb1['stats_']=Hi(_0x49fbb1['repoInfo_']),_0x49fbb1['forceRestClient_']||Yl())_0x49fbb1['server_']=new fn(_0x49fbb1['repoInfo_'],(_0x362a81,_0x62a74,_0x3b4b64,_0x48b5e1)=>{pr(_0x49fbb1,_0x362a81,_0x62a74,_0x3b4b64,_0x48b5e1);},_0x49fbb1['authTokenProvider_'],_0x49fbb1['appCheckProvider_']),setTimeout(()=>_r(_0x49fbb1,!0x0),0x0);else{if(typeof _0x2a830f<'u'&&_0x2a830f!==null){if(typeof _0x2a830f!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2a830f);}catch(_0x1214d9){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x1214d9);}}_0x49fbb1['persistentConnection_']=new ie(_0x49fbb1['repoInfo_'],_0x210413,(_0x384151,_0x1af22d,_0x49f02b,_0x1d186b)=>{pr(_0x49fbb1,_0x384151,_0x1af22d,_0x49f02b,_0x1d186b);},_0x100876=>{_r(_0x49fbb1,_0x100876);},_0xbf3a58=>{yd(_0x49fbb1,_0xbf3a58);},_0x49fbb1['authTokenProvider_'],_0x49fbb1['appCheckProvider_'],_0x2a830f),_0x49fbb1['server_']=_0x49fbb1['persistentConnection_'];}_0x49fbb1['authTokenProvider_']['addTokenChangeListener'](_0x3121fa=>{_0x49fbb1['server_']['refreshAuthToken'](_0x3121fa);}),_0x49fbb1['appCheckProvider_']['addTokenChangeListener'](_0x3bfffe=>{_0x49fbb1['server_']['refreshAppCheckToken'](_0x3bfffe['token']);}),_0x49fbb1['statsReporter_']=eh(_0x49fbb1['repoInfo_'],()=>new eu(_0x49fbb1['stats_'],_0x49fbb1['server_'])),_0x49fbb1['infoData_']=new Yh(),_0x49fbb1['infoSyncTree_']=new dr({'startListening':(_0x129d30,_0x267d54,_0x2260e6,_0x2abd98)=>{let _0x58ea77=[];const _0x390d26=_0x49fbb1['infoData_']['getNode'](_0x129d30['_path']);return _0x390d26['isEmpty']()||(_0x58ea77=$t(_0x49fbb1['infoSyncTree_'],_0x129d30['_path'],_0x390d26),setTimeout(()=>{_0x2abd98('ok');},0x0)),_0x58ea77;},'stopListening':()=>{}}),ms(_0x49fbb1,'connected',!0x1),_0x49fbb1['serverSyncTree_']=new dr({'startListening':(_0x30b209,_0x3546ff,_0x166ef3,_0x2b43bd)=>(_0x49fbb1['server_']['listen'](_0x30b209,_0x166ef3,_0x3546ff,(_0x7129b2,_0x28a8df)=>{const _0x1f21c0=_0x2b43bd(_0x7129b2,_0x28a8df);V(_0x49fbb1['eventQueue_'],_0x30b209['_path'],_0x1f21c0);}),[]),'stopListening':(_0x2ecf4,_0x2b1f4f)=>{_0x49fbb1['server_']['unlisten'](_0x2ecf4,_0x2b1f4f);}});}function oa(_0x490cd2){const _0x38ec47=_0x490cd2['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x38ec47;}function jt(_0x32471b){return ed({'timestamp':oa(_0x32471b)});}function pr(_0x2df027,_0x882fbc,_0x5a7456,_0x5db155,_0x5d587f){_0x2df027['dataUpdateCount']++;const _0x237c15=new C(_0x882fbc);_0x5a7456=_0x2df027['interceptServerDataCallback_']?_0x2df027['interceptServerDataCallback_'](_0x882fbc,_0x5a7456):_0x5a7456;let _0x5cc608=[];if(_0x5d587f){if(_0x5db155){const _0x5bf42a=ln(_0x5a7456,_0x2d1833=>N(_0x2d1833));_0x5cc608=Ku(_0x2df027['serverSyncTree_'],_0x237c15,_0x5bf42a,_0x5d587f);}else{const _0x24d1f1=N(_0x5a7456);_0x5cc608=Yo(_0x2df027['serverSyncTree_'],_0x237c15,_0x24d1f1,_0x5d587f);}}else{if(_0x5db155){const _0x83c0e4=ln(_0x5a7456,_0x5939f5=>N(_0x5939f5));_0x5cc608=qu(_0x2df027['serverSyncTree_'],_0x237c15,_0x83c0e4);}else{const _0x5a4aec=N(_0x5a7456);_0x5cc608=$t(_0x2df027['serverSyncTree_'],_0x237c15,_0x5a4aec);}}let _0x7cefde=_0x237c15;_0x5cc608['length']>0x0&&(_0x7cefde=st(_0x2df027,_0x237c15)),V(_0x2df027['eventQueue_'],_0x7cefde,_0x5cc608);}function _r(_0x4a1abe,_0x1b63a4){ms(_0x4a1abe,'connected',_0x1b63a4),_0x1b63a4===!0x1&&wd(_0x4a1abe);}function yd(_0x1d75df,_0x427ac3){x(_0x427ac3,(_0x59ef5c,_0x535ac0)=>{ms(_0x1d75df,_0x59ef5c,_0x535ac0);});}function ms(_0x2e7db5,_0x31664d,_0x28b77e){const _0x3a89bd=new C('/.info/'+_0x31664d),_0x467120=N(_0x28b77e);_0x2e7db5['infoData_']['updateSnapshot'](_0x3a89bd,_0x467120);const _0x47481e=$t(_0x2e7db5['infoSyncTree_'],_0x3a89bd,_0x467120);V(_0x2e7db5['eventQueue_'],_0x3a89bd,_0x47481e);}function Vn(_0x5578ed){return _0x5578ed['nextWriteId_']++;}function vd(_0x47a49d,_0x15b7b5,_0x4e6068){const _0x2104bb=Yu(_0x47a49d['serverSyncTree_'],_0x15b7b5);return _0x2104bb!=null?Promise['resolve'](_0x2104bb):_0x47a49d['server_']['get'](_0x15b7b5)['then'](_0x4b913d=>{const _0x15191b=N(_0x4b913d)['withIndex'](_0x15b7b5['_queryParams']['getIndex']());bi(_0x47a49d['serverSyncTree_'],_0x15b7b5,_0x4e6068,!0x0);let _0x11c660;if(_0x15b7b5['_queryParams']['loadsAllData']())_0x11c660=$t(_0x47a49d['serverSyncTree_'],_0x15b7b5['_path'],_0x15191b);else{const _0x24a392=Mt(_0x47a49d['serverSyncTree_'],_0x15b7b5);_0x11c660=Yo(_0x47a49d['serverSyncTree_'],_0x15b7b5['_path'],_0x15191b,_0x24a392);}return V(_0x47a49d['eventQueue_'],_0x15b7b5['_path'],_0x11c660),wn(_0x47a49d['serverSyncTree_'],_0x15b7b5,_0x4e6068,null,!0x0),_0x15191b;},_0x494a32=>(ut(_0x47a49d,'get\x20for\x20query\x20'+O(_0x15b7b5)+'\x20failed:\x20'+_0x494a32),Promise['reject'](new Error(_0x494a32))));}function Ed(_0xa34e40,_0x15a867,_0x3ae6cd,_0x21741b,_0x17f03d){ut(_0xa34e40,'set',{'path':_0x15a867['toString'](),'value':_0x3ae6cd,'priority':_0x21741b});const _0x24d4e1=jt(_0xa34e40),_0x5098d5=N(_0x3ae6cd,_0x21741b),_0x38d7a1=xn(_0xa34e40['serverSyncTree_'],_0x15a867),_0x5baeb8=hs(_0x5098d5,_0x38d7a1,_0x24d4e1),_0x160457=Vn(_0xa34e40),_0x176933=ss(_0xa34e40['serverSyncTree_'],_0x15a867,_0x5baeb8,_0x160457,!0x0);Bn(_0xa34e40['eventQueue_'],_0x176933),_0xa34e40['server_']['put'](_0x15a867['toString'](),_0x5098d5['val'](!0x0),(_0xf4ef63,_0x231534)=>{const _0x47f09e=_0xf4ef63==='ok';_0x47f09e||U('set\x20at\x20'+_0x15a867+'\x20failed:\x20'+_0xf4ef63);const _0x26e299=pe(_0xa34e40['serverSyncTree_'],_0x160457,!_0x47f09e);V(_0xa34e40['eventQueue_'],_0x15a867,_0x26e299),Ai(_0xa34e40,_0x17f03d,_0xf4ef63,_0x231534);});const _0x3026a8=vs(_0xa34e40,_0x15a867);st(_0xa34e40,_0x3026a8),V(_0xa34e40['eventQueue_'],_0x3026a8,[]);}function Id(_0x55c98f,_0x1042eb,_0x3bced9,_0x3a63e0){ut(_0x55c98f,'update',{'path':_0x1042eb['toString'](),'value':_0x3bced9});let _0x25dd46=!0x0;const _0x58c536=jt(_0x55c98f),_0x1e2dfc={};if(x(_0x3bced9,(_0x387a17,_0x316169)=>{_0x25dd46=!0x1,_0x1e2dfc[_0x387a17]=Zo(A(_0x1042eb,_0x387a17),N(_0x316169),_0x55c98f['serverSyncTree_'],_0x58c536);}),_0x25dd46)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x55c98f,_0x3a63e0,'ok',void 0x0);else{const _0x4e5400=Vn(_0x55c98f),_0x17f778=Gu(_0x55c98f['serverSyncTree_'],_0x1042eb,_0x1e2dfc,_0x4e5400);Bn(_0x55c98f['eventQueue_'],_0x17f778),_0x55c98f['server_']['merge'](_0x1042eb['toString'](),_0x3bced9,(_0x320255,_0x3e9e91)=>{const _0x21c3fa=_0x320255==='ok';_0x21c3fa||U('update\x20at\x20'+_0x1042eb+'\x20failed:\x20'+_0x320255);const _0xcb8624=pe(_0x55c98f['serverSyncTree_'],_0x4e5400,!_0x21c3fa),_0x20e80f=_0xcb8624['length']>0x0?st(_0x55c98f,_0x1042eb):_0x1042eb;V(_0x55c98f['eventQueue_'],_0x20e80f,_0xcb8624),Ai(_0x55c98f,_0x3a63e0,_0x320255,_0x3e9e91);}),x(_0x3bced9,_0x2773dc=>{const _0x2c28b7=vs(_0x55c98f,A(_0x1042eb,_0x2773dc));st(_0x55c98f,_0x2c28b7);}),V(_0x55c98f['eventQueue_'],_0x1042eb,[]);}}function wd(_0x12ea8b){ut(_0x12ea8b,'onDisconnectEvents');const _0x5a8bcc=jt(_0x12ea8b),_0x107866=pn();Ei(_0x12ea8b['onDisconnect_'],w(),(_0x3eb54c,_0x596d66)=>{const _0x3aeb7d=Zo(_0x3eb54c,_0x596d66,_0x12ea8b['serverSyncTree_'],_0x5a8bcc);Mo(_0x107866,_0x3eb54c,_0x3aeb7d);});let _0x2096f0=[];Ei(_0x107866,w(),(_0x443c34,_0x555a9e)=>{_0x2096f0=_0x2096f0['concat']($t(_0x12ea8b['serverSyncTree_'],_0x443c34,_0x555a9e));const _0x1ee608=vs(_0x12ea8b,_0x443c34);st(_0x12ea8b,_0x1ee608);}),_0x12ea8b['onDisconnect_']=pn(),V(_0x12ea8b['eventQueue_'],w(),_0x2096f0);}function Cd(_0xdbb09f,_0x3a37d3,_0x121b93){let _0x4726a5;y(_0x3a37d3['_path'])==='.info'?_0x4726a5=bi(_0xdbb09f['infoSyncTree_'],_0x3a37d3,_0x121b93):_0x4726a5=bi(_0xdbb09f['serverSyncTree_'],_0x3a37d3,_0x121b93),ia(_0xdbb09f['eventQueue_'],_0x3a37d3['_path'],_0x4726a5);}function Td(_0x23ef8e,_0x460e04,_0x11e9c2){let _0x1167f9;y(_0x460e04['_path'])==='.info'?_0x1167f9=wn(_0x23ef8e['infoSyncTree_'],_0x460e04,_0x11e9c2):_0x1167f9=wn(_0x23ef8e['serverSyncTree_'],_0x460e04,_0x11e9c2),ia(_0x23ef8e['eventQueue_'],_0x460e04['_path'],_0x1167f9);}function aa(_0x5dec66){_0x5dec66['persistentConnection_']&&_0x5dec66['persistentConnection_']['interrupt'](ra);}function Sd(_0x4f33b2){_0x4f33b2['persistentConnection_']&&_0x4f33b2['persistentConnection_']['resume'](ra);}function ut(_0x4294b7,..._0x3e4c30){let _0x1ce5e5='';_0x4294b7['persistentConnection_']&&(_0x1ce5e5=_0x4294b7['persistentConnection_']['id']+':'),L(_0x1ce5e5,..._0x3e4c30);}function Ai(_0x5dd2d6,_0x2b385a,_0x364bfd,_0x1ad01a){_0x2b385a&&lt(()=>{if(_0x364bfd==='ok')_0x2b385a(null);else{const _0x9862f9=(_0x364bfd||'error')['toUpperCase']();let _0x12a0cc=_0x9862f9;_0x1ad01a&&(_0x12a0cc+=':\x20'+_0x1ad01a);const _0x2b558c=new Error(_0x12a0cc);_0x2b558c['code']=_0x9862f9,_0x2b385a(_0x2b558c);}});}function bd(_0x3de43b,_0x267d61,_0x56210d,_0x27ba1a,_0x160861,_0x521570){ut(_0x3de43b,'transaction\x20on\x20'+_0x267d61);const _0xa89f8c={'path':_0x267d61,'update':_0x56210d,'onComplete':_0x27ba1a,'status':null,'order':to(),'applyLocally':_0x521570,'retryCount':0x0,'unwatcher':_0x160861,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4b3671=ys(_0x3de43b,_0x267d61,void 0x0);_0xa89f8c['currentInputSnapshot']=_0x4b3671;const _0x4c812a=_0xa89f8c['update'](_0x4b3671['val']());if(_0x4c812a===void 0x0)_0xa89f8c['unwatcher'](),_0xa89f8c['currentOutputSnapshotRaw']=null,_0xa89f8c['currentOutputSnapshotResolved']=null,_0xa89f8c['onComplete']&&_0xa89f8c['onComplete'](null,!0x1,_0xa89f8c['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c812a,_0xa89f8c['path']),_0xa89f8c['status']=0x0;const _0x4143f8=Un(_0x3de43b['transactionQueueTree_'],_0x267d61),_0x45b48c=Ge(_0x4143f8)||[];_0x45b48c['push'](_0xa89f8c),fs(_0x4143f8,_0x45b48c);let _0x36c904;typeof _0x4c812a=='object'&&_0x4c812a!==null&&Y(_0x4c812a,'.priority')?(_0x36c904=Oe(_0x4c812a,'.priority'),f(Cn(_0x36c904),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x36c904=(xn(_0x3de43b['serverSyncTree_'],_0x267d61)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xb62ea6=jt(_0x3de43b),_0x2213fc=N(_0x4c812a,_0x36c904),_0x1b6577=hs(_0x2213fc,_0x4b3671,_0xb62ea6);_0xa89f8c['currentOutputSnapshotRaw']=_0x2213fc,_0xa89f8c['currentOutputSnapshotResolved']=_0x1b6577,_0xa89f8c['currentWriteId']=Vn(_0x3de43b);const _0x1c890d=ss(_0x3de43b['serverSyncTree_'],_0x267d61,_0x1b6577,_0xa89f8c['currentWriteId'],_0xa89f8c['applyLocally']);V(_0x3de43b['eventQueue_'],_0x267d61,_0x1c890d),Hn(_0x3de43b,_0x3de43b['transactionQueueTree_']);}}function ys(_0x55f10b,_0x29b5da,_0x3e95c7){return xn(_0x55f10b['serverSyncTree_'],_0x29b5da,_0x3e95c7)||g['EMPTY_NODE'];}function Hn(_0x1c21a5,_0x395ebf=_0x1c21a5['transactionQueueTree_']){if(_0x395ebf||$n(_0x1c21a5,_0x395ebf),Ge(_0x395ebf)){const _0x3425b5=la(_0x1c21a5,_0x395ebf);f(_0x3425b5['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3425b5['every'](_0x191c0b=>_0x191c0b['status']===0x0)&&Rd(_0x1c21a5,Gt(_0x395ebf),_0x3425b5);}else ea(_0x395ebf)&&Wn(_0x395ebf,_0x447e8a=>{Hn(_0x1c21a5,_0x447e8a);});}function Rd(_0x1606c9,_0x1b8d10,_0x5bf1d5){const _0x1f4b0c=_0x5bf1d5['map'](_0x335d69=>_0x335d69['currentWriteId']),_0xf5e4f6=ys(_0x1606c9,_0x1b8d10,_0x1f4b0c);let _0x16f3f0=_0xf5e4f6;const _0x11aadc=_0xf5e4f6['hash']();for(let _0xb97107=0x0;_0xb97107<_0x5bf1d5['length'];_0xb97107++){const _0x2f93ba=_0x5bf1d5[_0xb97107];f(_0x2f93ba['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2f93ba['status']=0x1,_0x2f93ba['retryCount']++;const _0x2dc8dd=F(_0x1b8d10,_0x2f93ba['path']);_0x16f3f0=_0x16f3f0['updateChild'](_0x2dc8dd,_0x2f93ba['currentOutputSnapshotRaw']);}const _0x63432a=_0x16f3f0['val'](!0x0),_0x5f3028=_0x1b8d10;_0x1606c9['server_']['put'](_0x5f3028['toString'](),_0x63432a,_0x55d854=>{ut(_0x1606c9,'transaction\x20put\x20response',{'path':_0x5f3028['toString'](),'status':_0x55d854});let _0xfaf4f4=[];if(_0x55d854==='ok'){const _0x449ab5=[];for(let _0x3fd56a=0x0;_0x3fd56a<_0x5bf1d5['length'];_0x3fd56a++)_0x5bf1d5[_0x3fd56a]['status']=0x2,_0xfaf4f4=_0xfaf4f4['concat'](pe(_0x1606c9['serverSyncTree_'],_0x5bf1d5[_0x3fd56a]['currentWriteId'])),_0x5bf1d5[_0x3fd56a]['onComplete']&&_0x449ab5['push'](()=>_0x5bf1d5[_0x3fd56a]['onComplete'](null,!0x0,_0x5bf1d5[_0x3fd56a]['currentOutputSnapshotResolved'])),_0x5bf1d5[_0x3fd56a]['unwatcher']();$n(_0x1606c9,Un(_0x1606c9['transactionQueueTree_'],_0x1b8d10)),Hn(_0x1606c9,_0x1606c9['transactionQueueTree_']),V(_0x1606c9['eventQueue_'],_0x1b8d10,_0xfaf4f4);for(let _0x5350a9=0x0;_0x5350a9<_0x449ab5['length'];_0x5350a9++)lt(_0x449ab5[_0x5350a9]);}else{if(_0x55d854==='datastale'){for(let _0x11fab2=0x0;_0x11fab2<_0x5bf1d5['length'];_0x11fab2++)_0x5bf1d5[_0x11fab2]['status']===0x3?_0x5bf1d5[_0x11fab2]['status']=0x4:_0x5bf1d5[_0x11fab2]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5f3028['toString']()+'\x20failed:\x20'+_0x55d854);for(let _0x3ee21=0x0;_0x3ee21<_0x5bf1d5['length'];_0x3ee21++)_0x5bf1d5[_0x3ee21]['status']=0x4,_0x5bf1d5[_0x3ee21]['abortReason']=_0x55d854;}st(_0x1606c9,_0x1b8d10);}},_0x11aadc);}function st(_0x47c6aa,_0x45f236){const _0x403e8b=ca(_0x47c6aa,_0x45f236),_0x319c8b=Gt(_0x403e8b),_0x3a2869=la(_0x47c6aa,_0x403e8b);return Ad(_0x47c6aa,_0x3a2869,_0x319c8b),_0x319c8b;}function Ad(_0x1705ec,_0x27360d,_0x444eeb){if(_0x27360d['length']===0x0)return;const _0x5e582a=[];let _0x2afa29=[];const _0xe4a651=_0x27360d['filter'](_0x476fe6=>_0x476fe6['status']===0x0)['map'](_0x348799=>_0x348799['currentWriteId']);for(let _0x57da6b=0x0;_0x57da6b<_0x27360d['length'];_0x57da6b++){const _0x436a1e=_0x27360d[_0x57da6b],_0x362a02=F(_0x444eeb,_0x436a1e['path']);let _0x2f8a1a=!0x1,_0x3a3d10;if(f(_0x362a02!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x436a1e['status']===0x4)_0x2f8a1a=!0x0,_0x3a3d10=_0x436a1e['abortReason'],_0x2afa29=_0x2afa29['concat'](pe(_0x1705ec['serverSyncTree_'],_0x436a1e['currentWriteId'],!0x0));else{if(_0x436a1e['status']===0x0){if(_0x436a1e['retryCount']>=_d)_0x2f8a1a=!0x0,_0x3a3d10='maxretry',_0x2afa29=_0x2afa29['concat'](pe(_0x1705ec['serverSyncTree_'],_0x436a1e['currentWriteId'],!0x0));else{const _0x537425=ys(_0x1705ec,_0x436a1e['path'],_0xe4a651);_0x436a1e['currentInputSnapshot']=_0x537425;const _0xeeeca8=_0x27360d[_0x57da6b]['update'](_0x537425['val']());if(_0xeeeca8!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0xeeeca8,_0x436a1e['path']);let _0x463b08=N(_0xeeeca8);typeof _0xeeeca8=='object'&&_0xeeeca8!=null&&Y(_0xeeeca8,'.priority')||(_0x463b08=_0x463b08['updatePriority'](_0x537425['getPriority']()));const _0x495d2b=_0x436a1e['currentWriteId'],_0x5976a7=jt(_0x1705ec),_0x38011f=hs(_0x463b08,_0x537425,_0x5976a7);_0x436a1e['currentOutputSnapshotRaw']=_0x463b08,_0x436a1e['currentOutputSnapshotResolved']=_0x38011f,_0x436a1e['currentWriteId']=Vn(_0x1705ec),_0xe4a651['splice'](_0xe4a651['indexOf'](_0x495d2b),0x1),_0x2afa29=_0x2afa29['concat'](ss(_0x1705ec['serverSyncTree_'],_0x436a1e['path'],_0x38011f,_0x436a1e['currentWriteId'],_0x436a1e['applyLocally'])),_0x2afa29=_0x2afa29['concat'](pe(_0x1705ec['serverSyncTree_'],_0x495d2b,!0x0));}else _0x2f8a1a=!0x0,_0x3a3d10='nodata',_0x2afa29=_0x2afa29['concat'](pe(_0x1705ec['serverSyncTree_'],_0x436a1e['currentWriteId'],!0x0));}}}V(_0x1705ec['eventQueue_'],_0x444eeb,_0x2afa29),_0x2afa29=[],_0x2f8a1a&&(_0x27360d[_0x57da6b]['status']=0x2,function(_0x2c74a1){setTimeout(_0x2c74a1,Math['floor'](0x0));}(_0x27360d[_0x57da6b]['unwatcher']),_0x27360d[_0x57da6b]['onComplete']&&(_0x3a3d10==='nodata'?_0x5e582a['push'](()=>_0x27360d[_0x57da6b]['onComplete'](null,!0x1,_0x27360d[_0x57da6b]['currentInputSnapshot'])):_0x5e582a['push'](()=>_0x27360d[_0x57da6b]['onComplete'](new Error(_0x3a3d10),!0x1,null))));}$n(_0x1705ec,_0x1705ec['transactionQueueTree_']);for(let _0xd3ab84=0x0;_0xd3ab84<_0x5e582a['length'];_0xd3ab84++)lt(_0x5e582a[_0xd3ab84]);Hn(_0x1705ec,_0x1705ec['transactionQueueTree_']);}function ca(_0x3cf5a0,_0x55e2fa){let _0x556224,_0x4a65b6=_0x3cf5a0['transactionQueueTree_'];for(_0x556224=y(_0x55e2fa);_0x556224!==null&&Ge(_0x4a65b6)===void 0x0;)_0x4a65b6=Un(_0x4a65b6,_0x556224),_0x55e2fa=b(_0x55e2fa),_0x556224=y(_0x55e2fa);return _0x4a65b6;}function la(_0x1ea3a8,_0x54b51f){const _0xf3b5d6=[];return ha(_0x1ea3a8,_0x54b51f,_0xf3b5d6),_0xf3b5d6['sort']((_0x1742db,_0x24f83f)=>_0x1742db['order']-_0x24f83f['order']),_0xf3b5d6;}function ha(_0x2ca3f3,_0x1a0119,_0x4cea69){const _0x5b8142=Ge(_0x1a0119);if(_0x5b8142){for(let _0x3bd8a3=0x0;_0x3bd8a3<_0x5b8142['length'];_0x3bd8a3++)_0x4cea69['push'](_0x5b8142[_0x3bd8a3]);}Wn(_0x1a0119,_0x1e9db5=>{ha(_0x2ca3f3,_0x1e9db5,_0x4cea69);});}function $n(_0x457730,_0x53cdef){const _0x238584=Ge(_0x53cdef);if(_0x238584){let _0x595767=0x0;for(let _0x3101d8=0x0;_0x3101d8<_0x238584['length'];_0x3101d8++)_0x238584[_0x3101d8]['status']!==0x2&&(_0x238584[_0x595767]=_0x238584[_0x3101d8],_0x595767++);_0x238584['length']=_0x595767,fs(_0x53cdef,_0x238584['length']>0x0?_0x238584:void 0x0);}Wn(_0x53cdef,_0x5c7914=>{$n(_0x457730,_0x5c7914);});}function vs(_0x1dde83,_0x45b17c){const _0x35f7ff=Gt(ca(_0x1dde83,_0x45b17c)),_0x5a636a=Un(_0x1dde83['transactionQueueTree_'],_0x45b17c);return sd(_0x5a636a,_0x4168ec=>{ai(_0x1dde83,_0x4168ec);}),ai(_0x1dde83,_0x5a636a),ta(_0x5a636a,_0x4cce27=>{ai(_0x1dde83,_0x4cce27);}),_0x35f7ff;}function ai(_0x225a63,_0x2a009a){const _0x66c485=Ge(_0x2a009a);if(_0x66c485){const _0x28466d=[];let _0x3ef9ac=[],_0x5715b7=-0x1;for(let _0x24fa96=0x0;_0x24fa96<_0x66c485['length'];_0x24fa96++)_0x66c485[_0x24fa96]['status']===0x3||(_0x66c485[_0x24fa96]['status']===0x1?(f(_0x5715b7===_0x24fa96-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5715b7=_0x24fa96,_0x66c485[_0x24fa96]['status']=0x3,_0x66c485[_0x24fa96]['abortReason']='set'):(f(_0x66c485[_0x24fa96]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x66c485[_0x24fa96]['unwatcher'](),_0x3ef9ac=_0x3ef9ac['concat'](pe(_0x225a63['serverSyncTree_'],_0x66c485[_0x24fa96]['currentWriteId'],!0x0)),_0x66c485[_0x24fa96]['onComplete']&&_0x28466d['push'](_0x66c485[_0x24fa96]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5715b7===-0x1?fs(_0x2a009a,void 0x0):_0x66c485['length']=_0x5715b7+0x1,V(_0x225a63['eventQueue_'],Gt(_0x2a009a),_0x3ef9ac);for(let _0x23b413=0x0;_0x23b413<_0x28466d['length'];_0x23b413++)lt(_0x28466d[_0x23b413]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x468575){let _0x44da6c='';const _0x47fa6f=_0x468575['split']('/');for(let _0x9877e3=0x0;_0x9877e3<_0x47fa6f['length'];_0x9877e3++)if(_0x47fa6f[_0x9877e3]['length']>0x0){let _0x519753=_0x47fa6f[_0x9877e3];try{_0x519753=decodeURIComponent(_0x519753['replace'](/\+/g,'\x20'));}catch{}_0x44da6c+='/'+_0x519753;}return _0x44da6c;}function Nd(_0x27f897){const _0x2b05ed={};_0x27f897['charAt'](0x0)==='?'&&(_0x27f897=_0x27f897['substring'](0x1));for(const _0x37cf94 of _0x27f897['split']('&')){if(_0x37cf94['length']===0x0)continue;const _0x558197=_0x37cf94['split']('=');_0x558197['length']===0x2?_0x2b05ed[decodeURIComponent(_0x558197[0x0])]=decodeURIComponent(_0x558197[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x37cf94+'\x27\x20in\x20query\x20\x27'+_0x27f897+'\x27');}return _0x2b05ed;}const gr=function(_0x3e430c,_0x1ad633){const _0x39abf4=Pd(_0x3e430c),_0xa6d014=_0x39abf4['namespace'];_0x39abf4['domain']==='firebase.com'&&oe(_0x39abf4['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xa6d014||_0xa6d014==='undefined')&&_0x39abf4['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x39abf4['secure']||Bl();const _0x3b8581=_0x39abf4['scheme']==='ws'||_0x39abf4['scheme']==='wss';return{'repoInfo':new _o(_0x39abf4['host'],_0x39abf4['secure'],_0xa6d014,_0x3b8581,_0x1ad633,'',_0xa6d014!==_0x39abf4['subdomain']),'path':new C(_0x39abf4['pathString'])};},Pd=function(_0xc04444){let _0x2b3f66='',_0x242cac='',_0x27534d='',_0x479340='',_0x5121fb='',_0x36d27f=!0x0,_0x2dd38f='https',_0x319b57=0x1bb;if(typeof _0xc04444=='string'){let _0x553fe7=_0xc04444['indexOf']('//');_0x553fe7>=0x0&&(_0x2dd38f=_0xc04444['substring'](0x0,_0x553fe7-0x1),_0xc04444=_0xc04444['substring'](_0x553fe7+0x2));let _0x20d052=_0xc04444['indexOf']('/');_0x20d052===-0x1&&(_0x20d052=_0xc04444['length']);let _0x571166=_0xc04444['indexOf']('?');_0x571166===-0x1&&(_0x571166=_0xc04444['length']),_0x2b3f66=_0xc04444['substring'](0x0,Math['min'](_0x20d052,_0x571166)),_0x20d052<_0x571166&&(_0x479340=kd(_0xc04444['substring'](_0x20d052,_0x571166)));const _0x16ebb2=Nd(_0xc04444['substring'](Math['min'](_0xc04444['length'],_0x571166)));_0x553fe7=_0x2b3f66['indexOf'](':'),_0x553fe7>=0x0?(_0x36d27f=_0x2dd38f==='https'||_0x2dd38f==='wss',_0x319b57=parseInt(_0x2b3f66['substring'](_0x553fe7+0x1),0xa)):_0x553fe7=_0x2b3f66['length'];const _0x284028=_0x2b3f66['slice'](0x0,_0x553fe7);if(_0x284028['toLowerCase']()==='localhost')_0x242cac='localhost';else{if(_0x284028['split']('.')['length']<=0x2)_0x242cac=_0x284028;else{const _0x17c397=_0x2b3f66['indexOf']('.');_0x27534d=_0x2b3f66['substring'](0x0,_0x17c397)['toLowerCase'](),_0x242cac=_0x2b3f66['substring'](_0x17c397+0x1),_0x5121fb=_0x27534d;}}'ns'in _0x16ebb2&&(_0x5121fb=_0x16ebb2['ns']);}return{'host':_0x2b3f66,'port':_0x319b57,'domain':_0x242cac,'subdomain':_0x27534d,'secure':_0x36d27f,'scheme':_0x2dd38f,'pathString':_0x479340,'namespace':_0x5121fb};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x59b03e=0x0;const _0x424c17=[];return function(_0x28f3f8){const _0x5c3484=_0x28f3f8===_0x59b03e;_0x59b03e=_0x28f3f8;let _0x4121dd;const _0x4e26c0=new Array(0x8);for(_0x4121dd=0x7;_0x4121dd>=0x0;_0x4121dd--)_0x4e26c0[_0x4121dd]=mr['charAt'](_0x28f3f8%0x40),_0x28f3f8=Math['floor'](_0x28f3f8/0x40);f(_0x28f3f8===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x37abf0=_0x4e26c0['join']('');if(_0x5c3484){for(_0x4121dd=0xb;_0x4121dd>=0x0&&_0x424c17[_0x4121dd]===0x3f;_0x4121dd--)_0x424c17[_0x4121dd]=0x0;_0x424c17[_0x4121dd]++;}else{for(_0x4121dd=0x0;_0x4121dd<0xc;_0x4121dd++)_0x424c17[_0x4121dd]=Math['floor'](Math['random']()*0x40);}for(_0x4121dd=0x0;_0x4121dd<0xc;_0x4121dd++)_0x37abf0+=mr['charAt'](_0x424c17[_0x4121dd]);return f(_0x37abf0['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x37abf0;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x4a853d,_0x5019c8,_0x1e9e1b,_0x1367d3){this['eventType']=_0x4a853d,this['eventRegistration']=_0x5019c8,this['snapshot']=_0x1e9e1b,this['prevName']=_0x1367d3;}['getPath'](){const _0xf2fe6=this['snapshot']['ref'];return this['eventType']==='value'?_0xf2fe6['_path']:_0xf2fe6['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0xb5764b,_0x2c81fd,_0x336187){this['eventRegistration']=_0xb5764b,this['error']=_0x2c81fd,this['path']=_0x336187;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x2012e3,_0x281c22){this['snapshotCallback']=_0x2012e3,this['cancelCallback']=_0x281c22;}['onValue'](_0x342ce3,_0x118e08){this['snapshotCallback']['call'](null,_0x342ce3,_0x118e08);}['onCancel'](_0x48753d){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x48753d);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x1fc140){return this['snapshotCallback']===_0x1fc140['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x1fc140['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x1fc140['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3d1fbe,_0x26ddc8,_0x1e0b62,_0x46c8c3){this['_repo']=_0x3d1fbe,this['_path']=_0x26ddc8,this['_queryParams']=_0x1e0b62,this['_orderByCalled']=_0x46c8c3;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x12455a=nr(this['_queryParams']),_0x4c3007=Bi(_0x12455a);return _0x4c3007==='{}'?'default':_0x4c3007;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x4a8cde){if(_0x4a8cde=k(_0x4a8cde),!(_0x4a8cde instanceof be))return!0x1;const _0x4e9649=this['_repo']===_0x4a8cde['_repo'],_0x2bca3f=qi(this['_path'],_0x4a8cde['_path']),_0x82293b=this['_queryIdentifier']===_0x4a8cde['_queryIdentifier'];return _0x4e9649&&_0x2bca3f&&_0x82293b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x438d6a,_0x1fde45){if(_0x438d6a['_orderByCalled']===!0x0)throw new Error(_0x1fde45+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x49421d){let _0x5a860f=null,_0xc13ea2=null;if(_0x49421d['hasStart']()&&(_0x5a860f=_0x49421d['getIndexStartValue']()),_0x49421d['hasEnd']()&&(_0xc13ea2=_0x49421d['getIndexEndValue']()),_0x49421d['getIndex']()===ye){const _0x5c70b5='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x19412c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x49421d['hasStart']()){if(_0x49421d['getIndexStartName']()!==xe)throw new Error(_0x5c70b5);if(typeof _0x5a860f!='string')throw new Error(_0x19412c);}if(_0x49421d['hasEnd']()){if(_0x49421d['getIndexEndName']()!==Ie)throw new Error(_0x5c70b5);if(typeof _0xc13ea2!='string')throw new Error(_0x19412c);}}else{if(_0x49421d['getIndex']()===R){if(_0x5a860f!=null&&!Cn(_0x5a860f)||_0xc13ea2!=null&&!Cn(_0xc13ea2))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x49421d['getIndex']()instanceof Ki||_0x49421d['getIndex']()===Po,'unknown\x20index\x20type.'),_0x5a860f!=null&&typeof _0x5a860f=='object'||_0xc13ea2!=null&&typeof _0xc13ea2=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0xf8398b){if(_0xf8398b['hasStart']()&&_0xf8398b['hasEnd']()&&_0xf8398b['hasLimit']()&&!_0xf8398b['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x3189af,_0x1e3e2d){super(_0x3189af,_0x1e3e2d,new Qi(),!0x1);}get['parent'](){const _0x211903=To(this['_path']);return _0x211903===null?null:new Z(this['_repo'],_0x211903);}get['root'](){let _0x51ad23=this;for(;_0x51ad23['parent']!==null;)_0x51ad23=_0x51ad23['parent'];return _0x51ad23;}}class rt{constructor(_0x541de4,_0x19c16e,_0xf4ac){this['_node']=_0x541de4,this['ref']=_0x19c16e,this['_index']=_0xf4ac;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x299002){const _0x307c4d=new C(_0x299002),_0x5adb5c=Lt(this['ref'],_0x299002);return new rt(this['_node']['getChild'](_0x307c4d),_0x5adb5c,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xc752e3){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2fe5e2,_0x5e2f43)=>_0xc752e3(new rt(_0x5e2f43,Lt(this['ref'],_0x2fe5e2),R)));}['hasChild'](_0xf930e1){const _0x5c21b4=new C(_0xf930e1);return!this['_node']['getChild'](_0x5c21b4)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function h_(_0x40baf8,_0x2ab66a){return _0x40baf8=k(_0x40baf8),_0x40baf8['_checkNotDeleted']('ref'),_0x2ab66a!==void 0x0?Lt(_0x40baf8['_root'],_0x2ab66a):_0x40baf8['_root'];}function Lt(_0x4d7f28,_0x1627d7){return _0x4d7f28=k(_0x4d7f28),y(_0x4d7f28['_path'])===null?ud('child','path',_0x1627d7):_s('child','path',_0x1627d7),new Z(_0x4d7f28['_repo'],A(_0x4d7f28['_path'],_0x1627d7));}function u_(_0x1f7357,_0x1ea450){_0x1f7357=k(_0x1f7357),gs('push',_0x1f7357['_path']),qt('push',_0x1ea450,_0x1f7357['_path'],!0x0);const _0x228011=oa(_0x1f7357['_repo']),_0x2597c2=Od(_0x228011),_0x4003ed=Lt(_0x1f7357,_0x2597c2),_0x556a3c=Lt(_0x1f7357,_0x2597c2);let _0x1020bf;return _0x1ea450!=null?_0x1020bf=Ld(_0x556a3c,_0x1ea450)['then'](()=>_0x556a3c):_0x1020bf=Promise['resolve'](_0x556a3c),_0x4003ed['then']=_0x1020bf['then']['bind'](_0x1020bf),_0x4003ed['catch']=_0x1020bf['then']['bind'](_0x1020bf,void 0x0),_0x4003ed;}function Ld(_0xac5771,_0x2741c6){_0xac5771=k(_0xac5771),gs('set',_0xac5771['_path']),qt('set',_0x2741c6,_0xac5771['_path'],!0x1);const _0x1e457c=new Ve();return Ed(_0xac5771['_repo'],_0xac5771['_path'],_0x2741c6,null,_0x1e457c['wrapCallback'](()=>{})),_0x1e457c['promise'];}function d_(_0x2060ff,_0x3387b5){hd('update',_0x3387b5,_0x2060ff['_path']);const _0x532ab1=new Ve();return Id(_0x2060ff['_repo'],_0x2060ff['_path'],_0x3387b5,_0x532ab1['wrapCallback'](()=>{})),_0x532ab1['promise'];}function f_(_0x3de66e){_0x3de66e=k(_0x3de66e);const _0x21cd5f=new ua(()=>{}),_0x55ccd5=new qn(_0x21cd5f);return vd(_0x3de66e['_repo'],_0x3de66e,_0x55ccd5)['then'](_0x48397c=>new rt(_0x48397c,new Z(_0x3de66e['_repo'],_0x3de66e['_path']),_0x3de66e['_queryParams']['getIndex']()));}class qn{constructor(_0x2566c1){this['callbackContext']=_0x2566c1;}['respondsTo'](_0x76d82b){return _0x76d82b==='value';}['createEvent'](_0x5ce1dd,_0x4270af){const _0x2a56cc=_0x4270af['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x5ce1dd['snapshotNode'],new Z(_0x4270af['_repo'],_0x4270af['_path']),_0x2a56cc));}['getEventRunner'](_0x22d995){return _0x22d995['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x22d995['error']):()=>this['callbackContext']['onValue'](_0x22d995['snapshot'],null);}['createCancelEvent'](_0x5c8ef3,_0x4686fb){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x5c8ef3,_0x4686fb):null;}['matches'](_0x40378a){return _0x40378a instanceof qn?!_0x40378a['callbackContext']||!this['callbackContext']?!0x0:_0x40378a['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x4e5d32,_0x26e3c6,_0x37ad17,_0x5d24cd,_0x20ef35){const _0x4a6fc8=new ua(_0x37ad17,void 0x0),_0x2962d7=new qn(_0x4a6fc8);return Cd(_0x4e5d32['_repo'],_0x4e5d32,_0x2962d7),()=>Td(_0x4e5d32['_repo'],_0x4e5d32,_0x2962d7);}function Fd(_0x308c07,_0x302a18,_0x33dd19,_0x1d13f7){return xd(_0x308c07,'value',_0x302a18);}class dt{}class pa extends dt{constructor(_0x3f7cd7,_0xd7b745){super(),this['_value']=_0x3f7cd7,this['_key']=_0xd7b745,this['type']='endAt';}['_apply'](_0x52168e){qt('endAt',this['_value'],_0x52168e['_path'],!0x0);const _0x3f73ac=Kh(_0x52168e['_queryParams'],this['_value'],this['_key']);if(fa(_0x3f73ac),Gn(_0x3f73ac),_0x52168e['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x52168e['_repo'],_0x52168e['_path'],_0x3f73ac,_0x52168e['_orderByCalled']);}}function p_(_0x242c36,_0x208d57){return new pa(_0x242c36,_0x208d57);}class _a extends dt{constructor(_0x22b9fe,_0x290cfc){super(),this['_value']=_0x22b9fe,this['_key']=_0x290cfc,this['type']='startAt';}['_apply'](_0x56fc43){qt('startAt',this['_value'],_0x56fc43['_path'],!0x0);const _0x18a97a=jh(_0x56fc43['_queryParams'],this['_value'],this['_key']);if(fa(_0x18a97a),Gn(_0x18a97a),_0x56fc43['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x56fc43['_repo'],_0x56fc43['_path'],_0x18a97a,_0x56fc43['_orderByCalled']);}}function __(_0x180654=null,_0x51c42c){return new _a(_0x180654,_0x51c42c);}class Ud extends dt{constructor(_0x2fe74b){super(),this['_limit']=_0x2fe74b,this['type']='limitToFirst';}['_apply'](_0xcfe1f){if(_0xcfe1f['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0xcfe1f['_repo'],_0xcfe1f['_path'],zh(_0xcfe1f['_queryParams'],this['_limit']),_0xcfe1f['_orderByCalled']);}}function g_(_0x214ad9){if(Math['floor'](_0x214ad9)!==_0x214ad9||_0x214ad9<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x214ad9);}class Wd extends dt{constructor(_0x2d6de9){super(),this['_path']=_0x2d6de9,this['type']='orderByChild';}['_apply'](_0x198e05){da(_0x198e05,'orderByChild');const _0x4122c7=new C(this['_path']);if(v(_0x4122c7))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x47d382=new Ki(_0x4122c7),_0x5d2010=Do(_0x198e05['_queryParams'],_0x47d382);return Gn(_0x5d2010),new be(_0x198e05['_repo'],_0x198e05['_path'],_0x5d2010,!0x0);}}function m_(_0x3f85ec){if(_0x3f85ec==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3f85ec==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3f85ec==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x3f85ec),new Wd(_0x3f85ec);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x30cc23){da(_0x30cc23,'orderByKey');const _0x1f764f=Do(_0x30cc23['_queryParams'],ye);return Gn(_0x1f764f),new be(_0x30cc23['_repo'],_0x30cc23['_path'],_0x1f764f,!0x0);}}function y_(){return new Bd();}class Vd extends dt{constructor(_0x2cee4a,_0x4cd95b){super(),this['_value']=_0x2cee4a,this['_key']=_0x4cd95b,this['type']='equalTo';}['_apply'](_0x441734){if(qt('equalTo',this['_value'],_0x441734['_path'],!0x1),_0x441734['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x441734['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x441734));}}function v_(_0x2e0877,_0x919a2b){return new Vd(_0x2e0877,_0x919a2b);}function E_(_0x525eec,..._0x1c9558){let _0x1d65e6=k(_0x525eec);for(const _0x2d2d44 of _0x1c9558)_0x1d65e6=_0x2d2d44['_apply'](_0x1d65e6);return _0x1d65e6;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x3ff356,_0x1c9287,_0x2b9e50,_0x2ba0bb){const _0x31e449=_0x1c9287['lastIndexOf'](':'),_0x18b45b=_0x1c9287['substring'](0x0,_0x31e449),_0x4d467a=Wt(_0x18b45b);_0x3ff356['repoInfo_']=new _o(_0x1c9287,_0x4d467a,_0x3ff356['repoInfo_']['namespace'],_0x3ff356['repoInfo_']['webSocketOnly'],_0x3ff356['repoInfo_']['nodeAdmin'],_0x3ff356['repoInfo_']['persistenceKey'],_0x3ff356['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2b9e50),_0x2ba0bb&&(_0x3ff356['authTokenProvider_']=_0x2ba0bb);}function qd(_0x209f5a,_0x512ed3,_0x3e533a,_0x1d0152,_0x459022){let _0xbdf165=_0x1d0152||_0x209f5a['options']['databaseURL'];_0xbdf165===void 0x0&&(_0x209f5a['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x209f5a['options']['projectId']),_0xbdf165=_0x209f5a['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4c41c6=gr(_0xbdf165,_0x459022),_0x3018f5=_0x4c41c6['repoInfo'],_0x21400f;typeof process<'u'&&Us&&(_0x21400f=Us[Hd]),_0x21400f?(_0xbdf165='http://'+_0x21400f+'?ns='+_0x3018f5['namespace'],_0x4c41c6=gr(_0xbdf165,_0x459022),_0x3018f5=_0x4c41c6['repoInfo']):_0x4c41c6['repoInfo']['secure'];const _0x28557a=new Jl(_0x209f5a['name'],_0x209f5a['options'],_0x512ed3);dd('Invalid\x20Firebase\x20Database\x20URL',_0x4c41c6),v(_0x4c41c6['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x398b09=jd(_0x3018f5,_0x209f5a,_0x28557a,new Ql(_0x209f5a,_0x3e533a));return new Kd(_0x398b09,_0x209f5a);}function zd(_0x370e92,_0x25ffb6){const _0x54a815=ki[_0x25ffb6];(!_0x54a815||_0x54a815[_0x370e92['key']]!==_0x370e92)&&oe('Database\x20'+_0x25ffb6+'('+_0x370e92['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x370e92),delete _0x54a815[_0x370e92['key']];}function jd(_0x36d1f4,_0x13dcdc,_0xe4fe12,_0x3439e0){let _0x23c9be=ki[_0x13dcdc['name']];_0x23c9be||(_0x23c9be={},ki[_0x13dcdc['name']]=_0x23c9be);let _0x410d45=_0x23c9be[_0x36d1f4['toURLString']()];return _0x410d45&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x410d45=new gd(_0x36d1f4,$d,_0xe4fe12,_0x3439e0),_0x23c9be[_0x36d1f4['toURLString']()]=_0x410d45,_0x410d45;}class Kd{constructor(_0x496154,_0xf346d4){this['_repoInternal']=_0x496154,this['app']=_0xf346d4,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5d2383){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x5d2383+'\x20on\x20a\x20deleted\x20database.');}}function I_(_0x255a34=Qr(),_0x26a7f0){const _0x434eef=Ui(_0x255a34,'database')['getImmediate']({'identifier':_0x26a7f0});if(!_0x434eef['_instanceStarted']){const _0x193a3c=ac('database');_0x193a3c&&Yd(_0x434eef,..._0x193a3c);}return _0x434eef;}function Yd(_0x10c5e5,_0xe0c02b,_0x41ebd8,_0x390b6a={}){_0x10c5e5=k(_0x10c5e5),_0x10c5e5['_checkNotDeleted']('useEmulator');const _0x5c2a03=_0xe0c02b+':'+_0x41ebd8,_0x209a6f=_0x10c5e5['_repoInternal'];if(_0x10c5e5['_instanceStarted']){if(_0x5c2a03===_0x10c5e5['_repoInternal']['repoInfo_']['host']&&De(_0x390b6a,_0x209a6f['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x16e048;if(_0x209a6f['repoInfo_']['nodeAdmin'])_0x390b6a['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x16e048=new tn(tn['OWNER']);else{if(_0x390b6a['mockUserToken']){const _0x4354d0=typeof _0x390b6a['mockUserToken']=='string'?_0x390b6a['mockUserToken']:cc(_0x390b6a['mockUserToken'],_0x10c5e5['app']['options']['projectId']);_0x16e048=new tn(_0x4354d0);}}Wt(_0xe0c02b)&&jr(_0xe0c02b),Gd(_0x209a6f,_0x5c2a03,_0x390b6a,_0x16e048);}function w_(_0x99c8c5){_0x99c8c5=k(_0x99c8c5),_0x99c8c5['_checkNotDeleted']('goOffline'),aa(_0x99c8c5['_repo']);}function C_(_0x10626f){_0x10626f=k(_0x10626f),_0x10626f['_checkNotDeleted']('goOnline'),Sd(_0x10626f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x50a976){Ll(ct),et(new Me('database',(_0x130ad8,{instanceIdentifier:_0x2fa266})=>{const _0x94c7bc=_0x130ad8['getProvider']('app')['getImmediate'](),_0x2698e1=_0x130ad8['getProvider']('auth-internal'),_0x34e29c=_0x130ad8['getProvider']('app-check-internal');return qd(_0x94c7bc,_0x2698e1,_0x34e29c,_0x2fa266);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x50a976),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jd{constructor(_0x27242e,_0x10526b){this['committed']=_0x27242e,this['snapshot']=_0x10526b;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function T_(_0x12862f,_0x5e1bb4,_0xd9365e){if(_0x12862f=k(_0x12862f),gs('Reference.transaction',_0x12862f['_path']),_0x12862f['key']==='.length'||_0x12862f['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x12862f['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5693e0=!0x0,_0x55bb20=new Ve(),_0x28d809=(_0x77004d,_0xaf7430,_0x4c7b33)=>{let _0x330036=null;_0x77004d?_0x55bb20['reject'](_0x77004d):(_0x330036=new rt(_0x4c7b33,new Z(_0x12862f['_repo'],_0x12862f['_path']),R),_0x55bb20['resolve'](new Jd(_0xaf7430,_0x330036)));},_0x32ef35=Fd(_0x12862f,()=>{});return bd(_0x12862f['_repo'],_0x12862f['_path'],_0x5e1bb4,_0x28d809,_0x32ef35,_0x5693e0),_0x55bb20['promise'];}ie['prototype']['simpleListen']=function(_0x224418,_0x1a44ce){this['sendRequest']('q',{'p':_0x224418},_0x1a44ce);},ie['prototype']['echo']=function(_0x254068,_0x158ee6){this['sendRequest']('echo',{'d':_0x254068},_0x158ee6);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Xd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function Zd(_0x52be90,..._0x39e252){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x52be90,..._0x39e252);}function nn(_0x12adaa,..._0x56bb5b){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x12adaa,..._0x56bb5b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x3d432b,..._0x5327d6){throw Es(_0x3d432b,..._0x5327d6);}function J(_0x57579a,..._0x255dad){return Es(_0x57579a,..._0x255dad);}function ya(_0x55852c,_0x366545,_0x12104f){const _0x6afe05={...Xd(),[_0x366545]:_0x12104f};return new Ut('auth','Firebase',_0x6afe05)['create'](_0x366545,{'appName':_0x55852c['name']});}function se(_0x4e3f39){return ya(_0x4e3f39,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x1f82f3,..._0x33407e){if(typeof _0x1f82f3!='string'){const _0x288922=_0x33407e[0x0],_0x3e41ca=[..._0x33407e['slice'](0x1)];return _0x3e41ca[0x0]&&(_0x3e41ca[0x0]['appName']=_0x1f82f3['name']),_0x1f82f3['_errorFactory']['create'](_0x288922,..._0x3e41ca);}return ma['create'](_0x1f82f3,..._0x33407e);}function m(_0x77527c,_0x7ad239,..._0x3f5a70){if(!_0x77527c)throw Es(_0x7ad239,..._0x3f5a70);}function te(_0x14026e){const _0x5018ce='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x14026e;throw nn(_0x5018ce),new Error(_0x5018ce);}function ae(_0x4dbaf9,_0x1cb589){_0x4dbaf9||te(_0x1cb589);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x5364d0;return typeof self<'u'&&((_0x5364d0=self['location'])==null?void 0x0:_0x5364d0['href'])||'';}function ef(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x15ac18;return typeof self<'u'&&((_0x15ac18=self['location'])==null?void 0x0:_0x15ac18['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(ef()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function nf(){if(typeof navigator>'u')return null;const _0x341a51=navigator;return _0x341a51['languages']&&_0x341a51['languages'][0x0]||_0x341a51['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x491a6c,_0x42a3b8){this['shortDelay']=_0x491a6c,this['longDelay']=_0x42a3b8,ae(_0x42a3b8>_0x491a6c,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return tf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x4c866d,_0x174615){ae(_0x4c866d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2069ee}=_0x4c866d['emulator'];return _0x174615?''+_0x2069ee+(_0x174615['startsWith']('/')?_0x174615['slice'](0x1):_0x174615):_0x2069ee;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0xba3c05,_0x488efd,_0x353e76){this['fetchImpl']=_0xba3c05,_0x488efd&&(this['headersImpl']=_0x488efd),_0x353e76&&(this['responseImpl']=_0x353e76);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},rf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],of=new Kt(0x7530,0xea60);function Re(_0x2c31a4,_0x3a7138){return _0x2c31a4['tenantId']&&!_0x3a7138['tenantId']?{..._0x3a7138,'tenantId':_0x2c31a4['tenantId']}:_0x3a7138;}async function Ae(_0x3292da,_0x5741ff,_0x3c5850,_0x36bbe5,_0x86ab8d={}){return Ea(_0x3292da,_0x86ab8d,async()=>{let _0x4acc88={},_0x49b164={};_0x36bbe5&&(_0x5741ff==='GET'?_0x49b164=_0x36bbe5:_0x4acc88={'body':JSON['stringify'](_0x36bbe5)});const _0x2c5d5b=at({..._0x49b164,'key':_0x3292da['config']['apiKey']})['slice'](0x1),_0x5f1136=await _0x3292da['_getAdditionalHeaders']();_0x5f1136['Content-Type']='application/json',_0x3292da['languageCode']&&(_0x5f1136['X-Firebase-Locale']=_0x3292da['languageCode']);const _0x1ec055={'method':_0x5741ff,'headers':_0x5f1136,..._0x4acc88};return lc()||(_0x1ec055['referrerPolicy']='strict-origin-when-cross-origin'),_0x3292da['emulatorConfig']&&Wt(_0x3292da['emulatorConfig']['host'])&&(_0x1ec055['credentials']='include'),va['fetch']()(await Ia(_0x3292da,_0x3292da['config']['apiHost'],_0x3c5850,_0x2c5d5b),_0x1ec055);});}async function Ea(_0x42c813,_0x213d10,_0x23c03c){_0x42c813['_canInitEmulator']=!0x1;const _0x1bec13={...sf,..._0x213d10};try{const _0x31712f=new cf(_0x42c813),_0x16dcab=await Promise['race']([_0x23c03c(),_0x31712f['promise']]);_0x31712f['clearNetworkTimeout']();const _0x2e77ea=await _0x16dcab['json']();if('needConfirmation'in _0x2e77ea)throw en(_0x42c813,'account-exists-with-different-credential',_0x2e77ea);if(_0x16dcab['ok']&&!('errorMessage'in _0x2e77ea))return _0x2e77ea;{const _0x344269=_0x16dcab['ok']?_0x2e77ea['errorMessage']:_0x2e77ea['error']['message'],[_0x552e02,_0x40fe50]=_0x344269['split']('\x20:\x20');if(_0x552e02==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x42c813,'credential-already-in-use',_0x2e77ea);if(_0x552e02==='EMAIL_EXISTS')throw en(_0x42c813,'email-already-in-use',_0x2e77ea);if(_0x552e02==='USER_DISABLED')throw en(_0x42c813,'user-disabled',_0x2e77ea);const _0x15e52e=_0x1bec13[_0x552e02]||_0x552e02['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x40fe50)throw ya(_0x42c813,_0x15e52e,_0x40fe50);K(_0x42c813,_0x15e52e);}}catch(_0x310ac9){if(_0x310ac9 instanceof Se)throw _0x310ac9;K(_0x42c813,'network-request-failed',{'message':String(_0x310ac9)});}}async function Yt(_0x38e00f,_0x1b2c30,_0x2a4332,_0x10594e,_0x166826={}){const _0x4430b7=await Ae(_0x38e00f,_0x1b2c30,_0x2a4332,_0x10594e,_0x166826);return'mfaPendingCredential'in _0x4430b7&&K(_0x38e00f,'multi-factor-auth-required',{'_serverResponse':_0x4430b7}),_0x4430b7;}async function Ia(_0x20c64a,_0x4c1d4f,_0x178f9d,_0x3977f5){const _0x33aefe=''+_0x4c1d4f+_0x178f9d+'?'+_0x3977f5,_0x2bbf13=_0x20c64a,_0x4c1c2f=_0x2bbf13['config']['emulator']?Is(_0x20c64a['config'],_0x33aefe):_0x20c64a['config']['apiScheme']+'://'+_0x33aefe;return rf['includes'](_0x178f9d)&&(await _0x2bbf13['_persistenceManagerAvailable'],_0x2bbf13['_getPersistenceType']()==='COOKIE')?_0x2bbf13['_getPersistence']()['_getFinalTarget'](_0x4c1c2f)['toString']():_0x4c1c2f;}function af(_0x41fd87){switch(_0x41fd87){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class cf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x56040d){this['auth']=_0x56040d,this['timer']=null,this['promise']=new Promise((_0x10fdfb,_0x5c9d12)=>{this['timer']=setTimeout(()=>_0x5c9d12(J(this['auth'],'network-request-failed')),of['get']());});}}function en(_0x3ee1a6,_0x210555,_0x4f67a3){const _0x20a0e1={'appName':_0x3ee1a6['name']};_0x4f67a3['email']&&(_0x20a0e1['email']=_0x4f67a3['email']),_0x4f67a3['phoneNumber']&&(_0x20a0e1['phoneNumber']=_0x4f67a3['phoneNumber']);const _0x2700f3=J(_0x3ee1a6,_0x210555,_0x20a0e1);return _0x2700f3['customData']['_tokenResponse']=_0x4f67a3,_0x2700f3;}function vr(_0x330f7d){return _0x330f7d!==void 0x0&&_0x330f7d['enterprise']!==void 0x0;}class lf{constructor(_0x3a9348){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3a9348['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3a9348['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3a9348['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x1b974a){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x2a977e of this['recaptchaEnforcementState'])if(_0x2a977e['provider']&&_0x2a977e['provider']===_0x1b974a)return af(_0x2a977e['enforcementState']);return null;}['isProviderEnabled'](_0xb7c7ca){return this['getProviderEnforcementState'](_0xb7c7ca)==='ENFORCE'||this['getProviderEnforcementState'](_0xb7c7ca)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function hf(_0x42ef1d,_0x882dd){return Ae(_0x42ef1d,'GET','/v2/recaptchaConfig',Re(_0x42ef1d,_0x882dd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function uf(_0x17c687,_0x34b4c9){return Ae(_0x17c687,'POST','/v1/accounts:delete',_0x34b4c9);}async function Sn(_0x5d3613,_0x513700){return Ae(_0x5d3613,'POST','/v1/accounts:lookup',_0x513700);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x4e70c2){if(_0x4e70c2)try{const _0x3b75ec=new Date(Number(_0x4e70c2));if(!isNaN(_0x3b75ec['getTime']()))return _0x3b75ec['toUTCString']();}catch{}}async function df(_0x7775cf,_0x4c9b07=!0x1){const _0x14c5a7=k(_0x7775cf),_0x2b0f5c=await _0x14c5a7['getIdToken'](_0x4c9b07),_0x1ff63e=ws(_0x2b0f5c);m(_0x1ff63e&&_0x1ff63e['exp']&&_0x1ff63e['auth_time']&&_0x1ff63e['iat'],_0x14c5a7['auth'],'internal-error');const _0x366668=typeof _0x1ff63e['firebase']=='object'?_0x1ff63e['firebase']:void 0x0,_0x5e6cb8=_0x366668==null?void 0x0:_0x366668['sign_in_provider'];return{'claims':_0x1ff63e,'token':_0x2b0f5c,'authTime':St(ci(_0x1ff63e['auth_time'])),'issuedAtTime':St(ci(_0x1ff63e['iat'])),'expirationTime':St(ci(_0x1ff63e['exp'])),'signInProvider':_0x5e6cb8||null,'signInSecondFactor':(_0x366668==null?void 0x0:_0x366668['sign_in_second_factor'])||null};}function ci(_0x1e16cb){return Number(_0x1e16cb)*0x3e8;}function ws(_0x2ccdea){const [_0x456c8a,_0x34f140,_0x28f465]=_0x2ccdea['split']('.');if(_0x456c8a===void 0x0||_0x34f140===void 0x0||_0x28f465===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2d7c98=cn(_0x34f140);return _0x2d7c98?JSON['parse'](_0x2d7c98):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0xdb2a96){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0xdb2a96==null?void 0x0:_0xdb2a96['toString']()),null;}}function Er(_0x5bf309){const _0xc5c2f9=ws(_0x5bf309);return m(_0xc5c2f9,'internal-error'),m(typeof _0xc5c2f9['exp']<'u','internal-error'),m(typeof _0xc5c2f9['iat']<'u','internal-error'),Number(_0xc5c2f9['exp'])-Number(_0xc5c2f9['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x235e0a,_0x3c634b,_0xf5325a=!0x1){if(_0xf5325a)return _0x3c634b;try{return await _0x3c634b;}catch(_0x5d037f){throw _0x5d037f instanceof Se&&ff(_0x5d037f)&&_0x235e0a['auth']['currentUser']===_0x235e0a&&await _0x235e0a['auth']['signOut'](),_0x5d037f;}}function ff({code:_0x4f5c34}){return _0x4f5c34==='auth/user-disabled'||_0x4f5c34==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pf{constructor(_0x29ee2c){this['user']=_0x29ee2c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x175ba7){if(_0x175ba7){const _0x2e2f59=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2e2f59;}else{this['errorBackoff']=0x7530;const _0x12f9c7=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x12f9c7);}}['schedule'](_0x51bd7a=!0x1){if(!this['isRunning'])return;const _0x31bac8=this['getInterval'](_0x51bd7a);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x31bac8);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x59b281){(_0x59b281==null?void 0x0:_0x59b281['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x5c29a6,_0x38aa4b){this['createdAt']=_0x5c29a6,this['lastLoginAt']=_0x38aa4b,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x2fe5d1){this['createdAt']=_0x2fe5d1['createdAt'],this['lastLoginAt']=_0x2fe5d1['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x3e1886){var _0x3ee07c;const _0x222030=_0x3e1886['auth'],_0x5bfff4=await _0x3e1886['getIdToken'](),_0x4462a5=await xt(_0x3e1886,Sn(_0x222030,{'idToken':_0x5bfff4}));m(_0x4462a5==null?void 0x0:_0x4462a5['users']['length'],_0x222030,'internal-error');const _0xee0974=_0x4462a5['users'][0x0];_0x3e1886['_notifyReloadListener'](_0xee0974);const _0x11eae0=(_0x3ee07c=_0xee0974['providerUserInfo'])!=null&&_0x3ee07c['length']?wa(_0xee0974['providerUserInfo']):[],_0xdbd23=gf(_0x3e1886['providerData'],_0x11eae0),_0x3167e1=_0x3e1886['isAnonymous'],_0x4d1504=!(_0x3e1886['email']&&_0xee0974['passwordHash'])&&!(_0xdbd23!=null&&_0xdbd23['length']),_0x3f486a=_0x3167e1?_0x4d1504:!0x1,_0x599833={'uid':_0xee0974['localId'],'displayName':_0xee0974['displayName']||null,'photoURL':_0xee0974['photoUrl']||null,'email':_0xee0974['email']||null,'emailVerified':_0xee0974['emailVerified']||!0x1,'phoneNumber':_0xee0974['phoneNumber']||null,'tenantId':_0xee0974['tenantId']||null,'providerData':_0xdbd23,'metadata':new Pi(_0xee0974['createdAt'],_0xee0974['lastLoginAt']),'isAnonymous':_0x3f486a};Object['assign'](_0x3e1886,_0x599833);}async function _f(_0x5bb525){const _0xb99894=k(_0x5bb525);await bn(_0xb99894),await _0xb99894['auth']['_persistUserIfCurrent'](_0xb99894),_0xb99894['auth']['_notifyListenersIfCurrent'](_0xb99894);}function gf(_0x3ba242,_0x56c19e){return[..._0x3ba242['filter'](_0x39dde2=>!_0x56c19e['some'](_0x327433=>_0x327433['providerId']===_0x39dde2['providerId'])),..._0x56c19e];}function wa(_0x3a3757){return _0x3a3757['map'](({providerId:_0x6c83dc,..._0x27e762})=>({'providerId':_0x6c83dc,'uid':_0x27e762['rawId']||'','displayName':_0x27e762['displayName']||null,'email':_0x27e762['email']||null,'phoneNumber':_0x27e762['phoneNumber']||null,'photoURL':_0x27e762['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x51d6a7,_0x5d7dec){const _0x3b79ef=await Ea(_0x51d6a7,{},async()=>{const _0x216209=at({'grant_type':'refresh_token','refresh_token':_0x5d7dec})['slice'](0x1),{tokenApiHost:_0x496ad4,apiKey:_0x2a7b05}=_0x51d6a7['config'],_0x4deec6=await Ia(_0x51d6a7,_0x496ad4,'/v1/token','key='+_0x2a7b05),_0x9893=await _0x51d6a7['_getAdditionalHeaders']();_0x9893['Content-Type']='application/x-www-form-urlencoded';const _0x3583db={'method':'POST','headers':_0x9893,'body':_0x216209};return _0x51d6a7['emulatorConfig']&&Wt(_0x51d6a7['emulatorConfig']['host'])&&(_0x3583db['credentials']='include'),va['fetch']()(_0x4deec6,_0x3583db);});return{'accessToken':_0x3b79ef['access_token'],'expiresIn':_0x3b79ef['expires_in'],'refreshToken':_0x3b79ef['refresh_token']};}async function yf(_0x4c9126,_0x50b393){return Ae(_0x4c9126,'POST','/v2/accounts:revokeToken',Re(_0x4c9126,_0x50b393));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5a4417){m(_0x5a4417['idToken'],'internal-error'),m(typeof _0x5a4417['idToken']<'u','internal-error'),m(typeof _0x5a4417['refreshToken']<'u','internal-error');const _0x14de66='expiresIn'in _0x5a4417&&typeof _0x5a4417['expiresIn']<'u'?Number(_0x5a4417['expiresIn']):Er(_0x5a4417['idToken']);this['updateTokensAndExpiration'](_0x5a4417['idToken'],_0x5a4417['refreshToken'],_0x14de66);}['updateFromIdToken'](_0x114315){m(_0x114315['length']!==0x0,'internal-error');const _0x1dc487=Er(_0x114315);this['updateTokensAndExpiration'](_0x114315,null,_0x1dc487);}async['getToken'](_0x436196,_0x1a4282=!0x1){return!_0x1a4282&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x436196,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x436196,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x549054,_0x141276){const {accessToken:_0x179279,refreshToken:_0x57012f,expiresIn:_0x49848c}=await mf(_0x549054,_0x141276);this['updateTokensAndExpiration'](_0x179279,_0x57012f,Number(_0x49848c));}['updateTokensAndExpiration'](_0x183b53,_0x591e07,_0x1d7626){this['refreshToken']=_0x591e07||null,this['accessToken']=_0x183b53||null,this['expirationTime']=Date['now']()+_0x1d7626*0x3e8;}static['fromJSON'](_0x30743e,_0xa7676d){const {refreshToken:_0xc1a026,accessToken:_0x315a15,expirationTime:_0x1ab6f0}=_0xa7676d,_0x6a5503=new Je();return _0xc1a026&&(m(typeof _0xc1a026=='string','internal-error',{'appName':_0x30743e}),_0x6a5503['refreshToken']=_0xc1a026),_0x315a15&&(m(typeof _0x315a15=='string','internal-error',{'appName':_0x30743e}),_0x6a5503['accessToken']=_0x315a15),_0x1ab6f0&&(m(typeof _0x1ab6f0=='number','internal-error',{'appName':_0x30743e}),_0x6a5503['expirationTime']=_0x1ab6f0),_0x6a5503;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4ea0cc){this['accessToken']=_0x4ea0cc['accessToken'],this['refreshToken']=_0x4ea0cc['refreshToken'],this['expirationTime']=_0x4ea0cc['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x34de6a,_0x4c2eee){m(typeof _0x34de6a=='string'||typeof _0x34de6a>'u','internal-error',{'appName':_0x4c2eee});}class z{constructor({uid:_0x149632,auth:_0x98511e,stsTokenManager:_0x94039b,..._0x257604}){this['providerId']='firebase',this['proactiveRefresh']=new pf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x149632,this['auth']=_0x98511e,this['stsTokenManager']=_0x94039b,this['accessToken']=_0x94039b['accessToken'],this['displayName']=_0x257604['displayName']||null,this['email']=_0x257604['email']||null,this['emailVerified']=_0x257604['emailVerified']||!0x1,this['phoneNumber']=_0x257604['phoneNumber']||null,this['photoURL']=_0x257604['photoURL']||null,this['isAnonymous']=_0x257604['isAnonymous']||!0x1,this['tenantId']=_0x257604['tenantId']||null,this['providerData']=_0x257604['providerData']?[..._0x257604['providerData']]:[],this['metadata']=new Pi(_0x257604['createdAt']||void 0x0,_0x257604['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1b4ef8){const _0x45ea88=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0x1b4ef8));return m(_0x45ea88,this['auth'],'internal-error'),this['accessToken']!==_0x45ea88&&(this['accessToken']=_0x45ea88,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x45ea88;}['getIdTokenResult'](_0x209381){return df(this,_0x209381);}['reload'](){return _f(this);}['_assign'](_0x5c05f1){this!==_0x5c05f1&&(m(this['uid']===_0x5c05f1['uid'],this['auth'],'internal-error'),this['displayName']=_0x5c05f1['displayName'],this['photoURL']=_0x5c05f1['photoURL'],this['email']=_0x5c05f1['email'],this['emailVerified']=_0x5c05f1['emailVerified'],this['phoneNumber']=_0x5c05f1['phoneNumber'],this['isAnonymous']=_0x5c05f1['isAnonymous'],this['tenantId']=_0x5c05f1['tenantId'],this['providerData']=_0x5c05f1['providerData']['map'](_0x37ad13=>({..._0x37ad13})),this['metadata']['_copy'](_0x5c05f1['metadata']),this['stsTokenManager']['_assign'](_0x5c05f1['stsTokenManager']));}['_clone'](_0x273e06){const _0xa926fd=new z({...this,'auth':_0x273e06,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xa926fd['metadata']['_copy'](this['metadata']),_0xa926fd;}['_onReload'](_0x3c2d0e){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x3c2d0e,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4e685f){this['reloadListener']?this['reloadListener'](_0x4e685f):this['reloadUserInfo']=_0x4e685f;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x647f9,_0xae1522=!0x1){let _0x5e21e2=!0x1;_0x647f9['idToken']&&_0x647f9['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x647f9),_0x5e21e2=!0x0),_0xae1522&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5e21e2&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x592609=await this['getIdToken']();return await xt(this,uf(this['auth'],{'idToken':_0x592609})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x51a89f=>({..._0x51a89f})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x573358,_0x327666){const _0x4cb192=_0x327666['displayName']??void 0x0,_0x51e469=_0x327666['email']??void 0x0,_0x49b016=_0x327666['phoneNumber']??void 0x0,_0xedac25=_0x327666['photoURL']??void 0x0,_0x266ec8=_0x327666['tenantId']??void 0x0,_0x1819c1=_0x327666['_redirectEventId']??void 0x0,_0x293981=_0x327666['createdAt']??void 0x0,_0x2fd83d=_0x327666['lastLoginAt']??void 0x0,{uid:_0xc97407,emailVerified:_0x49b890,isAnonymous:_0x4df51e,providerData:_0x5391e5,stsTokenManager:_0x178a86}=_0x327666;m(_0xc97407&&_0x178a86,_0x573358,'internal-error');const _0x2f8385=Je['fromJSON'](this['name'],_0x178a86);m(typeof _0xc97407=='string',_0x573358,'internal-error'),ce(_0x4cb192,_0x573358['name']),ce(_0x51e469,_0x573358['name']),m(typeof _0x49b890=='boolean',_0x573358,'internal-error'),m(typeof _0x4df51e=='boolean',_0x573358,'internal-error'),ce(_0x49b016,_0x573358['name']),ce(_0xedac25,_0x573358['name']),ce(_0x266ec8,_0x573358['name']),ce(_0x1819c1,_0x573358['name']),ce(_0x293981,_0x573358['name']),ce(_0x2fd83d,_0x573358['name']);const _0x595179=new z({'uid':_0xc97407,'auth':_0x573358,'email':_0x51e469,'emailVerified':_0x49b890,'displayName':_0x4cb192,'isAnonymous':_0x4df51e,'photoURL':_0xedac25,'phoneNumber':_0x49b016,'tenantId':_0x266ec8,'stsTokenManager':_0x2f8385,'createdAt':_0x293981,'lastLoginAt':_0x2fd83d});return _0x5391e5&&Array['isArray'](_0x5391e5)&&(_0x595179['providerData']=_0x5391e5['map'](_0x4fe898=>({..._0x4fe898}))),_0x1819c1&&(_0x595179['_redirectEventId']=_0x1819c1),_0x595179;}static async['_fromIdTokenResponse'](_0x1349e2,_0x401514,_0x5e2d25=!0x1){const _0x3de626=new Je();_0x3de626['updateFromServerResponse'](_0x401514);const _0x43b0a0=new z({'uid':_0x401514['localId'],'auth':_0x1349e2,'stsTokenManager':_0x3de626,'isAnonymous':_0x5e2d25});return await bn(_0x43b0a0),_0x43b0a0;}static async['_fromGetAccountInfoResponse'](_0x23de25,_0x388671,_0x55209a){const _0x27f943=_0x388671['users'][0x0];m(_0x27f943['localId']!==void 0x0,'internal-error');const _0x38193c=_0x27f943['providerUserInfo']!==void 0x0?wa(_0x27f943['providerUserInfo']):[],_0x19d8de=!(_0x27f943['email']&&_0x27f943['passwordHash'])&&!(_0x38193c!=null&&_0x38193c['length']),_0x4fb75b=new Je();_0x4fb75b['updateFromIdToken'](_0x55209a);const _0x1b330c=new z({'uid':_0x27f943['localId'],'auth':_0x23de25,'stsTokenManager':_0x4fb75b,'isAnonymous':_0x19d8de}),_0x29ed21={'uid':_0x27f943['localId'],'displayName':_0x27f943['displayName']||null,'photoURL':_0x27f943['photoUrl']||null,'email':_0x27f943['email']||null,'emailVerified':_0x27f943['emailVerified']||!0x1,'phoneNumber':_0x27f943['phoneNumber']||null,'tenantId':_0x27f943['tenantId']||null,'providerData':_0x38193c,'metadata':new Pi(_0x27f943['createdAt'],_0x27f943['lastLoginAt']),'isAnonymous':!(_0x27f943['email']&&_0x27f943['passwordHash'])&&!(_0x38193c!=null&&_0x38193c['length'])};return Object['assign'](_0x1b330c,_0x29ed21),_0x1b330c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x5d0ecf){ae(_0x5d0ecf instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1bb4e1=Ir['get'](_0x5d0ecf);return _0x1bb4e1?(ae(_0x1bb4e1 instanceof _0x5d0ecf,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1bb4e1):(_0x1bb4e1=new _0x5d0ecf(),Ir['set'](_0x5d0ecf,_0x1bb4e1),_0x1bb4e1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2e9ebf,_0x2fc1e1){this['storage'][_0x2e9ebf]=_0x2fc1e1;}async['_get'](_0x4c271f){const _0x16117f=this['storage'][_0x4c271f];return _0x16117f===void 0x0?null:_0x16117f;}async['_remove'](_0x15d42d){delete this['storage'][_0x15d42d];}['_addListener'](_0xe31182,_0x128d36){}['_removeListener'](_0x26a662,_0x418d39){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x1ad1af,_0x152eb1,_0x4227f0){return'firebase:'+_0x1ad1af+':'+_0x152eb1+':'+_0x4227f0;}class Xe{constructor(_0x2356e7,_0x5da57c,_0x252b16){this['persistence']=_0x2356e7,this['auth']=_0x5da57c,this['userKey']=_0x252b16;const {config:_0x23f726,name:_0x346e4f}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x23f726['apiKey'],_0x346e4f),this['fullPersistenceKey']=sn('persistence',_0x23f726['apiKey'],_0x346e4f),this['boundEventHandler']=_0x5da57c['_onStorageEvent']['bind'](_0x5da57c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x5ae28a){return this['persistence']['_set'](this['fullUserKey'],_0x5ae28a['toJSON']());}async['getCurrentUser'](){const _0x6e55bc=await this['persistence']['_get'](this['fullUserKey']);if(!_0x6e55bc)return null;if(typeof _0x6e55bc=='string'){const _0x561111=await Sn(this['auth'],{'idToken':_0x6e55bc})['catch'](()=>{});return _0x561111?z['_fromGetAccountInfoResponse'](this['auth'],_0x561111,_0x6e55bc):null;}return z['_fromJSON'](this['auth'],_0x6e55bc);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x592674){if(this['persistence']===_0x592674)return;const _0x10cd35=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x592674,_0x10cd35)return this['setCurrentUser'](_0x10cd35);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x136838,_0x128754,_0x50677d='authUser'){if(!_0x128754['length'])return new Xe(ne(wr),_0x136838,_0x50677d);const _0x31481e=(await Promise['all'](_0x128754['map'](async _0x1c6a69=>{if(await _0x1c6a69['_isAvailable']())return _0x1c6a69;})))['filter'](_0x1885e6=>_0x1885e6);let _0x4b250f=_0x31481e[0x0]||ne(wr);const _0x223456=sn(_0x50677d,_0x136838['config']['apiKey'],_0x136838['name']);let _0x26e983=null;for(const _0x5848d1 of _0x128754)try{const _0xb78aec=await _0x5848d1['_get'](_0x223456);if(_0xb78aec){let _0x4adb8b;if(typeof _0xb78aec=='string'){const _0x5b953d=await Sn(_0x136838,{'idToken':_0xb78aec})['catch'](()=>{});if(!_0x5b953d)break;_0x4adb8b=await z['_fromGetAccountInfoResponse'](_0x136838,_0x5b953d,_0xb78aec);}else _0x4adb8b=z['_fromJSON'](_0x136838,_0xb78aec);_0x5848d1!==_0x4b250f&&(_0x26e983=_0x4adb8b),_0x4b250f=_0x5848d1;break;}}catch{}const _0x34a2ac=_0x31481e['filter'](_0x51deb1=>_0x51deb1['_shouldAllowMigration']);return!_0x4b250f['_shouldAllowMigration']||!_0x34a2ac['length']?new Xe(_0x4b250f,_0x136838,_0x50677d):(_0x4b250f=_0x34a2ac[0x0],_0x26e983&&await _0x4b250f['_set'](_0x223456,_0x26e983['toJSON']()),await Promise['all'](_0x128754['map'](async _0x5291c6=>{if(_0x5291c6!==_0x4b250f)try{await _0x5291c6['_remove'](_0x223456);}catch{}})),new Xe(_0x4b250f,_0x136838,_0x50677d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x2bbb36){const _0x5a39dc=_0x2bbb36['toLowerCase']();if(_0x5a39dc['includes']('opera/')||_0x5a39dc['includes']('opr/')||_0x5a39dc['includes']('opios/'))return'Opera';if(Ra(_0x5a39dc))return'IEMobile';if(_0x5a39dc['includes']('msie')||_0x5a39dc['includes']('trident/'))return'IE';if(_0x5a39dc['includes']('edge/'))return'Edge';if(Ta(_0x5a39dc))return'Firefox';if(_0x5a39dc['includes']('silk/'))return'Silk';if(ka(_0x5a39dc))return'Blackberry';if(Na(_0x5a39dc))return'Webos';if(Sa(_0x5a39dc))return'Safari';if((_0x5a39dc['includes']('chrome/')||ba(_0x5a39dc))&&!_0x5a39dc['includes']('edge/'))return'Chrome';if(Aa(_0x5a39dc))return'Android';{const _0x4cd614=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x157ff3=_0x2bbb36['match'](_0x4cd614);if((_0x157ff3==null?void 0x0:_0x157ff3['length'])===0x2)return _0x157ff3[0x1];}return'Other';}function Ta(_0x2a54ca=W()){return/firefox\//i['test'](_0x2a54ca);}function Sa(_0x47efd4=W()){const _0x11fb24=_0x47efd4['toLowerCase']();return _0x11fb24['includes']('safari/')&&!_0x11fb24['includes']('chrome/')&&!_0x11fb24['includes']('crios/')&&!_0x11fb24['includes']('android');}function ba(_0x337fcc=W()){return/crios\//i['test'](_0x337fcc);}function Ra(_0x4741ec=W()){return/iemobile/i['test'](_0x4741ec);}function Aa(_0x5f376d=W()){return/android/i['test'](_0x5f376d);}function ka(_0x23d025=W()){return/blackberry/i['test'](_0x23d025);}function Na(_0x22a130=W()){return/webos/i['test'](_0x22a130);}function Cs(_0x4449ed=W()){return/iphone|ipad|ipod/i['test'](_0x4449ed)||/macintosh/i['test'](_0x4449ed)&&/mobile/i['test'](_0x4449ed);}function vf(_0x5096c7=W()){var _0x223e88;return Cs(_0x5096c7)&&!!((_0x223e88=window['navigator'])!=null&&_0x223e88['standalone']);}function Ef(){return uc()&&document['documentMode']===0xa;}function Pa(_0x13f9e5=W()){return Cs(_0x13f9e5)||Aa(_0x13f9e5)||Na(_0x13f9e5)||ka(_0x13f9e5)||/windows phone/i['test'](_0x13f9e5)||Ra(_0x13f9e5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x5a9587,_0x444aa6=[]){let _0x1e2044;switch(_0x5a9587){case'Browser':_0x1e2044=Cr(W());break;case'Worker':_0x1e2044=Cr(W())+'-'+_0x5a9587;break;default:_0x1e2044=_0x5a9587;}const _0x317ab9=_0x444aa6['length']?_0x444aa6['join'](','):'FirebaseCore-web';return _0x1e2044+'/JsCore/'+ct+'/'+_0x317ab9;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class If{constructor(_0x1bea3b){this['auth']=_0x1bea3b,this['queue']=[];}['pushCallback'](_0x20c2ad,_0x3279e6){const _0x5a2a34=_0x43e8dc=>new Promise((_0x4c512f,_0x283761)=>{try{const _0x128ce3=_0x20c2ad(_0x43e8dc);_0x4c512f(_0x128ce3);}catch(_0x5c70f8){_0x283761(_0x5c70f8);}});_0x5a2a34['onAbort']=_0x3279e6,this['queue']['push'](_0x5a2a34);const _0x300f82=this['queue']['length']-0x1;return()=>{this['queue'][_0x300f82]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4a24b6){if(this['auth']['currentUser']===_0x4a24b6)return;const _0x6261ab=[];try{for(const _0x436778 of this['queue'])await _0x436778(_0x4a24b6),_0x436778['onAbort']&&_0x6261ab['push'](_0x436778['onAbort']);}catch(_0x1022d3){_0x6261ab['reverse']();for(const _0x4f8003 of _0x6261ab)try{_0x4f8003();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1022d3==null?void 0x0:_0x1022d3['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function wf(_0x2619fd,_0x8da05b={}){return Ae(_0x2619fd,'GET','/v2/passwordPolicy',Re(_0x2619fd,_0x8da05b));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cf=0x6;class Tf{constructor(_0x2331b0){var _0x44c88f;const _0x218177=_0x2331b0['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x218177['minPasswordLength']??Cf,_0x218177['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x218177['maxPasswordLength']),_0x218177['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x218177['containsLowercaseCharacter']),_0x218177['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x218177['containsUppercaseCharacter']),_0x218177['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x218177['containsNumericCharacter']),_0x218177['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x218177['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2331b0['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x44c88f=_0x2331b0['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x44c88f['join'](''))??'',this['forceUpgradeOnSignin']=_0x2331b0['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2331b0['schemaVersion'];}['validatePassword'](_0x1fdf05){const _0x215dff={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1fdf05,_0x215dff),this['validatePasswordCharacterOptions'](_0x1fdf05,_0x215dff),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['meetsMinPasswordLength']??!0x0),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['meetsMaxPasswordLength']??!0x0),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['containsLowercaseLetter']??!0x0),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['containsUppercaseLetter']??!0x0),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['containsNumericCharacter']??!0x0),_0x215dff['isValid']&&(_0x215dff['isValid']=_0x215dff['containsNonAlphanumericCharacter']??!0x0),_0x215dff;}['validatePasswordLengthOptions'](_0x239fb0,_0xf1e0d7){const _0x3ce7d0=this['customStrengthOptions']['minPasswordLength'],_0x1423be=this['customStrengthOptions']['maxPasswordLength'];_0x3ce7d0&&(_0xf1e0d7['meetsMinPasswordLength']=_0x239fb0['length']>=_0x3ce7d0),_0x1423be&&(_0xf1e0d7['meetsMaxPasswordLength']=_0x239fb0['length']<=_0x1423be);}['validatePasswordCharacterOptions'](_0x532486,_0x37f0fc){this['updatePasswordCharacterOptionsStatuses'](_0x37f0fc,!0x1,!0x1,!0x1,!0x1);let _0x498013;for(let _0x10e043=0x0;_0x10e043<_0x532486['length'];_0x10e043++)_0x498013=_0x532486['charAt'](_0x10e043),this['updatePasswordCharacterOptionsStatuses'](_0x37f0fc,_0x498013>='a'&&_0x498013<='z',_0x498013>='A'&&_0x498013<='Z',_0x498013>='0'&&_0x498013<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x498013));}['updatePasswordCharacterOptionsStatuses'](_0x20a0ff,_0x2d373e,_0x4efa3d,_0x4ad6ec,_0x6cc08d){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x20a0ff['containsLowercaseLetter']||(_0x20a0ff['containsLowercaseLetter']=_0x2d373e)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x20a0ff['containsUppercaseLetter']||(_0x20a0ff['containsUppercaseLetter']=_0x4efa3d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x20a0ff['containsNumericCharacter']||(_0x20a0ff['containsNumericCharacter']=_0x4ad6ec)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x20a0ff['containsNonAlphanumericCharacter']||(_0x20a0ff['containsNonAlphanumericCharacter']=_0x6cc08d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x5d1b22,_0x2ff664,_0x182128,_0x419d2f){this['app']=_0x5d1b22,this['heartbeatServiceProvider']=_0x2ff664,this['appCheckServiceProvider']=_0x182128,this['config']=_0x419d2f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new If(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5d1b22['name'],this['clientVersion']=_0x419d2f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x217e97=>this['_resolvePersistenceManagerAvailable']=_0x217e97);}['_initializeWithPersistence'](_0x3459a6,_0x1c7b5b){return _0x1c7b5b&&(this['_popupRedirectResolver']=ne(_0x1c7b5b)),this['_initializationPromise']=this['queue'](async()=>{var _0x5db7f0,_0x1c6903,_0x7f5bbb;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x3459a6),(_0x5db7f0=this['_resolvePersistenceManagerAvailable'])==null||_0x5db7f0['call'](this),!this['_deleted'])){if((_0x1c6903=this['_popupRedirectResolver'])!=null&&_0x1c6903['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x1c7b5b),this['lastNotifiedUid']=((_0x7f5bbb=this['currentUser'])==null?void 0x0:_0x7f5bbb['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x152c60=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x152c60)){if(this['currentUser']&&_0x152c60&&this['currentUser']['uid']===_0x152c60['uid']){this['_currentUser']['_assign'](_0x152c60),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x152c60,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x5e6c63){try{const _0x4754fa=await Sn(this,{'idToken':_0x5e6c63}),_0x1bde69=await z['_fromGetAccountInfoResponse'](this,_0x4754fa,_0x5e6c63);await this['directlySetCurrentUser'](_0x1bde69);}catch(_0x3d8ee6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x3d8ee6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xccbcc2){var _0x376b06;if(H(this['app'])){const _0x5aec92=this['app']['settings']['authIdToken'];return _0x5aec92?new Promise(_0x23f807=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5aec92)['then'](_0x23f807,_0x23f807));}):this['directlySetCurrentUser'](null);}const _0x710f7b=await this['assertedPersistence']['getCurrentUser']();let _0x1a69d3=_0x710f7b,_0x28c8df=!0x1;if(_0xccbcc2&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5e4b1b=(_0x376b06=this['redirectUser'])==null?void 0x0:_0x376b06['_redirectEventId'],_0x176813=_0x1a69d3==null?void 0x0:_0x1a69d3['_redirectEventId'],_0x297d96=await this['tryRedirectSignIn'](_0xccbcc2);(!_0x5e4b1b||_0x5e4b1b===_0x176813)&&(_0x297d96!=null&&_0x297d96['user'])&&(_0x1a69d3=_0x297d96['user'],_0x28c8df=!0x0);}if(!_0x1a69d3)return this['directlySetCurrentUser'](null);if(!_0x1a69d3['_redirectEventId']){if(_0x28c8df)try{await this['beforeStateQueue']['runMiddleware'](_0x1a69d3);}catch(_0x52e170){_0x1a69d3=_0x710f7b,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x52e170));}return _0x1a69d3?this['reloadAndSetCurrentUserOrClear'](_0x1a69d3):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1a69d3['_redirectEventId']?this['directlySetCurrentUser'](_0x1a69d3):this['reloadAndSetCurrentUserOrClear'](_0x1a69d3);}async['tryRedirectSignIn'](_0x401171){let _0x1de3e5=null;try{_0x1de3e5=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x401171,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1de3e5;}async['reloadAndSetCurrentUserOrClear'](_0x561eeb){try{await bn(_0x561eeb);}catch(_0x335fe8){if((_0x335fe8==null?void 0x0:_0x335fe8['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x561eeb);}['useDeviceLanguage'](){this['languageCode']=nf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x56682c){if(H(this['app']))return Promise['reject'](se(this));const _0x25eb12=_0x56682c?k(_0x56682c):null;return _0x25eb12&&m(_0x25eb12['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x25eb12&&_0x25eb12['_clone'](this));}async['_updateCurrentUser'](_0x358624,_0x3af4a5=!0x1){if(!this['_deleted'])return _0x358624&&m(this['tenantId']===_0x358624['tenantId'],this,'tenant-id-mismatch'),_0x3af4a5||await this['beforeStateQueue']['runMiddleware'](_0x358624),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x358624),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x46d2a7){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x46d2a7));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x192fff){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x476261=this['_getPasswordPolicyInternal']();return _0x476261['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x476261['validatePassword'](_0x192fff);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x25ca10=await wf(this),_0x5b6759=new Tf(_0x25ca10);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5b6759:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5b6759;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x48e487){this['_errorFactory']=new Ut('auth','Firebase',_0x48e487());}['onAuthStateChanged'](_0x237f5e,_0x470271,_0x4a23b3){return this['registerStateListener'](this['authStateSubscription'],_0x237f5e,_0x470271,_0x4a23b3);}['beforeAuthStateChanged'](_0x22528e,_0x58f16a){return this['beforeStateQueue']['pushCallback'](_0x22528e,_0x58f16a);}['onIdTokenChanged'](_0x50721f,_0x4e1139,_0x556f48){return this['registerStateListener'](this['idTokenSubscription'],_0x50721f,_0x4e1139,_0x556f48);}['authStateReady'](){return new Promise((_0x4938c1,_0x396c6e)=>{if(this['currentUser'])_0x4938c1();else{const _0x40031d=this['onAuthStateChanged'](()=>{_0x40031d(),_0x4938c1();},_0x396c6e);}});}async['revokeAccessToken'](_0x3f68d0){if(this['currentUser']){const _0x2c3f5f=await this['currentUser']['getIdToken'](),_0x2a6baf={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3f68d0,'idToken':_0x2c3f5f};this['tenantId']!=null&&(_0x2a6baf['tenantId']=this['tenantId']),await yf(this,_0x2a6baf);}}['toJSON'](){var _0x4933da;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4933da=this['_currentUser'])==null?void 0x0:_0x4933da['toJSON']()};}async['_setRedirectUser'](_0x4c8485,_0x1d5c1b){const _0x13e21d=await this['getOrInitRedirectPersistenceManager'](_0x1d5c1b);return _0x4c8485===null?_0x13e21d['removeCurrentUser']():_0x13e21d['setCurrentUser'](_0x4c8485);}async['getOrInitRedirectPersistenceManager'](_0x330bdd){if(!this['redirectPersistenceManager']){const _0x5084ab=_0x330bdd&&ne(_0x330bdd)||this['_popupRedirectResolver'];m(_0x5084ab,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x5084ab['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xfd6081){var _0x190d50,_0x5eddea;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x190d50=this['_currentUser'])==null?void 0x0:_0x190d50['_redirectEventId'])===_0xfd6081?this['_currentUser']:((_0x5eddea=this['redirectUser'])==null?void 0x0:_0x5eddea['_redirectEventId'])===_0xfd6081?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1c0263){if(_0x1c0263===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1c0263));}['_notifyListenersIfCurrent'](_0x53f090){_0x53f090===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x101524;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x58cd60=((_0x101524=this['currentUser'])==null?void 0x0:_0x101524['uid'])??null;this['lastNotifiedUid']!==_0x58cd60&&(this['lastNotifiedUid']=_0x58cd60,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x497e66,_0xcbf9ff,_0x45abbc,_0xccf206){if(this['_deleted'])return()=>{};const _0x4bf8e6=typeof _0xcbf9ff=='function'?_0xcbf9ff:_0xcbf9ff['next']['bind'](_0xcbf9ff);let _0x5abd4d=!0x1;const _0x226932=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x226932,this,'internal-error'),_0x226932['then'](()=>{_0x5abd4d||_0x4bf8e6(this['currentUser']);}),typeof _0xcbf9ff=='function'){const _0x4fd6a7=_0x497e66['addObserver'](_0xcbf9ff,_0x45abbc,_0xccf206);return()=>{_0x5abd4d=!0x0,_0x4fd6a7();};}else{const _0x137e5a=_0x497e66['addObserver'](_0xcbf9ff);return()=>{_0x5abd4d=!0x0,_0x137e5a();};}}async['directlySetCurrentUser'](_0x29c8a2){this['currentUser']&&this['currentUser']!==_0x29c8a2&&this['_currentUser']['_stopProactiveRefresh'](),_0x29c8a2&&this['isProactiveRefreshEnabled']&&_0x29c8a2['_startProactiveRefresh'](),this['currentUser']=_0x29c8a2,_0x29c8a2?await this['assertedPersistence']['setCurrentUser'](_0x29c8a2):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x112f13){return this['operations']=this['operations']['then'](_0x112f13,_0x112f13),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0xb6a65d){!_0xb6a65d||this['frameworks']['includes'](_0xb6a65d)||(this['frameworks']['push'](_0xb6a65d),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xc6e146;const _0x23e5fa={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x23e5fa['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1ab262=await((_0xc6e146=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xc6e146['getHeartbeatsHeader']());_0x1ab262&&(_0x23e5fa['X-Firebase-Client']=_0x1ab262);const _0x2053e0=await this['_getAppCheckToken']();return _0x2053e0&&(_0x23e5fa['X-Firebase-AppCheck']=_0x2053e0),_0x23e5fa;}async['_getAppCheckToken'](){var _0x547f72;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3f56df=await((_0x547f72=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x547f72['getToken']());return _0x3f56df!=null&&_0x3f56df['error']&&Zd('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3f56df['error']),_0x3f56df==null?void 0x0:_0x3f56df['token'];}}function qe(_0x845144){return k(_0x845144);}class Tr{constructor(_0x2fdd20){this['auth']=_0x2fdd20,this['observer']=null,this['addObserver']=Ic(_0x43db68=>this['observer']=_0x43db68);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function bf(_0x5652ab){zn=_0x5652ab;}function Da(_0x2cc3e2){return zn['loadJS'](_0x2cc3e2);}function Rf(){return zn['recaptchaEnterpriseScript'];}function Af(){return zn['gapiScript'];}function kf(_0x499628){return'__'+_0x499628+Math['floor'](Math['random']()*0xf4240);}class Nf{constructor(){this['enterprise']=new Pf();}['ready'](_0x52d910){_0x52d910();}['execute'](_0x434e79,_0x2bd387){return Promise['resolve']('token');}['render'](_0x7c837e,_0x245788){return'';}}class Pf{['ready'](_0x2a41f6){_0x2a41f6();}['execute'](_0x53d508,_0x3d14c6){return Promise['resolve']('token');}['render'](_0x250213,_0x37b85d){return'';}}const Of='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x4d00a5){this['type']=Of,this['auth']=qe(_0x4d00a5);}async['verify'](_0x53aa6e='verify',_0x422894=!0x1){async function _0x58d889(_0x9032d6){if(!_0x422894){if(_0x9032d6['tenantId']==null&&_0x9032d6['_agentRecaptchaConfig']!=null)return _0x9032d6['_agentRecaptchaConfig']['siteKey'];if(_0x9032d6['tenantId']!=null&&_0x9032d6['_tenantRecaptchaConfigs'][_0x9032d6['tenantId']]!==void 0x0)return _0x9032d6['_tenantRecaptchaConfigs'][_0x9032d6['tenantId']]['siteKey'];}return new Promise(async(_0x199ae1,_0x3c0628)=>{hf(_0x9032d6,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x1763ef=>{if(_0x1763ef['recaptchaKey']===void 0x0)_0x3c0628(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x280355=new lf(_0x1763ef);return _0x9032d6['tenantId']==null?_0x9032d6['_agentRecaptchaConfig']=_0x280355:_0x9032d6['_tenantRecaptchaConfigs'][_0x9032d6['tenantId']]=_0x280355,_0x199ae1(_0x280355['siteKey']);}})['catch'](_0x27e3b3=>{_0x3c0628(_0x27e3b3);});});}function _0x117c32(_0x563083,_0x2e6ba7,_0x2371a7){const _0x6cb0aa=window['grecaptcha'];vr(_0x6cb0aa)?_0x6cb0aa['enterprise']['ready'](()=>{_0x6cb0aa['enterprise']['execute'](_0x563083,{'action':_0x53aa6e})['then'](_0x28880b=>{_0x2e6ba7(_0x28880b);})['catch'](()=>{_0x2e6ba7(Ma);});}):_0x2371a7(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Nf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4137f1,_0x4b51bc)=>{_0x58d889(this['auth'])['then'](async _0x845d80=>{if(!_0x422894&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x117c32(_0x845d80,_0x4137f1,_0x4b51bc);else{if(typeof window>'u'){_0x4b51bc(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x20e1ec=Rf();_0x20e1ec['length']!==0x0&&(_0x20e1ec+=_0x845d80+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x5789c8;(_0x5789c8=le['scriptInjectionDeferred'])==null||_0x5789c8['resolve']();},Da(_0x20e1ec)['then'](()=>{var _0xf97bfa;return(_0xf97bfa=le['scriptInjectionDeferred'])==null?void 0x0:_0xf97bfa['promise'];})['then'](()=>{_0x117c32(_0x845d80,_0x4137f1,_0x4b51bc);})['catch'](_0x4ed9a5=>{_0x4b51bc(_0x4ed9a5);});}})['catch'](_0x3d257b=>{_0x4b51bc(_0x3d257b);});});}}le['scriptInjectionDeferred']=null;async function br(_0x58baad,_0x25a2f8,_0x5ea148,_0x1c2dc0=!0x1,_0xe31b52=!0x1){const _0x2f6474=new le(_0x58baad);let _0x4440d7;if(_0xe31b52)_0x4440d7=Ma;else try{_0x4440d7=await _0x2f6474['verify'](_0x5ea148);}catch{_0x4440d7=await _0x2f6474['verify'](_0x5ea148,!0x0);}const _0x32912a={..._0x25a2f8};if(_0x5ea148==='mfaSmsEnrollment'||_0x5ea148==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x32912a){const _0x320702=_0x32912a['phoneEnrollmentInfo']['phoneNumber'],_0x3d523e=_0x32912a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x32912a,{'phoneEnrollmentInfo':{'phoneNumber':_0x320702,'recaptchaToken':_0x3d523e,'captchaResponse':_0x4440d7,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x32912a){const _0x3c5b3e=_0x32912a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x32912a,{'phoneSignInInfo':{'recaptchaToken':_0x3c5b3e,'captchaResponse':_0x4440d7,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x32912a;}return _0x1c2dc0?Object['assign'](_0x32912a,{'captchaResp':_0x4440d7}):Object['assign'](_0x32912a,{'captchaResponse':_0x4440d7}),Object['assign'](_0x32912a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x32912a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x32912a;}async function Oi(_0x2ec913,_0x57496c,_0x241ad7,_0x39898f,_0x15c326){var _0x80e554;if((_0x80e554=_0x2ec913['_getRecaptchaConfig']())!=null&&_0x80e554['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x219d00=await br(_0x2ec913,_0x57496c,_0x241ad7,_0x241ad7==='getOobCode');return _0x39898f(_0x2ec913,_0x219d00);}else return _0x39898f(_0x2ec913,_0x57496c)['catch'](async _0x5705cc=>{if(_0x5705cc['code']==='auth/missing-recaptcha-token'){console['log'](_0x241ad7+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x257692=await br(_0x2ec913,_0x57496c,_0x241ad7,_0x241ad7==='getOobCode');return _0x39898f(_0x2ec913,_0x257692);}else return Promise['reject'](_0x5705cc);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Df(_0x16672a,_0x3e4e88){const _0xc8b52=Ui(_0x16672a,'auth');if(_0xc8b52['isInitialized']()){const _0x3573c9=_0xc8b52['getImmediate'](),_0x3d7c1e=_0xc8b52['getOptions']();if(De(_0x3d7c1e,_0x3e4e88??{}))return _0x3573c9;K(_0x3573c9,'already-initialized');}return _0xc8b52['initialize']({'options':_0x3e4e88});}function Mf(_0x324595,_0x42c125){const _0x2c3dc9=(_0x42c125==null?void 0x0:_0x42c125['persistence'])||[],_0x37d792=(Array['isArray'](_0x2c3dc9)?_0x2c3dc9:[_0x2c3dc9])['map'](ne);_0x42c125!=null&&_0x42c125['errorMap']&&_0x324595['_updateErrorMap'](_0x42c125['errorMap']),_0x324595['_initializeWithPersistence'](_0x37d792,_0x42c125==null?void 0x0:_0x42c125['popupRedirectResolver']);}function Lf(_0x2361d2,_0x466af4,_0x54cc6a){const _0x522567=qe(_0x2361d2);m(/^https?:\/\//['test'](_0x466af4),_0x522567,'invalid-emulator-scheme');const _0x3ac1d7=!0x1,_0x4104b4=La(_0x466af4),{host:_0x6e5d08,port:_0x4fa716}=xf(_0x466af4),_0x14ba1d=_0x4fa716===null?'':':'+_0x4fa716,_0x33d83b={'url':_0x4104b4+'//'+_0x6e5d08+_0x14ba1d+'/'},_0x43cbb3=Object['freeze']({'host':_0x6e5d08,'port':_0x4fa716,'protocol':_0x4104b4['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3ac1d7})});if(!_0x522567['_canInitEmulator']){m(_0x522567['config']['emulator']&&_0x522567['emulatorConfig'],_0x522567,'emulator-config-failed'),m(De(_0x33d83b,_0x522567['config']['emulator'])&&De(_0x43cbb3,_0x522567['emulatorConfig']),_0x522567,'emulator-config-failed');return;}_0x522567['config']['emulator']=_0x33d83b,_0x522567['emulatorConfig']=_0x43cbb3,_0x522567['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x6e5d08)?jr(_0x4104b4+'//'+_0x6e5d08+_0x14ba1d):Ff();}function La(_0xab1972){const _0x40b00d=_0xab1972['indexOf'](':');return _0x40b00d<0x0?'':_0xab1972['substr'](0x0,_0x40b00d+0x1);}function xf(_0x2fe58a){const _0x3acf61=La(_0x2fe58a),_0x3bd212=/(\/\/)?([^?#/]+)/['exec'](_0x2fe58a['substr'](_0x3acf61['length']));if(!_0x3bd212)return{'host':'','port':null};const _0x235bfb=_0x3bd212[0x2]['split']('@')['pop']()||'',_0x244ce9=/^(\[[^\]]+\])(:|$)/['exec'](_0x235bfb);if(_0x244ce9){const _0x54167d=_0x244ce9[0x1];return{'host':_0x54167d,'port':Rr(_0x235bfb['substr'](_0x54167d['length']+0x1))};}else{const [_0x3f4e7e,_0xe6959e]=_0x235bfb['split'](':');return{'host':_0x3f4e7e,'port':Rr(_0xe6959e)};}}function Rr(_0x10e092){if(!_0x10e092)return null;const _0x33234f=Number(_0x10e092);return isNaN(_0x33234f)?null:_0x33234f;}function Ff(){function _0x2f3780(){const _0xd09d87=document['createElement']('p'),_0x4903fd=_0xd09d87['style'];_0xd09d87['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x4903fd['position']='fixed',_0x4903fd['width']='100%',_0x4903fd['backgroundColor']='#ffffff',_0x4903fd['border']='.1em\x20solid\x20#000000',_0x4903fd['color']='#b50000',_0x4903fd['bottom']='0px',_0x4903fd['left']='0px',_0x4903fd['margin']='0px',_0x4903fd['zIndex']='10000',_0x4903fd['textAlign']='center',_0xd09d87['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xd09d87);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2f3780):_0x2f3780());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x51571d,_0x4897e1){this['providerId']=_0x51571d,this['signInMethod']=_0x4897e1;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x3df046){return te('not\x20implemented');}['_linkToIdToken'](_0x1468c9,_0x1a91bf){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x484860){return te('not\x20implemented');}}async function Uf(_0x3a09eb,_0x4f16c6){return Ae(_0x3a09eb,'POST','/v1/accounts:signUp',_0x4f16c6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wf(_0x1ab3c7,_0x2f5481){return Yt(_0x1ab3c7,'POST','/v1/accounts:signInWithPassword',Re(_0x1ab3c7,_0x2f5481));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x23567b,_0x3615ee){return Yt(_0x23567b,'POST','/v1/accounts:signInWithEmailLink',Re(_0x23567b,_0x3615ee));}async function Vf(_0x431c6c,_0x34a0be){return Yt(_0x431c6c,'POST','/v1/accounts:signInWithEmailLink',Re(_0x431c6c,_0x34a0be));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x16cc75,_0xfcee51,_0xef059b,_0x14901e=null){super('password',_0xef059b),this['_email']=_0x16cc75,this['_password']=_0xfcee51,this['_tenantId']=_0x14901e;}static['_fromEmailAndPassword'](_0x94aed7,_0x583955){return new Ft(_0x94aed7,_0x583955,'password');}static['_fromEmailAndCode'](_0x18e4a9,_0x48d213,_0x5e4000=null){return new Ft(_0x18e4a9,_0x48d213,'emailLink',_0x5e4000);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xe6dbfb){const _0x779bb8=typeof _0xe6dbfb=='string'?JSON['parse'](_0xe6dbfb):_0xe6dbfb;if(_0x779bb8!=null&&_0x779bb8['email']&&(_0x779bb8!=null&&_0x779bb8['password'])){if(_0x779bb8['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x779bb8['email'],_0x779bb8['password']);if(_0x779bb8['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x779bb8['email'],_0x779bb8['password'],_0x779bb8['tenantId']);}return null;}async['_getIdTokenResponse'](_0x356861){switch(this['signInMethod']){case'password':const _0x1ddf4b={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x356861,_0x1ddf4b,'signInWithPassword',Wf);case'emailLink':return Bf(_0x356861,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x356861,'internal-error');}}async['_linkToIdToken'](_0x2010cb,_0x29d4a8){switch(this['signInMethod']){case'password':const _0xfc2ee8={'idToken':_0x29d4a8,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x2010cb,_0xfc2ee8,'signUpPassword',Uf);case'emailLink':return Vf(_0x2010cb,{'idToken':_0x29d4a8,'email':this['_email'],'oobCode':this['_password']});default:K(_0x2010cb,'internal-error');}}['_getReauthenticationResolver'](_0xf9e70f){return this['_getIdTokenResponse'](_0xf9e70f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x319aa0,_0x492360){return Yt(_0x319aa0,'POST','/v1/accounts:signInWithIdp',Re(_0x319aa0,_0x492360));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hf='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2ac832){const _0x48f736=new We(_0x2ac832['providerId'],_0x2ac832['signInMethod']);return _0x2ac832['idToken']||_0x2ac832['accessToken']?(_0x2ac832['idToken']&&(_0x48f736['idToken']=_0x2ac832['idToken']),_0x2ac832['accessToken']&&(_0x48f736['accessToken']=_0x2ac832['accessToken']),_0x2ac832['nonce']&&!_0x2ac832['pendingToken']&&(_0x48f736['nonce']=_0x2ac832['nonce']),_0x2ac832['pendingToken']&&(_0x48f736['pendingToken']=_0x2ac832['pendingToken'])):_0x2ac832['oauthToken']&&_0x2ac832['oauthTokenSecret']?(_0x48f736['accessToken']=_0x2ac832['oauthToken'],_0x48f736['secret']=_0x2ac832['oauthTokenSecret']):K('argument-error'),_0x48f736;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x32fab6){const _0x3a722d=typeof _0x32fab6=='string'?JSON['parse'](_0x32fab6):_0x32fab6,{providerId:_0x3b2bd4,signInMethod:_0x24f928,..._0x4fbaaf}=_0x3a722d;if(!_0x3b2bd4||!_0x24f928)return null;const _0x3df075=new We(_0x3b2bd4,_0x24f928);return _0x3df075['idToken']=_0x4fbaaf['idToken']||void 0x0,_0x3df075['accessToken']=_0x4fbaaf['accessToken']||void 0x0,_0x3df075['secret']=_0x4fbaaf['secret'],_0x3df075['nonce']=_0x4fbaaf['nonce'],_0x3df075['pendingToken']=_0x4fbaaf['pendingToken']||null,_0x3df075;}['_getIdTokenResponse'](_0x206de3){const _0x4da500=this['buildRequest']();return Ze(_0x206de3,_0x4da500);}['_linkToIdToken'](_0x4bb7e1,_0x507883){const _0x1ec343=this['buildRequest']();return _0x1ec343['idToken']=_0x507883,Ze(_0x4bb7e1,_0x1ec343);}['_getReauthenticationResolver'](_0x220dce){const _0x40006d=this['buildRequest']();return _0x40006d['autoCreate']=!0x1,Ze(_0x220dce,_0x40006d);}['buildRequest'](){const _0x5935b2={'requestUri':Hf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5935b2['pendingToken']=this['pendingToken'];else{const _0x45b17b={};this['idToken']&&(_0x45b17b['id_token']=this['idToken']),this['accessToken']&&(_0x45b17b['access_token']=this['accessToken']),this['secret']&&(_0x45b17b['oauth_token_secret']=this['secret']),_0x45b17b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x45b17b['nonce']=this['nonce']),_0x5935b2['postBody']=at(_0x45b17b);}return _0x5935b2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function $f(_0x2c1b97){switch(_0x2c1b97){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Gf(_0x50a820){const _0x4190ec=yt(vt(_0x50a820))['link'],_0x4009b1=_0x4190ec?yt(vt(_0x4190ec))['deep_link_id']:null,_0x54dd67=yt(vt(_0x50a820))['deep_link_id'];return(_0x54dd67?yt(vt(_0x54dd67))['link']:null)||_0x54dd67||_0x4009b1||_0x4190ec||_0x50a820;}class Ss{constructor(_0x204621){const _0x4c54e0=yt(vt(_0x204621)),_0x429bda=_0x4c54e0['apiKey']??null,_0x5e253a=_0x4c54e0['oobCode']??null,_0x4ea852=$f(_0x4c54e0['mode']??null);m(_0x429bda&&_0x5e253a&&_0x4ea852,'argument-error'),this['apiKey']=_0x429bda,this['operation']=_0x4ea852,this['code']=_0x5e253a,this['continueUrl']=_0x4c54e0['continueUrl']??null,this['languageCode']=_0x4c54e0['lang']??null,this['tenantId']=_0x4c54e0['tenantId']??null;}static['parseLink'](_0x184b8a){const _0xc7b0fc=Gf(_0x184b8a);try{return new Ss(_0xc7b0fc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x333873,_0x429944){return Ft['_fromEmailAndPassword'](_0x333873,_0x429944);}static['credentialWithLink'](_0x406c28,_0x4307e2){const _0x4cd530=Ss['parseLink'](_0x4307e2);return m(_0x4cd530,'argument-error'),Ft['_fromEmailAndCode'](_0x406c28,_0x4cd530['code'],_0x4cd530['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5b3245){this['providerId']=_0x5b3245,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1c2e0a){this['defaultLanguageCode']=_0x1c2e0a;}['setCustomParameters'](_0x183c6e){return this['customParameters']=_0x183c6e,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5e85f8){return this['scopes']['includes'](_0x5e85f8)||this['scopes']['push'](_0x5e85f8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x1f26b5){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1f26b5});}static['credentialFromResult'](_0x1b1f92){return he['credentialFromTaggedObject'](_0x1b1f92);}static['credentialFromError'](_0x5d8e70){return he['credentialFromTaggedObject'](_0x5d8e70['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3a47ae}){if(!_0x3a47ae||!('oauthAccessToken'in _0x3a47ae)||!_0x3a47ae['oauthAccessToken'])return null;try{return he['credential'](_0x3a47ae['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1f4338,_0x4ce91a){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1f4338,'accessToken':_0x4ce91a});}static['credentialFromResult'](_0x4bfc5e){return ue['credentialFromTaggedObject'](_0x4bfc5e);}static['credentialFromError'](_0x4247b7){return ue['credentialFromTaggedObject'](_0x4247b7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4a80e2}){if(!_0x4a80e2)return null;const {oauthIdToken:_0x3e5777,oauthAccessToken:_0x1ee095}=_0x4a80e2;if(!_0x3e5777&&!_0x1ee095)return null;try{return ue['credential'](_0x3e5777,_0x1ee095);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x1b5300){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1b5300});}static['credentialFromResult'](_0x5dc2ab){return de['credentialFromTaggedObject'](_0x5dc2ab);}static['credentialFromError'](_0x2b398b){return de['credentialFromTaggedObject'](_0x2b398b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b404a}){if(!_0x1b404a||!('oauthAccessToken'in _0x1b404a)||!_0x1b404a['oauthAccessToken'])return null;try{return de['credential'](_0x1b404a['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x338f4a,_0x1e15df){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x338f4a,'oauthTokenSecret':_0x1e15df});}static['credentialFromResult'](_0x590d34){return fe['credentialFromTaggedObject'](_0x590d34);}static['credentialFromError'](_0x215998){return fe['credentialFromTaggedObject'](_0x215998['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30424e}){if(!_0x30424e)return null;const {oauthAccessToken:_0x47adec,oauthTokenSecret:_0x3c8c58}=_0x30424e;if(!_0x47adec||!_0x3c8c58)return null;try{return fe['credential'](_0x47adec,_0x3c8c58);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x3bd130,_0x771e5){return Yt(_0x3bd130,'POST','/v1/accounts:signUp',Re(_0x3bd130,_0x771e5));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x20419a){this['user']=_0x20419a['user'],this['providerId']=_0x20419a['providerId'],this['_tokenResponse']=_0x20419a['_tokenResponse'],this['operationType']=_0x20419a['operationType'];}static async['_fromIdTokenResponse'](_0x34da9d,_0x4bd842,_0x55bec6,_0x47f56a=!0x1){const _0x1571d8=await z['_fromIdTokenResponse'](_0x34da9d,_0x55bec6,_0x47f56a),_0x2012b0=Ar(_0x55bec6);return new Be({'user':_0x1571d8,'providerId':_0x2012b0,'_tokenResponse':_0x55bec6,'operationType':_0x4bd842});}static async['_forOperation'](_0x472a01,_0x195e0a,_0x55b10c){await _0x472a01['_updateTokensIfNecessary'](_0x55b10c,!0x0);const _0x560710=Ar(_0x55b10c);return new Be({'user':_0x472a01,'providerId':_0x560710,'_tokenResponse':_0x55b10c,'operationType':_0x195e0a});}}function Ar(_0x119398){return _0x119398['providerId']?_0x119398['providerId']:'phoneNumber'in _0x119398?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x36308c,_0x45f9f9,_0x3a06b5,_0x42e676){super(_0x45f9f9['code'],_0x45f9f9['message']),this['operationType']=_0x3a06b5,this['user']=_0x42e676,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x36308c['name'],'tenantId':_0x36308c['tenantId']??void 0x0,'_serverResponse':_0x45f9f9['customData']['_serverResponse'],'operationType':_0x3a06b5};}static['_fromErrorAndOperation'](_0x31fffd,_0x319488,_0x6e595b,_0x2366bc){return new Rn(_0x31fffd,_0x319488,_0x6e595b,_0x2366bc);}}function Fa(_0x542d68,_0x2c910f,_0x36838d,_0x52656c){return(_0x2c910f==='reauthenticate'?_0x36838d['_getReauthenticationResolver'](_0x542d68):_0x36838d['_getIdTokenResponse'](_0x542d68))['catch'](_0x4f6ec=>{throw _0x4f6ec['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0x542d68,_0x4f6ec,_0x2c910f,_0x52656c):_0x4f6ec;});}async function zf(_0x281894,_0x300d2f,_0x3faa1e=!0x1){const _0x3aeb60=await xt(_0x281894,_0x300d2f['_linkToIdToken'](_0x281894['auth'],await _0x281894['getIdToken']()),_0x3faa1e);return Be['_forOperation'](_0x281894,'link',_0x3aeb60);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x55c32e,_0x52b7de,_0x1d5b4f=!0x1){const {auth:_0x341f7b}=_0x55c32e;if(H(_0x341f7b['app']))return Promise['reject'](se(_0x341f7b));const _0xf77f25='reauthenticate';try{const _0x3dafe8=await xt(_0x55c32e,Fa(_0x341f7b,_0xf77f25,_0x52b7de,_0x55c32e),_0x1d5b4f);m(_0x3dafe8['idToken'],_0x341f7b,'internal-error');const _0x1b37ee=ws(_0x3dafe8['idToken']);m(_0x1b37ee,_0x341f7b,'internal-error');const {sub:_0x25507f}=_0x1b37ee;return m(_0x55c32e['uid']===_0x25507f,_0x341f7b,'user-mismatch'),Be['_forOperation'](_0x55c32e,_0xf77f25,_0x3dafe8);}catch(_0x2cba3f){throw(_0x2cba3f==null?void 0x0:_0x2cba3f['code'])==='auth/user-not-found'&&K(_0x341f7b,'user-mismatch'),_0x2cba3f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x9251b1,_0x449850,_0x187916=!0x1){if(H(_0x9251b1['app']))return Promise['reject'](se(_0x9251b1));const _0x44a547='signIn',_0x13a7a6=await Fa(_0x9251b1,_0x44a547,_0x449850),_0x3d4d70=await Be['_fromIdTokenResponse'](_0x9251b1,_0x44a547,_0x13a7a6);return _0x187916||await _0x9251b1['_updateCurrentUser'](_0x3d4d70['user']),_0x3d4d70;}async function Kf(_0x4d6f83,_0x3220ff){return Ua(qe(_0x4d6f83),_0x3220ff);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x26b9e6){const _0x17fdf9=qe(_0x26b9e6);_0x17fdf9['_getPasswordPolicyInternal']()&&await _0x17fdf9['_updatePasswordPolicy']();}async function S_(_0x6d5ffb,_0x4eac76,_0x3bd7d0){if(H(_0x6d5ffb['app']))return Promise['reject'](se(_0x6d5ffb));const _0x2b02fe=qe(_0x6d5ffb),_0x1a759e=await Oi(_0x2b02fe,{'returnSecureToken':!0x0,'email':_0x4eac76,'password':_0x3bd7d0,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',qf)['catch'](_0x480922=>{throw _0x480922['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x6d5ffb),_0x480922;}),_0x5d6bf5=await Be['_fromIdTokenResponse'](_0x2b02fe,'signIn',_0x1a759e);return await _0x2b02fe['_updateCurrentUser'](_0x5d6bf5['user']),_0x5d6bf5;}function b_(_0x5bfb2a,_0x47e97f,_0xd96fb0){return H(_0x5bfb2a['app'])?Promise['reject'](se(_0x5bfb2a)):Kf(k(_0x5bfb2a),ft['credential'](_0x47e97f,_0xd96fb0))['catch'](async _0x283dd5=>{throw _0x283dd5['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x5bfb2a),_0x283dd5;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function R_(_0x244eea,_0x5756a8){return k(_0x244eea)['setPersistence'](_0x5756a8);}function Yf(_0x12f19f,_0x19db0f,_0x5018b7,_0x420a56){return k(_0x12f19f)['onIdTokenChanged'](_0x19db0f,_0x5018b7,_0x420a56);}function Qf(_0x2ea388,_0x4a62a6,_0x2557f6){return k(_0x2ea388)['beforeAuthStateChanged'](_0x4a62a6,_0x2557f6);}function A_(_0x2855f4,_0x45fa69,_0x1ee0f5,_0x1b3f57){return k(_0x2855f4)['onAuthStateChanged'](_0x45fa69,_0x1ee0f5,_0x1b3f57);}function k_(_0x5c2928){return k(_0x5c2928)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x241a76,_0x18337a){this['storageRetriever']=_0x241a76,this['type']=_0x18337a;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5c7f58,_0x3529be){return this['storage']['setItem'](_0x5c7f58,JSON['stringify'](_0x3529be)),Promise['resolve']();}['_get'](_0x119da9){const _0x3aa7db=this['storage']['getItem'](_0x119da9);return Promise['resolve'](_0x3aa7db?JSON['parse'](_0x3aa7db):null);}['_remove'](_0x4da6ec){return this['storage']['removeItem'](_0x4da6ec),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jf=0x3e8,Xf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xfc6f1d,_0x4974c7)=>this['onStorageEvent'](_0xfc6f1d,_0x4974c7),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x396088){for(const _0x1038b8 of Object['keys'](this['listeners'])){const _0x4be459=this['storage']['getItem'](_0x1038b8),_0xd33fd7=this['localCache'][_0x1038b8];_0x4be459!==_0xd33fd7&&_0x396088(_0x1038b8,_0xd33fd7,_0x4be459);}}['onStorageEvent'](_0x7244cf,_0x283238=!0x1){if(!_0x7244cf['key']){this['forAllChangedKeys']((_0x192244,_0x4054ee,_0x58ebd4)=>{this['notifyListeners'](_0x192244,_0x58ebd4);});return;}const _0x10df22=_0x7244cf['key'];_0x283238?this['detachListener']():this['stopPolling']();const _0x37455e=()=>{const _0x38fafc=this['storage']['getItem'](_0x10df22);!_0x283238&&this['localCache'][_0x10df22]===_0x38fafc||this['notifyListeners'](_0x10df22,_0x38fafc);},_0x1240c5=this['storage']['getItem'](_0x10df22);Ef()&&_0x1240c5!==_0x7244cf['newValue']&&_0x7244cf['newValue']!==_0x7244cf['oldValue']?setTimeout(_0x37455e,Xf):_0x37455e();}['notifyListeners'](_0x4d3b52,_0x5c45e3){this['localCache'][_0x4d3b52]=_0x5c45e3;const _0x58dd5a=this['listeners'][_0x4d3b52];if(_0x58dd5a){for(const _0x5b677e of Array['from'](_0x58dd5a))_0x5b677e(_0x5c45e3&&JSON['parse'](_0x5c45e3));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x220d4b,_0x139ff7,_0x29de23)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x220d4b,'oldValue':_0x139ff7,'newValue':_0x29de23}),!0x0);});},Jf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x15b109,_0x488741){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x15b109]||(this['listeners'][_0x15b109]=new Set(),this['localCache'][_0x15b109]=this['storage']['getItem'](_0x15b109)),this['listeners'][_0x15b109]['add'](_0x488741);}['_removeListener'](_0x2e6fde,_0x51722d){this['listeners'][_0x2e6fde]&&(this['listeners'][_0x2e6fde]['delete'](_0x51722d),this['listeners'][_0x2e6fde]['size']===0x0&&delete this['listeners'][_0x2e6fde]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3f87c9,_0x3212d4){await super['_set'](_0x3f87c9,_0x3212d4),this['localCache'][_0x3f87c9]=JSON['stringify'](_0x3212d4);}async['_get'](_0x30e0ef){const _0x122896=await super['_get'](_0x30e0ef);return this['localCache'][_0x30e0ef]=JSON['stringify'](_0x122896),_0x122896;}async['_remove'](_0x2f6324){await super['_remove'](_0x2f6324),delete this['localCache'][_0x2f6324];}}Va['type']='LOCAL';const Zf=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x225f5b,_0x574ad7){}['_removeListener'](_0x351e12,_0x5bbb02){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ep(_0x4dbbdd){return Promise['all'](_0x4dbbdd['map'](async _0x50ab6e=>{try{return{'fulfilled':!0x0,'value':await _0x50ab6e};}catch(_0x389959){return{'fulfilled':!0x1,'reason':_0x389959};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x32faa8){this['eventTarget']=_0x32faa8,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x170bee){const _0x1077b7=this['receivers']['find'](_0x4bb724=>_0x4bb724['isListeningto'](_0x170bee));if(_0x1077b7)return _0x1077b7;const _0x3bfdbd=new jn(_0x170bee);return this['receivers']['push'](_0x3bfdbd),_0x3bfdbd;}['isListeningto'](_0x2f3e2e){return this['eventTarget']===_0x2f3e2e;}async['handleEvent'](_0x25298d){const _0x134cab=_0x25298d,{eventId:_0x4d3020,eventType:_0x43b8aa,data:_0x3373f7}=_0x134cab['data'],_0x3dd521=this['handlersMap'][_0x43b8aa];if(!(_0x3dd521!=null&&_0x3dd521['size']))return;_0x134cab['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4d3020,'eventType':_0x43b8aa});const _0x512000=Array['from'](_0x3dd521)['map'](async _0x52d6d9=>_0x52d6d9(_0x134cab['origin'],_0x3373f7)),_0x26ca2b=await ep(_0x512000);_0x134cab['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4d3020,'eventType':_0x43b8aa,'response':_0x26ca2b});}['_subscribe'](_0x449758,_0x49f6bb){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x449758]||(this['handlersMap'][_0x449758]=new Set()),this['handlersMap'][_0x449758]['add'](_0x49f6bb);}['_unsubscribe'](_0x2697b1,_0x78f1dc){this['handlersMap'][_0x2697b1]&&_0x78f1dc&&this['handlersMap'][_0x2697b1]['delete'](_0x78f1dc),(!_0x78f1dc||this['handlersMap'][_0x2697b1]['size']===0x0)&&delete this['handlersMap'][_0x2697b1],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x4c881f='',_0x49dacc=0xa){let _0x131ece='';for(let _0x3c1758=0x0;_0x3c1758<_0x49dacc;_0x3c1758++)_0x131ece+=Math['floor'](Math['random']()*0xa);return _0x4c881f+_0x131ece;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tp{constructor(_0x4576e8){this['target']=_0x4576e8,this['handlers']=new Set();}['removeMessageHandler'](_0x506671){_0x506671['messageChannel']&&(_0x506671['messageChannel']['port1']['removeEventListener']('message',_0x506671['onMessage']),_0x506671['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x506671);}async['_send'](_0x2282bb,_0xce2efe,_0x201380=0x32){const _0x211cb6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x211cb6)throw new Error('connection_unavailable');let _0x1f91c8,_0x2e9646;return new Promise((_0x2214ab,_0x4a365d)=>{const _0x2b3ee5=bs('',0x14);_0x211cb6['port1']['start']();const _0x2a2bdd=setTimeout(()=>{_0x4a365d(new Error('unsupported_event'));},_0x201380);_0x2e9646={'messageChannel':_0x211cb6,'onMessage'(_0x20d6b4){const _0x22ec96=_0x20d6b4;if(_0x22ec96['data']['eventId']===_0x2b3ee5)switch(_0x22ec96['data']['status']){case'ack':clearTimeout(_0x2a2bdd),_0x1f91c8=setTimeout(()=>{_0x4a365d(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1f91c8),_0x2214ab(_0x22ec96['data']['response']);break;default:clearTimeout(_0x2a2bdd),clearTimeout(_0x1f91c8),_0x4a365d(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2e9646),_0x211cb6['port1']['addEventListener']('message',_0x2e9646['onMessage']),this['target']['postMessage']({'eventType':_0x2282bb,'eventId':_0x2b3ee5,'data':_0xce2efe},[_0x211cb6['port2']]);})['finally'](()=>{_0x2e9646&&this['removeMessageHandler'](_0x2e9646);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function np(_0x486301){X()['location']['href']=_0x486301;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function ip(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function sp(){var _0x1e940a;return((_0x1e940a=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x1e940a['controller'])||null;}function rp(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',op=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5dfdad){this['request']=_0x5dfdad;}['toPromise'](){return new Promise((_0x18f9c9,_0x137f1f)=>{this['request']['addEventListener']('success',()=>{_0x18f9c9(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x137f1f(this['request']['error']);});});}}function Kn(_0x19c7ad,_0x7608f9){return _0x19c7ad['transaction']([kn],_0x7608f9?'readwrite':'readonly')['objectStore'](kn);}function ap(){const _0x2bfc2d=indexedDB['deleteDatabase'](qa);return new Jt(_0x2bfc2d)['toPromise']();}function ja(){const _0x1807e4=indexedDB['open'](qa,op);return new Promise((_0x11a5cc,_0xe42647)=>{_0x1807e4['addEventListener']('error',()=>{_0xe42647(_0x1807e4['error']);}),_0x1807e4['addEventListener']('upgradeneeded',()=>{const _0x1d60ce=_0x1807e4['result'];try{_0x1d60ce['createObjectStore'](kn,{'keyPath':za});}catch(_0x1ba174){_0xe42647(_0x1ba174);}}),_0x1807e4['addEventListener']('success',async()=>{const _0x5dd7d5=_0x1807e4['result'];_0x5dd7d5['objectStoreNames']['contains'](kn)?_0x11a5cc(_0x5dd7d5):(_0x5dd7d5['close'](),await ap(),_0x11a5cc(await ja()));});});}async function kr(_0x3d947c,_0x1055f1,_0x50156c){const _0xc79e8e=Kn(_0x3d947c,!0x0)['put']({[za]:_0x1055f1,'value':_0x50156c});return new Jt(_0xc79e8e)['toPromise']();}async function cp(_0x5b0b3d,_0x3977a5){const _0x4d21ef=Kn(_0x5b0b3d,!0x1)['get'](_0x3977a5),_0x4b4d99=await new Jt(_0x4d21ef)['toPromise']();return _0x4b4d99===void 0x0?null:_0x4b4d99['value'];}function Nr(_0x44fbde,_0x54dce2){const _0x3e36c8=Kn(_0x44fbde,!0x0)['delete'](_0x54dce2);return new Jt(_0x3e36c8)['toPromise']();}const lp=0x320,hp=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x139438){let _0x5df611=0x0;for(;;)try{const _0xd783ef=await this['_openDb']();return await _0x139438(_0xd783ef);}catch(_0x2da49c){if(_0x5df611++>hp)throw _0x2da49c;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](rp()),this['receiver']['_subscribe']('keyChanged',async(_0x19fb01,_0x295f19)=>({'keyProcessed':(await this['_poll']())['includes'](_0x295f19['key'])})),this['receiver']['_subscribe']('ping',async(_0x4a00f0,_0x30bb10)=>['keyChanged']);}async['initializeSender'](){var _0x4bc932,_0x2f9791;if(this['activeServiceWorker']=await ip(),!this['activeServiceWorker'])return;this['sender']=new tp(this['activeServiceWorker']);const _0x5dfad8=await this['sender']['_send']('ping',{},0x320);_0x5dfad8&&(_0x4bc932=_0x5dfad8[0x0])!=null&&_0x4bc932['fulfilled']&&(_0x2f9791=_0x5dfad8[0x0])!=null&&_0x2f9791['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x5983f6){if(!(!this['sender']||!this['activeServiceWorker']||sp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x5983f6},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4f5ede=>{await kr(_0x4f5ede,An,'1'),await Nr(_0x4f5ede,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x3fae48){this['pendingWrites']++;try{await _0x3fae48();}finally{this['pendingWrites']--;}}async['_set'](_0x1c3dd5,_0x4206ae){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3e2182=>kr(_0x3e2182,_0x1c3dd5,_0x4206ae)),this['localCache'][_0x1c3dd5]=_0x4206ae,this['notifyServiceWorker'](_0x1c3dd5)));}async['_get'](_0x357cce){const _0x250186=await this['_withRetries'](_0x4a5cfd=>cp(_0x4a5cfd,_0x357cce));return this['localCache'][_0x357cce]=_0x250186,_0x250186;}async['_remove'](_0x368652){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x38eea9=>Nr(_0x38eea9,_0x368652)),delete this['localCache'][_0x368652],this['notifyServiceWorker'](_0x368652)));}async['_poll'](){const _0x1ece2c=await this['_withRetries'](_0x51844e=>{const _0x375d5b=Kn(_0x51844e,!0x1)['getAll']();return new Jt(_0x375d5b)['toPromise']();});if(!_0x1ece2c)return[];if(this['pendingWrites']!==0x0)return[];const _0x5de5c4=[],_0x194f7f=new Set();if(_0x1ece2c['length']!==0x0){for(const {fbase_key:_0xf10b4f,value:_0xd2614e}of _0x1ece2c)_0x194f7f['add'](_0xf10b4f),JSON['stringify'](this['localCache'][_0xf10b4f])!==JSON['stringify'](_0xd2614e)&&(this['notifyListeners'](_0xf10b4f,_0xd2614e),_0x5de5c4['push'](_0xf10b4f));}for(const _0x107662 of Object['keys'](this['localCache']))this['localCache'][_0x107662]&&!_0x194f7f['has'](_0x107662)&&(this['notifyListeners'](_0x107662,null),_0x5de5c4['push'](_0x107662));return _0x5de5c4;}['notifyListeners'](_0x32babf,_0x1da2cf){this['localCache'][_0x32babf]=_0x1da2cf;const _0x1a3cfa=this['listeners'][_0x32babf];if(_0x1a3cfa){for(const _0x1fa42f of Array['from'](_0x1a3cfa))_0x1fa42f(_0x1da2cf);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),lp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x363f4d,_0xb17117){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x363f4d]||(this['listeners'][_0x363f4d]=new Set(),this['_get'](_0x363f4d)),this['listeners'][_0x363f4d]['add'](_0xb17117);}['_removeListener'](_0x16daf9,_0x24f87d){this['listeners'][_0x16daf9]&&(this['listeners'][_0x16daf9]['delete'](_0x24f87d),this['listeners'][_0x16daf9]['size']===0x0&&delete this['listeners'][_0x16daf9]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const up=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function dp(_0xec8be4,_0x234473){return _0x234473?ne(_0x234473):(m(_0xec8be4['_popupRedirectResolver'],_0xec8be4,'argument-error'),_0xec8be4['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x5651c5){super('custom','custom'),this['params']=_0x5651c5;}['_getIdTokenResponse'](_0x33feb8){return Ze(_0x33feb8,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1545e7,_0x10f01f){return Ze(_0x1545e7,this['_buildIdpRequest'](_0x10f01f));}['_getReauthenticationResolver'](_0x37c485){return Ze(_0x37c485,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x51006a){const _0x28973a={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x51006a&&(_0x28973a['idToken']=_0x51006a),_0x28973a;}}function fp(_0x53230e){return Ua(_0x53230e['auth'],new Rs(_0x53230e),_0x53230e['bypassAuthState']);}function pp(_0x42ab07){const {auth:_0x539c68,user:_0x211196}=_0x42ab07;return m(_0x211196,_0x539c68,'internal-error'),jf(_0x211196,new Rs(_0x42ab07),_0x42ab07['bypassAuthState']);}async function _p(_0x294e28){const {auth:_0x261f7f,user:_0x1805b9}=_0x294e28;return m(_0x1805b9,_0x261f7f,'internal-error'),zf(_0x1805b9,new Rs(_0x294e28),_0x294e28['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x17184f,_0x30f273,_0x179dbf,_0x549503,_0x5dbd8a=!0x1){this['auth']=_0x17184f,this['resolver']=_0x179dbf,this['user']=_0x549503,this['bypassAuthState']=_0x5dbd8a,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x30f273)?_0x30f273:[_0x30f273];}['execute'](){return new Promise(async(_0x2c07f5,_0xf4ec92)=>{this['pendingPromise']={'resolve':_0x2c07f5,'reject':_0xf4ec92};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x4259cc){this['reject'](_0x4259cc);}});}async['onAuthEvent'](_0xbf0299){const {urlResponse:_0x406be9,sessionId:_0x5f526f,postBody:_0x27504d,tenantId:_0x1d6000,error:_0x4e9b21,type:_0x5a0955}=_0xbf0299;if(_0x4e9b21){this['reject'](_0x4e9b21);return;}const _0x50ae0b={'auth':this['auth'],'requestUri':_0x406be9,'sessionId':_0x5f526f,'tenantId':_0x1d6000||void 0x0,'postBody':_0x27504d||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5a0955)(_0x50ae0b));}catch(_0x2da1c6){this['reject'](_0x2da1c6);}}['onError'](_0x43c8a5){this['reject'](_0x43c8a5);}['getIdpTask'](_0x22ae0b){switch(_0x22ae0b){case'signInViaPopup':case'signInViaRedirect':return fp;case'linkViaPopup':case'linkViaRedirect':return _p;case'reauthViaPopup':case'reauthViaRedirect':return pp;default:K(this['auth'],'internal-error');}}['resolve'](_0x22a433){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x22a433),this['unregisterAndCleanUp']();}['reject'](_0x309b50){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x309b50),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x1f98ee,_0xc77c84,_0x558436,_0x4b9a9a,_0x35bc42){super(_0x1f98ee,_0xc77c84,_0x4b9a9a,_0x35bc42),this['provider']=_0x558436,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x92d45=await this['execute']();return m(_0x92d45,this['auth'],'internal-error'),_0x92d45;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x25b708=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x25b708),this['authWindow']['associatedEvent']=_0x25b708,this['resolver']['_originValidation'](this['auth'])['catch'](_0x51d86e=>{this['reject'](_0x51d86e);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x564f17=>{_0x564f17||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5cf9eb;return((_0x5cf9eb=this['authWindow'])==null?void 0x0:_0x5cf9eb['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x453962=()=>{var _0x534c13,_0x14d1cf;if((_0x14d1cf=(_0x534c13=this['authWindow'])==null?void 0x0:_0x534c13['window'])!=null&&_0x14d1cf['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x453962,gp['get']());};_0x453962();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp='pendingRedirect',rn=new Map();class yp extends Ya{constructor(_0x4856d1,_0x5c0db5,_0x52f577=!0x1){super(_0x4856d1,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5c0db5,void 0x0,_0x52f577),this['eventId']=null;}async['execute'](){let _0x14f20b=rn['get'](this['auth']['_key']());if(!_0x14f20b){try{const _0x33a4da=await vp(this['resolver'],this['auth'])?await super['execute']():null;_0x14f20b=()=>Promise['resolve'](_0x33a4da);}catch(_0x26426f){_0x14f20b=()=>Promise['reject'](_0x26426f);}rn['set'](this['auth']['_key'](),_0x14f20b);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x14f20b();}async['onAuthEvent'](_0x39d2d4){if(_0x39d2d4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x39d2d4);if(_0x39d2d4['type']==='unknown'){this['resolve'](null);return;}if(_0x39d2d4['eventId']){const _0x43a350=await this['auth']['_redirectUserForId'](_0x39d2d4['eventId']);if(_0x43a350)return this['user']=_0x43a350,super['onAuthEvent'](_0x39d2d4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function vp(_0x2d25c5,_0x2a8e07){const _0x4623eb=wp(_0x2a8e07),_0x5121db=Ip(_0x2d25c5);if(!await _0x5121db['_isAvailable']())return!0x1;const _0x5d4eb9=await _0x5121db['_get'](_0x4623eb)==='true';return await _0x5121db['_remove'](_0x4623eb),_0x5d4eb9;}function Ep(_0x43ae7a,_0x5b9ee4){rn['set'](_0x43ae7a['_key'](),_0x5b9ee4);}function Ip(_0xc0d2d4){return ne(_0xc0d2d4['_redirectPersistence']);}function wp(_0x332f46){return sn(mp,_0x332f46['config']['apiKey'],_0x332f46['name']);}async function Cp(_0x38f35a,_0x3d838b,_0x1ac8df=!0x1){if(H(_0x38f35a['app']))return Promise['reject'](se(_0x38f35a));const _0x577a93=qe(_0x38f35a),_0x2362bf=dp(_0x577a93,_0x3d838b),_0xb09d82=await new yp(_0x577a93,_0x2362bf,_0x1ac8df)['execute']();return _0xb09d82&&!_0x1ac8df&&(delete _0xb09d82['user']['_redirectEventId'],await _0x577a93['_persistUserIfCurrent'](_0xb09d82['user']),await _0x577a93['_setRedirectUser'](null,_0x3d838b)),_0xb09d82;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=0x258*0x3e8;class Sp{constructor(_0x28811f){this['auth']=_0x28811f,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4805d6){this['consumers']['add'](_0x4805d6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4805d6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4805d6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x55de61){this['consumers']['delete'](_0x55de61);}['onEvent'](_0x582d3f){if(this['hasEventBeenHandled'](_0x582d3f))return!0x1;let _0x3528d3=!0x1;return this['consumers']['forEach'](_0x49904e=>{this['isEventForConsumer'](_0x582d3f,_0x49904e)&&(_0x3528d3=!0x0,this['sendToConsumer'](_0x582d3f,_0x49904e),this['saveEventToCache'](_0x582d3f));}),this['hasHandledPotentialRedirect']||!bp(_0x582d3f)||(this['hasHandledPotentialRedirect']=!0x0,_0x3528d3||(this['queuedRedirectEvent']=_0x582d3f,_0x3528d3=!0x0)),_0x3528d3;}['sendToConsumer'](_0x2a7bf1,_0x5ab675){var _0x4ad490;if(_0x2a7bf1['error']&&!Qa(_0x2a7bf1)){const _0x245b52=((_0x4ad490=_0x2a7bf1['error']['code'])==null?void 0x0:_0x4ad490['split']('auth/')[0x1])||'internal-error';_0x5ab675['onError'](J(this['auth'],_0x245b52));}else _0x5ab675['onAuthEvent'](_0x2a7bf1);}['isEventForConsumer'](_0x29fcb2,_0x4960de){const _0x40b309=_0x4960de['eventId']===null||!!_0x29fcb2['eventId']&&_0x29fcb2['eventId']===_0x4960de['eventId'];return _0x4960de['filter']['includes'](_0x29fcb2['type'])&&_0x40b309;}['hasEventBeenHandled'](_0x489e87){return Date['now']()-this['lastProcessedEventTime']>=Tp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x489e87));}['saveEventToCache'](_0x27c74e){this['cachedEventUids']['add'](Pr(_0x27c74e)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0x3ff31f){return[_0x3ff31f['type'],_0x3ff31f['eventId'],_0x3ff31f['sessionId'],_0x3ff31f['tenantId']]['filter'](_0x1160ee=>_0x1160ee)['join']('-');}function Qa({type:_0x2f4320,error:_0x5b3b10}){return _0x2f4320==='unknown'&&(_0x5b3b10==null?void 0x0:_0x5b3b10['code'])==='auth/no-auth-event';}function bp(_0x173083){switch(_0x173083['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x173083);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rp(_0x279771,_0x231d29={}){return Ae(_0x279771,'GET','/v1/projects',_0x231d29);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ap=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,kp=/^https?/;async function Np(_0x2099fd){if(_0x2099fd['config']['emulator'])return;const {authorizedDomains:_0x37cc9a}=await Rp(_0x2099fd);for(const _0x567336 of _0x37cc9a)try{if(Pp(_0x567336))return;}catch{}K(_0x2099fd,'unauthorized-domain');}function Pp(_0x5d42c7){const _0x4b8a29=Ni(),{protocol:_0x2315fb,hostname:_0x5f2a86}=new URL(_0x4b8a29);if(_0x5d42c7['startsWith']('chrome-extension://')){const _0x857860=new URL(_0x5d42c7);return _0x857860['hostname']===''&&_0x5f2a86===''?_0x2315fb==='chrome-extension:'&&_0x5d42c7['replace']('chrome-extension://','')===_0x4b8a29['replace']('chrome-extension://',''):_0x2315fb==='chrome-extension:'&&_0x857860['hostname']===_0x5f2a86;}if(!kp['test'](_0x2315fb))return!0x1;if(Ap['test'](_0x5d42c7))return _0x5f2a86===_0x5d42c7;const _0xcd56aa=_0x5d42c7['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0xcd56aa+'|'+_0xcd56aa+')$','i')['test'](_0x5f2a86);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=new Kt(0x7530,0xea60);function Or(){const _0x1f2cf7=X()['___jsl'];if(_0x1f2cf7!=null&&_0x1f2cf7['H']){for(const _0x15849f of Object['keys'](_0x1f2cf7['H']))if(_0x1f2cf7['H'][_0x15849f]['r']=_0x1f2cf7['H'][_0x15849f]['r']||[],_0x1f2cf7['H'][_0x15849f]['L']=_0x1f2cf7['H'][_0x15849f]['L']||[],_0x1f2cf7['H'][_0x15849f]['r']=[..._0x1f2cf7['H'][_0x15849f]['L']],_0x1f2cf7['CP']){for(let _0xf45e14=0x0;_0xf45e14<_0x1f2cf7['CP']['length'];_0xf45e14++)_0x1f2cf7['CP'][_0xf45e14]=null;}}}function Dp(_0x505fa1){return new Promise((_0x539c49,_0x38bccc)=>{var _0x7927d1,_0x425f73,_0x1fc9eb;function _0x32eaf8(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x539c49(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x38bccc(J(_0x505fa1,'network-request-failed'));},'timeout':Op['get']()});}if((_0x425f73=(_0x7927d1=X()['gapi'])==null?void 0x0:_0x7927d1['iframes'])!=null&&_0x425f73['Iframe'])_0x539c49(gapi['iframes']['getContext']());else{if((_0x1fc9eb=X()['gapi'])!=null&&_0x1fc9eb['load'])_0x32eaf8();else{const _0x43c35d=kf('iframefcb');return X()[_0x43c35d]=()=>{gapi['load']?_0x32eaf8():_0x38bccc(J(_0x505fa1,'network-request-failed'));},Da(Af()+'?onload='+_0x43c35d)['catch'](_0x211eb6=>_0x38bccc(_0x211eb6));}}})['catch'](_0x5515ad=>{throw on=null,_0x5515ad;});}let on=null;function Mp(_0x561d8e){return on=on||Dp(_0x561d8e),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Lp=new Kt(0x1388,0x3a98),xp='__/auth/iframe',Fp='emulator/auth/iframe',Up={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Wp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Bp(_0x52f52e){const _0xedd0fb=_0x52f52e['config'];m(_0xedd0fb['authDomain'],_0x52f52e,'auth-domain-config-required');const _0x56ea40=_0xedd0fb['emulator']?Is(_0xedd0fb,Fp):'https://'+_0x52f52e['config']['authDomain']+'/'+xp,_0x49b6ef={'apiKey':_0xedd0fb['apiKey'],'appName':_0x52f52e['name'],'v':ct},_0x55b7ea=Wp['get'](_0x52f52e['config']['apiHost']);_0x55b7ea&&(_0x49b6ef['eid']=_0x55b7ea);const _0x698594=_0x52f52e['_getFrameworks']();return _0x698594['length']&&(_0x49b6ef['fw']=_0x698594['join'](',')),_0x56ea40+'?'+at(_0x49b6ef)['slice'](0x1);}async function Vp(_0x4ea464){const _0x122f36=await Mp(_0x4ea464),_0x2ab17d=X()['gapi'];return m(_0x2ab17d,_0x4ea464,'internal-error'),_0x122f36['open']({'where':document['body'],'url':Bp(_0x4ea464),'messageHandlersFilter':_0x2ab17d['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Up,'dontclear':!0x0},_0x3457b5=>new Promise(async(_0x120715,_0x389ecc)=>{await _0x3457b5['restyle']({'setHideOnLeave':!0x1});const _0x18f33f=J(_0x4ea464,'network-request-failed'),_0x4fee6c=X()['setTimeout'](()=>{_0x389ecc(_0x18f33f);},Lp['get']());function _0x26ca93(){X()['clearTimeout'](_0x4fee6c),_0x120715(_0x3457b5);}_0x3457b5['ping'](_0x26ca93)['then'](_0x26ca93,()=>{_0x389ecc(_0x18f33f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},$p=0x1f4,Gp=0x258,qp='_blank',zp='http://localhost';class Dr{constructor(_0xee5777){this['window']=_0xee5777,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function jp(_0x1d24e8,_0x4282ed,_0x14bb74,_0x1d3a1a=$p,_0xe24c5=Gp){const _0x537664=Math['max']((window['screen']['availHeight']-_0xe24c5)/0x2,0x0)['toString'](),_0x45a293=Math['max']((window['screen']['availWidth']-_0x1d3a1a)/0x2,0x0)['toString']();let _0xf4ba20='';const _0x5f0d5e={...Hp,'width':_0x1d3a1a['toString'](),'height':_0xe24c5['toString'](),'top':_0x537664,'left':_0x45a293},_0x42ee77=W()['toLowerCase']();_0x14bb74&&(_0xf4ba20=ba(_0x42ee77)?qp:_0x14bb74),Ta(_0x42ee77)&&(_0x4282ed=_0x4282ed||zp,_0x5f0d5e['scrollbars']='yes');const _0x217a18=Object['entries'](_0x5f0d5e)['reduce']((_0x19abd9,[_0x290d96,_0x5b4bd2])=>''+_0x19abd9+_0x290d96+'='+_0x5b4bd2+',','');if(vf(_0x42ee77)&&_0xf4ba20!=='_self')return Kp(_0x4282ed||'',_0xf4ba20),new Dr(null);const _0x597b39=window['open'](_0x4282ed||'',_0xf4ba20,_0x217a18);m(_0x597b39,_0x1d24e8,'popup-blocked');try{_0x597b39['focus']();}catch{}return new Dr(_0x597b39);}function Kp(_0x518fde,_0x2a41a2){const _0x6a6957=document['createElement']('a');_0x6a6957['href']=_0x518fde,_0x6a6957['target']=_0x2a41a2;const _0x3502c2=document['createEvent']('MouseEvent');_0x3502c2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x6a6957['dispatchEvent'](_0x3502c2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yp='__/auth/handler',Qp='emulator/auth/handler',Jp=encodeURIComponent('fac');async function Mr(_0x14070d,_0x67d1cd,_0x303b9,_0x1fafc4,_0x99ceb6,_0x183d06){m(_0x14070d['config']['authDomain'],_0x14070d,'auth-domain-config-required'),m(_0x14070d['config']['apiKey'],_0x14070d,'invalid-api-key');const _0xe0364f={'apiKey':_0x14070d['config']['apiKey'],'appName':_0x14070d['name'],'authType':_0x303b9,'redirectUrl':_0x1fafc4,'v':ct,'eventId':_0x99ceb6};if(_0x67d1cd instanceof xa){_0x67d1cd['setDefaultLanguage'](_0x14070d['languageCode']),_0xe0364f['providerId']=_0x67d1cd['providerId']||'',hi(_0x67d1cd['getCustomParameters']())||(_0xe0364f['customParameters']=JSON['stringify'](_0x67d1cd['getCustomParameters']()));for(const [_0x512e92,_0x832b94]of Object['entries']({}))_0xe0364f[_0x512e92]=_0x832b94;}if(_0x67d1cd instanceof Qt){const _0x39ff51=_0x67d1cd['getScopes']()['filter'](_0x114fae=>_0x114fae!=='');_0x39ff51['length']>0x0&&(_0xe0364f['scopes']=_0x39ff51['join'](','));}_0x14070d['tenantId']&&(_0xe0364f['tid']=_0x14070d['tenantId']);const _0x334222=_0xe0364f;for(const _0x5a29ee of Object['keys'](_0x334222))_0x334222[_0x5a29ee]===void 0x0&&delete _0x334222[_0x5a29ee];const _0x3abb04=await _0x14070d['_getAppCheckToken'](),_0x3e6c72=_0x3abb04?'#'+Jp+'='+encodeURIComponent(_0x3abb04):'';return Xp(_0x14070d)+'?'+at(_0x334222)['slice'](0x1)+_0x3e6c72;}function Xp({config:_0xe6f871}){return _0xe6f871['emulator']?Is(_0xe6f871,Qp):'https://'+_0xe6f871['authDomain']+'/'+Yp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class Zp{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Cp,this['_overrideRedirectResult']=Ep;}async['_openPopup'](_0x48e889,_0x17912d,_0x112f2f,_0x16a0dc){var _0x52a8bb;ae((_0x52a8bb=this['eventManagers'][_0x48e889['_key']()])==null?void 0x0:_0x52a8bb['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x10c101=await Mr(_0x48e889,_0x17912d,_0x112f2f,Ni(),_0x16a0dc);return jp(_0x48e889,_0x10c101,bs());}async['_openRedirect'](_0x1f3942,_0x43e152,_0x4bc34e,_0x42fed1){await this['_originValidation'](_0x1f3942);const _0x345b2f=await Mr(_0x1f3942,_0x43e152,_0x4bc34e,Ni(),_0x42fed1);return np(_0x345b2f),new Promise(()=>{});}['_initialize'](_0x7d9686){const _0x3d529c=_0x7d9686['_key']();if(this['eventManagers'][_0x3d529c]){const {manager:_0x3570c1,promise:_0xcd778f}=this['eventManagers'][_0x3d529c];return _0x3570c1?Promise['resolve'](_0x3570c1):(ae(_0xcd778f,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xcd778f);}const _0x2c473c=this['initAndGetManager'](_0x7d9686);return this['eventManagers'][_0x3d529c]={'promise':_0x2c473c},_0x2c473c['catch'](()=>{delete this['eventManagers'][_0x3d529c];}),_0x2c473c;}async['initAndGetManager'](_0xf4479a){const _0x28969d=await Vp(_0xf4479a),_0x4fb9f0=new Sp(_0xf4479a);return _0x28969d['register']('authEvent',_0x4bd1ce=>(m(_0x4bd1ce==null?void 0x0:_0x4bd1ce['authEvent'],_0xf4479a,'invalid-auth-event'),{'status':_0x4fb9f0['onEvent'](_0x4bd1ce['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xf4479a['_key']()]={'manager':_0x4fb9f0},this['iframes'][_0xf4479a['_key']()]=_0x28969d,_0x4fb9f0;}['_isIframeWebStorageSupported'](_0x1fbdc5,_0x5aa2a6){this['iframes'][_0x1fbdc5['_key']()]['send'](li,{'type':li},_0x68ff59=>{var _0x58ead2;const _0x1ab78b=(_0x58ead2=_0x68ff59==null?void 0x0:_0x68ff59[0x0])==null?void 0x0:_0x58ead2[li];_0x1ab78b!==void 0x0&&_0x5aa2a6(!!_0x1ab78b),K(_0x1fbdc5,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x20031e){const _0x5b7a6a=_0x20031e['_key']();return this['originValidationPromises'][_0x5b7a6a]||(this['originValidationPromises'][_0x5b7a6a]=Np(_0x20031e)),this['originValidationPromises'][_0x5b7a6a];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const e_=Zp;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class t_{constructor(_0x20cfdd){this['auth']=_0x20cfdd,this['internalListeners']=new Map();}['getUid'](){var _0x34beab;return this['assertAuthConfigured'](),((_0x34beab=this['auth']['currentUser'])==null?void 0x0:_0x34beab['uid'])||null;}async['getToken'](_0x5b4999){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x5b4999)}:null;}['addAuthTokenListener'](_0x45b033){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x45b033))return;const _0x2007b2=this['auth']['onIdTokenChanged'](_0x54f059=>{_0x45b033((_0x54f059==null?void 0x0:_0x54f059['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x45b033,_0x2007b2),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x28bd6e){this['assertAuthConfigured']();const _0xe2cdad=this['internalListeners']['get'](_0x28bd6e);_0xe2cdad&&(this['internalListeners']['delete'](_0x28bd6e),_0xe2cdad(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function n_(_0x74771e){switch(_0x74771e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function i_(_0x2785cd){et(new Me('auth',(_0x2fb29e,{options:_0x534e19})=>{const _0x56cc2d=_0x2fb29e['getProvider']('app')['getImmediate'](),_0x2d0f36=_0x2fb29e['getProvider']('heartbeat'),_0x31b8d6=_0x2fb29e['getProvider']('app-check-internal'),{apiKey:_0x40ce8e,authDomain:_0x203da8}=_0x56cc2d['options'];m(_0x40ce8e&&!_0x40ce8e['includes'](':'),'invalid-api-key',{'appName':_0x56cc2d['name']});const _0x1d79ed={'apiKey':_0x40ce8e,'authDomain':_0x203da8,'clientPlatform':_0x2785cd,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x2785cd)},_0x2c2190=new Sf(_0x56cc2d,_0x2d0f36,_0x31b8d6,_0x1d79ed);return Mf(_0x2c2190,_0x534e19),_0x2c2190;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x168239,_0x7a9b3b,_0x48b70f)=>{_0x168239['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x3ccc48=>{const _0x5cc421=qe(_0x3ccc48['getProvider']('auth')['getImmediate']());return(_0x59bc44=>new t_(_0x59bc44))(_0x5cc421);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,n_(_0x2785cd)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const s_=0x12c,r_=Gr('authIdTokenMaxAge')||s_;let Fr=null;const o_=_0x23c9e4=>async _0x14410b=>{const _0x4d0ff2=_0x14410b&&await _0x14410b['getIdTokenResult'](),_0x10eb49=_0x4d0ff2&&(new Date()['getTime']()-Date['parse'](_0x4d0ff2['issuedAtTime']))/0x3e8;if(_0x10eb49&&_0x10eb49>r_)return;const _0x154197=_0x4d0ff2==null?void 0x0:_0x4d0ff2['token'];Fr!==_0x154197&&(Fr=_0x154197,await fetch(_0x23c9e4,{'method':_0x154197?'POST':'DELETE','headers':_0x154197?{'Authorization':'Bearer\x20'+_0x154197}:{}}));};function N_(_0x2cd961=Qr()){const _0x58441e=Ui(_0x2cd961,'auth');if(_0x58441e['isInitialized']())return _0x58441e['getImmediate']();const _0x7dda63=Df(_0x2cd961,{'popupRedirectResolver':e_,'persistence':[up,Zf,$a]}),_0x3e2382=Gr('authTokenSyncURL');if(_0x3e2382&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x169a16=new URL(_0x3e2382,location['origin']);if(location['origin']===_0x169a16['origin']){const _0x2116b5=o_(_0x169a16['toString']());Qf(_0x7dda63,_0x2116b5,()=>_0x2116b5(_0x7dda63['currentUser'])),Yf(_0x7dda63,_0x29dbbd=>_0x2116b5(_0x29dbbd));}}const _0x2e1816=Hr('auth');return _0x2e1816&&Lf(_0x7dda63,'http://'+_0x2e1816),_0x7dda63;}function a_(){var _0x3e6b99;return((_0x3e6b99=document['getElementsByTagName']('head'))==null?void 0x0:_0x3e6b99[0x0])??document;}bf({'loadJS'(_0x383842){return new Promise((_0x92bf09,_0x211246)=>{const _0x4485df=document['createElement']('script');_0x4485df['setAttribute']('src',_0x383842),_0x4485df['onload']=_0x92bf09,_0x4485df['onerror']=_0x4e40a9=>{const _0x460997=J('internal-error');_0x460997['customData']=_0x4e40a9,_0x211246(_0x460997);},_0x4485df['type']='text/javascript',_0x4485df['charset']='UTF-8',a_()['appendChild'](_0x4485df);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),i_('Browser');export{k_ as A,y_ as B,N_ as a,Zf as b,b_ as c,c_ as d,l_ as e,Qr as f,I_ as g,f_ as h,wl as i,v_ as j,Lt as k,Ld as l,A_ as m,C_ as n,m_ as o,u_ as p,E_ as q,h_ as r,R_ as s,w_ as t,d_ as u,T_ as v,__ as w,p_ as x,g_ as y,S_ as z};